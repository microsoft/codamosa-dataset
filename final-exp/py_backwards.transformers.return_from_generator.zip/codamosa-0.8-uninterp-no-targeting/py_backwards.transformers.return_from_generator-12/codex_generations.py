

# Generated at 2022-06-21 17:46:13.466894
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import TestCase

    defs = TestCase(__file__, "..\\tests\\definitions")
    before = ast.parse(defs('ReturnFromGeneratorTransformer'))
    after = ast.parse(defs('ReturnFromGeneratorTransformer.after'))

    assert str(after) == str(ReturnFromGeneratorTransformer().visit(before))

# Generated at 2022-06-21 17:46:17.898735
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source1, source2, source3

    tree = ast.parse(source1)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(tree) == source2

    tree = ast.parse(source1)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(tree) == source3

# Generated at 2022-06-21 17:46:28.613076
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:36.693713
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_transformed_ast_is, assert_tree_not_changed
    assert_transformed_ast_is(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            yield 1
            return 5
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """)

    assert_tree_not_changed(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            print('hello')
            return
        """)

# Generated at 2022-06-21 17:46:38.374288
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .helpers import assert_node_equal, parse_ast

# Generated at 2022-06-21 17:46:43.304890
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def test():
        yield 1
        return 5
    """
    expected_code = """
    def test():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == expected_code

# Generated at 2022-06-21 17:46:44.231720
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:53.058333
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    import sys
    import inspect

    source = '''
        def foo(x):
            yield 1
            yield 2
            return x
        def bar(x):
            return x
        def foobar(x):
            y = x
            yield y
            return y
        def foobaz(x):
            yield 1
            if True:
                return x
    '''

# Generated at 2022-06-21 17:47:01.606735
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .identity import Identity
    from ..utils.source import source

    code = '''
    def fn():
        yield 1
        return 5
    '''
    tree = ast.parse(code)
    version = (3, 2)

    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)

    identity_transformer = Identity()
    identity_transformer.visit(new_tree)

    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    assert source(new_tree) == expected

# Generated at 2022-06-21 17:47:06.352193
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_astunparse
    tree = ast.parse("""def test_return(a):\n    yield a\n    return 3\n""")
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert typed_astunparse.unparse(tree) == """def test_return(a):
    yield a
    exc = StopIteration()
    exc.value = 3
    raise exc\n"""


# Generated at 2022-06-21 17:47:16.436535
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).__class__.__name__ == 'ReturnFromGeneratorTransformer'
    assert ReturnFromGeneratorTransformer(None)._tree_changed == False
    assert hasattr(ReturnFromGeneratorTransformer(None), 'visit_FunctionDef')


# Generated at 2022-06-21 17:47:17.525273
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils import parse

    # Without yield

# Generated at 2022-06-21 17:47:19.695173
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:47:28.472913
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
                def fn():
                    yield 1
                    return 5
                def no_generator():
                    return 7
                def gen():
                    return
                    yield 1
            """
    expected = """
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
                def no_generator():
                    return 7
                def gen():
                    return
                    yield 1
            """

    code = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(code)

    assert ast.dump(code) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 17:47:38.632923
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test(func):
        node = ast.parse(func)
        next(node.body).value = ReturnFromGeneratorTransformer()(next(node.body).value)
        return compile(node, '<string>', 'exec')

    locals = {}
    test('''
    def fn():
        yield 1
        return 5
    ''')(locals)
    fn = locals['fn']()

    assert next(fn) == 1
    with pytest.raises(StopIteration) as excinfo:
        next(fn)
    assert excinfo.value.value == 5

    locals = {}
    test('''
    def fn():
        yield 1
        return
    ''')(locals)
    fn = locals['fn']()

    assert next(fn) == 1

# Generated at 2022-06-21 17:47:47.310617
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # set up the input
    __tracebackhide__ = True
    input = \
"""def fn():
    yield 1
    return 5
    yield 6
    return 7
"""

    expected_output = \
"""def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc
    yield 6
    exc = StopIteration()
    exc.value = 7
    raise exc
"""
    # compare input, expected output, and actual output
    # of the visit_FunctionDef method of ReturnFromGeneratorTransformer
    compare_visitor_output(  # noqa
        ReturnFromGeneratorTransformer(),
        input,
        expected_output,
        'visit_FunctionDef',
    )
#

# Generated at 2022-06-21 17:47:59.122594
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()._find_generator_returns(
        ast.parse('''
            def fn():
                yield 1
                if True:
                    return 5
            ''').body[0]
    ) == [
        (ast.parse('if True:\n    return 5'), ast.parse('return 5').body[0])
    ]


# Generated at 2022-06-21 17:48:10.712226
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.fake import FakeASTBuilder
    from ..utils.method_collector import method_collector
    from .return_transformer import ReturnTransformer
    from .nodes_to_function import NodesToFunctionTransformer

    ast_builder = FakeASTBuilder()
    transformer = ReturnFromGeneratorTransformer(ast_builder)

    class FakeNode(ast.AST):
        _fields = ()

    # class args(ast.AST):
    #     _fields = ()
    #
    # class FunctionDef(ast.AST):
    #     _fields = ('name', 'args', 'body')
    #     def __init__(self, name, args, body):
    #         self.name = name
    #         self.args = args
    #         self.body = body
    #
    # class Yield(ast.

# Generated at 2022-06-21 17:48:11.371808
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:48:15.090523
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformerEx.return_from_generator() == "StopIteration"
    assert ReturnFromGeneratorTransformerEx.return_from_generator.__name__ == "return_from_generator"


# Generated at 2022-06-21 17:48:26.301133
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a = ReturnFromGeneratorTransformer()
    assert a is not None


# Generated at 2022-06-21 17:48:27.489940
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:48:36.782324
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_transformer_returns import test_function_returns
    from .test_transformer_returns import test_function_no_yield
    from .test_transformer_returns import test_function_no_returns
    from .test_transformer_returns import test_function_nested_returns

    tr = ReturnFromGeneratorTransformer()

    assert tr.visit(test_function_returns) == test_function_returns
    assert tr.visit(test_function_no_yield) == test_function_no_yield
    assert tr.visit(test_function_no_returns) == test_function_no_returns
    assert tr.visit(test_function_nested_returns) == test_function_nested_returns

# Generated at 2022-06-21 17:48:46.281402
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ast_ = ast.parse("""
    def generator():
        yield 1
        return 2
    """)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_)


# Generated at 2022-06-21 17:48:53.338702
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def some_gen():
        yield 1
        return 5
    def some_no_gen():
        return 10
    """

    tree = ast.parse(source)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    tree = transformer.result()

    expected = """
    def some_gen():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    def some_no_gen():
        return 10
    """

    assert ast.dump(tree) == expected

# Generated at 2022-06-21 17:48:54.826435
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5


# Generated at 2022-06-21 17:48:56.037269
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

# Generated at 2022-06-21 17:49:07.540989
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_helpers import compile_snippet
    from .test_helpers import assert_ast

    snippet = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    assert_ast(ReturnFromGeneratorTransformer, snippet, expected)

    snippet = """
        def fn():
            yield 1
            return
    """
    expected = """
        def fn():
            yield 1
            return
    """
    assert_ast(ReturnFromGeneratorTransformer, snippet, expected)

    snippet = """
        def fn():
            def fn2():
                return 5
            yield 1
            return 5
    """

# Generated at 2022-06-21 17:49:08.412499
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:09.283223
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:45.739032
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:46.316525
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:49:54.777063
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..pretty_printer import pretty
    from ..utils.ast_helpers import parse
    h = """
    def generator():
        yield 1
        return 2

    def fn():
        return 3

    class A:
        def fn(a):
            return 4

    def generator2():
        yield 1
        return 4
    """
    # Expected result
    e = """
    def generator():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc

    def fn():
        return 3

    class A:
        def fn(a):
            return 4

    def generator2():
        yield 1
        exc = StopIteration()
        exc.value = 4
        raise exc
    """


# Generated at 2022-06-21 17:49:56.653614
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).__str__() == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-21 17:50:02.848776
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import test
    from .. import transformers
    from ..transformers.base import BaseNodeTransformer

    # def fn():
    #     yield 1
    #     return 5
    module = test.get_ast("def fn():\n    yield 1\n    return 5")
    assert test.get_source(module) == "def fn():\n    yield 1\n    return 5"

    transformed_module = transformers.ReturnFromGeneratorTransformer().visit(module)

# Generated at 2022-06-21 17:50:12.099176
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_function():
        yield 1
        return 5

    snippet_stmt = ReturnFromGeneratorTransformer().visit(
        ast.parse(inspect.getsource(test_function)))

    snippet_stmt = snippet_stmt.body[0].body  # type: ignore # noqa: F821

    assert isinstance(snippet_stmt[1], ast.Yield)
    assert isinstance(snippet_stmt[2], ast.Assign)
    assert isinstance(snippet_stmt[3], ast.Assign)
    assert isinstance(snippet_stmt[4], ast.Raise)
    assert isinstance(snippet_stmt[2].value, ast.Call)
    assert isinstance(snippet_stmt[3].value, ast.Attribute)

# Generated at 2022-06-21 17:50:15.022791
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__.__name__ == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-21 17:50:24.579282
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_setup import setup_test_out_dir, compare_ast
    from ..utils.files import source_to_ast

    test_out_dir = setup_test_out_dir(__file__)

    for i in range(4):
        file_name = '{}_in{}.py'.format(test_out_dir, i)
        with open(file_name, 'r', encoding='utf-8') as f:
            in_tree = source_to_ast.parse(f.read())

        out_tree = ReturnFromGeneratorTransformer().visit(in_tree)

        file_name = '{}_out{}.py'.format(test_out_dir, i)
        with open(file_name, 'r', encoding='utf-8') as f:
            expected_tree = source_to

# Generated at 2022-06-21 17:50:32.388415
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from ..utils.python_transformer import PythonTransformer
    from ..utils.snippet import snippet, let, load
    from ..utils.utils_for_unittests import UnittestSnippets

    class TestReturnFromGeneratorTransformer(PythonTransformer, UnittestSnippets):
        target = (3, 2)

        transformers = [ReturnFromGeneratorTransformer]

        @snippet
        def test_return_from_generator(self):
            let(return_from_generator)
            let(exc)
            let(fn)
            let(x)
            return_from_generator = \
    '''def fn():
        yield 1
        return 5
    '''
            fn = load(return_from_generator)
            x = fn()
           

# Generated at 2022-06-21 17:50:39.963630
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import create_code_snippet

    snippet = create_code_snippet(ReturnFromGeneratorTransformer)

    # test if constructor properly sets target
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.target == (3, 2)

    # test if returned value from generator is properly
    # modified
    code = snippet('''
    def fn():
        yield 1
        return 2
    ''')
    assert code == create_code_snippet('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    ''')

# Generated at 2022-06-21 17:51:16.153568
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:51:23.172486
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class ReturnFromGeneratorTransformer"""
    source = """\
    def fn():
        yield 1
        return 5
    """
    expected_ast = ast.parse("""\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    ast_tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert ast.dump(ast_tree) == ast.dump(expected_ast)

# Generated at 2022-06-21 17:51:31.399795
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import sys
    import _ast
    from typed_ast import ast3 as ast

    class MyTestCase(unittest.TestCase):
        def test_simple_return(self) -> None:
            code = '''
            def fn():
                return 5
            '''
            tree = ast.parse(code)
            expected = ast.parse(code)

            transformer = ReturnFromGeneratorTransformer()
            transformer.visit(tree)
            self.assertEqual(expected, tree)

        def test_return_from_generator(self) -> None:
            code = '''
            def fn():
                yield 1
                return 5
            '''
            tree = ast.parse(code)

# Generated at 2022-06-21 17:51:35.397696
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Arrange
    def fn():
        yield 1
        return 5
    node = ast.parse(fn.__text_signature__)
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    node = return_from_generator_transformer.visit(node)
    body = list(node.body[0].body) # type: ignore
    assert body[3].value.func.id == "StopIteration" # type:ignore

# Generated at 2022-06-21 17:51:38.965366
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with pytest.raises(TypeError) as exc:
        ReturnFromGeneratorTransformer()
    assert str(exc.value) == 'Can\'t instantiate abstract class ReturnFromGeneratorTransformer with abstract methods visit_FunctionDef'

# Generated at 2022-06-21 17:51:40.377501
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ...testing import assert_code_equal

# Generated at 2022-06-21 17:51:45.075952
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""def foo():
        yield 1
        if True:
            yield 2
            while True:
                yield 1
                return a
        yield 2
        return b
        """)
    expected = """def foo():
    yield 1
    exc = StopIteration()
    exc.value = a
    raise exc
    yield 2
    exc = StopIteration()
    exc.value = b
    raise exc
        """
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert expected == astunparse.unparse(node)

# Generated at 2022-06-21 17:51:51.141585
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    cls = ReturnFromGeneratorTransformer(None)

    tree = ast.parse("def fn():\n    yield 1\n    return 5\n")
    fn = tree.body[0]

    assert cls._find_generator_returns(fn) == [(fn, fn.body[1])]

    assert cls.visit(tree) == ast.parse("def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n")

# Generated at 2022-06-21 17:51:56.424962
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """\
    def f():
        yield 1
        return 10
    """
    expected = """\
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 10
        raise exc
    """
    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-21 17:52:01.515048
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Node:
        def value(self):
            return None
        def body(self):
            return None
    function = Node()
    returns = [((Node(), Node()), Node())]
    rfgt = ReturnFromGeneratorTransformer()
    transform = rfgt._find_generator_returns(function)
    assert transform == returns

# Generated at 2022-06-21 17:52:27.486643
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from astor import dump_tree

    assert dump_tree(ReturnFromGeneratorTransformer.get_ast(return_from_generator.get_body())) == \
        """Assign(
    targets=[Name(id='exc', ctx=Store())],
    value=Call(
        func=Name(id='StopIteration', ctx=Load()),
        args=[],
        keywords=[]))
Raise(
    exc=Name(id='exc', ctx=Load()),
    cause=None)"""

# Generated at 2022-06-21 17:52:32.656764
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # noqa
    node = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    t = ReturnFromGeneratorTransformer()
    t.visit(node)

# Generated at 2022-06-21 17:52:35.085546
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:52:43.136796
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source_repr import source_repr
    from ..utils.snippet import snippet, let
    from ..utils.ast_repr import ast_repr
    from .node_transformer import NodeTransformer
    let(gen, return_value)
    gen = ReturnFromGeneratorTransformer()
    return_value = 1
    test_function_1 = ast.parse("""
    def func():
        yield 1
        return return_value
    """)
    test_function_2 = ast.parse("""
    def func():
        yield 1
        return return_value
    """)
    gen.visit(test_function_1)
    return_statement_text = ast_repr(test_function_1).split("\n")[-2]

# Generated at 2022-06-21 17:52:52.546622
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from ..utils.test_utils import should_transform, run_transform

    src = dedent("""
    def fn1():
        yield 1
        return 1
    def fn2():
        def fn3():
            yield 1
            return 1
        yield fn3() + 1
        return 2
    def fn4():
        yield 1
        return
    def fn5():
        return 5
    def fn6():
        yield from [1]
        return 6
    """)


# Generated at 2022-06-21 17:52:53.897138
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:53:02.417428
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    m = ReturnFromGeneratorTransformer()

    fdef = ast.parse('def fn(): yield 1; return 5', 'fn', 'exec')
    m.visit(fdef)
    result = ast.dump(fdef)
    expected = ast.dump(ast.parse(
        'def fn(): yield 1; exc = StopIteration()\nexc.value = 5\nraise exc\n',
        'fn',
        'exec',
    ))

    assert expected == result



# Generated at 2022-06-21 17:53:08.005321
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from ..utils.test_utils import parse, compare
    code = """
    def fn():
        yield 5
        return 10
    """
    expected_code = """
    def fn():
        yield 5
        exc = StopIteration()
        exc.value = 10
        raise exc
    """

    module = parse(code)
    ReturnFromGeneratorTransformer().visit(module)
    compare(unparse(module), expected_code)



# Generated at 2022-06-21 17:53:18.938955
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest

    import typed_ast.ast3 as ast

    class _Tester(unittest.TestCase):
        def _test(self, input_body: str, expected_body: str) -> None:
            function_def_node = ast.parse(f'def f():\n    {input_body}')

            transformer = ReturnFromGeneratorTransformer()
            transformer.visit(function_def_node)

            result_function_def_node = ast.parse(f'def f():\n    {expected_body}')

            self.assertEqual(function_def_node, result_function_def_node)

        def test_return_in_generator(self) -> None:
            input_body = '''
                yield 1
                yield 2
                return 5
            '''

            expected_body

# Generated at 2022-06-21 17:53:27.123926
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..transpile import Transpiler

    code = 'def fn():\n    yield 1\n    return 5'
    expected_code = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'

    parsed_code = ast.parse(code) #type: ast.Module
    transpiler = Transpiler()
    transpiler.add_rule(ReturnFromGeneratorTransformer)
    transpiler.transpile_code(parsed_code)
    transpiled_code = transpiler.dump_code()

    assert(code != transpiled_code)
    assert(expected_code == transpiled_code)
    return transpiled_code

# Generated at 2022-06-21 17:54:09.309881
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:54:20.834597
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse('def number_gen():\n    yield 3\n    return 5')
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)

# Generated at 2022-06-21 17:54:21.681621
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:54:28.142494
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    code_gen1 = "def fn():\n    yield 1\n    return a\n"
    code_expected1 = "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = a\n    raise exc\n"
    tree1 = ast.parse(code_gen1)
    tree1 = ReturnFromGeneratorTransformer().visit(tree1)
    assert code_expected1 == astor.to_source(tree1)

    code_gen2 = """def fn():
    yield 1
    if True:
        return
    return a
"""
    code_expected2 = """def fn():
    yield 1
    if True:
        return
    exc = StopIteration()
    exc.value = a
    raise exc
"""

# Generated at 2022-06-21 17:54:38.762734
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def __init__(self, node):
            self.node = node     # type: ignore
            self.tree_changed = False
            self.generic_visit(self.node)

        def generic_visit(self, node):
            node = super().generic_visit(node)
            if self.tree_changed:
                raise self.TreeChanged()

        @property
        def tree_changed(self):
            return self._tree_changed

        @tree_changed.setter
        def tree_changed(self, value):
            self._tree_changed = value

        @contextmanager
        def with_tree_changed(self, value):
            old = self._tree_changed
            self._tree_changed = value
            yield None
            self._tree

# Generated at 2022-06-21 17:54:39.616656
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()



# Generated at 2022-06-21 17:54:47.319632
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(unittest.TestCase):
        def test1(self):
            nodes = ast.parse("""
                def fib(): 
                    a, b = 0, 1
                    while True:
                        yield a
                        a, b = b, a + b
            """)
            node = nodes.body[0]
            transformer = ReturnFromGeneratorTransformer()
            new_node = transformer.visit(node)
            self.assertEqual(new_node.body[0].body[0].value.value, 1)
            self.assertEqual(new_node.body[0].body[0].value.func.name, 'StopIteration')
            # self.assertEqual(new_node.body[0].body[1].value, 'a')
            # self.assertEqual(new_node.body[

# Generated at 2022-06-21 17:54:51.806666
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_ = ast.Return(value=None)
    node = ast.FunctionDef(dummy(), [], [], [return_], [])
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit_FunctionDef(node)
    assert node.body == []

# Generated at 2022-06-21 17:54:54.815522
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with open('data/ReturnFromGeneratorTransformer/sample_code.py', 'r') as f:
        code = f.read()

    tree = ast.parse(code)

    transformer = ReturnFromGeneratorTransformer(tree)
    tree_new = transformer.visit(tree)

    with open('data/ReturnFromGeneratorTransformer/transformed_code.py', 'r') as f:
        code_new = f.read()

    assert ast.dump(tree_new) == code_new

# Generated at 2022-06-21 17:54:59.720993
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    # Checks the case when return is in generator
    assert transformer.visit(ast.parse(
        """
        def fn():
            yield 1
            return 5
        """)).body == return_from_generator.get_body(return_value=ast.Num(n=5))[::-1]

    # Checks the case when return is not in generator
    assert transformer.visit(ast.parse(
        """
        def fn():
            print()
            return 5
        """)).body[1].value == 5