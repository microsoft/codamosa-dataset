

# Generated at 2022-06-21 17:46:19.897099
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..parser import fast_parse
    from ..rewriter import ast_to_code
    ast_to_code(
        ReturnFromGeneratorTransformer().visit(
            fast_parse("""
            def fn():
                yield 1
                return 2
            """)
        )
    )

# Generated at 2022-06-21 17:46:27.328368
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    expected = ast.parse('''
    def f():
        yield 1
        try:
            a = 1
            return 5
        except Exception as e:
            print(e)
    ''').body[0]

    actual = ast.parse('''
    def f():
        yield 1
        a = 1
        return 5
    ''').body[0]  # type: ignore

    assert transformer.visit(actual) == expected

# Generated at 2022-06-21 17:46:33.697224
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert_equal_with_printing(ReturnFromGeneratorTransformer().visit_FunctionDef,
                               '''
                               def foo():
                                   yield 1
                                   return 2
                               ''',
                               '''
                               def foo():
                                   yield 1
                                   exc = StopIteration()
                                   exc.value = 2
                                   raise exc
                               ''')



# Generated at 2022-06-21 17:46:35.119872
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import transform


# Generated at 2022-06-21 17:46:36.508980
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..codegen import to_source


# Generated at 2022-06-21 17:46:37.761183
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rfgt = ReturnFromGeneratorTransformer()
    return rfgt

# Generated at 2022-06-21 17:46:38.686140
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:40.065047
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer(lambda name, node: None)

# Generated at 2022-06-21 17:46:41.594115
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:51.190838
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest

    from typed_ast import ast3 as ast

    from typed_ast.transforms.return_from_generator import ReturnFromGeneratorTransformer

    def compile_snippet(src, filename='<test>'):
        from typed_ast import ast3 as ast
        from typed_ast.transforms.return_from_generator import ReturnFromGeneratorTransformer
        from typed_ast.transforms import npm

        src = '\n'.join(src)
        module = ast.parse(src, filename=filename)
        return module

    class TestReturnFromGeneratorTransformer(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def transform(self, src):
            module = compile_snippet(src)
            transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:47:05.393383
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class ReturnFromGeneratorTransformerProxy(ReturnFromGeneratorTransformer):
        def __init__(self, *args):
            self._returns = []
            self._yields = []
            self._parent = None

        def _find_generator_returns(self, node):
            self._returns = []
            self._parent = node
            return self._returns

        def _replace_return(self, parent, return_):
            self._returns.append((parent, return_))

    #parent function

# Generated at 2022-06-21 17:47:07.246547
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Arrange - Act
    transformer = ReturnFromGeneratorTransformer()

    # Assert
    assert (transformer != None)

# Generated at 2022-06-21 17:47:14.251263
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from .ast_converter import AstConverter
    from ..utils.angr_helpers import Patchable

    source = \
        """
        def fn():
            yield 1
            return 5
        """

    expected_source = \
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """

    ast_converter = AstConverter()
    return_from_generator_transformer = ReturnFromGeneratorTransformer()

    ast_node = ast_converter.parse_source(source)
    ast_node = return_from_generator_transformer.visit(ast_node)

    assert return_from_generator_transformer.tree_changed

# Generated at 2022-06-21 17:47:19.264451
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from copier.transformer_util import NodeTransformer

    node_transformer = NodeTransformer()
    node = node_transformer.visit(
        ast.parse("def fn():\n  yield 1\n  return 2\n"))
    generator_transformer = ReturnFromGeneratorTransformer()
    generator_transformer.visit(node)

# Generated at 2022-06-21 17:47:22.516560
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import unparse
    from ..utils.snippet import compile_text
    from ..testing import assert_text_transformation


# Generated at 2022-06-21 17:47:26.730328
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
        transformer = ReturnFromGeneratorTransformer()
        tree = ast.parse("""def fn():
            yield 1
            return 5
            """)
        ast.fix_missing_locations(tree)
        transformer.visit(tree)
        assert transformer._tree_changed == True

# Generated at 2022-06-21 17:47:32.172597
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    BaseNodeTransformerTest.test_method(ReturnFromGeneratorTransformer, 'visit_FunctionDef', """
        def fn():
            yield 1
            return 5
        """, """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """)

# Generated at 2022-06-21 17:47:40.698958
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""def fn():
    yield 1
    return 5
""")
    node = tree.body[0]
    assert isinstance(node, ast.FunctionDef)

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)

    expected = ast.parse("""def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc
""")
    assert isinstance(result, ast.FunctionDef)
    assert codegen(expected) == codegen(result)
    assert transformer._tree_changed

# Generated at 2022-06-21 17:47:41.602218
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:47:46.396371
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = """
        def fn():
            yield 1
            return 'a'
    """

    expect = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 'a'
            raise exc
    """
    mod = ast.parse(tree)
    ReturnFromGeneratorTransformer().visit(mod)
    assert expect == astor.to_source(mod)

# Generated at 2022-06-21 17:47:57.463706
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    nodes_to_test = [ast.parse(
        """
        def fn():
            yield 1
            return 2
        """
    )]

    for node in nodes_to_test:
        print('Before')
        print(ast.dump(node))
        print(ReturnFromGeneratorTransformer().visit(node))

# Generated at 2022-06-21 17:48:02.461540
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""def fn():\n    yield 1\n    return 5""").body[0]
    trans = ReturnFromGeneratorTransformer()
    trans.visit(node)
    expected = ast.parse("""def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc""").body[0]
    assert ast.dump(node) == ast.dump(expected)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 17:48:03.933000
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:48:14.646014
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        a = 1
        return a

    def fn2():
        yield 2
        return 2

    def fn3():
        yield from []
        return 3

    def fn4():
        return 4

    def fn5():
        yield 5

    for code, fname in [(fn, 'fn'), (fn2, 'fn2'), (fn3, 'fn3'), (fn4, 'fn4'), (fn5, 'fn5')]:
        root = ast.parse(dedent(code.__doc__))
        assert isinstance(root, ast.Module)
        node = getattr(root, fname)
        ReturnsFromGeneratorTransformer().visit(node)
        new_code = ast.unparse(root)
        assert new_code



# Generated at 2022-06-21 17:48:23.352592
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # First test
    g = ReturnFromGeneratorTransformer()
    func_def = ast.FunctionDef(name='fn', body=[ast.Return(value=ast.Num(5))])
    func_def = g.visit(func_def)
    assert not g._tree_changed

    # Second test
    g = ReturnFromGeneratorTransformer()
    func_def = ast.FunctionDef(name='fn', body=[ast.Yield(value=ast.Num(1)), ast.Return(value=ast.Num(5))])
    func_def = g.visit(func_def)
    assert g._tree_changed
    assert type(func_def.body[1]) == ast.Assign
    assert type(func_def.body[2]) == ast.Expr

# Generated at 2022-06-21 17:48:33.723055
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    defs = (
        """
        def fn():
            yield 1
            return 5
        """,
        """
        def fn():
            if True:
                yield 1
            else:
                yield 1
            return 5
        """,
        """
        def fn():
            yield 1
            if True:
                yield 1
            else:
                return 5
            return 6
        """,
    )
    for def_ in defs:
        node = ast.parse(def_)
        transformer.visit(node)
        assert (node.body[0].body[-1].value.func.id == 'StopIteration'
                and node.body[0].body[-1].value.args[0].value.value == 5)

# Generated at 2022-06-21 17:48:35.346599
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer

# Generated at 2022-06-21 17:48:36.474565
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:48:42.352321
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_transformer_utils import compare
    method_body = """def fn():
    yield 1
    return 5"""
    expected_body = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""

    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse(method_body)
    compare(node, expected_body, transformer)


# Generated at 2022-06-21 17:48:47.202363
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    node = ast.parse(fn.__code__.co_consts[0])
    transformer = ReturnFromGeneratorTransformer()  # type: ignore
    transformer.visit(node)
    assert len(transformer.warnings) == 0


# Generated at 2022-06-21 17:49:06.363281
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    actual = ReturnFromGeneratorTransformer().visit(ast.parse(code))
    assert ast.dump(ast.parse(expected)) == ast.dump(actual)

# Generated at 2022-06-21 17:49:07.279580
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer



# Generated at 2022-06-21 17:49:08.492535
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:49:15.613702
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    def fn_result():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    node = ast.parse(inspect.getsource(fn))
    node_expected = ast.parse(inspect.getsource(fn_result))

    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(node) == node_expected

# Generated at 2022-06-21 17:49:20.564069
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .visitor import dump
    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    '''
    node = ast.parse(expected).body[0]
    assert dump(node) == expected
    assert dump(ReturnFromGeneratorTransformer().visit(node)) == expected

# Generated at 2022-06-21 17:49:22.112899
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:27.196817
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal

    node = ast.parse("""
        def fn(a, b):
            yield a
            return 5
    """)
    new_node = ReturnFromGeneratorTransformer().visit(node)
    assert_code_equal(compile(new_node, '', 'exec'), """\
        def fn(a, b):
            yield a
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)



# Generated at 2022-06-21 17:49:28.331333
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:39.733787
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestReturnFromGeneratorTransformer(unittest.TestCase):

        def _test_return_int_function(self, func):
            gen = func()
            self.assertEqual(next(gen), 1)
            self.assertEqual(next(gen), 2)
            self.assertEqual(next(gen), 3)
            with self.assertRaises(StopIteration) as raised_ex:
                next(gen)
            self.assertEqual(raised_ex.exception.value, 4)

        def test_return_int_generator(self):
            @return_from_generator
            def fn():
                yield 1
                yield 2
                return 3
                yield 4

            self._test_return_int_function(fn)


# Generated at 2022-06-21 17:49:49.325046
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer(None)
    source = '''def test():
        d={}
        try:
            return 5
            a = 5
        except Exception as e:
            pass
        yield 5'''
    expected_source = '''def test():
    d = {}
    try:
        exc = StopIteration()
        exc.value = 5
        raise exc
        a = 5
    except Exception as e:
        pass
    yield 5'''
    tree = ast.parse(source)
    node = tree.body[0]
    assert isinstance(node, ast.FunctionDef)
    assert not node.body[0].body[0].body
    assert node.body[0].body[0].finalbody
    transformed = transformer.visit_FunctionDef(node)


# Generated at 2022-06-21 17:49:58.337035
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import run_test_ast


# Generated at 2022-06-21 17:50:00.079407
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:50:10.461015
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    src = """
        def g():
            yield 1
            return 2
        """
    expected_res = """
        def g():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """

    tree = ast.parse(src)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(new_tree, include_attributes=False) == expected_res

    src = """
    def g():
        a = yield 2
        return 4
    """
    expected_res = """
    def g():
        a = yield 2
        exc = StopIteration()
        exc.value = 4
        raise exc
    """

    tree = ast.parse(src)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-21 17:50:20.101893
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test cases
    test_cases = [
        (
            ast.parse(
                """
                def foo():
                    yield 1
                    return 5
                """,
                mode="exec"
            ),
            ast.parse(
                """
                def foo():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
                """,
                mode="exec"
            )
        )
    ]

    for test_case in test_cases:
        # Call method visit_FunctionDef
        ReturnFromGeneratorTransformer().visit(test_case[0])
        # Compare
        assert ast.dump(test_case[0]) == ast.dump(test_case[1])

# Generated at 2022-06-21 17:50:28.378599
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # case 1, target = (3, 2)
    node = ast.parse("""
            def fn():
                yield 1
                return 5
        """)

    expected = ast.parse("""
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        """)
    actual = ReturnFromGeneratorTransformer().visit_FunctionDef(node.body[0])

    assert expected.body[0].body == actual.body

    # case 2, target != (3, 2)
    node = ast.parse("""
            def fn():
                yield 1
                return 5
        """)

    expected = ast.parse("""
            def fn():
                yield 1
                return 5
        """)
    actual = ReturnFromGeneratorTransformer(target=(3, 7)).vis

# Generated at 2022-06-21 17:50:31.497743
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_test = ReturnFromGeneratorTransformer()
    assert class_test is not None

# Generated at 2022-06-21 17:50:40.858720
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Check test_case_1
    case_1 = ReturnFromGeneratorTransformer()
    case_1._tree_changed = False
    case_1._find_generator_returns(ast.parse("""\
        def fn():
            yield 1
            return 2
            """))
    assert case_1._tree_changed == True

    # Check test_case_2
    case_2 = ReturnFromGeneratorTransformer()
    case_2._tree_changed = False
    case_2._find_generator_returns(ast.parse("""\
        def fn():
            return 2
            """))
    assert case_2._tree_changed == False

    # Check test_case_3
    case_3 = ReturnFromGeneratorTransformer()
    case_3._tree_changed = False
    case_3._find

# Generated at 2022-06-21 17:50:43.804487
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__.__name__ == 'ReturnFromGeneratorTransformer'
    assert ReturnFromGeneratorTransformer.target == (3, 2)


# Generated at 2022-06-21 17:50:54.107958
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:55.743983
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:51:26.970914
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from pprint import pprint
    from .unparse import Unparser


# Generated at 2022-06-21 17:51:28.160983
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer


# Generated at 2022-06-21 17:51:36.694180
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast_str = "def foo():\n  yield 1\n  return 5"
    new_ast_str = "def foo():\n  yield 1\n  exc = StopIteration()\n  exc.value = 5\n  raise exc\n"
    ast_tree = ast.parse(ast_str)
    new_ast_tree = ast.parse(new_ast_str)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert ast.dump(ast_tree) == ast.dump(new_ast_tree)


# Generated at 2022-06-21 17:51:44.089589
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer

    # node1
    stmts = []
    stmts.append(ast.Return(value=ast.List(elts=[], ctx=ast.Load())))
    stmts.append(ast.Return(value=ast.Tuple(elts=[], ctx=ast.Load())))
    body = stmts
    funcdef = ast.FunctionDef('test', args=None, body=body, decorator_list=[],
                              returns=None)
    funcdef.args = ast.arguments(args=[], vararg=None, kwonlyargs=[],
                                 kw_defaults=[], kwarg=None, defaults=[])
    funcdef.decorator_list = []
    funcdef.returns = None
    type_ignores = None

    node

# Generated at 2022-06-21 17:51:45.144880
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse

# Generated at 2022-06-21 17:51:52.950935
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap
    from typed_astunparse import unparse

    # Test compiling return from generator
    code = textwrap.dedent('''
        def gen():
            yield 1
            return 5
    ''')

    module = ast.parse(code)
    node = module.body[0]  # type: ignore

    with __fuck_python_version__:
        transformer = ReturnFromGeneratorTransformer()
        result = transformer.visit(node)  # type: ignore

    expected = textwrap.dedent('''
        def gen():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')
    assert unparse(result) == expected

    # Test compiling return from generator to a nested generator

# Generated at 2022-06-21 17:52:00.707521
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from io import StringIO
    from . import get_node
    from . import compile_snippet
    from . import pprint_node

    # <<< tests >>> (1 of 1)
    test_source = \
        """\
        def generator_fn1():
            y = yield 2
            return 2
        def generator_fn2():
            yield 2
            return 2
        def generator_fn3():
            yield 2
            return 2
            yield 2
        def generator_fn4():
            yield 2
            y = yield 2
            return 2
        def fn1():
            return 2
        def fn2():
            yield 2
            return 2
        def fn3():
            yield 2
            y = yield 2
            return 2
        print(generator)
        """

# Generated at 2022-06-21 17:52:05.805868
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
        def foo():
            yield 1
            return 2
        def bar():
            yield 1
            return 2
            if True:
                yield 3
            if not True:
                return 4
        def baz():
            if True:
                yield 1
            return 2
    """


# Generated at 2022-06-21 17:52:14.811728
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse('def fn():\n yield 10\n return 12').body[0]) == []
    assert ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse('def fn():\n yield 10\n return 12').body[0]) == []
    assert ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse('def fn():\n yield 10\n if True:\n  return 12').body[0]) == []
    assert ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse('def fn():\n yield 10\n if True:\n  return 12\n else:\n  yield 13').body[0]) != []
    assert ReturnFromGeneratorTransformer()._find_generator_returns

# Generated at 2022-06-21 17:52:18.952699
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert '_find_generator_returns' in dir(transformer)
    assert '_replace_return' in dir(transformer)
    assert 'visit_FunctionDef' in dir(transformer)

test_ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:52:59.163308
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:53:02.441192
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    gen = ast.parse("""
    def f():
        yield 1
        yield 2
        return 5
        yield 3
    """).body[0]
    ast.fix_missing_locations(gen)
    ReturnFromGeneratorTransformer().visit(gen)

    expected_gen = ast.parse('''
    def f():
        yield 1
        yield 2
        exc = StopIteration()
        exc.value = 5
        raise exc
        yield 3
    ''').body[0]
    ast.fix_missing_locations(expected_gen)

    assert ast.dump(gen) == ast.dump(expected_gen)

# Generated at 2022-06-21 17:53:06.852809
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    print("TEST RETURN FROM GENERATOR TRANSFORMER")
    tree = ast.parse("""
    def generator():
        yield 1
        return
    """)
    ret_from_gen_transformer = ReturnFromGeneratorTransformer()
    ret_from_gen_transformer.visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-21 17:53:15.230974
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(ast.NodeVisitor):
        # test for transform:
        #   def fn():
        #       yield 1
        #       return 5
        # to:
        #   def fn():
        #       yield 1
        #       exc = StopIteration()
        #       exc.value = 5
        #       raise exc
        def visit_FunctionDef(self, node):
            if node.name == 'fn':
                return ReturnFromGeneratorTransformer.visit_FunctionDef(self, node)


# Generated at 2022-06-21 17:53:24.137121
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from sys import version_info
    ast_tree = ast.parse(
'''def fn():
    yield 1
    return 5
''')

    if version_info.major == 2:
        node = ast_tree.body[0]
    else:
        node = ast_tree.body[0].body[0]

    parent = ast_tree.body[0]

    return_ = ast.Return()
    return_.value = ast.Num(5)

    transformer = ReturnFromGeneratorTransformer()

    transformed = transformer.visit_FunctionDef(ast_tree.body[0])

    assert(transformed == parent)
    assert(transformer._tree_changed == True)
    assert(transformer._find_generator_returns(node) == [(parent, return_)])

# Generated at 2022-06-21 17:53:27.017219
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    f = ast.parse('def f():\n yield 1\n return 1')
    f = ast.fix_missing_locations(f)
    f = ReturnFromGeneratorTransformer().visit(f)
    assert compile(f, '<test>', 'exec')

# Generated at 2022-06-21 17:53:33.402849
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse('def fn():\n  yield 1\n  return 2')
    new_node = ReturnFromGeneratorTransformer().visit(node)

# Generated at 2022-06-21 17:53:41.820107
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse("""def fn():
        yield 1
        return 5""").body[0]) == [
        (ast.parse("def fn():\n        yield 1\n        return 5").body[0],
        ast.parse("return 5").body[0])
    ]
    assert ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse("""def fn():
        if True:
            yield 1
        return 5""").body[0]) == [
        (ast.parse("def fn():\n        if True:\n            yield 1\n        return 5").body[0],
        ast.parse("return 5").body[0])
    ]

# Generated at 2022-06-21 17:53:47.949901
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Return(ast.Return):
        def __init__(self):
            super().__init__(value=ast.Constant(value=5))
    class FunctionDef(ast.FunctionDef):
        def __init__(self):
            super().__init__(name='fn', body=[ast.Yield(value=ast.Constant(value=1)), Return(), ast.Yield(value=ast.Constant(value=2))])
    class Module(ast.Module):
        def __init__(self):
            super().__init__(body=[FunctionDef()])

    module = Module()
    ReturnFromGeneratorTransformer().visit(module)
    expected = Module()

# Generated at 2022-06-21 17:53:52.735009
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Test that the constructor works properly
    astnode = ast.parse("def fn():\n    yield 1\n    return 5")
    fn = astnode.body[0]
    ref = ReturnFromGeneratorTransformer()
    assert ref._find_generator_returns(fn) == [(fn, ast.Return(value=ast.Num(n=5)))]


# Generated at 2022-06-21 17:55:18.078720
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestReturnFromGeneratorTransformer(unittest.TestCase):
        def test_ReturnFromGeneratorTransformer_init(self):
            transformer = ReturnFromGeneratorTransformer()
            self.assertIsInstance(transformer, ReturnFromGeneratorTransformer)


# Generated at 2022-06-21 17:55:28.328528
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    import ast

    class DummyVisitor(ast.NodeVisitor):
        def visit_FunctionDef(self, node):
            return ast3.Return(ast3.Num(3))

    source = """
    def fn():
        x = 1
        yield 2
        return x
    """
    expected = """
    def fn():
        x = 1
        yield 2
        exc = StopIteration()
        exc.value = x
        raise exc
    """
    node = ast3.parse(source)
    DummyVisitor().visit(node)
    code = ast3.unparse(node)
    assert code == expected


# Generated at 2022-06-21 17:55:33.038859
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .basic_transformers import BasicTransformers
    from .print_to_log import PrintToLogTransformer
    import astor

    basic_transformer = BasicTransformers()
    printer = PrintToLogTransformer()
    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:55:41.970639
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:55:43.251691
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:55:50.461765
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()
    func_def = """
    def fn():
        yield 1
        return 5
    """
    result = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected = ast.parse(result).body[0]
    actual = ast.parse(func_def)
    ReturnFromGeneratorTransformer().visit(actual)
    assert ast.dump(expected) == ast.dump(actual)

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:56:00.466765
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import ast
    import _ast
    import astor
    source = """
    def foo():
        yield 1
        return 5
    """
    ast_tree = astor.parse_file(source)
    # print(astor.dump_tree(ast_tree))
    ast_tree = ReturnFromGeneratorTransformer().visit(ast_tree)
    expected = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    assert astor.to_source(ast_tree) == expected

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:56:03.050370
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rfgt = ReturnFromGeneratorTransformer()
    return rfgt

# unit test for function find_generator_returns

# Generated at 2022-06-21 17:56:09.717259
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def f(a):
        for i in a:
            yield i
        return 10

    expected = """def f(a):
    for i in a:
        yield i
    exc = StopIteration()
    exc.value = 10
    raise exc
"""
    node = ast.parse(snippet(f))
    ReturnFromGeneratorTransformer().visit(node)
    got = ast.unparse(node).strip()
    assert got == expected, got
