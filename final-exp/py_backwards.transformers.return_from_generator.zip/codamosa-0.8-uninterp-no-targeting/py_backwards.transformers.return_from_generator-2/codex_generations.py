

# Generated at 2022-06-21 17:46:14.228428
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.transform import run_transform_class
    from ..utils.codegen import to_source
    from ..utils.ast import compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    compare_ast(
        run_transform_class(ReturnFromGeneratorTransformer, source=source),
        run_transform_class(ReturnFromGeneratorTransformer, source=expected),
        check_source=True,
        source=source,
    )

# Generated at 2022-06-21 17:46:16.246126
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer


# Generated at 2022-06-21 17:46:17.198106
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:28.037353
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.fixtures import ast_fn1
    from ..utils.check import check_visitor

    fnA = ast_fn1.__data__()
    fnB = fnA.copy()  # type: ignore
    fnC = fnA.copy()  # type: ignore

    class test(ast.NodeVisitor):
        def visit_FunctionDef(self, node):
            if node.name == "fnA":
                return ReturnFromGeneratorTransformer.visit_FunctionDef(self, node)  # type: ignore
            else:
                return node

    test().visit(fnA)
    ReturnFromGeneratorTransformer().visit(fnB)
    assert check_visitor(fnA, fnB)


# Generated at 2022-06-21 17:46:32.850626
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    '''Unit test for constructor of class ReturnFromGeneratorTransformer'''
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.target == (3, 2)
    assert transformer._tree_changed == False
    assert transformer._module == None


# Generated at 2022-06-21 17:46:38.596057
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    transformer = ReturnFromGeneratorTransformer()

    node = ast.parse(fn.__code__.co_code)
    transformer.visit(node)
    assert transformer.tree_changed

    fn_code = compile(node, '', 'exec')
    glob = {}
    exec(fn_code, glob)
    gen = glob['fn']()
    assert next(gen) == 1
    assert next(gen) == 5

# Generated at 2022-06-21 17:46:47.013681
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ast_tree: ast.AST = ast.parse(
        """
        def fn():
            yield 1
            return 5
        """
    )
    node_transformer = ReturnFromGeneratorTransformer()
    node_transformer.visit(ast_tree)

# Generated at 2022-06-21 17:46:55.758236
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3
    from .utils import update_source_code

    source = """
        def foo():
            yield 1
            return 2
        """
    expected_source = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        """

    node = ast3.parse(source)
    updated_node = update_source_code(ReturnFromGeneratorTransformer(), node)
    new_source = ast3.unparse(updated_node)

    assert new_source == expected_source

# Generated at 2022-06-21 17:47:00.056218
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast_tree = ast.parse("""
        def fn():
            yield 1
            return 5
    """)

    Result = ReturnFromGeneratorTransformer.get_result_type(ast_tree)
    result = ReturnFromGeneratorTransformer().visit(ast_tree)
    assert isinstance(result, Result)

    exec(compile(result, '', 'exec'), globals(), locals())

    assert list(fn()) == [1]

# Generated at 2022-06-21 17:47:07.774709
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()

    test_code_snippet = """
    def foo():
        yield 1
        yield 2
        yield 3
        return 4
    """
    test_code = ast.parse(test_code_snippet)

    return_from_generator_transformer.visit(test_code)

    # Node:
    # <Node lineno="1" col_offset="0" object="<_ast.FunctionDef object at 0x7fcaaaef0c88>" >
    # expected_ast = ast.FunctionDef(
    #     name='foo',
    #     args=ast.arguments(
    #         args=[],
    #         vararg=None,
    #         kwonlyargs=[],
    #         kw_defaults

# Generated at 2022-06-21 17:47:17.813400
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = '''
    def func():
        yield 1
        return 2
    '''
    expected_result = '''
    def func():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    '''
    root = ast.parse(source, mode='exec')
    result = ReturnFromGeneratorTransformer().visit(root)
    assert ast.dump(result) == expected_result

# Generated at 2022-06-21 17:47:18.872190
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:26.497757
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn():
        yield 1
        return 5
    def fn2():
        yield 1
        return
    def fn3():
        return 5
    """
    # check for function fn
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    def fn2():
        yield 1
        return
    def fn3():
        return 5
    """
    compare(ReturnFromGeneratorTransformer, source, expected)


# Generated at 2022-06-21 17:47:33.499846
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    node = ast.parse(textwrap.dedent("""\
        def fn():
            yield 1
            return 5
        """))  # type: ast.AST
    expected_ast = ast.parse(textwrap.dedent("""\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """))  # type: ast.AST

    assert ast.dump(node) == ast.dump(expected_ast)

# Generated at 2022-06-21 17:47:44.710796
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_ = ast.Return(value=ast.Name(id='x', ctx=ast.Load()))

    parent = ast.FunctionDef(name='generator', args=ast.arguments(
        args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Yield(value=ast.Name(id='x', ctx=ast.Load())), return_], decorator_list=[], returns=None)

    node = ast.Module(body=[parent])

    rfg_transformer = ReturnFromGeneratorTransformer()
    transformed_node = rfg_transformer(node)

    assert transformed_node.body[0].body[0].value.id == 'x'

# Generated at 2022-06-21 17:47:48.714140
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""
        def fn():
            yield 1
            yield 2
            return 5
    """)

    fn = tree.body[0]
    for line in return_from_generator.get_body():
        assert line in fn.body[-3:]

    assert isinstance(fn.body[-1], ast.Return)
    assert fn.body[-1].value is None



# Generated at 2022-06-21 17:47:58.164215
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_snippet import test_Snippet
    from .transformers import AllTransformers, ClassTransformer
    class_transformer = ClassTransformer()
    class_transformer.apply('tests/resources/return_from_generator.py')

    test_Snippet(ReturnFromGeneratorTransformer(),
                 'tests/resources/return_from_generator.py',
                 'tests/resources/return_from_generator_target.py',
                 ignore_whitespace=True)

    # test if the transformer is in AllTransformers
    assert(ReturnFromGeneratorTransformer in AllTransformers)

# Generated at 2022-06-21 17:48:00.208113
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:48:10.859703
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import run_on_examples

    def func(fn, expected):
        node = ast.parse(fn)

        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(node)

        actual = ast.unparse(node)

        assert actual == expected


# Generated at 2022-06-21 17:48:21.146384
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ast import FunctionDef
    from compiler import ast27
    from compiler.ast import Printnl, Discard

    ast27.ReturnFromGeneratorTransformer = ReturnFromGeneratorTransformer


# Generated at 2022-06-21 17:48:26.639059
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    # Add a dummy docstring

# Generated at 2022-06-21 17:48:28.609613
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__.__name__ == 'ReturnFromGeneratorTransformer'


# Generated at 2022-06-21 17:48:34.466848
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def f():
        yield from [1, 2]
        return 1
    """
    expected = """
    def f():
        yield from [1, 2]
        exc = StopIteration()
        exc.value = 1
        raise exc
    """
    tree = ast.parse(source)

    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)

    actual = astunparse.unparse(tree)

    assert expected == actual

# Generated at 2022-06-21 17:48:42.391334
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3 as typed_ast
    import astunparse
    import textwrap

    tree = typed_ast.parse(textwrap.dedent('''
        def fn():
            yield 1
            return 5
        '''))
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(tree)
    code = astunparse.unparse(node)

    expected = textwrap.dedent('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''')

    assert expected == code



# Generated at 2022-06-21 17:48:50.527100
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # List of variables that should be transformed by the constructor.
    # This list should be checked by constructor when expanding.
    assert ReturnFromGeneratorTransformer._find_generator_returns(None, ast.parse(
        "def a():\n    yield 1\n    return 5\n").body[0])
    assert ReturnFromGeneratorTransformer._find_generator_returns(None, ast.parse(
        "def a():\n    return 5\n").body[0]) == []
    assert ReturnFromGeneratorTransformer._find_generator_returns(None, ast.parse(
        "def a():\n    try:\n        yield 1\n    finally:\n        return 5\n").body[0])

# Generated at 2022-06-21 17:48:51.534110
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tester = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:49:00.206036
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    # Test if _find_generator_returns function can find return statement in a generator function
    test_generator_tree = return_from_generator.get_ast(return_value=5)
    generator_returns = return_from_generator_transformer. \
        _find_generator_returns(test_generator_tree)
    assert generator_returns[0][1].value.n == 5
    assert len(generator_returns) == 1
    # Test _replace_return function
    test_generator_tree = return_from_generator.get_ast(return_value=5)

# Generated at 2022-06-21 17:49:09.939269
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(ast.parse("""
                            def fn():
                                yield 1
                                return 4
                        """)) == ast.parse("""
                            def fn():
                                yield 1
                                exc = StopIteration()
                                exc.value = 4
                                raise exc
                        """)  # type: ignore
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(ast.parse("""
                            def fn():
                                yield 1
                                return 4
                                yield 3
                        """)) == ast.parse("""
                            def fn():
                                yield 1
                                exc = StopIteration()
                                exc.value = 4
                                raise exc
                                yield 3
                        """ )

# Generated at 2022-06-21 17:49:18.022210
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing_utils import assert_equal_ast
    from ast_tools.transformers import ASTTransformer
    from ast_tools.testing_utils import generate_python_ast
    from ast_tools.testing_utils.transformer import get_ast_code

    code = '''
    def fn(x):
        if x == 5:
            yield 1
            return 3 + 2
        return
    '''

    expected_ast = generate_python_ast('''
    def fn(x):
        if x == 5:
            yield 1
            exc = StopIteration()
            exc.value = 3 + 2
            raise exc
        return
    ''')

    ast_ = generate_python_ast(code)

    transformed_ast = ASTTransformer([ReturnFromGeneratorTransformer]).visit(ast_)
    assert_equal

# Generated at 2022-06-21 17:49:19.024536
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:26.463776
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:27.232954
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-21 17:49:27.899767
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:37.400545
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from .. import compile_isolated

    node = ast.parse(source(
        """
        def fn():
            yield 1
            return 'return value'
        """
    ))

    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)  # type: ignore

    compiled = compile_isolated(new_node, flags=ast.PyCF_ONLY_AST)

    source_node = ast.parse(compiled)

    assert source_node.body[0].body[1].value.args[0].value.value == 'return value'

# Generated at 2022-06-21 17:49:40.433761
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import (
        assert_tree_equal,
        create_ast_tree,
        get_value,
    )


# Generated at 2022-06-21 17:49:41.989065
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:50.775920
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # test: visit_FunctionDef(), when return should be transformed
    node_original_1 = ast.parse('def fn():\n    yield 1\n    return 5')
    node_expected_1 = ast.parse('def fn():\n\
        yield 1\n\
        exc = StopIteration()\n\
        exc.value = 5\n\
        raise exc')

    transformer = ReturnFromGeneratorTransformer()

    node_transformed = transformer.visit(node_original_1)
    assert transformer._tree_changed == True
    assert ast.dump(node_transformed, include_attributes=True) == ast.dump(node_expected_1, include_attributes=True)

    # test: visit_FunctionDef(), when return shouldn't be transformed

# Generated at 2022-06-21 17:50:01.466025
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # # Unit test for ReturnFromGeneratorTransformer._find_generator_returns
    def test_find_generator_returns(fn):
        transformer = ReturnFromGeneratorTransformer()

        fn_ast = ast.parse(fn)

        fn_ast = transformer.visit(fn_ast)

        transpiled_fn = compile(fn_ast, '', 'exec')
        fn_namespace = {}
        exec(transpiled_fn, fn_namespace)
        transpiled_fn = fn_namespace['fn']

        _ = list(transpiled_fn())

    # Unit test for ReturnFromGeneratorTransformer._find_generator_returns
    # Test 1
    fn = """
    def fn():
        yield 1
        return
    """

# Generated at 2022-06-21 17:50:11.343946
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MyTestNodeTransformer(ReturnFromGeneratorTransformer):
        # pylint: disable = protected-access
        def _find_generator_returns(self, node):  # type: ignore
            return [(x, y) for x, y in super()._find_generator_returns(node)]  # type: ignore

        def _replace_return(self, parent, return_):  # type: ignore
            parent.result = return_

    code = """
        def f1():
            yield 1
            return 2
        def f2():
            return 3
    """
    tree = ast.parse(code)  # type: ignore
    MyTestNodeTransformer().visit(tree)  # type: ignore
    assert tree.body[0].result.value.n == 2

# Generated at 2022-06-21 17:50:20.053402
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_returns(code, expected_returns):
        node = ast.parse(code)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(node)

        code = compile(node, '', 'exec')
        glb = {}
        exec(code, glb)
        generator = glb['fn']()
        for expected in expected_returns:
            assert next(generator) == expected

    test_returns('def fn():\n\tyield 1', [1])
    test_returns('def fn():\n\tyield 1\n\treturn 5', [1])

# Generated at 2022-06-21 17:50:40.487474
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3, parse
    from . import _test_transform, assert_stmt

    def test_transformer(fn):
        node = parse(fn)
        assert isinstance(node, ast3.Module)

        transformer = ReturnFromGeneratorTransformer()
        new_node = transformer.visit(node)

        return new_node, transformer._tree_changed


# Generated at 2022-06-21 17:50:46.102627
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..compiler import Compiler
    from ..utils.testing import assert_program

    class R:
        def __init__(self):
            self.x = 1
            self.y = 0
            self.state = 0

    r = R()

# Generated at 2022-06-21 17:50:50.556354
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def check(src, dst):
        t = ReturnFromGeneratorTransformer()
        tree = ast.parse(src)
        t.visit(tree)
        assert ast.dump(tree) == dst

# Generated at 2022-06-21 17:50:57.121918
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    f = inspect.currentframe()
    outerframes = inspect.getouterframes(f)
    file_ = outerframes[1][1]
    with open(file_, 'r') as f:
        source = f.read()
    tree = ast.parse(source)

    gen_transformer = ReturnFromGeneratorTransformer(tree=tree, source=source)
    tree = gen_transformer.visit(tree)
    source2 = gen_transformer.rewrite(source)

    fn_def = tree.body[0]
    assert isinstance(fn_def, ast.FunctionDef)
    assert fn_def.name == 'Transformer'

    assert len(fn_def.body) == 7  # type: ignore
    assert isinstance(fn_def.body[-1], ast.Return)  # type: ignore


# Generated at 2022-06-21 17:50:58.097723
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:51:05.015913
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1

    assert list(fn()) == [1]

    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(source)

    new_tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(new_tree) == expected_source



# Generated at 2022-06-21 17:51:09.662001
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(code)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    generated_code = ast.unparse(new_tree)
    assert generated_code == expected

# Generated at 2022-06-21 17:51:10.612698
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:51:18.125729
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base import transform

    def f():
        yield 1
        return 5
    code = '''def f():
    yield 1
    return 5'''
    expected_code = '''def f():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc'''
    assert transform(ReturnFromGeneratorTransformer, f) == expected_code
    assert transform(ReturnFromGeneratorTransformer, code) == expected_code

# Generated at 2022-06-21 17:51:20.285289
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:51:52.230612
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import FunctionDef, Return, Yield
    from .utils import to_source

    tree = FunctionDef(name='fn', args=None, returns=None,
                       body=[
                           Yield(value=None),
                           Return(value=None),
                           Return(value=None),
                       ])
    t = ReturnFromGeneratorTransformer()
    t.visit(tree)


# Generated at 2022-06-21 17:51:53.460496
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:52:01.071545
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def assert_code(expected, code):
        expected = expected.strip()
        tree = ast.parse(code)
        transformer = ReturnFromGeneratorTransformer()
        transformed = transformer.visit(tree)
        transformer.assert_sync()

        assert ast.dump(transformed).strip() == expected

    # No returns
    assert_code('''
        def test():
            yield 1
            return
            1
    ''', '''
        def test():
            yield 1
            return
            1
    ''')

    # Return in non-generator
    assert_code('''
        def test():
            return 1
            1
    ''', '''
        def test():
            return 1
            1
    ''')

    # Returns in generator

# Generated at 2022-06-21 17:52:03.095959
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Check that class is constructed properly."""
    _ = ReturnFromGeneratorTransformer()



# Generated at 2022-06-21 17:52:08.023566
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils import test_ast

    code = """\
    def fn():
        yield 1
        return 5
    """
    expected_code = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = test_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert test_ast(expected_code) == tree

# Generated at 2022-06-21 17:52:12.422315
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test for constructor of class ReturnFromGeneratorTransformer."""
    from ..utils.snippet import parse
    from ..utils.compat import StringIO

    fake_file = StringIO()
    transformer = ReturnFromGeneratorTransformer(fake_file, parse('def fn():\n    yield 1\n    return "test"'))
    assert transformer is not None


# Generated at 2022-06-21 17:52:22.062727
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(textwrap.dedent("""\
    def a():
        x = 10
        y = a()
        return b()
    """))  # type: ignore
    ReturnFromGeneratorTransformer().visit(node)

# Generated at 2022-06-21 17:52:28.484302
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    tree = ast.parse(fn.__code__)
    ReturnFromGeneratorTransformer().visit(tree)


# Generated at 2022-06-21 17:52:32.963873
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    node = ast.parse('def fn(x):\n    yield x\n    return x + 1')
    expected = ast.parse('def fn(x):\n    yield x\n    exc = StopIteration()\n    exc.value = x + 1\n    raise exc')
    assert astunparse.unparse(ReturnFromGeneratorTransformer().visit(node)) == astunparse.unparse(expected)


# Generated at 2022-06-21 17:52:41.562226
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test."""
    def test(func: ast.FunctionDef) -> ast.FunctionDef:
        return ReturnFromGeneratorTransformer().visit(func)

    def test_yield(func: ast.FunctionDef) -> ast.FunctionDef:
        new_func = test(let(func))
        let(assertion)
        assertion = isinstance(new_func.body[0], ast.Assign)
        return new_func

    @test
    def x():
        return 5

    @test
    def fn():
        yield 1
        return 5

    @test_yield
    def g():
        yield 1
        return 5

# Generated at 2022-06-21 17:54:11.002007
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rt = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:54:22.046964
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source_conformance_check import test_transformer
    from ..utils.source_conformance_check import SourceConformanceChecker
    from ..utils.source_conformance_check import parse
    from ..utils.source_conformance_check import get_ast_diff
    from ..utils.source_conformance_check import ast_equal

    def test_return_from_generator():
        """
        Test return from generator
        """
        before = """
        def gen():
            yield 1
            return 2
        """
        after = """
        def gen():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        """

        transformed_node = test_transformer(ReturnFromGeneratorTransformer, before)
        assert ast_equal(transformed_node, parse(after))

# Generated at 2022-06-21 17:54:28.350782
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # This is an example of case where this transformer should work
    generator_with_return = ast.parse('''
    def fn():
        yield 1
        return 2
    ''')

    # This is an example of function with no return
    empty_generator = ast.parse('''
    def fn():
        yield 1
    ''')

    # This is an example of function with no yield
    simple_function = ast.parse('''
    def fn():
        return 2
    ''')

    # This is an example of function with return with no value
    return_none_generator = ast.parse('''
    def fn():
        yield 1
        return
    ''')

    # This is an example of function with return inside lambda

# Generated at 2022-06-21 17:54:30.370408
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer._target == (3, 2)


# Generated at 2022-06-21 17:54:36.585421
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
        def fn():
            yield 1
            return 2
    """)

    expected_result = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """)

    node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected_result)


# Generated at 2022-06-21 17:54:38.167296
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:54:46.208332
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import fix_missing_locations, get_ast
    from .mypy_transformer import MypyTransformer
    from .mypy_validation_transformer import MypyValidationTransformer
    from .unexposed_last_comprehension_transformer import UnexposedLastComprehensionTransformer
    from ..utils.source import Source

    source = Source("""
        def fn():
            yield 1
            return 5
    """)

    expected = Source("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    tree = get_ast(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    tree = UnexposedLastComprehensionTransformer().visit(tree)
    tree = MypyTransformer

# Generated at 2022-06-21 17:54:56.785710
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def test_contains_gen(expected: Any) -> Generator[str, str, str]:
        t = _mypyc.function_type(lambda: None, arg_types=[])
        try:
            _mypyc.contains_type_var(t)
        except Exception as e:
            return e
        return None

    def is_not_none(self):
        try:
            return x
        except:
            return None
    """


# Generated at 2022-06-21 17:54:58.837854
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # [the_same_code]

    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:55:04.089283
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import transform, assert_equal_code
    from . import base
    base.transformer_manager.add_transformer(ReturnFromGeneratorTransformer)
