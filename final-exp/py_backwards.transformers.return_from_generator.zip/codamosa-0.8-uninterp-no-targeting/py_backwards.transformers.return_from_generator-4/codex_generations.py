

# Generated at 2022-06-21 17:46:19.897285
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        x = 1
        yield x
        x = 2
        return x
    tree = ast.parse(fn.__code__)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    fn = compile(tree, '<string>', 'exec')
    g = fn()
    assert g.send(None) == 1
    with pytest.raises(StopIteration) as ex_info:
        g.send(None)
    assert ex_info.value.value == 2

# Generated at 2022-06-21 17:46:22.627903
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), BaseNodeTransformer)


# Generated at 2022-06-21 17:46:27.796918
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # GIVEN
    transformer = ReturnFromGeneratorTransformer()
    first = ast.parse("""\
        def gen():
            yield 1
            return 5
        """).body[0]

    second = ast.parse("""\
        def gen():
            yield 1
            if True:
                return 5
        """).body[0]

    third = ast.parse("""\
        def gen():
            if True:
                return 5
            yield 1
        """).body[0]

    fourth = ast.parse("""\
        def gen(a=None):
            if a > 5:
                return 7
            yield 1
        """).body[0]


    # WHEN
    actual = transformer.visit(first)

    # THEN

# Generated at 2022-06-21 17:46:38.552024
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(source_tree=ast.parse("""
        def fn():
            yield 1
            return 5
    """))


# Generated at 2022-06-21 17:46:41.109775
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class A:
        def f():
            yield 1
            return 5
    a = A()
    a.f()
    ReturnFromGeneratorTransformer().visit(a)

# Generated at 2022-06-21 17:46:42.573244
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:43.930764
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:52.625502
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    function_def = ast.parse(
        "def foo():\n"
        "    yield 1\n"
        "    return [x for x in range(0, 10) if x > 0]\n"
        "    return fn(x, y, z=None)"
    )
    node = function_def.body[0]
    assert str(node.body[2]) == "return [x for x in range(0, 10) if x > 0]"
    assert str(node.body[3]) == "return fn(x, y, z=None)"
    return_from_generator_transformer.visit(node)
    assert str(node.body[2]) == "exc = StopIteration()"

# Generated at 2022-06-21 17:46:55.897750
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    o = ReturnFromGeneratorTransformer()
    result = o._find_generator_returns(ast.parse('def f():\n    yield 1\n    return 1'))
    assert len(result) == 1
    assert isinstance(result[0][0], ast.FunctionDef)
    assert isinstance(result[0][1], ast.Return)


# Generated at 2022-06-21 17:46:56.518172
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:08.087738
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_transformer_base import assert_transformation
    from ..utils.snippet import snippet, let
        # parent.body.extend((
        #     let(exc),
        #     ast.Expr(
        #         value=ast.Call(
        #             func=ast.Name(id="StopIteration", ctx=ast.Load()),
        #             args=[],
        #             keywords=[]
        #         )
        #     ),
        #     ast.Raise(
        #         exc=ast.Name(id="exc", ctx=ast.Load()),
        #         cause=None
        #     )
        # ))


# Generated at 2022-06-21 17:47:09.719257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import compile_to_ast


# Generated at 2022-06-21 17:47:21.237640
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    source = """
        def generator(n):
            for i in range(n):
                yield i
            return
    """
    expected = """
        def generator(n):
            for i in range(n):
                yield i
            exc = StopIteration()
            exc.value = None
            raise exc
    """
    module_node = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    new_module_node = transformer.visit(module_node)

    assert astunparse.unparse(new_module_node) == expected

    # test that we don't change normal functions
    source = """
        def fn():
            return
    """
    module_node = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:47:26.093871
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    return_from_generator_transformer.transform_string('def foo():\n yield 1 \n return 5')
    return_from_generator_transformer.transform_string('def foo():\n return 5')
    return_from_generator_transformer.transform_string('def foo():\n yield 1\n return 5\n return 7')
    return_from_generator_transformer.transform_string('def foo():\n return 7\n yield 1\n return 5')

# Generated at 2022-06-21 17:47:27.242489
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:36.898512
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from test.test_base import BaseTest

    class Test(BaseTest):
        transformer = ReturnFromGeneratorTransformer

        def test_it_compiles_return_in_generators_to_raise_StopIteration(self):
            @self.transformer
            def fn():
                yield 1
                return 5

            def _check(node):
                self.assertIsInstance(node, ast.FunctionDef)
                self.assertEqual(len(node.body), 3)
                self.assertIsInstance(node.body[0], ast.Yield)
                self.assertIsInstance(node.body[1], ast.Assign)
                self.assertEqual(len(node.body[1].targets), 1)
                self.assertIsInstance(node.body[1].targets[0], ast.Name)


# Generated at 2022-06-21 17:47:46.675780
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    generator = ReturnFromGeneratorTransformer()\
    # The expected variables here is a list of class attributes to be tested.
    # The items in the list are tuples of two entries: the attribute name and
    # the assigned value of the attribute.
    # The first entry in the tuple is a string.
    # The second entry in the tuple is the expected value.
    # To test the parent class's attributes, put its name in the first entry
    # of the tuple.
    assert generator.__class__.__name__ == "ReturnFromGeneratorTransformer"
    expected_variables = [
        ('_tree_changed', False),
        ('target', (3, 2)),
    ]

# Generated at 2022-06-21 17:47:55.449015
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.testing import assert_in

    def _assert_returns_replaced(source_code):
        fn_node = ast.parse(source_code)
        visitor = ReturnFromGeneratorTransformer()
        visitor.visit(fn_node)
        assert visitor._tree_changed

        expected = source(return_from_generator.get_body(return_value=5)[::-1])
        assert_in(expected, source(fn_node))

    _assert_returns_replaced('''
        def fn():
            yield 1
            return 5
    ''')
    _assert_returns_replaced('''
        def fn():
            for i in range(5):
                return 5
    ''')


# Generated at 2022-06-21 17:47:56.722849
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:48:00.660447
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import compile_source, dump_tree

    # Test for issue #17
    code = '''
        def fn():
            yield 1
            return
    '''
    compiled = compile_source(code, '', 'exec', ReturnFromGeneratorTransformer)
    dump_tree(compiled)

    # Test for issue #18
    code = '''
        def fn():
            yield 1
            return 5
    '''
    compiled = compile_source(code, '', 'exec', ReturnFromGeneratorTransformer)
    dump_tree(compiled)

# Generated at 2022-06-21 17:48:15.804652
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    source = """
        def fn():
            yield 1
            return 5

        def fn2():
            yield 1
            return

        def fn3():
            return
            yield 1
    """

    tree = ast.parse(source)
    assert isinstance(tree, ast.Module)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    new_source = compile(tree, '<string>', 'exec')
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

        def fn2():
            yield 1
            return

        def fn3():
            return
            yield 1
    """

    assert expected_source == new_source

# Generated at 2022-06-21 17:48:16.757096
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:48:24.630435
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestTransformer(ReturnFromGeneratorTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            tree_changed = self._tree_changed
            self._tree_changed = False
            node = super().visit_FunctionDef(node)
            assert self._tree_changed == tree_changed
            return node

    return_from_generator = TestTransformer().visit(return_from_generator.ast)


# Generated at 2022-06-21 17:48:34.990710
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    x = ast.parse('def foo(): yield 1; return 2')
    x = ReturnFromGeneratorTransformer().visit(x)

# Generated at 2022-06-21 17:48:36.399399
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:48:39.841598
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class ReturnFromGeneratorTransformer."""
    # Test for instance creation for class ReturnFromGeneratorTransformer
    # TODO: some dummy tests
    assert ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:48:45.501332
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_transformer import run_test_for_visit_methods

    code_before = """\
        def test():
            yield 1
            return 5
    """
    code_after = """\
        def test():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    run_test_for_visit_methods(ReturnFromGeneratorTransformer, code_before, code_after)



# Generated at 2022-06-21 17:48:46.407030
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-21 17:48:55.836435
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast.ast3 import Assign, Load, FunctionDef, Num, Return, parse
    from ..utils.source_helpers import source

    def test_contains(s, tree):
        tr = ReturnFromGeneratorTransformer()
        func_def = parse(s).body[0]
        tr.visit(func_def)
        assert func_def.body == tree

    test_contains('def fn(): yield 1', [ast.Expr(value=ast.Yield(value=Num(1)))])
    test_contains('def fn(): return 1', [Return(value=Num(1))])

# Generated at 2022-06-21 17:49:03.216444
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import sys
    import textwrap
    from io import StringIO
    from ..utils.ast_builder import build
    from ..utils.transform import transform
    from ..utils.asserts import assert_item_ast_equals

    program = """
        def fn():
            yield 1
            return 2
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """

    program = textwrap.dedent(program)
    expected = textwrap.dedent(expected)

    module = build(program, __name__)  # type: ignore
    result_module = transform(module, ReturnFromGeneratorTransformer)  # type: ignore
    result = StringIO()
    ast.unparse(result_module, result)

    assert_item_ast

# Generated at 2022-06-21 17:49:19.967948
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from unittest import TestCase
    from .base import BaseNodeTransformerTestCase

    class Test(
        BaseNodeTransformerTestCase,
        TestCase
    ):
        target = (3, 2)
        transformer = ReturnFromGeneratorTransformer

        def test_return_from_generator(self):
            self.transformer_test(
                """
                def fn():
                    yield 1
                    return 5
                """,
                """
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
                """
            )

# Generated at 2022-06-21 17:49:20.408091
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:49:25.343456
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input_code = """
    def fn():
        yield 1
        return 5
    """

    tr = ReturnFromGeneratorTransformer()
    tree = ast.parse(input_code)
    tree = tr.visit(tree)
    code = compile(tree, '<test>', 'exec')
    fn = {}
    exec(code, fn)
    assert str([x for x in fn['fn']()]) == "[1, 5]"



# Generated at 2022-06-21 17:49:26.462075
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:34.484149
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()._find_generator_returns(
        ast.parse("def fn():\n    yield 5\n    return 1\n")
    )[0][1] == ast.parse("return 1").body[0]
    assert ReturnFromGeneratorTransformer()._find_generator_returns(
        ast.parse("def fn():\n    yield 5\n    return 1\n")
    )[0][0] == ast.parse("def fn():\n    yield 5\n    return 1\n").body[0]


# Generated at 2022-06-21 17:49:35.547981
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5


# Generated at 2022-06-21 17:49:46.723389
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestTransformer(ReturnFromGeneratorTransformer):
        _source = """
        def fn():
            if x:
                yield 1
                return 5
            y = yield 2
            while True:
                if y:
                    yield 3
                else:
                    return 0
            try:
                return 1
            except:
                yield 4
                return 6
        """


# Generated at 2022-06-21 17:49:53.268575
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer._find_generator_returns(
        ReturnFromGeneratorTransformer({}),  # type: ignore
        ast.parse('def fn():\n  yield 1\n  return 5\n').body[0],
    ) == []
    assert ReturnFromGeneratorTransformer._find_generator_returns(
        ReturnFromGeneratorTransformer({}),  # type: ignore
        ast.parse('def fn():\n  yield 1\n  return\n').body[0],
    ) == []
    assert ReturnFromGeneratorTransformer._find_generator_returns(
        ReturnFromGeneratorTransformer({}),  # type: ignore
        ast.parse('def fn():\n  yield 1\n  return 5\n').body[0],
    ) == []
    assert ReturnFromGener

# Generated at 2022-06-21 17:49:58.922247
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..object_type import ObjectType

    class S(ObjectType):
        def __init__(self, i: int):
            self.i = i

    class A(ObjectType):
        def __init__(self, s: S):
            self.s = s

    def fn():
        yield 1
        return 5

    res = ReturnFromGeneratorTransformer().visit(fn)
    res()

# Generated at 2022-06-21 17:50:08.107950
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .return_from_generator import ReturnFromGeneratorTransformer
    from ..utils.snippet import snippet
    from ..utils.helpers import is_child_of
    from ..utils.ast_helpers import ast_equal, ast_to_source
    import textwrap

    @snippet
    def basic():
        let(res)
        res = []
        for i in range(4):
            if i == 2:
                return res
            res.append(i)

    @snippet
    def multiple_returns():
        let(res)
        res = []
        for i in range(4):
            res.append(i)
            if i == 2:
                return res
        return i


# Generated at 2022-06-21 17:50:31.347828
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ast import parse
    from ..ast_processing import BaseNodeTransformer
    from ..utils.line_builder import LineBuilder

    with LineBuilder() as b:
        b.line('def fn():')
        b.line('   if True:')
        b.line('       yield 1')
        b.line('       while True:')
        b.line('           yield 1')
        b.line('           return 2')

    tree = parse(str(b))
    transformer = ReturnFromGeneratorTransformer()
    modified_tree = transformer.visit(tree)
    assert isinstance(transformer, BaseNodeTransformer)
    assert transformer._tree_changed is True

# Generated at 2022-06-21 17:50:40.759213
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = '''
        def foo():
            yield 1  # pragma: no cover
            return 5
    '''

    expected = '''
        def foo():
            yield 1  # pragma: no cover
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''

    node = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    result = compile(node, '<test>', 'exec')
    namespace = {}
    exec(result, namespace)
    gen = namespace['foo']()
    assert next(gen) == 1
    with pytest.raises(StopIteration) as excinfo:
        next(gen)
    assert excinfo.value.value == 5
    assert ast.dump(node) == expected

# Generated at 2022-06-21 17:50:51.623189
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # test for _find_generator_returns
    # test for _find_generator_returns empty list
    def fn():
        return 1
    node = ast.parse(dedent(fn.__doc__)).body[0]  # type: ignore
    assert ReturnFromGeneratorTransformer()._find_generator_returns(node) == []
    # test for _find_generator_returns
    def fn():
        yield 'abc'
    node = ast.parse(dedent(fn.__doc__)).body[0]  # type: ignore
    assert ReturnFromGeneratorTransformer()._find_generator_returns(node) == []
    # test for _find_generator_returns
    def fn():
        if True:
            yield 'abc'
        else:
            yield 'def'
   

# Generated at 2022-06-21 17:50:53.962325
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    sn = ReturnFromGeneratorTransformer()
    assert sn
    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    actual = sn.visit(ast.parse(code))
    assert expected == astor.to_source(actual)

# Generated at 2022-06-21 17:50:55.299751
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse


# Generated at 2022-06-21 17:50:59.896874
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(func_def_string, expected_string):
        tree = ast.parse(func_def_string)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)
        result = ast.dump(tree)
        assert result == expected_string


# Generated at 2022-06-21 17:51:00.668854
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer() is not None

# Generated at 2022-06-21 17:51:09.355754
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse(textwrap.dedent("""
        def fn():
            yield 1
            return 5
    """))
    fn_node = node.body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert len(fn_node.body) == 4
    assert ast.dump(fn_node.body[2].targets[0]) == 'exc'
    assert ast.dump(fn_node.body[2].value) == 'StopIteration()'
    assert ast.dump(fn_node.body[3].value.left) == 'exc.value'
    assert ast.dump(fn_node.body[3].value.right) == '5'


# Generated at 2022-06-21 17:51:13.169605
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast_ = ast.parse('def fn():\n    yield 1\n    return 5')
    ReturnFromGeneratorTransformer().visit(ast_)
    assert ast_.body[0].body[1].lineno == 4
    assert ast_.body[0].body[1].col_offset == 0


# Generated at 2022-06-21 17:51:16.105371
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert 'test_ReturnFromGeneratorTransformer' in globals(), 'Cannot find global name "test_ReturnFromGeneratorTransformer"!'


# Generated at 2022-06-21 17:51:58.366463
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .whitebox import whitebox

    t = ReturnFromGeneratorTransformer(whitebox)
    fn = ast.parse('def fn(): yield 1; return 2')
    fn = t.visit(fn)  # type: ignore
    assert eval(compile(fn, __file__, mode='exec'))() == 2

    fn = ast.parse('def fn(): x = 1; yield x; return x')
    fn = t.visit(fn)  # type: ignore
    assert eval(compile(fn, __file__, mode='exec'))() == 1

    fn = ast.parse('def fn(): x = 1; yield x; return 1')
    fn = t.visit(fn)  # type: ignore
    assert eval(compile(fn, __file__, mode='exec'))() == 1


# Generated at 2022-06-21 17:51:58.843957
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:52:04.010166
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    node = node.body[0]
    new_node = ReturnFromGeneratorTransformer().visit(node)

    expected_node = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    expected_node = expected_node.body[0]

    assert ast.dump(expected_node) == ast.dump(new_node), f"Expected:\n\n{ast.dump(expected_node)}\n\nActual:\n\n{ast.dump(new_node)}"

# Generated at 2022-06-21 17:52:13.326694
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    snip = return_from_generator.get_original()

# Generated at 2022-06-21 17:52:14.607631
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert_equal(ReturnFromGeneratorTransformer().target, (3, 2))

# Generated at 2022-06-21 17:52:21.947829
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..tests.test_transformer import check_transformation
    from .. import pegen

    code = """
        def gen():
            yield 123
            return 1
    """
    expected = """
        def gen():
            yield 123
            exc = StopIteration()
            exc.value = 1
            raise exc
    """
    ast_mod = pegen.parse_string(code)
    ast_expected = pegen.parse_string(expected)
    t = ReturnFromGeneratorTransformer()
    t.visit(ast_mod)
    check_transformation(t, ast_mod, ast_expected)



# Generated at 2022-06-21 17:52:27.957258
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    source = '''
        def fn():
            yield 1
            return 5
        def fn2():
            yield 1
            return
        def fn3():
            return
    '''
    module = ast.parse(source)
    return_from_generator_transformer(module)
    expected_source = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        def fn2():
            yield 1
            return
        def fn3():
            return
    '''
    expected_module = ast.parse(expected_source)
    assert ast.dump(module) == ast.dump(expected_module)

# Generated at 2022-06-21 17:52:32.971547
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer._find_generator_returns(
        ReturnFromGeneratorTransformer(), ast.parse(
            """
            def fn():
                yield 1
                return 5
            """
        )) == [
            (
                ast.parse(
                    """
                    def fn():
                        yield 1
                        return 5
                    """
                ).body[0],
                ast.Return(ast.parse('5').body[0])
            )
        ]

    assert ReturnFromGeneratorTransformer._find_generator_returns(
        ReturnFromGeneratorTransformer(), ast.parse(
            """
            def fn():
                def inner():
                    yield 1
                    return 5
            """
        )) == []


# Generated at 2022-06-21 17:52:42.707116
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert_expected_formatted_code(
        """
        def fn():
            yield 1
            return 5
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    assert_expected_formatted_code(
        """
        # comment
        def fn():
            yield 1
            for a in range(4):
                yield a
                return 5
            yield 6
        """,
        """
        # comment
        def fn():
            yield 1
            for a in range(4):
                yield a
                exc = StopIteration()
                exc.value = 5
                raise exc
            yield 6
        """
    )


# Generated at 2022-06-21 17:52:44.801905
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None


# Generated at 2022-06-21 17:54:10.816794
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    source = """
    def foo():
        def other():
            return 5
        
        yield 1
        return 5
    """

    expected = """
    def foo():
        def other():
            return 5
        
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    transformer._tree_changed = False
    tree = ast.parse(source)
    transformer.visit(tree)

    assert transformer._tree_changed is True
    assert ast.dump(tree).strip() == expected.strip()



# Generated at 2022-06-21 17:54:21.904155
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.visitor import Walker

    # Test for empty function
    source = 'def f(): pass'
    expected = 'def f(): pass'
    node = ast.parse(source)
    ast.fix_missing_locations(node)
    w = Walker(ReturnFromGeneratorTransformer)
    w.walk(node)

    assert(ast.dump(node) == expected)

    # Test for non-generator function
    source = 'def f():\n    return 5'
    expected = 'def f():\n    return 5'
    node = ast.parse(source)
    ast.fix_missing_locations(node)
    w = Walker(ReturnFromGeneratorTransformer)
    w.walk(node)

    assert(ast.dump(node) == expected)

    # Test for non-generator function with

# Generated at 2022-06-21 17:54:27.389288
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    module = """
    def gen():
        for x in range(10):
            if x % 2 == 0:
                return "hello"
            yield x
    """
    node = ast.parse(module)
    ReturnFromGeneratorTransformer().visit(node)
    processed_code = astor.to_source(node).strip()
    assert processed_code == """
    def gen():
        for x in range(10):
            if x % 2 == 0:
                exc = StopIteration()
                exc.value = "hello"
                raise exc
            yield x
    """.strip()



# Generated at 2022-06-21 17:54:37.990022
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astpretty import pformat
    from ..utils.source import source
    from .generator_compat import GeneratorCompatTransformer

    code = r'''
    def generator():
        yield 'done'
        return 'no'

    def generator_from_from():
        x = (yield from generator())
        return x
    '''

    tree = ast.parse(source(code))
    tree = GeneratorCompatTransformer().visit(tree)
    tree = ReturnFromGeneratorTransformer().visit(tree)


# Generated at 2022-06-21 17:54:46.074775
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    transformer = ReturnFromGeneratorTransformer()
    result1 = transformer.visit(ast.parse("""
    def foo():
        yield 1
        return 5
    """))
    expected1 = ast.parse("""
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)
    assert ast.dump(result1) == ast.dump(expected1)

    result2 = transformer.visit(ast.parse("""
    def foo():
        if 1:
            return 5
    """))
    expected2 = ast.parse("""
    def foo():
        if 1:
            return 5
    """)
    assert ast.dump(result2) == ast.dump(expected2)

# Generated at 2022-06-21 17:54:46.781717
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:54:48.716640
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer
    assert return_from_generator_transformer.target == (3, 2)

# Generated at 2022-06-21 17:54:51.612507
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class InTest_ReturnFromGeneratorTransformer:
        """for unit test"""

# Generated at 2022-06-21 17:54:59.961833
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn_def = ast.FunctionDef(name="foo", body=[
        ast.FunctionDef(name="bar", body=[
            ast.Yield(value=ast.Num(n=4)),
            ast.Return(value=ast.Num(n=42))
        ]),
        ast.Yield(value=ast.Num(n=5)),
        ast.Expr(value=ast.Return(value=ast.Num(n=43)))
    ])
    fn_id = id(fn_def)

    res = ReturnFromGeneratorTransformer().visit(fn_def)

    return_from_generator_snipp = ast.parse(return_from_generator.get_body()).body[0]

    assert res is not fn_def
    assert id(res) != fn_id

# Generated at 2022-06-21 17:55:09.683407
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import test_utils

    def _func(a):
        if a:
            return True
        else:
            return 3
    func = test_utils.source_to_ast(_func)
    ast_func = ReturnFromGeneratorTransformer().visit(func)

    def _func(a):
        if a:
            return True
        else:
            return 3
    func = test_utils.source_to_ast(_func)
    assert test_utils.ast_equal(ast_func, func)

    def _func():
        yield 1
        return 2
    func = test_utils.source_to_ast(_func)
    ast_func = ReturnFromGeneratorTransformer().visit(func)

    def _func():
        yield 1
        exc = StopIteration()
        exc.value = 2
