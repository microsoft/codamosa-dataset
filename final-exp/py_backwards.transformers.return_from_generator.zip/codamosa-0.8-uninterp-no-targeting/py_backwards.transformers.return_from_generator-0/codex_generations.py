

# Generated at 2022-06-21 17:46:20.995369
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    class A(ast.AST):
        pass

    class Return(A):
        def __init__(self, value):
            self.value = value

    class Yield(A):
        def __init__(self, value):
            self.value = value

    class FunctionDef(A):
        _fields = ('body', )

        def __init__(self, body):
            self.body = body

    class Assign(A):
        _fields = ('value', )

        def __init__(self, value):
            self.value = value

    class Raise(A):
        _fields = ('exc', )

        def __init__(self, exc):
            self.exc = exc

    class Raise(A):
        _fields = ('exc', )


# Generated at 2022-06-21 17:46:29.979676
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    assert transformer.visit_FunctionDef(ast.parse(
        '''def fn(): return 5'''
    ).body[0]) == ast.parse(
        '''def fn(): return 5'''
    ).body[0]

    assert transformer.visit_FunctionDef(ast.parse(
        '''def fn(): yield 1; return 5'''
    ).body[0]).body[1].value.value == 5

    assert transformer.visit_FunctionDef(ast.parse(
        '''def fn():
        if 1:
            return 5
        else:
            yield 5
        '''
    ).body[0]).body[1].value.value.value == 5


# Generated at 2022-06-21 17:46:31.037906
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:46:40.972445
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.FunctionDef(name = 'foo',
                           args = ast.arguments(args = [],
                                                kwonlyargs = [],
                                                vararg = None,
                                                kwarg = None,
                                                defaults = [],
                                                kw_defaults = []),
                           body = [ast.Yield(value = ast.Num(n = 5)),
                                   ast.Return(value = ast.Num(n = 2))],
                           decorator_list = [],
                           returns = None)
    fn = ast.parse(r'''def foo():
                    yield 1
                    return 2''')
    expected = ast.Module(body = [fn])

# Generated at 2022-06-21 17:46:42.500452
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:43.472462
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:46:45.428747
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tr = ReturnFromGeneratorTransformer()
    assert(isinstance(tr, ReturnFromGeneratorTransformer))

# Generated at 2022-06-21 17:46:56.150108
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    def run_test(source, expected):
        module = ast.parse(source).body[0]

        assert transformer.visit(module) == expected

    # Test 1. With only one return statement in body.
    source = "def fn():\n" \
             "    yield 1\n" \
             "    return 5"

    expected = "def fn():\n" \
               "    yield 1\n" \
               "    exc = StopIteration()\n" \
               "    exc.value = 5\n" \
               "    raise exc"

    run_test(source, expected)

    # Test 2. With only one return statement in body and no return argument.

# Generated at 2022-06-21 17:46:57.178371
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:46:58.277032
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_ = ReturnFromGeneratorTransformer()
    assert class_



# Generated at 2022-06-21 17:47:13.755130
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    fdef1 = ast.FunctionDef(name='fn1',
                            args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
                            body=[
                                ast.Yield(value=ast.Num(n=1)),
                                ast.Return(value=ast.Num(n=1))
                            ],
                            decorator_list=[],
                            returns=None)


# Generated at 2022-06-21 17:47:19.215705
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    source = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-21 17:47:19.827923
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:20.870573
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer



# Generated at 2022-06-21 17:47:23.659276
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from ..utils.visitor import NodeVisitor

    # Test with a generator function

# Generated at 2022-06-21 17:47:34.664155
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1  # Nothing changed
        return 5

    def fn2():
        yield 1
        yield 2  # Nothing changed
        return 6

    def fn3():
        yield 1
        return 5

    def fn4():
        yield 1
        return 5
        yield 6

    def fn5():
        yield 1
        if True:
            return 4

    def fn6():
        yield 1
        if True:
            a = 5
            yield 6
            return a

    def fn7():
        yield 1
        if True:
            a = 5
            yield 6
            return a
        else:
            return 1

    def fn8():
        yield 1
        if True:
            a = 5
            yield 6
            return a
        else:
            return 1
        yield 2


# Generated at 2022-06-21 17:47:45.194928
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast.parse("""
        import inspect
        import builtins


        def fn():
            yield 1
            return 5


        def fn2():
            yield 1
        """)
    fn = ReturnFromGeneratorTransformer().visit(ast.parse("""
        def fn():
            yield 1
            return 5
        """))
    assert fn.body[-2].value.func.value.id == 'StopIteration'
    assert fn.body[-2].value.args == [ast.Name(id="return_value", ctx=ast.Load())]
    assert fn.body[-2].value.keywords[0].arg == 'value'

    fn = ReturnFromGeneratorTransformer().visit(ast.parse("""
        def fn2():
            yield 1
        """))

# Generated at 2022-06-21 17:47:46.236462
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rfgt = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:47:47.565439
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import parse

# Generated at 2022-06-21 17:47:50.234868
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_ = ReturnFromGeneratorTransformer
    assert class_ is not None

# Generated at 2022-06-21 17:47:57.608869
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer().visit(ast.parse('''
        def fn():
            yield 1
            return 5
    ''')) == ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

# Generated at 2022-06-21 17:47:58.246862
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:48:01.150372
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__doc__ is not None

# Generated at 2022-06-21 17:48:12.034999
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from typing import List, Dict, Union

    def get_function_body(function: ast.FunctionDef) -> List[ast.stmt]:
        return function.body

    def get_function_return_value(function: ast.FunctionDef) -> Union[ast.expr, ast.Name, ast.Starred, ast.List, ast.Tuple, ast.Num, ast.Str]:
        return function.body[-1].value.value

    def get_function_return_target(function: ast.FunctionDef) -> Union[ast.expr, ast.Name, ast.Starred, ast.List, ast.Tuple, ast.Num, ast.Str]:
        return function.body[-1].value.targets[0]


# Generated at 2022-06-21 17:48:13.142856
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-21 17:48:18.891960
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse("""
        def g():
            yield 1
            return 5
    """)
    node = transformer.visit(node)
    assert transformer._tree_changed is True
    assert ast.dump(node) == ast.dump(ast.parse("""
        def g():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """))

# Generated at 2022-06-21 17:48:22.318711
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        yield 2
        return 5

    assert fn().__next__() == 1
    assert fn().__next__() == 2
    with pytest.raises(StopIteration) as exc:
        fn().__next__()
    assert exc.value.value == 5

# Generated at 2022-06-21 17:48:32.783152
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def correct_yield1():
        yield 1
        return 1
    assert correct_yield1() == 1
    assert correct_yield1().__next__() == 1

    def correct_yield_with_many_returns():
        yield 1
        return 1
        return 2
    assert correct_yield_with_many_returns() == 1
    assert correct_yield_with_many_returns().__next__() == 1

    def correct_yield_with_multiple_yields():
        yield 1
        yield 2
        return 1
    assert correct_yield_with_multiple_yields() == 1
    assert correct_yield_with_multiple_yields().__next__() == 1
    assert correct_yield_with_multiple_yields().__next__() == 2

   

# Generated at 2022-06-21 17:48:38.522773
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse('def f(): yield\nreturn', 'foo.py', 'exec')
    print(ast.dump(tree, annotate_fields=False))
    transformer.visit(tree)
    print(ast.dump(tree, annotate_fields=False))

# Generated at 2022-06-21 17:48:41.169563
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:48:53.292932
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Test(object):
        def fn1(self):
            yield 1

        def fn2(self):
            yield 2
            return 5


# Generated at 2022-06-21 17:48:54.201448
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:48:59.104190
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import node_factory

    # Before:
    # def fn():
    #     yield
    #     return 5
    fn_before_node = node_factory(
        'def fn():\n'
        '    yield\n'
        '    return 5\n'
    )


    # After:
    # def fn():
    #     yield
    #     exc = StopIteration()
    #     exc.value = 5
    #     raise exc
    fn_after_node = node_factory(
        'def fn():\n'
        '    yield\n'
        'exc = StopIteration()\n'
        'exc.value = 5\n'
        'raise exc\n'
    )


    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:49:00.225740
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:06.842964
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def fn():
            yield 1
            return 2
    """
    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """

    transformed = ast.fix_missing_locations(tree)
    assert expected == transformed


# Generated at 2022-06-21 17:49:14.262742
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def _test(fn):
        """Test transformer:
        - creates transformer
        - compiles transformed code
        - checks that code is equal to original
        - runs code and checks that it works
        """
        tree = ast.parse(inspect.getsource(fn))
        transformed = ReturnFromGeneratorTransformer().visit(tree)
        c = compile(transformed, "cname", "exec")

        fn_ = globals()["fn"]

        assert fn_.__code__.co_code == c.co_code
        assert list(fn_()) == [1, 5]

    # Test
    def fn():
        yield 1
        return 5

    _test(fn)

    # Test
    def fn():
        yield 1
        return 5
        yield 2

    _test(fn)

    # Test

# Generated at 2022-06-21 17:49:24.140558
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_function(test_node, expected):
        transformer = ReturnFromGeneratorTransformer()
        new_node = transformer.visit(test_node)
        assert ast.dump(new_node) == expected


# Generated at 2022-06-21 17:49:25.619474
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_x = ReturnFromGeneratorTransformer()
    assert class_x is not None

# Generated at 2022-06-21 17:49:27.220465
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import transform


# Generated at 2022-06-21 17:49:31.638800
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_astunparse import unparse
    from ..utils.testing import get_str_after_transform
    x = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert unparse(get_str_after_transform(x, ReturnFromGeneratorTransformer)) == expected

test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:49:48.554604
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:49:50.170385
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer(): # type: () -> None
    print(ReturnFromGeneratorTransformer(None, '<test>'))

# Generated at 2022-06-21 17:49:52.100579
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert str(ReturnFromGeneratorTransformer)

# Generated at 2022-06-21 17:49:57.326224
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    visitor = ReturnFromGeneratorTransformer()
    uut = ReturnFromGeneratorTransformer()
    assert str(uut) == "ReturnFromGeneratorTransformer"
    assert repr(uut) == "<ReturnFromGeneratorTransformer>"
    assert visitor is not uut
    assert visitor == uut
    assert not visitor != uut

# Generated at 2022-06-21 17:50:06.687449
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    return_stmt = ast.Return(value=ast.Num(n=5))
    func_def = ast.FunctionDef(name='fn',
                               args=ast.arguments(
                                   args=[],
                                   vararg=None,
                                   kwonlyargs=[],
                                   kw_defaults=[],
                                   kwarg=None,
                                   defaults=[]),
                               body=[return_stmt],
                               decorator_list=[],
                               returns=None)  # type: ast.FunctionDef
    transformer.visit(func_def)
    lines = return_from_generator.get_body(return_value=ast.Num(n=5))
    assert lines == func_def.body

# Generated at 2022-06-21 17:50:11.785755
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.testing import assert_code_equal, assert_tree_equal
    from ..utils.testing import assert_tree_code_equal, assert_code_tree_equal

    compiler = ReturnFromGeneratorTransformer()

    def fn1():
        yield 1
        return 5

    def fn2():
        yield 1
        if True:
            return False

    def fn_else():
        yield 1
        if True:
            return False
        else:
            return True

    def fn_else_true():
        yield 1
        if True:
            return True
        else:
            return False

    def fn_nested():
        yield 1
        if True:
            return 5
        else:
            if True:
                return 6

    def fn_nested_else():
        yield 1
        if True:
            return

# Generated at 2022-06-21 17:50:22.843570
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node_a = ast.FunctionDef(
        name="f",
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]),
        body=[
            ast.Yield(
                value=ast.Constant(
                    value=1)
            ),
            ast.Return(
                value=ast.Constant(
                    value=2)
            )
        ],
        decorator_list=[],
        returns=None
    )
    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(node_a)

# Generated at 2022-06-21 17:50:23.785206
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astunparse

# Generated at 2022-06-21 17:50:27.836427
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def check(before_fn, after_fn):
        test_node = ast.parse(before_fn)
        expected_node = ast.parse(after_fn)

        ReturnFromGeneratorTransformer().visit(test_node)
        assert test_node == expected_node


# Generated at 2022-06-21 17:50:39.483395
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class FooNodeVisitor(ReturnFromGeneratorTransformer):
        def __init__(self):
            self.visited = []

        def _generic_visit(self, node):
            self.visited.append('_generic_visit')

    foo_node_visitor = FooNodeVisitor()
    body = [ast.Expr(value=ast.Yield()),
            ast.Return(value=ast.Num(n=5))]
    func = ast.FunctionDef(name='foo', body=body, decorator_list=[])
    foo_node_visitor.visit(func)


# Generated at 2022-06-21 17:51:20.867795
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    program = """
        def fn():
            yield 1
            return 5
        """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    node = ast.parse(program)
    new_node = ReturnFromGeneratorTransformer().visit(node)
    new_program = ast.unparse(new_node)
    assert new_program == expected



# Generated at 2022-06-21 17:51:22.005223
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3, 2)


# Generated at 2022-06-21 17:51:22.864332
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:51:24.474810
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)



# Generated at 2022-06-21 17:51:27.712381
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..testing.test_transformer import transform_and_compare

# Generated at 2022-06-21 17:51:29.028412
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:51:32.178084
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .generators import transform
    from .generators_test import test_generator_return_to_exception_raising
    test_generator_return_to_exception_raising(
        transform,
        ReturnFromGeneratorTransformer
    )

# Generated at 2022-06-21 17:51:41.893521
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.uncompyle_test_case import UncompyleTestCase


# Generated at 2022-06-21 17:51:43.133679
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astunparse

# Generated at 2022-06-21 17:51:48.592249
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Class:
        def method(self):
            yield 1
            return 5

    ret = ReturnFromGeneratorTransformer()
    ret._target_version = (3, 2)
    assert ret._tree_changed == False
    ret.generic_visit(Class.method)
    assert ret._tree_changed == True

# Generated at 2022-06-21 17:54:00.700311
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import test_utils
    node = test_utils.build_ast(
        """
        def generator_func(arg1, arg2):
            def inner():
                if arg1 > arg2:
                    return
            yield from inner()
            return arg2
        """
    )
    expected_node = test_utils.build_ast(
        """
        def generator_func(arg1, arg2):
            def inner():
                if arg1 > arg2:
                    return
            yield from inner()
            exc = StopIteration()
            exc.value = arg2
            raise exc
        """
    )
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(node) == expected_node

# Generated at 2022-06-21 17:54:05.612119
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    program = """
        def foo():
            yield 1
            return 5"""
    expected_program = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc"""

    compare_ast(program, expected_program, ReturnFromGeneratorTransformer)

# Generated at 2022-06-21 17:54:11.728694
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import parse
    from . import transform

    def check(source: str, expected: str) -> None:
        node = parse(source)
        ReturnFromGeneratorTransformer().visit(node)
        assert transform(expected) == node

    # Test replacing returns in generator functions
    check(
        source = """
            def gen():
                yield 1
                return 2
        """,
        expected = """
            def gen():
                yield 1
                exc = StopIteration()
                exc.value = 2
                raise exc
        """
    )

    # Test replacing returns in generator function expressions

# Generated at 2022-06-21 17:54:13.697810
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..node_utils import to_source


# Generated at 2022-06-21 17:54:14.915105
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:54:24.512124
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def_ = ast.FunctionDef(
        name='fn',
        args=ast.arguments(
            args=[],
            kwonlyargs=[],
            vararg=None,
            kwarg=None,
            defaults=[],
            kw_defaults=[]
        ),
        body=[
            ast.Yield(value=ast.Num(n=1)),
            ast.Return(value=ast.Num(n=2))
        ],
        decorator_list=[],
        returns=None
    )

# Generated at 2022-06-21 17:54:34.902794
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    code = "def fn(): yield 1; return 5"
    expected_code = "def fn(): yield 1; exc  =  StopIteration(); exc.value  =  5; raise exc"

    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(ast.parse(code))
    assert transformer._tree_changed is True
    assert ast.dump(node) == expected_code

    code = "def fn(): yield from [1, 2, 3]; return 5"
    expected_code = "def fn(): yield from [1, 2, 3]; exc  =  StopIteration(); exc.value  =  5; raise exc"

    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(ast.parse(code))
    assert transformer._tree_changed

# Generated at 2022-06-21 17:54:43.480416
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    def assert_result(self, code, expected):
        tree = ast.parse(code, mode='exec')
        r = ReturnFromGeneratorTransformer()
        result = r.visit(tree)
        self.assertEqual(ast.dump(result), ast.dump(ast.parse(expected)))

    def test_it_should_visit_returns_in_generators(self):
        code = """
        def fn():
            yield 1
            return 5
        """
        expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
        assert_result(code, expected)


# Generated at 2022-06-21 17:54:50.191595
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from ..utils.fake import FakeNode

    class Test(BaseNodeTransformerTest):
        node = ast.FunctionDef(name='fn',
                               args=FakeNode(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
                               body=[FakeNode(1),
                                     ast.Return(value=FakeNode(2)),
                                     FakeNode(3),
                                     ast.Return(value=FakeNode(4))],
                               decorator_list=[],
                               returns=None,
                               type_comment=None)

# Generated at 2022-06-21 17:54:57.286465
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with snippets():
        class Test1:
            def test(x):
                yield 1
                return x + 3

        a = Test1()
        a.test()

        class Test2:
            def test(x):
                yield 1
                x = x + 3
                yield 2
                return x

        a = Test2()
        a.test()

        def test3(x):
            yield 1
            return x

        test3(4)

        class Test4:
            def test():
                return 3

        a = Test4()
        a.test()