

# Generated at 2022-06-21 17:46:14.098815
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:25.055066
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn_body = (
        ast.Expr(ast.Yield(ast.Num(2))),
        ast.Return(ast.Num(5))
    )
    input = ast.Module([ast.FunctionDef(name='fn', body=fn_body)])

# Generated at 2022-06-21 17:46:29.481463
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_generator_transformer_output
    source = "def fn(): yield 1; return 'hi'"
    assert_generator_transformer_output(source, ReturnFromGeneratorTransformer(),
                                        """
                                        def fn():
                                            yield 1
                                            exc = StopIteration()
                                            exc.value = 'hi'
                                            raise exc
                                        """)

# Generated at 2022-06-21 17:46:30.114145
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:32.245283
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).__class__.__name__ == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-21 17:46:41.795222
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor  # type: ignore
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:46:46.690493
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class DumpVisitor(ast.NodeVisitor):
        """Used for testing. Dumps nodes."""
        def visit_FunctionDef(self, node):
            print(ast.dump(node))
            self.generic_visit(node)

    # pylint: disable=W0612,W0613

# Generated at 2022-06-21 17:46:53.842280
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # pylint: disable=too-many-locals
    from ..utils.source import source

    from ..utils.source import generator
    code = generator.code('returns').read()

    # Parse AST
    parsed = ast.parse(code)

    # Remove lineno for assertion
    for node in ast.walk(parsed):
        node.lineno = 0

    # Expected AST
    expected_ast = ast.parse(next(generator.expected_code('returns')))
    for node in ast.walk(expected_ast):
        node.lineno = 0

    # Convert
    converted = ReturnFromGeneratorTransformer().visit(parsed)
    assert converted == expected_ast

# Generated at 2022-06-21 17:47:03.888430
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:04.722169
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer(): # type: ignore
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:47:16.437317
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_input = '''
        def fn():
            yield 1
            return 5
    '''
    test_output = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''

    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(ast.parse(test_input))  # type: ignore

    assert test_output == tree.body[0].body[1].value.body[2].value.value.value.value.id

# Generated at 2022-06-21 17:47:20.096267
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import trim_docstring
    from .transformer_utils import get_ast
    from .printer import print_node, to_source
    from ..utils.testing_utils import assert_ast

    # Simple function

# Generated at 2022-06-21 17:47:21.178125
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

# Generated at 2022-06-21 17:47:28.576248
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing import AssertSourceSampleVisitor
    from . import clean_node

    source = """
        def gen():
            yield 1
            return 2
    """
    expected = """
        def gen():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """
    visitor = AssertSourceSampleVisitor.from_str(source, expected)
    visitor.visit(clean_node(ast.parse(source)))
    visitor.assert_samples_equal()

# Generated at 2022-06-21 17:47:32.674181
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    code = "def fn(): yield 1; return 2"
    node = ast.parse(code)
    expected_code = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 2
    raise exc
"""
    assert transformer.visit(node) == ast.parse(expected_code)

# Generated at 2022-06-21 17:47:43.962536
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestReturnFromGeneratorTransformer(unittest.TestCase):
        def setUp(self):
            self.impl = ReturnFromGeneratorTransformer()

        def test_find_empty_generators(self):
            def fn():
                yield 5
            node = ast.parse(inspect.getsource(fn))
            self.assertEqual(self.impl._find_generator_returns(node.body[0]), [])

        def test_find_generator_return(self):
            def fn():
                yield 5
                return 6
            node = ast.parse(inspect.getsource(fn))
            self.assertEqual(self.impl._find_generator_returns(node.body[0]), [
                (node.body[0], node.body[0].body[1])
            ])

       

# Generated at 2022-06-21 17:47:48.253189
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer().visit(ast.parse("""def fn():
        yield 1
        return 5""")) == ast.parse("""def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc""")

# Generated at 2022-06-21 17:47:58.791108
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import typed_ast.ast3 as ast
    from typed_ast import ast3 as typed_ast
    from ..utils.sourcecode import source_to_ast

    fn = '''
        def fn():
            yield 1
            return 5
        '''

    transformer = ReturnFromGeneratorTransformer()
    fn_ast = ast.parse(fn)

    defs = fn_ast.body
    fn_node = defs[0]
    assert isinstance(fn_node, typed_ast.FunctionDef)

    fn_node_ast_transformed = transformer.visit(fn_node)
    assert isinstance(fn_node_ast_transformed, typed_ast.FunctionDef)
#
#

# Generated at 2022-06-21 17:48:03.720002
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test1 = ast.parse('def foo(): x = yield 1; return y')
    t1 = ReturnFromGeneratorTransformer()
    t1.generic_visit(test1)
    assert (t1._find_generator_returns(test1.body[0])) == [(test1.body[0].body[2], ast.Return(value=ast.Name(id='y',
                                                                                                        ctx=ast.Load())))]
    assert (t1._replace_return(test1.body[0].body[2], ast.Return(value=ast.Name(id='y', ctx=ast.Load())))) is None

# Generated at 2022-06-21 17:48:08.728953
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.code_block import CodeBlock

    code_block = CodeBlock("""
        def foo():
            yield 1
            return 5
    """)

    expected = CodeBlock("""
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    actual = code_block.copy()
    actual.ast_mutate(ReturnFromGeneratorTransformer())
    assert actual == expected



# Generated at 2022-06-21 17:48:24.367505
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from ..utils.helper import assert_source

    source = """
        def a():
            return 1
        """
    tree = parse(source)
    assert_source(ReturnFromGeneratorTransformer().visit(tree), source)

    source = """
        def a():
            yield 1
            return 1
        """
    expected = """
        def a():
            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc
        """
    tree = parse(source)
    assert_source(ReturnFromGeneratorTransformer().visit(tree), expected)

    source = """
        def a():
            if True:
                return 1
        """

# Generated at 2022-06-21 17:48:28.940370
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_generator():
        yield 1
        return 4

    tree = ast.parse(inspect.getsource(test_generator))

    transformed_tree = ReturnFromGeneratorTransformer(node=tree).visit(node=tree)


# Generated at 2022-06-21 17:48:29.915161
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None, None)

# Generated at 2022-06-21 17:48:32.736108
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    obj = ReturnFromGeneratorTransformer()
    assert obj.tree_changed == False
    assert obj.target == (3,2)


# Unit tests for method _find_generator_returns()

# Generated at 2022-06-21 17:48:35.943773
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generatorTransformer = ReturnFromGeneratorTransformer(None, None)

# Generated at 2022-06-21 17:48:37.583268
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

# Generated at 2022-06-21 17:48:38.379376
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:48:39.701214
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor  # type: ignore

# Generated at 2022-06-21 17:48:42.253131
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    p = ReturnFromGeneratorTransformer()



# Generated at 2022-06-21 17:48:43.135170
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:05.241484
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_transformers_base import get_func_with_body

    def assert_return_from_generator(source: str, expected: str) -> None:
        func = get_func_with_body(source)
        transformer = ReturnFromGeneratorTransformer()
        func = transformer.visit(func)
        assert expected == ast.dump(func)


# Generated at 2022-06-21 17:49:15.537196
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    s = """
        def generator():
            if False: yield
            else: return
    """
    t = """
        def generator():
            if False: yield
            else: exc = StopIteration()
                    exc.value = None
                    raise exc
    """
    tree = ast.parse(s)  # type: ignore
    tree = ReturnFromGeneratorTransformer().visit(tree)

    assert ast.dump(tree) == ast.dump(ast.parse(t))

    s = """
        def generator():
            if False: yield 1
            else: return 5
    """
    t = """
        def generator():
            if False: yield 1
            else: exc = StopIteration()
                    exc.value = 5
                    raise exc
    """
    tree = ast.parse(s)  # type: ignore
    tree

# Generated at 2022-06-21 17:49:22.828521
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case = """
        def foo():
            yield 1
            return 2
    """

    expected_result = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """

    tree = ast.parse(test_case)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)

    # FIXME: change after merge https://github.com/python/typed_ast/pull/77
    assert ast.dump(new_tree) == expected_result

# Generated at 2022-06-21 17:49:29.748104
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(textwrap.dedent('''
        def fn():
            yield 1
            return 5
    '''))
    node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == textwrap.dedent('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

# Generated at 2022-06-21 17:49:41.063873
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert not ReturnFromGeneratorTransformer(None)._find_generator_returns(None)
    assert not ReturnFromGeneratorTransformer(None)._find_generator_returns(ast.parse("def fn(): return 42"))
    assert not ReturnFromGeneratorTransformer(None)._find_generator_returns(ast.parse("def fn(): yield 42"))
    assert not ReturnFromGeneratorTransformer(None)._find_generator_returns(ast.parse("def fn(): yield 42; return 1")) \
        and ReturnFromGeneratorTransformer(None)._find_generator_returns(ast.parse("def fn(): return 42; yield 1"))

    node = ast.parse("def fn(): yield 1; return 1")
    assert ReturnFromGeneratorTransformer(None)._find_generator_returns(node)

# Generated at 2022-06-21 17:49:50.236582
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .testutils import roundtrip

    def test(fn):
        tree = ast.parse(fn)
        transformer = ReturnFromGeneratorTransformer()
        new_tree = transformer.visit(tree)
        new_fn = roundtrip(new_tree)
        return new_fn

    # Test for a generator function
    assert test('''
        def gen():
            yield 1
            return 2
    ''') == '''
        def gen():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc

    '''
    # Test for a generator function with yield from

# Generated at 2022-06-21 17:50:01.284034
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    for version in range(2, 4):
        code = '''
        def fn():
            yield 1
            return 5
        '''
        expected = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''

        tree = ast.parse(code, mode='exec')
        tree = ReturnFromGeneratorTransformer().visit(tree)

        # Convert returned ast.expr back to string
        to_print = tree.body[0]
        for line in ast.iter_fields(to_print):
            if isinstance(line[1], ast.AST):
                line[1] = ast.dump(line[1])

        # Assert returned ast objects are as expected
        tree_str = ast.dump(tree)
        assert expected == tree_str

# Generated at 2022-06-21 17:50:11.213382
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from darglint.extensions.annotated_args import annotated_args
    from darglint.line_parser import parse_line
    source = r"""
        def fn(a, b=0):
            if a == 1:
                return 4
            yield 1
            if a == 2:
                return 6
            if b == 2:
                return 7
            yield 2
    """
    body = parse_line(source)
    body = annotated_args(body)
    body = ReturnFromGeneratorTransformer().visit(body)

# Generated at 2022-06-21 17:50:22.308243
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import typed_astunparse

    class TestCase(unittest.TestCase):
        def test_return_from_generator_1(self):
            input = """
            def foo():
                yield 1
                return 5
            """
            expect = """
            def foo():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            """
            node = ast.parse(input)
            new_node = ReturnFromGeneratorTransformer().visit(node)
            result = typed_astunparse.unparse(new_node)
            self.assertEqual(result.strip(), expect.strip())


# Generated at 2022-06-21 17:50:31.052091
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def assert_generator_returns_transformation(input_str, expected_str):
        module = ast.parse(input_str)
        ReturnFromGeneratorTransformer().visit(module)
        assert ast.dump(module) == expected_str

    snippet = """
    def f():
        yield 1
        return 2
    """
    expected_snippet = '''
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    '''
    assert_generator_returns_transformation(snippet, expected_snippet)

    snippet = """
    def f():
        if True:
            yield 1
        else:
            yield 3
        return 4
    """

# Generated at 2022-06-21 17:51:06.121641
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:51:09.973656
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import apply_visitors
    from .parent_filler import ParentFiller
    from .remove_python2_parentheses import RemovePython2Parentheses
    from .type_annotation_to_assertion import TypeAnnotationToAssertion

# Generated at 2022-06-21 17:51:20.827875
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test(fn_src, expected):
        fn_ast = ast.parse(fn_src)
        actual = ReturnFromGeneratorTransformer().visit(fn_ast)
        actual_src = astor.to_source(actual)
        assert actual_src == expected

    # Simple case
    test('''
        def fn():
            yield 1
            return 5
    ''', '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

    # If-else in generator

# Generated at 2022-06-21 17:51:26.697175
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import run_all_nodes

# Generated at 2022-06-21 17:51:30.612419
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from astor import dump
    module = ast.parse('def fn(): yield 1; return 3')
    ReturnFromGeneratorTransformer().visit(module)
    assert dump(module) == """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 3
    raise exc"""

# Generated at 2022-06-21 17:51:34.434922
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip

    def check_transformation(before_node, after_node):
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(before_node)
        assert ast.dump(transformer.result) == ast.dump(after_node)


# Generated at 2022-06-21 17:51:41.856339
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.fake import FakeFile
    from ..utils.testing import assert_snippet_equal

    code = """\
    def fn(a, b):
        yield a
        return a + b
    """

    expected = """\
    def fn(a, b):
        yield a
        exc = StopIteration()
        exc.value = a + b
        raise exc
    """

    ast_ = ast.parse(FakeFile(code))
    new_ast = ReturnFromGeneratorTransformer().visit(ast_)

    assert_snippet_equal(new_ast, expected)

# Generated at 2022-06-21 17:51:42.373633
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:51:46.813199
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import sys
    import typing

    class ReturnFromGeneratorTransformerTest(unittest.TestCase):
        def _test_case(self, source: str, expected:  typing.Tuple[str, bool]):
            from typed_ast import parse
            node = parse(source, mode='func')
            transformer = ReturnFromGeneratorTransformer(source_path=None)
            transformed_node = transformer.visit(node)
            actual = (transformed_node, transformer._tree_changed)
            self.assertEqual(expected, actual)


# Generated at 2022-06-21 17:51:54.003133
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_same_ast
    from ..utils.ast_helpers import to_dependency_injection
    from ..utils.code_converter import CodeConverter

    def test_fn():
        yield 1
        return 5

    # we replace return's with StopIteration's, so we are able to inject our dependency
    transformed_fn = to_dependency_injection(
        CodeConverter(target=(3, 2), tree=ast.parse(test_fn.__code__)).visit(),
        has_inject_annotation=lambda x: False,
    )


# Generated at 2022-06-21 17:53:18.189454
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), BaseNodeTransformer)


# Generated at 2022-06-21 17:53:26.698890
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import UnitTestTransformer, assert_transformation

    def test(fn):
        return UnitTestTransformer(ReturnFromGeneratorTransformer).setup(fn)

    def test_fns(src):
        with assert_transformation(src, ReturnFromGeneratorTransformer) as result:
            assert result.argspec == ''

    def test_generators(src):
        with assert_transformation(src, ReturnFromGeneratorTransformer) as result:
            assert result.argspec == '*'

    #
    # Test functions
    #

    test_fns('''
        def fn():
            return 'hello'
    ''')

    test_fns('''
        def fn():
            return
    ''')


# Generated at 2022-06-21 17:53:36.569031
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Setup
    from typed_ast import ast3 as ast
    from ..transforms.__main__ import create_module
    from ..transforms.return_from_generator import ReturnFromGeneratorTransformer

    module = create_module(
        'def fn():\n'
        '    yield 2\n'
        '    return 5\n',
        '<module>'
    )

    transformer = ReturnFromGeneratorTransformer(module)
    # Exercise
    module = transformer.visit(module)
    # Verify
    assert str(module) == 'def fn():\n    yield 2\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'

# Generated at 2022-06-21 17:53:41.872443
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def generator():
        yield 1
        return 2

    def generator_with_loop():
        for i in range(2):
            yield i
            return i + 1

    transform = ReturnFromGeneratorTransformer()
    for g in (generator, generator_with_loop):
        fn = ast.parse(g.__code__.co_code)
        fn = ast.fix_missing_locations(transform.visit(fn))
        result = compile(fn, "gen.py", "exec")
        got = list(g())
        expect = eval(result)
        assert got == expect

# Generated at 2022-06-21 17:53:42.972997
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test ReturnFromGeneratorTransformer constructor."""
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:53:44.812401
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:53:48.506718
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test constructor of class ReturnFromGeneratorTransformer"""
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer.target == (3, 2)


# Generated at 2022-06-21 17:53:55.785970
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1

        return 5

    code = fn.__code__

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast.parse(code.co_code))
    assert transformer._tree_changed

    # Find expected code

# Generated at 2022-06-21 17:54:01.458507
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.transform import parse_transform, run_transform

    src = """
        def fn():
            yield from range(0, 10)
            return 100
    """
    expected_result = """
        def fn():
            yield from range(0, 10)
            exc = StopIteration()
            exc.value = 100
            raise exc
    """
    parsed = parse_transform(ReturnFromGeneratorTransformer, src)
    transformed = run_transform(parsed)
    assert expected_result == transformed

# Generated at 2022-06-21 17:54:09.694156
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test(expected_generator_returns, func):
        transformer = ReturnFromGeneratorTransformer()
        func_node = ast.parse(func).body[0]
        transformer.visit(func_node)
        assert transformer._find_generator_returns(func_node) == expected_generator_returns  # pylint: disable = protected-access

    test([
        (
            func_def,
            ast.Return(value=ast.Num(1))
        ),
        (
            func_def,
            ast.Return(value=ast.Num(3))
        )
    ],
        """
    def func():
        yield 1
        return 1
        return 3
        """
    )
