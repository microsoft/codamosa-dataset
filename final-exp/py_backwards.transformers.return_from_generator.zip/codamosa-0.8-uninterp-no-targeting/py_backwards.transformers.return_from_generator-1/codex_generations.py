

# Generated at 2022-06-21 17:46:17.650402
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    fn = ast.parse('def a():\n    yield 1\n    return 5').body[0]  # type: ast.FunctionDef
    fn = transformer.visit(fn)

# Generated at 2022-06-21 17:46:26.827933
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3 as ast
    import textwrap
    source = textwrap.dedent('''
    def fn():
        yield 1
        return 5
    ''')
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(tree)

    expected = ast.parse(textwrap.dedent('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''))

    assert ast.dump(result, include_attributes=True) == ast.dump(expected, include_attributes=True)

# Generated at 2022-06-21 17:46:32.049615
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def gen():
        yield 1
        return 5
    """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert tree.body[0].body[2].value.id == 'exc.value'

# Generated at 2022-06-21 17:46:32.991322
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:38.727360
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class MyReturnFromGeneratorTransformer(BaseNodeTransformer):
        target = (3, 2)
        def __init__(self):
            pass
        
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            assert "target" in dir(self)
            return self.generic_visit(node)  # type: ignore

    # test initialization
    assert MyReturnFromGeneratorTransformer().target == (3, 2)

# Generated at 2022-06-21 17:46:42.323547
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    name = 'ReturnFromGeneratorTransformer'
    class_module = sys.modules[__name__]
    class_object = getattr(class_module, name)
    instance = class_object()
    assert instance.target == (3, 2)


# Generated at 2022-06-21 17:46:49.541716
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    s = "def fn():\n    yield 1\n    return 5"
    tree = ast.parse(s)  # type: ignore
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)  # type: ignore
    code = compile(tree, '', 'exec')
    globs = {}
    exec(code, globs, globs)
    fn = globs['fn']
    it = fn()
    assert next(it) == 1
    with pytest.raises(StopIteration) as excinfo:
        next(it)
    assert excinfo.value.value == 5

# Generated at 2022-06-21 17:46:50.598329
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass
    # todo: implement test

# Generated at 2022-06-21 17:47:01.973422
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:03.104251
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3, 2)

# Generated at 2022-06-21 17:47:13.069056
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        yield 1
        return 5
    def fn2():
        yield 2
    """
    tree = ast.parse(code)
    visitor = ReturnFromGeneratorTransformer()
    tree = visitor.visit(tree)
    assert tree.body[0].body[1].value.s == "exc = StopIteration()\nexc.value = 5\nraise exc"
    assert tree.body[1].body[0].value.s == "yield 2"

# Generated at 2022-06-21 17:47:13.603086
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:18.108786
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from unittest.mock import Mock

    fn = """
        def g():
            yield 1
            return 5
    """
    t = ReturnFromGeneratorTransformer()

    t._find_generator_returns = Mock(return_value=[(object, object)])
    t._replace_return = Mock()
    t.generic_visit = Mock()

    node = ast.parse(fn)
    t.visit(node)

    assert t._tree_changed is True
    t.generic_visit.assert_called_with(node)
    t._replace_return.assert_called_with(object, object)


# Generated at 2022-06-21 17:47:25.077271
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    expected_src = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    expected_ast = ast.parse(expected_src)
    src = """
            def fn():
                yield 1
                return 5
    """
    actual_ast = ast.parse(src)
    transformer = ReturnFromGeneratorTransformer()
    actual_ast = transformer.visit(actual_ast)
    assert expected_ast == actual_ast


# Generated at 2022-06-21 17:47:33.232469
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..compiler import to_source
    from ..utils.unparse import Unparser

    code = '''
    def test():
        yield 1
        return 2
    '''

    expected = '''
    def test():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    '''

    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed is True
    assert to_source(tree) == expected


# Generated at 2022-06-21 17:47:44.464026
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Create mock AST for testing
    class_ = ast.ClassDef()
    class_.name = "MyClass"
    args = ast.arguments()
    func = ast.FunctionDef()
    func.name = "myfunc"
    func.args = args
    body = ast.parse("yield 1\nreturn 5").body
    func.body = body
    class_.body = [func]
    function = ast.parse("yield 2\nreturn 4").body[0]

    # Create transformer
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(class_)
    new_class = str(class_)
    new_function = str(function)
    # Assert AST was changed
    assert transformer._tree_changed == True
    assert isinstance(class_, ast.ClassDef)
    # Assert

# Generated at 2022-06-21 17:47:45.684340
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:46.290796
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass

# Generated at 2022-06-21 17:47:55.101326
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
        def fn():
            print(1)
            return 10
    """)

    ReturnFromGeneratorTransformer().visit(node)

    result = ast.dump(node)

# Generated at 2022-06-21 17:47:59.602624
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Mock(object):
        pass
    mock = Mock()
    mock.body = "body"
    mock.value = "value"
    mock.has_yield = "has_yield"
    mock.child = "child"
    mock.parent = "parent"
    rfgt = ReturnFromGeneratorTransformer()
    rfgt.tree_changed = "tree_changed"
    rfgt.visit_FunctionDef(mock)


# Generated at 2022-06-21 17:48:17.211316
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()

    # Test for a Yield in the node
    class Node(ast.AST):
        _fields = ("body",)

    class Return(ast.AST):
        _fields = ("value",)

    class Name(ast.AST):
        _fields = ("id",)

    class NameConstant(ast.AST):
        _fields = ("value",)

    function_def_node = Node()

    node1 = Return()
    node2 = Return()
    node3 = Return()
    node1.value = NameConstant(value=None)
    node2.value = NameConstant(value=True)
    node3.value = Name(id='d')


# Generated at 2022-06-21 17:48:24.212258
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    node = ast.parse('def f():\n    yield 1\n    return 2', mode='exec')  # type: ignore
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

# Generated at 2022-06-21 17:48:27.730704
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    # https://mail.python.org/pipermail/python-dev/2017-January/146770.html

# Generated at 2022-06-21 17:48:30.309035
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse
    from .transformer_test import TransformerTest
    from .return_from_generator_transformer import ReturnFromGeneratorTransformer


# Generated at 2022-06-21 17:48:34.512690
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import ast_tester

    def fn():
        yield 1
        yield 2
        return 5

    ast_tester.run(fn, ReturnFromGeneratorTransformer)



# Generated at 2022-06-21 17:48:35.990400
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:48:37.632463
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:48:38.564905
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    trans = ReturnFromGeneratorTransformer()
    assert trans

# Generated at 2022-06-21 17:48:45.587658
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    __tracebackhide__ = True
    import astor
    from typed_ast.ast3 import parse

    def check(s1: str, s2: str) -> None:
        t1 = ReturnFromGeneratorTransformer()
        tree = parse(s1)
        t1.visit(tree)
        assert astor.to_source(tree) == s2


# Generated at 2022-06-21 17:48:52.966826
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type:() -> None
    """ Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer. """
    # Arrange
    node = ast.parse("""def fn():
    yield 1
    return 2
""").body[0]
    expected = ast.parse("""def fn():
    yield 1
    exc = StopIteration()
    exc.value = 2
    raise exc
""").body[0]
    transformer = ReturnFromGeneratorTransformer()
    # Act
    transformed = transformer.visit(node)
    # Assert
    assert str(transformed) == str(expected)

# Generated at 2022-06-21 17:49:18.544948
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert not transformer.has_changed


# Generated at 2022-06-21 17:49:26.288994
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class __ReturnFromGeneratorTransformerTestSuite(unittest.TestCase):
        def test_ReturnFromGeneratorTransformer(self):
            code = """
            def fn():
                yield 1
                return 5
            def gen():
                return 5
            """
            expected = """
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            def gen():
                return 5
            """
            node = ast.parse(code)
            new_node = ReturnFromGeneratorTransformer().visit(node)
            self.assertEqual(ast.dump(new_node), ast.dump(ast.parse(expected)))

    return __ReturnFromGeneratorTransformerTestSuite

# Generated at 2022-06-21 17:49:37.504588
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def fn():\n'
                     '    yield 1\n'
                     '    return 5')
    tree = ReturnFromGeneratorTransformer().visit(node)  # type: ignore

# Generated at 2022-06-21 17:49:38.540561
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:46.580642
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # pylint: disable=invalid-name
    return_from_gen = ast.parse(
        "def foo():\n"
        "    yield 1\n"
        "    return 5"
    )
    expected = ast.parse(
        "def foo():\n"
        "    yield 1\n"
        "    exc = StopIteration()\n"
        "    exc.value = 5\n"
        "    raise exc"
    )
    assert expected == ReturnFromGeneratorTransformer().visit(return_from_gen)


# Generated at 2022-06-21 17:49:47.998338
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing_utils import assert_transformed_code_equals

# Generated at 2022-06-21 17:49:49.105034
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .transformer_util import round_trip, assert_equal

# Generated at 2022-06-21 17:49:54.225797
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn(arg):
            yield 1
            return 5
    """

    expected = """
        def fn(arg):
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)  # type: ignore

    assert ast.dump(node) == expected.strip()



# Generated at 2022-06-21 17:49:55.727927
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    f = ReturnFromGeneratorTransformer()
    assert f is not None

# Generated at 2022-06-21 17:50:06.000620
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(source: str, expected: str):
        transformer = ReturnFromGeneratorTransformer()
        transformed = transformer.visit_FunctionDef(ast.parse(source).body[0])
        assert ast.dump(transformed) == expected
    # Replace return with exception raising

    test('''
    def fn():
        yield 1
        return 5
        yield 2
    ''', '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
        yield 2
    ''')

    # Change nothing
    test('''
    def fn():
        yield 1
        return
    ''', '''
    def fn():
        yield 1
        return
    ''')


# Generated at 2022-06-21 17:50:42.924882
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:52.188758
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    program = """def test():
        yield 1
        return 2"""
    expected = """def test():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc"""
    assert ReturnFromGeneratorTransformer(program).result == expected

    program = """def test():
        yield 1
        if x:
            return 2
        else:
            return 3"""
    expected = """def test():
        yield 1
        if x:
            exc = StopIteration()
            exc.value = 2
            raise exc
        else:
            exc = StopIteration()
            exc.value = 3
            raise exc"""
    assert ReturnFromGeneratorTransformer(program).result == expected


# Generated at 2022-06-21 17:50:57.302735
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.mock_node import MockNode
    class Return(MockNode):
        _fields = ()
        value = None
    class Yield(MockNode):
        _fields = ()
    class FunctionDef(MockNode):
        _fields = ('body',)
        body = None
    class If(MockNode):
        _fields = ('body', 'orelse')
        body = orelse = None
    class With(MockNode):
        _fields = ('body',)
        body = None
    class For(MockNode):
        _fields = ('body',)
        body = None
    class While(MockNode):
        _fields = ('body',)
        body = None
    with_ = With(None, body=[])
    for_ = For(None, body=[])

# Generated at 2022-06-21 17:51:06.531612
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import unittest


    class Test(unittest.TestCase):
        def test(self):
            from typed_ast import ast3 as ast
            from typed_ast.transforms import ReturnFromGeneratorTransformer

            func = ast.parse('def fn():\n'
                             '    yield 1\n'
                             '    return 5').body[0]  # type: ignore
            transformer = ReturnFromGeneratorTransformer()
            transformer.visit(func)


# Generated at 2022-06-21 17:51:07.127718
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:51:10.253384
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse('def fn(): yield 4; return 5', 'fn.py', 'exec')
    t = ReturnFromGeneratorTransformer()
    t.visit(node)
    assert str(node) == 'def fn(): yield 4; exc = StopIteration(); exc.value = 5; raise exc'

# Generated at 2022-06-21 17:51:19.069066
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse(textwrap.dedent("""
    def fn(): 
        print('foo')
        yield 1
        return 2
    """))
    node = tree.body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit_FunctionDef(node)

    expected_text = textwrap.dedent("""
    def fn(): 
        print('foo')
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """)
    assert ast.dump(tree) == ast.dump(ast.parse(expected_text))



# Generated at 2022-06-21 17:51:20.791498
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:51:28.280975
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # source code
    code1 = """def fn():
        return 1"""
    code2 = """def fn():
        yield 1
        return 5
        yield 10"""

    # expected result
    expected1 = """def fn():
    return 1"""
    expected2 = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc
    yield 10"""

    # it must return identical source if there is no return in generators
    assert ReturnFromGeneratorTransformer().visit(ast.parse(code1)) == ast.parse(expected1)
    assert ReturnFromGeneratorTransformer().visit(ast.parse(code2)) == ast.parse(expected2)

# Generated at 2022-06-21 17:51:38.847269
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            source = """
                def fn():
                    yield 1
                    return 5
                    yield 'spam'
            """

            # Normal test
            compare_source_ast(source, ReturnFromGeneratorTransformer)

            # Test if method _find_generator_returns works
            fn_def = parse_ast(source).body[0]
            generator_returns = ReturnFromGeneratorTransformer._find_generator_returns(ReturnFromGeneratorTransformer, fn_def)
            self.assertEqual([x for _, x in generator_returns], fn_def.body[1:2])

            # Test if method _replace_return works
            fn_def = parse_ast(source).body[0]
            generator_return

# Generated at 2022-06-21 17:53:21.322596
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast_dump = """
    FunctionDef(
        name='foo',
        args=arguments(
            args=[arg(arg='a', annotation=None)],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]),
        body=[
            Return(value=Num(n=5))],
        decorator_list=[],
        returns=None)
    """

# Generated at 2022-06-21 17:53:29.035967
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .check_nodes import CheckAstNodes
    from .check_node_transformers import CheckNodeTransformers

    returns = [
        (ast.Return(ast.Constant(1, kind=None)),
         'exc = StopIteration()',
         'exc.value = 1',
         'raise exc',
         ),

        (ast.Return(ast.Name('x', ast.Load())),
         'exc = StopIteration()',
         'exc.value = x',
         'raise exc',
         ),

        (ast.Return(ast.Name('x', ast.Store())),
         'exc = StopIteration()',
         'exc.value = x',
         'raise exc',
         ),
    ]

    for return_, lines in returns:
        to_test

# Generated at 2022-06-21 17:53:32.438484
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test = ast.parse("""\
        def fn():
            yield 1
            return 2
    """)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(test)

    expected = ast.parse("""\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """)

    assert test == expected



# Generated at 2022-06-21 17:53:33.577019
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    r = ReturnFromGeneratorTransformer()
    assert r



# Generated at 2022-06-21 17:53:39.741137
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
 # noinspection PyArgumentList
    code = """
        def fn():
            yield 1
            return 5
    """

    node = parse(code)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(node)

    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    assert dump_ast(new_tree) == dump_ast(parse(expected_code))

# Generated at 2022-06-21 17:53:40.299507
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    r = ReturnFromGeneratorTransformer()
    assert r

# Generated at 2022-06-21 17:53:43.454058
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer

# Generated at 2022-06-21 17:53:53.385785
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTester
    from typed_ast import (
        ast3 as ast, 
    )

    class Tester(BaseNodeTransformerTester):
        transformer = ReturnFromGeneratorTransformer

        def define_test_cases(self):

            def test_return_from_generator(self, node: ast.AST, expected: ast.AST):
                """Compiles return in generators like:
                    def fn():
                        yield 1
                        yield 2
                        return 5

                    To:
                        def fn():
                            yield 1
                            yield 2
                            exc = StopIteration()
                            exc.value = 5
                            raise exc
                    """
                self.assertEqualAst(expected, self.transform(node))


# Generated at 2022-06-21 17:53:55.017225
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:53:56.779862
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3, 2)
