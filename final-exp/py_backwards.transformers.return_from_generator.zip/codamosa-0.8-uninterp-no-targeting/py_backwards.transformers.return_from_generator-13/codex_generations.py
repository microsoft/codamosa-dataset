

# Generated at 2022-06-21 17:46:14.598621
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer([]) is not None

# Generated at 2022-06-21 17:46:22.473059
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  transformer = ReturnFromGeneratorTransformer()

  fn = ast.parse("""
    def fn():
        yield 1
        return 5
  """).body[0]

  transformer.visit(fn)

  expected = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
  """).body[0]

  ast.fix_missing_locations(fn)
  ast.fix_missing_locations(expected)

  assert fn == expected

# Generated at 2022-06-21 17:46:29.943414
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer(): # no cover
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet, let, parse

    with snippet:
        let(node)
        let(transformer)
        let(expected)

        @parse
        def f():
            'docstring'
            a = 1
            yield a
            return a

        node = f()
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(node)

        @parse
        def g():
            'docstring'
            a = 1
            yield a
            exc = StopIteration()
            exc.value = a
            raise exc

        expected = g()

        assert expected == node

# Generated at 2022-06-21 17:46:32.099987
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Unit test

# Generated at 2022-06-21 17:46:37.503415
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..common import unit_test

    source = """\
    from typing import Generator

    def fn():
        print(1)
        return 5
    """
    expected = """\
    from typing import Generator

    def fn():
        print(1)
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    unit_test(ReturnFromGeneratorTransformer, source, expected)



# Generated at 2022-06-21 17:46:44.890102
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3 as ast

    from typed_ast.pretty_printer import PrettyPrinter
    from typed_ast.transforms import Py33Transformer

    def check(code):
        tree = ast.parse(code)
        tree = Py33Transformer().visit(tree)
        tree = ReturnFromGeneratorTransformer().visit(tree)
        gen = PrettyPrinter().visit(tree)
        print("\n" + code)
        print("-" * 10)
        while True:
            output = gen.send(None)
            if output is None:
                break
            print(output, end="")


# Generated at 2022-06-21 17:46:48.652371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base_node_transformer import compile_func, run_func
    code = """
    def fn():
        yield 1
        return 5
    """
    fn = compile_func(code, ReturnFromGeneratorTransformer)
    assert run_func(fn) == 5


# Generated at 2022-06-21 17:46:50.062612
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ft = ReturnFromGeneratorTransformer()
    assert ft is not None

# Generated at 2022-06-21 17:47:01.565081
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    func = ast.parse('def fn():\n\t1\n')
    func_with_yield = ast.parse('def fn():\n\t1\n\tyield\n')
    func_with_yield_from = ast.parse('def fn():\n\t1\n\tyield from\n')
    func_with_return = ast.parse('def fn():\n\t1\n\treturn 3\n')
    func_with_return_value = ast.parse('def fn():\n\t1\n\treturn 3\n')
    func_with_gen_ret = ast.parse('def fn():\n\t1\n\tyield\n\treturn 3\n')

    trans = ReturnFromGeneratorTransformer()
    new_func = trans.visit(func)

# Generated at 2022-06-21 17:47:05.314261
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Initialize the class
    test_class = ReturnFromGeneratorTransformer()

    # Test the utility function
    node = ast.parse("def fn():\n    yield 1\n    return 5")
    generator_returns = test_class._find_generator_returns(node.body[0])
    assert len(generator_returns) == 1

# Generated at 2022-06-21 17:47:20.708570
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .fixtures.compile_time.generators import sample_generator \
        as sample_generator_function, sample_coroutine_with_parenthesis, return_value
    f = sample_generator_function
    node = ast.parse(f.__code__.co_consts[0])
    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(node)
    assert ast.dump(res) == ast.dump(node)

    f = sample_coroutine_with_parenthesis
    node = ast.parse(f.__code__.co_consts[0])
    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(node)
    assert ast.dump(res) == ast.dump(node)

    f = return_value

# Generated at 2022-06-21 17:47:21.904241
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor

# Generated at 2022-06-21 17:47:22.912066
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:23.909248
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target is not None

# Generated at 2022-06-21 17:47:34.909889
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # 0 - no change
    node = ast.parse('def f(): yield 1')
    t = ReturnFromGeneratorTransformer()
    t.visit(node)
    assert t.tree_changed == 0
    assert ast.dump(node) == 'Module(body=[FunctionDef(name=\'f\', args=arguments(posonlyargs=[], args=[], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[]), body=[Expr(value=Yield(value=Num(n=1)))], decorator_list=[], returns=None)])'

    # 1 - change
    node = ast.parse('def f(): yield 1; return 5')
    t = ReturnFromGeneratorTransformer()
    t.visit(node)
    assert t.tree_changed == 1

# Generated at 2022-06-21 17:47:37.600365
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    r_transformer = ReturnFromGeneratorTransformer()
    assert r_transformer.target == (3, 2)


# Generated at 2022-06-21 17:47:47.130078
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import FunctionDef, Expr, Name, Str, Load, Raise, Call, Compare, Attribute, Is, Subscript
    from typed_ast.ast3 import Assign, AssignName, AssignAttr, AssignTuple, AssignSubscript
    from typed_ast.ast3 import Store, Del, Delete, DelAttr, DelName, DelSubscript, DelTuple
    from typed_ast.ast3 import AugAssign, Add, Sub, Mult, Div, Mod, Pow, BitOr, BitXor, BitAnd, LShift, RShift, FloorDiv
    from typed_ast.ast3 import Invert, Not, UAdd, USub, In, NotIn, IsNot, Eq, NotEq, Lt, LtE, Gt, GtE, And, Or, IfExp, BoolOp
   

# Generated at 2022-06-21 17:47:55.011534
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.testing import check_transform
    from ..utils.conversions import bytes_to_string
    from ..utils.source import source_to_function

    check_transform(
        ReturnFromGeneratorTransformer,
        source_to_function(
            bytes_to_string(return_from_generator),
        ),
        source_to_function(
            bytes_to_string(return_from_generator),
        ),
    )

# Generated at 2022-06-21 17:48:02.804997
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent

    from ..utils.source import source_to_module
    from ..utils.visitor import dump
    from ..utils.fake_mod import fake_mod

    def testit(mod):
        res = ReturnFromGeneratorTransformer().visit(mod)
        res = dump(res)
        print(res)

    mod = fake_mod()

# Generated at 2022-06-21 17:48:04.352994
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer


# Generated at 2022-06-21 17:48:12.562057
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer



# Generated at 2022-06-21 17:48:14.493893
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), ReturnFromGeneratorTransformer)


# Generated at 2022-06-21 17:48:18.588670
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import sys
    if sys.version_info[:2] < (3, 6):
        return

    node = ast.parse("""
        def fn():
            yield 1
            return 5
    """)

    transformed = ReturnFromGeneratorTransformer().visit(node)


# Generated at 2022-06-21 17:48:24.974321
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def is_gen_fn(node):
        return isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Yield)

    def is_stop_iteration(node):
        return isinstance(node.body[1], ast.Expr) and isinstance(node.body[1].value, ast.Call) and node.body[1].value.args[0].id == 'StopIteration' and node.body[1].value.args[1].n == 5

    def is_return(node):
        return isinstance(node.body[2], ast.Return) and node.body[2].value.n == 5


# Generated at 2022-06-21 17:48:35.189604
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from typed_ast import typing3 as typing


# Generated at 2022-06-21 17:48:42.446510
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    result = ReturnFromGeneratorTransformer().visit_FunctionDef(  # type: ignore
        ast.parse('def fn():\n    yield 1\n    return 5', mode='exec').body[0]
    )


# Generated at 2022-06-21 17:48:51.595392
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestReturnFromGeneratorTransformer:

        def __init__(self, code_to_test):
            self.code_to_test = code_to_test
            self.transformer = ReturnFromGeneratorTransformer()

        def run_test(self):
            tree = ast.parse(self.code_to_test)
            self.transformer.visit(tree)
            compiled = compile(tree, '<test>', 'exec')
            exec(compiled, {})

    # Test 1:
    TestReturnFromGeneratorTransformer(
        '''
        def fn():
            yield 1
            return 5
        '''
    ).run_test()

    # Test 2:

# Generated at 2022-06-21 17:48:57.768501
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Define FunctionDef snippet
    def x():
        yield 1
        return 5
    str_expected = textwrap.dedent("""\
    def x():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)
    # Compare expected and actual
    assert ReturnFromGeneratorTransformer().visit(ast.parse(textwrap.dedent(
        """\
        def x():
            yield 1
            return 5
        """
    ))) == ast.parse(str_expected)

# Generated at 2022-06-21 17:48:59.690057
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tt = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:49:01.281499
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tf = ReturnFromGeneratorTransformer()
    assert hasattr(tf, 'target')
    assert hasattr(tf, 'parent')
    assert hasattr(tf, 'visit_FunctionDef')
    assert hasattr(tf, 'visit')


# Generated at 2022-06-21 17:49:23.987087
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from typed_ast import ast3
    from ..utils.testing import print_body

    def test_case(source_code, expected_code, **kwargs):
        node = parse(source_code)
        target = ReturnFromGeneratorTransformer(**kwargs)
        node = target.visit(node)
        if expected_code:
            expected_node = parse(expected_code)
            print_body(expected_node)
            assert ast3.dump(expected_node) == ast3.dump(node)
        else:
            assert node is None

    # Test no generator

# Generated at 2022-06-21 17:49:35.123401
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import FunctionDef
    from .base import BaseNodeTransformer
    transformer = ReturnFromGeneratorTransformer()
    def fn():
        yield 1
        return 5
    node = ast.parse(fn.__code__.co_consts[0]).body[0]
    assert isinstance(node, FunctionDef)
    old_node = copy.deepcopy(node)
    new_node = transformer.visit(old_node)
    assert BaseNodeTransformer.equal_nodes(new_node, old_node)
    def fn():
        yield 1
        yield 2
        return 5
    node = ast.parse(fn.__code__.co_consts[0]).body[0]
    assert isinstance(node, FunctionDef)
    old_node = copy.deepcopy(node)
    new

# Generated at 2022-06-21 17:49:46.414387
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def check(before, after):
        before_node = ast.parse(before)  # type: ignore
        after_node = ast.parse(after)  # type: ignore
        transformer = ReturnFromGeneratorTransformer()
        node = transformer.visit(before_node)
        assert node_equals(node, after_node)

    check(
        before="""
        def fn():
            yield 1
            return 5
        """,
        after="""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )


# Generated at 2022-06-21 17:49:48.536729
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_utils import assert_transform

    assert_transform(
        ReturnFromGeneratorTransformer,
        before,
        after,
    )


# Generated at 2022-06-21 17:49:59.869162
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_return_from_generator = '''
        def fn():
            yield 1
            return 5
    '''

    tree = ast.parse(test_return_from_generator)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    result = ast.dump(tree)

# Generated at 2022-06-21 17:50:09.396464
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse(
        "def fn():\n"
        "    yield 1\n"
        "    return 5"
    )

    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)  # type: ignore
    expected = ast.parse(
        "def fn():\n"
        "    yield 1\n"
        "    exc = StopIteration()\n"
        "    exc.value = 5\n"
        "    raise exc"
    )

    # Check that code was corrected
    assert ast.dump(tree) == ast.dump(expected)
    # Check that function updated tree_changed variable
    assert transformer.tree_changed == True


# Generated at 2022-06-21 17:50:18.926258
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transform = ReturnFromGeneratorTransformer()
    source = '''
    def fn():
        a = 5
        for i in range(a):
            yield i

        if a:
            return a + 5

        return a
    '''

    expected = '''
    def fn():
        a = 5
        for i in range(a):
            yield i

        if a:
            exc = StopIteration()
            exc.value = (a + 5)
            raise exc

        exc = StopIteration()
        exc.value = a
        raise exc
    '''

    assert transform.visit(ast.parse(source)) == ast.parse(expected)



# Generated at 2022-06-21 17:50:27.685391
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    from .strip_type_comments import StripTypeCommentsTransformer
    from .extract_type_comments import ExtractTypeCommentsTransformer
    from ..utils.ast_utils import build_ast_from_snippet, ast2str

    class TestTransformer(BaseNodeTransformer):
        def __init__(self):
            super().__init__()
            self.register_transformer(2, StripTypeCommentsTransformer())
            self.register_transformer(2, ExtractTypeCommentsTransformer())
            self.register_transformer(2, ReturnFromGeneratorTransformer())

    node = ReturnFromGeneratorTransformer().transform(build_ast_from_snippet('def fn():\n    yield 1\n    return 5'))

# Generated at 2022-06-21 17:50:34.835659
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn = ast.parse('''
        def fn():
            yield 1
            return 5
    ''').body[0]
    assert ReturnFromGeneratorTransformer().visit(fn) == ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''').body[0]

# Generated at 2022-06-21 17:50:45.460360
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from random import randint
    from .transformers import FunctionDefTransformer
    from .transformers import ReturnFromGeneratorTransformer

    for seed in range(5):
        tree = {
            'name': 'fn',
            'args': {'args': [], 'defaults': [], 'kwonlyargs': [], 'kw_defaults': [], 'kwarg': None, 'vararg': None},
            'body': [],
            'decorator_list': [],
            'returns': None
        }


# Generated at 2022-06-21 17:51:22.823875
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from ..utils import script_from_ast, ast_equals
    node = parse('def fn(): yield 1; return 5').body[0] # type: ast.FunctionDef
    expected = parse('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''').body[0]
    result = ReturnFromGeneratorTransformer().visit(node)
    assert ast_equals(result, expected)

# Generated at 2022-06-21 17:51:27.641531
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fn_before = ast.parse("""
        def ff():
            yield 1
            return 5
    """)
    expected_snippet = """
        def ff():
            yield 1
            
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    fn_after = ReturnFromGeneratorTransformer().visit(fn_before)
    assert ast.dump(fn_after) == expected_snippet

# Generated at 2022-06-21 17:51:28.477171
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:51:39.005222
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    fn = ast.FunctionDef(
        name='test',
        args=ast.arguments(
            args=[
                ast.arg(arg='x'),
                ast.arg(arg='y', annotation=ast.Name(id='int', ctx=ast.Load())),
            ],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[],
        ),
        body=[
            ast.Expr(value=ast.Yield(value=ast.Num(n=1))),
            ast.Expr(value=ast.Yield(value=ast.Num(n=2))),
            ast.Return(value=ast.Num(n=3))
        ]
    )


# Generated at 2022-06-21 17:51:43.374575
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    import io
    import textwrap

    tree = ast.parse(textwrap.dedent("""
    def fn():
        yield 1
        return 5
    """))

    result = astunparse.unparse(ReturnFromGeneratorTransformer().visit(tree))

    expected = textwrap.dedent("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    assert result == expected

# Generated at 2022-06-21 17:51:50.179451
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    src = \
        '''
        def fn():
            yield 1
            return 5
        '''
    expected_result = \
        '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    tree = ast.parse(src)
    compiled = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(compiled) == ast.dump(ast.parse(expected_result))
# ----------------------------------------------------------------------------------------------------------------------

# Generated at 2022-06-21 17:51:59.506538
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    mod = ast.parse('def foo(): yield 1; return 5')
    mod = ReturnFromGeneratorTransformer().visit(mod)

# Generated at 2022-06-21 17:52:01.513752
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)
    assert isinstance(ReturnFromGeneratorTransformer, object)


# Generated at 2022-06-21 17:52:02.840563
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:52:11.179846
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..transform import TransformerVisitor

    node = ast.parse('\n'.join([
        "def fn():",
        "    yield 1",
        "    return 5"
    ]))

    result = TransformerVisitor(ReturnFromGeneratorTransformer()).visit(node)
    source = ast.dump(result)

    # result should be equal to:
    # def fn():
    #     yield 1
    #     exc = StopIteration()
    #     exc.value = 5
    #     raise exc

# Generated at 2022-06-21 17:53:25.594814
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:53:26.661802
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rfg = ReturnFromGeneratorTransformer()
    assert rfg is not None

# Generated at 2022-06-21 17:53:31.555180
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  transformer = ReturnFromGeneratorTransformer()

  tree = ast.parse(
    inspect.cleandoc(
      """
      def fn():
        yield 1
        return 5
      """
    )
  )

  expected = ast.parse(
    inspect.cleandoc(
      """
      def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
      """
    )
  )
  actual = transformer.visit(tree)

  assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-21 17:53:40.742911
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test simple example
    code = """
        def fn():
            yield 4
            return 4
    """
    expected = """
        def fn():
            yield 4
            exc = StopIteration()
            exc.value = 4
            raise exc
    """
    node = ast.parse(code)
    expected_node = ast.parse(expected)
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert ast.dump(node) == ast.dump(expected_node)
    # Test example with `return None`
    code = """
    def fn():
        yield 4
        return None
    """
    expected = """
    def fn():
        yield 4
    """
    node = ast.parse(code)
    expected_node = ast.parse(expected)
    transformer = Return

# Generated at 2022-06-21 17:53:48.898590
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = ast.parse(code)
    assert str(node) == code

    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert str(node) == expected



# Generated at 2022-06-21 17:53:50.450728
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:54:01.258491
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3
    # assert isinstance(x, float)

# Generated at 2022-06-21 17:54:09.667993
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test case where there is a return in the function body
    function_def_with_return_in_body = ast.parse("def f():\n    return 1").body[0]
    actual = ReturnFromGeneratorTransformer().visit(function_def_with_return_in_body)
    expected_body = [ast.Expr(value=ast.Call(func=ast.Name(id='return_from_generator'), args=[ast.Num(n=1)], keywords=[], starargs=None, kwargs=None)),
                     ast.Return(value=None)]

# Generated at 2022-06-21 17:54:21.189759
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test constant expression
    code = """
        def fn():
            yield 1
            return 5
    """
    root = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer().visit(root)
    source = astor.to_source(transformer)
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    assert source == expected

    # Test expression with variables
    code = """
        def fn():
            yield 1
            return a + 5
    """
    root = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer().visit(root)
    source = astor.to_source(transformer)

# Generated at 2022-06-21 17:54:27.114795
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source import Source
    from ..visitor import ASTNodeVisitor
    from ..loader import Loader

    source = Source("""
    def fn():
        yield 1
        yield 2
        return 3

    def fn2():
        return 4
    """)
    target = Source("""
    def fn():
        yield 1
        yield 2
        exc = StopIteration()
        exc.value = 3
        raise exc

    def fn2():
        return 4
    """)
    loader = Loader(source).load_source()
    visitor = ASTNodeVisitor(loader)
    visitor.apply(ReturnFromGeneratorTransformer())
    assert loader.source == target

# Generated at 2022-06-21 17:55:46.385774
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(target=None)

# Generated at 2022-06-21 17:55:53.845411
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class ReadLinesIter:
        def __iter__(self):
            for line in ['line1', 'line2']:
                yield line

        def __next__(self):
            try:
                return self.generator.__next__()
            except AttributeError:
                # Allow the iterable to be restarted
                self.generator = self.__iter__()
                return self.__next__()

    code = """
    def generator_fn():
        yield 'generator_yield'
        return 'generator_return'
    """

    node = ast.parse(dedent(code)).body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)


# Generated at 2022-06-21 17:56:02.399543
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Arrange
    from typing import Iterator
    from ..utils.source import source_from_node
    from ..utils.ast import ast_from_source

    source = '''\
        def fn():
            yield 1
            return 5
    '''
    expected = '''\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''

    # Act
    node = ast_from_source(source)
    ReturnFromGeneratorTransformer().visit(node)

    # Assert
    assert source_from_node(node) == expected