

# Generated at 2022-06-21 17:46:20.143052
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    statements = """
    def fn():
        yield 1
        return 2
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    node = ast.parse(statements)
    ReturnFromGeneratorTransformer().visit(node)
    assert ast.unparse(node) == expected

# Generated at 2022-06-21 17:46:26.519334
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert transformer_class_fixture_maker(
        ReturnFromGeneratorTransformer.target,
        ReturnFromGeneratorTransformer,
    )(
        """
        def fn():
            yield 1
            return 5
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """,
    )

# Generated at 2022-06-21 17:46:30.007797
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.instance() is ReturnFromGeneratorTransformer.instance()
    assert ReturnFromGeneratorTransformer() is not ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:38.818841
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    @snippet
    def source():
        def fn():
            yield 1
            return 5

    @snippet
    def expected():
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

    transformer = ReturnFromGeneratorTransformer()
    source_ast = source.ast()
    transformed_ast = transformer.visit(source_ast)
    assert source_ast != transformed_ast
    assert hasattr(transformer, '_tree_changed')
    assert transformer._tree_changed
    assert ast.dump(transformed_ast, include_attributes=True) == ast.dump(expected.ast(), include_attributes=True)



# Generated at 2022-06-21 17:46:42.084291
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse('def a(): yield 1 ; return 5')
    ReturnFromGeneratorTransformer().visit(node)
    assert compile(node, '', 'exec').co_consts[1] is StopIteration



# Generated at 2022-06-21 17:46:48.667770
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def _function_source(function_body):
        return 'def fn():\n' + '    ' + '\n    '.join(function_body.split('\n'))

    def _normalize_ast(node):
        node = ast.fix_missing_locations(node)
        return node

    def _compile_code(code):
        node = ast.parse(code)
        node = _normalize_ast(node)
        return node

    def _compare_source(actual_source, expected_source):
        assert actual_source.strip() == expected_source.strip()

    def _compare_ast(actual_source, expected_source):
        actual_ast = _compile_code(actual_source)
        expected_ast = _compile_code(expected_source)

# Generated at 2022-06-21 17:46:50.062976
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:51.405702
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    f = ReturnFromGeneratorTransformer


# Generated at 2022-06-21 17:46:53.434489
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with pytest.raises(TypeError):
        ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:47:03.542672
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import compare_ast
    input_function_1 = """
    @return_from_generator
    def fn():
        yield
        return 5
    """
    expected_function_1 = """
    def fn():
        yield
        exc = StopIteration()
        exc.value = 5
        raise exc

    """
    input_function_2 = """
    def fn():
        yield
        for i in range(10):
            yield i
        yield from some_function()
    """
    expected_function_2 = """
    def fn():
        yield
        for i in range(10):
            yield i
        yield from some_function()
    """

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.run(input_function_1)

# Generated at 2022-06-21 17:47:19.629579
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import parse
    from ..utils import astequal

    # case 1
    node = parse("""
        def fn():
            yield 1
            return 5
    """)
    expected = parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    trans = ReturnFromGeneratorTransformer()
    new_node = trans.visit(node)
    assert astequal(new_node, expected)

    # case 2
    node = parse("""
        def fn():
            return 5
    """)
    expected = parse("""
        def fn():
            return 5
    """)
    trans = ReturnFromGeneratorTransformer()
    new_node = trans.visit(node)

# Generated at 2022-06-21 17:47:23.074636
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.fixtures import basic_generator_function_return, basic_generator_function_return_expected

    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(basic_generator_function_return)

    assert ast.dump(res) == ast.dump(basic_generator_function_return_expected)

# Generated at 2022-06-21 17:47:31.377990
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def no_return_generator():
        yield 1

    assert no_return_generator.__code__.co_flags & 8 == 0  # 8 - CO_GENERATOR

    def return_generator():
        yield 1
        return 5

    assert return_generator.__code__.co_flags & 8 == 8

    result = return_generator()
    next(result)
    with pytest.raises(StopIteration) as excinfo:
        next(result)
    assert excinfo.value.value == 5


transformer = ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:33.292419
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert(isinstance(x,BaseNodeTransformer))


# Generated at 2022-06-21 17:47:35.309330
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None) is not None


# Generated at 2022-06-21 17:47:39.338078
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse("""def fn():\n    yield 1\n    return 2""")
    _ = ReturnFromGeneratorTransformer(node).visit(ast.parse("""def fn():\n    yield 1\n    return 2"""))

# Generated at 2022-06-21 17:47:41.198191
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:47:46.397771
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:55.218538
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    import astor


# Generated at 2022-06-21 17:48:00.636929
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def assert_rewrite(code: str, res: str):
        tree = ast.parse(code)
        res_tree = ast.parse(res)
        transformer = ReturnFromGeneratorTransformer()
        try:
            tree = transformer.visit(tree)
        except Exception:
            tree = None
        assert tree == res_tree, f'\n{code}\n!=\n{res}'

    def test_return_from_generator():
        code = """
        def fn():
            yield from (x for x in range(10))
            return 2
        """
        res = """
        def fn():
            yield from (x for x in range(10))
            exc = StopIteration()
            exc.value = 2
            raise exc
        """
        assert_rewrite(code, res)


# Generated at 2022-06-21 17:48:13.866324
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Return, Expr, Call, Name, Num, Yield, Load
    from .base import BaseNodeTransformer
    from astunparse import unparse
    from textwrap import dedent
    from typing import List
    from nose.tools import assert_equals, timed
    from libcst.testing.utils import data_provider, parse_function


# Generated at 2022-06-21 17:48:22.895137
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..ast_tools import parse
    from .. import transform, ast_tools

    def assert_converted(from_, to_):
        transformed = ast_tools.dump_ast(transform([ReturnFromGeneratorTransformer], parse(from_)))
        assert transformed == ast_tools.dump_ast(parse(to_))

    assert_converted(
        '''
        def func():
            yield 1
            return 2
        ''',
        '''
        def func():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        '''
    )

    assert_converted(
        '''
        def func():
            yield 1
            return
        ''',
        '''
        def func():
            yield 1
            return
        '''
    )

    assert_converted

# Generated at 2022-06-21 17:48:31.658143
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # noqa: D103
    code = """
    def fn():
        yield 1
        return 5
    """
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    compiled = compile(tree, '<test>', 'exec')
    globals_ = {}
    locals_ = {}
    exec(compiled, globals_, locals_)
    generator = locals_['fn']()

    assert next(generator) == 1
    with pytest.raises(StopIteration) as exc_info:
        next(generator)
    assert exc_info.value.value == 5

# Generated at 2022-06-21 17:48:42.428741
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    import ast, textwrap
    before = textwrap.dedent("""\
    def test_return_from_generator():
        def fn():
            yield 1
            return 5
    """)
    after = textwrap.dedent("""\
    def test_return_from_generator():
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    ast_after = ast.parse(after)
    ast_before = ast.parse(before)
    rfgt = ReturnFromGeneratorTransformer()
    node = rfgt.visit(ast_before)
    assert unparse(ast_after) == unparse(node)

# Generated at 2022-06-21 17:48:43.198788
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert type(ReturnFromGeneratorTransformer()) == ReturnFromGeneratorTransformer


# Generated at 2022-06-21 17:48:49.889547
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .fixtures import simple_generator, simple_generator_output
    from .test_base import transform, NodeTest, assert_code_equal
    from .test_unpacking import UnpackingTransformerTest

    source = simple_generator()
    expected_ast = simple_generator_output()

    # test UnpackingTransformer
    assert_code_equal(expected_ast, transform(source, UnpackingTransformerTest))

    # test ReturnFromGeneratorTransformer
    assert_code_equal(expected_ast, transform(source, NodeTest))

# Generated at 2022-06-21 17:48:55.460855
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert _test_if_transformer_works(ReturnFromGeneratorTransformer, 3, '''
        def foo():
            if False:
                return None
            yield 1
            return 5
            return 0
        ''', '''
        def foo():
            if False:
                return None
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            return 0
        ''')



# Generated at 2022-06-21 17:49:07.147134
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    class ReturnFromGeneratorTransformerImpl(ReturnFromGeneratorTransformer):
        def __init__(self):
            self._tree_changed = False

    class TestCase:
        def runTest(self):
            test_input = "def fn(): yield 5; return 1"
            test_output = "def fn(): yield 5; exc = StopIteration(); exc.value = 1; raise exc"
            node = ast.parse(test_input, '<test>', mode='exec').body[0]
            transformer = ReturnFromGeneratorTransformerImpl()
            transformer.visit(node)
            self.assertEqual(test_output, astor.to_source(node))
            self.assertTrue(transformer._tree_changed)

    return TestCase()

# Generated at 2022-06-21 17:49:14.479755
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test visit_FunctionDef method in class ReturnFromGeneratorTransformer"""
    # Test if the method converts a generator's return statements to raise statements
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    node = tree.body[0]
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    assert ast.dump(result) == expected

    # Test if the method does not convert a generator's return statements to raise statements
    source = """
        def fn():
            yield 1
            return 5
    """

# Generated at 2022-06-21 17:49:24.279009
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    generator_return_code = '''
    def test_fn():
        yield 1
        yield 2
        return 5
    '''
    class_generator_return_code = '''
    class TestClass():
        async def __aenter__(self):
            yield 1
            yield 2
            return 5
    '''
    generator_no_return_code = '''
    def test_fn():
        yield 1
        yield 2
    '''
    generator_no_yield_code = '''
    def test_fn():
        return 5
    '''

    test_codes = [generator_return_code, class_generator_return_code, generator_no_return_code, generator_no_yield_code]


# Generated at 2022-06-21 17:49:39.778789
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import parse
    ast_tree = parse('def fn():\n    yield 5\n    return 6')
    transformer = ReturnFromGeneratorTransformer()
    new_ast_tree = transformer.visit(ast_tree)
    assert transformer._tree_changed == True

    fn = new_ast_tree.body[0]
    assert fn.name == 'fn'
    assert len(fn.body) == 4
    assert len(fn.body[3].targets) == 1
    assert fn.body[3].targets[0].id == 'exc'
    assert isinstance(fn.body[3].value, ast.Name)
    assert fn.body[3].value.id == 'StopIteration'
    assert len(fn.body[2].targets) == 1

# Generated at 2022-06-21 17:49:49.361547
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ...testing import assert_node
    from typed_ast import ast3 as ast
    from ast_tools import NodeTransformer, NodeVisitor

    class A(NodeTransformer):
        pass

    class B(NodeTransformer):
        pass

    class C(NodeTransformer):
        pass

    class D(NodeTransformer):
        pass

    class E(NodeTransformer):
        pass

    class F(NodeTransformer):
        pass

    class X(NodeVisitor):
        def visit_Return(self, node):
            print("visit_Return")

    def fn():
        yield 1
        return 5

    node = ast.parse(fn.__code__)
    node = node.body[0]

    x = X()
    x.visit(node)

    a = A()
    b = B()


# Generated at 2022-06-21 17:50:00.514290
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    snippet_101 = """
    def fn():
        yield 1
        return 5
    """
    snippet_102 = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    # snippet_101 = """
    # def use_label(label, label_context):
    #     if label_context.current_label() == label:
    #         return 0
    #     elif label in label_context._labels:
    #         return len(label_context._labels)
    #     else:
    #         return -1
    # """
    # snippet_102 = """
    # def use_label(label, label_context):
    #     if label_context.current_label() == label:
    #         return 0
    #     el

# Generated at 2022-06-21 17:50:03.775329
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class ReturnFromGeneratorTransformer."""
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer



# Generated at 2022-06-21 17:50:05.251390
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-21 17:50:12.858726
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Create a "node" for testing
    return_value = ast.Num(n=5)
    return_node = ast.Return(value=return_value)
    yield_node = ast.Yield(value=None)
    body_node = [yield_node, return_node]
    node = ast.FunctionDef(name='fn', args=None, body=body_node, decorator_list=[], returns=None)
    # Perform test
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    # Check if the result is as expected
    expected_result = str([yield_node, return_from_generator(return_value)])
    actual_result = str(node.body)
    assert actual_result == expected_result

# Generated at 2022-06-21 17:50:16.958674
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = """
        def fn():
            yield 1
            return 5
    """
    compiled = ReturnFromGeneratorTransformer().transform_module(source)
    assert 'return_value=5' in compiled
    assert 'StopIteration()' in compiled

# Generated at 2022-06-21 17:50:21.014151
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.__class__.__name__ == 'ReturnFromGeneratorTransformer'
    assert transformer.__class__.target == (3, 2)
    assert transformer.tree_changed() is False
    assert transformer.changed_code is False


# Generated at 2022-06-21 17:50:27.472530
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    @decorator
    def test(x):
        for item in x:
            yield item
        return 1
    """
    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    transformed_code = ast.unparse(tree)
    expected_code = """
    @decorator
    def test(x):
        for item in x:
            yield item
        exc = StopIteration()
        exc.value = 1
        raise exc
    """
    assert expected_code == transformed_code



# Generated at 2022-06-21 17:50:28.325564
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:50:40.303312
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from io import StringIO
    from .base import BaseNodeTransformer


# Generated at 2022-06-21 17:50:48.187774
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    @snippet
    def fn():
        yield 1
        return 5


# Generated at 2022-06-21 17:50:49.511520
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:50:50.724271
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Dummy:
        pass


# Generated at 2022-06-21 17:50:51.906272
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tr = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:50:53.386618
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer

# Generated at 2022-06-21 17:51:04.255503
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.snippet import snippet
    from ..compile_transformer import compile_transformer

    @snippet
    def test_code_1():
        let(result)
        result = []

        # no return
        def fn1():
            yield 1

        for x in fn1():
            result.append(x)

        # no yields
        def fn2():
            return 1

        result.append(fn2())

        # multiple yields
        def fn3():
            yield 1
            yield 2
            return 3

        for x in fn3():
            result.append(x)

        # complex return
        def fn4():
            yield 1
            return 1 + 2

        for x in fn4():
            result.append(x)

        return result


# Generated at 2022-06-21 17:51:05.139835
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:51:14.127038
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import os
    import sys
    import unittest
    import textwrap
    from .. import Transpiler

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../"))
    from tests.utils import (
        combine_source_code,
        get_ast_tree,
        run_transpiler,
        get_python_source_code,
    )

    class ReturnFromGeneratorTransformerTest(unittest.TestCase):

        maxDiff = None

        def _assert_transpile(
            self,
            input: str,
            expected: str = None,
            transformer_cls: type = ReturnFromGeneratorTransformer,
            skip_transformer_arguments: bool = False,
        ) -> None:
            input = textwrap.ded

# Generated at 2022-06-21 17:51:23.172805
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_value = ast.Num(n=5)
    return_statement = ast.Return(value=return_value)
    function_def = ast.FunctionDef(
        name='fn',
        body=[ast.Yield(value=ast.Num(n=1)), return_statement],
        args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    )
    expected = ast.Module(body=[function_def])
    expected.body[0].body = return_from_generator.get_body(return_value=return_value) + [return_statement]

    t = ReturnFromGeneratorTransformer()
    actual = t.visit(ast.parse(return_from_generator.get_source()))

# Generated at 2022-06-21 17:51:40.841278
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    reactor = ReturnFromGeneratorTransformer()
    assert reactor is not None

# Example test

# Generated at 2022-06-21 17:51:42.166796
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:51:51.507182
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.snippet import set_code, get_code
    from ..utils.testutils import assert_equivalent_code

    set_code("""
    def foo():
        yield 1
        return 2
    """)
    assert_equivalent_code(get_code(), """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """)

    set_code("""
    def foo():
        yield 1
        return
    """)
    assert_equivalent_code(get_code(), """
    def foo():
        yield 1
        return
    """)

    set_code("""
    def foo():
        def bar():
            yield 1
            return 2
    """)

# Generated at 2022-06-21 17:51:55.823062
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    def test_helper(s, expected):
        # type: (str, str) -> None
        tree = ast.parse(s, mode="exec")
        ret = ReturnFromGeneratorTransformer().visit(tree)
        actual = ast.unparse(ret)
        assert expected == actual


# Generated at 2022-06-21 17:51:59.647341
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    f = ReturnFromGeneratorTransformer()
    c = f._find_generator_returns(ast.parse("0"))
    assert c == []


# Generated at 2022-06-21 17:52:08.373508
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Dummy code
    code = """
    def fn():
        yield 1
        return 5

    def fn2():
        if True:
            yield 2
            return 200
        else:
            yield 4
            return 5
    """

    # Run code through 'ReturnFromGeneratorTransformer'
    module_node = ast.parse(code)
    new_module = ReturnFromGeneratorTransformer().visit(module_node)

    # Run new code with 'ReturnFromGeneratorTransformer'
    new_code = compile(new_module, '', 'exec')
    code_ns = {
        'StopIteration': StopIteration,
        'fn': None,
        'fn2': None,
    }
    exec(new_code, code_ns)

    # Add return to fn2()

# Generated at 2022-06-21 17:52:09.793619
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-21 17:52:14.874378
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    import astor
    def test(code, expected):
        node = ast.parse(code)
        transformer.visit(node)
        observed = astor.to_source(node)
        assert expected == observed

# Generated at 2022-06-21 17:52:16.507539
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).target == (3, 2)


# Generated at 2022-06-21 17:52:17.324182
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:53:25.334625
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-21 17:53:32.176707
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..transforms.base import BaseNodeTransformer
    from ..transforms.return_from_generator import ReturnFromGeneratorTransformer
    import typed_ast.ast3 as ast
    import astor
    source = """def foo():
    yield 1
    return 5
x = 2
"""
    tree = astor.parse_file(source)
    node = tree.children[0]
    assert isinstance(node, ast.FunctionDef)
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.Yield)
    assert isinstance(node.body[1], ast.Return)
    assert isinstance(tree.children[1], ast.Assign)
    node_transformer = BaseNodeTransformer.mix(ReturnFromGeneratorTransformer)
    result = node_transformer.visit

# Generated at 2022-06-21 17:53:40.927565
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ast_helpers import function_def, assignment_stmt, expr_stmt, expr, \
        import_stmt, from_stmt, return_stmt, yield_stmt
    from ..utils.ast_checker import check_equal_ast

    # Create original node
    original = function_def(
        "fn",
        [],
        [
            yield_stmt(expr("1")),
            return_stmt(expr("5")),
        ]
    )

    # Create expected node

# Generated at 2022-06-21 17:53:44.910239
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.parse_tree import parse_tree
    @snippet
    def before():
        """
        def fn():
            yield 1
            return 5
        """

    @snippet
    def expected():
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """

    tree = parse_tree(before.code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.run(tree)

    assert tree == parse_tree(expected.code)

# Generated at 2022-06-21 17:53:51.673058
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """def fn():
        yield 1
        return 5
        """
    tree = ast.parse(code)
    visitor = ReturnFromGeneratorTransformer()
    visitor.visit(tree)
    expected_code = """def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
        """
    expected_tree = ast.parse(expected_code)
    assert ast.dump(tree) == ast.dump(expected_tree)



# Generated at 2022-06-21 17:54:02.240088
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:54:10.238843
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # type: () -> None
    def fn():
        # type: () -> None
        pass

    assert ReturnFromGeneratorTransformer(fn).transform() == fn

    def fn():
        # type: () -> None
        return 3

    def fn():
        # type: () -> None
        exc = StopIteration()
        exc.value = 3
        raise exc

    assert ReturnFromGeneratorTransformer(fn).transform() == fn

    def fn():
        # type: () -> None
        yield 1
        return 5

    def fn():
        # type: () -> None
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    assert ReturnFromGeneratorTransformer(fn).transform() == fn

    def fn():
        # type: () -> None
        if True:
            yield 1

# Generated at 2022-06-21 17:54:20.174081
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test that ReturnFromGeneratorTransformer works correctly"""
    transformer = ReturnFromGeneratorTransformer()
    code_before = """
    def foo():
        while True:
            yield 1
            return 5
    """
    code_after = """
    def foo():
        while True:
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    # print(ast.dump(ast.parse(code_before)))
    # print(ast.dump(ast.parse(code_after)))
    assert transformer.visit(ast.parse(code_before)) == ast.parse(code_after)


# Generated at 2022-06-21 17:54:23.117611
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Construct the object of class ReturnFromGeneratorTransformer
    obj = ReturnFromGeneratorTransformer()
    # Assert that object is instance of class ReturnFromGeneratorTransformer
    assert isinstance(obj, ReturnFromGeneratorTransformer)

# Generated at 2022-06-21 17:54:25.245425
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).tree_changed == False
    r = ReturnFromGeneratorTransformer(None)
    r.tree_changed = True
    assert r.tree_changed == True


# Generated at 2022-06-21 17:55:41.149699
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from astunparse import unparse
    from . import rename_parameters

    initial_code = """
    def fn():
        yield 1
        return 5
    """

    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    root = ast.parse(initial_code)
    root = rename_parameters.RenameParametersTransformer().visit(root)
    root = ReturnFromGeneratorTransformer().visit(root)
    assert unparse(root) == expected_code

# Generated at 2022-06-21 17:55:51.596109
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    # if return_value is None
    result = transformer.visit_FunctionDef(ast.parse("def fn():\n    return").body[0])
    assert result == ast.parse("def fn():\n    return").body[0]

    # if return_value is not None
    result = transformer.visit_FunctionDef(ast.parse("def fn():\n    return 1").body[0])
    assert transformer._tree_changed is True
    assert result == ast.parse("""
    def fn():
        exc = StopIteration()
        exc.value = 1
        raise exc
    """).body[0]

    # if function doesn't have return statement
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:56:02.465564
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # 1. Simple function body
    input = ast.parse("""
    def fn():
        yield 1
        return 5
    """)

    expected = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    actual = ReturnFromGeneratorTransformer().visit(input)

    assert ast.dump(expected) == ast.dump(actual)

    # 2. Function body with if and while
    input = ast.parse("""
    def fn():
        while True:
            if 2 == 2:
                yield 1
                return 5
    """)


# Generated at 2022-06-21 17:56:10.889733
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Create a tree with 6 lines (1 function definition and 5 lines of generator's body)
    func_def_tree = ast.FunctionDef(name='fn',body=[ast.Expr(value=ast.Yield(value=ast.Num(1)),),ast.Return(value=ast.Num(5),)],
                                    args=ast.arguments(args=[],vararg=None,kwonlyargs=[],kw_defaults=[],kwarg=None,defaults=[]))
    visitor = ReturnFromGeneratorTransformer()
    output = visitor.visit(func_def_tree)

    # The number of lines in output Body