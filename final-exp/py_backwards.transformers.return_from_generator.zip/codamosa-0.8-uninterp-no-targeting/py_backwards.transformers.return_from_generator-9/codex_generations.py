

# Generated at 2022-06-21 17:46:14.276416
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import compile_to_ast as c2a
    from ..utils import dump_ast
    # Test 1

# Generated at 2022-06-21 17:46:16.218866
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__.__name__ == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-21 17:46:22.030405
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTestCase, CompileError

    class TestCase(BaseNodeTransformerTestCase):
        def test_return_from_generator(self):
            # type: () -> None
            source = """
                def fn():
                    yield 1
                    return 5
                """
            expected = """
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
                """
            tree = ast.parse(source)
            transformer = ReturnFromGeneratorTransformer()
            transformer.visit(tree)
            self.assert_tree(tree, ast.parse(expected))


# Generated at 2022-06-21 17:46:30.726924
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseSnippet
    from .base import NodeTransformerTestCase
    from .base import transform

    class Test(BaseSnippet):
        target = (3, 2)

        def check(self):
            snippet = self.snippet
            transform(snippet, ReturnFromGeneratorTransformer)

            assert isinstance(snippet.node, ast.FunctionDef)
            assert snippet.node.name == 'fn'

            fn_body = snippet.node.body  # type: ignore
            assert len(fn_body) == 5

            assert isinstance(fn_body[0], ast.Expr)
            assert isinstance(fn_body[0].value, ast.Yield)
            assert isinstance(fn_body[0].value.value, ast.Num)
            assert fn_body[0].value

# Generated at 2022-06-21 17:46:35.851574
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = get_ast('def f():\n    yield 1\n    return 5\n')
    transformed = ReturnFromGeneratorTransformer().visit(node)
    assert astunparse.unparse(transformed) == 'def f():\n    yield 1\nexc = StopIteration()\nexc.value = 5\nraise exc\n'


# Generated at 2022-06-21 17:46:36.783390
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:39.183991
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    r = snippet.compile(ReturnFromGeneratorTransformer, return_from_generator)
    assert r(5) == 5
    assert isinstance(r(5), StopIteration)

# Generated at 2022-06-21 17:46:40.162372
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    o = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:44.949329
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ast_node = ast.parse('def fn():\n    yield 1\n    return 5')
    expected = ast.parse('def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc')

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(ast_node)

    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-21 17:46:51.226209
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.examples import simple_generator
    from ..utils.unparse import Unparser
    gen = simple_generator()
    transformer = ReturnFromGeneratorTransformer()
    transformed = transformer.visit(gen)
    unparser = Unparser()
    unparser.visit(transformed)
    assert unparser.get_value() == (
        "def fn():\n"
        "    yield 1\n"
        "    exc = StopIteration()\n"
        "    exc.value = 5\n"
        "    raise exc"
    )

# Generated at 2022-06-21 17:46:57.778485
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def f():
        yield 1
        return 2
    """
    expected = """
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    ast_tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    print(astor.to_source(ast_tree))
    assert astor.to_source(ast_tree) == expected

# Generated at 2022-06-21 17:47:02.416592
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == expected



# Generated at 2022-06-21 17:47:04.563092
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_node

    def test_fn(a):
        yield 1
        yield 2
        return a


# Generated at 2022-06-21 17:47:05.393071
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:47:06.138597
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:13.643997
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    code = \
    """
    def test():
        yield 1
        return 5
    def test2():
        yield 1
        if True:
            return 5
    def test3():
        if True:
            yield 1
        if True:
            return 5
    def test4():
        return 5
    """
    result = ast.parse(code)
    transformer.visit(result)

# Generated at 2022-06-21 17:47:17.268588
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn():
        yield 1
        return 5
    """
    expect = """
    def fn():
        yield 1
        exc = StopIteration()  # type: ignore
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    print(ast.dump(tree))
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    print(ast.dump(tree))
    assert ast.dump(tree) == expect

# Generated at 2022-06-21 17:47:28.627537
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from unittest.mock import patch, Mock
    visitor = ReturnFromGeneratorTransformer()

    with patch.object(ReturnFromGeneratorTransformer, 'generic_visit') as mock_generic_visit:
        node = Mock(spec=ast.FunctionDef)
        visitor.visit_FunctionDef(node)
        assert not visitor._tree_changed

    with patch.object(ReturnFromGeneratorTransformer, 'generic_visit') as mock_generic_visit:
        node = ast.parse('def fn():\n    yield 1\n    return 5').body[0]
        ret = visitor.visit_FunctionDef(node)
        assert visitor._tree_changed

# Generated at 2022-06-21 17:47:29.784999
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:38.235919
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fn_ = ast.FunctionDef(
        name='foo',
        args=ast.arguments(args=[], defaults=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, posonlyargs=[]),
        body=[
            ast.Expr(
                value=ast.Yield(value=ast.Num(
                    n=2
                ))
            ),
            ast.Return(
                value=ast.Num(
                    n=5
                )
            )
        ],
        decorator_list=[],
        returns=None
    )


# Generated at 2022-06-21 17:47:46.534012
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:47:47.895022
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None, None, None)

# Generated at 2022-06-21 17:47:59.483278
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3 as ast
    from ..utils import decorators
    from ..utils import source
    from ..utils.source import (
        FunctionDefinition,
        body_of_function,
        type_annotation,
        generator_function,
        generator_function_call,
    )
    from ..utils.snippet import snippet, let
    from ..utils.decorators import generator_function_example
    from ..utils.source import FunctionDefinition
    from ..utils.nodes import ast_call, ast_evaluate

    class ExpectedFunction(FunctionDefinition):
        def __init__(self):
            FunctionDefinition.__init__(self, 'f', 'return_from_generator')
            self.add_decorator(ast.Name(id='generator_function', ctx=ast.Load()))

# Generated at 2022-06-21 17:48:10.302765
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from magic_constraints import base, snippet
    let(node, module)
    node = ast.parse("""
        def fn():
            yield 1
            return 5
    """, mode='exec')
    module = node.body[0]

    transformer = base.ReturnFromGeneratorTransformer()
    transformed_module = transformer.visit(module)

    expected_result = snippet.return_from_generator.get_ast(return_value=ast.Num(n=5))
    expected_result_str = """def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc"""
    expected_result = ast.parse(expected_result_str, mode='exec').body[0]

    assert transformed_module == expected_result

# Generated at 2022-06-21 17:48:14.442858
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import convert
    from ..utils.test_nodes import func_with_yield_n_return

    source = func_with_yield_n_return(n=2)


# Generated at 2022-06-21 17:48:23.218551
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_astunparse
    from .utils import get_node
    # test that it transforms a single return from generator call
    source = '''
    def foo():
        yield 1
        return 2
    '''
    expected = '''
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    '''

    node = get_node(source, 3)
    result = ReturnFromGeneratorTransformer().visit(node)
    typed_astunparse.unparse(result)
    assert typed_astunparse.unparse(result) == expected
    # test that it transforms two returns from generators
    source = '''
    def foo():
        yield 1
        if True:
            yield 2
            return 3
    '''

# Generated at 2022-06-21 17:48:31.660257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_node
    from ..utils.dump import dump
    from ..utils.compare_ast import compare_ast

    tree = get_node('''
    def fn():
        yield 1
        return 5
    ''')
    expected_tree = get_node('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')


    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert compare_ast(expected_tree, new_tree)

# Generated at 2022-06-21 17:48:43.045106
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    get_tree = lambda text: ast.parse(text, mode='exec')
    expected_tree = get_tree("""
    def fn():
        yield 5
        exc = StopIteration()
        exc.value = None
        raise exc
    """)
    tree = get_tree("""
    def fn():
        yield 5
        return
    """)
    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

    expected_tree = get_tree("""
    def fn():
        yield 5
        exc = StopIteration()
        exc.value = (1, 2, 3)
        raise exc
    """)

# Generated at 2022-06-21 17:48:44.648842
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-21 17:48:46.062719
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer(None, None)


# Generated at 2022-06-21 17:49:08.173254
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.tester import assert_source

    @snippet
    def fn():
        let(yield_list)
        yield_list = [1, 2, 3]
        for value in yield_list:
            yield value
        let(return_list)
        return_list = [4, 5]
        for value in return_list:
            yield value
        return sum(return_list)

    with assert_source(ReturnFromGeneratorTransformer,
                       "return_from_generator(sum(return_list))",
                       fn):
        pass



# Generated at 2022-06-21 17:49:17.020904
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # python code to be tested
    code = """
    def generator():
        yield 1
        yield 2
        return 5

    def simple():
        return 5
    """
    # expected python code after visiting the tree
    expected = """
    def generator():
        yield 1
        yield 2
        exc = StopIteration()
        exc.value = 5
        raise exc

    def simple():
        return 5
    """
    # visit the tree and make assertions
    assert expected == ReturnFromGeneratorTransformer().visit(ast.parse(code))



# Generated at 2022-06-21 17:49:25.483314
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    assert visit(ReturnFromGeneratorTransformer, """
        def foo():
            yield 'foo'
            return 'bar'
    """) == """
        def foo():
            yield 'foo'
            exc = StopIteration()
            exc.value = 'bar'
            raise exc
    """

    assert visit(ReturnFromGeneratorTransformer, """
        def foo():
            if True:
                yield 'foo'
                return 'bar'
    """) == """
        def foo():
            if True:
                yield 'foo'
                exc = StopIteration()
                exc.value = 'bar'
                raise exc
    """


# Generated at 2022-06-21 17:49:26.151435
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-21 17:49:27.273767
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:29.234961
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), ReturnFromGeneratorTransformer)


# Generated at 2022-06-21 17:49:34.631802
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """def foo():\n    yield 1\n    return 5"""
    expected = """def foo():\n    yield 1\n    exc = StopIteration()\n\
    exc.value = 5\n    raise exc"""

    assert ReturnFromGeneratorTransformer().visit(ast.parse(code)) == ast.parse(expected)  # type: ignore

# Generated at 2022-06-21 17:49:37.608528
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == 'ReturnFromGeneratorTransformer'
    temp = ReturnFromGeneratorTransformer()
    assert temp.target == (3, 2)

# Generated at 2022-06-21 17:49:45.654995
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.mock_ast import parse_code, dump_tree
    from ..utils import assert_node_equal

    node = parse_code('''
    def fn():
        yield 1
        return 2
    ''')

    expected_node = parse_code('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    ''')

    transformer = ReturnFromGeneratorTransformer()
    tree_changed = transformer.visit(node)
    assert tree_changed

    assert_node_equal(expected_node, node)

# Generated at 2022-06-21 17:49:52.854966
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source import source_to_ast
    src = '''\
    def fn():
        yield 1
        return 5
    '''
    fn = source_to_ast(src).body[0]

    transformer = ReturnFromGeneratorTransformer()
    fn = transformer.visit(fn)

    expected_src = '''\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    expected_fn = source_to_ast(expected_src).body[0]
    assert ast.dump(fn) == ast.dump(expected_fn)



# Generated at 2022-06-21 17:50:29.221319
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    res = parse_str(_test_str_0)
    assert res.body[0].body[0].value.s == 'a'
    assert res.body[0].body[1].value.n == 5
    assert len(res.body[0].body[2].body) == 2
    assert res.body[0].body[2].body[0].value.n == 2
    assert res.body[0].body[2].body[1].value.n == 5


# Generated at 2022-06-21 17:50:35.861229
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = textwrap.dedent("""
        def fn():
            yield 1
            return 2
        """)
    assert transform_snippet(ReturnFromGeneratorTransformer, code) == textwrap.dedent("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        """)


# Generated at 2022-06-21 17:50:38.398248
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:50:39.539768
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:50:47.577274
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    def _test(func_body, expected):
        def test_function():
            exec(func_body)
        test_function.__name__ = 'test_function'
        tree = ast.parse(func_body)
        node = tree.body[0]
        node = ReturnFromGeneratorTransformer().visit(node)
        self.assertEqual(ast.dump(node), expected)

    # test 1: no return
    func_body = """def test_function():
        pass"""
    expected = """def test_function():
    pass"""
    _test(func_body, expected)

    # test 2: return
    func_body = """def test_function():
        return 1"""
    expected = """def test_function():
    return 1"""
    _test(func_body, expected)

    # test 3

# Generated at 2022-06-21 17:50:48.282484
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:54.600157
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    psrc = """
    def fn():
        yield 1
        if 1:
            return 5
        else:
            return 6
    """
    ptree = ast.parse(psrc)
    ReturnFromGeneratorTransformer().visit(ptree)

    src = """
    def fn():
        yield 1
        if 1:
            exc = StopIteration()
            exc.value  = 5
            raise exc
        else:
            exc = StopIteration()
            exc.value  = 6
            raise exc
    """
    tree = ast.parse(src)
    assert ptree == tree



# Generated at 2022-06-21 17:50:55.459264
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:56.793872
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:59.696982
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Unit test to check whether the function _find_generator_returns() is working correctly

# Generated at 2022-06-21 17:52:13.395581
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import NodeTransformerTest
    from textwrap import dedent as d


# Generated at 2022-06-21 17:52:14.645247
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer('3.2')


# Generated at 2022-06-21 17:52:23.423754
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():

    a = ast.FunctionDef(name='a', body=[
        ast.Yield(value=ast.Num(n=2.3)),
        ast.Return(value=ast.Num(n=5.6))
    ])

    a = ReturnFromGeneratorTransformer().visit(a)


# Generated at 2022-06-21 17:52:25.367087
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    res = ReturnFromGeneratorTransformer()
    assert isinstance(res, BaseNodeTransformer)

# Generated at 2022-06-21 17:52:29.787573
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    for stmt in [
        "def fn(): return x",
        "def fn(): return 1",
        "def fn(): x = input(); return x",
        "def fn(): x = input(); return",
        "def fn():\n\treturn x\n\tx = input()",
        "def fn():\n\treturn\n\tx = input()",
        "def fn(): return x\n\ty = input()",
        "def fn():\n\treturn x\n\treturn y",
        "def fn():\n\treturn x\n\treturn y\n\tx = input()\n\treturn",
        "def fn():\n\treturn x\n\tif x:\n\t\treturn y\n\telse:\n\t\treturn",
    ]:
        result

# Generated at 2022-06-21 17:52:40.946859
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from .base import TransformerSequence
    from ..utils.fixtures import (
        generator_function_without_return,
        generator_function_with_return,
        generator_function_with_inner_function,
    )
    import textwrap
    import astor
    import inspect
    import typed_astunparse

    generator_function_without_return_str = textwrap.dedent(inspect.getsource(generator_function_without_return))
    generator_function_with_return_str = textwrap.dedent(inspect.getsource(generator_function_with_return))
    generator_function_with_inner_function_str = textwrap.dedent(inspect.getsource(generator_function_with_inner_function))

    transformer = ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:52:42.485315
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:52:45.854252
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class Dummy:
        def __init__(self):
            pass

    t = ReturnFromGeneratorTransformer()
    t.visit_FunctionDef(Dummy())

# Generated at 2022-06-21 17:52:53.768318
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == 'ReturnFromGeneratorTransformer'
    assert ReturnFromGeneratorTransformer.target == (3, 2)
    r = ReturnFromGeneratorTransformer()
    assert not r._find_generator_returns(ast.parse('def fn(): pass\n').body[0])
    assert r._find_generator_returns(ast.parse('def fn(): yield 1;return 5').body[0])
    assert r._find_generator_returns(ast.parse('def fn(): return\ndef fn2(): yield 1;return 5').body[1])
    assert r._find_generator_returns(ast.parse('def fn(): pass; return').body[0]) == []

# Generated at 2022-06-21 17:53:05.505582
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestClass(unittest.TestCase):
        def test_class(self):
            module = ast.parse(''' # test_class
            def __init__(self):
                pass

            def fn():
                yield 1
                return 5

            def fn2():
                yield 1
                return 5''')

            result = ast.dump(ReturnFromGeneratorTransformer().visit(module)) # type: ignore

# Generated at 2022-06-21 17:56:03.698177
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from ..utils.context import Context
    from ..utils.data_for_tests import *

    # Simple cases
    code = "def fn():\n    yield from [1]\n    return 1"
    tree = ast3.parse(code)

    transformer = ReturnFromGeneratorTransformer(Context())
    result = transformer.visit(tree)

    expected = [
        {
            "exception": "StopIteration",
            "exception_val": "return_value",
            "line_num": 3,
        },
    ]
    assert transformer.context.error_collection.errors == expected

    assert transformer.context.error_collection.find_by_lines(3) != []
    assert transformer.context.error_collection.find_by_lines(2) == []  # Not generator

# Generated at 2022-06-21 17:56:05.392629
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:56:08.554445
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = '''
    def gen():
        yield 1
        return 5
    '''
    node = ast.parse(code)
    assert not ReturnFromGeneratorTransformer().visit(node)