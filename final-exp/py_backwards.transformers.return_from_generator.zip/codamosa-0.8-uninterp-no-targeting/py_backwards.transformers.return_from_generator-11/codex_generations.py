

# Generated at 2022-06-21 17:46:09.242658
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    func = ast.parse('def fn(): yield 1; return 1').body[0]
    func = ReturnFromGeneratorTransformer().visit(func)
    assert '''def fn():
    yield 1
    exc = StopIteration()
    exc.value = 1
    raise exc''' == ast.unparse(func)

# Generated at 2022-06-21 17:46:15.529852
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    expected = """def f():
    yield "yield"
    exc = StopIteration()
    exc.value = "return value"
    raise exc"""
    test_input = """def f():
    yield "yield"
    return "return value" """
    node = ast.parse(test_input)
    node = ReturnFromGeneratorTransformer().visit(node)
    result: str = ast.unparse(node)
    assert expected == result


# Generated at 2022-06-21 17:46:21.776109
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typing
    import unittest
    import typed_ast.ast3 as ast

    class test_ReturnFromGeneratorTransformer_visit_FunctionDef(unittest.TestCase):

        def test_0(self):
            program = ast.parse(
                textwrap.dedent(
                    '''\
                    def fn():
                        yield 1
                        return 5
                    '''
                ),
                mode='exec',
            )

            node = program.body[0].value  # type: ast.FunctionDef

            visitor = ReturnFromGeneratorTransformer(None)
            visitor.visit(node)


# Generated at 2022-06-21 17:46:23.847735
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    f = ReturnFromGeneratorTransformer()
    print('test_ReturnFromGeneratorTransformer', f)



# Generated at 2022-06-21 17:46:32.923899
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    fn = ast.parse('def gen():\n'
            '    yield 1\n'
            '\n'
            '    return 5')
    fn2 = ast.parse('def gen2():\n'
            '    yield 2\n'
            '    if True:\n'
            '        return 5')

    t.visit(fn)
    t.visit(fn2)
    assert t._find_generator_returns(fn.body[0]) == [(fn.body[0], fn.body[0].body[1])]
    assert t._find_generator_returns(fn2.body[0]) == [(fn2.body[0].body[1], fn2.body[0].body[1].body[0])]


# Generated at 2022-06-21 17:46:39.776906
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    print("Testing class ReturnFromGeneratorTransformer")
    m = ast.parse('def test():\n    x = 5\n    yield x\n    return x\n')
    ReturnFromGeneratorTransformer().visit(m)  
    code = compile(m, "<test>", "exec")
    exec(code)
    test = locals()["test"]
    assert next(test()) == 5
    with pytest.raises(StopIteration) as exc:
        next(test())
    assert exc.value.value == 5

# Generated at 2022-06-21 17:46:40.828447
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:43.190014
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3


# Generated at 2022-06-21 17:46:51.149141
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source import source
    from ..utils.compat import builtins
    from .base import BaseNodeTransformer

    class Compiler(BaseNodeTransformer):
        def visit_Module(self, node):
            return ast.Interactive([node.body[0]])

        def visit_Expr(self, node):
            return node

    tree = ast.parse(source(ReturnFromGeneratorTransformer))
    compiler = Compiler()
    tree = compiler.visit(tree)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    
    code = compile(tree, '', 'exec')
    eval(code, {'__name__': '__main__', '__builtins__': builtins})

# Generated at 2022-06-21 17:47:02.186387
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # assert that ReturnFromGeneratorTransformer._find_generator_returns method works as expected
    assert isinstance(find_generator_returns('def test(): yield'), list)
    assert isinstance(find_generator_returns('def test(): return 5'), list)
    assert isinstance(find_generator_returns('def test(): yield 5'), list)
    assert isinstance(find_generator_returns('def test(): if True: yield\nelif True: return 5'), list)
    assert isinstance(find_generator_returns('def test(): if True: return 5\nelif True: yield'), list)

    assert not find_generator_returns('def test(): return 5')
    assert not find_generator_returns('def test(): pass')

# Generated at 2022-06-21 17:47:07.930007
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer



# Generated at 2022-06-21 17:47:19.529334
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    # Use the parse function from the ast module
    root = ast.parse(
        "def fn():\n"
        "    yield 1\n"
        "    yield 2\n"
        "    return 5\n"
        "def fn2():\n"
        "    yield 1\n"
        "    yield 2")
    # Transform the tree and get a modified version
    new_root = transformer.visit(root)

    # Generate code from the modified tree
    code = compile(new_root, filename="<ast>", mode="exec")

    # Make sure the code is what we expect it to be
    exec(code)
    assert fn().__next__() == 1
    assert fn().__next__() == 2
    assert fn().__next__() == 5



# Generated at 2022-06-21 17:47:22.369368
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def init_ReturnFromGeneratorTransformer():
        return ReturnFromGeneratorTransformer

    assert callable(init_ReturnFromGeneratorTransformer)


# Generated at 2022-06-21 17:47:33.372849
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    '''
    Test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    '''
    # We will create a code snippet that should be transformed.
    # This code creates two types of variables:
    # - one is created from the arguments of the function
    # - one is created from the assignment inside the function
    # The variables are:
    # - a: this is an argument and it should be transformed
    # - b: this is an argument but it should be ignored because it is used in an
    #      if statement
    # - c: this is an argument but it should be ignored because it is not used
    #      anywhere
    # - d: this is a variable created inside the function
    # - e: this is a variable created inside the function but it should be ignored
    #      because it is used in an if statement
    # - f

# Generated at 2022-06-21 17:47:43.964406
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import compile_isolated
    gen_code = """
    def fn():
        yield 1
        return 5
    """
    compiled_fn = compile_isolated(gen_code, flags=["-3"])
    assert next(compiled_fn.fn()) == 1
    assert next(compiled_fn.fn()) == 5

    gen_code = """
    def fn():
        yield 1
        return 5
    """
    compiled_fn = compile_isolated(gen_code, flags=["-3"])
    assert next(compiled_fn.fn()) == 1
    try:
        next(compiled_fn.fn())
        assert False
    except StopIteration as e:
        assert e.value == 5

# Generated at 2022-06-21 17:47:53.749080
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer, flatten_code
    from .inline_passes import InlinePassTransformer
    from ..utils.testing import assert_transformation_result

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            return node

    def transform(code):
        return flatten_code(code, [InlinePassTransformer, TestTransformer, ReturnFromGeneratorTransformer])

    assert_transformation_result(
        transform,
        """
        def fn():

            yield 1
            return 1
        """,
        """
        def fn():

            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc
        """,
    )


# Generated at 2022-06-21 17:47:58.958149
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .utils import get_node
    from ..utils import run_all
    from .. import xtrans

    code = '''
    def fn():
        yield 1
        return 5
    '''
    ast_tree = get_node(code)
    run_all(ast_tree)
    xtrans.run_all(ast_tree)
    assert code != ast.dump(ast_tree)

# Generated at 2022-06-21 17:48:02.102861
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_astunparse
    from . import compile
    from . import base
    from ..utils import debugger

    def run(source):
        node = compile.parse_code(source)

        node = ReturnFromGeneratorTransformer().visit(node)

        return typed_astunparse.unparse(node)



# Generated at 2022-06-21 17:48:06.369539
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def gen():
        yield 1
        return 5
    compiled = compile(gen.__code__, 'test.py', 'exec')
    tree = ast.parse(compiled)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    exec(compile(tree, 'test.py', 'exec'))

# Generated at 2022-06-21 17:48:17.352060
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def make_function_def(body: List[ast.AST]) -> ast.FunctionDef:
        node = ast.FunctionDef('', ast.arguments([], [], [], []), body, [])
        return ReturnFromGeneratorTransformer().visit(node)


# Generated at 2022-06-21 17:48:39.175969
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from textwrap import dedent

    source = dedent('''\
    def fn():
        yield 1
        return 5
    ''')

    expected = dedent('''\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    tree_modified = astor.to_source(tree)
    assert_equal(tree_modified, expected)


# Generated at 2022-06-21 17:48:40.851690
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .utils import compile_to_ast

# Generated at 2022-06-21 17:48:51.201324
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.fake import fake

    fake.reset()
    fake.add_node('node', [])
    fake.add_node('return_node', [])
    fake.add_node_attr('return_node', 'value', 'fake_return_value')

    transformer = ReturnFromGeneratorTransformer()
    node = fake.FunctionDefWithBody([
        fake.YieldFrom('node'),
        fake.Return('return_node'),
    ])

    new_node = transformer.visit(node)


# Generated at 2022-06-21 17:48:53.210461
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    try:
        ReturnFromGeneratorTransformer()
    except:
        assert False


# Generated at 2022-06-21 17:48:53.846509
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:48:56.635727
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_ast = ast.parse('def fn(): yield 1; return 1')
    visitor = ReturnFromGeneratorTransformer()
    visitor.visit(test_ast)
    assert visitor.tree_changed == True

# Generated at 2022-06-21 17:49:07.926051
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from ..plugins.return_from_generator import ReturnFromGeneratorTransformer
    import ast
    import astunparse

    source = """
        def foo():
            yield 1
            return 5
    
        def bar():
            for x in range(5):
                yield x
            return 5
    
        def baz():
            if True:
                yield from bar()
                print(1)
            return 7
    
        def qux():
            while True:
                yield 1
                return 5
    
        def quux():
            if True:
                return 5
            yield 1
        """


# Generated at 2022-06-21 17:49:12.613713
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class ReturnFromGeneratorTransformerSubclass(ReturnFromGeneratorTransformer):
        def _find_generator_returns(self, node):
            return [(node, x) for x in node.body]

    tree = ast.parse('def fn(): yield 1; return 5')
    fn = tree.body[0]
    transformer = ReturnFromGeneratorTransformerSubclass()

    transformer.visit(fn)

    assert fn.body[-1].value.func.id == 'StopIteration'



# Generated at 2022-06-21 17:49:20.093807
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .as_ast import to_ast
    from .base import BaseNodeTransformer
    from .remove_unused_variables import RemoveUnusedVariablesTransformer
    from .convert_with_blocks_to_try_finally import ConvertWithBlocksToTryFinallyTransformer
    from .lift_try_finally import LiftTryFinallyTransformer
    from .unroll_loops import UnrollLoopsTransformer
    from .gather_arguments import GatherArgumentsTransformer
    from .gather_withs import GatherWithsTransformer
    t = ReturnFromGeneratorTransformer()
    o = ast.parse(
        """
        def fn():
            yield 1
            return 5
        """).body[0]
    t.visit(o)

# Generated at 2022-06-21 17:49:25.855303
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..utils import compile_snippet, ast_dump
    snippet_code = """
    def fn():
        yield 1
        return 5
    """
    node = compile_snippet(snippet_code, mode='exec', to_ast=True)
    node = node.body[0]
    assert ast_dump(node) == snippet_code
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert 'return 5' not in ast_dump(node)

# Generated at 2022-06-21 17:49:46.095354
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:49:47.260454
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    return not transformer

# Generated at 2022-06-21 17:49:48.382582
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:56.719048
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestReturnFromGeneratorTransformer(unittest.TestCase):
        def test_find_generator_returns(self):
            def test(definition, expected):
                body = ast.parse(definition)
                self.assertEqual(
                    ReturnFromGeneratorTransformer()._find_generator_returns(body.body[0]),
                    expected
                )

            # empty functions have no returns
            test('def fn(): pass', [])

            # returns with values should be interesting
            test('def fn(): return 1', [(body, body.body[0])])
            test('def fn(): pass; return 1', [(body, body.body[1])])
            test('def fn(): return 1; yield 1', [(body, body.body[0])])
            test('def fn(): return; yield 1', [])
            test

# Generated at 2022-06-21 17:50:08.587436
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast.ast3 import parse
    from typed_ast.transforms import Py23CompatTransformer
    from typed_ast.transforms import PrintTransformer
    from typed_ast.transforms import GeneratorTransformer
    from typed_ast.transforms.unwrap import UnwrapTransformer
    from typed_ast.transforms.return_from_generator import ReturnFromGeneratorTransformer
    body = [parse('yield 5').body[0], parse('return 1').body[0]]
    fun = parse('def test():\n' + '  ' + '\n  '.join(PrintTransformer().visit(body)))
    fun, = (GeneratorTransformer().visit(fun))
    fun, = ReturnFromGeneratorTransformer(Py23CompatTransformer()).visit(fun)
    fun, = UnwrapTransformer().vis

# Generated at 2022-06-21 17:50:19.344488
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .listcomp import ListcompsToForLoops
    from .yieldexpression import YieldExpressionTransformer
    from .yieldfrom import YieldFromTransformer

    tree = ast.parse("""
    def f():
        yield 1
        return 5
    """)

    expected_tree = ast.parse("""
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    tree = ListcompsToForLoops().visit(tree)
    tree = YieldExpressionTransformer().visit(tree)
    tree = YieldFromTransformer().visit(tree)
    tree = ReturnFromGeneratorTransformer().visit(tree)

    ast.fix_missing_locations(tree)

# Generated at 2022-06-21 17:50:26.813582
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    class NodeTransformerForTesting(ReturnFromGeneratorTransformer):
        _tree_changed = False

    code = """def fn():
    yield 1
    return 5"""
    expected_code = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""

    root_node = ast.parse(textwrap.dedent(code), mode='exec')
    node_transformer = NodeTransformerForTesting()
    transformed_root_node = node_transformer.visit(root_node)
    transformed_code = astunparse.unparse(transformed_root_node)

    assert transformed_code == expected_code


# Generated at 2022-06-21 17:50:33.849645
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse, FunctionDef

    code = "def fn(): yield 1; return 5"  # type: ignore
    ast_tree = parse(code)
    assert len(ast_tree.body) == 1
    node = ast_tree.body[0]
    assert isinstance(node, FunctionDef)

    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(ast_tree)

    assert transformer._tree_changed
    assert len(new_ast.body[0].body) == 5

    # visit_Assign
    assert isinstance(new_ast.body[0].body[0], ast.Assign)

    # visit_Expr
    assert isinstance(new_ast.body[0].body[1], ast.Expr)

# Generated at 2022-06-21 17:50:36.090321
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.testing import assert_codemod

# Generated at 2022-06-21 17:50:45.795181
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    gen_returns = ReturnFromGeneratorTransformer()._find_generator_returns
    assert len(gen_returns(ast.parse('def fn(x): return x').body[0])) == 1
    assert len(gen_returns(ast.parse('async def fn(x): return x').body[0])) == 1
    assert len(gen_returns(ast.parse('def fn(x): yield x').body[0])) == 0
    assert len(gen_returns(ast.parse('async def fn(x): yield x').body[0])) == 0
    assert len(gen_returns(ast.parse('def fn(x): yield x; return x').body[0])) == 1

# Generated at 2022-06-21 17:51:26.971247
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast

    import astor


# Generated at 2022-06-21 17:51:31.349512
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    f = ReturnFromGeneratorTransformer()
    expected = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    node = ast.parse('def fn():\n    yield 1\n    return 5', mode='exec')
    assert f.visit(node) == expected

# Generated at 2022-06-21 17:51:41.122423
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformerTest
    from .return_from_generator import ReturnFromGeneratorTransformer

    class Test(BaseNodeTransformerTest):
        target = ReturnFromGeneratorTransformer

        def test_regular_function(self):
            program = """
            def fn():
                pass
            """

            expected = """
            def fn():
                pass
            """

            self.compare(program, expected)

        def test_generator_function(self):
            program = """
            def fn():
                yield 1
            """

            expected = """
            def fn():
                yield 1
            """

            self.compare(program, expected)

        def test_generator_with_return(self):
            program = """
            def fn():
                yield 1
                return 5
            """


# Generated at 2022-06-21 17:51:45.242337
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with ReturnFromGeneratorTransformer('') as t:
        assert len(t._find_generator_returns(ast.parse('''\
            def gen():
                yield 1
                return 2
        ''').body[0])) == 1



# Generated at 2022-06-21 17:51:47.516374
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse

# Generated at 2022-06-21 17:51:54.857746
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from .test_BaseNodeTransformer import BaseNodeTransformerSchema
    from ..utils import Code
    from .test_ReturnFromGeneratorTransformer import ReturnFromGeneratorTransformerSchema

    class ReturnFromGeneratorTransformer(
            BaseNodeTransformer,
            metaclass=ReturnFromGeneratorTransformerSchema,
            init_schema=BaseNodeTransformerSchema
    ):
        def _find_generator_returns(
                self, node: ast3.FunctionDef
        ) -> List[Tuple[ast3.stmt, ast3.Return]]:
            return []

        def _replace_return(self, parent: Any, return_: ast3.Return) -> None:
            pass


# Generated at 2022-06-21 17:51:59.332667
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    t = ReturnFromGeneratorTransformer()
    t.visit(ast.parse(fn.__code__))

# Generated at 2022-06-21 17:52:08.176116
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def transpile(func):
        node = ast.parse(inspect.getsource(func))
        ReturnFromGeneratorTransformer().visit(node)
        return node

    def fn():
        yield 1
        return 5

    node = transpile(fn)
    assert node.body[0].body[1].value.func.id == 'StopIteration'

    def fn():
        return 5  # Should be ignored

    node = transpile(fn)
    assert not node.body[0].body[1].value.func.id == 'StopIteration'

    def fn():
        yield 1
        return
        return 5  # Should be ignored

    node = transpile(fn)
    assert not node.body[0].body[1].value.func.id == 'StopIteration'

# Generated at 2022-06-21 17:52:09.314276
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    print(x)

# Generated at 2022-06-21 17:52:11.456993
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    object1 = ReturnFromGeneratorTransformer()
    object1.visit_FunctionDef(2)



# Generated at 2022-06-21 17:53:36.986459
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''
        def fn():
            yield 1
            return 2
            ''')
    node = ReturnFromGeneratorTransformer().visit(node)
    assert node.body[0].body[1].func == ast.Name('StopIteration', ast.Load())
    assert node.body[0].body[1].keywords[0].value == ast.Num(2)
    assert isinstance(node.body[0].body[2], ast.Raise)


# Generated at 2022-06-21 17:53:41.792939
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
        def generator():
            a = yield 1
            return 2
        """)
    expected = ast.parse("""
    def generator():
        a = yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """)
    transformer = ReturnFromGeneratorTransformer()
    actual = transformer.visit(node)
    assert ast.dump(expected, include_attributes=False) == ast.dump(actual, include_attributes=False)



# Generated at 2022-06-21 17:53:45.600390
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # test 1
    node = ast.parse("""
    def fn():
        yield 1
        return 5
    """)

    transformer = ReturnFromGeneratorTransformer(node)

    expected = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    assert transformer._tree_changed == True
    assert list(map(ast.dump, expected.body)) ==  list(map(ast.dump, transformer._output.body))

# Generated at 2022-06-21 17:53:51.035085
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(new_tree) == expected



# Generated at 2022-06-21 17:53:53.950742
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert x is not None


# Generated at 2022-06-21 17:53:56.240673
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    try:
        ReturnFromGeneratorTransformer()
    except:
        assert False


# Generated at 2022-06-21 17:53:57.046323
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:54:03.772100
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import compile_snippet
    from .. import main
    from ..compiler import CompilationResult
    from ..utils import get_body_string
    from ..utils.snippet import snippet_to_string

    class FakeCompilationResult(CompilationResult):
        def __init__(self, body: str) -> None:
            self.body = body

    # Testing __init__
    assert ReturnFromGeneratorTransformer().visit_alias(None) is None
    assert ReturnFromGeneratorTransformer().visit_arg(None) is None

    # Testing visit_FunctionDef
    def fn():
        yield 1
        return 5

    def fn_expected():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    result = FakeCompilationResult(get_body_string(fn))

# Generated at 2022-06-21 17:54:08.834587
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    gen_node = ast.parse("""
    def fn():
        yield 1
        return 5""")
    gen_node_passed = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc""")
    node_transformed = ReturnFromGeneratorTransformer().visit(gen_node)
    assert ast.dump(node_transformed, include_attributes=True) == ast.dump(gen_node_passed, include_attributes=True)


# Generated at 2022-06-21 17:54:11.234177
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    '''
    Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    '''