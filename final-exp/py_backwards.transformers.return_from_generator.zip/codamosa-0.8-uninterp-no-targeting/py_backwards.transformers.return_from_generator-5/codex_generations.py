

# Generated at 2022-06-21 17:46:09.777096
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import parse
    from .context import Context
    import os


# Generated at 2022-06-21 17:46:17.562695
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # type: () -> None
    source = """
        def fn():
            yield 1
            a = 3
            return 5
    """
    expected = """
        def fn():
            yield 1
            a = 3
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = ast.parse(textwrap.dedent(source))
    node = ReturnFromGeneratorTransformer().visit(node)  # type: ignore
    actual = textwrap.dedent(source)
    assert ast.dump(node) == ast.dump(ast.parse(textwrap.dedent(expected)))

# Generated at 2022-06-21 17:46:19.117126
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:24.323535
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer"""
    return_from_generator_transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:46:26.518036
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from astunparse import unparse as unparse_original

# Generated at 2022-06-21 17:46:30.008642
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from ..utils.test_utils import assert_equal_source
    from typed_astunparse import unparse


# Generated at 2022-06-21 17:46:31.038512
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:33.122538
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of ReturnFromGeneratorTransformer"""
    x = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:46:41.158023
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test for method visit_FunctionDef of class ReturnFromGeneratorTransformer"""
    _test_input = """\
    def fn():
        yield 1
        return 5
    """
    _test_output = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    _expected = ast.parse(_test_output)  # type: ignore
    _transformer = ReturnFromGeneratorTransformer()
    _tree = ast.parse(_test_input)  # type: ignore
    _transformer.visit(_tree)
    assert ast.dump(_tree) == ast.dump(_expected)


# Generated at 2022-06-21 17:46:42.573494
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:48.490222
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:50.324221
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:53.090383
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Check if it is possible to initialize class
    ReturnFromGeneratorTransformer."""
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:54.927825
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import ast_transformer
    transformer = ast_transformer.ast_transformer()
    transformer.register_transformer(ReturnFromGeneratorTransformer)
    return transformer


# Generated at 2022-06-21 17:46:55.816237
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None


# Generated at 2022-06-21 17:47:02.882013
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    def fn():
        yield 1
        return 5

    def diff_fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    result = ReturnFromGeneratorTransformer().visit(ast.parse(inspect.getsource(fn)))

    # Assert that tree has changed.
    assert ReturnFromGeneratorTransformer._tree_changed

    assert astor.to_source(result) == astor.to_source(ast.parse(inspect.getsource(diff_fn)))

# Generated at 2022-06-21 17:47:08.250037
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    transformer._find_generator_returns(ast.parse('def foo():\n    yield 1\n    return 5')[0])
    assert len(transformer.generator_returns) == 1
    assert transformer.generator_returns[0][0] == ast.parse('def foo():\n    yield 1\n    return 5')[0]
    assert transformer.generator_returns[0][1] == ast.parse('return 5')[0]

# Generated at 2022-06-21 17:47:10.601771
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).__class__.__name__ == 'ReturnFromGeneratorTransformer'


# Generated at 2022-06-21 17:47:22.369653
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def fn():\n yield 1\n return 5\n')
    node.body[0].body[1] = ast.Return()

    new_node = ReturnFromGeneratorTransformer().visit(node)
    node_str = ast.dump(new_node)

# Generated at 2022-06-21 17:47:33.373691
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Node(BaseNodeTransformer):
        target = (3, 2)

        def visit_Return(self, node):  # type: (ast.Return) -> ast.Return
            node.value = ast.Name(id=node.value.s, ctx=ast.Load())
            return node

    tree_ = ast.parse(
        """def fn():
            yield 1
            yield 2
            return 5
        def fn_without_yield():
            return 5

        def fn_with_None_return():
            yield 1
            yield 2
            return None

        def fn_with_many_return():
            if True:
                return 5
            return 10
        """)

    tree_.body[0].body.insert(0, ast.Yield(value=ast.Num(n=1)))

# Generated at 2022-06-21 17:47:49.820724
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..tests.test_transpiler import assert_transpiles_to, generate_ast
    def fn():
        yield 1
        return True
    assert_transpiles_to(ReturnFromGeneratorTransformer, fn, """\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = True
            raise exc
        """)

    def fn():
        return 1
        yield
    assert_transpiles_to(ReturnFromGeneratorTransformer, fn, fn)

    def fn(name):
        if name:
            yield
        return 1
    assert_transpiles_to(ReturnFromGeneratorTransformer, fn, """\
        def fn(name):
            if name:
                yield
            exc = StopIteration()
            exc.value = 1
            raise exc
        """)

# Generated at 2022-06-21 17:47:55.671893
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def foo(a):
        if a:
            return 1
        yield 10
        return 5
        """
    tree = ast.parse(source)
    node = tree.body[0]

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    expected = """
    def foo(a):
        if a:
            return 1
        yield 10
        exc = StopIteration()
        exc.value = 5
        raise exc
        """
    assert astor.to_source(tree) == expected

# Generated at 2022-06-21 17:47:57.984710
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.tester import run_transformer_test
    transformer = ReturnFromGeneratorTransformer()
    run_transformer_test(transformer, 3, 2)

# Generated at 2022-06-21 17:48:04.149643
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from .utils import roundtrip, assert_equal

    # Test normal function
    tree = ast.parse('def f(): return 1').body[0]
    node = ReturnFromGeneratorTransformer().visit(tree)
    assert_equal(node, tree)

    # Test generator
    tree = ast.parse('def f(): yield 1; return 2').body[0]
    node = ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-21 17:48:15.236463
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert_equal(ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse(
        """
    def fn():
        yield 1
        return 5
    """
    )), [((ast.FunctionDef('fn', [], [
        ast.Expr(ast.Yield(ast.Num(1))),
        ast.Return(ast.Num(5))
    ], [], [])), ast.Return(ast.Num(5)))])

    assert_equal(ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse(
        """
    def fn():
        yield 1
        raise ValueError()
    """
    )), [])


# Generated at 2022-06-21 17:48:17.018029
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:48:24.095783
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn = ast.parse("""
        def foo():
            yield 1
            return 5
        """).body[0]

    # assert fn is ast.FunctionDef
    assert hasattr(fn, 'body')

    fn = ReturnFromGeneratorTransformer().visit(fn)

    # assert fn is ast.FunctionDef
    assert hasattr(fn, 'body')

    # assert fn.body is List[ast.stmt]
    assert isinstance(fn.body, list)

    # assert fn.body[1] is ast.Yield
    assert isinstance(fn.body[1], ast.Yield)

    # assert fn.body[2] is ast.stmt
    assert isinstance(fn.body[2], ast.stmt)

    # assert fn.body[2].body is List[ast.expr]

# Generated at 2022-06-21 17:48:26.358030
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test constructor of class ReturnFromGeneratorTransformer."""

# Generated at 2022-06-21 17:48:32.778147
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer"""
    import typed_ast.ast3 as ast

    node = ast.copy_location(
        ast.FunctionDef(
            name='foo',
            args=ast.arguments(
                args=[],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]
            ),
            body=[
                ast.Expr(ast.Yield(value=ast.Num(1))),
                ast.Return(value=ast.Num(5))
            ],
            decorator_list=[],
            returns=None
        ),
        lineno=1,
        col_offset=1
    )
    

# Generated at 2022-06-21 17:48:38.863103
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    code = """
        def fn_generator():
            yield 1
            return 2
    """
    tree = ast.parse(code)
    transformer.visit(tree)
    generator_returns = transformer._find_generator_returns(tree.body[0])

    assert generator_returns

# Generated at 2022-06-21 17:48:55.699774
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()
    assert True

# Generated at 2022-06-21 17:49:05.241779
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''
        def fn():
            yield 1
            return 2
            ''')
    ast.fix_missing_locations(node)

    expected = ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
            ''')
    ast.fix_missing_locations(expected)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    #assert transformer.tree_changed == True

    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-21 17:49:13.676782
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap
    from ..utils.string_sources import wrap_tree_as_python

    source = textwrap.dedent("""
        def fn():
            yield 1
            return 5
    """)
    expected = textwrap.dedent("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5  # type: ignore
            raise exc
    """)

    tree = ast.parse(source)
    ReturnFromGeneratorTransformer.run_on_tree(tree)

    assert wrap_tree_as_python(tree) == expected


# Generated at 2022-06-21 17:49:20.218291
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class FunctionDefReturnFromGeneratorTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            generator_returns = self._find_generator_returns(node)

            if generator_returns:
                self._tree_changed = True

            for parent, return_ in generator_returns:
                self._replace_return(parent, return_)

            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-21 17:49:28.059206
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.testing import assert_code
    from .base import parse_to_ast

    def test(code, expected_code):
        node = parse_to_ast(code)
        node = ReturnFromGeneratorTransformer().visit(node)
        output = ast.fix_missing_locations(node)
        test_code = compile(output, '<string>', 'exec')
        exec_global, exec_local = globals().copy(), locals().copy()
        exec(test_code, exec_global, exec_local)
        assert exec_local['__test_fn']() == 5

        mod = ast.Module(body=[node])
        assert_code(mod, expected_code)


# Generated at 2022-06-21 17:49:30.188115
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:49:31.268725
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-21 17:49:42.466439
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .test_helpers import get_ast
    from .test_target import compile_to_verify_target_python
    from .test_helpers import assert_equal
    from .test_helpers import compile_to_python
    from .test_helpers import wrap_in_module

    source = """
    def fn1():
        yield 10
        return 15
    def fn2():
        yield 12
        return 17
    """
    expected = """
    def fn1():
        yield 10
        exc = StopIteration()
        exc.value = 15
        raise exc

    def fn2():
        yield 12
        exc = StopIteration()
        exc.value = 17
        raise exc
    """

# Generated at 2022-06-21 17:49:51.060776
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_code(code):
        node = ast.parse(code)
        ReturnFromGeneratorTransformer().visit(node)

        return ReturnFromGeneratorTransformer._tree_changed, ast.unparse(node)

    # Test 1
    code = """
    def fn():
        yield 1
    """
    tree_changed, code = test_code(code)

    assert not tree_changed
    assert code == """
    def fn():
        yield 1
    """

    # Test 2
    code = """
    def fn():
        yield 1
        return 1
    """
    tree_changed, code = test_code(code)

    assert tree_changed
    assert code == """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 1
        raise exc
    """

   

# Generated at 2022-06-21 17:49:53.212859
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:50:46.447056
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MockNode(ast.AST):
        body = []

        def __init__(self, body):
            self.body = body

    class MockBody(ast.AST):
        _fields = ('value',)

        def __init__(self, value):
            self.value = value

    class MockYield(ast.AST):
        _fields = ('value',)

        def __init__(self, value):
            self.value = value

    class MockReturn(ast.AST):
        _fields = ('value',)

        def __init__(self, value):
            self.value = value

    class MockFunctionDef(ast.AST):
        _fields = ('body',)

        def __init__(self, body):
            self.body = body

    class MockValue(ast.AST):
        pass


# Generated at 2022-06-21 17:50:49.849895
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = '''
        def func():
            for i in range(3):
                yield i
            return 5
    '''
    return_from_gen = ReturnFromGeneratorTransformer()
    for node in ast.parse(code).body:
        return_from_gen.visit(node)
        # Unparse
        print(ast.unparse(node))

# Generated at 2022-06-21 17:50:52.794958
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def function_fn():
        yield 1
        return 5
    expected_fn = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert ReturnFromGeneratorTransformer.run_single(function_fn).strip() == expected_fn.strip()

# Generated at 2022-06-21 17:50:55.009486
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:51:04.974224
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test compilation of return in generators like:
    #     def fn():
    #         yield 1
    #         return 5
    # To:
    #     def fn():
    #         yield 1
    #         exc = StopIteration()
    #         exc.value = 5
    #         raise exc

    def check(s):
        module = ast.parse(s)
        ReturnFromGeneratorTransformer().visit(module)
        print(module.body[0].body)
        exec(compile(module, filename="<ast>", mode='exec'), namespace)
        return namespace['fn']

    namespace = {}
    fn = check('''
    def fn():
        yield 1
        return 5
    ''')
    assert next(fn()) == 1

# Generated at 2022-06-21 17:51:13.975590
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """
    Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    """
    code = "def fn():\n" + \
           "    yield 1\n" + \
           "    return 5\n" + \
           "def fn2():\n" + \
           "    return 5\n" + \
           "\n" + \
           "def fn3():\n" + \
           "    yield 1\n" + \
           "    for i in range(10):\n" + \
           "        return 5\n"


# Generated at 2022-06-21 17:51:15.584671
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).target == (3, 2)

# Generated at 2022-06-21 17:51:17.652641
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:51:25.252124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    def fn1():
        yield 1
        return 5

    fn1_node = ast.parse(fn1.__code__).body[0]
    fn1_node = transformer.visit(fn1_node)
    assert compile(ast.fix_missing_locations(fn1_node), __file__, 'exec').co_flags & 0x20

    fn2_node = ast.parse(fn1.__code__).body[0]
    fn2_node = transformer.visit(fn2_node)
    assert not compile(ast.fix_missing_locations(fn2_node), __file__, 'exec').co_flags & 0x20

    def fn3():
        return 1


# Generated at 2022-06-21 17:51:30.574644
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class DummyTransformer:
        _tree_changed = False

    cls = ReturnFromGeneratorTransformer(DummyTransformer())
    code = "def foo():\n\treturn 5"
    tree = ast.parse(code)
    assert not DummyTransformer._tree_changed
    cls.visit(tree)
    assert not DummyTransformer._tree_changed


# Generated at 2022-06-21 17:52:42.503234
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert_equal('def foo():\n    yield 5\n    exc = StopIteration()\n    exc.value = 5\n    raise exc',
                 transform_snippet(
                     'def foo():\n    yield 5\n    return 5',
                     ReturnFromGeneratorTransformer))
    assert_equal('def foo():\n    yield 5\n    yield 6\n    exc = StopIteration()\n    exc.value = 7\n    raise exc',
                 transform_snippet(
                     'def foo():\n    yield 5\n    yield 6\n    return 7',
                     ReturnFromGeneratorTransformer))

# Generated at 2022-06-21 17:52:43.461662
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:52:44.591099
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:52:53.103539
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test that the visit_FunctionDef method of the ReturnFromGeneratorTransformer class"""
    # is able to replace a return statement in a generator
    from typed_ast import ast3
    from .base import NodeTransformer
    from .return_from_generator import ReturnFromGeneratorTransformer

    ast_tree = ast3.parse("""
    def foo():
        yield 1
        return 5
    """)

    transformer = NodeTransformer()
    transformer.register_transformer(ReturnFromGeneratorTransformer)

    transformer.visit(ast_tree)


# Generated at 2022-06-21 17:52:54.837852
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import transform_and_compare

    @transform_and_compare
    def fn():
        yield 1
        yield 2
        return 5 + 5

    @transform_and_compare
    def fn():
        return 5 + 5

# Generated at 2022-06-21 17:52:59.330279
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test(source, expected_source):
        ast_tree = ast.parse(source)
        result = str(ReturnFromGeneratorTransformer().visit(ast_tree))
        assert result == expected_source, result


# Generated at 2022-06-21 17:53:01.355694
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:53:02.893479
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert issubclass(ReturnFromGeneratorTransformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:53:06.064740
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test method visit_FunctionDef of ReturnFromGeneratorTransformer.
    
    Test with every case of return in generator.
    """
    from ..utils.testutils import assert_ast, assert_source


# Generated at 2022-06-21 17:53:07.017191
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer


# Generated at 2022-06-21 17:55:40.969850
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import transform_and_compile_from_string
    from ..utils.testing import dedent

    code = dedent("""
        def foo():
            yield 1
            return 2
    """)

    assert transform_and_compile_from_string(code, ReturnFromGeneratorTransformer) == dedent("""
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """)

    assert transform_and_compile_from_string(code, ReturnFromGeneratorTransformer,
                                             import_from_future=True) == dedent("""
        from __future__ import generators
        def foo():
            yield 1
            raise StopIteration(2)
    """)



# Generated at 2022-06-21 17:55:46.493672
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transform = ReturnFromGeneratorTransformer

        def test_basic_usage(self):
            input = '''
                def fn():
                    x = 3
                    yield x
                    return x
                '''
            expected_output = '''
                def fn():
                    x = 3
                    yield x
                    exc = StopIteration()
                    exc.value = x
                    raise exc
                '''
            self.assertTransformedAST(input, expected_output)
        def test_multiple_yields(self):
            input = '''
                def fn():
                    yield 1
                    yield 2
                    return 3
                '''

# Generated at 2022-06-21 17:55:53.879205
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import compile
    import random
    random.seed(0)

    def get_return_statements(fn):
        body = compile(fn, to_str=False).body[0].body  # type: ignore
        for i, statement in enumerate(body):
            if isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Call):
                exc_type, exc_value, _ = statement.value.args
                assert exc_type.id == 'StopIteration'
                return_value = exc_value.value
                return_index = i + 1  # index of return statement
                break
        return [body[i] for i in range(return_index, len(body))]


# Generated at 2022-06-21 17:56:02.715481
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .helpers import get_ast, compare_node
    from .test_FunctionDefTransformer import test_FunctionDefTransformer_function_def

    transformer = ReturnFromGeneratorTransformer()
    generator_def = get_ast("""
        def generator():
            yield 1
            return 5
    """)
    new_generator_def = get_ast("""
        def generator():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    compare_node(test_FunctionDefTransformer_function_def, transformer, generator_def, new_generator_def)