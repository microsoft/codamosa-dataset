

# Generated at 2022-06-21 17:46:16.705539
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.snippet import snippet
    from ..utils.ast_source import ast_source

    @snippet
    def test():
        def foo():
            yield 1
            return 1

        foo()
        return 1

    transformed = ReturnFromGeneratorTransformer().run(test)
    assert ast_source(transformed) == """
    def test():
        def foo():
            yield 1
            _0 = StopIteration()
            _0.value = 1
            raise _0
        foo()
        return 1
    """

# Generated at 2022-06-21 17:46:24.705982
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """
    Test that `ReturnFromGeneratorTransformer` correctly replaces return statement in generators.
    """

    return_from_generator = """
            def fn():
                yield 1
                return 5
        """

    return_from_generator_modified = """
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        """

    assert ReturnFromGeneratorTransformer().transform(return_from_generator).strip() == return_from_generator_modified.strip()


# Generated at 2022-06-21 17:46:27.296810
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert isinstance(x, BaseNodeTransformer)

# Generated at 2022-06-21 17:46:33.278040
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse("""def fn():\n    yield 1\n    return 5""")
    ReturnFromGeneratorTransformer().visit(tree)
    expected = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
    assert ast.dump(tree, include_attributes=False) == expected

# Generated at 2022-06-21 17:46:38.603951
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    src = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(src)
    ReturnFromGeneratorTransformer().visit(tree)

    assert ast.dump(tree) == expected



# Generated at 2022-06-21 17:46:39.967951
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-21 17:46:43.516827
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing_utils import assert_equal_with_printing
    from ..testing_utils import make_call_node


# Generated at 2022-06-21 17:46:47.914942
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from python_transpile_checker.utils.source_code import to_source
    from ..utils.checker import valid_source
    from .checker import valid_function

    code = """
    def fn():
        yield 1
        return 5
    """

    valid_function(ReturnFromGeneratorTransformer, code, 'fn')

# Generated at 2022-06-21 17:46:52.199343
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("def fn():\n    yield 1\n    return 5")
    node = tree.body[0]

    transformer = ReturnFromGeneratorTransformer(tree)
    transformer.visit(node)

    assert ast.dump(tree) == "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"

# Generated at 2022-06-21 17:47:02.578399
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTestCase
    from typed_ast import ast3 as ast
    
    class ReturnFromGeneratorTransformerTestCase(BaseNodeTransformerTestCase):
        transformer = ReturnFromGeneratorTransformer
    
        # input_code = "def fn(x):\n\tyield x\n\treturn x\n"
        # expected_code = "def fn(x):\n\tyield x\n\texc = StopIteration()\n\texc.value = x\n\traise exc\n"
        # tree = ast.parse(input_code)
        # tree = ReturnFromGeneratorTransformer().visit(tree)
        # self.assertEqual(compile(tree, "<test>", "exec"), compile(expected_code, "<test>", "exec"))
        # self.

# Generated at 2022-06-21 17:47:11.910691
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def f(x):
        if x == 1:
            yield 1
        else:
            yield 2
        return 3

    # can't work with lambda since it has no bodies
    node = ast.parse(f.__doc__)
    expected = ast.parse("""
    def f(x):
        if x == 1:
            yield 1
        else:
            yield 2
        exc = StopIteration()
        exc.value = 3
        raise exc
    """)
    ReturnFromGeneratorTransformer().visit(node)  # type: ignore
    assert ast.dump(expected) == ast.dump(node)



# Generated at 2022-06-21 17:47:18.677053
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse(textwrap.dedent("""
    def fn():
        yield 1
        return 5
        """))
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert transformer.get_source(tree) == textwrap.dedent("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
        """)

# Generated at 2022-06-21 17:47:29.995132
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("def fn(): yield 1; return 5")
    first_body = node.body[0].body
    assert isinstance(first_body[0], ast.Expr)
    assert isinstance(first_body[1], ast.Return)
    t = ReturnFromGeneratorTransformer()
    tree = t.visit(node)
    body = tree.body[0].body
    assert len(body) == 9
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[3], ast.Load)
    assert isinstance(body[4], ast.Eq)
    assert isinstance(body[5], ast.Call)
    assert isinstance(body[6], ast.Attribute)
    assert isinstance(body[7], ast.Raise)

# Generated at 2022-06-21 17:47:41.376860
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    for func in [
            'def fn(): yield 1; return 5',
            'def fn():\n    yield 1\n    return 5',
            'def fn(): yield 1; x = 5; return x',
            'def fn(): yield 1; return x\n'
            'def fn(): pass\n'
            'def fn(): yield 1; return x'
            ]:
        ast_func = ast.parse(func).body[0]
        ReturnFromGeneratorTransformer().visit(ast_func)
        result = ast.dump(ast_func)
        print(result)

        if 'pass' in func:
            body = result.split('\n')
            result = '\n'.join(body[:2] + body[3:])


# Generated at 2022-06-21 17:47:49.379469
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast_node = ast.parse("""
                        def fn():
                            yield 1
                            return 5
                        """)

    fn = ast_node.body[0]

    generator_returns = ReturnFromGeneratorTransformer()._find_generator_returns(fn)
    assert(len(generator_returns) == 1)

    parent, return_ = generator_returns[0]
    assert(isinstance(parent, ast.FunctionDef))
    assert(isinstance(return_, ast.Return))

    ReturnFromGeneratorTransformer()._replace_return(parent, return_)
    assert(len(return_from_generator.get_body()) + 1 == len(parent.body))
    assert(isinstance(parent.body[-1], ast.Expr))

# Generated at 2022-06-21 17:47:51.895114
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.__name__ == "ReturnFromGeneratorTransformer"


# Generated at 2022-06-21 17:47:56.289219
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_helpers import round_trip, round_trip_with_transformer
    from .test_helpers import parse as parse_python2
    from typed_astunparse import unparse, dump as dump_python2

    def transform(node, context):
        return ReturnFromGenerato

# Generated at 2022-06-21 17:47:57.139131
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None


# Generated at 2022-06-21 17:48:02.223427
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils import generator_return_to_stop
    from astor import to_source
    from ast import Name, FunctionDef, Return, Yield
    node = FunctionDef(
        name='fn',
        args=ast.arguments(args=[],  # type: ignore
                           vararg=None,
                           kwonlyargs=[],
                           kw_defaults=[],
                           kwarg=None,
                           defaults=[]),
        body=[Yield(value=Name(id='a', ctx=ast.Load())),
              Return(value=Name(id='b', ctx=ast.Load()))],
        decorator_list=[],
        returns=None)

# Generated at 2022-06-21 17:48:07.417271
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    fn = ast.parse("def fn():\n    yield 1\n    return 5").body[0]
    transformer.visit(fn)
    assert "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc".strip() == ast.dump(fn).strip()

# Generated at 2022-06-21 17:48:12.616279
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:48:14.949252
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.target[0] == 3
    assert ReturnFromGeneratorTransformer.target[1] == 2


# Generated at 2022-06-21 17:48:18.632386
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        yield 1
        return 5
    """

    assert ReturnFromGeneratorTransformer().visit(code) == """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

# Generated at 2022-06-21 17:48:24.345871
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input = """
    def foo(a, b, c, d):
        yield 1
        return a
    """
    expectations = """
    def foo(a, b, c, d):
        yield 1
        exc = StopIteration()
        exc.value = a
        raise exc
    """
    ast_tree = ast.parse(input)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(ast_tree)

    assert ast.unparse(result) == expectations



# Generated at 2022-06-21 17:48:34.606247
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from ..utils.testutils import assert_source

    test_tree = ast.parse(dedent('''\
        def fn():
            def gen_fn():
                yield 1
                return 5

            def non_gen_fn():
                return 6

            return 1
    '''))

    expected_tree = ast.parse(dedent('''\
        def fn():
            def gen_fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc

            def non_gen_fn():
                return 6

            return 1
    '''))

    # test
    tree = ReturnFromGeneratorTransformer().visit(test_tree)
    assert_source(tree, expected_tree)



# Generated at 2022-06-21 17:48:37.541754
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Unit test for constructor of class ReturnFromGeneratorTransformer"""
    assert ReturnFromGeneratorTransformer(None).target == (3, 2)


# Generated at 2022-06-21 17:48:38.521238
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()



# Generated at 2022-06-21 17:48:47.824215
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from tagged_ast import ast as tagged_ast
    line = "def fn():\n  yield 1\n  return 5\n"
    tree = tagged_ast.parse(line, "", "eval")
    class DummyNodeTransformer(ast.NodeTransformer):
        def visit_Str(self, node):
            return node
    DummyNodeTransformer().visit(tree)
    tree = ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-21 17:48:55.794727
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..context import Context
    from ..main import compile
    from ..visitors.debug import print_tree
    from ..visitors.tree_visitors import visit_tree
    from typing import List
    ctx = Context()
    tree = compile("""
        def fn():
            yield 1
            return 5
    """, ctx=ctx)
    print_tree(tree)

    transformer = ReturnFromGeneratorTransformer()
    visit_tree(transformer, tree)
    print(ctx.entry_point)
    assert ctx.entry_point == """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

# Generated at 2022-06-21 17:48:56.377546
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-21 17:49:08.060699
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:49:09.597573
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:49:15.384180
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def for_test(a):
        def fn():
            yield a
            return 1
        return fn()

    expected = for_test.get_source().replace('return 1', return_from_generator.get_body(1))

    source = for_test.get_source()

    module_node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(module_node)

    actual = compile(module_node, '<test>', 'exec').co_consts[0]

    assert actual == expected

# Generated at 2022-06-21 17:49:16.142738
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:17.220571
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:49:18.258715
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:25.981917
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import astor

    class TestReturnFromGeneratorTransformer_visit_FunctionDef(unittest.TestCase):
        def assertTransformedAST(self, before, after):
            node = ast.parse(before)
            expected = ast.parse(after)

            transformer = ReturnFromGeneratorTransformer()
            new_node = transformer.visit(node) # type: ignore

            self.assertTrue(transformer.tree_changed())
            self.assertEqual(astor.to_source(new_node).strip(), astor.to_source(expected).strip())

        def test_return_in_generator(self):
            before = """
            def fn():
                yield
                return 1
            """

# Generated at 2022-06-21 17:49:33.666039
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    input_code = """
    def fn():
        yield 1
        return 5
    """

    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    module = ast.parse(input_code)
    transformer = ReturnFromGeneratorTransformer()
    new_module = transformer.visit(module)
    assert transformer.tree_changed
    assert codegen.to_source(new_module) == expected_code


# Generated at 2022-06-21 17:49:35.079569
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:49:46.372987
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:12.346456
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    class Test:
        """A test suite."""
        def gen():
            """A test generator."""
            yield 1
            return 5
    # Build AST
    node = ast.parse(inspect.getsource(Test.gen))  # type: ignore
    node = node.body[0]
    # Transform
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)
    # Test
    assert new_node is not None

# Generated at 2022-06-21 17:50:23.394171
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def check(input_code, expected_code):
        module_node = ast.parse(input_code)
        transformer = ReturnFromGeneratorTransformer()
        transformed = transformer.visit(module_node)

        assert transformer.tree_changed is True
        assert ast.dump(transformed, annotate_fields=False) == expected_code

    check(
        input_code='''
            def fn():
                yield 1
                return 5
        ''',
        expected_code='''
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        '''
    )


# Generated at 2022-06-21 17:50:30.242578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap

    source = textwrap.dedent('''\
    def fn():
        yield 1
        return 5
    ''')

    expected = textwrap.dedent('''\
    def fn():
        yield 1
        exc = BaseException()
        exc.value = 5
        raise exc
    ''')

    _, expected_node = ast.parse(expected)
    _, node = ast.parse(source)
    fixed_node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(fixed_node) == ast.dump(expected_node)

# Generated at 2022-06-21 17:50:35.168278
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Transformer(ReturnFromGeneratorTransformer):
        def __init__(self, code):
            self._tree_changed = False
            self._code = code

        def generic_visit(self, node):
            return ast.NodeTransformer.generic_visit(self, node)
    t = Transformer("""def fn():
        yield 1
        return 5
    """)
    ast_node = ast.parse(t._code)
    node = t.visit(ast_node)

# Generated at 2022-06-21 17:50:37.704811
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:38.834808
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:50:39.756875
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:47.750046
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ft = ReturnFromGeneratorTransformer()
    ft._tree_changed = False

    fn = ast.FunctionDef(
        ast.arguments(
            [], ast.arg(arg='a', annotation=None), [], [], None, []),
        body=[
            ast.Expr(ast.Yield()),
            ast.Return(value=ast.Num(5))
        ])

    # creating the expected output

# Generated at 2022-06-21 17:50:55.631390
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from unittest import TestCase
    from .test_utils import compile_to_untyped_ast

    class Test(TestCase):
        def test_basic(self):
            code = '''
                def fn():
                    x = 5
                    yield x
                    return x
                '''
            tree = compile_to_untyped_ast(code)
            expected_codes = [
                'def fn():',
                '    x = 5',
                '    yield x',
                '    exc = StopIteration()',
                '    exc.value = x',
                '    raise exc'
            ]
            tree = ReturnFromGeneratorTransformer().visit(tree)
            result = tree.body[0].body
            for code, node in zip(expected_codes, result):
                assert code == node.to_source()

# Generated at 2022-06-21 17:50:59.258350
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class EmptyTransformer(ReturnFromGeneratorTransformer):
        def _visit(self, node):
            pass
    node = ast.parse("""
    def foo():
        yield 1
        return 2
        yield 3
    """
    ).body[0]
    x = EmptyTransformer()
    x.visit(node)
    assert x._find_generator_returns(node) == [(node, node.body[1])]
    assert ast.dump(node) == """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
        yield 3
    """

# Generated at 2022-06-21 17:51:42.416192
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Arrange
    t = ReturnFromGeneratorTransformer()

    # Act
    t._find_generator_returns()

    # Assert
    assert t._find_generator_returns() == []


# Generated at 2022-06-21 17:51:51.709978
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Node does not contain FunctionDef
    node = ast.NameConstant(value=None)
    assert ReturnFromGeneratorTransformer.check_node(node) == False

    function_def = ast.FunctionDef(name='fn', body=[], args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[]))
    # Node does not contain yield
    node = ast.Module(body=[function_def])
    assert ReturnFromGeneratorTransformer.check_node(node) == False
    # Node does contain yield
    function_def.body.append(ast.Yield(value=None))
    node = ast.Module(body=[function_def])
    assert ReturnFromGeneratorTransformer.check_node(node) == True



# Generated at 2022-06-21 17:52:00.011571
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    func_def = ast.parse("""
        def fn():
            yield 1
            return 5
    """).body[0]  # type: ast3.FunctionDef

    transformer = ReturnFromGeneratorTransformer()
    transformed = transformer.visit(func_def)


# Generated at 2022-06-21 17:52:08.597937
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from .base import BaseCompiler
    from .return_last_value import ReturnLastValueTransformer

    class TestGeneratorReturnTransformer(BaseCompiler):
        def __init__(self):
            self.transformers = [
                ReturnLastValueTransformer,
                ReturnFromGeneratorTransformer,
            ]

    class ReturnVisitor(NodeVisitor):
        def __init__(self):
            self.returns = []

        def visit_Return(self, node):  # type: ignore
            self.returns.append(node)

            super().visit(node)

    visitor = ReturnVisitor()

# Generated at 2022-06-21 17:52:13.735064
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import get_compiled_func

    def f(x):
        if x>1:
            return 3
        yield x
        if x>0:
            return 4
    f_compiled = get_compiled_func(f, ReturnFromGeneratorTransformer)
    assert next(f_compiled(0)) == 0
    assert next(f_compiled(1)) is StopIteration
    assert f_compiled(2) == 3



# Generated at 2022-06-21 17:52:20.054195
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import AssertAstFormatEqual
    from typed_ast import ast3 as ast

    code = 'def fn():\n    yield 1\n    return 5'
    expect = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'

    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    AssertAstFormatEqual(tree, expect)



# Generated at 2022-06-21 17:52:21.318148
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer(), BaseNodeTransformer)



# Generated at 2022-06-21 17:52:22.388301
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert hasattr(ReturnFromGeneratorTransformer, '__init__')

# Generated at 2022-06-21 17:52:24.231526
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(None)
    assert transformer.target == (3, 2)
    assert transformer._tree_changed == False


# Generated at 2022-06-21 17:52:25.390959
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:53:50.142414
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def generator_function(x):
        if x == 1:
            return x
        yield x
        if x == 2:
            return x
        yield x + 1
        if x == 3:
            return x
        yield x + 2
        return 'failed'


# Generated at 2022-06-21 17:53:55.464235
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .test_BaseNodeTransformer import BaseNodeTransformer_visit_FunctionDef
    from .test_BaseNodeTransformer import transform, run_test

    snip = snippet('''
    def fn():
        yield 1
        return 5
    ''')
    expected_src = snippet('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')
    node = ast.parse(snip.get_source())
    node = transform(ReturnFromGeneratorTransformer, node)
    actual_src = ast.unparse(node)
    run_test(expected_src, actual_src)


# Generated at 2022-06-21 17:53:56.894326
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).target == (3, 2)

# Generated at 2022-06-21 17:53:59.132322
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    o = ReturnFromGeneratorTransformer()
    assert isinstance(o, BaseNodeTransformer)


# Generated at 2022-06-21 17:54:07.973843
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3
    from . import helpers
    from .helpers import make_function
    from .transformers import ReturnFromGeneratorTransformer

    for GeneratedFunctionClass in helpers.generate_function_classes():
        def generator(x):
            yield 1
            return x

        def non_generator(x):
            return x

        class_instance = ReturnFromGeneratorTransformer()

        transformer_generator = class_instance.visit(ast.parse(make_function(generator)))
        transformer_non_generator = class_instance.visit(ast.parse(make_function(non_generator)))

        generated_generator = GeneratedFunctionClass(transformer_generator)
        generated_non_generator = GeneratedFunctionClass(transformer_non_generator)


# Generated at 2022-06-21 17:54:08.987293
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().target == (3, 2)


# Generated at 2022-06-21 17:54:09.978037
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:54:11.861673
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..codegen import to_source

    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:54:16.346620
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # ARRANGE #

    def test_transformer(fn, expected):
        transformed = ReturnFromGeneratorTransformer().visit(fn)
        assert unparse(transformed) == expected

    # ACT & ASSERT #


# Generated at 2022-06-21 17:54:22.351790
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input_ = """
        def fn():
            yield 'a'
            return 'b'
    """
    expected_output_ = """
        def fn():
            yield 'a'
            exc = StopIteration()
            exc.value = 'b'
            raise exc
    """
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.run_and_compare(input_, expected_output_) is True

