

# Generated at 2022-06-21 17:46:12.507942
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-21 17:46:13.849726
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer._tree_changed == False

# Generated at 2022-06-21 17:46:19.891446
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test=ReturnFromGeneratorTransformer()
    node = ast.FunctionDef(name="test", args=ast.arguments())
    node.body = [ast.Yield(value=ast.Str('hello')), ast.Return(value=ast.Num(1))]
    test.visit(node)
    assert len(node.body) == 3
    assert isinstance(node.body[0], ast.Yield)
    assert isinstance(node.body[1], ast.Assign)
    assert isinstance(node.body[2], ast.Raise)

# Generated at 2022-06-21 17:46:22.632607
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert t


# Generated at 2022-06-21 17:46:24.420008
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class_ = ReturnFromGeneratorTransformer()

    # Case 1:

# Generated at 2022-06-21 17:46:36.211900
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import NodeTestCase
    from .test_utils import transform, parse

    class Test(NodeTestCase):
        target = ReturnFromGeneratorTransformer

        def test_simple(self):
            code = """
            def fn():
                yield 1
                return 5
            """
            result = """
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            """
            self.check(code, result)

        def test_complex(self):
            code = """
            def fn(x):
                yield 1
                if x < 5:
                    return x + 5
                else:
                    if x < 10:
                        return x + 10
            """

# Generated at 2022-06-21 17:46:45.269760
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = 'def fn1():\n    def fn2():\n        yield 1\n        return 5\n\ndef fn3():\n    pass\ndef fn4():\n    yield 1\ndef fn5():\n    return 5\n'
    expected = 'def fn1():\n    def fn2():\n        yield 1\n        exc = StopIteration()\n        exc.value = 5\n        raise exc\n\ndef fn3():\n    pass\ndef fn4():\n    yield 1\ndef fn5():\n    return 5\n'
    module = ast.parse(code)
    expected_module = ast.parse(expected)

    transformer = ReturnFromGeneratorTransformer()
    module = transformer.visit(module) # type: ast.Module


# Generated at 2022-06-21 17:46:46.546911
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:52.989610
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    ast = x.visit_FunctionDef(ReturnFromGeneratorTransformer.ast_tree)
    ast_str = ReturnFromGeneratorTransformer.ast_to_src(ast)
    print (ast_str)  # NOQA
    assert ast_str == x.expected_str


# Generated at 2022-06-21 17:46:53.983719
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:07.954351
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test1():
        def fn():
            yield 1  # noqa
            return 5

    def test2():
        def fn():
            return 5

    def test3():
        def fn():
            yield 1  # noqa
            return 5
            print(5)

    def test4():
        def fn():
            print(1)
            yield 2  # noqa
            return 5
            print(5)

    def test5():
        def fn():
            if 1:
                print(1)
                return 5

    def test6():
        def fn():
            if 1:
                print(1)
                yield 2  # noqa
                return 5


# Generated at 2022-06-21 17:47:09.138483
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:47:20.654618
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    program = """
        def gen():
            yield 1
            return 5

        def gen_2():
            yield 2
            return 5

        def gen_3():
            yield 1
            return 5

        def gen_4():
            yield 1
            return 5
        """

    expected_program = """

        def gen():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

        def gen_2():
            yield 2
            return 5

        def gen_3():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

        def gen_4():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    t = ReturnFromGeneratorTransformer()
    new_tree = t.visit

# Generated at 2022-06-21 17:47:25.321173
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """

    tree = ast.parse(source)
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert expected == astunparse.unparse(new_tree).strip()



# Generated at 2022-06-21 17:47:32.701556
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    functiondef_node = ast.parse("""def fn():
        yield 1
        return 5
        """).body[0]
    # call method
    ReturnFromGeneratorTransformer().visit(functiondef_node)
    parsed_node = ast.parse("""def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
        """).body[0]
    assert ast.dump(functiondef_node) == ast.dump(parsed_node)

# Generated at 2022-06-21 17:47:44.005884
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def foo(): yield 1; return 2').body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

# Generated at 2022-06-21 17:47:49.997840
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fn = ast.parse(textwrap.dedent("""
    def fn():
        yield 1
        return 5
    """)).body[0]  # type: ignore

    trans = ReturnFromGeneratorTransformer()
    trans.visit(fn)

    assert ast.dump(fn) == textwrap.dedent("""\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc""")

# Generated at 2022-06-21 17:47:57.897086
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print('test_ReturnFromGeneratorTransformer_visit_FunctionDef... ', end='')

    source = '''def fn():
    yield 1
    return 5
'''
    expected = '''def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc
'''
    module = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module)

    assert transformer._tree_changed is True
    assert ast.dump(module) == expected

    print('OK')


# Generated at 2022-06-21 17:48:03.151023
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''def fn():
        yield 1
        return 5'''
    bt = ReturnFromGeneratorTransformer()
    module = ast.parse(code)
    transformed = bt.visit(module)
    return_from_generator.code == ast.unparse(module)


# Generated at 2022-06-21 17:48:14.279767
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Simple case
    module = ast.parse("""def fn():
        yield 1
        return 5
    """)
    ReturnFromGeneratorTransformer().visit(module)
    assert str(module) == """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc
"""
    # Should work on multiple levels
    module = ast.parse("""def fn():
        for x in 1:
            if x:
                yield 1
                return 5
                return 6
    """)
    ReturnFromGeneratorTransformer().visit(module)
    assert str(module) == """def fn():
    for x in 1:
        if x:
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            return 6
"""
    # Works with

# Generated at 2022-06-21 17:48:20.833115
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.new_tree is None

# Generated at 2022-06-21 17:48:27.997203
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(
        'def fn():\n'
        '    yield 1\n'
        '    return 5'
    )
    node = ReturnFromGeneratorTransformer().visit(node)

# Generated at 2022-06-21 17:48:34.282616
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..environment import get_global_environment
    from . import PythonCompiler
    from ..utils.source import SourceCode

    env = get_global_environment()
    code = SourceCode.parse(
        """
        def fn():
            yield 1
            return 2
        def fn2():
            return 5
    """)

    new_code = PythonCompiler.compile(code, env, requires=['typed_ast'], nodes=[ReturnFromGeneratorTransformer])
    # TODO: assert



# Generated at 2022-06-21 17:48:35.188865
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:48:36.591581
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast.fix_missing_locations

# Generated at 2022-06-21 17:48:44.615052
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source_helpers import source_to_string
    from ..testing import run_transformer_test
    from .return_to_yield_with_exception import ReturnToYieldWithExceptionTransformer
    node = ast.parse('def fn():\n  yield 1\n  return 2')
    target = ast.parse('''def fn():
  yield 1
  exc = StopIteration()
  exc.value = 2
  raise exc''')
    targets = [target]
    transformer = ReturnFromGeneratorTransformer()
    run_transformer_test(transformer, node, targets, __name__,
                         transforms=[ReturnToYieldWithExceptionTransformer.transform])

# Generated at 2022-06-21 17:48:46.724536
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None).__class__.__name__ == "ReturnFromGeneratorTransformer"


# Generated at 2022-06-21 17:48:56.074965
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class DummyNode:
        """Dummy class for the class 'ast.Return'.

        Represents the string in the attribute 'value' of the class 'ast.Return'.
        """
        def __init__(self, value):
            self.value = value

    class DummyClass:
        """Dummy class for the class 'ast.FunctionDef'.

        Represents the list in the attribute 'body' of the class 'ast.FunctionDef'.
        """
        def __init__(self, body):
            self.body = body

    class DummyAST:
        """Dummy class for the class 'ast'.

        Represents the class 'ast'.
        """
        @staticmethod
        def Return(value):
            """Represents the class 'ast.Return'.

            Creates and returns an object of the class 'DummyNode'.
            """

# Generated at 2022-06-21 17:49:07.541839
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """This method test for code:

    # code
    def fn():
        yield 1
        return 5
    """
    node = ast.parse(dedent('''
        def fn():
            yield 1
            return 5
    '''))

    fn = node.body[0]
    assert str(fn.body[0]) == 'yield 1'
    assert str(fn.body[1]) == 'return 5'
    assert len(fn.body) == 2

    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)

    assert transformer._tree_changed

    fn = node.body[0]
    assert str(fn.body[0]) == 'yield 1'
    assert str(fn.body[1]) == 'exc = StopIteration()'

# Generated at 2022-06-21 17:49:08.564936
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:49:18.928798
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:49:22.526468
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  s = """def fn():
  yield 1
  return 5"""
  expected_result = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""

  result = ReturnFromGeneratorTransformer.run_pipeline(s)

  assert expected_result == result

# Generated at 2022-06-21 17:49:26.093509
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def fn():
            yield 1
            return 5
            return 6
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            return 6
    """
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    transformed_code = astunparse.unparse(tree)
    assert transformed_code == expected_code



# Generated at 2022-06-21 17:49:32.845343
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(ast.parse(fn.__code__))[0]

    import inspect
    src = inspect.getsource(fn)
    expected = inspect.getsource(eval(compile(result, '<test>', 'exec')))

    print(src)
    print('\n')
    print(expected)

    assert src == expected

# Generated at 2022-06-21 17:49:34.269902
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transform = ReturnFromGeneratorTransformer()
    assert transform is not None


# Generated at 2022-06-21 17:49:35.616511
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..ast_utils import equal_ast
    from .. import jit

# Generated at 2022-06-21 17:49:46.762225
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    test_snippets_code = """
        def fn(): pass
        def fn2(): yield 1
        def fn3(): return 5 
        def fn4(): yield 1; return 5 
        def fn5():
            if True:
                return 5
        def fn6():
            if True:
                yield 1
            else:
                yield 1
        def fn7():
            if True:
                yield 1
            else:
                return 5
        def fn8():
            if True:
                yield 1
            else:
                yield 2
                return 5
        def fn9():
            if True:
                yield 1
                if True:
                    return 5
    """

# Generated at 2022-06-21 17:49:52.664393
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source import source, dedent
    from .bytecode_transformer import BytecodeTransformer

    source = source(dedent('''
        def fn():
            yield 1
            return 5
    '''))

    ast_node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(ast_node)
    BytecodeTransformer().visit(ast_node)
    exec(compile(ast_node, filename="<ast>", mode="exec"), globals())

    fn_ = fn()
    next(fn_)
    with pytest.raises(StopIteration) as excinfo:
        next(fn_)
    assert excinfo.value.value == 5

# Generated at 2022-06-21 17:49:53.386436
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-21 17:49:56.176631
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_object = ReturnFromGeneratorTransformer()
    assert return_from_generator_object._find_generator_returns(node) == []

# Generated at 2022-06-21 17:50:12.810254
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test for simple case
    source = """\
    def gen():
        yield 1
        return 2
    """

    expected = """\
    def gen():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """

    module_node = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module_node)
    assert ast.dump(module_node) == expected

    # Test with extra line
    source = """\
    def gen():
        yield 1
        x = 1 + 1
        return 2
    """

    expected = """\
    def gen():
        yield 1
        x = 1 + 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """

    module_node = ast

# Generated at 2022-06-21 17:50:19.599765
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..base import CodeTree
    tree = CodeTree(ReturnFromGeneratorTransformer)
    return_from_generator_func = """
        def fn():
            yield 1
            return 5
    """
    tree.parse(return_from_generator_func)
    tree.run()
    assert tree.get_code() == """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

# Generated at 2022-06-21 17:50:28.097874
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    in_ = """
    def fn():
        yield 5
        return
    """
    expected_out = """
    def fn():
        yield 5
        exc = StopIteration()
        exc.value = None
        raise exc
    """
    out = ReturnFromGeneratorTransformer(tree=ast.parse(in_)).visit()
    assert ast.dump(out) == expected_out

    in_ = """
    def fn():
        yield
        return 5
    """
    expected_out = """
    def fn():
        yield
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    out = ReturnFromGeneratorTransformer(tree=ast.parse(in_)).visit()
    assert ast.dump(out) == expected_out


# Generated at 2022-06-21 17:50:32.083528
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:50:33.096506
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:41.792411
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..load_test_data import load_test_data
    tree = load_test_data('generator_return.py')
    for node in ast.walk(tree):
        if (isinstance(node, ast.FunctionDef) and
                node.name == 'func_with_return_in_gen'):
            func_with_return_in_gen = node
            break
    else:
        raise ValueError('function not found')


# Generated at 2022-06-21 17:50:42.312283
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:46.122141
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .type_annotation_transformer import TypeAnnotationTransformer
    from .from_import_transformer import FromImportTransformer
    from .from_future_import_transformer import FromFutureImportTransformer
    from .raise_from_transformer import RaiseFromTransformer
    from ..visitor import Visitor


# Generated at 2022-06-21 17:50:55.416668
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import _fixtures.regression_tests
    from cnorm.parsing.declaration import Declaration
    from cnorm.parsing.declaration import DeclarationParser
    from Kooc import kc_ast
    from pyrser import parsing
    from copy import deepcopy

    cparser = DeclarationParser()
    decl = cparser.parse("""
int __attribute__((optimize("-fno-builtin")))
foo(int a)
{
  return 1;
  __klass__ Bar;
}
    """)

    assert len(decl) == 1
    cdecl = decl[0]
    assert isinstance(cdecl, Declaration)

# Generated at 2022-06-21 17:51:05.057709
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from .base import MinimalNodeTransformer
    from .unpacking import UnpackingTransformer

    source = """
    def fn():
        yield 1
        return 4
    """
    source_ast = source_to_ast(source)
    expected_ast = source_to_ast("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 4
        raise exc
    """)

    # noinspection PyTypeChecker
    actual_ast = MinimalNodeTransformer().visit(
        UnpackingTransformer().visit(ReturnFromGeneratorTransformer().visit(source_ast)))

    assert ast.dump(actual_ast) == ast.dump(expected_ast)

# Generated at 2022-06-21 17:51:27.631368
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fn = ast.parse("""
    def wait(t):
        start = time.time()
        end = start + t
        while start < end:
            yield
            start = time.time()
        return 
    """)

    t = ReturnFromGeneratorTransformer()
    fn = t.visit(fn)

    expected = ast.parse("""
    def wait(t):
        start = time.time()
        end = start + t
        while start < end:
            yield
            start = time.time()
        exc = StopIteration()
        raise exc
    """)
    assert ast.dump(fn, annotations=True) == ast.dump(expected, annotations=True)

# Generated at 2022-06-21 17:51:38.185021
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test that when a return statement within a generator function is returned
    # Teh return statement is transformed into a raise statement with a StopIteration
    from typed_ast import ast3
    import astor

    class Test(ast3.NodeTransformer):
        def visit_Return(self, node):
            # Make sure it does not come from the first level, to test that the
            # visit_FunctionDef method visits the function body completely
            if isinstance(node.parent, ast3.While):
                return_from_generator_transformer = ReturnFromGeneratorTransformer(None, None)
                assert isinstance(return_from_generator_transformer, ast3.NodeTransformer)
                return_from_generator_transformer.generic_visit(node)

# Generated at 2022-06-21 17:51:39.042090
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:51:42.332649
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert hasattr(ReturnFromGeneratorTransformer, 'target')
    assert hasattr(ReturnFromGeneratorTransformer, 'visit_FunctionDef')

# Generated at 2022-06-21 17:51:51.613134
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast.ast3 import parse
    tree = parse("""
        def fn(a, b):
            yield 1
            yield b
            return 5
        def fn1():
            yield 1
            return 5
        def fn2():
            pass
        def fn3(a):
            return a
    """)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    assert str(tree) == """
        def fn(a, b):
            yield 1
            yield b
            exc = StopIteration()
            exc.value = 5
            raise exc


        def fn1():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc


        def fn2():
            pass


        def fn3(a):
            return a
    """

# Generated at 2022-06-21 17:51:53.873792
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(3,2) \
            is ReturnFromGeneratorTransformer(3,2)


# Generated at 2022-06-21 17:52:01.340340
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import Py2JSCodegen
    from ..utils.snippet import snippet_to_function

    return_static = snippet_to_function("""
    def fn(x):
        if x == 1:
            return 1
        else:
            return 2
        else:
            return 3
    """)

    return_from_generator = snippet_to_function("""
    def fn(x):
        if x == 1:
            yield 1
            return 1
        else:
            yield 2
            return 2
        else:
            return 3
    """)

    # Test static functions
    ReturnFromGeneratorTransformer().visit(return_static)
    assert return_static.body[3].value.args[0].n == 3  # type: ignore

    # Test function with generator
    ReturnFromGeneratorTrans

# Generated at 2022-06-21 17:52:03.874851
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5
    ReturnFromGeneratorTransformer._find_generator_returns(ReturnFromGeneratorTransformer(), fn)


# Generated at 2022-06-21 17:52:04.968721
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer # use of transformer


# Generated at 2022-06-21 17:52:07.704094
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node = ast.parse('test = 1')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)


# Generated at 2022-06-21 17:53:06.571606
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typing import generator
    from typed_ast.ast3 import parse
    from ..utils.context import Context
    from ..utils.source import Source
    from ..utils.message import Message

    code_without_returns = '''
        def fn():
            yield "a"
            yield "b"
    '''
    code_with_returns = '''
        def fn():
            yield "a"
            return "b"
    '''
    code_with_yield_from = '''
        def fn():
            yield "a"
            yield from fn()
    '''
    code_with_return_in_if = '''
        def fn():
            yield "a"
            if True:
                return "b"
    '''

    ctx = Context()

# Generated at 2022-06-21 17:53:13.763371
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
        def fn():
            yield 1
            return 5
        """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    node = ast.parse(code)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == expected_code

# Generated at 2022-06-21 17:53:15.498645
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer().__class__.__name__ == 'ReturnFromGeneratorTransformer'

# Generated at 2022-06-21 17:53:16.759202
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer != []

# Generated at 2022-06-21 17:53:25.486129
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import run_test_ast_transformer

    # test 1: generator with only one return
    code = '''
        def fn():
            yield 1
            return 2
    '''
    expected_code = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    '''
    run_test_ast_transformer(ReturnFromGeneratorTransformer, code, expected_code)

    # test 2: generator with several returns
    code = '''
        def fn():
            yield 1
            if True:
                return 2
            elif True:
                return 3
            else:
                return 4
    '''

# Generated at 2022-06-21 17:53:32.285073
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class NodeTransformer(ast.NodeTransformer):
        def __init__(self):
            self._tree_changed = False

    class TestTransformer(NodeTransformer):
        def generic_visit(self, node):
            return ast.NodeTransformer.generic_visit(self, node)

    def test_func(data):
        def fn():
            yield 1
            return data

        ret = fn()
        print('next(ret): ', next(ret))
        print('next(ret): ', next(ret))
        return ret

    def test_func_with_two_returns(data_1, data_2):
        def fn():
            yield 1
            return data_1

            yield 2
            return data_2

        ret = fn()
        print('next(ret): ', next(ret))

# Generated at 2022-06-21 17:53:34.644593
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer

if __name__ == "__main__":
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:53:42.172139
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import print_ast
    from .. import parse_ast
    from .. import tree_equal

    # Case: function without generator
    source = """
    def fn():
        return 1
    """
    tree = parse_ast(source)
    unparser = ReturnFromGeneratorTransformer()
    unparser.visit(tree)
    assert tree_equal(unparser, tree, source)

    # Case: generator without return
    source = """
    def fn():
        yield from range(10)
    """
    tree = parse_ast(source)
    unparser = ReturnFromGeneratorTransformer()
    unparser.visit(tree)
    assert tree_equal(unparser, tree, source)

    # Case: generator with return
    source = """
    def fn():
        yield f
        return n
    """


# Generated at 2022-06-21 17:53:44.455068
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer
    assert x.__name__ == "ReturnFromGeneratorTransformer"
    assert x.__module__ == "python_minifier.transformer.return_from_generator"
    assert x.target == (3, 2)


# Generated at 2022-06-21 17:53:46.229038
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:54:46.109022
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_fn(value):
        try:
            yield value
        except ValueError:
            raise
        except Exception:
            print('exception')
        return 5

    def test_fn2(value):
        yield value

    def test_fn3(value):
        yield value
        return 5

    def test_fn4(value):
        yield value
        return

    def test_fn5(value):
        if value == 1:
            return 0
        elif value == 2:
            yield 0
        else:
            yield 1
            return

    def test_fn6(value):
        1+1
        return value

    def test_fn7(value):
        return value
        2+2
        return

    def test_fn8(value):
        return value
        return


# Generated at 2022-06-21 17:54:56.686062
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ast import FunctionDef, Return, Yield
    call = ReturnFromGeneratorTransformer()

    with pytest.raises(NotImplementedError):
        call.visit(Node())

    node = FunctionDef(name='test',
                       args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
                       body=[
                           Return(value=None)
                       ], decorator_list=[])
    call.visit(node)
    assert node.body == [Return(value=None)]


# Generated at 2022-06-21 17:54:57.681935
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer((3, 2))

# Generated at 2022-06-21 17:55:01.262519
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.testing import assert_node_ast_is

    @snippet
    def function_body(a, b=1):
        yield a
        return b

    assert_node_ast_is(ReturnFromGeneratorTransformer(None).visit(function_body.get_ast()), function_body.get_stub())

# Generated at 2022-06-21 17:55:10.725024
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # test example code
    @snippet
    def before():
        def fn():
            yield 1
            return 5

    @snippet
    def after():
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

    assert_match(ReturnFromGeneratorTransformer().visit(before.tree), after.tree)

    # test example code
    @snippet
    def before():
        def fn():
            return 5

    @snippet
    def after():
        def fn():
            return 5

    assert_match(ReturnFromGeneratorTransformer().visit(before.tree), after.tree)

    # test example code
    @snippet
    def before():
        def fn():
            yield 1
            if True:
                return 5
           

# Generated at 2022-06-21 17:55:11.732948
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.target == (3, 2)



# Generated at 2022-06-21 17:55:16.735616
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .test_unwrap_generator import unwrap_generator

    @snippet
    def fn():
        let(x)
        x = 0
        for _ in range(x):
            yield 1
        return x

    @snippet
    def expected_code():
        let(exc)
        exc = StopIteration()
        exc.value = 0
        raise exc

    tr = unwrap_generator.visit(ReturnFromGeneratorTransformer().visit(fn.root))
    assert tr.code == expected_code.code

# Generated at 2022-06-21 17:55:22.072756
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from ..utils.test_utils import run_test, construct_test_testcase
    from ..utils.test_utils import get_test_files_from_testcase
    
    # Unit test cases

# Generated at 2022-06-21 17:55:30.744423
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer().visit(ast.parse("""
    def foo():
        try: raise Exception()
        except: pass
        yield 1
        return 1
    """)) == ast.parse("""
    def foo():
        try: raise Exception()
        except:
            pass
        yield 1
        exc = StopIteration()
        exc.value = 1
        raise exc
    """)

    assert ReturnFromGeneratorTransformer().visit(ast.parse("""
    def foo():
        yield from bar()
        return 1
    """)) == ast.parse("""
    def foo():
        yield from bar()
        exc = StopIteration()
        exc.value = 1
        raise exc
    """)


# Generated at 2022-06-21 17:55:31.614018
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer([])
