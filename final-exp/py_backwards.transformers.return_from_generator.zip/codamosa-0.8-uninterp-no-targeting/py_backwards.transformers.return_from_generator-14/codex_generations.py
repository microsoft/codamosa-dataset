

# Generated at 2022-06-21 17:46:19.896619
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse

    @snippet
    def input_code_1(a):
        def foo(a):
            yield a
            return "2"
        print("3")

    @snippet
    def expected_1(a):
        def foo(a):
            yield a
            exc = StopIteration()
            exc.value = "2"
            raise exc
        print("3")

    @snippet
    def input_code_2(a):
        def foo(a):
            yield a
            return "2"
        print("3")
        print("4")

    @snippet
    def expected_2(a):
        def foo(a):
            yield a
            exc = StopIteration()
            exc.value = "2"
            raise exc
        print("3")
       

# Generated at 2022-06-21 17:46:22.188251
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():  # noqa
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:29.779250
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5
    assert fn.__code__.co_flags & ast.CO_GENERATOR

    code = ast.parse(inspect.getsource(fn))
    for node in ast.walk(code):
        if isinstance(node, ast.FunctionDef):
            node = ReturnFromGeneratorTransformer().visit(node)
            break

    code = ast.fix_missing_locations(node)
    ast.increment_lineno(code, 1)
    code = compile(code, '', 'exec')

    globs = {}
    eval(code, globs)
    assert globs['fn']() == 1


# Generated at 2022-06-21 17:46:32.318728
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
	from typed_ast import ast3 as ast
	x = ReturnFromGeneratorTransformer()
	assert type(x) is ReturnFromGeneratorTransformer


# Generated at 2022-06-21 17:46:37.369525
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    program = """\
        def fn():
            yield 1
            return 5
    """
    expected = """\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    tree = ast.parse(program)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(tree) == expected



# Generated at 2022-06-21 17:46:39.042855
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer(should_change=None)

# Generated at 2022-06-21 17:46:41.623181
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert(isinstance(return_from_generator_transformer, BaseNodeTransformer))

# Generated at 2022-06-21 17:46:45.938110
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from . import transform

    @transform(ReturnFromGeneratorTransformer)
    def test():
        def fn():
            yield 1
            return 5

    assert test.fn.__code__.co_flags == 32
    assert list(test.fn()) == [1]

# Generated at 2022-06-21 17:46:46.483127
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-21 17:46:54.411555
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.tools import unparse

    def test(original_func_def: str, expected_func_def: str):
        original_func_def_ast = ast.parse(original_func_def)
        expected_func_def_ast = ast.parse(expected_func_def)

        actual_func_def_ast = ReturnFromGeneratorTransformer().visit(original_func_def_ast)

        assert actual_func_def_ast == expected_func_def_ast, (
            'Error in ReturnFromGeneratorTransformer.visit_FunctionDef:\n'
            f'    {unparse(actual_func_def_ast)}  != \n'
            f'    {unparse(expected_func_def_ast)}\n'
        )


# Generated at 2022-06-21 17:46:59.323360
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:47:00.090781
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:05.928474
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    cls = ReturnFromGeneratorTransformer(None)

    def fn():
        yield 1
        return 5

    def fn_str():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    formatter = ast.dump if hasattr(ast, 'dump') else ast.NodeVisitor.generic_visit
    expected = formatter(ast.parse(inspect.getsource(fn_str)))
    actual = formatter(cls.visit(ast.parse(inspect.getsource(fn))))
    assert expected == actual



# Generated at 2022-06-21 17:47:13.511129
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Tests if ReturnFromGeneratorTransformer.visit_FunctionDef() visits all elements of the AST
    # function, including those that are not returns.
    class MockedBaseNodeTransformer(BaseNodeTransformer):
        def __init__(self, *args, **kwargs):
            self.visited_elements = []
            super().__init__(*args, **kwargs)
        def generic_visit(self, node: ast.AST) -> ast.AST:
            if not isinstance(node, ast.Return):  # we want to visit all elements of the AST except for returns
                self.visited_elements.append(node)
            return node
    # tests if normal (non-generator) function is not affected

# Generated at 2022-06-21 17:47:16.064994
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_helpers import assert_equal_with_printing
    from ..codegen import to_source


# Generated at 2022-06-21 17:47:17.517885
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:18.720864
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:30.046099
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..nodes import FunctionDef
    from ..utils.source import source_to_node
    from .loop import LoopTransformer
    from .ifelse import IfElseTransformer
    from .constants import ConstantsReplacer

    def check_compile(source: str, expected: str) -> None:
        node = source_to_node(source)

        for transformer in (
            ConstantsReplacer(),
            LoopTransformer(),
            IfElseTransformer(),
            ReturnFromGeneratorTransformer(),
        ):
            node = transformer.visit(node)

        func = FunctionDef(source='fn', args=None, body=node)

        assert func.compile().strip() == expected.strip()

    # Function with yield and return, should be transformed

# Generated at 2022-06-21 17:47:39.851980
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import assert_text_transformation
    assert_text_transformation(
        ReturnFromGeneratorTransformer,
        """
        def f():
            yield 1
            return 5
        """, """
        def f():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    assert_text_transformation(
        ReturnFromGeneratorTransformer,
        """
        def f():
            if 1:
                return 5
        """, # unchanged
        """
        def f():
            if 1:
                return 5
        """
    )


__all__ = ["ReturnFromGeneratorTransformer"]

# Generated at 2022-06-21 17:47:44.586594
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.fixtures import basic_function

    class _ReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        _tree_changed = False

    transformer = _ReturnFromGeneratorTransformer()

    node = basic_function.copy()
    node.body.append(ast.Return(value=ast.Num(n=1)))
    node = transformer.visit(node)

# Generated at 2022-06-21 17:47:53.468781
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()



# Generated at 2022-06-21 17:48:02.194738
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    function_name = "generator"
    number_of_lines = 4
    number_of_nodes = 3
    number_of_return_nodes = 1
    function_body = "yield 1\n    return 5"

    generator = ast.parse(function_body)
    generator = generator.body[0]
    assert isinstance(generator, ast.FunctionDef)

    transformer = ReturnFromGeneratorTransformer(None)
    modified_node = transformer.visit_FunctionDef(generator)
    assert generator != modified_node

    assert generator.name == function_name
    assert len(generator.body) == number_of_lines

    return_node = generator.body[1]
    assert isinstance(return_node, ast.Return)
    assert return_node.value is None


# Generated at 2022-06-21 17:48:13.337139
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  from pycsmart.pycsmart import check_ast_trees

  node = ast.parse('def foo():\n'
                     '  for i in range(10):\n'
                     '    yield i\n'
                     '  return 2\n'
                     '\n')

  expected_node = ast.parse('def foo():\n'
                             '  for i in range(10):\n'
                             '    yield i\n'
                             '  exc = StopIteration()\n'
                             '  exc.value = 2\n'
                             '  raise exc\n'
                             '\n')

  transformer = ReturnFromGeneratorTransformer()
  actual_node = transformer.visit(node)

# Generated at 2022-06-21 17:48:22.605912
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Node:
        body: List[Any]

    class Return:
        value: str


# Generated at 2022-06-21 17:48:33.104725
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(node):
        refactored_node = check_refactoring(node, (ReturnFromGeneratorTransformer,))
        return refactored_node

    # noinspection PyUnusedLocal
    def test_generator():
        yield 42
        return 3

    # noinspection PyUnusedLocal
    def test_simple_generator():
        yield 42
        return 3

    r_from_generator = ast.Raise(exc=ast.Call(
        func=ast.Name(id='StopIteration',
                      ctx=ast.Load()),
        args=[],
        keywords=[ast.keyword(arg='value',
                              value=ast.Name(id='return_value',
                                             ctx=ast.Load()))]
    ),
        cause=None)

    expected_tree = ast

# Generated at 2022-06-21 17:48:38.812337
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    with open("sor/tests/data/return_from_generator.test", "r") as f:
        code = f.read()
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    with open("sor/tests/data/return_from_generator_expected.py", "r") as f:
        expected_code = f.read()
    expected_tree = ast.parse(expected_code)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-21 17:48:40.850707
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    type_of_self = ReturnFromGeneratorTransformer()
    assert isinstance(type_of_self, ReturnFromGeneratorTransformer)



# Generated at 2022-06-21 17:48:51.205125
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_tree = ast.parse("""
    def foo():
        yield 1
        return 2
    """)
    visitor = ReturnFromGeneratorTransformer()
    visitor.visit(test_tree)

# Generated at 2022-06-21 17:48:52.723727
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer  # hint for pyflakes



# Generated at 2022-06-21 17:49:00.894057
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class ReturnFromGeneratorTransformer(BaseNodeTransformer):
        """Compiles return in generators like:
            def fn():
                yield 1
                return 5
        To:
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        """
        target = (3, 2)

        def _find_generator_returns(self, node: ast.FunctionDef) \
                -> List[Tuple[ast.stmt, ast.Return]]:
            to_check = [(node, x) for x in node.body]  # type: ignore
            returns = []
            has_yield = False
            while to_check:
                parent, current = to_check.pop()

                if isinstance(current, ast.FunctionDef):
                    continue

# Generated at 2022-06-21 17:49:23.084867
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import untokenize

    # In
    module = ast.Module([
        ast.FunctionDef(
            name='fn',
            args=ast.arguments(
                args=[],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[],
            ),
            decorator_list=[],
            body=[
                ast.Expr(
                    value=ast.Yield(
                        value=ast.Num(
                            n=1,
                        ),
                    ),
                ),
                ast.Return(
                    value=ast.Num(
                        n=5,
                    ),
                ),
            ],
            returns=None,
        ),
    ])

    # Out

# Generated at 2022-06-21 17:49:35.028004
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:41.751325
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .. import context
    from ..tree.node import get_ast
    context.config('python_version', '3.7')

    test_context = context.to_context(ReturnFromGeneratorTransformer())
    tree = get_ast(get_sample_file('generator.py'))
    tree.apply_transforms(test_context.transforms)
    tree.save("test_files/generator_test.py")

# Generated at 2022-06-21 17:49:46.492838
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def fn():
        yield 1
        return 5

    t = ReturnFromGeneratorTransformer()
    t.visit(fn.root)

    @snippet
    def expected():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    assert fn.root == expected.root

# Generated at 2022-06-21 17:49:53.013637
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Input
    tree_text = '''
    def fn():
        yield 1
        return 5
    '''
    # Expected output
    expected_text = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    # Testing
    tree = ast.parse(textwrap.dedent(tree_text))
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_source_equal(expected_text, astor.to_source(tree))


# Generated at 2022-06-21 17:49:54.204410
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer() is not None

# Generated at 2022-06-21 17:49:56.072384
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    constructor = ReturnFromGeneratorTransformer()
    assert isinstance(constructor, ReturnFromGeneratorTransformer)

# Generated at 2022-06-21 17:49:57.231109
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:06.868257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(dedent('''\
        def fn():
            yield 1
            return 5
        def fn2():
            for i in range(10):
                yield i
            yield from [1, 2, 3]
            return 5
        def fn3():
            yield 1
            return 5
            a = 7
            b = 9
        def fn4():
            yield 1
            return
            a = 7
            b = 9
        def fn5():
            yield 1
            return 5
        def fn6():
            return fn6()
            a = 7
            b = 9
        def fn7():
            yield 1
        def fn8():
            return 7
    '''))
    tree = transformer.visit(tree)
    assert ast.dump(tree)

# Generated at 2022-06-21 17:50:10.766975
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    #Setup
    node = ast.parse("""def test(arg):\n  yield 0\n  return 1\n""").body[0]
    expected = ast.parse("""def test(arg):\n  yield 0\n  exc = StopIteration()\n  exc.value = 1\n  raise exc""").body[0]
    transformer = ReturnFromGeneratorTransformer()

    #Execution
    result = transformer.visit(node)

    #Verification
    assert_equals(expected, result)

# Generated at 2022-06-21 17:50:39.728709
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Given
    func = ast.parse("""
    def fn():
        yield 1
        return 5
    """).body[0]
    # When
    transformer = ReturnFromGeneratorTransformer()
    new_func = transformer.visit(func)
    # Then
    # FIXME: Can't use assert_equals because ast.parse returns different
    # lineno's than ast.dump does
    expected = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)  # noqa
    assert ast.dump(new_func) == ast.dump(expected)

# Generated at 2022-06-21 17:50:41.101467
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer  # using this to silence flake8

# Generated at 2022-06-21 17:50:43.634370
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer is not None

# Generated at 2022-06-21 17:50:44.699516
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:45.332083
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:50:47.919352
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:50:48.921948
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:50:56.066547
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import MockNode, get_code, transform, compare_source
    node = MockNode(body=[
        MockNode(type=ast.FunctionDef, name='fn',
            body=[
                MockNode(type=ast.Yield, value=MockNode(type=ast.Num, n=1)),
                MockNode(type=ast.Return, value=MockNode(type=ast.Name, id='x')),
            ]
        )
    ])
    assert transform(ReturnFromGeneratorTransformer, node) == \
        '\n'.join([
            'def fn():',
            '    yield 1',
            '    exc = StopIteration()',
            '    exc.value = x',
            '    raise exc'
        ]) + '\n'

# Generated at 2022-06-21 17:50:57.484597
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer



# Generated at 2022-06-21 17:51:02.788895
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def foo():
            yield 1
            return 5
    """
    expected = """
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    t = ReturnFromGeneratorTransformer(source)
    t.visit(ast.parse(source))
    assert t.dump_tree() == expected



# Generated at 2022-06-21 17:51:26.387970
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:51:37.038413
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node_to_test = ast.parse(
        '''
            def my_function():
                yield 5
                return 0
        '''
    )
    transformer = ReturnFromGeneratorTransformer()

    assert not transformer._find_generator_returns(node_to_test.body[0])

    node_to_test = ast.parse(
        '''
            def my_function():
                yield 5
                return 0
                x = 4
        '''
    )

    assert transformer._find_generator_returns(node_to_test.body[0])

    node_to_test = ast.parse(
        '''
            def my_function():
                yield 5
                return 0
                x = y + 4
        '''
    )


# Generated at 2022-06-21 17:51:41.822716
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Example code
    code = """def fn():
        yield 1
        return 5"""

    # Expected result after transformation
    expected = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""

    # Initialize ast
    module = ast.parse(code)
    module = ReturnFromGeneratorTransformer().visit(module)

    # Compare code with expected
    assert astor.to_source(module).strip() == expected

# Generated at 2022-06-21 17:51:44.703634
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    src = '''
        def fn():
            yield 1
            return 5
        '''
    expected = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    assert ReturnFromGeneratorTransformer().transform_snippet(src) == expected

# Generated at 2022-06-21 17:51:47.757907
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    '''Test of method visit_FunctionDef of class ReturnFromGeneratorTransformer'''

# Generated at 2022-06-21 17:51:55.217328
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    t = ReturnFromGeneratorTransformer()
    assert not t._find_generator_returns(
        ast.parse('function foo() {\n  return 2;\n}').body[0])
    assert t._find_generator_returns(
        ast.parse('function* foo() {\n  yield 1;\n  return 2;\n}').body[0])

    code = """
    def fn():
        yield 1
        return 5
    """
    a = ast.parse(code)
    t.visit(a)
    assert a.body[0].body == ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """).body[0].body

# Test that actual code is changed

# Generated at 2022-06-21 17:52:05.811625
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..transforms.base import BaseNodeTransformer
    from ..utils.snippet import let
    import ast as stdlib_ast
    import astor as astor
    import typed_astunparse as astunparse
    class ExpectedTransformer(BaseNodeTransformer):
        def visit_Return(self, node: stdlib_ast.Return):
            body = let(exc)
            exc = StopIteration()
            exc.value = 5
            raise exc
            return stdlib_ast.Return(value=stdlib_ast.Tuple(elts=[stdlib_ast.Name(id='y', ctx=stdlib_ast.Load()), stdlib_ast.Name(id='z', ctx=stdlib_ast.Load())], ctx=stdlib_ast.Load()))

# Generated at 2022-06-21 17:52:14.811997
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:52:16.469159
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    print("Unit test for constructor of class ReturnFromGeneratorTransformer")

# Generated at 2022-06-21 17:52:24.783634
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:53:18.146806
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:53:26.699297
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class ReturnFromGeneratorTransformerTester(
            ReturnFromGeneratorTransformer):
        transformed_tree = None  # type: ast.AST

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.transformed_tree = self._tree

        def _update_tree(self, new_tree: ast.AST) -> None:
            self.transformed_tree = new_tree

    test_tree = ast.parse("""
    def fn():
        yield 1
        return 5
    def fn2():
        yield 1
    def fn3():
        yield 1
        yield 5
        return 5
    """)

    transformer = ReturnFromGeneratorTransformerTester(test_tree)

# Generated at 2022-06-21 17:53:27.419945
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:53:38.587314
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import sys
    from .utils import NodeTransformerTestCase, source_to_ast
    from . import is_equal_node

    # FIXME: Python 3.3 does not support `__qualname__`
    if sys.version_info[:2] >= (3, 3):
        class ReturnFromGeneratorTransformerTestCase(NodeTransformerTestCase):
            def setUp(self):
                # FIXME: Typed AST does not support assignment expression
                self._maxDiff = None

            def test_simple_generator(self):
                source = '''\
                def fn():
                    yield 1
                    return 42
                '''
                expected = '''\
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 42
                    raise exc
                '''
                tree

# Generated at 2022-06-21 17:53:44.045355
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test:
        def __init__(self):
            self._tree_changed = False

        def _find_generator_returns(self, node):
            return [('parent2', 'return_2')]

        def _replace_return(self, parent, return_):
            pass

    node = type('node', (), {})
    node.body = ['node_body']
    node_body = type('node_body', (), {})
    node_body.body = []
    node_body.body.append('return_1')
    node_body.body.append(node_body)
    node.body.append(node_body)
    node.body.append('return_3')
    test = Test()

# Generated at 2022-06-21 17:53:45.299146
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:53:46.820246
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:53:50.093628
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of
    class ReturnFromGeneratorTransformer.
    """

    # use single run to reduce number of line that should be tested
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:53:56.594421
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from .do_not_generate_unused_variables import DoNotGenerateUnusedVariablesTransformer
    from .add_type_annotation import AddTypeAnnotationTransformer
    from .add_docstring import AddDocstringTransformer
    from .add_optional_type_annotation import AddOptionalTypeAnnotationTransformer
    from .import_statement import ImportStatementTransformer
    from ..utils.context import Context
    from ..utils.source_code import SourceCode
    import os

    source_code = SourceCode(file_path=os.path.dirname(os.path.abspath(__file__)) + '\\test_files\\test_ReturnFromGeneratorTransformer_visit_FunctionDef\\test.py')
    context = Context()
    context.max_line_length = 80

# Generated at 2022-06-21 17:54:03.560736
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..parse_python import parse_python_snippet
    from .indentation import FormattingTransformer, ForceLinefeedAfterCodeTransformer
    

# Generated at 2022-06-21 17:56:04.521839
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:56:05.903613
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()