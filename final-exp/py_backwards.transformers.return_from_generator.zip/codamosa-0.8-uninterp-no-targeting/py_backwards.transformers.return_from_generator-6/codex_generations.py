

# Generated at 2022-06-21 17:46:13.751639
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    expected: ast.FunctionDef = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    actual: ast.FunctionDef = ast.parse("""
        def fn():
            yield 1
            return 5
    """)

    transformer = ReturnFromGeneratorTransformer()
    actual = transformer.visit(actual)

    assert actual == expected


# Generated at 2022-06-21 17:46:14.240382
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer

# Generated at 2022-06-21 17:46:25.417381
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test method of class ReturnFromGeneratorTransformer."""
    from typed_astunparse import unparse
    from .base import BaseNodeTransformer

    source = """def fn():
        yield 1
        return 5"""
    node = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(node)
    result = unparse(node)
    expected = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
    if result != expected:
        print('Error in ReturnFromGeneratorTransformer.visit_FunctionDef.\n'
              '\tresult   : {}\n'
              '\texpected : {}'.format(result, expected))

    source = """def fn():
    yield 1"""
    node = ast.parse(source)
    Return

# Generated at 2022-06-21 17:46:31.414308
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:37.056234
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(code)
    transformer.visit(tree)
    assert astor.to_source(tree).strip() == expected.strip()



# Generated at 2022-06-21 17:46:45.899788
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import pytest
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_node import tree_to_str

    fn = source('''
        def fn():
            yield 1
            return 5
    ''').name('fn').node

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(fn)
    assert transformer._tree_changed

    expected = source('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''').name('fn').node

    assert tree_to_str(fn, True) == tree_to_str(expected, True)

    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:46:54.026911
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(
        """
        def func():
            yield 1
            return 5
        """
    )
    trans = ReturnFromGeneratorTransformer()
    trans.visit(node)


# Generated at 2022-06-21 17:46:55.456843
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:46:59.325375
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import inspect_ast

    def fn():
        yield 1
        return 5

    tree = ast.parse(inspect_ast(fn))
    ReturnFromGeneratorTransformer().visit(tree)

    @let(fn)
    def fn():
        yield 1
        let(exc)
        exc = StopIteration()
        exc.value = 5
        raise exc

    assert fn is fn



# Generated at 2022-06-21 17:47:00.886306
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.get_name() == \
            'ReturnFromGeneratorTransformer'

# Generated at 2022-06-21 17:47:10.050317
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer(ast.parse('def foo(): yield 1; return 5'), 0)
    node = ast.parse('def foo(): yield 1; return 5')
    transformer.generic_visit(node)
    assert transformer._tree_changed == True

    # Unit test for method _find_generator_returns of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:11.485590
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:47:12.394658
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:47:24.161855
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    generator_returns = transformer._find_generator_returns
    replace_return = transformer._replace_return

    assert transformer.visit_FunctionDef(  # type: ignore
        ast.parse("""def fn():\n"""
                  """    yield 1\n"""
                  """    return 5\n""")
    ) == ast.parse("""def fn():\n"""
                   """    yield 1\n"""
                   """    exc = StopIteration()\n"""
                   """    exc.value = 5\n"""
                   """    raise exc\n""")


# Generated at 2022-06-21 17:47:29.166091
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """ Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer """

    import typed_python.compiler
    fn = typed_python.compiler.compile_isolated(ReturnFromGeneratorTransformer.visit_FunctionDef, [ast.AST])


# Generated at 2022-06-21 17:47:31.005578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Fn:
        def fn():
            yield 1
            return 5
    fn = Fn()

    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:47:33.380280
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..typed_astunparse import unparse
    from astunparse import unparse as astunparse


# Generated at 2022-06-21 17:47:44.628761
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import sys
    import unittest
    import astor
    TARGET_VERSION = sys.version_info[0:2]

    class TestCase(unittest.TestCase):
        def do(self, before, after):
            """Helper method for test cases."""
            import gast as ast
            from astmonkey import transformers

            module = ast.parse(before)
            transformer = transformers.ReturnFromGeneratorTransformer()
            transformer.visit(module)
            # Compile to code
            after_compiled = compile(module, '<string>', 'exec')
            exec(after_compiled, {})

            self.assertMultiLineEqual(astor.to_source(module).strip(), after.strip())

        def test_1(self):
            """Test do not transform when no yield statement"""

# Generated at 2022-06-21 17:47:50.934323
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer().visit(
        ast.parse(
            """
            def fn():
                yield 1
                return 5
        """
        )
    ) == ast.parse(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    )


# Generated at 2022-06-21 17:47:52.492946
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(['a', 'b']) is not None

# Generated at 2022-06-21 17:47:56.609576
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert True

# Generated at 2022-06-21 17:48:03.517449
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from unittest import TestCase


    class Test(TestCase):
        def test_imports(self):
            from ..utils.snippet import snippet


        def test_find_generator_returns(self):
            from typed_ast import ast3 as ast


            t = ReturnFromGeneratorTransformer({})
            node = ast.parse('\n'.join([
                'def outer():',
                '    def inner():',
                '        while True:',
                '            yield 1',
                '            return 5',
                '    return 5',
                '    return 5',
                'def generator():',
                '    yield 1',
                '    return 5',
                '    return 5',
                'def no_yields():',
                '    return 5',
            ]))

            # Generator function
           

# Generated at 2022-06-21 17:48:04.601669
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-21 17:48:11.877742
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5

        def fn2():
            return 6
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

        def fn2():
            return 6
    """
    node = ast.parse(source)
    new_node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == ast.dump(ast.parse(expected))

# Generated at 2022-06-21 17:48:21.574818
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import typed_astunparse

    from .base import BaseNodeTransformerTest

    class ReturnFromGeneratorTransformerTest(BaseNodeTransformerTest, unittest.TestCase):
        TRANSFORMER = ReturnFromGeneratorTransformer
        # Examples of code where this transformer is used
        CODE = """\
            def test():
                yield 1
                return a

            def test():
                yield 1
                return
                return a

            def test():
                yield 1
                return a
                return b

            def test():
                return a
                yield 1

            def test():
                yield from a
                return b

            def test():
                return a
                yield from b

            def test():
                return
                yield from b

            def test():
                yield from b
                return
        """
        # Examples of expected

# Generated at 2022-06-21 17:48:28.635856
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        yield 2

    def fn():
        yield 1
        yield 2
        return 1

    def fn():
        yield 1
        return 1
        yield 2
        yield 1

    def fn():
        yield 1
        yield 2
        return 1
        yield 2

    def fn():
        yield 1
        return 1
        yield 2
        return 2

    def fn():
        yield 1
        return 1

    def fn():
        yield 1
        return 1
        yield 2

    def fn():
        return 1

    def fn():
        yield 1

    def fn():
        yield 2

    def fn():
        if True:
            yield 1
        yield 2
        return 1

    def fn(a):
        if a:
            yield 1
            yield 2
            return 1

# Generated at 2022-06-21 17:48:31.595102
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from tests.transformer.utils import transform, generate_visitor_test_cases
    from typed_ast import ast3 as ast

    cases = generate_visitor_test_cases(ReturnFromGeneratorTransformer, ast.FunctionDef)
    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:48:39.055906
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils.source import source_to_ast
    from ..utils.templates import generator_function
    from ..utils.visitor import walk

    for version in (3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13):
        for i in range(5):
            count_of_visitors = 0
            ast_tree = source_to_ast(generator_function(version=version, return_value=i))
            visitor = ReturnFromGeneratorTransformer()
            walk(ast_tree, visitor)
            if visitor.tree_changed:
                count_of_visitors += 1
            assert visitor.tree_changed == True
            assert count_of_visitors == 1

# Generated at 2022-06-21 17:48:50.298359
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .unwrap_asserts_test import UnwrapAssertsTransformer

    def tearDown():
        ast.fix_missing_locations(tree)

    class TestInlineVariablesTransformer(BaseNodeTransformer):
        target = (3, 5)
        # pylint: disable=too-few-public-methods

        def __init__(self):
            self._tree_changed = False

    def _test_transform(node_orig, node_new):
        tearDown()
        transformer = TestInlineVariablesTransformer()
        tree_new = transformer.visit(node_orig)
        assert ast.dump(tree_new) == ast.dump(node_new)
        assert transformer.tree_changed

    tree = ast.parse('def fn():\n    yield 1\n    return 5')
    tree_

# Generated at 2022-06-21 17:48:51.393289
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:08.175224
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    nodes = ast.parse('def f():\n    yield 1\n    return 5')
    node = nodes.body[0]
    res = return_from_generator_transformer.visit(node)
    assert res.lineno == 1
    assert res.col_offset == 0
    assert isinstance(res, ast.FunctionDef)
    assert res.name == 'f'
    assert res.body[0].lineno == 2
    assert res.body[0].col_offset == 4
    assert isinstance(res.body[0], ast.Yield)
    assert res.body[0].value.lineno == 2
    assert res.body[0].value.col_offset == 9

# Generated at 2022-06-21 17:49:12.531090
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def return_from_generator(return_value):
        # type: (int) -> None
        exc = StopIteration()
        exc.value = return_value
        raise exc

    assert ReturnFromGeneratorTransformer().run(return_from_generator) is not None

# Generated at 2022-06-21 17:49:20.031666
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert hasattr(ReturnFromGeneratorTransformer, 'visit_FunctionDef'), 'did not find visit_FunctionDef() method'
    assert inspect.signature(ReturnFromGeneratorTransformer.visit_FunctionDef), 'did not find visit_FunctionDef() method'
    assert hasattr(ReturnFromGeneratorTransformer, '_find_generator_returns'), 'did not find _find_generator_returns() method'
    assert inspect.signature(ReturnFromGeneratorTransformer._find_generator_returns), 'did not find _find_generator_returns() method'
    assert hasattr(ReturnFromGeneratorTransformer, '_replace_return'), 'did not find _replace_return() method'
    assert inspect.signature(ReturnFromGeneratorTransformer._replace_return), 'did not find _replace_return() method'

# Generated at 2022-06-21 17:49:26.616882
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestTransformer(BaseNodeTransformer):
        target = (3, 6)

        def visit_FunctionDef(self, node):
            return ast.FunctionDef(node.name, node.args, node.body, node.decorator_list, node.returns)

    class ActualTransformer(ReturnFromGeneratorTransformer):
        pass

    class AssertTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            assert isinstance(node, ast.FunctionDef)

    source = """
    def fn():
        yield 1
        return 5
    """
    actual_node = ActualTransformer().visit(ast.parse(source))
    expected_node = TestTransformer().visit(ast.parse(source))
    AssertTransformer().visit(expected_node)
    assert ast.dump

# Generated at 2022-06-21 17:49:37.819409
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    def def_(decorator_list) -> ast.FunctionDef:
        ctx = ast.Load()
        return ast.FunctionDef(name="test", args=ast.arguments(args=[],
                               vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
                               body=[ast.Expr(value=ast.Yield(value=ast.Num(n=1))),
                                     ast.Return(value=ast.Num(n=2))], decorator_list=decorator_list,
                               returns=None, type_comment=None)

    function_def_1 = def_([])
    function_def_2 = def_([ast.Name(id="decorator")])
    function_def_

# Generated at 2022-06-21 17:49:48.151237
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:48.672058
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:49:50.205576
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test constructor of class ReturnFromGeneratorTransformer."""
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:50:01.284790
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    @snippet
    def function_with_generator_return():
        def fn():
            yield 1
            return 1
    function_with_generator_return.apply(transformer)

    @snippet
    def function_with_generator_return_complex():
        def fn():
            yield 1
            if True:
                if True:
                    yield 5
                    if True:
                        yield 6
                        if True:
                            yield 7
            return 1
    function_with_generator_return_complex.apply(transformer)

    @snippet
    def function_with_return():
        def fn():
            return 1
    function_with_return.apply(transformer)


# Generated at 2022-06-21 17:50:08.970580
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test():
        def fn():
            yield 1
            return 5
    node = ast.parse(test.__code__.co_consts[0])
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert transformer._find_generator_returns(node.body[0]) == []
    assert transformer._find_generator_returns(node.body[0].body[0]) == [
        (node.body[0].body[0], node.body[0].body[0].body[1].body[1])
    ]

# Generated at 2022-06-21 17:50:19.339095
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:50:24.654602
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from textwrap import dedent
    source = dedent("""
        def fn():
            yield 1
            return 5
    """)

    test = ReturnFromGeneratorTransformer()
    test_result = test.transform_source(source)
    test_expected = dedent("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    assert test_result == test_expected

# Generated at 2022-06-21 17:50:25.564311
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-21 17:50:27.422454
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typing
    import typed_ast.ast3 as ast
    # Test function with a generator function

# Generated at 2022-06-21 17:50:31.185306
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    node, _ = parse(fn)
    node = ReturnFromGeneratorTransformer().visit(node)  # type: ignore
    code = unparser(node)
    assert code == "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n"

# Generated at 2022-06-21 17:50:40.655952
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(code):
        expect = ast3.fix_missing_locations(ast3.parse(code))
        given = ast3.fix_missing_locations(ast3.parse(code))
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(given)
        print(ast3.dump(given))
        print(ast3.dump(expect))
        assert ast3.dump(given) == ast3.dump(expect)

    code = """
    def fn():
        yield 1
        return 5
    """
    test(code)

    code = """
    def fn():
        if True:
            yield 1
            return 5
    """
    test(code)


# Generated at 2022-06-21 17:50:44.961505
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .common import roundtrip

    fn_1 = """
        def fn():
            yield 1
            return 3
    """
    result = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 3
            raise exc
    """

    assert roundtrip(fn_1)[0] == result



# Generated at 2022-06-21 17:50:53.700143
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    tree = ast.parse(fn.__code__)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)

    assert transformer.tree_changed
    assert new_tree is not tree

    fn = compile(new_tree, '', 'exec')
    namespace = {}
    exec(fn, namespace)

    generator = namespace['fn']()
    assert generator.__next__() == 1
    with pytest.raises(StopIteration) as e:
        generator.__next__()
    assert e.value.value == 5


# Generated at 2022-06-21 17:51:03.318519
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    from ..utils.source import source_to_ast
    from ..transformers import ReturnFromGeneratorTransformer
    from ..transformers import TestTransformerMixin

    class Test(unittest.TestCase, TestTransformerMixin): pass

    ast_tree = source_to_ast.parse('''
    def fn():
        yield 1
        return 5
    ''')

    expected_tree = source_to_ast.parse('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

    ReturnFromGeneratorTransformer.assert_transform(
        Test,
        ast_tree, expected_tree
    )

# Generated at 2022-06-21 17:51:12.519592
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
        """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    tree = ast.parse(source)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    print(ast.unparse(new_tree))
    assert ast.unparse(new_tree) == expected

    source = """
    def fn():
        yield 1
        yield 5
        return 10
    """
    expected = """
    def fn():
        yield 1
        yield 5
        exc = StopIteration()
        exc.value = 10
        raise exc
    """
    tree = ast.parse(source)

# Generated at 2022-06-21 17:51:32.300081
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:51:38.771257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fn = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')

    compiler = ReturnFromGeneratorTransformer()
    compiler.visit(fn)

    expected = ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

    assert ast.dump(fn) == ast.dump(expected)

# Generated at 2022-06-21 17:51:40.184285
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .conftest import transform
    from ..utils import dump


# Generated at 2022-06-21 17:51:40.946086
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ReturnFromGeneratorTransformer()


# Generated at 2022-06-21 17:51:43.500859
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert x._tree_changed == False
    assert len(x._find_generator_returns(None)) == 0
    x._replace_return(None, None)
    assert x.visit_FunctionDef(None) == None

# Generated at 2022-06-21 17:51:48.542929
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    # find generator_returns is ok
    expected = [
        (ast.FunctionDef(
            name='fn',
            args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
            body=[ast.Yield(value=ast.Num(n=1)), ast.Return(value=ast.Num(n=5))],
            decorator_list=[]
        ), ast.Return(value=ast.Num(n=5))
        )
    ]

# Generated at 2022-06-21 17:51:58.219137
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.yield_tester import YieldTester
    from ..utils.utils import compile_source
    from ..utils.exception import InvalidCode
    from .base import run_transform

    # Run code without transformer
    tester = YieldTester(compile_source("""def func():
    yield 1
    return 5
    yield 2""", '<string>', mode='exec'))
    with pytest.raises(InvalidCode):
        tester.run()

    # Run code with transformer
    tester = YieldTester(
        compile_source(run_transform(ReturnFromGeneratorTransformer, """def func():
    yield 1
    return 5
    yield 2"""), '<string>', mode='exec'))
    tester.run()
    out, err = capsys.readouterr()
   

# Generated at 2022-06-21 17:52:02.408998
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer(None)
    test_input = """
    def test():
        yield 1
        return 5
    """
    tree = ast.parse(test_input)
    tree_changed = transformer.visit(tree)
    expected_output = """
    def test():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert tree_changed
    assert ast.dump(tree) == ast.dump(ast.parse(expected_output))

# Generated at 2022-06-21 17:52:03.131023
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:52:11.538123
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:53:33.181330
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import parse
    from . import dump
    tree = parse('def fn(): yield 1; return 2;')
    res = dump(ReturnFromGeneratorTransformer().visit(tree))
    assert res == 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 2\n    raise exc\n'

# Generated at 2022-06-21 17:53:35.801406
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer is not None


# Generated at 2022-06-21 17:53:36.606358
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None

# Generated at 2022-06-21 17:53:37.940131
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer is not None


# Generated at 2022-06-21 17:53:43.748371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from . import fix_ast_lineno

    def transform(src):
        return astor.to_source(fix_ast_lineno(ReturnFromGeneratorTransformer().visit(ast.parse(src))))

    assert transform("""
    def fn():
        yield 1
        return 5
    """) == """
    def fn():
        yield 1;
        exc = StopIteration();
        exc.value = 5;
        raise exc;
    """

    assert transform("""
    def fn():
        while cond:
            yield 1
            return 5
    """) == """
    def fn():
        while cond:
            yield 1;
            exc = StopIteration();
            exc.value = 5;
            raise exc;
    """


# Generated at 2022-06-21 17:53:45.442162
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    gen = ReturnFromGeneratorTransformer()
    assert gen is not None

# Generated at 2022-06-21 17:53:46.896691
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:53:56.440365
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .base import NodeTest
    from .base import BaseNodeTransformerTest
    from .fake_context import FakeContext

    class Test(BaseNodeTransformerTest, unittest.TestCase):
        transformer = ReturnFromGeneratorTransformer
        method = 'visit_FunctionDef'
        target = (3, 2)

        def make_node(self, tree: ast.AST) -> ast.AST:
            tree = ast.fix_missing_locations(tree)
            return ast.FunctionDef(
                name=tree.name,
                args=tree.args,
                body=tree.body,
                decorator_list=tree.decorator_list,
                returns=tree.returns,
                lineno=1,
                col_offset=0,
            )

    #

# Generated at 2022-06-21 17:53:58.977006
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Test the constructor of the class ReturnFromGeneratorTransformer
    transformer = ReturnFromGeneratorTransformer()

    assert transformer is not None


# Generated at 2022-06-21 17:54:07.458738
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.compat import to_tuple

    from ..utils import six
    from ..utils.visitor import NodeTransformerV2

    source = """
        def fn():
            yield 1
            return 5
    """

    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    ReturnFromGeneratorTransformer.target = (3, 5)

    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(source)
    tree = NodeTransformerV2().visit(tree)

    tree = transformer.visit(tree)
    out = to_tuple(tree)[0]

    assert six.to_source(out) == expected



# Generated at 2022-06-21 17:55:06.385723
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import get_ast, assert_ast_equals, source_to_ast

# Generated at 2022-06-21 17:55:09.008924
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class_instance = ReturnFromGeneratorTransformer()
    assert isinstance(class_instance, BaseNodeTransformer)


# Generated at 2022-06-21 17:55:12.922392
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import run_transformer

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    run_transformer(ReturnFromGeneratorTransformer, source, expected)  # type: ignore



# Generated at 2022-06-21 17:55:13.704772
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:55:18.778085
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_astunparse

    def get_tree(source: str) -> ast.FunctionDef:
        tree = ast.parse(source)  # type: ignore
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)
        return tree.body[0]

    source = """
    def test():
        yield 1
        return 2
    """
    correct_tree = """
    def test():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    assert typed_astunparse.unparse(get_tree(source)) == correct_tree

# Generated at 2022-06-21 17:55:29.870648
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from ..utils import get_ast, compare_ast

    code = '''\
        def f():
            yield 1
            yield 2
            return 3
    '''
    # to make the tests work with both typed_ast and ast
    if hasattr(ast, 'Return'):
        Return = ast.Return
    else:
        Return = ast.return_

# Generated at 2022-06-21 17:55:31.731327
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer



# Generated at 2022-06-21 17:55:32.877722
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-21 17:55:37.472499
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import astor

    def fn():
        yield 1
        return 5

    source = astor.to_source(ast.parse(fn.__code__))
    expected = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""

    assert source == expected



# Generated at 2022-06-21 17:55:44.428810
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    from typed_ast.ast3 import FunctionDef, Return, Expr, Name, NameConstant, Yield, YieldFrom
    from unittest import TestCase

    transformer = ReturnFromGeneratorTransformer()

    node = FunctionDef(
        name='f',
        args=None,
        body=[
            Return(value=NameConstant(value=None))
        ],
        decorator_list=[]
    )
    new_node = transformer.visit(node)
    assert new_node == node

    node = FunctionDef(
        name='f',
        args=None,
        body=[
            Return(value=NameConstant(value=None)),
        ],
        decorator_list=[]
    )
    new_node = transformer.visit(node)
    assert new