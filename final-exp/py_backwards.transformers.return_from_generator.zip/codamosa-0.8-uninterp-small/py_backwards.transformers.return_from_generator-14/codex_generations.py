

# Generated at 2022-06-25 22:18:25.261929
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    def _test_FunctionDef_0():
        a_s_t_1 = module_0.AST()

# Generated at 2022-06-25 22:18:31.878180
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """
    Test case for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    """
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(arguments_0=module_0.arguments(args_0=[], vararg_0=None, kwonlyargs_0=[], kwarg_0=None, defaults_0=[], kw_defaults_0=[]), body_0=[], name_0='fn', decorator_list_0=[], returns_0=None)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    assert function

# Generated at 2022-06-25 22:18:36.600779
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # test for first use
    _test_first_use()
    # test for second use
    _test_second_use()
    # test for third use
    _test_third_use()


# Generated at 2022-06-25 22:18:40.971920
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert hasattr(return_from_generator_transformer_0, 'visit_FunctionDef')


# Generated at 2022-06-25 22:18:47.887725
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Defining arguments
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    node_0 = module_0.FunctionDef()
    # Call the method
    returned_0 = return_from_generator_transformer_0.visit_FunctionDef(node_0)
    # Check the returned type
    assert isinstance(returned_0, module_0.FunctionDef)

# Generated at 2022-06-25 22:18:51.841378
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    functiondef_0 = module_0.FunctionDef()
    functiondef_0 = return_from_generator_transformer_0.visit_FunctionDef(functiondef_0)

# Generated at 2022-06-25 22:19:02.456401
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    class_def_0 = module_0.ClassDef(name='TestClass', bases=[], keywords=[], body=[], decorator_list=[])
    function_def_0 = module_0.FunctionDef(name='TestMethod', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:19:08.244871
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1)

# Generated at 2022-06-25 22:19:16.800414
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    a_s_t_1 = module_0.AST()
    suite_0 = module_0.Suite([])
    return_0 = module_0.Return()
    a_s_t_2 = module_0.AST()
    if_exp_0 = module_0.IfExp()
    a_s_t_3 = module_0.AST()
    load_0 = module_0.Load()
    a_s_t_4 = module_0.AST()
    mod_0 = module_0.Mod()
    a_s_t_5 = module

# Generated at 2022-06-25 22:19:25.329386
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    module_0.FunctionDef('f', module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), [module_0.Yield(), module_0.Return(value=module_0.Num(n=0))], [], None)

# Generated at 2022-06-25 22:19:45.880480
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='test_function', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)
    return_from_generator_transformer_0._find_generator_returns(function_def_0)
    return_from_generator_transformer_0._replace_return(function_def_0, module_0.Return(value=module_0.Name(id='a', ctx=module_0.Load())))


# Generated at 2022-06-25 22:19:55.458909
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = ast.parse('def fn():\n    yield 1\n    return 5')
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    fn_0 = return_from_generator_transformer_0.visit(a_s_t_0.body[0])
    assert return_from_generator_transformer_0._tree_changed is True
    assert isinstance(fn_0, ast.FunctionDef)
    assert isinstance(fn_0.body[1], ast.Expr)
    assert isinstance(fn_0.body[2], ast.Expr)
    assert isinstance(fn_0.body[3], ast.Assign)

# Generated at 2022-06-25 22:20:03.552533
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = a_s_t_0.FunctionDef(name='foo', args=module_0.arguments(
    args=[module_0.Name(id='self', ctx=module_0.Load())], vararg=None, kwonlyargs=[], kw_defaults=[],
    kwarg=None, defaults=[]), body=[module_0.Return(value=module_0.Constant(value=1))], decorator_list=[],
    returns=None)
    # call method

# Generated at 2022-06-25 22:20:13.902539
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    functiondef_0 = module_0.FunctionDef(name='b',
                                         args=module_0.arguments(posonlyargs=[],
                                                                 args=[],
                                                                 kwonlyargs=[],
                                                                 kw_defaults=[],
                                                                 defaults=[]),
                                         body=[module_0.Return(value=module_0.Num(n=1))],
                                         decorator_list=[],
                                         returns=None)
    _ = return_from_generator_transformer_0.visit_FunctionDef(functiondef_0)


# Generated at 2022-06-25 22:20:22.577093
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_node_0 = module_0.FunctionDef('fn')
    return_node_0 = module_0.Return()
    
    function_def_node_0.body.append(module_0.Yield())
    function_def_node_0.body.append(return_node_0)
    
    return_from_generator_transformer_0.visit(function_def_node_0)
    
    assert function_def_node_0.body[2].value == 1
    assert function_def_node_0.body[3].value == return_node_0
    

# Generated at 2022-06-25 22:20:30.414339
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    source_code_lines_0 = []
    line_0 = []
    line_0.append(('0', 'CodeLine(0, 5)'))
    source_code_lines_0.append(line_0)
    line_1 = []
    line_1.append(('line_number', 'CodeLine(1, 0)'))
    line_1.append(('def', 'Keyword(1, 3)'))
    line_1.append(('fn', 'Name(1, 6)'))
    line_1.append(('(', 'Delimiter(1, 7)'))

# Generated at 2022-06-25 22:20:34.971973
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    functiondef_0_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(functiondef_0_0)


# Generated at 2022-06-25 22:20:44.549228
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # Make instance of module_0.AST
    a_s_t_0 = module_0.AST()
    # Create instance of class ReturnFromGeneratorTransformer
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Create instance of module_0.FunctionDef
    function_def_0 = module_0.FunctionDef()
    # Set the name of function_def_0 to "foo"
    function_def_0.name = "foo"

    # Create instance of module_0.Return
    return_0 = module_0.Return()

    # Create instance of module_0.Expr
    expr_0 = module_0.Expr()
    # Set the body of expr_0 to module_0.NameConstant(value=None)
    expr_

# Generated at 2022-06-25 22:20:47.694807
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(None)


# Generated at 2022-06-25 22:20:59.290011
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='test_case_0',\
                                         args=module_0.arguments(args=[], vararg=None,\
                                                                 kwonlyargs=[], kw_defaults=[],\
                                                                 kwarg=None, defaults=[]),\
                                         body=[], decorator_list=[],\
                                         returns=None)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_0.returns is None


# Generated at 2022-06-25 22:21:09.555048
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    ast_0 = module_0.Str()
    function_def_0 = module_0.FunctionDef(arguments=ast_0, body=ast_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

test_case_0()
test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:21:18.326291
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef( 
        name='', 
        args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), 
        body=[], 
        decorator_list=[], 
        returns=None
    )
    return_from_generator_transformer_0.visit(function_def_0)

# Generated at 2022-06-25 22:21:30.451821
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    arg_1 = module_0.FunctionDef()
    try:
        return_from_generator_transformer_0.visit_FunctionDef(arg_1)
        throw_exception('AssertionError')
    except:
        exception_type, exception_value, exception_tb = sys.exc_info()

# Generated at 2022-06-25 22:21:33.100665
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

test_case_0()

# Generated at 2022-06-25 22:21:35.549049
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:38.233322
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:40.785284
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:45.130227
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # fn_0's type is FunctionDef
    fn_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(fn_0)


# Generated at 2022-06-25 22:21:52.692569
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast
    import module_a_s_t_0 as module_0
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = ast.FunctionDef()
    function_def_0.name = 'test'
    function_def_0.args = ast.arguments()
    annotations_0 = []
    function_def_0.args.posonlyargs = []
    annotations_0_0 = []
    function_def_0.args.args = []
    function_def_0.args.vararg = None
    function_def_0.args.kwonlyargs = []
    annotations_0_1 = []
    function_def_0.args.kw_

# Generated at 2022-06-25 22:22:01.803824
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0_copy_0 = copy.deepcopy(function_def_0)
    function_def_0_copy_1 = copy.deepcopy(function_def_0)
    assert not (function_def_0_copy_0 is function_def_0)
    assert not (function_def_0_copy_1 is function_def_0)
    assert not (function_def_0_copy_0 is function_def_0_copy_1)
    function_def_0_copy_1 = return_from_generator_transformer_0.visit_

# Generated at 2022-06-25 22:22:14.488904
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

	# Arrange
    
	a_s_t_0 = module_0.AST()
	return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
	a_s_t_1 = a_s_t_0
	a_s_t_1.body = []
	a_s_t_1.type_ignores = []
	a_s_t_1.returns = []
	a_s_t_1.args = []
	a_s_t_1.defaults = []
	a_s_t_1.decorator_list = []
	a_s_t_1.arguments = []
	a_s_t_1.func = None
	a_s_t_1.iter = None
	a_

# Generated at 2022-06-25 22:22:17.415931
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    pass


# Generated at 2022-06-25 22:22:21.628106
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)


# Generated at 2022-06-25 22:22:23.801442
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:31.959562
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    function_def_0 = module_0.FunctionDef(
        name = "f",
        args = module_0.arguments(
            args = [],
            vararg = None,
            kwonlyargs = [],
            kw_defaults = [],
            kwarg = None,
            defaults = []
        ),
        body = [
            module_0.Yield(
                value = module_0.Num(
                    n = 1
                )
            ),
            module_0.Return(
                value = module_0.Num(
                    n = 5
                )
            )
        ],
        decorator_list = [],
        returns = None,
        type_comment = None
    )
    return_from_generator_transformer

# Generated at 2022-06-25 22:22:36.656309
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    import typed_ast
    a_s_t_0 = typed_ast.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert isinstance(return_from_generator_transformer_0, ReturnFromGeneratorTransformer)
    assert hasattr(return_from_generator_transformer_0, "visit_FunctionDef")


# Generated at 2022-06-25 22:22:39.364882
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:47.792145
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(
        name="foo",
        args=module_0.arguments(
            args=[module_0.arg(arg="a", annotation=None)],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]),
        body=[module_0.Return(value=module_0.Num(n=3))],
        decorator_list=[],
        returns=None)

# Generated at 2022-06-25 22:22:55.704699
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = []
    a_s_t_0.type_ignores = []

# Generated at 2022-06-25 22:23:04.951780
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0.body = [module_0.YieldFrom()]
    function_def_0.body.append(module_0.Return())
    function_def_0.body[-1].value = module_0.Num()
    function_def_0.body[-1].value.n = 1
    function_def_0.body.append(module_0.YieldFrom())
    function_def_0.body.append(module_0.Return())
    function_def_0.body[-1].value = module_0.Num()
    function_

# Generated at 2022-06-25 22:23:11.193484
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)



# Generated at 2022-06-25 22:23:15.141771
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:23.259385
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0.body = [module_0.Expr()]
    function_def_0.body[0].value = module_0.Yield()
    function_def_0.body[0].value.value = module_0.Constant(1)
    function_def_0.body.append(module_0.Return())
    function_def_0.body[1].value = module_0.Constant(5)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    # Case 0:
   

# Generated at 2022-06-25 22:23:26.190562
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    module_0 = ReturnFromGeneratorTransformer(None)
    module_0 = ReturnFromGeneratorTransformer()


# Generated at 2022-06-25 22:23:28.742528
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:23:32.766067
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    node_0 = ast.FunctionDef()
    node_0.body = [ast.Expr()]
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(node_0)


# Generated at 2022-06-25 22:23:37.504143
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_f_n_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(a_f_n_0)

test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:23:45.598495
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_node_0 = module_0.FunctionDef(name='fn', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Expr(value=module_0.Yield(value=module_0.Num(n=1))), module_0.Return(value=module_0.Num(n=5))], decorator_list=[], returns=None, type_comment=None)
    __tracebackhide__ = True

# Generated at 2022-06-25 22:23:53.680814
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3 as ast
    tree = ast.parse('def fn():\n    yield 1\n    return 5')
    assert ReturnFromGeneratorTransformer.is_target_tree(tree)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)

    assert transformer.tree_changed

# Generated at 2022-06-25 22:23:56.007510
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert callable(ReturnFromGeneratorTransformer.__init__)
    assert callable(ReturnFromGeneratorTransformer.visit_FunctionDef)
    assert callable(ReturnFromGeneratorTransformer._find_generator_returns)

# Generated at 2022-06-25 22:24:07.282109
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer, type), '`ReturnFromGeneratorTransformer` class is not a type'


# Generated at 2022-06-25 22:24:09.275113
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:24:13.667741
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


if __name__ == '__main__':
    return_from_generator_transformer_0 = test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-25 22:24:21.527617
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # Test

# Generated at 2022-06-25 22:24:24.401160
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:24:27.360300
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:24:28.470275
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert True, "Failed to initialize class ReturnFromGeneratorTransformer"


# Generated at 2022-06-25 22:24:35.376829
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # 1. Arrange
    a_s_t_0 = module_0.AST()

    # 2. Act
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # 3. Assert
    assert return_from_generator_transformer_0.tree.version == (3, 8)
    assert return_from_generator_transformer_0.tree.future_features == {'typing', 'annotations'}
    assert return_from_generator_transformer_0.tree.string_repr == {'string': [], 'unicode': [], 'bytes': []}


# Generated at 2022-06-25 22:24:43.761322
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    genexpr_0 = module_0.GeneratorExp(module_0.Call(module_0.Name('range', module_0.Load()), [module_0.Num(10)], []),
                                      module_0.comprehension(module_0.Name('i', module_0.Store()), [module_0.BinOp(module_0.Name('i', module_0.Load()), module_0.FloorDiv(), module_0.Num(2))], []))
    with_item_0 = module_0.withitem(module_0.Name('a', module_0.Store()), genexpr_0)
   

# Generated at 2022-06-25 22:24:51.294078
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_0 = module_0.FunctionDef(name_0='f', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Yield(value=module_0.Constant(value=1))], decorator_list=[], returns=None)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert isinstance(function_def_0, module_0.FunctionDef)
    assert function_def_0.name

# Generated at 2022-06-25 22:25:01.970178
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:25:08.379273
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    str_1 = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    var_2 = module_0.parse(str_1)
    var_3 = module_0.dump(var_2)
    assert var_3 == module_0.dump(var_1)


# Generated at 2022-06-25 22:25:13.617822
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    # OUT:
    # return_from_generator.get_body(return_value=return_.value)
    # return_from_generator.get_body(return_value=return_.value)


# Generated at 2022-06-25 22:25:18.955581
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    var_1_str = module_0.unparse(var_1)
    assert var_1_str == 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'

# Generated at 2022-06-25 22:25:22.813385
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:25:25.485873
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    module_0 = ast.parse('y = 3')
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(module_0)
    assert return_from_generator_transformer_0.tree == module_0


# Generated at 2022-06-25 22:25:26.146941
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    _test()


# Generated at 2022-06-25 22:25:29.906637
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:25:31.300338
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = ReturnFromGeneratorTransformer(module_0.Module())
    assert var_0 is not None


# Generated at 2022-06-25 22:25:32.034980
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass


# Generated at 2022-06-25 22:25:57.395216
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:26:00.201472
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:26:01.028806
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass


# Generated at 2022-06-25 22:26:01.671605
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:26:02.660262
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-25 22:26:09.861660
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:26:12.203795
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = ReturnFromGeneratorTransformer(None)
    assert isinstance(var_0, ReturnFromGeneratorTransformer)


# Generated at 2022-06-25 22:26:17.330370
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

################################################################################
# Test string methods
################################################################################


# Generated at 2022-06-25 22:26:18.029635
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # function test
    test_case_0()

# Generated at 2022-06-25 22:26:23.104255
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_1 = 'def fn():\n    yield 1\n    return 5'
    module_0 = ast
    var_2 = module_0.parse(str_1)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(var_2)
    var_3 = return_from_generator_transformer_1.visit(var_2)


# Generated at 2022-06-25 22:27:16.321681
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:27:16.934480
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert True == False


# Generated at 2022-06-25 22:27:19.543077
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit_FunctionDef(var_0)



# Generated at 2022-06-25 22:27:22.061226
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)



# Generated at 2022-06-25 22:27:25.436069
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = None
    var_1 = test_case_0()
    var_2 = module_0.dump(var_1)
    var_3 = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    var_4 = var_3 == var_2
    var_5 = var_4


# Generated at 2022-06-25 22:27:26.097279
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = test_case_0()

# Generated at 2022-06-25 22:27:27.963786
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(ast.Module())
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(ast.parse('a'))

# Generated at 2022-06-25 22:27:30.807179
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:27:31.247420
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass

# Generated at 2022-06-25 22:27:34.408404
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

