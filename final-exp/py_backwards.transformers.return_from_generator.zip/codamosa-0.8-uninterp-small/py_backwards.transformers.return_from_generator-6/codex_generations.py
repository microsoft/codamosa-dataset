

# Generated at 2022-06-25 22:18:17.208299
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_ReturnFromGeneratorTransformer_visit_FunctionDef_0()
    test_ReturnFromGeneratorTransformer_visit_FunctionDef_1()


# Generated at 2022-06-25 22:18:21.229097
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit(a_s_t_1)

# Generated at 2022-06-25 22:18:29.482163
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .visit_FunctionDef_test import test_cases

# Generated at 2022-06-25 22:18:37.508936
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='', args=module_0.arguments(args=[], vararg=None, kwarg=None, defaults=[], kw_defaults=[]), body=[module_0.Expr(value=module_0.Num(n=1))], decorator_list=[], returns=None)
    node_0 = function_def_0
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:18:48.102541
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3 as a_s_t

    a_s_t_0 = a_s_t.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:01.770640
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    ast_node_0 = module_0.FunctionDef()
    node_0 = module_0.FunctionDef(ast_node_0, [], [], [], [], None, None, [])
    ast_node_1 = module_0.Expr()
    node_1 = module_0.Expr(ast_node_1, [], [], [], [], None, None, [], None)
    ast_node_2 = module_0.Return()
    node_2 = module_0.Return(ast_node_2, [], [], [], [], None, None, [], None)
    ast_node_3 = module

# Generated at 2022-06-25 22:19:11.930699
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Setup
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Testing
    a_s_t_1 = module_0.AST()
    function_def_0 = module_0.FunctionDef(
        name="foo",
        arguments=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
        body=[],
        decorator_list=[])

    # Exercise
    output = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    # Verify

    assert output == function_def_0

# Benchmark for method visit_

# Generated at 2022-06-25 22:19:17.898047
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(arguments_0, body_0, decorator_list_0, returns_0, type_comment_0, lineno_0, col_offset_0, end_lineno_0, end_col_offset_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:19:27.032968
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)

    test_case_1 = module_0.FunctionDef(
        name='f',
        args=module_0.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            module_0.Return(value=None)
        ],
        decorator_list=[],
        returns=None
    )


# Generated at 2022-06-25 22:19:33.305593
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = ast.parse('def fn():\n    return 5')
    a_s_t_0 = module_0
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    module_0 = return_from_generator_transformer_0.visit(module_0)
    assert module_0 == ast.parse('def fn():\n    exc = StopIteration()\n    exc.value = 5\n    raise exc')


# Generated at 2022-06-25 22:19:37.886778
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert test_case_0() == None

# EOF

# Generated at 2022-06-25 22:19:41.940147
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    list_0 = []


# Generated at 2022-06-25 22:19:47.094909
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    assert(isinstance(var_1, module_0.FunctionDef))


# Generated at 2022-06-25 22:19:52.694745
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    module_0.dump(var_1)


# Generated at 2022-06-25 22:19:54.971995
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    var_0 = test_case_0()
    test_result_0 = (list_0 == var_0)
    assert test_result_0



# Generated at 2022-06-25 22:20:03.098580
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    node_0: module_0.FunctionDef = module_0.parse('def fn():\n    return 5') # type: module_0.FunctionDef
    var_13 = return_from_generator_transformer_0.visit(node_0)
    var_14 = var_13.lineno
    int_0 = 1
    var_15 = (int_0 == var_14)
    var_16 = var_13.col_offset
    int_1 = 0
    var_17 = (int_1 == var_16)
    var_18 = var_13.col_

# Generated at 2022-06-25 22:20:07.796995
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    list_0 = []


# Generated at 2022-06-25 22:20:11.021989
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = ReturnFromGeneratorTransformer()
    var_0 = ast.FunctionDef()
    var_1 = module_0.visit_FunctionDef(var_0)
    assert type(var_1) == ast.FunctionDef

# Generated at 2022-06-25 22:20:16.319879
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    list_0 = []


# Generated at 2022-06-25 22:20:20.744145
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    list_0 = []


# Generated at 2022-06-25 22:20:31.188641
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    var_1 = 'def fn():\n    return 5'
    var_0 = module_0.parse(var_1)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_2 = return_from_generator_transformer_0.visit(var_0)

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:20:35.376934
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:20:42.546623
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    assert hasattr(module_0.FunctionDef,'body') == True
    assert hasattr(module_0.Return,'value') == True
    assert hasattr(module_0.StopIteration,'value') == True

# Generated at 2022-06-25 22:20:46.579616
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    assert var_1 == var_0

# Generated at 2022-06-25 22:20:52.330116
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:21:02.228140
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    str_1 = 'def fn():\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    var_2 = module_0.parse(str_1)
    var_3 = var_1.body[0]
    var_3.decorator_list = var_2.body[0].decorator_list
    var_3.name = var_2.body[0].name
    var_3.args = var_2.body

# Generated at 2022-06-25 22:21:09.638121
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    assert var_1.__class__ == module_0.FunctionDef


# Generated at 2022-06-25 22:21:17.951812
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    var_2 = isinstance(var_1, module_0.FunctionDef)
    assert var_2 == True

if (__name__ == '__main__'):
    test_case_0()

    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:21:27.240258
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


@snippet
async def return_from_coroutine(return_value):
    let(exc)
    exc = StopAsyncIteration()
    exc.value = return_value
    raise exc


# Generated at 2022-06-25 22:21:31.919108
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:21:46.390270
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0.parse('def fn():\n    yield 5\n    return 1')
    module_0.parse('def fn():\n    yield from [5, 6, 7]\n    return 1')
    module_0.parse('def fn():\n    return 1\n    yield 5')
    module_0.parse('def fn():\n    return 1\n    yield from [5, 6, 7]')
    module_0.parse('def fn(a):\n    yield 5\n    return a')
    module_0.parse('def fn(a):\n    yield from [5, 6, 7]\n    return a')
    module_0.parse('def fn(a):\n    return a\n    yield 5')

# Generated at 2022-06-25 22:21:49.849230
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    var_2 = var_1.body
    var_3 = var_2[0]
    var_4 = var_3.body
    var_5 = var_4[0]
    var_6 = var_5.value


# Generated at 2022-06-25 22:21:58.137951
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    var_2 = var_1
    var_3 = var_2
    var_4 = var_3.body
    var_5 = var_4[0]
    var_6 = var_5.body
    var_7 = var_6[0]
    var_8 = var_6[1]
    var_9 = var_6[2]
    var_10 = var_6[3]
    var_11 = var_6[4]

# Generated at 2022-06-25 22:21:59.451600
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    var_0 = test_case_0()

test_case_0()

# Generated at 2022-06-25 22:22:04.632893
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test for argument "node" type "FunctionDef"
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:22:06.873225
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
        assert True
    except:
        assert False

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:22:07.828103
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:16.709955
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    global var_1

    def fn_0():
        var_2 = None
        var_2 = test_case_0()

    fn_0()
    var_3 = var_1.body
    var_4 = var_3[0]

    assert(isinstance(var_4, module_0.Return))
    assert(var_4.value.ctx == module_0.Load)
    var_5 = var_4.value.value

    assert(isinstance(var_5, module_0.Call))
    str_1 = 'StopIteration'
    var_6 = var_5.func
    var_7 = var_6.id

    assert(var_7 == str_1)
    var_8 = var_5.args
    var_9 = var_8[0]


# Generated at 2022-06-25 22:22:20.371629
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print('\n========= TEST CASE 0 =========')
    var_2 = test_case_0()
    print('Output:\n%s\n' % (var_2))
    assert 0

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:22:24.009153
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    pass


# Generated at 2022-06-25 22:22:36.695565
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:22:41.631599
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn(arg1: int) -> int:\n    return arg1'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    #assert var_1 == module_0.parse(str_0)

# Generated at 2022-06-25 22:22:45.884414
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:22:49.379497
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:22:57.195710
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    assert(var_1.body[0].lineno == 2)
    assert(var_1.body[3].value.n == 5)
    assert(var_1.body[0].col_offset == 0)
    assert(var_1.body[2].lineno == 2)
    assert(var_1.body[2].col_offset == 4)
    assert(var_1.body[2].value.ctx == 1)

# Generated at 2022-06-25 22:23:01.797713
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:23:09.331519
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    str_1 = 'def fn():\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    var_2 = module_0.dump(var_0)
    var_3 = module_0.dump(var_1)
    assert var_2 == var_3


# Generated at 2022-06-25 22:23:13.253648
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:23:17.146744
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:23:21.195243
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    module_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(module_0)
    var_0 = return_from_generator_transformer_0.visit(module_0)


# Generated at 2022-06-25 22:23:37.678181
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    module_0.fix_missing_locations(var_0)
    str_1 = module_0.unparse(var_0)
    str_2 = 'def fn():\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n'
    var_1 = return_from_generator_transformer_0.visit(var_0)
    module_0.fix_missing_locations(var_1)
    str_3 = module_0.unparse(var_1)
    var_2 = (str_2 == str_3)

# Generated at 2022-06-25 22:23:41.459181
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    str_1 = module_0.dump(var_0)
    str_2 = module_0.dump(var_0)
    var_1 = ReturnFromGeneratorTransformer(var_0)



# Generated at 2022-06-25 22:23:45.116061
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_1)
    assert return_from_generator_transformer_0.tree == var_1
    assert return_from_generator_transformer_0.target == (3, 2)

test_case_0()
test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-25 22:23:51.817270
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = "def fn():\n    return 5"
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    module_0.dump(var_1)
    str_1 = module_0.to_source(var_1)
    str_2 = "def fn():\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"
    assert str_1 == str_2


# Generated at 2022-06-25 22:23:55.022749
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:23:57.036236
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_2 = module_0.parse('def fn():\n    return 5')
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(var_2)


# Generated at 2022-06-25 22:24:00.201553
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:24:07.475414
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

    # Check if ast.Module type
    assert isinstance(var_1, ast.Module)
    # Check if ast.FunctionDef type
    assert isinstance(var_1.body[0], ast.FunctionDef)
    # Check if ast.Return type
    assert isinstance(var_1.body[0].body[0], ast.Return)



# Generated at 2022-06-25 22:24:15.148512
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    # var_1 should be:
    #     def fn():
    #         exc = StopIteration()
    #         exc.value = 5
    #         raise exc
    # but doesn't really matter
    # because it's not used anywhere and isn't tested
    return None

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer()
    test_case_0()

# Generated at 2022-06-25 22:24:16.582022
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)


# Generated at 2022-06-25 22:24:30.751479
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        return 5
    
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    str_1 = str(var_1)
    print(str_1)


# Generated at 2022-06-25 22:24:34.627320
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:24:37.217980
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)


# Generated at 2022-06-25 22:24:39.942587
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)


# Generated at 2022-06-25 22:24:44.203683
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    del var_1

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:24:46.611865
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    return 5'
    var_0 = ast.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)


# Generated at 2022-06-25 22:24:47.346145
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = 1


# Generated at 2022-06-25 22:24:49.887846
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    assert return_from_generator_transformer_0.tree == var_0


# Generated at 2022-06-25 22:24:50.633819
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:24:56.188057
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    return 5'

    var_0 = module_0.parse(str_0)
    str_1 = "def fn():\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"

    var_1 = module_0.parse(str_1)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    assert(return_from_generator_transformer_0._target == (3, 2))

# Generated at 2022-06-25 22:25:09.368223
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    assert return_from_generator_transformer_0.tree == var_0


# Generated at 2022-06-25 22:25:12.643603
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:25:19.777883
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Module level variable test_case_0 has type ast.Module
#assert isinstance(test_case_0, ast.Module)

# TODO: fix, sometimes works other not
# Module level variable test_case_0.body[0] has type ast.FunctionDef
#assert isinstance(test_case_0.body[0], ast.FunctionDef)

# Module level variable test_case_0.body[0].body[0] has type ast.Expr
#assert isinstance(

# Generated at 2022-06-25 22:25:20.801058
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-25 22:25:26.148462
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

    str_1 = 'def fn():\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    var_2 = module_0.parse(str_1)
    assert_equal(var_1, var_2)


# Generated at 2022-06-25 22:25:30.631775
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

test_case_0()
test_ReturnFromGeneratorTransformer_visit_FunctionDef()
print('Unit Tests Done')

# Generated at 2022-06-25 22:25:37.914709
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = test_case_0()
    assert isinstance(module_0, module_0.Module)
    assert len(module_0.body) == 1
    assert isinstance(module_0.body[0], module_0.FunctionDef)
    assert module_0.body[0].name == 'fn'
    assert len(module_0.body[0].args.args) == 0
    assert len(module_0.body[0].body) == 3
    assert isinstance(module_0.body[0].body[0], module_0.Expr)
    assert isinstance(module_0.body[0].body[0].value, module_0.Call)
    assert isinstance(module_0.body[0].body[0].value.func, module_0.Name)

# Generated at 2022-06-25 22:25:39.078420
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = ReturnFromGeneratorTransformer(module_0.parse('def fn():\n    return 5'))

# Generated at 2022-06-25 22:25:40.243383
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():

    import astor
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 22:25:41.193398
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass


# Generated at 2022-06-25 22:25:55.506885
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:25:58.091518
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = ast.parse
    var_1 = ReturnFromGeneratorTransformer(var_0)
    assert var_1.tree == var_0
    assert var_1._tree_changed is False
    assert var_1.target == (3, 2)


# Generated at 2022-06-25 22:26:00.613848
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    assert var_0 == return_from_generator_transformer_0._tree


# Generated at 2022-06-25 22:26:03.398623
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn0():
        return 5
    var_0 = module_0.parse(fn0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:26:05.188843
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)
    pass


# Generated at 2022-06-25 22:26:12.632465
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:26:14.075382
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()
    return None

# Main function

# Generated at 2022-06-25 22:26:17.964557
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:26:29.541420
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Call to _find_generator_returns() ...
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = var_0.body[0]
    var_2 = return_from_generator_transformer_0._find_generator_returns(var_1)
    var_3 = return_from_generator_transformer_0.visit(var_0)
    assert var_2 == [(var_1, var_1.body[1])]
    # Call to visit() ...
    str_1 = 'def fn():\n    yield 1\n    return 5'
    var_

# Generated at 2022-06-25 22:26:33.074057
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# For testing:
if __name__ == '__main__':
    import sys
    import nose2
    module_name = sys.modules[__name__].__file__
    nose2.main(argv=['nose2', '-s', '-v', module_name, '-A', 'not test_case_0 and not test_ReturnFromGeneratorTransformer'])

# Generated at 2022-06-25 22:26:43.957548
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:26:46.809540
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:26:47.618678
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass


# Generated at 2022-06-25 22:26:53.774892
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Simple function with return
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

    exp_str = 'def fn():\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    assert var_1 == module_0.parse(exp_str)

    # Simple generator with return
    str_0 = 'def fn():\n    yield 5\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGener

# Generated at 2022-06-25 22:26:56.292594
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:26:59.416237
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_5 = module_0.parse('def f():\n    return 5')
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_5)
    var_6 = return_from_generator_transformer_0.visit(var_5)
    assert isinstance(var_6, module_0.Module)


# Generated at 2022-06-25 22:27:00.318301
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Call function "test_case_0"
    test_case_0()

# Generated at 2022-06-25 22:27:01.288220
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = return_from_generator_transformer.ReturnFromGeneratorTransformer()


# Generated at 2022-06-25 22:27:02.343224
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Used with the help of the generate_test_case.py script

# Generated at 2022-06-25 22:27:02.943518
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_2 = test_case_0()

# Generated at 2022-06-25 22:27:18.311238
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    for i in range(1):\n        yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:27:20.592192
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:27:22.984235
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:27:28.145714
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_0.body[0].body[0].value = module_0.parse('f()').body[0].value
    exception_0 = None
    try:
        var_1 = return_from_generator_transformer_0.visit(var_0)
    except Exception as exception_0:
        pass
    else:
        raise Exception('ExpectedTypeError')
    assert exception_0 is not None


# Generated at 2022-06-25 22:27:32.136861
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        return 5

    var_0 = module_0.parse(fn.__code__.co_code)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    test_case_0()
    assert return_from_generator_transformer_0._tree_changed == False
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:27:34.840783
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:27:40.681965
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    var_2 = 'def fn():\n    return 5'
    var_3 = module_0.parse(var_2)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(var_3)
    return_from_generator_transformer_1._find_generator_returns = lambda var_5: [((module_0.FunctionDef(var_5.name, var_5.args, var_5.body, var_5.decorator_list), [module_0.Return(module_0.Constant(5))])[1])]

# Generated at 2022-06-25 22:27:45.288968
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

    expected_result = 'def fn():\n\texc = StopIteration()\n\texc.value = 5\n\traise exc'
    assert_string = str(var_1.body[0].body[1])
    assert assert_string == expected_result, 'Expected: {}, but got: {}'.format(expected_result, assert_string)


# Generated at 2022-06-25 22:27:48.550350
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():

    try:
        # test case with 1 argument
        assert test_case_0() == None
    except:
        print("Unable to run test case")

test_ReturnFromGeneratorTransformer()
 
# EOF

# Generated at 2022-06-25 22:27:56.818458
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    var_2 = var_1.body[0]
    assert isinstance(var_2, module_0.FunctionDef)
    assert var_2.name == 'fn'
    var_3 = var_2.body[0]
    assert isinstance(var_3, module_0.Expr)
    var_4 = var_3.value
    assert isinstance(var_4, module_0.Call)
    var_5 = var_4.func

# Generated at 2022-06-25 22:28:09.416456
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    try:
        ReturnFromGeneratorTransformer_0 = ReturnFromGeneratorTransformer(None)
    except RuntimeError:
        pass
    try:
        ReturnFromGeneratorTransformer_1 = ReturnFromGeneratorTransformer(3)
    except RuntimeError:
        pass
