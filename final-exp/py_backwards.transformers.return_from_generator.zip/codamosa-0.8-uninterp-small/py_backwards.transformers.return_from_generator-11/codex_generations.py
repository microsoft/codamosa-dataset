

# Generated at 2022-06-25 22:18:24.873559
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(
        name='fn',
        args=module_0.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            module_0.Yield(
                value=module_0.Num(n=1)
            ),
            module_0.Return(
                value=module_0.Num(n=5)
            )
        ],
        decorator_list=[],
        returns=None
    )
    function_

# Generated at 2022-06-25 22:18:30.293756
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(arguments_0=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)

    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:18:37.432111
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0.body = [module_0.Yield(), module_0.Return()]
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    module_0.FunctionDef(None, None, function_def_0.body, [module_0.Assign()])
    return return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:18:48.033779
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    module_1 = module_0.Module()
    function_def_0 = module_0.FunctionDef()
    module_1.body.append(function_def_0)
    function_def_0.name = "fn"
    function_def_0.body.append(module_0.Expr())
    module_0.Expr().value = module_0.Yield()
    function_def_0.body.append(module_0.Return())
    module_0.Return().value = module_0.Num()
    module_0.Num().n = 5
    return_from_generator_transformer_0.visit_

# Generated at 2022-06-25 22:18:55.028717
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    module_1 = module_0.Module()
    function_def_0 = module_0.FunctionDef()
    module_0.copy_location(module_1, function_def_0)
    function_def_0.name = 'fn'
    function_def_0.args = module_0.arguments()
    function_def_0.args.vararg = None
    function_def_0.args.kwarg = None
    function_def_0.args.defaults = []
    function_def_0.args.kw_defaults = []
    function_def_0.args.args = []
    function_def_0

# Generated at 2022-06-25 22:18:56.812043
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:19:01.653085
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    # TODO: check output value/type


# Generated at 2022-06-25 22:19:10.818576
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='bar', 
    args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Pass()], decorator_list=[], returns=None)
    return_from_generator_transformer_0.visit(function_def_0)
    assert function_def_0.name == 'bar'
    
    

# Generated at 2022-06-25 22:19:14.908163
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    def fn():
        yield 1
        return 5
    fn()

    # TODO: Figure out how to write the test

    # assert False


# Generated at 2022-06-25 22:19:20.622665
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:42.270666
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='my_fn')

    # need to set the inner objects (to do: automate this as much as possible)
    function_def_0.args = module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])

    function_def_0.body.append(module_0.Print())

    return_from_generator_transformer_0.visit(function_def_0)

# Generated at 2022-06-25 22:19:47.133520
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:19:54.763220
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # AssertionError: The value of the given snippet is not a function definition.
    # assert \
    #     return_from_generator_transformer_0.visit_FunctionDef('test_return_from_generator_transformer_0') == \
    #     'def test_return_from_generator_transformer_0():\n' \
    #     '\tyield 1\n' \
    #     '\texc = StopIteration()\n' \
    #     '\texc.value = 5\n' \
    #     '\traise exc'
    pass


# Generated at 2022-06-25 22:20:02.931273
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    node_0 = module_0.FunctionDef()
    node_0.name = module_0.Name()
    node_0.name.id = module_0.Str()
    node_0.decorator_list = module_0.List()
    node_0.args = module_0.arguments()
    node_0.args.args = module_0.List()
    node_0.args.vararg = module_0.Name()
    node_0.args.vararg.id = module_0.Str()
    node_0.args.kwonlyargs = module_0.List()
    node_0.args.kw

# Generated at 2022-06-25 22:20:06.158337
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # Other tests, not from the target


# Generated at 2022-06-25 22:20:16.182909
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Initialize the AST
    a_s_t_0 = ast.AST()
    # Initialize the ReturnFromGeneratorTransformer with the AST
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_0 = ast.AST(1, 2)
    # Initialize the AST
    a_s_t_1 = ast.AST(2, 3)
    # Initialize the AST
    a_s_t_2 = ast.AST(3, 4)
    # Initialize the AST
    a_s_t_3 = ast.AST(4, 5)
    # Initialize the AST
    a_s_t_4 = ast.AST(5, 6)
    # Initialize the AST

# Generated at 2022-06-25 22:20:20.929704
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    


# Generated at 2022-06-25 22:20:23.640186
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef()



# Generated at 2022-06-25 22:20:26.741901
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(module_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(module_0.FunctionDef())
    pass

# Generated at 2022-06-25 22:20:35.578953
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Case 1:

# Generated at 2022-06-25 22:20:48.726623
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Initialization of var test
    test = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    function_def_0 = ast.FunctionDef()
    # Visit node
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    # Check result
    assert function_def_1.body == [], f"Expected: {[]}, but got: {function_def_1.body}"
    return


# Generated at 2022-06-25 22:20:55.644314
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST(body=[])
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:21:01.987589
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = ast.FunctionDef()
    a_s_t_0 = ast.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    assert(isinstance(function_def_0, ast.FunctionDef))
    assert(isinstance(function_def_1, ast.FunctionDef))


# Generated at 2022-06-25 22:21:08.695399
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:10.261747
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:21:17.230586
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert isinstance(function_def_1, module_0.FunctionDef)

# Testing visit_alias

# Generated at 2022-06-25 22:21:24.415118
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:30.751931
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    #assert function_def_1.body == function_def_0.body


# Generated at 2022-06-25 22:21:35.697724
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    print(function_def_1)
    assert 0


# Generated at 2022-06-25 22:21:42.014854
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    if not(function_def_1==function_def_0):
        raise ValueError


test_case_0()
test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:22:01.634550
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:22:05.779735
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:10.061025
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef() 
    a_s_t_0 = module_0.AST() 
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)  
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:15.212255
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = module_0
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:19.709483
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:22:27.007491
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    main = function_def = module.FunctionDef()
    a_s_t = module.AST(body=[function_def])
    transformer = ReturnFromGeneratorTransformer(a_s_t)

    # Test if statement
    if_statement = module.If()
    function_def.body.append(if_statement)

    # This will be ignored, not in generator
    if_statement.body.append(module.Return())

    # This will be replaced
    if_statement.body.append(module.Yield())
    if_statement.body.append(module.Return())

    # Test while statement
    while_statement = module.While()
    function_def.body.append(while_statement)

    # This will be ignored, not in generator
    while_statement.body.append(module.Return())

    # This will be

# Generated at 2022-06-25 22:22:32.203381
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    function_def_0 = module_0.FunctionDef()
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    assert function_def_1 is None


# Generated at 2022-06-25 22:22:36.512267
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    print(function_def_1)

# Generated at 2022-06-25 22:22:43.716498
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a = module_0.Name()
    a.id = 'a'
    b = module_0.Name()
    b.id = 'b'
    function_def_0 = module_0.FunctionDef()
    function_def_0.name = 'fn'
    function_def_0.args = module_0.arguments()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:22:48.519182
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_2 = ReturnFromGeneratorTransformer()
    function_def_2 = module_0.FunctionDef()
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_2.modifier = a_s_t_1
    function_def_3 = return_from_generator_transformer_2.visit_FunctionDef(function_def_2)


# Generated at 2022-06-25 22:23:20.357707
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:24.642164
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:29.854597
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:23:33.668379
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:41.827462
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Transfomer to test
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(module_0.AST())
    # Test FunctionDef
    function_def_0 = module_0.FunctionDef()
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert(isinstance( function_def_1, module_0.FunctionDef ))
    # Test FunctionDef with a YieldFrom inside
    function_def_0 = module_0.FunctionDef()
    yield_from_0 = module_0.YieldFrom()
    function_def_0.body.append(yield_from_0)

# Generated at 2022-06-25 22:23:43.682047
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:23:50.296926
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # INITIALIZATION
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    # END OF INITIALIZATION

    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    # Asserts
    assert function_def_1 is function_def_0
    # END OF Asserts


# Generated at 2022-06-25 22:23:54.207867
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:23:55.712910
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  # Let's make sure that we can generate an ordinary random number.
  assert 0 <= random.randrange(100) < 100, 'Test failed'

# Generated at 2022-06-25 22:24:02.183579
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

if __name__ == '__main__':
    import sys, os
    sys.path.append(os.path.abspath(__file__ + "/../../"))
    from src.gen import gen_transformer
    gen_transformer.generate(ReturnFromGeneratorTransformer)

# Generated at 2022-06-25 22:25:14.991063
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:18.784332
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:25:24.460411
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert (function_def_1 is function_def_0)
    assert (function_def_0.body is None)
    assert (function_def_1.body is None)


# Generated at 2022-06-25 22:25:27.961339
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:25:31.799267
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is function_def_0

# Generated at 2022-06-25 22:25:39.054137
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0.decorator_list = [module_0.Name()]
    function_def_0.args = module_0.arguments()
    function_def_0.body = [module_0.Return(module_0.Name())]
    function_def_2 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert len(function_def_2.body) == 4
    assert isinstance(function_def_2, module_0.FunctionDef)



# Generated at 2022-06-25 22:25:43.409595
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:25:47.376752
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    root = ast.parse('def fn(): pass')
    transformer = ReturnFromGeneratorTransformer(root)
    transformer._find_generator_returns(root.body[0])
    def fn():
        pass
    expected = fn
    result = transformer.visit_FunctionDef(root.body[0])
    assert result == expected


# Generated at 2022-06-25 22:25:55.179785
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def _check_visit_FunctionDef(unit_test_var_0 : module_0.FunctionDef):
        a_s_t_0 = module_0.AST()
        return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
        function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(unit_test_var_0)

    test_case_0()
    function_def_0 = module_0.FunctionDef()
    _check_visit_FunctionDef(function_def_0)
    function_def_1 = module_0.FunctionDef()
    _check_visit_FunctionDef(function_def_1)
    function_def_2 = module_0.FunctionDef()
    _check_visit

# Generated at 2022-06-25 22:25:55.856258
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()