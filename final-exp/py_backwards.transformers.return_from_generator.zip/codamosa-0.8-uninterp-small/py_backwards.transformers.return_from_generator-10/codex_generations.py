

# Generated at 2022-06-25 22:18:21.454058
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:18:26.423469
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    def test_0():

        def fn0():
            return 1

        a_s_t_1 = fn0()
        a_s_t_2 = return_from_generator_transformer_0.visit(a_s_t_1)

# Generated at 2022-06-25 22:18:36.016006
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    class_declaration_0 = ReturnFromGeneratorTransformer(None)

    function_def_0 = ast.FunctionDef(name='test1', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Yield(value=ast.Num(n=1)), ast.Return(value=ast.Num(n=5))], decorator_list=[], returns=None)

    assert_equal(class_declaration_0.visit_FunctionDef(function_def_0).body[0].__class__.__name__, 'Yield')
    assert_equal(class_declaration_0.visit_FunctionDef(function_def_0).body[1].__class__.__name__, 'Assign')
   

# Generated at 2022-06-25 22:18:46.300001
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    a_s_t_1 = ast.FunctionDef()
    a_s_t_1.name = "foo"
    a_s_t_1.args = ast.arguments()
    a_s_t_1.args.args = []
    a_s_t_1.args.vararg = None
    a_s_t_1.args.kwonlyargs = []
    a_s_t_1.args.kw_defaults = []
    a_s_t_1.args.kwarg = None
    a_s_t_1.args.defaults = []
    a_s_t_1.returns = None


# Generated at 2022-06-25 22:18:54.354180
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Test for the cases where return_from_generator_transformer_0.visit_FunctionDef is called with an instance of FunctionDef instead of an instance of Module
    a_s_t_1 = ast.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1)

    # Test for the cases where return_from_generator_transformer_0.visit_FunctionDef is called with an instance of Module instead of an instance of FunctionDef
    a_s_t_2 = ast.Module()

# Generated at 2022-06-25 22:18:58.552220
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    var_0 = None
    ReturnFromGeneratorTransformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = ast.FunctionDef()
    ReturnFromGeneratorTransformer_0.visit_FunctionDef(var_1)

# Generated at 2022-06-25 22:18:59.484133
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:19:07.455875
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = ast.parse("def fn():\n    yield 1").body[0]
    b_y_p_a_s_s_0 = a_s_t_0
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(b_y_p_a_s_s_0)
    a_s_t_1 = ast.parse("def fn():\n    yield 1").body[0]
    return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1)

# Generated at 2022-06-25 22:19:14.491916
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test if call of method on instance returns correct value
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)
    generator_returns_0 = None
    try:
        parent_0 = None
        return_0 = None
        return_from_generator_transformer_0.visit_FunctionDef(generator_returns_0, parent_0, return_0)
    except:
        pass

    generator_returns_0 = None
    assert return_from_generator_transformer_0.visit_FunctionDef(generator_returns_0) is None



# Generated at 2022-06-25 22:19:16.132553
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)
    functiondef_0 = None
    functiondef_1 = return_from_generator_transformer_0.visit_FunctionDef(functiondef_0)

# Generated at 2022-06-25 22:19:28.654992
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:36.055014
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = ast.parse('def foo():\n    yield 1\n    return 2')
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    foo = return_from_generator_transformer_0.visit(a_s_t_0.body[0])
    bar = None
    try:
        bar = ast.parse("""def foo():
    yield 1
    exc = StopIteration()
    exc.value = 2
    raise exc""")
    except:
        pass
    try:
        assert foo == bar
    except:
        pass

# Generated at 2022-06-25 22:19:40.493122
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = ast.parse("def fn():\n    yield 1")
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    assert return_from_generator_transformer_0.visit_FunctionDef(function_def_0) == ast.parse("def fn():\n    yield 1")

# Generated at 2022-06-25 22:19:41.225032
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

# Generated at 2022-06-25 22:19:51.560835
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    a_s_t_1 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = ast.FunctionDef(
        name='fn_0',
        args=None, body=[], decorator_list=[], returns=None)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert isinstance(function_def_0, ast.FunctionDef)
    assert function_def_0.name == 'fn_0'
    assert not function_def_0.args
    assert function_def_0.body == []
    assert function_def_0.decorator_list == []
    assert function_

# Generated at 2022-06-25 22:19:55.383046
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test function should raise an exception if tree is changed
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0.visit_FunctionDef(a_s_t_0) is None

# Generated at 2022-06-25 22:20:03.457585
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = ast.parse('def fn(): yield 1; return 5')
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = return_from_generator_transformer_0.visit(a_s_t_0)

    fn_0 = a_s_t_1.body[0]
    assert isinstance(fn_0, ast.FunctionDef)
    assert fn_0.name == 'fn'

    assert len(fn_0.body) == 3

    yield_0 = fn_0.body[0]
    assert isinstance(yield_0, ast.Yield)
    assert yield_0.value.n == 1

    assert_0 = fn_0.body[1]


# Generated at 2022-06-25 22:20:13.752161
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    from typed_ast import ast3
    from typed_ast import convert
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from ..utils.snippet import snippet
    def obj(name, value=None):
        """Create a dict for an object in the source code."""
        node = {
            "__class__": "Name",
            "ctx": {"__class__": "Load"},
            "id": name
        }
        if value is not None:
            node['value'] = value
        return node

    def fn(name, *args: dict, body: list) -> dict:
        """Create a dict for a function in the source code."""

# Generated at 2022-06-25 22:20:18.413164
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_1 = None
    a_s_t_2 = return_from_generator_transformer_0.visit_FunctionDef(function_def_1)


# Generated at 2022-06-25 22:20:23.211999
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = ast.FunctionDef(args=None, body=[None], decorator_list=[], name="fn", returns=None)
    assert return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1) is None


# Generated at 2022-06-25 22:20:29.799016
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:20:30.707308
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:31.772170
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:20:34.353765
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test():
        a_s_t_0 = module_0.AST()
        return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)



# Generated at 2022-06-25 22:20:43.970461
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Code from: ../samples/sample-0-origin.py
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    def fn():
        yield 1
        return 5


# Generated at 2022-06-25 22:20:48.933831
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is None
    assert return_from_generator_transformer_0.get_tree_changed() is False


# Generated at 2022-06-25 22:20:53.873977
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Test constructor
    assert ReturnFromGeneratorTransformer([module_0.AST()])._tree is not None
    # Test constructor
    assert ReturnFromGeneratorTransformer(module_0.AST())._tree is not None
    pass


# Generated at 2022-06-25 22:20:57.749163
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert isinstance(return_from_generator_transformer_0, ReturnFromGeneratorTransformer)


# Generated at 2022-06-25 22:21:05.166041
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    target = (3, 2)
    a_s_t_0 = module_0.AST()
    assert a_s_t_0 != None  # In case there are no asserts in the function
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0 != None  # In case there are no asserts in the function
    assert return_from_generator_transformer_0.target == target  # In case there are no asserts in the function
    assert return_from_generator_transformer_0.a_s_t == a_s_t_0  # In case there are no asserts in the function


# Generated at 2022-06-25 22:21:13.464434
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is None


# Generated at 2022-06-25 22:21:19.965962
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()


# Generated at 2022-06-25 22:21:22.865532
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()


# Generated at 2022-06-25 22:21:29.409965
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 == None

# Generated at 2022-06-25 22:21:30.265087
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:21:31.609234
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    with pytest.raises(UnboundLocalError):
        test_case_0()

# Generated at 2022-06-25 22:21:34.078262
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(ReturnFromGeneratorTransformer(a_s_t_0), ReturnFromGeneratorTransformer)


# Generated at 2022-06-25 22:21:37.478919
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0 is not None


# Generated at 2022-06-25 22:21:38.307749
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()


# Generated at 2022-06-25 22:21:43.010112
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_2 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:46.326315
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3 as ast
    a_s_t_0 = ast.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    
    # Test case with args
    
    # Test case without args
    


# Generated at 2022-06-25 22:21:56.948528
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:03.238135
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
  
    # assert function_def_1. == expected_value

test_case_0()

# Generated at 2022-06-25 22:22:04.337954
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Unit tests for ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:22:12.631639
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    assert return_from_generator_transformer_0.visit_FunctionDef(function_def_0) == function_def_0

# Generated at 2022-06-25 22:22:19.156687
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_2 = None
    try:
        function_def_3 = return_from_generator_transformer_1.visit_FunctionDef(function_def_2)
    except:
        function_def_3 = None
    try:
        assert function_def_3 == function_def_2
    except:
        pass


# Generated at 2022-06-25 22:22:21.309525
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:29.600784
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    a_s_t_0.return_from_generator_transformer_0 = return_from_generator_transformer_0
    a_s_t_0.function_def_0 = function_def_0
    a_s_t_0.function_def_1 = None
    def call_a_s_t_0_fn_0():
        a_s_t_0.function_def_1 = a_s_t_0.return_from_generator_transformer_0.visit_FunctionDef(a_s_t_0.function_def_0)

   

# Generated at 2022-06-25 22:22:30.357998
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:31.375436
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 22:22:35.090103
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:52.365030
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_cases = [test_case_0, ]
    for test_case in test_cases:
        test_case()

# Generated at 2022-06-25 22:22:54.794895
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:58.005004
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(module_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:23:06.553734
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Create a FunctionDef object
    function_def_0 = module_0.FunctionDef(None, None, module_0.arguments(None, None, None, None), [], None, None)
    # Create a AST object
    a_s_t_0 = module_0.AST()
    # Create a ReturnFromGeneratorTransformer object
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # Call method visit_FunctionDef of class ReturnFromGeneratorTransformer with parameter function_def_0
    returned_value_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:09.258478
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:10.256665
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:23:14.913025
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert isinstance(return_from_generator_transformer_0, ReturnFromGeneratorTransformer)
    assert isinstance(return_from_generator_transformer_0, BaseNodeTransformer)


# Generated at 2022-06-25 22:23:15.692144
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:23:18.943903
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert isinstance(return_from_generator_transformer_0, ReturnFromGeneratorTransformer)


# Generated at 2022-06-25 22:23:19.460752
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-25 22:23:50.801612
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:51.545954
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:23:54.691801
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:57.224537
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(tree_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(tree_0)


# Generated at 2022-06-25 22:24:05.240767
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import typed_ast
    from . import ast3
    from . import node_transformer
    import inspect
    import ast

    a_s_t_0 = typed_ast.AST()
    return_from_generator_transformer_0 = node_transformer.ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:24:09.495560
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is None
    pass


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:24:18.262545
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Test for constructor
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert_equal(return_from_generator_transformer_0.tree.version, (3, 2))
    assert_equal(return_from_generator_transformer_0.tree.str_type, "ast.AST")
    assert_equal(return_from_generator_transformer_0.tree, a_s_t_0)
    assert_equal(return_from_generator_transformer_0.target, (3, 2))
    assert_equal(return_from_generator_transformer_0.version, (3, 2))

# Generated at 2022-06-25 22:24:20.874021
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

test_case_0()
test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-25 22:24:21.592086
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
    return 0


# Generated at 2022-06-25 22:24:30.140944
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    arg_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(arg_0)
    # Test attributes are set correctly
    assert return_from_generator_transformer_0._tree_changed == False
    assert return_from_generator_transformer_0._tree == None
    assert return_from_generator_transformer_0._target == (3, 2)
    # Test __str__ method
    return_from_generator_transformer_0_str = str(return_from_generator_transformer_0)
    # Test __repr__ method
    return_from_generator_transformer_0_repr = repr(return_from_generator_transformer_0)

# Generated at 2022-06-25 22:25:25.888968
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:25:30.488979
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    """Test for ReturnFromGeneratorTransformer.__init__."""
    # Initialization
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Initialization
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)


# Generated at 2022-06-25 22:25:34.672420
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:36.517526
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_2 = module_0.AST()
    return_from_generator_transformer_2 = ReturnFromGeneratorTransformer(a_s_t_2)


# Generated at 2022-06-25 22:25:37.202453
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:25:38.859063
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .transformer_test_utils import expecting_no_warnings

    # This class cannot be tested
    assert False, "TODO: ReturnFromGeneratorTransformer"


# Generated at 2022-06-25 22:25:41.257326
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:25:41.756091
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert True

# Generated at 2022-06-25 22:25:42.644112
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:25:47.177210
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    root = None
    return_from_generator_transformer = ReturnFromGeneratorTransformer(root)
    assert return_from_generator_transformer.root == None
    assert return_from_generator_transformer.tree_changed == False
    assert return_from_generator_transformer.inplace_changes == False
    assert return_from_generator_transformer.target == (3, 2)


# Generated at 2022-06-25 22:27:54.242142
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is None

# Generated at 2022-06-25 22:27:56.876709
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # TODO: Add test for constructor for class ReturnFromGeneratorTransformer
    assert False, 'Test for constructor of class ReturnFromGeneratorTransformer not implemented'


# Generated at 2022-06-25 22:27:57.603405
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:28:01.404784
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is None


# Generated at 2022-06-25 22:28:07.690077
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0_checksum = hash(return_from_generator_transformer_0)
    assert return_from_generator_transformer_0_checksum == -9154656709420518860
    return_from_generator_transformer_0_class = return_from_generator_transformer_0.__class__.__name__
    assert return_from_generator_transformer_0_class == 'ReturnFromGeneratorTransformer'
