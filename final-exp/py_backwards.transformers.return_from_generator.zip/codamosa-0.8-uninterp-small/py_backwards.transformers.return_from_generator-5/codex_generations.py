

# Generated at 2022-06-25 22:18:24.960315
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef(name='fn',
                                   args=module_0.arguments(args=[],
                                                           vararg=None,
                                                           kwonlyargs=[],
                                                           kw_defaults=[],
                                                           kwarg=None,
                                                           defaults=[]),
                                   body=[module_0.Yield(value=module_0.Num(n=1))],
                                   decorator_list=[],
                                   returns=None)

# Generated at 2022-06-25 22:18:31.596448
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    function_def_0 = module_0.FunctionDef(return_from_generator_transformer_0.a_s_t_0, '', [], module_0.arguments(return_from_generator_transformer_0.a_s_t_0, [], None, None, []), [], [], module_0.Return(return_from_generator_transformer_0.a_s_t_0, module_0.Constant(return_from_generator_transformer_0.a_s_t_0, '')))
    body_0 = function_def_0.body
    body_0_0 = module

# Generated at 2022-06-25 22:18:38.734561
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test case for method visit_FunctionDef of class ReturnFromGeneratorTransformer.
    """
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0.name = "fn"
    function_def_0.body = [module_0.Yield()]

    return_0 = module_0.Return()
    return_0.value = module_0.Num(n=5)
    function_def_0.body.append(return_0)

    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_

# Generated at 2022-06-25 22:18:39.692019
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:18:49.461556
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Creation of a module
    module_0 = ast.parse("""\
    def fn(a, b):
        return a + b
    """)

    # Creation of a ReturnFromGeneratorTransformer
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()

    # Replacing node function_def_0 with a transformed node
    # (modification of the original node).
    module_0.body[0] = return_from_generator_transformer_0.visit(module_0.body[0])

    # Test
    assert module_0.body[0].body[0].value.value == module_0.body[0].args.args[0].id + module_0.body[0].args.args[1].id


# Generated at 2022-06-25 22:18:55.794185
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:00.678796
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    single_0_0 = return_from_generator_transformer_0.visit(function_def_0)


# Generated at 2022-06-25 22:19:10.818240
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    def_0 = module_0.FunctionDef('xxx', module_0.arguments([module_0.arg('self', None, None, []), module_0.arg('x', None, None, [])], None, None, []), [module_0.Expr(module_0.Call(module_0.Name('f', module_0.Load()), [module_0.Name('x', module_0.Load())], [], None, None))], [], None, None)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(def_0)

# Generated at 2022-06-25 22:19:15.220987
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    functiondef_0 = module_0.FunctionDef()
    functiondef_0 = return_from_generator_transformer_0.visit_FunctionDef(functiondef_0)

# Generated at 2022-06-25 22:19:20.750524
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()

    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    module_1 = module_0.Module([])

# Generated at 2022-06-25 22:19:36.509274
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name=None, args=None, body=None, decorator_list=[], returns=None)
    function_def_0_0 = function_def_0.body
    function_def_0_0.append(function_def_0_0.pop())
    function_def_0_0.append(function_def_0_0.pop())
    function_def_0_0.append(function_def_0_0.pop())
    function_def_0_0.append(function_def_0_0.pop())

# Generated at 2022-06-25 22:19:42.196737
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Input Parameters
    node_0 = module_0.FunctionDef()

    # Expected Output Parameters
    expected_node_0: ast.FunctionDef = module_0.FunctionDef()

    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    actual_node_0 = return_from_generator_transformer_0.visit_FunctionDef(node_0)
    assert actual_node_0 == expected_node_0

# Generated at 2022-06-25 22:19:52.492071
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    
    # ReturnFromGeneratorTransformer - node after visiting
    # Setup
    return_from_generator_transformer_0._tree_changed = True
    node_1 = module_0.FunctionDef()
    node_1.name = "node_1"
    node_1.body = [ ]
    node_1.decorator_list = [ ]
    node_1.args = module_0.arguments()
    node_1.args.args = [ ]
    node_1.args.defaults = [ ]
    node_1.args.kwonlyargs = [ ]

# Generated at 2022-06-25 22:20:00.980247
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Test case with empty body
    function_node_0 = module_0.parse("def foo():\n  pass\n")
    function_node_0 = return_from_generator_transformer_0.visit_FunctionDef(function_node_0)

    # Test case - return first
    function_node_1 = module_0.parse("\n\ndef foo():\n  return 1\n  yield 1\n")
    function_node_1 = return_from_generator_transformer_0.visit_FunctionDef(function_node_1)

    # Test case - return nonempty

# Generated at 2022-06-25 22:20:06.624669
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='fn', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Expr(value=module_0.Call(func=module_0.Name(id='', ctx=module_0.Load()), args=[], keywords=[]))], decorator_list=[], returns=None)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:20:16.637487
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_2 = ast.AST()
    return_from_generator_transformer_2 = ReturnFromGeneratorTransformer(a_s_t_2)
    module_1 = ast.parse('def fn():\n')
    module_2 = ast.parse('return\n')
    module_3 = ast.parse('yield\n')
    module_4 = ast.parse('None\n')
    return_from_generator_transformer_2.visit_FunctionDef(module_1)
    return_from_generator_transformer_2.visit_FunctionDef(module_2)
    return_from_generator_transformer_2.visit_FunctionDef(module_3)

# Generated at 2022-06-25 22:20:20.403021
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = ast.parse('def foo():\n    bar = 1\n    return bar')
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    return_from_generator_transformer_0.visit(module_0)



# Generated at 2022-06-25 22:20:22.202718
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Tested with PY2 and 3, but more tests are needed
    from typed_ast import ast3
    from typed_ast import convert
    from .test_helpers import code_equal, dump_ast

# Generated at 2022-06-25 22:20:29.799192
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(
        name='foo', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Return(value=module_0.Num(n=2))], decorator_list=[], returns=None)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    name_0 = function_def_1.name
    assert name_0 == 'foo'
    args_0 = function_

# Generated at 2022-06-25 22:20:36.341959
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    f_a_s_t_0 = module_0.FunctionDef()
    f_a_s_t_0.body = [module_0.Return()]
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(f_a_s_t_0)
    print(return_from_generator_transformer_0._tree_changed)


# Generated at 2022-06-25 22:20:48.702162
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:20:54.993288
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  a_s_t_0 = module_0.AST()
  # Testing constructor of class ReturnFromGeneratorTransformer
  return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
  assert (return_from_generator_transformer_0) != (None)


# Generated at 2022-06-25 22:20:55.844353
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:57.864964
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Main function
if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-25 22:21:05.631058
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    extract_return_0 = \
        ReturnFromGeneratorTransformer(module_0.AST())

    extract_return_1 = \
        ReturnFromGeneratorTransformer(module_0.AST())

    extract_return_2 = \
        ReturnFromGeneratorTransformer(module_0.AST())

    extract_return_3 = \
        ReturnFromGeneratorTransformer(module_0.AST())

    extract_return_4 = \
        ReturnFromGeneratorTransformer(module_0.AST())

    extract_return_5 = \
        ReturnFromGeneratorTransformer(module_0.AST())

    extract_return_6 = \
        ReturnFromGeneratorTransformer(module_0.AST())

    extract_return_7 = \
        ReturnFromGeneratorTransformer(module_0.AST())


# Generated at 2022-06-25 22:21:12.474437
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert isinstance(return_from_generator_transformer_0, ReturnFromGeneratorTransformer)


# Generated at 2022-06-25 22:21:19.729886
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    assert repr(function_def_0) == repr(', , def foo():')

# Generated at 2022-06-25 22:21:21.444696
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-25 22:21:24.324819
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

test_ReturnFromGeneratorTransformer_visit_FunctionDef()


# Generated at 2022-06-25 22:21:32.822065
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    return_from_generator_transformer_0.visit(function_def_0)
    assert 'return 1\n' in str(function_def_0)


# Generated at 2022-06-25 22:21:50.944264
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    expected_value_0 = '\n\ndef foo():\n  exc = StopIteration()\n  exc.value = 1\n  raise exc\n  yield 1\n'

    # Act
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    actual_value_0 = module_2.unparse(function_def_0)

    # Assert


# Generated at 2022-06-25 22:21:53.534760
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = module_0.AST()
    var_1 = ReturnFromGeneratorTransformer(var_0)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 22:21:56.614868
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0 is not None

# Generated at 2022-06-25 22:22:02.887382
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    str_1 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_1 = module_2.parse(str_1)
    function_def_1 = return_from_generator_transformer_1.visit_FunctionDef(var_1)


# Generated at 2022-06-25 22:22:03.741086
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:22:06.831633
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0


# Generated at 2022-06-25 22:22:07.790123
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:09.048053
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 22:22:14.749101
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:22:15.553680
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:22:24.991058
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:26.903356
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Testing
if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:22:27.667967
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:29.345722
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:31.473995
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Reference: https://github.com/serge-sans-paille/python-typed-ast/blob/master/tests/test_transformer.py#L830
    test_case_0()

# Generated at 2022-06-25 22:22:34.615869
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0 is not None


# Generated at 2022-06-25 22:22:35.410973
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass


# Generated at 2022-06-25 22:22:36.323508
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:39.659554
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

if __name__ == '__main__':
    test_case_0()
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-25 22:22:44.923057
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:23:03.107148
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:23:05.788312
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:07.691702
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test case for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""

    test_case_0()


# Generated at 2022-06-25 22:23:11.117200
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0


# Generated at 2022-06-25 22:23:13.144113
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():

    assert test_case_0() == '\n\ndef foo():\n  return 1\n  yield 1\n', 'Failed at line: 9, column: 1'

# Generated at 2022-06-25 22:23:21.543591
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_1 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_1)
    str_1 = '\n\ndef foo():\n  yield 1\n  exc = StopIteration()\n  exc.value = 1\n  raise exc\n'
    var_2 = module_2.parse(str_1)
    assert str(function_def_0) == str(var_2.body[0])

# Generated at 2022-06-25 22:23:27.668058
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    function_def_0 = module_2.parse(str_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:29.111759
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    var_0 = ReturnFromGeneratorTransformer()

# Generated at 2022-06-25 22:23:37.074865
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import random
    import src.transformer.return_from_generator
    import pytest
    import typed_ast._ast3 as module_0
    import typed_ast.ast3 as module_2
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = src.transformer.return_from_generator.ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_2.FunctionDef()
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_1 = module_2.parse(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(var_1)
    function_def_

# Generated at 2022-06-25 22:23:42.257012
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:24:00.062325
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:24:05.859248
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # Unit test for method visit_FunctionDef
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:24:10.664630
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:24:13.739268
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def test_not_None():
        assert ReturnFromGeneratorTransformer(None) is not None, 'Error message: {ReturnFromGeneratorTransformer(None)} should not be None'


# Generated at 2022-06-25 22:24:14.823728
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 22:24:22.715796
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    var_1 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    str_1 = '\n\ndef foo():\n  exc = StopIteration()\n  exc.value = 1\n  raise exc\n  yield 1'
    var_2 = module_2.parse(str_1)

# Generated at 2022-06-25 22:24:28.539319
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:24:35.910436
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        exec(sys.argv[1])
    else:
        from pytest import main
        main([__file__])

# Generated at 2022-06-25 22:24:37.936323
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()


# Generated at 2022-06-25 22:24:38.806738
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:24:56.484524
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:24:58.326042
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Unit tests for class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:24:59.224179
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test case where function returns from generator."""
    test_case_0()

# Generated at 2022-06-25 22:25:06.142451
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    #
    #
    # def foo():
    #  return 1
    #  yield 1
    #
    #
    #

    def foo():
        return 1
        yield 1


    #
    #
    # def foo():
    #  return 1
    #  yield 1
    #
    #
    #

    def foo():
        return 1
        yield 1


    #
    #
    # def foo():
    #  return 1
    #  yield 1
    #
    #
    #

    def foo():
        return 1
        yield 1


    #
    #
    # def foo():
    #  return 1
    #  yield 1
    #
    #
    #

    def foo():
        return 1
        yield 1


import unittest



# Generated at 2022-06-25 22:25:08.956256
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0 is not None


# Generated at 2022-06-25 22:25:13.269264
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:25:13.973000
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:25:18.275726
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(ast_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:25:20.687125
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(ReturnFromGeneratorTransformer(a_s_t_0), ReturnFromGeneratorTransformer)



# Generated at 2022-06-25 22:25:22.054085
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    obj = ReturnFromGeneratorTransformer()
    assert isinstance(obj, ReturnFromGeneratorTransformer)


# Generated at 2022-06-25 22:25:37.150051
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()


# Generated at 2022-06-25 22:25:39.966310
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert id(return_from_generator_transformer_0) != id(a_s_t_0)


# Generated at 2022-06-25 22:25:41.204958
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print("\n\nff\n")
    assert True


# Generated at 2022-06-25 22:25:43.610297
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:25:44.526156
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert False == test_case_0()

# Generated at 2022-06-25 22:25:45.725998
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:25:46.205124
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass


# Generated at 2022-06-25 22:25:48.279438
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

test_case_0()
test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-25 22:25:53.297566
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:26:03.058056
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:26:19.345733
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
    except BaseException as e:
        assert False, str(e)


# Generated at 2022-06-25 22:26:20.298282
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:26:22.845988
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:26:23.543227
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:26:31.496724
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:26:33.271097
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  tree = module_0.AST()
  return_from_generator_transformer = ReturnFromGeneratorTransformer(tree)
  assert isinstance(return_from_generator_transformer, ReturnFromGeneratorTransformer)

# Generated at 2022-06-25 22:26:37.606032
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print('test')
    test_case_0()
    print('test_passed')


if __name__ == "__main__":
    module_0 = ast.parse('\n\ndef foo():\n  return 1\n  yield 1\n')
    t = ReturnFromGeneratorTransformer(module_0)
    t.visit(module_0)

# Generated at 2022-06-25 22:26:41.200552
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    test_case_0()


# Generated at 2022-06-25 22:26:47.507203
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_2.Return = module_2.Return
    module_2.Yield = module_2.Yield
    module_2.YieldFrom = module_2.YieldFrom
    module_2.FunctionDef = module_2.FunctionDef
    module_2.NodeVisitor = module_2.NodeVisitor
    module_2.Name = module_2.Name
    module_2.Str = module_2.Str
    module_2.Raise = module_2.Raise
    module_2.Call = module_2.Call
    module_2.Attribute = module_2.Attribute
    module_2.Expr = module_2.Expr
    module_2.AST = module_2.AST
    module_2.Assign = module_2.Assign
    module_2.parse = module_2.parse

# Generated at 2022-06-25 22:26:48.815629
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():

    # TODO Test for constructor of class ReturnFromGeneratorTransformer
    pass



# Generated at 2022-06-25 22:27:25.354367
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0.target == (3, 2)

# Generated at 2022-06-25 22:27:28.330764
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    str_0 = '\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:27:29.022600
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:27:31.868520
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert isinstance(return_from_generator_transformer_0, module_2.NodeTransformer)


# Generated at 2022-06-25 22:27:35.625888
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:27:39.795594
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo(bar):\n  baz = bar\n  yield bar\n  return bar\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:27:41.107619
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(module_0.AST())
    pass


# Generated at 2022-06-25 22:27:42.971728
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    test_case_0()


# Generated at 2022-06-25 22:27:45.358647
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '\n\ndef foo():\n  return 1\n  yield 1\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:27:48.639528
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    test_case_0()