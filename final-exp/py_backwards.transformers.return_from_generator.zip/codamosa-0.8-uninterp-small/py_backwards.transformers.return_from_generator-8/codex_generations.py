

# Generated at 2022-06-25 22:18:25.770320
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    functiondef_0 = module_0.FunctionDef(name='fn', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Expr(value=module_0.Yield(value=module_0.Num(n=1))), module_0.Return(value=module_0.Num(n=5))], decorator_list=[], returns=None)
    return_result = return_from_generator_transformer_0.visit_FunctionDef(functiondef_0)
    assert return_result.body

# Generated at 2022-06-25 22:18:32.130407
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Code to execute
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef()
    a_s_t_0.body.append(a_s_t_1)
    a_s_t_1.args = module_0.arguments()
    a_s_t_2 = module_0.arguments()
    a_s_t_1.args = a_s_t_2
    a_s_t_3 = module_0.arg()
    a_s_t_2.args.append(a_s_t_3)
    a_s_t_3 = module_0.arg()


# Generated at 2022-06-25 22:18:35.717742
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    
    #Invalid call
    if True:
        test_case_0()

# Generated at 2022-06-25 22:18:46.102880
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_a_s_t_1 = module_0.FunctionDef()
    return_from_generator_transformer_1.visit_FunctionDef(function_def_a_s_t_1)

    assert not return_from_generator_transformer_1._find_generator_returns(function_def_a_s_t_1)

    return_a_s_t_1 = module_0.Return()
    return_a_s_t_1.value = module_0.Name()
    function_def_a_s_t_1.body.append(return_a_s_t_1)

# Generated at 2022-06-25 22:18:47.980655
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # TODO
    assert True is True


# Generated at 2022-06-25 22:18:55.039157
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    method_name_0 = "visit_FunctionDef"

# Generated at 2022-06-25 22:19:01.491501
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.Module([])
    function_def_0 = function_def_0.body[0]
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:19:03.236625
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    print()
    print("Testing method visit_FunctionDef of class ReturnFromGeneratorTransformer ...")

    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Test 1

# Generated at 2022-06-25 22:19:13.493730
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    module_0.FunctionDef()
    generator_returns_0 = module_0.FunctionDef()
    assert return_from_generator_transformer_0._find_generator_returns(generator_returns_0) == []
    generator_returns_1 = module_0.FunctionDef()
    assert return_from_generator_transformer_0._find_generator_returns(generator_returns_1) == []
    generator_returns_2 = module_0.FunctionDef()
    return_from_generator_transformer_0.generic_visit(generator_returns_2)
    assert return_

# Generated at 2022-06-25 22:19:20.017399
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_node_0 = module_0.FunctionDef(name='test_fn',args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Expr(value=module_0.Yield(value=module_0.Num(n=0))), module_0.Return(value=module_0.Num(n=1))], decorator_list=[], returns=None)

# Generated at 2022-06-25 22:19:35.602902
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_cases = [
        [],
        [0],
        [0, 0],
        [0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ]
    for arg in test_cases:
        try:
            test_case_0()
        except:
            continue


# Generated at 2022-06-25 22:19:37.213425
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:19:43.008577
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib_parse'
    list_0 = [str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:19:49.378387
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    list_0 = []
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:19:50.760043
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a = test_case_0()
    b = True
    assert( a == b)

# Generated at 2022-06-25 22:19:51.600392
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:57.270740
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib_parse'
    list_0 = [str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:58.129654
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:58.989757
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:01.352640
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

#### END OF TESTS ####

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()
    print("All tests succeeded.")

# Generated at 2022-06-25 22:20:10.972750
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
    return_from_generator_transformer_inst_0 = ReturnFromGeneratorTransformer(None)
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 22:20:11.931195
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:18.928909
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_1 = 'urllib_parse'
    list_1 = [str_1, str_1, str_1]
    function_def_2 = module_0.FunctionDef(*list_1)
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_3 = return_from_generator_transformer_1.visit_FunctionDef(function_def_2)


# Generated at 2022-06-25 22:20:19.875089
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test with case 0
    case_0_function_def_0 = test_case_0()
    print(case_0_function_def_0)

# Generated at 2022-06-25 22:20:20.411985
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:20:20.996487
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:27.791418
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Declaration for function test_case_0
    def test_case_0():
        str_0 = 'urllib_parse'
        list_0 = [str_0, str_0, str_0]
        function_def_0 = module_0.FunctionDef(*list_0)
        a_s_t_0 = module_0.AST()
        return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
        function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    # Call function test_case_0
    test_case_0()

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:20:31.893309
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)
    function_def_0 = FunctionDef(*[str, str, str])
    a_s_t_0 = AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:41.366046
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # FunctionDef
    function_def_0 = module_0.FunctionDef('Name', [], [], None)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    print(function_def_1)
    # FunctionDef
    function_def_2 = module_0.FunctionDef('Name', [], [], None)
    function_def_3 = return_from_generator_transformer_0.visit_FunctionDef(function_def_2)
    print(function_def_3)
    # FunctionDef
    function_def_4 = module_

# Generated at 2022-06-25 22:20:42.298925
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:53.284913
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:20:54.649147
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:20:56.502820
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    '''
    Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    '''
    test_case_0()

# Generated at 2022-06-25 22:20:57.605738
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:04.373766
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef(arguments=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], name='urllib_parse', returns=None)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:08.099909
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
    assert True

# Generated at 2022-06-25 22:21:09.917878
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:18.139196
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib_parse'
    list_0 = [str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is function_def_0


# Generated at 2022-06-25 22:21:19.516483
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:21:20.754410
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:36.351435
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5
    tree = ast.parse(fn.__code__)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)

    assert new_tree.body[0].body[2].value.func.id == 'StopIteration'
    assert new_tree.body[0].body[2].value.args[0].id == 'exc'
    assert new_tree.body[0].body[1].value.elts[0].id == 'exc'
    assert new_tree.body[0].body[1].value.elts[1].id == 'StopIteration'

# Generated at 2022-06-25 22:21:37.129281
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:42.051855
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_1 = 'urllib'
    function_def_2 = module_0.FunctionDef(*str_1)
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_3 = return_from_generator_transformer_1.visit_FunctionDef(function_def_2)

# Generated at 2022-06-25 22:21:47.617462
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Find the next free variable
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    str_0 = 'abc'
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return_from_generator_transformer_0.visit_FunctionDef(str_0)


# Generated at 2022-06-25 22:21:52.694812
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Create a new instance of function_def with attributes
    function_def = return_from_generator_transformer.FunctionDef(name="_test_private_function")
    # Create a new instance of return_from_generator_transformer with attributes
    return_from_generator_transformer = ReturnFromGeneratorTransformer(ast)
    # Visit return_from_generator_transformer
    return_from_generator_transformer.visit_FunctionDef(function_def)


# Generated at 2022-06-25 22:21:57.173558
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:06.070127
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    new_a_s_t_0 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(new_a_s_t_0)
    new_function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:12.020504
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    if function_def_0 is not function_def_1:
        raise Exception('Expected equality but was not')


# Generated at 2022-06-25 22:22:15.027692
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print('Test ReturnFromGeneratorTransformer.visit_FunctionDef')
    test_case_0()
    return 0

tests_count = 1


# Generated at 2022-06-25 22:22:23.061243
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    str_1 = 'typed_ast'
    module_1 = sys.modules[str_1]
    function_def_2 = module_1.FunctionDef(*str_0)
    function_def_3 = return_from_generator_transformer_0.visit_FunctionDef(function_def_2)
    str_2 = 'argparse'
    argument_parser_

# Generated at 2022-06-25 22:22:46.239960
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:22:47.004246
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:47.791025
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:22:52.888295
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is function_def_0


# Generated at 2022-06-25 22:22:57.375114
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:03.138143
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:08.184554
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:13.106811
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:23:18.198139
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:23:18.994726
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:24:04.649678
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_1 = 'urllib'
    function_def_2 = module_0.FunctionDef(*str_1)
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_3 = return_from_generator_transformer_1.visit_FunctionDef(function_def_2)


# Generated at 2022-06-25 22:24:12.725200
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # This test is for a bug where the return_from_generator snippet
    # was inserted twice.
    str_tuple_0 = ('y', 'value')
    str_0 = 'y'
    str_tuple_1 = ('y', 'value')
    name_0 = module_0.Name(*str_tuple_0)
    name_1 = module_0.Name(*str_tuple_1)
    str_tuple_1 = ('value',)
    str_1 = 'value'
    str_tuple_2 = ('y', 'value')
    name_2 = module_0.Name(*str_tuple_1)
    name_3 = module_0.Name(*str_tuple_2)
    str_tuple_1 = ('y',)

# Generated at 2022-06-25 22:24:17.323189
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:24:18.094460
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:24:22.892537
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:24:28.362997
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:24:29.123785
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # Test 0
    test_case_0()

# Generated at 2022-06-25 22:24:34.271807
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:24:42.037678
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'abc'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_2 = return_from_generator_transformer_1.visit_FunctionDef(function_def_1)
    assert function_def_2

# Generated at 2022-06-25 22:24:49.529692
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef('urllib',
                                          module_0.arguments([], module_0.arg('href', None, None, None)),
                                          [
                                              module_0.Return(module_0.Call(
                                                  module_0.Name('urllib', module_0.Load()),
                                                  [
                                                      module_0.Name('href', module_0.Load())],
                                                  []))],
                                          [])
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:26:46.640022
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:26:50.319464
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:26:53.856638
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:26:56.971690
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'urllib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:26:57.560789
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:26:58.513440
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:26:59.196525
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:27:03.537966
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    original_str = """
    def fn():
        yield 1
        return 5
    """

    expected_str = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    module, _ = get_ast_source(original_str)
    function_def = module.body[0]  # type: ast.FunctionDef

    t = ReturnFromGeneratorTransformer(module)
    function_def = t.visit_FunctionDef(function_def)

    result_str = dump_python_source(module)
    assert result_str == expected_str

# Generated at 2022-06-25 22:27:04.111772
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:27:07.456338
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'httplib'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)