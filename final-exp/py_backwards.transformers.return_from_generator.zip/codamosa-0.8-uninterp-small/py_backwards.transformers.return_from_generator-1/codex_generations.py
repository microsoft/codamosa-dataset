

# Generated at 2022-06-25 22:18:25.261925
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    permanent_patches_0 = [
        (4, module_0.Store())
    ]

# Generated at 2022-06-25 22:18:31.878264
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef(name='a', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Return(value=module_0.Constant(value='a'))], decorator_list=[], returns=None)
    return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1)
    assert len(a_s_t_1.body) == 3
    assert a_s_t_1.body[0].value

# Generated at 2022-06-25 22:18:38.893274
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:18:47.577982
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    node = a_s_t_1.parse('def foo():\n  yield 1\n  return 1', '<input>', 'exec')
    node = return_from_generator_transformer_0.visit_FunctionDef(node)
    assert str(node) == 'def foo():\n  yield 1\n  exc = StopIteration()\n  exc.value = 1\n  raise exc'

# Generated at 2022-06-25 22:18:52.670040
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Unit tests for class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:19:03.067804
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    global return_from_generator_transformer_0

    # Input
    a_s_t_0_0 = module_0.PyCF_ONLY_AST
    a_s_t_0_1 = module_0.PyCF_TYPE_COMMENTS

# Generated at 2022-06-25 22:19:11.435742
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Input Parameters
    node = None

    a_s_t_0 = module_0.AST()

    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    print("Executing: "+"return_from_generator_transformer_0.visit_FunctionDef(node)")
    actual = return_from_generator_transformer_0.visit_FunctionDef(node)
    print("Expecting:"+" node")
    print("Output:"+str(actual))
    assert actual == node, str(actual) + " should equal input " + str(node)



# Generated at 2022-06-25 22:19:16.366246
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a = ReturnFromGeneratorTransformer(None)
    b = ast.FunctionDef(name='', args=None, body=[], decorator_list=[], returns=None)
    c = a.visit_FunctionDef(b)
    assert c is None
    assert a._tree_changed == False
    assert a._tree is None
    assert b.decorator_list is None
    assert b.returns is None


# Generated at 2022-06-25 22:19:17.119286
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass # TODO: Implement test


# Generated at 2022-06-25 22:19:25.928615
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef('f', module_0.arguments(None, None, [], None, []), [module_0.Return(module_0.Str('a'))], [], None, None)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert isinstance(function_def_1, module_0.FunctionDef)
    if isinstance(function_def_1, module_0.FunctionDef):
        assert function_def_1.args == function_def_0.args
        assert function_def_1.body

# Generated at 2022-06-25 22:19:32.241859
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0.ast == a_s_t_0
    assert not return_from_generator_transformer_0.tree_changed


# Generated at 2022-06-25 22:19:34.567102
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:37.292954
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from typed_ast import ast3 as ast
    a_s_t_1 = ast.AST()
    print(ReturnFromGeneratorTransformer(a_s_t_1))


# Generated at 2022-06-25 22:19:40.956879
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    args = function_def_0.args
    body = function_def_0.body
    decorator_list = function_def_0.decorator_list
    kwargs = function_def_0.kwargs
    name = function_def_0.name
    returns = function_def_0.returns


# Generated at 2022-06-25 22:19:51.285798
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_level_function_return_from_generator_transformer_extern_1 = ReturnFromGeneratorTransformer
    module_level_function_return_from_generator_transformer_extern_0 = ReturnFromGeneratorTransformer
    module_level_function_return_from_generator_transformer_extern_2 = ReturnFromGeneratorTransformer
    module_level_function_return_from_generator_transformer_extern_3 = ReturnFromGeneratorTransformer
    module_level_function_return_from_generator_transformer_extern_4 = ReturnFromGeneratorTransformer
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:19:54.163818
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0


# Generated at 2022-06-25 22:19:58.437437
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

from ..utils.snippet import snippet, let
from ..utils.mangling import apply_mangling
from ..utils.snippets import generators, coroutines
from ..utils.ast_visitor import FullAstVisitor
from .base import BaseNodeTransformer
from ..utils.types import GeneratorFunctionType, CoroutineFunctionType



# Generated at 2022-06-25 22:19:59.268122
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:01.017251
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree = ast.parse("def test(): pass")
    ReturnFromGeneratorTransformer(tree)
    assert True


# Generated at 2022-06-25 22:20:06.058257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    test_case_0()


# Generated at 2022-06-25 22:20:19.574291
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    str_1 = 'yield 1'
    var_1 = module_2.parse(str_1, str_1, str_1)
    function_def_1 = return_from_generator_transformer_1.visit_FunctionDef(var_1)
    str_2 = 'return 1'
    var_2 = module_2.parse(str_2, str_2, str_2)
    function_def_2 = return_from_generator_transformer_1.visit_FunctionDef(var_2)
    str_3 = 'def foo(): yield 1\nreturn 1'
    var_3 = module_2

# Generated at 2022-06-25 22:20:20.364626
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:23.112361
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0 is not None


# Generated at 2022-06-25 22:20:23.833137
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:20:26.358685
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:34.118764
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn(): yield 1; return 5'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    str_1 = 'def fn(): yield 1\nexc = StopIteration()\nexc.value = 5\nraise exc'
    assert str(function_def_0) == str_1 # Assertion failed


# Generated at 2022-06-25 22:20:35.055043
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:36.848936
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# MAIN
#if __name__ == '__main__':
#    _test_module()

# Generated at 2022-06-25 22:20:38.407486
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:39.799263
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print("\n*** Testing ***\n")

    test_case_0()



# Generated at 2022-06-25 22:20:52.332803
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

    assert True

# Generated at 2022-06-25 22:20:53.875380
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:54.953397
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:20:56.502491
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:21:01.868715
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:21:09.950830
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

    return_from_generator_transformer_0.tree_changed # BUG


# Generated at 2022-06-25 22:21:19.973757
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    assert( return_from_generator.return_value == return_from_generator_0.return_value)
    return_from_generator_0 = return_from_generator()
    return_from_generator_1 = return_from_generator(return_from_generator_0)
    assert( return_from_generator.return_value == return_from_generator_1.return_value)
    return_from_generator_2 = return_from_generator(return_from_generator_1)

# Generated at 2022-06-25 22:21:24.669166
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Initialize argument
    a_s_t_0 = module_0.AST()

    # Construct object
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:27.384230
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    return_from_generator_transformer_0.target = (3, 4)

# Generated at 2022-06-25 22:21:28.966304
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:46.945013
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t = module_0.AST()
    return_from_generator_transformer = ReturnFromGeneratorTransformer(a_s_t)
    assert hasattr(return_from_generator_transformer, '_tree_changed')
    assert hasattr(return_from_generator_transformer, '_target')
    assert hasattr(return_from_generator_transformer, '_tree')


# Generated at 2022-06-25 22:21:50.979163
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Manual test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:21:53.004486
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:21:57.358664
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    from .snippet import SnippetTestCase
    from .snippet import SnippetTestCase_0

    # Test case for __init__(self, tree: AST)
    ast_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(ast_0)


# Generated at 2022-06-25 22:21:59.876005
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:04.777477
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    var_0 = return_from_generator_transformer_0

if __name__ == '__main__':
    test_case_0()
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-25 22:22:12.443041
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert callable(ReturnFromGeneratorTransformer)
    with pytest.raises(TypeError):
        ReturnFromGeneratorTransformer(8)
    with pytest.raises(TypeError):
        ReturnFromGeneratorTransformer(8, 8)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0._tree is a_s_t_0
    assert return_from_generator_transformer_0._tree_changed is False
    assert return_from_generator_transformer_0.name == 'ReturnFromGenerator'


# Generated at 2022-06-25 22:22:13.977359
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:14.951400
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:22:16.340573
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    case_list = [test_case_0]
    for case in case_list:
        case()


# Generated at 2022-06-25 22:22:45.298146
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:48.592514
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# testing
# import unittest
# class TestReturnFromGeneratorTransformer(unittest.TestCase):
#     def test_0(self):
#         test_case_0()
#
# if __name__ == '__main__':
#     unittest.main()

# Generated at 2022-06-25 22:22:50.069373
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-25 22:22:57.857813
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_1)
    a_s_t_1.add_path('test/test_resources/test_resources/test_resources/test_resources/test_resources/test_resources/test_resources/test_resources')
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    str_1 = 'import'

# Generated at 2022-06-25 22:22:59.920877
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert test_case_0() == None, "function test_case_0 failed"

# Generated at 2022-06-25 22:23:02.352733
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:08.961287
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    assert function_def_0 is not None
    assert function_def_0 is var_0


# Generated at 2022-06-25 22:23:10.582803
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
    #
    # 
    #
    #

# Generated at 2022-06-25 22:23:12.094280
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast_0 = module_0.AST()
    assert (ReturnFromGeneratorTransformer(ast_0))


# Generated at 2022-06-25 22:23:17.258977
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Arrange
    a_s_t_0 = module_0.AST()

    # Act
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Assert
    assert isinstance(return_from_generator_transformer_0, ReturnFromGeneratorTransformer)
    assert return_from_generator_transformer_0.tree is a_s_t_0


# Generated at 2022-06-25 22:24:42.686638
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(a_s_t_0, module_0.AST)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert isinstance(return_from_generator_transformer_0, ReturnFromGeneratorTransformer)


# Generated at 2022-06-25 22:24:50.498441
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

    # Assert that nodes are equal

# Generated at 2022-06-25 22:24:58.969534
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def foo():\n    yield 1\n    return 2'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)

# Generated at 2022-06-25 22:25:03.239815
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:25:06.077789
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:25:08.095141
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:25:12.443058
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_2 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_2)
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:25:13.141339
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:25:16.422901
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    function_def = FunctionDef()
    function_def.body = []
    function_def.body.append(Return(value=None))
    node = return_from_generator_transformer.visit_FunctionDef(function_def)
    assert node is not None

# Generated at 2022-06-25 22:25:20.857231
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:27:32.372467
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    assert False


# Generated at 2022-06-25 22:27:38.358015
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn(first, second):\n    return\n'
    var_1 = module_2.parse(str_0, str_0, str_0)
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_0 = return_from_generator_transformer_1.visit_FunctionDef(var_1)
    str_1 = 'def fn(first, second):\n    return\n'

# Generated at 2022-06-25 22:27:43.254608
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    str_1 = 'def fn():\r\n    yield 1\r\n    return 5'
    var_1 = module_2.parse(str_1, str_1, str_1)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(var_1)


# Generated at 2022-06-25 22:27:44.802671
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:27:53.359038
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_5 = 'def f():\n    yield 1\n    return None'
    var_0 = module_2.parse(str_5, str_5, str_5)
    try:
        var_1 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    except:
        # raise
        pass
    var_2 = 'def f():\n    yield 1\n    exc = StopIteration()\n    exc.value = None\n    raise exc'

# Generated at 2022-06-25 22:27:55.323745
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(test_case_0(), type)

test_ReturnFromGeneratorTransformer()



# Generated at 2022-06-25 22:27:56.183495
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:27:59.759440
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_4 = module_0.AST()
    return_from_generator_transformer_4 = ReturnFromGeneratorTransformer(a_s_t_4)
    assert (return_from_generator_transformer_4.generic_visit is not None)
    assert (return_from_generator_transformer_4.get_snippet is not None)

# Generated at 2022-06-25 22:28:05.815479
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ast_unparse import unparse
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def f():\n    yield 1\n    return 5'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    assert unparse(function_def_0) == 'def f():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'


# Generated at 2022-06-25 22:28:11.380446
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'exec'
    var_0 = module_2.parse(str_0, str_0, str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    assert function_def_0 is not None
    assert isinstance(function_def_0, ast.AST)
    print("Test passed")
