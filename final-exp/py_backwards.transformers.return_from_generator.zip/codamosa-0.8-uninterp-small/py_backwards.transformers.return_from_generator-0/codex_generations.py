

# Generated at 2022-06-25 22:18:26.154704
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    a_s_t_0._fields = ['body']
    function_def_0._fields = ['body']
    return_from_generator_transformer_0._tree_changed = False
    return_from_generator_transformer_0.visit(function_def_0)
    assert return_from_generator_transformer_0._tree_changed == False

# Generated at 2022-06-25 22:18:35.868974
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    module_0_FunctionDef_0 = module_0.FunctionDef(name = '', args = module_0.arguments(args = [], vararg = None, kwarg = None, defaults = []), body = [module_0.FunctionDef(name = '', args = module_0.arguments(args = [], vararg = None, kwarg = None, defaults = []), body = [module_0.Return(value = module_0.Num(n = 1))], decorator_list = [])], decorator_list = [])
    a_s_t_0 = module_0.AST()
    return_from_generator_trans

# Generated at 2022-06-25 22:18:40.799786
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:18:49.500413
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef('fn', module_0.arguments([], None, [], [], None, [], []), [], [], None, module_0.Yield(None))
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert isinstance(function_def_1, module_0.FunctionDef)

    test_case_ReturnFromGeneratorTransformer.test_case_0()

# Generated at 2022-06-25 22:18:55.810715
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name="fn")
    generator_expr_0 = module_0.GeneratorExp()
    yield_from_0 = module_0.YieldFrom(value=generator_expr_0)
    return_0 = module_0.Return(value=yield_from_0)
    function_def_0.body.append(return_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return_0 = function_def_0.body[0]

# Generated at 2022-06-25 22:19:06.359249
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast._ast3 as module_0
    import typed_ast._ast3 as module_1
    import typed_ast._ast3 as module_2
    import typed_ast._ast3 as module_3
    import typed_ast._ast3 as module_4
    import typed_ast._ast3 as module_5
    import typed_ast._ast3 as module_6
    import typed_ast._ast3 as module_7
    import typed_ast._ast3 as module_8
    import typed_ast._ast3 as module_9
    import typed_ast._ast3 as module_10
    import typed_ast._ast3 as module_11
    import typed_ast._ast3 as module_12
    import typed_ast._ast3 as module_13
    import typed_ast._ast3 as module_14
    import typed_

# Generated at 2022-06-25 22:19:12.495862
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    node_0 = module_0.FunctionDef()
    # AssertionError: <class 'typed_ast._ast3.FunctionDef'> is not an instance of <class 'typed_ast._ast3.FunctionDef'>
    # assert return_from_generator_transformer_0.visit_FunctionDef(node_0) == node_0

# Generated at 2022-06-25 22:19:16.727224
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    pass

# Generated at 2022-06-25 22:19:25.174041
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0 is not None
    return_from_generator_transformer_0.generic_visit = lambda node: node

    module_0_0 = module_0.Module([module_0.FunctionDef('function_1', module_0.arguments([module_0.arg('arg_0', None)], None, [], [], None, []), [module_0.Return(module_0.Num(5))])], [])
    module_0_0_0 = return_from_generator_transformer_0.visit_Module(module_0_0)

# Generated at 2022-06-25 22:19:34.336684
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:43.470699
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class_definition = """\
    def fn():
        yield 1
        return 5
    """
    compiled_class_definition = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    class_definition = ast.parse(class_definition)
    compiled_class_definition = ast.parse(compiled_class_definition)

    transformer = ReturnFromGeneratorTransformer(class_definition)
    transformed = transformer.visit(class_definition)

    assert ast.dump(transformed, include_attributes=True) == ast.dump(compiled_class_definition, include_attributes=True)

# Generated at 2022-06-25 22:19:44.247160
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass

# Generated at 2022-06-25 22:19:45.312124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:46.274490
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:47.133541
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:48.221255
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:49.885058
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:19:57.617299
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = None
    str_0 = '_{\nelTorXW`:r#xZ`\tY'
    bytes_0 = b"\xdat$\xa4h':\xa0\xc8\x1b\xdda \xe9\x9c\\\xadx"
    dict_0 = {str_0: bytes_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:19:58.478089
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:59.305521
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:20:16.545256
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    test_case_0()
test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:20:17.505875
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert_equal(test_case_0(), 0)

# Generated at 2022-06-25 22:20:18.452124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:19.498685
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:20.290436
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:25.188569
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'q`0{&WGa?vjYU6]s'
    list_0 = [str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:20:28.134622
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import sys
    import io
    import contextlib
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()
    try:
        test_case_0()
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-25 22:20:34.729238
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef('tfYBfsg,23,A3[S?6', 'tfYBfsg,23,A3[S?6', 'tfYBfsg,23,A3[S?6')
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:20:35.578327
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:20:39.321603
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

import typed_ast._ast3 as module_1
import typed_ast._ast3 as module_2

str_1 = 'T0Tm(V,;M8m3K{7'


# Generated at 2022-06-25 22:20:47.283680
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:48.700671
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:49.990182
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:58.269356
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'tfYBfsg,23,A3[S?6'
    list_0 = [str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:20:59.330029
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:00.145339
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert test_case_0() != None

# Generated at 2022-06-25 22:21:01.261713
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:03.583035
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
        assert False, "Expected assertion error to be thrown"
    except AssertionError as e:
        assert True, "Expected assertion error to be thrown"

# Generated at 2022-06-25 22:21:08.991431
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Initialize the context
    test_case_0()


# Generated at 2022-06-25 22:21:19.628393
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'd'
    str_1 = 'kw'
    str_2 = 't'
    str_3 = 'xOhqW((q'
    list_0 = [str_3, str_3, str_3, str_3, str_3]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_4 = '=I'
    str_5 = 'Bq'
    str_6 = 'I'
    str_7 = 'D,<'
    list_1 = [str_7, str_7, str_7, str_7, str_7]


# Generated at 2022-06-25 22:21:26.623280
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:27.661948
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:29.257547
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:35.518918
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'tfYBfsg,23,A3[S?6'
    list_0 = [str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:41.858378
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef(
        arg=None,
        body=[],
        decorator_list=[],
        name=None,
        returns=None,
        type_comment=None
    )
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:21:46.654560
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '_H;jtJC'
    list_0 = [str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:21:48.760699
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.input_file import InputFile
    from ..utils.snippet_list import SnippetList
    from ..utils.compiler import compile_text


# Generated at 2022-06-25 22:21:54.431510
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'IW;zyvIBkS'
    list_0 = [str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:03.275163
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    list_0 = []
    return_0 = module_0.Return(*list_0)
    list_1 = [return_0]
    function_def_0 = module_0.FunctionDef(*list_1)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    str_0 = repr(function_def_1)
    str_1 = '<_ast3.FunctionDef object at 0x0000029053D3FEF0>'
    assert str_0 == str_1


# Generated at 2022-06-25 22:22:04.077139
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:11.105375
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert test_case_0()


# Generated at 2022-06-25 22:22:11.906237
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:22:12.714938
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    assert False, 'Unimplemented'

# Generated at 2022-06-25 22:22:21.770997
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# tests run in order of appearance in file (so if method A is before method B, method A will be tested first)
# to run tests, invoke pytest
# to run a specific test, invoke pytest -k test_<test_name>
# to run a specific test in a specific file, invoke pytest <test_file_path> -k test_<test_name>
# to skip the slow tests, invoke pytest --skip-slow
# to run all the tests and create a report in html, invoke pytest --html=report.html
# to run all the tests and create a report in xml, invoke pytest --junitxml=report.xml
# to run tests in verbose mode, invoke pytest -v
# to create a coverage report, invoke

# Generated at 2022-06-25 22:22:27.282507
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'tfYBfsg,23,A3[S?6'
    list_0 = [str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return function_def_1

# Generated at 2022-06-25 22:22:28.981858
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
# End unit test.

# Generated at 2022-06-25 22:22:35.799243
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'tfYBfsg,23,A3[S?6'
    list_0 = [str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

if __name__ == '__main__':
    test_case_0()
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:22:42.182191
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'fq'
    str_1 = '9'
    list_0 = [str_0, str_0, str_1]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:22:44.257843
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # - TEST 1 -
    test_case_0()
    # - TEST 2 -

    # - TEST 3 -

    # - TEST 4 -

    # - TEST 5 -


# Generated at 2022-06-25 22:22:45.377010
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Unit tests for class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:23:00.508004
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    sample = function_def_1
    expected = module_0.FunctionDef(*str_0)
    assert sample == expected

if __name__ == '__main__':
    test_case_0()
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:23:05.914058
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)



# Generated at 2022-06-25 22:23:06.405601
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass

# Generated at 2022-06-25 22:23:11.551843
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:17.336612
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Create instance of named tuple
    a_s_t_1 = module_0.AST()
    # Create instance of class ReturnFromGeneratorTransformer
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    # Create instance of class FunctionDef
    function_def_2 = module_0.FunctionDef(*('2$Z',))
    function_def_3 = return_from_generator_transformer_1.visit_FunctionDef(function_def_2)

# Generated at 2022-06-25 22:23:22.111457
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:27.888556
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '0%'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:30.836946
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    d = {'a': 2, 'b': 3}
    d_map = map(lambda k, v: [k, v], d)
    list_0 = list(d_map)
    assert len(list_0) == 2

import astunparse

# Generated at 2022-06-25 22:23:31.594308
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:23:37.831352
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


if __name__ == '__main__':
    test_case_0()
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:23:58.685692
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '1&K'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:24:03.961144
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert isinstance(function_def_0, module_0.FunctionDef)

# Generated at 2022-06-25 22:24:04.943786
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:24:08.951627
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:24:17.667862
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    if ((function_def_1 is not None) and hasattr(function_def_1, 'body') and isinstance(function_def_1.body, list)):
        function_def_1_body_0 = function_def_1.body
        assert (len(function_def_1_body_0) == 1)
        function_def_1_body_1 = function_

# Generated at 2022-06-25 22:24:19.180900
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:24:26.372981
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    # Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    # Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    assert function_def_1 == function_def_0

# Generated at 2022-06-25 22:24:31.050129
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    function_def_2 = module_0.FunctionDef(*str_0)

# Generated at 2022-06-25 22:24:39.911124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    str_1 = '9X'
    function_def_2 = module_0.FunctionDef(*str_1)
    module_0.Expr(function_def_2)
    module_0.Raise(module_0.Call(module_0.Name('b', module_0.Load()), [], [], None, None))
    str_2 = 'b'
    name_0 = module_0.Name(*str_2)
    expr_0 = module_0.Expr(name_0)
    module_0.While(module_0.Assert(function_def_2), [expr_0], [])
    function

# Generated at 2022-06-25 22:24:40.677251
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:25:56.059249
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import ast_compare
    test_case_0()
    test_case_1()
    assert ast_compare.compare_ast(test_case_0.__closure__[0].cell_contents.result, test_case_1.__closure__[0].cell_contents.result)

# Generated at 2022-06-25 22:25:57.161482
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:25:57.814545
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:26:01.049446
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    str_1 = 'C\\%X'
    function_def_2 = module_0.FunctionDef(*str_1)
    function_def_3 = return_from_generator_transformer_1.visit_FunctionDef(function_def_2)


# Generated at 2022-06-25 22:26:11.112075
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_1)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:26:12.063222
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:26:21.326331
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '9@j'
    str_1 = '=Nj'
    str_2 = 't Z'
    str_3 = 'EhC'
    str_4 = 'ZY]'
    str_5 = 'x_j'
    str_6 = 'XDg'
    str_7 = 'nA+'
    str_8 = '"{6'
    str_9 = '<WU'
    str_10 = '_0a'
    str_11 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_11)
    return_1 = module

# Generated at 2022-06-25 22:26:23.041818
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = module_0
    test_case_0()

    ReturnFromGeneratorTransformer.visit_FunctionDef()



# Generated at 2022-06-25 22:26:31.253127
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    generator_returns = []
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert len(function_def_1.body) == 1

# Generated at 2022-06-25 22:26:35.780114
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)

    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:27:36.153208
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = FunctionDef('test')
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:27:42.010854
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    '''
        def fn():
            yield 1
            return 5
    '''
    a_s_t_0 = AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    try:
        # where x is a variable, print (x)
        list_0 = []
        for x in function_def_1:
            str_1 = '{x}'
            print(str_1)
    except Exception as error_0:
        print('type error.')
    return function_def_1

# Generated at 2022-06-25 22:27:44.802492
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:27:45.364546
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:27:47.623750
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    with pytest.raises(ValueError):
        test_case_0()

# Generated at 2022-06-25 22:27:51.815050
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:27:52.704229
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:27:58.417839
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return_from_generator_transformer_0.visit_FunctionDef(None)


# Generated at 2022-06-25 22:27:59.274165
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:28:02.940970
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '2$Z'
    function_def_0 = module_0.FunctionDef(*str_0)
    test_case_0()

test_ReturnFromGeneratorTransformer_visit_FunctionDef()