

# Generated at 2022-06-25 22:18:22.636575
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0.body = [ast.Yield(None)]
    function_def_0.body.append(ast.Return(None))
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:18:26.970842
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    

# Generated at 2022-06-25 22:18:31.572185
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:18:35.137448
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()


# Generated at 2022-06-25 22:18:44.286118
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()

    # NOTE: Testing private method
    return_from_generator_transformer_0._find_generator_returns(function_def_0)
    # NOTE: Testing private method
    return_from_generator_transformer_0._replace_return(function_def_0, None)

    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:18:46.417902
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass

if __name__ == "__main__":
    test_case_0()
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:18:51.414686
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Create instance of a FunctionDef
    function_def_0 = module_0.FunctionDef()
    
    # Create instance of ReturnFromGeneratorTransformer
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    
    # Call method visit_FunctionDef of ReturnFromGeneratorTransformer
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:18:55.621410
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_0 is not None


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:19:01.330276
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # Test exception case
    # test check for None
    try:
        function_def_0 = None
        return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    except Exception:
        pass



# Generated at 2022-06-25 22:19:06.579994
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:19:18.379706
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:19:19.340793
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:19:20.257882
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:28.691932
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '!4;ATI\x0cn\x0bQ\x0cl=pBS|~'
    list_0 = [str_0, str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_1.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:19:29.502992
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:30.342271
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:39.454102
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'y\x0c?\x0c\x0ckde\x03Q'
    list_0 = []
    function_def_0 = module_0.FunctionDef(*list_0)
    str_1 = '\x07d\x0c/\x0cA\x02{;\x0c\x0c%\x0e'
    list_1 = [str_1, str_0]
    return_0 = module_0.Return(*list_1)
    list_2 = [return_0]
    function_def_1 = module_0.FunctionDef(*list_2)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:40.296467
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:44.412462
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_1 = '!4;ATI\x0cn\x0bQ\x0cl=pBS|~'
    list_1 = [str_1, str_1, str_1, str_1]
    function_def_0 = module_0.FunctionDef(*list_1)
    list_2 = []
    list_3 = []
    list_4 = []
    list_5 = []
    list_2.extend(list_3)
    list_2.extend(list_4)
    list_2.extend(list_5)

# Generated at 2022-06-25 22:19:54.286909
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    global module_0
    global list_0
    global str_0
    global function_def_0
    global a_s_t_0
    global return_from_generator_transformer_0
    global return_from_generator_transformer_1
    global function_def_1

    module_0 = typed_ast._ast3
    str_0 = '!4;ATI\x0cn\x0bQ\x0cl=pBS|~'
    list_0 = [str_0, str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:20:04.275557
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Instance of class ReturnFromGeneratorTransformer
    return_from_generator_transformer_0 = None
    # Instance of class FunctionDef
    function_def_0 = module_0.FunctionDef()
    # Call method of class ReturnFromGeneratorTransformer
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    try:
        assert_equals(function_def_0, function_def_1)
    except AssertionError as e:
        print('Expected:', function_def_0)
        print('Actual  :', function_def_1)
        raise e


# Generated at 2022-06-25 22:20:07.362355
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # args
    args = test_case_0()
    assert True == True

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:20:14.146233
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '!4;ATI\x0cn\x0bQ\x0cl=pBS|~'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert True

# Generated at 2022-06-25 22:20:15.092437
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:20:18.573000
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print("Running test for method visit_FunctionDef of class ReturnFromGeneratorTransformer")
    test_case_0()
    print("Done")

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:20:19.611660
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass # test_case_0

# Generated at 2022-06-25 22:20:25.078677
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Type_0 is "str"
    str_0 = '!4;ATI\x0cn\x0bQ\x0cl=pBS|~'
    # Type_1 is "str"
    str_1 = [str_0, str_0, str_0, str_0]
    # Type_2 is "typed_ast._ast3.FunctionDef"
    function_def_0 = module_0.FunctionDef(*str_1)
    a_s_t_0 = None
    # Type_3 is "typed_ast.transforms.ReturnFromGeneratorTransformer"
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef

# Generated at 2022-06-25 22:20:32.055458
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '!4;ATI\x0cn\x0bQ\x0cl=pBS|~'
    str_1 = [str_0, str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*str_1)
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:20:39.562971
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '!4;ATI\x0cn\x0bQ\x0cl=pBS|~'
    str_1 = [str_0, str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*str_1)
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:20:47.282462
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '!4;ATI\x0cn\x0bQ\x0cl=pBS|~'
    str_1 = [str_0, str_0, str_0, str_0]
    function_def_0 = module_0.FunctionDef(*str_1)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

if __name__ == '__main__':
    test_case_0()
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:20:52.997395
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:54.516477
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:55.491924
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()



# Generated at 2022-06-25 22:20:56.968778
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:20:57.637140
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return

# Generated at 2022-06-25 22:20:58.695053
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:59.529386
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:04.925602
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t = None
    return_from_generator_transformer = ReturnFromGeneratorTransformer(a_s_t)
    str_0 = '!4;ATI\x0cn\x0bQ\x0cl=pBS|~'
    str_1 = [str_0, str_0, str_0, str_0]
    function_def = module_0.FunctionDef(*str_1)
    function_def_0 = return_from_generator_transformer.visit_FunctionDef(function_def)

# Generated at 2022-06-25 22:21:12.429645
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Commit: c6692d3c085baff2e76a7a4a4a4c4ffb9be06782
    test_case_0()


if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()  # type: ignore

# Generated at 2022-06-25 22:21:13.348541
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:25.488690
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
    


if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:21:29.662373
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    def check_pattern(node):
        if not isinstance(node, ast.FunctionDef):
            return False

        if isinstance(node.body[0], ast.Return):
            return False

        return True

    assert check_pattern(test_case_0())

# Generated at 2022-06-25 22:21:30.449910
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:36.463973
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

if (__name__ == '__main__'):
    test_case_0()


# Generated at 2022-06-25 22:21:44.918987
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '7t$'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0.name = 'c64f'
    function_def_0.body.append(function_def_0)
    function_def_0.arguments = ('5t$')
    return_1 = module_0.Return()
    return_1.value = 'y'
    function_def_0.body.append(return_1)
    yield_0 = module_0.Yield()
    yield_0.value = '\U0007fa30'

# Generated at 2022-06-25 22:21:49.249639
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = '5t$'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 == function_def_0

# Generated at 2022-06-25 22:21:51.696524
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
    except TypeError as exc:
        assert 'required positional argument' in str(exc)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:22:00.071672
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_string = 'assert True'
    function_def_0 = ast.parse(test_string).body[0]
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    str_0 = function_def_1.body[0].targets[0].id
    str_1 = 'exc'
    assert (str_0 == str_1)
    str_2 = function_def_1.body[3].value.id
    str_3 = 'StopIteration'
    assert (str_2 == str_3)

# Generated at 2022-06-25 22:22:01.638842
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:02.611000
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:12.477763
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:12.981268
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass

# Generated at 2022-06-25 22:22:20.583429
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3 as module_0
    str_0 = '5t$'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

if __name__ == '__main__': 
    test_case_0()
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:22:24.496565
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:25.274649
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:30.704367
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef('5t$')
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

test_case_0()
test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:22:34.944629
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:39.534287
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$'
    function_def_0 = module_0.FunctionDef(*str_0)
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:22:42.031175
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    try:
        test_case_0()
    except:
        print('Exception raised')

test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:22:47.545431
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def_0 = 'def fn():\n    yield 1\n    return 5'
    as_t_0 = compile(def_0, '', 'exec', ast.PyCF_ONLY_AST)
    function_def_0 = as_t_0.body[0]
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(as_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert 0



# Generated at 2022-06-25 22:23:02.118200
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    str_0 = '`iH'
    function_def_0 = module_0.FunctionDef(*str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:06.552838
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


if __name__ == '__main__':
    import sys
    import os
    import pytest
    print(pytest.main(
        [
            os.path.join(os.path.dirname(__file__), __file__),
            '-s',
        ] + sys.argv[1:]
    ))

# Generated at 2022-06-25 22:23:07.536218
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:23:08.382943
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:23:11.658033
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestReturnFromGeneratorTransformer_visit_FunctionDef))
    runner = unittest.TextTestRunner()
    runner.run(suite)


# Generated at 2022-06-25 22:23:16.517224
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert_equal(function_def_1, function_def_0)

# Generated at 2022-06-25 22:23:17.386163
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:23:20.246123
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

# Test case for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:23:24.153064
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:23:26.016647
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:23:47.349745
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:23:48.062803
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:23:48.807902
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()



# Generated at 2022-06-25 22:23:50.182413
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()




# Generated at 2022-06-25 22:23:55.420968
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    function_def_0 = module_0.FunctionDef()
    returns = [
        (function_def_0, module_0.Return())
    ]
    return_from_generator_transformer_0._find_generator_returns = lambda _: returns

    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_0.body == function_def_1.body


# Generated at 2022-06-25 22:23:56.907764
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    #TODO: Write test
    #assert False
    assert True

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:24:00.338777
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = "5t$`"
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:24:05.206755
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 == function_def_0


# Generated at 2022-06-25 22:24:07.664324
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

__all__ = ['test_case_0', 'test_ReturnFromGeneratorTransformer_visit_FunctionDef']
from ..utils import trim_docstring
__doc__ = trim_docstring(__doc__)

# Generated at 2022-06-25 22:24:13.880083
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    # Testing for ValueError (Str)
    try:
        function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    except ValueError as e:
        if type(e) != ValueError:
            raise
        else:
            pass


# Generated at 2022-06-25 22:25:03.322070
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:04.265310
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
# test_case_0()

# Generated at 2022-06-25 22:25:08.717826
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    expect_0 = 'm^-@o'
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert(expect_0 == function_def_1)

# Generated at 2022-06-25 22:25:09.470784
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:25:13.493768
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 == module_0.Module()


# Generated at 2022-06-25 22:25:17.085496
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = None
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:25:17.768681
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:25:21.333902
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:25.106132
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:28.412429
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:26:24.393121
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef(*'5t$`')
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer('5t$`')
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:26:28.447358
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:26:32.107750
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:26:34.143032
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    r"""Running tests for method visit_FunctionDef of class ReturnFromGeneratorTransformer:
            - function_def_0
    """
    test_case_0()
    return None

# Generated at 2022-06-25 22:26:35.042617
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:26:39.046667
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    #assert function_def_1 == function_def_0

# Generated at 2022-06-25 22:26:40.983019
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:26:41.695572
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:26:43.759124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    client = ReturnFromGeneratorTransformer('5t$`')
    function_def = module_0.FunctionDef(*'5t$`')
    assert client.visit_FunctionDef(function_def) is function_def


# Generated at 2022-06-25 22:26:44.449385
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert test_case_0() is None

# Generated at 2022-06-25 22:27:44.539931
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
    except AssertionError as e:
        if str(e) == 'abc':
            return
    raise AssertionError('abc')

# Generated at 2022-06-25 22:27:48.810196
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '*6'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:27:53.152514
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is not function_def_0

# Generated at 2022-06-25 22:27:53.659259
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass

# Generated at 2022-06-25 22:28:01.404434
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = ast.parse('def foo():\n    yield 1\n    return 5')
    function_def_0 = module_0.body[0]

    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(module_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    function_def_2 = return_from_generator_transformer_0.visit_FunctionDef(function_def_1)

    assert function_def_2.body[1].value.func.id == 'StopIteration'


if __name__ == '__main__':
    import os
    import sys

# Generated at 2022-06-25 22:28:05.305534
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert (function_def_1 == function_def_0)


# Generated at 2022-06-25 22:28:09.591136
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:28:18.941530
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '5t$`'
    function_def_0 = module_0.FunctionDef(*str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(str_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    for element in function_def_1.body:
        str_1 = element.lineno
        str_2 = element.col_offset
    str_3 = function_def_1.col_offset
    str_4 = function_def_1.lineno
    str_5 = function_def_1.col_offset
    str_6 = function_def_1.lineno
    str_7 = function_def_1.col_offset
    str_8