

# Generated at 2022-06-25 22:18:26.835536
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0.body = [module_0.Yield(), module_0.Return()]
    function_def_0.returns = None
    function_def_0.name = 'foo'
    function_def_0.args = module_0.arguments()
    function_def_0.returns = None
    function_def_0.decorator_list = None
    function_def_0.kwonlyargs = None
    function_def_0.kw_defaults = None
    function_def_0.kwarg = None
    function_def_0

# Generated at 2022-06-25 22:18:32.325193
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    functiondef_0 = module_0.FunctionDef('generator', module_0.arguments([]), [], [], None, None)
    return return_from_generator_transformer_0.visit_FunctionDef(functiondef_0)

# Generated at 2022-06-25 22:18:36.469055
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_0.body.append(return_from_generator_transformer_0.visit_FunctionDef())


# Generated at 2022-06-25 22:18:43.988685
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    f_n_0 = module_0.FunctionDef(name='foo', args=module_0.arguments())
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(f_n_0)
    assert isinstance(function_def_0, module_0.FunctionDef)


# Generated at 2022-06-25 22:18:50.162652
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    node_0 = module_0.FunctionDef(id="fn", args=object, body=[object], decorator_list=[object], returns=object)
    node_0 = return_from_generator_transformer_0.visit_FunctionDef(node_0)
    return node_0


# Generated at 2022-06-25 22:18:57.961656
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef('GenericVisitor', [], [], [], None, None)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:19:08.328399
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(
        name='foo',
        args=module_0.arguments(args=[], defaults=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, posonlyargs=[]),
        body=[
            module_0.Assign(targets=[module_0.Name(id='a', ctx=module_0.Load())], value=module_0.Num(n=0)),
            module_0.Return(module_0.Num(n=1))
        ],
        decorator_list=[],
        returns=None
    )


# Generated at 2022-06-25 22:19:08.926715
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:19:17.330265
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = t_ast_0.FunctionDef('fn',
                                          t_ast_0.arguments(posonlyargs=[],
                                                            args=[],
                                                            kwonlyargs=[],
                                                            kw_defaults=[],
                                                            defaults=[]),
                                          t_ast_0.stmt([t_ast_0.Expr(t_ast_0.Yield(t_ast_0.Num(1))),
                                                        t_ast_0.Return(None)]))

# Generated at 2022-06-25 22:19:26.254562
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test with typing enabled
    with typeshed.sources.TypedDict('a', 'b', 'c'):
        def test_function(self):
            '''
            def fn():
                1
                yield 1
                return 5
            '''
            a_s_t_0 = module_0.Return()
            a_s_t_1 = module_0.NameConstant(value=1)
            a_s_t_0.value = a_s_t_1
            a_s_t_2 = module_0.Yield()
            a_s_t_3 = module_0.NameConstant(value=1)
            a_s_t_2.value = a_s_t_3

# Generated at 2022-06-25 22:19:34.194614
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:38.913775
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = ast.parse('def a():\n    yield 1\n    return 5')
    a_s_t_0 = module_0
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(module_0.body[0])  # type: ignore



# Generated at 2022-06-25 22:19:41.162029
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # Missing return type for visit_FunctionDef
    # Missing call for visit_FunctionDef(node)



# Generated at 2022-06-25 22:19:51.482285
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    
    assert ReturnFromGeneratorTransformer(a_s_t_0).visit_FunctionDef(a_s_t_0.Module(body=[])) == a_s_t_0.Module(body=[])
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:59.985797
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # This is a test for the following case:
    #  - AST <module>
    #    - FunctionDef <class 'typed_ast.ast3.FunctionDef'>
        fn_0 = module_0.FunctionDef(name='foo', args=module_0.arguments(args=[],  # type: ignore
        defaults=[], vararg=None, kwonlyargs=[], kw_defaults=[],  # type: ignore
        kwarg=None, annotations={}), body=[  # type: ignore
        module_0.Expr(value=module_0.Yield(value=None)),  # type: ignore
        module_0.Return(value=module_0.Num(n=0))],  # type: ignore
        decorator_list=[], returns=None)  # type: ignore

# Generated at 2022-06-25 22:20:06.177810
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    assert 1 == 1
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_0 = module_0.FunctionDef("no_yield", [], [], [], [], None)
    a_s_t_1.new_list(list())
    assert a_s_t_1 == a_s_t_1
    assert "no_yield" == "no_yield"
    assert isinstance(function_def_0, module_0.FunctionDef)
    function_def_0_output_variable_0 = return_from_generator_transformer_1.visit_FunctionDef(function_def_0)
    assert function_def_0_output_variable

# Generated at 2022-06-25 22:20:16.179975
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)

# Generated at 2022-06-25 22:20:24.195195
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    a_s_t_0.body = [module_0.FunctionDef(
        name='fn',
        args=module_0.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]),
        body=[module_0.Yield(
            value=module_0.Num(n=1)),
            module_0.Return(value=module_0.Num(n=5))],
        decorator_list=[],
        returns=None)]


# Generated at 2022-06-25 22:20:31.471253
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef('name_0', [], [], [], [], None, 'annotations_0')
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

test_cases = [
    (test_case_0, 'test_case_0'),
    (test_ReturnFromGeneratorTransformer_visit_FunctionDef, 'test_ReturnFromGeneratorTransformer_visit_FunctionDef'),
]

# Generated at 2022-06-25 22:20:35.859214
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return None


# Generated at 2022-06-25 22:20:46.830118
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree_0 = module_0.parse("def fn():\n    yield 1\n    return 5")
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    module_0.copy_location(return_from_generator_transformer_0, tree_0)
    module_0.fix_missing_locations(return_from_generator_transformer_0)

# Generated at 2022-06-25 22:20:51.890203
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Test Arguments
    function_def_0 = module_0.FunctionDef()

    # Invocation of method
    result = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    if result is not function_def_0:
        print("Error: visit_FunctionDef method of class ReturnFromGeneratorTransformer returned " + result.__repr__() + " instead of " + function_def_0.__repr__() + " as expected")

# Generated at 2022-06-25 22:20:55.606657
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)


# Generated at 2022-06-25 22:21:00.073013
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    _input_0_0 = return_from_generator_transformer_0.visit_FunctionDef(node=None)
    assert_equal(_input_0_0, None)


# Generated at 2022-06-25 22:21:04.638665
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    function_def_0 = module_0.FunctionDef('f', [], [], [], [])
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)



# Generated at 2022-06-25 22:21:18.561211
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    func_0 = module_0.FunctionDef('foo', [], [], [], None, None)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)
    func_1 = module_0.FunctionDef('foo', [], [], [], None, None)
    return_from_generator_transformer_2 = ReturnFromGeneratorTransformer(a_s_t_0)
    func_2 = module_0.FunctionDef('foo', [], [], [], None, None)

# Generated at 2022-06-25 22:21:30.597616
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    executable_object_0 = ast.FunctionDef(
        name='fn',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[ast.Expr(value=ast.Yield(value=ast.Num(n=1))), ast.Return(value=ast.Num(n=5))],
        decorator_list=[],
        returns=None,
        type_comment=None
    )
    a_s_t_0 = ast.parse(
        source='def fn():\n    yield 1\n    return 5',
        mode='exec'
    )
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:21:37.736491
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.parse("x")
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    ast.fix_missing_locations(a_s_t_0)
    a_s_t_1 = return_from_generator_transformer_0.visit(a_s_t_0)
    SOURCE_CODE_0 = """
x = 1
    """
    assert(str(a_s_t_1) == SOURCE_CODE_0)


# Generated at 2022-06-25 22:21:44.474564
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef()
    a_s_t_1.body = []
    a_s_t_1.args = module_0.arguments()
    a_s_t_1.decorator_list = []
    a_s_t_1.name = "fn"
    return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1)

# Generated at 2022-06-25 22:21:51.881903
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def __init__():
        ReturnFromGeneratorTransformer.__init__(self, ast)

    a_s_t_2 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_2)
    a_s_t_4 = module_0.FunctionDef()
    # a_s_t_4.name = 
    # a_s_t_4.args = 
    # a_s_t_4.body = 
    # a_s_t_4.decorator_list = 
    # a_s_t_4.returns = 
    return_from_generator_transformer_0.visit_FunctionDef(a_s_t_4)
    # assert a_s_t_4

# Generated at 2022-06-25 22:21:58.546283
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    return_from_generator_transformer.visit_FunctionDef(None)

# Generated at 2022-06-25 22:22:07.940449
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    module_0 = __import__("typed_ast._ast3", fromlist=("AST",), level=0)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.target = return_from_generator_transformer_0.target
    return_from_generator_transformer_0.tree_changed = return_from_generator_transformer_0.tree_changed
    return_from_generator_transformer_0.generic_visit = return_from_generator_transformer_0.generic_visit

# Generated at 2022-06-25 22:22:11.906044
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:22:21.026492
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fn_0 = ast.FunctionDef('test', ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), [ast.Return(value=ast.Constant(value=1))], [], None)
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:22.953334
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    assert return_from_generator_transformer_0.tree == a_s_t_0


# Generated at 2022-06-25 22:22:25.972999
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert isinstance(return_from_generator_transformer_0, module_0.NodeTransformer)


# Generated at 2022-06-25 22:22:31.114357
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_1 = function_def_0.copy()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_1)


# Generated at 2022-06-25 22:22:31.827452
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:22:36.582478
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    a_s_t_1 = module_0.FunctionDef()
    a_s_t_0 = a_s_t_1

    return_from_generator_transformer_0.visit_FunctionDef(a_s_t_0)

# Generated at 2022-06-25 22:22:38.922215
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:45.114487
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-25 22:22:51.522242
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    function_0 = ast.FunctionDef(name='fn', body=[ast.Yield(value=ast.Num(n=1)), ast.Return(value=ast.Num(n=5))], decorator_list=[], args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]))
    function_0 = return_from_generator_transformer_0.visit_FunctionDef(function_0)
    assert function_0.body[1].value.value == 5

# Generated at 2022-06-25 22:22:52.636628
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer.description == "Replace return in generators with StopIteration."

# Generated at 2022-06-25 22:22:56.254392
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():  # type: ignore
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    expected_function_def = fn.__code__.co_consts[0]

# Generated at 2022-06-25 22:23:05.654958
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  # Create an instance of ReturnFromGeneratorTransformer
  return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
  # Create an instance of ast.Attribute
  attribute_0 = ast.Attribute()
  # Assign values to object attribute_0
  attribute_0.attr = 'async_generator'
  attribute_0.ctx = ast.Load()
  attribute_0.value = func
  # Create an instance of ast.Num
  num_0 = ast.Num()
  # Assign values to object num_0
  num_0.n = 0
  num_0.n = 0
  # Create an instance of ast.GeneratorExp
  generator_exp_0 = ast.GeneratorExp()
  # Assign values to object generator_exp_0
  generator_exp_0.elt = num

# Generated at 2022-06-25 22:23:07.138152
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()


# Generated at 2022-06-25 22:23:08.848710
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()


# Generated at 2022-06-25 22:23:10.469770
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()



# Generated at 2022-06-25 22:23:11.370640
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:23:14.990810
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def foo():\n  yield 1\ndef bar():\n  return 2').body[0]
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    return_from_generator_transformer.visit_FunctionDef(node)


# Generated at 2022-06-25 22:23:22.484403
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ast_0 = module_0.AST()
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(ast_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:23:27.678796
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:28.456896
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:23:33.539030
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    fun = """
    def fn():
        yield 1
        return 5
    """
    tree = ast.parse(fun)
    transformer = ReturnFromGeneratorTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert astor.to_source(tree) == astor.to_source(ast.parse(expected))

# Generated at 2022-06-25 22:23:34.353868
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert True == True


# Generated at 2022-06-25 22:23:39.638939
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


if __name__ == '__main__':
    test_case_0()
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()
    print('')

# Generated at 2022-06-25 22:23:46.636675
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    module_0.FunctionDef()
    module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:54.526492
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Test
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Test
    assert return_from_generator_transformer_0.module != None, \
            "Expected {} to be != None".format("return_from_generator_transformer_0.module")
    assert return_from_generator_transformer_0.tree != None, \
            "Expected {} to be != None".format("return_from_generator_transformer_0.tree")

# Generated at 2022-06-25 22:24:02.057169
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    function_def_2 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    function_def_3 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    function_def_4 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    a_s_t_1 = module_

# Generated at 2022-06-25 22:24:06.092718
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:24:19.111086
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Instantiate mock class, mock functions.
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    # Instantiate mock class
    a_s_t_0 = module_0.AST()

    # Instantiate mock class.
    function_def_0 = module_0.FunctionDef()

    # Call method.
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    # Check conditions.
    assert function_def_1 is not None


# Generated at 2022-06-25 22:24:21.905941
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_tuple_0 = (module_0.FunctionDef(),)
    function_def_tuple_1 = ReturnFromGeneratorTransformer._find_generator_returns(function_def_tuple_0)
    assert function_def_tuple_1 == ([],)

# Generated at 2022-06-25 22:24:24.435053
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    assert return_from_generator_transformer_0 is not None


# Generated at 2022-06-25 22:24:30.358123
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Assigning values for attributes of the class
    node = module_0.Module()
    return_from_generator_transformer = ReturnFromGeneratorTransformer(node)
    # Assigning values for attributes of the class
    node = module_0.Module()
    return_from_generator_transformer = ReturnFromGeneratorTransformer(node)
    # Checking the equality of two objects
    assert return_from_generator_transformer_0 == return_from_generator_transformer


# Generated at 2022-06-25 22:24:33.006199
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    try:
        test_case_0()
    except Exception as e:
        print('Caught exception when testing ReturnFromGeneratorTransformer: ' + str(e))

# Generated at 2022-06-25 22:24:37.444942
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:24:41.900793
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert isinstance(function_def_1, module_0.FunctionDef)


# Generated at 2022-06-25 22:24:42.686904
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:24:45.746886
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0 is not None


# Generated at 2022-06-25 22:24:53.335133
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Try initializing with a tree node
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    # Try initializing with a tree node and some additional properties

# Generated at 2022-06-25 22:25:09.367219
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:25:12.887419
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:16.682495
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:25:17.916353
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast = module_0.AST()
    ReturnFromGeneratorTransformer(ast)


# Generated at 2022-06-25 22:25:20.371937
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    assert ReturnFromGeneratorTransformer(a_s_t_0).tree == a_s_t_0


# Generated at 2022-06-25 22:25:27.626992
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # (1)
    def test_func():
        yield 1
        return 5
    # (2)
    def test_func2():
        yield 1
        return  # should be skipped
    # (3)
    def test_func3():
        return 5  # should be skipped
    # (4)
    def test_func4():
        yield 5
        return 5  # should be handled
    # (5)
    def test_func5():
        yield 5

# Generated at 2022-06-25 22:25:30.995860
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:34.935478
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    root = ast.parse('def fn():\n  yield 1\n  return 1')
    transformer = ReturnFromGeneratorTransformer(root)
    node = root.body[0]

    parent, replace = transformer._find_generator_returns(node)[0]
    transformer._replace_return(parent, replace)
    assert transformer._tree_changed

# Generated at 2022-06-25 22:25:38.470742
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 == None


# Generated at 2022-06-25 22:25:42.441760
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:26:16.366045
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    ast_ = module_0.AST()
    return_from_generator_transformer = ReturnFromGeneratorTransformer(ast_)
    assert return_from_generator_transformer._ast == ast_


# Generated at 2022-06-25 22:26:25.518387
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    # return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)
    # function_def_0 = module_0.FunctionDef()
    # function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    # assert function_def_1 is not None
    # assert hasattr(function_def_1, 'name')
    # assert function_def_1.name == 'yield_test'
    # assert hasattr(function_def_1, 'args')
    # assert isinstance(function_def_1.args, ast.arguments)
    # assert hasattr(function_def_1.args, 'args')
    # assert function_def_1.args.args == []


# Generated at 2022-06-25 22:26:30.436320
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0 is not None


# Generated at 2022-06-25 22:26:31.528592
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Test of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:26:35.455155
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:26:40.141207
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:26:44.173239
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is function_def_0

# Generated at 2022-06-25 22:26:46.553708
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Initialization
    a_s_t_2 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_2)

    assert return_from_generator_transformer_0


# Generated at 2022-06-25 22:26:48.190422
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

if __name__ == "__main__":
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:26:50.432421
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
    except Exception:
        print('Exception: test_ReturnFromGeneratorTransformer_visit_FunctionDef')
        e = sys.exc_info()[1]
        print(e)
        assert False

# Generated at 2022-06-25 22:27:56.786451
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    snippet_0 = ReturnFromGeneratorTransformer()


# Generated at 2022-06-25 22:27:59.305767
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    u_n_i_t_test_ReturnFromGeneratorTransformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)



# Generated at 2022-06-25 22:28:01.032296
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t = module_0.AST()
    return_from_generator_transformer = ReturnFromGeneratorTransformer(a_s_t)


# Generated at 2022-06-25 22:28:08.190822
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer