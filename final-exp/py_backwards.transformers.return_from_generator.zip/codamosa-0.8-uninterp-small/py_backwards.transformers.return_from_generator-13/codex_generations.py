

# Generated at 2022-06-25 22:18:21.981695
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def root():
        def fn():
            yield 1
            return 5

    r = root()

    root_ast = ast.parse(inspect.getsource(root))

    fn_def = root_ast.body[0].body[0]

    generator_returns = return_from_generator_transformer_0._find_generator_returns(fn_def)

# Generated at 2022-06-25 22:18:23.463728
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:18:31.559425
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def def_fn_fake(node):
        node.body = [
            ast.Yield(value=ast.Num(n=1)),
            ast.Return(
                value=ast.Num(n=5)
            )
        ]
        return_from_generator_transformer_0._find_generator_returns = lambda node: [
            (node, ast.Return(
                value=ast.Num(n=5)
            ))
        ]
        assert ast.dump(node) == "FunctionDef(name='fn', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Yield(value=Num(n=1)), Return(value=Num(n=5))], decorator_list=[], returns=None)"

# Generated at 2022-06-25 22:18:32.037158
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert True == True

# Generated at 2022-06-25 22:18:37.431762
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = ast.parse('def fn():\n    yield 1\n    return 5')
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = return_from_generator_transformer_0.visit(a_s_t_0)
    assert a_s_t_1.body[0].body[2].value.func.id == 'StopIteration'

# Generated at 2022-06-25 22:18:45.072508
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_0 = ast.AST()
    try:
        return_from_generator_transformer_0.visit_FunctionDef(a_s_t_0)
    except Exception as e:
        assert type(e) == TypeError
    else:
        assert False


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:18:47.888016
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:18:52.672880
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:19:03.067549
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Instantiate the AST
        a_s_t_1 = ast.parse("def a(arg):\n    return arg")

        # Instantiate a ReturnFromGeneratorTransformer
        return_from_generator_transformer_1 = ReturnFromGeneratorTransformer()

        # Define a dictionary that will serve as the environment for the evaluation
        env = {}

        # Call the visit_FunctionDef method on the AST
        f_evaluation = return_from_generator_transformer_1.visit_FunctionDef(a_s_t_1.body[0])

        # Assert the result of the evaluation
        assert f_evaluation == ast.parse("def a(arg):\n    exc = StopIteration()\n    exc.value = arg\n    raise exc").body[0]



# Generated at 2022-06-25 22:19:12.772532
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """
    Notes:
    * _tree_changed is set to False (0) by default
    * _tree_changed is set to True (1) by default if class has visit_FunctionDef method
    """
    # Lets define the variables
    a_s_t_0 = None
    a_s_t_1 = None
    # Lets initialize the class
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # Lets call the method
    return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1)
    # Lets test if the _tree_changed is set as expected
    assert return_from_generator_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:19:18.701873
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:19:22.326128
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = test_case_0()
    str_0 = module_0.body[0].body[2].value.elts[0]
    str_1 = 'exc = StopIteration()'
    assert str_0 == str_1

import typed_ast.ast3 as module_1


# Generated at 2022-06-25 22:19:27.315392
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = ReturnFromGeneratorTransformer(None)
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_1 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_1)
    return_from_generator_transformer_0.visit(var_1)

# Generated at 2022-06-25 22:19:34.336776
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(module_0.parse('def fn():\n    yield 1\n    return 5'))
    return_from_generator_transformer_0.visit(return_from_generator_transformer_0._find_generator_returns(return_from_generator_transformer_0._find_generator_returns(return_from_generator_transformer_0.visit_FunctionDef(module_0.parse('def fn():\n    yield 1\n    return 5')))))


# Generated at 2022-06-25 22:19:35.697639
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert hasattr(ReturnFromGeneratorTransformer, "__init__")


# Generated at 2022-06-25 22:19:38.908986
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = ast.parse('1').body[0]
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    assert return_from_generator_transformer_0.tree is var_0


# Generated at 2022-06-25 22:19:48.180611
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    class mock_FunctionDef(object):
        def __init__(self):
            self.body = [1, 2, 3]

    class mock_Return(object):
        def __init__(self):
            self.value = None

    class mock_List(list):
        def index(self, item):
            return 1

        def pop(self, index):
            assert index == 1

        def insert(self, index, item):
            assert index == 1

    class mock_visit_FunctionDef(object):

        def visit(self, node):
            return self

        def generic_visit(self, node):
            return self

    var_1 = mock_visit_FunctionDef()
    var_4 = mock_FunctionDef()
    var_5 = mock_Return()
    var_4.body = mock_List()

# Generated at 2022-06-25 22:19:49.885298
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:19:50.879532
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:59.417354
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    var_2 = return_from_generator_transformer_0._tree_changed
    var_3 = module_0.parse('def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc')
    var_4 = module_0.dump(var_3) == module_0.dump(var_1)

# Generated at 2022-06-25 22:20:10.373950
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = module_0.parse('def fn():\n    yield 1\n    return 5')
    var_1 = ReturnFromGeneratorTransformer(var_0)
    try:
        var_2 = var_1.visit(var_0)
    except:
        var_2 = None
    try:
        var_3 = var_1.visit(var_0)
    except:
        var_3 = None



# Generated at 2022-06-25 22:20:11.336161
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:20:12.799228
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()


# Generated at 2022-06-25 22:20:17.549558
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Try to create instance of ReturnFromGeneratorTransformer with wrong type of argument 'tree' (is not a instance of Module)
    with pytest.raises(TypeError, match="Invalid type for parameter tree. Expected 'Module', got 'ClassDef'!"):
        return_from_generator_transformer_2 = ReturnFromGeneratorTransformer(module_0.ClassDef(name='A'))

# Generated at 2022-06-25 22:20:21.438662
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    assert return_from_generator_transformer_0


# Generated at 2022-06-25 22:20:25.361873
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # PyUnit TODO: Move this into a test decorator.
    try:
        test_case_0()
    except Exception:
        import traceback
        import sys
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    import pytest
    pypylog_0 = pytest.main(['-s', '--pdb', 'test/test_return_from_generator.py'])

# Generated at 2022-06-25 22:20:29.069319
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:20:38.781726
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

    def fn_0():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

# Generated at 2022-06-25 22:20:43.238991
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)



# Generated at 2022-06-25 22:20:45.987970
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_2 = module_0.parse('def fn():\n    yield 1\n    return 5')
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_2)


# Generated at 2022-06-25 22:21:02.860521
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    var_2 = eval(test_case_0.__code__.co_consts[0])
    var_3 = test_case_0.__code__.co_varnames[0]
    var_4 = test_case_0.__code__.co_varnames[1]
    var_5 = test_case_0.__code__.co_varnames[2]
    var_6 = test_case_0.__code__.co_varnames[3]
    var_7 = module_0.parse(var_2)
    var_8 = ReturnFromGeneratorTransformer(var_7)
    var_9 = var_8.visit_FunctionDef(var_7)

# Generated at 2022-06-25 22:21:10.288168
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # String of the function
    str_0 = 'def fn():\n    yield 1\n    return 5'

    # Parse the tree
    var_0 = module_0.parse(str_0)

    # Create a ReturnFromGeneratorTransformer
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)

    # Compile the file
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:21:10.873695
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-25 22:21:17.905295
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import CompilerError
    from typed_ast.ast3 import FunctionDef
    try:
        test_case_0()
    except SyntaxError as ex:
        print(ex)
        pass
    except CompilerError as ex:
        print(ex)
        pass
    except TypeError as ex:
        print(ex)
        pass
    except AssertionError as ex:
        print(ex)
        pass

    assert(str(ReturnFromGeneratorTransformer(FunctionDef)) == 'None')

# Generated at 2022-06-25 22:21:24.707926
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:21:33.274653
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    str_1 = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    var_2 = module_0.parse(str_1)
    return str(var_1) == str(var_2)


# Generated at 2022-06-25 22:21:34.844681
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:21:39.102084
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:21:43.395907
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    assert_equal(return_from_generator_transformer_0.visit(var_0), var_0)

# Generated at 2022-06-25 22:21:47.037269
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:22:04.852089
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = test_case_0()
    str_0 = module_0.unparse(var_0).strip()
    str_1 = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    assert str_0 == str_1


# Generated at 2022-06-25 22:22:05.742260
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass



# Generated at 2022-06-25 22:22:09.730430
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:22:11.435494
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(module_0.arguments(
    ), module.replacements())

# Generated at 2022-06-25 22:22:12.249011
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:22:13.055184
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass


# Generated at 2022-06-25 22:22:22.096532
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    # Verify that instances of Local and Enclosure are being stored correctly in transformer
    assert return_from_generator_transformer_0.scope_handlers[0].local_to_name.has_key(var_0.body[0])
    assert return_from_generator_transformer_0.scope_handlers[1].local_to_name.has_key(var_0.body[0].body[0].value)

# Generated at 2022-06-25 22:22:23.163406
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # Call test_case_0()
    test_case_0()

# Generated at 2022-06-25 22:22:31.375105
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5
    str_0 = 'def fn():\n    yield 1\n    return 5'
    str_1 = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    var_0 = module_0.parse(str_0)
    var_1 = module_0.parse(str_1)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()
    var_2 = return_from_generator_transformer_0.visit(var_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer()
    var_3 = return_from_generator_transformer_1.visit(var_2)
    return_

# Generated at 2022-06-25 22:22:32.203226
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:23:04.668547
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Unit tests for ReturnFromGeneratorTransformer
    var_0 = ReturnFromGeneratorTransformer(None)
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_1 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_1)
    var_2 = return_from_generator_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:23:05.654493
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # TODO
    assert False

# Generated at 2022-06-25 22:23:09.547334
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:23:11.334756
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 22:23:17.072020
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = module_0.parse('def fn():\n    yield 1\n    return 5')
    var_1 = ReturnFromGeneratorTransformer(var_0)
    assert var_1
    try:
        var_2 = ReturnFromGeneratorTransformer("")
    except Exception:
        var_2 = False
    assert not var_2
    try:
        var_3 = ReturnFromGeneratorTransformer("")
    except Exception:
        var_3 = False
    assert not var_3


# Generated at 2022-06-25 22:23:18.459128
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert not hasattr(ReturnFromGeneratorTransformer(None), "source_tree")


# Generated at 2022-06-25 22:23:19.270949
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:23:23.114067
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:23:24.153071
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert 1 == 1


# Generated at 2022-06-25 22:23:28.706941
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:24:02.281302
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)



# Generated at 2022-06-25 22:24:03.124812
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass # TODO


# Generated at 2022-06-25 22:24:10.597183
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    assert isinstance(var_1, module_0.Module)
    assert isinstance(var_1.body[0], module_0.FunctionDef)
    assert isinstance(var_1.body[0].body[0], module_0.Expr)
    assert isinstance(var_1.body[0].body[0].value, module_0.Yield)

# Generated at 2022-06-25 22:24:12.160588
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass


# Generated at 2022-06-25 22:24:15.698575
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:24:21.694106
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_0 = None
    try:
        var_1 = return_from_generator_transformer_0.visit(var_0)
    except Exception as var_2:
        var_3 = """'NoneType' object has no attribute 'body'"""
        assert var_2.args[0] == var_3


# Generated at 2022-06-25 22:24:27.280879
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    assert not hasattr(var_1, 'body')


# Generated at 2022-06-25 22:24:28.143173
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:24:28.919141
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert test_case_0()

# Generated at 2022-06-25 22:24:32.757114
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    var_1 = ReturnFromGeneratorTransformer(var_0)
    var_2 = var_1.visit(var_0)

# Generated at 2022-06-25 22:25:44.553052
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)
    assert var_1.body[1].value.value.body[0].value.value.value.func.id == 'StopIteration'


# Generated at 2022-06-25 22:25:45.723992
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:25:47.687176
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = module_0.parse('def fn():\n    yield 1\n    return 5')
    var_1 = ReturnFromGeneratorTransformer(var_0)


# Generated at 2022-06-25 22:25:48.334848
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass # could not parse


# Generated at 2022-06-25 22:25:49.393743
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer()


# Generated at 2022-06-25 22:25:52.617162
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = module_0.parse('def fn():\n    yield 1\n    return 5')
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)



# Generated at 2022-06-25 22:25:58.063541
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    try:
        # Test 1
        str_0 = 'def fn():\n    yield 1\n    return 5'
        var_0 = module_0.parse(str_0)
        return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
        # Unit test for visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef
        try:
            return_from_generator_transformer_0.visit_FunctionDef(var_0)
        except Exception:
            return None
    except Exception:
        return None

# Generated at 2022-06-25 22:26:00.765192
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:26:01.473525
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:26:11.838557
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    str_1 = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    var_2 = module_0.parse(str_1)
    assert var_1 == var_2


# Generated at 2022-06-25 22:27:32.163370
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    module_0 = test_case_0()
    str_0 = module_0.body[0].body[1].value.exc.name
    assert str_0 == 'StopIteration'
    int_0 = module_0.body[0].body[1].value.exc.ctx.__class__
    assert int_0 == module_0.Store
    str_1 = module_0.body[0].body[1].value.exc.ctx.__class__
    assert str_1 == 'Store'
    str_2 = module_0.body[0].body[1].value.exc.ctx.__class__
    assert str_2 == 'Store'
    str_3 = module_0.body[0].body[1].value.func.__class__
    assert str_3 == 'Name'
    str_4

# Generated at 2022-06-25 22:27:33.118792
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)

# Generated at 2022-06-25 22:27:34.185855
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert type(ReturnFromGeneratorTransformer()) == ReturnFromGeneratorTransformer


# Generated at 2022-06-25 22:27:36.961940
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:27:39.634460
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:27:44.959669
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    var_0 = 'def fn():\n    yield 1\n    return 5'
    var_1 = module_0.parse(var_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(var_1)
    var_2 = return_from_generator_transformer_1.visit(var_1)
    var_3 = return_from_generator_transformer_1.visit_FunctionDef(var_2)
    var_4 = module_0.FunctionDef(args=var_3.args, body=var_3.body, decorator_list=[], name=var_3.name, returns=var_3.returns, type_comment=var_3.type_comment)
    var_5 = module_0.parse(str(var_4))
    var

# Generated at 2022-06-25 22:27:48.638259
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)


# Generated at 2022-06-25 22:27:52.317154
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = 'def fn():\n    yield 1\n    return 5'
    var_0 = module_0.parse(str_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(var_0)
    var_1 = return_from_generator_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:27:56.544835
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_4 = 'def fn():\n    yield 1\n    return 5'
    var_6 = module_0.parse(str_4)
    return_from_generator_transformer_6 = ReturnFromGeneratorTransformer(var_6)
    var_7 = return_from_generator_transformer_6.visit(var_6)

# Generated at 2022-06-25 22:28:03.706071
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    var_0 = test_case_0()
    assert_equals(var_0.body[0].lineno, 1)
    assert_equals(var_0.body[0].col_offset, 0)
    assert_equals(var_0.body[0].body[0].lineno, 2)
    assert_equals(var_0.body[0].body[0].col_offset, 4)
    assert_equals(var_0.body[0].body[1].lineno, 3)
    assert_equals(var_0.body[0].body[1].col_offset, 4)
    assert_equals(var_0.body[0].body[1].value.lineno, 3)