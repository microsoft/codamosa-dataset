

# Generated at 2022-06-25 22:18:25.615092
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    node_0 = module_0.FunctionDef()
    node_2 = module_0.Name()
    node_2.id = "GenExp"
    node_2.ctx = module_0.Load()
    node_1 = module_0.GeneratorExp()
    node_1.elt = node_2
    node_4 = module_0.Name()
    node_4.id = "b"
    node_4.ctx = module_0.Load()
    node_3 = module_0.comprehension()
    node_3.target = node_4
    node_6 = module_0.Name()
    node_

# Generated at 2022-06-25 22:18:31.104308
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1)


# Generated at 2022-06-25 22:18:38.464640
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    class test0_FunctionDef_class:
        def __init__(self):
            self.body = []

    test0_FunctionDef_instance = test0_FunctionDef_class()
    return_from_generator_transformer_0.visit_FunctionDef(test0_FunctionDef_instance)

    # Test for exception

# Generated at 2022-06-25 22:18:45.748678
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    module_1 = module_0.Module([])
    function_def_0 = module_0.FunctionDef('fn', [], [], [], None, None)
    try:
        return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    except Exception as e:
        assert type(e) == AttributeError


# Generated at 2022-06-25 22:18:52.741747
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    function_def_0 = module_0.FunctionDef('test_1', module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), [], [],)
    function_def_0_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_0_1 is not None


# Generated at 2022-06-25 22:19:03.119200
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    b_s_t_0 = module_0.FunctionDef(name=module_0.Name(id='foo_0', ctx=module_0.Load()), args=module_0.arguments(args=[], vararg=None, kwarg=None, kwonlyargs=[], defaults=[], kw_defaults=[]), body=[module_0.Return(value=module_0.Num(n=0))], decorator_list=[], returns=None)
    result_0 = return_from_generator_transformer_0.visit_FunctionDef(b_s_t_0)
    assert result_0 == None

#

# Generated at 2022-06-25 22:19:13.385047
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    s_t_node_0 = module_0.stmt()
    try:
        # We need to cast s_t_node_0 to any because AST doesn't have a type for stmt, but that's okay because
        # we'll be catching the TypeError
        return_from_generator_transformer_0.visit_FunctionDef(s_t_node_0)
    except TypeError:
        pass


# We need to create an AST, then create a ReturnFromGeneratorTransformer with that AST
a_s_t_0 = module_0.AST()
return_from_generator_transformer_0 = ReturnFromGeneratorTrans

# Generated at 2022-06-25 22:19:19.959166
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()

# Generated at 2022-06-25 22:19:29.050922
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    a_s_t_1 = module_0.AST()
    function_def_0 = module_0.FunctionDef(name='fn', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Expr(value=module_0.Yield(value=module_0.Num(n=1))), module_0.Return(value=module_0.Num(n=5))], decorator_list=[], returns=None)
    a_s_t_1.body = [function_def_0]


# Generated at 2022-06-25 22:19:34.289889
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Initialization
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    node = module_0.FunctionDef()
    # Action
    result_node_0 = return_from_generator_transformer_0.visit_FunctionDef(node)
    # Assertion
    pass


# Generated at 2022-06-25 22:19:47.604773
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:48.187429
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass

# Generated at 2022-06-25 22:19:57.733817
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_0.body.extend([module_0.FunctionDef(name='fn', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Expr(value=module_0.Yield(value=module_0.Num(n=1))), module_0.Return(value=module_0.Num(n=5))], decorator_list=[], returns=None, type_comment=None)])

# Generated at 2022-06-25 22:20:04.909198
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    #  def fn():
    #    yield 1
    #    return 5
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = module_0.FunctionDef('fn', module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), [module_0.Expr(module_0.Yield(value=module_0.Constant(1))), module_0.Return(value=module_0.Constant(5))], [], None)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_1)

# Generated at 2022-06-25 22:20:14.764813
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    class_def_0 = module_0.FunctionDef()
    class_def_0.name = "name_0"
    stmt_0 = module_0.Return()
    stmt_0.value = 1
    class_def_0.body = [stmt_0]
    module_0.FunctionDef.visit_FunctionDef = lambda self, visitor: visitor.visit_FunctionDef(class_def_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)

# Generated at 2022-06-25 22:20:19.460844
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)



# Generated at 2022-06-25 22:20:25.896338
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast
    import astunparse
    a_s_t_0 = ast.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # Try with a function that does not need any transformation
    function_def_0 = ast.FunctionDef(name='foo', params=[], body=[ast.Pass()], decorator_list=[], returns=None)
    function_def_0 = return_from_generator_transformer_0.visit(function_def_0)
    assert astunparse.unparse(function_def_0) == 'def foo():\n    pass'
    # Try with a generator

# Generated at 2022-06-25 22:20:34.684924
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_1)
    fn_0 = module_0.FunctionDef('fn', [], [], [module_0.Yield(module_0.Num(1))], [], None, [], [module_0.Return(module_0.Num(5))])

# Generated at 2022-06-25 22:20:44.262812
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef("foo", [], [module_0.Pass()], [module_0.Expr(module_0.Yield(module_0.Num(1)))], module_0.Return(module_0.Num(5)))
    a_s_t_1 = return_from_generator_transformer_0.visit(a_s_t_1)
    assert isinstance(a_s_t_1, module_0.FunctionDef)
    assert a_s_t_1.name == "foo"
    assert a_s_t_1.args is None
    assert a

# Generated at 2022-06-25 22:20:51.076757
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test with a simple function
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    let(fname)
    let(args)
    fname = module_0.Name()
    fname.id = 'foo'
    fname.ctx = module_0.Load()
    args = module_0.arguments()
    args.args = []
    args.vararg = None
    args.kwarg = None
    args.kwonlyargs = []
    args.defaults = []
    args.kw_defaults = []
    let(foo)
    foo = module_0.FunctionDef()
    foo.name = 'foo'
    foo.args = args

# Generated at 2022-06-25 22:20:59.566479
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
    except Exception:
        pass


# Generated at 2022-06-25 22:21:01.302776
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = test_case_0()
    assert (module_0 == None)


# Generated at 2022-06-25 22:21:02.122267
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:21:02.877711
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:11.063346
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:12.301731
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:19.856426
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:31.564359
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    function_def_2 = return_from_generator_transformer_0.visit_FunctionDef(function_def_1)

    assert function_def_1 is None
    assert function_def_2 is None

# Generated at 2022-06-25 22:21:32.368197
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:38.945360
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:54.621992
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:01.679243
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_2 = module_0.FunctionDef()
    str_1 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_1 = {str_1: str_1, str_1: str_1}
    a_s_t_1 = module_0.AST(**dict_1)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_3 = return_from_generator_transformer_1.visit_FunctionDef(function_def_2)

# Generated at 2022-06-25 22:22:08.244067
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:10.419501
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    #self.assertEqual(expected, ReturnFromGeneratorTransformer.visit_FunctionDef(node))
    assert False # TODO: implement your test here



# Generated at 2022-06-25 22:22:19.385000
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:20.285540
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:21.102738
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:22:21.882807
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:29.838949
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0.args = module_0.arguments()

    node_0 = module_0.FunctionDef()

    # Ensures that the transformed node is semantically identical
    # to the original node.
    assert function_def_0.__dict__ == function_def_0.__dict__


# Generated at 2022-06-25 22:22:31.142867
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    #Generated code
    #Please write your own tests for this method
    #TODO
    pass

# Generated at 2022-06-25 22:23:10.468973
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # class ast.FunctionDef(arguments, name, body, decorator_list, returns, type_comment)
    # typed_ast.ast3.FunctionDef(arguments, name, body, decorator_list, returns)
    # typed_ast.ast3.FunctionDef(arguments, name, body, decorator_list)
    # typed_ast.ast3.FunctionDef(arguments, name, body)
    function_def_0 = ast.FunctionDef()
    function_def_1 = ReturnFromGeneratorTransformer().visit_FunctionDef(function_def_0)
    assert isinstance(function_def_1, ast.FunctionDef)


# Generated at 2022-06-25 22:23:12.659766
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
    test_case_0()
    test_case_0()
    assert True # TODO: implement your test here

test_case_0()

# Generated at 2022-06-25 22:23:18.942076
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:20.246121
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    has_changed = test_case_0()
    assert has_changed == False

# Generated at 2022-06-25 22:23:27.629081
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:23:35.693943
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astroid import test_utils
    from python_ta.transforms.return_from_generator import ReturnFromGeneratorTransformer
    node = test_utils.extract_node('''
    def fn(): 
        yield 1 
        return 5
    ''')
    node.parent = module_0.Module()
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit_FunctionDef(node)
    assert result.__class__.__name__ == 'FunctionDef'
    assert result.name == 'fn'
    assert len(result.body) == 4
    assert result.body[0].__class__.__name__ == 'Expr'
    assert result.body[0].value.__class__.__name__ == 'Yield'
    assert result.body[0].value.value.__

# Generated at 2022-06-25 22:23:41.794311
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:42.604896
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:23:43.486706
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    for _ in range(4 - 1):
        test_case_0()

# Generated at 2022-06-25 22:23:50.801606
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


import unittest


# Generated at 2022-06-25 22:25:15.610657
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:25:17.111219
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:25:24.063386
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

from typed_ast.ast3 import AST

from .base import BaseNodeTransformer
from ..utils.snippet import snippet, let



# Generated at 2022-06-25 22:25:25.188550
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:25:29.698914
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    print(function_def_1)

# Generated at 2022-06-25 22:25:35.636799
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:36.077870
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert True

# Generated at 2022-06-25 22:25:43.243467
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    a_s_t_1 = module_0.AST(**dict_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def

# Generated at 2022-06-25 22:25:44.408380
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Test cases for class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:25:48.748610
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    str_0 = '7Aq&I(X_SG%?3Rr_TMq'
    dict_0 = {str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    assert (return_from_generator_transformer_0.visit_FunctionDef(function_def_0) is function_def_1)