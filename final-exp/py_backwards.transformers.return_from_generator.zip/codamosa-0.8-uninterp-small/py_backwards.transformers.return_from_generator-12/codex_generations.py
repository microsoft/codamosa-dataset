

# Generated at 2022-06-25 22:18:19.472117
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef()

# Generated at 2022-06-25 22:18:28.079268
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # mock module typed_ast._ast3
    class module_0_class:
        AST = None

    module_0_instance = module_0_class()

    module_0_mock = MagicMock(return_value=module_0_instance)
    with patch.dict(sys.modules, {'typed_ast._ast3': module_0_mock}):
        from typed_ast.transforms import return_from_generator

        # mock class AST of module typed_ast._ast3
        class AST_class:
            def visit_FunctionDef(self, node):
                pass
        module_0_instance.AST = AST_class()
        return_from_generator_instance = return_from_generator.ReturnFromGeneratorTransformer(module_0_instance.AST)
        assert return_from_generator_

# Generated at 2022-06-25 22:18:34.253578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    module_0.FunctionDef()
    assert return_from_generator_transformer_0.visit_FunctionDef(None) is None
    # test code here
    # assert expected_result == result
    assert True # "Suggestion: replace this line with the test code"


# Generated at 2022-06-25 22:18:42.387606
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    assert_equal(return_from_generator_transformer_0._tree_changed, None)
    assert_equal(return_from_generator_transformer_0._tree, None)
    assert_equal(return_from_generator_transformer_0._current_line_number, None)



# Generated at 2022-06-25 22:18:49.755901
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    a_s_t_2 = module_0.FunctionDef()
    a_s_t_3 = return_from_generator_transformer_1.visit_FunctionDef(a_s_t_2)
    assert a_s_t_3 == a_s_t_2
    # TODO mock return from self.generic_visit()
    # TODO assert that self._tree_changed is True

# Generated at 2022-06-25 22:18:55.964705
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = [module_0.FunctionDef(name = 'foo',
        args = module_0.arguments(args = [module_0.arg(arg = 'a', annotation = None)],
            vararg = None, kwonlyargs = [], kw_defaults = [], kwarg = None, defaults = []),
        body = [module_0.Return(value = module_0.Num(n = 1))],
        decorator_list = [], returns = None)]
    # Run the method with an argument of a_s_t

# Generated at 2022-06-25 22:18:59.391434
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # prepare data
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef("<unknown>", None, [], [], None, "argument_0")
    # execute function
    return_from_generator_transformer_0_output = return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1)
    # evaluate results
    assert isinstance(return_from_generator_transformer_0_output, module_0.FunctionDef)
    assert return_from_generator_transformer_0_output.name == "<unknown>"
    assert return_from_generator_transformer_0_

# Generated at 2022-06-25 22:19:09.676029
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    def_0 = module_0.FunctionDef('f', [], [], module_0.Expr(module_0.Num(1)), [], None, None)
    return_from_generator_transformer_0.visit(def_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_0 = module_0.Return()
    def_1 = module_0.FunctionDef('f', [], [], module_0.Expr(module_0.Yield(module_0.Num(1))), [return_0], None, None)
   

# Generated at 2022-06-25 22:19:17.958921
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    def_0 = module_0.FunctionDef('fn', module_0.arguments([module_0.arg('a', None), module_0.arg('b', None)], None, [], [], None, []), [module_0.Expr(module_0.Call(module_0.Name('print', module_0.Load()), [module_0.Str('Hello!'), module_0.Name('b', module_0.Load())], [])), module_0.Return(module_0.Name('a', module_0.Load()))], [])

# Generated at 2022-06-25 22:19:27.073401
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test case where 'yield' appears before 'return' statement
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    ctx_0 = module_0.Load()
    func_0 = module_0.FunctionDef(name='fn', args=module_0.arguments(args=[], kwonlyargs=[], defaults=[], kw_defaults=[]), body=[module_0.Yield(value=module_0.Constant(value=1, kind=None)), module_0.Return(value=module_0.Constant(value=5, kind=None))], decorator_list=[], returns=None, type_comment=None)

# Generated at 2022-06-25 22:19:35.697553
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(test_case_0.__code__.co_consts[0]).body[0]
    assert isinstance(node, ast.Expr)

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)

    assert result is not None
    assert isinstance(result, ast.Expr)

    assert transformer._tree_changed is False


# Generated at 2022-06-25 22:19:40.766491
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    var_0 = ast.Module()
    var_1 = ast.Assign()
    var_2 = [ast.Name(id = "var_0", ctx = ast.Store())]
    var_3 = ast.Name(id = "test_case_0", ctx = ast.Load())
    var_1.targets = var_2
    var_1.value = var_3
    var_0.body = [var_1]
    var_0 = ReturnFromGeneratorTransformer().visit(var_0)
    assert var_0 == ast.Module(body = [ast.Assign(targets = [ast.Name(id = "var_0", ctx = ast.Store())], value = ast.Name(id = "test_case_0", ctx = ast.Load()))])

# Generated at 2022-06-25 22:19:51.081122
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("var_0")
    tree_transformer = ReturnFromGeneratorTransformer()
    tree_transformer.visit(tree)

# Generated at 2022-06-25 22:19:59.604727
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    var_0 = ast.Module([
        ast.FunctionDef(
            'fn',
            ast.arguments([], [], None, []),
            [
                ast.Yield(ast.Num(1)),
                ast.Return(ast.Num(5))
            ]
        )
    ])

# Generated at 2022-06-25 22:20:05.972408
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    var_0 = ast.parse(test_case_0.__doc__)
    var_1 = Var(
        lineno=1,
        col_offset=0,
        name='var_0',
        annotation=None,
        type_comment=None
    )
    var_2 = ast.AnnAssign(
        lineno=2,
        col_offset=0,
        target=var_1,
        annotation=None,
        value=None,
        simple=1
    )
    var_3 = Str(
        lineno=2,
        col_offset=0,
        s='generator_returns = self._find_generator_returns(node)'
    )

# Generated at 2022-06-25 22:20:16.011183
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # simple_0
    var_0 = None
    var_1 = ast.parse(textwrap.dedent('''
    def Fn_0():
        def Fn_1():
            return
        yield var_0
    '''))
    var_2 = ReturnFromGeneratorTransformer()
    var_1 = var_2.visit(var_1)

# Generated at 2022-06-25 22:20:19.877542
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Compiles return in generators like:
        def fn():
            yield 1
            return 5
    To:
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    test_case_0()
    assert var_0 == None

# Generated at 2022-06-25 22:20:21.196217
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source
    from .return_from_generator import ReturnFromGeneratorTransformer


# Generated at 2022-06-25 22:20:22.542642
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    fake_parser = ast.parse

# Generated at 2022-06-25 22:20:24.957556
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    var_0 = test_case_0
    var_1 = ast.parse(var_0.__doc__)
    var_1 = var_1.body[0]
    var_2 = ReturnFromGeneratorTransformer()
    var_2(var_1)

# Generated at 2022-06-25 22:20:32.496146
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:20:36.733554
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:20:43.375552
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)
    generator_return_0 = module_0.GeneratorExp()
    node_0 = module_0.GeneratorExp()
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(node_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(generator_return_0)



# Generated at 2022-06-25 22:20:47.245169
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:20:59.133693
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:21:03.618575
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  a_s_t_0 = module_0.AST()
  function_def_0 = module_0.FunctionDef()
  return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
  function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:21:13.874608
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Assignment expression to call of function _find_generator_returns

# Generated at 2022-06-25 22:21:19.662265
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is None


# Generated at 2022-06-25 22:21:26.381706
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:21:31.958410
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:21:43.651249
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_2 = module_0.AST()
    function_def_3 = module_0.FunctionDef()
    return_from_generator_transformer_2 = ReturnFromGeneratorTransformer(a_s_t_2)
    function_def_4 = return_from_generator_transformer_2.visit_FunctionDef(function_def_3)
    return_from_generator_transformer_3 = ReturnFromGeneratorTransformer(a_s_t_2)

# Generated at 2022-06-25 22:21:45.024828
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ... import testing
    from ...testing import create_and_run_local_test

# Generated at 2022-06-25 22:21:47.588344
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    p = ast.parse('''
        def fn():
            yield 1
            return 5
    ''')
    transformer = ReturnFromGeneratorTransformer(p)
    transformer.visit(p)

    assert p == ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''')

# Generated at 2022-06-25 22:21:51.662682
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert True

# Generated at 2022-06-25 22:21:55.728333
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:04.852623
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)

if __name__ == '__main__':
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1

# Generated at 2022-06-25 22:22:09.235035
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:17.641020
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    performance_decorator_0 = performance()
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    function_def_1.name
    function_def_1.args
    function_def_1.returns
    function_def_1.decorator_list
    function_def_1.body
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:21.555538
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t = module_0.AST()
    function_def = module_0.FunctionDef()
    return_from_generator_transformer = ReturnFromGeneratorTransformer(a_s_t)
    function_def_0 = return_from_generator_transformer.visit_FunctionDef(function_def)


# Generated at 2022-06-25 22:22:25.451963
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:22:46.095888
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)
    # assert function_def_1 == function_def_0
    # assert function_def_1.args == function_def_0.args


# Generated at 2022-06-25 22:22:53.848476
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    function_def_0.name = ""
    function_def_0.args = None
    function_def_0.body = []
    function_def_0.decorator_list = []
    function_def_0.returns = None
    function_def_0.lineno = 0
    function_def_0.col_offset = 0
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert (function_def_1 == function_def_0)
    function_def_0

# Generated at 2022-06-25 22:23:02.756993
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_2 = module_0.AST()
    function_def_2 = module_0.FunctionDef()
    return_from_generator_transformer_2 = ReturnFromGeneratorTransformer(a_s_t_2)
    function_def_3 = return_from_generator_transformer_2.visit_FunctionDef(function_def_2)
    a_s_t_3 = module_0.AST()
    function_def_4 = module_0.FunctionDef()
    return_from_generator_transformer_3 = ReturnFromGeneratorTransformer(a_s_t_3)
    function_def_5 = return_from_generator_transformer_3.visit_FunctionDef(function_def_4)
    a_s_t_4 = module_0.AST()

# Generated at 2022-06-25 22:23:07.960706
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is not None


# Generated at 2022-06-25 22:23:13.513613
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:23:21.998645
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Settings
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0.lineno = 71
    function_def_0.col_offset = 76
    function_def_0.name = "visit_FunctionDef"
    function_def_0.args = module_0.arguments()
    function_def_0.body = [module_0.Return()]
    function_def_0.decorator_list = []
    function_def_0.end_lineno = 90
    function_def_0.end_col_offset = 71

# Generated at 2022-06-25 22:23:22.779858
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:23:31.766980
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    failed = 0
    passed = 0


# Generated at 2022-06-25 22:23:36.284805
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    print('Tests Finished')

test_case_0()

# Generated at 2022-06-25 22:23:38.469916
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tmp_global = globals().copy()
    try:
        globals().clear()
        test_case_0()
    finally:
        globals().clear()
        globals().update(tmp_global)

# Generated at 2022-06-25 22:24:15.184184
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:24:16.615875
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Test for method __init__ of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:24:17.634024
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:24:21.695472
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    test_case_0()

# Generated at 2022-06-25 22:24:26.613496
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:24:30.715559
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = ast.AST()
    function_def_0 = ast.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:24:39.630030
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()

    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert(function_def_1 is not None)

    class_def_0 = module_0.ClassDef()
    function_def_1 = return_from_generator_transformer_0.visit_ClassDef(class_def_0)
    assert(function_def_1 is None)

    assert_0, assert_1 = module_0.Assert(), module_0.Assert()


# Generated at 2022-06-25 22:24:42.977156
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)



# Generated at 2022-06-25 22:24:44.895974
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Begin unit test

    test_case_0()
    # End unit test

test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:24:48.620594
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:25:36.887284
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)



# Generated at 2022-06-25 22:25:40.655611
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:25:44.557257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:49.315378
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    function_def_0.args = None
    function_def_0.name = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert_equal(function_def_1, function_def_0)

# Generated at 2022-06-25 22:25:55.642628
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert function_def_1 == function_def_0


# Generated at 2022-06-25 22:25:58.888425
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)



# Generated at 2022-06-25 22:26:02.877533
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:26:11.356260
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:26:15.322695
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:26:20.094899
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:28:04.607477
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    function_def_0.body.append(module_0.Yield())
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_2 = return_from_generator_transformer_1.visit_FunctionDef(function_def_0)
    pass


# Generated at 2022-06-25 22:28:11.496290
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1.args == function_def_0.args
    assert function_def_1.body == function_def_0.body
    assert function_def_1.decorator_list == function_def_0.decorator_list
    assert function_def_1.returns == function_def_0.returns
    a_s_t_1 = module_0.AST()
    function_def_2 = module_