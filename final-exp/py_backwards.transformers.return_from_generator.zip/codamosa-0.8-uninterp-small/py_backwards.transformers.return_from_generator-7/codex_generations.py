

# Generated at 2022-06-25 22:18:25.383752
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='fn', args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Return(value=module_0.Num(n=1))], decorator_list=[], returns=None)
    return_from_generator_transformer_0.visit(function_def_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_0.body[0].value == module

# Generated at 2022-06-25 22:18:31.938841
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    x_0 = module_0.Name()
    x_0.lineno = 1
    x_0.col_offset = 1
    x_0.id = 'x'
    assert module_0.Name == type(x_0)
    x_1 = module_0.Name()
    x_1.lineno = 1
    x_1.col_offset = 1
    x_1.id = 'x'
    assert module_0.Name == type(x_1)
    y_0 = module_0.Name()
    y_0.lineno = 1
    y_0.col_offset = 1
    y_0.id = 'y'
    assert module_0.Name == type(y_0)
    d_0 = module

# Generated at 2022-06-25 22:18:36.401019
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    ast_0 = '<SCRIPT>'
    function_def_0 = return_from_generator_transformer_0.visit(ast_0)


# Generated at 2022-06-25 22:18:46.536631
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = module_0.FunctionDef()
    t_y_p_e_1 = module_0.arguments()
    function_def_1.args = t_y_p_e_1
    function_def_1.name = 'fn'
    function_def_1.returns = None
    function_def_1.decorator_list = []

# Generated at 2022-06-25 22:19:01.731015
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)
    node_0 = module_0.FunctionDef(
        'function_def',
        module_0.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            module_0.Yield(
                module_0.Constant('yield')
            ),
        ],
        decorator_list=[],
        returns=None
    )
    print('FunctionDef:', node_0)

# Generated at 2022-06-25 22:19:11.881016
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:19:19.330658
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    
    # Example #0
    a_s_t_0 = module_0.AST()
    function_def_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0.name = 'test'
    function_def_0.args = arguments(args=['x'], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    function_def_0.body = [return_from_generator(return_value=const(n=42))]
    function_def_0.decorator_list = []
    function_def_

# Generated at 2022-06-25 22:19:28.558795
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='fn', argnames=[], defaults=[], flags=0, body=[], decorator_list=[], returns=None)
    
    return_0 = module_0.Return(value=None)
    function_def_0.body.append(return_0)
    return_from_generator_transformer_0.generic_visit(function_def_0)
    assert function_def_0.body[0].value == None
    
    
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGener

# Generated at 2022-06-25 22:19:29.386831
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass


# Generated at 2022-06-25 22:19:38.515578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = ast.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = ast.FunctionDef(name='lambda_0', args=ast.arguments(args=[], vararg=None, kwarg=None, kwonlyargs=[], kw_defaults=[], defaults=[]), body=[ast.Yield(value=ast.Constant(value=42, kind=None)), ast.Return(value=ast.Constant(value=42, kind=None))], decorator_list=[], returns=None)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:19:50.046704
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert isinstance(function_def_1, module_0.FunctionDef)



# Generated at 2022-06-25 22:19:55.303794
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    return_from_generator_transformer_0.get_tree_changed()

# Generated at 2022-06-25 22:20:01.463878
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    print(function_def_0)
    print(function_def_1)
    
if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:20:05.083847
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 == function_def_0

# Generated at 2022-06-25 22:20:05.891928
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  test_case_0()

# Generated at 2022-06-25 22:20:07.834305
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import sys
    if "typed_astunparse" not in sys.modules:
        return
    test_case_0()

# Generated at 2022-06-25 22:20:10.700777
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    assert(hasattr(ReturnFromGeneratorTransformer, 'visit_FunctionDef'))
    assert(type(ReturnFromGeneratorTransformer.visit_FunctionDef) == types.MethodType)


# Generated at 2022-06-25 22:20:14.905944
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:20:23.313770
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    # AssertionError: Module(body=[FunctionDef(args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None, name='', lineno=1, col_offset=0)]): None != FunctionDef(args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults

# Generated at 2022-06-25 22:20:26.102936
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:20:36.219755
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:20:42.352649
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_1 = ReturnFromGeneratorTransformer.visit_FunctionDef

    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:20:46.760387
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:20:52.458779
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
        
# unit test
# CCF-812 # python_src_code = module_0.Module()
# CCF-812 # function_def_0 = module_0.FunctionDef()
# CCF-812 # module_0.Module.body.append(python_src_code, function_def_0)
# CCF-812 # a_s_t_0 = module_0.AST()
# CCF-812 # return

# Generated at 2022-06-25 22:21:00.105451
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

if __name__ == '__main__':
    import typeguard

    typeguard.typechecked(test_case_0)()
    typeguard.typechecked(test_ReturnFromGeneratorTransformer_visit_FunctionDef)()

# Generated at 2022-06-25 22:21:01.224178
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 22:21:05.244502
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast._ast3 as module_0
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:13.464424
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = ast.FunctionDef()
    a_s_t_0 = ast.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0.body = []
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:19.413439
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # call instance method of class ReturnFromGeneratorTransformer
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:25.896212
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:21:42.011026
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:21:43.084619
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  try:
    test_case_0()
  except Exception as err:
    pass

# Generated at 2022-06-25 22:21:49.925501
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.level = function_def_0
    return_from_generator_transformer_0.return_value = function_def_0
    return_from_generator_transformer_0.lineno = function_def_0
    return_from_generator_transformer_0.col_offset = function_def_0
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:21:51.733424
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    source = inspect.getsource(test_case_0)
    assert source.count("yield") == 1

# Generated at 2022-06-25 22:21:56.283462
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)
    function_def_0 = module_0.FunctionDef()
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    # Verify
    assert isinstance(function_def_1, function_def_0.__class__)

# Generated at 2022-06-25 22:22:04.667206
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    parser = module_0.Parser()
    source_code_0 = "def fn():\n    a = 1\n    b = 2\n    c = a + b\n    return c"
    a_s_t_0 = parser.parse(source_code_0)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = a_s_t_0.body[0]
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    # Asserting to avoid flamegraphs
    assert function_def_0 == function_def_1


# Generated at 2022-06-25 22:22:09.311154
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_1 = module_0.FunctionDef()
    a_s_t_1 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_2 = return_from_generator_transformer_1.visit_FunctionDef(function_def_1)


# Generated at 2022-06-25 22:22:10.095710
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:22:15.516182
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 == function_def_0


# Generated at 2022-06-25 22:22:19.234451
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = ReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer.a_s_t)
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(function_def_0)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:22:36.729065
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():


    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    try:
        function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    except AttributeError as exc:
        assert isinstance(exc, AttributeError) and str(exc) == "'StopIteration' object has no attribute 'value'"
    else:
        assert 0, 'If statements should not be reached'


# Generated at 2022-06-25 22:22:41.314143
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)



# Generated at 2022-06-25 22:22:42.858671
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
    except(Exception):
        print("Exception in test case 0")


# Generated at 2022-06-25 22:22:45.223572
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Try to run test case
    try:
        test_case_0()
    except Exception as e:
        msg = e.args[0]
    else:
        msg = None
    assert msg is None, msg

# Generated at 2022-06-25 22:22:46.494632
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 22:22:50.962593
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 == module_0.FunctionDef()


# Generated at 2022-06-25 22:22:52.040075
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert test_case_0(), "test_case_0"

# Generated at 2022-06-25 22:22:56.576859
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    func_def = ast.FunctionDef(name='f',
                               args=ast.arguments(args=[]),
                               body=[
                                   ast.Yield(value=ast.Constant(0)),
                                   ast.Return(value=ast.Constant(1))
                               ])

    module = ast.Module([func_def])

    transpiled = module.transpile()

    assert eval(transpiled)() == [0]

# Generated at 2022-06-25 22:23:02.395488
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    try:
        function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    except AttributeError:
        print("AttributeError")


# Generated at 2022-06-25 22:23:07.178155
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:23:35.836657
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    field_0 = function_def_0.__annotations__
    field_1 = function_def_0.__kwargdefaults__
    field_2 = function_def_0.__defaults__
    field_3 = function_def_0.__dict__
    field_4 = function_def_0.__closure__
    field_5 = function_def_0.__code__
    field_6 = function_def_0.__

# Generated at 2022-06-25 22:23:41.391297
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is not module_0.FunctionDef()
    assert function_def_1 is module_0.FunctionDef()


# Generated at 2022-06-25 22:23:45.324596
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:50.144840
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_1.visit_FunctionDef(function_def_0)
    assert function_def_1 == function_def_0


# Generated at 2022-06-25 22:23:54.105053
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # Test branch #0
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:23:57.719931
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:24:03.537446
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    body_0 = [module_0.Return(None)]
    function_def_0 = module_0.FunctionDef("fn", [], body_0, None, [])
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    # Test for custom assertions here
    assert True


# Generated at 2022-06-25 22:24:08.155584
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Construct the arguments
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert function_def_1 is function_def_0

# Generated at 2022-06-25 22:24:12.652591
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:24:16.477392
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:13.305900
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Setup
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # Target
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    # Verify
    assert function_def_1 == function_def_0

# Generated at 2022-06-25 22:25:14.002586
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:25:19.478639
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # 1. Create an instance of the AST class
    a_s_t_0 = module_0.AST()
    # 2. Create an instance of the ReturnFromGeneratorTransformer class
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    # 3. Create an instance of the FunctionDef class
    function_def_0 = module_0.FunctionDef()
    # 4. Call the visit_FunctionDef method with the previously created instances as arguments
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:23.704967
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arguments
    function_def_0 = module_0.FunctionDef()

    # Return type specification
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:25:24.373056
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:25:28.885791
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # Act
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

    # Assert
    assert function_def_0 != function_def_1


# Generated at 2022-06-25 22:25:32.735692
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Setup a call chain to test the overhead of each node

# Generated at 2022-06-25 22:25:33.467321
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert False

# Generated at 2022-06-25 22:25:37.521756
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:25:45.009666
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function_def_0 = module_0.FunctionDef()
    function_def_0.name = "fn"
    function_def_0.args = module_0.arguments()
    function_def_0.args.args = [
        module_0.arg(),
    ]
    function_def_0.args.args[0].arg = "a"
    function_def_0.args.vararg = module_0.arg()
    function_def_0.args.vararg.arg = "b"
    function_def_0.args.kwonlyargs = [
        module_0.arg(),
    ]
    function_def_0.args.kwonlyargs[0].arg = "c"
    function_def_0.args.kw_defaults = [
        module_0.Name(),
    ]


# Generated at 2022-06-25 22:27:54.208693
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:27:59.921096
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_0 = ast.parse("""def foo(x):
    yield x
    return x""")
    function_def_0 = module_0.body[0]
    a_s_t_0 = module_0
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)
    assert isinstance(function_def_1, ast.FunctionDef)

# Generated at 2022-06-25 22:28:06.623784
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  # Testing first branch of selection construct
  # _tree_changed = False
  function_def_1 = module_0.FunctionDef()
  a_s_t_0 = module_0.AST()
  return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
  function_def_2 = return_from_generator_transformer_0.visit_FunctionDef(function_def_1)
  assert function_def_2 != None
  assert function_def_2 == function_def_1
  assert return_from_generator_transformer_0._tree_changed == False
  # Testing second branch of selection construct
  # _tree_changed = True
  function_def_3 = module_0.FunctionDef()
  return_4 = module_0.Return()
