

# Generated at 2022-06-25 22:18:19.725590
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    import astor
    from astor.ast_visitor import PrintVisitor
    a_s_t_1 = module_0.parse('''def fn():
    yield 1
    return 5
''')
    return_from_generator_transformer_0._find_generator_returns(a_s_t_1.body[0])
    return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1.body[0])
    print(astor.to_source(a_s_t_1))

# Generated at 2022-06-25 22:18:25.423421
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef()
    a_s_t_2 = return_from_generator_transformer_0.visit_FunctionDef(a_s_t_1)
    assert a_s_t_2 is None


# Generated at 2022-06-25 22:18:29.221799
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_1 = module_0.FunctionDef()

    # Test with assert_equal
    assert return_from_generator_transformer_0.visit_FunctionDef(function_def_1)==None

# Generated at 2022-06-25 22:18:34.715396
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    from typed_ast import ast3 as ast
    function_def_0 = ast.FunctionDef(None, None, None, None, None, [], None, None, None)
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:18:41.063610
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    a_s_t_1 = module_0.FunctionDef()
    function_def_1 = a_s_t_1
    return_from_generator_transformer_0.visit_FunctionDef(function_def_1)

# Generated at 2022-06-25 22:18:50.879581
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    function_def_0_0 = module_0.FunctionDef()
    function_def_0_0.body = [None, None, None]
    function_def_0_0.args = None
    function_def_0_0.returns = None
    function_def_0_0.decorator_list = None
    function_def_0_0.name = None
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    function_def_1_0 = return_from_generator_transformer_1.visit_FunctionDef(function_def_0_0)
    function_def_1_0.body = [None, None, None]
    function_def_1

# Generated at 2022-06-25 22:19:01.896526
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_1._fields = ('module','body','type_ignores','meta_lineno','meta_col_offset')
    a_s_t_1._attributes = ('body','type_ignores','meta_lineno','meta_col_offset')
    a_s_t_1.arguments = module_0.arguments
    a_s_t_1.Assert = module_0.Assert
    a_s_t_1.Assign = module_0.Assign
    a_s_t_1.Attribute = module_0.Attribute

# Generated at 2022-06-25 22:19:12.037369
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='fn', args=module_0.arguments([module_0.arg('self', None)], None, [], [], None, []), body=[module_0.Expr(value=module_0.Call(func=module_0.Name(id='print', ctx=module_0.Load()), args=[module_0.Str(s='Hello')], keywords=[])), module_0.Return(value=module_0.Str(s='world'))], decorator_list=[], returns=None)

# Generated at 2022-06-25 22:19:19.424686
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    funcdef_node_0 = ast.FunctionDef(name='fn', args=ast.arguments(), body=[], decorator_list=[])
    funcdef_node_0.body.append(ast.Yield(value=ast.Num(n=1)))
    funcdef_node_0.body.append(ast.Return(value=ast.Str(s='abc')))
    return_from_generator_transformer_0.visit_FunctionDef(node=funcdef_node_0)
    return_from_generator_transformer_0._tree_changed

# Generated at 2022-06-25 22:19:23.229578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:19:28.313864
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert isinstance(ReturnFromGeneratorTransformer, object)


# Generated at 2022-06-25 22:19:29.117525
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:19:32.651618
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 22:19:36.100585
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    try:
        a_s_t_0 = module_0.AST()
        return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 22:19:38.638865
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:39.489984
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:19:48.135828
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='foo', args=module_0.arguments(args=[module_0.arg(arg='a')], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Return(value=module_0.Num(n=1))], decorator_list=[], returns=None)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)


# Generated at 2022-06-25 22:19:52.211403
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef()


# Generated at 2022-06-25 22:20:00.670155
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef()
    a_s_t_1.args = module_0.arguments()
    a_s_t_1.name = "fn"
    a_s_t_2 = module_0.Return()
    a_s_t_2.value = module_0.Num()
    a_s_t_2.value.n = 5
    a_s_t_3 = module_0.Yield()
    a_s_t_3.value = module_0.Num()
    a_s_t_3.value.n = 1
    a_s

# Generated at 2022-06-25 22:20:02.913588
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    assert(return_from_generator_transformer_0.tree == a_s_t_0)

    assert(return_from_generator_transformer_0.target == (3, 2))

    assert(return_from_generator_transformer_0._tree_changed is False)


# Generated at 2022-06-25 22:20:07.576758
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert True


# Generated at 2022-06-25 22:20:13.598974
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = None
    node_0 = module_0.FunctionDef('node_0', [], [], [], [], None)
    return_from_generator_transformer_0.visit_FunctionDef(node_0)

# Generated at 2022-06-25 22:20:19.726408
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_1 = module_0.FunctionDef('a', [], [], [], [], None, None)
    return_from_generator_transformer_1 = return_from_generator_transformer_0.visit(a_s_t_1)


# Generated at 2022-06-25 22:20:24.498539
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast._ast3 as module_0
    method_0 = ReturnFromGeneratorTransformer.visit_FunctionDef
    import typed_ast._ast3 as module_1
    a_s_t_1 = module_1.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_1)
    import typed_ast._ast3 as module_2
    function_def_0 = module_2.FunctionDef('function_def_0', module_2.arguments([]))
    function_def_0 = method_0(return_from_generator_transformer_0,
                              function_def_0)



# Generated at 2022-06-25 22:20:26.599576
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert '<typed_ast.ast3.AST object at 0x7f659a6a3a90>' == str(test_case_0())

# Generated at 2022-06-25 22:20:30.806411
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert return_from_generator_transformer_0._tree is a_s_t_0
    assert return_from_generator_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:20:35.013370
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:20:37.733902
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)



# Generated at 2022-06-25 22:20:46.795746
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Init a_s_t_0_0
    a_s_t_0_0 = module_0.AST()
    # Init return_from_generator_transformer_0_0
    return_from_generator_transformer_0_0 = ReturnFromGeneratorTransformer(a_s_t_0_0)
    # Init ast_0_0
    ast_0_0 = module_0.FunctionDef()
    # Init body_0_0
    body_0_0 = []
    # Init arg_0_0
    arg_0_0 = module_0.Str()
    # Init return_from_generator_0_0
    return_from_generator_0_0 = module_0.Return()
    # Init return_from_generator_0_1
    return_from_gener

# Generated at 2022-06-25 22:20:49.002165
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():

    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)



# Generated at 2022-06-25 22:21:01.908904
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert isinstance(return_from_generator_transformer_0, ReturnFromGeneratorTransformer)
    assert not hasattr(return_from_generator_transformer_0, '_find_generator_returns_find_generator_returns_0')
    assert not hasattr(return_from_generator_transformer_0, '_replace_return_replace_return_0')
    assert not hasattr(return_from_generator_transformer_0, '_replace_return_replace_return_1')


# Generated at 2022-06-25 22:21:07.163402
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    str_1 = str(function_def_0)
    expect = "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n"
    actual = str_1
    assert actual == expect, actual

# Generated at 2022-06-25 22:21:08.984639
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:21:15.529100
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:21:18.885939
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:21.150424
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()


if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer()

# Generated at 2022-06-25 22:21:22.273802
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()


# Generated at 2022-06-25 22:21:24.189814
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:21:27.238519
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:29.154890
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:38.308360
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    # Act
    test_case_0()


# Generated at 2022-06-25 22:21:44.140763
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Case 1
    test_case_0()

if __name__ == '__main__':
    import sys
    import unittest

    if len(sys.argv) > 1:
        target = sys.argv.pop()
        if target in locals():
            test = locals()[target]
            try:
                unittest.main(argv=[sys.argv[0]])
            except SystemExit:
                pass
            test()
    else:
        unittest.main(argv=[sys.argv[0]])

# Generated at 2022-06-25 22:21:46.375679
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0, 1)


# Generated at 2022-06-25 22:21:47.855933
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

# Generated at 2022-06-25 22:21:56.026353
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert return_from_generator_transformer_0.__doc__ == 'Compiles return in generators like:\n    def fn():\n        yield 1\n        return 5\nTo:\n    def fn():\n        yield 1\n        exc = StopIteration()\n        exc.value = 5\n        raise exc\n'
    assert return_from_generator_transformer_0.__module__ == 'typed_ast.compat.gen_signatures'
    assert return_from_generator_transformer_0.__class__.__name__ == 'ReturnFromGeneratorTransformer'
    assert return_from_generator_transformer_0.target == (3, 2)

# Generated at 2022-06-25 22:22:04.992952
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    str_1 = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n'
    function_def_0 = module_2.parse(str_1)
    function_def_1 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    line_0 = function_def_1.body[0]

# Generated at 2022-06-25 22:22:05.779796
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    test_case_0()


# Generated at 2022-06-25 22:22:14.987498
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-25 22:22:20.090920
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:22:22.025825
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = None
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:38.681701
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass


# Generated at 2022-06-25 22:22:39.577181
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:22:40.663825
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()


# Generated at 2022-06-25 22:22:44.485325
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    f_n_0 = 'fn'
    assert return_from_generator_transformer_0.file_name == f_n_0

# Generated at 2022-06-25 22:22:49.380491
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:22:52.924730
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    function_def_0_expected = (module_2.parse("def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n")).body[0]
    test_case_0()
    assert (function_def_0 == function_def_0_expected)

# Generated at 2022-06-25 22:22:58.006416
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5
    ast_ = module_0.AST()
    transformer = ReturnFromGeneratorTransformer(ast_)
    result = transformer.visit_FunctionDef(ast.parse(fn.__code__.co_consts[1]))
    assert result.body[3].value.value == return_from_generator.get_body(return_value=5)[0].value.value
    assert isinstance(result.body[2], ast.Expr)

# Generated at 2022-06-25 22:22:58.485573
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass


# Generated at 2022-06-25 22:23:01.539073
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    tree_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(tree_0)


# Generated at 2022-06-25 22:23:04.952714
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    assert not return_from_generator_transformer_0._tree_changed


# Generated at 2022-06-25 22:23:36.469749
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:23:43.890714
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

a_s_t_0 = module_0.AST()
return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
str_0 = 'def fn():\n    yield 1\n    return 5\n'
var_0 = module_2.parse(str_0)
function_def_

# Generated at 2022-06-25 22:23:45.361906
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

import sys

# Generated at 2022-06-25 22:23:47.575875
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:55.453445
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    # assert function_def_0.__class__.__name__ == 'FunctionDef'
    # assert function_def_0.name == 'fn'
    # assert function_def_0.args.vararg == None
    # assert function_def_0.args.kwarg == None
    # assert function_def_0.args.kwonlyargs == []

# Generated at 2022-06-25 22:23:59.614735
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:24:05.432978
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    return_from_generator_transformer_0.visit_FunctionDef(var_0)
    assert str(return_from_generator_transformer_0._tree_changed) == 'True'

# Generated at 2022-06-25 22:24:06.156593
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass  # TODO: implement your test here


# Generated at 2022-06-25 22:24:13.846023
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    str_1 = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n'
    var_1 = module_2.parse(str_1)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    assert function_def_0 == var_1

# Generated at 2022-06-25 22:24:19.824754
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    print("[+] Testing constructor of class ReturnFromGeneratorTransformer")
    try:
        a_s_t_0 = module_0.AST()
        return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
        assert return_from_generator_transformer_0 is not None
    except Exception as exception_0:
        print("[-] Test Failed ")
    else:
        print("[+] Test Passed")
        print("[+] Testing constructor of class ReturnFromGeneratorTransformer finished")
        

# Generated at 2022-06-25 22:25:50.788964
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    assert (function_def_0)


# Generated at 2022-06-25 22:25:51.752932
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    test_case_0()

# Generated at 2022-06-25 22:25:52.418107
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert test_case_0() is None


# Generated at 2022-06-25 22:25:55.693074
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    # test __init__()
    assert return_from_generator_transformer_0 is not None


# Generated at 2022-06-25 22:25:56.294988
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:26:00.205147
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = 'def fn():\n    yield 1\n    return 5\n'
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)

# Generated at 2022-06-25 22:26:05.685419
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    var_0 = module_2.Module([module_2.FunctionDef('fn', [], [module_2.Expr(module_2.Yield(None)), module_2.Return(None)], [], None)], None)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)


# Generated at 2022-06-25 22:26:12.436397
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t = module_0.AST()
    return_from_generator_transformer = ReturnFromGeneratorTransformer(a_s_t)



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:26:14.900841
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)


# Generated at 2022-06-25 22:26:21.667104
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = ''
    var_0 = module_2.parse(str_0)
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(var_0)
    try:
        print(function_def_0)
    except Exception as exception_0:
        print(exception_0)
