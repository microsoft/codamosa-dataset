

# Generated at 2022-06-25 22:18:24.873914
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_1 = module_0.AST()
    t_y_p_e_0 = module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    t_y_p_e_1 = module_0.Name(id='None', ctx=module_0.Load())
    t_y_p_e_2 = module_0.FunctionDef(name='fn', args=t_y_p_e_0, body=[module_0.Return(value=t_y_p_e_1)], decorator_list=[], returns=None)
    return_from_generator_transformer_1 = ReturnFromGeneratorTransformer(a_s_t_1)
    t_y_p_e

# Generated at 2022-06-25 22:18:30.294676
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    class0_0 = a_s_t_0.ClassDef(body=[])
    functiondef0_0 = a_s_t_0.FunctionDef(body=[])
    class0_0.body.append(functiondef0_0)
    ret_val_0 = return_from_generator_transformer_0.visit_FunctionDef(functiondef0_0)
    return ret_val_0 == functiondef0_0

# Generated at 2022-06-25 22:18:31.677797
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast as ast_0

# Generated at 2022-06-25 22:18:38.770561
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    function_def_0 = module_0.FunctionDef('foo', module_0.arguments([module_0.arg('x', None), module_0.arg('y', None)], None, [], [], None, []), [module_0.Expr(module_0.BinOp(module_0.Name('x', module_0.Load()), module_0.Add(), module_0.Name('y', module_0.Load())))], [], None, None)
    function_def_0.lineno = 0
    function_def_0.col_offset = 0
    function_def_0.end_lineno = 0
   

# Generated at 2022-06-25 22:18:44.911620
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    str_0 = module_0.Str()
    function_def_0 = module_0.FunctionDef(str_0, [], [], [], [])
    function_def_0 = return_from_generator_transformer_0.visit_FunctionDef(function_def_0)

# Generated at 2022-06-25 22:18:49.194893
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    return_from_generator_transformer_0.visit_FunctionDef(module_0.FunctionDef())

# Generated at 2022-06-25 22:19:01.807255
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    function_def_expr = module_0.FunctionDef(body=[module_0.Yield(value=module_0.NameConstant(value=None)), module_0.Return(value=module_0.Num(n=42))], args=module_0.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), decorator_list=[], returns=None, name='foo', type_comment=None)


# Generated at 2022-06-25 22:19:11.959560
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  # Case 1: Token(type=NAME, string='name', start=(1, 0), end=(1, 4), line='def name():')
  a_s_t_0 = module_0.AST()
  module_0.fix_missing_locations(module_0.parse('def name():'))
  return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
  assert return_from_generator_transformer_0.visit_FunctionDef((module_0.parse('def name():'))) == (module_0.parse('def name():'))

  # Case 2: Token(type=NAME, string='name', start=(1, 0), end=(1, 4), line='def name():')
  a_s_t_1 = module_0.AST()
 

# Generated at 2022-06-25 22:19:19.384071
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)
    a_s_t_0_0 = module_0.arg(arg='a', annotation=None)
    a_s_t_2 = module_0.Expr(value=a_s_t_0_0)
    a_s_t_1_0 = module_0.arg(arg='a', annotation=None)
    a_s_t_1 = module_0.FunctionDef(name='F', args=a_s_t_1_0, body=[a_s_t_2], decorator_list=[], returns=None)
    a_s_t_1_1 = return_from_generator_transformer

# Generated at 2022-06-25 22:19:28.546678
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a_s_t_0 = module_0.AST()
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(a_s_t_0)

    a_s_t_1 = module_0.Module()
    source_code_str_0 = "class Foo:\n  def __init__(self):\n    self.x = 1\n  def __eq__(self, other):\n    return self.x == other.x\n  def __hash__(self):\n    return hash(self.x)\n\n\ndef bar():\n  simple_return = \"\"\n  multi_line_return = \"\"\"\n  multiline\n  return\n  \"\"\"\n  yield 1\n  return 5\n"
    a_s_t

# Generated at 2022-06-25 22:19:32.697497
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:19:33.556306
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:35.649062
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    try:
        test_case_0()
    except Exception:
        return (False, 1)

    return (True, 2)

# Generated at 2022-06-25 22:19:36.934896
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():  # pylint: disable=invalid-name
    test_case_0()

# Generated at 2022-06-25 22:19:38.123882
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # do not raise error
    test_case_0()

###

# Generated at 2022-06-25 22:19:42.924403
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer_0 = ReturnFromGeneratorTransformer(None)
    with pytest.raises(TypeError):
        return_from_generator_transformer_0.visit_FunctionDef('str')
    pytest.raises(ValueError, return_from_generator_transformer_0.visit_FunctionDef, 6)
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 22:19:43.891093
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()

# Generated at 2022-06-25 22:19:46.885489
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    set_recursion_limit(2 ** 30)
    assert test_case_0() == set_recursion_limit(2 ** 30)

test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-25 22:19:47.973796
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()


# Generated at 2022-06-25 22:19:49.612955
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_case_0()
