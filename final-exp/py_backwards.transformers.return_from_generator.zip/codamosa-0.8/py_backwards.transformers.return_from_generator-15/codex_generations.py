

# Generated at 2022-06-12 03:50:49.681884
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:50:55.997598
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ptpython.repl import PythonRepl
    import ast
    repl = PythonRepl()
    visitor = ReturnFromGeneratorTransformer()
    code = """
    def fn():
        yield 1
        return 5
    """
    code_ast = repl.transform_to_ast(code)
    fn_def = code_ast.body[0]
    visitor.visit(fn_def)
    expected_output = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert repl.transform_from_ast(code_ast) == repl.transform_from_ast(repl.transform_to_ast(expected_output))

# Generated at 2022-06-12 03:51:07.343678
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.transformer_util import run_transformer_on_single_file
    from ..utils.testing_utils import get_call_node

    source_1 = \
    """
    def fn():
        yield 1
        return 2
    """

    source_2 = \
    """
    def fn():
        yield 1
        return 2 + 3
    """

    source_3 = \
    """
    def fn():
        return 4
    """

    source_4 = \
    """
    def fn():
        yield 1
        return

    def fn2():
        return 4
    """

    source_5 = \
    """
    def fn():
        yield 1
        if 3 > 5:
            return 4
        yield 5
    """


# Generated at 2022-06-12 03:51:12.822848
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    src = """
    def f():
        yield 1
        return 5
    """
    expected = """
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    mod = ast.parse(src)
    mod = ReturnFromGeneratorTransformer().visit(mod)  # type: ignore
    assert expected == ast.unparse(mod)


# Generated at 2022-06-12 03:51:15.042262
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:51:27.406062
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:37.817318
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from typed_ast import ast3 as ast
    from ..utils.test_utils import should_transform


    class TestNodeTransformer(ReturnFromGeneratorTransformer):
        def __init__(self, test_case, before, after):
            self._test_case = test_case
            self._before = before
            self._after = after

        def _check(self, node: ast.AST) -> bool:
            return should_transform(self._test_case, self._before, self._after, node)

        def _transform(self, node: ast.AST) -> ast.AST:
            return self.visit(node)

    def test_replace_return_in_gen():
        def before():
            def foo():
                yield 1
                return 2

        def after():
            def foo():
                yield 1

# Generated at 2022-06-12 03:51:50.002205
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.visitor import NodeVisitor

    def return_from_generator(return_value):
        exc = StopIteration()
        exc.value = return_value
        raise exc

    class TestVisitor(NodeVisitor):
        def get_docstring(self, node):
            """Approximate getting of docstring."""
            lines = []
            for child in node.body:
                if isinstance(child, ast.Expr) and isinstance(child.value, ast.Str):
                    lines.append(child.value.s)
                else:
                    break
            return "\n".join(lines)

    def assert_equal(source, expected):
        tree = ast.parse(source)
        transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:51:52.167308
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse, dump
    from ..exhaustive import exhaustively_visit


# Generated at 2022-06-12 03:52:00.348293
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_cases = {}

    def check(self, node: ast.AST) -> None:
        new_node = self.visit(node)

        if new_node != node:
            self._tree_changed = True

        self.generic_visit(new_node)  # type: ignore

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit = check

    @snippet
    def test_case():
        let(fn)
        fn = lambda: None

    test_cases['function_without_return'] = test_case.get_ast()

    @snippet
    def test_case():
        let(fn)
        fn = lambda: fn()

    test_cases['function_without_yield'] = test_case.get_ast()


# Generated at 2022-06-12 03:52:08.471048
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import ast_transformer
    transformer = ast_transformer.PythonAstTransformer(target=[3, 2])
    transformer.add(ReturnFromGeneratorTransformer)

# Generated at 2022-06-12 03:52:20.006054
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_helpers import assert_equal_source

    @assert_equal_source
    def test():
        def fn():
            yield 1
            return 5

    @assert_equal_source
    def test_in_loop():
        def gen():
            for i in range(10):
                yield 1
                return 5

    @assert_equal_source
    def test_not_generator():
        def fn():
            return 5

    @assert_equal_source
    def test_as_generator():
        def fn():
            return (x for x in range(5))

    @assert_equal_source
    def test_sub_generator():
        def gen():
            yield from (x for x in range(5))
            yield 5


# Generated at 2022-06-12 03:52:25.856570
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module = ast.parse('''
    @snippet
    def fn():
        yield 1
        return 5
    
    @snippet
    def fn2():
        yield from [1, 2, 3]
        return 5
    
    @snippet
    def fn3():
        def inner():
            return 5
        yield 1
    ''')

    ReturnFromGeneratorTransformer().visit(module)


# Generated at 2022-06-12 03:52:32.965614
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_source_equal
    from ..utils import Source

    source = Source("""
    def fn():
        yield 1
        return 5
    """)

    expected = Source("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    node = source.ast()
    ReturnFromGeneratorTransformer().visit(node)
    assert_source_equal(expected.source, node)

# Generated at 2022-06-12 03:52:34.164541
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor


# Generated at 2022-06-12 03:52:43.811680
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test:
        def test_method(self):
            # Test with simple method
            @switchy.switchy
            def foo():
                yield 1
                return 5
            assert foo.__code__.co_flags & ast.CO_GENERATOR

            # Test with more complex method
            @switchy.switchy
            def foo():
                for i in range(10):
                    yield i
                return 5
            assert foo.__code__.co_flags & ast.CO_GENERATOR

            # Test @asyncio.coroutine
            @switchy.switchy
            @asyncio.coroutine
            def foo():
                yield from asyncio.sleep(3)
                return 5
            assert foo.__code__.co_flags & ast.CO_GENERATOR

            # Test @asyncio.coroutine


# Generated at 2022-06-12 03:52:44.453975
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:45.502836
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:46.530716
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:53.311204
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .common import generate_function_ast  # noqa

    def test_code(ret):
        def fn():
            yield 1
            ret
        return fn

    def expected_code(ret):
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = ret
            raise exc
        return fn

    function_code = generate_function_ast(test_code(5))
    expected_code = generate_function_ast(expected_code(5))
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(function_code)
    assert result == expected_code

# Generated at 2022-06-12 03:53:06.034791
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ... import ast_utils
    from .flatten_yields import FlattenYieldsTransformer
    from .unwrap_none_values import UnwrapNoneValuesTransformer


# Generated at 2022-06-12 03:53:13.158666
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def assert_result(source, expected):
        tree = ast.parse(source)
        expected_tree = ast.parse(expected)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)
        assert transformer._tree_changed == True
        assert ast.dump(tree) == ast.dump(expected_tree)

    # Test non-generator function
    source = "def f():\n    return 5"
    expected = "def f():\n    return 5"
    assert_result(source, expected)

    # Test generator without returns
    source = "def f():\n    yield 1"
    expected = "def f():\n    yield 1"
    assert_result(source, expected)

    # Test generator with single return
    source = "def f():\n    yield 1\n    return 5"

# Generated at 2022-06-12 03:53:21.514745
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import FunctionDef, Return, Name, Yield
    from .scaffolding import setup_test_function, finalize_test
    from ..utils import typed_astunparse

    tree = setup_test_function(ast.parse('''def gen(x):
    yield x + 5
    return x + 10'''))
    rfg = ReturnFromGeneratorTransformer()
    rfg.visit(tree)
    code = typed_astunparse.unparse(tree)

    tree = setup_test_function(ast.parse(code))
    gen = tree.body[0]

    check = [isinstance(x, FunctionDef) for x in gen.body]
    assert all(check)

    check = [isinstance(x, Yield) for x in gen.body]

# Generated at 2022-06-12 03:53:32.801180
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import run_all_nodes
    from ..compile_node import compile_node
    from .move_yield_to_top_level import MoveYieldToTopLevelTransformer

    transformer = ReturnFromGeneratorTransformer()
    node = run_all_nodes('''
        @foo
        def bar():
            yield 1
            return 2
    ''')

    code = compile_node(node)
    assert code == '''
        def bar():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    '''.strip()

    print(code)

    transformer = MoveYieldToTopLevelTransformer()
    node = run_all_nodes('''
        def bar():
            yield 1
            return 2
    ''')

    code = compile_

# Generated at 2022-06-12 03:53:41.750818
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import roundtrip
    from .test_utils import make_code
    from .test_utils import compare_dedent

    source = make_code("""
        def foo():
            yield 10
            return 20
    """)

    module_node = roundtrip(source)
    transformed_node = ReturnFromGeneratorTransformer.visit(module_node)
    transformed_code = make_code(transformed_node)
    assert compare_dedent("""
        def foo():
            yield 10
            exc = StopIteration()
            exc.value = 20
            raise exc
    """, transformed_code)

# Generated at 2022-06-12 03:53:45.304984
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    def blah():
        yield 1
        return 5
    blah()
    node = ast3.parse(textwrap.dedent(inspect.getsource(blah)))


# Generated at 2022-06-12 03:53:57.271672
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.tree import print_tree, tree_eq
    from ..utils.file import get_src_from_fname
    from .base import compile_snippet
    from .is_generator import IsGeneratorTransformer
    import re

    src = get_src_from_fname('test_src/return_from_generator_test.py')

    def compile_src(src, version):
        return compile_snippet(src, 'test', version)[0]

    def update_numbers(src):
        """Remove all number to avoid checking them."""
        return re.sub(r'\d+', 'NUMBER', src)

    def remove_spaces(s):
        return re.sub(r'\s+', ' ', s)

    def compare(version):
        src1 = update_n

# Generated at 2022-06-12 03:54:09.003272
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from ..utils import  ast_compare
    from ..utils.ast_parse import parse


# Generated at 2022-06-12 03:54:13.456391
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from typed_ast import TypeError
    from ast_masker import AstMasker
    from ..utils.compare_ast import compare_ast

    node = parse('def fn():\n    print(1)\n    return 5')

# Generated at 2022-06-12 03:54:22.447115
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    program = '''def fn():\n y = yield 1\n return y'''
    tree = ast.parse(program)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    expected_program = '''def fn():\n y = yield 1\n exc = StopIteration()\n exc.value = y\n raise exc'''
    expected = ast.parse(expected_program)
    assert ast.dump(tree, include_attributes=False) == ast.dump(expected, include_attributes=False)



# Generated at 2022-06-12 03:54:39.688307
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import parse
    from .. import unparse


# Generated at 2022-06-12 03:54:48.334630
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    result = ReturnFromGeneratorTransformer().visit(
        ast.parse(
            "def fn(x):\n    yield 'asd'\n    return x\n",
            mode='exec'
        )
    )

    expected_result = ast.parse(
        "def fn(x):\n    yield 'asd'\n    exc = StopIteration()\n    exc.value = x\n    raise exc\n"
    )

    assert ast.dump(result) == ast.dump(expected_result)

# Generated at 2022-06-12 03:54:49.304693
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:52.323615
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ast import parse as make_ast
    from ..utils.ast_helpers import dump
    from ..utils.compat import IS_PY3
    from . import fix_missing_locations
    from .ast_unparser import AstUnparser
    from .type_promoter import TypePromoter
    from .yield_in_except_transformer import YieldInExceptTransformer


# Generated at 2022-06-12 03:54:53.826428
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    from ..compiler import to_source


# Generated at 2022-06-12 03:55:02.205641
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from .test_BaseNodeTransformer import BaseNodeTransformerSchema
    from .test_BaseNodeTransformer import compile_transformer_test
    from ..schema.node_visitor_schema import NodeTransformerSchema

    class Transformer(ReturnFromGeneratorTransformer, BaseNodeTransformerSchema):
        pass

    source = """
    def f():
        yield 'K'
        return 5
    """

    expected = """
    def f():
        yield 'K'
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(source)
    assert unparse(tree) == source

    transformer = Transformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-12 03:55:07.865678
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        yield 1
        return 5
    """
    result = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    t = ReturnFromGeneratorTransformer()
    node = ast.parse(code)
    node = t.visit(node)
    assert ast.dump(node, include_attributes=False) == result


# Generated at 2022-06-12 03:55:15.824201
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    from ..utils.source_transform_test_case import SourceTransformTestCase

    class TestFirst(SourceTransformTestCase):
        transform = ReturnFromGeneratorTransformer

        def test_return_from_generator(self):
            self.assertTransform(
                {
                    'before': 'def fn(): yield 1; yield 2; return 3',
                    'after': '''
                        def fn():
                            yield 1
                            yield 2
                            exc = StopIteration()
                            exc.value = 3
                            raise exc
                    ''',
                }
            )

    unittest.main()

# Generated at 2022-06-12 03:55:21.403278
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import assert_function_transformation

    assert_function_transformation(
        FunctionDefTransformer,
        """
        def f():
            yield 1
            return 20
            """,
        """
        def f():
            yield 1
            exc = StopIteration()
            exc.value = 20
            raise exc
            """,
    )



# Generated at 2022-06-12 03:55:30.689998
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    _fn = '''
    def fn():
        yield 1
        return 5
    '''
    _fn_expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    _fn_other_method_expected = '''
    def fn():
        yield 1
        return 5
    '''

    # Act
    _fn_ast = ast.parse(_fn)
    _fn_other_method = ast.parse(_fn_other_method_expected)

    _fn_ast_modified = ReturnFromGeneratorTransformer().visit(_fn_ast)
    _fn_other_method_modified = ReturnFromGeneratorTransformer().visit(_fn_other_method)

    # Assert
    _fn_ast_

# Generated at 2022-06-12 03:56:13.189446
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        TRANSFORMER = ReturnFromGeneratorTransformer

        def test_simple(self):
            node = ast.parse("""
                    def fn():
                        yield 1
                        return 1
                    """)
            expected = """
                    def fn():
                        yield 1
                        exc = StopIteration()
                        exc.value = 1
                        raise exc
                    """
            self.compare(node, expected)

        def test_simple_multiple_yield(self):
            node = ast.parse("""
                    def fn():
                        yield 1
                        yield 1
                        return 1
                    """)
            expected = """
                    def fn():
                        yield 1
                        yield 1
                        exc = StopIteration()
                        exc.value = 1
                        raise exc
                    """
           

# Generated at 2022-06-12 03:56:22.856531
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse(
        '''def fn():
        yield None
        yield 1
        return 5''')
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(tree)
    source = ast.dump(node)

# Generated at 2022-06-12 03:56:24.592035
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""

# Generated at 2022-06-12 03:56:29.669821
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    from typed_ast.ast3 import parse
    from .utils import CustomNodeTransformer

    class CustomTransformer(CustomNodeTransformer):
        def __init__(self):
            self.source = ""

    class TargetTransformer(ReturnFromGeneratorTransformer):
        def _replace_return(self, parent, return_):
            index = parent.body.index(return_)
            parent.body.pop(index)

            # Add self.source to body
            self.source = return_from_generator.get_body(return_value=return_.value)[0]


# Generated at 2022-06-12 03:56:30.105063
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:36.742469
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Placeholder(str):
        pass
    placeholder = Placeholder('')
    return_value_ast = ast.Num()
    return_value_ast.n = 1
    return_value_placeholder = ast.Num()
    return_value_placeholder.n = placeholder
    class TestCode:
        @snippet
        def good_code():
            yield 1
            yield 2
            return return_value_ast
        @snippet
        def bad_code_no_return():
            yield 1
        @snippet
        def bad_code_no_yield():
            return return_value_ast
    test_cases = (
        TestCode.good_code,
        TestCode.bad_code_no_return,
        TestCode.bad_code_no_yield
    )

# Generated at 2022-06-12 03:56:47.264141
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer(package="test")
    node = ast.parse("""
        def fn():
            yield 1
            return 5
        """).body[0]
    assert transformer.visit(node) == ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """).body[0]  # noqa

    transformer = ReturnFromGeneratorTransformer(package="test")
    node = ast.parse("""
        def fn():
            yield 1
            for n in [1, 2, 3, 4]:
                if n > 3:
                    return 'result'
                else:
                    yield n
        """).body[0]

# Generated at 2022-06-12 03:56:51.691725
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from .test_utils import assert_equal_ast

    code = dedent('''
    def fn():
        yield 1
        return 2
    ''')

    assert_equal_ast(ReturnFromGeneratorTransformer(), code, dedent('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    '''))

# Generated at 2022-06-12 03:56:54.964006
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn_return_from_gen_in_fn():
        def fn():
            yield 1
            return 5
        return fn


# Generated at 2022-06-12 03:57:03.796096
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    #case 1
    node = ast.parse('def fn():\n    yield 1\n    "b"\n    return 5\n')
    expected = ast.parse('def fn():\n    yield 1\n    "b"\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n')
    ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected)

    #case 2
    node = ast.parse('def fn():      \n"a"\n    yield 1\n    "b"\n    return 5\n')

# Generated at 2022-06-12 03:57:46.769068
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test case data
    input1 = """
        def test_fct():
            if x == 1:
                return y
    """
    input2 = """
        def test_fct():
            yield 1
            if x == 2:
                return y
            yield 3
            return 4
    """
    input3 = """
        def test_fct():
            yield from [1, 2]
            if x == 3:
                return y
            yield from [3, 4]
            return 5
    """

    expected1 = """
        def test_fct():
            if x == 1:
                return y

    """

# Generated at 2022-06-12 03:57:57.682678
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Example 1
    node = ast.parse('def fn(v):\n'
                     '    print(v)')
    fn = node.body[0]
    ReturnFromGeneratorTransformer().visit(fn)
    assert ast.dump(fn) == 'FunctionDef(name=\'fn\', args=arguments(args=[arg(arg=\'v\', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Name(id=\'print\', ctx=Load()), args=[Name(id=\'v\', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)'

    # Example 2

# Generated at 2022-06-12 03:58:06.969530
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # First try, returning inside the loop
    function_body = [
        ast.For(
            target=ast.Name(id='x', ctx=ast.Store()),
            iter=ast.Name(id='range', ctx=ast.Load()),
            body=[
                ast.Expr(value=ast.Yield(value=ast.Name(id='x', ctx=ast.Load()))),
                ast.Return(value=ast.Constant(value=1))
            ],
            orelse=[]
        )
    ]


# Generated at 2022-06-12 03:58:11.739688
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    def fn():
        yield 1
        return 5
    node = ast.parse(fn.__code__.co_consts[0])
    ReturnFromGeneratorTransformer().visit(node)
    fn = compile(astor.to_source(node), '', 'exec')
    assert list(fn()) == [1]



# Generated at 2022-06-12 03:58:16.624465
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import Options
    import typed_ast.ast3 as typed_ast
    return_from_generator = ReturnFromGeneratorTransformer(Options(), typed_ast)
    typed_ast, _ = return_from_generator.transform_single_node(typed_ast)
    expected_ast = typed_ast.parse(r"""
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    assert typed_ast == expected_ast

# Generated at 2022-06-12 03:58:17.572960
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:58:19.008642
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse

# Generated at 2022-06-12 03:58:28.346960
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from itertools import count
    import astor
    from ..utils import get_test_data
    from ..common import SEP

    # Read in the expected output from the test case file
    expected_output_file_path = get_test_data("test_ReturnFromGeneratorTransformer_visit_FunctionDef.py")
    expected_output = open(expected_output_file_path, 'r').read()
    actual_output = None

    # Read in the test case file
    testcase_file_path = get_test_data("test_ReturnFromGeneratorTransformer_visit_FunctionDef_input.py")
    testcase_source = open(testcase_file_path, 'r').read()
    tree = ast.parse(testcase_source)

    # Perform the transformation
    node_transformer = ReturnFromGenerator

# Generated at 2022-06-12 03:58:37.342687
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestVisitor(ast.NodeVisitor):
        """Test visitor."""
        def visit_Return(self, node):
            """Test visitor for Return."""
            if isinstance(node.value, ast.Num):
                assert node.value.n == 5
            else:
                assert False

    source = """
    def generator_return_1():
        yield 1
        return 5

    def generator_return_2():
        if True:
            pass
        else:
            return 5
    """

    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.transform(tree)

    TestVisitor().visit(tree)

# Generated at 2022-06-12 03:58:45.575951
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    source = """
    def a():
        yield 1
        return 5
    """
    expected_error = None
    expected_tree = ast.parse(source)

    instance = ReturnFromGeneratorTransformer()
    result_tree = instance.visit(expected_tree)
    errors = []


# Generated at 2022-06-12 04:00:26.157378
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # no return in generator
    node1 = ast.parse('''def fn():
        yield 1
        yield 2''', mode='exec').body[0]
    transform1 = ReturnFromGeneratorTransformer().visit(node1)
    assert transform1 == node1

    # one return in generator
    node2 = ast.parse('''def fn():
        yield 1
        yield 2
        return 6''', mode='exec').body[0]
    transform2 = ReturnFromGeneratorTransformer().visit(node2)
    assert transform2.body[2].value.value == 6
    assert transform2.body[3].value.func.id == 'StopIteration'
    assert transform2.body[4].value.value.value == 6
    assert transform2.body[5].value.func.id == 'StopIteration'

# Generated at 2022-06-12 04:00:32.338824
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.tester import assert_equal_source_code
    from .unpacking_transformer import UnpackingTransformer

    transformer = UnpackingTransformer()
    node = ast.parse('''
    def fn():
        yield 1
        return 5
    ''')
    expected_node = ast.parse('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

    transformer.update(node)
    assert_equal_source_code(node, expected_node)

# Generated at 2022-06-12 04:00:39.153671
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def foo():
            1
            return 2
        def generator():
            yield 1
            return 2
    """
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    expected_code = """
        def foo():
            1
            return 2
        def generator():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """
    expected_tree = ast.parse(expected_code)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 04:00:44.566122
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..utils.creator import create_function
    from ..utils.compiler import compile_code

    def fn():
        def inner():
            yield 1
            return 3

        return inner()

    expected = """
    def inner():
        yield 1
        exc = StopIteration()
        exc.value = 3
        raise exc

    def fn():
        return inner()
    """

    transformer = ReturnFromGeneratorTransformer()
    tree = create_function(fn).__ast__()
    tree = transformer.visit(tree)
    assert astor.to_source(tree) == expected

