

# Generated at 2022-06-12 03:50:53.868917
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:50:54.904688
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:51:06.376035
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    code = """
    def fn(foo):
        bar = 5
        if bar > 3:
            bar += 1
            return bar
        else:
            bar -= 1
            return bar - 2
    """
    expected = """
    def fn(foo):
        bar = 5
        if bar > 3:
            bar += 1
            exc = StopIteration()
            exc.value = bar
            raise exc
        else:
            bar -= 1
            exc = StopIteration()
            exc.value = bar - 2
            raise exc
    """

    tree = ast.parse(code)
    new_tree = ReturnFromGeneratorTransformer(tree).visit(tree)
    new_code = astor.to_source(new_tree)

    assert new_code == expected  # type: ignore

# Generated at 2022-06-12 03:51:17.865386
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import NodeTest, transform
    from .test_utils import compare_ast, get_ast
    from .test_utils import Assign, AssignAttr, Expr, FunctionDef, Name, Return, Yield
    from .test_utils import Call

    def test_body(body: List[NodeTest], *, top_level=False) -> FunctionDef:
        return FunctionDef(
            'foo',
            ['a1'],
            body,
            returns=None,
            decorator_list=[],
            returns=None,
            type_comment=None,
        )

    # No `return` -> no changes
    obj = test_body([Yield(None, lineno=0, col_offset=0)])

    assert compare_ast(transform(obj, ReturnFromGeneratorTransformer), obj)

   

# Generated at 2022-06-12 03:51:26.564142
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal
    from ..utils.code_repr import code_repr

    code = """
    def fn():
        yield 1
        return 5
    """
    code_expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(code)
    tree = ReturnFromGeneratorTransformer.run_pipeline(tree)
    assert_code_equal(code_repr(tree), code_expected)


# Generated at 2022-06-12 03:51:27.200870
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:33.614389
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    node = ast.parse("""\
    def f():
        yield 1
        return 'hello'
    """)
    expected = """\
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 'hello'
        raise exc
    """
    result = astunparse.unparse(ReturnFromGeneratorTransformer().visit(node))
    assert result == expected


# Generated at 2022-06-12 03:51:36.467604
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def testSnippet(code):
        node = ast.parse(code)
        node = ReturnFromGeneratorTransformer().visit(node)
        return node

    # testSimple

# Generated at 2022-06-12 03:51:37.396369
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor


# Generated at 2022-06-12 03:51:43.740891
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    from .add_yield_from_to_return import AddYieldFromToReturnTransformer
    from .python3_remove_print_function import Python3RemovePrintFunctionTransformer
    source = '''
    def fn():
        return 5
    '''
    expected = '''
    def fn():
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    tree = AddYieldFromToReturnTransformer().visit(tree)
    tree = Python3RemovePrintFunctionTransformer().visit(tree)
    result = astunparse.unparse(tree)
    assert result == expected


# Generated at 2022-06-12 03:51:49.796984
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:58.851622
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typing import Iterator
    import astor
    transformer = ReturnFromGeneratorTransformer()

    def test_fn() -> Iterator[int]:
        yield 1
        yield 2
        yield 3
        return 5

    fn_def = ast.parse(inspect.getsource(test_fn)).body[0]
    transformer.visit(fn_def)

    def test_fn_compiled() -> Iterator[int]:
        yield 1
        yield 2
        yield 3
        exc = StopIteration()
        exc.value = 5
        raise exc

    compiled_source = astor.to_source(ast.parse(inspect.getsource(test_fn_compiled)))

    print(astor.to_source(fn_def))
    print(compiled_source)


# Generated at 2022-06-12 03:52:07.327716
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Check visit_FunctionDef method of class ReturnFromGeneratorTransformer."""
    from typed_astunparse import unparse
    from ..utils.case import CodeCase
    from ..typing import check_transformation


# Generated at 2022-06-12 03:52:18.847081
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from typing import Dict, Any

    class FunctionDefMock(ast.AST):

        def __init__(
                self, body: List[ast.AST], type_comments: Dict[ast.AST, str] = None):
            self.body = body
            self.type_comments = type_comments

    class ReturnMock(ast.AST):

        def __init__(self, value: ast.AST):
            self.value = value

    class YieldFromMock(ast.AST):

        pass

    class YieldMock(ast.AST):

        pass

    class AssignMock(ast.AST):

        def __init__(self, value: ast.AST):
            self.value = value


# Generated at 2022-06-12 03:52:20.938164
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    from ..utils import ast3tool
    from ..transformer import Transformer

# Generated at 2022-06-12 03:52:28.414916
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def g(x):
            yield x
            return 5
    """
    result = """
        def g(x):
            yield x
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    assert ReturnFromGeneratorTransformer().visit(ast.parse(code)) == ast.parse(result)


# Generated at 2022-06-12 03:52:37.652092
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .identity import IdentityTransformer
    from .mock_nodes import MOCK_FUNCTION_DEF
    from .node_transformer_test_case import NodeTransformerTestCase

    class TestCase(NodeTransformerTestCase):
        def __init__(self, *args, **kwargs):
            self.last_return = None
            self.test_function = None
            self.transform_function = IdentityTransformer()

            super().__init__(*args, **kwargs)

        def test_function_def(self, node: ast.FunctionDef) -> None:
            self.test_function = node

        def create_return(self, return_value: ast.AST) -> ast.AST:
            ret = ast.Return(value=return_value, lineno=1, col_offset=1)
            self.last

# Generated at 2022-06-12 03:52:40.242725
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test import check_transformer
    check_transformer(ReturnFromGeneratorTransformer, """
        def fn():
            yield 1
            return 5
    """)

# Generated at 2022-06-12 03:52:45.555517
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def test():
        yield 0
        return 10
    """
    module = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module)

    expected_code = """
    def test():
        yield 0
        exc = StopIteration()
        exc.value = 10
        raise exc
    """

    assert compare_ast(module, expected_code)

# Generated at 2022-06-12 03:52:46.985184
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # TODO: write tests
    pass


# Generated at 2022-06-12 03:53:09.735748
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    import astunparse
    import textwrap

    source = textwrap.dedent(r'''
    def fn():
        yield 1
        return 5
    ''')
    ast_module = ast.parse(source)

    node = ast_module.body[0]
    node = ReturnFromGeneratorTransformer().visit(node)

    expected_ast = textwrap.dedent('''\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')
    assert astor.to_source(node) == expected_ast
    assert astunparse.unparse(node) == expected_ast

# Generated at 2022-06-12 03:53:16.946617
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module = ast.parse('def fn():\n\tyield 1\n\treturn 5')
    node = module.body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module)
    assert len(node.body) == 3
    assert isinstance(node.body[0], ast.Yield)
    assert isinstance(node.body[1], ast.Expr)
    assert isinstance(node.body[2], ast.Raise)


# Generated at 2022-06-12 03:53:28.465749
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    code = 'def fn(): yield 5'
    tree = ast.parse(code)
    transformer.visit(tree)
    assert ast.dump(tree) == code

    code = 'def fn(): return 5'
    tree = ast.parse(code)
    transformer.visit(tree)
    assert ast.dump(tree) == "def fn():\n    return 5"

    code = 'def fn(): yield 5\nreturn 5'
    tree = ast.parse(code)
    transformer.visit(tree)
    expected = 'def fn():\n' \
               '    yield 5\n' \
               '    exc = StopIteration()\n' \
               '    exc.value = 5\n' \
               '    raise exc'

# Generated at 2022-06-12 03:53:33.285370
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert_equal = TransformerAssertEqual()

    # pylint: disable=missing-docstring,invalid-name
    def get_input(has_yield=True):
        if has_yield:
            yield_ = ast.Yield(value=ast.NameConstant(value=1))
        else:
            yield_ = ast.Pass()

        return ast.Return(lineno=1, col_offset=1, value=ast.Num(n=5))

    def get_output(has_yield=True):
        if has_yield:
            yield_ = ast.Yield(value=ast.NameConstant(value=1))
        else:
            yield_ = ast.Pass()

        # pylint: disable=unused-variable
        exc = StopIteration()

# Generated at 2022-06-12 03:53:43.084725
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import compile_to_ast

    def fn():  # noqa: F811
        yield 1
        return 5

    # ReturnFromGeneratorTransformer works only with Python > 3.2
    if sys.version_info < (3, 2):
        return
    else:
        original = compile_to_ast(fn)
        expected = compile_to_ast(return_from_generator.get_body(return_value=5))  # noqa: F811
        transformed = ReturnFromGeneratorTransformer().visit(original)  # type: ignore

        assert expected.body[0].body[-3:] == transformed.body[0].body[-3:]

# Generated at 2022-06-12 03:53:54.998394
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def _find_generator_returns(self, node: ast.FunctionDef) -> List[Tuple[ast.stmt, ast.Return]]:
            return [node, node.body[-1]]

    class TestReturnFromGeneratorTransformer_tree_changed(TestReturnFromGeneratorTransformer):
        """Unit test for ReturnFromGeneratorTransformer._tree_changed() method.
        """
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            generator_returns = self._find_generator_returns(node)
            return self.generic_visit(node)  # type: ignore

    source = '''\
    def fn():
        yield 1
        return 5
    '''

# Generated at 2022-06-12 03:53:55.609419
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:01.859441
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..compile_tools import compile_and_test_snippets, ast_compare_deep, ast_to_text
    from ..test_utils import get_node_by_path


# Generated at 2022-06-12 03:54:02.615498
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:03.793487
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:29.236616
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input_code = """
    def fn(a,b):
        yield 1
        if a:
            return b+1
        else:
            return b+3
        return b+5

    def fn2(a):
        yield 1
        yield 2
        return a+1
    """

# Generated at 2022-06-12 03:54:39.688463
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet, let
    from .base import BaseNodeTransformer

    with let(a):
        a = 5

    @snippet
    def fn():
        let(b)
        b = yield 1
        return a

    t = ReturnFromGeneratorTransformer()
    node = ast.parse(fn.as_string(), mode='exec')
    node = t.visit(node)

    assert ast.dump(node) == ast.dump(ast.parse(return_from_generator.as_string() + fn.as_string(), mode='exec'))


# Generated at 2022-06-12 03:54:51.256634
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test method visit_FunctionDef of class ReturnFromGeneratorTransformer. """
    node_def = ast.parse("""
        def fn(a, b):
            yield a
            return b
        def fn1(a, b):
            yield a
            return
        def fn2(a, b):
            yield a
            return b
            return c
        def fn3(a, b):
            return a
    """).body[0]


# Generated at 2022-06-12 03:54:58.473411
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    from ..utils.testing import assert_code_equal
    from .summarize_exceptions import SummarizeExceptionsTransformer
    from .unwrap_asserts import UnwrapAssertsTransformer

    code = """
        def fn():
            def fn_inner():
                return 4
            return 5
    """
    expected_code = """
        def fn():
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(code)

    # Act
    tree = SummarizeExceptionsTransformer().visit(tree)
    tree = UnwrapAssertsTransformer().visit(tree)
    tree = ReturnFromGeneratorTransformer().visit(tree)

    # Assert
    assert_code_equal(tree, expected_code)




# Generated at 2022-06-12 03:54:59.023192
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:08.047269
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import get_ast

    node = get_ast("""
    def fn(x):
        if x > 5:
            yield x
            return x
    """)
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)
    assert transformer.tree_changed
    code = compile(new_node, '<test>', 'exec')
    ns = {}
    exec(code, globals(), ns)
    assert next(ns['fn'](1)) == 1
    assert next(ns['fn'](10)) == 10
    with pytest.raises(StopIteration) as e:
        next(ns['fn'](1))
    assert e.value.value == 1

# Generated at 2022-06-12 03:55:18.735015
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import setup_node_transformer_tests
    setup_node_transformer_tests()

    from ..utils.test_utils import generate_equivalent_ast
    from ..utils.test_utils import parse_python
    from ..utils.test_utils import get_ast_node_by_path

    tree = parse_python("""
        def fn():
            yield 1
            return 5
        def fn2():
            return 5
    """)

    tree = generate_equivalent_ast(tree)
    fn = get_ast_node_by_path(tree, "body.0")  # type: ast.FunctionDef
    fn2 = get_ast_node_by_path(tree, "body.1")  # type: ast.FunctionDef

    tree = ReturnFromGeneratorTransformer().visit(tree)

    #

# Generated at 2022-06-12 03:55:25.004822
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""
    def fn():
      yield 1
      return 5
    """)
    node = tree.body[0]
    rft = ReturnFromGeneratorTransformer(None)
    rft.visit_FunctionDef(node)
    result_code = compile(tree, '', mode='exec')
    assert 'exc.value = 5' in result_code.co_code.hex()

# Generated at 2022-06-12 03:55:32.174760
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    from ..utils.test_utils import get_ast, assert_ast_equal

    # Non-generator function
    src = '''
        def fn():
            a = 1
            return 0
    '''
    expected = '''
        def fn():
            a = 1
            return 0
    '''
    result = ReturnFromGeneratorTransformer().visit(get_ast(src))
    assert_ast_equal(expected, result)

    # Generator function with return inside
    src = '''
        def fn():
            a = 1
            yield a
            return 2
    '''
    expected = '''
        def fn():
            exc = StopIteration()
            exc.value = 2
            raise exc
            a = 1
            yield a
    '''
    result = ReturnFrom

# Generated at 2022-06-12 03:55:43.241754
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast as pyast
    from typed_astunparse import unparse as unparse_pyast
    from typed_astunparse import dump as dump_pyast
    from typed_ast import ast3 as typed_ast


# Generated at 2022-06-12 03:56:08.690850
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    def fn2():
        yield from fn()
        return 5

    def fn3(x):
        return x

    def fn4():
        return

    sample = fn

# Generated at 2022-06-12 03:56:14.534710
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def foo():\n'
                     '    yield 1\n'
                     '    return 2\n')
    fn_def_node = node.body[0]

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(fn_def_node)

    assert str(fn_def_node) == 'def foo():\n    yield 1\n    exc = StopIteration()\n    exc.value = 2\n    raise exc\n'
    assert transformer.changed



# Generated at 2022-06-12 03:56:20.906203
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3 as ast
    import inspect
    import astor

    transformer = ReturnFromGeneratorTransformer()

    def test_fn1():
        yield 1
        return 5
    fn1 = test_fn1

    # get AST
    fn1_ast = ast.parse(inspect.getsource(fn1))

    # apply transformer
    transformed = transformer.visit(fn1_ast)

    # compare
    actual = astor.to_source(transformed)

# Generated at 2022-06-12 03:56:30.106374
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .transformer import Transformer
    from ..utils.ast import parse_ast_from_string
    from ..utils.test import test_transformer
    from ..utils.test import get_test_case_name


# Generated at 2022-06-12 03:56:41.322186
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test method `visit_FunctionDef` of class ReturnFromGeneratorTransformer."""
    node = ast.parse(textwrap.dedent('''
    def generator():
        yield 1
        return 1
    '''))
    ReturnFromGeneratorTransformer().visit(node)

# Generated at 2022-06-12 03:56:49.371425
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn(a: set) -> set:
            if a:
                return 5
    """
    tree = ast.parse(source)
    expected_source = """
        def fn(a: set) -> set:
            if a:
                exc = StopIteration()
                exc.value = 5
                raise exc
    """
    expected_tree = ast.parse(expected_source)

    transformer = ReturnFromGeneratorTransformer()
    transformed_tree = transformer.visit(tree)
    assert ast.dump(transformed_tree, include_attributes=False) == ast.dump(expected_tree, include_attributes=False)

# Generated at 2022-06-12 03:56:57.298236
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    '''
    Test method visit_FunctionDef of class ReturnFromGeneratorTransformer
    '''
    import textwrap
    import astor

    code = textwrap.dedent('''\
        def fn():
            yield 1
            return 5
        ''')

    expected_code = textwrap.dedent('''\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''')

    tree = ast.parse(code)
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    new_tree_code = astor.to_source(new_tree).strip()
    assert new_tree_code == expected_code

# Generated at 2022-06-12 03:57:06.840374
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .generator import GeneratorTransformer
    from .variable_arguments import VariableArgumentsTransformer

    prefix = 'from typing import Generator, Any\n'

    def do_test(code, expected):
        tree = ast.parse(code)
        vargs_transformer = VariableArgumentsTransformer()
        vargs_transformer.visit(tree)
        gen_transformer = GeneratorTransformer()
        gen_transformer.visit(tree)
        return_transformer = ReturnFromGeneratorTransformer()
        return_transformer.visit(tree)
        actual = prefix + astor.to_source(tree)
        assert actual == prefix + expected

    def do_test_for_error(code):
        tree = ast.parse(code)
        vargs_transformer = VariableArgumentsTransformer()
        vargs_

# Generated at 2022-06-12 03:57:07.679072
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # TODO
    pass

# Generated at 2022-06-12 03:57:17.086992
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Setup
    function_def = ast.FunctionDef(name=str(), args=ast.arguments(args=[], vararg=None,
                                   kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
                                   body=[ast.Yield(value=ast.Num(n=1)), ast.Return(value=ast.Num(n=5))],
                                   decorator_list=[], returns=None)
    node_transformer = ReturnFromGeneratorTransformer()

    # Exercise
    actual_code = node_transformer.visit(function_def)

# Generated at 2022-06-12 03:58:15.861790
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .sample_asts import return_from_generator_multiple_returns, return_from_generator_single_return, \
        return_from_generator_single_return_broken
    from .ast_utils import pretty

    def test_return_from_generator_multiple_returns():
        expected = """def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 2\n    raise exc\n    exc = StopIteration()\n    exc.value = 3\n    raise exc"""
        actual = pretty(return_from_generator_multiple_returns)
        assert expected == actual


# Generated at 2022-06-12 03:58:21.511938
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    inp = """
    def foo():
        yield 1
        return 1
    """
    out = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 1
        raise exc
    """
    node = ast.parse(inp)
    transformed = ReturnFromGeneratorTransformer().visit(node)
    assert astor.to_source(transformed) == out


# Generated at 2022-06-12 03:58:30.607224
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.snippet import snippet, let
    from ..utils.visitor import get_ast

    @snippet
    def test():
        let(a)
        def fn():
            for i in range(5):
                if i > 1:
                    return 2
                yield i

            return 7

        a = [i for i in fn()]

    tree = get_ast(test)
    transformer = ReturnFromGeneratorTransformer()
    transformed = transformer.visit(tree)

    @snippet
    def expected():
        let(a)
        def fn():
            for i in range(5):
                if i > 1:
                    exc = StopIteration()
                    exc.value = 2
                    raise exc

                yield i

            exc = StopIteration()
            exc.value = 7
            raise exc



# Generated at 2022-06-12 03:58:40.964681
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap
    from ..utils import SourceCode
    code = textwrap.dedent('''
    def fn():
        a = 1
        def fn1():
            yield a
            return 5
        fn1()
        yield 2
        return '4'
    ''')

    expected_code = textwrap.dedent('''
    def fn():
        a = 1
        def fn1():
            yield a
            exc = StopIteration()
            exc.value = 5
            raise exc
        fn1()
        yield 2
        exc = StopIteration()
        exc.value = '4'
        raise exc
    ''')

    source_code = SourceCode(code)
    transformer = ReturnFromGeneratorTransformer(source_code)

# Generated at 2022-06-12 03:58:47.323974
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # SETUP
    code = """
    # Given
    def fn():
        yield 1
        return 5
    """
    tree = ast.parse(code)

    expected_code = """
    # Expected
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    expected_tree = ast.parse(expected_code)

    transformer = ReturnFromGeneratorTransformer()

    # RUN
    result = transformer.visit(tree)

    # ASSERT
    assert_equal_ast(result, expected_tree)



# Generated at 2022-06-12 03:58:51.607553
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    tree = astor.parse_file('tests/fixtures/return_from_generator.py')
    rfgt = ReturnFromGeneratorTransformer()
    rfgt.visit(tree)
    assert astor.to_source(tree) == astor.code_to_ast.parse_file('tests/fixtures/return_from_generator_expected.py').body[0]

# Generated at 2022-06-12 03:58:58.603244
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source_transformer import get_ast
    transformer = ReturnFromGeneratorTransformer()
    source = """
    def fn():
        yield 1
        return 5
    """
    expected_ast = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert transformer.get_visit_changes(get_ast(source)) == [True]
    assert ast.dump(get_ast(source), include_attributes=True) == ast.dump(get_ast(expected_ast), include_attributes=True)



# Generated at 2022-06-12 03:59:06.616834
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def fn():
        yield 1
        return 5

    module_node = ast.parse(fn)
    function_node = module_node.body[0]

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(function_node)

    expected = fn.get_body(return_value=5)[:-1]
    result = []
    for node in function_node.body:
        result.append(ast.fix_missing_locations(ast.Module(body=[node])))

    assert len(result) == len(expected)
    for res, exp in zip(result, expected):
        assert ast.dump(res) == ast.dump(exp)

# Generated at 2022-06-12 03:59:16.520346
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import render_to_functiondef
    example_code = \
        """
        def f():
            a = 1
            yield a
            return 1
        def f2():
            a = 1
            yield a
            yield 1
        def f3():
            yield from a()
            return 1
        def f4():
            return 1
        def f5():
            yield from a()
            yield 1
        def f6():
            yield from a()
            yield from b()
        """

# Generated at 2022-06-12 03:59:22.175494
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_node
    from .. import ast_converter

    src = '''
    def fn():
        yield 1
        return 5
    '''
    module = get_node(src, 'module')
    module.body[0] = ReturnFromGeneratorTransformer().visit(module.body[0])
    result = ast_converter.convert_ast(module)