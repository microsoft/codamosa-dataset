

# Generated at 2022-06-12 03:50:56.166310
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .helpers import parse_function

    def check(code, expected):
        node = parse_function(code)
        actual = ReturnFromGeneratorTransformer().visit(node)
        assert actual.as_string() == expected

    check('def foo(): pass', 'def foo(): pass')
    check('def foo(): return', 'def foo(): pass')

    # Simple case with single return.
    check('''
    def foo():
        yield 1
    ''',
    '''
    def foo():
        yield 1

        pass
    ''')
    check('''
    def foo():
        yield 1
        return
    ''',
    '''
    def foo():
        yield 1

        exc = StopIteration()
        exc.value = None
        raise exc
    ''')

# Generated at 2022-06-12 03:51:07.521738
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    @transformer.register
    def add_gen(n) -> int:
        """Add n to generator body."""
        def fn(a: int, b: int) -> int:
            """Add `a` and `b` in generator."""
            yield a + b
            return a + b + n
        return fn

    @add_gen(5)
    def fn(a: int, b: int) -> int:
        """Add `a` and `b` in generator."""
        yield a + b
        return a + b

    tree = ast.parse(inspect.getsource(fn))
    transformer.visit(tree)


# Generated at 2022-06-12 03:51:18.713918
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MockedAssert:
        def __init__(self):
            self.assertEqualsCalled = False
            self.assertEqualsArgs = None

        def assertEquals(self, *args):
            self.assertEqualsCalled = True
            self.assertEqualsArgs = args
    mockedAssert = MockedAssert()

    def get_returns(funcdef):
        return_from_generator = ReturnFromGeneratorTransformer().visit_FunctionDef(funcdef)
        return return_from_generator.body

    def get_first_return(funcdef):
        return get_returns(funcdef)[0]

    def get_last_return(funcdef):
        return get_returns(funcdef)[-1]


# Generated at 2022-06-12 03:51:30.634428
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3 as ast
    import ast as py_ast
    import astunparse
    import sys
    
    def test_compile_string_with_python_ast(code):
        expected_ast = py_ast.parse(code)
        expected_code = astunparse.unparse(expected_ast)
        typed_ast = ast.parse(code)
        transformer = ReturnFromGeneratorTransformer()
        typed_ast = transformer.visit(typed_ast)
        typed_ast_unparsed = astunparse.unparse(typed_ast)
        assert expected_code == typed_ast_unparsed
    
    def test_compile_string_with_typed_ast(code):
        expected_ast = ast.parse(code)

# Generated at 2022-06-12 03:51:36.069690
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tr = ReturnFromGeneratorTransformer()
    tree = ast.parse("""def fn():
            yield 1
            return 5
    """)
    result = tr.visit(tree)
    expected = ast.parse("""def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-12 03:51:36.843416
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:38.398701
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..compiler.transformer import PythonToPythonSemanticTreeTransformer
    
    transformer = PythonToPythonSemanticTreeTransformer()
    transformer.transform(__file__)
    assert transformer._tree_changed == True

# Generated at 2022-06-12 03:51:50.002087
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    # Tests when node is not a generator
    node = ast.parse('''
        def foo():
            return

        x = foo()
    ''')
    transformer.visit(node)
    assert node == ast.parse('''
        def foo():
            return

        x = foo()
    ''')

    # Tests when node is a generator and has a return
    node = ast.parse('''
        def foo():
            yield 1
            return 5

        x = foo()
    ''')
    transformer.visit(node)
    assert node == ast.parse('''
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

        x = foo()
    ''')

    # Tests when

# Generated at 2022-06-12 03:51:57.148318
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from ..utils.test_utils import compile_snippet, compare, AssertSnippetInside

    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    source = """
        @return_from_generator
        def fn():
            yield 1
            return 5
    """
    compare(parse(expected_source), compile_snippet(source, {'return_from_generator': ReturnFromGeneratorTransformer}))



# Generated at 2022-06-12 03:51:58.621686
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_astunparse

# Generated at 2022-06-12 03:52:10.602371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = "def fn(): yield 1; return 5"
    actual = transform(ReturnFromGeneratorTransformer, source)
    expected = "def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc"
    assert actual == expected



# Generated at 2022-06-12 03:52:17.066853
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    node = ast.parse("""def fn():
        yield 1
        return 5""")
    transformer = ReturnFromGeneratorTransformer()
    expected = ast.parse("""def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc""")
    # Act
    result = transformer.visit(node)
    # Assert
    assert result == expected


# Generated at 2022-06-12 03:52:30.463157
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Create AST to test on
    ast_tree = ast.parse(
        "def fn():\n"
        "    if True: return 5\n"
        "    yield 1\n"
        "    return 5\n"
        "    yield 2\n"
    )
    expected = ast.parse(
        "def fn():\n"
        "    if True:\n"
        "        exc = StopIteration()\n"
        "        exc.value = 5\n"
        "        raise exc\n"
        "    yield 1\n"
        "    exc = StopIteration()\n"
        "    exc.value = 5\n"
        "    raise exc\n"
        "    yield 2\n"
    )

    transformer = ReturnFromGeneratorTransformer()
    transformer.vis

# Generated at 2022-06-12 03:52:40.008394
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    RETURN_FROM_SINGLE_GENERATOR = '''
        def with_return():
            yield 1
            return 2

        def without_return():
            yield 1

        def without_yield():
            return 2
    '''
    rfgt = ReturnFromGeneratorTransformer()
    tree = ast.parse(RETURN_FROM_SINGLE_GENERATOR)
    rfgt.visit(tree)
    expected_code = '''
        def with_return():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc

        def without_return():
            yield 1

        def without_yield():
            return 2
    '''
    assert unparse(tree).strip() == expected_code.strip()



# Generated at 2022-06-12 03:52:41.030195
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:45.192814
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..generate_code import generate_code
    from .base import NodeTransformerTestCase

    class TestCase(NodeTransformerTestCase):
        def generate_code_from_ast(self, tree):
            return generate_code(tree, '__main__')

    TestCase.test(ReturnFromGeneratorTransformer)

# Generated at 2022-06-12 03:52:48.968107
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        yield 1
        return 5
    """

    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))



# Generated at 2022-06-12 03:52:54.213581
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.node_utils import compare_ast
    from ..utils.helpers import get_python_source
    from ..utils.fixtures import get_ast_function_def

    node = get_ast_function_def()
    node = get_python_source(node)
    node = ast.parse(node)
    node = ReturnFromGeneratorTransformer().visit(node)
    ast.fix_missing_locations(node)
    node = ast.dump(node)
    node = get_python_source(node)

    expected = get_python_source(get_ast_function_def())
    assert compare_ast(expected, node) == True

# Generated at 2022-06-12 03:53:07.032404
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def fn(): yield 1; return 5')
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed == True
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.FunctionDef)
    assert isinstance(node.body[0].body[0], ast.Expr)
    assert node.body[0].body[0].value.id == '1'
    assert isinstance(node.body[0].body[1], ast.Assign)
    assert node.body[0].body[1].targets[0].id == 'exc'
    assert isinstance(node.body[0].body[1].value, ast.Call)
    assert node.body[0].body[1].value

# Generated at 2022-06-12 03:53:09.736270
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import sys
    import io
    captured_output = io.StringIO()         # Create StringIO object
    sys.stdout = captured_output            # and redirect stdout.
    

# Generated at 2022-06-12 03:53:28.414466
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .generator import GeneratorTransformer
    from .noreturn import NoReturnTransformer
    from .base import combine_transformers

    class UserTransform(combine_transformers(GeneratorTransformer, NoReturnTransformer, ReturnFromGeneratorTransformer)):
        pass

    source = """def fn():
        yield 1
        yield 2
        return 3"""

    expected = """def fn():
        yield 1
        yield 2
        exc = StopIteration()
        exc.value = 3
        raise exc"""

    transformer = UserTransform()
    transformed = transformer.visit(ast.parse(source))
    transformed = ast.unparse(transformed).strip()
    assert transformed == expected

# Generated at 2022-06-12 03:53:39.719309
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ...utils.testing import assert_code_equal
    from ...utils.testing import transform

    @transform(ReturnFromGeneratorTransformer)
    def test_func():
        def fn1():
            yield 1
            return 5

        def fn2():
            for x in [1, 2, 3]:
                yield x
            return 7

        def fn3():
            return 12

        def fn4():
            yield 4

        def fn5():
            yield 5
            return

        def fn6():
            yield 6
            return None

        def fn7():
            if True:
                yield 7
                return 1
            yield 2

        def fn8():
            if True:
                yield 8
                return 3
            else:
                yield 9
                return 4
            yield 10


# Generated at 2022-06-12 03:53:42.044735
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import compile_snippet
    from ..utils.source_recode import encode_string


# Generated at 2022-06-12 03:53:43.482149
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # given
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:53:55.450528
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def function():
        return 5
    node = ast.parse(inspect.getsource(function))
    assert isinstance(node.body[0], ast.FunctionDef)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert isinstance(node.body[0], ast.FunctionDef)
    assert 'exc = StopIteration()' in ast.dump(node)

    def generator():
        yield 1
        return 5
    node = ast.parse(inspect.getsource(generator))
    assert isinstance(node.body[0], ast.FunctionDef)
    node = ReturnFromGeneratorTransformer().visit(node)
    assert isinstance(node.body[0], ast.FunctionDef)
    assert not isinstance(node.body[0].body[0], ast.Return)


# Generated at 2022-06-12 03:54:06.114835
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import format_code
    from .base import BaseNodeTransformerTest
    from .test_function_def_test import _macros as macros
    from .test_function_def_test import _test_visit_FunctionDef_implementation as test_visit_FunctionDef_implementation

    class Test(BaseNodeTransformerTest):
        target = (3, 2)
        @property
        def node_transformer(self) -> BaseNodeTransformer:
            return ReturnFromGeneratorTransformer()

    code = \
        """\
        def fn():
            yield 1
            return 5
        """
    assert format_code(code) == format_code(test_visit_FunctionDef_implementation(Test, code, macros))

# Generated at 2022-06-12 03:54:15.815371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    c = ReturnFromGeneratorTransformer()
    test_nodes_list = [
            ast.parse(
                textwrap.dedent(
                    """
                    def fn():
                        yield 1
                        return 5
                    """
                )
            )
        ]
    expected_nodes_list = [
            ast.parse(
                textwrap.dedent(
                    """
                    def fn():
                        yield 1
                        exc = StopIteration()
                        exc.value = 5
                        raise exc
                    """
                )
            )
        ]
    for test_node, expected_node in zip(test_nodes_list, expected_nodes_list):
        assert ast.dump(c.visit(test_node), include_attributes=True) == ast.dump(expected_node, include_attributes=True)

# Generated at 2022-06-12 03:54:19.025503
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def load_ast(code):
        return ast.parse(code).body[0]


# Generated at 2022-06-12 03:54:23.803742
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def f1():
        x = 5
        return x
    node = ast.parse(return_from_generator.get_source(return_value=0))
    node = ReturnFromGeneratorTransformer().visit_FunctionDef(node)
    assert ast.dump(node) == ast.dump(f1)

# Generated at 2022-06-12 03:54:36.105600
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import FunctionDef
    from typed_ast import ast3


# Generated at 2022-06-12 03:54:50.199923
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import astunparse


# Generated at 2022-06-12 03:54:50.835808
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:58.217877
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from ..utils.testing import node_to_strs

    code = """
    def fn():
        yield 1
        return 2
    """

    code_expected = """
    def fn():
        yield 1
        # line 2
        exc = StopIteration()
        # line 3
        exc.value = 2
        # line 4
        raise exc
    """

    node = ast.parse(code).body[0]
    node_expected = ast.parse(code_expected).body[0]

    t = ReturnFromGeneratorTransformer()
    node_actual = t.visit(node)

    assert node_to_strs(node_actual) == node_to_strs(node_expected)

    # Test for function without return statement
    code = """
    def fn():
        yield 1
    """


# Generated at 2022-06-12 03:55:03.180489
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # -- setup --
    f = ast.parse("def fn(): yield 1; return 5", mode='exec').body[0]
    s = ReturnFromGeneratorTransformer()

    # -- test --
    f1 = s.visit(f)

    # -- assert --
    assert str(f1) == "def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc", "expected to be equal"



# Generated at 2022-06-12 03:55:04.703990
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class_name = ReturnFromGeneratorTransformer.__name__


# Generated at 2022-06-12 03:55:14.803245
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:26.141148
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..transpile import Transpiler
    from ..utils import as_tuple

    transpiler = Transpiler()

    @transpiler.register(ReturnFromGeneratorTransformer)
    def foo():
        yield 1
        return 5  # pragma: no cover

    @transpiler.register(ReturnFromGeneratorTransformer)
    def bar():
        yield 1
        if True:
            return 5  # pragma: no cover


# Generated at 2022-06-12 03:55:35.644942
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from typed_astunparse import unparse
    from ..utils import typed_exec, test_node
    from .. import utils
    import astunparse
    import ast

    class TestReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer, BaseNodeTransformer):
        def __init__(self, tree: ast.AST, filename: str = "<unknown>"):
            super().__init__(tree, filename)

    code = utils.code_equal
    code_true = utils.code_true

    code_true("""
        def fn():
            yield 1
            return 5
    """)

    tree = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    TestReturnFromGeneratorTransformer(tree).visit(tree)
   

# Generated at 2022-06-12 03:55:45.135450
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..fixer import Fixer
    from ..utils import get_ast as _get_ast
    from ..utils import parse_to_fixed as _parse_to_fixed

    code_to_fix = """
    def foo():
        def bar():
            yield 1
            return 1
        return bar()
    """

    code_fixed = """
    def foo():
        def bar():
            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc
        return bar()
    """

    ast_tree = _get_ast(code_to_fix)
    ast_tree = ReturnFromGeneratorTransformer.run(Fixer, ast_tree)
    code_fixed_1 = _parse_to_fixed(ast_tree)
    assert code_fixed_1 == code_fixed


# Generated at 2022-06-12 03:55:55.860501
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def function_with_inner_functions():
        def fn1():
            yield 1
            return 5
        def fn2():
            yield 2
            return 6

        def fn3():
            yield 3
            return 7

        a = 42
        return a

    @snippet
    def function_with_inner_functions_expected():
        def fn1():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        def fn2():
            yield 2
            exc = StopIteration()
            exc.value = 6
            raise exc

        def fn3():
            yield 3
            exc = StopIteration()
            exc.value = 7
            raise exc

        a = 42
        return a


# Generated at 2022-06-12 03:56:30.727885
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astor import dump_tree, parse_tree
    class TestReturnFromGeneratorTransformer_visit_FunctionDef:
        def fn():
            yield 1
            return 5
    code = dump_tree(parse_tree(TestReturnFromGeneratorTransformer_visit_FunctionDef.__dict__['fn']))
    expected_code = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
    node = parse_tree(TestReturnFromGeneratorTransformer_visit_FunctionDef.__dict__['fn'])
    transformer = ReturnFromGeneratorTransformer(None)
    transformer.visit(node)
    assert dump_tree(node) == expected_code


# Generated at 2022-06-12 03:56:40.390119
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator = ReturnFromGeneratorTransformer()
    tree = ast.parse(
        """
    def f():
        yield 5
        return 6
        """
    )
    return_from_generator.visit(tree)
    assert return_from_generator._tree_changed
    expected = ast.parse(
        """
    def f():
        yield 5
        exc = StopIteration()
        exc.value = 6
        raise exc
        """
    ).body[0]
    assert ast.dump(tree.body[0], annotate_fields=False) == ast.dump(expected, annotate_fields=False)

# Generated at 2022-06-12 03:56:45.411383
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("def foo():\n  yield 1\n  return 2\n")  # type: ignore
    f = node.body[0]
    fn_transformer = ReturnFromGeneratorTransformer()
    fn_transformer.visit(f)
    assert [x.lineno for x in f.body] == [1, 2, 3, 3]  # type: ignore

# Generated at 2022-06-12 03:56:48.781795
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import sys

    class TestReturnFromGeneratorTransformer_visit_FunctionDef(unittest.TestCase):
        def test(self):
            self.maxDiff = None

# Generated at 2022-06-12 03:56:57.682018
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn():
        yield 1
        return 5
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert ast.dump(tree) == ast.dump(ast.parse(expected))

    source = """
    def fn():
        try:
            yield 1
        except:
            return 5
    """
    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    expected = """
    def fn():
        try:
            yield 1
        except:
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
   

# Generated at 2022-06-12 03:57:03.574700
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn(self):
        yield 1
        return 5
        yield 2

    func = fn.__code__
    output = ReturnFromGeneratorTransformer().visit_FunctionDef(ast.parse(func.co_consts[1]).body[0])
    assert ast.dump(output) == ast.dump(ast.parse("""
        def fn(self):
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            yield 2
    """))

# Generated at 2022-06-12 03:57:10.181138
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base import TestTransformerBase

    class Test(TestTransformerBase):
        transformer = ReturnFromGeneratorTransformer

        def test_no_generator(self):
            fn = self.transform_func('''
                def fn():
                    pass
            ''')
            self.assertEqual(fn.body, [])

        def test_simple_generator(self):
            fn = self.transform_func('''
                def fn():
                    yield 1
            ''')
            self.assertEqual(fn.body, [ast.Expr(ast.Yield(ast.Num(1)))])

        def test_simple_generator_with_return(self):
            fn = self.transform_func('''
                def fn():
                    yield 1
                    return 5
            ''')
            expected

# Generated at 2022-06-12 03:57:12.509998
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..test_utils import get_test_ast
    from ..test_utils import format_code
    from ..test_utils import compare_ast


# Generated at 2022-06-12 03:57:15.668294
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from .compile_forbid_generator_return import compile_forbid_generator_return
    from ..runtime import return_from_generator as runtime_return_from_generator

# Generated at 2022-06-12 03:57:20.232370
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fn = '''
    def fn():
        yield 1
        return 1
    '''
    expected_fn = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 1
        raise exc
    '''
    t = ReturnFromGeneratorTransformer()
    node = ast.parse(fn)
    t.visit(node)
    assert node == ast.parse(expected_fn)



# Generated at 2022-06-12 03:58:02.617374
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

# Generated at 2022-06-12 03:58:03.450206
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:58:10.203208
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = \
        """
        def t():
            yield 5
            return 6
        def s():
            return 7
        """
    tree = ast.parse(source)
    node = tree.body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformed_tree = transformer.visit(node)
    code = compile(transformed_tree, '<ast>', mode='exec')
    gl = {}
    exec(code, gl)
    fn = gl['t']
    assert next(fn()) == 5
    assert next(fn()) == 6



# Generated at 2022-06-12 03:58:15.670668
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    src = """
        def fn():
            yield 1
            return 5
    """
    correct = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(src)
    result = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(result) == ast.dump(ast.parse(correct))



# Generated at 2022-06-12 03:58:22.121087
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import _ast as ast

    transformer = ReturnFromGeneratorTransformer(None)
    original = ast.parse("""def f():
                            a = 5
                            return a""")

    expected = ast.parse("""def f():
                            a = 5
                            exc = StopIteration()
                            exc.value = a
                            raise exc""")

    transformer._replace_return = lambda *args: None
    assert transformer.visit_FunctionDef(original.body[0]) == expected.body[0]

# Generated at 2022-06-12 03:58:31.092371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..codegen import to_source, get_ast

    def _test_fn(fn: Any) -> str:
        """:type fn: function"""
        nonlocal node
        assert isinstance(fn, ast.FunctionDef)
        assert isinstance(fn.body[-1], ast.Return), 'There should be Return in the last line'
        node = fn

    source = """
    def fn():
        yield 1
        return 5
        for i in range(10):
            if i == 5:
                return 7
    """
    module = get_ast(source)
    ReturnFromGeneratorTransformer().visit(module)
    results: List[str] = list(filter(None, map(to_source, node.body)))

# Generated at 2022-06-12 03:58:38.525887
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(
        'def fn():\n'
        '    yield 1\n'
        '    return 2'
    )
    node = ReturnFromGeneratorTransformer().visit(node)
    expected = (
        'def fn():\n'
        '    yield 1\n'
        '    exc = StopIteration()\n'
        '    exc.value = 2\n'
        '    raise exc')
    assert ast_to_source(node) == expected



# Generated at 2022-06-12 03:58:46.701247
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from ..utils.source import source_to_ast

    class MockTransformer(BaseNodeTransformer):
        def __init__(self):
            self.n_calls = 0

        def generic_visit(self, node, **kwargs):
            self.n_calls += 1
            return node, kwargs

    source = """
        def foo():
            yield 1
            return
            yield 2

        def bar():
            yield 1
            return 1
            yield 2

        def baz():
            return
            yield
    """
    ast_mod = source_to_ast(source)
    generator_transformer = ReturnFromGeneratorTransformer()

    mock_transformer = MockTransformer()
    assert not generator_transformer.tree_changed

# Generated at 2022-06-12 03:58:50.635037
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..typed_astunparse import unparse
    from .transformers import print_tree

    code = '''
    def foo():
        yield 1
        return 5
    '''
    tree = ast.parse(code)
    print_tree(tree)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    print_tree(tree)
    unparse(tree)

# Generated at 2022-06-12 03:58:59.604823
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # No return with no yield
    no_return_no_yield = '''def test():
            a = 5
            return a'''
    no_return_no_yield_result = '''def test():
            a = 5
            return a'''
    # Return with no yield
    return_no_yield = '''def test():
            return 5'''
    return_no_yield_result = '''def test():
            return 5'''
    # Return with yield
    return_with_yield = '''def test():
            yield
            return 5'''
    return_with_yield_result = '''def test():
            yield
            exc = StopIteration()
            exc.value = 5
            raise exc'''
    # Return with many yields
    return_with_many_yields