

# Generated at 2022-06-12 03:50:58.549087
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    init_node = ast.FunctionDef(
        name='fn',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            ast.Assign(
                targets=[
                    ast.Name(
                        id='a',
                        ctx=ast.Store()
                    )
                ],
                value=ast.Num(n=1)
            ),
            ast.Yield(value=ast.Num(n=1)),
            ast.Return(value=ast.Num(n=5))
        ],
        decorator_list=[],
        returns=None
    )

    expected_node = ast.Function

# Generated at 2022-06-12 03:51:07.859335
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import Script
    import astunparse
    generator_return_script = Script("""
        def fn():
            yield 1
            return 5
        """)
    generator_return_tree = generator_return_script.tree
    expected_tree = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """)
    ReturnFromGeneratorTransformer().visit(generator_return_tree)
    assert astunparse.unparse(generator_return_tree) == astunparse.unparse(expected_tree)



# Generated at 2022-06-12 03:51:08.854974
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:15.323920
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    snippet = """
    def foo():
        yield 1
        return 5
    """
    expected_code = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(snippet)
    ReturnFromGeneratorTransformer().visit(node)
    assert expected_code == astor.to_source(node)


snippet_count = 0



# Generated at 2022-06-12 03:51:27.616816
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse('def fn(): yield 1; return 5').body[0]
    transformer.visit(node)

# Generated at 2022-06-12 03:51:37.980433
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MockNode:
        def __init__(self, value=None):
            self.value = value

    class MockFunctionDef:
        def __init__(self, body):
            self.body = body

    class MockReturn:
        def __init__(self, value=None):
            self.value = value

    class MockParent:
        def __init__(self, body):
            self.body = body

    func = MockFunctionDef(body=[MockNode(), MockNode(), MockReturn()])
    parent = MockParent(body=[MockNode(), MockReturn()])

    node_transformer = ReturnFromGeneratorTransformer()
    node_transformer._find_generator_returns = lambda x: [parent, func]
    node_transformer.generic_visit = lambda x: True
    node_transformer.vis

# Generated at 2022-06-12 03:51:45.620936
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    from ..utils.source import source

    src1 = """
    def fn():
        yield 1
        return 5
    """

    src2 = source(return_from_generator) + """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    for i in range(2):
        result = BaseNodeTransformerTest.run_transformer(src1, ReturnFromGeneratorTransformer)
        assert result == src2

# Generated at 2022-06-12 03:51:55.954441
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.ast.generator import generator_def, return_in_generator_def, yield_in_generator_def

    case_no_yield = ('def gen():\n'
                     '    a = 1\n'
                     '    return a')

    case_yield = ('def gen():\n'
                  '    a = 1\n'
                  '    yield a')

    case_yield_return = ('def gen():\n'
                         '    a = 1\n'
                         '    yield a\n'
                         '    return a')

    case_yield_return_if = ('def gen():\n'
                            '    a = 1\n'
                            '    yield a\n'
                            '    if a == 1:\n'
                            '        return a')

    case

# Generated at 2022-06-12 03:52:03.504644
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # snippet
    def fn():
        yield 1
        return 5

    tree = ast.parse(fn.getsource())
    assert isinstance(tree, ast.Module)
    node = tree.body[0]
    assert isinstance(node, ast.FunctionDef)

    transformed = ReturnFromGeneratorTransformer().visit(tree)
    result = ast.unparse(transformed)

    # snippet
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    expected = compile(ast.parse(fn.getsource()), '', 'exec')
    exec(expected)
    assert result == fn.getsource()

# Generated at 2022-06-12 03:52:10.004961
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import make_call_node
    def_ = ast.FunctionDef(args=ast.arguments(), body=[
        ast.Yield(value=ast.Num(n=1)),
        ast.Return(value=ast.Num(n=2)),
        ast.Return(value=None),
        ast.Raise(exc=ast.Name(id='StopIteration'), cause=None),
    ])
    new_def = ReturnFromGeneratorTransformer().visit(def_)

# Generated at 2022-06-12 03:52:19.428698
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Visitor(ast.NodeVisitor):
        def __init__(self):
            self.result_list = []

        def generic_visit(self, node):
            self.result_list.append(node)


# Generated at 2022-06-12 03:52:25.522477
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source
    from ..utils.ast_builder import ast_from_source
    from ..utils.source import source
    from ..transforms.return_from_generator import ReturnFromGeneratorTransformer

    code = '''
    def generator():
        yield 1
        yield 2
        return

    def not_generator():
        yield 1
        return
    '''
    mod = ast_from_source(code)

    expected_code = '''
    def generator():
        yield 1
        yield 2
        exc = StopIteration()
        exc.value = None
        raise exc

    def not_generator():
        yield 1
        exc = StopIteration()
        exc.value = None
        raise exc
    '''
    expected_mod = ast_from_source(expected_code)

    transformer

# Generated at 2022-06-12 03:52:26.376876
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:31.494596
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    tree = ast3.parse('''
    def fn():
        yield 1
        return 12
    ''')
    rt_fn = ReturnFromGeneratorTransformer().visit(tree)

    for line in ast3.dump(rt_fn).splitlines():
        print(line)

# Generated at 2022-06-12 03:52:42.015742
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    func = ast.parse('def f(): yield 1; return 5').body[0]
    trans = ReturnFromGeneratorTransformer()
    transformed = trans.visit(func)
    assert isinstance(transformed, ast.FunctionDef)
    assert transformed.name == 'f'
    assert len(transformed.body) == 4
    assert isinstance(transformed.body[0], ast.Yield)
    assert isinstance(transformed.body[1], ast.Assign)
    assert isinstance(transformed.body[1].value, ast.Call)
    assert isinstance(transformed.body[1].value.func, ast.Name)
    assert transformed.body[1].value.func.id == 'StopIteration'
    assert isinstance(transformed.body[2], ast.Assign)

# Generated at 2022-06-12 03:52:45.090328
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn1():
        yield 1
        return 5

    def fn2():
        yield 1
        return
    
    def fn3():
        yield 1
        return 5, 6


# Generated at 2022-06-12 03:52:45.719176
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:52:54.723629
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from test.parser.pattern import pattern

    # Pattern for methods visit_FunctionDef and visit_Return
    fdef_pat = pattern(
        """
        def fn(params):
            return_expr
            return_expr
        """
    )

    # Splice for `return_expr`
    ret_splice = pattern(
        """
        if true_expr:
            return value
        """
    )

    # Testing method visit_FunctionDef
    fdef = fdef_pat.randomize()
    ast.fix_missing_locations(fdef)
    ast.copy_location(fdef, ast.parse(fdef_pat.string()))

    t = ReturnFromGeneratorTransformer()
    t.visit(fdef)

    assert (t.generic_visit(fdef) == fdef)

# Generated at 2022-06-12 03:52:58.527276
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def check(code_before, code_after):
        node = ast.parse(code_before)
        node = ReturnFromGeneratorTransformer().visit(node)
        assert code_after == ast.dump(node)


# Generated at 2022-06-12 03:53:00.860531
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:53:14.409072
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_input = """
        def f():
            yield 1
            return 5
        def f():
            return 5
        def f():
            yield 1
    """
    test_output = """
        def f():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        def f():
            return 5
        def f():
            yield 1
    """
    uwlines = yapf_test_helper.ParseAndUnwrap(test_input)
    uwlines = ReturnFromGeneratorTransformer().transform(uwlines)
    assert test_output == reformat(uwlines)

# Generated at 2022-06-12 03:53:22.010546
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_transformers_base import get_node
    node = get_node('''
        def fn():
            yield 1
            return 5
    ''')
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert transformer.tree_changed is True

    expected_1 = 'def fn():'
    expected_2 = '    yield 1'
    expected_3 = '    exc = StopIteration()'
    expected_4 = '    exc.value = 5'
    expected_5 = '    raise exc'
    expected = [expected_1, expected_2, expected_3, expected_4, expected_5]
    assert expected == [line.strip() for line in node.body[0].body]

# Generated at 2022-06-12 03:53:24.734044
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .example_asts import function_with_generator_return
    from .example_asts import function_with_generator_return_as_string
    expected = ast.parse(function_with_generator_return_as_string)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(function_with_generator_return)
    assert ast.dump(function_with_generator_return) == ast.dump(expected)


# Generated at 2022-06-12 03:53:35.641580
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""def fn():
    yield 1
    return 5""").body[0]
    assert node.body[-1].value is not None
    assert isinstance(node.body[-1], ast.Return)
    ReturnFromGeneratorTransformer.run(node)
    body = [x.body[0] for x in node.body if isinstance(x, ast.Expr)]
    assert len(body) == 3
    assert isinstance(body[0], ast.Yield)
    assert isinstance(body[1], ast.Assign)
    assert isinstance(body[1].value, ast.Call)
    assert isinstance(body[1].value.func, ast.Name)
    assert isinstance(body[2], ast.Raise)

# Generated at 2022-06-12 03:53:47.269893
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
    def foo():
        yield 1
        return 42
    """)
    module = ReturnFromGeneratorTransformer().visit(node)


# Generated at 2022-06-12 03:53:59.288532
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a = """def foo():
    yield 1
    return 5"""
    a_expected = """def foo():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""

    b = """def foo():
        yield from bar()
        yield from baz()
        return 5"""
    b_expected = """def foo():
        yield from bar()
        yield from baz()
        exc = StopIteration()
        exc.value = 5
        raise exc"""

    c = """def foo():
        for i in range(5):
            yield i
        return 5"""
    c_expected = """def foo():
        for i in range(5):
            yield i
        exc = StopIteration()
        exc.value = 5
        raise exc"""


# Generated at 2022-06-12 03:54:10.911706
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import ast_util
    from . import source_util
    from .. import fixer_util
    from ast import FunctionDef, Return
    from typed_ast.ast3 import fix_missing_locations, parse

    source = '''\
    def fn():
        yield 1
        return 5
        '''
    expected_source = '''\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
        '''
    tree = parse(source)
    fixer_util.touch_import(None, 'typing', tree)
    fix_missing_locations(tree)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert source_util.to_source(tree) == expected_source


# Generated at 2022-06-12 03:54:22.878423
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Create the AST
    node = ast.FunctionDef(
        name='test',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[],
        ),
        body=[
            ast.Expr(
                value=ast.Yield(
                    value=ast.Constant(
                        value=1,
                    ),
                ),
            ),
            ast.Return(
                value=ast.Constant(
                    value=5,
                ),
            ),
        ],
        decorator_list=[],
        returns=None,
    )

    # Create the transformer
    transformer = ReturnFromGeneratorTransformer()

    # Visit the AST

# Generated at 2022-06-12 03:54:24.315090
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:26.140110
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import setup_test_env
    setup_test_env()


# Generated at 2022-06-12 03:54:48.332204
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_node = ast.parse('def fn():\n'
                            '    yield 1\n'
                            '    return 2')
    ReturnFromGeneratorTransformer().visit(module_node)
    assert(ast.dump(module_node) ==
           "Module(body=[FunctionDef(name='fn', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Yield(value=Num(n=1))), Expr(value=Call(func=Name(id='return_from_generator', ctx=Load()), args=[Num(n=2)], keywords=[], starargs=None, kwargs=None)), Return()], decorator_list=[], returns=None)])")

# Generated at 2022-06-12 03:54:49.400749
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:57.249798
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Simple function with a single return
    node = ast.parse("""
        def fn():
            yield 1
            return 5
        """).body[0]  # type: ast.FunctionDef
    actual_node = ReturnFromGeneratorTransformer().visit(node)
    actual_source = ast.unparse(actual_node).strip()
    expected_source = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """.strip()
    assert expected_source == actual_source

    # Simple function with a single return, with if
    node = ast.parse("""
        def fn():
            if some_condition():
                yield 1
            return 5
        """).body[0]  # type: ast.FunctionDef
    actual_node = ReturnFromGenerator

# Generated at 2022-06-12 03:55:03.644502
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        yield 1
        return 5
    """
    abstract_syntax_tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(abstract_syntax_tree)
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    assert ast.dump(abstract_syntax_tree) == ast.dump(expected)
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-12 03:55:13.021477
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def fn():
            yield 1
            return 5
        def fn2():
            a = 5
            a = 6
            yield a
            return a
        """
    node = ast.parse(code)
    trans = ReturnFromGeneratorTransformer()
    new_node = trans.visit(node)
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        def fn2():
            a = 5
            a = 6
            yield a
            exc = StopIteration()
            exc.value = a
            raise exc
        """
    expected_node = ast.parse(expected_code)
    assert ast.dump(new_node) == ast.dump(expected_node)

# Generated at 2022-06-12 03:55:14.907046
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import source_to_node

# Generated at 2022-06-12 03:55:15.981060
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:27.041218
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    class SampleVisitor(ast.NodeVisitor):
        def visit_Assign(self, node):
            return {'target': node.targets[0], 'value': node.value}

    expected = {
        'assign_return_value': {
            'target': {'id': 'exc', 'ctx': {'type': 'Store'}},
            'value': {'func': {'id': 'StopIteration'}, 'args': [], 'keywords': []},
            },
        'raise': {
            'exc': {'id': 'exc'}
            }
        }

    # Empty function
    func = ast.parse('def fn(): return 5').body[0]
    sample = SampleVisitor()
    function = ReturnFromGeneratorTransformer().visit

# Generated at 2022-06-12 03:55:37.490503
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from ..utils import debug_ast, ast_equals_ignore_linenos
    from random import seed

    script = """
    def foo(a, b, c):
        if a > 5:
            return 2
        yield 2
        if b:
            yield 3
            if b.c:
                return False
            yield 4
            if c > 6:
                return 4
        return 5
    """
    tree_old = ast3.parse(script)
    tree_new = ast3.parse(script)
    seed(0)
    transformer = ReturnFromGeneratorTransformer()
    tree_new = transformer.visit(tree_new)

    generated_script = debug_ast(tree_new)
    print(generated_script)
    print('')
    print(script)


# Generated at 2022-06-12 03:55:44.305597
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from ..utils.source import Source
    from ..compat import to_tuple

    source = Source(dedent("""
        def fn():
            yield 1
            return 2
    """))

    node = source.tree
    ReturnFromGeneratorTransformer().visit(node)

    # Make sure return was changed to exception raise
    assert source.code == dedent("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """).strip()


# Generated at 2022-06-12 03:56:05.432266
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:13.857052
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def f():
        if False:
            yield
        else:
            yield 0
            return 1
        return 2

    def f_expected():
        if False:
            yield
        else:
            yield 0
            exc = StopIteration()
            exc.value = 1
            raise exc
        return 2

    node = ast.parse(inspect.getsource(f)).body[0]
    transformer = ReturnFromGeneratorTransformer()
    new_node = ast.fix_missing_locations(transformer.visit(node))
    expected_node = ast.parse(inspect.getsource(f_expected)).body[0]

    assert ast.dump(new_node) == ast.dump(expected_node)



# Generated at 2022-06-12 03:56:23.223133
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # input
    code = """
        def fn(a):
            yield a
            return 5
    """
    node = ast.parse(code)

    # output
    excepted_out = """
        def fn(a):
            yield a
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    # transform
    transformer = ReturnFromGeneratorTransformer()
    out = transformer.visit(node)

    # compare
    excepted_out = ast.parse(excepted_out)
    excepted_out = ast.fix_missing_locations(excepted_out)
    out = ast.fix_missing_locations(out)
    assert ast.dump(out) == ast.dump(excepted_out)



# Generated at 2022-06-12 03:56:32.068617
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MockFunctionDef(ast.FunctionDef):
        def __init__(self, body):
            self.body = body
    class MockReturn(ast.Return):
        def __init__(self, value):
            self.value = value

    node = MockFunctionDef([
        MockReturn(0),
        MockReturn(1),
        MockReturn(2),
        MockReturn(3)
    ])

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    assert node.body[0].value == 0
    assert node.body[1].value == 1
    assert node.body[2].value == 2
    assert node.body[3].value == 3
    assert node.body[4].targets[0].id == 'exc'
    assert type(node.body[5].exc) is ast

# Generated at 2022-06-12 03:56:43.999000
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from .make_function import make_function

    def check(before, expected):
        assert expected == str(ReturnFromGeneratorTransformer().visit(make_function(before)))

    check('def fn(): yield 1', 'def fn():\n    yield 1\n\n')
    check('def fn(): return 5', 'def fn():\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n\n')

    check('''def fn():
        if True:
            yield 1
        else:
            yield 1
    ''', '''def fn():\n    if True:\n        yield 1\n    else:\n        yield 1\n\n''')


# Generated at 2022-06-12 03:56:44.921660
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:50.876956
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap
    from ..utils import assert_equal_code
    tree = ast.parse(textwrap.dedent("""\
        def fn():
            yield 1
            return 5"""))

    expected = textwrap.dedent("""\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc""")

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert_equal_code(expected, tree)

# Generated at 2022-06-12 03:56:51.896642
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:57.594207
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    snippet = 'def fn():\n    yield 1\n    return 5'
    expected = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc'
    code = compile(snippet, 'file.py', 'single', flags=0, dont_inherit=True)
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-12 03:57:03.079330
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = '''
        def fn():
            yield 1
            if smth:
                return 7
    '''
    expected = '''
        def fn():
            yield 1
            if smth:
                exc = StopIteration()
                exc.value = 7
                raise exc
    '''
    node = ast.parse(source)
    transformed = ReturnFromGeneratorTransformer().visit(node)
    assert ast.unparse(transformed) == expected

# Generated at 2022-06-12 03:57:45.251257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # 1. Target function
    def fn():
        yield 1
        return 5

    # 2. Parse the target AST node
    node = ast.parse(inspect.getsource(fn))
    node = node.body[0]

    # 3. Create transformer instance
    transformer = ReturnFromGeneratorTransformer()

    # 4. Run visit code
    transformed_node = transformer.visit(node)

    # 5. Compare
    # 5.1. Source code of the target function
    source = inspect.getsource(fn)

    # 5.2. Transformed source code (return instead of yield
    transformed_source = inspect.getsource(transformed_node)

    # 5.3. Compare
    assert source != transformed_source

    # 5.4. Assemble transformed function
    ns = {}

# Generated at 2022-06-12 03:57:50.106220
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    func_def_node = ast.parse('def generator():\n\tfor x in range(5):\n\t\tyield 3').body[0]
    with pytest.raises(StopIteration):
        ReturnFromGeneratorTransformer().visit(func_def_node)


# Generated at 2022-06-12 03:57:53.740385
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    def fn():
        yield 1
        return 5

    correct_result = 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n'
    res = ReturnFromGeneratorTransformer().visit(ast.parse(fn))
    assert ast.dump(res) == correct_result

# Generated at 2022-06-12 03:57:55.426985
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""

# Generated at 2022-06-12 03:58:02.065141
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    f = r'''
        def fn():
            yield 1
            return 2
    '''

    actual = ReturnFromGeneratorTransformer().visit(ast.parse(f))

# Generated at 2022-06-12 03:58:08.376821
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
    def fn():
        yield 1
        return 2
    """)

    node = ReturnFromGeneratorTransformer().visit(node)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.FunctionDef)
    assert node.body[0].name == 'fn'
    assert isinstance(node.body[0].body[0], ast.Expr)
    assert isinstance(node.body[0].body[0].value, ast.Yield)
    assert isinstance(node.body[0].body[1], ast.Expr)
    assert isinstance(node.body[0].body[1].value, ast.Yield)
    assert node.body[0].body[1].value.value.n == 2



# Generated at 2022-06-12 03:58:16.919967
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.gen import gen_function_def, gen_return

    block1 = ast.Expr(value=gen_return())
    block2 = ast.Return(value=gen_return('value'))
    function_def1 = gen_function_def(body=[block1, block2])
    assert ast.dump(function_def1) == "FunctionDef(name='fn', body=[Expr(value=Return(value=Str(s='return'))), Return(value=Str(s='value'))], decorator_list=[], returns=None)"

    function_def2 = ReturnFromGeneratorTransformer.run(function_def1)

# Generated at 2022-06-12 03:58:26.140995
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..dsl import c, i, v
    from ..primitives import f, fn
    from ..utils import get_body

    trans = ReturnFromGeneratorTransformer()

    @f
    def a():
        yield i(1)
        return i(5)

    @f
    def b():
        yield i(1)
        return i(5)

    node = a.target
    trans.visit(node)
    assert get_body(node) == [
        c('yield 1'),
        c('exc = StopIteration()'),
        c('exc.value = 5'),
        c('raise exc')
    ]

    node = b.target
    trans.visit(node)
    assert c(node) == c(b.target)



# Generated at 2022-06-12 03:58:36.331359
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class FakeNode:
        pass

    function_def = ast.FunctionDef(name='foo', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None)
    fake_node = FakeNode()
    fake_node.body = [function_def]
    fake_node.body.append(ast.Yield(value=ast.Num(n=0)))


    return_node = ast.Return(value=ast.Num(n=0))
    fake_node.body.append(return_node)


    transformer = ReturnFromGeneratorTransformer()
    function_def_nodes = transformer.visit_FunctionDef(function_def)



# Generated at 2022-06-12 03:58:40.106914
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    print("Testing method visit_FunctionDef of class ReturnFromGeneratorTransformer")

    from ..utils.snippet import Snippet
    from ..visitors.printer import Printer

    snippet = Snippet()
    printer = Printer()
    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-12 04:00:03.359003
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_astunparse

    def generator_fn():
        x = 2
        y = 3
        yield x
        return x + y

    expected = """
        def generator_fn():
            x = 2
            y = 3
            yield x
            exc = StopIteration()
            exc.value = x + y
            raise exc
    """

    node = typed_ast.ast3.parse(inspect.getsource(generator_fn)).body[0]
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)

    assert typed_astunparse.unparse(new_node) == expected.strip()

# Generated at 2022-06-12 04:00:08.157127
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = '''
    def fn():
        yield 1
        return 5
    '''
    tree = ast.parse(source)
    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    assert ast.dump(tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 04:00:09.633076
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 04:00:10.126957
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 04:00:15.662831
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = '''
        def f1():
            yield 1
            return 5
    '''
    expected = '''
        def f1():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    expected_compiled = compile(expected, '<str>', 'exec')

    actual_compiled = ReturnFromGeneratorTransformer.run(source)
    assert expected_compiled == actual_compiled


# Generated at 2022-06-12 04:00:22.635289
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.ast_builder import build, build_ast
    from ..utils.test_utils import get_test_cases, run_test_function

    def test_method(test_case):
        node = build_ast(test_case['input'][0])
        xformer = ReturnFromGeneratorTransformer()
        result = xformer.visit(node)  # type: ignore
        assert build(result) == test_case['expected']

    run_test_function(get_test_cases('data/return_from_generator.json'), test_method)

# Generated at 2022-06-12 04:00:27.760218
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
        def fn():
            yield 1
            return 5
    """)

    expected = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    result = ReturnFromGeneratorTransformer().visit(node)

    assert ast.dump(expected) == ast.dump(result)

# Generated at 2022-06-12 04:00:36.612585
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''
    def gen():
        yield 1
        return None

    def gen_return_none():
        yield 1
        return

    def gen_nested_if():
        yield 3
        if True:
            return 4
        else:
            return 5

    def gen_nested_if_return_none():
        yield 3
        if True:
            return
        else:
            return

    def gen_nested_while():
        yield 2
        while True:
            yield 3
            return 4

    def gen_nested_while_return_none():
        yield 2
        while True:
            yield 3
            return
    '''

# Generated at 2022-06-12 04:00:38.609568
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """This unit test is based on the following code, which is a simplification of real case"""


# Generated at 2022-06-12 04:00:45.633001
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test method visit_FunctionDef of class
    `ReturnFromGeneratorTransformer`.
    """
    # Main code
    main_code = """
    import typing
    import typed_ast.ast3 as ast
    if 1:
        def fn():
            yield 1
            return 5
    """
    # Expected result
    expected_result = """
    import typing
    import typed_ast.ast3 as ast
    if 1:
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    # Perform test