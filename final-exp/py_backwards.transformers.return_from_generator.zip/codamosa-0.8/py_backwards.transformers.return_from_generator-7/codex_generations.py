

# Generated at 2022-06-12 03:50:57.216990
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..modules import transformers
    from ..utils import compare_ast
    import random
    import string

    def gen_function():
        def gen_name():
            return ''.join([random.choice(string.ascii_lowercase)
                            for _ in range(random.randint(2, 10))])

        def gen_statement() -> ast.AST:
            if random.random() < 0.5:
                return ast.Expr(value=gen_expression())
            else:
                return ast.Return(value=gen_expression())

        def gen_expression() -> ast.AST:
            if random.random() < 0.4:
                return ast.Name(id=gen_name(), ctx=ast.Load())

# Generated at 2022-06-12 03:51:04.758852
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import io
    import astor
    from typed_ast import ast3 as ast
    from ..utils import transform
    module = ast.parse('def fn(): yield 1; return [1, 2, 3]')
    transform(module, ReturnFromGeneratorTransformer)
    assert astor.to_source(module) == 'def fn(): yield 1\n    exc = StopIteration()\n    exc.value = [1, 2, 3]\n    raise exc\n'

# Generated at 2022-06-12 03:51:05.788269
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:17.864954
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import subprocess
    from ..utils.typed_ast_wrapper import ast3
    from ..utils.test_utils import get_test_data

    class ReturnFromGeneratorTransformerTest(unittest.TestCase):
        def test_simple(self):
            code = b"""
                def fn():
                    yield 1
                    return 5
            """
            tree = ast3.parse(code)
            transformer = ReturnFromGeneratorTransformer()
            new_tree = transformer.visit(tree)
            expected = b"""
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
            """
            self.assertEqual(ua(expected), ua(ast3.dump(new_tree)))


# Generated at 2022-06-12 03:51:29.783804
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_code_equal, parse_ast_tree, tree_to_str


# Generated at 2022-06-12 03:51:39.468040
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .methodDefinition import MethodDefinition
    from .generatorComprehension import GeneratorComprehensionTransformer
    input = """
    def fn(a,b,c):
        if a:
            return a
        else:
            yield 1
            return
    """
    expected1 = """
    def fn(a,b,c):
        if a:
            return a
        else:
            yield 1
            exc = StopIteration()
            exc.value = None
            raise exc
    """
    expected2 = """
    def fn(a, b, c):
        if a:
            return a
        else:
            yield 1
            raise StopIteration()
    """

# Generated at 2022-06-12 03:51:49.640921
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""def fn():
        yield 1
        return
        yield 2
        def foo():
            return 'a'
    """)
    parent = node.body[0]
    body = parent.body
    return1 = ast.Return()
    return2 = ast.Return()
    body.append(return1)
    body.append(return2)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert transformer.tree_changed == True
    assert len(body) == 5
    assert isinstance(body[3], ast.Assign)
    assert isinstance(body[4], ast.Raise)
    


# Generated at 2022-06-12 03:51:58.732248
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ts = ReturnFromGeneratorTransformer()
    ast0 = ast.parse(
        """
        def foo(x):
            if x:
                return 1
            else:
                return 2
        """
    )
    ast1 = ast.parse(
        """
        def foo(x):
            if x:
                return 1
            else:
                return 2
        """
    )
    ast2 = ast.parse(
        """
        def foo():
            yield 1
            return 2
        """
    )
    ast3 = ast.parse(
        """
        def foo(x):
            if x:
                yield 1
                return 2
            else:
                yield 1
                return 2
        """
    )
    assert ts.visit(ast0) == ast0

# Generated at 2022-06-12 03:52:07.272726
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Case:
    # def foo():
    #     yield 1
    #     return 5
    f = ast.parse('def foo():\n    yield 1\n    return 5').body[0]
    r = ReturnFromGeneratorTransformer(None, {}).visit(f)
    assert isinstance(r, ast.FunctionDef)

# Generated at 2022-06-12 03:52:18.793478
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    test_ast = ast.parse(
        """
        def generator(a):
            def nested(b):
                if True:
                    for i in range(a):
                        yield i
                    return i
                else:
                    return a
                return b
            yield nested(a)
            return nested(a)
            return a
            return nested(a)
            return 1
        """
    )

# Generated at 2022-06-12 03:52:30.984415
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    with open(__file__[:-3] + "_cases/return_from_generator.py") as f:
        cases = ast.parse(f.read())

    for test_case in cases.body:
        with ReturnFromGeneratorTransformer() as t:
            fn = t.visit(test_case)

        assert fn.body

        expected_result = test_case.body[1].value.n
        assert [x.value.value.n for x in fn.body] == list(range(expected_result))

# Generated at 2022-06-12 03:52:31.416404
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:41.926550
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ...context import Context
    from ...visitor import NodeSetTransformer

    class TestTransformer(NodeSetTransformer):
        def test(self, node):
            return node.value == '5'

    context = Context()
    context['test'] = TestTransformer()  # type: ignore

    tree = ast.parse('''
    def fn():
        yield 10
        return 5
    ''')
    transformed = ReturnFromGeneratorTransformer.visit(context, tree)

# Generated at 2022-06-12 03:52:51.566309
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.FunctionDef(name='test', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[]), body=[ast.Expr(value=ast.Yield(value=ast.Num(n=1))), ast.Return(value=ast.Num(n=5))], decorator_list=[], returns=None)

# Generated at 2022-06-12 03:52:58.418441
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast, ast_to_source

    original = """
    def fn():
        yield 1
        print(5)
        return 5
    """
    expected = """
    def fn():
        yield 1
        print(5)
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = source_to_ast(original)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    result = ast_to_source(tree)
    assert result == expected

# Generated at 2022-06-12 03:53:08.795304
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test for method visit_FunctionDef of class ReturnFromGeneratorTransformer"""
    from typed_ast import ast3 as ast
    from ..utils.compat import unicode
    from ..utils.fake import Fake
    from .base import BaseNodeTransformer

    source = """def fn():
    yield 1
    return 5"""

    expected = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""

    assert unicode(ReturnFromGeneratorTransformer().visit(ast.parse(source))) == expected


__all__ = ['ReturnFromGeneratorTransformer', 'return_from_generator']

# Generated at 2022-06-12 03:53:17.901048
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""
    def f():
        yield 4
        if True:
            return 5
        return 10
    """)  # type: ast.Module
    expected = ast.parse("""
    def f():
        yield 4
        if True:
            exc = StopIteration()
            exc.value = 5
            raise exc
        if True:
            exc = StopIteration()
            exc.value = 10
            raise exc
    """)  # type: ast.Module

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-12 03:53:18.409845
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass



# Generated at 2022-06-12 03:53:24.506033
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
    def f():
        yield 1
        return 2
    """)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    expected = """
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    assert transformer.dump_tree(node) == expected

# Generated at 2022-06-12 03:53:31.066984
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .fixtures import generator_with_return_source_tree, generator_with_return_fixed_tree
    source_tree = generator_with_return_source_tree()
    expected_tree = generator_with_return_fixed_tree()
    transformer = ReturnFromGeneratorTransformer()
    actual_tree = transformer.visit(source_tree)
    assert ast.dump(actual_tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 03:53:48.408968
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import FunctionDef, Return, Name, Num, arguments
    from typed_ast.ast3 import arg, Load, Yield

    def test(fn: FunctionDef) -> FunctionDef:
        node = ReturnFromGeneratorTransformer().visit(fn)  # type: ignore
        return node

    def check(node: FunctionDef, expected: FunctionDef) -> None:
        assert node == expected  # Check identity

        assert isinstance(node, ast.FunctionDef)
        assert node.name == expected.name
        assert len(node.args.args) == len(expected.args.args)
        assert [x.arg for x in node.args.args] == [x.arg for x in expected.args.args]
        assert isinstance(node.args.vararg, type(expected.args.vararg))
       

# Generated at 2022-06-12 03:53:59.997714
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.fixtures import function_def

    _code_before = function_def(
        name='generator',
        body=[ast.Yield(value=ast.Num(n=1)),
              ast.Return(value=ast.Num(n=5))])


# Generated at 2022-06-12 03:54:11.525335
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from asttokens import ASTTokens
    from ..utils.test_utils import nodes_equal

    def get_expected(code: str) -> ast.AST:
        return ast.parse(code)

    transformer = ReturnFromGeneratorTransformer()

    def test(code: str) -> None:
        node = ast.parse(code)
        tokens = ASTTokens(code, parse=True)
        transformer.visit(node)
        expected = get_expected(code)
        nodes_equal(node, expected, tokens)

    code = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    test(code)



# Generated at 2022-06-12 03:54:12.096612
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:23.903903
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.visitor import dump_ast
    from .cleanup_tuples import CleanupTuples
    node = ast.parse("""
    def fn():
        yield 1
        return 4
    """)
    ReturnFromGeneratorTransformer().visit(node)
    CleanupTuples().visit(node)

# Generated at 2022-06-12 03:54:32.124462
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module_node = ast.parse('def fn():\n    yield 1\n    return 5', '', 'exec')
    transformer = ReturnFromGeneratorTransformer()

    assert transformer.visit(module_node) == module_node
    assert transformer._tree_changed is True
    assert module_node == ast.parse(
        'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc',
        '',
        'exec'
    )

# Generated at 2022-06-12 03:54:33.579193
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:46.026922
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from typed_python import Function, ListOf
    from typed_python.compiler.typed_expression import Bottom as TypedExpressionBottom
    from typed_python.compiler.type_wrappers.compiler_ir import CompilerIRFunction
    from typed_python.compiler.conversion_level import ConversionLevel
    from typed_python.compiler.type_wrappers.two_way_dict import TwoWayDict
    from typed_python import compile_function
    from typed_python import NoneType, OneOf
    from typed_python.compiler.native_ast import INT64


# Generated at 2022-06-12 03:54:55.264856
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..adapters import ast
    from ..utils.testing import make_dummy_fn
    from ..utils.testing import get_node_types

    fn = make_dummy_fn('a = yield 1\nreturn 2\n')
    test_fn = ast.parse(fn)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit_FunctionDef(test_fn.body[0])  # type: ignore

# Generated at 2022-06-12 03:55:03.965459
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Function with return statement and a generator
    def fn_with_return_generator():
        return 5
        yield 1

    # Function without return statement and a generator
    def fn_no_return_generator():
        yield 1

    # Test transformations
    def test_transform(fn, compare_with):
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(fn)
        assert transformer.get_source() == compare_with

    # Test cases
    test_transform(fn_with_return_generator, 'def fn_with_return_generator():\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n    yield 1')
    test_transform(fn_no_return_generator, 'def fn_no_return_generator():\n    yield 1')

# Generated at 2022-06-12 03:55:19.055312
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:23.406427
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # function has got no returns
    node = ast.parse("""
    def fn():
        pass
    """)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    assert result.body[0] == node.body[0]

    # function has got return and is not generator
    node = ast.parse("""
    def fn():
        return 5
    """)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    assert result.body[0] == node.body[0]

    # function is generator but has got no return
    node = ast.parse("""
    def fn():
        yield 5
    """)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)

# Generated at 2022-06-12 03:55:31.766061
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    def _transform(node):
        transformer = ReturnFromGeneratorTransformer()
        return transformer.visit(node)

    @snippet
    def return_from_generator(return_value):
        let(exc)
        exc = StopIteration()
        exc.value = return_value
        raise exc

    def test_no_yield():
        def fn():
            return 5

        transformer_fn = _transform(fn)
        fn_body = transformer_fn.body
        assert len(fn_body) == 1

    def test_no_return():
        def fn():
            yield 1

        transformer_fn = _transform(fn)
        fn_body = transformer_fn.body

# Generated at 2022-06-12 03:55:43.062347
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..transformers.base import BaseNodeTransformer
    # TODO: fix iteration node.body of type ignore
    from ..utils.method_dispatch import method_dispatch
    from ..utils.visitor import BaseNodeVisitor
    from .base import NodeTransformer

# Generated at 2022-06-12 03:55:45.123000
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    maxDiff = None

    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:55:46.354438
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:57.040697
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
  # Creating AST of FunctionDef
  node = ast.parse('def fn():\n    yield 1\n    return 5')
  node = node.body[0]
  # Creating instance of ReturnFromGeneratorTransformer
  transformer = ReturnFromGeneratorTransformer()
  # Calling method visit_FunctionDef
  result = transformer.visit_FunctionDef(node)
  # Verifying the results
  assert result.body[1].value.value == 'StopIteration'
  assert result.body[2].target == 'exc'
  assert result.body[2].value.value == 'StopIteration'
  assert result.body[3].value.args[0].value == 'exc'
  assert result.body[4].value.value == 'exc'
  assert result.body[5].value.func.value == 'exc'

# Generated at 2022-06-12 03:55:59.720063
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """\
    def fn():
        yield 1
        return 5
    """

    expected = """\
    def fn() -> None:
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = parse(source)
    result = ReturnFromGeneratorTransformer().visit(node)
    print(expected)
    print(unparse(result))
    assert unparse(result) == expected

# Generated at 2022-06-12 03:56:07.786768
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''
        def f():
            yield 1
            return x
            return y
        def g():
            yield 2
            return x
            yield 3
            return y
    '''
    expected_code = '''
        def f():
            yield 1
            exc = StopIteration()
            exc.value = x
            raise exc

        def g():
            yield 2
            exc = StopIteration()
            exc.value = x
            raise exc
            yield 3
            exc = StopIteration()
            exc.value = y
            raise exc
    '''
    result = ReturnFromGeneratorTransformer().visit(ast.parse(code))

    assert result is not None
    assert ast.dump(result) == ast.dump(ast.parse(expected_code))


# Generated at 2022-06-12 03:56:16.519817
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = '''
        def gen():
            yield 1
            yield 2
            return 5
        
        def not_gen():
            yield 1
            return 5
    '''

    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)

    result = ast.dump(tree)

# Generated at 2022-06-12 03:56:54.738874
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..t import FunctionDef, Return, Yield, YieldFrom
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import GenericTransformer
    from ..utils import cached_property
    from ..utils.deprecation import deprecated
    from ..utils.node import get_docstring
    from ..utils.snippet import snippet
    from ..utils.helpers import is_valid_ast_node
    from ..utils.typing import get_args
    from ..utils.typing import get_origin
    from ..utils.typing import get_origin_alias
    from ..utils.typing import get_origin_name
    from ..utils.typing import get_parameters
    from ..utils.typing import get_returns
    from ..utils.typing import get_type_hints
   

# Generated at 2022-06-12 03:56:55.618995
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:58.214608
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .return_from_generator import ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:57:06.455412
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class_ = ReturnFromGeneratorTransformer

    # Case: no return statements.
    def_ = let(def_)
    def_ = ast.parse('''
        def fn():
            yield 1
    ''').body[0]
    call = lambda: class_().visit_FunctionDef(def_)
    assert call() == def_

    # Case: return in generator.
    def_ = let(def_)
    def_ = ast.parse('''
        def fn():
            yield 1
            return 5
    ''').body[0]
    expected_body = ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    ''').body[0].body
    call = lambda: class_().visit_Function

# Generated at 2022-06-12 03:57:15.747983
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import get_function_def
    from copy import copy

    ast_tree = get_function_def(is_generator=True)
    expected = copy(ast_tree)
    ReturnFromGeneratorTransformer().visit(ast_tree)
    assert ast_tree == expected

    ast_tree = get_function_def(is_generator=True, return_value=True)
    ReturnFromGeneratorTransformer().visit(ast_tree)

    expected = get_function_def(is_generator=True, return_value=True, is_modifed=True)
    assert ast_tree == expected

    ast_tree = get_function_def(is_generator=True, return_value=True, has_yield=False)
    ReturnFromGeneratorTransformer().visit(ast_tree)

# Generated at 2022-06-12 03:57:22.703991
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # def fn():
    #     yield 1
    #     return 5
    node = ast.FunctionDef(
        name='fn',
        args=ast.arguments(
            args=[],
            kwonlyargs=[],
            vararg=None,
            kwarg=None,
            defaults=[],
            kw_defaults=[]
        ),
        body=[
            ast.Expr(
                value=ast.Yield(value=ast.Num(n=1))
            ),
            ast.Return(value=ast.Num(n=5))
        ],
        decorator_list=[],
        returns=None
    )

# Generated at 2022-06-12 03:57:30.083974
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import Tester
    from ..utils.typed_ast import ast3

    tester = Tester()
    input_ = tester.load_example('return_from_generator.py')
    output = tester.load_example('return_from_generator.py.out')
    node = ast3.parse(input_)
    ReturnFromGeneratorTransformer().visit(node)
    assert [x.strip() for x in ast3.dump(node).split('\n')] == \
           [x.strip() for x in output.split('\n')]

# Generated at 2022-06-12 03:57:31.048703
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..run import run


# Generated at 2022-06-12 03:57:36.128952
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from .transformers import ReturnFromGeneratorTransformer, SimplePromoteLiteralsTransformer
    from .utils import BaseNodeTransformerTestCase
    from ..utils.testing import evaluate_transformer_on_file


# Generated at 2022-06-12 03:57:37.688431
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import AutoNumberTransformer


# Generated at 2022-06-12 04:00:23.250418
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base import compile_to_ast
    from .test_base import compile_transformer_test

    def test_function():
        def regular_return():
            return 42

        def no_yield():
            return 42
            yield

        def simple_yield_return():
            yield 101
            return 102

        def nested_yield_return():
            if True:
                yield 103
                return 104

            yield
            yield 105
            return 106

        def nested_no_yield_return():
            if True:
                return 107
                yield

            yield
            yield 108
            return 109

        def nested_yield_no_return():
            if True:
                yield 110
                yield 111

            yield
            yield 112
            yield 113


# Generated at 2022-06-12 04:00:28.848806
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test method visit_FunctionDef of class ReturnFromGeneratorTransformer"""
    expect = "def fn():\n yield 1\n exc = StopIteration()\n exc.value = 5\n raise exc"
    actual = str(ReturnFromGeneratorTransformer().visit(ast.parse("def fn(): yield 1; return 5")))
    assert expect == actual
# Test the method visit_FunctionDef of the class ReturnFromGeneratorTransformer



# Generated at 2022-06-12 04:00:38.111987
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 04:00:45.269472
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MockNode(ast.AST):
        """Fake AST node that can be used as a child of ast.FunctionDef"""
        _fields = ('body',)

    class ReturnMock(ast.Return):
        """Fake return statement."""
        pass

    class YieldMock(ast.Yield):
        """Fake yield statement."""
        pass

    class YieldFromMock(ast.YieldFrom):
        """Fake yield statement."""
        pass

    def _init_tree(returns, yields):
        """Create a tree of nodes to be used for testing."""