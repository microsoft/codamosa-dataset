

# Generated at 2022-06-12 03:50:51.009768
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from pprint import pprint

# Generated at 2022-06-12 03:50:53.725922
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def check(test_input, expected):
        actual = get_ast(test_input)
        ReturnFromGeneratorTransformer().visit(actual)
        assert ast.dump(actual) == expected
    # Test case 1

# Generated at 2022-06-12 03:50:59.995256
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """ Unit test for method visit_FunctionDef of class
        ReturnFromGeneratorTransformer
    """
    # Arrange
    function_str = """
        def demo1(a, b, *args, c, d=0, **kwargs):
            yield 1
            return a
    """
    expected_function_str = """
        def demo1(a, b, *args, c, d=0, **kwargs):
            yield 1
            exc = StopIteration()
            exc.value = a
            raise exc
    """
    expected_code_snippet = """\
        def demo1(a, b, *args, c, d=0, **kwargs):
            yield 1
            exc = StopIteration()
            exc.value = a
            raise exc
    """
    # Act
    result = ReturnFromGener

# Generated at 2022-06-12 03:51:10.109865
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    src = """
    def fn():
        yield 'From generator'
        return 5
    """
    expected = """
    def fn():
        yield 'From generator'
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    actual = ReturnFromGeneratorTransformer().visit_module(ast.parse(src))
    expected = ast.parse(expected)

    assert ast.dump(actual, include_attributes=False) == ast.dump(expected, include_attributes=False)



# Generated at 2022-06-12 03:51:12.246016
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typing as t
    import astor  # type: ignore


# Generated at 2022-06-12 03:51:23.952225
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap
    from typing import Generator

    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse

    snippet = textwrap.dedent("""\
        def fn():
            yield 1
            return 5
    """)
    expected = textwrap.dedent("""\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    module = parse(snippet)
    transformer = ReturnFromGeneratorTransformer()
    new_module = transformer.visit(module)
    fn = new_module.body[0]
    assert transformer.tree_changed()
    assert isinstance(fn, ast.FunctionDef)
    assert str(fn) == expected



# Generated at 2022-06-12 03:51:35.312844
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def assert_code(before, after=None):
        node = ast.parse(before)
        after = ast.parse(after or before)
        ReturnFromGeneratorTransformer.run_annotations(node)
        assert ast.dump(node) == ast.dump(after)

    assert_code("""
    def fn():
        pass
    """)

    assert_code("""
    def fn():
        pass
    """)

    assert_code("""
    def fn():
        return 5
    """)

    assert_code("""
    def fn():
        return (yield 5)
    """)


# Generated at 2022-06-12 03:51:40.183041
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Setup
    node = ast.parse("""\
    def foo():
        return 5
    """)
    # Exercise
    transformer = ReturnFromGeneratorTransformer()
    transformed_node = transformer.visit(node)
    # Verify
    assert transformer._tree_changed == False
    assert compare(transformed_node, node) == True

    # Setup
    node = ast.parse("""\
    def foo():
        if False:
            return 5
        return 6
    """)
    # Exercise
    transformer = ReturnFromGeneratorTransformer()
    transformed_node = transformer.visit(node)
    # Verify
    assert transformer._tree_changed == False
    assert compare(transformed_node, node) == True

    # Setup

# Generated at 2022-06-12 03:51:49.088283
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import transform, compare

    @snippet
    def before():
        def fn(arg1, arg2=1, *args, **kwargs):
            yield arg1 if arg2 else arg2
            if arg1:
                return 5

    @snippet
    def after():
        def fn(arg1, arg2=1, *args, **kwargs):
            yield arg1 if arg2 else arg2
            exc = StopIteration()
            exc.value = 5
            raise exc

    assert compare(transform(ReturnFromGeneratorTransformer, before), after)

# Generated at 2022-06-12 03:51:58.451153
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    def gen1():
        yield 1
        yield 2
        yield 3
        return 10

    def gen2():
        yield 2
        return 2
        yield 4

    def gen3():
        yield 4
        if 4:
            yield 5
        yield 5

    def gen4():
        yield 1
        if 4:
            yield 5
        return 5
        yield 4

    def gen5():
        while 1:
            yield 1
        return 2

    def gen6():
        try:
            yield 1
        finally:
            return 10

    def gen7():
        yield 1
        def gen7_1():
            yield 1
            return 2
        for x in gen7_1():
            yield x

    def gen8():
        yield 1

# Generated at 2022-06-12 03:52:09.368568
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # case 1:
    #   input:
    #       def fn():
    #           return 1
    #   output:
    #       def fn():
    #           return 1
    n1 = ast.Return(value=ast.Num(n=1))
    n2 = ast.FunctionDef(name='fn', args=ast.arguments(), body=[n1])
    node1 = ReturnFromGeneratorTransformer().visit(n2)
    assert len(node1.body) == 1
    assert isinstance(node1.body[0], ast.Return)

    # case 2:
    #   input:
    #       def fn():
    #           yield 1
    #           return 2
    #   output:
    #       def fn():
    #           yield 1
    #           exc = StopIteration()
    #          

# Generated at 2022-06-12 03:52:11.744833
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Named expression are unit tested for Python 3.8 using astparam.
    Executed in test_base.py"""
    pass

# Generated at 2022-06-12 03:52:24.558260
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
        def fn():
            yield 1

            if True:
                return 2
            else:
                return 3

            return 4
        """).body[0]

    rfg_transformer = ReturnFromGeneratorTransformer()
    rfg_transformer.visit(node)
    module = ast.Module(body=[node])


# Generated at 2022-06-12 03:52:35.779483
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import compile_snippet, parse
    from .functiondef import FunctionDefTransformer
    from .yieldfrom import YieldFromTransformer
    from .yield2generator import Yield2GeneratorTransformer

    from ..utils.source import Source
    from ..utils.pytree import PyTreeVisitor, PyTreeTransformer, extract_node

    # Set of nodes we want to test visit_FunctionDef

# Generated at 2022-06-12 03:52:45.973432
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def check(before, after):
        transformer = ReturnFromGeneratorTransformer()
        node = ast.parse(before)
        transformer.visit(node)
        assert before != after
        assert ast.dump(node) == ast.dump(ast.parse(after))

    check('def fn(): yield 1; return 5',
          'def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc')
    check('def fn(): return 5', 'def fn(): return 5')
    check('def fn(): yield "y"; return 5',
          'def fn(): yield "y"; exc = StopIteration(); exc.value = 5; raise exc')
    check('def fn(a): yield a; return 5',
          'def fn(a): yield a; exc = StopIteration(); exc.value = 5; raise exc')


# Generated at 2022-06-12 03:52:50.167412
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    check_node_transformed(
        ReturnFromGeneratorTransformer,
        '''
        def fn():
            yield 1
            return 5
        ''',
        '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    )


# Generated at 2022-06-12 03:52:51.410371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse


# Generated at 2022-06-12 03:52:52.231580
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:53.140937
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:58.305502
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(func):
        tree = ast.parse(inspect.getsource(func))
        t = ReturnFromGeneratorTransformer()
        t.visit(tree)
        exec(compile(tree, '<string>', 'exec'), globals())
        return func == t_fn
    return test



# Generated at 2022-06-12 03:53:18.113472
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a = ast.parse("""
        def foo():
            yield 10
            return 30
    """)
    a = ReturnFromGeneratorTransformer().visit(a)

# Generated at 2022-06-12 03:53:18.963845
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:27.440929
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    from ..testing import run_local_tests

    code = dedent('''
        def main():
            yield
            return 1
    ''')

    expected = dedent('''
        def main():
            yield
            exc = StopIteration()
            exc.value = 1
            raise exc
    ''')

    module = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(module)
    assert expected == module_code(module)

    run_local_tests()



# Generated at 2022-06-12 03:53:28.417317
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:34.652000
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn(x):
        yield 1
        return 5 if x > 0 else 0

    fn_ast = ast.parse(fn.__code__)
    ReturnFromGeneratorTransformer().visit(fn_ast)
    exec(compile(fn_ast, '', 'exec'), globals())
    assert fn(1) == 1
    assert next(fn(1)) == 5
    assert fn(0) == 0
    assert next(fn(0)) is None

# Generated at 2022-06-12 03:53:46.288255
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..base import BaseNodeTransformer
    tree = ast.parse("""def fn():
        x = 1
        yield x
        return x
    """)
    trans = BaseNodeTransformer(target=(3, 2))
    trans.visit(tree)

# Generated at 2022-06-12 03:53:48.902755
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import get_node


# Generated at 2022-06-12 03:53:56.255732
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Tests for method visit_FunctionDef of ReturnFromGeneratorTransformer transformer"""
    import asttokens
    from asttokens import ASTTokens

    transformer = ReturnFromGeneratorTransformer()

    def assert_nodes(code, expected_code):
        atok = ASTTokens(code, parse=True, parse_comments=True)
        transformer.visit(atok.tree)
        assert atok.get_text() == expected_code


# Generated at 2022-06-12 03:54:05.617236
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor  # type: ignore
    import python_minifier  # type: ignore
    import textwrap

    node = ast.parse(textwrap.dedent("""
        def some(a):
            yield 1
            return 5
        """))
    python_minifier.add_transformer(ReturnFromGeneratorTransformer)
    for _ in range(2):
        node = python_minifier.minify_ast(node)

    assert astor.to_source(node) == textwrap.dedent("""
        def some(a):
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """)

# Generated at 2022-06-12 03:54:15.478276
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse
    from ..pythran import PythranAnalysis
    import idaplugin.plugin as plg

    py_code = """
    def foo():
        def bar():
            yield 1
            yield 2
            return 3
    """
    ref_code = """
    def foo():
        def bar():
            yield 1
            yield 2
            exc = StopIteration()
            exc.value = 3
            raise exc
    """

    ida = plg.create_service("ida")  # type: ignore
    idc = ida.get_proxy().idc  # type: ignore

    node = parse(py_code)
    transformed = ReturnFromGeneratorTransformer().visit(node)

    ref_node = parse(ref_code)

    assert PythranAnalysis.equal(transformed, ref_node)

# Generated at 2022-06-12 03:54:43.426928
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.transforms import try_to_name

    class TestTransformer(BaseNodeTransformer):
        def visit_Yield(self, node):
            self._tree_changed = True
            return ast.Name(id="x")

    node = ast.parse("def fn():\n    yield 3\n    return 5")
    tr = TestTransformer()
    tr.visit(node)

    tr = ReturnFromGeneratorTransformer()
    tr.visit(node)

    tr = try_to_name.TryToNameTransformer()
    tr.visit(node)


# Generated at 2022-06-12 03:54:53.625905
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    import unittest
    from nuitka.nodes.VariableRefNodes import ExpressionTargetTempVariableRef
    from nuitka.nodes.AssignmentNodes import ExpressionTargetAssignment
    from nuitka.nodes.BuiltinIteratorNodes import ExpressionBuiltinStopIteration
    from nuitka.nodes.RaiseNodes import ExpressionRaiseException
    from nuitka.nodes.AttributeNodes import ExpressionAttributeLookup
    from nuitka.nodes.AssignNodes import StatementAssignmentVariable
    from nuitka.nodes.ComparisonNodes import ExpressionComparisonIs
    from nuitka.nodes.BuiltinRefNodes import ExpressionBuiltinRef
    from nuitka.nodes.ConstantRefNodes import ExpressionConstantRef

# Generated at 2022-06-12 03:54:56.208185
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.unparse import Unparse
    from ..utils.ast_factory import ast_call, ast_list, ast_none, ast_num, ast_raise, ast_return, ast_yield


# Generated at 2022-06-12 03:55:00.824095
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
    def fn(x):
        yield from x
        return 5
    """).body[0]

    assert ReturnFromGeneratorTransformer().visit(node) == ast.parse("""
    def fn(x):
        yield from x
        exc = StopIteration()
        exc.value = 5
        raise exc
    """).body[0]


# Generated at 2022-06-12 03:55:10.200741
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestVisitor(ast.NodeVisitor):
        """Helper for test."""
        def __init__(self):
            self.look_for = None
            self.parent = None

        def visit_FunctionDef(self, node):
            if node.name == self.look_for:
                self.parent = node

    def get_hasattr_value(parent, name):
        """Helper for test."""
        for item in parent:
            if isinstance(item, ast.Expr) and isinstance(item.value, ast.Name) and item.value.id == name:
                if isinstance(item.value, ast.Attribute):
                    return item.value
        return None

    def check(src, expected_is_changed, expected_returns_count):
        """Helper for test."""
        tree = ast.parse

# Generated at 2022-06-12 03:55:21.067760
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # test transform
    from .fake_ast import fake_ast
    from .fake_typed_ast import fake_typed_ast

    # before transform
    ast_node = fake_ast.function_def_gen_with_return()
    typed_ast_node = fake_typed_ast.function_def_gen_with_return()

    transformer = ReturnFromGeneratorTransformer()
    new_typed_ast = transformer.visit(typed_ast_node)

    assert new_typed_ast != typed_ast_node
    assert not transformer.fail()

    # after transform
    transformer = ReturnFromGeneratorTransformer()
    new_typed_ast = transformer.visit(new_typed_ast)

    assert new_typed_ast == typed_ast_node
    assert not transformer.fail()

   

# Generated at 2022-06-12 03:55:30.497910
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typing import List
    from typed_ast import ast3 as ast

    import pytest
    from .test_transformer import transformer_test_on_node


# Generated at 2022-06-12 03:55:41.967598
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit_FunctionDef(ast.parse('def fn():\n\tdef fn2():\n\t\tyield 1\n\t\treturn 5\n').body[0]) == ast.parse('def fn():\n\tdef fn2():\n\t\tyield 1\n\t\texc = StopIteration()\n\t\texc.value = 5\n\t\traise exc').body[0]
    assert transformer.visit_FunctionDef(ast.parse('def fn():\n\tdef fn2():\n\t\tyield 2\n').body[0]) == ast.parse('def fn():\n\tdef fn2():\n\t\tyield 2').body[0]
    assert transformer.visit_FunctionDef

# Generated at 2022-06-12 03:55:52.201393
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    '''
    Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    '''
    from typed_ast import ast3 as ast
    from ..utils.node_test import assert_node
    import typing
    if typing.TYPE_CHECKING:
        from ..utils.typed_formatter import TypedFormatter
    else:
        from ..utils.untyped_formatter import UntypedFormatter
    from ..utils.snippet import snippet, let

    def test(node: ast.FunctionDef):
        '''
        This method tests if ReturnFromGeneratorTransformer.visit_FunctionDef
        breaks the original code.
        '''
        from .return_from_generator import ReturnFromGeneratorTransformer
        transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:55:57.466339
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn(n):
        if n == 1:
            return n
        elif n == 10:
            yield n
            return n
        else:
            if n <= 20:
                yield n
            else:
                return n
            yield n + 20
            return n + 20
    wanted = """def fn(n):
    if n == 1:
        return n
    elif n == 10:
        yield n
        exc = StopIteration()
        exc.value = n
        raise exc
    else:
        if n <= 20:
            yield n
        else:
            return n
        # return n + 20  # already replaced
        yield n + 20
        exc = StopIteration()
        exc.value = n + 20
        raise exc"""


# Generated at 2022-06-12 03:56:39.769720
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target = (3, 2)
        transformer = ReturnFromGeneratorTransformer
        code_before = """
            def fn(a):
                yield a
                return 5
        """

        code_after = """
            def fn(a):
                yield a
                exc = StopIteration()
                exc.value = 5
                raise exc
        """

    Test.run_test()

# Generated at 2022-06-12 03:56:42.309687
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typing
    import typed_astunparse
    from ..unparser import Unparser
    # Test with return in generator

# Generated at 2022-06-12 03:56:50.170258
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import cStringIO
    import typed_astunparse
    import textwrap

    string = textwrap.dedent('''\
        def fn():
            yield 1
            return 5
        ''')

    node = typed_astunparse.parse(string)

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    result = typed_astunparse.unparse(result)

    assert result == textwrap.dedent('''\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''')



# Generated at 2022-06-12 03:56:59.217977
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import make_parse

    from .node_transformer_test import assert_transform_equal

    ast_ = make_parse(
        """
    def fn():
        yield 1
        return (fn2() + output) or None
        yield 2

    def fn2():
        print(123)

    def fn3():
        yield 1
        yield 2
        return
    """)

    expected_ast_ = make_parse(
        """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = (fn2() + output) or None
        raise exc
        yield 2

    def fn2():
        print(123)

    def fn3():
        yield 1
        yield 2
        return
    """
    )

    transformer = ReturnFromGeneratorTransformer()
    assert_transform

# Generated at 2022-06-12 03:57:01.796201
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.refactoring import refactor
    from ..utils.compiler import compile_code


# Generated at 2022-06-12 03:57:08.833635
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.tester import AbstractNodeTransformerTest

    class Test(AbstractNodeTransformerTest):
        node_transformer_class = ReturnFromGeneratorTransformer

        def test_replace_generator_return_with_exception(self):
            code = """
                def fn():
                    yield 1
                    return 5
            """
            expected_code = """
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
            """
            self.compare(code, expected_code)

        def test_not_change_return_when_no_yield(self):
            code = """
                def fn():
                    return 5
            """
            self.compare(code, code)


# Generated at 2022-06-12 03:57:18.231704
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.compat import upper_bound
    from ..utils.testing import assert_equal_source

    source = """
        def fn():
            yield 1
            return 5
    """

    result = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    assert_equal_source(ReturnFromGeneratorTransformer, source, result)

    source = """
        def fn():
            a = (yield 1)
            return 5
    """

    result = """
        def fn():
            a = (yield 1)
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    assert_equal_source(ReturnFromGeneratorTransformer, source, result)


# Generated at 2022-06-12 03:57:25.922256
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    @snippet
    def old_fn():
        yield 1
        return 5

    @snippet
    def new_fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    returntrans = ReturnFromGeneratorTransformer().visit(ast.parse(old_fn.getsnippet()))
    new_fn_ast = ast.parse(new_fn.getsnippet())

    assert ast.dump(returntrans, include_attributes=False) == ast.dump(new_fn_ast, include_attributes=False)

if __name__ == '__main__':
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-12 03:57:34.917597
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    exp_str = '\n'.join([
        'def fn():',
        '    yield 1',
        '    exc = StopIteration()',
        '    exc.value = 5',
        '    raise exc'
    ])
    exp_ast = ast.parse(exp_str)
    fn_str = '\n'.join([
        'def fn():',
        '    yield 1',
        '    return 5'
    ])
    fn = ast.parse(fn_str, 'fn.py', 'exec').body[0]
    act = ReturnFromGeneratorTransformer(fn).visit(fn)
    assert ast.dump(act) == ast.dump(exp_ast), 'ASTs should be equal!'



# Generated at 2022-06-12 03:57:41.285352
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = '''
    def fn():
        yield 1
        return 5
    '''
    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast.parse(source))
    assert ast.dump(ast.parse(expected)) == ast.dump(ast.parse(transformer.get_source()))


# Generated at 2022-06-12 04:00:14.929183
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 04:00:23.823597
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer().visit_FunctionDef(ast.parse("""
        def foo():
            yield 1
            return 5
    """).body[0]) == ast.parse("""
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """).body[0]
    assert ReturnFromGeneratorTransformer().visit_FunctionDef(ast.parse("""
        def foo():
            yield 1
            for i in range(10):
                yield i
            return 5
    """).body[0]) == ast.parse("""
        def foo():
            yield 1
            for i in range(10):
                yield i
            exc = StopIteration()
            exc.value = 5
            raise exc
    """).body[0]
    assert ReturnFromGener

# Generated at 2022-06-12 04:00:33.677998
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test for the function (method) visit_FunctionDef in class
    ReturnFromGeneratorTransformer.
    """
    import astor
    from .unparse import UnparsingTransformer

    # prepare node
    node = ast.parse(
        """
        def fn():
            yield 1
            return 5
        """
    )
    # prepare expected node
    expected_node = ast.parse(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    # initialize transformer
    transformer = ReturnFromGeneratorTransformer()
    # run method visit_FunctionDef in transformer
    node = transformer.visit_FunctionDef(node.body[0])
    # initialize unparser
    unparser = UnparsingTransformer()
    #

# Generated at 2022-06-12 04:00:37.930254
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse('''
    def fn(x):
        if x == 1:
            yield 1
        elif x == 2:
            yield 2
        elif x == 3:
            return 3
        else:
            yield 4
    ''')

    # Check if tree is not changed if there are no returns in generator
    new_tree = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(new_tree)

    # Check if tree is not changed if returns is not in generator
    tree = ast.parse('''
    def fn(x):
        if x == 3:
            return 3
        elif x == 2:
            yield 2
        elif x == 1:
            yield 1
        else:
            yield 4
    ''')

    new

# Generated at 2022-06-12 04:00:41.340579
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_source

    def check(src, expected):
        tree = ast.parse(src)
        transformer = ReturnFromGeneratorTransformer()
        new_tree = transformer.visit(tree)
        assert_source(new_tree, expected)


# Generated at 2022-06-12 04:00:43.882418
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.transform_test_helper import get_test_case
    from ..utils.transform_test_helper import run_test_cases


# Generated at 2022-06-12 04:00:47.850775
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..tests.utils import assert_equal_ast
    assert_equal_ast(
        ReturnFromGeneratorTransformer().visit(
            ast.parse('def fn():\n'
                      '    yield 1\n'
                      '    return 5')
        ),
        ast.parse('def fn():\n'
                  '    yield 1\n'
                  '    exc = StopIteration()\n'
                  '    exc.value = 5\n'
                  '    raise exc')
    )