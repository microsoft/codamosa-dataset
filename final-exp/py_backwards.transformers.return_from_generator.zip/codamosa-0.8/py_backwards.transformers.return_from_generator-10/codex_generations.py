

# Generated at 2022-06-12 03:51:00.043882
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        def create_transformer(self):
            return ReturnFromGeneratorTransformer

        def generate_test_cases(self):
            cases = []
            for version in self.get_tested_versions():
                cases.append(self.generate_ast_test_case(
                    'def foo(): yield bar ; return 0',
                    'def foo(): yield bar ; exc = StopIteration(); exc.value = 0 ; raise exc'
                ))

# Generated at 2022-06-12 03:51:08.737651
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        for i in range(5):
            yield i
        return 'yay'

    fn = ReturnFromGeneratorTransformer().visit(fn)
    assert fn.__code__.co_flags & inspect.CO_GENERATOR is 0
    assert fn().__next__() == 0
    assert fn().__next__() == 1
    assert fn().__next__() == 2
    assert fn().__next__() == 3
    assert fn().__next__() == 4
    assert fn().__next__() == 'yay'
    with pytest.raises(StopIteration):
        fn().__next__()

# Generated at 2022-06-12 03:51:18.819410
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    t = ReturnFromGeneratorTransformer()

    def fn():
        yield 1
        return 2

    def fn2():
        yield from [1, 2, 3]
        return 2

    def fn3():
        yield
        yield 1
        return 2

    def fn4():
        return 2

    for f in [fn, fn2, fn3]:
        result = ast.parse(f.__code__)
        t.visit(result)
        assert result.body[0].body[-1].value.elts[0].value == 2

    result = ast.parse(fn4.__code__)
    t.visit(result)
    assert len(result.body[0].body) == 0

# Generated at 2022-06-12 03:51:25.374221
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    code = """
        def fn():
            yield 1
            return 5
    """

    # Act
    transformed = ReturnFromGeneratorTransformer().visit(ast.parse(code))

    # Assert
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    assert ast.dump(transformed) == expected

# Generated at 2022-06-12 03:51:36.159497
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import six
    from ..utils.environment import Environment
    from ..utils.source import Source
    from ..utils.sourcetree import SourceTree
    from ..utils.visitor import print_python_source

    environment = Environment(
        six.moves.builtins,
        None,
        None,
        None,
        None,
        None,
        None
    )

    def check(src: str) -> None:
        src_tree = SourceTree()
        src_obj = Source(src)
        src_mod = src_tree.create_module(src_obj)
        src_mod.apply_transformer(ReturnFromGeneratorTransformer(environment))
        ast_tree = src_tree.compile()
        new_src_obj = print_python_source(ast_tree.body[0])  # type:

# Generated at 2022-06-12 03:51:38.878724
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input_code = '''
    def fn():
        yield 1
        return 2'''
    expected_code = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc'''
    utils.assert_convert_tree(input_code, expected_code,
                              ReturnFromGeneratorTransformer)



# Generated at 2022-06-12 03:51:44.665013
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.examples import simple_generator_function as test_fn
    from ..utils.examples import simple_generator_function_result as result

    t = ReturnFromGeneratorTransformer()
    module = ast.parse(test_fn.__doc__)
    module = t.visit(module)

    assert result == compile(module, filename="", mode='exec').__doc__

# Generated at 2022-06-12 03:51:52.303736
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse(
        textwrap.dedent(
            """\
            def fn():
                yield 1
                return 5
            """
        ), mode='exec'
    ).body[0]  # type: ast.FunctionDef
    node = transformer.visit(node)
    assert ast.dump(node) == textwrap.dedent(
        """\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

# Generated at 2022-06-12 03:51:53.003336
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:55.484320
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from typed_ast.transforms.ReturnTransforms.ReturnFromGeneratorTransformer import ReturnFromGeneratorTransformer
    from .ReturnTransformerTester import ReturnTransformerTester

# Generated at 2022-06-12 03:52:07.064084
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    src = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(src)
    node = transformer.visit(node)  # type: ignore
    result = compile(node, "<test>", "exec")
    exec(result, {})
    assert src != expected
    assert node == ast.parse(expected)

# Generated at 2022-06-12 03:52:08.163078
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:15.947279
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    n = ast.parse('def f():\n\tfor x in range(10):\n\t\tyield x\n\t\ts = "foo"\n\t\treturn s').body[0]
    ReturnFromGeneratorTransformer().visit(n)
    assert "def f():\n    for x in range(10):\n        yield x\n        s = 'foo'\n        exc = StopIteration()\n        exc.value = s\n        raise exc" == astor.to_source(n)

# Generated at 2022-06-12 03:52:24.956839
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def fn():\n    yield 1\n    return 5')
    actual = ReturnFromGeneratorTransformer().visit(node)
    expected = ast.parse(dedent('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''))
    assert ast.dump(actual, include_attributes=False) == ast.dump(expected, include_attributes=False)


# TODO: test ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:35.896117
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_source():
        def fn1():
            yield 1
            return

    def test_target():
        def fn1():
            yield 1
            
    def test_source():
        def fn2():
            yield 1
            return 5

    def test_target():
        def fn2():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

    test_source = test_source.__code__
    test_target = test_target.__code__

    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse(test_source)
    result = transformer.visit(node)
    source = compile(result, '', 'exec')

    assert source.co_code == test_target.co_code
    assert source.co_consts == test_target.co

# Generated at 2022-06-12 03:52:46.079129
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_transform
    from ..utils.multiline_string import multiline_string

    def before():
        def foo():
            yield 1
            return 2

        def bar():
            yield from [1, 2]
            return 2

        def baz():
            yield
            return 2

        def qux():
            return 2

        return foo, bar, baz, qux

    def after():
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc

        def bar():
            yield from [1, 2]
            exc = StopIteration()
            exc.value = 2
            raise exc

        def baz():
            yield
            exc = StopIteration()
            exc.value = 2
            raise exc


# Generated at 2022-06-12 03:52:49.335315
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def fn():
            yield 1
            yield 3
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            yield 3
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    assert ReturnFromGeneratorTransformer.test(code) == expected_code

# Generated at 2022-06-12 03:52:53.924946
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test():
        def a():
            if True:
                return 1
            yield 1
            return 2

        def b():
            yield 1
            return 2

        def c():
            return 1

        def d():
            return a()

        def e():
            return b()

        def f():
            return c()

        def g():
            yield a()
            return 1

# Generated at 2022-06-12 03:52:56.400076
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import source_to_ast, source_to_ast_as_string
    from ..utils.testing import assert_equal_ast


# Generated at 2022-06-12 03:53:03.966492
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import evaluate

    class Test(unittest.TestCase):
        def test_return_from_generator(self):
            code = 'def f(): yield 1; return 1'
            node = ast.parse(code)

            transformer = ReturnFromGeneratorTransformer()
            new_node = transformer.visit(node)


# Generated at 2022-06-12 03:53:22.295914
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Creating an example function with a `return` statement
    fd = ast.FunctionDef(name="foo", args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
                                 body=[ast.Yield(value=ast.Constant(value=1)),
                                       ast.Return(value=ast.Constant(value=5))],
                                 decorator_list=[],
                                 returns=None)

    # Creating a ReturnFromGeneratorTransformer and applying it on the example function
    rfgv = ReturnFromGeneratorTransformer()
    fd_out = rfgv.visit(fd)

    # Creating expected output

# Generated at 2022-06-12 03:53:24.920332
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:35.787554
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..unit_tools import assert_not_changed, assert_changed
    from ..unit_tools import parse

    not_changed = [
        'def foo():\n'
        '    return 5',
        'def foo():\n'
        '    yield 5',
        'def foo():\n'
        '    yield\'a\'\n'
        '    if True:\n'
        '        return 5',
        'def foo():\n'
        '    yield\'a\'\n'
        '    if True:\n'
        '        yield 5'
    ]


# Generated at 2022-06-12 03:53:47.423466
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.dump_ast import dump_ast
    from .remove_unused_imports import RemoveUnusedImports
    from .remove_variable_types import RemoveVariableTypes

    source = """
    def fn(a: int, b: int) -> int:
        c = a + b
        return c * 2
    """
    result = """
    def fn(a, b):
        c = a + b
        exc = StopIteration()
        exc.value = c * 2
        raise exc
    """
    ast_tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert dump_ast(ast_tree) == dump_ast(ast.parse(result))

    ast_tree = ast.parse(source)
    transformer = ReturnFromGener

# Generated at 2022-06-12 03:53:59.447310
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse('def fn(): yield 6; return 14')
    transformer.visit(tree)
    fn = tree.body[0]
    assert isinstance(fn, ast.FunctionDef)

    assert isinstance(fn.body[0], ast.Expr)
    assert isinstance(fn.body[0].value, ast.Yield)
    assert isinstance(fn.body[0].value.value, ast.Constant)
    assert fn.body[0].value.value.value == 6

    assert isinstance(fn.body[1], ast.Assign)
    assert isinstance(fn.body[1].value, ast.Call)
    assert isinstance(fn.body[1].value.func, ast.Name)
    assert fn.body[1].value.func

# Generated at 2022-06-12 03:54:06.759877
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .utils import BlankTransformer

    code = open('test/_fixtures/return_from_generator/function_def.py').read()

    test_tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(test_tree)
    BlankTransformer().visit(test_tree)

    assert code == compile(test_tree, filename="<ast>", mode="exec")

# Generated at 2022-06-12 03:54:16.116547
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input_code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    actual_code = ReturnFromGeneratorTransformer.run_test(input_code)
    assert actual_code == expected_code

    input_code = """
        def fn():
            return 5
    """
    expected_code = """
        def fn():
            return 5
    """
    actual_code = ReturnFromGeneratorTransformer.run_test(input_code)
    assert actual_code == expected_code

    input_code = """
        def fn():
            yield 1
            return 5
            yield 2
            return 6
    """

# Generated at 2022-06-12 03:54:21.961070
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.FunctionDef(name="testFunction",
                           args=ast.arguments(args=[],
                                              vararg=None,
                                              kwonlyargs=[],
                                              defaults=[],
                                              kw_defaults=[],
                                              kwarg=None),
                           body=[ast.Yield(value=ast.Constant(value=1)),
                                 ast.Return(value=ast.Constant(value=5))],
                           decorator_list=[],
                           returns=None)

# Generated at 2022-06-12 03:54:33.984426
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    import textwrap
    body_before = textwrap.dedent("""\
    def fn():
        yield 1
        return 2
    def fn2(a):
        yield 2
        return a
    def fn3():
        return
    def fn4():
        yield 1
        yield yield 2
        return 2
    def fn5():
        return 3
        yield 3
    """)


# Generated at 2022-06-12 03:54:35.762392
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import round_trip

# Generated at 2022-06-12 03:54:58.085780
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    def extract_return_nodes(node: ast.FunctionDef) -> List[ast.Return]:
        """Get all return nodes from a function ast node."""
        to_check = [(node, x) for x in node.body]  # type: ignore
        returns = []
        while to_check:
            parent, current = to_check.pop()

            if isinstance(current, ast.FunctionDef):
                continue
            elif hasattr(current, 'value'):
                to_check.append((current, current.value))  # type: ignore
            elif hasattr(current, 'body') and isinstance(current.body, list):  # type: ignore
                to_check.extend([(parent, x) for x in current.body])  # type: ignore


# Generated at 2022-06-12 03:55:07.001614
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_method(self, node1):
        node2 = ast.Return(value=node1)
        node3 = ast.Yield(value=None)
        node4 = ast.FunctionDef(name='test_FunctionDef_node4',
                                args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
                                body=[node3], decorator_list=[], returns=None)
        node5 = ast.If(test=ast.Name(id='test_FunctionDef_node5', ctx=ast.Load()),
                       body=[node2], orelse=[ast.Return()])

# Generated at 2022-06-12 03:55:12.742750
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    node = ast.parse("""def fn():
        yield 1
        return 5""")
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    expected = ast.parse("""def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc""")
    assert astor.to_source(expected) == astor.to_source(node)

# Generated at 2022-06-12 03:55:24.337670
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(unittest.TestCase):
        def test_empty(self):
            node = ast.parse("def fn():\n    pass")
            node = node.body[0]
            t = ReturnFromGeneratorTransformer()
            t.visit(node)
        
            self.assertEqual(ast.dump(node),
            """FunctionDef(name='fn', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Pass()], decorator_list=[], returns=None)""")
            self.assertFalse(t._tree_changed)
        
        def test_return_in_generator(self):
            node = ast.parse("def fn():\n    yield 1\n    return 5")
            node

# Generated at 2022-06-12 03:55:31.878718
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # The test will check the following example:
    # def foo():
    #     yield 1
    #     return 5
    # To:
    # def foo():
    #     yield 1
    #     exc = StopIteration()
    #     exc.value = 5
    #     raise exc

    # given
    foo_func = ast.FunctionDef(name='foo',
                               args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None,
                                                  defaults=[]),
                               body=[ast.Yield(value=ast.Constant(value=1)),
                                     ast.Return(value=ast.Constant(value=5))],
                               decorator_list=[],
                               returns=None)

    expected_foo_func = ast

# Generated at 2022-06-12 03:55:36.823691
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..lib3.compilers.return_from_generator import ReturnFromGeneratorTransformer
    from ..lib3.compilers.base import BaseCompiler
    from ..utils.ast_helpers import find_node_type


# Generated at 2022-06-12 03:55:45.660712
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:52.552943
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from typed_ast.ast3 import parse
    source = """def gen():
        yield 1
        return 5"""
    expected = """def gen():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc"""
    tree = parse(source)
    ReturnFromGeneratorTransformer.run_visitor(tree)
    tree_after = parse(expected)
    assert BaseNodeTransformer.compare_trees(tree, tree_after) == ''



# Generated at 2022-06-12 03:55:57.723060
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal

    code = '''
    def fn():
        yield 1
        return 5

    def fn2():
        def fn3():
            yield 1
            return 6
        return fn3()

    def fn4():
        yield 2
        yield 3

    def fn5():
        return 4

    fn6 = lambda: 5
    '''

    module = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(module)

# Generated at 2022-06-12 03:55:59.804658
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    # return_from_generator

# Generated at 2022-06-12 03:56:57.801201
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    func_def_1 = ast.FunctionDef('fn',
                                 ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
                                 [ast.Yield(ast.Num(1)), ast.Return(ast.Num(2))],
                                 [])
    expected_1 = [ast.Yield(ast.Num(1)),
                  ast.Assign([ast.Name('exc', ast.Store())], ast.Call(ast.Name('StopIteration', ast.Load()), [], [])),
                  ast.Assign([ast.Attribute(ast.Name('exc', ast.Store()), 'value', ast.Store())], ast.Num(2)),
                  ast.Raise(ast.Name('exc', ast.Load()), None)]



# Generated at 2022-06-12 03:56:58.843772
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

# Generated at 2022-06-12 03:57:06.930843
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # test_empty_function
    tree = ast.parse("def fn(): pass")
    tf = ReturnFromGeneratorTransformer()
    tf.visit(tree)
    assert tf._tree_changed == False

    # test_not_generator_function
    tree = ast.parse("def fn(): return 42")
    tf = ReturnFromGeneratorTransformer()
    tf.visit(tree)
    assert tf._tree_changed == False

    # test_simple_generator_function
    tree = ast.parse("def fn(): yield 1\n return 42")
    tf = ReturnFromGeneratorTransformer()
    tf.visit(tree)
    assert tf._tree_changed == True
    assert ast.dump(tree) == "def fn():\n    yield 1\n    exc = StopIteration()\n" \
                            

# Generated at 2022-06-12 03:57:08.135806
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import compile_to_ast

    # simple case

# Generated at 2022-06-12 03:57:17.541603
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_node
    from ..utils.snippet import snippets_equal

    def_ = get_node(
        """
        def fn():
            yield 1
            return 5
        """
    )
    expected = get_node(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    xformer = ReturnFromGeneratorTransformer()
    assert xformer.visit(def_) == expected

    def_ = get_node(
        """
        def fn():
            return 5
        """
    )
    expected = get_node(
        """
        def fn():
            return 5
        """
    )
    xformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:57:18.990931
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:57:28.023657
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import sample_ast
    from .base import BaseNodeTest
    from .base import normalize_text

    func = sample_ast.generator_ast()
    expected_func = sample_ast.generator_ast()

    expected_func.body[1].body[-1].value.body.insert(0, ast.Expr(ast.Call(
        func=ast.Name(id='let', ctx=ast.Load()),
        args=[ast.Name(id='exc', ctx=ast.Load())],
        keywords=[]
    )))

# Generated at 2022-06-12 03:57:37.862973
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""def fn(a):
                            return a""")

    assert ast.dump(ReturnFromGeneratorTransformer().visit(node)) == \
        """Module(body=[FunctionDef(name='fn', args=arguments(args=[Name(id='a', ctx=Param())], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Name(id='a', ctx=Load()))], decorator_list=[])])""" # noqa: E501 (line too long)

    node = ast.parse("""def fn():
                            yield 1
                            return 5""")


# Generated at 2022-06-12 03:57:46.341255
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fn = "def fn():\n" \
         "    yield 1\n" \
         "    return 5\n"

    # NOTE Remove setting source code for ast.parse
    src = ast.parse(fn).body[0]
    src.body[-1].value.n = 5
    src.body[-1].value.lineno = 3
    src.body[-1].value.col_offset = 10

    # NOTE Remove setting source code for ast.parse
    expected = ast.parse(fn).body[0]
    expected.body[-1].value.n = 5
    expected.body[-1].value.lineno = 3
    expected.body[-1].value.col_offset = 10
    expected.body[-1].lineno = 4
    expected.body[-1].col_offset = 2

# Generated at 2022-06-12 03:57:54.022684
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTest
    class ReturnFromGeneratorTransformerTest(BaseNodeTest):
        target = ReturnFromGeneratorTransformer
        input = """
            def some_generator():
                yield 1
                return 2
        """
        expected = """
            def some_generator():
                yield 1
                exc = StopIteration()
                exc.value = 2
                raise exc
        """

    ReturnFromGeneratorTransformerTest().test()



# Generated at 2022-06-12 03:59:13.967925
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # It's not possible to correctly cover this function with unittests as it depends on another function
    # _find_generator_returns which is covered by testing it's result.
    pass



# Generated at 2022-06-12 03:59:20.659863
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils import get_node
    from .remove_decorators import RemoveDecorators
    from .remove_type_hinter import RemoveTypeHinter
    from .remove_namespace_packages import RemoveNamespacePackages
    # import typed_ast.ast3
    # import typed_astunparse
    # print(typed_astunparse.dump(ast.parse(remove_namespace_packages(remove_decorator(remove_type_hinter(code)))))

    code = remove_namespace_packages(remove_decorator(remove_type_hinter("""\
    def fn():
        yield 1
        return 5
    """)))

    node = get_node(code)
    r = ReturnFromGeneratorTransformer().visit(node)
    assert code == remove

# Generated at 2022-06-12 03:59:25.498085
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import write_and_run
    from .. import convert_source

    tree = ast.parse('def anhui():\n yield 1\n return 3')
    tree = ReturnFromGeneratorTransformer().visit(tree)
    tree = convert_source(tree)
    assert write_and_run(3, tree) == 3

# Generated at 2022-06-12 03:59:26.378821
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:59:27.594254
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:59:31.736017
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer().run_pipeline('''
        def fn():
            yield 1
            return 5
    ''') == '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''



# Generated at 2022-06-12 03:59:35.098230
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:59:40.294411
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import LazyArguments
    from .base import BaseNodeTransformerTester

    INPUT = """
    def f():
        yield 1
        return 5
    """

    OUTPUT = """
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    BaseNodeTransformerTester(ReturnFromGeneratorTransformer, OUTPUT).set_up()

# Generated at 2022-06-12 03:59:43.066581
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import round_trip
    from ..builtin_transformers import GeneratorFunctionTransformer
    from ..utils.python_source_code import PythonSource

# Generated at 2022-06-12 03:59:48.674485
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code_in = '''
    def fn():
        if True:
            return 5
    '''
    expected = '''
    def fn():
        if True:
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''
    node = ast.parse(code_in)
    expected_node = ast.parse(expected)
    ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected_node)