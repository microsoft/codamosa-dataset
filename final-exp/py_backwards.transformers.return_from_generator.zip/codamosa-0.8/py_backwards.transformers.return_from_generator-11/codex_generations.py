

# Generated at 2022-06-12 03:50:58.437230
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import load_ast_snippet
    from ..utils.ast_helpers import get_function_names

    ast_tree = load_ast_snippet("""
        def fn():
            yield 1
            return 5
    """)
    expected_ast_tree = load_ast_snippet("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(ast_tree)
    assert get_function_names(ast_tree) == get_function_names(expected_ast_tree)

# Generated at 2022-06-12 03:51:00.588573
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import compile, assert_equal_ast


# Generated at 2022-06-12 03:51:09.189373
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:16.715557
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test case data
    input = """def fn():
    yield 1
    return 5"""
    expected_output = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
    # Perform test
    node = ast.parse(input)
    node = ReturnFromGeneratorTransformer().visit(node)  # type: ignore
    actual_output = astor.to_source(node).strip()

    # Assert
    assert actual_output == expected_output

# Generated at 2022-06-12 03:51:19.687732
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:31.519695
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(ReturnFromGeneratorTransformer):
        def _find_generator_returns(self, node):
            return [(node, ast.Return(value=1))]

        def _replace_return(self, parent, return_):
            assert return_.value == 1
            ast.copy_location(ast.Assign(targets=[ast.Name(id='_')], value=2), return_)
            return_ = ast.Return(value=2)
            ast.copy_location(return_, parent)
            parent.body.append(return_)

    tree = ast.parse("""
    def fn():
        return 1
    """)

    result = ast.parse("""
    def fn():
        _ = 2
        return 2
    """)

    assert Test.run(tree) == result

# Generated at 2022-06-12 03:51:38.225065
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    ast_tree = ast.parse(
        textwrap.dedent("""
            def fn():
                yield 1
                return 2
        """))

    transformer = ReturnFromGeneratorTransformer()

    # Act
    transformer.visit(ast_tree)

    # Assert
    expected_tree = ast.parse(
        textwrap.dedent("""
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 2
                raise exc
        """))
    assert ast_tree == expected_tree

# Generated at 2022-06-12 03:51:41.801491
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def foo(): yield (1, 2); return {"A": "B"}')
    visitor = ReturnFromGeneratorTransformer()
    node = visitor.visit(node)
    result = visitor._dump(node)

# Generated at 2022-06-12 03:51:53.451077
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .remove_tuple_unpacking import RemoveTupleUnpackingTransformer
    from .remove_braces import RemoveBracesTransformer
    from .single_line_functions import SingleLineFunctionsTransformer
    from ..utils.fakemake_ast import fakemake_ast
    from .remove_lambda import RemoveLambdaTransformer
    from .literal_eval import LiteralEvalTransformer
    from .. import tree_compare

    source_code = """
        def fn():
            yield 1
            return 5
    """
    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    parse_tree = fakemake_ast(source_code)

    node = ReturnFromGeneratorTransformer()
    new_ast = node.visit

# Generated at 2022-06-12 03:52:02.022799
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test method visit_FunctionDef of class ReturnFromGeneratorTransformer."""

# Generated at 2022-06-12 03:52:17.677185
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3, parse
    from .function import FunctionTransformer
    from .reduce_assign import ReduceAssignTransformer

    class Test:
        def test_none(self):
            node = ast3.parse(
                '''
                def fn(x):
                    return x
                ''')
            res = ReturnFromGeneratorTransformer(node).visit(node)
            assert ast3.dump(res) == ast3.dump(
                ast3.parse(
                    '''
                    def fn(x):
                        return x
                    '''))

        def test_return_from_gen_with_local(self):
            node = ast3.parse(
                '''
                def fn():
                    a = 1
                    yield a
                    return a
                ''')
            res = ReturnFromGenerator

# Generated at 2022-06-12 03:52:18.953307
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:20.815243
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_funcdef
    from astunparse import dump
    from ..utils.testing import PeekableIterator


# Generated at 2022-06-12 03:52:21.925678
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:25.644410
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_BaseNodeTransformer import _test_BaseNodeTransformer_generic_visit

# Generated at 2022-06-12 03:52:34.573521
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    """Test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    transformer = ReturnFromGeneratorTransformer(None)

    source = """def fn():\n
                    yield 1\n
                    return 5"""
    root = ast.parse(source)
    expected = """def fn():\n
                    yield 1\n
                    exc = StopIteration()
                    exc.value = 5
                    raise exc"""
    new_node = transformer.visit(root)
    assert transformer._tree_changed
    assert astunparse.unparse(new_node[0]).strip() == expected



# Generated at 2022-06-12 03:52:36.025810
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:46.228709
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class mock_ast(ast.AST):
        pass
    function_def = mock_ast()
    function_def.body = [
        mock_ast(),
        mock_ast(),
        mock_ast(),
        mock_ast(),
        mock_ast(),
    ]
    function_def.body[0].body = [
        mock_ast(),
        mock_ast(),
        mock_ast(),
    ]
    function_def.body[1].body = [
        mock_ast(),
        mock_ast(),
        mock_ast(),
        mock_ast(),
        mock_ast(),
    ]
    function_def.body[2].body = [
        function_def,
    ]

# Generated at 2022-06-12 03:52:53.172244
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import render_node
    from .compile_to_ast import compile_to_ast
    def gen():
        yield 1
        return 5

    class DummyNodeTransformer(ast.NodeTransformer):
        def __init__(self):
            self._tree_changed = False

    DummyNodeTransformer().visit(ReturnFromGeneratorTransformer().visit(compile_to_ast(gen)))
    source_lines = render_node(compile_to_ast(gen)).split('\n')
    expected_lines = [
        "def gen():",
        "    yield 1",
        "    exc = StopIteration()",
        "    exc.value = 5",
        "    raise exc"
    ]
    for i, expected_line in enumerate(expected_lines):
        assert expected_line == source

# Generated at 2022-06-12 03:53:04.073092
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.testutils import assert_source_equal
    # return_from_generator must be imported after testutils to hide it from pytest
    from .compat import return_from_generator

    source = '''
        def fn():
            yield 1
            return 5
        '''
    expected = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''

    transformer = ReturnFromGeneratorTransformer()
    module = transformer.visit(ast.parse(source))
    assert_source_equal(expected, module)



# Generated at 2022-06-12 03:53:08.308581
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Only for type check
    ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:53:18.761275
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    transformer = ReturnFromGeneratorTransformer()

    fn = ast.FunctionDef(name='fn',
                         args=ast.arguments(
                             args=[],
                             vararg=None,
                             kwonlyargs=[],
                             kw_defaults=[],
                             kwarg=None,
                             defaults=[]),
                         body=[ast.Yield(value=ast.Num(n=1)),
                               ast.Return(value=ast.Num(n=5))],
                         decorator_list=[],
                         returns=None,
                         type_comment=None)
    # Act
    transformed_fn = transformer.visit(fn)

    # Assert
    assert transformer.was_changed == True
    assert isinstance(transformed_fn.body[1], ast.Assign)
   

# Generated at 2022-06-12 03:53:20.515490
# Unit test for constructor of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:27.313630
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_clean import compile_to_ast

    code = """def fn():
        yield 1
        return 5"""
    tree = compile_to_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    generated_code = compile(tree, '<test>', 'exec')
    exec(generated_code)

    assert fn().__next__() == 1
    assert fn().__next__() == 5

# Generated at 2022-06-12 03:53:28.777663
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    rfgt = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:53:29.393189
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-12 03:53:31.226862
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None)._find_generator_returns(None) == []

# Generated at 2022-06-12 03:53:32.875572
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert type(x) == ReturnFromGeneratorTransformer


# Generated at 2022-06-12 03:53:44.232303
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import BaseNodeTransformer
    from .remove_unneeded_pass import RemoveUnneededPassTransformer
    from .remove_unused_locals import RemoveUnusedLocalsTransformer


    returned, calls = None, None

# Generated at 2022-06-12 03:53:45.402056
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:00.102239
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..compile_to_ast import compile_to_ast
    from ..NodeTransformer import NodeTransformer
    from ..TransformerSequence import TransformerSequence
    sequence = TransformerSequence(transformers=[ReturnFromGeneratorTransformer()])
    sequence.process_all()

    class NodeTransformerStub(NodeTransformer):
        def visit_Return(self, node: ast.Return) -> ast.Return:
            if node.value is not None:
                node.value = ast.Num(n=5)
            return node

    sequence.add_transformer(NodeTransformerStub())
    sequence.process_all()


# Generated at 2022-06-12 03:54:03.930667
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .fix_all import fix_all
    from ..utils.source import Source
    from ..utils.source_tree import SourceTree
    from ..utils.line_numbers import LineNumbers

    source = Source("""
    def fn():
        yield 1
        return 5
    """)
    source_tree = SourceTree.from_source(source)
    line_numbers = LineNumbers.from_source(source)
    transformer = ReturnFromGeneratorTransformer()
    result = fix_all(source_tree, [transformer], line_numbers)
    assert result == """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    source = Source("""
    def fn():
        return 5
    """)
    source_tree = SourceTree.from_

# Generated at 2022-06-12 03:54:14.326516
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # ReturnFromGeneratorTransformer.visit_FunctionDef -> fn()
    def fn():
        yield 1
        return 5

    result = ReturnFromGeneratorTransformer().visit(fn.__code__) # type: ignore
    assert result.co_consts[1] == StopIteration.__code__
    assert result.co_consts[2] == StopIteration
    assert result.co_consts[3] == 5

# Generated at 2022-06-12 03:54:26.328315
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .base import CTBTestCase
    from .unpack import UnpackAssignmentTransformer
    from .genexp import GeneratorExpTransformer
    from .decorator import DecoratorTransformer
    import textwrap

    class TestReturnFromGeneratorTransformer(CTBTestCase):
        def setUp(self):
            self.transformer = ReturnFromGeneratorTransformer()
            self.uat = UnpackAssignmentTransformer()
            self.get = GeneratorExpTransformer()
            self.det = DecoratorTransformer()

        def test_simple(self):
            code = 'def f():\n    yield 1\n    return 3'

# Generated at 2022-06-12 03:54:34.186271
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    code = """
    def prev():
        yield 1
        return 5
    """
    new_code = """
    def prev():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(code)
    visitor = ReturnFromGeneratorTransformer()
    visitor.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(new_code))



# Generated at 2022-06-12 03:54:35.534257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:47.844680
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            transformer = ReturnFromGeneratorTransformer()

            # Replace return in generator
            node1 = ast.parse("""
            def gen():
                yield 1
                return 5
            """)

            expected1 = ast.parse("""
            def gen():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            """)

            node1 = transformer.visit(node1)
            self.assertEqual(expected1, node1)

            # Do not replace return in generator
            node2 = ast.parse("""
            def gen():
                return 5
            """)

            node2 = transformer.visit(node2)
            self.assertEqual(node2, node2)

   

# Generated at 2022-06-12 03:54:50.477088
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
  return_from_generator_transformer =  ReturnFromGeneratorTransformer()
  assert return_from_generator_transformer is not None
  assert isinstance(return_from_generator_transformer, ReturnFromGeneratorTransformer)



# Generated at 2022-06-12 03:54:53.665459
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    def fn():
        yield 1
        return 5

    res = ReturnFromGeneratorTransformer().visit(ast.parse(fn.__code__))
    assert compile(res, "<test>", "exec").co_consts == (None, StopIteration)

# Generated at 2022-06-12 03:55:01.960080
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn():
        yield 1
        yield 2
        return 3

    def fn2():
        yield 1
        return 2

    def fn3():
        return 3
    def fn4():
        yield 1
        return 2
    def fn5():
        yield 1
        return 2
        yield 3

    def fn6():
        yield 1
        if True:
            return 2
        yield 3
    """


# Generated at 2022-06-12 03:55:14.154239
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """def f():
    print("1")
    return 2"""

    expected = """def f():
    print("1")
    exc = StopIteration()
    exc.value = 2
    raise exc"""

    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)
    result = str(node)

    assert result == expected, result


# Generated at 2022-06-12 03:55:14.807097
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-12 03:55:26.141046
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Unit test for _find_generator_returns
    def test_find_generator_returns(node, expected):
        transformer = ReturnFromGeneratorTransformer()
        actual = transformer._find_generator_returns(node)
        assert expected == actual
    # No `return` in fn
    test_find_generator_returns(ast.parse("""
        def fn():
            pass
    """).body[0], [])
    # No `return` in fn
    test_find_generator_returns(ast.parse("""
        def fn():
            return 1
    """).body[0], [])
    # No `return` in fn

# Generated at 2022-06-12 03:55:29.412423
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    from .examples import return_from_generator
    from .utils import compare_ast

    source = return_from_generator.source
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    compare_ast(tree, return_from_generator.expected_tree)

# Generated at 2022-06-12 03:55:40.840622
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(None, None).visit(
        ast.parse('def fn():\n pass')) == ast.parse('def fn():\n pass')
    assert ReturnFromGeneratorTransformer(None, None).visit(
        ast.parse('def fn():\n return')) == ast.parse('def fn():\n return')
    assert ReturnFromGeneratorTransformer(None, None).visit(
        ast.parse('def fn():\n yield\n return')) == ast.parse(
            'def fn():\n yield\n exc = StopIteration()\n exc.value = None\n '
            'raise exc')

# Generated at 2022-06-12 03:55:43.161295
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class_obj = ReturnFromGeneratorTransformer()
    result = class_obj.visit_FunctionDef(None)
    assert result is None


# Generated at 2022-06-12 03:55:52.274504
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .transforment_test_utils import check_transform_function

    snippet = """
    def fn(a):
        a = yield 1
        i = 2
        for i in a:
            if a:
                return 2
            yield i
        return 4
    """
    sneck = """
    def fn(a):
        a = yield 1
        i = 2
        for i in a:
            if a:
                exc = StopIteration()
                exc.value = 2
                raise exc
            yield i
        exc = StopIteration()
        exc.value = 4
        raise exc
    """
    check_transform_function(snippet, sneck, ReturnFromGeneratorTransformer)



# Generated at 2022-06-12 03:56:02.689615
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''
    def function():
        def function_inside():
            if True:
                return 8
                yield 5
            else:
                return_this = "foo"
                return return_this
        yield from function_inside()
        return
    '''
    expected = '''
    def function():
        def function_inside():
            if True:
                exc = StopIteration()
                exc.value = 8
                raise exc
                yield 5
            else:
                return_this = "foo"
                exc = StopIteration()
                exc.value = return_this
                raise exc
        yield from function_inside()
        return
    '''

    transformer = ReturnFromGeneratorTransformer()
    res = transformer.visit(ast.parse(code))
    assert ast.unparse(res) == expected




# Generated at 2022-06-12 03:56:10.913538
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

# Generated at 2022-06-12 03:56:20.797296
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import ast_compare, ast_dump
    from ..typed_ast_pprint import pprint as pp
    from ._transformer import run_transformer

    # First test
    example = """
    def fn():
        yield 1
        return 5
    """
    # The expected result
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    root = ast.parse(example)
    tree = run_transformer(root, ReturnFromGeneratorTransformer)
    assert ast_compare(ast.parse(expected), tree), \
        ast_dump(tree) + " is not like " + ast_dump(ast.parse(expected))
    # Recheck after serialize-deserialize
    tree = run_transformer

# Generated at 2022-06-12 03:56:34.723727
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse(textwrap.dedent(
        """
        def gen():
            yield 1
            return 5
        """
    ))
    ret = transformer.visit(tree)
    assert ret is transformer.tree
    assert isinstance(ret, ast.Module)
    assert len(ret.body) == 1
    assert isinstance(ret.body[0], ast.FunctionDef)

# Generated at 2022-06-12 03:56:36.814636
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    l = [1,2,3]
    assert l == [1,2,3]


# Generated at 2022-06-12 03:56:37.378958
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    pass

# Generated at 2022-06-12 03:56:47.891723
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert len(ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse("""
    def fn():
        return 5
        yield 1
        return 5
    """).body[0])) == 2

    assert len(ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse("""
    def fn():
        yield 1
        return 5
    """).body[0])) == 1

    assert len(ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse("""
    def fn():
        return 5
    """).body[0])) == 0

    assert len(ReturnFromGeneratorTransformer()._find_generator_returns(ast.parse("""
    def fn():
        yield 1
    """).body[0])) == 0

# Generated at 2022-06-12 03:56:54.540848
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5

    tree = ast.parse(fn.__code__.co_code.decode('utf-8'))
    tree = ReturnFromGeneratorTransformer().visit(tree)

    code = compile(tree, '<test>', 'exec')
    g = fn()

    test_g = code.__code__.co_names[0]()
    assert next(g) == next(test_g)

    with pytest.raises(StopIteration) as exc:
        g.send(None)
    assert exc.value.value == 5
    with pytest.raises(StopIteration) as exc:
        test_g.send(None)
    assert exc.value.value == 5



# Generated at 2022-06-12 03:56:56.522224
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def fn():
        yield 1
        return 5
    assert ReturnFromGeneratorTransformer().run(fn) == return_from_generator

# Generated at 2022-06-12 03:56:58.417752
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:57:00.055383
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer(3, 2).target == (3, 2)


# Generated at 2022-06-12 03:57:03.684265
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = '''\
    def f():
        yield
        return 1
    '''
    target = '''\
    def f():
        yield
        exc = StopIteration()
        exc.value = 1
        raise exc
    '''
    assert convert(source) == target



# Generated at 2022-06-12 03:57:12.634757
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    def get_generator_definition():
        """Get definition of generator like:
            def fn():
                yield 1
                return 5
        """
        return ast.FunctionDef(
            name='fn',
            args=ast.arguments(args=[],
                               vararg=None,
                               kwonlyargs=[],
                               kw_defaults=[],
                               kwarg=None,
                               defaults=[]),
            body=[ast.Yield(value=ast.Num(n=1)),
                  ast.Return(value=ast.Num(n=5))],
            decorator_list=[],
            returns=None,
        )


# Generated at 2022-06-12 03:57:26.701456
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    x = ReturnFromGeneratorTransformer()
    assert x is not None


# Generated at 2022-06-12 03:57:29.173778
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    class TestReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def __init__(self):
            super().__init__("")

    return TestReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:57:39.250787
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return
            
        def fn2():
            yield 1
            return 5
            print(1)
            
        def fn3():
            yield 1
            return 5
        """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(tree)
    expected = """
        def fn():
            yield 1
        
        def fn2():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            print(1)
            
        def fn3():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    assert ast.dump(result) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 03:57:40.189041
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

# Generated at 2022-06-12 03:57:45.071496
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    source = """
    def foo():
        yield 1
        return 5
    """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)  # type: ignore
    new_source = ast.unparse(new_tree)
    expected_source = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    assert new_source == expected_source

# Generated at 2022-06-12 03:57:45.870188
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer(None).visit_FunctionDef(None) is None

# Generated at 2022-06-12 03:57:56.820668
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def foo(a):
            yield a
            return a

        def bar(a):
            return a

        def baz(a):
            yield a
            b = 5
            if a > b:
                return a
            else:
                return b
    """
    expected = """
        def foo(a):
            yield a
            exc = StopIteration()
            exc.value = a
            raise exc

        def bar(a):
            return a

        def baz(a):
            yield a
            b = 5
            if a > b:
                exc = StopIteration()
                exc.value = a
                raise exc
            else:
                exc = StopIteration()
                exc.value = b
                raise exc
    """


# Generated at 2022-06-12 03:58:03.934338
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    stmt = "def fn():\n    yield 1\n    return a\n"
    input_ast = ast.parse(stmt).body[0]
    transformer = ReturnFromGeneratorTransformer()
    output_ast = transformer.visit(input_ast)
    expected_output = "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = a\n    raise exc\n"
    # print(astor.to_source(output_ast))
    assert astor.to_source(output_ast) == expected_output


# Generated at 2022-06-12 03:58:13.798291
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..unit_transformers.snippets import node, standalone_visit
    from ..utils.snippet import snippet

    @snippet
    def expected(var_a, var_b):
        let(var_a)
        var_a = 1
        try:
            let(exc)
            exc = StopIteration()
            exc.value = var_b
            raise exc
        except StopIteration as exc:
            var_b = exc.value
        return var_b

    with node("""
        def fn(var_a):
            var_a = 1
            try:
                return var_a
            except NameError:
                pass
    """) as ast_node:
        res_ast_node = standalone_visit(ast_node, ReturnFromGeneratorTransformer)

        assert expected.get_

# Generated at 2022-06-12 03:58:23.713389
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    # Arrange
    source_code = """
        def gen1():
            yield 1
            return "abc"
        def gen2():
            yield 1
            yield 2
            return "abc"
        def gen3():
            yield 1
            return 3
        def gen4():
            yield 1
            1
            return 3
        def gen5():
            yield 1
            if True:
                return 3
        def gen6():
            yield 1
            1, 2
            return "ab"
        def gen7():
            yield 1
            for i in range(2):
                return "abc"
        def gen8():
            yield 1
            def gen8_inner():
                yield 2
                return "abc"
            yield from gen8_inner()
        def gen9():
            yield 1
    """

# Generated at 2022-06-12 03:58:55.363215
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()

    def fn1():
        yield 1
        return 5

    def fn2():
        return 1

    c = transformer.compile_snippet(fn1)
    c = transformer.compile_snippet(fn2)

__all__ = ['ReturnFromGeneratorTransformer']

# Generated at 2022-06-12 03:59:05.179794
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    transformer = ReturnFromGeneratorTransformer()
    assert transformer._find_generator_returns(ast.parse(
        '''
        def fn():
            yield 1
            return 5
        '''
    )) == [(ast.parse(
        '''
        def fn():
            yield 1
            return 5
        '''
    ).body[1], ast.parse(
        '''
        return 5
        '''
    ))]
    assert transformer._find_generator_returns(ast.parse(
        '''
        def fn():
            return 5
        '''
    )) == []
    assert transformer._find_generator_returns(ast.parse(
        '''
        def fn():
            yield 1
            yield 2
            yield 3
        '''
    )) == []


# Generated at 2022-06-12 03:59:06.184206
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    assert ReturnFromGeneratorTransformer()


# Generated at 2022-06-12 03:59:07.532390
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer(): # noqa
    def fn():
        yield 1
        return 5

# Generated at 2022-06-12 03:59:10.236798
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def v(tree):
        return ReturnFromGeneratorTransformer().visit(tree)


# Generated at 2022-06-12 03:59:17.165990
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    nodes = ast.parse('''
        def fn():
            if True:
                yield 1
                return len([])
            return 2
    ''')
    assert len(nodes.body[0].body) == 1

    transformer = ReturnFromGeneratorTransformer()
    nodes = transformer.visit(nodes)
    assert transformer._tree_changed == True

    assert len(nodes.body[0].body) == 3
    assert len(nodes.body[0].body[1].body) == 6
    assert len(nodes.body[0].body[1].body[-1].body) == 5



# Generated at 2022-06-12 03:59:25.225292
# Unit test for constructor of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer():
    frsg = ReturnFromGeneratorTransformer()
    function_def_node = ast.parse("""
        def fn():
            yield 1
            return 5
    """, mode="exec")
    frsg.visit(function_def_node)

# Generated at 2022-06-12 03:59:34.304323
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        target = (3, 2)
        transformer = ReturnFromGeneratorTransformer

        def test_return_from_generator_with_docstring(self):
            before_code = """
                def fn():
                    '''docstring'''

                    yield 1

                    return 42
            """
            after_code = """
                def fn():
                    '''docstring'''

                    yield 1

                    exc = StopIteration()
                    exc.value = 42
                    raise exc
            """

            self.assertTransformedAST(before_code, after_code)

        def test_return_from_generator(self):
            before_code = """
                def fn():
                    yield 1

                    return 42
            """

# Generated at 2022-06-12 03:59:43.408812
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def l():
            yield 5
            if a == 5:
                yield 7
            return 'value'

        def k():
            yield 6
            yield from l()
            return 'value2'
    """
    module_ast = ast.parse(code)
    node_transformer = ReturnFromGeneratorTransformer()
    new_module_ast = node_transformer.visit(module_ast)

    assert_that(code, equal_to(ast.unparse(module_ast)))

# Generated at 2022-06-12 03:59:47.403245
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc\n" == \
        compile(ReturnFromGeneratorTransformer().visit(ast.parse("""def fn():
    yield 1
    return 5""")), '<test>', 'exec').strip()