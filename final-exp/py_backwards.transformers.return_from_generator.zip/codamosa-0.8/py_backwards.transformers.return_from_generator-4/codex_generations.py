

# Generated at 2022-06-12 03:50:58.464576
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test method to test visit_FunctionDef method of ReturnFromGeneratorTransformer"""
    import astor
    from collections import namedtuple
    from cStringIO import StringIO

    GeneratorReturn = namedtuple('GeneratorReturn', ['parent', 'return_'])

    def test_return_from_generator(code:str, returns: List[GeneratorReturn]) -> bool:
        """Compares given code after compile to python with our transformed code."""
        module = ast.parse(code)
        xformer = ReturnFromGeneratorTransformer()
        xformer.visit(module)

        # collect all return statements from expected results
        expected_returns = []
        for parent, return_ in returns:
            expected_returns.extend(astor.to_source(return_).splitlines())

        # collect all return statements from transformed

# Generated at 2022-06-12 03:51:05.943223
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.compiler import compile_snippet, get_ast
    f = compile_snippet(
        '''
        def fn():
            yield 1
            return 5
        '''
    )
    expected = compile_snippet(
        '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    )
    assert get_ast(f) == get_ast(expected)

# Generated at 2022-06-12 03:51:17.864808
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing_utils import assert_equal_ignore_ws

    tree = ast.parse("""\
        def fn():
            yield 1
            return 5
    """)

    ReturnFromGeneratorTransformer().visit(tree)

# Generated at 2022-06-12 03:51:19.041349
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Foo:
        def __init__(self):
            self.value = 5
    from astor.code_gen import to_source

    # test case 1

# Generated at 2022-06-12 03:51:30.949479
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_node
    from .remove_elts_transformer import RemoveEltsTransformer
    from .return_to_assign_transformer import ReturnToAssignTransformer

    code =  """
    def foo():
        yield 1
        return 5
    """

    expected_str =  """
    def foo():
        # let exc
        exc = StopIteration()
        exc.value = 5
        raise exc
        yield 1
        raise exc
    """
    node = source_to_node(code)
    transformer = ReturnToAssignTransformer()
    transformer.visit(node)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    transformer = RemoveEltsTransformer()
    transformer.visit(node)
    node_str = ast.dump

# Generated at 2022-06-12 03:51:40.258461
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert_equal = lambda a, b: a == b
    assert_equal.__name__ = 'assert_equal'
    test_code = """
    def fn():
        yield 0
        yield 1
        return 5
    """
    expected_code = """
    def fn():
        yield 0
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc

    """
    assert_equal(ReturnFromGeneratorTransformer(test_code).result, expected_code)

    test_code = """
    def fn():
        def foo():
            pass

        yield 0
        yield 1
        return 5
    """

# Generated at 2022-06-12 03:51:50.214817
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn(x):
        for i in x:
            yield i
        return x
    """
    del_except = """
    def fn(x):
        for i in x:
            yield i
        exc = StopIteration()
        exc.value = x
        raise exc
    """
    expected = ast.parse(del_except)
    source = ast.parse(source)
    tf = ReturnFromGeneratorTransformer()
    actual = tf.visit(source)
    assert ast.dump(actual, include_attributes=True) == ast.dump(expected, include_attributes=True)



# Generated at 2022-06-12 03:51:57.838343
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # This test is a unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer.
    # It check that the visit_FunctionDef can correctly compile return in generators.
    module_node = ast.parse('def a(): return 1', mode="exec")  # type: ignore
    assert len(ast.walk(module_node)) == 2  # type: ignore
    module_node = ReturnFromGeneratorTransformer().visit(module_node)  # type: ignore
    assert len(ast.walk(module_node)) == 5  # type: ignore
    module_node = ast.parse('def b(): yield 1; return 2', mode="exec")  # type: ignore
    assert len(ast.walk(module_node)) == 3  # type: ignore
    module_node = ReturnFromGeneratorTransformer().visit(module_node)

# Generated at 2022-06-12 03:51:59.196405
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:04.890471
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing_utils import assert_code_equal
    from ..testing_utils import get_ast

    node = get_ast("def fn():\n    yield 1\n    return 5")
    rft = ReturnFromGeneratorTransformer()
    res = rft.visit(node)
    assert_code_equal(res, "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc")

# Generated at 2022-06-12 03:52:15.061933
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # FIXME: the code below is not the real test
    one = ast.parse('import typing')
    generator_returns = ReturnFromGeneratorTransformer()._find_generator_returns(one.body[0])
    parent, return_ = generator_returns[0]
    ReturnFromGeneratorTransformer()._replace_return(parent, return_)
    # FIXME: the code above is not the real test

# Generated at 2022-06-12 03:52:22.667382
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = """
    def fn():
        yield 1
        yield 2
        return 5
    """
    expected = """
    def fn():
        yield 1
        yield 2
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(tree)
    expected = ast.parse(expected)
    ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-12 03:52:29.503130
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.run(source=source) == expected



# Generated at 2022-06-12 03:52:38.127760
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Setup
    from typed_astunparse import unparse
    from test.test_utils import assert_code_equal, get_ast

    code = """\
    def fn():
        yield 1
        return 5
    """
    expected_code = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    """Test:
    def fn():
        yield 1
        return 5
    To:
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = get_ast(code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    # Exercise
    result = unparse(tree)

    # Verify
    assert_code_

# Generated at 2022-06-12 03:52:43.407688
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Base cases
    assert ReturnFromGeneratorTransformer.visit_FunctionDef(None, None) is None
    assert ReturnFromGeneratorTransformer().visit_FunctionDef(None, None) is None

    # Expected
    def fn1():
        yield 1
        return 2
    expected1 = '''def fn1():
    yield 1
    exc = StopIteration()
    exc.value = 2
    raise exc'''
    assert ''.join(str(x) for x in ReturnFromGeneratorTransformer.visit_FunctionDef(None, ast.parse(fn1.__doc__)).body) == expected1

    def fn2():
        yield 1
        return 2
        return 3

# Generated at 2022-06-12 03:52:52.755501
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Given
    def fn1():
        yield 1
        return 5
    def fn2():
        for i in range(10):
            if i % 2:
                yield i
        return 5
    def fn3():
        yield 1
        if True:
            return 6
        yield 2
    def fn4():
        return 5

    # Transform
    out = [ReturnFromGeneratorTransformer(fn1),
           ReturnFromGeneratorTransformer(fn2),
           ReturnFromGeneratorTransformer(fn3),
           ReturnFromGeneratorTransformer(fn4)]

    # Testing
    assert out[0]() == [1, 5]
    assert list(out[1]()) == [1, 3, 5, 7, 9]
    assert out[2]() == [1, 6]
    assert out[3]() == 5

# Generated at 2022-06-12 03:52:53.313498
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:06.140556
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""def fn():
        yield 1
        x = 5
        y = 6
        return 7""")
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

# Generated at 2022-06-12 03:53:16.661895
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    result = ReturnFromGeneratorTransformer().visit(ast.parse("""
        def fn():
            yield 1
            return 5
    """))


# Generated at 2022-06-12 03:53:27.875948
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    assert ReturnFromGeneratorTransformer.apply(r'''
        def fn():
            yield 1
            return 5
    ''') == r'''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''

    assert ReturnFromGeneratorTransformer.apply(r'''
        def fn2():
            yield from [1]
            return 5
    ''') == r'''
        def fn2():
            yield from [1]
            exc = StopIteration()
            exc.value = 5
            raise exc
    '''

    assert ReturnFromGeneratorTransformer.apply(r'''
        def fn3():
            return 5
    ''') == r'''
        def fn3():
            return 5
    '''

    assert ReturnFromGener

# Generated at 2022-06-12 03:53:36.496353
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:48.409797
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTestCase
    from .base import as_string
    from .base import run_transformer

    class TestCase(BaseNodeTransformerTestCase):
        def test_return_from_generator(self):
            source = 'def fn():\n' \
                     '    yield 1\n' \
                     '    return 5\n'

            expected = 'def fn():\n' \
                       '    yield 1\n' \
                       '    exc = StopIteration()\n' \
                       '    exc.value = 5\n' \
                       '    raise exc\n'

            tree = ast.parse(source)
            run_transformer(tree, ReturnFromGeneratorTransformer())
            self.assertEqual(as_string(tree), expected)


# Generated at 2022-06-12 03:53:56.468022
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for Visit_FunctionDef"""
    node = ast.parse("""
    def example():
        yield 1
        return 5
    """)

    target_node = ast.parse("""
    def example():
        yield 1
        StopIteration = StopIteration
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert ast.dump(node) == ast.dump(target_node)

# Generated at 2022-06-12 03:54:08.191969
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from unittest.mock import Mock

    class MockReturn:
        def __init__(self, value):
            self.value = value

    class MockYield:
        pass

    class MockYieldFrom:
        pass

    class MockFunctionDef:
        def __init__(self, body):
            self.body = body


# Generated at 2022-06-12 03:54:20.074848
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Check where return is inside if
    node_no_return = ast.parse('def fn(): if True: return 42')
    node_return = ast.parse('def fn(): if True: return 42')

    return_no_return = node_no_return.body[0].body[0].body[0]
    return_return = node_return.body[0].body[0].body[0]

    assert isinstance(return_no_return, ast.Return)
    assert isinstance(return_return, ast.Return)

    assert return_no_return.value is None
    assert return_return.value is None

    transformer_no_return = ReturnFromGeneratorTransformer()
    transformer_return = ReturnFromGeneratorTransformer()

    transformer_no_return.visit(node_no_return)

# Generated at 2022-06-12 03:54:32.232947
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def fn(): yield 1')
    expected = ast.parse('def fn(): yield 1')
    new_node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(expected) == ast.dump(new_node)
    node = ast.parse('def fn(): yield 1; yield 2')
    expected = ast.parse('def fn(): yield 1; yield 2')
    new_node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(expected) == ast.dump(new_node)
    node = ast.parse('def fn(): return 1')
    expected = ast.parse('def fn(): return 1')
    new_node = ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(expected) == ast.dump(new_node)
   

# Generated at 2022-06-12 03:54:44.412332
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn(a):
            yield
            b = 5
            if a:
                yield b
                return b
            else:
                yield 8
                return 10
    """
    expected = """
        def fn(a):
            yield

            b = 5
            if a:
                yield b
                exc = StopIteration()
                exc.value = b
                raise exc
            else:
                yield 8
                exc = StopIteration()
                exc.value = 10
                raise exc
    """
    node = ast.parse(source)

    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)

    assert transformer._tree_changed is True
    assert ast.dump(new_node) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 03:54:49.260207
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:54.089839
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import tests
    import astunparse
    fn = tests.test_constants.func_gen_return
    unparsed_fn = astunparse.unparse(fn)
    ast_fn = ast.parse(unparsed_fn)
    
    rfg = ReturnFromGeneratorTransformer()
    transformed_ast_fn = rfg.visit(ast_fn)
    transformed_fn = astunparse.unparse(transformed_ast_fn)
    
    assert transformed_fn == fn.replace('return 2', 
        'exc = StopIteration()\nexc.value = 2\nraise exc')


# Generated at 2022-06-12 03:54:55.460161
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import assert_ast
    from ..utils import parse

# Generated at 2022-06-12 03:55:13.267761
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse


# Generated at 2022-06-12 03:55:13.896171
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:22.367097
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    tree = ast.parse("""
    def foo(a):
        a += 1
        yield a
        return a
    """)
    expected = ast.parse("""
    def foo(a):
        a += 1
        yield a
        exc = StopIteration()
        exc.value = a
        raise exc
    """)
    # Act
    tr = ReturnFromGeneratorTransformer()
    tr.visit(tree)
    # Assert
    assert ast.dump(tree, include_attributes=True) == ast.dump(expected, include_attributes=True)

# Generated at 2022-06-12 03:55:23.366104
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:31.742979
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_from_module
    from ..utils.visitor import visitor_module
    target = ReturnFromGeneratorTransformer.target
    test_snippet: str = """
        @decorator
        class C:
            def fn(self):
                yield 1
                return 'hello'
    """
    expect: str = """
        @decorator
        class C:
            def fn(self):
                yield 1
                exc = StopIteration()
                exc.value = 'hello'
                raise exc
    """
    test_ast = get_from_module(test_snippet, target=target)
    expect_ast = get_from_module(expect, target=target)
    result = ReturnFromGeneratorTransformer().visit(test_ast)

# Generated at 2022-06-12 03:55:41.803877
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import fold_assignment_in_function
    from ..utils.testing import generate_function_body_from_source

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    transformer = ReturnFromGeneratorTransformer()
    function_def = generate_function_body_from_source(source)
    function_def = transformer.visit(function_def)  # type: ignore
    actual = fold_assignment_in_function(function_def)
    assert expected == actual



# Generated at 2022-06-12 03:55:52.037799
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from unittest import TestCase
    import typing as tp
    from ..type_inference import infer_types, TypeStore

    class __TestCase(TestCase):
        def test_ReturnFromGeneratorTransformer_visit_FunctionDef(self):
            from typed_ast import ast3 as ast  # type: ignore
            from ..base import BaseNodeTransformer
            from ..utils.compat import StringIO

            class _(BaseNodeTransformer):
                pass

            def a():
                yield 1
                return 5

            def b():
                return 5

            def c():
                yield 1

            def d():
                yield 1
                return

            def e():
                yield 1
                return None

            def f():
                yield 1
                return 5


# Generated at 2022-06-12 03:55:57.310554
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:06.126824
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(unittest.TestCase):
        def setUp(self):
            self.transformer = ReturnFromGeneratorTransformer()

        def test_usual_function(self):
            source = """\
                def usual_function(arg):
                    return 1
            """
            tree = ast.parse(source)
            self.transformer.visit(tree)
            self.assertEqual(ast.dump(tree), source)

        def test_generator(self):
            source = """\
                def generator():
                    yield 1
                    return 2
            """
            expected = """\
                def generator():
                    yield 1
                    exc = StopIteration()
                    exc.value = 2
                    raise exc
            """

            tree = ast.parse(source)
            self.transformer.visit(tree)

# Generated at 2022-06-12 03:56:10.740755
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert astor.to_source(tree) == expected

# Generated at 2022-06-12 03:56:45.498303
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from colin_net.lifecycle import LifecycleManager
    from colin_net.nodes import RootNode

    class CompilationData:
        def __init__(self, tree: ast.AST, code: str, file: str, module_name: str, new_name: str) -> None:
            self.code = code
            self.file = file
            self.module_name = module_name
            self.new_name = new_name
            self.tree = tree


# Generated at 2022-06-12 03:56:53.671458
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """def fn(n):
    yield n + 1
    return n + 2"""

    tree = ast.parse(code)
    tree = ReturnFromGeneratorTransformer().visit(tree)

    fn = tree.body[0]
    assert isinstance(fn, ast.FunctionDef)
    assert len(fn.body) == 4

    fn_body = fn.body[2]
    assert isinstance(fn_body, ast.Expr)
    assert isinstance(fn_body.value, ast.Raise)

    f_body = fn_body.value.exc
    assert isinstance(f_body, ast.Call)
    assert isinstance(f_body.func, ast.Name)
    assert f_body.func.id == 'StopIteration'

    assert len(f_body.args) == 1


# Generated at 2022-06-12 03:57:02.619593
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        return 7
    # Call tested function:
    ret_val = ReturnFromGeneratorTransformer().visit(fn)

    import inspect
    assert inspect.getsource(ret_val) == 'def fn():\n    return 7'

    def fn():
        yield 1
        return 7
    # Call tested function:
    ret_val = ReturnFromGeneratorTransformer().visit(fn)

    import inspect
    assert inspect.getsource(ret_val) == 'def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 7\n    raise exc'

    def fn():
        yield 1
        if False:
            return 7
    # Call tested function:
    ret_val = ReturnFromGeneratorTransformer().visit(fn)

    import inspect

# Generated at 2022-06-12 03:57:09.451979
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..unittest_tools import assert_code_equal
    from ..utils import parse

    source = """
    def fn1():
        return 1

    def fn2():
        yield 2
        return 2

    def fn3():
        for i in range(10):
            yield i
        return 3

    def fn4():
        for i in range(10):
            yield i
            return 4

    def fn5():
        for i in range(10):
            yield i
        yield from other_generator()
        return 5

    def fn6():
        yield from other_generator()
        return 6

    def fn7():
        yield 7
        yield 8
        return 7
    """

# Generated at 2022-06-12 03:57:11.088200
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import compile_from_str


# Generated at 2022-06-12 03:57:16.355889
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn_with_return() -> Generator[int, None, int]:
        yield 1
        return 5

    node = ast.parse(fn_with_return.__code__.co_consts[0]).body[0]
    t = ReturnFromGeneratorTransformer()
    t.visit(node)
    assert ast.dump(node) == '<_ast.FunctionDef object at 0x1107f48d0>'


# Generated at 2022-06-12 03:57:20.668869
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """
    Unit test for method visit_FunctionDef

    This test checks if the function is a generator and if the function has a return
    statement and if the function has a return statement it replaces that return statement
    with an exception raising statement.

    The function is:
        def fn():
            yield 1
            return 5
    To:
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    pass # FIXME

# Generated at 2022-06-12 03:57:27.430669
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import parse
    from .. import unparser
    from .unused_import_transformer import UnusedImportTransformer
    code = """\
    def f():
        yield 1
        return 2
    """
    expected = """\
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    module = parse(code)
    UnusedImportTransformer().visit(module)
    module = ReturnFromGeneratorTransformer().visit(module)
    result = unparser(module)
    assert expected == result

# Generated at 2022-06-12 03:57:28.731945
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .parent_refactor import ParentRefactorTransformer


# Generated at 2022-06-12 03:57:33.466669
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse, to_source
    from pprint import pprint

    code = '''
        def fn():
            # test
            yield 1
            return 1
    '''
    tree = parse(code)
    pprint(tree)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)


# Generated at 2022-06-12 03:58:55.139476
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # return 5 in generator
    source = """
    def fn():
        yield 1
        return 5
    """
    expected_source = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    module = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(module)
    actual_source = astor.to_source(module)
    assert actual_source == expected_source


# Generated at 2022-06-12 03:58:56.268600
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import round_trip


# Generated at 2022-06-12 03:58:57.860013
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:59:07.147190
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn1():
        yield 1
        return 1

    def fn2():
        yield 1
        return

    def fn3():
        yield 1
        return 1

    def fn4():
        yield 1

    def fn5(a):
        yield 1
        return a

    def fn6(a):
        yield 1
        return a

    def fn7(a):
        yield 1


# Generated at 2022-06-12 03:59:13.544058
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    new_tree = transformer.visit(tree)
    assert ast.dump(new_tree) == expected



# Generated at 2022-06-12 03:59:14.417479
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:59:17.438952
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''
    def example():
        yield 1
        def inner():
            yield 2
            return 3
        return 4
    '''
    result_code, _ = _test_example(code, ReturnFromGeneratorTransformer)

# Generated at 2022-06-12 03:59:25.348508
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    import astunparse.unparser as astunparse

    class ModuleVisitor(ast.NodeVisitor):
        def __init__(self):
            self.result = []

        def visit_Module(self, node):
            self.result = [node.body]

    class DummyNode(object):
        pass

    class DummyFunctionDef(DummyNode):
        def __init__(self, body):
            self.body = body
            self.args = DummyNode()

    def _create_return(value):
        return DummyNode(value=value)

    def _create_yield(value):
        return DummyNode(value=value)

    def _create_assign(targets, value):
        return DummyNode(targets=targets, value=value)



# Generated at 2022-06-12 03:59:30.260074
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Do not modify!
    source = "def fn(): yield 1; return 5"
    expected_result = "def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc"
    output = ReturnFromGeneratorTransformer().visit(ast.parse(source))
    assert ast.unparse(output) == expected_result


# Generated at 2022-06-12 03:59:38.778427
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test 1
    snippet1 = """
        def fn():
            yield 10
            return 5
    """  # type: str
    expected1 = """ 
        def fn():
            yield 10
            exc = StopIteration()
            exc.value = 5
            raise exc
    """  # type: str
    ast_before1 = ast.parse(snippet1)
    ast_after1 = ast.parse(expected1)
    transformer1 = ReturnFromGeneratorTransformer()
    res1 = transformer1.visit(ast_before1)
    assert res1 == ast_after1

    # Test 2
    snippet2 = """
        def fn():
            for x in range(10):
                yield x
    """  # type: str
    ast_before2 = ast.parse(snippet2)
    ast_