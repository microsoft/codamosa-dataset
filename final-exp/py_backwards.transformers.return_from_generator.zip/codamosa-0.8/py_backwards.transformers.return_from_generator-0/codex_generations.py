

# Generated at 2022-06-12 03:50:58.938217
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:02.203090
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from astunparse import unparse as py_unparse

# Generated at 2022-06-12 03:51:11.021265
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_node
    from ..utils.compare_ast import compare_asts, wrap_in_fn

    # Test with function with yield statement with no returns
    transformer = ReturnFromGeneratorTransformer()
    node = get_node("""
    def test():
        yield 1
    """)
    expected_node = get_node("""
    def test():
        yield 1
    """)
    actual_node = transformer.visit(node)
    assert compare_asts(expected_node, actual_node)

    # Test with zero arguments function with yield statement with return
    transformer = ReturnFromGeneratorTransformer()
    node = get_node("""
    def test():
        a = 1
        yield a
        return a + 1
    """)

# Generated at 2022-06-12 03:51:21.738538
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .context import Context
    from ..utils.source import source

    source = source('''
        def fn():
            yield 1
            return 5
    ''')
    actual = source.tree.body[0]
    transformer = ReturnFromGeneratorTransformer(Context(source=source))
    expected = transformer.visit(actual)

    assert actual.body[0].value.n == 1
    assert expected.body[0].value.n == 1
    assert actual.body[1].value.n == 5
    assert len(expected.body) == 3
    assert isinstance(expected.body[1], ast.Assign)
    assert isinstance(expected.body[2], ast.Raise)

# Generated at 2022-06-12 03:51:33.478005
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    return_from_generator_transform_example = ast.FunctionDef(
        name = 'return_value_example',
        args = ast.arguments(
            args = [],
            vararg = None,
            kwonlyargs = [],
            kw_defaults = [],
            kwarg = None,
            defaults = []
        ),
        body = [
            ast.Yield(
                value = ast.Num(n=1)
            ),
            ast.Return(
                value = ast.Num(n=5)
            ),
            ast.Return(
                value = ast.Num(n=5)
            )
        ],
        decorator_list = [],
        returns = None
    )


# Generated at 2022-06-12 03:51:41.744592
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.fake import Fake, fake_ast


# Generated at 2022-06-12 03:51:44.042693
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 2
        return 2


# Generated at 2022-06-12 03:51:54.667832
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .utils.visitor_test import check_visitor, test_node
    from .utils.grok_test import test_ast

    @test_ast
    def test_simple_generator():
        def fn():
            yield 1
            return 1

    @test_ast
    def test_generator_with_return_inside():
        def fn():
            yield 1
            if True:
                return 1
            yield 2

    @test_ast
    def test_generator_inside_generator():
        def fn():
            yield 1
            if True:
                def fn2():
                    yield 2
                    return 2
                yield from fn2()
            yield 3

    @test_ast
    def test_simple_fn():
        def fn(arg):
            if arg:
                return 1


# Generated at 2022-06-12 03:52:03.184829
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from .base import get_ast_from_source
    from ..utils import debug

    source = """
        def fn1():
            yield 1
            return 2
    """

    expected = """
        def fn1():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
    """
    BaseNodeTransformer().get_ast_from_source(source)

    expected_ast, expected_code = BaseNodeTransformer().get_ast_from_source(expected)
    transformer = ReturnFromGeneratorTransformer()
    ast_ = transformer.get_ast_from_source(source)
    assert transformer.tree_changed is True
    debug(ast_, expected_ast)
    assert ast_ == expected_ast

# Generated at 2022-06-12 03:52:09.853944
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer().visit_FunctionDef(parse("""
        def test():
            return 5
    """).body[0]) == parse("""
        def test():
            return 5
    """).body[0]

    assert ReturnFromGeneratorTransformer().visit_FunctionDef(parse("""
        def test():
            yield 5
            return 6
    """).body[0]) == parse("""
        def test():
            yield 5
            exc = StopIteration()
            exc.value = 6
            raise exc
    """).body[0]


# Generated at 2022-06-12 03:52:15.633433
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:28.959508
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    transformer = ReturnFromGeneratorTransformer()

    func_node = ast.parse(textwrap.dedent("""
        def fn():
            yield 1
            return 2
        """))
    expected = ast.parse(textwrap.dedent("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        """))
    assert transformer.visit(func_node) == expected
    assert transformer._tree_changed is True

    func_node = ast.parse(textwrap.dedent("""
        def fn():
            for i in range(10):
                yield i
            return 42
        """))

# Generated at 2022-06-12 03:52:30.025018
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:31.288166
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse, fix_missing_locations
    from astunparse import unparse
    import astor
    import copy

    # Test case 1

# Generated at 2022-06-12 03:52:33.964606
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:40.096891
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    code = """
    def foo():
        yield 1
        return 5
    """
    expected_code = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = ast.parse(code)

    actual_node = ReturnFromGeneratorTransformer().visit(node)

    expected_node = ast.parse(expected_code)

    assert ast.dump(actual_node) == ast.dump(expected_node)



# Generated at 2022-06-12 03:52:44.549492
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass
    # TODO: completely rework

    # tree = ast.parse('def fn():\n\tyield 1\n\treturn 5')
    # transformer = ReturnFromGeneratorTransformer(tree)
    # transformer.run()
    # assert tree == ast.parse(get_data('generator_return_function.py'))

# Generated at 2022-06-12 03:52:50.761218
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def fn():
            yield 1
            return 5
    """

    expected_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """

    node = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(node)
    actual_code = compile(node, '', 'exec')
    exec(actual_code)
    assert inspect.getsource(fn) == expected_code

# Generated at 2022-06-12 03:52:56.638473
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test 1: Check if transformer really changes the AST tree
    assert_changed = lambda fn: assert_equal(ReturnFromGeneratorTransformer.transform_snippet(fn), True)

    # Case 1.1: Test that the snippet is not transformed
    assert_not_changed = lambda fn: assert_equal(ReturnFromGeneratorTransformer.transform_snippet(fn), False)
    assert_not_changed(lambda: 'a')
    assert_not_changed(lambda: [])

    # Case 1.2: Test that the snippet is transformed
    assert_changed(lambda: (yield 1))
    assert_changed(lambda: return_value)
    assert_changed(lambda: if_else_else)
    assert_changed(lambda: while_else)
    assert_changed(lambda: for_else)

# Generated at 2022-06-12 03:53:09.194139
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest

    code_gen = "def foo():\n    yield 1" + return_from_generator.snippet
    expected = "def foo():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"
    code = "def foo():\n    yield 1\n    return 5"

    module = ast.parse(code)
    node = module.body[0]
    r = ReturnFromGeneratorTransformer().visit(node)

    class TestReturnFromGeneratorTransformer_visit_FunctionDef(unittest.TestCase):
        def test_return_from_generator(self):
            self.assertEqual(ast.dump(r), code_gen)

    TestReturnFromGeneratorTransformer_visit_FunctionDef().test_return_

# Generated at 2022-06-12 03:53:21.838671
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    func_def_input = ast.FunctionDef(
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[],
        ),
        body=[
            ast.Expr(
                value=ast.Yield(
                    value=ast.Num(
                        n=1
                    )
                )
            ),
            ast.Return(
                value=ast.Num(
                    n=5
                )
            )
        ],
        decorator_list=[],
        name='fn',
        returns=None,
        type_comment=None
    )


# Generated at 2022-06-12 03:53:33.168972
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """
    Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    """
    def check(func_by_code, func_by_ast, test_id):
        """

        :param func_by_code:
        :param func_by_ast:
        :param test_id:
        """
        func_by_code = ast.fix_missing_locations(func_by_code)
        func_by_ast = ast.fix_missing_locations(func_by_ast)
        __transformer = ReturnFromGeneratorTransformer()
        __transformer.visit(func_by_code)
        assert ast.dump(func_by_code) == ast.dump(func_by_ast), test_id
    # simple function without generators

# Generated at 2022-06-12 03:53:40.440582
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import js_to_py, py_to_js

    source = """\
    def func():
        yield 1
        return 2
    """
    expected = """\
    def func():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    tree = js_to_py(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    assert expected == py_to_js(tree)

# Generated at 2022-06-12 03:53:42.398634
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:46.909301
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from .common_transformer_test import get_common_transformer_test_function

    test_function = get_common_transformer_test_function(
        lambda: ReturnFromGeneratorTransformer(),
        lambda target, version: target[:2] == version[:2],
    )
    test_function(
        '''
        def fn():
            yield 1
            return 5
        '''
    )
    test_function(
        '''
        def fn():
            if True:
                yield 1
            return 5
        '''
    )
    test_function(
        '''
        def fn():
            for x in y:
                yield 1
            return 5
        '''
    )

# Generated at 2022-06-12 03:53:58.917824
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from .base import BaseNodeTransformerTestCase
    from .base import BaseNodeTransformerWithVariablesTestCase

    class Test(BaseNodeTransformerTestCase):
        def test_generator_with_tuple_assign(self):
            """Used to crash the transformer."""
            code = '''
            def fn():
                a, (b, c) = 1
                yield b
                return c
            '''
            node = parse(code)
            ReturnFromGeneratorTransformer().visit(node)
            self.assertEqual(node.body[0].body[0].value.elts[0].value, 3)

        def test_no_yield(self):
            code = '''
            def fn():
                return 1
            '''

# Generated at 2022-06-12 03:54:08.452190
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Example of code to be transformed
    code = 'def fn():\n    yield 1\n    return 42'
    add_import_module_to_env('typed_ast.ast3', globals())

    # Call the method
    node = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(node)
    assert node is not None

    # Check the result
    expected_code = 'def fn():\n    yield 1\nexc = StopIteration()\nexc.value = 42\nraise exc'
    generated_code = node_to_str(node.body[0])
    assert generated_code == expected_code

# Generated at 2022-06-12 03:54:17.040341
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:28.359583
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Tests case when function has generator returns with return values
    # Method being tested:
    #   visit_FunctionDef
    # Tested AST node and its direct children:
    #   FunctionDef(
    #       name='fn',
    #       body=[
    #           Expr(
    #               value=Yield(value=Num(n=1))
    #           ),
    #           Return(
    #               value=Num(n=5)
    #           )
    #       ],
    #       args=arguments(
    #           args=[],
    #           vararg=None,
    #           kwonlyargs=[],
    #           kw_defaults=[]
    #       ),
    #       decorator_list=[],
    #       returns=None
    #   )
    ast_node = ast.parse

# Generated at 2022-06-12 03:54:31.860433
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astor.code_gen import to_source
    from ..utils.python_source import get_func_content


# Generated at 2022-06-12 03:54:51.337914
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:52.240353
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:57.366095
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    sample_code = """
    def foo():
        return 1
    """
    # Creating an AST from the code
    root = ast.parse(sample_code)

    # Optimizing the AST
    new_ast = return_from_generator_transformer.visit(root)

    # The optimized code is equal to the original code
    optimzed_code = astor.to_source(new_ast)
    assert optimzed_code == sample_code



# Generated at 2022-06-12 03:55:00.659706
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3 as ast
    from ..utils.testing import BasicTestCase

    class ReturnFromGeneratorTransformerTest(BasicTestCase):
        TRANSFORMER = ReturnFromGeneratorTransformer
        FILENAME = __file__

    ReturnFromGeneratorTransformerTest.generate()

# Generated at 2022-06-12 03:55:06.858596
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing_utils import assert_equal_ast

    source = """
            def hello():
                a = 5
                yield b
                yield c
                return a
            """
    expected = """
            def hello():
                a = 5
                yield b
                yield c
                exc = StopIteration()
                exc.value = a
                raise exc
            """
    module = ast.parse(source)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module)
    assert_equal_ast(module, expected)

# Generated at 2022-06-12 03:55:13.838774
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.ast_helpers import parse_ast, dump
    from ..utils.compare_ast import compare_ast

    code = """
    def fn():
        yield 1
        return 4
    """

    result = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 4
        raise exc
    """

    module = parse_ast(code)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module)

    assert compare_ast(dump(module), result)



# Generated at 2022-06-12 03:55:15.326006
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3 as ast


# Generated at 2022-06-12 03:55:26.559356
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestSource:
        def foo():
            yield 1
            return 1
        def foo1():
            yield 1
            return 1
            yield 2
            return 2
        def foo2():
            yield 1
            return 1
            return 2
        def foo3():
            yield 1
            while True:
                yield 1
                if True:
                    yield 3
                    return 1
                else:
                    yield 3
                    return 3
                return 3
                yield 4
                return 4
        def foo4():
            yield from []
            return 1
        def foo5():
            return 1
        def foo6():
            yield 1
            return
        def foo7():
            yield from bar()
            return
        def bar():
            yield from foo7()
        def foo8():
            yield from bar()
            raise StopIteration()


# Generated at 2022-06-12 03:55:30.958291
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """\
    def fn():
        yield 1
        return 5
    """
    expected = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    result = ReturnFromGeneratorTransformer().visit(tree)
    assert ast.dump(result) == expected



# Generated at 2022-06-12 03:55:35.339129
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .generator_base import GeneratorBaseTransformer
    from ..utils.source import get_func_body
    from .import_fixer import ImportFixerTransformer
    from ..utils.fixer_util import FixerError


# Generated at 2022-06-12 03:55:59.400336
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        if 1:
            yield 1
        if 2:
            return 5
        else:
            return 5 if 6 else 7
        yield 5 if 6 else 7
        return 5 if 6 else 7

    compiled = compile(fn.__code__, '', mode='exec')
    root = ast.parse(compiled)

# Generated at 2022-06-12 03:56:06.343255
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import Return, Yield, FunctionDef
    target = ReturnFromGeneratorTransformer().visit(  # type: ignore
        FunctionDef(None, "fn", None, None, [Yield(None), Return(None)])
    )
    expected = ReturnFromGeneratorTransformer().visit(  # type: ignore
        FunctionDef(None, "fn", None, None, [Yield(None),
            ReturnFromGeneratorTransformer().visit(  # type: ignore
                return_from_generator.get_body(None)[0]
            )
        ])
    )
    assert target == expected

# Generated at 2022-06-12 03:56:12.583560
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3 as ast
    from ..utils.source import source
    from ..utils.fixtures import simple_generator_fn
    code = simple_generator_fn.format(expr='x = "spam"')
    tree = ast.parse(source(code))
    node = tree.body[0]
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)
    assert source(tree) == simple_generator_fn.format(expr='exc.value = "spam"')

# Generated at 2022-06-12 03:56:18.074421
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    code = 'def fn(): yield 5; return 1'
    expected_code = '\n'.join(
        [
            'def fn():',
            '    yield 5',
            '    exc = StopIteration()',
            '    exc.value = 1',
            '    raise exc',
        ],
    )
    root = ast.parse(code)
    assert astunparse.unparse(root) == expected_code

# Generated at 2022-06-12 03:56:27.499284
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:30.944034
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    in_ = r"""
    def fn():
        yield 123
        return 321
    print(123)
    """
    out = r"""
    def fn():
        yield 123
        exc = StopIteration()
        exc.value = 321
        raise exc
    print(123)
    """

    deep_equal(transform(in_, ReturnFromGeneratorTransformer), out)



# Generated at 2022-06-12 03:56:43.023085
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_string_1 = """
        def foo():
            yield 1
            return 2
    """
    test_string_2 = """
        def foo(bar, baz):
            a = bar
            yield a
            try:
                a = baz
            except:
                a = 1
            finally:
                yield a
                return a
    """
    test_string_3 = """
        def foo():
            try:
                a = 1
                yield a
                return a
            except:
                yield 2
            finally:
                return 3
    """
    test_string_4 = """
        def foo():
            for x in [1, 2, 3]:
                yield x
            return 4
    """
    test_string_5 = """
        async def foo():
            yield 1
            return 2
    """

# Generated at 2022-06-12 03:56:51.963086
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer().visit(
        ast.parse('def fn(): yield 1')
    ) == ast.parse('def fn(): yield 1')

    assert ReturnFromGeneratorTransformer().visit(
        ast.parse('def fn(): yield 1; return 4')
    ) == ast.parse('def fn(): yield 1; exc = StopIteration(); exc.value = 4; raise exc')

    assert ReturnFromGeneratorTransformer().visit(
        ast.parse('def fn():\n    yield 1\n    return 4\n    print(4)')
    ) == ast.parse('def fn():\n    yield 1\n    exc = StopIteration(); exc.value = 4; raise exc\n    print(4)')


# Generated at 2022-06-12 03:56:52.889381
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:59.962359
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..compiler import Transformer
    from .base import BaseTransformerTest

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)  # type: ignore
    transformer = Transformer({ReturnFromGeneratorTransformer})
    tree = transformer.visit(tree)  # type: ignore

    class Test(BaseTransformerTest):
        tree = tree
        expected = expected
        transformer = transformer

    return Test()



# Generated at 2022-06-12 03:57:44.301915
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..tests.fixtures import tree_builder
    from ..tests.utils import dump
    from ..utils.bfs import bfs
    source = """
    def fn():
        yield 1
        return 2
    """
    tree = tree_builder(source, __name__)
    ReturnFromGeneratorTransformer().visit(tree)

    assert dump(tree_builder(source, __name__), False) == dump(tree, False)



# Generated at 2022-06-12 03:57:49.722215
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:57:54.828960
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse('def f(x): return x')
    gen = ReturnFromGeneratorTransformer()
    gen.visit(tree)
    expected = ast.parse(
        'def f(x):\n'
        '    exc = StopIteration()\n'
        '    exc.value = x\n'
        '    raise exc'
    )
    ast.fix_missing_locations(tree)
    ast.fix_missing_locations(expected)
    assert ast.dump(tree) == ast.dump(expected)



# Generated at 2022-06-12 03:58:01.775854
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # simple case
    code1 = """def fn():
        yield 1
        return 2"""
    wanted1 = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 2
    raise exc"""

    # return only
    code2 = """def fn():
        return 1"""
    wanted2 = """def fn():
    return 1"""

    # return inside if
    code3 = """def fn():
        if True:
            return 1"""
    wanted3 = """def fn():
    if True:
        return 1"""

    t = ReturnFromGeneratorTransformer()
    for code, wanted in [(code1, wanted1), (code2, wanted2), (code3, wanted3)]:
        got = t.run(code)
        assert wanted == got



# Generated at 2022-06-12 03:58:05.900606
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_source

    node = ast.parse("""def fn():\n    yield 0\n    return 5""")
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    actual = ast.fix_missing_locations(node)
    expected = ast.parse("""def fn():\n    yield 0\n    exc = StopIteration()\n    exc.value = 5\n    raise exc""")
    assert_equal_source(actual, expected)



# Generated at 2022-06-12 03:58:07.138598
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:58:13.343579
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    f = ast.parse(
        'def fn():\n'
        '    yield 1\n'
        '    return 2\n'
    ).body[0]

    new_f = ReturnFromGeneratorTransformer().visit(f)
    assert ast.dump(new_f) == '\n'.join([
        'def fn():',
        '    exc = StopIteration()',
        '    exc.value = 2',
        '    raise exc',
    ])

# Generated at 2022-06-12 03:58:23.151680
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Set up mock
    node = mock.Mock()

    # Set up mock method '_find_generator_returns'
    base_node_transformer = ReturnFromGeneratorTransformer()
    base_node_transformer._find_generator_returns = mock.Mock()
    base_node_transformer._find_generator_returns.return_value = [(mock.Mock(), mock.Mock())]

    base_node_transformer._replace_return = mock.Mock()

    # Call tested method
    assert base_node_transformer.visit_FunctionDef(node) == node

    # Check calls to '_find_generator_returns', '_replace_return', 'generic_visit'
    assert base_node_transformer._find_generator_returns.call_count == 1


# Generated at 2022-06-12 03:58:33.219360
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..templates.template import template

    python_source = template('python3')

    def test(generator_source, expected):
        generator_source = generator_source.strip()
        expected = expected.strip()
        # Check that transform done correctly
        result = ReturnFromGeneratorTransformer().visit(ast.parse(generator_source))
        assert expected == python_source(result).strip()
        # Check that transform is idempotent
        result = ReturnFromGeneratorTransformer().visit(result)
        assert expected == python_source(result).strip()

    gen_vu = "def foo(): yield 1; return 1"
    expected_vu = "def foo(): yield 1; exc = StopIteration(); exc.value = 1; raise exc"
    test(gen_vu, expected_vu)


# Generated at 2022-06-12 03:58:39.946271
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..transpiler import Transpiler
    from ..utils.source_repr import source_repr
    from ..utils.ast_repr import ast_repr

    transpiler = Transpiler.from_str('def fn(): yield 1; return 1', from_version=PYTHON_VERSION)
    transpiler.transform(ReturnFromGeneratorTransformer)
    assert source_repr(transpiler.tree) == 'def fn(): yield 1; exc = StopIteration(); exc.value = 1; raise exc'

# Generated at 2022-06-12 04:00:27.723271
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def a():
            yield 1
            return 5
        def b():
            return 5
    """
    expected = """
        def a():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc


        def b():
            return 5
    """
    transform = ReturnFromGeneratorTransformer()
    new_tree = transform(ast.parse(code))
    print(ast.dump(new_tree))
    # TODO: consider making deep comparison with astnodes
    expected = astor.to_source(expected)
    actual = astor.to_source(new_tree)
    assert actual.strip() == expected.strip()

# Generated at 2022-06-12 04:00:36.541452
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test_input = """
        def test0():
            return
    
        def test1():
            yield 0
            y = yield 1
            return 2
    
        def test2():
            return 1
    
        def test3():
            yield 0
            yield from range(1, 5)
            return
    
        def test4():
            yield 0
            if True:
                yield 1
                return
    
        def test5():
            yield 0
            if True:
                return
    
        def test6():
            yield 0
            if True:
                yield 1
            else:
                yield 2
                return
    """

# Generated at 2022-06-12 04:00:41.374794
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transpiler = ReturnFromGeneratorTransformer()

    def fn():  # noqa
        yield 1
        return 2

    def fn2():  # noqa
        yield 1
        return 2
        return 3  # noqa

    node1 = ast.parse(inspect.getsource(fn))
    node2 = ast.parse(inspect.getsource(fn2))
