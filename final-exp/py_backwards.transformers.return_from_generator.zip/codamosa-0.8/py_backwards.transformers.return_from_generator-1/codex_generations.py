

# Generated at 2022-06-12 03:50:54.594774
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer"""
    # Construct a node.
    body = [ast.Yield(value=ast.Constant(value=1)), ast.Return(value=ast.Constant(value=5))]
    _ast = ast.FunctionDef(name='fn', args=ast.arguments(posonlyargs=[],
                                                         args=[],
                                                         vararg=None,
                                                         kwonlyargs=[],
                                                         kw_defaults=[],
                                                         kwarg=None,
                                                         defaults=[]),
                           body=body,
                           decorator_list=[],
                           returns=None)
    # Construct an instance of ReturnFromGeneratorTransformer.
    transformer = ReturnFromGeneratorTransformer()

    # Call method.


# Generated at 2022-06-12 03:51:00.570035
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    install_packages()
    from typed_ast import ast3 as ast
    from typed_ast.transforms import ReturnFromGeneratorTransformer

    transforms = ReturnFromGeneratorTransformer()
    test_code = dedent("""
        def foo():
            yield 3
            return
            yield 4
        def bar():
            yield 5
            return 4
            yield 6
        def baz():
            yield 10
            return 4

            # The following should not be transformed
            yield 11
            return
            yield 12
    """)

# Generated at 2022-06-12 03:51:05.324958
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from .code_gen import to_source
    from .base import BaseNodeTransformer
    from .compound_statements import CompoundStatementsTransformer
    from .literal_comparisons import LiteralComparisonsTransformer

# Generated at 2022-06-12 03:51:17.865199
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    fn = ast.FunctionDef(name='foo',
                         args=ast.arguments(args=[], defaults=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None,
                                            posonlyargs=[]),
                         body=[ast.Yield(value=ast.Constant(value=1)),
                               ast.Return(value=ast.Constant(value=5))],
                         decorator_list=[], returns=None)

# Generated at 2022-06-12 03:51:29.784033
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from .base import BaseNodeTransformerTestCase
    from .test_scope_hoist_variables import ScopeHoistVariablesTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase, ScopeHoistVariablesTransformerTestCase):
        TRANSFORMER = ReturnFromGeneratorTransformer
        BASE_NODE = ast3.FunctionDef
        # Template for generating python code of custom AST classes
        # embedded in a Python module.
        CODE_template = """\
            def fn():
                yield 1
                return 2
        """

        def test_function_transformed(self):
            # Test that the function was transformed
            node = self.transform_code()
            result = self.unparse_code(node)
            # Test that additional code was inserted

# Generated at 2022-06-12 03:51:35.313232
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def_test = "def test(): yield 1; return 5"
    expected = "def test(): yield 1; exc=StopIteration(); exc.value=5; raise exc"
    result = ReturnFromGeneratorTransformer().visit(ast.parse(def_test))
    assert(expected == astor.to_source(result).strip())

# Test if visit_FunctionDef do nothing if hasn't yield or return

# Generated at 2022-06-12 03:51:42.775691
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:48.877325
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # test with FunctionDef: def fn() -> None:
    def fn() -> None:
        yield 1
        return 5
    node = ast.parse(inspect.getsource(fn))

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    assert transformer._tree_changed == True
    assert transformer.generic_visit.__name__ == 'generic_visit'


# Generated at 2022-06-12 03:51:56.381360
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..tests.test_utils import parse, round_trip, transpile
    from .. import visitor

    source = """
    def test(name: str) -> str:
        yield 1
        return name
    """
    expected = """
    def test(name: str) -> str:
        yield 1
        exc = StopIteration()
        exc.value = name
        raise exc
    """

    module = parse(source)
    visitor.visit(module, ReturnFromGeneratorTransformer())
    round_trip(module, expected)
    assert transpile(source) == transpile(expected)

# Generated at 2022-06-12 03:52:05.757435
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast as pyast
    from ast_helpers.common import get_first_expression_from_source, \
        get_first_expression_from_ast_node
    from ast_helpers.matcher import match
    from ast_helpers.transformers import ReturnFromGeneratorTransformer

    pyast_node = get_first_expression_from_source(
        """
            def fn():
                yield 1
                return 5
        """
    )

    node = ReturnFromGeneratorTransformer().visit(pyast_node)

    expected_node = get_first_expression_from_source(
        """
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        """
    )

    assert match(node, expected_node) is None

# Generated at 2022-06-12 03:52:18.463049
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..common import get_ast
    from ..utils import get_code
    from typing import Generator

    code = get_code(test_ReturnFromGeneratorTransformer_visit_FunctionDef)

    ast_orig = get_ast(code)

    result = ReturnFromGeneratorTransformer().visit(ast_orig)
    assert astor.to_source(result) == get_code(test_ReturnFromGeneratorTransformer_visit_FunctionDef).replace('"""', '')

if __name__ == "__main__":
    test_ReturnFromGeneratorTransformer_visit_FunctionDef()

# Generated at 2022-06-12 03:52:31.549206
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    '''
    Test case to check if the return statements are transformed to yield
    statements.
    '''
    import astor

    def generator_fn():
        yield 1
        return 5

    test_node = ast.parse(inspect.getsource(generator_fn)).body[0]

    returned = ReturnFromGeneratorTransformer().visit(test_node)
    returned = astor.to_source(returned).strip()
    returned = "".join(returned.split("\n"))

    expected = """
        def generator_fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """.strip()

    expected = "".join(expected.split("\n"))
    assert returned == expected


# Generated at 2022-06-12 03:52:39.018100
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    test = ast.parse(textwrap.dedent(
        """
        def fn1():
            yield 1
            return 5
        """
    ))
    expected = ast.parse(textwrap.dedent(
        """
        def fn1():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    ))
    result = transformer.visit(test)
    assert ast.dump(result, include_attributes=False) == ast.dump(expected)

# Generated at 2022-06-12 03:52:39.624900
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:44.502911
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import compile_snippet
    from ..tree import cst as ast

    @compile_snippet(ReturnFromGeneratorTransformer, 3, 2)
    def compile_(fn):
        fn = """
            def fn():
                yield 1
                return 5
        """
        return fn

    assert isinstance(compile_(), ast.FunctionDef)

# Generated at 2022-06-12 03:52:48.264188
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from test.test_transformers import _test_ReturnFromGeneratorTransformer_visit_FunctionDef_Iterator
    cls = ReturnFromGeneratorTransformer
    _test_ReturnFromGeneratorTransformer_visit_FunctionDef_Iterator(cls)


# Generated at 2022-06-12 03:52:55.827018
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal
    from .base import BaseNodeTransformerTest
    class Test(BaseNodeTransformerTest):
        def test(self):
            src = """
            def fn():
                yield 1
                return 5
            """
            expected_program = """
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            """

            expected_program = compile(expected_program, '<string>', 'exec')
            actual_program = self.run_transformer(src)
            assert_programs_equal(expected_program, actual_program)

    Test().test()

# Generated at 2022-06-12 03:53:05.229003
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node_tree = ast.parse(
        """
        def fn():
            yield 1
            return 5
        """
    )

    expected_tree = ast.parse(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )

    result_tree = ReturnFromGeneratorTransformer().visit(node_tree)

    assert ast.dump(result_tree) == ast.dump(expected_tree)



# Generated at 2022-06-12 03:53:15.759233
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    new_node = ReturnFromGeneratorTransformer().visit_FunctionDef(
        ast.parse('def fn(): yield 1; return 5').body[0])

# Generated at 2022-06-12 03:53:23.897660
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from ..utils.visitor import Visitor
    source = """\
    def fn():
        yield 1
        return 5
    """
    node = ast.parse(source)
    node = Visitor.visit(node, ReturnFromGeneratorTransformer())

    expected = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    result = unparse(node).strip()
    assert result == expected


# Code generation for method _find_generator_returns of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:41.323609
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    node_expect_source = ast.parse('def fn(): yield 1\nexc = StopIteration()\nexc.value = 5\nraise exc')
    node_source = ast.parse('def fn(): yield 1\nreturn 5')
    node_expect = ReturnFromGeneratorTransformer().visit(node_expect_source)
    node = ReturnFromGeneratorTransformer().visit(node_source)

    # Assert
    assert_equals(node_expect, node)

# Generated at 2022-06-12 03:53:53.189072
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ... import ast_utils
    from ..utils.test_utils import generate_visitor_test

    module_node = ast_utils.parse('''
        def fn():
            if test:
                yield
            if test2:
                def foo():
                    return
            else:
                return
                yield
    ''')

    compiled_node = ast_utils.parse('''
        def fn():
            if test:
                yield
            if test2:
                def foo():
                    exc = StopIteration()
                    exc.value = None
                    raise exc

            else:
                exc = StopIteration()
                exc.value = None
                raise exc
                yield
    ''')

    test = generate_visitor_test(
        module_node, compiled_node, ReturnFromGeneratorTransformer)

# Generated at 2022-06-12 03:54:04.663369
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:05.345645
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:15.288849
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_programs_equal, get_program
    from ..utils.source import Source

    program = get_program(
        Source("""
        x = 5

        def foo():
            x = 5
            yield x
            return x

        def bar():
            yield x

        def baz():
            return x
        """)
    )

    expected = get_program(
        Source("""
        x = 5

        def foo():
            x = 5
            yield x
            exc = StopIteration()
            exc.value = x
            raise exc

        def bar():
            yield x

        def baz():
            return x
        """)
    )

    node_transformed = ReturnFromGeneratorTransformer().visit(program)

# Generated at 2022-06-12 03:54:17.550618
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:54:25.743364
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    code_snippet = '''
            def fn():
                yield 1
                return 2
    '''
    # Act
    root = ast.parse(code_snippet)
    transformer = ReturnFromGeneratorTransformer()
    new_root = transformer.visit(root)
    code = str(new_root)

    # Assert
    assert transformer.tree_changed == True
    assert code == '''def fn():
    yield 1
    exc = StopIteration()
    exc.value = 2
    raise exc'''



# Generated at 2022-06-12 03:54:32.334159
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse

    # This form of generator had appeared in a real world project and caused
    # bugs when compiled with Python 2.7
    #
    # If `return_` statement is changed to `return` code will be compiled
    # with Python 2.7 as a regular generator, not a generator that can
    # return a value.

# Generated at 2022-06-12 03:54:33.382123
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:45.821359
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:06.954312
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    code = '''
        def fn():
            yield 1
            return 5
            yield 2
            return 6
            yield 3
    '''

    wanted_ast = ast.parse('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            yield 2
            exc = StopIteration()
            exc.value = 6
            raise exc
            yield 3
    ''')

    tree = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()
    tree = transformer.visit(tree)

    assert transformer._tree_changed
    assert ast.dump(tree) == ast.dump(wanted_ast)



# Generated at 2022-06-12 03:55:17.297609
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3

    # Without returns
    @snippet
    def test():
        def fn():
            yield 1
    test_ast = ast3.parse(test.source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(test_ast)
    new_source = str(new_ast)
    assert new_source == test.source

    # With returns
    @snippet
    def test():
        def fn():
            yield 1
            return 5
    test_ast = ast3.parse(test.source)
    transformer = ReturnFromGeneratorTransformer()
    new_ast = transformer.visit(test_ast)
    new_source = str(new_ast)
    assert new_source == test.expected_source

    # With nested statements

# Generated at 2022-06-12 03:55:18.573657
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:19.213471
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:27.120808
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def fn():\n'
                     '    yield 1\n'
                     '    return 5\n')
    actual = ReturnFromGeneratorTransformer().visit(node)
    expected = 'def fn():\n'  \
               '    yield 1\n' \
               '    exc = StopIteration()\n' \
               '    exc.value = 5\n' \
               '    raise exc\n'
    expected = ast.parse(expected).body[0]
    assert ast.dump(actual) == ast.dump(expected)  # type: ignore

# Generated at 2022-06-12 03:55:33.604672
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    expected_ast = ast.parse("def fn_1():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc").body[0]

    node_to_be_tested = ast.parse("def fn_1():\n    yield 1\n    return 5").body[0]

    transformed_ast = ReturnFromGeneratorTransformer().visit_FunctionDef(node_to_be_tested)

    # TODO: Make comparison of nodes working again
    return None



# Generated at 2022-06-12 03:55:44.124266
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_not_equal_ast
    from ..utils.test_utils import parse
    transformer = ReturnFromGeneratorTransformer()
    assert_equal_ast(
        transformer.visit(parse('def fn(): yield 1')),
        parse('def fn(): yield 1', transformer.target)
    )
    assert_equal_ast(
        transformer.visit(parse('def fn(): yield 1; return 5')),
        parse('def fn(): yield 1; exc = StopIteration(); exc.value = 5; raise exc', transformer.target)
    )
    assert_equal_ast(
        transformer.visit(parse('def fn(): yield 1; return')),
        parse('def fn(): yield 1; return', transformer.target)
    )


# Generated at 2022-06-12 03:55:54.396371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test:
        """Check that when 'return' is found in generator, it's replaced with
        'exc = StopIteration(); exc.value = return_value; raise exc'.
        """
        input_ = lambda: 10
        expected_ = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''

    class Test2:
        """Check that 'return' is replaced only inside generators."""
        input_ = lambda: 10
        expected_ = '''
        def fn():
            return 5
        '''

    class Test3:
        """Check that 'return' is replaced only inside generators."""
        input_ = lambda: 10
        expected_ = '''
        def fn():
            yield 1
            return 5
        '''


# Generated at 2022-06-12 03:56:04.075793
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..tests.base import relative_to_this_test_folder
    from ..utils.ast_converter import AstConverter

    with open(relative_to_this_test_folder('generator.py')) as fd:
        source = fd.read()
    module = AstConverter([ReturnFromGeneratorTransformer]).convert_source(source)

    assert module is not None
    assert len(module.body) == 1

    initial_fn = module.body[0]
    assert isinstance(initial_fn, ast.FunctionDef)
    assert initial_fn.name == 'my_generator'

    assert len(initial_fn.body) == 7
    assert initial_fn.body[0] == ast.Global(names=['result_test'])

# Generated at 2022-06-12 03:56:10.766543
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_ast
    node = get_ast("""
        def fn():  # noqa
            yield 1
            return 2
    """)

    StopIteration = type('StopIteration', (Exception,), {})

    trans = ReturnFromGeneratorTransformer()
    trans.visit(node)

    exec(compile(node, filename='<unknown>', mode='exec'), {'StopIteration': StopIteration})

    y = fn()
    assert next(y) == 1
    with pytest.raises(StopIteration) as ei:
        next(y)

    assert ei.value.value == 2

# Generated at 2022-06-12 03:56:48.061266
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..ast_transformer import ASTTransformer
    res = ASTTransformer([ReturnFromGeneratorTransformer()]).visit(ast.parse("""
    def foo():
        yield 1
        return 2
    """))
    assert str(res) == """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """


# Generated at 2022-06-12 03:56:53.072551
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    snippet_result = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = ast.parse("""
    def fn():
        yield 1
        return 5
    """)

    new_node = ReturnFromGeneratorTransformer().visit(node)
    expected_node = ast.parse(snippet_result)

    assert ast.dump(new_node) == ast.dump(expected_node)


# Generated at 2022-06-12 03:57:02.113834
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .transformer_util import parse, compare_ast

    code = """
    def gen():
        yield
        return 5
    """
    expected_code = """
    def gen():
        yield
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = parse(code)
    ReturnFromGeneratorTransformer().visit(node)
    assert compare_ast(node, expected_code)

    code = """
    def fn():
        return 5
    """
    node = parse(code)
    ReturnFromGeneratorTransformer().visit(node)
    assert compare_ast(node, code)

    code = """
    def fn():
        yield 5
        return
    """
    node = parse(code)
    ReturnFromGeneratorTransformer().visit(node)
   

# Generated at 2022-06-12 03:57:09.569351
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert compile(ast.parse(
        'def fn():\n'
        '    yield 1\n'
        '    return 5\n'
    ), '', 'exec').co_consts[1] == 5

    tree = ast.parse(
        'def fn():\n'
        '    yield 1\n'
        '    return 5\n'
    )
    assert ReturnFromGeneratorTransformer().visit(tree) == ast.parse(
        'def fn():\n'
        '    yield 1\n'
        'exc = StopIteration()\n'
        'exc.value = 5\n'
        'raise exc\n'
    )

# Generated at 2022-06-12 03:57:18.233295
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestVisitor(ReturnFromGeneratorTransformer):
        def __init__(self, *args):
            super().__init__(*args)
            self.calls = 0

        def _find_generator_returns(self, node):
            self.calls += 1
            return [('1', '2')]

        def _replace_return(self, parent, return_):
            self.calls += 1

    args = (None, None, None)

    tree = ast.parse('def fn():\n    yield 1\n    return 5')
    visitor = TestVisitor(*args)
    visitor.visit(tree)

    assert tree._changed == True
    assert visitor.calls == 2



# Generated at 2022-06-12 03:57:20.050741
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def  _():
        def foo(x):
            yield 0
            y = x * x
            yield y
            return y



# Generated at 2022-06-12 03:57:29.216549
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..utils.snippet import snippet

    @snippet
    def before():
        def fn():
            yield 1
            return 2

    @snippet
    def after():
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc

    node = ast.parse(before())
    ReturnFromGeneratorTransformer().visit(node)
    assert astor.to_source(node) == after()

    @snippet
    def before():
        def fn():
            yield 1
            return 2

    node = ast.parse(before())
    ReturnFromGeneratorTransformer().visit(node)
    assert astor.to_source(node) == after()

    @snippet
    def before():
        def fn():
            yield

# Generated at 2022-06-12 03:57:32.844373
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    assert ReturnFromGeneratorTransformer.run_on_code(fn) == expected

# Generated at 2022-06-12 03:57:39.160911
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """\
    def fn():
        yield 1
        return 5
    """
    expected = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = ast.parse(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)  # type: ignore
    assert ast.dump(tree) == ast.dump(ast.parse(expected))


# Generated at 2022-06-12 03:57:41.399371
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import unwrap_location_tracker, round_trip


# Generated at 2022-06-12 03:59:11.139441
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 2
    fn_ast = ast.parse(fn.__doc__)
    fn_node = fn_ast.body[0]

    transformer = ReturnFromGeneratorTransformer()
    fn_node = transformer.visit(fn_node)
    fn_ast.body[0] = fn_node

    exec(compile(fn_ast, '', mode='exec'))

    generator = fn()

    assert next(generator) == 1
    with pytest.raises(StopIteration) as excinfo:
        next(generator)

    assert excinfo.value.value == 2

    def fn():
        yield 1
        yield 2
        return 3
    fn_ast = ast.parse(fn.__doc__)
    fn_node = fn_ast.body[0]



# Generated at 2022-06-12 03:59:12.068232
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:59:17.606086
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.annotations import assert_ast_node
    from .stringify import stringify
    from ..utils.utils import get_ast

    t = ReturnFromGeneratorTransformer()
    test_module = get_ast('def fn():\n    yield 3\n    return 5')

    t.visit(test_module)
    assert_ast_node(stringify(test_module), 'def fn():\n    yield 3\n    exc = StopIteration()\n    exc.value = 5\n    raise exc')


# Generated at 2022-06-12 03:59:20.257142
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer, get_source_from_node, get_node_from_source


# Generated at 2022-06-12 03:59:30.387775
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astmonkey import transformers
    transformer = transformers.ReturnFromGeneratorTransformer()

    ##########
    # Setup #
    ##########
    class FunctionDefStub(object):
        def __init__(self):
            self.body = [None, None]

        def __repr__(self):
            return "FunctionDefStub()"

    class ReturnStub(object):
        def __init__(self):
            self.value = None

        def __repr__(self):
            return "ReturnStub()"

    class YieldFromStub(object):
        def __init__(self):
            self.value = None

        def __repr__(self):
            return "YieldFromStub()"


# Generated at 2022-06-12 03:59:38.258732
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from typed_ast import ast3

    # Python code
    code = '''
    def fn():
        yield 1
        return 5
    '''

    # Python AST
    tree = ast3.parse(code)

    # Expectations as snippet-style code
    expectations = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''

    # Applying ReturnFromGeneratorTransformer
    node_transformer = ReturnFromGeneratorTransformer()
    tree = node_transformer.visit(tree)
    tree = ast3.fix_missing_locations(tree)

    # Compare expectations with actual results
    assert ast3.dump(tree) == expectations


# Generated at 2022-06-12 03:59:39.985026
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ...utils.test_utils.snippet import assert_equal_source


# Generated at 2022-06-12 03:59:47.566099
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("def f():\n  yield 1\n  return 2").body[0]
    assert isinstance(node, ast.FunctionDef)

    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)
    assert isinstance(node, ast.FunctionDef)

    body = node.body
    assert isinstance(body, list)
    assert len(body) == 4
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[1], ast.Expr)
    assert isinstance(body[2], ast.Assign)
    assert isinstance(body[3], ast.Raise)

# Generated at 2022-06-12 03:59:55.865561
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_source():
        def fn():
            yield 1  # noqa

            if False:
                return None

            yield 'foo'
            return 7

        def fn_normal():
            yield 2
            return 2
    # Test result
    def test_target():
        def fn():
            yield 1  # noqa

            if False:
                return None

            yield 'foo'
            exc = StopIteration()
            exc.value = 7
            raise exc

        def fn_normal():
            yield 2
            return 2
    # Apply transform
    result = ReturnFromGeneratorTransformer().visit(ast.parse(test_source))
    expected = ast.parse(test_target)

    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-12 04:00:01.223765
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from textwrap import dedent
    import astor
    tree = ast.parse(
        dedent('''
        def foo():
            yield 1
            return 5
        '''))
    trans = ReturnFromGeneratorTransformer()
    res = trans.visit(tree)

    assert astor.to_source(res) == dedent('''
        def foo():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''').strip()