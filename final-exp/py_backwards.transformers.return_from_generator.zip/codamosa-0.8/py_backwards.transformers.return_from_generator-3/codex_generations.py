

# Generated at 2022-06-12 03:50:58.655228
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .transform_generator import StatementTransformer
    from ..utils.tests import get_test_nodes, get_comparison_ast_tree, transform

    def comparison_func(node):
        for parent, return_ in ReturnFromGeneratorTransformer(None)._find_generator_returns(node):  # type: ignore
            ReturnFromGeneratorTransformer(None)._replace_return(parent, return_)
        return node

    nodes = get_test_nodes(test_ReturnFromGeneratorTransformer_visit_FunctionDef)
    StatementTransformer(None).visit(nodes[0])
    comparison_func(nodes[0])


# Generated at 2022-06-12 03:51:03.651960
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    def test_only_yield(source, expected):
        node = ast.parse(source)
        transformed = ReturnFromGeneratorTransformer().visit(node)
        assert ast.dump(transformed) == expected


# Generated at 2022-06-12 03:51:06.691044
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Mock(BaseNodeTransformer):
        def __init__(self) -> None:
            self.body: List[Tuple[Any, Any]] = []

# Generated at 2022-06-12 03:51:17.865086
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_module import apply_and_compare

    def transform_returns_in_generators(code: str) -> str:
        node = ast.parse(code)
        ReturnFromGeneratorTransformer().visit(node)
        return code[:node.body[0].body[2].col_offset+1] + \
               'exc = StopIteration()\n' + \
               'exc.value = 5\n' + \
               'raise exc'

    apply_and_compare(transform_returns_in_generators, """
        def fn():
            yield 1
            return 5""", """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc""")


# Generated at 2022-06-12 03:51:21.370946
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.example import example_function_def
    from ..utils.compat import nodemap
    from ..utils.parser import parse

    # Add a generator to function

    def fn_as_string():
        def fn():
            yield 1
            return 2

    tree = parse(fn_as_string.__code__)
    old_tree = deepcopy(tree)
    node = tree.body[0]
    new_node = ReturnFromGeneratorTransformer().visit(node)

    # Check if new node is a generator
    assert isinstance(new_node, ast.FunctionDef)
    assert new_node.__dict__ == node.__dict__
    assert nodemap(old_tree) == nodemap(tree)

# Generated at 2022-06-12 03:51:33.174324
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    def fn(a, b, c):
        yield 1
        return 5
    node = compile(fn, '<test_ReturnFromGeneratorTransformer_visit_FunctionDef>', 'exec', ast.PyCF_ONLY_AST)
    node = node.body[0] # fn

    tf = ReturnFromGeneratorTransformer()
    tf.visit(node)


# Generated at 2022-06-12 03:51:40.291290
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from ..utils.snippet import snippet
    from .utils import transform
    from .types import AnyFunctionDef

    source = snippet[AnyFunctionDef]
    source = source(
        fn_name="fn",
        has_yield=True,
        has_return=True
    )

    expected = snippet[AnyFunctionDef]
    expected = expected(
        fn_name="fn",
        has_yield=True,
        has_return=False,
        has_exception=True
    )

    tree = transform(ReturnFromGeneratorTransformer, source)

    assert unparse(tree) == expected

# Generated at 2022-06-12 03:51:50.684612
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import transforms_to
    import typed_astunparse  # type: ignore
    from . import unparse

    @transforms_to("\ndef fn() -> int:\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc")
    def _():
        def fn():
            yield 1
            return 5

    @transforms_to("\ndef fn() -> int:\n    yield 1")
    def _():
        def fn():
            yield 1

    @transforms_to("\ndef fn():\n    pass")
    def _():
        def fn():
            pass



# Generated at 2022-06-12 03:51:51.191051
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    pass

# Generated at 2022-06-12 03:51:56.188638
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.testing import assert_equal_ast

    tree = ast.parse(
        """
        def fn():
            yield 1
            return 5
        """
    )

    tree = ReturnFromGeneratorTransformer().visit(tree)

    assert_equal_ast(
        tree,
        ast.parse(
            """
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            """
        )
    )



# Generated at 2022-06-12 03:52:07.953887
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_ReturnFromGeneratorTransformer_visit_FunctionDef0():
        s = """def foo(): return 5"""
        tree = ast.parse(s)
        parsed_code_tree = ReturnFromGeneratorTransformer(tree).visit()
        assert ast.dump(tree) == ast.dump(parsed_code_tree)
    def test_ReturnFromGeneratorTransformer_visit_FunctionDef1():
        s = """def foo():
            yield 1
            if True:
                return 5"""
        expected = """def foo():
            yield 1
            if True:
                exc = StopIteration()
                exc.value = 5
                raise exc"""
        tree = ast.parse(s)
        parsed_code_tree = ReturnFromGeneratorTransformer(tree).visit()

# Generated at 2022-06-12 03:52:13.293779
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    test_function_def = ast.parse("""
    def test_function():
        yield 5
        yield 6

        return 5

    """)
    ast.fix_missing_locations(test_function_def)
    transformer.visit(test_function_def)

# Generated at 2022-06-12 03:52:16.345677
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from ..utils.testing import MockNodeTransformer, assert_node_unchanged

# Generated at 2022-06-12 03:52:21.081563
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:30.843821
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    node = ast.parse(textwrap.dedent('''
    def fn():
        yield 1
        return 5
    '''))
    expected_result = ast.parse(textwrap.dedent('''
    def fn():

        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''))

    node = ReturnFromGeneratorTransformer().visit(node)

    assert ast.dump(node) == ast.dump(expected_result)



# Generated at 2022-06-12 03:52:40.983004
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:50.715357
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source

    from typed_ast import ast3 as ast

    gen_fn = source('''
        def fn():
            yield 1
            return 5
        ''')[0]
    node = ast.parse(gen_fn)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    # pylint:disable=unidiomatic-typecheck
    assert type(node.body[0].body[1]) is ast.Assign
    assert type(node.body[0].body[2]) is ast.Expr
    assert type(node.body[0].body[3]) is ast.Raise
    # pylint:enable=unidiomatic-typecheck

    assert node.body[0].body[1].value.id == 'exc'

# Generated at 2022-06-12 03:52:56.621720
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base import BaseNodeTransformerTest
    class Test(BaseNodeTransformerTest):
        T = ReturnFromGeneratorTransformer

        def test_without_yield(self):
            code = """
                def fn():
                    return 5
            """
            result = self.transform(code)
            assert result == code

        def test_with_yield(self):
            code = """
                def fn():
                    yield 1
                    return 5
            """
            result = self.transform(code)
            expected = """
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
            """
            assert result == expected


# Generated at 2022-06-12 03:53:05.489956
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import assert_code_equal
    func_def = ast.parse('def fn(): yield 1; return 5').body[0]
    transformed = ReturnFromGeneratorTransformer().visit(func_def)
    assert_code_equal(
        dedent('''
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
            '''),
        ast.fix_missing_locations(transformed)
    )

# Generated at 2022-06-12 03:53:08.832067
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from copy import deepcopy

    from ast_tools.passes import FunctionDefPass, ApplyPass
    from ast_tools.transformers.return_from_generator import ReturnFromGeneratorTransformer
    from ast_tools.utils import parse

    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = parse(source)
    FunctionDefPass(
        ReplaceWith(
            lambda node: node.name == 'fn',
            tree.body[0]
        )
    ).visit(tree)

    transformed = ApplyPass(ReturnFromGeneratorTransformer()).visit(deepcopy(tree))

    assert transformed == parse(expected), transformed

# Generated at 2022-06-12 03:53:22.892157
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.syntax import node_to_str as n2s
    from .. import transforms
    from .base import NodeTransformer
    from .test_base_transformer import TestTransformer

    class TestTransformer(NodeTransformer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.count = 0

        def visit_FunctionDef(self, node):
            self.count += 1
            return node

    class TestTransforms(TestTransformer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)


# Generated at 2022-06-12 03:53:29.753612
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astunparse import unparse
    from .. import transform

    source = """
    def foo():
        yield 1
        return 1
    """

    expected_source = """
    def foo():
        yield 1
        let(exc)
        exc = StopIteration()
        exc.value = 1
        raise exc
    """

    module = transform(ast.parse(source), ReturnFromGeneratorTransformer)
    assert unparse(module) == expected_source

# Generated at 2022-06-12 03:53:40.932730
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    result = transformer(
        ast.parse(
            "def fn(): "
            "    yield 1\n"
            "    return 5"
        )
    )


# Generated at 2022-06-12 03:53:47.571244
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    actual = ast.parse('''
    def fn():
        yield 1
        return 5
    ''')

    expected = ast.parse('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

    node = ReturnFromGeneratorTransformer().visit(actual)
    assert ast.dump(node) == ast.dump(expected), 'Should compile return statement in generator to exception'


# Generated at 2022-06-12 03:53:59.659124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse('''
        def generator_function_with_return():
            yield 1
            return 2

        def generator_function_without_return():
            1 + 1
            return 2

        def function_without_yield_with_return():
            1 + 1
            return 2

        def function_without_yield_without_return():
            1 + 1
        ''')
    transformer.visit(tree)

# Generated at 2022-06-12 03:54:06.586413
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def f():
            yield 1
            return 2 + 5
    """
    expected = """
        def f():
            yield 1
            exc = StopIteration()
            exc.value = 2 + 5
            raise exc
    """
    node = ast.parse(source)
    node = ReturnFromGeneratorTransformer().visit(node)  # type: ignore
    actual = ast.unparse(node)
    assert actual == expected

# Generated at 2022-06-12 03:54:15.985558
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import json

    class _ReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def __init__(self):
            super().__init__()
            self.node_json: List[str] = []

        def visit(self, node):
            self.node_json.append(json.dumps(ast.dump(node), indent=4))
            return super().visit(node)

    def _test(input: str, output: str, *, add_brackets=True):
        if add_brackets:
            input = 'def fn():\n' + input.replace('\n', '\n    ')

        output = 'def fn():\n' + output.replace('\n', '\n    ')

        tree = ast.parse(input)
        transformer = _ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:54:17.677953
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:18.803154
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

# Generated at 2022-06-12 03:54:31.188121
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # Test 1: no return in function
    node1 = ast.Module([
        ast.FunctionDef(
            name='fn',
            args=ast.arguments(
                args=[],
                vararg=None,
                kwonlyargs=[],
                kw_defaults=[],
                kwarg=None,
                defaults=[]
            ),
            body=[
                ast.Expr(value=ast.Name(id='yield', ctx=ast.Load())),
                ast.Expr(value=ast.Name(id='1', ctx=ast.Load()))
            ],
            decorator_list=[],
            returns=None
        )
    ])


# Generated at 2022-06-12 03:54:52.242998
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """\
    def fn():
        yield 1
        return 5"""
    expected_ast = ast.parse(
        """\
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc"""
    )
    assert ast.dump(expected_ast) == ast.dump(
        ReturnFromGeneratorTransformer().visit(ast.parse(source))
    )



# Generated at 2022-06-12 03:54:53.006372
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:01.032816
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # First test case with a yield statement
    test_body = """
    def fn():
        yield 1
        return 5
    """
    node = ast.parse(test_body).body[0]
    expected = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """).body[0]
    transformer = ReturnFromGeneratorTransformer(tree=None)
    result = transformer.visit(node)
    assert ast.dump(result) == ast.dump(expected)

    # Second test case, with no yield statement
    test_body = """
    def fn():
        return 1
    """
    node = ast.parse(test_body).body[0]
    expected = node

# Generated at 2022-06-12 03:55:03.359966
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..visitor import Visitor
    from ..utils.get_ast import get_ast
    from ..utils.test_helper import compare_source


# Generated at 2022-06-12 03:55:13.073242
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    method_name = 'visit_FunctionDef'
    visit_method = getattr(transformer, method_name, None)
    def test_case(test_in, test_out):
        assert visit_method(test_in) == test_out
    test_in = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    test_out = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    test_case(test_in, test_out)
    test_in = ast.parse("""
        def fn():
            yield 1
            return 5
            yield 6
    """)

# Generated at 2022-06-12 03:55:18.958440
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """\
    def foo():
        yield 1
        return 5
    """

    result_code = """\
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(node)
    assert_equal_pycode(node, result_code)

# Generated at 2022-06-12 03:55:29.105141
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(
        """
        def foo():
            a = 1
            yield a
            b = 2
            if a:
                return 1
            try:
                return 2
            except Exception:
                return 3
            finally:
                return 4

        def bar():
            return 4

        def foo2():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )  # type: ast.Module


# Generated at 2022-06-12 03:55:40.557717
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    node = ast.parse(
        """
        def f():
            yield 1
            return 7
            """
    )  # type: ignore
    new_node = transformer.visit(node)  # type: ignore

    assert transformer._tree_changed
    assert isinstance(new_node, ast.Module)
    assert isinstance(new_node.body[0], ast.FunctionDef)
    assert isinstance(new_node.body[0].body[0], ast.Expr)
    assert isinstance(new_node.body[0].body[0].value, ast.Yield)
    assert new_node.body[0].body[1].value.n == 7
    assert new_node.body[0].body[1].col_offset == 5



# Generated at 2022-06-12 03:55:50.742124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.python import parser
    import jinja2
    from .base import BaseNodeTransformer

    snippet_tmpl = jinja2.Template("""
    from ..utils.snippet import snippet

    @snippet
    def snippet_fn():
        {{ code }}
    """)
    # TODO: refactor this test to use test.py.context
    def test_function(original_code, transformed_code):
        original_ast = parser.parse(original_code)
        node_transformer = ReturnFromGeneratorTransformer()
        transformer_cls = BaseNodeTransformer.get_transformer_class_for_version(
            node_transformer.target)


# Generated at 2022-06-12 03:55:52.194305
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:25.354002
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def assert_code_equal(code1, code2):
        module1 = ast.parse(code1)
        module2 = ast.parse(code2)
        assert ast.dump(module1) == ast.dump(module2)


# Generated at 2022-06-12 03:56:30.700815
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MockAst:
        pass

    node = MockAst()
    node.body = []
    returner = MockAst()
    returner.value = None
    ret_parent = MockAst()
    ret_parent.body = [returner]
    node.body.append(ret_parent)
    fn = ReturnFromGeneratorTransformer()
    new_node = fn.visit_FunctionDef(node)
    assert new_node.body[0].body == []

# Generated at 2022-06-12 03:56:42.310597
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor


# Generated at 2022-06-12 03:56:48.868089
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    source_tree = ast.parse(
        """
        def fn():
            yield 1
            return 5
        """
    )
    result_tree = ast.parse(
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    transformer.visit(source_tree)
    assert_equal(source_tree.body, result_tree.body)



# Generated at 2022-06-12 03:56:57.082495
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import typed_ast.ast3
    from ..transformers.manual.returns_from_generator import ReturnFromGeneratorTransformer
    import astor
    test = '''def func(x):
            yield 1
            return 5
        '''
    node = typed_ast.ast3.parse(test)
    ReturnFromGeneratorTransformer().visit(node)
    expected = '''def func(x):
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc
        '''
    expected_node = typed_ast.ast3.parse(expected)
    assert astor.to_source(node).strip() == astor.to_source(expected_node).strip()


# Generated at 2022-06-12 03:57:05.567969
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input_code = """
        def fn():
            yield 1
            return "hello"
    """
    output_code = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = "hello"
            raise exc
    """

    # Do not use assertWarns because of https://bugs.python.org/issue29672
    def fake_warn(msg: str) -> None:
        raise AssertionError(msg)
    import warnings
    old_showwarning = warnings.showwarning
    warnings.showwarning = fake_warn

    node = ast.parse(input_code)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    warnings.showwarning = old_showwarning
    assert transformer._tree_changed is True

# Generated at 2022-06-12 03:57:12.552229
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import parse
    from ..testing_utils import compare_to_native_function

    transformer = ReturnFromGeneratorTransformer()
    native = """
        def fn():
          def fn2():
            yield 1
            return 5
          return fn2()
    """
    typed = """
        def fn():
          def fn2():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
          return fn2()
    """

    compare_to_native_function(transformer, parse, typed, native, builtins)



# Generated at 2022-06-12 03:57:20.814118
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .optimize_unpacking_assign import OptimizeUnpackingAssignTransformer
    from ..testing_utils import assert_transform, assert_transform_before_opt
    from ..testing_utils import assert_transform_unchanged, assert_tree

    from_source = lambda src: ast.parse(src, '<string>')
    to_source = lambda tree: ast.unparse(tree).strip()
    transformer = ReturnFromGeneratorTransformer(is_optimizing=False)

    assert_transform(
        transformer,
        """
        def fn1():
            yield 1
            return 2
        """,
        """
        def fn1():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        """
    )


# Generated at 2022-06-12 03:57:30.254387
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer_REPLACEMENT_MARKER

    transformer = ReturnFromGeneratorTransformer()
    method = transformer.visit_FunctionDef
    module = ast.parse('def fn():\n    yield 1\n    return 5')
    body = list(module.body[0].body)
    assert len(body) == 2
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[1], ast.Return)
    assert body[1].value.n == 5

    result = method(module.body[0])
    body = list(result.body)
    assert len(body) == 4
    assert isinstance(body[0], ast.Expr)
    assert isinstance(body[1], ast.Assign)

# Generated at 2022-06-12 03:57:38.714996
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from .transpile import Transpiler

    transpiler = Transpiler()
    tree = ast3.parse(open('backend/compiler/tests/samples/return_from_generator.py').read())

    transformer = ReturnFromGeneratorTransformer(tree=tree)
    transformer.visit(tree)

    code = transpiler.visit(tree)
    expected_code_path = 'backend/compiler/tests/samples/return_from_generator_expected_output.py'
    with open(expected_code_path) as fp:
        expected_code = fp.read()

        assert code == expected_code

# Generated at 2022-06-12 03:59:06.771455
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Class used for testing
    class Test:
        def function1(self):
            yield 1
        def function2(self):
            yield 1
            return 5
        def function3(self):
            yield 1
            return
        def function4(self):
            yield 1
            return None
        def function5(self):
            yield 1
            return 5
            return 6
        def function6(self):
            for i in range(4):
                yield i
            return 5
        def function7(self):
            for i in range(4):
                yield i
                return 5
            return 6
        def function8(self):
            for i in range(4):
                yield i
                return 5
                return 6
        def function9(self):
            yield from range(4)
            return 5
        # Multiple yield


# Generated at 2022-06-12 03:59:12.325137
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..test_utils.test_node_factory import node_to_str

    def to_str(x):
        return node_to_str(x, indent=4, sort_keys=True, trailing_commas=True,
                           no_parens=True, no_type_comments=True, no_type_commits=True)


# Generated at 2022-06-12 03:59:19.480275
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer."""
    tree = ast.parse(
        "def fn():\n"
        "    yield 1\n"
        "    return 5\n"
    )

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)


# Generated at 2022-06-12 03:59:20.517085
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:59:21.280805
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:59:30.303004
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def check(code, expected):
        module = ast.parse(code)
        assert type(module) is ast.Module
        assert len(module.body) == 1
        assert type(module.body[0]) is ast.FunctionDef

        transformer = ReturnFromGeneratorTransformer()
        transformed_node = transformer.visit(module)

        expected_module = ast.parse(expected)
        assert type(expected_module) is ast.Module
        assert len(expected_module.body) == 1
        assert type(expected_module.body[0]) is ast.FunctionDef

        assert ast.dump(transformed_node) == ast.dump(expected_module)


# Generated at 2022-06-12 03:59:34.023139
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    t = ReturnFromGeneratorTransformer()
    test_node = ast.parse(
        "def func(x):\n"
        "    yield 1\n"
        "    return x")
    assert t._tree_changed == False
    t.visit(test_node)
    assert t._tree_changed == True


# Generated at 2022-06-12 03:59:41.281898
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # source
    code = """
    def ret():
        yield 1
        return 2
    """

    # expected result
    expected = """
    def ret():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """

    # create transformer
    transformer = ReturnFromGeneratorTransformer()

    # parse code
    root = ast.parse(textwrap.dedent(code))

    # transform code
    new_root = transformer.visit(root)  # type: ignore

    # check if root nodes are equal
    assert ast.dump(new_root) == textwrap.dedent(expected)

# Generated at 2022-06-12 03:59:49.952684
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    module_node = ast.parse(fn.__code__.co_consts[0])
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(module_node)
    exec(compile(module_node, filename="<ast>", mode="exec"))

    # Test the generator without stopping it by itself
    g = fn()
    assert next(g) == 1
    with pytest.raises(StopIteration) as exc:
        next(g)
    assert exc.value.value == 5

    # Test the generator stopping itself
    g = fn()
    assert next(g) == 1
    with pytest.raises(StopIteration) as exc:
        g.send(None)
    assert exc.value.value == 5


# Generated at 2022-06-12 03:59:50.880725
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer