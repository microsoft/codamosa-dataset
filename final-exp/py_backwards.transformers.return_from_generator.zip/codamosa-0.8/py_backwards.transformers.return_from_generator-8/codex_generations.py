

# Generated at 2022-06-12 03:50:54.837862
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn1():
        yield 1
        return 5

    def fn2():
        yield 1
        yield 2
        return 5

    def fn3():
        yield 1
        if True:
            return 5
        else:
            return 6

    def fn4():
        yield 1
        return 5
        yield 2

    def fn5():
        return 5

    def fn6():
        yield from [1]

    def fn7():
        yield from [1]
        return 5

    node1 = ast.parse(inspect.getsource(fn1)).body[0]
    node2 = ast.parse(inspect.getsource(fn2)).body[0]
    node3 = ast.parse(inspect.getsource(fn3)).body[0]

# Generated at 2022-06-12 03:51:00.723096
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    t = ReturnFromGeneratorTransformer()
    assert t.visit_FunctionDef(ast.parse('def foo(): return 1').body[0]) == ast.parse('def foo(): raise StopIteration()\n').body[0]
    assert t.visit_FunctionDef(ast.parse('def foo(): yield 1').body[0]) == ast.parse('def foo(): yield 1\n').body[0]
    assert t.visit_FunctionDef(ast.parse('def foo(): yield 1\n return 2').body[0]) == ast.parse('def foo(): yield 1\n exc = StopIteration()\n exc.value = 2\n raise exc\n').body[0]

# Generated at 2022-06-12 03:51:01.979817
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:08.816617
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import ToTestingTransform

    code = '''
    def foo():
        yield 1
        return 2
    '''
    module = ast.parse(code)
    ToTestingTransform().visit(module)

    expected = '''
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    '''

    module = ReturnFromGeneratorTransformer().visit(module)
    module = ToTestingTransform().visit(module)

    assert expected == module

# Generated at 2022-06-12 03:51:16.663081
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..ast_utils import dump
    from .test_base import BaseNodeTransformerTest
    import textwrap

    class Test(BaseNodeTransformerTest):
        target_transformer = ReturnFromGeneratorTransformer
        target_version = (3, 2)

        def _test_equal_ast(self, before, after):
            """Test equality of ast.AST after and before transformation.
            """
            self.assertEqual(
                dump(before), dump(after)
            )

    tests = []


# Generated at 2022-06-12 03:51:22.381178
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    @snippet
    def before():
        def fn():
            yield 1
            return 5

    after = return_from_generator.call_and_capture(return_value=5)

    transformer = ReturnFromGeneratorTransformer(before)
    transformer.visit(before)

    assert str(after) == transformer.get_source()

# Generated at 2022-06-12 03:51:31.055234
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    expected_ast = ast.parse(
        'def foo():\n'
        '    yield 1\n'
        '    exc = StopIteration()\n'
        '    exc.value = 5\n'
        '    raise exc\n'
    )

    tested_ast = ast.parse(
        'def foo():\n'
        '    yield 1\n'
        '    return 5\n'
    )

    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(tested_ast)
    assert (result) == (expected_ast)

# Generated at 2022-06-12 03:51:40.324948
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:43.020092
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:51:44.928549
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import parse_to_ast, assert_source_equal

# Generated at 2022-06-12 03:51:52.631831
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import source_to_uncompyle_ast
    from ..utils.test_utils import node_to_str
    from ..utils.test_utils import assert_equal_with_printing

# Generated at 2022-06-12 03:51:57.628707
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(unittest.TestCase):
        # Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
        def test_return_from_generator(self):
            source = """def fn():\n    yield 1\n    return 5"""
            expected = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""
            self.assertEqual(expected, tr.transform_source(source))
    return Test



# Generated at 2022-06-12 03:52:06.721863
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..ast_processing import get_ast
    from .ReturnInGeneratorTransformer import ReturnInGeneratorTransformer

    class Options:
        return_in_generator = True

    source = """
    def gen():
        yield 1
        return 5
    """
    mod, _ = get_ast(source, Options)
    assert mod is not None
    transform = ReturnInGeneratorTransformer()
    mod = transform.visit(mod)
    assert mod is not None
    transform = ReturnFromGeneratorTransformer()
    mod = transform.visit(mod)
    assert mod is not None


# Generated at 2022-06-12 03:52:12.532735
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    tree = ast.parse("""
    def fn():
        yield 1
        return 5
    """)
    final_tree = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)
    assert transformer.visit(tree) == final_tree


# Generated at 2022-06-12 03:52:13.182989
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:18.114687
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestArg(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            yield node.name
            return node.name

    class TestArg2(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            yield node.name
            return node.name
        def visit_arg(self, node: ast.arg) -> ast.arg:
            return node.arg

    class TestArg3(BaseNodeTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            return node.name
        def visit_arg(self, node: ast.arg) -> ast.arg:
            return node.arg

# Generated at 2022-06-12 03:52:28.594582
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .common import compile_from_ast, parse_ast_tree

    code = """
        def f():
            def f():
                return 1
            return 2
    """

    tree = parse_ast_tree(code)
    ReturnFromGeneratorTransformer().visit(tree)
    compile_from_ast(tree)

    code = """
        def f():
            def g():
                return 1
            yield 1
            return 2
    """

    tree = parse_ast_tree(code)
    ReturnFromGeneratorTransformer().visit(tree)
    compile_from_ast(tree)

# Generated at 2022-06-12 03:52:37.732830
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.unparse import Unparser
    from ..utils.visitor import dump


# Generated at 2022-06-12 03:52:41.531031
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    return_from_generator_transformer = ReturnFromGeneratorTransformer()
    module = ast.parse("""def f(a, b, c): if a: return b // (c + 5)""")
    function = module.body[0]
    return_from_generator_transformer.visit(function)
    assert str(function) == """def f(a, b, c):
    if a:
        exc = StopIteration()
        exc.value = (b // (c + 5))
        raise exc"""


# Generated at 2022-06-12 03:52:51.214721
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestTransformer(ReturnFromGeneratorTransformer):
        def __init__(self):
            super().__init__()
            self.tree_changed = False

        @property
        def tree_changed(self):
            return self._tree_changed

        @tree_changed.setter
        def tree_changed(self, value):
            self._tree_changed = value


# Generated at 2022-06-12 03:53:08.352456
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_utils import transform_and_compare
    from ..utils.source import source_to_unicode
    from astor.code_gen import to_source

    # Transform return in generator to exception raising

# Generated at 2022-06-12 03:53:09.291119
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:17.321360
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def f():
        yield 4
        return 7
    """
    tree = ast.parse(code)
    node = tree.body[0]  # type: ignore

    expected = """
    def f():
        yield 4
        exc = StopIteration()
        exc.value = 7
        raise exc
    """
    expected = ast.parse(expected).body[0]  # type: ignore

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)

    assert ast.dump(expected) == ast.dump(node)

# Generated at 2022-06-12 03:53:29.036876
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # A snippet of Python code
    snippet_code = """
        def function():
            yield 1
            return 5
    """
    # Expected transformed AST

# Generated at 2022-06-12 03:53:32.091521
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(BaseNodeTransformerTest):
        def create_transformer(self):
            return ReturnFromGeneratorTransformer()


# Generated at 2022-06-12 03:53:33.381637
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:44.382973
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # test without changes
    node = ast.parse('''
        def fn():
            yield from 1
        ''')
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    assert str(result) == str(node)
    assert transformer._tree_changed is False

    # test with changes
    node = ast.parse('''
        def fn():
            yield from 1
            return 5
        ''')
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(node)
    assert transformer._tree_changed is True
    expected = '''
        def fn():
            yield from 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    assert str(result) == expected

# Generated at 2022-06-12 03:53:48.850632
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    def fn():
        yield 1
        return 5

    original = ast.parse(fn.__code__.co_code)

    fn_node = original.body[0]


# Generated at 2022-06-12 03:53:58.864087
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .fixtures_transformer_classes import ReturnFromGeneratorTransformer_visit_FunctionDef
    from .fixtures_typed_ast import ast3_parse
    from transformers.ast_transformer import ASTTransformer
    transformer = ASTTransformer()
    transformer.add_transformer(ReturnFromGeneratorTransformer(target=(3, 2)))
    expected_ast = ast3_parse(ReturnFromGeneratorTransformer_visit_FunctionDef.expected_ast)
    tree_to_transform = ast3_parse(ReturnFromGeneratorTransformer_visit_FunctionDef.tree_to_transform)
    transformed_tree = transformer.transform(tree_to_transform)
    assert expected_ast == transformed_tree


# Generated at 2022-06-12 03:54:10.576959
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def assert_function_equal(func: ast.FunctionDef, expected_func: ast.FunctionDef) -> None:
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(func)
        assert ast.dump(func) == ast.dump(expected_func)

    p = ast.parse

    # Generator with yield and return
    func1 = p("""
        def fn():
            yield 1
            return 5
    """)
    expected_func1 = p("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    assert_function_equal(func1, expected_func1)

    # Generator with yield and return in try-finally will not be transformed

# Generated at 2022-06-12 03:54:31.500560
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    node_fn_def = ast.FunctionDef(
        name='fn',
        body=[
            ast.Return(value=ast.Num(2))
        ],
        args=ast.arguments(args=[], kwonlyargs=[], vararg=None, kwarg=None, kw_defaults=[], defaults=[]),
        returns=None,
        decorator_list=[],
        type_comment=None
        )


# Generated at 2022-06-12 03:54:33.786030
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import compare_ast
    from .base import BaseNodeTransformer


# Generated at 2022-06-12 03:54:35.032166
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:47.415970
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test function visit_FunctionDef from class FunctionDef"""
    from typed_astunparse import unparse
    from .base import BaseNodeTransformer
    from .cython_generator import CythonGeneratorTransformer
    from .lambda_lifting import LambdaLiftingTransformer
    from .inline_closure_call import InlineClosureCallTransformer
    from .nested_func_optimization import NestedFuncOptimizationTransformer
    from .count_constants import CountConstantsTransformer
    from .normalize_builtins import NormalizeBuiltinsTransformer
    from .pass_literals import PassLiteralsTransformer
    from .remove_asserts import RemoveAssertsTransformer
    from .simplify_comprehensions import SimplifyComprehensionsTransformer


# Generated at 2022-06-12 03:54:54.245329
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(func, expected):
        actual = ReturnFromGeneratorTransformer(None).visit_FunctionDef(func)  # type: ignore
        assert expected == actual.body

    # Compiling following code:
    #
    #   def fn():
    #       yield 1
    #       return 5
    #
    # To
    #
    #   def fn():
    #       yield 1
    #       exc = StopIteration()
    #       exc.value = 5
    #       raise exc
    #
    func = ast.FunctionDef(name='fn', body=[
        ast.Expr(value=ast.Yield(value=ast.Num(1))),
        ast.Return(value=ast.Num(5))
    ])
    return_from_generator_body = return_from_generator.get_body

# Generated at 2022-06-12 03:54:59.396530
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ast_raw = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    ast_expected = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    node = ast_raw.body[0]
    expected = ast_expected.body[0]
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(node) == expected

# Generated at 2022-06-12 03:55:01.293444
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Input
    input = '''def fn():
        yield 1
        return 5'''

    # Expected output

# Generated at 2022-06-12 03:55:10.713686
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from . import ast_convert
    from .ast_helpers import get_func
    from .ast_convert import to_src

    def test(src, expected):
        actual = to_src(ast_convert(get_func(src), ReturnFromGeneratorTransformer))
        assert actual == expected, f'{actual} != {expected}'

    test('''
    def fn():
        yield 1
        return 2
    ''', '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    ''')


# Generated at 2022-06-12 03:55:15.509118
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    tree = ast.parse(fn.__code__)

    ReturnFromGeneratorTransformer().run(tree)

    expected = ("""def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc""")

    assert ast.dump(tree) == expected

# Generated at 2022-06-12 03:55:16.988581
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .unparse import Unparser

# Generated at 2022-06-12 03:55:37.805515
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:39.251204
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:43.849910
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def gen():
        yield 1
        return 5

    node = ast.parse(inspect.getsource(gen))
    ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == cleandoc('''
        def gen():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc''')



# Generated at 2022-06-12 03:55:53.598625
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import MockNodeTransformer
    from ..utils.source import source_to_unicode
    from ..utils.file_io import read_file

    # :Given:
    test_data = {}
    for test_file in [
        '../tests/example_snippets/generator_with_return.py',
        '../tests/example_snippets/generator_with_return_with_docstring.py',
    ]:
        test_data[test_file] = {
            'original': source_to_unicode(read_file(test_file)),
            'transformed': source_to_unicode(read_file(test_file + '.fix')),
        }

    # :When:
    for test_file, test_case in test_data.items():
        MockNodeTransformer.reset()

# Generated at 2022-06-12 03:56:03.957558
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base import get_ast
    from ..utils.snippet import snippet

    node = get_ast('''
    def x():
        yield 1
        return y
    ''')

    expected = get_ast('''
    def x():
        yield 1
        exc = StopIteration()
        exc.value = y
        raise exc
    ''')

    assert node == expected

    node = get_ast('''
    def x():
        nonlocal z
        def y():
            return z
        yield 0
        return z
    ''')

    expected = get_ast('''
    def x():
        nonlocal z
        def y():
            return z
        yield 0
        exc = StopIteration()
        exc.value = z
        raise exc
    ''')

   

# Generated at 2022-06-12 03:56:08.878174
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
            yield 2
    """

    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            yield 2
    """
    node = ast.parse(source)

    ReturnFromGeneratorTransformer().visit(node)
    result = astunparse.unparse(node)

    assert expected == result

# Generated at 2022-06-12 03:56:10.317189
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.node_util import print_ast

# Generated at 2022-06-12 03:56:20.104867
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import FunctionDef, Return, Yield, YieldFrom

    def assert_generator_returns(code, ret_count, yf_count, y_count):
        root = parse(code)
        node_ret_count = len(list(root.body[0].body[0].body))
        node_yf_count = len([x for x in root.body[0].body[0].body if isinstance(x, YieldFrom)])
        node_y_count = len([x for x in root.body[0].body[0].body if isinstance(x, Yield)])
        assert node_ret_count == ret_count and node_yf_count == yf_count and node_y_count == y_count


# Generated at 2022-06-12 03:56:29.347188
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_base import BaseNodeTransformerTestCase, BaseNodeTransformerUnitTest


    class _(BaseNodeTransformerTestCase, BaseNodeTransformerUnitTest):
        transformer_type = ReturnFromGeneratorTransformer

        def test_simple_yield(self):
            @snippet
            def code():
                def fn():
                    yield 1
                    return 5

            self.assertCodeEqual(
                code,
                """
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
                """
            )

        def test_simple_yield_many_returns(self):
            @snippet
            def code():
                def fn():
                    yield 1
                    if True:
                        yield 2
                        return 3
                    else:
                        yield 9
                        return

# Generated at 2022-06-12 03:56:37.104425
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    from .test_base import BaseNodeTransformerTestCase

    source = '''
        def fn():
            yield 1
            return 5
    '''

    tree = parse(source)
    transformer = ReturnFromGeneratorTransformer()
    result = transformer.visit(tree)
    expected = parse(
        '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    )  # noqa

    assert_equals(result, expected)

# Generated at 2022-06-12 03:57:22.422260
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # python3 -m unittest -c tests.compilers.test_return_from_generator
    import unittest
    import astor
    from ..utils.snippet import snippet
    from ..utils.test_utils import compile_snippet, transform_and_compile
    from .remove_pass import RemovePassTransformer


# Generated at 2022-06-12 03:57:25.165933
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def _(fn):
        node = ast.parse(fn)
        transformer = ReturnFromGeneratorTransformer()
        return transformer.visit(node)

    # generator function with return inside

# Generated at 2022-06-12 03:57:32.129981
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import cst_to_ast, ast_to_cst

    def f():
        yield 1
        return 5
    tree = ast.parse(f'{f}')
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    result = ast_to_cst(tree)
    expected_cst = cst_to_ast(
        """
        def f():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """
    )
    assert result == expected_cst



# Generated at 2022-06-12 03:57:41.895098
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def Fn():
        yield 1
        return 5

    import typed_ast.ast3 as ast
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    transformer = ReturnFromGeneratorTransformer(1)
    node = ast.parse(source=inspect.getsource(Fn))
    transformer.visit(node)
    expected = ast.parse("""def Fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc""")
    assert ast.dump(node, annotate_fields=False, include_attributes=True) == \
           ast.dump(expected, annotate_fields=False, include_attributes=True)

# Generated at 2022-06-12 03:57:48.359634
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import unittest
    import astunparse

    class TestCase(unittest.TestCase):
        def test_find_generator_returns(self):
            transformer = ReturnFromGeneratorTransformer()
            function_def = ast.parse("""
                def fn():
                    yield 1
                    return 5
            """).body[0]
            assert transformer._find_generator_returns(function_def) == [
                (function_def, function_def.body[1]),
            ]

        def test_replace_return(self):
            transformer = ReturnFromGeneratorTransformer()
            function_def = ast.parse("""
                def fn():
                    yield 1
                    return 5
            """).body[0]
            transformer._replace_return(function_def, function_def.body[1])
            result = astun

# Generated at 2022-06-12 03:57:58.232524
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module = ast.parse(r'''
        def fn():
            if True:
                yield 1
                return 5
            return 6
    ''')
    with patch.object(ast, 'parse') as mock_parse:
        mock_parse.return_value = module
        transformer = ReturnFromGeneratorTransformer()
        new_module = transformer.visit(module)
    assert ast.dump(module) != ast.dump(new_module)

# Generated at 2022-06-12 03:58:07.565211
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    from . import set_up_and_invoke

    # Test for return0
    def return0():
        yield 1
        return 2

    got = set_up_and_invoke(ast.parse(inspect.getsource(return0)), ReturnFromGeneratorTransformer())

    def return0_expected():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc

    assert got == return0_expected()

    # Test for return1
    def return1():
        yield 1
        return 2
        x = 3

    got = set_up_and_invoke(ast.parse(inspect.getsource(return1)), ReturnFromGeneratorTransformer())

    def return1_expected():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
        x = 3

# Generated at 2022-06-12 03:58:09.145828
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-12 03:58:14.886295
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''\
    def fn():
        yield 1
        return 2
    ''').body[0]
    before = ast.dump(node)
    transformer = ReturnFromGeneratorTransformer()
    assert node == transformer.visit(node)
    after = ast.dump(node)
    assert before != after
    assert node.body[2].value.value.elts[0].value.value == '2'

# Generated at 2022-06-12 03:58:24.838248
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Method used in unit test
    def check_function(source, expected_source=None, expected_tree_changed=False):
        func = ast.parse(source).body[0]
        r = ReturnFromGeneratorTransformer()
        assert isinstance(func, ast.FunctionDef)
        new_func = r.visit(func)
        assert isinstance(new_func, ast.FunctionDef)
        assert r.tree_changed is expected_tree_changed
        generated = ast.unparse(new_func)
        if expected_source is None:
            expected_source = source
        assert generated == expected_source

    # check_function: no return in functions
    # (i.e.: check generator_returns is an empty list in _find_generator_returns)

# Generated at 2022-06-12 04:00:13.065218
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(ReturnFromGeneratorTransformer):
        def __init__(self):
            self._tree_changed = False

        def get_changed(self):
            return self._tree_changed

        def _replace_return(self, parent, return_):
            pass

    def check(code, expected_code, tree_changed=True):
        test = Test()
        result = test.visit(ast.parse(code))
        assert test.get_changed() == tree_changed
        assert ast.dump(result) == expected_code

    check('def a():\n    return 5', 'def a():\n    pass')

# Generated at 2022-06-12 04:00:22.472109
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    # Set of the path of python files that are going to be compiled
    files = set()

    # Append the name of the file to compile to the set of files
    files.add('test/fixtures/input/optional_typing.py')
    files.add('test/fixtures/input/nested.py')
    files.add('test/fixtures/input/multiple_decorators.py')
    files.add('test/fixtures/input/yield_from.py')
    files.add('test/fixtures/input/yield_from_with_return.py')
    files.add('test/fixtures/input/yield.py')
    files.add('test/fixtures/input/yield_with_return.py')

    # For each file in the set of files

# Generated at 2022-06-12 04:00:23.233338
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 04:00:29.454100
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .utils import update_expected
    from .test_remove_unnecessary_statements import test_RemoveUnnecessaryStatementsTransformer_visit_FunctionDef
    node = ast.parse(test_RemoveUnnecessaryStatementsTransformer_visit_FunctionDef.__doc__)
    updated_expected = update_expected(test_RemoveUnnecessaryStatementsTransformer_visit_FunctionDef.__doc__)
    ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == updated_expected



# Generated at 2022-06-12 04:00:35.742074
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformerTest
    import astunparse
    from copy import copy

    class Test(BaseNodeTransformerTest):
        target = ReturnFromGeneratorTransformer.target
        transformer = ReturnFromGeneratorTransformer
        filename = __file__

        def test_before_after(self):
            self.before_after()

        # error uncomment

        # def test_transform(self):
        #     self.transform()

    test = Test()
    test.test_before_after()
    # test.test_transform()

# Generated at 2022-06-12 04:00:43.791074
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def f1():
        yield 1

    def f2():
        yield 1
        return 5

    def f3():
        yield 1
        ret = f1()
        ret.send(None)
        return 10

    def f4():
        yield 1
        ret = f2()
        ret.send(None)
        return 10

    def f5():
        yield 1
        return

    def f6():
        yield
        return

    def f7():
        return

    def f8():
        yield 1
        x = yield 1
        yield x
        return

    def f9():
        yield
        return 1

    def f10():
        return 1

    def f11():
        yield 1