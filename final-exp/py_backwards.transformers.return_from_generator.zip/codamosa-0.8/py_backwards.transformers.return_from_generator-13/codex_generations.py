

# Generated at 2022-06-12 03:50:58.354290
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ast_tree = ast.parse(
        inspect.cleandoc('''
            def fn_with_many_returns():
                yield 1
                return 5
                yield 7
                return 10
                yield 15

            def fn_without_yield():
                return 5
                return 7
                return 10

            def fn_without_return():
                yield 5
                yield 7
                yield 10
        ''')).body

    fn_with_many_returns = ast_tree[0]
    fn_without_yield = ast_tree[1]
    fn_without_return = ast_tree[2]

    transformer = ReturnFromGeneratorTransformer()

    new_fn_with_many_returns = transformer.visit(fn_with_many_returns)
    new_fn_without_yield = transformer.visit

# Generated at 2022-06-12 03:51:01.644150
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    with patch('compileall.ReturnFromGeneratorTransformer._find_generator_returns', return_value=[('parent', 'return')]):
        with patch('compileall.ReturnFromGeneratorTransformer._replace_return') as mock:
            ast_tree = MagicMock()
            ast_tree.body = []
            ast_tree.returns = []
            ReturnFromGeneratorTransformer('root').visit_FunctionDef(ast_tree)
            assert mock.called
            mock.assert_called_with('parent', 'return')


# Generated at 2022-06-12 03:51:02.736019
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:11.299467
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    from typed_ast import ast3 as ast
    from ..fixer.typing import NodeTransformerWithTypingHints
    from ..fixer.transformers import ReturnFromGeneratorTransformer
    from ..fixer.utils.source import get_source
    from ..fixer.utils.source import set_source
    from ..fixer.utils.source import Source
    from ..fixer.utils.snippet import snippet_to_ast
    import sys

    code = """\
    def fn():
        yield 1
        return 5
    """

    expected_code = """\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    test_source = Source(code, 'test.py')

# Generated at 2022-06-12 03:51:23.461124
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..nodes import FunctionDef
    from ..utils.source import source_to_node
    from .identity_transformer import IdentityTransformer
    from .replace_strings_with_chars import ReplaceStringsWithCharsTransformer
    transformer = ReturnFromGeneratorTransformer(
        next(ReplaceStringsWithCharsTransformer(
            next(IdentityTransformer(
                source_to_node(
                    """
                    def fn():
                        yield 1
                        return 5
                    """
                ))))))
    modified = transformer.visit(transformer.node)  # type: ignore

# Generated at 2022-06-12 03:51:34.897853
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_compile(src):
        src = "def fn():\n" + "\n".join(["    " + x for x in src.splitlines()])
        tree = ast.parse(src)
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(tree)
        return tree

    assert test_compile("return 5") == ast.parse("def fn():\n    return 5")
    assert test_compile("yield 1\nreturn 5") == ast.parse(
        "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc")

# Generated at 2022-06-12 03:51:39.897668
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class TestReturnFromGeneratorTransformer_visit_FunctionDef(ReturnFromGeneratorTransformer):
        def __init__(self):
            self.visit_FunctionDef_called = 0

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            self.visit_FunctionDef_called += 1
            return super().visit_FunctionDef(node)


# Generated at 2022-06-12 03:51:46.119447
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    a = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    ReturnFromGeneratorTransformer().visit(a)

    b = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)
    assert a == b


# Generated at 2022-06-12 03:51:56.339849
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    function = ast.parse("""
      def fn():
          yield 1
          return 5
    """).body[0]
    transformer = ReturnFromGeneratorTransformer()
    transformed_function = transformer.visit(function)


# Generated at 2022-06-12 03:52:01.187427
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("def fn():\n    yield 1\n    return 5")
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    expected = "def fn():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"
    assert ast.dump(node) == expected


# Generated at 2022-06-12 03:52:16.204453
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer._test_generic_visit(
        """
            def fn():
                yield 1
                return 5
        """,
        """
            def fn():
                yield 1
                exc = StopIteration()
                exc.value = 5
                raise exc
        """
    )
    # Multiple returns.
    assert ReturnFromGeneratorTransformer._test_generic_visit(
        """
            def fn():
                yield 1
                if a:
                    return 5
                else:
                    return 6
        """,
        """
            def fn():
                yield 1
                if a:
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
                else:
                    exc = StopIteration()
                    exc.value = 6
                    raise exc
        """
    )
    # Has `

# Generated at 2022-06-12 03:52:28.750749
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Basic case
    a = """
        def fn():
            yield 1
            return 5
    """
    b = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    assert transform(a, ReturnFromGeneratorTransformer) == b

    # Ignore transpilation if there is no return inside a generator
    a = """
        def fn():
            yield 1
    """
    assert transform(a, ReturnFromGeneratorTransformer) == a

    # Ignore transpilation if there is no yield inside a generator
    a = """
        def fn():
            return 5
    """
    assert transform(a, ReturnFromGeneratorTransformer) == a


# Generated at 2022-06-12 03:52:30.324006
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import parse

# Generated at 2022-06-12 03:52:31.033919
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:31.995534
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse

# Generated at 2022-06-12 03:52:34.678268
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_node

    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-12 03:52:35.826774
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    t = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:52:43.904859
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import compile_all
    from .main import transform_ast

    def fn():
        yield 1
        return 5

    transformed = compile_all(fn)
    ast_tree = compile(str(transformed), '<test>', 'exec')
    transform_ast(ast_tree, ReturnFromGeneratorTransformer)

    # Check that return is transformed to exception raising.
    exc = StopIteration()
    exc.value = 5
    try:
        transformed()
    except StopIteration as e:
        assert e.value == 5
    else:
        raise AssertionError("Transformation to exception raising is wrong")


# Generated at 2022-06-12 03:52:44.980836
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:54.101304
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import Return, FunctionDef, Yield, Expr
    from .base import BaseNodeTransformer

    class TestNodeTransformer(BaseNodeTransformer):
        def __init__(self, *args, **kwargs):
            self._tree_changed = False

        def get_tree_changed(self):
            return self._tree_changed

    class TestReturn(Return):
        def __init__(self, *args, **kwargs):
            pass

    class TestFunctionDef(FunctionDef):
        def __init__(self, *args, **kwargs):
            pass

        def body(self):
            return []

    class TestYield(Yield):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-12 03:53:03.252880
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:53:08.439952
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTest
    from .base import make_snippet_op

    class ReturnFromGeneratorTest(BaseNodeTest):
        target_class = ReturnFromGeneratorTransformer

    ReturnFromGeneratorTest.rename_tests("test_visit_FunctionDef", globals())


# Generated at 2022-06-12 03:53:18.878190
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    class_ = ReturnFromGeneratorTransformer()
    node = ast.parse('''
        def fn():
            yield 1
            return 5 
    ''')
    # Act
    class_.visit(node)
    result = ast.dump(node)

    # Assert

# Generated at 2022-06-12 03:53:31.016580
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import parse
    tree = parse('''
        def fn():
            yield 5
            return 6
    ''')

    tree = ReturnFromGeneratorTransformer().visit(tree)


# Generated at 2022-06-12 03:53:42.295523
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast as python_ast
    import typed_ast.ast3 as typed_ast

    class Visitor(typed_ast.NodeVisitor):
        def generic_visit(self, node):
            assert False, f"{node.__class__.__name__} is not supported"

        def visit_Assign(self, node):
            self.visit(node.value)

        def visit_Return(self, node):
            assert node.value is None

        def visit_Expr(self, node):
            self.visit(node.value)

        def visit_Attribute(self, node):
            self.visit(node.value)

        def visit_Call(self, node):
            for arg in node.args:
                self.visit(arg)

# Generated at 2022-06-12 03:53:44.597744
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('def fn():\n yield 2\n return 2', mode='exec')

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)
    assert str(node) == 'def fn():\n yield 2\n exc = StopIteration()\n exc.value = 2\n raise exc'

# Generated at 2022-06-12 03:53:50.380756
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(input_code: str, output_code: str):
        output_node = compile(input_code, '<string>', 'exec')

        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(output_node)

        assert output_code == transformer.to_source()


# Generated at 2022-06-12 03:54:01.747016
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from . import magic_ast
    from .test_utils import assert_equal_ast

    def test_function_def(source, expected):
        assert_equal_ast(ReturnFromGeneratorTransformer(None), source, expected)

    # Empty function
    test_function_def('def fn():\n    pass', 'def fn():\n    pass\n')

    # Function without returns and yields
    test_function_def('def fn():\n    a = 1', 'def fn():\n    a = 1\n')

    # Function with return --> no changes
    test_function_def(
        'def fn():\n    a = 1\n    return 2',
        'def fn():\n    a = 1\n    return 2\n'
    )

    # Generator without returns and yields

# Generated at 2022-06-12 03:54:09.972639
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    src = """
    def fn():
        yield 1

        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    module = ast.parse(src)
    fn = module.body[0]
    module.body[0] = ReturnFromGeneratorTransformer().visit(fn)

    assert(compile(module, '<test>', 'exec') == compile(expected, '<test>', 'exec'))



# Generated at 2022-06-12 03:54:17.866008
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Check that compiler compiles generators like:
        def fn():
            yield 1
            return 5
    To:
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    import typing
    transformer = ReturnFromGeneratorTransformer()
    generator_function = ast.FunctionDef(
        name='fn',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwarg=None,
            defaults=[]
        ),
        body=[
            ast.Expr(value=ast.Yield(value=ast.Num(n=1))),
            ast.Return(value=ast.Num(n=5))
        ],
        decorator_list=[],
        returns=None
    )

# Generated at 2022-06-12 03:54:31.504045
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = 'def fn(): yield 1; return 2'
    tree = ast.parse(code)
    expected = 'def fn(): yield 1; exc = StopIteration(); exc.value = 2; raise exc'
    ReturnFromGeneratorTransformer().visit(tree)
    assert astor.to_source(tree) == expected

# Generated at 2022-06-12 03:54:37.985604
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    src = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(src)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    tree = ast.fix_missing_locations(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-12 03:54:46.685158
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import get_compiled_function_from_snippet

    code = """
    def fn():
        yield from range(5)
        return 6
    """
    snippet_body = """
    exc = StopIteration()
    exc.value = return_value
    raise exc
    """
    compiled_fn = get_compiled_function_from_snippet(
        code, ReturnFromGeneratorTransformer)
    assert snippet_body in compiled_fn.__code__.co_code.__str__()

# Generated at 2022-06-12 03:54:55.700273
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    # Function that does not contain yield statement
    module_node = ast.Module(body=[
        ast.FunctionDef(
            name='fn',
            args=ast.arguments(
                args=[ast.arg(arg='a', annotation=None)],
                vararg=None,
                kwonlyargs=[],
                kwarg=None,
                defaults=[],
                kw_defaults=[]
            ),
            returns=None,
            body=[
                ast.Return(value=ast.Num(n=5)),
                ast.Return(value=ast.Str(s='5'))
            ],
            decorator_list=[],
            returns=None
        )
    ])

    transformer = ReturnFromGeneratorTransformer()
    new_module_node = transformer.visit

# Generated at 2022-06-12 03:55:01.997528
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    transformer = ReturnFromGeneratorTransformer()
    ast_tree = ast.parse('def fn():\n    yield 1\n    return 5')
    expected = [
        'def fn():',
        '    yield 1',
        '    exc = StopIteration()',
        '    exc.value = 5',
        '    raise exc',
    ]

    # Act
    transformer.visit(ast_tree)

    # Assert
    lines = astor.to_source(ast_tree).split('\n')
    assert lines == expected

# Generated at 2022-06-12 03:55:07.637010
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    
    def check(before, after):
        # type: (str, str) -> None
        before_ast = ast.parse(before, mode='exec')
        after_ast = ast.parse(after, mode='exec')
        transformed_ast = ReturnFromGeneratorTransformer().visit(before_ast)
        assert astor.to_source(transformed_ast).strip() == astor.to_source(after_ast).strip()


# Generated at 2022-06-12 03:55:15.569346
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    @snippet
    def expected():
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc

    @snippet
    def snippet0():
        def fn():
            yield 1
            return 5

    # Verify test case
    node, _ = compile_snippet(snippet0)
    expected_node, _ = compile_snippet(expected)

    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit(node)

    assert_equivalent_node(new_node, expected_node)

# Generated at 2022-06-12 03:55:16.607222
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:55:24.386394
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(
        """def foo():
            return 1""",
        mode='exec'
    ).body[0]

    transformer = ReturnFromGeneratorTransformer(node)
    transformer.visit(node)

    assert ast.dump(node, include_attributes=False) == \
        "def foo():\n" \
        "    exc = StopIteration()\n" \
        "    exc.value = 1\n" \
        "    raise exc"


# Generated at 2022-06-12 03:55:25.035197
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:00.938027
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer().visit_FunctionDef(
        ast.parse(
            """
            def f():
                yield 1
                return 2
            """
        ).body[0]
    ) == ast.parse(
        """
        def f():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        """
    ).body[0]

# Generated at 2022-06-12 03:56:02.320258
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .function_def import FunctionDefTransformer


# Generated at 2022-06-12 03:56:09.206800
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing import assert_transformed

    class TestTransformer(ReturnFromGeneratorTransformer):
        def __init__(self):
            self._test_data = []  # type: List[Tuple[ast.stmt, ast.Return]]

        def _replace_return(self, parent: ast.stmt, return_: ast.Return) -> None:
            self._test_data.append((parent, return_))

    # If a function is not a generator returns it as is
    source = 'def fn(): pass\n'
    assert_transformed(TestTransformer, source)

    # If a function does not have returns it returns it as is
    source = 'def fn():\n    yield 1\n'
    assert_transformed(TestTransformer, source)

    # If a function is not a generator and it has returns it

# Generated at 2022-06-12 03:56:10.017969
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:19.746979
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:25.915170
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def fn():
            yield 5
            return 6
    """

    snippet = """
        def fn():
            yield 5
            exc = StopIteration()
            exc.value = 6
            raise exc
    """

    node = ast.parse(code)
    node = ReturnFromGeneratorTransformer().visit(node)
    result = ast.dump(node)
    result = textwrap.dedent(result)

    expected = textwrap.dedent(snippet)

    assert result == expected

# Generated at 2022-06-12 03:56:30.232400
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        return 5
    """
    expected = """
    def fn():
        return 5
    """

    node = ast.parse(code)  # type: ignore
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(node)  # type: ignore

    assert ast.dump(node) == expected



# Generated at 2022-06-12 03:56:36.821495
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    """It replaces yield-return statements with StopIteration-exception raising."""
    module = ast.parse("""
        def fn():
            yield 1
            return 5
    """)

    node = ReturnFromGeneratorTransformer().visit(module)


# Generated at 2022-06-12 03:56:47.349372
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import get_test_ast

    tree1 = ast.parse('def f(x):\n  return x')
    tree2 = ast.parse('def f(x):\n  yield x\n  return x')
    tree3 = ast.parse('def f(x):\n  for i in x:\n    return i')
    tree4 = ast.parse(
        'def f(x):\n  yield x\n  for i in x:\n    return i')
    tree5 = ast.parse(
        'def f(x):\n  yield x\n  for i in x:\n    if True:\n      return i')

    t = ReturnFromGeneratorTransformer()
    result1 = get_test_ast(t.visit(tree1))
    result2 = get_test

# Generated at 2022-06-12 03:56:54.461880
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Test method that visits FunctionDef ast node."""

    # Test function with return and yield
    def fn_with_yield_and_return():
        yield 1
        return 5

    # Test function with return
    def fn_with_return():
        return 5

    # Test function with yield
    def fn_with_yield():
        yield 1

    # Test function without yield and return
    def fn_without_yield_and_return():
        print()

    # Test function with comments
    def fn_with_comments():
        yield 1
        # return 5

    def visit_stmt(node):
        """Visit stmt node."""
        return_index = 0
        yield_index = 0
        fn_index = 0

# Generated at 2022-06-12 03:58:08.813257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:58:15.179639
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def original_generator():
        yield 4
        return 5

    def expected_generator():
        yield 4
        exc = StopIteration()
        exc.value = 5
        raise exc

    original_node = ast.parse(inspect.getsource(original_generator))
    expected_node = ast.parse(inspect.getsource(expected_generator))
    ReturnFromGeneratorTransformer().visit(original_node)
    assert ast.dump(original_node) == ast.dump(expected_node)

# Generated at 2022-06-12 03:58:19.054824
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert ReturnFromGeneratorTransformer().visit_all('''
    def foo():
        yield 2
        return 2
    ''') == '''
    def foo():
        yield 2
        exc = StopIteration()
        exc.value = 2
        raise exc
    '''

# Generated at 2022-06-12 03:58:28.387141
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.source import source_to_ast
    from ..utils.pyversion import assert_only_python_versions
    from .generator_compat import compare_source

    with assert_only_python_versions(3, 2, 3, 3):
        source = """
            def fn(a, b):
                if True:
                    yield 1
                else:
                    return 5
        """
        source_gen = """
            def fn(a, b):
                if True:
                    yield 1
                else:
                    exc = StopIteration()
                    exc.value = 5
                    raise exc
        """
        source_no_gen = """
            def fn(a, b):
                if True:
                    yield 1
                else:
                    return 5
        """
        ast_gen = source_to_ast(source_gen)

# Generated at 2022-06-12 03:58:29.252536
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:58:39.669915
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import string
    import random
    import ast as pyast

    from typed_ast.ast3 import FunctionDef as ASTFunctionDef
    from typed_ast.ast3 import Return as ASTReturn
    from typed_ast.ast3 import Yield as ASTYield
    from typed_ast.ast3 import Assign as ASTAssign
    from typed_ast.ast3 import Name as ASTName
    from typed_ast.ast3 import Load as ASTLoad
    from typed_ast.ast3 import Call as ASTCall
    from typed_ast.ast3 import Compare as ASTCompare
    from typed_ast.ast3 import If as ASTIf
    from typed_ast.ast3 import Str as ASTStr
    from typed_ast.ast3 import Num as ASTNum

    def generate_function_def(with_yield, with_return):
        function_def = AST

# Generated at 2022-06-12 03:58:45.876662
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    code = """
        def foo():
            print(1)
            def bar():
                print(3)
                return 5
            print(2)
        """
    expected = """
        def foo():
            print(1)
            def bar():
                print(3)
                exc = StopIteration()
                exc.value = 5
                raise exc
            print(2)
        """
    tree = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(tree)
    assert_code_equal(expected, tree)


# Generated at 2022-06-12 03:58:50.529112
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_ast, compare_ast

    source = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1

        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = get_ast(source)
    tree = ReturnFromGeneratorTransformer().visit(tree)
    compare_ast(tree, expected)



# Generated at 2022-06-12 03:58:55.823234
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(textwrap.dedent(
        """
        def func():
            yield 1
            return 4
        """
    ))

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(node)

    assert transformer._tree_changed is True
    assert ast.dump(node) == textwrap.dedent(
        """
        def func():
            yield 1
            exc = StopIteration()
            exc.value = 4
            raise exc
        """
    )



# Generated at 2022-06-12 03:58:56.349444
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer