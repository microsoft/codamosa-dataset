

# Generated at 2022-06-12 03:50:53.940525
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:02.254560
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse(textwrap.dedent('''
    def fn():
        yield 1

        if True:
            yield 1

        return 5
    '''))

    expected = ast.parse(textwrap.dedent('''
    def fn():
        yield 1

        if True:
            yield 1

        exc = StopIteration()
        exc.value = 5
        raise exc
    '''))

    actual = ReturnFromGeneratorTransformer().visit(node)

    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-12 03:51:11.061728
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Test for return_from_generator
    module = ast.parse("""
        from typing import Generator
    
        def fn() -> Generator[int, int, None]:
            yield 1
            return 5
        """)
    trans = ReturnFromGeneratorTransformer()
    expected_ast = ast.parse("""
        from typing import Generator
        def fn() -> Generator[int, int, None]:
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        """)
    unit_test_ast = trans.visit(module)
    assert ast.dump(unit_test_ast) == ast.dump(expected_ast)

    # Test for return_from_generator

# Generated at 2022-06-12 03:51:20.829588
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from astmonkey import transformers

    code = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = ast.parse(code)
    transformer = transformers.ReturnFromGeneratorTransformer()
    transformer.visit(node)
    result = compile(node, filename="", mode="exec")
    exec(result)

    assert fn().__next__() == 1
    assert fn().__next__() == 5

    assert ast.dump(node, include_attributes=True) == expected

# Generated at 2022-06-12 03:51:32.749392
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .remove_returns_with_no_value import RemoveReturnsFromGeneratorTransformer
    from .remove_returns_with_no_value import test_RemoveReturnsFromGeneratorTransformer_visit_FunctionDef
    from ..utils.source import source_to_ast, ast_to_source

    source = test_RemoveReturnsFromGeneratorTransformer_visit_FunctionDef()
    source = source.replace('return', 'yield', 1)

    ast_module = source_to_ast(source)

    ast_module.body[0].body.pop(0)

    ast_module = RemoveReturnsFromGeneratorTransformer().visit(ast_module)  # type: ignore
    ast_module = ReturnFromGeneratorTransformer().visit(ast_module)  # type: ignore


# Generated at 2022-06-12 03:51:37.820109
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # arrange
    class TestNode:
        def __init__(self, lineno):
            self.lineno = lineno

    class TestNodeList:
        def __init__(self, nodes):
            self.nodes = nodes

        def index(self, node):
            return self.nodes.index(node)

        def pop(self, index):
            self.nodes.pop(index)

        def insert(self, index, node):
            self.nodes.insert(index, node)

        def __len__(self):
            return len(self.nodes)

    parent = TestNodeList([
        TestNode(1),
        TestNode(2),
        TestNode(3),
        TestNode(4)
    ])
    return_ = TestNode(5)

# Generated at 2022-06-12 03:51:38.583263
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:47.027711
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer
    from astmonkey import transformers
    from ..utils import parse

    source = """
    def y():
        yield 1
        return 2
    """
    expected = """
    def y():
        yield 1
        exc = StopIteration()
        exc.value = (2,)
        raise exc
    """

    tree = parse(source)
    transformer = ReturnFromGeneratorTransformer(transformers())
    transformer.visit(tree)

    assert expected == ast.dump(tree, include_attributes=False)



# Generated at 2022-06-12 03:51:56.979017
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    def assert_transformed_code(before: str, after: str) -> None:
        tree = ast.parse(before)
        tree = ReturnFromGeneratorTransformer().visit(tree)
        trans_code = compile(tree, '<unknown>', 'exec')
        globs = {}
        locs = {}
        eval(trans_code, globs, locs)
        fn = locs['fn']
        assert fn() == (1, 2, 3, 5)

    assert_transformed_code(
        '''def fn():
            yield 1
            yield 2
            yield 3
            return 5''',
        '''def fn():
            yield 1
            yield 2
            yield 3
            exc = StopIteration()
            exc.value = 5
            raise exc'''
    )

    assert_transformed_code

# Generated at 2022-06-12 03:51:57.767076
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:08.004383
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    @snippet
    def src():
        def fn():
            yield 1
            return 2

    src_ = src()
    module = ast.parse(src_)  # type: ast.Module
    ReturnFromGeneratorTransformer().visit(module)

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """

    assert astor.to_source(module).strip() == expected.strip()

# Generated at 2022-06-12 03:52:08.677875
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:18.955094
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    code = '''
        def foo():
            for x in range(1, 10):
                if x % 2:
                    yield x
                else:
                    return x
    '''
    expected = '''
        def foo():
            for x in range(1, 10):
                if x % 2:
                    yield x
                else:
                    exc = StopIteration()
                    exc.value = x
                    raise exc
    '''
    tree = ast.parse(code)
    transformer.visit(tree)
    assert ast.dump(tree) == expected

# Example of usage of method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:25.207626
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import textwrap
    from ..utils.ast_converter import convert_source_to_ast
    from ..utils.ast_inspector import is_equal_ast

    transformer = ReturnFromGeneratorTransformer()

    # CASE 1: return in generator
    code = textwrap.dedent('''
        def fn():
            yield 1
            return 5
        ''')
    ast_tree = convert_source_to_ast(code)
    expected = textwrap.dedent('''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        ''')
    expected = convert_source_to_ast(expected)
    transformer.visit(ast_tree)
    assert is_equal_ast(ast_tree, expected)

    # CASE 2: return outside

# Generated at 2022-06-12 03:52:33.811506
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(BaseNodeTransformerTest):
        def create_instance(self):
            return ReturnFromGeneratorTransformer()

        def create_valid_input(self):
            def a():
                def b():
                    yield 1
                    return 2
                yield b()
            return a  # type: ignore

        def create_invalid_input(self):
            def a():
                yield 1
                return 2
            return a  # type: ignore

        def assert_output(self, input, output):
            assert ast.dump(input) == ast.dump(output)

    Test().run()



# Generated at 2022-06-12 03:52:39.904208
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Arrange
    code = """
    def fn():
        yield 1
        return 5
    """

    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    node = ast.parse(code)
    transformer = ReturnFromGeneratorTransformer()

    # Act
    new_node = transformer.visit(node)
    actual = ast.unparse(new_node)

    # Assert
    assert actual == expected

# Generated at 2022-06-12 03:52:45.192958
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_assignment_expression_normalizer import node_from_code
    from .test_return_fixer import code_from_node
    from .test_expression_normalizer import ExpressionNormalizer
    from .test_return_fixer import ReturnFixer
    from .test_assignment_expression_normalizer import AssignmentExpressionNormalizer


# Generated at 2022-06-12 03:52:46.124617
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import run_on_lines

# Generated at 2022-06-12 03:52:47.707053
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:53.354615
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    code = """
    def fn():
        yield 1
        return 5
    """

    expected_code = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

    tree = ast.parse(code)
    fn = tree.body[0]
    transformer = ReturnFromGeneratorTransformer()
    node = transformer.visit(fn)
    assert ast.dump(node) == expected_code

# Generated at 2022-06-12 03:53:09.379025
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import get_ast, ast_equal
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        @property
        def target(self):
            return (3, 2)

        def test_return_in_function_with_yield(self):
            code = 'def fn(): yield 1; return 2'
            tree = get_ast(code, self.target)
            transformer = ReturnFromGeneratorTransformer(self.target)
            new = transformer.visit(tree)
            self.assertTrue(transformer.tree_changed, 'Tree changed')

            expected = get_ast('''
                def fn():
                    yield 1
                    exc = StopIteration()
                    exc.value = 2
                    raise exc
                ''', self.target)

# Generated at 2022-06-12 03:53:19.660873
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import parse, compare_ast

    snippet = """
    def fn():
        yield 1
        return 5
    """
    expected = """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse(snippet)
    new = ReturnFromGeneratorTransformer().visit(tree)
    assert compare_ast(new, parse(expected))

    snippet = """
    def fn():
        yield from (x for x in range(10))
        return 5
    """
    expected = """
    def fn():
        for x in range(10):
            yield x
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    tree = parse(snippet)
    new = ReturnFromGenerator

# Generated at 2022-06-12 03:53:29.181965
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """\
    class A:
        def fn(self):
            yield 1
            return 5
    """
    expected = """\
    class A:
        def fn(self):
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    function = list(tree.body)[0].body[0]
    assert isinstance(function.body[1], ast.Return)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(function)
    assert transformer._tree_changed
    assert ast.dump(tree) == expected

# Generated at 2022-06-12 03:53:40.395105
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    func_def1 = ast.FunctionDef(name='func', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[
        ast.Expr(value=ast.Yield()),
        ast.Return(value=ast.Num(n=1))
    ], decorator_list=[], returns=None)

    func_def2 = ast.FunctionDef(name='func', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[
        ast.Expr(value=ast.Yield()),
        ast.Return(value=ast.Num(n=1))
    ], decorator_list=[], returns=None)

# Generated at 2022-06-12 03:53:50.332387
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

    #
    # Test: Simple return from generator
    #
    def test1(x):
        yield x
        return x
    # ast.parse(text)
    print(astor.to_source(ast.parse('test1(x)')))
    assert astor.to_source(ast.parse('test1(x)')) == 'test1(x)'

    node1 = ast.parse(test1.__doc__)
    print(astor.to_source(node1))
    print(astor.to_source(ReturnFromGeneratorTransformer().visit(node1)))

# Generated at 2022-06-12 03:53:57.809108
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    def test_method(function, expected_function):  # pylint: disable=redefined-outer-name
        node = ast.parse(function)  # type: ignore
        expected_node = ast.parse(expected_function)  # type: ignore
        output_node = transformer.visit(node)
        assert ast.dump(output_node, annotate_fields=False) == ast.dump(expected_node, annotate_fields=False)


# Generated at 2022-06-12 03:54:06.170257
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""
    def fn():
        yield 1
        return 5
    """)  # type: ast.FunctionDef
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    expected_tree = ast.parse("""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)  # type: ast.FunctionDef
    assert ast.dump(tree) == ast.dump(expected_tree)


# Generated at 2022-06-12 03:54:13.679589
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import parse
    from ..utils.helpers import node_to_snippet

    snippet = """
        def fn():
            yield 1
            return 5
            return 'dupa'
        """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
            return 'dupa'
        """

    node = parse(snippet)
    new_node = ReturnFromGeneratorTransformer().visit(node)
    assert node_to_snippet(new_node) == expected


# Generated at 2022-06-12 03:54:14.244663
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert True

# Generated at 2022-06-12 03:54:26.297858
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .test_rename_future_imports import RenameFutureImportsTransformer
    from .test_fix_annotation import FixAnnotationTransformer
    from .test_fix_syntax import FixSyntaxTransformer

    source = """\
        def fn():
            yield 1
            return 5
    """
    expected_source = """\
        @coroutine
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    module = ast.parse(source)
    module = RenameFutureImportsTransformer().visit(module)
    module = FixAnnotationTransformer().visit(module)
    module = FixSyntaxTransformer().visit(module)
    module = ReturnFromGeneratorTransformer().visit(module)

# Generated at 2022-06-12 03:54:42.224785
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.source import source

    class Test(ast.NodeTransformer):
        pass

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit = lambda x: Test.generic_visit(transformer, x) # type: ignore
    node = ast.parse(source('''
    def func():
        yield 1

        return 2
    '''))
    assert source(transformer.visit(node)) == source('''
    def func():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    ''')

# Generated at 2022-06-12 03:54:52.745843
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    t = ReturnFromGeneratorTransformer()
    source = \
"""def fn():
    yield 1
    yield 2
    return 5"""

    node = ast.parse(source)
    t.visit(node)
    assert ast.dump(node) == \
"""def fn():
    yield 1
    yield 2
    exc = StopIteration()
    exc.value = 5
    raise exc"""

    source = \
"""def fn():
    yield 1
    yield 2
    if True:
        return 5"""

    node = ast.parse(source)
    t.visit(node)
    assert ast.dump(node) == \
"""def fn():
    yield 1
    yield 2
    if True:
        exc = StopIteration()
        exc.value = 5
        raise exc"""

# Generated at 2022-06-12 03:55:00.701329
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class ReturnFromGeneratorTransformerSubclass(ReturnFromGeneratorTransformer):
        target = (3, 5)
        def _find_generator_returns(self, node: ast.FunctionDef) -> List[Tuple[ast.stmt, ast.Return]]:
            return []
        def _replace_return(self, parent: ast.stmt, return_: ast.Return) -> None:
            pass

    # Expected result:
    class Fn(ast.FunctionDef):
        def __init__(self):
            self.name = 'fn'
            self.args = ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])

# Generated at 2022-06-12 03:55:05.684835
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # snippet
    def before(retval):
        def fn():
            yield 1
            do_something()
            return retval
    # /snippet
    after = before
    # snippet
    def fn():
        yield 1
        do_something()
        exc = StopIteration()
        exc.value = retval
        raise exc
    # /snippet

    assert ReturnFromGeneratorTransformer().transform_snippet(before) == after

# Generated at 2022-06-12 03:55:09.871724
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def assert_equal(tree, expected_tree):
        # assert_equal checks if tree and expected_tree have the same structure
        # For more info about this function see file tests/test_utils.py
        assert_equal(tree, expected_tree)


# Generated at 2022-06-12 03:55:11.958356
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    transformer._tree_changed = False

# Generated at 2022-06-12 03:55:23.005578
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert_source_equal(ReturnFromGeneratorTransformer.apply('def fn(): yield "Hurray!"'),
                        'def fn():\n    yield "Hurray!"')

    assert_source_equal(ReturnFromGeneratorTransformer.apply(
        'def fn(): yield "Wow!"; return 42'),
        'def fn():\n    yield "Wow!"\n    exc = StopIteration()\n'
        '    exc.value = 42\n    raise exc')

    assert_source_equal(ReturnFromGeneratorTransformer.apply(
        'def fn(): yield "Wow!"; return 42; return 53'),
        'def fn():\n    yield "Wow!"\n    exc = StopIteration()\n'
        '    exc.value = 42\n    raise exc')


# Generated at 2022-06-12 03:55:26.803797
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    test = """def fn():
            yield 1
            return 5
            yield 2
    """
    tree = ast.parse(test)

    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)


# Generated at 2022-06-12 03:55:31.880362
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # type: () -> None
    from ..utils import parse, unparse
    from .recursive import RecursiveTransformer
    code = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = parse(code)
    rec, _ = RecursiveTransformer().visit(node)
    ReturnFromGeneratorTransformer(rec).visit(rec)
    assert unparse(rec) == expected

# Generated at 2022-06-12 03:55:42.537860
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ...testing import assert_transformed_code_equals

    assert_transformed_code_equals(
        ReturnFromGeneratorTransformer,
        """
        def fn():
            yield 1
            return 5
        def fn2():
            yield 1
            return
        def fn3():
            yield 1
            return 2 if 5 < 2 else 4
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        def fn2():
            yield 1
            return
        def fn3():
            yield 1
            exc = StopIteration()
            exc.value = 2 if 5 < 2 else 4
            raise exc
        """,
    )


# Generated at 2022-06-12 03:56:04.003203
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3
    from typed_ast.ast3 import Return, Yield, FunctionDef, Expr, Load, Name, Raise, StopIteration, Call, Attribute, NameConstant, Str, Module, Assign, Store, Call, Name

    def fn():
        yield 1
        return 5

    class SnippetMock:
        def get_body(self, return_value):
            return [
                Expr(value=Call(
                    func=Attribute(
                        value=Name(id='exc', ctx=Store()),
                        attr='value',
                        ctx=Load()
                    ),
                    args=[NameConstant(value=None)],
                    keywords=[]
                )),
                Raise(exc=Name(id='exc', ctx=Load()), cause=None)
            ]

    return_from

# Generated at 2022-06-12 03:56:12.803140
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    src = """
    def fn():
        yield 1
        return 5

    def fn1(a):
        if a:
            print(1)
            return 5
        yield 6
        if a:
            print(2)
            return 6
        yield 7
        return 8

    def fn2():
        yield 1
        return 5

    def fn3():
        return 5

    def fn4():
        pass

    def fn5():
        yield from (1, 2)

    def fn6():
        yield from (1, 2)
        return 5
    """


# Generated at 2022-06-12 03:56:13.703338
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:23.441698
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def function_def1(numbers):
        for num in numbers:
            yield num
        return sum(numbers)

    result1 = ReturnFromGeneratorTransformer().visit(ast.parse(inspect.getsource(function_def1)))
    body1 = ''.join(line.body[0] for line in result1.body)
    expected_body1 = 'for num in numbers:\n            yield num\nexc = StopIteration()\nexc.value = sum(numbers)\nraise exc'
    assert body1 == expected_body1
    expected_output1 = [1, 2, 3]
    assert list(function_def1(expected_output1)) == expected_output1

    def function_def2(numbers):
        for num in numbers:
            yield num

# Generated at 2022-06-12 03:56:25.852422
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.snippet import load
    from ..ast_compat import parse

    ctx = load(ReturnFromGeneratorTransformer)
    src = 'def fn(): yield 1\nreturn 5'
    node = parse(src)
    assert src == ctx.compile(node, sys.stdout)


# Generated at 2022-06-12 03:56:26.716235
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor

# Generated at 2022-06-12 03:56:33.631724
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast
    import unittest

    def check_ok(before: ast.FunctionDef, after: ast.FunctionDef) -> None:
        class TestCase(unittest.TestCase):
            def test_pass(self) -> None:
                transformer = ReturnFromGeneratorTransformer()
                transformer.visit(before)
                self.assertEqual(before, after)

        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(TestCase))
        runner = unittest.TextTestRunner(verbosity=2)
        runner.run(suite)


# Generated at 2022-06-12 03:56:40.858461
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import test_snippet

    source = '''
    def fn():
        yield 1
        return 5
    '''

    expected = '''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    '''

    assert_code_equal(ReturnFromGeneratorTransformer().visit(test_snippet(source)), test_snippet(expected))

# Generated at 2022-06-12 03:56:45.184440
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test(body, expected):
        node = ast.parse(body)
        node = ReturnFromGeneratorTransformer().visit(node)
        assert ast.dump(node) == expected

    test(u"""
        def fn():
            return 1
    """, u"""
        def fn():
            return 1
    """)

    test(u"""
        def fn():
            yield 1
            return 1
    """, u"""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 1
            raise exc
    """)

    test(u"""
        def fn():
            if True:
                return 1
            return 2
    """, u"""
        def fn():
            if True:
                return 1
            return 2
    """)


# Generated at 2022-06-12 03:56:53.479377
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # FIXME: This method should be moved to tests/test_return_from_generator.py
    import astor  # type: ignore
    import typed_astunparse  # type: ignore

    def transform(test_func):
        module = ast.parse(dedent(test_func))
        func = module.body[0]  # type: ignore
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(func)
        return module

    def get_output(test_func):
        module = transform(test_func)
        return dedent(typed_astunparse.unparse(module))

    def get_output_ast(test_func):
        module = transform(test_func)
        return astor.to_source(module).strip()


# Generated at 2022-06-12 03:57:45.456442
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test(ReturnFromGeneratorTransformer):
        def __init__(self, tree: ast.AST) -> None:
            self._tree_changed = False
            self._tree = ast.fix_missing_locations(tree)
            self._result_tree = self.visit(self._tree)

        def get_tree_changed(self) -> bool:
            return self._tree_changed

        def get_tree(self) -> ast.AST:
            return self._tree

        def get_result_tree(self) -> ast.AST:
            return self._result_tree

    # Test returns 1

# Generated at 2022-06-12 03:57:46.503911
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    c = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:57:57.468212
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse("""
    def fn():
        a = 1
        yield a
        return 2
    def fn2():
        yield 1
        return 2
    def fn3():
        yield from [1, 2, 3]
        return 4
    """)
    transformer = ReturnFromGeneratorTransformer()
    transformer.visit(tree)
    # print(ast.dump(tree))

# Generated at 2022-06-12 03:58:06.711668
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse("""
    def gen():
        yield 1
        return 5
    """)

    visitor = ReturnFromGeneratorTransformer(node)
    visitor.visit(node)

# Generated at 2022-06-12 03:58:15.922872
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        a = "a"
        return a

    fn_ast = ast.parse(fn.__code__.co_consts[0]).body[0]

    fn2 = fn_ast
    fn2 = ReturnFromGeneratorTransformer().visit(fn2)  # type: ignore
    assert fn2 is fn_ast

    def fn3():
        yield 1
        return 2

    fn3_ast = ast.parse(fn3.__code__.co_consts[0]).body[0]

    fn4 = fn3_ast
    fn4 = ReturnFromGeneratorTransformer().visit(fn4)  # type: ignore
    assert fn4 is not fn3_ast

    fn4_body = ast.Module(body=[fn4]).body  # type: ignore

# Generated at 2022-06-12 03:58:25.890501
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from tests.compiler.utils import compile_any
    from ..utils.ast_generator import generate_function
    from .base import BaseNodeTransformerTest

    def transform(function: ast.FunctionDef, **kwargs) -> ast.FunctionDef:
        node = ReturnFromGeneratorTransformer(**kwargs).visit(function)
        return node

    def get_test_function(return_value: str) -> ast.FunctionDef:
        return_value = ast.parse(return_value, mode='eval').body
        generator = generate_function('', body=(
            'yield 1',
            'yield 2',
            'return ' + return_value,
        ))
        return generator

    def get_function_code(function: ast.FunctionDef) -> str:
        function = compile_any(function)

# Generated at 2022-06-12 03:58:31.054294
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """

    tree = ast.parse(source)
    ReturnFromGeneratorTransformer().visit(tree)
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    ast.fix_missing_locations(tree)

    assert ast.dump(tree).replace('\n', '') == expected

# Generated at 2022-06-12 03:58:34.287600
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    import astor

# Generated at 2022-06-12 03:58:40.554166
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = ast.parse(source)
    transformed_node = transformer.visit(node)
    assert transformer._tree_changed
    expected_node = ast.parse(expected)
    assert ast.dump(transformed_node) == ast.dump(expected_node)



# Generated at 2022-06-12 03:58:46.846125
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class A(ReturnFromGeneratorTransformer):
        def _find_generator_returns(self, node: ast.FunctionDef) \
                -> List[Tuple[ast.stmt, ast.Return]]:
            return [(node, ast.Return(ast.Num(1)))]

        def _replace_return(self, parent: Any, return_: ast.Return) -> None:
            return

    code = 'def fn():\n    return 5'
    node = ast.parse(code)
    A().visit(node)
    assert code not in ast.dump(node)

# Generated at 2022-06-12 03:59:51.002399
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.example import ExampleFunctionTransformer
    from .fix_missing_locations import FixMissingLocationsTransformer
    from .desugar import DesugarTransformer
    from ..compiler.compiler import compile

    transformer = ExampleFunctionTransformer('def fn(): yield 1; return 5')
    transformer = DesugarTransformer(transformer)
    transformer = ReturnFromGeneratorTransformer(transformer)
    transformer = FixMissingLocationsTransformer(transformer)
    fn = compile(transformer.tree)

    assert next(fn()) == 1
    with pytest.raises(StopIteration) as excinfo:
        next(fn())
    assert excinfo.value.value == 5

# Generated at 2022-06-12 03:59:59.740611
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import BaseNodeTransformer_unit_test
    from .base import BaseNodeTransformer_unit_test_for_method
    from .base import BaseNodeTransformer_visit_FunctionDef_test_cases

    class ThisTest(
            BaseNodeTransformer_unit_test,
            BaseNodeTransformer_unit_test_for_method,
            BaseNodeTransformer_visit_FunctionDef_test_cases):
        def test_every_method_called(self):
            self.assertEqual(self.methods['visit_FunctionDef'], 1)

        def setUp(self):
            BaseNodeTransformer_unit_test.setUp(self)
            BaseNodeTransformer_unit_test_for_method.setUp(self,
                'visit_FunctionDef', None)

        # === Test cases for 'vis

# Generated at 2022-06-12 04:00:07.261572
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer"""
    from ..conftest import transform, function_reference

    source_0 = '''
        def fn():
            yield 1
            return 5
        '''
    output_0 = '''
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
        '''
    transform(ReturnFromGeneratorTransformer, source_0, output_0)
    function_reference.update(globals())

    source_1 = '''
        def fn():
            yield from (1, 2, 3)
            return 5
        '''

# Generated at 2022-06-12 04:00:09.395537
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 04:00:10.882567
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..testing_utils import assert_equal_ast


# Generated at 2022-06-12 04:00:16.523474
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    tree = ast.parse('def gen(): yield 1; return 1')
    node = tree.body[0]

    transformer = ReturnFromGeneratorTransformer()
    out_node = transformer.visit(node)

    assert transformer._tree_changed
    assert 'exc = StopIteration()' in ast.dump(out_node)
    assert out_node.body is not node.body
    assert out_node.args is node.args
    assert out_node.name is node.name

# Generated at 2022-06-12 04:00:20.579694
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 04:00:25.275507
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    node = tree.body[0]
    transformer = ReturnFromGeneratorTransformer()
    new_node = transformer.visit_FunctionDef(node)
    assert ast.dump(new_node) == ast.dump(ast.parse(expected).body[0])

# Generated at 2022-06-12 04:00:34.615527
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    ast_module_1 = ast.parse("def cube():\n\tyield 1\n\treturn 5")
    node_transformer_1 = ReturnFromGeneratorTransformer()
    node_transformer_1.visit(ast_module_1)
    assert str(ast_module_1) == "def cube():\n    yield 1\n    exc = StopIteration()\n    exc.value = 5\n    raise exc"
    ast_module_2 = ast.parse("def square():\n\treturn 5")
    node_transformer_2 = ReturnFromGeneratorTransformer()
    node_transformer_2.visit(ast_module_2)
    assert str(ast_module_2) == "def square():\n    return 5"

# Generated at 2022-06-12 04:00:40.463718
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 2
 
    fn_ast = ast.parse(inspect.getsource(fn))
    fn_ast = ReturnFromGeneratorTransformer().visit(fn_ast)
    fn_compiled = compile(fn_ast, '<string>', mode='exec')
    fn_compiled_fn = eval(fn_compiled)

    it = fn_compiled_fn()
    assert next(it) == 1
    assert it.send(None) == 2
