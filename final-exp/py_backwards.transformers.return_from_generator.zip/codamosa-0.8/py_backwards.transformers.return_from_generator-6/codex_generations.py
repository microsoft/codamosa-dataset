

# Generated at 2022-06-12 03:50:56.230358
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast

    actual = ast.parse("""
        def fn():
            yield 1
            return 3
    """)

    expected = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 3
            raise exc
    """)

    assert ast.dump(expected, include_attributes=True) == \
           ast.dump(ReturnFromGeneratorTransformer().visit(actual), include_attributes=True)

# Generated at 2022-06-12 03:50:57.896594
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..transformer import Transformer
    from ..utils import ast_dump, load_string


# Generated at 2022-06-12 03:50:58.664685
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:01.304244
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:02.987869
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()


# Generated at 2022-06-12 03:51:07.649943
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.testutils import assert_transformed_ast
    assert_transformed_ast(
        """
        def fn():
            yield 1
            return 2
        """,
        """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc
        """
    )



# Generated at 2022-06-12 03:51:18.869060
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    import os

    def test_one(code_in, code_out):
        module = ast.parse(code_in)
        node = module.body[0]
        assert isinstance(node, ast.FunctionDef)
        transformed_node = ReturnFromGeneratorTransformer().visit(node)
        transformed_code = unparse(transformed_node)
        print("IN:")
        print(code_in)
        print("OUT:")
        print(transformed_code)
        print("EXPECTED:")
        print(code_out)
        assert transformed_code == code_out

    # Test simple generator
    code_in = """
        def fn():
            yield 1
            return 5
    """

# Generated at 2022-06-12 03:51:30.780891
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn():
        yield 1
        return 5

    def other_fn():
        return 5

    def inline_fn():
        yield 2

    class Foo(object):
        @property
        def foo(self):
            yield 2

    assert ReturnFromGeneratorTransformer(is_inplace=False) \
               .visit(ast.parse(fn.__code__)) \
               .body[0] \
               .body[-2:] \
               == return_from_generator.get_body()


# Generated at 2022-06-12 03:51:40.151692
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    module = ast.parse('def generator(): yield 1; return 5')
    ReturnFromGeneratorTransformer().visit(module)

# Generated at 2022-06-12 03:51:40.735616
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:51:55.156081
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
    from .base import BaseNodeTransformer
    from ..utils.generator import generator
    from .base import compile_function
    from .base import BaseNodeTransformer
    from ..utils.generator import generator
    from .base import compile_function
    from .base import BaseNodeTransformer
    from ..utils.generator import generator
    from .base import compile_function

    @generator
    def fn() -> typing.Iterator[Any]:
        yield 1
        return 5

    @generator
    def fn_with_yield_from() -> typing.Iterator[Any]:
        yield from [1, 2, 3]
        return 5

    @generator
    def fn_without_return() -> typing.Iterator[Any]:
        return


# Generated at 2022-06-12 03:52:00.200201
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    find_generator_returns_mock = Mock()

    custom_transformer = ReturnFromGeneratorTransformer(None)
    custom_transformer._find_generator_returns = find_generator_returns_mock
    custom_transformer.visit_FunctionDef(1)
    find_generator_returns_mock.assert_called_once_with(custom_transformer, 1)


# Generated at 2022-06-12 03:52:07.792932
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():

    class NodeTransformerMock(BaseNodeTransformer):

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
            def fn():
                yield 1
                return 5

            src = inspect.getsource(fn)
            node = self.parse(src)
            ReturnFromGeneratorTransformer(self.options).visit(node)
            expected = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc
"""
            assert node is not None
            assert ast.dump(node) == ast.dump(ast.parse(expected))
            return node

    transformer = NodeTransformerMock({})
    transformer.visit(ast.parse(''))



# Generated at 2022-06-12 03:52:08.421208
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:52:19.960859
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils import setup_module_for_testing, remove_module_for_testing
    from ..utils import string_to_ast_node
    from .docstrings import DocstringTransformer
    from .return_compat import ReturnTransformer

    setup_module_for_testing(ReturnFromGeneratorTransformer)
    t = ReturnFromGeneratorTransformer()

    # Generator with no return
    node = string_to_ast_node("""
        def fn():
            yield 1
        """)
    t.visit(node)
    assert string_to_ast_node("""
        def fn():
            yield 1
        """) == node

    # Generator with simple return
    node = string_to_ast_node("""
        def fn():
            yield 1
            return 2
        """)
    t.visit(node)

# Generated at 2022-06-12 03:52:21.825688
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
        def fn():
            yield 1
            return 5
    """
    assert ast.parse(code) != ast.parse(ReturnFromGeneratorTransformer().visit(ast.parse(code)))

# Generated at 2022-06-12 03:52:26.975567
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def generator_function_with_two_returns():
        yield 0
        return 1
        yield 2
        return 3

    def generator_function_with_one_return():
        yield 0
        return 1

    def generator_function_with_no_returns():
        yield 0

    def function_with_no_returns():
        pass

    def function_with_return():
        return 1

    def test_function(function):
        node = ast.parse(inspect.getsource(function))
        node = node.body[0]
        print('\nInput function:\n', inspect.getsource(function))
        transformer = ReturnFromGeneratorTransformer()
        transformer.visit(node)
        print('\nTransformer on input function:\n', ast.dump(node))


# Generated at 2022-06-12 03:52:31.135797
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    expected = b"""
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """
    node = ast.parse(expected)
    transformer = ReturnFromGeneratorTransformer()
    assert transformer.visit(node)

# Generated at 2022-06-12 03:52:41.525998
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .. import ast_util
    from .stmt_insertion import StmtInsertionTransformer

    # @snippet
    # def fn():
    #     if x:
    #         yield 1
    #         return x + 1
    #     else:
    #         yield 2
    #         return x + 2

    x = ast.Name(id='x', ctx=ast.Load())
    one = ast.Num(n=1)
    two = ast.Num(n=2)
    one_plus_x = ast.BinOp(left=one, op=ast.Add(), right=x)
    two_plus_x = ast.BinOp(left=two, op=ast.Add(), right=x)


# Generated at 2022-06-12 03:52:43.218519
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.macro_test_utils import assert_code_equal


# Generated at 2022-06-12 03:52:56.400185
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .utils import get_nodes
    node = get_nodes(
        'def fn():\n'
        '    yield 1\n'
        '    return 5\n'
    )
    ReturnFromGeneratorTransformer().generic_visit(node)

    expected = get_nodes(
        'def fn():\n'
        '    yield 1\n'
        '    exc = StopIteration()\n'
        '    exc.value = 5\n'
        '    raise exc\n'
    )

    assert node == expected



# Generated at 2022-06-12 03:53:09.193233
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from unittest.mock import patch
    from typed_astunparse import unparse, dump
    # Build AST
    # FunctionDef(name='fn', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Yield(value=Num(n=1))), Return(value=Num(n=5))], decorator_list=[], returns=None)

# Generated at 2022-06-12 03:53:11.524513
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..utils.helper import get_generator_body

# Generated at 2022-06-12 03:53:20.768531
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    transformer = ReturnFromGeneratorTransformer()

    node = ast.parse('''
        def fn():
            yield 1
            return 5
            return 6
            yield 2
        ''')
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.FunctionDef)  # type: ignore
    fn = node.body[0]
    assert len(fn.body) == 4
    assert isinstance(fn.body[0], ast.Expr)  # type: ignore
    assert isinstance(fn.body[1], ast.Return)  # type: ignore
    assert isinstance(fn.body[2], ast.Return)  # type: ignore
    assert isinstance(fn.body[3], ast.Expr)  # type: ignore

# Generated at 2022-06-12 03:53:32.092212
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ..utils.test_utils import generate_function_def, check_transformation
    import astor

    def test_transformation(tree):
        transformer = ReturnFromGeneratorTransformer()
        node = transformer.visit(tree)
        code = astor.to_source(node)
        exec(code)

        fn = locals()['fn']
        result = list(fn())

        assert result == [(1, 2), (3, 4), 'fin']


# Generated at 2022-06-12 03:53:40.054822
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast.ast3 import parse
    code = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    node = parse(code)

    ReturnFromGeneratorTransformer().visit(node)
    actual = compile(node, '<test>', 'exec')
    expected = compile(expected, '<test>', 'exec')
    assert actual == expected


# Generated at 2022-06-12 03:53:46.647962
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .context import CompilationContext
    from .exceptions import TreeChangedError

    code = """
        def fn(a):
            yield 1
            return a + 1
    """

    tree = ast.parse(code)
    context = CompilationContext(tree, code)
    transformer = ReturnFromGeneratorTransformer(context)
    transformer.visit(tree)
    with pytest.raises(TreeChangedError):
        transformer.visit(tree)

# Generated at 2022-06-12 03:53:54.685586
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class MyCodeVisitor(ast.NodeVisitor):
        def generic_visit(self, node):
            pass

        def visit_Return(self, node: ast.Return) -> ast.Return:
            assert(node.value.value == 5)
            return node

    class MyCodeTransformer(ReturnFromGeneratorTransformer):
        def visit_stmt(self, node: ast.stmt):
            MyCodeVisitor().visit(node)
            return node


# Generated at 2022-06-12 03:53:56.328469
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    assert_equal(ast.parse('''
        def fn():
            yield 1
            return 5
    '''), ast.parse(ReturnFromGeneratorTransformer().visit(ast.parse('''
        def fn():
            yield 1
            return 5
    '''))))



# Generated at 2022-06-12 03:54:08.082244
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    original_code = inspect.cleandoc(
        '''
        def fn():
            yield 1
            return 5
        
        def f1():
            yield from fn()
        
        def f2():
            a = (yield)
            return a
        
        def f3():
            a = yield from fn()
            return a
        '''
    )

# Generated at 2022-06-12 03:54:33.787553
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    expected_function_return = ast.Return(
        value=ast.Constant(
            value=5,
            kind=None
        )
    )
    expected_function_return_with_exception = ast.Raise(
        exc=ast.Call(
            func=ast.Name(
                id='StopIteration',
                ctx=ast.Load()
            ),
            args=[],
            keywords=[
                ast.keyword(
                    arg='value',
                    value=ast.Constant(
                        value=5,
                        kind=None
                    )
                )
            ]
        ),
        cause=None
    )

# Generated at 2022-06-12 03:54:46.225966
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = """
    def fn():
        yield 1
        return 5
    """

    class TestReturnFromGeneratorTransformer(ReturnFromGeneratorTransformer):
        def __init__(self):
            self._tree_changed = False

        def _find_generator_returns(self, node):
            return [(node.body[0], node.body[1])]

        def _replace_return(self, parent, return_):
            assert parent.body[0] == return_
            assert return_.value.n == 5

            index = parent.body.index(return_)
            parent.body.pop(index)
            for line in return_from_generator.get_body(return_value=return_.value)[::-1]:
                parent.body.insert(index, line)


# Generated at 2022-06-12 03:54:50.506076
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astunparse
    from .utils import roundtrip
    source = """
        def fn():
            yield 1
            return 5
    """
    expected = """
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """
    tree = ast.parse(source)
    new_tree = roundtrip(tree, ReturnFromGeneratorTransformer)
    assert astunparse.unparse(new_tree) == expected

# Generated at 2022-06-12 03:54:51.378300
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:54:55.710496
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .utils import assert_converted_tree_equal

    tree = ast.parse("""\
    @add_argument('foo')
    def fn():
        yield 1
        return 5
    """)
    expected = ast.parse("""\
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """)

    transformer = ReturnFromGeneratorTransformer()
    assert_converted_tree_equal(transformer, tree, expected)

# Generated at 2022-06-12 03:55:01.668065
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from yat.printer import PrettyPrinter
    from yat.model import Program
    from tests.utils import create_function_def

    def run(function_def: ast.FunctionDef) -> str:
        node = Program([function_def])
        node = ReturnFromGeneratorTransformer().visit(node)
        return PrettyPrinter().visit(node)

    assert run(create_function_def("def fn(): yield 1")) == "def fn():\n    yield 1"


# Generated at 2022-06-12 03:55:04.619701
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .base import CompilerError, run_transformer_function_test
    from .base import run_transformer_test, run_transformer_class_test

    transformer = ReturnFromGeneratorTransformer()

# Generated at 2022-06-12 03:55:14.697549
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input1 = """
    def foo():
        yield 1
    """
    expected1 = """
    def foo():
        yield 1
    """
    input2 = """
    def foo():
        yield 1
        return 2
    """
    expected2 = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """
    input3 = """
    def foo():
        return 1
    """
    expected3 = """
    def foo():
        return 1
    """
    input4 = """
    def foo():
        yield 1
        if True:
            return 2
        else:
            return 3
    """

# Generated at 2022-06-12 03:55:20.649320
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def test_case(src):
        tree = ast.parse(src)
        ref_tree = ast.parse(expected)
        rfgt = ReturnFromGeneratorTransformer()
        rfgt.generic_visit(tree)
        assert ast.dump(tree) == ast.dump(ref_tree)

    def _gen():
        yield 1
        return 5


# Generated at 2022-06-12 03:55:30.227595
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import astor
    from ..utils import node_from_src
    from ..utils.test_utils import (transform, assert_equal_code,
                                    assert_equal_node)

    @transform(ReturnFromGeneratorTransformer)
    def gen():
        def fn():
            yield 1
            return 5
        return fn

    @transform(ReturnFromGeneratorTransformer)
    def gen2():
        def fn():
            yield from range(10)
            return 5
        return fn

    @transform(ReturnFromGeneratorTransformer)
    def not_gen():
        def fn():
            return 5
        return fn

    @transform(ReturnFromGeneratorTransformer)
    def not_gen2():
        def fn():
            yield 2
        return fn


# Generated at 2022-06-12 03:56:07.453232
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    # foo
    @snippet
    def test():
        def foo():
            yield 1
            return 5
    #
    value = ReturnFromGeneratorTransformer().visit(test.ast)
    assert test.source == value.body[0].body[0].body  # type: ignore

    # bar
    @snippet
    def test():
        def bar():
            if True:
                yield 3
                return 4
    #
    value = ReturnFromGeneratorTransformer().visit(test.ast)
    assert test.source == value.body[0].body[0].body[1].body[0].body  # type: ignore

    # baz
    @snippet
    def test():
        def baz():
            if True:
                yield 5
            else:
                return 6
    #


# Generated at 2022-06-12 03:56:08.468358
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:56:13.585113
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node = ast.parse('''
    def fn():
        yield 1
        return 5
    ''')

    expected = ast.parse('''
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    ''')

    actual = ReturnFromGeneratorTransformer.run_pipeline(node)

    assert ast.dump(actual) == ast.dump(expected)



# Generated at 2022-06-12 03:56:23.300457
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    node1 = ast.FunctionDef(name='fn', body=[], returns=None)
    transformer1 = ReturnFromGeneratorTransformer()
    modified_node1 = transformer1.visit(node1)
    assert transformer1._tree_changed == False
    assert modified_node1.body == []

    node2 = ast.FunctionDef(name='fn', body=[ast.Return()], returns=None)
    transformer2 = ReturnFromGeneratorTransformer()
    modified_node2 = transformer2.visit(node2)
    assert transformer2._tree_changed == False
    assert modified_node2.body == [ast.Return()]

    node3 = ast.FunctionDef(name='fn', body=[ast.Return(value=ast.Num(n=1))], returns=None)
    transformer3 = ReturnFromGeneratorTransformer()
   

# Generated at 2022-06-12 03:56:32.146575
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def fn1():
        return 5

    def fn2():
        yield 1
        return 5

    def fn3():
        try:
            return 5
        except:
            return 0

    def fn4():
        yield 1
        yield 2
        return 5

    def fn5():
        yield 1
        if True:
            return 5

    def fn6():
        yield 1
        try:
            return 5
        except:
            return 0

    def fn7():
        yield 1
        yield 2
        return

    def fn8():
        yield 1
        while False:
            yield 2
            return

    def fn9():
        yield 1
        try:
            return
        except:
            return

    def fn10():
        return

    def fn11():
        yield from [1, 2]
        return



# Generated at 2022-06-12 03:56:39.014488
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code = '''
    def f():
        yield 1
        return 1
    '''
    expected = '''
    def f():
        yield 1
        exc = StopIteration()
        exc.value = 1
        raise exc
    '''
    node = ast.parse(code)
    ReturnFromGeneratorTransformer().visit(node)
    assert ast.dump(node) == expected


# Generated at 2022-06-12 03:56:48.782934
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    """Unit tests for method visit_FunctionDef of class ReturnFromGeneratorTransformer.

    Tests that function definition is transformed when it contains `return` statement in generator.
    """

    transformer = ReturnFromGeneratorTransformer()
    assert transformer.tree_changed is False

    func_def = ast.parse("""
    def foo():
        yield 1
        return 2
        yield 3 """)
    expected = ast.parse("""
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
        yield 3 """)
    new_func_def = transformer.visit(func_def)
    assert expected.body[0].body == new_func_def.body[0].body

    assert transformer.tree_changed is True



# Generated at 2022-06-12 03:56:57.679804
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    class Test:
        def assertCompiled(self, before, expected):
            node = ast.parse(before)
            visitor = ReturnFromGeneratorTransformer()
            visitor.visit(node)
            result = ast.unparse(node)
            assert result == expected, '%s != %s' % (result, expected)

        def test_nothing_to_do(self):
            self.assertCompiled('''
                def p():
                    return 5
            ''', '''
                def p():
                    return 5
            ''')

        def test_just_yield(self):
            self.assertCompiled('''
                def p():
                    yield 1
            ''', '''
                def p():
                    yield 1
            ''')

        def test_return_in_normal_fn(self):
            self

# Generated at 2022-06-12 03:57:06.036268
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    import ast
    from typed_ast import ast3 as typed_ast
    from ..utils.test_visitor import TestVisitor
    from .test_dsl import test_dsl
    from .return_from_generator import ReturnFromGeneratorTransformer

    # We write the code to be compiled
    code = """def fn():
    yield 1
    return 5"""

    # We create the AST of this code
    ast_tree = ast.parse(code)

    # We run the transform to replace the return by an exception raise
    new_tree = ReturnFromGeneratorTransformer().visit(ast_tree)

    # We expect this code after the transform
    expected_code = """def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc"""

    # We check that the transform worked by comparing

# Generated at 2022-06-12 03:57:15.304187
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:58:30.143409
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse

# Generated at 2022-06-12 03:58:38.305691
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from ast_toolbox.utils.ast_diff import ast_diff
    from ..utils.snippet import snippet, let

    node = let(node)
    node = ast.parse("""
        def fn():
            yield 1
            return 5
    """)
    expected = let(expected)
    expected = ast.parse("""
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 5
            raise exc
    """)

    assert ast_diff(expected, ReturnFromGeneratorTransformer().visit(node)) == []

# Generated at 2022-06-12 03:58:46.413818
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from .util import Source
    from .util import compare
    from .util import run_test
    from ..utils import dump
    # test that an exception is raised if a return statement without value is found
    test_source = Source("""
        def foo():
            yield 0
            return
    """)
    with pytest.raises(SyntaxError):
            run_test(test_source, ReturnFromGeneratorTransformer)
    # test that no exception occurs if a return statement without value is found because its not a generator
    test_source = Source("""
        def foo():
            return
    """)
    run_test(test_source, ReturnFromGeneratorTransformer)
    # test that an exception is raised if a bare return statement is found inside a generator

# Generated at 2022-06-12 03:58:50.454630
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    input_node = ast.parse("""def fn():
    yield 1
    return 5""")
    expected_node = ast.parse("""def fn():
    yield 1
    exc = StopIteration()
    exc.value = 5
    raise exc""")
    assert_equal_ast(expected_node, ReturnFromGeneratorTransformer().visit(input_node))


# Generated at 2022-06-12 03:58:51.310460
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:58:51.997848
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer

# Generated at 2022-06-12 03:59:00.841736
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_ast import ast3 as ast
    from ..utils.helpers import compare_ast
    from .generator_return_to_yield import GeneratorReturnToYieldTransformer

    def verify(tree, expected_tree):
        tree = GeneratorReturnToYieldTransformer().visit(tree)
        tree = ReturnFromGeneratorTransformer().visit(tree)
        tree = ast.fix_missing_locations(tree)

        compare_ast(tree, expected_tree)

        return tree

    # Verified manually
    def raw_fn1(n):
        def fn():
            yield 1
            return 3
        return fn

    def expected_fn1(n):
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 3
            raise exc
        return fn


# Generated at 2022-06-12 03:59:11.139805
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    code_snippet = '''
    def foo():
        yield 1
        return 2
    '''
    expected_ast = """
    def foo():
        yield 1
        exc = StopIteration()
        exc.value = 2
        raise exc
    """

    # Parse code snippet.
    root_node = ast.parse(code_snippet)

    # Transform the ast.
    transformer = ReturnFromGeneratorTransformer()
    new_root_node = transformer.visit(root_node)  # type: ignore

    # Ensure that the transformer successfully converted the return inside the
    # generator to exception raising.
    assert transformer._tree_changed is True
    assert ast.dump(new_root_node, annotate_fields=False) == expected_ast


# Generated at 2022-06-12 03:59:18.697460
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    from typed_astunparse import unparse
    from ..utils.test_visitor import test_visitor
    from ..utils.tree_checker import assert_tree, assert_tree_source_equals

    assert_tree(
        unparse(ReturnFromGeneratorTransformer().visit(
            assert_tree(unparse(test_visitor(ReturnFromGeneratorTransformer, """
            def fn():
                yield 1
                return 5
            """)))))
    ), """
    def fn():
        yield 1
        exc = StopIteration()
        exc.value = 5
        raise exc
    """

# Generated at 2022-06-12 03:59:25.922255
# Unit test for method visit_FunctionDef of class ReturnFromGeneratorTransformer
def test_ReturnFromGeneratorTransformer_visit_FunctionDef():
    def input_code_1():
        def fn():
            yield 1
            return 2

    def expected_code_1():
        def fn():
            yield 1
            exc = StopIteration()
            exc.value = 2
            raise exc

    def input_code_2():
        def fn():
            return 1

    def expected_code_2():
        def fn():
            return 1

    module_1 = ast.parse(input_code_1.__code__.co_code)
    module_2 = ast.parse(input_code_2.__code__.co_code)
    module_expected_1 = ast.parse(expected_code_1.__code__.co_code)
    module_expected_2 = ast.parse(expected_code_2.__code__.co_code)

    ReturnFromGener