

# Generated at 2022-06-17 13:51:22.052331
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:51:28.956737
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:51:37.740677
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:51:48.913898
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/path/to/file.ps1') == 'file.ps1'
    assert shell.get_remote_filename('/path/to/file.exe') == 'file.exe'
    assert shell.get_remote_filename('/path/to/file') == 'file.ps1'
    assert shell.get_remote_filename('/path/to/file.ps1.bak') == 'file.ps1.bak'
    assert shell.get_remote_filename('/path/to/file.exe.bak') == 'file.exe.bak'
    assert shell.get_remote_filename('/path/to/file.bak') == 'file.bak.ps1'

# Generated at 2022-06-17 13:51:52.772932
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:52:05.975933
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\') == shell._encode_script("Write-Output ((Get-Location).Path + '\\')")
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('~\\test\\') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\')")
    assert shell.expand_user('~\\test\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\test')")

# Generated at 2022-06-17 13:52:17.683281
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test that the bootstrap wrapper is added when the shebang is '#!powershell'
    shell = ShellModule()
    cmd = shell.build_module_command('', '#!powershell', 'test.ps1')

# Generated at 2022-06-17 13:52:24.967452
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script("Write-Output (Get-Location).Path")
    assert shell.expand_user('~\\') == shell._encode_script("Write-Output ((Get-Location).Path + '')")
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('~\\test\\') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\')")
    assert shell.expand_user('~\\test\\test2') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\test2')")

# Generated at 2022-06-17 13:52:29.481796
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS

# Generated at 2022-06-17 13:52:43.420974
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Create a ShellModule object
    shell_module = ShellModule()

    # Test with a shebang
    shebang = '#!powershell'
    cmd = 'Get-ChildItem'
    result = shell_module.build_module_command('', shebang, cmd)

# Generated at 2022-06-17 13:52:55.862691
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\')
    assert shell.path_has_trailing_slash('C:\\test\\')
    assert shell.path_has_trailing_slash('C:\\test\\test2\\')
    assert not shell.path_has_trailing_slash('C:\\test')
    assert not shell.path_has_trailing_slash('C:\\test\\test2')


# Generated at 2022-06-17 13:53:01.332326
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:07.757773
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    cmd = shell.mkdtemp(basefile='ansible-tmp-', tmpdir='C:\\Users\\Administrator\\AppData\\Local\\Temp')
    assert cmd == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Users\\Administrator\\AppData\\Local\\Temp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-*'
        Write-Output -InputObject $tmp.FullName
        '''.strip()

# Generated at 2022-06-17 13:53:11.745902
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    script = shell.mkdtemp()
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Users\\')
    assert script.endswith('\nWrite-Output -InputObject $tmp.FullName\n')


# Generated at 2022-06-17 13:53:24.109645
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\Users\\')
    assert shell.path_has_trailing_slash('C:\\Users\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\test2\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\test2\\\\')
    assert shell.path_

# Generated at 2022-06-17 13:53:35.345586
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/')
    assert shell.path_has_trailing_slash('\\')
    assert shell.path_has_trailing_slash('c:\\')
    assert shell.path_has_trailing_slash('c:/')
    assert shell.path_has_trailing_slash('c:\\windows\\')
    assert shell.path_has_trailing_slash('c:/windows/')
    assert shell.path_has_trailing_slash('\\\\server\\share\\')
    assert shell.path_has_trailing_slash('//server/share/')
    assert shell.path_has_trailing_slash('\\\\server\\share\\folder\\')

# Generated at 2022-06-17 13:53:41.632358
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:53:48.461824
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:58.485599
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a ShellModule object
    shell = ShellModule(connection=None, add_ansible_module_cmd=False, shell_type='powershell', no_log=True)

    # Create a temporary directory using mkdtemp
    script = shell.mkdtemp(basefile=None, system=False, mode=None, tmpdir=tmpdir)
    rc, stdout, stderr = shell._execute_module(tmpfile.name, tmpfile.name, script, '', False, '', '')
    assert rc == 0
    assert stderr == ''
    assert stdout.strip

# Generated at 2022-06-17 13:54:03.515584
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:12.672989
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:17.487104
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:29.195277
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    # Test with no basefile
    script = shell.mkdtemp()
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Users\\')
    assert script.endswith('\')\n$tmp = New-Item -Type Directory -Path $tmp_path -Name \'tmp\'')
    # Test with basefile
    script = shell.mkdtemp(basefile='test')
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Users\\')
    assert script.endswith('\')\n$tmp = New-Item -Type Directory -Path $tmp_path -Name \'test\'')
    # Test with tmpdir

# Generated at 2022-06-17 13:54:37.021745
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:45.187823
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == shell._encode_script(script='''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Users\\vagrant\\AppData\\Local\\Temp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmp'
        Write-Output -InputObject $tmp.FullName
        ''')
    assert shell.mkdtemp(tmpdir='/tmp') == shell._encode_script(script='''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('/tmp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmp'
        Write-Output -InputObject $tmp.FullName
        ''')

# Generated at 2022-06-17 13:54:50.189563
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:54.834123
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:58.883368
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:06.380992
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp('test') == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'test'
        Write-Output -InputObject $tmp.FullName
        ''' % shell.get_option('remote_tmp'))


# Generated at 2022-06-17 13:55:09.621620
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS


# Generated at 2022-06-17 13:55:18.738723
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:55:19.319238
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-17 13:55:22.852975
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:28.712774
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:37.900287
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:44.995896
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:53.042431
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-*'
        Write-Output -InputObject $tmp.FullName
        ''' % shell.get_option('remote_tmp'))

# Generated at 2022-06-17 13:55:58.555045
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:09.029006
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    cmd = shell.mkdtemp(basefile='ansible-tmp-', tmpdir='C:\\Users\\vagrant\\AppData\\Local\\Temp')

# Generated at 2022-06-17 13:56:14.978674
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:32.506369
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.txt') == 'test.txt'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.path_has_trailing_slash('/test/') is True
    assert shell.path_has_tra

# Generated at 2022-06-17 13:56:40.226666
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:48.719147
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    # Test with basefile
    basefile = 'ansible-tmp-1534752763.6-140176598849328'
    tmpdir = 'C:\\Users\\vagrant\\AppData\\Local\\Temp'
    script = shell.mkdtemp(basefile=basefile, tmpdir=tmpdir)
    assert script == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Users\\vagrant\\AppData\\Local\\Temp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-1534752763.6-140176598849328'
        Write-Output -InputObject $tmp.FullName
        '''
    # Test without basefile

# Generated at 2022-06-17 13:56:51.647668
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True

# Generated at 2022-06-17 13:56:56.217242
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:57:01.335399
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:57:04.995344
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:10.742506
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:19.936058
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    from ansible.module_utils.powershell import ShellModule
    from ansible.module_utils.six import PY3

    # Test with no basefile
    shell = ShellModule(connection=None)
    shell.get_option = lambda x: 'C:\\Users\\Administrator\\AppData\\Local\\Temp'
    cmd = shell.mkdtemp()
    if PY3:
        assert cmd == b'$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Users\\Administrator\\AppData\\Local\\Temp\'); $tmp = New-Item -Type Directory -Path $tmp_path -Name \'tmp\' ; Write-Output -InputObject $tmp.FullName ; '

# Generated at 2022-06-17 13:57:25.122854
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:39.243681
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:43.932591
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:47.831208
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:57:52.069277
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:01.866100
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    # Test with no basefile
    cmd = shell.mkdtemp()
    assert cmd.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\\\Windows\\\\TEMP\')')
    assert cmd.endswith('Write-Output -InputObject $tmp.FullName')
    # Test with basefile
    cmd = shell.mkdtemp(basefile='test')
    assert cmd.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\\\Windows\\\\TEMP\')')
    assert cmd.endswith('Write-Output -InputObject $tmp.FullName')
    # Test with tmpdir
    cmd = shell.mkdtemp(tmpdir='C:\\Users\\test\\AppData\\Local\\Temp')
    assert cmd

# Generated at 2022-06-17 13:58:06.557223
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:07.698606
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:58:11.371140
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-17 13:58:15.811765
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:21.356000
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:51.525203
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:57.759391
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:02.704833
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test the constructor of class ShellModule
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:59:12.737758
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('/tmp/test.txt') == 'test.txt'
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'

# Generated at 2022-06-17 13:59:16.681403
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:19.600937
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:24.537695
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:59:25.901230
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:59:34.552465
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.txt') == 'test.txt'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.path_has_trailing_slash('test\\') is True
    assert shell.path_has_trailing

# Generated at 2022-06-17 13:59:40.062820
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS == True
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.env_prefix() == ''
    assert sm.join_path('c:\\', 'a', 'b', 'c') == 'c:\\a\\b\\c'
    assert sm.join_path('c:\\', 'a', 'b', 'c\\') == 'c:\\a\\b\\c\\'
    assert sm.join_path('c:\\', 'a', 'b', 'c\\', '\\') == 'c:\\a\\b\\c\\'

# Generated at 2022-06-17 14:00:18.547749
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:21.745955
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 14:00:27.457123
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:32.044107
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:40.107558
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'



# Generated at 2022-06-17 14:00:45.190146
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:54.123206
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell.get_remote_filename('/tmp/test.txt') == 'test.txt'
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.join_path('C:\\', 'tmp', 'test')

# Generated at 2022-06-17 14:01:01.125826
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 14:01:07.225963
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:01:13.142564
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

