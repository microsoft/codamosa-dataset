

# Generated at 2022-06-17 13:51:16.788687
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:51:28.552631
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    # Test with no basefile
    cmd = shell.mkdtemp()
    assert cmd.startswith("$tmp_path = [System.Environment]::ExpandEnvironmentVariables('")
    assert cmd.endswith("');\n$tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmp';\nWrite-Output -InputObject $tmp.FullName;")
    # Test with basefile
    cmd = shell.mkdtemp(basefile='test')
    assert cmd.startswith("$tmp_path = [System.Environment]::ExpandEnvironmentVariables('")
    assert cmd.endswith("');\n$tmp = New-Item -Type Directory -Path $tmp_path -Name 'test';\nWrite-Output -InputObject $tmp.FullName;")
    # Test with

# Generated at 2022-06-17 13:51:43.390523
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Users\\vagrant\\AppData\\Local\\Temp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmp'
        Write-Output -InputObject $tmp.FullName
        ''')
    assert shell.mkdtemp(basefile='test') == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Users\\vagrant\\AppData\\Local\\Temp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'test'
        Write-Output -InputObject $tmp.FullName
        ''')
    assert shell

# Generated at 2022-06-17 13:51:50.171475
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell import ShellModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})
    shell = ShellModule(connection=None, no_log=True)
    cmd = 'echo "hello world"'
    shebang = '#!powershell'
    env_string = '$env:ANSIBLE_MODULE_ARGS = ConvertTo-Json @{}'
    result = shell.build_module_command(env_string, shebang, cmd)
    if PY2:
        assert result == '& type echo.ps1 | & $env:ANSIBLE_MODULE_ARGS = ConvertTo-Json @{}; echo "hello world"; exit $LASTEXITCODE'


# Generated at 2022-06-17 13:51:57.929664
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:52:10.018074
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell.ShellModule as ShellModule
    import ansible.executor.powershell.common as common
    import ansible.module_utils.powershell as powershell

    # Test with a binary module
    cmd = 'Test-Module'
    shebang = None
    arg_path = 'C:\\Users\\Administrator\\AppData\\Local\\Temp\\ansible_powershell_payload_15277715.ps1'
    env_string = '$env:ANSIBLE_MODULE_ARGS=\'{"ANSIBLE_MODULE_ARGS": "Test-Module"}\''

# Generated at 2022-06-17 13:52:16.833443
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.py') == 'test.py.ps1'


# Generated at 2022-06-17 13:52:24.583782
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.py') == 'test.py.ps1'
    assert shell.get_remote_filename('/tmp/test.pyc') == 'test.pyc.ps1'
    assert shell.get_remote_filename('/tmp/test.py.c') == 'test.py.c.ps1'

# Generated at 2022-06-17 13:52:34.814133
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test.sh') == 'test.sh.ps1'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.') == 'test..ps1'
    assert shell.get_remote_filename('/tmp/test.sh.ps1') == 'test.sh.ps1'
    assert shell.get_remote_filename('/tmp/test.sh.exe') == 'test.sh.exe'


# Generated at 2022-06-17 13:52:42.763173
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    shell.get_option = lambda x: 'C:\\Users\\Administrator\\AppData\\Local\\Temp'
    script = shell.mkdtemp()
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Users\\Administrator\\AppData\\Local\\Temp\')')
    assert script.endswith('Write-Output -InputObject $tmp.FullName')


# Generated at 2022-06-17 13:53:00.555022
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\')
    assert shell.path_has_trailing_slash('C:\\test\\')
    assert not shell.path_has_trailing_slash('C:\\test')
    assert not shell.path_has_trailing_slash('C:')
    assert shell.path_has_trailing_slash('C:\\test\\test2\\')
    assert shell.path_has_trailing_slash('C:\\test\\test2\\test3\\')
    assert shell.path_has_trailing_slash('C:\\test\\test2\\test3\\test4\\')

# Generated at 2022-06-17 13:53:04.901216
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:53:09.115637
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:14.459699
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/foo/bar/')
    assert shell.path_has_trailing_slash('/foo/bar\\')
    assert not shell.path_has_trailing_slash('/foo/bar')
    assert not shell.path_has_trailing_slash('/foo/bar/baz')
    assert not shell.path_has_trailing_slash('/foo/bar\\baz')
    assert not shell.path_has_trailing_slash('/foo/bar/baz/')
    assert not shell.path_has_trailing_slash('/foo/bar\\baz\\')


# Generated at 2022-06-17 13:53:27.475249
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    # Test with no basefile
    cmd = shell.mkdtemp()
    assert cmd.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Windows\\Temp\')')
    assert cmd.endswith('Write-Output -InputObject $tmp.FullName')
    # Test with basefile
    cmd = shell.mkdtemp(basefile='ansible-test')
    assert cmd.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Windows\\Temp\')')
    assert cmd.endswith('Write-Output -InputObject $tmp.FullName')
    assert 'ansible-test' in cmd
    # Test with tmpdir

# Generated at 2022-06-17 13:53:37.757289
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with no arguments
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.env_prefix() == ''
    assert shell.join_path('/', 'tmp', 'test.txt') == '\\tmp\\test.txt'
    assert shell.get_remote_filename('test.txt') == 'test.txt'
    assert shell.path_has_trailing_slash('/tmp/') is True
    assert shell.path_has_trailing_slash('/tmp') is False

# Generated at 2022-06-17 13:53:48.728970
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test with a binary module
    module = ShellModule()
    shebang = '#!/usr/bin/python'
    cmd = 'testmodule arg1 arg2'
    arg_path = '/path/to/arg/file'

# Generated at 2022-06-17 13:53:54.073276
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:00.377693
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:04.948363
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test for constructor of class ShellModule
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-17 13:54:14.825035
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('test') == shell._encode_script("Write-Output 'test'")

# Generated at 2022-06-17 13:54:19.526234
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('test') == shell._encode_script("Write-Output 'test'")


# Generated at 2022-06-17 13:54:26.172720
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('test') == shell._encode_script("Write-Output 'test'")

# Generated at 2022-06-17 13:54:31.933853
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.plugins.shell import ShellModule
    shell = ShellModule(connection=None)
    assert shell.expand_user('~') == shell._encode_script("Write-Output (Get-Location).Path")
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('test') == shell._encode_script("Write-Output 'test'")

# Generated at 2022-06-17 13:54:35.492414
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:54:44.658010
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test constructor
    shell_module = ShellModule()

    # Test _parse_clixml
    assert shell_module._parse_clixml(b'#< CLIXML\r\n<Objs Version="1.1.0.1" xmlns="http://schemas.microsoft.com/powershell/2004/04"><S S="Error">Test error message</S></Objs>') == b'Test error message'

# Generated at 2022-06-17 13:54:50.099019
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:59.252335
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    basefile = 'ansible-tmp-1501095472.8-241879079395860'
    tmpdir = 'C:\\Users\\Administrator\\AppData\\Local\\Temp'
    script = shell.mkdtemp(basefile=basefile, tmpdir=tmpdir)
    assert script == b"$tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Users\\Administrator\\AppData\\Local\\Temp')\r\n$tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-1501095472.8-241879079395860'\r\nWrite-Output -InputObject $tmp.FullName\r\n"


# Generated at 2022-06-17 13:55:05.273882
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:55:14.535281
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name '%s'
        Write-Output -InputObject $tmp.FullName
        ''' % (shell.get_option('remote_tmp'), shell.__class__._generate_temp_dir_name()))

# Generated at 2022-06-17 13:55:24.005326
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:34.964601
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    result = shell.mkdtemp(basefile='ansible-tmp-', tmpdir='%TEMP%')

# Generated at 2022-06-17 13:55:40.888355
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:55:50.446113
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell.shell as shell
    import ansible.executor.powershell.common as common
    import ansible.executor.powershell.module_common as module_common
    import ansible.executor.powershell.module_utils.basic as basic
    import ansible.executor.powershell.module_utils.common as module_utils_common
    import ansible.executor.powershell.module_utils.json_utils as json_utils
    import ansible.executor.powershell.module_utils.text as module_utils_text
    import ansible.executor.powershell.module_utils.win_file as win_file
    import ansible.executor.powershell.module_utils.win_package as win_package
    import ansible.executor.powershell.module_utils.win

# Generated at 2022-06-17 13:55:56.559276
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-*'
        Write-Output -InputObject $tmp.FullName
        '''

# Generated at 2022-06-17 13:56:02.226281
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:06.456821
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-17 13:56:10.509582
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with no arguments
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:22.938708
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('/tmp/test.sh') == 'test.sh'
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.join_path('c:\\', 'tmp', 'test')

# Generated at 2022-06-17 13:56:25.770148
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'


# Generated at 2022-06-17 13:56:39.379866
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:43.722153
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:48.105013
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:00.737191
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test.py') == 'test.ps1'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.sh') == 'test.ps1'
    assert shell.get_remote

# Generated at 2022-06-17 13:57:05.845795
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with no arguments
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:57:11.440646
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:16.342420
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:17.536734
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:57:22.820104
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:28.225426
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:40.888670
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:46.446954
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:57:50.546121
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:57:54.069480
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:58.960744
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS == True
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:03.949256
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:09.138023
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:19.959000
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with no arguments
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.join_path('C:\\', 'test') == 'C:\\test'

# Generated at 2022-06-17 13:58:25.326989
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:30.162711
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:43.517879
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:58:47.253601
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:53.247454
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'



# Generated at 2022-06-17 13:58:59.251068
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:05.443421
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:13.691429
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with no args
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.DEFAULT_EXECUTABLE == 'powershell'
    assert shell.DEFAULT_ARGS == '-NoProfile -NonInteractive -ExecutionPolicy Unrestricted'
    assert shell.BINARY_MODULES == {}
    assert shell.BINARY_MODULES_SHELL_TRANSPORT == {}

# Generated at 2022-06-17 13:59:17.623557
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:29.954137
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager

    # Create a mock task result
    task_result = TaskResult(host=Host(name='testhost'), return_data={'invocation': {'module_args': 'echo hello'}})

    # Create a mock play context
    play_context = PlayContext()

    # Create a mock variable manager
    variable_manager = VariableManager()
    variable_manager._hostvars = HostVars(host=Host(name='testhost'), variables={'ansible_connection': 'winrm'})

   

# Generated at 2022-06-17 13:59:37.983597
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:49.015218
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.env_prefix() == ""
    assert shell.join_path("C:\\", "Users", "test") == "C:\\Users\\test"
    assert shell.join_path("C:\\", "Users", "test\\") == "C:\\Users\\test"
    assert shell.join_path("C:\\", "Users", "test\\\\") == "C:\\Users\\test"
    assert shell.join_path("C:\\", "Users", "test", "\\") == "C:\\Users\\test"

# Generated at 2022-06-17 14:00:35.294751
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-17 14:00:41.717047
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS is True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'

# Generated at 2022-06-17 14:00:46.299276
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 14:00:51.057443
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:58.161672
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'


# Generated at 2022-06-17 14:01:02.803103
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:01:07.148916
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS is True
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module.COMPATIBLE_SHELLS == frozenset()