

# Generated at 2022-06-17 13:51:24.693432
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-17 13:51:35.861601
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\')
    assert shell.path_has_trailing_slash('C:\\foo\\')
    assert shell.path_has_trailing_slash('C:/')
    assert shell.path_has_trailing_slash('C:/foo/')
    assert not shell.path_has_trailing_slash('C:')
    assert not shell.path_has_trailing_slash('C:foo')
    assert not shell.path_has_trailing_slash('C:foo\\')
    assert not shell.path_has_trailing_slash('C:foo/')
    assert not shell.path_has_trailing_slash('C:\\foo')
    assert not shell.path_has_trailing_

# Generated at 2022-06-17 13:51:40.892207
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.sh') == 'test.sh.ps1'
    assert shell.path_has_trailing_slash('/test/') is True
    assert shell.path_

# Generated at 2022-06-17 13:51:46.829195
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:51:50.092681
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:51:59.846351
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/home/test/')
    assert shell.path_has_trailing_slash('/home/test\\')
    assert not shell.path_has_trailing_slash('/home/test')
    assert not shell.path_has_trailing_slash('/home/test/file.txt')
    assert not shell.path_has_trailing_slash('/home/test\\file.txt')


# Generated at 2022-06-17 13:52:04.412604
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/path/to/file.ps1') == 'file.ps1'
    assert shell.get_remote_filename('/path/to/file.exe') == 'file.exe'
    assert shell.get_remote_filename('/path/to/file.sh') == 'file.sh.ps1'
    assert shell.get_remote_filename('/path/to/file') == 'file.ps1'
    assert shell.get_remote_filename('file.ps1') == 'file.ps1'
    assert shell.get_remote_filename('file.exe') == 'file.exe'
    assert shell.get_remote_filename('file.sh') == 'file.sh.ps1'

# Generated at 2022-06-17 13:52:16.373710
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/path/to/file.ps1') == 'file.ps1'
    assert shell.get_remote_filename('/path/to/file.exe') == 'file.exe'
    assert shell.get_remote_filename('/path/to/file.sh') == 'file.sh.ps1'
    assert shell.get_remote_filename('/path/to/file') == 'file.ps1'
    assert shell.get_remote_filename('/path/to/file.sh.ps1') == 'file.sh.ps1'
    assert shell.get_remote_filename('/path/to/file.sh.exe') == 'file.sh.exe'

# Generated at 2022-06-17 13:52:22.129540
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell.ShellModule as ShellModule
    import ansible.module_utils.powershell as powershell
    import ansible.module_utils.basic as basic
    import ansible.module_utils.six as six

    # Test for pipelining bypass
    cmd = ''
    shebang = '#!powershell'
    env_string = '$env:ANSIBLE_MODULE_ARGS=\'' + basic.jsonify(dict(ANSIBLE_MODULE_ARGS=dict(a=1, b=2))) + '\''
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

# Generated at 2022-06-17 13:52:33.227743
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/path/to/file.ps1') == 'file.ps1'
    assert shell.get_remote_filename('/path/to/file.exe') == 'file.exe'
    assert shell.get_remote_filename('/path/to/file.txt') == 'file.ps1'
    assert shell.get_remote_filename('/path/to/file') == 'file.ps1'
    assert shell.get_remote_filename('file.ps1') == 'file.ps1'
    assert shell.get_remote_filename('file.exe') == 'file.exe'
    assert shell.get_remote_filename('file.txt') == 'file.ps1'
    assert shell.get_remote_filename('file') == 'file.ps1'


# Generated at 2022-06-17 13:52:46.872196
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.join_path('C:\\', 'test') == 'C:\\test'
    assert shell.join_path('C:\\', 'test', 'test2') == 'C:\\test\\test2'


# Generated at 2022-06-17 13:53:00.048880
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script("Write-Output (Get-Location).Path")
    assert shell.expand_user('~\\') == shell._encode_script("Write-Output ((Get-Location).Path + '')")
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('~\\test\\') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\')")
    assert shell.expand_user('~\\test\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\test')")

# Generated at 2022-06-17 13:53:05.498110
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script(script='Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\foo') == shell._encode_script(script="Write-Output ((Get-Location).Path + '\\foo')")
    assert shell.expand_user('foo') == shell._encode_script(script="Write-Output 'foo'")

# Generated at 2022-06-17 13:53:12.982473
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.sh') == 'test.sh.ps1'

# Generated at 2022-06-17 13:53:25.948426
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-*'
        Write-Output -InputObject $tmp.FullName
        ''' % shell.get_option('remote_tmp'))

# Generated at 2022-06-17 13:53:31.451716
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:35.961883
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS


# Generated at 2022-06-17 13:53:45.814160
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmp'
        Write-Output -InputObject $tmp.FullName
        ''')
    assert shell.mkdtemp(basefile='test') == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'test'
        Write-Output -InputObject $tmp.FullName
        ''')
    assert shell.mkdtemp(basefile='test', tmpdir='/tmp')

# Generated at 2022-06-17 13:53:56.180794
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    basefile = 'ansible-tmp-1528234912.8-149780790786596'
    tmpdir = 'C:\\Users\\ADMINI~1\\AppData\\Local\\Temp'
    script = shell.mkdtemp(basefile=basefile, tmpdir=tmpdir)
    assert script == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Users\\ADMINI~1\\AppData\\Local\\Temp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-1528234912.8-149780790786596'
        Write-Output -InputObject $tmp.FullName
        '''

# Generated at 2022-06-17 13:54:02.735963
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:13.683717
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:17.169205
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-17 13:54:28.666573
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test.ps1.exe') == 'test.ps1.exe'

# Generated at 2022-06-17 13:54:36.492881
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:41.734044
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:53.326154
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    # Test with no basefile
    script = shell.mkdtemp()
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Windows\\TEMP\')')
    assert script.endswith('Write-Output -InputObject $tmp.FullName')
    # Test with basefile
    script = shell.mkdtemp(basefile='ansible-tmp-')
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Windows\\TEMP\')')
    assert script.endswith('Write-Output -InputObject $tmp.FullName')
    # Test with tmpdir
    script = shell.mkdtemp(tmpdir='C:\\temp')
    assert script.startswith

# Generated at 2022-06-17 13:54:56.240844
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-17 13:55:02.776860
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:55:08.270494
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:55:12.287463
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Create a new instance of ShellModule
    shell = ShellModule()
    # Call method mkdtemp of class ShellModule
    result = shell.mkdtemp()
    # Check if the result is not None
    assert result is not None
    # Check if the result is a string
    assert isinstance(result, str)


# Generated at 2022-06-17 13:55:28.360341
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import tempfile
    import shutil
    import os
    import re

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_file2 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_file3 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_file4 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_file5 = tempfile.mkstemp()
    os.close(fd)

    # Create

# Generated at 2022-06-17 13:55:33.471373
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:47.065169
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell.ShellModule as ShellModule
    import ansible.module_utils.powershell as powershell
    import os
    import tempfile
    import shutil
    import pkgutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary powershell module
    module_name = 'TestModule'
    module_path = os.path.join(tmpdir, module_name + '.psm1')
    module_content = '''
    function TestModule {
        Write-Output "TestModule"
    }
    '''
    with open(module_path, 'w') as f:
        f.write(module_content)

    # Create a temporary powershell script
    script_name = 'TestScript'

# Generated at 2022-06-17 13:55:51.759175
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    script = shell.mkdtemp(basefile='ansible-tmp-', tmpdir='/tmp')
    assert script == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('/tmp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-'
        Write-Output -InputObject $tmp.FullName
        '''


# Generated at 2022-06-17 13:55:57.791506
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:03.766620
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.py') == 'test.ps1'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.path_has_trailing_slash('C:\\') is True
    assert shell.path_has_

# Generated at 2022-06-17 13:56:06.002409
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:56:09.937120
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:22.427973
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.env_prefix() == ''
    assert shell.join_path('c:\\', 'temp', 'test') == 'c:\\temp\\test'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.path_has_trailing_slash('c:\\temp\\test\\') is True
    assert shell.path_has_

# Generated at 2022-06-17 13:56:28.147902
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:52.236640
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell.ShellModule as ShellModule
    import ansible.executor.powershell.common as common
    import ansible.module_utils.powershell as powershell
    import ansible.module_utils.powershell.common as powershell_common
    import ansible.module_utils.powershell.text as powershell_text
    import ansible.module_utils.powershell.winrm as winrm

    # Create a mock object for the powershell.ps1 script

# Generated at 2022-06-17 13:56:59.185875
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:03.472850
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:05.239401
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:57:15.910083
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    # Test with shebang
    shebang = '#!powershell'
    cmd = '$a = 1; $b = 2; $a + $b'
    cmd_parts = shell.build_module_command('', shebang, cmd)
    assert cmd_parts == shell._encode_script(script=cmd, strict_mode=False, preserve_rc=False)
    # Test with shebang and arg_path
    shebang = '#!powershell'
    cmd = '$a = 1; $b = 2; $a + $b'
    arg_path = 'C:\\Users\\Administrator\\AppData\\Local\\Temp\\ansible-tmp-1535306059.24-226909898125798\\AnsiballZ_setup.ps1'
    cmd_parts = shell

# Generated at 2022-06-17 13:57:20.083190
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:24.943935
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:57:34.965130
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test with a binary module
    module_name = 'win_ping'
    module_args = '-c 2'
    shebang = None
    arg_path = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\Modules\\Ansible.ModuleUtils.Legacy.PS1'

    shell = ShellModule()
    cmd = shell.build_module_command(env_string='', shebang=shebang, cmd=module_name, arg_path=arg_path)
    cmd_parts = shlex.split(cmd, posix=False)
    cmd_parts = list(map(to_text, cmd_parts))
    assert cmd_parts[-1] == arg_path
    assert cmd_parts[-2] == module_args
    assert cmd_parts[-3] == module_name



# Generated at 2022-06-17 13:57:42.159823
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:47.652656
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:59.801978
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:04.469052
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:15.041893
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.txt') == 'test.txt'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.path_has_trailing_slash('/test/')
    assert shell.path_has_trailing_slash('/test\\')

# Generated at 2022-06-17 13:58:26.089470
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('/tmp/test.sh') == 'test.sh'
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'

# Generated at 2022-06-17 13:58:30.789919
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:39.486979
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'


# Generated at 2022-06-17 13:58:50.523675
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with no arguments
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

    # Test with arguments
    shell = ShellModule(SHELL_FAMILY='test_family', COMPATIBLE_SHELLS=['test_shell'], IS_WINDOWS=False, SHELL_REDIRECT_ALLNULL='test_redirect', SHELL_AND='test_and')
    assert shell.SHELL_FAMILY == 'test_family'
    assert shell.COMPATIBLE_SHELLS == frozenset(['test_shell'])

# Generated at 2022-06-17 13:58:56.328993
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:59:07.974172
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_option('remote_tmp') == '$env:TEMP'
    assert shell.get_option('_ansible_tmpdir') == '$env:TEMP'
    assert shell.get_option('_ansible_no_log') == False
    assert shell.get_option('_ansible_verbosity') == 0

# Generated at 2022-06-17 13:59:12.656889
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:34.528916
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS

# Generated at 2022-06-17 13:59:42.287163
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:47.005016
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:50.496992
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:55.121695
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:00.387156
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:02.981633
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS == True

# Generated at 2022-06-17 14:00:06.509554
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test the constructor of class ShellModule
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-17 14:00:11.880844
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:22.242179
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('/tmp/test.txt') == 'test.txt'
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'

# Generated at 2022-06-17 14:01:01.760995
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS == True
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'


# Generated at 2022-06-17 14:01:07.034156
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 14:01:11.055882
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
