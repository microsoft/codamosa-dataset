

# Generated at 2022-06-17 13:51:17.461740
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:51:29.617411
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    assert shell.build_module_command('', '', 'echo "hello"') == shell._encode_script('echo "hello"')
    assert shell.build_module_command('', '#!powershell', 'echo "hello"') == shell._encode_script('echo "hello"', strict_mode=False)
    assert shell.build_module_command('', '#!powershell', 'echo "hello"', arg_path='/tmp/foo') == shell._encode_script('echo "hello" "/tmp/foo"', strict_mode=False)
    assert shell.build_module_command('', '#!/bin/bash', 'echo "hello"') == shell._encode_script('echo "hello"', strict_mode=False)

# Generated at 2022-06-17 13:51:38.608705
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\foo') == shell._encode_script("Write-Output ((Get-Location).Path + '\\foo')")
    assert shell.expand_user('foo') == shell._encode_script("Write-Output 'foo'")

# Generated at 2022-06-17 13:51:47.959212
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    basefile = 'ansible-tmp-1524-24'
    tmpdir = 'C:\\Users\\Administrator\\AppData\\Local\\Temp'
    script = shell.mkdtemp(basefile=basefile, tmpdir=tmpdir)
    assert script == b'$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Users\\Administrator\\AppData\\Local\\Temp\'); $tmp = New-Item -Type Directory -Path $tmp_path -Name \'ansible-tmp-1524-24\'; Write-Output -InputObject $tmp.FullName;'


# Generated at 2022-06-17 13:51:59.846760
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\') == shell._encode_script("Write-Output ((Get-Location).Path + '')")
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('~\\test\\') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\')")
    assert shell.expand_user('~\\test\\test2') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\test2')")

# Generated at 2022-06-17 13:52:07.007123
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.plugins.shell import ShellModule
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('test') == shell._encode_script("Write-Output 'test'")

# Generated at 2022-06-17 13:52:12.991496
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:52:21.827048
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.txt') == 'test.txt.ps1'
    assert shell.get_remote_filename('/tmp/test.txt.ps1') == 'test.txt.ps1'
    assert shell.get_remote_filename('/tmp/test.txt.exe') == 'test.txt.exe'


# Generated at 2022-06-17 13:52:30.603099
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.py') == 'test.py.ps1'
    assert shell.get_remote_filename('/tmp/test.py.ps1') == 'test.py.ps1'


# Generated at 2022-06-17 13:52:43.692005
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\') == shell._encode_script("Write-Output ((Get-Location).Path + '')")
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('~\\test\\') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\')")
    assert shell.expand_user('~\\test\\test2') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\test2')")

# Generated at 2022-06-17 13:53:01.637665
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == shell._encode_script("""
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-*'
        Write-Output -InputObject $tmp.FullName
        """ % shell.get_option('remote_tmp'))
    assert shell.mkdtemp(basefile='test') == shell._encode_script("""
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'test'
        Write-Output -InputObject $tmp.FullName
        """ % shell.get_option('remote_tmp'))

# Generated at 2022-06-17 13:53:05.965194
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with no arguments
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_AND == ';'
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-17 13:53:09.002071
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:53:14.935630
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/')
    assert shell.path_has_trailing_slash('/foo/bar/')
    assert shell.path_has_trailing_slash('/foo/bar\\')
    assert shell.path_has_trailing_slash('c:\\foo\\bar\\')
    assert shell.path_has_trailing_slash('c:/foo/bar/')
    assert not shell.path_has_trailing_slash('/foo/bar')
    assert not shell.path_has_trailing_slash('/foo/bar\\')
    assert not shell.path_has_trailing_slash('c:\\foo\\bar\\')
    assert not shell.path_has_trailing_slash('c:/foo/bar')

# Generated at 2022-06-17 13:53:27.906364
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/')
    assert shell.path_has_trailing_slash('\\')
    assert shell.path_has_trailing_slash('/foo/bar/')
    assert shell.path_has_trailing_slash('\\foo\\bar\\')
    assert not shell.path_has_trailing_slash('/foo/bar')
    assert not shell.path_has_trailing_slash('\\foo\\bar')
    assert not shell.path_has_trailing_slash('foo/bar')
    assert not shell.path_has_trailing_slash('foo\\bar')
    assert not shell.path_has_trailing_slash('foo/bar/')
    assert not shell.path_has_trailing_sl

# Generated at 2022-06-17 13:53:38.041244
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-*'
        Write-Output -InputObject $tmp.FullName
        ''' % shell.get_option('remote_tmp'))

# Generated at 2022-06-17 13:53:42.297922
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:54.891114
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS is True
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.env_prefix() == ''
    assert sm.join_path('c:\\', 'a', 'b') == 'c:\\a\\b'
    assert sm.join_path('c:\\', 'a', 'b\\') == 'c:\\a\\b'
    assert sm.join_path('c:\\', 'a\\', 'b') == 'c:\\a\\b'
    assert sm.join_path('c:\\', 'a\\', 'b\\') == 'c:\\a\\b'

# Generated at 2022-06-17 13:54:06.571877
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/tmp/')
    assert shell.path_has_trailing_slash('/tmp\\')
    assert not shell.path_has_trailing_slash('/tmp')
    assert not shell.path_has_trailing_slash('/tmp/foo')
    assert not shell.path_has_trailing_slash('/tmp\\foo')
    assert shell.path_has_trailing_slash('/tmp/foo/')
    assert shell.path_has_trailing_slash('/tmp\\foo\\')
    assert not shell.path_has_trailing_slash('/tmp/foo/bar')
    assert not shell.path_has_trailing_slash('/tmp\\foo\\bar')
    assert shell.path

# Generated at 2022-06-17 13:54:12.344403
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:22.412516
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Test with no basefile
    shell = ShellModule()
    script = shell.mkdtemp()
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Users\\')
    assert script.endswith('\n$tmp = New-Item -Type Directory -Path $tmp_path -Name \'tmp\'\nWrite-Output -InputObject $tmp.FullName\n')

    # Test with basefile
    shell = ShellModule()
    script = shell.mkdtemp(basefile='test')
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Users\\')

# Generated at 2022-06-17 13:54:27.206949
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:31.891443
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:37.626687
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:42.421101
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:53.662833
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('/tmp/test.txt') == 'test.txt'
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'

# Generated at 2022-06-17 13:54:58.578308
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.env_prefix() == ''


# Generated at 2022-06-17 13:55:05.110245
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:14.440244
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.path_has_trailing_slash('test\\') is True
    assert shell.path_has_trailing_slash('test/') is True


# Generated at 2022-06-17 13:55:17.633569
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:55:35.868354
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    # Test with no basefile
    script = shell.mkdtemp()
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Users\\')
    assert script.endswith('\')\n$tmp = New-Item -Type Directory -Path $tmp_path -Name \'tmp\'')
    # Test with basefile
    script = shell.mkdtemp(basefile='test')
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Users\\')
    assert script.endswith('\')\n$tmp = New-Item -Type Directory -Path $tmp_path -Name \'test\'')
    # Test with tmpdir

# Generated at 2022-06-17 13:55:48.056557
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    script = shell.mkdtemp()
    assert script == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-*'
        Write-Output -InputObject $tmp.FullName
        '''.strip()
    script = shell.mkdtemp(basefile='ansible-tmp-test')
    assert script == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-test'
        Write-Output -InputObject $tmp.FullName
        '''.strip()
    script = shell.mk

# Generated at 2022-06-17 13:55:50.621757
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True

# Generated at 2022-06-17 13:55:56.322560
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:01.970639
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:06.924998
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:13.810306
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:19.534841
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:25.000896
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:30.522945
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:00.342240
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with no arguments
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_EXECUTABLE == 'powershell'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_EXECUTABLE == 'powershell'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_EX

# Generated at 2022-06-17 13:57:07.974827
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    # Test with basefile
    basefile = 'ansible-tmp-1516058984.5-149765019749587'
    result = shell.mkdtemp(basefile=basefile)

# Generated at 2022-06-17 13:57:13.223517
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:17.858224
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:23.456542
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:26.661781
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:57:31.805593
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:44.213302
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.env_prefix() == ''
    assert shell.join_path('C:\\', 'Users', 'Administrator') == 'C:\\Users\\Administrator'
    assert shell.get_remote_filename('C:\\Users\\Administrator\\test.ps1') == 'test.ps1'
    assert shell.path_has_trailing_slash('C:\\Users\\Administrator\\') == True
    assert shell.path_has_trailing_slash('C:\\Users\\Administrator') == False
    assert shell.chmod('C:\\Users\\Administrator\\test.ps1', '777') == Not

# Generated at 2022-06-17 13:57:48.010469
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True


# Generated at 2022-06-17 13:57:55.445678
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    from ansible.module_utils.powershell import ShellModule
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a ShellModule object

# Generated at 2022-06-17 13:58:15.448756
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS is True
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:26.497600
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.env_prefix() == ""
    assert shell.join_path('c:\\', 'foo', 'bar') == 'c:\\foo\\bar'
    assert shell.get_remote_filename('foo.ps1') == 'foo.ps1'
    assert shell.get_remote_filename('foo.py') == 'foo.ps1'
    assert shell.get_remote_filename('foo.exe') == 'foo.exe'
    assert shell.path_has_trailing_slash('c:\\foo\\') == True

# Generated at 2022-06-17 13:58:29.394344
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS == True


# Generated at 2022-06-17 13:58:44.447916
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Test with no arguments
    shell = ShellModule()
    cmd = shell.mkdtemp()
    assert cmd.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Windows\\TEMP\')\n$tmp = New-Item -Type Directory -Path $tmp_path -Name \'')
    assert cmd.endswith('\nWrite-Output -InputObject $tmp.FullName\n')

    # Test with basefile
    shell = ShellModule()
    cmd = shell.mkdtemp(basefile='test')
    assert cmd.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'C:\\Windows\\TEMP\')\n$tmp = New-Item -Type Directory -Path $tmp_path -Name \'test')
    assert cmd.end

# Generated at 2022-06-17 13:58:48.149544
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:58:54.097364
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:00.045702
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:04.349320
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:59:09.583427
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:17.792542
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.env_prefix() == ""
    assert shell.join_path('/', 'tmp', 'test') == '\\tmp\\test'
    assert shell.get_remote_filename('test.txt') == 'test.txt'
    assert shell.path_has_trailing_slash('/tmp/test/') == True
    assert shell.path_has_trailing_slash('/tmp/test') == False
    assert shell.chmod('/tmp/test', '777') == NotImplementedError('chmod is not implemented for Powershell')
    assert shell.chown('/tmp/test', 'root')

# Generated at 2022-06-17 14:00:15.191247
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:26.071413
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test shebang
    shebang = '#!powershell'
    cmd = 'Get-ChildItem'
    sm = ShellModule()
    result = sm.build_module_command('', shebang, cmd)

# Generated at 2022-06-17 14:00:31.004085
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:38.678934
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 14:00:48.890868
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._IS_WINDOWS is True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.env_prefix() == ''
    assert shell.join_path('C:\\', 'foo', 'bar') == 'C:\\foo\\bar'
    assert shell.join_path('C:\\', 'foo', 'bar\\') == 'C:\\foo\\bar'
    assert shell.join_path('C:\\', 'foo\\', 'bar\\') == 'C:\\foo\\bar'

# Generated at 2022-06-17 14:00:52.756505
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:01:00.733619
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:01:03.930213
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
