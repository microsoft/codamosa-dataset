

# Generated at 2022-06-17 13:51:26.699714
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.txt') == 'test.txt.ps1'
    assert shell.get_remote_filename('/tmp/test.txt.ps1') == 'test.txt.ps1'
    assert shell.get_remote_filename('/tmp/test.txt.exe') == 'test.txt.exe'
    assert shell.get_remote_filename('/tmp/test.txt.exe.ps1') == 'test.txt.exe.ps1'


# Generated at 2022-06-17 13:51:30.266613
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:51:37.996004
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:51:49.076591
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell.ShellModule as ShellModule
    import ansible.module_utils.powershell as powershell
    import ansible.module_utils.basic as basic
    import ansible.module_utils.six as six
    import ansible.module_utils.urls as urls
    import ansible.module_utils.winrm as winrm
    import ansible.module_utils.windows.win_file as win_file
    import ansible.module_utils.windows.win_path as win_path
    import ansible.module_utils.windows.win_system as win_system
    import ansible.module_utils.windows.win_tempfile as win_tempfile
    import ansible.module_utils.windows.win_unzip as win_unzip
    import ansible.module_utils.windows.win

# Generated at 2022-06-17 13:51:56.932253
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\foo') == shell._encode_script("Write-Output ((Get-Location).Path + '\\foo')")
    assert shell.expand_user('foo') == shell._encode_script("Write-Output 'foo'")

# Generated at 2022-06-17 13:52:08.656542
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmp'
        Write-Output -InputObject $tmp.FullName
        ''')
    assert shell.mkdtemp(basefile='test') == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'test'
        Write-Output -InputObject $tmp.FullName
        ''')
    assert shell.mkdtemp(basefile='test', tmpdir='/tmp')

# Generated at 2022-06-17 13:52:15.478094
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script("Write-Output (Get-Location).Path")
    assert shell.expand_user('~\\foo') == shell._encode_script("Write-Output ((Get-Location).Path + '\\foo')")
    assert shell.expand_user('foo') == shell._encode_script("Write-Output 'foo'")


# Generated at 2022-06-17 13:52:23.900688
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell.connection import Connection
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Create a mock task to use for testing
    task = Task()
    task.action = 'win_ping'
    task.args = {}
    task.async_val = 0
    task.become = False
    task.become_method = None
    task.become_user = None
    task.delegate_to = None
    task.environment = None
    task.loop = None
    task.loop_args = None
    task.module_

# Generated at 2022-06-17 13:52:28.570390
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script("Write-Output (Get-Location).Path")
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('test') == shell._encode_script("Write-Output 'test'")

# Generated at 2022-06-17 13:52:43.036315
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-*'
        Write-Output -InputObject $tmp.FullName
        ''')

    assert shell.mkdtemp(basefile='ansible-tmp-test') == shell._encode_script('''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-test'
        Write-Output -InputObject $tmp.FullName
        ''')


# Generated at 2022-06-17 13:53:02.278837
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell import ShellModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Create a dummy module
    module = AnsibleModule(
        argument_spec=dict(
            cmd=dict(type='str', required=True),
            arg_path=dict(type='str', required=False),
            shebang=dict(type='str', required=False),
            env_string=dict(type='str', required=False),
        ),
        supports_check_mode=True
    )

    # Create a dummy shell module

# Generated at 2022-06-17 13:53:06.420093
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:13.555929
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    cmd = shell.build_module_command('', '#!powershell', 'Get-ChildItem')
    assert cmd == 'type Get-ChildItem.ps1 | & $PSHOME\\Modules\\Ansible\\Ansible.psm1; exit $LASTEXITCODE'
    cmd = shell.build_module_command('', '#!powershell', 'Get-ChildItem', '-Path C:\\temp')
    assert cmd == 'type Get-ChildItem.ps1 | & $PSHOME\\Modules\\Ansible\\Ansible.psm1; exit $LASTEXITCODE'
    cmd = shell.build_module_command('', '#!powershell', 'Get-ChildItem', '-Path C:\\temp -Recurse')

# Generated at 2022-06-17 13:53:20.755676
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:26.433219
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:32.203316
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-17 13:53:36.634773
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-17 13:53:42.248288
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:53:47.045815
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:53:52.827998
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:08.797078
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell import ShellModule
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # Test with a module that is a binary
    module_name = 'win_ping'
    module_args = 'arg1 arg2'
    shebang = '#!powershell'
    sm = ShellModule(connection=None)
    cmd = sm.build_module_command(env_string='', shebang=shebang, cmd=module_name, arg_path=module_args)

# Generated at 2022-06-17 13:54:12.300576
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:20.483402
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.path_has_trailing_slash('/test/') == True
    assert shell.path_has_trailing_slash('/test') == False
    assert shell.path_has_trailing_slash('C:\\test\\') == True

# Generated at 2022-06-17 13:54:31.472022
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/') == True
    assert shell.path_has_trailing_slash('\\') == True
    assert shell.path_has_trailing_slash('/foo/bar') == True
    assert shell.path_has_trailing_slash('\\foo\\bar') == True
    assert shell.path_has_trailing_slash('/foo/bar/') == True
    assert shell.path_has_trailing_slash('\\foo\\bar\\') == True
    assert shell.path_has_trailing_slash('foo/bar') == False
    assert shell.path_has_trailing_slash('foo\\bar') == False
    assert shell.path_has_trailing_slash('foo/bar/') == False


# Generated at 2022-06-17 13:54:42.460967
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\Users\\')
    assert shell.path_has_trailing_slash('C:\\Users\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\\\\\')
    assert not shell.path_has_trailing_

# Generated at 2022-06-17 13:54:47.680793
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, shell_type='powershell', no_log=False)
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'


# Generated at 2022-06-17 13:54:52.403967
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'


# Generated at 2022-06-17 13:54:57.134223
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:09.712023
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/tmp/')
    assert shell.path_has_trailing_slash('/tmp\\')
    assert not shell.path_has_trailing_slash('/tmp')
    assert not shell.path_has_trailing_slash('/tmp/test')
    assert not shell.path_has_trailing_slash('/tmp\\test')
    assert shell.path_has_trailing_slash('/tmp/test/')
    assert shell.path_has_trailing_slash('/tmp\\test\\')
    assert not shell.path_has_trailing_slash('/tmp/test/test')
    assert not shell.path_has_trailing_slash('/tmp\\test\\test')
    assert shell.path

# Generated at 2022-06-17 13:55:15.235889
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:31.079533
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test shebang
    shebang = '#!powershell'
    cmd = 'Get-ChildItem'
    arg_path = 'C:\\test'
    env_string = '$env:ANSIBLE_MODULE_ARGS="{\\"ANSIBLE_MODULE_ARGS\\": \\"\\"}"'
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

# Generated at 2022-06-17 13:55:39.828811
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:44.539399
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:55:48.467330
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:55:52.388256
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:58.125794
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:03.436137
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:06.588559
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:19.684797
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell.get_remote_filename('/tmp/test.txt') == 'test.txt'
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'

# Generated at 2022-06-17 13:56:22.618783
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:39.303517
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:43.417672
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with no arguments
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:45.013553
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test that the constructor of ShellModule does not raise an exception
    shell_module = ShellModule()
    assert shell_module is not None

# Generated at 2022-06-17 13:56:50.224061
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:52.749388
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    This is a test for the constructor of the class ShellModule
    """
    shell_module = ShellModule()
    assert shell_module is not None

# Generated at 2022-06-17 13:56:59.682517
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:02.520772
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:57:04.683351
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:57:10.337373
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:14.935393
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:28.690144
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:32.702574
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:37.567941
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-17 13:57:40.686468
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:42.490177
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:57:46.899284
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test the constructor of class ShellModule
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:57:48.277759
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:57:52.449442
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:57.582637
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:02.669592
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:14.911532
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:58:20.010879
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:25.025745
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:29.248455
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:37.363921
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:49.051053
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.join_path('c:\\', 'test') == 'c:\\test'
    assert shell.join_path('c:\\', 'test\\') == 'c:\\test'

# Generated at 2022-06-17 13:58:54.366507
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module._IS_WINDOWS == True

# Generated at 2022-06-17 13:59:00.241972
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True
    assert module._SHELL_AND == ';'
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-17 13:59:06.728164
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_AND == ';'
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-17 13:59:11.582668
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:48.405024
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell.SHELL_TYPE == 'powershell'
    assert shell.SHELL_NAME == 'powershell'
    assert shell.SHELL_VERSION == ''
    assert shell.SHELL_RELEASE == ''
    assert shell.SHELL_EPOCH == ''
    assert shell.SHELL_VARIANT == ''
    assert shell.SHELL_ARCH == ''
    assert shell.SHELL_API == ''
    assert shell.SHELL_API_VERSION == ''
    assert shell.SHELL_API_RELEASE == ''
    assert shell.SHELL_API_EPOCH == ''
    assert shell.SHELL_

# Generated at 2022-06-17 13:59:53.270761
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:03.939855
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.join_path('C:\\', 'test') == 'C:\\test'

# Generated at 2022-06-17 14:00:07.186687
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:13.046225
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:17.940852
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with no arguments
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS
    assert shell_module._SHELL_AND == ';'
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-17 14:00:22.114483
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 14:00:28.386459
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:32.738375
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:34.914048
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
