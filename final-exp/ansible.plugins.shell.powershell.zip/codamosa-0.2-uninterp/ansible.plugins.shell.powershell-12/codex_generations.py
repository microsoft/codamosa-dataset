

# Generated at 2022-06-17 13:51:31.439287
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS is True
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.get_remote_filename('test.ps1') == 'test.ps1'
    assert sm.get_remote_filename('test.exe') == 'test.exe'
    assert sm.get_remote_filename('test.sh') == 'test.ps1'
    assert sm.get_remote_filename('test') == 'test.ps1'
    assert sm.get_remote_filename('test.sh.ps1') == 'test.sh.ps1'
    assert sm.get_remote_filename('test.sh.exe') == 'test.sh.exe'

# Generated at 2022-06-17 13:51:40.370730
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\foo') == shell._encode_script("Write-Output ((Get-Location).Path + '\\foo')")
    assert shell.expand_user('foo') == shell._encode_script("Write-Output 'foo'")


# Generated at 2022-06-17 13:51:46.796812
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:51:49.780800
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:51:57.810109
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:52:09.910115
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/path/to/file.ps1') == 'file.ps1'
    assert shell.get_remote_filename('/path/to/file.exe') == 'file.exe'
    assert shell.get_remote_filename('/path/to/file.sh') == 'file.sh.ps1'
    assert shell.get_remote_filename('/path/to/file') == 'file.ps1'
    assert shell.get_remote_filename('file.ps1') == 'file.ps1'
    assert shell.get_remote_filename('file.exe') == 'file.exe'
    assert shell.get_remote_filename('file.sh') == 'file.sh.ps1'

# Generated at 2022-06-17 13:52:15.040722
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell.ShellModule as ShellModule
    import ansible.executor.powershell.bootstrap_wrapper as bootstrap_wrapper
    import ansible.module_utils.powershell as powershell
    import ansible.module_utils.basic as basic
    import ansible.module_utils.six as six
    import ansible.module_utils.urls as urls
    import ansible.module_utils.winrm as winrm
    import ansible.module_utils.windows.win_file as win_file
    import ansible.module_utils.windows.win_path as win_path
    import ansible.module_utils.windows.win_system as win_system
    import ansible.module_utils.windows.win_tempfile as win_tempfile
    import ansible.module_utils.windows.win

# Generated at 2022-06-17 13:52:23.653058
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\') == shell._encode_script("Write-Output ((Get-Location).Path + '')")
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('~\\test\\') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\')")
    assert shell.expand_user('~\\test\\test2') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\test2')")

# Generated at 2022-06-17 13:52:27.974597
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:52:33.077674
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('test') == shell._encode_script("Write-Output 'test'")

# Generated at 2022-06-17 13:52:46.319488
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell import ShellModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes

    # Test with a module that is a binary
    module_name = 'win_ping'
    module_args = '-a "hello"'
    env_string = '$env:ANSIBLE_MODULE_ARGS="%s";' % module_args
    shebang = None
    cmd = module_name
    arg_path = '$env:ANSIBLE_MODULE_ARGS'
    sm = ShellModule(ImmutableDict())
    result = sm.build_module_command(env_string, shebang, cmd, arg_path)

# Generated at 2022-06-17 13:52:47.494907
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:52:54.684311
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:52:57.167789
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True

# Generated at 2022-06-17 13:53:02.142447
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:12.558471
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\Windows\\') is True
    assert shell.path_has_trailing_slash('C:\\Windows') is False
    assert shell.path_has_trailing_slash('C:/Windows/') is True
    assert shell.path_has_trailing_slash('C:/Windows') is False
    assert shell.path_has_trailing_slash('C:\\Windows\\System32\\') is True
    assert shell.path_has_trailing_slash('C:\\Windows\\System32') is False
    assert shell.path_has_trailing_slash('C:/Windows/System32/') is True
    assert shell.path_has_trailing_slash('C:/Windows/System32') is False

# Generated at 2022-06-17 13:53:25.515271
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell.SHELL_TYPE == 'powershell'
    assert shell.DEFAULT_EXECUTABLE == 'powershell'
    assert shell.BINARY_MODULES_SHELL_TRANSPORT == 'winrm'
    assert shell.BINARY_MODULES_SHELL_INTERPRETER == 'powershell'
    assert shell.BINARY_MODULE_INTERPRETER_ARGS == ''
    assert shell.BINARY_MODULE_ENV_VARS == {}
    assert shell.BINARY_MODULE_COMPRESSED_TYPES == ['gz']
    assert shell.BIN

# Generated at 2022-06-17 13:53:36.375627
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\Users\\')
    assert shell.path_has_trailing_slash('C:\\Users\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\test2\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\test2\\\\')
    assert shell.path_

# Generated at 2022-06-17 13:53:40.400918
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:41.101109
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-17 13:53:53.606491
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:58.092979
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:54:03.981672
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-17 13:54:08.241815
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:18.650606
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import os
    import tempfile
    import shutil

    from ansible.module_utils.powershell import ShellModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary module file
    module_file = os.path.join(tmpdir, 'test_module.ps1')
    with open(module_file, 'w') as f:
        f.write('Write-Output "Hello, World!"')

    # Create a temporary argument file
    arg_file = os.path.join(tmpdir, 'test_module.json')
    with open(arg_file, 'w') as f:
        f.write('{"ANSIBLE_MODULE_ARGS": {"arg1": "value1", "arg2": "value2"}}')

    # Create a temporary environment file
    env_

# Generated at 2022-06-17 13:54:23.128219
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:54:27.897820
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:33.301458
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:37.772111
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-17 13:54:42.579984
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:07.867526
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:55:16.138549
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test for module command with shebang
    shell = ShellModule()
    cmd = shell.build_module_command(env_string='', shebang='#!powershell', cmd='test.ps1', arg_path='')

# Generated at 2022-06-17 13:55:24.861705
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell
    import ansible.plugins.shell
    import ansible.plugins.loader
    import ansible.plugins.connection.winrm
    import ansible.plugins.connection.psrp

    # Create a dummy module
    module_name = 'test_module'
    module_args = 'arg1 arg2'
    module_path = 'test_module.ps1'
    module_content = '''
    param (
        [string]$arg1,
        [string]$arg2
    )
    Write-Output "arg1=$arg1"
    Write-Output "arg2=$arg2"
    '''
    module_file = open(module_path, 'w')
    module_file.write(module_content)
    module_file.close()

    # Create a dummy connection

# Generated at 2022-06-17 13:55:29.315987
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-17 13:55:37.660525
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:42.575675
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS


# Generated at 2022-06-17 13:55:47.256673
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:54.660860
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    cmd = shell.build_module_command('', '#!powershell', 'Test-Module')
    assert cmd == shell._encode_script(script=pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"), strict_mode=False, preserve_rc=False)
    cmd = shell.build_module_command('', '#!powershell', 'Test-Module.ps1')
    assert cmd == shell._encode_script(script=pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"), strict_mode=False, preserve_rc=False)
    cmd = shell.build_module_command('', '#!powershell', 'Test-Module.exe')

# Generated at 2022-06-17 13:56:00.181085
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:05.896743
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:41.135960
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:44.670584
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:49.444567
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:56.316076
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:01.816021
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:07.358332
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:12.519192
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'


# Generated at 2022-06-17 13:57:15.279571
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS is True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:17.983455
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:57:23.584812
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:19.212675
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:29.683583
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.env_prefix() == ''
    assert shell.join_path('/', 'tmp', 'test') == '\\tmp\\test'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.path_has_trailing_slash('/tmp/test/') == True
    assert shell.path_has_trailing_slash('/tmp/test') == False

# Generated at 2022-06-17 13:58:38.011794
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:43.847995
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:48.563716
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:54.156273
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:58.172487
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-17 13:59:04.401194
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:09.261729
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:59:13.570445
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:01:03.350467
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:01:07.736669
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:01:12.041437
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with a valid connection plugin
    shell = ShellModule(connection='winrm')
    assert shell.connection == 'winrm'

    # Test with an invalid connection plugin
    shell = ShellModule(connection='local')
    assert shell.connection == 'local'