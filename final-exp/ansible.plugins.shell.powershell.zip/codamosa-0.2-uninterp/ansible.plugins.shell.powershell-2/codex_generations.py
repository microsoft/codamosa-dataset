

# Generated at 2022-06-17 13:51:27.400767
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script('Write-Output (Get-Location).Path')
    assert shell.expand_user('~\\foo') == shell._encode_script("Write-Output ((Get-Location).Path + '\\foo')")
    assert shell.expand_user('foo') == shell._encode_script("Write-Output 'foo'")


# Generated at 2022-06-17 13:51:32.221860
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:51:44.332980
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-*'
        Write-Output -InputObject $tmp.FullName
        '''
    assert shell.mkdtemp(basefile='ansible-test') == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-test'
        Write-Output -InputObject $tmp.FullName
        '''

# Generated at 2022-06-17 13:51:47.082950
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS is True
    assert shell_module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-17 13:51:52.823486
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script("Write-Output (Get-Location).Path")
    assert shell.expand_user('~\\') == shell._encode_script("Write-Output ((Get-Location).Path + '\\')")
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('~\\test\\') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\')")
    assert shell.expand_user('~\\test\\test2') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\test2')")
    assert shell.expand_user

# Generated at 2022-06-17 13:52:06.026301
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell as powershell
    import ansible.plugins.shell as shell
    import ansible.plugins.loader as plugin_loader

    # Load the shell plugin
    shell_plugin = plugin_loader.get(shell.ShellBase.SHELL_FAMILY, 'powershell')

    # Create a new instance of the shell plugin
    shell_plugin_instance = shell_plugin()

    # Create a new instance of the powershell module
    powershell_module = powershell.ShellModule()

    # Set the shell plugin instance in the powershell module
    powershell_module.shell = shell_plugin_instance

    # Test the build_module_command method
    cmd = powershell_module.build_module_command('', '', '', '')

# Generated at 2022-06-17 13:52:10.899096
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/foo/bar/') == True
    assert shell.path_has_trailing_slash('/foo/bar') == False
    assert shell.path_has_trailing_slash('/foo/bar\\') == True
    assert shell.path_has_trailing_slash('/foo/bar\\\\') == True
    assert shell.path_has_trailing_slash('/foo/bar\\\\\\') == True
    assert shell.path_has_trailing_slash('/foo/bar\\\\\\/') == True
    assert shell.path_has_trailing_slash('/foo/bar\\\\\\//') == True
    assert shell.path_has_trailing_slash('/foo/bar\\\\\\///') == True

# Generated at 2022-06-17 13:52:21.349930
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module = ShellModule()
    assert shell_module.get_remote_filename('/path/to/file.ps1') == 'file.ps1'
    assert shell_module.get_remote_filename('/path/to/file.exe') == 'file.exe'
    assert shell_module.get_remote_filename('/path/to/file.sh') == 'file.sh.ps1'
    assert shell_module.get_remote_filename('/path/to/file') == 'file.ps1'
    assert shell_module.get_remote_filename('/path/to/file.sh.ps1') == 'file.sh.ps1'
    assert shell_module.get_remote_filename('/path/to/file.sh.exe') == 'file.sh.exe'
    assert shell_module.get_

# Generated at 2022-06-17 13:52:30.075459
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module.get_remote_filename('test.ps1') == 'test.ps1'
    assert module.get_remote_filename('test.exe') == 'test.exe'
    assert module.get_remote_filename('test') == 'test.ps1'
    assert module.path_has_trailing_slash('/test/')
    assert module.path_has_trailing_slash('\\test\\')

# Generated at 2022-06-17 13:52:43.573803
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import sys
    import os
    import tempfile
    import shutil
    import stat
    import subprocess
    import json
    import base64
    import shlex

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary module
    fd, tmpmodule = tempfile.mkstemp(dir=tmpdir, suffix='.ps1')
    os.close(fd)

    # Create a temporary binary module
    fd, tmpbinmodule = tempfile.mkstemp(dir=tmpdir, suffix='.exe')
    os.close(fd)

    # Create a temporary script
    fd, tmpscript = tempfile.mkstem

# Generated at 2022-06-17 13:52:55.183581
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:03.724714
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test with shebang
    shebang = '#!powershell'
    cmd = 'Get-ChildItem'
    arg_path = 'c:\\temp'
    env_string = '$env:ANSIBLE_MODULE_ARGS="{\\"ANSIBLE_MODULE_ARGS\\": \\"c:\\\\temp\\"}"'
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

# Generated at 2022-06-17 13:53:13.437177
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test with a module that is a script
    module_name = 'win_ping'
    shebang = '#!powershell'
    cmd = '"%s.ps1"' % module_name
    arg_path = None
    env_string = '$env:ANSIBLE_MODULE_ARGS = ConvertTo-Json @{}'

# Generated at 2022-06-17 13:53:20.707105
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:31.907424
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test with a binary module
    module_name = 'win_ping'
    module_args = '-c localhost'
    module_path = 'ansible.builtin.win_ping'
    shebang = None
    arg_path = 'C:\\Windows\\Temp\\ansible_module_win_ping.ps1'
    sm = ShellModule()
    cmd = sm.build_module_command(env_string='', shebang=shebang, cmd=module_name + ' ' + module_args, arg_path=arg_path)

# Generated at 2022-06-17 13:53:41.036707
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtemp() == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmp'
        Write-Output -InputObject $tmp.FullName
        '''
    assert shell.mkdtemp(basefile='test') == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'test'
        Write-Output -InputObject $tmp.FullName
        '''

# Generated at 2022-06-17 13:53:53.939077
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    # Test with shebang
    cmd = shell.build_module_command('', '#!powershell', 'Test-Module')

# Generated at 2022-06-17 13:54:00.215086
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:05.207414
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:12.060615
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:23.901915
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:54:28.348788
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:33.888126
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:37.369985
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:41.462147
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:47.705881
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:56.446685
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.env_prefix() == ""
    assert shell.join_path('C:\\', 'a', 'b') == 'C:\\a\\b'
    assert shell.join_path('C:\\', 'a\\', 'b') == 'C:\\a\\b'
    assert shell.join_path('C:\\', 'a\\', 'b\\') == 'C:\\a\\b'
    assert shell.join_path('C:\\', 'a/', 'b') == 'C:\\a\\b'

# Generated at 2022-06-17 13:55:03.473667
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:13.776110
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('/tmp/test.txt') == 'test.txt'
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'

# Generated at 2022-06-17 13:55:18.449739
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:31.503590
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:40.076797
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:45.596327
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:55:48.218884
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS


# Generated at 2022-06-17 13:55:55.304886
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.path_has_trailing_slash('test/') is True
    assert shell.path_has_trailing_slash('test\\') is True
    assert shell.path_has_trailing_

# Generated at 2022-06-17 13:55:56.850682
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:56:00.612424
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:56:05.846547
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:09.791679
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:15.975953
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:34.979443
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:56:45.308747
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.path_has_trailing_slash('/test/')
    assert shell.path_has_trailing_slash('/test\\')

# Generated at 2022-06-17 13:56:57.573442
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    cmd = shell.build_module_command('', '#!powershell', 'Test-Module')
    assert cmd == shell._encode_script(script=pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"), strict_mode=False, preserve_rc=False)

    cmd = shell.build_module_command('', '#!powershell', 'Test-Module.ps1')
    assert cmd == shell._encode_script(script=pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"), strict_mode=False, preserve_rc=False)

    cmd = shell.build_module_command('', '#!powershell', 'Test-Module.exe')

# Generated at 2022-06-17 13:56:59.475011
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:57:03.290680
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:08.669354
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:57:13.929274
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm._IS_WINDOWS == True
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:18.147044
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:57:23.663700
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:28.930280
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:53.053722
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with a valid connection plugin
    shell = ShellModule(connection='winrm')
    assert shell.connection == 'winrm'
    assert shell.SHELL_FAMILY == 'powershell'

    # Test with a valid connection plugin
    shell = ShellModule(connection='psrp')
    assert shell.connection == 'psrp'
    assert shell.SHELL_FAMILY == 'powershell'

    # Test with an invalid connection plugin
    shell = ShellModule(connection='ssh')
    assert shell.connection == 'ssh'
    assert shell.SHELL_FAMILY == 'powershell'



# Generated at 2022-06-17 13:57:57.869799
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:01.546476
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:58:06.361388
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:16.247529
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.join_path('c:\\', 'test') == 'c:\\test'

# Generated at 2022-06-17 13:58:21.809443
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS is True
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:27.109393
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:30.373556
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True


# Generated at 2022-06-17 13:58:38.749671
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:44.208090
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:59:24.359279
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:59:30.247466
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:38.929615
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:44.751749
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:49.325374
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:51.337613
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj.SHELL_FAMILY == 'powershell'
    assert obj._IS_WINDOWS == True


# Generated at 2022-06-17 13:59:54.311464
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS


# Generated at 2022-06-17 14:00:00.213932
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:04.830022
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:07.844523
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
