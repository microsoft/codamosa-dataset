

# Generated at 2022-06-17 13:51:27.014550
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:51:37.331949
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell as powershell
    import ansible.plugins.shell as shell
    import ansible.plugins.loader as plugin_loader

    # Create a mock shell plugin
    class MockShellModule(shell.ShellBase):
        pass

    # Create a mock powershell plugin
    class MockPowershellModule(powershell.ShellModule):
        pass

    # Create a mock module
    class MockModule(object):
        def __init__(self, args=None):
            self.args = args

    # Create a mock connection

# Generated at 2022-06-17 13:51:43.624817
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:51:48.084255
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:52:00.112706
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == shell._encode_script("Write-Output (Get-Location).Path")
    assert shell.expand_user('~\\') == shell._encode_script("Write-Output ((Get-Location).Path + '')")
    assert shell.expand_user('~\\test') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test')")
    assert shell.expand_user('~\\test\\') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\')")
    assert shell.expand_user('~\\test\\test2') == shell._encode_script("Write-Output ((Get-Location).Path + '\\test\\test2')")

# Generated at 2022-06-17 13:52:04.354642
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == 'VwByAGkAdABlAGwAbAAgAEkAbgB2AG8AZwBhAHQAaQBvAG4ALgBwAHIAbwBjAGUAbgBzAGUALgBwAHIAbwBjAGUAbgBzAGUA'
    assert shell.expand_user('~\\foo') == 'VwByAGkAdABlAGwAbAAgAEkAbgB2AG8AZwBhAHQAaQBvAG4ALgBwAHIAbwBjAGUAbgBzAGUALgBwAHIAbwBjAGUAbgBzAGUAYQBiAGwAZQBdADoAOgBGb28A'
    assert shell.expand_

# Generated at 2022-06-17 13:52:16.321670
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.exe') == 'test.exe'
    assert shell.get_remote_filename('/tmp/test.py') == 'test.py.ps1'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.pyc') == 'test.pyc.ps1'
    assert shell.get_remote_filename('/tmp/test.pyo') == 'test.pyo.ps1'
    assert shell.get_remote_filename('/tmp/test.pyw') == 'test.pyw.ps1'
    assert shell.get

# Generated at 2022-06-17 13:52:21.100934
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:52:32.658744
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell import ShellModule
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # Test that the bootstrap wrapper is used when shebang is #!powershell
    shebang = '#!powershell'
    cmd = 'Get-ChildItem'

# Generated at 2022-06-17 13:52:44.464044
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    env_string = '$env:ANSIBLE_MODULE_ARGS = \'{"ANSIBLE_MODULE_ARGS": "ANSIBLE_MODULE_ARGS"}\''
    shebang = '#!powershell'
    cmd = 'Test-Module'
    arg_path = 'C:\\Windows\\Temp\\ansible-tmp-1517651560.46-140134563353752\\test_module.ps1'

    result = shell.build_module_command(env_string, shebang, cmd, arg_path)


# Generated at 2022-06-17 13:53:02.215390
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.join_path('C:\\', 'test') == 'C:\\test'

# Generated at 2022-06-17 13:53:10.819637
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    env_string = '$env:ANSIBLE_MODULE_ARGS=\'{"ANSIBLE_MODULE_ARGS": "ANSIBLE_MODULE_ARGS"}\''
    shebang = '#!powershell'
    cmd = 'Get-ChildItem'
    arg_path = 'arg_path'

# Generated at 2022-06-17 13:53:18.565547
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\')
    assert shell.path_has_trailing_slash('C:\\test\\')
    assert shell.path_has_trailing_slash('C:\\test\\test2\\')
    assert shell.path_has_trailing_slash('C:/')
    assert shell.path_has_trailing_slash('C:/test/')
    assert shell.path_has_trailing_slash('C:/test/test2/')
    assert not shell.path_has_trailing_slash('C:')
    assert not shell.path_has_trailing_slash('C:\\test')
    assert not shell.path_has_trailing_slash('C:\\test\\test2')

# Generated at 2022-06-17 13:53:24.683769
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:26.272644
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 13:53:31.721630
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:39.193499
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:53:47.123100
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.py') == 'test.py.ps1'
    assert shell.path_has_trailing_slash('test\\') is True
    assert shell.path_has

# Generated at 2022-06-17 13:53:52.934339
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:54:04.494050
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\')
    assert shell.path_has_trailing_slash('C:\\test\\')
    assert shell.path_has_trailing_slash('C:\\test\\test2\\')
    assert shell.path_has_trailing_slash('C:\\test\\test2\\test3\\')
    assert shell.path_has_trailing_slash('C:\\test\\test2\\test3\\test4\\')
    assert shell.path_has_trailing_slash('C:\\test\\test2\\test3\\test4\\test5\\')
    assert shell.path_has_trailing_slash('C:\\test\\test2\\test3\\test4\\test5\\test6\\')

# Generated at 2022-06-17 13:54:21.287613
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell.SHELL_NAME == 'powershell'
    assert shell.SHELL_TYPE == 'powershell'
    assert shell.SHELL_VERSION == 'powershell'
    assert shell.SHELL_STATUS == 0
    assert shell.SHELL_EXEC_PATH == ''
    assert shell.SHELL_EXEC_ARGS == []
    assert shell.SHELL_CMD == ''
    assert shell.SHELL_ARGS == []
    assert shell.SHELL_PIPE == ''
    assert shell.SHELL_PIPE_IN == ''

# Generated at 2022-06-17 13:54:32.394314
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.py') == 'test.py.ps1'
    assert shell.path_has_trailing_slash('/test/') is True
    assert shell.path_

# Generated at 2022-06-17 13:54:37.662568
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:42.093541
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:54:53.628443
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\Users\\')
    assert shell.path_has_trailing_slash('C:\\Users\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\\\')
    assert shell.path_has_trailing_slash('C:\\Users\\test\\\\\\')
    assert not shell.path_has_trailing_

# Generated at 2022-06-17 13:55:01.783815
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.module_utils.powershell import ShellModule
    from ansible.module_utils.powershell.common import WIN_DEFAULT_SHELL_FAMILY

    # Test with a binary module
    module_cmd = 'Test-Module'
    module_path = 'C:\\Windows\\Temp\\ansible_test_module.exe'
    shell = ShellModule(connection_info={'network_os': WIN_DEFAULT_SHELL_FAMILY})
    cmd = shell.build_module_command('', '', module_cmd, arg_path=module_path)
    assert cmd == '& Test-Module C:\\Windows\\Temp\\ansible_test_module.exe; exit $LASTEXITCODE'

    # Test with a powershell module
    module_cmd = 'Test-Module'

# Generated at 2022-06-17 13:55:07.815948
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:15.133734
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/')
    assert shell.path_has_trailing_slash('\\')
    assert shell.path_has_trailing_slash('/foo')
    assert shell.path_has_trailing_slash('\\foo')
    assert shell.path_has_trailing_slash('/foo/')
    assert shell.path_has_trailing_slash('\\foo\\')
    assert not shell.path_has_trailing_slash('foo')
    assert not shell.path_has_trailing_slash('foo/')
    assert not shell.path_has_trailing_slash('foo\\')

# Generated at 2022-06-17 13:55:19.652569
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:24.167181
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test constructor of class ShellModule
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:40.319683
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS


# Generated at 2022-06-17 13:55:47.778451
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test.sh') == 'test.ps1'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.join_path('C:\\', 'test') == 'C:\\test'
    assert shell.join_

# Generated at 2022-06-17 13:55:51.791297
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:55:58.007099
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:03.333490
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:56:11.922357
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.module_utils.powershell import _encode_script
    from ansible.module_utils.powershell import _escape
    from ansible.module_utils.powershell import _unquote
    from ansible.module_utils.powershell import _parse_clixml
    from ansible.module_utils.powershell import _SHELL_REDIRECT_ALLNULL
    from ansible.module_utils.powershell import _SHELL_AND

    # Test _unquote
    assert _unquote('"test"') == 'test'
    assert _unquote("'test'") == 'test'
    assert _unquote('test') == 'test'

    # Test _escape
    assert _escape('test') == 'test'
    assert _escape('test"') == 'test""'

# Generated at 2022-06-17 13:56:18.224225
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-17 13:56:20.629244
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:26.823387
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell.SHELL_TYPE == 'powershell'
    assert shell.SHELL_NAME == 'powershell'
    assert shell.SHELL_VERSION == '1.0'

# Generated at 2022-06-17 13:56:32.308699
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:56:53.920199
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test.txt') == 'test.ps1'
    assert shell.join_path('C:\\', 'test') == 'C:\\test'
    assert shell.join_path('C:\\', 'test\\') == 'C:\\test'

# Generated at 2022-06-17 13:56:59.047160
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:57:02.178702
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:57:13.649897
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell import ShellModule
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # Test the case where the module is a powershell script
    shebang = '#!powershell'
    cmd = 'test.ps1'
    arg_path = None
    env_string = ''
    shell = ShellModule(None)
    result = shell.build_module_command(env_string, shebang, cmd, arg_path)
    assert result == to_text(b'& type "test.ps1.ps1" | ') + to_text(pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"))

    # Test the case

# Generated at 2022-06-17 13:57:16.495482
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:20.820827
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:25.795029
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:30.646786
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:57:36.243852
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    assert shell.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-17 13:57:42.489081
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:24.590346
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-17 13:58:29.500184
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:37.712598
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:44.004684
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:58:47.106843
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS == True
    assert sm.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-17 13:58:50.831333
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 13:58:57.052505
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:03.323093
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:08.493486
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 13:59:13.016973
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:17.121114
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:21.705607
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:27.393543
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS is True
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:30.406527
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-17 14:00:35.206672
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True

# Generated at 2022-06-17 14:00:42.340700
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-17 14:00:44.275963
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-17 14:00:52.460801
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.env_prefix() == ''
    assert shell.join_path('/', 'a', 'b') == '\\a\\b'
    assert shell.join_path('/', 'a', 'b', 'c') == '\\a\\b\\c'
    assert shell.join_path('/', 'a', 'b', 'c', 'd') == '\\a\\b\\c\\d'

# Generated at 2022-06-17 14:00:58.724248
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-17 14:01:02.035622
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
