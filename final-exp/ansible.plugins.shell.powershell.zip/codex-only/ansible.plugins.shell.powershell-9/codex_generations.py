

# Generated at 2022-06-23 12:41:20.013504
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    assert ShellModule(connector='winrm').exists('file') == b"If (Test-Path 'file')\n            {\n                $res = 0;\n            }\n            Else\n            {\n                $res = 1;\n            }\n            Write-Output '$res';\n            Exit $res;\n         "


# Generated at 2022-06-23 12:41:30.803344
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    stm = ShellModule()

    input_args = ('C:\\temp', '..\\temp1', '..\\temp2\\')
    expected_result = 'C:\\temp\\..\\temp1\\..\\temp2'
    actual_result = stm.join_path(*input_args)
    assert actual_result == expected_result

    input_args = ('C:\\temp', '..\\temp1', '..\\temp2')
    expected_result = 'C:\\temp\\..\\temp1\\..\\temp2'
    actual_result = stm.join_path(*input_args)
    assert actual_result == expected_result

    input_args = ('C:\\temp', '..\\temp1', '..\\temp2\\', '/test')

# Generated at 2022-06-23 12:41:37.249355
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    from ansible.errors import AnsibleError
    from ansible.executor.powershell import ShellModule
    myShellModule = ShellModule()

    with pytest.raises(AnsibleError) as excinfo:
        myShellModule.set_user_facl('test_file', 'test_user', 'test_mode')

    assert 'set_user_facl is not implemented for Powershell' in str(excinfo)


# Generated at 2022-06-23 12:41:39.743137
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule()
    assert shell.env_prefix() == ''
# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 12:41:45.299511
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    # Initialize the class
    module = ShellModule()

    # Populate the input variables
    cmd = 'wc -l *.txt'

    # Run the method under test
    result = module.wrap_for_exec(cmd)

    # Assert the result is as expected
    assert result == '& wc -l *.txt; exit $LASTEXITCODE', "result does not match"

# Generated at 2022-06-23 12:41:49.409591
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert b'C:\\Users\\Administrator' == shell.expand_user('~')
    assert b'C:\\Users\\Administrator\\test' == shell.expand_user('~\\test')


# Generated at 2022-06-23 12:41:55.687489
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    from ansible.plugins.shell.powershell import ShellModule

    p = ShellModule()

    env_string = '$env:ANSIBLE_MODULE_ARGS = "' + ' '.join(['-a', 'arg1=1', '-a', 'arg2=2']) + '"'

    assert p.env_prefix(arg1=1, arg2=2) == env_string

# Generated at 2022-06-23 12:42:03.300750
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    from ansible.plugins.shell import ShellModule
    fake_shell_obj = ShellModule(connection=None)
    assert fake_shell_obj.exists('test') == b"`r`nIf (Test-Path 'test')`r`n{`r`n    $res = 0;`r`n}`r`nElse`r`n{`r`n    $res = 1;`r`n}`r`nWrite-Output '$res';`r`nExit $res;`r`n"


# Generated at 2022-06-23 12:42:14.712494
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    module = ShellModule()
    test_exists = [
        ('test-file', 0),
        ('test-path', 3),
        ('test-path-that-does-not-exist', 1),
    ]
    test_data = [
        ('test-data', 'test-data-checksum'),
        ('test-data-with-new-line\ntest-data-with-new-line', 'test-data-checksum-with-new-line'),
        ('test-data-with-new-line\ntest-data-with-new-line\n', 'test-data-checksum-with-new-line-and-carriage-return'),
        ('\n', 'test-data-checksum-new-line'),
        ('', 'test-data-checksum-empty'),
    ]


# Generated at 2022-06-23 12:42:23.009344
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():  # noqa
    from ansible.module_utils.powershell import ShellModule, _parse_clixml

    module = ShellModule()

    # Test remove without recurse param
    expected_script = b"Remove-Item 'C:\test' -Force;"
    script = module.remove('C:\\test')
    assert script == expected_script

    # Test remove with recurse param
    expected_script = b"Remove-Item 'C:\test' -Force -Recurse;"
    script = module.remove('C:\\test', True)
    assert script == expected_script

    # Test error message parsing
    # Windows error message with newlines
    expected_stderr = b"test\r\n"
    expected_rc = 1

# Generated at 2022-06-23 12:42:34.021470
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    shell = ShellModule(connection=None)

# Generated at 2022-06-23 12:42:41.699320
# Unit test for method remove of class ShellModule

# Generated at 2022-06-23 12:42:45.826633
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    result = shell.set_user_facl('/foo', 'user', 'rw')
    assert result is None


# Generated at 2022-06-23 12:42:48.381668
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    plugin = ShellModule()
    assert plugin.env_prefix() == ''
    assert plugin.env_prefix(one=1) == ''


# Generated at 2022-06-23 12:42:49.367244
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    ShellModule.chown("path", "user")

# Generated at 2022-06-23 12:42:59.540100
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import os
    import random
    import string

    def random_string(len=12, type=string.ascii_letters + string.digits):
        return ''.join([random.choice(type) for i in range(len)])

    tests = ((None, None, {}),
             (random_string(), None, {}),
             (None, os.path.join('C:\\', 'TEMP'), {}),
             (random_string(), os.path.join('C:\\', 'TEMP'), {}),)

    import ansible.plugins.shell.powershell
    powershell = ansible.plugins.shell.powershell.ShellModule(None)
    for basefile, tmpdir, kwargs in tests:
        ansible_module = 'ansible_module.ps1'
        if basefile:
            expected_path

# Generated at 2022-06-23 12:43:11.328498
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    module = ShellModule()

    # Expected result
    assert ntpath.basename(module.get_remote_filename('/etc/ansible/powershell.ps1')) == 'powershell.ps1'
    assert ntpath.basename(module.get_remote_filename('/etc/ansible/powershell.exe')) == 'powershell.exe'
    assert ntpath.basename(module.get_remote_filename('/etc/ansible/powershell')) == 'powershell.ps1'
    assert ntpath.basename(module.get_remote_filename('/etc/ansible/powershell.py')) == 'powershell.ps1'

# Generated at 2022-06-23 12:43:20.448287
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():

    s = ShellModule()

    assert s.get_remote_filename('/tmp/foo.ps1') == 'foo.ps1'
    assert s.get_remote_filename('/tmp/foo.psm1') == 'foo.psm1'
    assert s.get_remote_filename('/tmp/foo.exe') == 'foo.exe'
    assert s.get_remote_filename('/tmp/foo.bat') == 'foo.bat'
    assert s.get_remote_filename('/tmp/foo') == 'foo.ps1'

# Generated at 2022-06-23 12:43:24.962051
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    host = {'ansible_connection': 'powershell'}
    shell = ShellModule(host)

    with pytest.raises(NotImplementedError) as excinfo:
        shell.chmod('test/some/path', '666')
    assert 'chmod is not implemented for Powershell' in str(excinfo.value)


# Generated at 2022-06-23 12:43:36.920461
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    sm = ShellModule()

    # Test relative paths string
    test_str = 'a\\b\\c'
    result = sm.join_path(test_str)
    assert result == test_str

    # Test absolute paths string
    test_str = 'C:\\a\\b\\c'
    result = sm.join_path(test_str)
    assert result == test_str

    # Test quoted paths string
    test_str = '"C:\\a\\b\\c"'
    result = sm.join_path(test_str)
    assert result == test_str

    # Test multiply quoted paths string
    test_str = '"""C:\\a\\b\\c"""'
    result = sm.join_path(test_str)
    assert result == test_str

    # Test empty paths string
    test_str

# Generated at 2022-06-23 12:43:47.951154
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()


# Generated at 2022-06-23 12:44:00.219480
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    import pytest
    # Create an empty class to mock a AnsibleModule
    class MockAnsibleModule:
        pass

    mockAnsibleModule = MockAnsibleModule()

    # Create an empty class to mock a AnsibleModule
    class MockTaskVars:
        pass

    mockTaskVars = MockTaskVars()

    # Create an empty class to mock a AnsibleModule
    class MockAnsible:
        pass

    mockAnsible = MockAnsible()

    mockAnsibleModule.task_vars = mockTaskVars
    sm = ShellModule(mockAnsible, mockAnsibleModule)

    # Test with a simple string
    test_tuple = (r"C:\Users\Administrator\Desktop",)
    result = sm.join_path(*test_tuple)

# Generated at 2022-06-23 12:44:08.789686
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule()
    assert shell.chown(path="c:\temp\tst.txt", user='Administrator') == r"Remove-Item 'c:\temp\tst.txt' -Force;New-Item -Type File 'c:\temp\tst.txt';"
    assert shell.chown(path="c:\temp\tst.txt", user='Administrator', recurse=True) == r"Remove-Item 'c:\temp\tst.txt' -Force;New-Item -Type File 'c:\temp\tst.txt';"


# Generated at 2022-06-23 12:44:11.651189
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    from ansible.executor.powershell import ShellModule

    shellModule = ShellModule()

    assert shellModule.env_prefix() == ""



# Generated at 2022-06-23 12:44:23.656261
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    m = __import__('ansible.plugins.shell.powershell').plugins.shell.powershell.ShellModule()

    # the base case
    assert m.join_path('C:\\', 'Users', 'whoever', 'Documents') == 'C:\\Users\\whoever\\Documents'

    # child path relative to current directory
    assert m.join_path('C:\\', 'Windows\\System32\\', '..\\drivers') == 'C:\\Windows\\drivers'

    # child path relative to parent directory
    assert m.join_path('C:\\', 'Windows\\', '..\\drivers') == 'C:\\drivers'

    # parent path relative to current directory
    assert m.join_path('C:\\Windows\\System32\\', '..\\drivers') == 'C:\\Windows\\drivers'

    # parent path relative to parent directory

# Generated at 2022-06-23 12:44:35.646478
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import sys
    import os
    import io
    import json

    from ansible.plugins.shell import ShellModule

    class FakePopen():

        def __getitem__(self, key):
            return FakePopen()

        def communicate(self):
            return ('', '')

    class FakeModule(object):

        def __init__(self, **kwargs):
            self.params = dict(
                creates=None,
                removes=None,
                chdir=None,
                stdin=None,
                stdout_callback=None,
                shell=None,
                _uses_shell=False,
                _raw_params=kwargs.get('_raw_params', ''),
            )
            self.params.update(kwargs)


# Generated at 2022-06-23 12:44:44.475437
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    TEST_CASES = []
    TEST_CASES.append({'desc': 'Attempt to change permissions on Windows',
                       'args': [],
                       'module': 'shell'})
    for test_case in TEST_CASES:
        module = ShellModule()
        for attr in test_case:
            setattr(module, attr, test_case[attr])
        try:
            module.chmod()
        except NotImplementedError as e:
            assert str(e).startswith('chmod is not implemented for Powershell')


# Generated at 2022-06-23 12:44:53.514805
# Unit test for method build_module_command of class ShellModule

# Generated at 2022-06-23 12:44:56.333978
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    m = ShellModule(None)
    assert m.chown('a', 'b') == {"cmd": "Remove-Item 'a' -Force\n"}

# Generated at 2022-06-23 12:45:07.450082
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    shell = ShellModule()
    # Test if the method returns valid results for different values as input
    # for param 'path'
    # Positive tests
    result = shell.exists(path='test/path/of/file')
    assert re.match(r"^\s*if (\(Test-Path -PathType Leaf '|\(Test-Path -LiteralPath ')test/path/of/file('|'\)))", result)
    # Negative tests
    result = shell.exists(path='')
    assert re.match(r"^\s*if (\(Test-Path -PathType Leaf '|\(Test-Path -LiteralPath ')('|'\)))", result)


# Generated at 2022-06-23 12:45:10.603835
# Unit test for method expand_user of class ShellModule

# Generated at 2022-06-23 12:45:17.302892
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell = ShellModule()
    cmd_1 = shell.remove('C:\\Windows\\Temp', False)
    assert cmd_1 == b'''Remove-Item 'C:\\Windows\\Temp' -Force;'''
    cmd_2 = shell.remove('C:\\Windows\\Temp', True)
    assert cmd_2 == b'''Remove-Item 'C:\\Windows\\Temp' -Force -Recurse;'''


# Generated at 2022-06-23 12:45:26.727243
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()

    assert shell.join_path('c:', 'foo', 'bar') == 'c:\\foo\\bar'
    assert shell.join_path('c:/', 'bar') == 'c:\\bar'
    assert shell.join_path('c:', '/foo', 'bar') == 'c:\\foo\\bar'
    assert shell.join_path('c:\\', 'foo', 'bar') == 'c:\\foo\\bar'
    assert shell.join_path('c:\\', '/bar') == 'c:\\bar'
    assert shell.join_path('c:\\', '\\foo', 'bar') == 'c:\\foo\\bar'
    assert shell.join_path('c:\\\\', 'foo', 'bar') == 'c:\\foo\\bar'

# Generated at 2022-06-23 12:45:37.769584
# Unit test for method mkdtemp of class ShellModule

# Generated at 2022-06-23 12:45:46.510487
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    sm = ShellModule()
    assert sm.get_remote_filename('./test.ps1') == 'test.ps1'
    assert sm.get_remote_filename('./test') == 'test.ps1'
    assert sm.get_remote_filename('./test.exe') == 'test.exe'
    assert sm.get_remote_filename('./test.bat') == 'test.bat.ps1'
    assert sm.get_remote_filename('test') == 'test.ps1'

# Generated at 2022-06-23 12:45:54.189638
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    class PSShell(ShellModule):
        pass

    src = r'c:\temp\testfile.txt'
    dest = r'c:\temp\destfile.txt'
    ps = PSShell()

    # test for file
    cmd = ps.checksum(path=src)
    assert isinstance(cmd, str)
    assert '3' not in cmd

    # test for dir
    cmd = ps.checksum(path=dest)
    assert isinstance(cmd, str)
    assert '3' in cmd

    # test for non-existed path
    non_existed = r'c:\temp\notexist.txt'
    cmd = ps.checksum(path=non_existed)
    assert isinstance(cmd, str)
    assert '3' not in cmd
    assert '1' in cmd

# Generated at 2022-06-23 12:45:58.933358
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    from ansible.plugins.shell import ShellModule
    s = ShellModule()
    assert s.exists('"C:\Windows\\System32"') == 'If (Test-Path \'C:\\Windows\\System32\') { $res = 0; } Else { $res = 1; } Write-Output \'$res\'; Exit $res;'

# Generated at 2022-06-23 12:46:03.435134
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell = ShellModule(connection='winrm')
    cmd = shell.remove('/path/to/file', True)
    assert 'Remove-Item /path/to/file -Force -Recurse' in to_text(base64.b64decode(cmd[8:]))

# Generated at 2022-06-23 12:46:14.925581
# Unit test for method join_path of class ShellModule

# Generated at 2022-06-23 12:46:19.955208
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    sm = ShellModule()
    assert sm.path_has_trailing_slash('"c:\\test\\"') == True
    assert sm.path_has_trailing_slash('"c:\\test"') == False


# Generated at 2022-06-23 12:46:28.582472
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    # instantiate and set config
    shell = ShellModule(connection=None)
    shell.shell.set_options({'remote_tmp': 'remote_tmp'})
    # check path
    path = 'path'
    result = shell.exists(path)
    assert result == b"#ps1_sysnative\r\nIf (Test-Path " + '\'' + to_bytes(path) + '\'' + b")\r\n{\r\n    $res = 0;\r\n}\r\nElse\r\n{\r\n    $res = 1;\r\n}\r\nWrite-Output '" + '\'' + b'$res' + '\'' + b"';\r\nExit $res;\r\n "

    path = 'path'
    recurse = False
   

# Generated at 2022-06-23 12:46:29.249921
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():

    assert(False)


# Generated at 2022-06-23 12:46:31.251575
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    assert False, "Unit test not implemented"


# Generated at 2022-06-23 12:46:39.702791
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    args = "powershell -NoLogo -NonInteractive -NoProfile -ExecutionPolicy Bypass -Command -"
    testInput = "Write-Host 'Hello World'"

    shell = ShellModule("connection")
    expectedOutput = "& %s; exit $LASTEXITCODE" % " ".join([args, to_text(
        base64.b64encode(testInput.encode('utf-16-le')), 'utf-8')])

    result = shell.wrap_for_exec(
        " ".join([args, to_text(base64.b64encode(testInput.encode('utf-16-le')), 'utf-8')]))

    assert result == expectedOutput



# Generated at 2022-06-23 12:46:44.928646
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
  m = ShellModule(connection=None, runner=None)
  with pytest.raises(NotImplementedError) as excinfo:
    m.chown(paths='/tmp/foo',user='bar')
  assert "chown is not implemented for Powershell" in str(excinfo.value)


# Generated at 2022-06-23 12:46:48.608437
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    result = ShellModule().set_user_facl(None, None, None)
    assert result.startswith('NotImplementedError') 


# Generated at 2022-06-23 12:46:49.985832
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    assert False, "Unit test not implemented for ShellModule.chmod"


# Generated at 2022-06-23 12:47:00.921747
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import tempfile
    import ansible.plugins.shell.powershell as powershell
    tmpdir_name = tempfile.mkdtemp(prefix='test_ShellModule_mkdtemp_')
    print(tmpdir_name)
    basefile = "test1"
    p = powershell.ShellModule()
    command = p.mkdtemp(basefile=basefile, system=True, mode=None, tmpdir=tmpdir_name)
    print(command)
    print(command.decode('utf-8'))
    import subprocess

# Generated at 2022-06-23 12:47:11.593578
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert hasattr(shell, 'COMPATIBLE_SHELLS')
    assert hasattr(shell, 'SHELL_FAMILY')
    assert hasattr(shell, '_IS_WINDOWS')
    assert hasattr(shell, 'env_prefix')
    assert hasattr(shell, 'join_path')
    assert hasattr(shell, 'get_remote_filename')
    assert hasattr(shell, 'path_has_trailing_slash')
    assert hasattr(shell, 'chmod')
    assert hasattr(shell, 'chown')
    assert hasattr(shell, 'set_user_facl')
    assert hasattr(shell, 'remove')
    assert hasattr(shell, 'mkdtemp')
    assert hasattr(shell, 'expand_user')

# Generated at 2022-06-23 12:47:17.902524
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    module = ShellModule()

    assert module.get_remote_filename('C:/Bob/SHELL.exe') == 'SHELL.exe'
    assert module.get_remote_filename('C:/Bob/SHELL') == 'SHELL.ps1'
    assert module.get_remote_filename('C:/Bob/SHELL.ps1.ps1') == 'SHELL.ps1.ps1'


# Generated at 2022-06-23 12:47:29.053172
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Import necessary module_utils and Ansible stuff
    import os
    import sys
    import tempfile

    sys.path.append(os.path.dirname(__file__))
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    # Create temp powershell scripts
    (fd, pscmd) = tempfile.mkstemp(prefix='ansible_test_BuildModuleCommand_cmd_', suffix='.ps1')
    with os.fdopen(fd, 'wb') as f:
        f.write(b'Get-ChildItem -Path .')
    (fd, psarg) = tempfile.mkstemp(prefix='ansible_test_BuildModuleCommand_arg_', suffix='.ps1')
   

# Generated at 2022-06-23 12:47:37.873501
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    temp_file = tempfile.NamedTemporaryFile()
    test_path = temp_file.name
    plugin_obj = ShellModule(connection=None, shell_executable=None)
    assert plugin_obj.exists(test_path) == plugin_obj._encode_script("""\
            If (Test-Path '%s')
            {
                $res = 0;
            }
            Else
            {
                $res = 1;
            }
            Write-Output '$res';
            Exit $res;
         """ % test_path)



# Generated at 2022-06-23 12:47:40.725874
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    m = ShellModule()
    try:
        m.chmod(paths='/foo/bar/file.txt', mode='644')
    except NotImplementedError:
        assert True
        return
    assert False


# Generated at 2022-06-23 12:47:42.803703
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    result = shell.set_user_facl(paths="/path/to/foo", user="bar", mode="rw-")
    assert result is None


# Generated at 2022-06-23 12:47:45.188609
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule()
    with pytest.raises(NotImplementedError):
        shell.chown('', '')


# Generated at 2022-06-23 12:47:47.778846
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    assert ShellModule(None, None).chmod('file1', 755) is None


# Generated at 2022-06-23 12:47:58.242319
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():

    # Plug-in initialization
    fakeargs = [0, 'a', 'b']

# Generated at 2022-06-23 12:48:06.844963
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    powershell = ShellModule(connection=None)

    def execute(cmd, shell_type, module_args, as_list=False):
        cmd = powershell.build_module_command(
            env_string=cmd,
            shebang=shell_type,
            cmd=module_args
        )
        if as_list:
            return shlex.split(cmd, posix=False)
        return cmd

    def assert_command(cmd, expected=None):
        actual, = shlex.split(cmd, posix=False)
        actual = to_text(base64.b64decode(actual), 'utf-16-le')
        if expected is None:
            expected = cmd
        expected = to_text(expected)
        assert actual == expected


# Generated at 2022-06-23 12:48:09.510781
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell_mod = ShellModule()
    cmd = 'a command'
    assert(shell_mod.wrap_for_exec(cmd) == '& a command; exit $LASTEXITCODE')



# Generated at 2022-06-23 12:48:10.175525
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert isinstance(ShellModule(), ShellBase)

# Generated at 2022-06-23 12:48:15.242623
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    # simple test for chown
    module = ('module_utils.basic', 'ShellModule')
    m = module[1](connection='winrm', no_log=True)
    result = m.chown('/root/file', 'root')
    assert result == None
# test_ShellModule_chown ends here


# Generated at 2022-06-23 12:48:24.426051
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # Windows tests
    windows_shell = ShellModule()
    assert windows_shell.get_remote_filename('a_file_name') == 'a_file_name.ps1'
    assert windows_shell.get_remote_filename('a_file_name.py') == 'a_file_name.py.ps1'
    assert windows_shell.get_remote_filename('a_file_name.EXE') == 'a_file_name.EXE.ps1'
    assert windows_shell.get_remote_filename('a_file_name.ps1') == 'a_file_name.ps1'

# Generated at 2022-06-23 12:48:31.776578
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    mock_paths = [
        """C:\\Users\\test.user1\\AppData\\Local\\Temp\\tmp782f_1bz\\foo.txt""",
        """C:\\Users\\test.user1\\AppData\\Local\\Temp\\tmp782f_1bz\\foo.txt""",
        """C:\\Users\\test.user1\\AppData\\Local\\Temp\\tmp782f_1bz\\foo.txt\\""",
        """C:\\Users\\test.user1\\AppData\\Local\\Temp\\tmp782f_1bz\\foo.txt\\""",
    ]

    for path in mock_paths:
        try:
            ShellModule.chmod(path, 0o666)
        except NotImplementedError:
            pass
        else:
            raise Exception('Expected NotImplementedError exception')



# Generated at 2022-06-23 12:48:33.443754
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule()

    # Test default values without any arguments
    assert shell.env_prefix(**{}) == ''



# Generated at 2022-06-23 12:48:44.080947
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    class ShellModuleStub(ShellModule):
        def wrap_for_exec(self, cmd):
            return super(ShellModule, self).wrap_for_exec(cmd)

    def functest(cmd, expected):
        actual = ShellModuleStub().wrap_for_exec(cmd)
        assert actual == expected, "Expected: %s -> %s, actual: %s" % (cmd, expected, actual)

    functest('ansible-test', '& ansible-test; exit $LASTEXITCODE')
    functest('ansible-test arg1 arg2', '& ansible-test arg1 arg2; exit $LASTEXITCODE')


# Generated at 2022-06-23 12:48:48.028395
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    plugin = ShellModule()
    assert plugin.remove('foo/bar') == 'Remove-Item ''foo/bar'' -Force;'
    assert plugin.remove('foo/bar', True) == 'Remove-Item ''foo/bar'' -Force -Recurse;'


# Generated at 2022-06-23 12:48:50.076126
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    assert(ShellModule().wrap_for_exec("test_test") == '& test_test; exit $LASTEXITCODE')


# Generated at 2022-06-23 12:48:52.453743
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    result = ShellModule.set_user_facl('/test_path', 'admin', 'rw')
    assert result == 'NotImplementedError: set_user_facl is not implemented for Powershell'


# Generated at 2022-06-23 12:48:55.480547
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert 'powershell' == shell_module.SHELL_FAMILY
    assert 'Remove-Item' == shell_module.remove('/')[:10]

# Generated at 2022-06-23 12:49:04.387525
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    # directory separator is \ in Windows
    # multiple \ in the beginning should be ignored and replaced with single \
    assert ShellModule.join_path('\\\\a', 'b\\c') == '\\\\a\\b\\c'

    assert ShellModule.join_path('a', 'b\\c') == 'a\\b\\c'
    assert ShellModule.join_path('a', 'b', 'c') == 'a\\b\\c'
    assert ShellModule.join_path('a', 'b', 'c', 'd') == 'a\\b\\c\\d'
    assert ShellModule.join_path('a', 'b', 'c', 'd', 'e') == 'a\\b\\c\\d\\e'

# Generated at 2022-06-23 12:49:10.231907
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    module = ShellModule(connection=None)
    result = module.env_prefix(
        PATH='C:\\path1;C:\\path2;C:\\path3',
        TERM='xterm',
        VAR1='stuff',
        VAR2='stuff and more stuff'
    )

    assert result == ''


# Generated at 2022-06-23 12:49:23.251767
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    _shell = ShellModule()
    _shell.join_path('path', 'to', 'file') == 'path\\to\\file'
    _shell.join_path('path/to', '/file') == 'path\\to\\file'
    _shell.join_path('', '/file') == 'file'
    _shell.join_path('path/to', '/file', '') == 'path\\to\\file'
    _shell.join_path('path/to/', '/file') == 'path\\to\\file'
    _shell.join_path('path/to', '/file/') == 'path\\to\\file'
    _shell.join_path('path/to/', '/file/') == 'path\\to\\file'
    _shell.join_path('', '/', '') == ''
    _shell.join_path

# Generated at 2022-06-23 12:49:31.017947
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    temp_shell = ShellModule()
    test_files = {'/tmp/powershell.exe': '0fae0a8f1c746e64d2c72e3fd814b8532c2310a5',
                  '/tmp/powershell.exe.txt': '0fae0a8f1c746e64d2c72e3fd814b8532c2310a5'}

    for path, checksum in test_files.items():
        assert checksum == temp_shell.checksum(path).strip()



# Generated at 2022-06-23 12:49:42.562381
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    import unittest
    import ansible.plugins.shell.powershell

    class ShellModule_get_remote_filenameTestCase(unittest.TestCase):

        @classmethod
        def setUpClass(self):
            self.shell = ansible.plugins.shell.powershell.ShellModule()

        def test_get_remote_filename_ext(self):
            self.assertTrue(self.shell.get_remote_filename("foo.ps1") == "foo.ps1")
            self.assertTrue(self.shell.get_remote_filename("foo.exe") == "foo.exe")

        def test_get_remote_filename_ext_no(self):
            self.assertTrue(self.shell.get_remote_filename("foo") == "foo.ps1")


# Generated at 2022-06-23 12:49:53.246096
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()

    assert not shell.path_has_trailing_slash("C:\\Users")
    assert not shell.path_has_trailing_slash("C:\\\\Users")

    assert shell.path_has_trailing_slash("C:\\Users\\")
    assert shell.path_has_trailing_slash("C:\\\\Users\\\\")

    assert not shell.path_has_trailing_slash("C:\\Users\\foo")
    assert not shell.path_has_trailing_slash("C:\\\\Users\\\\foo")

    assert shell.path_has_trailing_slash("C:\\Users\\foo\\")
    assert shell.path_has_trailing_slash("C:\\\\Users\\\\foo\\\\")


# Generated at 2022-06-23 12:50:04.355475
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    '''
    This tests generating the checksum command for the powershell ShellModule
    when given a file path.
    '''
    fake_module = type('FakeModule', (object, ), {'_IS_WINDOWS': True})
    shell_mod = ShellModule(fake_module)
    checksum_test_file = '/foo/bar/test_ps1_checksum_file.ps1'
    checksum_test_command = shell_mod.checksum(checksum_test_file)

# Generated at 2022-06-23 12:50:13.928202
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    '''
    Simulate ansible raw or win_command module. We need to use winrm because
    that's the only connection that uses PowerShell and the ShellModule class.
    '''
    def get_module(cmd):
        command = {
            'module_name': 'raw',
            '_raw_params': cmd,
            '_uses_shell': True,
            '_ansible_shell_executable': '/bin/sh',
            '_ansible_no_log': False,
            '_uses_shell': True
        }
        module = ShellModule(command)
        module._shell.executable = '/bin/sh'
        return module

    mycmd = '''
        $var=get-date
        write-output $var
    '''
    module = get_module(mycmd)

# Generated at 2022-06-23 12:50:25.231900
# Unit test for method mkdtemp of class ShellModule

# Generated at 2022-06-23 12:50:27.656305
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    shell.set_user_facl("foo", "bar", "baz")
    exception = None  # This was the exception that caused the test to fail.

# Generated at 2022-06-23 12:50:39.595596
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    from ansible.errors import AnsibleError

    # Test with Test-Path returning True for type 'Leaf', False for
    # type 'Container' and False for anything else
    class TestShellModule(ShellModule):
        def run(self, cmd, tmp_path, in_data, sudoable=True):
            return cmd, None
        def checksum(self, path, *args, **kwargs):
            # see checksum method body for details on this
            if path == 'test_leaf':
                return self._encode_script('test_hash')
            elif path == 'test_container':
                return self._encode_script('3')
            else:
                return self._encode_script('1')

    test_module = TestShellModule(connection=None)

    # Test with Test-Path returning True for type 'Leaf

# Generated at 2022-06-23 12:50:40.840975
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    pass

# Generated at 2022-06-23 12:50:51.193780
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shm = ShellModule()

# Generated at 2022-06-23 12:51:01.153907
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Test with no basefile parameter
    print("Testing with no basefile parameter")
    p = ShellModule()
    script = p.mkdtemp()
    assert '''$tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Temp');
$tmp = New-Item -Type Directory -Path $tmp_path -Name ''' in script

    # Test with basefile parameter
    print("Testing with basefile parameter")
    p = ShellModule()
    script = p.mkdtemp(basefile='ansible_test')
    assert '''$tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Temp');
$tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible_test'
Write-Output -InputObject $tmp.FullName
''' in script

    #

# Generated at 2022-06-23 12:51:13.695747
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import os

    test_cases = (
        ('~', os.path.expanduser('~')),
        ('~\\', os.path.join(os.path.expanduser('~'), '')),
        ('~\\foo', os.path.join(os.path.expanduser('~'), 'foo')),
        ('c:\\temp', 'c:\\temp'),
        ('c:\\temp\\', 'c:\\temp\\'),
        ('c:\\temp\\foo', 'c:\\temp\\foo'),
        ('c:/temp', 'c:\\temp'),
        ('c:/temp/', 'c:\\temp\\'),
        ('c:/temp/foo', 'c:\\temp\\foo'),
    )
