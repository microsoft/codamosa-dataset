

# Generated at 2022-06-23 12:41:27.170185
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    # Getting a handle to the module
    sm = ShellModule()
    # Testing method with a given parameter
    path = "C:\\Users\\ansible\\AppData\\Local\\Temp\\ansible-tmp-1598981019.87-232074408384713\\test"
    ret = sm.checksum(path)

# Generated at 2022-06-23 12:41:39.522426
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import binary_type
    import json

    # Stream for capture stdout
    out = StringIO()
    module = ShellModule('winrm', out)
    path = 'C:\\Users\\localadmin\\Ansible\\test.txt'
    script = to_bytes(module.remove(path, recurse=True))
    if PY2:
        script = str(script)
    with open(script) as f:
        script = f.read()
    if not isinstance(script, binary_type):
        script = script.encode()

    # Capture stderr
    err = StringIO()
    # Capture stdout
    out = StringIO()

# Generated at 2022-06-23 12:41:47.154663
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()

    # Unit test for case 1
    path = "C:\Windows\system32"
    actual = shell.path_has_trailing_slash(path)
    assert actual == False, "path_has_trailing_slash() failed when expected to pass."

    # Unit test for case 2
    path = "C:\Windows\system32\\"
    actual = shell.path_has_trailing_slash(path)
    assert actual == True, "path_has_trailing_slash() failed when expected to pass."


# Generated at 2022-06-23 12:41:49.112744
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    assert None == ShellModule.set_user_facl('', '', '')


# Generated at 2022-06-23 12:41:55.343166
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    """This unit test verifies that the ShellModule.mkdtemp() method
    creates temp directories that do not exist."""
    # Create a shell module object
    shell = ShellModule()
    # Create a temp dir path that is not expected to exist
    tmpdir = '$env:TMP\\ansible-test-%s' % shell.__class__._generate_temp_dir_name()
    # Verify that the dir does not exist
    if shell.exists(tmpdir):
        shell.remove(tmpdir)
        assert not shell.exists(tmpdir)
    # Create the temp dir
    script = shell.mkdtemp(tmpdir=tmpdir, system=False, mode=None)
    assert script.startswith('$tmp')
    assert shell.exists(tmpdir)
    # Remove the temp dir
    shell

# Generated at 2022-06-23 12:42:02.098423
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    shell = ShellModule()
    target_path = "C:\\Program Files\\"
    expect_value = b"&{$res = $null;If (Test-Path 'C:\\Program Files\\\\')($res = 0) Else ($res = 1);Write-Output -InputObject $res;Exit $res;}"
    actual_value = shell.exists(target_path)
    assert actual_value == expect_value


# Generated at 2022-06-23 12:42:10.786658
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    # Given
    shell = ShellModule()
    shell._unquote = lambda x: x
    shell._escape = lambda x: x

    # When
    result = shell.remove("/test/test1", recurse=False)
    result2 = shell.remove("/test2/test3", recurse=True)

    # Then
    assert result == b'Remove-Item \'/test/test1\' -Force;'
    assert result2 == b'Remove-Item \'/test2/test3\' -Force -Recurse;'

# Generated at 2022-06-23 12:42:16.384095
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY is 'powershell'
    assert module.COMPATIBLE_SHELLS is frozenset()
    assert module._IS_WINDOWS is True
    assert module._SHELL_REDIRECT_ALLNULL is '> $null'
    assert module._SHELL_AND is ';'


# Generated at 2022-06-23 12:42:23.372664
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    class FakeConnection:
        def __init__(self, host=None):
            self.host = host
            self.become_method_supported = ['runas']

    connection = FakeConnection()
    shell = ShellModule(connection)
    assert shell.path_has_trailing_slash("/tmp/") is True
    assert shell.path_has_trailing_slash("C:/Temp/") is True
    assert shell.path_has_trailing_slash("C:\\Temp\\") is True
    assert shell.path_has_trailing_slash("C:\\Temp") is False
    assert shell.path_has_trailing_slash("/tmp") is False



# Generated at 2022-06-23 12:42:30.341225
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.powershell import ShellModule
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    import six

    if six.PY2:
        from ansible.errors import AnsibleError
        from ansible.plugins import module_loader

    display = Display()
    loader = DataLoader()
    host = Host('localhost')
    task_vars = {}
    variable_manager = VariableManager()

# Generated at 2022-06-23 12:42:40.758198
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()
    fixture_data = [
        # args, expected
        (('c:', 'temp'), 'c:\\temp'),
        (('c:', 'temp\\'), 'c:\\temp'),
        (('c:\\', '\\temp'), 'c:\\temp'),
        (('c:\\', '\\temp\\'), 'c:\\temp'),
        (('c:\\', '\\temp', 'temp2', 'temp3'), 'c:\\temp\\temp2\\temp3'),
        (('c:\\', '\\temp', 'temp2', 'temp3\\'), 'c:\\temp\\temp2\\temp3'),
    ]

    for args, expected in fixture_data:
        assert shell.join_path(*args) == expected

# Generated at 2022-06-23 12:42:53.573489
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # The following data is obtained with the following PowerShell command:
    # PS:> [System.Environment]::GetEnvironmentVariable('USERPROFILE')
    # C:\Users\Administrator
    user_home_path = r'C:\Users\Administrator'

    # The following data is obtained with the following PowerShell command:
    # PS:> (Get-Location).Path
    # C:\Users\Administrator
    pwd = user_home_path

    # Initializes an instance of the ShellModule class
    shell_module = ShellModule()

    # The function expand_user should return the same value
    # as the PowerShell command (Get-Location).Path on Windows
    assert shell_module.expand_user('~') == shell_module._encode_script("Write-Output (Get-Location).Path")

    # The function expand_user should return a path

# Generated at 2022-06-23 12:43:02.613937
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    '''
    Test the command execution of a module.
    '''
    class TestShellModule(ShellModule):
        """
        A subclass of ShellModule which makes it possible to mock the
        _encode_script method.
        """

        def _encode_script(self, script, as_list=False, strict_mode=True, preserve_rc=True):
            """
            Mock _encode_script.

            @return: The script to execute.
            @rtype: str
            """
            return script

    env_string = '$ErrorActionPreference = \'Stop\''
    module_name = 'shell'
    module_args = 'echo some_value1'
    module_shebang = '#!foo'
    test_obj = TestShellModule()

# Generated at 2022-06-23 12:43:08.026224
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    # Test that with a non-existing file, exists returns 1
    module = ShellModule()
    assert module.exists("C:\\non_existing_file.txt") == b"$res = 1;\r\nWrite-Output '$res';\r\nExit $res\r\n"



# Generated at 2022-06-23 12:43:11.545018
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    plugin = ShellModule()
    assert plugin.remove("path", False) == b"Remove-Item 'path' -Force;"
    assert plugin.remove("path", True) == b"Remove-Item 'path' -Force -Recurse;"


# Generated at 2022-06-23 12:43:23.333663
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # create the test module
    module = ShellModule()
    # create a dummy variables
    tmp = "C:\\Users\\<User>\\AppData\\Local\\Temp"

    #test the empty tmpdir
    expected = module._encode_script(script='''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-1559352400.77-107708878943311'
        Write-Output -InputObject $tmp.FullName
        ''' % tmp.strip())
    assert module.mkdtemp() == expected

    # test with tmpdir

# Generated at 2022-06-23 12:43:34.781329
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test module_common
    x = ShellModule()
    result = x.build_module_command(
        'New-Variable -Name foo -Value bar',
        '#!powershell',
        'mytestmodule',
        'testarg1 testarg2'
    )

    # Test the bootstrap_wrapper.ps1 check
    result_bootstrap_wrapper = x.build_module_command(
        'New-Variable -Name foo -Value bar',
        '#!powershell',
        'join-path $PSScriptRoot mytestmodule.ps1',
        'testarg1 testarg2'
    )

    # Test binary modules

# Generated at 2022-06-23 12:43:36.292883
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm and isinstance(sm, ShellModule)

# Generated at 2022-06-23 12:43:39.372644
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    shell = ShellModule()
    shell._unquote = lambda string: string
    shell._escape = lambda string: string
    script = shell.exists('test')
    assert script == "If (Test-Path 'test'){$res=0;}Else{$res=1;}Write-Output '$res';Exit $res;"

# Generated at 2022-06-23 12:43:41.632093
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    _test_ShellModule = ShellModule()
    assert _test_ShellModule.env_prefix() == ''


# Generated at 2022-06-23 12:43:46.734077
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell = ShellModule()

    # Test normal behavior
    cmd = shell.remove("/path")
    assert cmd.strip() == "Remove-Item '/path' -Force;"

    # Test normal behavior with recurse
    cmd = shell.remove("/path", recurse=True)
    assert cmd.strip() == "Remove-Item '/path' -Force -Recurse;"

    # Test that a trailing slash is handled properly
    cmd = shell.remove("/path/to/file/", raw_arguments=False, recurse=False)
    assert cmd.strip() == "Remove-Item '/path/to/file' -Force;"

    # Test raw argument
    cmd = shell.remove("/path", raw_arguments=True)
    assert cmd.strip() == "Remove-Item '/path' -Force;"

# Generated at 2022-06-23 12:43:59.425187
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    # Base test class
    class TestModule(object):
        @staticmethod
        def get_option(x):
            return '~'
    #Instance of the Base test class
    t = TestModule()
    # Necessary for the checksum method
    class Connection(object):
        shell = ShellModule('/tmp/test_file')
    # Necessary for the checksum method
    class PlayContext(object):
        basedir = '/tmp'
        def __init__(self):
            self.check = False
    # Necessary for the checksum method
    class Play(object):
        class Task(object):
            connection = Connection()
        file_vars = []
        no_log = False
        timeout = 0
        callbacks = None
        force_handlers = False
        only_tags = None
        run

# Generated at 2022-06-23 12:44:10.928865
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import tempfile
    # build a ShellModule object with a fake tmpdir
    shell = ShellModule()
    fake_tmpdir = tempfile.mkdtemp()
    shell.options['remote_tmp'] = fake_tmpdir
    # create a temporary directory
    script = '\r\n'.join(shell.mkdtemp().split(' '))
    assert to_text(script).startswith("""
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name '""" % fake_tmpdir)
    import subprocess
    p = subprocess.Popen("powershell.exe -NonInteractive", stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    stdout, _ = p.commun

# Generated at 2022-06-23 12:44:18.264727
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import sys
    import os
    import shutil
    import tempfile
    from ansible_module_powershell import *

    test_data = [
        ("~\\AppData\\Local", b'Write-Output "C:\\Users\\test_user\\AppData\\Local"'),
        ("~", b'Write-Output "C:\\Users\\test_user"'),
        ("%SystemDrive%\\Users\\%UserName%\\AppData\\Local", b'Write-Output "C:\\Users\\test_user\\AppData\\Local"'),
        ("C:\\Users\\%UserName%\\AppData\\Local", b'Write-Output "C:\\Users\\%%UserName%%\\AppData\\Local"'),
    ]

    test_user = "test_user"

    # Revert USERNAME to the shell env when tear down
    old_user = os

# Generated at 2022-06-23 12:44:31.432051
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    input_module_shebang = "#!/usr/bin/python"
    expected_output_module_shebang = 'C:\\Python27\\python.exe "$env:temp\\ansible_modlib.zip\\ansible\\module_utils\\basic.py" "$env:temp\\ansible_modlib.zip\\ansible\\modules\\commands\\command.py"'
    input_module_without_shebang = "echo"
    expected_output_module_without_shebang = 'echo "$env:temp\\ansible_modlib.zip\\ansible\\module_utils\\basic.py" "$env:temp\\ansible_modlib.zip\\ansible\\modules\\commands\\command.py"'
    input_binary_module = "file.exe"

# Generated at 2022-06-23 12:44:34.840744
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    mod = ShellModule(connection='local', no_log=True)
    try:
        mod.chmod('/path', '777')
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 12:44:47.134409
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    exists_test_cases = [
        # source, result_expected
        ('test.txt', '''
            If (Test-Path 'test.txt')
            {
                $res = 0;
            }
            Else
            {
                $res = 1;
            }
            Write-Output '$res';
            Exit $res;
         '''),
    ]

    for exists_test_case in exists_test_cases:
        result = ShellModule().exists(exists_test_case[0])
        result = result.replace('\n', '')
        result_expected = exists_test_case[1].replace('\n', '')


# Generated at 2022-06-23 12:44:49.334992
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule(None)
    assert '1' == shell.chown(paths='/c/a', user='root')

# Generated at 2022-06-23 12:45:00.624994
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    module = ShellModule()
    content = to_bytes('Hello World')
    path = to_text(module.get_remote_filename('/tmp/test.txt'))
    cmd = module.checksum(path)
    results = module.run(cmd)

    # Create a file to test checksum
    script = """
            $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
            $tmp = [System.IO.File]::Open($tmp_path, 'Create', 'Write')
            $tmp.Write($args, 0, $args.Length)
            $tmp.Dispose()
            """ % path
    script = module._encode_script(script, preserve_rc=False)
    module.run(script, data=content)
    results = module.run(cmd)

# Generated at 2022-06-23 12:45:08.998602
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule(conn=None, tmpdir=None, become_username=None, become_password=None,
                        become_exe=None, become_flags=None, become_method=None, environment=None,
                        no_log=False, become=False, verbosity=0)
    try:
        shell.set_user_facl('path','user','mode')
        assert False
    except NotImplementedError as e:
        assert e.args[0] == 'set_user_facl is not implemented for Powershell'


# Generated at 2022-06-23 12:45:19.305782
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    '''unit tests to verify the powershell encoding of a base64-encoded powershell command'''
    powershell_module = ShellModule()
    script_1 = '''Get-ChildItem -Path $args[0]'''
    encoded_script_1 = powershell_module._encode_script(script_1)

# Generated at 2022-06-23 12:45:21.212473
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """This is just a basic sanity check to ensure we can create a ShellModule object"""
    ShellModule(connection=None, exec_env=None)

# Generated at 2022-06-23 12:45:22.857638
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    shell_module = ShellModule()
    assert 'chmod is not implemented for Powershell' == shell_module.chmod('test.txt', 775)


# Generated at 2022-06-23 12:45:26.008105
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule()
    assert 'NotImplemented' in shell.chown('/path/to/file', 'username')


# Generated at 2022-06-23 12:45:35.656362
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    module = ShellModule()
    assert module.path_has_trailing_slash('\\')
    assert module.path_has_trailing_slash('\\\\')
    assert module.path_has_trailing_slash('\\a')
    assert module.path_has_trailing_slash('/a')
    assert module.path_has_trailing_slash('/a/')
    assert module.path_has_trailing_slash('\\a\\')
    assert module.path_has_trailing_slash('a\\')
    assert module.path_has_trailing_slash('a/')
    assert not module.path_has_trailing_slash('a')


# Generated at 2022-06-23 12:45:37.292672
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert str(type(module)) == "<class 'ansible.plugins.shell.powershell.ShellModule'>"

# Generated at 2022-06-23 12:45:42.590492
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    # Arrange
    module = ShellModule()
    # Act
    result = module.exists('C:\\Windows')
    decoded_result = base64.b64decode(result).decode('utf-16-le')
    expected_result = 'If (Test-Path \'C:\\Windows\') { $res = 0; } Else { $res = 1; } Write-Output \'$res\'; Exit $res; '
    # Assert
    assert decoded_result == expected_result



# Generated at 2022-06-23 12:45:52.309585
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    # Run with debug enabled, which will output the command to run
    status, stdout, stderr = module_common.run_command(cmd, _input='', check_rc=False)
    assert status == 0

    #
    # Non-pipelining with shebang and binary module
    #

    shell = ShellModule(connection=None)

    cmd = shell.build_module_command(
        env_string='$env:ANSIBLE_INVENTORY="$env:TEMP\\inventory"',
        shebang='#!python',
        cmd=u'',
        arg_path='C:\\Windows\\System32\\calc.exe')

    # Run with debug enabled, which will output the command to run

# Generated at 2022-06-23 12:46:02.954556
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

    script = shell.mkdtemp(basefile="test_file_name", tmpdir="C:\\tmp")
    assert script == shell._encode_script("""
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\tmp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'test_file_name'
        Write-Output -InputObject $tmp.FullName
    """.strip())

    script = shell.join_path("C:\\tmp", "test_file_name", "new_file")
    assert script == shell._encode_script("""
        $res = 'C:\\tmp\\test_file_name\\new_file'
        Write-Output $res
        Exit 0
    """.strip())

    # test paths with

# Generated at 2022-06-23 12:46:14.411003
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    class TestModule(ShellModule):
        '''Test module for build_module_command'''
        def __init__(self):
            self.basefile = None
            self.system = True
            self.mode = None
            self.tmpdir = None

    # test generic call
    cmd = 'some.ps1 "a b" c d'
    shell = TestModule()
    result = shell.build_module_command('', '', cmd)
    assert result == shell._encode_script('& some.ps1 "a b" c d')

    # test shebang
    cmd = 'some.ps1 "a b" c d'
    shell = TestModule()
    result = shell.build_module_command('', '#!powershell', cmd)

# Generated at 2022-06-23 12:46:25.944518
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    assert ShellModule().join_path('C:', 'foo', 'bar') == 'C:/foo/bar'
    assert ShellModule().join_path('C:\\', 'foo', 'bar') == 'C:/foo/bar'
    assert ShellModule().join_path('C:/', 'foo', 'bar') == 'C:/foo/bar'
    assert ShellModule().join_path('C:\\', 'foo', 'bar') == 'C:/foo/bar'
    assert ShellModule().join_path('C:/foo/bar', '..', 'baz') == 'C:/foo/baz'
    assert ShellModule().join_path('C:/foo//bar', '..', 'baz') == 'C:/foo/baz'

# Generated at 2022-06-23 12:46:29.133320
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    from ansible.executor.powershell import ShellModule
    shell = ShellModule()
    assert shell.chown(["path1", "path2"], "user1") == ""

# Generated at 2022-06-23 12:46:39.398679
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import os
    import tempfile
    from ansible.executor.powershell.shell_wrappers import ShellModule

    # create a simple module (say, ping.py)
    module_path = tempfile.mkstemp(suffix='_ping.py')[1]
    with open(module_path, mode='w') as f:
        f.write("#!/bin/python\nprint 'pong'")
    os.chmod(module_path, 0o555)


# Generated at 2022-06-23 12:46:42.216085
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    sh = ShellModule()
    assert sh.wrap_for_exec('cmd') == '& cmd; exit $LASTEXITCODE'


# Generated at 2022-06-23 12:46:46.587623
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule(connection=None)
    assert mod.SHELL_FAMILY == 'powershell'
    assert mod.COMPATIBLE_SHELLS == frozenset()
    assert mod._IS_WINDOWS
    assert mod._SHELL_REDIRECT_ALLNULL == '> $null'
    assert mod._SHELL_AND == ';'
    assert mod.SHELL_TYPE == 'powershell'



# Generated at 2022-06-23 12:46:56.840231
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()
    # Test joining of path on Windows.
    assert shell.join_path('C:', 'home', 'bob', 'file.txt') == 'C:\\home\\bob\\file.txt'
    assert shell.join_path('C:\\', 'home', 'bob', 'file.txt') == 'C:\\home\\bob\\file.txt'
    assert shell.join_path('C:/', 'home', 'bob', 'file.txt') == 'C:\\home\\bob\\file.txt'
    assert shell.join_path('C:\\', 'home\\', 'bob', 'file.txt') == 'C:\\home\\bob\\file.txt'

# Generated at 2022-06-23 12:46:57.728608
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-23 12:47:06.824743
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    shell = ShellModule()


# Generated at 2022-06-23 12:47:11.058417
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    from mock import Mock
    from ansible.plugins.shell import ShellModule
    shell_module = ShellModule(connection=Mock())
    assert shell_module.env_prefix() == ""

if __name__ == '__main__':
    # Unit test for method env_prefix of class ShellModule
    test_ShellModule_env_prefix()

# Generated at 2022-06-23 12:47:21.672262
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
        cmd = '''
            If (Test-Path psdrive:test)
            {
                $res = 0;
            }
            Else
            {
                $res = 1;
            }
            Write-Output '$res';
            Exit $res;
         '''
        cmd = cmd.strip()
        encoded_script = ' '.join(['PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand' , to_text(base64.b64encode(cmd.encode('utf-16-le')), 'utf-8')])
        print(encoded_script)

if __name__ == '__main__':
    test_ShellModule_exists()

# Generated at 2022-06-23 12:47:23.623790
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell_module = ShellModule()
    assert 'set_user_facl is not implemented for Powershell' == shell_module.set_user_facl('/tmp/foo', 'bar', '0777')


# Generated at 2022-06-23 12:47:28.936697
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    from ansible_collections.notstdlib.moveitallout.tests.units.mock.loader import DictDataLoader
    from ansible_collections.notstdlib.moveitallout.plugins.action.shell_windows import ActionModule as ShellModule

    shell = ShellModule({}, DictDataLoader({}))
    assert shell.chmod('/tmp/example', 755) == 'chmod 755 /tmp/example'
    del shell


# Generated at 2022-06-23 12:47:32.995683
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    test_shell = ShellModule()
    assert test_shell.chmod("/path", 0o777) == "NOTIMPLEMENTED - chmod is not implemented for Powershell"


# Generated at 2022-06-23 12:47:41.586505
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    env_string = ''
    shebang = '#!powershell'
    cmd = '/usr/bin/python setup.py install'
    expected = shell._encode_script(script='type "setup.py.ps1" | & "bootstrap_wrapper.ps1"')
    actual = shell.build_module_command(env_string, shebang, cmd)
    assert expected == actual
    shebang = ''
    cmd = '/usr/bin/python setup.py install'
    expected = "& '/usr/bin/python' 'setup.py.ps1' 'install'; exit $LASTEXITCODE"
    actual = shell.build_module_command(env_string, shebang, cmd)
    assert expected == actual

# Generated at 2022-06-23 12:47:45.000521
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    s = ShellModule()

    # Test without parameters
    try:
        s.chmod()
    except Exception as e:
        assert e.message == "chmod is not implemented for Powershell"


# Generated at 2022-06-23 12:47:48.101468
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    print(shell.mkdtemp(basefile='ansible-tmp-test-', tmpdir='/tmp'))


# Generated at 2022-06-23 12:47:58.493304
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # case: a shebang of '#!/bin/sh'
    cmd = "pwd"
    env_string = "env_string"
    shebang = "#! /bin/sh"
    # the actual command that is expected to be executed by the exec module
    expected_cmd = "cd \"$(dirname -- \"$0\")\"; \"$(basename -- \"$0\")\"; exit $?"
    expected_cmd = expected_cmd.strip(';')

    shell_module = ShellModule()
    actual_cmd = shell_module.build_module_command(env_string, shebang, cmd).strip(';')
    assert actual_cmd == expected_cmd

    # case: a shebang of '#!powershell'
    cmd = "pwd"
    env_string = "env_string"
    shebang

# Generated at 2022-06-23 12:48:03.542961
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    s = ShellModule()
    assert s.remove('c:\\file.txt') == b'Remove-Item \'c:\\\\file.txt\' -Force;'
    assert s.remove('c:\\windows\\system32\\foo.txt', True) == b'Remove-Item \'c:\\\\windows\\\\system32\\\\foo.txt\' -Force -Recurse;'


# Generated at 2022-06-23 12:48:15.721012
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    assert not shell_module.path_has_trailing_slash('/path/')
    assert shell_module.path_has_trailing_slash('/path/file.txt')
    assert shell_module.path_has_trailing_slash('/path/file.txt/')
    assert shell_module.path_has_trailing_slash('"/path/file.txt"')
    assert shell_module.path_has_trailing_slash('"/path/file.txt/"')
    assert shell_module.path_has_trailing_slash('"/path/file.txt/file.txt"')
    assert not shell_module.path_has_trailing_slash('"/path/file.txt/"')
    assert not shell_module.path_has

# Generated at 2022-06-23 12:48:20.832928
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    import sys
    sys.modules['ansible.plugins.connection.winrm'] = None
    shell_module = ShellModule()
    assert '$Env:ANSIBLE_' in shell_module.env_prefix()
    del sys.modules['ansible.plugins.connection.winrm']

# Generated at 2022-06-23 12:48:29.933801
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell.native_powershell import to_bytes
    from ansible.module_utils._text import to_native

    text_type = u'text'
    result = ShellModule.build_module_command(ShellModule(), text_type, text_type, text_type)

    if not isinstance(result, str) and isinstance(result, bytes):
        result = to_native(result)

    assert isinstance(result, str)
    assert 'Set-StrictMode -Version Latest' in result

# Generated at 2022-06-23 12:48:37.650310
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    import tempfile
    import shutil
    import os

    tmpdir = to_text(tempfile.mkdtemp())

    # create a test file
    test_file = os.path.join(tmpdir, 'shellmodule_test')
    with open(test_file, 'wb') as f:
        f.write(b'testfile')
    sha1_testfile = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

    # create a test directory
    test_dir = os.path.join(tmpdir, 'directory')
    os.makedirs(test_dir)

    # create the ShellModule class object
    shell_class = ShellModule()

    # test_file should return a proper sha1 checksum
    actual_return = shell_class

# Generated at 2022-06-23 12:48:48.351182
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell import ShellModule

    sm = ShellModule(connection=None)
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    p = sm.build_module_command(env_string="", shebang='#!powershell', cmd="somepath", arg_path="somepath")
    assert p is not None
    assert 'type' in p
    assert 'somepath.ps1' in p
    assert 'bootstrap_wrapper.ps1' in p

    p = sm.build_module_command(env_string="", shebang='#!/bin/bash', cmd="somepath", arg_path="somepath")
    assert p is not None
    assert 'somepath' in p

# Generated at 2022-06-23 12:48:53.753740
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Assume basefile is None and tmpdir is None
    shell_module = ShellModule()
    # Assume basefile is not None and tmpdir is None
    shell_module = ShellModule()
    # Assume basefile is None and tmpdir is not None
    shell_module = ShellModule()
    # Assume basefile is not None and tmpdir is not None
    shell_module = ShellModule()
    # Assume basefile is not None and tmpdir is not None and invalid basefile
    shell_module = ShellModule()



# Generated at 2022-06-23 12:48:56.438547
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    data = ShellModule()
    assert data.wrap_for_exec('whoami') == '& whoami; exit $LASTEXITCODE'



# Generated at 2022-06-23 12:49:08.781267
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module = ShellModule()

    test_dict = {
        'path' : '~',
        'output' : 'Write-Output (Get-Location).Path'
    }
    assert shell_module.expand_user(**test_dict) == shell_module._encode_script(script=test_dict['output'])

    test_dict = {
        'path' : '~\\',
        'output' : "Write-Output ((Get-Location).Path + '\\')"
    }
    assert shell_module.expand_user(**test_dict) == shell_module._encode_script(script=test_dict['output'])


# Generated at 2022-06-23 12:49:21.630410
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    '''Return a command line that executes an encoded PowerShell script without attaching a debugger. '''
    shell = ShellModule()
    cmd = '& %s; exit $LASTEXITCODE' % shell._encode_script('Write-Output \'Hello World!\'')

# Generated at 2022-06-23 12:49:27.644344
# Unit test for method wrap_for_exec of class ShellModule

# Generated at 2022-06-23 12:49:34.418565
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    shell_obj = ShellModule()
    path = 'my_path'
    script = shell_obj.exists(path)
    path = shell_obj._escape(shell_obj._unquote(path))
    expected_script = '''
            If (Test-Path '%s')
            {
                $res = 0;
            }
            Else
            {
                $res = 1;
            }
            Write-Output '$res';
            Exit $res;
         ''' % path
    assert script == shell_obj._encode_script(expected_script)

# Generated at 2022-06-23 12:49:35.640011
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell_plugin = ShellModule(connection=None)
    assert shell_plugin.env_prefix() == ""


# Generated at 2022-06-23 12:49:40.436173
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    module = ShellModule(command_timeout=1)
    path = r"C:\Users\vagrant\OneDrive\Documents\Powershell_scripts\Test.ps1"
    print(module.remove(path, recurse=False))
    print(module.remove(path, recurse=True))


# Generated at 2022-06-23 12:49:49.103012
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    
    ShellModule_obj = ShellModule()
    
    ## test case - 01
    path = ShellModule_obj._escape(ShellModule_obj._unquote('/root'))
    script = '''
        If (Test-Path '%s')
        {
            $res = 0;
        }
        Else
        {
            $res = 1;
        }
        Write-Output '$res';
        Exit $res;
     ''' % path
    script = script.strip()
    cmd_parts = ' '.join(_common_args + ['-EncodedCommand', to_text(base64.b64encode(script.encode('utf-16-le')), 'utf-8')])
    
    assert ShellModule_obj.exists('/root') == cmd_parts

    ## test case - 02

# Generated at 2022-06-23 12:50:00.812154
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    shell = ShellModule()

    # Test simple path
    path = shell._escape("c:\\Windows\\System32")
    script = '''
        If (Test-Path '%s')
        {
            $res = 0;
        }
        Else
        {
            $res = 1;
        }
        Write-Output '$res';
        Exit $res;
    ''' % path

# Generated at 2022-06-23 12:50:02.009703
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    pass



# Generated at 2022-06-23 12:50:12.195361
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()

# Generated at 2022-06-23 12:50:14.708873
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule(None)
    test_string = shell.wrap_for_exec('test string')
    assert test_string == "& 'test string'; exit $LASTEXITCODE"

# Generated at 2022-06-23 12:50:21.657974
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    import pytest

    shexec = ShellModule(run_command=None)

    # Test remove with recurse=False
    # Test path with spaces and with "-" and "/" characters
    command = shexec.remove("my file - 1.ps1", recurse=False)

# Generated at 2022-06-23 12:50:23.895998
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    # Setup
    myshell = ShellModule()
    # Test
    assert myshell.env_prefix(**{}) == ""

# Generated at 2022-06-23 12:50:31.959834
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.powershell import ensure_bytes

    def _test_checksum(filename, contents, expected_checksum, shell):
        path = os.path.join(tmpdir, filename)
        with open(path, 'wb') as f:
            f.write(ensure_bytes(contents))

        filename = shell._escape(shell._unquote(filename))

# Generated at 2022-06-23 12:50:33.988634
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    shell = ShellModule(connection=None, **{'_host': None})
    path = 'C:\\Users\\foo\\file.txt'
    mode = '0755'
    result = shell.chmod(path=path, mode=mode)
    assert result == "NOT SUPPORTED"


# Generated at 2022-06-23 12:50:44.003607
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    import pytest
    from units.compat.mock import patch

    ansible = pytest.importorskip('ansible')
    from ansible.plugins.shell.powershell import ShellModule

    # Create a mock task to test
    # the below patch is more of a "catch-all" to ensure that nothing will
    # actually execute when we call the callback.  We just need to instantiate
    # the class.

# Generated at 2022-06-23 12:50:54.550150
# Unit test for method exists of class ShellModule

# Generated at 2022-06-23 12:50:57.935795
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    test_obj = ShellModule()
    paths = list()
    user = 'test'
    mode = 'test'

    test_obj.set_user_facl(paths, user, mode)


# Generated at 2022-06-23 12:51:06.218192
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()

    assert shell.join_path('C:\\', 'foo') ==   'C:\\foo'
    assert shell.join_path('C:\\', '\\foo') == 'C:\\foo'
    assert shell.join_path('C:\\', 'foo\\') == 'C:\\foo'
    assert shell.join_path('C:\\', '\\foo\\') == 'C:\\foo'
    assert shell.join_path('C:\\', '/foo') ==   'C:\\foo'
    assert shell.join_path('C:\\', '\\foo') == 'C:\\foo'
    assert shell.join_path('C:\\', '/foo\\') ==   'C:\\foo'

# Generated at 2022-06-23 12:51:13.273307
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule()

    # Test case: Test for raising of NotImplementedException in function chown
    try:
        shell.chown("", "")
        raise AssertionError("NotImplementedException not raised in function chown")
    except NotImplementedError as e:
        assert e.args[0] == "chown is not implemented for Powershell"


# Generated at 2022-06-23 12:51:15.563388
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    assert '& test; exit $LASTEXITCODE' == ShellModule().wrap_for_exec('test')
