

# Generated at 2022-06-23 12:41:19.811790
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    module = ShellModule({})
    with pytest.raises(NotImplementedError):
        module.set_user_facl("path", "user", "mode")

# Generated at 2022-06-23 12:41:30.669981
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.common.text.converters import to_bytes
    shm = ShellModule(connection=None, no_log=None, run_anyway=None)
    assert (shm.SHELL_FAMILY == 'powershell')
    assert (shm.join_path('test1', 'test2') == 'test1\\test2')
    assert (shm.join_path('test1/', 'test2\\') == 'test1\\test2')
    assert (shm.join_path('C:\\', 'test1/', 'test2\\') == 'C:\\test1\\test2')
    assert (shm.get_remote_filename('test1.py') == 'test1.py')

# Generated at 2022-06-23 12:41:31.547410
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    return True

# Generated at 2022-06-23 12:41:43.472359
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()

    pathname = 'my_script.ps1'
    expected = 'my_script.ps1'
    result = shell.get_remote_filename(pathname)
    assert result == expected

    pathname = 'my_script.sh'
    expected = 'my_script.ps1'
    result = shell.get_remote_filename(pathname)
    assert result == expected

    pathname = 'my_script.bash'
    expected = 'my_script.ps1'
    result = shell.get_remote_filename(pathname)
    assert result == expected

    pathname = 'my_script'
    expected = 'my_script.ps1'
    result = shell.get_remote_filename(pathname)
    assert result == expected


# Generated at 2022-06-23 12:41:50.232944
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    module = ShellModule()
    assert module.join_path(b'c:/tmp', b'abc', b'abc') == 'c:\\tmp\\abc\\abc'
    assert module.join_path(b'c:/tmp', b'abc', b'abc\\') == 'c:\\tmp\\abc\\abc\\'

    if os.path.normcase(__file__) == 'test_powershell_windows.py':
        # skip this test when running from installed module, because it will fail
        assert module.join_path(b'c:/tmp', b'abc', b'..\\abc') == 'c:\\tmp\\abc'

# Generated at 2022-06-23 12:42:02.440632
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    '''Test for method build_module_command of class ShellModule'''
    import os

    tempfile.tempdir = os.sep + 'tmp'
    shell = ShellModule()
    powershell = shell.get_option('shell')

    cmd = r'Write-Output "Hello World"'
    as_list = shell.build_module_command(None, '#!powershell', cmd, None)
    assert type(as_list) is list
    assert len(as_list) == 2
    cmd_first_part = "type echo.ps1 | " + shell._encode_script(script=shell.get_remote_filename(powershell), strict_mode=False, preserve_rc=False)
    assert as_list[0].startswith(cmd_first_part)

    cmd = "Write-Output 'Hello World'"


# Generated at 2022-06-23 12:42:08.519937
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == "DQoKCXdyaXRlLW91dHB1dCAoZ2V0LWxvY2F0aW9uKS5wYXRoDQoKCg=="

# Generated at 2022-06-23 12:42:11.359070
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell_module = ShellModule()
    assert shell_module.env_prefix() == ''



# Generated at 2022-06-23 12:42:17.479638
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Create a shell plugin for testing purposes
    shell = ShellModule()

    # Test a path ending with a trailing slash
    path = r'C:\Windows\\'
    assert shell.path_has_trailing_slash(path) == True

    # Test a path not ending with a trailing slash
    path = r'C:\Windows'
    assert shell.path_has_trailing_slash(path) == False


# Generated at 2022-06-23 12:42:20.431457
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
  sm = ShellModule()
  assert sm.wrap_for_exec('$foo') == '& $foo; exit $LASTEXITCODE'

# Generated at 2022-06-23 12:42:24.336020
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule()
    cmd = 'test.ps1'
    wrapped_cmd = '& test.ps1; exit $LASTEXITCODE'
    assert shell.wrap_for_exec(cmd) == wrapped_cmd


# Generated at 2022-06-23 12:42:27.481611
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell_obj = ShellModule()
    base = 'C:\\'
    assert shell_obj.join_path(base, 'a', 'b', 'c') == 'C:\\a\\b\\c', 'win_shell.join_path failed'



# Generated at 2022-06-23 12:42:37.739083
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    module = ShellModule()
    # Test with path type leaf
    test_data = dict(path="C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe")
    expected_data = '''
            If (Test-Path 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe')
            {
                $res = 0;
            }
            Else
            {
                $res = 1;
            }
            Write-Output '$res';
            Exit $res;
         '''
    assert module.exists(**test_data) == module._encode_script(expected_data)
    # Test with path type container
    test_data = dict(path="C:\\Windows\\System32\\WindowsPowerShell\\v1.0")

# Generated at 2022-06-23 12:42:45.706688
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_obj = ShellModule(connection=None, add_ansible_module=False, runner_supports_wildcards=True)
    cmd = shell_obj.mkdtemp(basefile='basefilename.fileextension', tmpdir='T:\temp', system=False)
    expected_cmds = [
        "$tmp_path = [System.Environment]::ExpandEnvironmentVariables('T:\temp')",
        "$tmp = New-Item -Type Directory -Path $tmp_path -Name 'basefilename.fileextension'",
        'Write-Output -InputObject $tmp.FullName'
    ]
    cmds = cmd.split(';')
    assert len(cmds) == len(expected_cmds)
    for i, cmd_in_list in enumerate(cmds):
        assert cmd_in_list.strip() == expected

# Generated at 2022-06-23 12:42:48.281426
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    module = ShellModule()
    with pytest.raises(NotImplementedError):
        module.chmod('path', 'mode')


# Generated at 2022-06-23 12:42:54.392925
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    args = dict(
        module_name='file',
        module_args='name=foo state=touch owner=root group=root',
        task_vars=dict(ansible_winrm_transport='kerberos')
    )

    sm = ShellModule()
    result = sm.chown(module_args=args)

    assert result == 'file name=foo state=touch owner=root group=root'



# Generated at 2022-06-23 12:43:03.161927
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import os
    import tempfile

    class MockActionModule:

        def __init__(self):
            self.runner = None
            self.connection = None
            self.module = None
            self.shebang = None

    class MockOptions:

        def __init__(self):
            self.remote_tmp = tempfile.gettempdir()

    class MockAnsibleModule:

        def __init__(self):
            self.runner = MockActionModule()
            self.module = MockActionModule()
            self.options = MockOptions()
            self.runner.module = self.module
            self.runner.module.runner = self.runner

    class MockTaskResult:

        def __init__(self):
            self.__init()

        def __init(self):
            self.cmd = list()

# Generated at 2022-06-23 12:43:13.946602
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    # mock class
    class MockArgs(object):
        pass

    class MockModule(object):
        pass

    module = MockModule()
    module.args = MockArgs()
    module.args.host = 'localhost'
    module.args.password = 'Password123'
    module.args.connection = 'winrm'
    module.args.port = '5986'
    module.args.timeout = '600'
    module.args.username = 'ansible'
    module.args.no_log = False
    module.args.transport = 'kerberos'
    module.args.remote_tmp = 'c:\\ansible\\tmp'
    module.args.nossl = False
    module.args.nosslverify = False
    module.args.dest = 'C:\\ansible\\test_file'

# Generated at 2022-06-23 12:43:24.568262
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()

    # 'base_path' doesn't end in a slash, 'path' doesn't start with a slash
    assert shell.join_path('base_path', 'path') == 'base_path\\path'

    # 'base_path' ends in a slash, 'path' doesn't start with a slash
    assert shell.join_path('base_path\\', 'path') == 'base_path\\path'

    # 'base_path' doesn't end in a slash, 'path' starts with a slash
    assert shell.join_path('base_path', '\\path') == 'base_path\\path'

    # 'base_path' ends in a slash, 'path' starts with a slash
    assert shell.join_path('base_path\\', '\\path') == 'base_path\\path'

# Generated at 2022-06-23 12:43:36.050677
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible_powershell import ShellModule
    shell = ShellModule(None)
    env_string = shell._compile_flags(dict())
    shebang = None
    cmd = shell._escape('C:\\Program Files\\WindowsPowerShell\\Modules\\TestModule\\TestModule.psm1')
    arg_path = shell._escape('C:\\Program Files\\WindowsPowerShell\\Modules\\TestModule\\Arguments.txt')
    cmd_list = shell.build_module_command(env_string, shebang, cmd, arg_path).split()
    # first argument is the executable
    assert cmd_list[0] == 'PowerShell', "The first argument is not PowerShell"
    # second argument is -NoProfile
    assert cmd_list[1] == '-NoProfile', "The second argument is not '-NoProfile'"
    #

# Generated at 2022-06-23 12:43:39.067351
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule(connection=None)
    assert mod.IS_WINDOWS == True
    assert mod.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-23 12:43:45.734058
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    tests = [
        # (input_value, expected_output)
        ("~", "((Get-Location).Path)"),
        ("~\\test", "((Get-Location).Path + '\\test')"),
        ("test\\~\\test", "'test\\~\\test'")
    ]

    sm = ShellModule()
    for (input, expected) in tests:
        assert sm.expand_user(input) == sm._encode_script(expected)

# Generated at 2022-06-23 12:43:58.327141
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Windows paths can contain both forward and backward slashes to separate directory/file names.
    assert ShellModule().path_has_trailing_slash('C:/Users/')
    assert ShellModule().path_has_trailing_slash('C:/Users\\')
    assert ShellModule().path_has_trailing_slash('C:\\Users\\')
    assert ShellModule().path_has_trailing_slash('C:/Users/Test/')
    assert ShellModule().path_has_trailing_slash('C:\\Users\\Test\\')
    assert ShellModule().path_has_trailing_slash('C:/Users\\Test/')
    assert ShellModule().path_has_trailing_slash('C:/Users\\Test\\')

# Generated at 2022-06-23 12:44:06.798933
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    check_paths = ['/tmp/foo/bar/', '/tmp/foo\\bar\\', 'c:\\foo\\bar\\']
    result = []
    for path in check_paths:
        result.append(shell.path_has_trailing_slash(path))
    if result != [True, True, True]:
        raise Exception('path_has_trailing_slash returned %s, expected [True, True, True]' % result)

if __name__ == '__main__':
    test_ShellModule_path_has_trailing_slash()

# Generated at 2022-06-23 12:44:08.687755
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule()
    assert shell.env_prefix() == ''



# Generated at 2022-06-23 12:44:18.410296
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansiballz.tests.utils import get_next_target_powershell
    target, _ = get_next_target_powershell()
    assert target.expand_user('~/bar') == "Write-Output '$HOME/bar'"
    assert target.expand_user('~\\bar') == "Write-Output ((Get-Location).Path + '\\bar')"
    assert target.expand_user('~/bar/') == "Write-Output '$HOME/bar/'"
    assert target.expand_user('~\\bar\\') == "Write-Output ((Get-Location).Path + '\\bar\\')"


# Generated at 2022-06-23 12:44:31.706547
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    """
    Test the build_module_command method of the ShellModule class.
    """
    sm = ShellModule(None)

    # pipelining bypass
    cmd = sm.build_module_command('', '', '')
    assert cmd.startswith('powershell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand')

    # non-pipelining, default shebang
    cmd = sm.build_module_command('', '', 'python setup.py install')
    assert cmd.startswith('powershell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand')
    assert 'python setup.py install' in cmd

    # non-pipelining, powershell
    cmd = sm.build_module_command('', '#!powershell', 'foo bar baz')

# Generated at 2022-06-23 12:44:34.018774
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    # Test that env_prefix() returns a string
    tmp_shell = ShellModule()
    assert isinstance(tmp_shell.env_prefix(), str)

# Generated at 2022-06-23 12:44:45.528804
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    '''
    Unit test for method remove of class ShellModule
    '''
    # Encodes the script and checks if it is the expected one
    sh = ShellModule()
    assert sh.remove('path') == '''\n$MyInvocation.MyCommand.ScriptBlock.File = $MyInvocation.MyCommand.ScriptBlock.File -replace '\\\\','\\\\\\\\'\nRemove-Item "path" -Force;\n'''
    assert sh.remove('path', recurse=True) == '''\n$MyInvocation.MyCommand.ScriptBlock.File = $MyInvocation.MyCommand.ScriptBlock.File -replace '\\\\','\\\\\\\\'\nRemove-Item "path" -Force -Recurse;\n'''


# Generated at 2022-06-23 12:44:47.183696
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell_module = ShellModule()
    assert shell_module.env_prefix(FOO='bar') == ''


# Generated at 2022-06-23 12:44:56.070590
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    '''
    Powershell
    ==========

    Windows does not have a system-wide temporary directory. Powershell modules
    are encoded in base64 and executed by a powershell.exe command. We test
    both powershell and powershell_command modules.
    '''
    assert ShellModule({}).get_remote_filename('/path/to/file') == 'file.ps1'
    assert ShellModule({}).get_remote_filename('/path/to/file.ps1') == 'file.ps1'
    assert ShellModule({}).get_remote_filename('/path/to/file.py') == 'file.py.ps1'
    assert ShellModule({}).get_remote_filename('/path/to/file.exe') == 'file.exe'

# Generated at 2022-06-23 12:45:08.021695
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()

    # Test PS bootstrap wrapper
    module_cmd = 'Test-Module'
    shebang = '#!powershell'
    env_string = '$env:PATH'
    actual_cmd = module.build_module_command(env_string, shebang, module_cmd)
    expected_cmd = "%s '%s'" % (module._encode_script(script=bootstrap_wrapper, strict_mode=False, preserve_rc=False),
                                module_cmd)
    assert actual_cmd == expected_cmd

    # Test PS non-bootstrap wrapper
    shebang = '#!powershell'
    module_cmd = 'Tests.ps1'
    actual_cmd = module.build_module_command(env_string, shebang, module_cmd)

# Generated at 2022-06-23 12:45:11.598868
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    sh = ShellModule(connection=None, become_method=None, become_user=None)
    assert sh.env_prefix() == ''


if __name__ == '__main__':
    test_ShellModule_env_prefix()

# Generated at 2022-06-23 12:45:14.746125
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    shell = ShellModule()
    try:
        shell.chmod("/path/to/file", "0644")
    except NotImplementedError as e:
        assert 'chmod is not implemented for Powershell' in str(e)


# Generated at 2022-06-23 12:45:17.404309
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell_module = ShellModule()
    shell_module.set_user_facl('', '')


# Generated at 2022-06-23 12:45:26.799762
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell_obj = ShellModule()

    # All arguments are absolute paths
    assert shell_obj.join_path("C:\\test","C:\\test\\ansible") == "C:\\test\\ansible"

    # Two arguments, first absolute, second relative path
    assert shell_obj.join_path("C:\\test","ansible") == "C:\\test\\ansible"

    # one relative path
    assert shell_obj.join_path("test","ansible") == "test\\ansible"

    # two relative paths
    assert shell_obj.join_path("test","ansible","test") == "test\\ansible\\test"

    # two relative paths, one of them empty
    assert shell_obj.join_path("","ansible","test") == "ansible\\test"

# Generated at 2022-06-23 12:45:29.822167
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    shell = ShellModule(connection=None, no_log=True)
    chmod_result = shell.chmod('C:\\Users\\a\\Documents\\a.txt', '0755')
    assert chmod_result == NotImplementedError('chmod is not implemented for Powershell')


# Generated at 2022-06-23 12:45:37.128018
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    ret = ShellModule().path_has_trailing_slash('C:\\Users\\')
    assert ret is True

    ret = ShellModule().path_has_trailing_slash('dir1/dir2\\dir3\\')
    assert ret is True

    ret = ShellModule().path_has_trailing_slash('\\dir1/dir2\\dir3')
    assert ret is False

    ret = ShellModule().path_has_trailing_slash('dir1\\dir2/dir3')
    assert ret is False

# Generated at 2022-06-23 12:45:49.285011
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    assert(bootstrap_wrapper)

    # Invoke with NULL cmd: pipelining bypass
    pshell = ShellModule()
    cmd = pshell.build_module_command("$env:FOO = \"bar\"", '', '')
    assert(cmd == pshell._encode_script(script=bootstrap_wrapper, strict_mode=False, preserve_rc=False))

    # Invoke with shebang PowerShell (module via bootstrap)
    cmd = pshell.build_module_command("$env:FOO = \"bar\"", "#!powershell", "file")

# Generated at 2022-06-23 12:45:59.774676
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()
    if shell.join_path('c:\\', 'share', 'folder') != 'c:\\share\\folder':
        raise AssertionError("Path not joined properly: %s" % shell.join_path('c:\\', 'share', 'folder'))
    if shell.join_path("c:\\", "share\\", "folder") != "c:\\share\\folder":
        raise AssertionError("Path not joined properly: %s" % shell.join_path("c:\\", "share\\", "folder"))
    if shell.join_path("c:\\", "share\\", "folder\\") != "c:\\share\\folder":
        raise AssertionError("Path not joined properly: %s" % shell.join_path("c:\\", "share\\", "folder\\"))
    shell

# Generated at 2022-06-23 12:46:08.182185
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    shell = ShellModule(connection=None, play_context=None, shell_executable=None)

    # file has some content
    assert shell.checksum(path="test_file", data="test") == "{0}".format(to_text(b'5e543256c480ac577d30f76f9120eb74f12bbc5b'))

    # empty file
    assert shell.checksum(path="test_file", data="") == "{0}".format(to_text(b'da39a3ee5e6b4b0d3255bfef95601890afd80709'))

    # test for directory path
    assert shell.checksum(path="test_dir") == "{0}".format(to_text(b'3'))

    # test for invalid path
    assert shell.checksum

# Generated at 2022-06-23 12:46:14.855359
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    shell.no_log = False
    # non-pipelining
    cmd = shell.build_module_command('', '', 'echo foo')
    assert cmd == '& $PSVersionTable.PSVersion.Major -ge 3 -and (Invoke-Command { [System.Text.Encoding]::UTF8.GetString(([System.Convert]::FromBase64String((gp AnsiblePSVersion -EA 0).Content))); exit $LASTEXITCODE }  | iex; exit $LASTEXITCODE); exit $LASTEXITCODE'

    # pipelining, explicit powershell
    cmd = shell.build_module_command('', '#!/usr/bin/powershell', '')

# Generated at 2022-06-23 12:46:21.771792
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    plugin = ShellModule()
    assert plugin.expand_user("~").decode() == plugin._encode_script("Write-Output (Get-Location).Path").decode()
    assert plugin.expand_user("~foobar").decode() == plugin._encode_script("Write-Output '~foobar'").decode()
    assert plugin.expand_user("~\\foobar").decode() == plugin._encode_script("Write-Output ((Get-Location).Path + '\\foobar')").decode()
    assert plugin.expand_user("C:\\foobar").decode() == plugin._encode_script("Write-Output 'C:\\foobar'").decode()

# Generated at 2022-06-23 12:46:23.318899
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    module = ShellModule()
    assert module.chown([], None) is NotImplementedError

# Generated at 2022-06-23 12:46:35.448298
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    # arrange
    module = ShellModule()

    # act/assert
    assert module.join_path('/home/user/.ssh/id_rsa') == r'\home\user\.ssh\id_rsa'
    assert module.join_path(r'c:\temp', r'\\server\share\test.txt') == r'c:\temp\server\share\test.txt'
    assert module.join_path('/home/user/data/', '../abc') == r'\home\user\data\..\abc'
    assert module.join_path('') == ''
    assert module.join_path(r'\\server\share') == r'\\server\share'

# Generated at 2022-06-23 12:46:48.093284
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create a dummy shell module that is used to test some of the
    # base implementation of the module.
    shell_mod = ShellModule()

    # Test parsing of a module filename that does not end in .ps1
    remote_mod_path = shell_mod.get_remote_filename('test.exe')
    assert remote_mod_path == 'test.exe'

    # Test parsing of a module filename that does end in .ps1
    remote_mod_path = shell_mod.get_remote_filename('test.ps1')
    assert remote_mod_path == 'test.ps1'

    # Test parsing of a module filename that does not have an extension
    remote_mod_path = shell_mod.get_remote_filename('test')
    assert remote_mod_path == 'test.ps1'

    # Test parsing of a module path

# Generated at 2022-06-23 12:46:58.844630
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()
    result = shell.join_path('C:\\', 'Windows', 'Temp', 'ansible-tmp-1537904064.02-117855822642994')
    assert result == 'C:\\Windows\\Temp\\ansible-tmp-1537904064.02-117855822642994'
    result = shell.join_path('C:\\', 'Windows\\', 'Temp\\', 'ansible-tmp-1537904064.02-117855822642994\\')
    assert result == 'C:\\Windows\\Temp\\ansible-tmp-1537904064.02-117855822642994'

# Generated at 2022-06-23 12:47:10.353382
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_mod = ShellModule()

    # Test for trailing slash
    assert shell_mod.path_has_trailing_slash("C:\\\Test\\")
    assert shell_mod.path_has_trailing_slash("C:\\\Test/")
    assert shell_mod.path_has_trailing_slash("C:\\\Test\\\\\\")
    assert shell_mod.path_has_trailing_slash("C:\\\Test/\\\\")
    assert shell_mod.path_has_trailing_slash("C:\\\Test////")

    # Test for no trailing slash
    assert not shell_mod.path_has_trailing_slash("C:\\\TestDirectory")
    assert not shell_mod.path_has_trailing_slash("C:\\\TestDirectory\\")

# Generated at 2022-06-23 12:47:19.917819
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    class EmptyModule:
        pass
    mod = EmptyModule()
    # setup
    my_ShellModule = ShellModule(mod)
    my_ShellModule._escape = lambda x: x
    my_ShellModule._unquote = lambda x: x

    # test
    assert my_ShellModule.exists("/usr/bin/ansible") == '''
            If (Test-Path '/usr/bin/ansible')
            {
                $res = 0;
            }
            Else
            {
                $res = 1;
            }
            Write-Output '$res';
            Exit $res;
         '''
    # cleanup - none necessary


# Generated at 2022-06-23 12:47:23.410742
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    """
    Test exists method from shell plugin
    """
    m = ShellModule()
    assert m.exists("c:\\windows") == 0

# Generated at 2022-06-23 12:47:31.598074
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.plugins.shell import ShellModule

    m = ShellModule()
    commands = [
        ('~',
         m.expand_user('~')),
        ('\\~\\bin',
         m.expand_user('~\\bin')),
        ('C:\\WINDOWS',
         m.expand_user('C:\\WINDOWS')),
        ("'C:\\Program Files (x86)'",
         m.expand_user("'C:\\Program Files (x86)'")),
        ('"C:\\Program Files (x86)"',
         m.expand_user('"C:\\Program Files (x86)"')),
    ]

    for item in commands:
        print("%s %s" % (item[0], item[1]))



# Generated at 2022-06-23 12:47:40.175274
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    test_cases = [  # command, expected output
        ('ls', '& ls; exit $LASTEXITCODE'),
        ('''$a='a'; ls $a''', '''& $a='a'; ls $a; exit $LASTEXITCODE'''),
        ('"ls"', '& "ls"; exit $LASTEXITCODE'),
        ('"ls" "a"', '& "ls" "a"; exit $LASTEXITCODE')
    ]

    for test_case in test_cases:
        assert ShellModule.wrap_for_exec(ShellModule, test_case[0]) == test_case[1]



# Generated at 2022-06-23 12:47:50.304331
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    sh = ShellModule(connection='winrm', no_log=True)

    # Test removing a directory.
    code = sh.remove(path='C:\\test\\foo', recurse=True)
    assert code == sh._encode_script('''Remove-Item 'C:\\test\\foo' -Force -Recurse;''')

    # Test removing a file.
    code = sh.remove(path='C:\\test\\foo.txt', recurse=False)
    assert code == sh._encode_script('''Remove-Item 'C:\\test\\foo.txt' -Force;''')


# Generated at 2022-06-23 12:47:59.737031
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    import os
    from units.compat.mock import patch

    shell = ShellModule(command_timeout=300, connect_timeout=10, become_method='runas')
    script = shell.exists(os.path.dirname(__file__))
    assert script == shell._encode_script('''
            If (Test-Path '{path}')
            {{
                $res = 0;
            }}
            Else
            {{
                $res = 1;
            }}
            Write-Output '$res';
            Exit $res;
         '''.format(path=os.path.dirname(__file__)))
    with patch.object(ShellModule, '_unquote', return_value=script):
        assert shell.exists(script) == script

# Generated at 2022-06-23 12:48:02.025930
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell_obj = ShellModule()
    result = shell_obj.env_prefix()
    assert result == ""


# Generated at 2022-06-23 12:48:05.510470
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    pathname = str('/tmp/file1.txt')
    ansible_powershell_shell = ShellModule()
    assert ansible_powershell_shell.get_remote_filename(pathname) == 'file1.txt'


# Generated at 2022-06-23 12:48:11.225211
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule(connection=None, run_command=None)
    exc = None
    try:
        shell.set_user_facl(paths=None, user=None, mode=None)
    except NotImplementedError as e:
        exc = e
    assert "not implemented" in str(exc)

# Generated at 2022-06-23 12:48:20.754601
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # ensure Windows paths are correctly identified as having a trailing slash
    # single backslash
    assert ShellModule().path_has_trailing_slash('C:\\')
    assert ShellModule().path_has_trailing_slash('C:\\test\\')
    assert not ShellModule().path_has_trailing_slash('C:\\test')

    # double backslash
    assert ShellModule().path_has_trailing_slash('C:\\\\')
    assert ShellModule().path_has_trailing_slash('C:\\\\test\\\\')
    assert not ShellModule().path_has_trailing_slash('C:\\\\test')

    # single forward slash
    assert ShellModule().path_has_trailing_slash('C:/')

# Generated at 2022-06-23 12:48:25.901457
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module = ShellModule()

    input_basefile = 'test_basefile'
    expected_output_script = "New-Item -Type Directory -Path C:\\tmp -Name 'test_basefile'"

    output_script = shell_module.mkdtemp('test_basefile', tmpdir='C:\\tmp')
    assert output_script == expected_output_script


# Generated at 2022-06-23 12:48:28.040849
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    # type: () -> None
    ''' ShellModule.env_prefix() '''
    module = ShellModule()
    assert module.env_prefix() == ''



# Generated at 2022-06-23 12:48:36.308691
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shebang = '#!powershell'
    env_string = '$env:ANSIBLE_MODULE_ARGS="";'
    ps_script = '''
    $arg_path = $env:ANSIBLE_MODULE_ARGS
    Write-Output $arg_path
    '''
    arg_path = '"{`"ANSIBLE_MODULE_ARGS`":`"arg_path`"}"'
    cmd = 'Write-Host "hello"'
    module_cmd = 'powershell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted '
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    bootstrap_wrapper = to_text(bootstrap_wrapper, 'utf-8')

    # Test without shebang
    sm = Shell

# Generated at 2022-06-23 12:48:47.796092
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    from ansible.executor.powershell.module_common import EscapeStatementParser
    from ansible.parsing import unescape_path
    from ansible.module_utils.six import string_types

    powershell = ShellModule(connection=None)

    def run(fn, expected):
        c = powershell.checksum(fn)
        c = re.match(r'.*\r?\n(.*)\r?\nExit.*', c.strip('\r\n'), re.DOTALL)
        assert isinstance(c, string_types)
        c = c.group(1)
        assert isinstance(c, string_types)
        c = c.strip('\r\n')

        escaped_fn = EscapeStatementParser.escape_path(unescape_path(fn.replace('\\', '\\\\')))
       

# Generated at 2022-06-23 12:48:50.709370
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    obj = ShellModule()

    expected = "\n        Write-Output \"unsupported\" \n        Exit 1 \n        "
    assert obj.chown("path", "user") == expected


# Generated at 2022-06-23 12:48:55.938220
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    mod = ShellModule()
    mod.SHELL_FAMILY = 'powershell'
    import os
    path = "%s\\.ansible" % os.environ['USERPROFILE']
    # Test if the path is equal to the variable path.
    if mod.mkdtemp().strip() == "New-Item -Type Directory -Path '%s' -Name 'tmp'" % path:
        print('Test passed')

# Generated at 2022-06-23 12:48:57.651756
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    mod_obj = ShellModule()
    assert mod_obj.checksum('test') == ''

# Generated at 2022-06-23 12:49:02.039452
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():

    test_shell = ShellModule()

    error = None

    try:
        test_shell.chown(None, None)
    except NotImplementedError as e:
        error = str(e)

    assert error is not None and error == 'chown is not implemented for Powershell'


# Generated at 2022-06-23 12:49:04.749001
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    p = ShellModule()
    assert p.chown(paths='', user='') == ''


# Generated at 2022-06-23 12:49:07.953729
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert not sm.COMPATIBLE_SHELLS



# Generated at 2022-06-23 12:49:16.477305
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    cmd = shell.mkdtemp(basefile='ansible-tmp-', tmpdir="'%TEMP%'")

# Generated at 2022-06-23 12:49:28.475488
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shmod = ShellModule()
    # Simple example
    assert shmod.expand_user("~") == "Expand-Archive -LiteralPath \"Directory.zip\""
    assert shmod.expand_user("~/test.txt") == "Expand-Archive -LiteralPath \"Directory.zip\""
    # Nested example
    assert shmod.expand_user("~/test/test.txt") == "Expand-Archive -LiteralPath \"Directory.zip\""
    assert shmod.expand_user("~/foo bar/test/test.txt") == "Expand-Archive -LiteralPath \"Directory.zip\""
    # Unsupported
    assert shmod.expand_user("~root") == "Expand-Archive -LiteralPath \"Directory.zip\""


# Generated at 2022-06-23 12:49:30.278241
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule()
    assert shell.env_prefix() == ""

# Generated at 2022-06-23 12:49:32.613872
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    sut = ShellModule()
    sut.get_remote_filename('file without extension')
    sut.get_remote_filename('/path/file without extension')



# Generated at 2022-06-23 12:49:44.371064
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    powershell = ShellModule(None)
    assert powershell.exists(u"C:\\Windows\\Temp") == 'If (Test-Path "C:\\\\Windows\\\\Temp")\n            {\n                $res = 0;\n            }\n            Else\n            {\n                $res = 1;\n            }\n            Write-Output "$res";\n            Exit $res;\n         '
    assert powershell.exists(u"C:\\Users\\testuser\\Temp") == 'If (Test-Path "C:\\\\Users\\\\testuser\\\\Temp")\n            {\n                $res = 0;\n            }\n            Else\n            {\n                $res = 1;\n            }\n            Write-Output "$res";\n            Exit $res;\n         '


# Generated at 2022-06-23 12:49:49.364322
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    import tempfile
    handle, path = tempfile.mkstemp()

    try:
        shell = ShellModule(connection='winrm', no_log=True)
        cmd = shell.env_prefix(ENV_BAR='123')
        assert cmd == ''

    finally:
        os.unlink(path)

# Generated at 2022-06-23 12:50:00.915367
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    """
    Test the expand_user method of class ShellModule
    """
    # Test scenario when OS is Windows
    win_shell = ShellModule()
    # Testing path without username
    assert win_shell.expand_user('~') == b"Write-Output (Get-Location).Path"
    # Testing path with username
    assert win_shell.expand_user('~username') == b"Write-Output '~username'"
    # Testing path with username with special character
    assert win_shell.expand_user('~username@') == b"Write-Output '~username@'"
    # Testing path with username with special character and slash
    assert win_shell.expand_user('~username@/') == b"Write-Output '~username@/'"
    # Testing path with username with special character, slash and some path string
    assert win

# Generated at 2022-06-23 12:50:02.281724
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with valid options
    shell = ShellModule(connection=None, shell_type='powershell', no_log=False)
    assert shell._shell_type == 'powershell'

# Generated at 2022-06-23 12:50:04.663889
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    obj = ShellModule()
    assert obj.chmod("/test", "777") == "chmod 777 /test"


# Generated at 2022-06-23 12:50:13.294318
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import ansible_powershell.shell

    for user_home_path, expected_result in [
            ('~', '(Get-Location).Path'),
            ('~\\folder_name', "((Get-Location).Path + '\\folder_name')"),
            ('~/folder_name', "((Get-Location).Path + '/folder_name')"),
            ('c:\\temp\\folder_name', "c:\\temp\\folder_name"),
            ('d:/temp/folder_name', "d:\\temp\\folder_name")
    ]:
        result = ansible_powershell.shell.ShellModule.expand_user(user_home_path)
        assert result == expected_result, "Result of expand_user is wrong!"

# Generated at 2022-06-23 12:50:20.670919
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS

    assert shell.env_prefix() == ''
    assert shell.join_path('foo', 'bar') == 'foo\\bar'
    assert shell.join_path('foo', 'bar', 'baz') == 'foo\\bar\\baz'
    assert shell.join_path('foo\\', 'bar', 'baz') == 'foo\\bar\\baz'
    assert shell.join_path('foo\\', 'bar\\', 'baz') == 'foo\\bar\\baz'
    assert shell.join_path('foo\\bar', 'baz') == 'foo\\bar\\baz'

# Generated at 2022-06-23 12:50:30.173190
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell_plugin = ShellModule()

    # Test for a normal path
    expected = 'c:\\Program Files\\Test'
    actual = shell_plugin.join_path('c:\\Program Files', 'Test')

    assert(expected == actual)

    # Test for a path with extra slashes
    expected = 'c:\\Program Files\\Test'
    actual = shell_plugin.join_path('c:\\\\\\Program Files\\\\\\', 'Test')

    assert(expected == actual)

    # Test for a path with extra slashes and a leading space
    expected = 'c:\\Program Files\\Test'
    actual = shell_plugin.join_path(' c:\\\\\\Program Files\\\\\\ ', 'Test')

    assert(expected == actual)

    # Test for a path with a trailing slash
    expected = 'c:\\Program Files\\Test'


# Generated at 2022-06-23 12:50:42.141670
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    command_linux = "shasum -a 1 ${file} | awk '{print $1}'"
    command_windows = "Get-FileHash ${file} | Select-Object -ExpandProperty Hash | ForEach-Object {$_ -join ''}"
    check_sum = ShellModule(connection=None).checksum('C:\\Temp\\test.log')
    cmd_parts = shlex.split(check_sum, posix=False)
    assert cmd_parts[0] == 'PowerShell'
    assert cmd_parts[1] == '-NoProfile'
    assert cmd_parts[2] == '-NonInteractive'
    assert cmd_parts[3] == '-ExecutionPolicy'
    assert cmd_parts[4] == 'Unrestricted'
    assert cmd_parts[5] == '-EncodedCommand'

# Generated at 2022-06-23 12:50:51.942613
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import os
    import tempfile

    # Create a temporary directory that will be used for testing the expand_user
    # method of the ShellModule class.
    tmpdir = to_text(tempfile.mkdtemp())
    user_home_path = os.path.join(tmpdir, to_text(os.getenv('USERNAME', 'Unknown')))
    os.makedirs(user_home_path)
    os.chdir(user_home_path)

    # Get the current drive.
    user_home_drive = os.getcwd()[0:2]

    # Create a temporary file inside the temporary directory.
    with tempfile.NamedTemporaryFile(dir=tmpdir, delete=False) as tmp_file:
        tmp_file.write(to_bytes('Hello World'))
        tmp_file_name

# Generated at 2022-06-23 12:50:53.656605
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell_module = ShellModule()
    shell_module.chown("share", "user")


# Generated at 2022-06-23 12:50:59.852096
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert hasattr(shell, 'COMPATIBLE_SHELLS')
    assert hasattr(shell, 'SHELL_FAMILY')
    assert hasattr(shell, '_IS_WINDOWS')
    assert hasattr(shell, '_SHELL_REDIRECT_ALLNULL')
    assert hasattr(shell, '_SHELL_AND')

# Generated at 2022-06-23 12:51:07.894153
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import PY2, PY3

    # No code to test for Python3.
    if PY3:
        return
    # Params needed for the constructor
    connection_info = dict(ipv4=dict(address='192.168.0.2'))
    agnostic_shell_obj = ShellModule(connection_info)

    # Params needed for the method
    paths = '/Users/John/src/ansible/explore'
    mode = '0755'

    try:
        agnostic_shell_obj.chmod(paths, mode)
    except NotImplementedError:
        pass



# Generated at 2022-06-23 12:51:13.318324
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_text
    shell = ShellModule(Mapping())
    cmd = to_text("echo this is a test")
    result = shell.build_module_command("", "", cmd)
    assert result is not None, "Command was not wrapped"
    assert result.startswith("&"), "Command was not wrapped in ampersands"
    assert result.endswith("; exit $LASTEXITCODE"), "Command was not wrapped in ampersands"

# Generated at 2022-06-23 12:51:22.685340
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    powershell = ShellModule()
