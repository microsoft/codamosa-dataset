

# Generated at 2022-06-23 12:41:27.578245
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    from ansible.executor.powershell.shell import ShellModule
    sm = ShellModule()

# Generated at 2022-06-23 12:41:39.013004
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    obj = ShellModule()
    user_home_path = '~'
    assert obj.expand_user(user_home_path).strip() == r"Write-Output (Get-Location).Path"
    user_home_path = '~\Desktop'
    assert obj.expand_user(user_home_path).strip() == r"Write-Output ((Get-Location).Path + '\\Desktop')"
    user_home_path = '~john\Desktop'
    assert obj.expand_user(user_home_path).strip() == r"Write-Output '~john\\Desktop'"
    user_home_path = '~tariq\Desktop'
    assert obj.expand_user(user_home_path).strip() == r"Write-Output '~tariq\\Desktop'"

# Generated at 2022-06-23 12:41:48.997834
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    powershell = ShellModule()

    shebang = "#!powershell"
    cmd = "Get-Process"

    result = powershell.build_module_command("", shebang, cmd)
    assert result.startswith("type")

# Generated at 2022-06-23 12:41:50.698538
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    module = ShellModule()
    assert module.env_prefix() == ''


# Generated at 2022-06-23 12:42:00.296126
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule(connection=None, play_context=None, shell_type='powershell', become_method='runas')
    arg1 = 'Write-Host -Object "hello"'
    arg2 = 'Write-Output -InputObject "hello"'
    arg3 = '& Write-Host -Object "hello"; exit $LASTEXITCODE'

    assert shell.wrap_for_exec(arg1) == arg3
    assert shell.wrap_for_exec(arg2) == arg3
    assert shell.wrap_for_exec(arg3) == arg3



# Generated at 2022-06-23 12:42:07.130539
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    p = ShellModule(connection=None, host=None)
    assert(p._unquote(r"\\") == "\\\\")
    assert(p._unquote(r"\\\\") == "\\\\")

# Generated at 2022-06-23 12:42:12.262025
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    shell = ShellModule()
    module_path = "C:\\some\\path\\some_module.ps1"
    checksum = shell.checksum(path=module_path)
    assert (checksum.startswith("IF "))
    assert ("PathType Leaf" in checksum)
    assert ("Write-Output 1" in checksum)



# Generated at 2022-06-23 12:42:21.723943
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    script = '''
        $acl = Get-Acl "$path"
        $ace = $acl.Access | Where-Object {$_.IdentityReference -eq "$user"}
        if ($ace) { $acl.RemoveAccessRule($ace)}
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule($user,$permission,$inheritanceflag,"$propagationflag","$accesstype")
        $acl.AddAccessRule($rule)
        Set-Acl "$path" $acl
        '''
    path = "test"
    user = "user"
    permission = "permission"
    inheritanceflag = "inheritanceflag"
    propagationflag = "propagationflag"
    accesstype = "accesstype"

# Generated at 2022-06-23 12:42:25.225163
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    obj = ShellModule()

    # Testing return value on an empty string
    res = obj.env_prefix()
    assert res == "", "Unexpected return value '%s'" % res


# Generated at 2022-06-23 12:42:27.689896
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule()
    
    # From test_chown in test_file.py
    assert 'chown is not implemented for Powershell' in shell.chown('test_path', user='test_user')

# Generated at 2022-06-23 12:42:29.402438
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    assert ShellModule(conn=None).wrap_for_exec(cmd='#test') == '& #test; exit $LASTEXITCODE'


# Generated at 2022-06-23 12:42:32.479234
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    sh = ShellModule()
    result = sh.chmod('', '')
    assert type(result) == NotImplementedError and result.args[0] == 'chmod is not implemented for Powershell'


# Generated at 2022-06-23 12:42:43.003025
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    """Unit test for method checksum of class ShellModule
    """
    try:
        from __main__ import display
    except ImportError:
        # Python 3.5
        from .display import Display
        display = Display()

    display.display("Running unit test for method checksum of class ShellModule from powershell")

    shell = ShellModule()

    path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    path += "/lib/ansible/module_utils/powershell/common.psm1"

    checksum = shell.checksum(path)

    encoding = shell.get_option('remote_temp_encoding')
    script_bytes = subprocess.check_output([checksum], shell=True)
    script_text = script_bytes

# Generated at 2022-06-23 12:42:52.618230
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    obj = ShellModule()
    res = obj.mkdtemp()
    assert res == b'IF($null -eq $using:basetmpdir){\n    $tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'%TEMP%\')\n}ELSE{\n    $tmp_path = [System.Environment]::ExpandEnvironmentVariables($using:basetmpdir)\n}\n$tmp = New-Item -Type Directory -Path $tmp_path -Name \'tmpcak9XJn\'\nWrite-Output -InputObject $tmp.FullName\n'



# Generated at 2022-06-23 12:42:58.099897
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    sh = ShellModule()
    assert sh.wrap_for_exec("echo hello") == "& echo hello; exit $LASTEXITCODE"
    assert sh.wrap_for_exec("echo hello; echo world") == "& echo hello; echo world; exit $LASTEXITCODE"
    assert sh.wrap_for_exec("echo hello & echo world") == "& echo hello & echo world; exit $LASTEXITCODE"
    assert sh.wrap_for_exec("echo hello & echo world; echo last") == "& echo hello & echo world; echo last; exit $LASTEXITCODE"

    # We have to ensure that the semicolons are only added once

# Generated at 2022-06-23 12:43:00.066375
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell_module = ShellModule()
    shell_module.set_user_facl('/tmp', 'root', '0755')

# Generated at 2022-06-23 12:43:11.676598
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()

    assert shell.join_path('C:\\', 'Windows') == 'C:\\Windows'
    assert shell.join_path('C:\\', 'Windows\\') == 'C:\\Windows'
    assert shell.join_path('C:\\', 'Windows\\', '\\Programs') == 'C:\\Windows\\Programs'
    assert shell.join_path('C:\\', '\\Windows') == 'C:\\Windows'
    assert shell.join_path('C:\\', '\\Windows\\') == 'C:\\Windows'

    assert shell.join_path('\\', 'Windows') == '\\Windows'
    assert shell.join_path('\\', 'Windows\\') == '\\Windows'

# Generated at 2022-06-23 12:43:23.480825
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule(None)

    assert shell.join_path("a", "b") == ntpath.join("a", "b")
    assert shell.join_path("a\\", "b") == ntpath.join("a", "b")
    assert shell.join_path("a", "\\b") == ntpath.join("a", "b")
    assert shell.join_path("a\\", "\\b") == ntpath.join("a", "b")
    assert shell.join_path("a/", "b") == ntpath.join("a", "b")
    assert shell.join_path("a", "/b") == ntpath.join("a", "b")
    assert shell.join_path("a/", "/b") == ntpath.join("a", "b")

#

# Generated at 2022-06-23 12:43:24.567472
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    assert ShellModule().env_prefix() == ''


# Generated at 2022-06-23 12:43:31.668699
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import StringIO
    from ansible.plugins.shell.powershell import ShellModule

    # Given
    sm = ShellModule()
    # When (recurse=False)
    remove_result = sm.remove(path="C:\\Temp", recurse=False)
    # Then
    result = to_text(remove_result)
    assert b'Remove-Item "C:\\Temp" -Force;' == remove_result

    # When (recurse=True)
    remove_result = sm.remove(path="C:\\Temp", recurse=True)
    # Then
    result = to_text(remove_result)
    assert b'Remove-Item "C:\\Temp" -Force -Recurse;' == remove

# Generated at 2022-06-23 12:43:36.148073
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell_module = ShellModule()
    with pytest.raises(NotImplementedError) as exc:
        shell_module.chown(paths="", user="")
    assert exc.value.args[0] == 'chown is not implemented for Powershell'


# Generated at 2022-06-23 12:43:45.540998
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    s = ShellModule()
    testvals = {'foo.sh': 'foo.ps1',
                'foo.py': 'foo.ps1',
                'foo.rb': 'foo.ps1',
                'foo.ps1': 'foo.ps1',
                'foo.bat': 'foo.bat',
                'foo.exe': 'foo.exe',
                'foo': 'foo.ps1',
                'foo.rb.rb': 'foo.rb.ps1'}

    for test in testvals:
        assert testvals[test] == s.get_remote_filename(test)


# Generated at 2022-06-23 12:43:55.562201
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # "EncodedCommand" is a member of the common_args.  We're testing
    # the constructor to make sure we have the same result
    encoded_script = base64.b64encode(b'echo -n test')
    encoded_script_string = "EncodedCommand " + str(encoded_script, 'utf-8')
    temp_shell_module = ShellModule()
    script_string = temp_shell_module._encode_script('echo -n test', preserve_rc=True)

    if encoded_script_string in script_string:
        assert True
    else:
        assert False

# Generated at 2022-06-23 12:44:03.968763
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # Create an instance of ShellModule
    shell_module = ShellModule()

    # Testing get_remote_filename of class ShellModule
    remote_filename = shell_module.get_remote_filename(to_bytes('test.ps1'))
    assert remote_filename == u'test.ps1'
    remote_filename = shell_module.get_remote_filename(to_bytes('test_script.sh'))
    assert remote_filename == u'test_script.ps1'
    remote_filename = shell_module.get_remote_filename(to_bytes('test'))
    assert remote_filename == u'test.ps1'
    remote_filename = shell_module.get_remote_filename(to_bytes('/path/to/test.ps1'))
    assert remote_filename == u'test.ps1'
    remote_

# Generated at 2022-06-23 12:44:06.859191
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    resp = ShellModule(connection=None).wrap_for_exec("'echo 'hello world'")

    assert resp == "& 'echo 'hello world'' ; exit $LASTEXITCODE"


# Generated at 2022-06-23 12:44:17.829685
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module = ShellModule()
    assert shell_module.expand_user("~/test") == 'Write-Output ((Get-Location).Path + "\\test")'
    assert shell_module.expand_user("~\\test") == 'Write-Output ((Get-Location).Path + "\\test")'
    assert shell_module.expand_user("~/test/") == 'Write-Output ((Get-Location).Path + "\\test\\")'
    assert shell_module.expand_user("~\\test\\") == 'Write-Output ((Get-Location).Path + "\\test\\")'
    assert shell_module.expand_user("~") == 'Write-Output (Get-Location).Path'

# Generated at 2022-06-23 12:44:30.961298
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    res = shell.expand_user("", "")
    assert res == shell._encode_script("''", preserve_rc=False)

    raw_res = shell._execute_remote_cmd(res)
    assert raw_res.decode("utf-8") == "$HOME"

    res = shell.expand_user("~", "Username")
    assert res == shell._encode_script('''
        Write-Output (Get-Location).Path
    ''', preserve_rc=False)

    raw_res = shell._execute_remote_cmd(res)
    assert raw_res.decode("utf-8") == "$HOME"

    res = shell.expand_user("~/Desktop","Username")

# Generated at 2022-06-23 12:44:42.053907
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    import os
    import re
    import unittest

    sh = ShellModule()

    path1 = 'c:\\windows'
    path2 = 'system32\\Temp'
    path3 = 'c:\\users\\Admin1'
    path4 = 'c:\\users\\temp'
    path5 = '\\\\remote_host\\share'
    path6 = '.'

    paths = [path1, path2, path3, path4, path5, path6]

    for path in paths:
        for path2 in paths:
            new_path = sh.join_path(path, path2)


# Generated at 2022-06-23 12:44:52.062758
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import sys
    if sys.version_info < (3,):
        def b(v):
            return v
    else:
        def b(v):
            return v.encode('utf-8')


# Generated at 2022-06-23 12:44:55.036273
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    module = ShellModule()
    value = module.chown('path', 'user')
    assert value is NotImplemented
# end of test_ShellModule_chown


# Generated at 2022-06-23 12:45:07.244376
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    # testing for pathtype file
    test1_obj = ShellModule()

# Generated at 2022-06-23 12:45:16.392809
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    instance = ShellModule(None)
    # with rootslash and tilde
    user_home_path = "~\\test"
    expected = "Write-Output ((Get-Location).Path + '\\test')"
    result = instance.expand_user(user_home_path, username='')
    assert expected == result
    # with tilde and no rootslash
    user_home_path = "~test"
    expected = "Write-Output '~test'"
    result = instance.expand_user(user_home_path, username='')
    assert expected == result
    # with no tilde
    user_home_path = "test"
    expected = "Write-Output 'test'"
    result = instance.expand_user(user_home_path, username='')
    assert expected == result


# Generated at 2022-06-23 12:45:23.867547
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    assert ShellModule().expand_user('/tmp') == 'Write-Output \'/tmp\''
    assert ShellModule().expand_user('~') == 'Write-Output (Get-Location).Path'
    assert ShellModule().expand_user('~/foo') == "Write-Output ((Get-Location).Path + '\\foo')"
    assert ShellModule().expand_user('~foo/foo') == "Write-Output '~foo/foo'"
    assert ShellModule().expand_user('~foo') == "Write-Output '~foo'"

# Generated at 2022-06-23 12:45:27.402254
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    shell = ShellModule()
    result = shell.chmod('/tmp/test', 0o755)
    assert result == "ERROR! chmod is not implemented for Powershell"

# Generated at 2022-06-23 12:45:38.434327
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    # Test the exists function with a relative path
    plugin_instance = ShellModule(connection=object())
    script = plugin_instance.exists('test_ansible')
    assert script == "$res = 1;\nWrite-Output '$res';\nExit $res;\n"

    # Test the exists function with an absolute path
    script = plugin_instance.exists('$env:TEMP\\test_ansible')
    assert script == "$res = 1;\nWrite-Output '$res';\nExit $res;\n"

    # Test the exists function with a quoted path
    script = plugin_instance.exists('"$env:TEMP\\test_ansible"')
    assert script == "$res = 1;\nWrite-Output '$res';\nExit $res;\n"

# Test class exists exists


# Generated at 2022-06-23 12:45:49.573158
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import tempfile
    import shutil
    tmpdir = os.path.realpath(tempfile.mkdtemp())
    tmpdirchild = os.path.join(tmpdir, "child")
    os.mkdir(tmpdirchild)
    basefile = "ansible_test_file"
    try:
        from ansible.plugins.shell import ShellModule
        ansibleshell = ShellModule()
        ret = ansibleshell.mkdtemp(basefile=basefile, tmpdir=tmpdir)
        assert '$a' not in ret
        assert '$1' not in ret
        assert basefile in ret
        assert tmpdir in ret
        assert tmpdirchild not in ret
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-23 12:45:53.199787
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    module = ShellModule(connection=None)
    paths = '/tmp/a'
    user = 'user'
    mode = '777'

    try:
        module.set_user_facl(paths, user, mode)
    except NotImplementedError:
        pass

# Generated at 2022-06-23 12:46:03.338953
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    sm = ShellModule()

    test_cases = [
        (None, True, 'fooabcdefg'),
        ('abcdef', True, 'abcdef'),
    ]

    for test_case in test_cases:
        basefile = test_case[0]
        system = test_case[1]
        expected = test_case[2]

        assert sm.mkdtemp(basefile, system) == sm.mkdtemp(basefile, system), "Test failed with basefile: %s" % basefile
        assert sm.mkdtemp(basefile, system).startswith("New-Item"), "Test failed with basefile: %s" % basefile
        assert sm.mkdtemp(basefile, system).endswith(expected), "Test failed with basefile: %s" % basefile

# Generated at 2022-06-23 12:46:14.840824
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import json
    import tempfile
    s = ShellModule()
    f = tempfile.NamedTemporaryFile()
    name = f.name
    f.close()
    script = s.expand_user('~/test.ps1')
    os.environ['ANSIBLE_REMOTE_TMP'] = os.path.dirname(name)
    out = s._run(script)
    assert json.loads(to_text(out)) == os.path.abspath('~/test.ps1'), 'invalid path'
    script = s.expand_user('~\\test.ps1')
    out = s._run(script)
    assert json.loads(to_text(out)) == os.path.abspath('~/test.ps1'), 'invalid path'
    script = s.expand

# Generated at 2022-06-23 12:46:22.680301
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    sh = ShellModule()

# Generated at 2022-06-23 12:46:34.778972
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    s = ShellModule()
    cwd = os.getcwd()

# Generated at 2022-06-23 12:46:47.362229
# Unit test for method exists of class ShellModule

# Generated at 2022-06-23 12:46:55.298785
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    module = ShellModule()
    assert module.wrap_for_exec(None) == ''
    assert module.wrap_for_exec('') == '&  ; exit $LASTEXITCODE'
    assert module.wrap_for_exec(u'ls') == u'& ls ; exit $LASTEXITCODE'
    assert module.wrap_for_exec('ls') == '& ls ; exit $LASTEXITCODE'
    assert module.wrap_for_exec(u'&') == u'& & ; exit $LASTEXITCODE'
    assert module.wrap_for_exec(u'& &') == u'& & ; exit $LASTEXITCODE'
    assert module.wrap_for_exec(u'& & ') == u'& &  ; exit $LASTEXITCODE'

# Generated at 2022-06-23 12:46:58.844655
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    testmod = ShellModule(connection=None, shell_plugin=None, shell_executable=None)
    assert testmod.chown('test') == 'Not implemented'


# Generated at 2022-06-23 12:47:05.729412
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test with normal file name
    fixture1 = 'c:/test/test.txt'
    obj1 = ShellModule()
    result1 = obj1.get_remote_filename(fixture1)
    assert result1 == 'test.txt'

    # Test with file name ending with .ps1
    fixture2 = 'c:/test/test.ps1'
    obj2 = ShellModule()
    result2 = obj2.get_remote_filename(fixture2)
    assert result2 == 'test.ps1'


# Generated at 2022-06-23 12:47:06.291278
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    assert False

# Generated at 2022-06-23 12:47:18.108599
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    from ansible.executor.powershell.shell import ShellModule

    shell_module = ShellModule()
    script = """
        If (Test-Path 'C:\Windows\System32\notepad.exe')
        {
            Write-Output '0';
        }
        Else
        {
            Write-Output '1';
        }
    """
    # For the sake of test, set the results of the script
    script_results = '0'

    # We encode the script into base64
    # decode in order to avoid encoding problems
    encoded_script = str(shell_module._encode_script(script=script))
    decoded_script = base64.b64decode(encoded_script).decode("utf-8")
    # We remove the arguments of the powershell command
    # and we keep only the script
    #

# Generated at 2022-06-23 12:47:21.110499
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    module = ShellModule(connection=None)
    assert module.chown("/path/to/something", "user") is None


# Generated at 2022-06-23 12:47:30.647422
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    '''
    Unit tests for module_utils.shell.ShellModule.checksum
    '''
    import ansible.module_utils.powershell

    shell = ansible.module_utils.powershell.ShellModule()
    assert shell.checksum('C:\\Windows\\System32\\ntdll.dll', checksum='sha1') == "30f9203d6491d0321b3a3ea77d78eec2aacb5d78"
    assert shell.checksum('C:\\Windows\\System32\\ntdll.dll', checksum='sha224') == "e3b3a3e9a946c7d2fd4e4c8dcb4d285f4b4caea0b47798c824f61009"

# Generated at 2022-06-23 12:47:34.554620
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    s = ShellModule()
    assert s.set_user_facl(paths='', user='', mode='') == 'NotImplementedError: set_user_facl is not implemented for Powershell'

# Generated at 2022-06-23 12:47:38.315726
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    conn = ShellModule('', '')
    actual = conn.env_prefix(timeout=5)
    assert actual == ""
    actual = conn.env_prefix(timeout=5, test="test", test_other=5)
    assert actual == ""


# Generated at 2022-06-23 12:47:42.771922
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('testfile.ps1') == 'testfile.ps1', \
        "testfile.ps1 should be returned as is"
    assert shell.get_remote_filename('test') == 'test.ps1', \
        "test should be returned as test.ps1"
    assert shell.get_remote_filename('test.exe') == 'test.exe', \
        "test.exe should be returned as is"

# Generated at 2022-06-23 12:47:45.187874
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    mock_self = type('MockClass', (object,), {})
    assert ShellModule.env_prefix(mock_self) == ''

# Generated at 2022-06-23 12:47:52.348175
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    tests = [
        # ( shebang, cmd, arg_path )
        # cmd includes the arg_path if it is not None
        (None, 'foo bar', None),
        ('#!/usr/bin/python', 'foo bar', None),
        ('#!/usr/bin/python', 'foo bar', 'baz.py'),
        ('#!powershell', 'foo.ps1', 'bar'),
    ]

    sm = ShellModule(connection=None)

    # The script should not include the interpreter or the arg_path if it exists
    # So the expected cmd parts are the same regardless of the interpreter

# Generated at 2022-06-23 12:48:02.109916
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    temp_dir = ShellModule().mkdtemp()

    # Test with recurse=False
    cmd = ShellModule().remove(base64.b64encode('[io.path]::Combine("{0}", "test.file")'.format(temp_dir).encode()).decode(), recurse=False)

# Generated at 2022-06-23 12:48:04.551294
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    module = ShellModule()
    import pytest
    with pytest.raises(NotImplementedError):
        module.chown('', '')



# Generated at 2022-06-23 12:48:10.888068
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell_module = ShellModule()
    assert shell_module.remove("'C:\\Test'") == b'Remove-Item \'C:\\Test\' -Force;'
    assert shell_module.remove("'C:\\Test'", recurse=True) == b'Remove-Item \'C:\\Test\' -Force -Recurse;'


# Generated at 2022-06-23 12:48:18.098070
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule(None, None)
    result = shell.path_has_trailing_slash('\\foo\\bar\\baz\\')
    assert result == True
    result = shell.path_has_trailing_slash('\\foo\\bar/baz')
    assert result == False
    result = shell.path_has_trailing_slash('\\foo/bar/baz\\')
    assert result == True
    result = shell.path_has_trailing_slash('\\foo/bar\\baz')
    assert result == False



# Generated at 2022-06-23 12:48:25.744324
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert not shell.path_has_trailing_slash('')
    assert not shell.path_has_trailing_slash('')
    assert not shell.path_has_trailing_slash('c:\\windows')
    assert shell.path_has_trailing_slash('c:\\windows\\')

# Generated at 2022-06-23 12:48:27.158282
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    windows_shell = ShellModule()
    assert windows_shell.env_prefix() == ""


# Generated at 2022-06-23 12:48:29.476224
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule()
    assert shell.chown(paths='paths', user='user') == NotImplementedError('chown is not implemented for Powershell')


# Generated at 2022-06-23 12:48:39.808672
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock

    class TestShellModule(unittest.TestCase):

        def setUp(self):
            self.module = AnsibleModule(
                argument_spec=dict()
            )
            setattr(self.module, '_ansible_debug', True)

            self.module_patcher = patch.multiple(basic.AnsibleModule, exit_json=Mock(return_value=None), fail_json=Mock(return_value=None))
            self.module_patcher.start()


# Generated at 2022-06-23 12:48:44.921800
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    from ansible.plugins.connection import network_cli

    shell = ShellModule(connection=network_cli.NetworkCli(play_context=dict(become=True, become_method='sudo', become_user='root')))
    name = shell.mkdtemp()
    print(name)
    assert name == '/tmp/ansible_ShellModule_'

# Generated at 2022-06-23 12:48:48.350738
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell_module = ShellModule()
    paths = ['test']
    user = 'test'
    try:
        shell_module.chown(paths, user)
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-23 12:48:58.558781
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():

    from ansible.modules.extras.windows.win_command import ShellModule

    # Initialize object
    sm = ShellModule()
    # Remove file

# Generated at 2022-06-23 12:49:11.002356
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Test with unquoted Windows paths
    path = r'C:\ansible\test\path'
    assert False == ShellModule().path_has_trailing_slash(path)
    path = r'C:\ansible\test\path\\'
    assert True == ShellModule().path_has_trailing_slash(path)
    path = r'C:\ansible\test\path/'
    assert True == ShellModule().path_has_trailing_slash(path)

    # Test with quoted paths
    path = r'"C:\ansible\test\path"'
    assert False == ShellModule().path_has_trailing_slash(path)
    path = r'"C:\ansible\test\path\\"'
    assert True == ShellModule().path_has_trailing_slash(path)
    path = r

# Generated at 2022-06-23 12:49:23.894402
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    from ansible.module_utils.six.moves import StringIO
    from ansible.playbook import play_context
    from ansible.executor.powershell import ShellModule
    from ansible.executor.task_executor import TaskExecutor

    ctx = play_context.PlayContext()
    shellmodule = ShellModule(TaskExecutor(None, ctx), dict(tmpdir='/tmp/'))

    # Testing checksum method of class ShellModule
    # testing directory checksum
    command = shellmodule.checksum('/tmp/')
    assert command.encode('utf-8') == shellmodule.wrap_for_exec(u"Write-Output \"3\"").encode('utf-8')
    # testing existing file checksum
    command = shellmodule.checksum('/tmp/fixture.txt')

# Generated at 2022-06-23 12:49:31.549839
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    # Constructor
    shell = ShellModule()

    # Test method
    assert shell.exists('C:\\TestFile.txt') == "If (Test-Path 'C:\\TestFile.txt')\r\n            {\r\n                $res = 0;\r\n            }\r\n            Else\r\n            {\r\n                $res = 1;\r\n            }\r\n            Write-Output '$res';\r\n            Exit $res;\r\n         "


# Generated at 2022-06-23 12:49:36.253013
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, play_context=None)
    assert shell
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS

# Generated at 2022-06-23 12:49:39.600701
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    assert shell.build_module_command(env_string='', shebang='#!powershell', cmd='foo') == 'type "foo.ps1" | & ansible_powershell_invoke.exe -stdin; exit $LASTEXITCODE'


# Generated at 2022-06-23 12:49:50.020614
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    from ansible.module_utils.shell.powershell import ShellModule
    shell = ShellModule()
    # Because ntpath.join treats any component that begins with a backslash as an absolute path,
    # it's necessary to strip slashes from at least the beginning of the path components
    assert shell.join_path('c:', 'windows') == shell.join_path('c:\\', 'windows') == 'c:\\windows'
    assert shell.join_path('c:', 'windows') == shell.join_path('c:\\\\\\\\\\\\', 'windows') == 'c:\\windows'
    assert shell.join_path('C:', '\\', '\\', '\\', '\\\\Windows') == shell.join_path('C:\\\\\\\\\\\\', 'windows') == 'C:\\Windows'


# Generated at 2022-06-23 12:49:53.906986
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule()
    assert "NotImplementedError('chown is not implemented for Powershell')" in shell.chown('/test/owner/file', 'test_owner')


# Generated at 2022-06-23 12:50:00.854770
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    powershell = ShellModule()
    assert powershell.join_path(r'C:\users\username') == r'C:\users\username'

# Generated at 2022-06-23 12:50:20.366865
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    from ansible.plugins.shell import ShellModule
    sm = ShellModule(connection=None)

    # path without trailing slash
    path_input = 'C:\\Temp\\T1'
    result = sm.path_has_trailing_slash(path_input)
    assert result == False

    # path with trailing slash
    path_input = 'C:\\Temp\\T1\\'
    result = sm.path_has_trailing_slash(path_input)
    assert result == True

    # path with double backslash
    path_input = 'C:\\\\Temp\\\\T1\\\\'
    result = sm.path_has_trailing_slash(path_input)
    assert result == True

    # path with mixed slash
    path_input = 'C:\\\\Temp/T1\\\\'

# Generated at 2022-06-23 12:50:24.362942
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shellmodule = ShellModule()
    try:
        shellmodule.set_user_facl('testuser', 'testpath', 'testmode')
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-23 12:50:26.411391
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell_obj = ShellModule()
    try:
        shell_obj.set_user_facl("path", "user", "mode")
    except Exception as err:
        assert str(err) == "set_user_facl is not implemented for Powershell"

# Generated at 2022-06-23 12:50:32.656621
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    cmd = ShellModule().remove('C:\\some', True)
    assert(cmd == b"Remove-Item 'C:\\some' -Force -Recurse;")
    cmd = ShellModule().remove('C:\\some\\other\\file.txt', False)
    assert(cmd == b"Remove-Item 'C:\\some\\other\\file.txt' -Force;")


# Generated at 2022-06-23 12:50:34.494185
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-23 12:50:38.283456
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell_module = ShellModule(None, None)
    assert shell_module.wrap_for_exec('asdf') == '& asdf; exit $LASTEXITCODE'



# Generated at 2022-06-23 12:50:39.705911
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    result = shell.get_remote_filename('C:/foo/bar.txt')
    assert result == 'bar.txt'

# Generated at 2022-06-23 12:50:50.851733
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    plugin = ShellModule()
    # positive test case
    # test checksum method on file

# Generated at 2022-06-23 12:51:02.296831
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    m = AnsibleModule(
        argument_spec=dict(),
    )
    s = ShellModule(m)

    # Powershell module: powershell modules (e.g. .psm1) run by the bootstrap wrapper
    #
    # A powershell module needs the bootstrap_wrapper.ps1 to be prepended to set the
    # environment correctly.
    #
    # The module is assumed to be a file, because that is what the powershell connection
    # plugin returns (see ``get_remote_filename`` method.

# Generated at 2022-06-23 12:51:14.669465
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    assert shell_module.build_module_command('', '#!powershell', '', arg_path=None) is not None
    assert shell_module.build_module_command('', '#!powershell', '', arg_path='/dev/null') is not None
    assert shell_module.build_module_command('', '#!python', '', arg_path=None) is not None
    assert shell_module.build_module_command('', '#!python', '', arg_path='/dev/null') is not None
    assert shell_module.build_module_command('', '', '', arg_path=None) is not None
    assert shell_module.build_module_command('', '', '', arg_path='/dev/null') is not None
    assert shell_module

# Generated at 2022-06-23 12:51:19.509176
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    shell_module = ShellModule()
    with pytest.raises(NotImplementedError) as exec_info:
        shell_module.chmod("", 0o777)
    assert exec_info.value.args[0] == "chmod is not implemented for Powershell"
