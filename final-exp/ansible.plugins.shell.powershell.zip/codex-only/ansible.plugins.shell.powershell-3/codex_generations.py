

# Generated at 2022-06-23 12:41:21.129203
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    # ShellModule.exists

    result = ShellModule(connection=None).exists("/tmp/")

    assert result == b'''
            If (Test-Path '/tmp/')
            {
                $res = 0;
            }
            Else
            {
                $res = 1;
            }
            Write-Output '$res';
            Exit $res;
         ''', result



# Generated at 2022-06-23 12:41:23.861784
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(conn=None, *tuple(), **dict());
    assert shell is not None

# Generated at 2022-06-23 12:41:32.637868
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    shell_module = ShellModule()

    # Test with path type as Leaf
    checksum_path_leaf = shell_module.checksum('"C:/Users/Administrator/Documents/Ansible/temp"')

# Generated at 2022-06-23 12:41:36.282074
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule()
    cmd = shell._encode_script("Write-Output 'hello world';")
    assert shell.wrap_for_exec(cmd) == "& " + cmd + " exit $LASTEXITCODE"

# Generated at 2022-06-23 12:41:47.353043
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # mock_type_check.patch for type checking
    mock_type_check = mock.patch('ansible.plugins.shell.windows.type_check')
    mock_type_check.start()

    # mock_get_option.patch for get_option method
    mock_get_option = mock.patch('ansible.plugins.shell.windows.ShellModule.get_option')
    mock_get_option.start()

    # mock_shebang_for_bin.patch for shebang_for_bin method
    mock_shebang_for_bin = mock.patch('ansible.plugins.shell.windows.ShellModule.shebang_for_bin')
    mock_shebang_for_bin.start()

    module = ShellModule(connection=mock.MagicMock())

    module.no_log_values.return_value = False

# Generated at 2022-06-23 12:41:49.834600
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    assert ShellModule(connection=None).wrap_for_exec('"foo"') == '& "foo"; exit $LASTEXITCODE'

# Generated at 2022-06-23 12:41:59.568083
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    module = ShellModule()

    # Test case for imput is a simple file
    path = r'C:\Users\Administrator'
    script = module.exists(path)
    expected_output = module._encode_script('''
        If (Test-Path 'C:\\Users\\Administrator')
        {
            $res = 0;
        }
        Else
        {
            $res = 1;
        }
        Write-Output '$res';
        Exit $res;
     ''')
    assert script == expected_output


# Generated at 2022-06-23 12:42:04.558113
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    filename = shell.get_remote_filename('/path/to/file.ps1')
    assert filename == 'file.ps1'

    filename = shell.get_remote_filename('/path/to/file.cmd')
    assert filename == 'file.cmd.ps1'

    filename = shell.get_remote_filename('/path/to/file')
    assert filename == 'file.ps1'



# Generated at 2022-06-23 12:42:08.013529
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    test_obj = ShellModule()
    assert test_obj.chown('/home/user/testing', 'testuser') is not None

# Generated at 2022-06-23 12:42:19.688847
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    sm = ShellModule()

    # Test regular modules
    assert sm.build_module_command('', '', 'ping localhost') == '& Windows\\System32\\ping.exe localhost; exit $LASTEXITCODE'
    cmd = sm.build_module_command('$env:ANSIBLE_POWERSHELL_SHELL = "pwsh"', '', 'ping localhost')

# Generated at 2022-06-23 12:42:31.711026
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    module = ShellModule()

    # Case: simple file

# Generated at 2022-06-23 12:42:42.473032
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule(connection=None, temppath="tempdir", module_compression='ZIP', always_pipeline=False,
                        no_log=False, remote_tmp='/tmp/ansible', shell_type='powershell')
    assert not shell.path_has_trailing_slash("test")
    assert shell.path_has_trailing_slash("test\\")
    assert shell.path_has_trailing_slash("test/")
    assert shell.path_has_trailing_slash("test\\\\")
    assert not shell.path_has_trailing_slash("test\\\\\\")
    assert shell.path_has_trailing_slash("test/\\")
    assert shell.path_has_trailing_slash("test\\/")
    assert not shell.path_has_tra

# Generated at 2022-06-23 12:42:44.293923
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    assert ShellModule().chmod("test.txt", "777") is None


# Generated at 2022-06-23 12:42:52.133272
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    from ansible.executor.powershell import ShellModule
    # Instance for ShellModule
    shell_module = ShellModule()
    # Test path as C:\fake_path_empty.txt
    path = 'C:\\fake_path_empty.txt'
    result = shell_module.exists(path)
    # Check and test the result
    if result:
        raise AssertionError('Result is not False')


if __name__ == '__main__':
    test_ShellModule_exists()

# Generated at 2022-06-23 12:42:57.632074
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()

    # Non powershell script, non pipelining
    cmd = "/usr/bin/python1 arg1 arg2 arg3"
    shebang = '#!python'
    expected = "/usr/bin/python1 arg1 arg2 arg3"
    actual = shell.build_module_command(None, shebang, cmd)
    assert actual == expected

    # Non powershell script, pipelining
    cmd = ''
    shebang = '#!python'

# Generated at 2022-06-23 12:43:05.350864
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    expand_user_test_cases = (
        ("~",
         'Write-Output (Get-Location).Path'),
        ("~/test_path",
         "Write-Output ((Get-Location).Path + '\\test_path')"),
        ("'~/test_path'",
         "Write-Output ((Get-Location).Path + '\\test_path')"),
        ("\"~/test_path\"",
         "Write-Output ((Get-Location).Path + '\\test_path')"),
        ("non_expanding_path",
         "Write-Output 'non_expanding_path'")
    )

    shell_module = ShellModule()

# Generated at 2022-06-23 12:43:14.646882
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module = ShellModule()
    assert shell_module.get_remote_filename('/home/file1.sh') == 'file1.sh'
    assert shell_module.get_remote_filename(u'/home/f\xe2\x9f\xb3e2.sh') == 'f\xe2\x9f\xb3e2.sh'
    assert shell_module.get_remote_filename('file1.sh') == 'file1.sh'
    assert shell_module.get_remote_filename('file1') == 'file1.ps1'
    assert shell_module.get_remote_filename('file1.txt') == 'file1.txt'
    assert shell_module.get_remote_filename('file1.txt.exe') == 'file1.txt.exe'

# Generated at 2022-06-23 12:43:20.716672
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():  # pylint: disable=unused-variable
    # Windows doesn't support chmod
    shell_module = ShellModule()

# Generated at 2022-06-23 12:43:24.608730
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule(None)
    cmd = shell.wrap_for_exec('[System.Console]::WriteLine(\'hello\')')
    assert cmd == '& [System.Console]::WriteLine(\'hello\'); exit $LASTEXITCODE'



# Generated at 2022-06-23 12:43:25.960145
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    assert ShellModule().env_prefix() == ''


# Generated at 2022-06-23 12:43:29.519324
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    from ansible.plugins.shell import ShellModule

    script = ShellModule().chown(paths='C:\\temp', user='abc')
    assert script == b"0"


# Generated at 2022-06-23 12:43:35.901515
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    assert ShellModule(connection=None).chown('path', 'user') == "Remove-Item 'path' -Force -Recurse; (Get-Item 'path').Owner = 'user' -Force"
    assert ShellModule(connection=None).chown('path', 'user', recurse=True) == "Remove-Item 'path' -Force -Recurse; (Get-Item 'path').Owner = 'user' -Force"

# Generated at 2022-06-23 12:43:43.894073
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    m = ShellModule()

    # Create a function with the same name as the method being tested
    def chmod(self, paths, mode):
        return ShellModule.chmod(self, paths, mode)

    # Call the method being tested
    try:
        chmod(m, 'test/test_file', 755)
    except NotImplementedError:
        pass
    else:
        raise AssertionError('ShellModule.chmod did not raise NotImplementedError')


# Generated at 2022-06-23 12:43:56.206315
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    # Build a mock ShellModule, since it requires a connection to run
    class MockConnection:
        def __init__(self, shell_plugin_class=ShellModule):
            self.shell = shell_plugin_class()

    script = MockConnection().shell.checksum('/path/to/file.ext')

# Generated at 2022-06-23 12:44:01.592284
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell = ShellModule(conn=None)
    assert shell.remove(path=r'C:\foo\bar.txt') == 'Remove-Item \'C:\\foo\\bar.txt\' -Force ;'
    assert shell.remove(path=r'C:\foo\bar.txt', recurse=True) == 'Remove-Item \'C:\\foo\\bar.txt\' -Force -Recurse ;'


# Generated at 2022-06-23 12:44:08.416787
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
        test_cases = [
            ('test.ps1', 'test.ps1'),
            ('test.exe', 'test.exe'),
            ('test.foo', 'test.ps1'),
            ('', 'tmp.ps1'),
            ('.', 'tmp.ps1'),
            ('foo bar', 'foo bar.ps1')
        ]

        for (arg, expected) in test_cases:
            if ShellModule(connection=None).get_remote_filename(arg) != expected:
                raise AssertionError('"%s" != "%s"' % (arg, expected))


# Generated at 2022-06-23 12:44:20.374639
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY2

    if PY2:
        from ansible.module_utils.basic import env_fallback
        environ = env_fallback(['TEST_REMOTE_TMP'])
    else:
        environ = dict(TEST_REMOTE_TMP='C:\temp')

    class FakeModule(object):
        def __init__(self):
            self.params = ImmutableDict()

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return executable


# Generated at 2022-06-23 12:44:22.562493
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    module_obj = ShellModule()
    assert module_obj.env_prefix() == ''


# Generated at 2022-06-23 12:44:35.105475
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    sm = ShellModule(command_name='shell')

    # test the UNC paths with \\ and \
    assert '\\root\\1\\2' == sm.join_path('\\\\root', '\\1\\', '2')

    # test the UNC paths with multiple slashes
    assert '\\\\root\\1\\2' == sm.join_path('\\\\root', '\\1\\\\\\\\\\/\\/2')

    # test a path without drive and without slash at the end
    assert 'root\\path' == sm.join_path('root\\path')

    # test empty paths
    assert '' == sm.join_path('')

    # test a path with backslashes
    assert 'root\\\\path\\\\1' == sm.join_path('root', '\\\\path', '1')

    # test a path without drive and with slash at the end

# Generated at 2022-06-23 12:44:39.269538
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test') == 'test.ps1'

# Generated at 2022-06-23 12:44:44.528051
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    original_cmd = '& echo test'
    expected_wrapped_cmd = '& %s; exit $LASTEXITCODE' % original_cmd
    wrapped_cmd = ShellModule()
    wrapped_cmd = wrapped_cmd.wrap_for_exec(original_cmd)
    assert wrapped_cmd == expected_wrapped_cmd

# Generated at 2022-06-23 12:44:46.510198
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    # Test with valid input
    test_shell = ShellModule()

    assert test_shell.env_prefix() == ""

# Generated at 2022-06-23 12:44:48.696668
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule(connection=None, play_context=None)
    assert [''] == shell.env_prefix()


# Generated at 2022-06-23 12:44:54.802100
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    def do_test(script, expected):
        data = dict(
            shebang="powershell",
            script=script,
            expected=expected)

        sm = ShellModule()
        result = sm.wrap_for_exec(data['script'])
        assert result == data['expected']

    do_test('write-output test', '& write-output test; exit $LASTEXITCODE')
    do_test('write-output test 1', '& write-output test 1; exit $LASTEXITCODE')
    do_test('write-output test 1 2', '& write-output test 1 2; exit $LASTEXITCODE')

# Generated at 2022-06-23 12:45:03.536518
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shellmod = ShellModule(connection='winrm')
    script = shellmod.remove(path=r"C:\Temp\testfile.txt", recurse=False)
    if sys.platform.startswith('win'):
        # On Windows, remove is converted to Remove-Item, which always uses
        # forward slashes.
        assert script == shellmod._encode_script('''Remove-Item C:/Temp/testfile.txt -Force;''')
    else:
        # On other platforms, we can't easily test this.
        pass


# Generated at 2022-06-23 12:45:10.021354
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    module_obj = ShellModule(connection=None)
    assert module_obj.path_has_trailing_slash('/backup') is False
    assert module_obj.path_has_trailing_slash('/backup/') is True
    assert module_obj.path_has_trailing_slash('C:\\test\\test') is False
    assert module_obj.path_has_trailing_slash('C:\\test\\test\\') is True
    assert module_obj.path_has_trailing_slash('C:\\test\\test\\ansible.exe') is False
    assert module_obj.path_has_trailing_slash('C:\\test\\test\\mymodule.ps1') is False

# Generated at 2022-06-23 12:45:18.780359
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    import io
    import unittest
    from ansible.module_utils.common.collections import ImmutableDict

    def decode(s):
        '''Return a decoded from utf-8 string'''
        return s.decode('utf-8')

    class FakeModule:

        def __init__(self):
            self.params = ImmutableDict()

    # Setup
    stdout = io.StringIO()
    module = FakeModule()
    # Dummy _unquote function
    module.path_has_trailing_slash = lambda: True
    # Replace Utils.prepare_writeable_dir
    module.run_command = lambda: 0

    # Test

# Generated at 2022-06-23 12:45:20.248121
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule()
    assert shell.env_prefix() == ""


# Generated at 2022-06-23 12:45:26.210424
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():

    # Test a valid module, 'stat'
    module_name = 'stat'
    module_args = ['path=/etc/passwd']

    shell = ShellModule(connection=None, no_log=True)

    try:
        cmd = shell.build_module_command(None, None, module_name, module_args)
    except NotImplementedError:
        # chown is not implemented for Powershell
        assert True
        return
    assert False, "Failed to raise an expected exception from build_module_command"

# Generated at 2022-06-23 12:45:36.278714
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Test paths with trailing slashes
    cmd = ShellModule()
    path = "C:\\Windows\\"
    assert cmd.path_has_trailing_slash(path) is True
    path = "C:/Windows/"
    assert cmd.path_has_trailing_slash(path) is True
    # Test paths without trailing slashes
    path = "C:\\Temp"
    assert cmd.path_has_trailing_slash(path) is False
    path = "C:/Temp"
    assert cmd.path_has_trailing_slash(path) is False
    # Test paths with single quotes
    path = "'C:\\Temp'"
    assert cmd.path_has_trailing_slash(path) is False


# Generated at 2022-06-23 12:45:44.255340
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule(shell='powershell')
    assert shell.expand_user(user_home_path='~') == shell._encode_script(script="Write-Output (Get-Location).Path")
    assert shell.expand_user(user_home_path='~\\path') == shell._encode_script(script="Write-Output ((Get-Location).Path + '\path')")
    assert shell.expand_user(user_home_path='/path') == shell._encode_script(script="Write-Output '\path'")
    assert shell.expand_user(user_home_path='\\\\path') == shell._encode_script(script="Write-Output 'path'")

# Generated at 2022-06-23 12:45:46.511169
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    module = ShellModule()

    assert module.env_prefix() == ''
# end of test_ShellModule_env_prefix


# Generated at 2022-06-23 12:45:54.190137
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # This method must return a string that is quoted for powershell
    # and the string includes the path to a temp dir and the basename
    # of the tempdir to create.
    #
    # The tempdir will be created from a guid, so it should be something like
    #
    #   c:\users\testuser\appdata\local\temp\1
    #
    # However, the basename can be any string, so it could be
    #
    #   c:\users\testuser\appdata\local\temp\random_name

    shell_mod = ShellModule()
    shell_mod.get_option = lambda x: getattr(shell_mod, x, None)
    shell_mod.remote_cwd = 'u:\\inetpub\\wwwroot'

# Generated at 2022-06-23 12:45:55.393940
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell_obj = ShellModule()
    assert shell_obj.set_user_facl("/test_dir", "test_user", 15) is None

# Generated at 2022-06-23 12:46:04.982862
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    _shell_redirect_allnull = '> $null'
    _shell_and = ';'
    shebang = u'#!' + os.path.normpath('/usr/bin/env')
    shebang_cmd = 'powershell'
    base_dir = os.path.normpath('test/ansible/test_utils')
    module_path = 'test_module_template.ps1'
    module_args = 'arg1 arg2 arg3'
    module_cmd = os.path.join(base_dir, module_path)
    test_module_cmd = ' '.join([module_path, module_args])
    test_module_base64_cmd = os.path.join(base_dir, shell.get_remote_filename(module_path))

    assert shell.build_

# Generated at 2022-06-23 12:46:09.080100
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    module = ShellModule()
    path = "myFile.txt"
    actual = module.remove(path, False)
    expected = "Remove-Item 'myFile.txt' -Force;"
    assert expected == actual


# Generated at 2022-06-23 12:46:14.497412
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    from ansible.plugins.shell import ShellModule
    from ansible.utils.path import mux_lookup_path
    from ansible import constants as C


# Generated at 2022-06-23 12:46:22.144971
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    """
    Test the method path_has_trailing_slash in class ShellModule.
    """
    shell = ShellModule()
    # Test with a basic path with a slash at the end
    assert shell.path_has_trailing_slash("C:\\Test\\")
    # Test with a basic path with a slash at the end
    assert shell.path_has_trailing_slash("C:/Test/")
    # Test with a basic path with no slash at the end
    assert not shell.path_has_trailing_slash("C:\\Test")
    # Test with a basic path with no slash at the end
    assert not shell.path_has_trailing_slash("C:/Test")
    # Test with a basic path with a slash at the end and a space in the path
    assert shell.path_has_tra

# Generated at 2022-06-23 12:46:24.039270
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    """
    test_ShellModule_env_prefix
    """
    sm = ShellModule()
    assert sm.env_prefix() == ""


# Generated at 2022-06-23 12:46:29.328290
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    sm = ShellModule()
    assert sm.remove("/home/username") == "$null = Remove-Item /home/username -Force;\n"
    assert sm.remove("/home/username", recurse=True) == "$null = Remove-Item /home/username -Force -Recurse;\n"

# Generated at 2022-06-23 12:46:33.815489
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    try:
        shell.set_user_facl('/home/someuser/testfile.txt', 'testuser', 'rw')
    except NotImplementedError:
        pass


# Generated at 2022-06-23 12:46:42.129695
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    """Test the ShellModule exists method"""
    shell = ShellModule(connection=None)

    # Test if file exist
    script = shell.exists('file_path')
    assert script == '''
        If (Test-Path 'file_path')
        {
            $res = 0;
        }
        Else
        {
            $res = 1;
        }
        Write-Output '$res';
        Exit $res;
     '''

    # Test if file doesn't exist
    script = shell.exists('file_path2')
    assert script == '''
        If (Test-Path 'file_path2')
        {
            $res = 0;
        }
        Else
        {
            $res = 1;
        }
        Write-Output '$res';
        Exit $res;
     '''



# Generated at 2022-06-23 12:46:48.568628
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():

    # Tests if shell module removes file from ansible if recurse is set true
    shell = ShellModule()
    assert shell.remove("/tmp/1.txt", True) == "Remove-Item '/tmp/1.txt' -Force -Recurse;"

    # Tests if shell module removes directory from ansible if recurse is set true
    shell = ShellModule()
    assert shell.remove("/tmp/testdir", True) == "Remove-Item '/tmp/testdir' -Force -Recurse;"

    # Tests if shell module removes file from ansible if recurse is set false
    shell = ShellModule()
    assert shell.remove("/tmp/1.txt", False) == "Remove-Item '/tmp/1.txt' -Force;"

# Generated at 2022-06-23 12:46:59.409965
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # instantiate ShellModule module class
    shell = ShellModule()
    shell._SHELL_REDIRECT_ALLNULL
    shell._SHELL_AND
    shell._IS_WINDOWS
    shell.COMPATIBLE_SHELLS
    shell.SHELL_FAMILY
    shell.env_prefix
    shell.join_path
    shell.get_remote_filename
    shell.path_has_trailing_slash
    shell.chmod
    shell.chown
    shell.set_user_facl
    shell.remove
    shell.mkdtemp
    shell.expand_user
    shell.exists
    shell.checksum
    shell.build_module_command
    shell.wrap_for_exec
    shell._unquote
    shell._escape
    shell._encode_script

# Generated at 2022-06-23 12:47:10.436488
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    module = ShellModule()
    path = 'test.txt'
    script = '''
        If (Test-Path '%s')
        {
            $res = 0;
        }
        Else
        {
            $res = 1;
        }
        Write-Output $res;
        Exit $res;
     ''' % path
    test_script = module._encode_script(script)

# Generated at 2022-06-23 12:47:22.997137
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    import sys

    if sys.version_info < (2, 7):
        print("SKIP: Python 2.6 detected. Test not run.")
        import unittest
        raise unittest.SkipTest("Python 2.6 detected. Test not run.")

    # Create instance of class
    shell_module = ShellModule()

    # Test case #1 - Test for filename with .ps1 extension
    # Create dictionary of inputs for test case
    inputs = dict()
    inputs['pathname'] = 'C:\\Temp\\test.ps1'

    # Get expected result
    expected_result = 'test.ps1'

    # Call method being tested
    actual_result = shell_module.get_remote_filename(**inputs)

    # Verify method behavior
    assert expected_result == actual_result



# Generated at 2022-06-23 12:47:31.337603
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module = ShellModule()
    program = 'Test.ps1' # Powershell Script
    assert program == shell_module.get_remote_filename(program), 'ShellModule.get_remote_filename should return the same filename that is passed as input'
    rect_with_ext = 'Dont_Change_me_I_have_ext.ps1' # Powershell Script
    assert rect_with_ext == shell_module.get_remote_filename(rect_with_ext), 'ShellModule.get_remote_filename should return the same filename that is passed as input'
    rect_without_ext = 'Dont_Change_me_I_dont_have_ext' # Extension missing

# Generated at 2022-06-23 12:47:33.252781
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    s = ShellModule()

    assert s.env_prefix() == ""

# Generated at 2022-06-23 12:47:34.701043
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO:
    return

# Generated at 2022-06-23 12:47:36.875373
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    assert shell.set_user_facl("/path/to/file", "testuser", "rw") == 'Not implemented'


# Generated at 2022-06-23 12:47:44.634754
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    class FakeConnection:
        def __init__(self):
            self.become_method = None

    class FakeRunner:
        def __init__(self):
            self.connection = FakeConnection()

    FakeRunner.get_remote_filename = ShellModule.get_remote_filename

    runner = FakeRunner()

    assert runner.get_remote_filename('test') == 'test.ps1'
    assert runner.get_remote_filename('test.ps1') == 'test.ps1'
    assert runner.get_remote_filename('test.py') == 'test.py.ps1'
    assert runner.get_remote_filename('test.exe') == 'test.exe'
    assert runner.get_remote_filename('test.txt') == 'test.txt.ps1'

# Generated at 2022-06-23 12:47:56.220175
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule(connection=dict())

    shebang = '#!/bin/sh'
    cmd = '/tmp/ansible-test-command'
    arg_path = '/tmp/ansible-test-arg-path'
    env_string = 'env'
    ret_cmd = shell.build_module_command(env_string, shebang, cmd, arg_path=arg_path)
    assert ret_cmd == "#!/bin/sh '/tmp/ansible-test-command' '/tmp/ansible-test-arg-path'"
    assert isinstance(ret_cmd, str)

    shebang = '#!/bin/bash'
    cmd = '/tmp/ansible-test-command'
    arg_path = '/tmp/ansible-test-arg-path'
    env_string = 'env'

# Generated at 2022-06-23 12:48:05.632655
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()
    result1 = shell.join_path('c:\\abc', 'def')
    assert result1 == 'c:\\abc\\def'
    result2 = shell.join_path('c:\\abc', '\\def')
    assert result2 == 'c:\\def'
    result3 = shell.join_path('c:\\abc', '\\\\def')
    assert result3 == 'c:\\def'
    result4 = shell.join_path('c:\\abc', '\\\\\\def')
    assert result4 == 'c:\\def'
    result5 = shell.join_path('c:\\abc', '\\\\\\def', '')
    assert result5 == 'c:\\def'
    result6 = shell.join_path('c:\\abc', '\\\\\\def', '\\')
    assert result

# Generated at 2022-06-23 12:48:17.300438
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.plugins.shell import ShellModule
    from ansible.errors import AnsibleError


# Generated at 2022-06-23 12:48:20.164315
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
   shell = ShellModule(connection=None)
   assert shell.chmod(paths=None, mode=None) == NotImplementedError('chmod is not implemented for Powershell')

# Generated at 2022-06-23 12:48:29.488481
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    sl = ShellModule(connection=None)
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

    # Test for pipelining bypass:
    # cmd = ''
    cmd = sl.build_module_command(env_string='', shebang='', cmd='')
    assert cmd == sl._encode_script(script=bootstrap_wrapper, strict_mode=False, preserve_rc=False)

    # Test for non-pipelining with module as .ps1 file:
    # cmd = 'c:\temp\foo.ps1'
    cmd = sl.build_module_command(env_string='', shebang='#!powershell', cmd='c:\\temp\\foo.ps1')

# Generated at 2022-06-23 12:48:30.450872
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None

# Generated at 2022-06-23 12:48:41.476256
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    s = ShellModule()
    # Test local path
    win_local_path = "C:\path\to\file"
    assert s.expand_user(win_local_path) == '''Write-Output "C:\\path\\to\\file"'''
    # Test network share path
    win_net_path = "\\server\share\directory\file"
    assert s.expand_user(win_net_path) == '''Write-Output "\\\\server\\share\\directory\\file"'''
    # Test local path with leading ~
    win_local_path_with_tilde = "~\file"
    assert s.expand_user(win_local_path_with_tilde) == '''Write-Output ((Get-Location).Path + '\\file')'''
    # Test network share path with leading ~

# Generated at 2022-06-23 12:48:48.816713
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    from ansible.utils.path import unfrackpath
    from ansible.plugins.shell import ShellModule
    import os
    cwd = os.getcwd()
    os.chdir('/tmp')
    s = ShellModule()
    source = unfrackpath("/tmp/source")
    os.makedirs(source)
    dest = unfrackpath("/tmp/dest")
    os.makedirs(dest)

# Generated at 2022-06-23 12:48:59.076803
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    module_inst = ShellModule()

    # test with '~' as input
    new_path = module_inst.expand_user(user_home_path='~')
    assert 'Write-Output' in new_path
    assert 'Get-Location' in new_path

    # test with '~/' as input
    new_path = module_inst.expand_user(user_home_path='~/')
    assert 'Write-Output' in new_path
    assert 'Get-Location' in new_path

    # test with '~\\' as input
    new_path = module_inst.expand_user(user_home_path='~\\')
    assert 'Write-Output' in new_path
    assert 'Get-Location' in new_path

    # test with '~/something' as input
    new_

# Generated at 2022-06-23 12:49:11.485396
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule(connection=None)
    module.no_log = True
    module.run_command = lambda **kwargs: 'result'
    module.get_option = lambda **kwargs: 'test'

    # pipelining
    result = module.build_module_command('', '', '')
    assert result == 'result'

    # not pipelining
    result = module.build_module_command('', '', 'test')
    assert result == '& test; exit $LASTEXITCODE'
    result = module.build_module_command('', '#!powershell', 'test')
    assert result == '& test; exit $LASTEXITCODE'
    result = module.build_module_command('', '#!/bin/test', 'test')

# Generated at 2022-06-23 12:49:24.381752
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule(None)
    assert shell.build_module_command('', '#!powershell', 'foo.py') == shell._encode_script(script="type foo.py.ps1 | " + pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"), strict_mode=False, preserve_rc=False)
    assert shell.build_module_command('', '#!ps', 'foo.py') == shell._encode_script(script="type foo.py.ps1 | " + pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"), strict_mode=False, preserve_rc=False)
    assert shell.build_module_command('', '#!powershell', 'foo.py arg1 arg2') == shell._

# Generated at 2022-06-23 12:49:32.337734
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    sm = ShellModule()
    for ext in ('.ps1', '.Powershell', '.cmd', '.bat', '.exe', ''):
        for path in (
                'shell_plugin/hello',
                'shell_plugin/path/hello',
                'shell_plugin/hello.ps1',
                'shell_plugin/path/hello.ps1',
                'shell_plugin/hello.cmd',
                'shell_plugin/path/hello.cmd',):
            assert sm.get_remote_filename(path + ext) == 'hello.ps1'


# Generated at 2022-06-23 12:49:38.098283
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule(
        connection=dict(
            transport='winrm'
        ),
        run_as=dict(
            user='IUSR'
        )
    )

    # TODO: Check that the method "chown" raises the appropriate exception.



# Generated at 2022-06-23 12:49:46.679662
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Empty path
    test = ShellModule()
    assert not test.path_has_trailing_slash("")

    # Path with forward slashes
    assert test.path_has_trailing_slash("foo")
    assert test.path_has_trailing_slash("foo/bar")
    assert test.path_has_trailing_slash("foo/bar/")
    assert not test.path_has_trailing_slash("foo/bar/txt")

    # Path with forward and backslashes
    assert test.path_has_trailing_slash("foo")
    assert test.path_has_trailing_slash("foo\\bar")
    assert test.path_has_trailing_slash("foo\\bar\\")

# Generated at 2022-06-23 12:49:51.484334
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_obj = ShellModule()
    base_name = "ansible_test.XXXXXX"
    mkdtemp_re = "^.*\\\\" + re.escape(base_name) + "$"
    assert re.match(mkdtemp_re, shell_obj.mkdtemp(base_name=base_name))


# Generated at 2022-06-23 12:49:59.049226
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell_module = ShellModule()
    test_cases = [
        ('a', False, "Remove-Item 'a' -Force;"),
        ('a', True, "Remove-Item 'a' -Force -Recurse;"),
    ]
    for path, recurse, expected_output in test_cases:
        actual_output = shell_module.remove(path, recurse)
        assert actual_output == expected_output, "{} == {}".format(actual_output, expected_output)


# Generated at 2022-06-23 12:50:08.308305
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    """
    Method remove of class ShellModule
    """
    # Test for recurse mode
    shell_module = ShellModule()
    cmd = shell_module.remove('/tmp/test', True)
    assert cmd == b'powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command Remove-Item \'/tmp/test\' -Force -Recurse;'

    # Test for no recurse mode
    shell_module = ShellModule()
    cmd = shell_module.remove('/tmp/test', False)
    assert cmd == b'powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command Remove-Item \'/tmp/test\' -Force;'



# Generated at 2022-06-23 12:50:10.871892
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule()
    wrapper = shell.wrap_for_exec('test')
    assert wrapper == '& test; exit $LASTEXITCODE'


# Generated at 2022-06-23 12:50:16.834831
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    assert ShellModule._exists('C:\\Boot') == '''
            If ((Test-Path -PathType Leaf 'C:\\Boot'))
            {
                $res = 0
            }
            Else
            {
                $res = 1
            }
            Write-Output '$res'
            Exit $res
        '''


# Generated at 2022-06-23 12:50:22.089112
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    script = ShellModule().mkdtemp()
    assert type(script) == str
    assert re.match(r"^powershell .*", script)
    assert re.match(r".*New-Item -Type Directory.*", script)
    # print(script)


# Generated at 2022-06-23 12:50:23.684924
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    path = "path"
    user = "user"
    obj = ShellModule()
    assert NotImplementedError == obj.chown(path, user)


# Generated at 2022-06-23 12:50:31.826605
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.plugins.connection.winrm
    import ansible.plugins.shell.powershell
    run_module_mock = ansible.plugins.connection.winrm.run_ps(
        'localhost',
        'some_module_command',
        '',
        '',
        '',
        None,
        '',
        None,
        None,
        ''
    )

    shell = ansible.plugins.shell.powershell.ShellModule(connection=None)
    shell.run_command = run_module_mock

    command = shell.build_module_command('some_env', 'some_shebang', 'some_command')
    encoded_command = to_text(base64.b64encode('some_command'.encode('utf-16-le')), 'utf-8')

# Generated at 2022-06-23 12:50:40.104268
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # setup test
    shell = ShellModule()
    # execute tests
    command = shell.mkdtemp('some-prefix-')
    # verify
    assert command == r'PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command $tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'$env:TEMP\') $tmp = New-Item -Type Directory -Path $tmp_path -Name \'some-prefix-\' Write-Output -InputObject $tmp.FullName'

# Generated at 2022-06-23 12:50:50.919525
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    # Test backward-compatibility
    result = ShellModule().join_path('C:\\', 'temp', 'test.txt')
    assert result == 'C:\\temp\\test.txt'

    # Ensure double backslashes are removed
    result = ShellModule().join_path('C:\\temp', '\\test.txt')
    assert result == 'C:\\temp\\test.txt'

    # Ensure trailing backslashes are removed
    result = ShellModule().join_path('C:\\temp\\', 'test.txt')
    assert result == 'C:\\temp\\test.txt'

    # Ensure forward slashes are not changed
    result = ShellModule().join_path('C:/temp/', 'test.txt')
    assert result == 'C:/temp/test.txt'

    # Ensure quoted parts are expanded

# Generated at 2022-06-23 12:51:02.369944
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import shutil
    import tempfile
    import os

    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    assert bootstrap_wrapper is not None
    bootstrap_wrapper_filename = os.path.join(tempfile.mkdtemp(), "bootstrap_wrapper.ps1")
    with open(bootstrap_wrapper_filename, 'w') as bootstrap_wrapper_file:
        bootstrap_wrapper_file.write(to_text(bootstrap_wrapper))

    builtin_module_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules', 'windows')
    ps_module_path = tempfile.mkdtemp()

    # Test when the

# Generated at 2022-06-23 12:51:13.071454
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    powershell = ShellModule()

    assert powershell.path_has_trailing_slash("/foo/bar/")
    assert powershell.path_has_trailing_slash("/foo/bar\\")
    assert not powershell.path_has_trailing_slash("/foo/bar")

    # empty paths return False
    assert not powershell.path_has_trailing_slash("")
    assert not powershell.path_has_trailing_slash("\\")
    assert not powershell.path_has_trailing_slash("\\\\")
    assert not powershell.path_has_trailing_slash("/")


# Generated at 2022-06-23 12:51:15.375448
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    with pytest.raises(NotImplementedError):
        ShellModule().chmod(paths=None, mode=None)
