

# Generated at 2022-06-11 16:41:34.998798
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule._SHELL_AND == ';'
    assert ShellModule._IS_WINDOWS


# Generated at 2022-06-11 16:41:42.605901
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Create a new instance of ShellModule
    test_instance = ShellModule()
    # Test user_home_path = '~'
    assert test_instance.expand_user('~') == 'VABoAGkAcwAgAGsAZQBpAGwAIAAoAEUAbgBjAG8AbgBkACkA'
    # Test user_home_path = '~\\test'
    assert test_instance.expand_user('~\\test') == 'VABoAGkAcwAgAGsAZQBpAGwAIAAoAEUAbgBjAG8AbgBkACkAIC4gJ3Rlc3Qn'
    # Test user_home_path = '~test'

# Generated at 2022-06-11 16:41:47.681551
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Create an instance of argument spec for test module
    args = dict(
        shell_type='powershell'
    )

    # Create a instance of ShellModule class with argument spec
    shell_module_instance = ShellModule(args)

    # Check whether it is Unix based shell
    assert(shell_module_instance._IS_WINDOWS == True)

# Generated at 2022-06-11 16:42:00.256092
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Create the test object
    shell_module = ShellModule()

    # Define the parameters passed into the method
    env_string = 'Option Explicit'
    shebang = '#!python'
    cmd = 'ansible-test-module.py'
    arg_path = 'test_path'

    # Execute the method
    result = shell_module.build_module_command(env_string, shebang, cmd, arg_path)

    # Get the expected result

# Generated at 2022-06-11 16:42:08.531378
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shellmod = ShellModule()
    print(shellmod.expand_user('~'))
    print(shellmod.expand_user('~\\'))
    print(shellmod.expand_user('~\\local\\temp'))
    print(shellmod.expand_user('C:\\'))
    print(shellmod.expand_user('C:\\local\\temp'))

if __name__ == "__main__":
    test_ShellModule_expand_user()

# Generated at 2022-06-11 16:42:10.149856
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection='winrm')

# Generated at 2022-06-11 16:42:14.354773
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test') == 'test.ps1'

# Generated at 2022-06-11 16:42:15.021228
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:42:17.763725
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''constructor'''
    shell = ShellModule(connection=None)
    assert shell.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-11 16:42:25.217213
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Test the constructor of the ShellModule class.
    """
    from ansible.utils.path import unfrackpath

    assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule._SHELL_AND == ';'
    assert hasattr(ShellModule, 'COMPATIBLE_SHELLS')
    assert hasattr(ShellModule, 'SHELL_FAMILY')
    assert hasattr(ShellModule, '_IS_WINDOWS')
    sm = ShellModule('/foo/bar')
    assert sm.get_option('remote_tmp') == '/foo/bar'
    sm = ShellModule(remote_tmp='/foo/bar')
    assert sm.get_option('remote_tmp') == '/foo/bar'
    sm = ShellModule()

# Generated at 2022-06-11 16:42:37.782872
# Unit test for constructor of class ShellModule
def test_ShellModule():
    new_shell = ShellModule()
    assert new_shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:42:45.274217
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    shell_module = ShellModule()

    # test first use case: pipelining
    cmd = 'foo.exe'
    shebang = ''
    env_string = None
    arg_path = None

    expected = shell_module._encode_script('type foo.exe.ps1 | & bootstrap_wrapper.ps1', strict_mode=False, preserve_rc=False)
    actual = shell_module.build_module_command(env_string, shebang, cmd, arg_path)
    assert actual == expected

    # test second case, without shebang
    cmd = 'foo.exe'
    shebang = None
    env_string = 'C:\temp'
    arg_path = None


# Generated at 2022-06-11 16:42:52.786100
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Create an instance of ShellModule with the name 'powershell'.
    shell_module = ShellModule(connection=None, shell_executable='powershell.exe')
    # Create a sample command
    cmd = shell_module.build_module_command("", "", " echo foo")
    # Test that the command is not empty
    assert(cmd != '')
    # Test that the command is valid powershell code
    assert(cmd.startswith("powershell.exe"))


# Generated at 2022-06-11 16:42:54.247289
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule(connection_type='winrm', become_username='bob', prompt=['>'])

# Generated at 2022-06-11 16:42:55.114180
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule() is not None

# Generated at 2022-06-11 16:43:02.526893
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    powershell_shell = ShellModule()
    assert powershell_shell.path_has_trailing_slash('c:\\ansible\\test\\') == True
    assert powershell_shell.path_has_trailing_slash('c:/ansible/test/') == True
    assert powershell_shell.path_has_trailing_slash('c:\\ansible\\test') == False
    assert powershell_shell.path_has_trailing_slash('c:/ansible/test') == False

# Generated at 2022-06-11 16:43:12.351131
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_cmd = ShellModule()
    ans = shell_cmd.path_has_trailing_slash(path='\\\\server')
    assert ans == True, "ShellModule_path_has_trailing_slash test fails"
    ans = shell_cmd.path_has_trailing_slash(path='file.txt')
    assert ans == False, "ShellModule_path_has_trailing_slash test fails"
    ans = shell_cmd.path_has_trailing_slash(path='file.txt')
    assert ans == False, "ShellModule_path_has_trailing_slash test fails"
    ans = shell_cmd.path_has_trailing_slash(path='c:')
    assert ans == True, "ShellModule_path_has_trailing_slash test fails"
    ans = shell

# Generated at 2022-06-11 16:43:21.420404
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    import platform
    import sys

    if_is_linux = platform.system() == 'Linux'
    if if_is_linux:
        import platform
        platform.system = lambda: 'Windows'
        platform.release = lambda: '7'

    from ansible.plugins import shell_loader


# Generated at 2022-06-11 16:43:23.740207
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Correct implementation of constructor should return instance of class ShellModule
    powershell = ShellModule()
    assert type(powershell) == ShellModule

# Generated at 2022-06-11 16:43:35.010971
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

    # test if _unquote without quotes
    assert 'abcd' == shell._unquote('abcd')
    # test if _unquote with single quotes
    assert 'abcd' == shell._unquote("'abcd'")
    # test if _unquote with double quotes
    assert 'abcd' == shell._unquote('"abcd"')
    # test if _unquote with whitespace + single quotes
    assert 'abcd' == shell._unquote("' abcd '")
    # test if _unquote with whitespace + double quotes
    assert 'abcd' == shell._unquote('" abcd "')

    # test if _unquote with single quotes + whitespace + single quotes
    assert 'abcd ' == shell._unquote("'abcd '")

    # test if _escape with empty string

# Generated at 2022-06-11 16:43:48.219367
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    sm.join_path('/tmp/the_folder_name', 'the_file_name')
    sm.get_remote_filename('/tmp/the_folder_name/the_file_name')
    sm.path_has_trailing_slash('/tmp/the_folder_name/the_file_name')

# Generated at 2022-06-11 16:43:51.803300
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(conn=None, in_data=None, prompt=None, newline=None, runner=None)
    assert isinstance(shell, ShellBase)

# Generated at 2022-06-11 16:44:01.605632
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    assert ShellModule().path_has_trailing_slash("/home/user/") == True
    assert ShellModule().path_has_trailing_slash("/home/user") == False

# Generated at 2022-06-11 16:44:03.136138
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:44:04.306882
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shm = ShellModule()

# Generated at 2022-06-11 16:44:05.668014
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # pylint: disable=unused-variable
    shell_module = ShellModule()
    # pylint: enable=unused-variable

# Generated at 2022-06-11 16:44:14.558912
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    powershell_module = ShellModule()

    module_cmd = powershell_module.build_module_command(env_string='', shebang='', cmd='', arg_path='')
    assert module_cmd == powershell_module._encode_script(script=pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"), strict_mode=False, preserve_rc=False)

    module_cmd = powershell_module.build_module_command(env_string='', shebang='#!powershell',
                                                        cmd='"c:\\program files (x86)\\test script.ps1"', arg_path='')

# Generated at 2022-06-11 16:44:24.796289
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test the method build_module_command of the class ShellModule
    # The return of this method will be tested, so the method _encode_script
    # is mocked.
    shell = ShellModule()

    # Test the pipelining bypass
    cmd = '-Command -'
    bootstrap_wrapper = '''
        $PSVersionTable
        $ProgressPreference = 'SilentlyContinue'
        $DebugPreference = 'SilentlyContinue'
        $ErrorActionPreference = 'Stop'
        [System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    '''
    encoded_script = shell._encode_script(bootstrap_wrapper, strict_mode=False)
    cmd_parts = _common_args + [cmd]
    assert ' '.join(cmd_parts) == shell.build_module_

# Generated at 2022-06-11 16:44:29.491505
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test = ShellModule(connection=None, become_method=None, become_user=None, become_password=None, check=False, diff=False)
    assert test.SHELL_FAMILY == 'powershell'
    assert test._IS_WINDOWS is True


# Generated at 2022-06-11 16:44:34.191718
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Construct a module handler
    ps_module = ShellModule()
    # Test the module handler
    assert ps_module.SHELL_FAMILY == 'powershell'
    assert ps_module.COMPATIBLE_SHELLS == frozenset()
    assert ps_module._IS_WINDOWS



# Generated at 2022-06-11 16:44:56.849231
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(command_terminator=';', shebang='#!/usr/bin/env powershell', delete_remote_tmp=True)
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'

    # Test with bogus command_terminator, should fail with a TypeError
    try:
        module = ShellModule(command_terminator=42, shebang='#!/usr/bin/env powershell', delete_remote_tmp=True)
        raise Exception('module init with bogus command_terminator')
    except TypeError as e:
        pass

    # Test with bogus shebang, should raise an AssertionError

# Generated at 2022-06-11 16:45:08.021120
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    cmd = "echo hello"

    # Check the common arguments
    assert ' '.join(shell._encode_script(cmd, as_list=True)) == "PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command echo hello"
    assert ' '.join(shell.build_module_command(None, None, cmd)) == "PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command echo hello"

    # Check if the script is being encoded correctly

# Generated at 2022-06-11 16:45:19.834000
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.txt') == 'test.txt.ps1'
    assert shell.get_remote_filename('hello/test/world.txt') == 'world.txt.ps1'
    assert shell.get_remote_filename('hello/world') == 'world.ps1'
    assert shell.get_remote_filename('hello\\world.ps1') == 'world.ps1'
    assert shell.get_remote_filename('hello\\test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('hello\\world') == 'world.ps1'
    assert shell.get

# Generated at 2022-06-11 16:45:20.351176
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:45:21.205091
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule is not None

# Generated at 2022-06-11 16:45:23.850987
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    assert s.get_remote_filename('role/../some/other/path.ps1') == 'path.ps1'


# Generated at 2022-06-11 16:45:36.353901
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test for Windows
    assert ShellModule()._IS_WINDOWS is True
    # Test for Linux
    assert ShellModule(SHELL_FAMILY='csh')._IS_WINDOWS is False
    # Test for Mac OSX
    assert ShellModule(SHELL_FAMILY='ksh')._IS_WINDOWS is False

    # Test constructor of parent class ShellBase
    assert ShellBase(SHELL_FAMILY='ksh')._IS_WINDOWS is False
    assert ShellBase(SHELL_FAMILY='csh')._IS_WINDOWS is False
    assert ShellBase(SHELL_FAMILY='bash')._IS_WINDOWS is False
    assert ShellBase(SHELL_FAMILY='zsh')._IS_WINDOWS is False
    assert ShellBase(SHELL_FAMILY='sh')._IS_WINDOWS is False

# Generated at 2022-06-11 16:45:44.500500
# Unit test for constructor of class ShellModule
def test_ShellModule():
    my_shell = ShellModule()

# Generated at 2022-06-11 16:45:45.724724
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection='winrm')

# Generated at 2022-06-11 16:45:51.866736
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert hasattr(module, 'language')
    assert hasattr(module, 'compile_extension')
    assert hasattr(module, 'shebang')
    assert hasattr(module, '_escape')
    assert hasattr(module, '_quote')
    assert hasattr(module, '_unquote')
    assert hasattr(module, '_encode_script')
    assert hasattr(module, '_build_module_command')
    assert hasattr(module, 'wrap_for_exec')
    return True

# Generated at 2022-06-11 16:46:20.242801
# Unit test for constructor of class ShellModule
def test_ShellModule():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    options = Options(connection='winrm', remote_addr='localhost',
                      remote_port=5985, no_log=True)

    shell = ShellModule(task=None, connection=None, shell_type='powershell',
                        no_log=options.no_log, options=options)
    assert shell.connection == 'winrm'
    assert shell.no_log == options.no_log
    assert shell.options == options
    assert shell.shebang == '#!powershell'

    # Test with options

# Generated at 2022-06-11 16:46:29.554071
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Init should generate a random temporary directory
    c = ShellModule()
    c.inject = {}

    c.inject['no_log'] = True
    c.inject['chdir'] = "/tmp"
    assert c.no_log == True
    assert c.chdir == "/tmp"
    assert c.tmpdir.startswith('/tmp/ansible_shell_')
    assert c.remote_tmp.startswith('$env:TEMP\\ansible_shell_')
    assert c.remote_tmp.startswith('$env:TEMP\\ansible_shell_')
    assert c.remote_tmp.startswith('$env:TEMP\\ansible_shell_')
    assert c.get_remote_filename('test.txt') == 'test.txt'
    assert c.get_remote_filename

# Generated at 2022-06-11 16:46:31.188532
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule(connection=None, runner=None, templar=None)

# Generated at 2022-06-11 16:46:40.035202
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shebang = '#!powershell'
    cmd = 'echo "MyString"'

    a = ShellModule(conn=None)
    encoded_cmd = a.build_module_command(env_string='', shebang=shebang, cmd=cmd, arg_path=None)
    assert isinstance(encoded_cmd, str)

    # Test _unquote method
    m = re.match(r'^\s*?\'(.*?)\'\s*?$', "''")
    assert m.group(1) == ''

    m = re.match(r'^\s*?\"(.*?)\"\s*?$', '"Invalid String"')
    assert m.group(1) == 'Invalid String'


# Generated at 2022-06-11 16:46:42.760154
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    assert(shell_obj._SHELL_REDIRECT_ALLNULL == '> $null')
    assert(shell_obj._SHELL_AND == ';')

# Generated at 2022-06-11 16:46:44.317153
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Instantiate the module and get the version
    ShellModule()

# Generated at 2022-06-11 16:46:50.948976
# Unit test for constructor of class ShellModule
def test_ShellModule():
    script = u"Write-Output 'Hello world'"
    conn = ShellModule(None, None, None)
    encoded_script = conn._encode_script(script)
    decoded_script = base64.b64decode(encoded_script[encoded_script.find(' ')+1:].encode('utf-8')).decode('utf-16-le')
    assert decoded_script.find(script) != -1


# Generated at 2022-06-11 16:46:54.140301
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm.COMPATIBLE_SHELLS == set()
    assert sm._IS_WINDOWS



# Generated at 2022-06-11 16:46:59.599686
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()
    assert p._SHELL_REDIRECT_ALLNULL
    assert p._SHELL_AND == ';'
    assert p._IS_WINDOWS
    assert p.COMPATIBLE_SHELLS == frozenset()
    assert p.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:47:11.235572
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import sys
    if sys.version_info >= (3, 0):
        assert to_bytes('cmd.exe /C echo hello world') == ShellModule()._build_command('cmd.exe /C echo hello world')
        assert to_bytes('cmd.exe /C echo hello world') == ShellModule()._build_command('cmd.exe /C echo hello world', executable='cmd.exe')
    assert to_bytes('cmd.exe /C echo hello world') == ShellModule()._build_command(u'cmd.exe /C echo hello world')
    assert to_bytes('cmd.exe /C echo hello world') == ShellModule()._build_command(u'cmd.exe /C echo hello world', executable='cmd.exe')

# Generated at 2022-06-11 16:48:01.628873
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:48:09.883061
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 16:48:20.365437
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Test constructor of class ShellModule
    """
    _COMMON_ARGS = ['PowerShell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Unrestricted']
    shell_obj = ShellModule()
    assert shell_obj.COMPATIBLE_SHELLS == frozenset()
    assert shell_obj.SHELL_FAMILY == 'powershell'
    assert shell_obj._IS_WINDOWS == True
    assert shell_obj._shell_executable == 'PowerShell'
    assert shell_obj._shell_executable_abs == 'PowerShell'
    assert shell_obj._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_obj._SHELL_AND == ';'
    assert shell_obj._COMMON_ARGS == _COMMON_ARGS


#

# Generated at 2022-06-11 16:48:24.840985
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.env_prefix() == ""


# Generated at 2022-06-11 16:48:26.363658
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    #s.sanitize_output('abcd',True)

# Generated at 2022-06-11 16:48:34.346278
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # set up
    context = dict(ANSIBLE_POWERCLI_FORCE=True)
    context.update(os.environ)
    context['TEST_SHELL_PLUGIN'] = 'powershell'
    # test
    ps_plugin = ShellModule(connection='winrm', runner_name='local', module_name='shell', module_args='echo "hello"', become_method='runas', become_user='administrator', context=context)
    # assert
    assert ps_plugin.SHELL_FAMILY == 'powershell'
    assert isinstance(ps_plugin, ShellBase)
    assert ps_plugin._IS_WINDOWS
    assert ps_plugin.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:48:45.926037
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Construct a shell plugin
    plugged_shell = ShellModule()

    # Assert all of the basic plugin options are set to something
    assert plugged_shell.SHELL_FAMILY == 'powershell'
    assert plugged_shell.COMPATIBLE_SHELLS == frozenset()
    assert plugged_shell._IS_WINDOWS is True

    # Assert the basic methods (which don't need args) don't fail
    assert plugged_shell.get_remote_filename('test') == 'test.ps1'
    assert plugged_shell.get_remote_filename('test.EXE') == 'test.EXE'
    assert plugged_shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert plugged_shell.get_remote_filename('test.bin') == 'test.bin.ps1'

# Generated at 2022-06-11 16:48:47.221836
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Check whether the correct class is constructed.
    my_shell = ShellModule('my_context')
    assert isinstance(my_shell, ShellModule)

# Generated at 2022-06-11 16:48:50.546158
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS

# Unit tests for methods of class ShellModule

# Generated at 2022-06-11 16:48:53.305541
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert isinstance(module, ShellModule)

# Generated at 2022-06-11 16:50:51.649638
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    assert isinstance(s, ShellBase)
    assert hasattr(s, "_SHELL_REDIRECT_ALLNULL")
    assert hasattr(s, "SHELL_FAMILY")
    assert hasattr(s, "CHUNK_SIZE")
    assert hasattr(s, "COMPATIBLE_SHELLS")


# FIXME: connection plugin

# Generated at 2022-06-11 16:51:00.288238
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import ansible
    testmod = ShellModule(connection=None)
    assert testmod.SHELL_FAMILY == 'powershell'
    assert isinstance(testmod.COMPATIBLE_SHELLS, frozenset)
    assert ansible.module_utils.windows.winapi.__name__ == 'ansible.module_utils.windows.winapi'
    assert testmod._IS_WINDOWS

# Usage in connection plugin
# ========================
#
# class Connection(ConnectionBase):
#     transport = 'winrm'
#     # Add other methods needed for specific connection plugin here
#     # ...
#
# def _winrm_connection_builder(conn):
#     # import winrm, PowerShell, etc.
#     conn.winrm = winrm_conn.winrm
#     conn.PowerShell = conn.winrm

# Generated at 2022-06-11 16:51:06.240899
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule()

    assert powershell.COMPATIBLE_SHELLS == frozenset()
    assert powershell.SHELL_FAMILY == 'powershell'
    assert powershell._IS_WINDOWS is True
    assert powershell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert powershell._SHELL_AND == ';'

# Generated at 2022-06-11 16:51:08.711210
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell._executable == 'PowerShell'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'


# Generated at 2022-06-11 16:51:16.208320
# Unit test for constructor of class ShellModule
def test_ShellModule():

    sh_m = ShellModule()

    assert sh_m.COMPATIBLE_SHELLS == frozenset()
    assert sh_m.SHELL_FAMILY == 'powershell'
    assert sh_m._IS_WINDOWS is True

    test_path = "C:\\Program Files\\Program Files (x86)\\"
    test_path_joined = "C:\\Program Files\\Program Files (x86)\\"

    assert sh_m.join_path(test_path) == test_path_joined

    assert sh_m.get_remote_filename("ansible-test.txt") == "ansible-test.txt"
    assert sh_m.get_remote_filename("ansible-test") == "ansible-test.ps1"


# Generated at 2022-06-11 16:51:18.216474
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:51:21.509334
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_mod = ShellModule()
    assert shell_mod.COMPATIBLE_SHELLS is not None
    assert shell_mod.SHELL_FAMILY is not None
    assert shell_mod._IS_WINDOWS is not None
