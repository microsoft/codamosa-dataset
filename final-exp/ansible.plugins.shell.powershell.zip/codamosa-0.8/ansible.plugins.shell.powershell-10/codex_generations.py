

# Generated at 2022-06-11 16:41:32.163746
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()


# Generated at 2022-06-11 16:41:40.980371
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    import types
    import unittest

    class TestShellModule(ShellModule):
        pass

    test_shell_module = TestShellModule()
    assert isinstance(test_shell_module.COMPATIBLE_SHELLS, types.FrozenSet)
    assert isinstance(test_shell_module.SHELL_FAMILY, str)
    assert test_shell_module.SHELL_FAMILY == "powershell"

    assert isinstance(test_shell_module._IS_WINDOWS, bool)
    assert test_shell_module._IS_WINDOWS == True

    assert isinstance(test_shell_module.COMPATIBLE_SHELLS, types.FrozenSet)
    assert test_shell_module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-11 16:41:52.102561
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()

    path_list = ["~", "~/test", "c:\\home\\test", "~\\test", "~/hello/world", "~/hello/world\\", "~/hello/world\\\\", "~\\hello\\world", "~\\hello\\world\\", "~\\hello\\world\\\\"]
    results = []
    for path in path_list:
        results.append(shell.expand_user(path))

    assert 'Write-Output (Get-Location).Path' in results[0]
    assert 'Write-Output ((Get-Location).Path + ' in results[1]
    assert 'Write-Output ((Get-Location).Path + ' not in results[2]
    assert 'Write-Output ((Get-Location).Path + ' in results[3]
    #assert 'Write-Output ((Get-

# Generated at 2022-06-11 16:42:03.753301
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.plugins.shell.powershell import ShellModule
    sm = ShellModule()
    cmd = sm.build_module_command(None, '#!foo/bar', 'test_module', None)

# Generated at 2022-06-11 16:42:13.795899
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    shell.noop_on_check_mode = True
    shell.HAS_TTY = False
    shell.SHELL_FAMILY = 'powershell'

    basefile = 'test_ShellModule_mkdtemp'
    system = False
    mode = None
    tmpdir = None
    ret = shell.mkdtemp(basefile=basefile, system=system, mode=mode, tmpdir=tmpdir)

    if not isinstance(ret, dict):
        print("test_ShellModule_mkdtemp() failed - returns unknown type")
        return False

    if not ret['rc'] == 0:
        print("test_ShellModule_mkdtemp() failed - returns: %s" % ret['rc'])
        return False


# Generated at 2022-06-11 16:42:23.294510
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.utils.vars import combine_vars

    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'

    # test escaped() function
    assert sm._escape(u'foo\u2018bar\u2019baz\u201abaz\u201b') == u"foo'bar'baz`baz`"
    assert sm._escape(u'foo"bar') == u'foo""bar'
    assert sm._escape(u'luke\'s lightsaber') == u'luke\'\'s lightsaber'

# Generated at 2022-06-11 16:42:24.450985
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert isinstance(ShellModule(), ShellModule)

# Generated at 2022-06-11 16:42:33.345717
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    s = ShellModule('test', None)
    assert s.expand_user(u"~") == s._encode_script(script="Write-Output (Get-Location).Path")
    assert s.expand_user(u"~\\") == s._encode_script(script="Write-Output ((Get-Location).Path + '')")
    assert s.expand_user(u"~\\test") == s._encode_script(script="Write-Output ((Get-Location).Path + '\\test')")
    assert s.expand_user(u"c:\\users") == s._encode_script(script="Write-Output 'c:\\users'")
    assert s.expand_user(u"c:\\users\\") == s._encode_script(script="Write-Output 'c:\\users\\'")

# Generated at 2022-06-11 16:42:39.689953
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    module = ShellModule({})
    basefile = 'test'
    mode = None
    tmpdir = 'tmp'
    command = module.mkdtemp(basefile=basefile, system=False, mode=mode, tmpdir=tmpdir)
    print('command=' + command)
    assert command == u'''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('tmp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'test'
        Write-Output -InputObject $tmp.FullName
        '''

# Generated at 2022-06-11 16:42:41.767952
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    #assert sm.COMPATIBLE_SHELLS == frozenset()



# Generated at 2022-06-11 16:42:51.273522
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    module = ShellModule()
    assert module.get_remote_filename("ping.py") == "ping.py"
    assert module.get_remote_filename("ping.ps1") == "ping.ps1"
    assert module.get_remote_filename("ping") == "ping.ps1"


# Generated at 2022-06-11 16:43:01.362940
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    sh = ShellModule(connection=NoopConnection(new_stdin=None))
    env_string = '$env:ANSIBLE_MODULE_ARGS=\'{"ANSIBLE_MODULE_ARGS": "value"}\''
    shebang = '#!/usr/bin/python'
    cmd = '"path\\to\\module"; Write-Output "success"'
    expected = ''
    assert sh.build_module_command(env_string, shebang, cmd) == expected
    cmd = 'echo $basename'

# Generated at 2022-06-11 16:43:08.140798
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()

    assert 'file.ps1' == shell.get_remote_filename('file')
    assert 'file.txt.ps1' == shell.get_remote_filename('file.txt')
    assert 'file.ps1' == shell.get_remote_filename('file.ps1')
    assert 'file.exe' == shell.get_remote_filename('file.exe')



# Generated at 2022-06-11 16:43:09.377905
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module is not None

# Generated at 2022-06-11 16:43:20.191443
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()

# Generated at 2022-06-11 16:43:24.821891
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == "powershell"
    assert shell._SHELL_REDIRECT_ALLNULL == "> $null"
    assert shell._SHELL_AND == ";"
    assert shell._IS_WINDOWS

# Generated at 2022-06-11 16:43:29.993967
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    m = ShellModule()
    assert m.get_remote_filename('/path/to/foo') == 'foo.ps1'
    assert m.get_remote_filename('/path/to/foo.ps1') == 'foo.ps1'
    assert m.get_remote_filename('/path/to/foo.exe') == 'foo.exe'

# Generated at 2022-06-11 16:43:38.200019
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    result = ShellModule.get_remote_filename('filename')
    assert result == 'filename.ps1'

    result = ShellModule.get_remote_filename('filename.ps1')
    assert result == 'filename.ps1'

    result = ShellModule.get_remote_filename('filename.exe')
    assert result == 'filename.exe'

    result = ShellModule.get_remote_filename('c:\path\filename.exe')
    assert result == 'filename.exe'

    result = ShellModule.get_remote_filename('c:\path\filename.ps1')
    assert result == 'filename.ps1'

# Generated at 2022-06-11 16:43:48.379609
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Verify the constructor
    sm = ShellModule()
    assert sm
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS
    assert sm.env_prefix(**{}) == ''
    assert sm.join_path('a', 'b', 'c') == ntpath.join('a', 'b', 'c')
    assert sm.join_path('a\\', 'b', 'c') == ntpath.join('a', 'b', 'c')
    assert sm.join_path('a', 'b\\', 'c') == ntpath.join('a', 'b', 'c')

# Generated at 2022-06-11 16:43:56.718504
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_obj = ShellModule()
    assert shell_obj.get_remote_filename('/path/to/path.py') == 'path.py'
    assert shell_obj.get_remote_filename('/path/to/path.ps1') == 'path.ps1'
    assert shell_obj.get_remote_filename('/path/to/path.txt') == 'path.txt.ps1'
    assert shell_obj.get_remote_filename('/path/to/path') == 'path.ps1'

# Generated at 2022-06-11 16:44:02.262054
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellmodule = ShellModule()
    assert shellmodule is not None

# Generated at 2022-06-11 16:44:12.928189
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.six.moves import StringIO

    # A simple Plugins/Shells/ShellModule for testing.
    class SimpleShellModule(ShellModule):
        def __init__(self, *args, **kwargs):
            super(SimpleShellModule, self).__init__(*args, **kwargs)
            self.call_counts = {}
            self.test_methods = ['join_path', 'exists', 'checksum', 'chmod', 'chown', 'mkdtemp',
                                 'set_user_facl', 'expand_user', 'path_has_trailing_slash', 'get_remote_filename',
                                 'remove', 'wrap_for_exec', 'env_prefix', '_unquote', '_escape', '_encode_script']


# Generated at 2022-06-11 16:44:15.529007
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(connection=None, no_log=None, run_has_failed=None,
                         diff_quality=None, shell=None)

# Generated at 2022-06-11 16:44:21.318786
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj.SHELL_FAMILY == 'powershell'
    assert obj._IS_WINDOWS == True
    assert obj._SHELL_REDIRECT_ALLNULL == '> $null'
    assert obj._SHELL_AND == ';'
    assert obj.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:44:23.737300
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS == True


# Generated at 2022-06-11 16:44:28.707922
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()
    cmd = module.build_module_command('', '', 'ping', 'arg_path')
    assert "ping" in cmd
    assert "arg_path" in cmd
    assert "bootstrap_wrapper" in cmd



# Generated at 2022-06-11 16:44:34.680556
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with basic/minimal dicts
    test_dicts = [
        {},
        {'_ansible_version': '2.8.0', '_ansible_sysversion': '3.4.0'},
    ]
    for test_dict in test_dicts:
        shell = ShellModule(task_vars=test_dict)
        assert shell.env_prefix() == ''
        del shell

# Generated at 2022-06-11 16:44:41.109946
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Constructor of class ShellModule needs to be tested.
    # Currently, there is no way to get the output from a constructor. Need to
    # find a way to test this.
    module = ShellModule()
    assert module.DEFAULT_INTERPRETER_SHEBANG == ['#!powershell']
    module = ShellModule(runner=None)
    assert module.DEFAULT_INTERPRETER_SHEBANG == ['#!powershell']


# Generated at 2022-06-11 16:44:45.106067
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod
    assert hasattr(mod, 'run')
    assert hasattr(mod, 'join_path')
    assert hasattr(mod, 'mkdtemp')

    assert mod.run("echo 'hello'") == "hello"

# Generated at 2022-06-11 16:44:49.320406
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # __init__ for class ShellModule
    module = ShellModule()
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module._IS_WINDOWS

# Generated at 2022-06-11 16:44:55.097727
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    print(shell_obj)
    assert shell_obj is not None

# Generated at 2022-06-11 16:44:59.530043
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection='winrm')
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True

# Generated at 2022-06-11 16:45:02.976902
# Unit test for constructor of class ShellModule
def test_ShellModule():
    winUtils = ShellModule()
    # check if it is a Windows host, this test is for Windows host only
    assert winUtils._IS_WINDOWS == True, "Expected shell module to be initialized for a Windows host"

# Generated at 2022-06-11 16:45:11.239866
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    ps_module_script = "Write-Output 'module script'"

    shebang = '#!powershell'
    module = 'module'
    module_args = 'module args'
    env_string = '$env:var1 = "stuff"'
    module_path = 'c:/path/to/module'

    shell = ShellModule()
    script_encoded = shell.build_module_command(env_string, shebang, module, module_args)
    encoded_ps_module_script = shell._encode_script(script=ps_module_script, strict_mode=False, preserve_rc=False)

    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

# Generated at 2022-06-11 16:45:12.689837
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule()

# Generated at 2022-06-11 16:45:14.116059
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Constructor of class ShellModule.
    :return:
    """
    import ansible.executor.powershell.powershell as powershell

    powershell.ShellModule()

# Generated at 2022-06-11 16:45:18.911206
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert callable(shell.set_user_facl)
    assert isinstance(shell.SHELL_FAMILY, str)
    assert check_for_prompt(shell.DEFAULT_PROMPT)
    assert isinstance(shell.COMPATIBLE_SHELLS, list)

# Generated at 2022-06-11 16:45:21.196935
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Create a module instance and verify we get the expected class."""
    s = ShellModule(conn=None)
    assert isinstance(s, ShellModule)


# Generated at 2022-06-11 16:45:32.600073
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert hasattr(shell, '_SHELL_REDIRECT_ALLNULL')
    assert hasattr(shell, '_SHELL_AND')
    assert hasattr(shell, '_IS_WINDOWS')
    assert hasattr(shell, 'env_prefix')
    assert callable(shell.env_prefix)
    assert hasattr(shell, 'join_path')
    assert callable(shell.join_path)
    assert hasattr(shell, 'get_remote_filename')
    assert callable(shell.get_remote_filename)
    assert hasattr(shell, 'path_has_trailing_slash')
    assert callable(shell.path_has_trailing_slash)
    assert hasattr(shell, 'chmod')
    assert callable(shell.chmod)
    assert hasattr

# Generated at 2022-06-11 16:45:42.722680
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()

    # test script with shebang
    assert module.build_module_command('', '#!powershell', 'Get-Host') == \
        module._unquote(''.join([
            'if ($PSVersionTable.PSVersion.Major -ge 3) { Invoke-Expression (& {& ',
            module._encode_script(script='Get-Host', strict_mode=False, preserve_rc=False),
            '; exit $LASTEXITCODE } | Out-String) } else {',
            module._encode_script(script='Get-Host', strict_mode=False, preserve_rc=False),
            '; exit $LASTEXITCODE }']))

    # test script without shebang
    assert module.build_module_command('', None, 'Get-Host') == \
        module

# Generated at 2022-06-11 16:45:55.403559
# Unit test for constructor of class ShellModule
def test_ShellModule():
    _DummyShellModule = type('_DummyShellModule', (ShellModule,), shell=ShellModule)
    module = _DummyShellModule(connection=None)
    module.get_remote_filename('test.sh')

    # Test that expand_user is working for ~
    assert module.expand_user('~') == module._encode_script('Write-Output (Get-Location).Path')

    # Test that expand_user is working for ~\path
    assert module.expand_user('~\\path') == module._encode_script("Write-Output ((Get-Location).Path + '\\\\path')")

    # Test that expand_user is working for c:\path\to\file

# Generated at 2022-06-11 16:45:56.509340
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm=ShellModule()

# Generated at 2022-06-11 16:45:58.874636
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Return a test_module class."""
    return ShellModule('winrm')


# For backwards compat.
copy = test_ShellModule

# Generated at 2022-06-11 16:46:00.527718
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module is not None

# Generated at 2022-06-11 16:46:02.489990
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell

# Generated at 2022-06-11 16:46:11.827590
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import ansible.executor.powershell

    def test_data():
        exe = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

        if exe is None:
            return "powershell"
        else:
            return exe

    def test_data2():
        return '''#!powershell
$a = "hello"
$b = 'world'
Write-Host $a $b
'''

    def test_data3():
        return "whoami"

    # Test the data in the test_data function
    sm = ShellModule(connection=None, no_log=True)
    script = sm.build_module_command("", "", test_data())

    # We expect this to be a valid powershell command line that has the
    # PowerShell script

# Generated at 2022-06-11 16:46:14.989254
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.plugins.loader import find_plugin
    plugin = find_plugin('shell.ps1')
    assert plugin is not None
    assert plugin[1] == ShellModule

# Generated at 2022-06-11 16:46:16.370289
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    assert m.get_option('remote_tmp')

# Generated at 2022-06-11 16:46:17.765530
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:46:19.357403
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()


# Generated at 2022-06-11 16:46:37.681330
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()

# Generated at 2022-06-11 16:46:39.092609
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert isinstance(module, ShellModule)

# Generated at 2022-06-11 16:46:40.777173
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    assert shell._shell_type == 'powershell'

# Generated at 2022-06-11 16:46:42.017341
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule('', '', '')

# Generated at 2022-06-11 16:46:49.464881
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.compat.tests.mock import patch, Mock
    from ansible.executor import module_common

    # Constructor directly calls module_common.ShellModule.__init__
    # To test call of parent constructor we mock module_common.ShellModule.__init__
    with patch.object(module_common.ShellModule, '__init__', return_value=None) as mock_shell_module_init:
        shell_module = ShellModule(connection=None)
        assert mock_shell_module_init.called



# Generated at 2022-06-11 16:46:53.458878
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh_mod = ShellModule()
    assert isinstance(sh_mod, ShellBase)
    assert sh_mod._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sh_mod._SHELL_AND == ';'

# Generated at 2022-06-11 16:47:00.316064
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module
    assert ShellModule.COMPATIBLE_SHELLS == frozenset([])
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'

    assert module.env_prefix() == ""


# Generated at 2022-06-11 16:47:00.840446
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-11 16:47:01.661750
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    return obj

# Generated at 2022-06-11 16:47:14.255599
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Test with a dict of connection info
    cli_dict = dict(connection_info=dict(connector_hostname='host',
                                         connector_port=8080,
                                         username='user',
                                         password='password'))
    # Create a new ShellModule object
    shell_module = ShellModule(cli_dict)
    # Verify that the options dict and ShellModule object are equal
    assert shell_module.get_option('ssh_executable') is None
    assert shell_module.get_option('connection_info') == \
           dict(connector_hostname='host',
                connector_port=8080,
                username='user',
                password='password')
    assert shell_module.get_option('remote_tmp') == '/tmp'
    assert shell_module.get_option('remote_uid') == '0'

# Generated at 2022-06-11 16:47:26.821287
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.SHELL_NAME == 'powershell'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-11 16:47:28.235939
# Unit test for constructor of class ShellModule
def test_ShellModule():
    plugin = ShellModule()
    assert plugin is not None

# Generated at 2022-06-11 16:47:29.624092
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:47:39.089391
# Unit test for constructor of class ShellModule

# Generated at 2022-06-11 16:47:40.002475
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert isinstance(ShellModule(), ShellModule)

# Generated at 2022-06-11 16:47:44.497998
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Test case for constructor of class ShellModule"""

    myshell = ShellModule()
    assert myshell.COMPATIBLE_SHELLS == frozenset()
    assert myshell.SHELL_FAMILY == 'powershell'
    assert myshell._IS_WINDOWS

# Generated at 2022-06-11 16:47:45.978933
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:47:46.582128
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:47:52.732382
# Unit test for constructor of class ShellModule
def test_ShellModule():
    class TestShellModule(ShellModule):
        SHELL_NAME = 'powershell'

        def __init__(self, shell_executable, **kwargs):
            self.shell_executable = shell_executable
            self.shell_type = 'powershell'
            self.become = False
            self.become_method = None
            self.become_user = None
            # Set default value for ansible_shell_type because additional shell plugins
            # may not have it in module_args
            self.module_args['ansible_shell_type'] = 'powershell'
            super(TestShellModule, self).__init__(**kwargs)


# Generated at 2022-06-11 16:48:01.213530
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        data = pkgutil.get_data("ansible.errors", "winrm_unavailable.ps1")
    except IOError:
        data = None
    encoding = to_text(base64.b64encode(data.encode('utf-16-le')), 'utf-8')

    s = ShellModule()
    assert s is not None
    assert s._encode_script(script='$true', as_list=False) == u'PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command $true'
    assert s._encode_script(script='$true', as_list=True) == [u'PowerShell', u'-NoProfile', u'-NonInteractive', u'-ExecutionPolicy', u'Unrestricted', u'-Command', u'$true']
    assert s._encode_

# Generated at 2022-06-11 16:48:11.059776
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True

# Generated at 2022-06-11 16:48:21.355797
# Unit test for constructor of class ShellModule
def test_ShellModule():
    args = {
        'become_method': None,
        'become_user': None,
        'check': False,
        'diff': False,
        'extra_vars': [],
        'gather_subset': ['all'],
        'gather_timeout': 10,
        'inventory': None,
        'su': False,
        'subset': None,
        'su_user': None,
        'sudo': False,
        'sudo_user': None,
        'vault_password': None,
        'verbosity': 0
    }
    test_ShellModule = ShellModule(connection=None, ansible_shell_type='Powershell', ansible_shell_executable='/bin/powershell', **args)
    assert test_ShellModule is not None
    # Cleanup - Just in case

# Generated at 2022-06-11 16:48:23.336640
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module is not None

# Generated at 2022-06-11 16:48:24.427604
# Unit test for constructor of class ShellModule
def test_ShellModule():
    data = ShellModule()
    assert data

# Generated at 2022-06-11 16:48:24.880324
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:48:29.471874
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule(command_timeout=101, persistent_connect_timeout=102)
    assert s.command_timeout == 101
    assert s.persistent_connect_timeout == 102
    assert not s._SHELL_REDIRECT_ALLNULL == '> /dev/null'



# Generated at 2022-06-11 16:48:30.681262
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert hasattr(module, 'build_module_command')

# Generated at 2022-06-11 16:48:39.743488
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Build a shell
    powershell_shell = ShellModule(connection=None, no_log=None, shell_type=None, become_username=None, become_password=None, become_exe=None, become_flags=None, executable=None, stdin=None, stdout=None, stderr=None, environment=None)

    # Test object
    assert isinstance(powershell_shell, ShellModule)
    assert isinstance(powershell_shell._SHELL_AND, str)
    assert isinstance(powershell_shell._SHELL_REDIRECT_ALLNULL, str)
    assert isinstance(powershell_shell._IS_WINDOWS, bool)

#TODO: Unit test for encode_script
#TODO: Unit test for env_prefix

# Generated at 2022-06-11 16:48:45.924790
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert isinstance(sm, ShellModule)
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS
    assert SM._SHELL_REDIRECT_ALLNULL
    assert SM._SHELL_AND



# Generated at 2022-06-11 16:48:46.704192
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO: Add test
    pass

# Generated at 2022-06-11 16:48:58.445345
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    Create our shell plugin for testing.
    '''
    s = ShellModule()

# Generated at 2022-06-11 16:49:06.801993
# Unit test for constructor of class ShellModule

# Generated at 2022-06-11 16:49:10.300102
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule(connection=None, no_log=True, shell_executable=None)
    assert powershell.SHELL_FAMILY == 'powershell'
    assert isinstance(powershell, ShellModule) is True

# Generated at 2022-06-11 16:49:15.638566
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule._IS_WINDOWS
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert not ShellModule.COMPATIBLE_SHELLS

    s = ShellModule('connection')
    assert s.COMPATIBLE_SHELLS
    assert s._IS_WINDOWS
    assert s.SHELL_FAMILY == 'powershell'

    try:
        s = ShellModule('psrp', 'connection')
    except TypeError:
        pass


# Generated at 2022-06-11 16:49:16.216818
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:49:18.077754
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    Test the class constructor
    '''
    module = ShellModule()

    assert module is not None


# Generated at 2022-06-11 16:49:23.351685
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # For testing, we need to patch the '_executor.get_plugin_option' function
    # so we can stub out data rather than needing to have actual running
    # systems on the network.  We also need to patch the DLL loader so that
    # we can load our statically linked implementation of
    # System.Management.Automation.dll
    try:
        from unittest import mock
    except ImportError:
        import mock


# Generated at 2022-06-11 16:49:33.855618
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Here we need to mock the module struct for the plugin.
    # In this case, we mock it as print_output=True and run_is_verbose=True
    shell_module = ShellModule()
    shell_module.verbosity = 3
    shell_module.no_log = False
    shell_module.warn = True
    shell_module.connection = 'winrm'

    # Test that the verbose is set correctly in the options
    assert shell_module.get_option('verbose') is True

    # Test that the options are set correctly in the options
    assert shell_module.get_option('run_is_verbose') is True

    # Test that the options are set correctly in the options
    assert shell_module.get_option('print_output') is True

    # Test the connection plugin is set correctly
    assert shell_module

# Generated at 2022-06-11 16:49:34.740240
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-11 16:49:37.393166
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.path_has_trailing_slash("c:\\temp\\")
    assert not shell.path_has_trailing_slash("c:\\temp")

# Generated at 2022-06-11 16:49:59.653356
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Test to make sure that the constructor for ShellModule works."""
    # Create a test instance of ShellModule

# Generated at 2022-06-11 16:50:01.017554
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print(ShellModule())

# Generated at 2022-06-11 16:50:02.359101
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell is not None

# Generated at 2022-06-11 16:50:12.658929
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Test ShellModule constructor"""
    options = {'_ansible_shell_executable': 'powershell'}
    # Test no args
    shell = ShellModule(**options)
    assert shell.plugin_name == 'powershell'
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True

    # Test with args
    shell = ShellModule(**options)
    assert shell.plugin_name == 'powershell'
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell.plugin_options['remote_tmp'] == "$env:TMP"


# Generated at 2022-06-11 16:50:13.960133
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert(None != module)



# Generated at 2022-06-11 16:50:17.173202
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS

# Generated at 2022-06-11 16:50:22.239571
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''shell_test; construct class and test environment setup'''
    module = _get_shell()
    args = ['FAKE']
    if not module.HAS_PYWINRM:
        return 'SKIP (pywinrm is not installed)'

    module.HAS_PTY_SHELL = True
    result = module.generate_cmd(*args)
    if not result:
        return 'could not get cmd list'

    if not isinstance(result, list):
        return 'cmd is not a list'

    if not result[0].endswith('PowerShell'):
        return 'cmd does not end with PowerShell'

    if len(result) == 1:
        return 'cmd line has no arguments'


# Generated at 2022-06-11 16:50:27.690982
# Unit test for constructor of class ShellModule
def test_ShellModule():
    options = {
        'remote_tmp': '%TMP%',
    }
    shell = ShellModule(connection=None, runner=None, tmp=None, **options)
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-11 16:50:35.307745
# Unit test for constructor of class ShellModule
def test_ShellModule():
    cmd = ShellModule()
    #cmd.path_has_trailing_slash problem is not resolved
    assert cmd.join_path('c:\\', '_testdir_') == os.path.join('c:\\', '_testdir_')
    assert cmd.join_path('c:\\', '_testdir_', 'file.txt') == os.path.join('c:\\', '_testdir_', 'file.txt')
    assert cmd.set_user_facl('_testdir_', '_testu_', '_testfacl_') == "set_user_facl is not implemented for PowerShell"
    assert cmd.chown('_testdir_','_testu_') == "chown is not implemented for PowerShell"

# Generated at 2022-06-11 16:50:36.313918
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

# Generated at 2022-06-11 16:50:48.628390
# Unit test for constructor of class ShellModule
def test_ShellModule():
    x = ShellModule()
    assert isinstance(x, ShellModule)

# Generated at 2022-06-11 16:50:50.634413
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    path = '/path/to/somefile'
    out = module.join_path(path)
    assert out == path

# Generated at 2022-06-11 16:50:54.203180
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(connection=None, ansible_module_name='unit test')
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS

# Generated at 2022-06-11 16:51:01.109947
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import tempfile
    shell = ShellModule(connection=None, add_ssh_args=None,
                        safe_args_insert=0,
                        module_implementation_preferences=None)
    tempdir = tempfile.gettempdir()
    tempfile = shell.get_remote_filename(tempdir + '/tmpfile')
    assert tempfile == 'tmpfile.ps1'
    tempfile = shell.get_remote_filename(tempdir + '/tmpfile.ps1')
    assert tempfile == 'tmpfile.ps1'
    tempfile = shell.get_remote_filename(tempdir + '/bin/python')
    assert tempfile == 'python.ps1'

# Unit tests for _parse_clixml

# Generated at 2022-06-11 16:51:02.634303
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sc = ShellModule(connection=None)
    assert sc.family == 'powershell'

# Generated at 2022-06-11 16:51:04.398030
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    assert shell_module is not None

# Generated at 2022-06-11 16:51:09.558766
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm._IS_WINDOWS is True
    assert isinstance(sm._SHELL_AND, str)
    assert isinstance(sm._SHELL_REDIRECT_ALLNULL, str)

# Generated at 2022-06-11 16:51:11.349317
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    assert s.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:51:15.674906
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    for a in ['Command', 'Shell', 'Binary', 'Prompt', 'Kickstart', 'Terminal', 'Version', 'Env']:
        assert a in sm.SHELL_OPTS

# Generated at 2022-06-11 16:51:19.517782
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule(connection=None)
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS == True

