

# Generated at 2022-06-11 16:41:33.308820
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

# Generated at 2022-06-11 16:41:40.235906
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module = ShellModule()
    ans = shell_module.get_remote_filename('/a/b/c/d') == 'd.ps1'
    assert ans == True
    ans = shell_module.get_remote_filename('/a/b/c/d.ps1') == 'd.ps1'
    assert ans == True
    ans = shell_module.get_remote_filename('/a/b/c/d.exe') == 'd.exe'
    assert ans == True


# Generated at 2022-06-11 16:41:44.922607
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import ansible.plugins.connection.local
    from ansible.runner.task_result import TaskResult
    from ansible.playbook import PlayBook

    my_shell = ShellModule(connection=ansible.plugins.connection.local.Connection())
    my_shell.run(PlayBook(), TaskResult())

# Generated at 2022-06-11 16:41:56.504092
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    "Check the method get_remote_filename of class ShellModule"
    shell = ShellModule()
    assert shell.get_remote_filename('~/some/directory/file.exe') == 'file.exe'
    assert shell.get_remote_filename('~/some/directory/file.ps1') == 'file.ps1'
    assert shell.get_remote_filename('~/some/directory/script.foo') == 'script.foo.ps1'
    assert shell.get_remote_filename('/some/directory/file.ps1') == 'file.ps1'
    assert shell.get_remote_filename('/some/directory/file.exe') == 'file.exe'
    assert shell.get_remote_filename('/some/directory/script.foo') == 'script.foo.ps1'
    assert shell.get_remote

# Generated at 2022-06-11 16:42:06.254565
# Unit test for method mkdtemp of class ShellModule

# Generated at 2022-06-11 16:42:07.317048
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert isinstance(ShellModule(), ShellModule)

# Generated at 2022-06-11 16:42:13.511035
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_obj = ShellModule()
    cmd = shell_module_obj.build_module_command('', '', '', '')

    # Test the value of cmd
    assert cmd == "\n        \n        \n        \n        \n            \n            \n        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('')\n        $tmp = New-Item -Type Directory -Path $tmp_path -Name ''\n        Write-Output -InputObject $tmp.FullName\n        \n        "



# Generated at 2022-06-11 16:42:18.309402
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()

    assert shell.path_has_trailing_slash('c:\\Program Files\\') == True
    assert shell.path_has_trailing_slash('c:\\Program Files\\\\') == True
    assert shell.path_has_trailing_slash('c:\\Program Files') == False

    assert shell.path_has_trailing_slash('c:/Program Files/') == True
    assert shell.path_has_trailing_slash('c:/Program Files//') == True
    assert shell.path_has_trailing_slash('c:/Program Files') == False


# Generated at 2022-06-11 16:42:29.072455
# Unit test for method get_remote_filename of class ShellModule

# Generated at 2022-06-11 16:42:40.124263
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import itertools
    import pytest
    # Powershell is the only thing that supports this right now
    shell = ShellModule(None)

    # Generate combinations of test cases:
    #   - The remote home directory
    #   - The home directory path
    #   - The username
    test_cases = itertools.product(
        ['', '/home/remote_user'],
        ['', '~', '~/', '~/somedir', '~/somedir/somefile.txt'],
        ['', 'username'])

    for home_dir, home_path, username in test_cases:
        expected = home_path
        if expected != '~':
            if home_path == '~':
                expected = home_dir
            else:
                expected = home_dir + home_path[1:]


# Generated at 2022-06-11 16:42:55.370264
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule(connection=None, play_context=dict(become=False))

    # The ShellModule's expand_user method should output the correct result
    result = shell.expand_user("~", "USER")
    assert result == shell._encode_script("Write-Output (Get-Location).Path")

    # The ShellModule's expand_user method should output the correct result
    result = shell.expand_user("/home/USER", "USER")
    assert result == shell._encode_script("Write-Output '/home/USER'")

    # The ShellModule's expand_user method should output the correct result
    result = shell.expand_user("~/Documents", "USER")
    assert result == shell._encode_script("Write-Output ((Get-Location).Path + '/Documents')")


# Generated at 2022-06-11 16:43:07.478133
# Unit test for constructor of class ShellModule
def test_ShellModule():
    def check_results(result, test_case):
        assert result['invocation'].get_command() == test_case['command']
        if test_case.get('rc'):
            assert result['rc'] == test_case['rc']
        if test_case.get('stdout'):
            assert result['stdout'] == test_case['stdout']
        if test_case.get('stderr'):
            assert result['stderr'] == test_case['stderr']

    # Initialize module state
    shell = ShellModule()
    shell.noop_on_check(False)

    # Test escaped char with single quote

# Generated at 2022-06-11 16:43:09.376481
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """test_ShellModule: constructor of class ShellModule"""
    shell = ShellModule()
    assert shell != None

# Generated at 2022-06-11 16:43:20.190705
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    # Test no slash
    path = 'c:\\ansible'
    assert not shell.path_has_trailing_slash(path)
    # Test trailing slash
    path = 'c:\\ansible\\'
    assert shell.path_has_trailing_slash(path)
    # Test trailing single-quote
    path = "c:\\ansible\\'"
    assert shell.path_has_trailing_slash(path)
    # Test trailing double-quote
    path = 'c:\\ansible\\"'
    assert shell.path_has_trailing_slash(path)
    # Test trailing slash in string wrapped in single-quotes
    path = "'c:\\ansible\\'"
    assert shell.path_has_trailing_slash(path)
    # Test trailing slash

# Generated at 2022-06-11 16:43:22.363088
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Tests the constructor for class ShellModule"""

    # Fails when executable is provided
    assert ShellModule('powershell').executable == None

# Generated at 2022-06-11 16:43:33.651689
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Test native Windows path checks
    assert ShellModule(None).path_has_trailing_slash('C:\\dir\\')
    assert ShellModule(None).path_has_trailing_slash('C:\\dir\\\\')
    assert not ShellModule(None).path_has_trailing_slash('C:\\dir')
    assert not ShellModule(None).path_has_trailing_slash('C:\\dir\\\\')
    assert not ShellModule(None).path_has_trailing_slash('C:\\dir\\\\\\')
    # Test mixed slashes
    assert ShellModule(None).path_has_trailing_slash('C:\\dir/\\')
    assert ShellModule(None).path_has_trailing_slash('C:\\dir/\\\\')
    assert ShellModule(None).path_has

# Generated at 2022-06-11 16:43:44.427857
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    class MockGenerator(object):
        def __init__(self, testcase):
            self.testcase = testcase

        def __enter__(self):
            self.testcase.mock_generator_enter_count += 1
            return self

        def __exit__(self, type, value, traceback):
            self.testcase.mock_generator_exit_count += 1
            return False

        def __call__(self, **kwargs):
            self.testcase.mock_generator_call_count += 1
            res = self.testcase._mock_generator_function(**kwargs)
            return res

    import unittest
    import sys

    if 'ansible.module_utils.basic' in sys.modules:
        del sys.modules['ansible.module_utils.basic']


# Generated at 2022-06-11 16:43:54.443529
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import pkgutil
    import re
    import ansible.executor.powershell
    script = pkgutil.get_data('ansible.executor.powershell', 'bootstrap_wrapper.ps1').decode('utf-8')


# Generated at 2022-06-11 16:44:01.256023
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert not shell.path_has_trailing_slash(r'c:\abc')

# Generated at 2022-06-11 16:44:02.775918
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:44:09.544229
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Quick test for construction
    mymodule = ShellModule(connection=None, no_log=True)
    assert mymodule



# Generated at 2022-06-11 16:44:12.794896
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = pkgutil.get_data(__package__, 'powershell.exe')
    plugin = ShellModule(None, 'tmp', (0, 0), powershell, 'utf-8', False)
    assert(plugin.SHELL_FAMILY == 'powershell')

# Generated at 2022-06-11 16:44:18.970483
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    s = ShellModule()
    script = to_bytes(s.mkdtemp(basefile='', mode=None, tmpdir=None))
    pattern = re.compile(b'^New-Item -Type Directory -Path.* -Name [a-f0-9]{8}$')
    assert pattern.match(script)



# Generated at 2022-06-11 16:44:26.498349
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    s = ShellModule()
    # test for each possible platform encoding
    for encoding in [None, 'utf-8', 'utf-16-le', 'utf-16-be', 'utf-32-le', 'utf-32-be']:
        # test each possible user path with and without tilde expansion
        for user_home_path in [u'', u'~', u'~\\', u'~\\test', u'~0test', u'test0~', u'~\\test0~', u'~\\test~0~test']:
            if encoding:
                encoded_user_home_path = to_bytes(user_home_path, encoding)
            else:
                encoded_user_home_path = to_bytes(user_home_path)
            # test with a valid path and with an invalid path

# Generated at 2022-06-11 16:44:34.960837
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule(None)

# Generated at 2022-06-11 16:44:37.703726
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Test the constructor of the ShellModule() class."""

    sm = ShellModule()
    assert sm._IS_WINDOWS is True
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:44:45.420928
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection='ssh', no_log=True, become_method=None, become_user=None, become_exe=None,
                        become_flags=None, check=False, diff=None, executable=None, su=None, su_user=None,
                        su_exe=None, sudo=None, sudo_user=None, sudo_exe=None, sudo_flags=None, async_timeout=30,
                        pty=True, prompt=None, answer=None, connect_timeout=30, passwd=None,
                        encoder=None, decoder=None, module_implementation_preferences=None,
                        runner_facts=None, remote_tmp='~/.ansible/tmp', tmpdir=None)
    print(shell)



# Generated at 2022-06-11 16:44:48.134059
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS is True
    assert "sh" not in sm.COMPATIBLE_SHELLS

# Generated at 2022-06-11 16:44:50.888861
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    assert m.SHELL_FAMILY == 'powershell'
    assert m.COMPATIBLE_SHELLS == frozenset()
    assert m.env_prefix() == ''

# Generated at 2022-06-11 16:45:03.075626
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    from ansible.errors import AnsibleError
    from ansible.executor.powershell import ShellModule

    shell_module = ShellModule(temppath='/tmp/ansible/tempdir')

    # test without basefile
    try:
        result = shell_module.mkdtemp()
    except Exception as e:
        assert False, 'Unexpected exception: %s' % e

    # test with basefile
    try:
        result = shell_module.mkdtemp(basefile='basefile')
    except Exception as e:
        assert False, 'Unexpected exception: %s' % e

    # test with tmpdir
    try:
        result = shell_module.mkdtemp(tmpdir='/tmp/ansible/tempdir')
    except Exception as e:
        assert False, 'Unexpected exception: %s' % e

# Generated at 2022-06-11 16:45:14.882066
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj.SHELL_FAMILY == 'powershell'
    assert obj.COMPATIBLE_SHELLS == frozenset()
    assert obj._IS_WINDOWS is True
    assert obj._SHELL_REDIRECT_ALLNULL == '> $null'
    assert obj._SHELL_AND == ';'
    assert obj.get_option('remote_tmp') is None

# Unit tests for function _unquote

# Generated at 2022-06-11 16:45:20.635188
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Unit test for constructor of class ShellModule.
    """

    # Test 1: Default constructor
    test1_shell_mod = ShellModule()
    assert test1_shell_mod.COMPATIBLE_SHELLS == frozenset()
    assert test1_shell_mod.SHELL_FAMILY == 'powershell'
    assert test1_shell_mod._IS_WINDOWS == True

# Generated at 2022-06-11 16:45:29.816715
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert hasattr(ShellModule, 'chmod')
    assert hasattr(ShellModule, 'chown')
    assert hasattr(ShellModule, 'set_user_facl')
    assert hasattr(ShellModule, 'mkdtemp')
    assert hasattr(ShellModule, 'remove')
    assert hasattr(ShellModule, 'expand_user')
    assert hasattr(ShellModule, 'exists')
    assert hasattr(ShellModule, 'checksum')
    assert hasattr(ShellModule, 'join_path')
    assert hasattr(ShellModule, 'build_module_command')
    assert hasattr(ShellModule, 'wrap_for_exec')



# Generated at 2022-06-11 16:45:33.881305
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    assert m.SHELL_FAMILY == 'powershell'
    assert m._SHELL_AND == ';'
    assert m._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-11 16:45:37.508920
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule('/usr/bin/python', '/', [])

    # assert that Shell_exec is set to None
    assert sm.SHELL_EXEC == None

# Generated at 2022-06-11 16:45:45.274732
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    pm = ShellModule()
    ret = pm.build_module_command('', '#!powershell', 'Set-ExecutionPolicy Unrestricted -Scope CurrentUser;')
    assert len(ret.split()) == 5
    assert ret.split()[0].lower() == 'powershell'
    assert ret.split()[2].lower() == '-noninteractive'
    assert ret.split()[3].lower() == '-executionpolicy'
    assert ret.split()[4].lower() == 'unrestricted'

    # With binary module
    ret = pm.build_module_command('', '', 'Get-ChildItem', 'C:\\Windows\\System32\\')
    assert len(ret.split()) == 4
    assert ret.split()[2].lower() == '-command'
    assert ret.split()[3].lower()

# Generated at 2022-06-11 16:45:49.575689
# Unit test for constructor of class ShellModule
def test_ShellModule():
    runner = ShellModule(connection=None)
    assert runner._SHELL_REDIRECT_ALLNULL == '> $null'
    assert runner._IS_WINDOWS
    assert 'chmod' not in dir(runner)
    assert 'remove' in dir(runner)
    assert 'exists' in dir(runner)

# Generated at 2022-06-11 16:45:54.053626
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert 'powershell' == ShellModule.SHELL_FAMILY
    assert 'chmod' not in dir(ShellModule())
    assert 'chown' not in dir(ShellModule())
    assert 'set_user_facl' not in dir(ShellModule())
    assert 'remove' in dir(ShellModule())
    assert 'tests' in ShellModule.COMPATIBLE_SHELLS

# Generated at 2022-06-11 16:46:04.434964
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    def _test(shell_plugin, shebang, expected_cmd, cmd=None, arg_path=None):
        shell_plugin_class = type(shell_plugin)  # avoid pylint warning about unhashable instance
        shell_plugin.SHELL_FAMILY = 'powershell'  # for some reason tests are not running with this set
        expected_cmd = expected_cmd.strip()
        cmd = cmd.strip() if cmd else ''
        actual_cmd = shell_plugin.build_module_command('', shebang, cmd, arg_path)

        # check that build_module_command returns the expected command
        assert actual_cmd == expected_cmd, "Unexpected command: %r (expected %r)" % (actual_cmd, expected_cmd)

        # decode the command and remove redundant blank lines
        decoded_cmd = to_text

# Generated at 2022-06-11 16:46:08.545973
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    powershell = ShellModule()
    user_home_path = powershell.expand_user("~")
    assert user_home_path is not None
    assert type(user_home_path) is not str
    assert type(user_home_path) is not bytes

# Generated at 2022-06-11 16:46:17.582009
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:46:23.942083
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True

    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-11 16:46:31.265798
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    mock_self = type('', (), {'_unquote': lambda self, s: s})()

    set_1 = (('c:\\', True),
        ('\\\\server\\share\\', True),
        ('\\\\server\\share', False),
        ('C:\\', True),
        ('C:\\temp', False),
        ('C:\\temp\\', True),
        ('C:\\temp\\\\', True))

    for (path, expected) in set_1:
        result = ShellModule.path_has_trailing_slash(mock_self, path)
        assert result == expected


# Generated at 2022-06-11 16:46:34.257660
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule()
    print(powershell.__doc__)


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:46:39.006872
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert(shell._SHELL_REDIRECT_ALLNULL == '> $null')
    assert(shell._SHELL_AND == ';')
    assert(shell._IS_WINDOWS)


# Generated at 2022-06-11 16:46:46.831153
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import tempfile

    s = ShellModule()

    def _test(test_value, expected):
        result = s.expand_user(test_value)
        if not result.startswith('Write-Output'):
            raise ValueError("Returned value '%s' did not start with 'Write-Output'" % result)

        with tempfile.NamedTemporaryFile(mode='w') as test_file:
            test_file.write(result)
            test_file.flush()

            cmd = ['powershell', '-NoProfile', '-File', test_file.name]
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout, stderr = proc.communicate()

# Generated at 2022-06-11 16:46:51.872835
# Unit test for constructor of class ShellModule
def test_ShellModule():
    win_shell = ShellModule(connection=None,no_log=True)
    from ansible.plugins.connection.winrm import Connection
    # test Connection object
    assert isinstance(win_shell.connection,Connection)
    # test other attrs
    assert win_shell.remote_tmp == "C:\\Windows\\TEMP"

# Generated at 2022-06-11 16:46:59.672216
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS
    assert shell.env_prefix() == ''
    assert shell.join_path('/path/', 'to/file') == '/path/to/file'
    assert shell.get_remote_filename('/path/to/file.txt') == 'file.txt'
    assert shell.path_has_trailing_slash('/path/to/file.txt/')
    assert not shell.path_has_trailing_slash('/path/to/file.txt')

# Generated at 2022-06-11 16:47:11.236623
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    plugin = ShellModule(connection=None)
    assert plugin.expand_user("~") == '[System.Convert]::FromBase64String("UABzAGUAcwB0AGEAdABlAHIAXQBzAHQAcgBpAGIAdQB0AHkALgBjAG8AbQAvAHIAYQBuAHMAdABlAG0ALgBkAGkAbgBnAC8AYwBvAG0ALwBiAGEAdABvAHIA")'
    assert plugin.expand_user("~fake-user") == '"~fake-user"'
    assert plugin.expand_user("/home/fake-user/test") == '/home/fake-user/test'

# Generated at 2022-06-11 16:47:14.574443
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule(connection=None, ansible_playbook=None, options=None,
                    shell_type='powershell', become_method=None, become_user=None,
                    become_exe=None, become_flags=None, become_pass=None,
                    tmpdir=None, become_ask_pass=False)
    assert s.SHELL_FAMILY == 'powershell'



# Generated at 2022-06-11 16:47:23.014248
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pytest_shell = ShellModule(connection=None, shell_type='powershell', no_log=None)
    return pytest_shell

# Generated at 2022-06-11 16:47:26.762592
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # test with default args
    shell = ShellModule()

    # test with args
    shell = ShellModule(shell_type='powershell')

    # test with kwargs
    shell = ShellModule(**{})

    # test with kwargs
    shell = ShellModule(**{'shell_type': 'powershell'})

# Generated at 2022-06-11 16:47:29.369012
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Test is not valid until I can figure out how to mock the
    # execution of a powershell command.
    pass

# Generated at 2022-06-11 16:47:38.820226
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    base_shell = ShellModule(shell=None)

    # The following Home directories are based on the default user profile paths in
    # Windows 10 1709
    # C:\Users\username
    username = "username"
    user_home_path = "~"
    expected_script = 'Write-Output (Get-Location).Path'
    assert base_shell.expand_user(username=username, user_home_path=user_home_path) == expected_script

    # C:\Users\username\Desktop
    username = "username"
    user_home_path = "~\\Desktop"
    expected_script = "Write-Output ((Get-Location).Path + '\\Desktop')"
    assert base_shell.expand_user(username=username, user_home_path=user_home_path) == expected_script

    # C:\

# Generated at 2022-06-11 16:47:46.301058
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.shell import ShellModule

    module = AnsibleModule(argument_spec={})
    module.shell = ShellModule(executable='powershell.exe',
                               runas='testdomain\\myadminuser',
                               runas_password='password',
                               no_log=True,
                               become=True,
                               become_method='runas',
                               become_user='testdomain\\myadminuser',
                               become_password='password',
                               become_exe='',
                               remote_tmp='C:\\Windows\\Temp',
                               task_vars={})

    # run tests

# Generated at 2022-06-11 16:47:52.111862
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule('winrm', 'index_number', 'inventory_hostname', {}, {}, 'become_method')
    assert shell_module is not None
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._SHELL_AND == ';'
    assert shell_module._IS_WINDOWS == True
    # Assert the static methods
    assert shell_module.expand_user('~/test/path', '') == "Write-Output 'C:\\test\\path'"
    assert shell_module.expand_user('~\\test\\path', '') == "Write-Output ((Get-Location).Path + '\\test\\path')"

# Generated at 2022-06-11 16:48:00.380711
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()

    # if user_home_path is a valid windows path, return the user_home_path
    user_home_path = r'C:/test/test.txt'
    result1 = shell.expand_user(user_home_path, username='')
    assert result1 == shell._encode_script(user_home_path)

    # if user_home_path is not a valid windows path, return the default user home
    user_home_path = r'./test/test.txt'
    result2 = shell.expand_user(user_home_path, username='')
    assert result2 == shell._encode_script('Write-Output (Get-Location).Path')

    # if user_home_path is ~, return the default user home
    user_home_path = '~'


# Generated at 2022-06-11 16:48:08.585076
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():

    # Test expansion of ~ (~ is root directory)
    sh = ShellModule()
    assert sh.expand_user('~') == sh._encode_script('Write-Output (Get-Location).Path')

    # Test expansion of ~ followed by a path
    sh = ShellModule()
    assert sh.expand_user('~\\test') == sh._encode_script("Write-Output ((Get-Location).Path + '\\test')")

    # Test expansion of ~ followed by a path with a trailing slash
    sh = ShellModule()
    assert sh.expand_user('~\\test\\') == sh._encode_script("Write-Output ((Get-Location).Path + '\\test')")

    # Test expansion of non-tilde path
    # Test expansion of ~ followed by a path with a trailing slash
    sh = ShellModule()

# Generated at 2022-06-11 16:48:14.087284
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.shell.common import run_command

    (fd, temp_file) = tempfile.mkstemp(suffix='.ps1')
    os.close(fd)
    try:
        os.remove(temp_file)
    except OSError:
        pass

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.params['_ansible_verbosity'] = 3
    module._ansible_version = ('2.0', '2.0')
    module._ansible_no_log = False
    setattr(module, '_ansible_no_log', False)


# Generated at 2022-06-11 16:48:15.857274
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_mod_obj = ShellModule()


# Generated at 2022-06-11 16:48:21.254485
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert isinstance(shell, ShellModule)

# Generated at 2022-06-11 16:48:22.722104
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

# Generated at 2022-06-11 16:48:23.900909
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert type(ShellModule()) is ShellModule

# Generated at 2022-06-11 16:48:27.196890
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Given
    prs = ShellModule()

    # Then
    assert prs.SHELL_FAMILY == 'powershell'
    assert prs._IS_WINDOWS

# Generated at 2022-06-11 16:48:28.521050
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule is not None

# Generated at 2022-06-11 16:48:30.187896
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, add_docker_vars=False, task_uuid='')
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:48:31.562341
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule(None)
    assert m

# Generated at 2022-06-11 16:48:39.493089
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shm = ShellModule(connection=None)

    # Test the special powershell path handling
    assert shm.join_path('C:', 'Windows', 'System32') == 'C:\\Windows\\System32'
    assert shm.join_path('C:\\', '\\', 'Windows', '\\', 'System32\\') == 'C:\\Windows\\System32'
    assert shm.join_path('C:\\Windows\\', '\\Program Files\\') == 'C:\\Windows\\Program Files'
    assert shm.join_path('C:\\Windows\\', '\\Program Files\\', '\\') == 'C:\\Windows\\Program Files'

# Generated at 2022-06-11 16:48:46.640259
# Unit test for constructor of class ShellModule
def test_ShellModule():
    win_shell = ShellModule(connection=None, no_log=True)
    assert win_shell.COMPATIBLE_SHELLS == frozenset()
    assert win_shell._IS_WINDOWS
    assert win_shell.SHELL_FAMILY == 'powershell'
    assert win_shell.build_module_command(env_string='', shebang='', cmd='')


# Generated at 2022-06-11 16:48:48.106890
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-11 16:49:00.815400
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS

# Generated at 2022-06-11 16:49:01.496404
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()

# Generated at 2022-06-11 16:49:02.623424
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_obj = ShellModule(connection=None)

# Generated at 2022-06-11 16:49:08.176330
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create an instance of ShellModule
    host_data = {}
    shell_module = ShellModule(connection=None, host_data=host_data)

    # Test the constructor of ShellModule
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()



# Generated at 2022-06-11 16:49:09.749352
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    print(shell.get_option('remote_tmp'))

# Generated at 2022-06-11 16:49:13.738872
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    sm.join_path('/a', '/b/')
    sm.set_user_facl(['/a'], 'foo', 'bar')
    sm.path_has_trailing_slash('/a/b/')

# Generated at 2022-06-11 16:49:18.525546
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS
    assert shell.env_prefix() == ""
    assert shell.join_path('foo', 'bar') == 'foo\\bar'
    # TODO: add more asserts
    # TODO: add asserts for other functions



# Generated at 2022-06-11 16:49:20.259320
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule is not None, 'ShellModule class cannot be None'


# Generated at 2022-06-11 16:49:31.018251
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    # Check if the shell class is inherited from ShellBase
    assert isinstance(shell, ShellBase)
    # _encode_script()
    assert shell.wrap_for_exec('') == '&  ; exit $LASTEXITCODE'
    assert shell.wrap_for_exec('a') == '& a ; exit $LASTEXITCODE'
    assert shell.wrap_for_exec('a b') == '& a b ; exit $LASTEXITCODE'
    # _escape()
    assert shell._escape("'") == "''"
    assert shell._escape("'a'") == "''a''"
    assert shell._escape("''") == ''''''
    # _unquote()
    assert shell._unquote("'a'") == "a"
    assert shell._

# Generated at 2022-06-11 16:49:32.610225
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj != None

# Generated at 2022-06-11 16:50:00.962478
# Unit test for constructor of class ShellModule
def test_ShellModule():
    class MockPlugin(object):
        _shell_type = 'powershell'

    plugin = MockPlugin()
    shell_obj = ShellModule(plugin)
    assert shell_obj
    assert shell_obj.SHELL_FAMILY == u'powershell'
    assert shell_obj._is_pipelining_enabled() is False
    assert shell_obj.SHELL_COMMAND_RETRY_TIMER == float(1.0)
    assert shell_obj.SHELL_COMMAND_RETRY_RETRIES == int(0)



# Generated at 2022-06-11 16:50:03.032780
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.name == 'powershell'

# Generated at 2022-06-11 16:50:05.315288
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS is True

# Generated at 2022-06-11 16:50:08.104475
# Unit test for constructor of class ShellModule
def test_ShellModule():
    if os.name == 'nt':
        import ansible.plugins.connection.winrm
        ansible.plugins.connection.winrm.ShellModule
        return 0
    else:
        return 1

# Generated at 2022-06-11 16:50:08.713259
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:50:11.117756
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod.SHELL_FAMILY == 'powershell'
    assert mod._shell_executable == 'powershell'

# Generated at 2022-06-11 16:50:15.767720
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module._IS_WINDOWS is True
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:50:19.943001
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule('winrm', '/usr/bin/powershell', 'path')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.plugin_args == {}
    assert shell.plugin_class == 'ShellModule'

# Generated at 2022-06-11 16:50:20.498976
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:50:21.395362
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule() is not None

# Generated at 2022-06-11 16:51:11.189943
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert hasattr(ShellModule(None), 'get_option')
    assert hasattr(ShellModule(None), 'chmod')
    assert hasattr(ShellModule(None), 'chown')
    assert hasattr(ShellModule(None), 'join_path')
    assert hasattr(ShellModule(None), 'set_user_facl')
    assert hasattr(ShellModule(None), 'remove')
    assert hasattr(ShellModule(None), 'mkdtemp')
    assert hasattr(ShellModule(None), 'expand_user')
    assert hasattr(ShellModule(None), 'exists')
    assert hasattr(ShellModule(None), 'checksum')
    assert hasattr(ShellModule(None), 'build_module_command')
    assert hasattr(ShellModule(None), 'wrap_for_exec')



# Generated at 2022-06-11 16:51:13.681874
# Unit test for constructor of class ShellModule
def test_ShellModule():
    x = ShellModule(None, None, None)
    assert x.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:51:14.679860
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:51:19.185982
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import tempfile
    temp_path = tempfile.gettempdir()
    shell = ShellModule(connection=dict(module_implementation_preferences=[]), runner_connection_class=None)
    assert isinstance(shell, ShellModule)
    assert not temp_path.endswith('\\')
    temp_path += '\\'
    assert shell.join_path(temp_path, 'test1.txt') == temp_path+'test1.txt'
    assert shell.join_path(temp_path, 'test2.txt') == temp_path+'test2.txt'



# Generated at 2022-06-11 16:51:22.933116
# Unit test for constructor of class ShellModule
def test_ShellModule():
    x = ShellModule()
    assert x.shebang == '#!powershell'
    x = type('obj', (object,), {'connection': 'winrm'})
    print(ShellModule.load_plugin(x, None))
    assert 'ShellModule' in ShellModule.load_plugin(x, None)

# Generated at 2022-06-11 16:51:24.516546
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule('')
    assert shell_module is not None


# Generated at 2022-06-11 16:51:25.124365
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()