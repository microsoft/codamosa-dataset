

# Generated at 2022-06-11 16:41:34.954715
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell._SHELL_REDIRECT_ALLNULL.startswith('>')
    assert shell._SHELL_AND == ';'
    assert shell._IS_WINDOWS
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.env_prefix() == ''

# Generated at 2022-06-11 16:41:39.002336
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    tmp = ShellModule()
    cmd = tmp.mkdtemp(basefile="", tmpdir="")
    assert cmd == b'New-Item -Type Directory -Path $env:TEMP | Write-Output;$tmp=$_;New-Item -Type Directory -Path $tmp_path -Name $tmp | Write-Output -InputObject $_.FullName\n'

# Generated at 2022-06-11 16:41:50.095074
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    assert ShellModule(None)._unquote(r'C:\Program Files') == r'C:\Program Files'
    assert ShellModule(None)._unquote(r'"C:\Program Files"') == r'C:\Program Files'

# Generated at 2022-06-11 16:41:55.561301
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    shell_command = module.join_path('fakedir', 'fakefile')
    assert shell_command == r'fakedir\fakefile'

    shell_command = module.join_path('fakedir', 'fakefile\\')
    assert shell_command == r'fakedir\fakefile'

# Generated at 2022-06-11 16:42:05.838541
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import ansible.executor.powershell.ShellModule as SM
    s = SM()
    s._IS_WINDOWS = True
    # assert s.expand_user("~/foo") == s._escape("$HOME\\foo")
    assert s.expand_user("~") == s._encode_script("Write-Output (Get-Location).Path")
    assert s.expand_user("~\\foo") == s._encode_script("Write-Output ((Get-Location).Path + '\\foo')")
    assert s.expand_user("foo") == s._encode_script("Write-Output 'foo'")
    assert s.expand_user("~/foo", "ansible_user") == s._encode_script("Write-Output (Get-Location).Path + '\\foo'")
    assert s.expand

# Generated at 2022-06-11 16:42:14.464038
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    module = ShellModule()
    assert module.expand_user('~') == module._encode_script('Write-Output (Get-Location).Path')
    assert module.expand_user('~', 'username') == module._encode_script('Write-Output (Get-Location).Path')
    assert module.expand_user('~user', 'username') == module._encode_script("Write-Output '~user'")
    assert module.expand_user('~\\foo.txt') == module._encode_script("Write-Output ((Get-Location).Path + '\\foo.txt')")
    assert module.expand_user('f:\\foo.txt') == module._encode_script("Write-Output 'f:\\foo.txt'")

# Generated at 2022-06-11 16:42:18.962823
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create object of ShellModule class
    ShellModule_obj = ShellModule()

    # Call the method get_remote_filename
    ShellModule_obj.get_remote_filename("C:\\Windows\\Temp\\ansible-tmp-1529475354.54-225742868269094\\")

# Generated at 2022-06-11 16:42:20.769745
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert hasattr(obj, 'run')


# Generated at 2022-06-11 16:42:27.712509
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, become_method=None, become_user=None, become_exe=None, become_flags=None, no_log=False, check=False, executable=None, stdin=None, stdin_add_newline=True,
        strip_prompt=True, respond_cache=None, ansible_shell_type='powershell', ansible_shell_executable='powershell', ansible_shell_executable_arg=None)
    return True

# Generated at 2022-06-11 16:42:34.995181
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellmodule = ShellModule()
    assert shellmodule.get_remote_filename("/home/foo.txt") == "foo.txt"
    assert shellmodule.get_remote_filename("/home/foo") == "foo.ps1"
    assert shellmodule.get_remote_filename("/home/foo.exe") == "foo.exe"
    assert shellmodule.get_remote_filename("/home/foo.ps1") == "foo.ps1"

    assert shellmodule.join_path("/home/foo", "bar.txt") == "/home/foo/bar.txt"
    assert shellmodule.join_path("/home/foo", "", "bar.txt") == "/home/foo/bar.txt"
    assert shellmodule.join_path("/home/foo", "") == "/home/foo"

# Generated at 2022-06-11 16:42:42.339814
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert type(shell_module) == ShellModule

# Generated at 2022-06-11 16:42:54.079547
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    # ShellModule(self, connection, *args, **kwargs)
    #   connection:      connection object
    #   args:            currently unknown use case
    #   kwargs:
    #       'gather_facts':         Gathering facts from the remote host.
    #       'module_name':          The name of the module being executed.
    #       'tmp':                  Temporary directory for this execution.
    #       'remote_tmp':           Temporary directory for this execution on the remote host.
    #       'fail_json':            Error-reporting method from the module code.
    #       'debug':                Debug mode.
    #       'no_log':               Suppress logging on the remote host.
    #       'data':                 Data passed to the module.
    #       'incremental_connection':
    #      

# Generated at 2022-06-11 16:42:54.655679
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()

# Generated at 2022-06-11 16:42:56.417544
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    assert shell.SHELL_FAMILY == 'powershell'
    return shell

# Generated at 2022-06-11 16:43:08.430147
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # FIXME: this test is no longer valid as the PowerShell code is no longer passed through shellwraps

    # Inject a mock object to replace the real "self"
    class MockSelf(object):
        _IS_WINDOWS = True
        _SHELL_REDIRECT_ALLNULL = '> $null'

        def get_option(self, option):
            return '/tmp/ansible-tmp'

        def _encode_script(self, script, as_list=False, strict_mode=True, preserve_rc=True):
            # Simulate the method of build_module_command that is called from powershell
            if not as_list:
                script = ''.join(script.splitlines())

# Generated at 2022-06-11 16:43:19.709604
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Initialize the ShellModule, then test whether the methods in ShellModule are implemented.
    # We do this by trying to call the methods and seeing if they raise a NotImplementedError
    shell = ShellModule()
    for m in ['env_prefix', 'join_path', 'get_remote_filename', 'path_has_trailing_slash',
              'chmod', 'chown', 'set_user_facl', 'remove', 'mkdtemp', 'expand_user',
              'exists', 'checksum', 'build_module_command', 'wrap_for_exec', '_unquote',
              '_escape', '_encode_script']:
        callit = getattr(shell, m)

# Generated at 2022-06-11 16:43:30.329034
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    ''' returns ansible module command as bytes to execute in a PowerShell session '''
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO
    from ansible.module_utils.powershell.executor import ShellModule

    powershell_module_shebang = "#!powershell"
    powershell_script_shebang = "#!not-powershell"
    powershell_script_path = "/path/to/script.ps1"
    executable_path = "/path/to/script.exe"

    env_string = "some_powershell_env_variable=42"
    cmd = "some_powershell_code args ...; exit $res; #"

    module = ShellModule(None, None, None)
    module_likely_path = module

# Generated at 2022-06-11 16:43:36.891362
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    module = ShellModule()

# Generated at 2022-06-11 16:43:40.517831
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(None)
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._IS_WINDOWS


# Generated at 2022-06-11 16:43:44.582584
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create an object of class ShellModule
    shell_obj = ShellModule()

    cmd = 'Write-Host "Hello World"'
    (rc, out, err) = shell_obj.exec_command(cmd)
    print(rc, out, err)


# Generated at 2022-06-11 16:44:03.109621
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create a fake play context
    class Options(object):
        become = False
        become_method = None
        become_user = ''
        become_flags = ''
        become_exe = ''
        become_pass = ''
        module_path = ''
        remote_tmp = '~/.ansible/tmp'
        listtags = False
        listtasks = False
        listhosts = False
        syntax = False
        module_compression = 'gzip'
        diff = False
        check = False
        connection = 'ssh'
        ansible_check_hostname = True
        ansible_host_key_checking = False
        private_key_file = "/path/to/rsa/file"
    class Task(object):
        become_user = ''
        no_log = False
        run_once = False
       

# Generated at 2022-06-11 16:44:12.317681
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('c:/foo/bar/')
    assert shell.path_has_trailing_slash('c:/foo/bar\\')
    assert not shell.path_has_trailing_slash('c:/foo/bar')

# Function to unit test method _encode_script of class ShellModule
# The unit test of encode_script is a little bit different than the usual ones
# because the result of the method encode_script is passed to the module as
# a command that is run by the shell, so it is not possible to just return
# an expected value that can be compared to the result of the method

# Generated at 2022-06-11 16:44:23.552412
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_obj = ShellModule()

    # Verify path_has_trailing_slash for path C:\
    assert shell_obj.path_has_trailing_slash('C:\\') is False

    # Verify path_has_trailing_slash for path C:\dir\
    assert shell_obj.path_has_trailing_slash('C:\\dir\\') is True

    # Verify path_has_trailing_slash for path C:\dir\
    assert shell_obj.path_has_trailing_slash('C:\\dir/') is True

    # Verify path_has_trailing_slash for path \\server\share\
    assert shell_obj.path_has_trailing_slash('\\\\server\\share\\') is True

    # Verify path_has_trailing_slash for path \\server\

# Generated at 2022-06-11 16:44:27.678865
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm._IS_WINDOWS

# Generated at 2022-06-11 16:44:29.538776
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Test if ShellModule is created properly"""
    shell_obj = ShellModule()
    assert shell_obj is not None

# Generated at 2022-06-11 16:44:36.503637
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection='winrm', no_log=True)
    assert shell.connection == 'winrm'
    assert shell.no_log is True
    assert shell._IS_WINDOWS is True
    assert shell.SHELL_FAMILY == 'powershell'
    assert len(shell.COMPATIBLE_SHELLS) == 0
    assert set(shell.SHELL_FAMILY) == set(['powershell'])

# Generated at 2022-06-11 16:44:41.093981
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Test constructor
    powershell = ShellModule()

    # Test attributes
    assert powershell.SHELL_FAMILY == 'powershell'
    assert powershell.COMPATIBLE_SHELLS == frozenset()
    assert powershell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert powershell._SHELL_AND == ';'
    assert powershell._IS_WINDOWS



# Generated at 2022-06-11 16:44:44.417866
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(command_name='powershell')
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:44:46.130143
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)

# Generated at 2022-06-11 16:44:48.800063
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    print('ShellModule: %s' % sm)

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-11 16:45:02.357843
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True


# Generated at 2022-06-11 16:45:11.020092
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test instantiating ShellModule
    shell = ShellModule()

    # Test join_path
    assert shell.join_path("C:\\foo", "bar", "baz") == "C:\\foo\\bar\\baz"
    assert shell.join_path("C:\\foo\\", "bar", "baz") == "C:\\foo\\bar\\baz"
    assert shell.join_path("C:\\foo", "bar", "baz\\") == "C:\\foo\\bar\\baz\\"
    assert shell.join_path("C:\\foo\\", "bar", "baz\\") == "C:\\foo\\bar\\baz\\"
    assert shell.join_path("C:\\foo", "bar\\", "baz") == "C:\\foo\\bar\\baz"
    assert shell.join

# Generated at 2022-06-11 16:45:18.105687
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_shell = ShellModule()
    assert(test_shell.COMPATIBLE_SHELLS == frozenset())
    assert(test_shell.SHELL_FAMILY == 'powershell')
    assert(test_shell._IS_WINDOWS == True)
    assert(test_shell._SHELL_REDIRECT_ALLNULL == '> $null')
    assert(test_shell._SHELL_AND == ';')


# Generated at 2022-06-11 16:45:19.604987
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """ Test ShellModule constructor
    """
    s = ShellModule()
    assert s

# Generated at 2022-06-11 16:45:21.160466
# Unit test for constructor of class ShellModule
def test_ShellModule():
    xf = ShellModule()
    return isinstance(xf, ShellModule)


# Generated at 2022-06-11 16:45:28.248646
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Test constructor of ShellModule class"""
    # Don't include checksum_unix because we do not support that class
    shmod = ShellModule(command_timeout=123, plugin_args=dict(constant_time_delay=1.23))
    assert shmod.command_timeout == 123
    assert shmod.plugin_args['constant_time_delay'] == 1.23
    assert shmod.plugin_args['forks'] is None

# Unit tests for _escape function in class ShellModule

# Generated at 2022-06-11 16:45:40.214831
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    class_ = ShellModule
    class_.SHELL_FAMILY = 'powershell'

    i = class_()


# Generated at 2022-06-11 16:45:47.388589
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import copy
    import ansible.constants as C
    mod = ShellModule(load_plugins=False)

    orig_constants = copy.deepcopy(C.__dict__)
    # test defaults
    assert mod.DEFAULT_EXECUTABLE == 'powershell'
    assert mod.SHELL_FAMILY == 'powershell'

    # reset
    C.__dict__.clear()
    C.__dict__ = copy.deepcopy(orig_constants)
    del orig_constants
    del copy

# Generated at 2022-06-11 16:45:47.955917
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:45:49.695595
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # test whether the module is a binary
    # test whether module is a wrapper
    pass

# Generated at 2022-06-11 16:46:11.144824
# Unit test for method build_module_command of class ShellModule

# Generated at 2022-06-11 16:46:21.733590
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import tempfile

    temp_handle, temp_path = tempfile.mkstemp(prefix='ansible_shell_test')
    os.close(temp_handle)

    # Copied from lib/ansible/constants.py
    # These are needed for the module_replacer fixture to work
    # This is not a good pattern and should be changed in the future
    DEFAULT_MODULE_PATH = '~/.ansible/plugins/modules'
    DEFAULT_MODULE_NAME = 'command'
    DEFAULT_PATHS = ['/usr/share/ansible']
    MODULE_REPLACER = None

    for path in [path for path in DEFAULT_PATHS if os.path.isdir(path)]:
        if MODULE_REPLACER is not None:
            break

# Generated at 2022-06-11 16:46:22.564611
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

# Generated at 2022-06-11 16:46:24.555551
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    assert m.SHELL_FAMILY == 'powershell'
    assert m._IS_WINDOWS

# Generated at 2022-06-11 16:46:26.578232
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm != None
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-11 16:46:30.095769
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(command_name='test command name')
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'

# Generated at 2022-06-11 16:46:30.987372
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:46:31.664504
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:46:36.242595
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()
    result = module.build_module_command(
        u"$env:TEST = 'test'",
        u'#!/usr/bin/python',
        u'data = open(\'test\').read()',
        u'test'
    )
    assert result == '''& $env:TEST = 'test'; /usr/bin/python 'data = open(\\'test\\').read()' 'test'; exit $LASTEXITCODE'''

    result = module.build_module_command(
        u"$env:TEST = 'test'",
        u'#!/usr/bin/python',
        u'data = open(\'test\').read()',
        u'test'
    )

# Generated at 2022-06-11 16:46:39.826679
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'
    assert sm._IS_WINDOWS

# Generated at 2022-06-11 16:46:55.428380
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset([])

# Generated at 2022-06-11 16:47:04.489077
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Type: () -> Any
    # Testing that arguments are correctly escaped.
    # Powershell will not always give an error if the args are not quoted correctly
    # The -Command arg is not a string and can be tricky, quotes will be changed
    # to a backtick which will cause problems
    def test(module_name, module_args):
        shell = ShellModule()
        cmd = shell.build_module_command('', '#!powershell', module_name, module_args)
        return cmd

    # Powershell does not like if quotes are not prepended with a backtick
    # or if double-quotes are used to wrap the entire argument.

# Generated at 2022-06-11 16:47:07.223218
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Check that the constructor doesn't freak out if we call it with a nonexistent connection
    x = ShellModule('foo')
    assert x is not None

# Generated at 2022-06-11 16:47:11.189532
# Unit test for constructor of class ShellModule
def test_ShellModule():
    result = ShellModule(connection=None)

    assert result.COMPATIBLE_SHELLS == frozenset()
    assert result.SHELL_FAMILY == 'powershell'
    assert result._IS_WINDOWS is True

# Generated at 2022-06-11 16:47:13.662413
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert isinstance(shell, ShellModule)
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:47:15.458204
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    assert shell_obj.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:47:23.320341
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    ps_module = ShellModule()
    for module in ['setup', 'file', 'custom_module']:
        module_command = ps_module.build_module_command('env', None, 'type ' + module + '.ps1|./bootstrap_wrapper.ps1', None)
        assert module_command == '& type ' + module + '.ps1|./bootstrap_wrapper.ps1; exit $LASTEXITCODE'
        module_command = ps_module.build_module_command('env', None, 'type ' + module + '.ps1', None)
        assert module_command == '& type ' + module + '.ps1; exit $LASTEXITCODE'
    module_command = ps_module.build_module_command('env', '#!test', module + '.ps1', None)

# Generated at 2022-06-11 16:47:34.593778
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import io

    class TestShell(ShellModule):
        def __init__(self, **kwargs):
            self.args = kwargs

        def _exec_rc(self):
            """Simulate _exec_rc() by reading command's exit code from the output."""
            if self.args.get('use_binary_module'):
                # For binary modules make-believe cmd returns exit code 2
                return 2

            # Simulate cmd output:
            # {"failed": true, "msg": "Unexpected failure during module execution.", "output": "...", "rc": 1}
            # {"failed": false, "rc": 0, "changed": true, ...}
            stdout = self.args['_output']

# Generated at 2022-06-11 16:47:36.643615
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    assert shell.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:47:40.499016
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule(connection=None,become_method=None,become_username=None,become_password=None,su=None,su_user=None,su_pass=None)
    assert(s.SHELL_FAMILY == 'powershell')
    assert(s.COMPATIBLE_SHELLS == frozenset())


# Generated at 2022-06-11 16:48:10.008810
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    obj.join_path('test_base', 'test_path')
    obj.get_remote_filename('test_filename')
    obj.path_has_trailing_slash('test_trailing_slash')
    obj.chmod('test_chmod', 'test_mode')
    obj.chown('test_chown', 'test_user')
    obj.set_user_facl('test_user_facl', 'test_user', 'test_mode')
    obj.remove('test_remove', False)
    obj.mkdtemp(basefile='test_basefile', system=False, mode=None, tmpdir=None)
    obj.expand_user('test_home_path', 'test_user')
    obj.exists('test_path')
    obj.checksum

# Generated at 2022-06-11 16:48:11.729380
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    This is a simple test function that instantiates the ShellModule class.
    """
    ShellModule()

# Generated at 2022-06-11 16:48:21.736089
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()

    assert module.build_module_command('', '#!powershell', 'WinRM.psm1 Get-Command') == module.build_module_command('', '#!powershell', 'winrm.psm1 Get-Command')
    assert module.build_module_command('', '#!powershell', 'WinRM.psm1 Get-Command'), b'&'
    assert module.build_module_command('', '#!python', 'Install-Module -Name Ansible -Force'), b'& python "Install-Module -Name Ansible -Force"'

# Generated at 2022-06-11 16:48:24.890028
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module = ShellModule()
    #compare instance shell module of class ShellModule
    assert isinstance(shell_module, ShellModule)

# Generated at 2022-06-11 16:48:29.472712
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_win_inst = ShellModule()

    assert shell_win_inst._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_win_inst._SHELL_AND == ';'
    assert shell_win_inst._IS_WINDOWS == True



# Generated at 2022-06-11 16:48:39.079306
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    '''
    Unit test for method build_module_command of class ShellModule
    '''
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.shell import ShellModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.powershell.become import BecomeModule
    from ansible.module_utils.powershell import ps_script_args

    loader = DataLoader()
    shell_plugin = ShellModule(None)
    become_plugin = BecomeModule(None)

    # Test wrapping of base module
    environ = ImmutableDict({
        'env1': 'value1',
        'env2': 'value2',
        'env3': 'value3',
        'env4': 'value4',
    })

# Generated at 2022-06-11 16:48:50.513531
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import os
    import tempfile
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils._text import to_bytes

    base_dir = os.path.dirname(__file__)
    test_files = ['sample_module.ps1', 'sample_module.py']
    test_files = [os.path.join(base_dir, x) for x in test_files]

    class _test_build_module_command(unittest.TestCase):
        def setUp(self):
            self.sm = ShellModule(connection='connection', shell_type='powershell', no_log=True)

# Generated at 2022-06-11 16:49:01.993147
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()
    assert p.SHELL_FAMILY == 'powershell'

    assert p.get_remote_filename('foo.ps1').lower() == 'foo.ps1'
    assert p.get_remote_filename('foo.py').lower() == 'foo.ps1'
    assert p.get_remote_filename('foo').lower() == 'foo.ps1'
    assert p.get_remote_filename('foo.txt').lower() == 'foo.ps1'
    assert p.get_remote_filename('foo.exe').lower() == 'foo.exe'
    assert p.get_remote_filename('foo.exe.1').lower() == 'foo.exe.1'


# Generated at 2022-06-11 16:49:11.363701
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create a new instance of the class ShellModule
    mytest = ShellModule()

    # Run a positive test
    result = mytest.run('c:\python27', '')
    assert result == {'rc': 1, 'stdout': '', 'stdout_lines': [], 'stdin': '', 'stderr': '', 'changed': False}

    # Run a negative test
    result = mytest.run("c:\python27", "dir c:\\")
    assert result == {'rc': 1, 'stdout': '', 'stdout_lines': [], 'stdin': '', 'stderr': '', 'changed': False}

# Generated at 2022-06-11 16:49:12.235367
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:49:40.361674
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    assert shell_obj.SHELL_FAMILY == 'powershell'
    assert shell_obj.COMPATIBLE_SHELLS == frozenset()
    assert shell_obj._IS_WINDOWS == True

# Generated at 2022-06-11 16:49:41.050049
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:49:50.725498
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    assert shell.SHELL_FAMILY == 'powershell'

    # Test _escape()
    assert shell._escape('a') == 'a'
    assert shell._escape("abc'abc") == "abc''abc"
    assert shell._escape("abc`abc") == "abc``abc"
    assert shell._escape('abc"abc') == 'abc""abc'

    # Test _unquote()
    assert shell._unquote('"a"') == 'a'
    assert shell._unquote("'a'") == 'a'

    # Test _encode_script()

# Generated at 2022-06-11 16:49:51.788234
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Instantiate
    ShellModule(connection=None, no_log=True, run_command_environ_update=None)

# Generated at 2022-06-11 16:49:52.450982
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

# Generated at 2022-06-11 16:49:55.144505
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-11 16:50:01.221674
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ps = ShellModule()
    assert ps.COMPATIBLE_SHELLS == frozenset()
    assert ps.SHELL_FAMILY == 'powershell'

    assert ps._SHELL_REDIRECT_ALLNULL == '> $null', 'Invalid value!'
    assert ps._SHELL_AND == ';', 'Invalid value!'
    assert ps._IS_WINDOWS is True, 'Invalid value!'


# Generated at 2022-06-11 16:50:04.799984
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True

# Generated at 2022-06-11 16:50:06.809737
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = dict(ANSIBLE_MODULE_ARGS='', ANSIBLE_MODULE_CONSTANTS='foo')
    ShellModule(module)

# Generated at 2022-06-11 16:50:09.904339
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS
    assert shell_module.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:50:54.283507
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule(connection=None)
    assert type(shell_obj) == ShellModule

# Generated at 2022-06-11 16:50:56.911403
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    # The check is implemented by _encode_script in the shell module
    shell._encode_script('#!/usr/bin/python')

# Generated at 2022-06-11 16:50:58.112222
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule(connection=None)
    assert sm is not None

# Generated at 2022-06-11 16:51:09.557889
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.plugins.shell.powershell import ShellModule

    m = ShellModule(command='Test', prompt=None, newline=None, answers=None,
                                    runner=None, running_as_administrator=False)
    assert m.get_remote_filename != None
    assert m.get_option != None
    assert m.set_option != None
    assert m.path_has_trailing_slash != None
    assert m.chmod != None
    assert m.chown != None
    assert m.set_user_facl != None
    assert m.remove != None
    assert m.mkdtemp != None
    assert m.expand_user != None
    assert m.exists != None
    assert m.checksum != None
    assert m.build_module_command != None
    assert m.wrap_

# Generated at 2022-06-11 16:51:13.109479
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:51:20.739256
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_args = {'_ansible_verbosity': 2,
                   '_ansible_version': '2.6.1.dev0',
                   '_ansible_no_log': False}
    obj = ShellModule(None, **module_args)
    assert obj.SHELL_FAMILY == 'powershell'
    assert obj._IS_WINDOWS is True
    assert obj._SHELL_AND == ';'
    assert obj._SHELL_REDIRECT_ALLNULL == '> $null'