

# Generated at 2022-06-11 16:41:47.591680
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # Test with a file that does not have .ps1 extension
    assert(ShellModule().get_remote_filename('file.yml') == 'file.yml.ps1')
    # Test with a file that has .ps1 extension
    assert(ShellModule().get_remote_filename('file.ps1') == 'file.ps1')
    # Test with a file that has no extension
    assert(ShellModule().get_remote_filename('file') == 'file.ps1')
    # Test with an empty file name
    assert(ShellModule().get_remote_filename('') == '.ps1')
    # Test with a file that already has .ps1 extension but with leading/trailing whitespace
    assert(ShellModule().get_remote_filename('  file.ps1   ') == 'file.ps1')

# Generated at 2022-06-11 16:41:48.330591
# Unit test for constructor of class ShellModule
def test_ShellModule():
    return ShellModule()

# Generated at 2022-06-11 16:42:00.797708
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Connect to an endpoint that doesn't actually exist to ensure we get a
    # failure when accessing stdout or stderr.
    fake_executor = dict(
        connection=dict(
            host='does-not-exist.local',
            port='12345',
            remote_user='nobody',
            password='secret',
            connection='winrm'
        ),
        options=dict(
            become=False,
            become_method=None,
            become_user=None,
        ),
        module_name='shell',
        task_uuid='fake',
    )

    shell = ShellModule(fake_executor)

    # Command is defined as empty, should return an empty string.
    assert shell._encode_script('') == ''


# Generated at 2022-06-11 16:42:11.879504
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # test for an empty string
    shell_module = ShellModule()
    assert shell_module.expand_user('', 'dummy_user') == shell_module._encode_script(script='Write-Output \'\'')

    # test for an existing directory
    script = r'''
        Write-Output ((Get-Location).Path + '\dummy_dir');
    '''
    shell_module = ShellModule()
    assert shell_module.expand_user(ntpath.join('~', 'dummy_dir'), 'dummy_user') == shell_module._encode_script(script.strip())

    # test for an existing directory inside ~
    shell_module = ShellModule()

# Generated at 2022-06-11 16:42:20.613009
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    module = ShellModule()
    assert _unwrap("%s") == module.expand_user("~")
    assert _unwrap("%s") == module.expand_user(".")
    assert _unwrap("%s") == module.expand_user("~/")
    assert _unwrap("%s") == module.expand_user("~/test")
    assert _unwrap("%s") == module.expand_user("~\\test")
    assert _unwrap("%s") == module.expand_user("test/test")
    assert _unwrap("%s") == module.expand_user("test\\test")


# Generated at 2022-06-11 16:42:23.997930
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Unit test class ShellModule"""
    shell_obj = ShellModule()
    # Testing path_has_trailing_slash function
    assert shell_obj.path_has_trailing_slash('/') is False

# Generated at 2022-06-11 16:42:33.084711
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    plugin = ShellModule()

    # The input `pathname` does not have extension or extension is not `.ps1`/`.exe`
    pathname1 = 'C:\\Users\\Administrator\\ansible_test.py'
    assert plugin.get_remote_filename(pathname1) == 'ansible_test.ps1'

    # The input `pathname` is a path without extension
    pathname2 = 'C:\\Users\\Administrator\\ansible_test'
    assert plugin.get_remote_filename(pathname2) == 'ansible_test.ps1'

    # The input `pathname` is a path with extension
    pathname3 = 'C:\\Users\\Administrator\\ansible_test.exe'
    assert plugin.get_remote_filename(pathname3) == 'ansible_test.exe'

# Generated at 2022-06-11 16:42:41.212608
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert 'pipeline.ps1' == shell.get_remote_filename('/etc/ansible/roles/devel/library/pipeline')
    assert 'pipeline.ps1' != shell.get_remote_filename('/etc/ansible/roles/devel/library/pipeline.ps1')
    assert 'pipeline.ps1' == shell.get_remote_filename('C:\\etc\\ansible\\roles\\devel\\library\\pipeline')
    assert 'pipeline.ps1' != shell.get_remote_filename('C:\\etc\\ansible\\roles\\devel\\library\\pipeline.ps1')
    assert 'pipeline.ps1' == shell.get_remote_filename('pipeline')

# Generated at 2022-06-11 16:42:48.740877
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Test default argument values
    shell = ShellModule()

    # Check that class object attributes are correctly set
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True
    assert shell.SHELL_FAMILY == 'powershell'

    # Check that instance attributes are set to default attributes
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._shell is None

# Generated at 2022-06-11 16:42:54.116272
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module._IS_WINDOWS == True
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-11 16:43:03.444749
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-11 16:43:12.723562
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # pylint: disable=unused-variable,expression-not-assigned

    # Set up a ShellModule instance with values in the options dictionary
    # that would normally be provided by the module runner.
    plugin = ShellModule()
    plugin.options = dict(
        remote_tmp='REMOTE_TMP',
        module_name='MODULE_NAME',
        task_vars=dict(
            TEST_VAR='TEST_VALUE'
        ),
        module_args='MODULE_ARGS'
    )
    plugin.noop_on_check(False)

    # Test the build_module_command method of the ShellModule class.
    #
    # The following test cases are executed:
    #
    #  * (1) '--shebang' is provided and is "#!powershell"
    #  * (2

# Generated at 2022-06-11 16:43:16.512436
# Unit test for constructor of class ShellModule
def test_ShellModule():
    plugin = ShellModule(connection=None)
    assert plugin._SHELL_REDIRECT_ALLNULL == '> $null'
    assert plugin._SHELL_AND == ';'
    assert plugin._IS_WINDOWS == True



# Generated at 2022-06-11 16:43:17.068543
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:43:20.546722
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_obj = ShellModule()

    assert shell_obj.SHELL_FAMILY == "powershell"
    assert shell_obj._IS_WINDOWS == True
    assert shell_obj.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-11 16:43:31.536802
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert(shell.COMPATIBLE_SHELLS == frozenset())
    assert(shell.SHELL_FAMILY == 'powershell')
    assert(shell._SHELL_REDIRECT_ALLNULL == '> $null')
    assert(shell._SHELL_AND == ';')
    assert(shell._IS_WINDOWS == True)
    assert(shell.env_prefix() == "")
    assert(shell.join_path('C:\\Temp', 'ansible', 'foo') == 'C:\\Temp\\ansible\\foo')
    assert(shell.get_remote_filename('/tmp/ansible.tar.gz') == 'ansible.tar.gz')
    assert(shell.path_has_trailing_slash('C:\\Temp\\') == True)

# Generated at 2022-06-11 16:43:32.783103
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule(connection=None)

# Generated at 2022-06-11 16:43:39.451077
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Verify the queuing of command works when it's pipelined
    assert "& " + "; ".join(_common_args) == ShellModule().wrap_for_exec("")
    # Verify the queuing of command works when it's non-pipelined
    encoded_script = to_text(base64.b64encode('Set-StrictMode -Version Latest\nWrite-Output HelloWorld'.encode('utf-16-le')), 'utf-8')
    non_pipeline_cmd = _common_args + ['-EncodedCommand', encoded_script]
    assert "& " + "; ".join(non_pipeline_cmd) + "; exit $LASTEXITCODE" == ShellModule().wrap_for_exec("Set-StrictMode -Version Latest\nWrite-Output HelloWorld")



# Generated at 2022-06-11 16:43:41.025254
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert isinstance(module, ShellModule)



# Generated at 2022-06-11 16:43:42.129627
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule({})
    assert sm

# Generated at 2022-06-11 16:43:54.914978
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj.COMPATIBLE_SHELLS == frozenset()
    assert obj.SHELL_FAMILY == "powershell"
    assert obj._IS_WINDOWS == True

# Generated at 2022-06-11 16:43:55.543957
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

# Generated at 2022-06-11 16:43:59.165144
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True



# Generated at 2022-06-11 16:44:00.249352
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

# Generated at 2022-06-11 16:44:02.029317
# Unit test for constructor of class ShellModule
def test_ShellModule():
    dut = ShellModule()
    assert dut.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:44:02.786815
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-11 16:44:04.358282
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:44:11.638759
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == dict()
    assert shell.DEFAULT_EXECUTABLE == 'powershell'
    assert shell.PATH_SEPARATOR == ';'
    assert shell.HAS_SYMLINKS == False
    assert shell.HAS_PIPE == True
    assert shell.HAS_TTY == True
    assert shell.SUPPORT_CHECK_MODE == True


# Generated at 2022-06-11 16:44:15.370383
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    assert m.COMPATIBLE_SHELLS == frozenset()
    assert m.SHELL_FAMILY == 'powershell'
    assert m._IS_WINDOWS is True


# Generated at 2022-06-11 16:44:17.044802
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule() is not None

# Generated at 2022-06-11 16:44:36.465286
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import tempfile
    import sys
    import os

    """
    Check that ShellModule.build_module_command works properly for different cases.

    These test cases cover three different ways to invoke a command:
        - execute a binary directly
        - execute a script on the remote machine (pipelining)
        - execute a script via the bootstrap script (non-pipelining)

    There are four cases that are important:
        - the command is not a module
        - the command is a module and pipelining is not used
        - the command is a module and pipelining is used
        - the command is a module and the shebang is Windows specific

    The last case is for a module like win_command which uses a Windows specific
    shebang so that it can bypass the bootstrap script.
    """
    # For testing purposes we will write temp files to the current

# Generated at 2022-06-11 16:44:37.857148
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print(ShellModule())


# Generated at 2022-06-11 16:44:44.781556
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    # New style modules
    shebang = '#!/usr/bin/python'
    cmd = '/path/to/python /path/to/ansible/lib/ansible/module_utils/basic.py arg1 arg2'
    # legacy modules
    shebang = '#!/bin/sh'
    cmd = '/bin/sh /path/to/ansible/hacking/test-module -m /path/to/ansible/lib/ansible/modules/system/ping arg1 arg2'
    shebang = None
    cmd = '/path/to/ansible/hacking/test-module -m /path/to/ansible/lib/ansible/modules/system/ping arg1 arg2'

# Generated at 2022-06-11 16:44:49.359434
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert getattr(shell, '_SHELL_REDIRECT_ALLNULL') == '> $null'
    assert getattr(shell, '_SHELL_AND') == ';'
    assert getattr(shell, '_IS_WINDOWS') == True
    pass

# Generated at 2022-06-11 16:44:50.293992
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell

# Generated at 2022-06-11 16:44:53.231411
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    This is a test of the constructor in ShellModule.
    """
    module = ShellModule(connection=dict())
    assert isinstance(module, ShellModule)



# Generated at 2022-06-11 16:44:58.115324
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'
    assert sm._IS_WINDOWS

# Generated at 2022-06-11 16:45:07.708811
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.plugins import shell_loader
    import ansible.executor.powershell
    import os
    import sys

    # Find the class name for a powershell shell plugin for a given host
    hostname = "windows"
    con_plugin = 'winrm'
    shell_name = 'powershell'
    loader, plugin_name, lookup_terms = shell_loader.find_plugin(con_plugin, shell_name)
    shell_class = loader.get(plugin_name)
    shell_class_instance = shell_class

    mod = ShellModule({}, {}, hostname, {}, None)
    assert isinstance(mod, ShellModule)

    assert mod._IS_WINDOWS and not mod._IS_POSIX

# Generated at 2022-06-11 16:45:08.271554
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-11 16:45:10.454538
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh = ShellModule()
    sh.expand_user("~")
    sh.join_path()
    pass

# Generated at 2022-06-11 16:45:35.254570
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:45:43.785491
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Constructor test for ShellModule class
    """
    if False:
        shell_module = ShellModule()
        shell_module._unquote('unquote')
        shell_module.join_path('zero', 'one', 'two', 'three')
        shell_module.get_remote_filename('zero')
        shell_module.path_has_trailing_slash('zero')
        # shell_module.chmod('zero', 'one')
        # shell_module.chown('zero', 'one')
        # shell_module.set_user_facl('zero', 'one', 'two')
        shell_module.remove('zero', True)
        shell_module.mkdtemp(basefile='zero', tmpdir='tmp')
        shell_module.expand_user('~', 'zero')
        shell_module.exists

# Generated at 2022-06-11 16:45:50.968761
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''Check the Shell Module constructor'''
    sm = ShellModule('/tmp', 'my_user', 'my_pass', 'my_port', 'my_host')
    assert sm._cwd == '/tmp'
    assert sm._user == 'my_user'
    assert sm._password == 'my_pass'
    assert sm._port == 'my_port'
    assert sm._host == 'my_host'
    assert sm._shell_plugin == 'shell_powershell'

# Unit Test for _unquote function

# Generated at 2022-06-11 16:45:52.606154
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell._shell_type == 'powershell'

# Generated at 2022-06-11 16:46:03.750537
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.plugins.shell.powershell as pshell
    import collections

    # create a new ShellModule instance & invoke the method
    m = pshell.ShellModule()

# Generated at 2022-06-11 16:46:05.709549
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert isinstance(module, ShellBase)



# Generated at 2022-06-11 16:46:09.738055
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test ShellModule class constructor.
    this_module = ShellModule()
    assert isinstance(this_module, ShellBase)
    assert this_module.SHELL_FAMILY == 'powershell'
    assert not this_module.COMPATIBLE_SHELLS
    assert this_module._IS_WINDOWS



# Generated at 2022-06-11 16:46:12.805447
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        ShellModule()
        assert True, "ShellModule instanstiated"
    except Exception as ex:
        assert False, "ShellModule not instanstiated due to error %s" %ex

# Generated at 2022-06-11 16:46:17.267425
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(None)   # pylint: disable=E1102

    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS

    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'



# Generated at 2022-06-11 16:46:24.047416
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shebang = "#!"
    module_path = os.path.expanduser("~/foo.ps1")
    module_command = "a b c"
    module_args = "d e f"

    wrapper_command = ShellModule.build_module_command("", shebang, module_path+" "+module_args)
    assert "a.ps1 d e f" in wrapper_command
    assert "Exit $LastExitCode" in wrapper_command

# Generated at 2022-06-11 16:47:06.031428
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()

# Generated at 2022-06-11 16:47:17.844084
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(connection=None)
    assert module.get_remote_filename('test') == 'test.ps1'
    assert module.path_has_trailing_slash('test\\')
    assert not module.path_has_trailing_slash('test')
    assert not module.path_has_trailing_slash('test/')
    assert module.join_path('test', 'subdir\\subsubdir') == 'test\\subdir\\subsubdir'
    assert module.join_path('test/', 'subdir\\subsubdir/') == 'test\\subdir\\subsubdir'
    assert module.expand_user('~test') == "$env:HOME + '\\test'"
    assert module.expand_user('~\\test') == "((Get-Location).Path + '\\test')"


# Generated at 2022-06-11 16:47:19.127734
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:47:27.279508
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

    bootstrap_wrapper_base64 = to_text(base64.b64encode(bootstrap_wrapper))

    cmd = "Find-File.ps1"
    shebang = None
    sm = ShellModule()

    result = sm.build_module_command("", shebang, cmd)

    expected_result = "& %s -EncodedCommand %s; exit $LASTEXITCODE" % (_common_args[0], bootstrap_wrapper_base64)

    assert result == expected_result, "Supplied cmd was not converted as expected"

# Generated at 2022-06-11 16:47:31.604338
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:47:32.937137
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert isinstance(shell, ShellModule)

# Generated at 2022-06-11 16:47:35.722309
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule(connection='smart', tmpdir='c:/tmp')
    assert s
    # Instantiate a shell plugin with the current directory as the TMPDIR
    s = ShellModule(connection='smart')
    assert s


# Generated at 2022-06-11 16:47:37.270212
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert isinstance(module, ShellModule)



# Generated at 2022-06-11 16:47:43.390875
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Constructor of ShellModule
    """
    # Test with no arguments
    obj = ShellModule()
    assert isinstance(obj, ShellModule)

    # Test with one argument
    obj = ShellModule(None)
    assert isinstance(obj, ShellModule)

    # Error test: when an argument has an invalid type
    with pytest.raises(TypeError):
        ShellModule(1)

    # Error test: when an argument is not a valid type
    with pytest.raises(TypeError):
        ShellModule(dict())



# Generated at 2022-06-11 16:47:44.210162
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule is not None

# Generated at 2022-06-11 16:49:17.534261
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    m = ShellModule()

    # Single command
    assert '& $PSHOME/Modules/Microsoft.PowerShell.Management/Microsoft.PowerShell.Management.psm1; exit $LASTEXITCODE' == m.build_module_command(None, '#!powershell', cmd='Microsoft.PowerShell.Management')

    # Multiple commands
    assert '& type "Microsoft.PowerShell.Management.psm1" | & $PSHOME/Modules/Microsoft.PowerShell.Management/Microsoft.PowerShell.Management.psm1; exit $LASTEXITCODE' == m._encode_script('type "Microsoft.PowerShell.Management.psm1" | $PSHOME/Modules/Microsoft.PowerShell.Management/Microsoft.PowerShell.Management.psm1')



# Generated at 2022-06-11 16:49:19.979433
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, add_shared_module=None)
    assert shell.COMPATIBLE_SHELLS == frozenset([])
    assert shell.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-11 16:49:28.084805
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    Unit test for constructor of class ShellModule.
    '''
    module = ShellModule()

    # Check the value of _IS_WINDOWS
    assert module._IS_WINDOWS == True

    # Check the value of SHELL_FAMILY
    assert module.SHELL_FAMILY == 'powershell'

    # Check the type of COMPATIBLE_SHELLS
    assert isinstance(module.COMPATIBLE_SHELLS, frozenset)

    # Check the value of the COMPATIBLE_SHELLS
    assert len(module.COMPATIBLE_SHELLS) == 0

# Generated at 2022-06-11 16:49:28.904955
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-11 16:49:30.523389
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert isinstance(ShellModule(), object)



# Generated at 2022-06-11 16:49:38.069469
# Unit test for constructor of class ShellModule
def test_ShellModule():
    config = dict(
        ansible_shell_type="powershell",
        ansible_shell_executable="",
        ansible_shell_executable_arguments="",
        ansible_shell_env={},
        ansible_shell_common_arguments=[],
        ansible_shell_replace_coreutils=True,
        ansible_shell_core_fix_replace=True,
        module_setup=dict(
            # insert common_arguments here
        ),
    )
    m = ShellModule(config=config)
    assert hasattr(m, '_IS_WINDOWS')
    assert hasattr(m, 'COMPATIBLE_SHELLS')
    assert m.COMPATIBLE_SHELLS == frozenset()
    assert hasattr(m, 'SHELL_FAMILY')

# Generated at 2022-06-11 16:49:41.074540
# Unit test for constructor of class ShellModule
def test_ShellModule():
    c = ShellModule(connection=None)

    assert c.COMPATIBLE_SHELLS == frozenset()
    assert c.SHELL_FAMILY == 'powershell'
    assert c._IS_WINDOWS == True

# Generated at 2022-06-11 16:49:50.725321
# Unit test for constructor of class ShellModule
def test_ShellModule():
    tester_instance = ShellModule()
    ShellModule._generate_temp_dir_name()
    tester_instance.join_path("/tmp/a")
    tester_instance.get_remote_filename("/tmp/a/b.txt")
    tester_instance.path_has_trailing_slash("/tmp/a/b.txt")
    tester_instance.path_has_trailing_slash("/tmp/a/b.txt/")
    tester_instance.chmod("/tmp/a/b.txt", 777)
    tester_instance.chown("/tmp/a/b.txt", "tom")
    tester_instance.set_user_facl("/tmp/a/b.txt", "tom", 777)

# Generated at 2022-06-11 16:50:02.040540
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.plugins.shell import ShellModule

    # Environment variables need to use the syntax '$env:VAR=VALUE'
    env = dict((to_text(envvar), to_text(val)) for envvar, val in os.environ.items())

    # Build the environment string for the powershell command
    env_str = ''
    for key, value in env.items():
        if value is not None:
            env_str += u"$env:%s='%s';" % (key, value.replace('\n', '\r\n'))
    # Windows uses $env:SystemRoot instead of $env:HOME
    if env_str and 'HOME' not in env and 'SystemRoot' in env:
        env_str += u'$env:HOME=$env:SystemRoot;'


# Generated at 2022-06-11 16:50:06.118799
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test C(SEP) for Windows
    s = ShellModule()
    assert s.SHELL_FAMILY == 'powershell'
    assert s.COMPATIBLE_SHELLS == frozenset()
    assert s._IS_WINDOWS



# Generated at 2022-06-11 16:51:23.919219
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._SHELL_AND == ';'
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._IS_WINDOWS == True


# Generated at 2022-06-11 16:51:29.338978
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Constructor for class ShellModule
    module = ShellModule()
    # Assert if value of '_IS_WINDOWS' is True
    assert module._IS_WINDOWS == True
    # Assert if value of '_SHELL_AND' is ';'
    assert module._SHELL_AND == ';'
    # Assert if value of '_SHELL_REDIRECT_ALLNULL' is '> $null'
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    # Assert if value of 'COMPATIBLE_SHELLS' is empty
    assert module.COMPATIBLE_SHELLS == frozenset()
    # Assert if value of 'SHELL_FAMILY' is 'powershell'
    assert module.SHELL_FAMILY == 'powershell'


# Unit test