

# Generated at 2022-06-11 16:41:41.664259
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import cStringIO
    import ansible.module_utils.powershell as powershell
    module_io = cStringIO()
    dummy_connection = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Create a new powershell ShellModule object
    shell_plugin_obj = powershell.ShellModule(dummy_connection)

    # Call expand_user

# Generated at 2022-06-11 16:41:47.179890
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pshell = ShellModule()
    # check it's an instance of ShellBase
    assert isinstance(pshell, ShellBase)
    # check it's an instance of ShellModule
    assert isinstance(pshell, ShellModule)
    # check it's the correct Shell Module class
    assert pshell.__class__.__name__ == 'ShellModule'


# Generated at 2022-06-11 16:41:50.488949
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    path = '~\\test'
    expected_output = 'Write-Output ((Get-Location).Path + \'\\\\test\')'
    assert expected_output == ShellModule().expand_user(path, '')

# Generated at 2022-06-11 16:42:02.681886
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule(connection=None)
    basefile = 'ansible-tmp-%s-%s' % (os.getpid(), 'tAFO.tAMO')
    system = False
    mode = None
    tmpdir = None

    # 1. Create a temp path with a custom base file name
    tmp_dir = 'C:\\Users\\testuser\\AppData\\Local\\Temp\\'
    answer = shell.mkdtemp(basefile=basefile, system=system, mode=mode, tmpdir=tmpdir)

    # 2. Test if the returned path is correct
    assert(answer.startswith('powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand'))

# Generated at 2022-06-11 16:42:04.790845
# Unit test for constructor of class ShellModule
def test_ShellModule():
    plugin = ShellModule()
    assert plugin.SHELL_FAMILY == 'powershell'
    assert plugin._IS_WINDOWS

# Generated at 2022-06-11 16:42:14.498422
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    temp_dir_name = "abcd"
    base_temp_dir = "C:/Temp"
    result = "C:/Temp/abcd"

    def exists(self, path):
        return self._encode_script("""
            if(Test-Path "%s")
            {
                Write-Output 0
                exit 0
            }
            else
            {
                Write-Output 1
                exit 1
            }
            """ % result)

    shell_module = ShellModule()
    shell_module.exists = exists.__get__(shell_module)

# Generated at 2022-06-11 16:42:23.739563
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Set up
    tmp_path_1 = 'C:\\Windows\\temp\\ansible-tmp-1503648058.69-183868996152403'
    tmp_path_2 = '/C/Windows/temp/ansible-tmp-1503648058.69-183868996152403'
    tmp_path_3 = '/C/Windows/temp/ansible-tmp-1503648058.69-183868996152403/'

    sm = ShellModule()

    # Check
    assert sm.join_path(tmp_path_1, tmp_path_2) == sm.join_path(tmp_path_1, tmp_path_3)

# Generated at 2022-06-11 16:42:30.720666
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shebang = "#!/usr/bin/env pip"
    cmd = "install ansible"

    args = {
        'as_list': True,
        'sanitize': False
    }

    # Run unit test
    cmd_runner = ShellModule(connection=None, **args)
    results = cmd_runner.build_module_command(shebang, cmd)

    print('TEST: %s' % results)

    assert results == "& '" + cmd + "'; exit $LASTEXITCODE"



# Generated at 2022-06-11 16:42:36.085363
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Normalize input and output paths on Windows using ntpath normpath
    shell = ShellModule()
    basefile = '1'

    # test without tmpdir
    script = to_text(shell.mkdtemp(basefile))
    assert script == "New-Item -Type Directory -Path $Env:TEMP -Name '1'"

    # test with tmpdir
    tmpdir = r"c:\temp"
    script = to_text(shell.mkdtemp(basefile, tmpdir=tmpdir))
    assert script == "New-Item -Type Directory -Path '%s' -Name '1'" % ntpath.normpath(tmpdir)

# Generated at 2022-06-11 16:42:37.255221
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()


# Generated at 2022-06-11 16:42:42.107345
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:42:45.614540
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        ShellModule()
    except Exception as e:
        assert False, "instance of ShellModule raised an exception"
    assert True, "instance of ShellModule did not raise an exception"


# Generated at 2022-06-11 16:42:47.938659
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    assert not s.review_content, "Failed to instantiate ShellModule object"



# Generated at 2022-06-11 16:42:52.174716
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    module = ShellModule(connection=None, runner_per_host=None)
    assert re.search(r'New-Item -Type Directory -Path .* -Name .*', module.mkdtemp().decode('utf-8'))

# Generated at 2022-06-11 16:42:58.001020
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # we need to do this to get decent output from pylint
    from ansible.plugins.shell import ShellBase
    shell_base_obj = ShellBase()
    shell_base_obj.EXPECTED_SHELLS = ['powershell']

    module_obj = ShellModule(shell_base_obj, 'powershell')

    assert module_obj._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module_obj._SHELL_AND == ';'
    assert module_obj._IS_WINDOWS == True

# Generated at 2022-06-11 16:43:09.686276
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # crate a new ShellModule
    powershell_test = ShellModule()
    assert powershell_test is not None

    # test if the shebang is correct
    assert powershell_test.shebang('/bin/test', '#!/bin/sh') == '#!/bin/sh'
    assert powershell_test.shebang('/bin/test', '#!/bin/test') == '#!powershell'

    # test if the common arguments of powershell are correct
    assert powershell_test.common_args == ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Unrestricted']

    # test if the basepath is correct
    accounts_path = r'C:\Users\Accounts'

# Generated at 2022-06-11 16:43:14.649686
# Unit test for constructor of class ShellModule
def test_ShellModule():
    def comparator(obj1, obj2):
        return obj1.__dict__ == obj2.__dict__
    powershell_obj = ShellModule()
    powershell_expected_obj = ShellModule()
    assert comparator(powershell_obj, powershell_expected_obj)

# Generated at 2022-06-11 16:43:18.611007
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_object = ShellModule()
    # Windows paths can contain either slash
    assert shell_object.path_has_trailing_slash('c:\\foo\\bar')
    assert shell_object.path_has_trailing_slash('c:/foo/bar')

# Generated at 2022-06-11 16:43:22.877770
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert ShellModule._IS_WINDOWS is True
    assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule._SHELL_AND == ';'



# Generated at 2022-06-11 16:43:24.705826
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell = ShellModule()
        assert True
    except:
        assert False



# Generated at 2022-06-11 16:43:39.040581
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.cli.adhoc import AdHocCLI as DeprecatedAdHocCLI
    from ansible.cli import CLI as NewAdHocCLI
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import tempfile
    import shutil

    def create_module(filename, content):
        file_path = os.path.join(temp_dir, 'test_modules', filename)
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

# Generated at 2022-06-11 16:43:48.196023
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module = ShellModule()
    # converts the following code to a powershell command
    #   $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
    #   $tmp = New-Item -Type Directory -Path $tmp_path -Name '%s'
    #   Write-Output -InputObject $tmp.FullName
    # where %s are replaced with the two parameters passed to the function mkdtemp call
    #   shell_module.mkdtemp(basefile, tmpdir)
    # the return is a powershell command that creates a directory using the basefile name
    # and the tmpdir path, then returns the created path
    #
    return shell_module.mkdtemp('basefile', tmpdir='C:\\temp')

# Generated at 2022-06-11 16:43:55.779088
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    filename = shell.get_remote_filename("/test/test.ps1")
    assert filename == "test.ps1"

    filename = shell.get_remote_filename("test.sh")
    assert filename == "test.ps1"

    filename = shell.get_remote_filename("test")
    assert filename == "test.ps1"

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 16:44:03.530208
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    fixture = '''
    - name: copy source to destination and then delete source
      become: true
      win_copy:
        src: C://testfile.txt
        dest: C://test2file.txt
        force: yes
      post_tasks:
      - name: delete copied source file
        win_file:
          path: C://testfile.txt
          state: absent
    '''
    inventory = 'localhost ansible_connection=local'

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

        def _load_params(self):
            args = load_fixture(fixture)
            for k, v in args.items():
                setattr(self, k, v)

    mock

# Generated at 2022-06-11 16:44:10.309201
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create an instance of ShellModule() class
    shell_module = ShellModule()

    # Check if the SHELL_FAMILY is set to 'powershell' as expected
    assert shell_module.SHELL_FAMILY == 'powershell'

    # Check if the IS_WINDOWS boolean is set to True
    assert shell_module._IS_WINDOWS == True

    assert shell_module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-11 16:44:21.676629
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    test_cases = [
        {
            "basefile": "somefile",
            "system": False,
            "mode": None,
            "tmpdir": None
        }
    ]

    shellModule = ShellModule()
    for test in test_cases:
        result = shellModule.mkdtemp(**test)
        r_basefile = re.compile(r".*New-Item.*?(?<!\\)somefile')")
        r_system = re.compile(r".*New-Item.*?(?<!\\)somefile')")
        r_mode = re.compile(r".*New-Item.*?(?<!\\)somefile')")
        r_tmpdir = re.compile(r".*New-Item.*?(?<!\\)somefile')")
        assert re

# Generated at 2022-06-11 16:44:30.083245
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    powershell_shell = ShellModule(connection=None, become_method=None)
    assert '\'' in powershell_shell.path_has_trailing_slash('/w')
    assert '\'' in powershell_shell.path_has_trailing_slash('/w/')
    assert '\'' in powershell_shell.path_has_trailing_slash('/w\'w')
    assert '\'' in powershell_shell.path_has_trailing_slash('/w"w/')


# Generated at 2022-06-11 16:44:37.631023
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import os
    from ansible.module_utils.six import PY2
    from ansible.executor.powershell.module_common import to_bytes
    basefile = 'test-' + __name__
    shell = ShellModule(connection=None, add_command_to_script=False, stdin=None)
    shell.DEFAULT_TMP = os.path.dirname(os.path.abspath(__file__))
    command = shell.mkdtemp(basefile=basefile)
    if PY2:
        command = command.encode('utf-8')
    stdout, stderr, rc = shell.run(command)
    assert rc == 0
    stdout = to_bytes(stdout)

# Generated at 2022-06-11 16:44:46.070824
# Unit test for constructor of class ShellModule
def test_ShellModule():
    script = 'Get-Process'
    connection = dict(ansible_connection='winrm', ansible_shell_type='powershell')
    m = ShellModule(None, script, **connection)
    # pylint: disable=protected-access
    assert m._shell._connection.become_method == 'runas'
    assert m._shell._connection.become_user == 'Administrator'
    assert m._shell._connection.become_pass == ''
    assert m._shell._connection.remote_addr == '127.0.0.1'
    assert m._shell._connection.remote_port == 5985
    assert m._shell._connection.transport == 'winrm'
    assert m._shell._connection.no_log is False
    assert m._shell._connection.winrm_server_cert_validation is 'ignore'


# Generated at 2022-06-11 16:44:57.283854
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_module = ShellModule()
    print("%s" % test_module._SHELL_REDIRECT_ALLNULL)
    print("%s" % test_module._SHELL_AND)
    assert(" " == test_module.env_prefix())
    assert(" $null" == test_module._SHELL_REDIRECT_ALLNULL)
    assert(";" == test_module._SHELL_AND)
    assert("c:\\test\\test.txt" == test_module.join_path("c:/", "test", "test.txt"))
    assert("c:\\test\\test.txt" == test_module.join_path("c:/test", "/test.txt"))
    assert("c:\\test\\test.txt" == test_module.join_path("c:/test/", "\\test.txt"))

# Generated at 2022-06-11 16:45:12.278364
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

    # Test replacing backslashes with slashes for windows paths
    assert sm.join_path('C:\\', 'Users', 'user1', 'Desktop') == 'C:/Users/user1/Desktop'
    assert sm.join_path('C:', '\\', 'Users', 'user1', 'Desktop') == 'C:/Users/user1/Desktop'
    assert sm.join_path('C:\\', '\\', 'Users', '\\', 'user1', '\\', 'Desktop') == 'C:/Users/user1/Desktop'

    win_path = 'C:\\Users\\user1\\Desktop\\example_file.txt'
    unix_path = 'C:/Users/user1/Desktop/example_file.txt'

# Generated at 2022-06-11 16:45:18.610851
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'

# Generated at 2022-06-11 16:45:25.728959
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    import ansible.executor.powershell as pshell_executor

    test_shebangs = [
        # { shebang: expected_result }
        { '#!powershell': 'type "{{ executable_arg }}" | ' + pshell_executor.ShellModule._encode_script(script=pshell_executor.bootstrap_wrapper, strict_mode=False, preserve_rc=False) },
        { '#!powershell': '-EncodedCommand {{ executable_arg }}' },
        { None: '{{ executable_arg }} {{ arg_path }}' },
        { '#!/bin/bash': '{{ executable_arg }} {{ arg_path }}' },
    ]

    for test_shebang in test_shebangs:
        shebang = next(iter(test_shebang))
        expected_result = test_she

# Generated at 2022-06-11 16:45:30.510996
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert 'Remove-Item' in list(shell_module.COMPATIBLE_SHELLS)[0]
    assert shell_module.__class__._IS_WINDOWS is True

# Generated at 2022-06-11 16:45:41.477886
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

    if not isinstance(shell, ShellModule):
        raise AssertionError('ShellModule instance expected')


# Generated at 2022-06-11 16:45:43.563895
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    shell_obj.get_option('remote_tmp')


# Generated at 2022-06-11 16:45:48.824475
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(None, None, None, 'winrm', None)
    shell.get_remote_filename('abc.txt')
    shell.path_has_trailing_slash('/tmp/test/')
    shell.path_has_trailing_slash('/tmp/test')
    shell.chmod(None, None)
    shell.chown(None, None)

# Generated at 2022-06-11 16:45:57.850728
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Arrange
    from ansible.executor.powershell.shell import _generate_temp_dir_name
    from ansible.executor.powershell.shell import ShellModule

    from ansible.module_utils._text import to_bytes

    basefile='Ansible_TEMP_DIR'
    tmpdir=r'C:\Windows\Temp'

    shell_module = ShellModule(None, None)
    shell_module._generate_temp_dir_name = _generate_temp_dir_name
    shell_module.get_option = lambda x: tmpdir
    shell_module._escape = lambda x: x

    #Act
    result=shell_module.mkdtemp(basefile=basefile, system=False, mode=None, tmpdir=None)

    #Assert

# Generated at 2022-06-11 16:45:58.496824
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:46:05.034863
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    sm = ShellModule()
    if sm:
        sm.get_option = lambda x: None
        sm._generate_temp_dir_name = lambda: 'ansiballz-test'
        script = sm.mkdtemp()
        assert script == b"$tmp_path = [System.Environment]::ExpandEnvironmentVariables('/tmp');\r\n$tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansiballz-test';\r\nWrite-Output -InputObject $tmp.FullName;\r\n"


# Generated at 2022-06-11 16:46:15.956755
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS



# Generated at 2022-06-11 16:46:26.789130
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    windows_shell = ShellModule()

    shebang = u'#!powershell'
    script = '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name '%s'
        Write-Output -InputObject $tmp.FullName
        ''' % (windows_shell.get_option('remote_tmp'), windows_shell.__class__._generate_temp_dir_name())
    cmd = windows_shell.build_module_command(env_string='', shebang=shebang, cmd=script)
    assert cmd.startswith(shebang)

# Generated at 2022-06-11 16:46:37.715098
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True

    assert shell.env_prefix() == ""
    assert shell.join_path('a','b','c') == 'a\\b\\c'

    assert shell.get_remote_filename('/path/to/file.py') == 'file.py'
    assert shell.get_remote_filename('/path/to/file.sh') == 'file.sh.ps1'
    assert shell.get_remote_filename('/path/to/file.bash') == 'file.bash.ps1'

    assert shell.path_has_trailing_slash('/path/to/file.sh') == False

# Generated at 2022-06-11 16:46:45.986671
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import jinja2
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext

    def test_function(name, **kwargs):
        # create the module mock
        module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True
        )

        # set the module args
        args = dict(
            CHANGED_WHEN='yes',
            ENV=dict(),
            WARN=dict(),
        )
        args.update(**kwargs)

        setattr(module, 'params', args)

        # initialize the class we are testing

# Generated at 2022-06-11 16:46:56.258508
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    module = ShellModule()

    # Test with single forward slash
    user_home_path = '/Users/myuser'
    result = module.expand_user(user_home_path)
    assert (result == "Write-Output '/Users/myuser'")

    # Test with double forward slash
    user_home_path = '//Users/myuser'
    result = module.expand_user(user_home_path)
    assert (result == "Write-Output '//Users/myuser'")

    # Test with single back slash
    user_home_path = '\\Users\\myuser'
    result = module.expand_user(user_home_path)
    assert (result == "Write-Output '\\Users\\myuser'")

    # Test with double back slash

# Generated at 2022-06-11 16:47:05.090834
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    result = shell.mkdtemp(basefile=None, system=False, mode=None, tmpdir=None)
    assert isinstance(result, str)
    #result = shell.mkdtemp(basefile='tmp', system=True, mode=None, tmpdir=None)
    #assert isinstance(result, str)
    #result = shell.mkdtemp(basefile=None, system=False, mode=None, tmpdir='/tmp')
    #assert isinstance(result, str)
    #result = shell.mkdtemp(basefile='tmp', system=True, mode=None, tmpdir='/tmp')
    #assert isinstance(result, str)
    #result = shell.mkdtemp(basefile='tmp', system=False, mode=None, tmpdir=None)
    #assert

# Generated at 2022-06-11 16:47:17.233536
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Windows only
    import os
    import tempfile
    import shutil
    sm = ShellModule()
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 16:47:22.998680
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule(command_timeout=10)
    shell._is_logged_in = False
    basefile = "abcdef"
    shell.mkdtemp(basefile=basefile, mode=None, tmpdir=r"C:\temp")
    script = '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\temp')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'abcdef'
        Write-Output -InputObject $tmp.FullName
        '''
    assert script.strip() == shell._last_invocation[5].strip()

# Generated at 2022-06-11 16:47:24.051325
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:47:27.119316
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module._IS_WINDOWS == True

# Generated at 2022-06-11 16:47:51.489503
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test for when there is a shebang
    powershell = ShellModule()
    cmd = powershell.build_module_command("", "#!powershell", "", "")
    assert cmd == u'& type .\\ansible_module_ping.ps1 | . '
    # Test for when there is no shebang
    cmd = powershell.build_module_command("", "", ".\\ansible_module_ping.exe", "")
    assert cmd == u'& .\\ansible_module_ping.exe ; exit $LASTEXITCODE'
    # Test for when there is no shebang and the file doesn't end with .exe
    cmd = powershell.build_module_command("", "", ".\\ansible_module_ping", "")

# Generated at 2022-06-11 16:47:52.907389
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 16:47:56.177743
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    sm = ShellModule()
    result = sm.mkdtemp()
    assert isinstance(result, str)
    assert result.endswith('$null')
    assert result.startswith('$tmp = New-Item -Type Directory -Path ')

# Generated at 2022-06-11 16:48:05.067803
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    def _mktemp(tmp):
        return '$tmp'

    import sys
    class FakeModuleExecutor(object):
        def __init__(self):
            self.shell = None
        def shell_class(self):
            return self.shell

    class FakeRunner(object):
        def __init__(self):
            self.module_executor = FakeModuleExecutor()
            self.module_executor.shell = ShellModule(runner=self)
        def run(self, cmd, tmp_path, sudoable=False):
            cmd = cmd.strip()
            path = self.module_executor.shell.mkdtemp(tmpdir=tmp, basefile='')
            assert cmd == path
            return 0, '', ''

    runner = FakeRunner()
    tmp = os.getenv('TEMP')

# Generated at 2022-06-11 16:48:05.910029
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create instance of class ShellModule
    assert ShellModule()

# Generated at 2022-06-11 16:48:11.441055
# Unit test for constructor of class ShellModule
def test_ShellModule():

    module = ShellModule(command_name='shell')
    module._set_shell_exceptions({})
    #  Default option values
    assert module.get_option('remote_tmp') == r'$env:TEMP'
    assert module.get_option('remote_interrupt_timeout') == 60
    assert module.get_option('remote_connect_timeout') == 30
    assert module.get_option('remote_copy_tmp') == r'$env:TEMP'
    assert module.get_option('remote_copy_timeout') == 60
    assert module.get_option('remote_copy_tmp_dir_access') == '0777'



# Generated at 2022-06-11 16:48:12.632416
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule('winrm')

# Generated at 2022-06-11 16:48:15.215021
# Unit test for constructor of class ShellModule
def test_ShellModule():
    x = ShellModule()
    x.SHELL_FAMILY = 'powershell'
    assert x.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:48:21.086916
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Executing constructor
    newShellModule = ShellModule()

    # Testing the parameters of the constructor
    assert newShellModule.COMPATIBLE_SHELLS == frozenset()
    assert newShellModule.SHELL_FAMILY == 'powershell'
    assert newShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert newShellModule._SHELL_AND == ';'
    assert newShellModule._IS_WINDOWS == True


# Generated at 2022-06-11 16:48:24.289285
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """ constructor test case """
    ssh_executor = ShellModule()
    assert ssh_executor.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:48:52.099124
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import tempfile

    def _tst_mkdtemp(basename):
        tmpdir = tempfile.mkdtemp()
        mod = ShellModule()
        mod.get_option = lambda x: tmpdir
        res = mod.mkdtemp(basename=basename)
        res = to_text(res)[1:-1].replace('\\', '/')
        return tmpdir, res

    assert _tst_mkdtemp('""') == _tst_mkdtemp('\"\"')
    assert _tst_mkdtemp('""') == _tst_mkdtemp('')
    assert _tst_mkdtemp('foo') != _tst_mkdtemp('bar')
    assert _tst_mkdtemp('foo') != _tst_mkdtemp('FOO')

# Generated at 2022-06-11 16:48:56.099445
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert isinstance(shell, ShellModule)
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()



# Generated at 2022-06-11 16:49:05.762075
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()

    # test shebang

# Generated at 2022-06-11 16:49:11.291639
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    from ansible.plugins.shell import ShellModule
    shell = ShellModule()
    script = shell.mkdtemp(basefile='asd')
    assert script == 'New-Item -Type Directory -Path ' + shell.get_option('remote_tmp') + ' -Name asd; Write-Output -InputObject $tmp.FullName'

# Generated at 2022-06-11 16:49:13.917342
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    This is not really a unit test, it just tries to run the constructor of the class ShellModule
    '''
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:49:21.248022
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    s = ShellModule()
    # Test method with non empty tmpdir
    script_non_empty_tmpdir = '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name '%s'
        Write-Output -InputObject $tmp.FullName
        ''' % ('C:/temp', 'basefile')
    assert s.mkdtemp('basefile', tmpdir='C:/temp') == script_non_empty_tmpdir
    # Test method without tmpdir
    script_empty_tmpdir = script_non_empty_tmpdir.replace('C:/temp', s.get_option('remote_tmp'))
    assert s.mkdtemp('basefile') == script_empty_tmpdir
    # Test method with empty base

# Generated at 2022-06-11 16:49:22.332999
# Unit test for constructor of class ShellModule
def test_ShellModule():
    PowerShellShell = ShellModule()
    assert PowerShellShell

# Generated at 2022-06-11 16:49:24.482074
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''shell_plugin_powershell.py:test_ShellModule()'''
    obj = ShellModule()
    assert isinstance(obj, ShellModule)

# Generated at 2022-06-11 16:49:25.232208
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

# Generated at 2022-06-11 16:49:30.900462
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Instantiate a shell into a module and then call its functions
    """
    # Create a module for test
    test_module = ShellModule()

    # Assert that it exists and is an instance of the ShellModule class
    assert isinstance(test_module, ShellModule)

    # Call methods for test
    test_module.checksum('c:\\users\\test_user', 'sha1')

# Generated at 2022-06-11 16:49:57.385792
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.get_option('remote_tmp') == 'c:/windows/temp'
    assert module.get_option('_ansible_tmpdir') == 'c:/windows/temp'

# Generated at 2022-06-11 16:49:58.081650
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()

# Generated at 2022-06-11 16:50:02.334948
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module = ShellModule()
    # Test for parameters: basefile, system, mode, tmpdir
    result = shell_module.mkdtemp(basefile='testdata', system=False, mode='testdata', tmpdir='testdata')
    assert isinstance(result, unicode)



# Generated at 2022-06-11 16:50:12.661085
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import tempfile
    import os
    import shutil
    # Set tmp dir to system default
    old_tmpdir = tempfile.gettempdir()
    tempfile.tempdir = None
    # Try to create a temporary directory

# Generated at 2022-06-11 16:50:13.303978
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule() is not None


# Generated at 2022-06-11 16:50:14.304402
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell._IS_WINDOWS

# Generated at 2022-06-11 16:50:21.198934
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(
        runner_path='', ansible_version='',
        check=False, diff=False, cmd='',
        shell_type='powershell',
        remote_user='', remote_pass='', connection='',
        become_user='', become_method='', become_pass='',
        loader=None, no_log=True
    )
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS

# Generated at 2022-06-11 16:50:31.592006
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    s = ShellModule()
    # no tempdir
    tempdir = s.mkdtemp()
    assert tempdir == '''Write-Output -InputObject ([System.IO.Path]::GetRandomFileName() | ForEach-Object { $tmppath = '%s\\ansible-${_}'; New-Item -Type Directory -Path $tmppath; $tmppath; });''' % (s.get_option('remote_tmp'))
    # set tempdir
    tempdir = s.mkdtemp(tmpdir="C:\\test\\")

# Generated at 2022-06-11 16:50:39.732059
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    '''
    create a temp directory
    '''
    # Usage of mkdtemp
    # shell_obj = ShellModule(connection)
    # result = shell_obj.mkdtemp(basefile, system, mode, tmpdir)

    from ansible.plugins.connection.winrm import Connection

    # initialize connection object
    # connection = Connection(play_context)
    connection = Connection()
    # initialize shell object
    shell_obj = ShellModule(connection)
    test_result = shell_obj.mkdtemp()
    assert type(test_result) == str
    assert re.match('^ansible', os.path.basename(test_result))

# Generated at 2022-06-11 16:50:43.364328
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Test both tilde usernames and tilde paths
    # Test tilde path not starting with slash
    sm = ShellModule(None)
    output = sm.expand_user('~/testing')
    assert(sm._unquote(output) == '$((Get-Location).Path + \'/testing\')')



# Generated at 2022-06-11 16:51:13.925110
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    '''
    ShellModule.expand_user() Test
    '''
    p = ShellModule()

    def test_expand_user(usr_home_path):
        cmd = p.expand_user(usr_home_path)
        assert isinstance(cmd, bytes)

        # Split the command into arguments
        cmd_arg = shlex.split(cmd.decode('utf-8'), posix=False)

        # First element should be base64-encoded string
        encoded_script = cmd_arg[-1]

        # Decode base64-encoded string
        script = base64.b64decode(encoded_script).decode('utf-16le')

        # Get the value of PowerShell output

# Generated at 2022-06-11 16:51:14.663941
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()
    assert p.IS_WINDOWS

# Generated at 2022-06-11 16:51:16.429287
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule(runner=None) != None



# Generated at 2022-06-11 16:51:19.866488
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule(connection=None, cleaner=None, shell_executable=None)
    assert obj is not None

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:51:21.985562
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_plugin = ShellModule()

    # Check instance variables
    assert shell_plugin.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:51:28.589404
# Unit test for constructor of class ShellModule
def test_ShellModule():
    class NullConnection(object):
        def __init__(self):
            self.connected = False

        def connect(self, host, port, user, password):
            self.connected = True

    # Test when connection plugin is 'ssh' and C(DefaultShell) is set to PowerShell
    c = NullConnection()
    powershell = ShellModule(c)
    assert not c.connected
    powershell.exec_command('pwd', tmp='/tmp')
    assert c.connected
    assert powershell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert powershell._SHELL_AND == ';'
    assert powershell._IS_WINDOWS
    assert powershell.SHELL_FAMILY == 'powershell'


# Unit tests for method _unquote() of class ShellModule