

# Generated at 2022-06-11 16:41:42.277285
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell.module_common
    import tempfile
    import shutil
    import os
    import stat
    import textwrap

    module_name = "hello_world.ps1"
    shebang = "#!powershell"
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

    # create temporary directory
    tmpdir = tempfile.mkdtemp()

    # create temporary hello_world.ps1 file
    temp_hello_world = os.path.join(tmpdir, module_name)

# Generated at 2022-06-11 16:41:53.824691
# Unit test for method build_module_command of class ShellModule

# Generated at 2022-06-11 16:41:59.013554
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    from ansible.plugins.shell.powershell import ShellModule
    assert ShellModule(None, '').path_has_trailing_slash('C:\\Windows\\') is True
    assert ShellModule(None, '').path_has_trailing_slash('C:\\Windows') is False

# Generated at 2022-06-11 16:42:04.953332
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    test_paths = [
        ('abc', False),
        ('abc\\', True),
        ('abc/', True),
        ('abc/test\\test', False),
        ('abc/test\\test\\', True),
        ('abc\\test/test', False),
        ('abc\\test/test/', True),
        ('abc\\test\\test/', True),
    ]
    for path, expected in test_paths:
        assert ShellModule().path_has_trailing_slash(path) == expected

# Generated at 2022-06-11 16:42:14.597667
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    script = shell.expand_user('~')
    assert len(script) == 1

# Generated at 2022-06-11 16:42:20.114912
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_obj = ShellModule()
    assert shell_obj.expand_user('~') == 'Write-Output (Get-Location).Path'
    assert shell_obj.expand_user('~\\test') == "Write-Output ((Get-Location).Path + '\test')"
    assert shell_obj.expand_user('test') == "Write-Output 'test'"



# Generated at 2022-06-11 16:42:30.721916
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module_path = '/path/to/module'
    module_name = 'module'
    module_args = 'fake_module_args'


# Generated at 2022-06-11 16:42:34.013776
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.run == '& %s; exit $LASTEXITCODE'
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.env_prefix() == ''
    assert sm.remote_path == ';'
    assert sm._IS_WINDOWS is True

# Generated at 2022-06-11 16:42:35.086393
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj is not None

# Generated at 2022-06-11 16:42:38.666603
# Unit test for constructor of class ShellModule
def test_ShellModule():
    args = _common_args + ['-EncodedCommand', 'foo']
    shell = ShellModule(task_uuid=None, runner_uuid=None, module_name='FakeModule')
    assert args == shell._encode_script(script='foo', as_list=True)


# Generated at 2022-06-11 16:42:44.893854
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    print(shell)

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:42:50.017578
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule('C:\\Windows', 'Test-Path')
    assert shell.executable == 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'
    assert shell.args == '-NonInteractive -NoProfile -ExecutionPolicy Bypass -Command'

# Generated at 2022-06-11 16:42:51.985922
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.txt') == 'test.txt'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'


# Generated at 2022-06-11 16:42:54.444590
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    p = ShellModule()
    assert p.build_module_command("", "", "", "") == "IyEvdXNyL2Jpbi9zaAoK"



# Generated at 2022-06-11 16:43:03.050313
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import tempfile
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'wb') as f:
        f.write(b'#!/usr/bin/python -tt\nprint "hello"\n')
        f.write(b'print "world"\n')
    try:
        plugin = ShellModule()
        shebang, cmd = plugin._build_module_command(path, '')
        assert shebang == '#!/usr/bin/python'
        assert cmd == '-tt %s' % path
    finally:
        os.remove(path)

# Generated at 2022-06-11 16:43:07.368822
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-11 16:43:18.818232
# Unit test for constructor of class ShellModule
def test_ShellModule():
    plugin = ShellModule()

    assert plugin.COMPATIBLE_SHELLS == frozenset()
    assert plugin.SHELL_FAMILY == 'powershell'
    assert plugin._IS_WINDOWS
    assert plugin.env_prefix() == ''
    assert plugin.join_path('/a', '/b') == r'\a\b'
    assert plugin.get_remote_filename('a') == 'a.ps1'
    assert plugin.get_remote_filename('a.py') == 'a.py'
    assert plugin.get_remote_filename('a.pyc') == 'a.pyc'
    assert plugin.get_remote_filename('a.PS1') == 'a.PS1'
    assert plugin.get_remote_filename('a.PY') == 'a.PY'
    assert plugin.get_

# Generated at 2022-06-11 16:43:19.707496
# Unit test for constructor of class ShellModule
def test_ShellModule():
    Plugin = ShellModule()
    assert Plugin

# Generated at 2022-06-11 16:43:30.328089
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # initialize ansible powershell module class
    shell = ShellModule()

    # validate instance variables of class
    # TODO: add validation for different inputs for each variable
    assert shell.SHELL_FAMILY == "powershell"
    assert shell._IS_WINDOWS is True
    assert shell.COMPATIBLE_SHELLS == frozenset()

    # validate methods of class
    assert shell.build_module_command('''if ($false) { Write-Output "foo" }''', '#!powershell', '') == '''& (type bootstrap_wrapper.ps1 | iex); exit $LASTEXITCODE'''
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test') == 'test.ps1'

# Generated at 2022-06-11 16:43:34.292099
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS == True
    assert len(sm.COMPATIBLE_SHELLS) == 0


# Generated at 2022-06-11 16:43:42.853137
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule._IS_WINDOWS
    assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule._SHELL_AND == ';'
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:43:44.735812
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh = ShellModule()
    assert sh.COMPATIBLE_SHELLS == ['powershell', 'pwsh']

# Generated at 2022-06-11 16:43:49.044020
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    '''ansible.module_utils.powershell.shell.ShellModule.path_has_trailing_slash'''
    assert ShellModule().path_has_trailing_slash('foo') == False
    assert ShellModule().path_has_trailing_slash('foo/') == True
    assert ShellModule().path_has_trailing_slash('foo\\') == True


# Generated at 2022-06-11 16:43:58.060978
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    shell.set_options({'connection': 'psrp', 'remote_tmp': '/tmp'})
    shell.join_path('/foo', 'bar')
    shell.set_user_facl('foo', 'bar')
    shell.is_executable('/foo/bar.exe')
    shell.is_executable('/foo/bar.ps1')
    shell.is_executable('/foo/bar')
    shell.exists('/foo/bar')
    shell.build_module_command({}, '#!powershell', 'foo')

# Generated at 2022-06-11 16:44:10.084103
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import os
    from ansible.module_utils.six import PY3

    module = ShellModule()

    assert module.COMPATIBLE_SHELLS == frozenset()

    if os.name == 'nt':
        exe = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\' + 'powershell.exe'
    else:
        exe = '/bin/false'

    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module._IS_WINDOWS
    assert module._SHELL_BACKSLASH

    assert module.env_prefix() == ''


# Generated at 2022-06-11 16:44:11.950382
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule(connection='winrm', no_log=False)
    assert mod.no_log == False
    assert mod.connection == 'winrm'

# Generated at 2022-06-11 16:44:21.671046
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # setup test data
    module_name = 'TestModuleName'
    module_args = 'TestModuleArgs'
    cmd = 'TestCmd'
    shebang = 'TestShebang'

    # create object
    shell_module = ShellModule()
    # try without shebang
    result = shell_module.build_module_command('', '', cmd)
    # TestCmd.ps1 TestModuleArgs
    assert result == cmd + '.ps1 ' + module_args
    # try with shebang
    result = shell_module.build_module_command('', shebang, cmd)
    assert result == cmd + '.ps1 ' + module_args

# Generated at 2022-06-11 16:44:32.682750
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    m = ShellModule()
    assert m.path_has_trailing_slash(r'C:\something') is False

# Generated at 2022-06-11 16:44:42.979984
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.plugins.shell.powershell as powershell
    s = powershell.ShellModule()

    # Non-pipelining
    assert (s.build_module_command('', '', 'echo $1') ==
            '& powershell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand AgABAA==')
    # stderr output should be encoded as clixml
    assert (_parse_clixml(s.build_module_command('', '', 'echo $1 1>&2')) ==
            '\r\n'.join(['<Objs Version="1.1.0.1" xmlns="http://schemas.microsoft.com/powershell/2004/04">',
                         '  <S S="Error">$1</S>', '</Objs>']))

    # Pip

# Generated at 2022-06-11 16:44:50.734682
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    import ansible.module_utils.windows.powershell as ps
    assert ps.ShellModule(connection=None).path_has_trailing_slash('C:') is False
    assert ps.ShellModule(connection=None).path_has_trailing_slash('C:\\') is True
    assert ps.ShellModule(connection=None).path_has_trailing_slash('C:\\temp\\file') is False
    assert ps.ShellModule(connection=None).path_has_trailing_slash('C:\\temp\\file\\') is True
    assert ps.ShellModule(connection=None).path_has_trailing_slash('C:/') is True
    assert ps.ShellModule(connection=None).path_has_trailing_slash('C:/temp/file') is False

# Generated at 2022-06-11 16:45:06.981048
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a host
    loader = DataLoader()
    host = Host(name="some_host")
    host.vars = HostVars(loader=loader, hostname="some_host")
    host.groups = []

    # Create a group
    group = Group(name="some_group")
    group.vars = HostVars(loader=loader, hostname="some_host")
    group.hosts.append(host)
    group.groups = []

    #

# Generated at 2022-06-11 16:45:07.554608
# Unit test for constructor of class ShellModule
def test_ShellModule():
    a = ShellModule()

# Generated at 2022-06-11 16:45:08.427758
# Unit test for constructor of class ShellModule
def test_ShellModule():
    conn = ShellModule(None)
    assert conn

# Generated at 2022-06-11 16:45:20.229661
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():

    sm = ShellModule()

    assert sm.path_has_trailing_slash('C:\\Users')
    assert sm.path_has_trailing_slash('C:\\Users\\')
    assert not sm.path_has_trailing_slash('C:\\Users\\username')

    assert sm.path_has_trailing_slash('/')
    assert sm.path_has_trailing_slash('/home')
    assert sm.path_has_trailing_slash('/home/')
    assert not sm.path_has_trailing_slash('/home/username')


# Generated at 2022-06-11 16:45:23.143866
# Unit test for constructor of class ShellModule
def test_ShellModule():
    args = {}
    powershell_shell = ShellModule(**args)
    assert powershell_shell.SHELL_FAMILY == 'powershell'
    assert powershell_shell._IS_WINDOWS

# Generated at 2022-06-11 16:45:29.569882
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule(None)
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'
    assert sm._IS_WINDOWS == True

    assert sm.COMPATIBLE_SHELLS == frozenset()


if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-11 16:45:41.013152
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    # Test trimming of unbalanced quotes
    module_cmd = shell.build_module_command(env_string='', shebang='', cmd='\"echo hello world')
    assert module_cmd == to_bytes('& type echo hello world.ps1 | & %s; exit $LASTEXITCODE' % _common_args)

    # Test addition of .ps1 suffix if needed
    module_cmd = shell.build_module_command(env_string='', shebang='', cmd='echo hello world')
    assert module_cmd == to_bytes('& type echo hello world.ps1 | & %s; exit $LASTEXITCODE' % _common_args)

    # Test native binary support

# Generated at 2022-06-11 16:45:42.598750
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule(conn=None, shell_type='powershell')

# Generated at 2022-06-11 16:45:48.891453
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert hasattr(module, 'COMPATIBLE_SHELLS')
    assert hasattr(module, 'SHELL_FAMILY')
    assert hasattr(module, '_SHELL_REDIRECT_ALLNULL')
    assert hasattr(module, '_SHELL_AND')
    assert hasattr(module, '_IS_WINDOWS')
    assert callable(module.env_prefix)


# Generated at 2022-06-11 16:45:57.869972
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

    # test join_path
    assert "C:\\Windows\\Temp\\foo.txt" == sm.join_path("C:\\Windows", "C:\\Windows\\Temp\\foo.txt")
    assert "C:\\Windows\\Temp\\foo.txt" == sm.join_path("C:\\Windows\\", "C:\\Windows\\Temp\\foo.txt")
    assert "C:\\Windows\\Temp\\foo.txt" == sm.join_path("C:\\Windows", "C:\\Windows\\Temp\\foo.txt")
    assert "C:\\foo.txt" == sm.join_path("C:\\", "C:\\foo.txt")
    assert "C:\\foo.txt" == sm.join_path("C:\\", "C:\\foo.txt")

# Generated at 2022-06-11 16:46:02.899951
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:46:12.155940
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    def run_test(module_args, shebang, cmdline_parts, expected_result):
        result = ShellModule(connection='local').build_module_command(
            module_args=module_args,
            shebang=shebang,
            cmd=cmdline_parts
        )
        assert result == expected_result

    def test(test_data):
        run_test(test_data['arguments'], test_data['shebang'], test_data['cmdline_parts'], test_data['expected_result'])


# Generated at 2022-06-11 16:46:13.969902
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Check that we can create an instance of the ShellModule class
    sm = ShellModule()

# Generated at 2022-06-11 16:46:18.928728
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'
    assert sm._IS_WINDOWS is True
    sm = ShellModule(None)
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'
    assert sm._IS_WINDOWS is True
    return True


# Generated at 2022-06-11 16:46:28.715463
# Unit test for constructor of class ShellModule

# Generated at 2022-06-11 16:46:31.598197
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_shell_obj = ShellModule()
    assert test_shell_obj is not None, "ShellModule constructor failed"

# Generated at 2022-06-11 16:46:37.851221
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.basic import AnsibleModule
    # Create a module that is used for typically for testing
    module = AnsibleModule(
        argument_spec = dict(
            test = dict(default=None)
        ),
        supports_check_mode=True,
    )

    powershell = ShellModule(module)

    assert powershell._encoding == 'utf-8'
    assert powershell._shell.SHELL_FAMILY == 'powershell'



# Generated at 2022-06-11 16:46:38.962767
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm is not None

# Generated at 2022-06-11 16:46:46.800823
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    win_paths = [
        'c:\\',
        'c:\\foo\\bar\\',
        'c:\\foo\\bar\\\\',
        '\\\\foo\\bar',
        '\\\\foo\\bar\\',
        '\\\\foo\\bar\\\\',
        '//foo/bar/',
        '//foo/bar//'
    ]

    non_win_paths = [
        'c:',
        'c:\\foo\\bar',
        '\\\\foo\\bar\\baz',
        '//foo/bar/baz'
    ]

    sm = ShellModule()
    for path in win_paths:
        assert(sm.path_has_trailing_slash(path))


# Generated at 2022-06-11 16:46:56.858913
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():

    def test_path_has_trailing_slash(path_in, result):
        this_path_has_trailing_slash = shell_module.path_has_trailing_slash(path_in)
        assert this_path_has_trailing_slash == result, \
            "Testing path '%s' returns '%s', should be '%s'." % (path_in, this_path_has_trailing_slash, result)

    shell_module = ShellModule()


# Generated at 2022-06-11 16:47:14.548911
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell import PowershellModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader

    module_loader = DataLoader()
    module_loader.set_basedir(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'lib'))

    am = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    exec_wrapper = PowershellModule(am)

    cmd = 'echo test'
    shebang = '#!/bin/sh'
    result = exec_wrapper.build_module_command('', shebang, cmd, '/tmp/test.txt')

    assert 'powershell' in result

# Generated at 2022-06-11 16:47:18.226235
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod._SHELL_REDIRECT_ALLNULL == '> $null'
    assert mod._SHELL_AND == ';'
    assert mod._IS_WINDOWS is True


# Unit tests for _unquote function

# Generated at 2022-06-11 16:47:20.825868
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS

# Generated at 2022-06-11 16:47:25.464719
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS is True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'

# Generated at 2022-06-11 16:47:36.539118
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    import os
    import sys
    import tempfile

    if sys.version_info[0] == 2:
        # Python 2.7: import the backported mock module
        from mock import patch, MagicMock
    else:
        # Python 3.4 and above: use built-in mock module
        from unittest.mock import patch, MagicMock

    # Mock the run_command method using patch decorator
    with patch('ansible.module_utils.basic.AnsibleModule') as mock_AnsibleModule:
        # Mock the built-in open method
        with patch(builtins_name + '.open', mock_open()) as m:
            mocked_module = MagicMock()
            mock_AnsibleModule.return_value = mocked_module
            # Perform the test
            powershell = ShellModule('')
           

# Generated at 2022-06-11 16:47:46.561239
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.utils.unsafe_proxy

    class Connection(object):
        def __init__(self, host, port, user, password, *args, **kwargs):
            self.host = host
            self.port = port
            self.user = user
            self.password = password
            self.args = args
            self.kwargs = kwargs

        def get_host(self):
            return self.host

    class Task(object):
        def __init__(self, connection, *args, **kwargs):
            self.connection = connection
            self.args = args
            self.kwargs = kwargs

        def __getattr__(self, name):
            return getattr(self.connection, name)

        @property
        def become(self):
            return False


# Generated at 2022-06-11 16:47:51.207206
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    Test that the constructor of ShellModule works properly
    '''

    # Test with no parameters
    shellmod = ShellModule()

    # Test with some parameters
    shellmod = ShellModule(
        executor=None,
        engine=None,
        generated_profile=None,
        task_uuid=None,
        task_vars=None,
        templar=None,
        ansible_playbook_dir='/playbookdir',
        ansible_version='/ansibleversion',
    )

# Generated at 2022-06-11 16:47:59.467921
# Unit test for method build_module_command of class ShellModule

# Generated at 2022-06-11 16:48:00.423053
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell is not None

# Generated at 2022-06-11 16:48:02.433501
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True

# Generated at 2022-06-11 16:48:08.353911
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS

# Generated at 2022-06-11 16:48:10.374938
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule(connection=None, shell_executable=None)

# Generated at 2022-06-11 16:48:10.993450
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-11 16:48:21.324229
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh = ShellModule()
    assert sh.SHELL_FAMILY == 'powershell'
    assert len(sh.COMPATIBLE_SHELLS) == 0
    assert sh.IS_BINARY == False
    # TODO: Test that base64 encoding of script works?
    # TODO: Test that shebang support is working?
    # TODO: Test that the common arguments are properly added?
    # TODO: Test that clixml is properly handled?
    # TODO: Test that module command is properly built?
    # TODO: Test that wrap_for_exec is properly built?
    # TODO: Test that tmp directories are properly built?
    # TODO: Test that paths are properly escaped?
    # TODO: Test that paths are properly joined?
    # TODO: Test that paths are properly normalized?
    # TOD

# Generated at 2022-06-11 16:48:23.738768
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None

# Generated at 2022-06-11 16:48:28.566787
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Test class constructor
    shell_obj = ShellModule()

    assert shell_obj._IS_WINDOWS

    assert 'powershell' == shell_obj.SHELL_FAMILY

    assert not shell_obj.COMPATIBLE_SHELLS


# Generated at 2022-06-11 16:48:37.702877
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    shell = ShellModule()

    # Test no shebang and no space in path
    module_command = shell.build_module_command(env_string='', shebang=None, cmd='/path/to/my.ps1', arg_path='/path/to/temp.txt')
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    bootstrap_wrapper = to_text(bootstrap_wrapper)

# Generated at 2022-06-11 16:48:49.558750
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.module_common

    # Get a copy of the ShellModule module object
    shell_module = ShellModule(connection=None)

    script = ansible.executor.module_common.escape_windows_path('test.ps1')
    assert shell_module.build_module_command(None, "#! powershell", script) == shell_module._encode_script(script=script, strict_mode=False, preserve_rc=False)

    # Test that if the shebang is not #!powershell, the script is unchanged
    assert shell_module.build_module_command(None, "#! powershell", script) != shell_module._encode_script(script=script)

    # Test that if there is no shebang, the script is unchanged
    script = "test.ps1"
    assert shell_module.build

# Generated at 2022-06-11 16:48:56.782040
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Unit test for constructor of class ShellModule
    """
    mod = ShellModule()
    assert mod.get_remote_filename('') == '.ps1'
    assert mod.get_remote_filename('/tmp') == 'tmp.ps1'
    assert mod.get_remote_filename('/tmp.bat') == 'tmp.bat'
    assert mod.get_remote_filename('/tmp.ps1') == 'tmp.ps1'


# Generated at 2022-06-11 16:49:01.301440
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    s = ShellModule()
    assert True == s.path_has_trailing_slash('c:/temp/')
    assert False == s.path_has_trailing_slash('c:/temp')
    assert True == s.path_has_trailing_slash('c://temp/')


# Generated at 2022-06-11 16:49:09.218471
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    assert m.SHELL_FAMILY == 'powershell'
    assert m._IS_WINDOWS

# Generated at 2022-06-11 16:49:10.230182
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule() is not None

# Generated at 2022-06-11 16:49:12.554994
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert(module._SHELL_REDIRECT_ALLNULL == '> $null')

# Generated at 2022-06-11 16:49:19.335213
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, add_ssh_args=None, runner_on_failed=None,
                        runner_on_unreachable=None, runner_on_no_hosts=None, runner_on_async_poll=None,
                        runner_on_async_ok=None, runner_on_async_failed=None, cp=None)

    assert shell.COMPATIBLE_SHELLS == frozenset(), 'Failed to initialize plugin. Compatibility shells are not empty.'
    assert shell.SHELL_FAMILY == 'powershell', 'Failed to initialize plugin. Family is not powershell.'



# Generated at 2022-06-11 16:49:27.825648
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert isinstance(module, ShellModule)

    module.get_remote_filename('/path/to/my/file.ps1')
    module.get_remote_filename('/path/to/my/file.PS1')

    module.wrap_for_exec('test') == '& test; exit $LASTEXITCODE'

    # testing a non-pipeline command
    script_name = 'test_script.ps1'
    cmd = '-file %s' % script_name
    module.build_module_command('', '', cmd) == 'test'

# Generated at 2022-06-11 16:49:33.742817
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    Basic Powershell test.
    '''
    sm = ShellModule('winrm', None, False, None)
    shell_parts = ['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Unrestricted']
    assert shell_parts == sm._build_shell_commands()


# Unit test(s) for method(s) in class ShellModule

# Generated at 2022-06-11 16:49:42.283829
# Unit test for constructor of class ShellModule
def test_ShellModule():

    class MockConnection():

        def __init__(self, *args, **kwargs):
            pass

        def get_option(self, option):
            if option == 'shell_type':
                return 'powershell'
            return None

        def run(self, cmd, *args, **kwargs):
            return cmd

    shell = ShellModule(MockConnection(), '/usr/bin/ansible', 'winrm')
    assert shell.SHELL_FAMILY == 'powershell'
    assert type(shell.COMPATIBLE_SHELLS) == frozenset
    assert type(shell._SHELL_REDIRECT_ALLNULL) == str
    assert shell._IS_WINDOWS


# Test _parse_clixml

# Generated at 2022-06-11 16:49:46.379634
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module._IS_WINDOWS is True
    assert module._SHELL_REDIRECT_ALLNULL == "> $null"
    assert module._SHELL_AND == ";"

# Generated at 2022-06-11 16:49:51.965451
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    base64_bootstrap_wrapper = base64.b64encode(
        pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")).decode('utf-8')
    bootstrap_wrapper_encoded = shell_module._encode_script(base64_bootstrap_wrapper, strict_mode=False, preserve_rc=False)
    assert shell_module.build_module_command('', '', '') == bootstrap_wrapper_encoded, \
        "build_module_command did not return the bootstrap wrapper when called with an empty command"


# Generated at 2022-06-11 16:50:01.892469
# Unit test for constructor of class ShellModule
def test_ShellModule():
    debug = {}
    sm = ShellModule(None, host=None, task_uuid=None, tmpdir=None, debug=debug, loader=None, callee=None, shell_type='powershell', exec_env={})
    assert sm.path_has_trailing_slash('"c:\\temp\\"') is True
    assert sm.path_has_trailing_slash('"c:\\temp"') is False
    assert sm.path_has_trailing_slash('c:\\temp') is False
    assert sm.path_has_trailing_slash('"c:\\temp') is False
    assert sm.path_has_trailing_slash('c:\\temp\\') is True



# Generated at 2022-06-11 16:50:08.912572
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=dict(conn_files=dict()))
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-11 16:50:19.262540
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.connection_info import ConnectionInformation
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins.loader import find_plugin_files

    shell_plugins = find_plugin_files('.*shell$', os.path.join(os.path.dirname(ansible.__file__), 'plugins'))
    for plugin in shell_plugins:
        # get a list of the classes in each module
        module = pkgutil.get_loader(plugin).load_module()
        class_members = [getattr(module, s) for s in dir(module) if isinstance(getattr(module, s), type)]
        # find any that are subclasses of ShellBase

# Generated at 2022-06-11 16:50:26.026883
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    class MockModule(object):
        def __init__(self, module_args=''):
            self.params = {}
            if module_args:
                for kv_str in module_args.split():
                    (k, v) = kv_str.split("=")
                    self.params[k.strip()] = to_text(v.strip())
    powershell = ShellModule(connection=None)
    mod = MockModule("msi_path=/tmp/test.msi")
    # Test if the command is built correctly when msi_path is passed in

# Generated at 2022-06-11 16:50:34.604105
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test case for shebang = #!powershell
    from ansible.errors import AnsibleError
    from ansible.executor.powershell.module_common import _ENCODED_SCRIPT_SHEBANG
    module_utils_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ansible_module_utils')
    os.environ['ANSIBLE_MODULE_UTILS_PATH'] = module_utils_path
    shell = ShellModule()
    shebang = '#!powershell'
    cmd = 'sample_module'

# Generated at 2022-06-11 16:50:36.217197
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, **dict())
    assert shell is not None

# Generated at 2022-06-11 16:50:43.084111
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test instantiation of class
    shell = ShellModule()
    # Test class variables
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True
    # Test class methods
    # Test env_prefix
    assert shell.env_prefix() == ""
    # Test join_path
    assert shell.join_path("C:\\Windows", "System32\\") == "C:\\Windows\\System32"
    assert shell.join_path("C:", "Windows", "System32\\") == "C:\\Windows\\System32"
    assert shell.join_path("C:", "\\Windows", "\\System32\\") == "C:\\Windows\\System32"
    assert shell.join_path("../System32")

# Generated at 2022-06-11 16:50:47.724570
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test against ShellModule to enable mocking
    if hasattr(ShellModule(), 'build_module_command'):
        assert hasattr(ShellModule().build_module_command, '__call__')

# Generated at 2022-06-11 16:50:48.370666
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:50:58.151226
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

    stdout = 'This is a string'
    stderr = 'This is also a string'
    rc = 0

    # rc = 0
    result = shell.parse_output(stdout, stderr, rc)
    assert result['stdout'] == stdout
    assert result['stdout_lines'] == [stdout]
    assert result['stderr'] == stderr
    assert result['stderr_lines'] == [stderr]

    # rc != 0, error stream present
    result = shell.parse_output(stdout, stderr, 1)
    assert result['stdout'] == stdout
    assert result['stdout_lines'] == [stdout]
    assert result['stderr'] == stderr

# Generated at 2022-06-11 16:50:59.821788
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO: implement test_ShellModule test cases
    pass

# Generated at 2022-06-11 16:51:12.098021
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes, to_native

    sm = ShellModule()

    assert sm
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS
    assert to_native(sm.env_prefix()) == ''
    assert to_native(sm.get_remote_filename('test.ps1')) == 'test.ps1'
    assert to_native(sm.get_remote_filename('test.exe')) == 'test.exe'
    assert to_native(sm.get_remote_filename('test')) == 'test.ps1'
    # path_has_trailing_slash
    assert sm.path_

# Generated at 2022-06-11 16:51:16.548505
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule().COMPATIBLE_SHELLS == frozenset()
    assert ShellModule().SHELL_FAMILY == 'powershell'
    assert ShellModule()._IS_WINDOWS is True

# Unit tests for various methods of class ShellModule

# Generated at 2022-06-11 16:51:17.858384
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:51:22.813965
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # pylint: disable=no-self-use
    import ansible.plugins.shell as shell_plugins
    shell_plugin = shell_plugins.ShellModule()

    for method in list(shell_plugin.SHELL_PLUGIN_COMPAT_MODULES):
        if not getattr(shell_plugin, method):
            raise Exception("Missing handler for %s" % method)

    # TODO: Add more tests