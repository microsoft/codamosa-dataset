

# Generated at 2022-06-11 16:41:40.284875
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():

    shell_module = ShellModule()
    shell_module._IS_WINDOWS = True

    result = shell_module.expand_user('~')
    assert result == shell_module._encode_script("Write-Output (Get-Location).Path")

    result = shell_module.expand_user('~\\abc')
    assert result == shell_module._encode_script("Write-Output ((Get-Location).Path + '\\abc')")

    result = shell_module.expand_user('~\\')
    assert result == shell_module._encode_script("Write-Output ((Get-Location).Path + '\\')")

    result = shell_module.expand_user('~/abc')
    assert result == shell_module._encode_script("Write-Output ((Get-Location).Path + '\\abc')")

    result = shell

# Generated at 2022-06-11 16:41:42.843041
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'

# Generated at 2022-06-11 16:41:51.097824
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import ansible.module_utils.powershell as ps
    shell = ps.ShellModule(connection=None, no_log=False,
                           command_timeout=10,
                           executable="ansible.module_utils.powershell.ShellModule")
    assert shell.connection == 'winrm'
    assert shell.SUFFIX == '.ps1'
    assert shell.no_log
    assert shell.command_timeout == 10
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.no_log
    assert shell._IS_WINDOWS


# Generated at 2022-06-11 16:42:01.789124
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    plugin = ShellModule(connection=None, *[], **{})
    assert not plugin.path_has_trailing_slash(r'c:\temp')
    assert plugin.path_has_trailing_slash(r'c:\temp\\')
    assert plugin.path_has_trailing_slash(r'c:\temp\123')
    assert plugin.path_has_trailing_slash(r'c:\temp/123')
    assert not plugin.path_has_trailing_slash(r'c:\temp\123\\')
    assert not plugin.path_has_trailing_slash(r'c:\temp/123//')


# Generated at 2022-06-11 16:42:08.795189
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    s = ShellModule(connection=None, shell_executable=None)
    assert s.get_remote_filename("/tmp/i.ps1") == "i.ps1"
    assert s.get_remote_filename("/tmp/i") == "i.ps1"
    assert s.get_remote_filename("/tmp/i.exe") == "i.exe"

# Unit tests for method join_path of class ShellModule

# Generated at 2022-06-11 16:42:09.925507
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, shell_type='powershell')
    assert shell

# Generated at 2022-06-11 16:42:12.379854
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-11 16:42:22.081232
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell
    sh = ShellModule(None)
    # test module as binary
    cmd = sh.build_module_command('', '', 'my_program.exe', 'my_argument')
    assert cmd == '"my_program.exe" my_argument'
    # test module as script
    cmd = sh.build_module_command('', '', 'my_script.ps1')
    assert cmd == 'type my_script.ps1 | ' + pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    # test module as script without extension
    cmd = sh.build_module_command('', '', 'my_script')

# Generated at 2022-06-11 16:42:31.921088
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.plugins.shell.powershell

    shell_plugin = ansible.plugins.shell.powershell.ShellModule(connection=None)

    cmd = shell_plugin.build_module_command("", "shebang", "type %s | some_wrapper" % ("test.ps1" if to_text(os.name) == 'nt' else "test"))
    assert 'type test.ps1 | some_wrapper' in cmd

    cmd = shell_plugin.build_module_command("", "shebang", "type %s | some_wrapper" % ("test.exe" if to_text(os.name) == 'nt' else "test"))
    assert 'type test.exe | some_wrapper' in cmd


# Generated at 2022-06-11 16:42:37.148560
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user("~") == b'Write-Output "\\$env:USERPROFILE"'
    assert shell.expand_user("~/test") == b"Write-Output ((Get-Location).Path + '\\test')"
    assert shell.expand_user("~test") == b"Write-Output '~test'"

# Generated at 2022-06-11 16:42:53.108763
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    powershell = ShellModule(connection='winrm')
    assert powershell.path_has_trailing_slash('C:\\path\\')
    assert powershell.path_has_trailing_slash('C:\\path\\to\\file\\')
    assert powershell.path_has_trailing_slash('C:\\path to\\file\\')
    assert powershell.path_has_trailing_slash('C:\\path to\\file with spaces\\')
    assert powershell.path_has_trailing_slash('C:/path/to/file/')
    assert powershell.path_has_trailing_slash('C:/path/to/file with spaces/')
    assert powershell.path_has_trailing_slash('\\\\server\\path\\to\\file\\')
    assert powershell.path_has

# Generated at 2022-06-11 16:42:54.563747
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    Unit test for constructor of class ShellModule
    '''
    assert (ShellModule != None)

# Generated at 2022-06-11 16:43:06.421368
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    m = ShellModule(None)

    assert m.build_module_command(env_string='export', shebang='#!powershell', cmd='Get-ChildItem') == 'type Get-ChildItem.ps1 | ICAgICJlcHBvcnQiOwoJIlNldC1TdHJpY3RNb2RlIC1WZXJzaW9uIExhdGVzdCIKCQoiR2V0LUNoaWxkSXRlbSI7Cg=='


# Generated at 2022-06-11 16:43:08.377378
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module is not None, 'Failed to instantiate ShellModule'

# Generated at 2022-06-11 16:43:13.400420
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == "powershell"
    assert module.get_remote_filename("/tmp/foo.sh") == "foo.sh"

# Generated at 2022-06-11 16:43:21.851846
# Unit test for constructor of class ShellModule
def test_ShellModule():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    import ansible.executor.powershell

    # Setup a module object
    module = AnsibleModule(
        argument_spec=dict(
            _raw_params=dict(),
            _uses_shell=dict(default=True, type='bool'),
            _executable=dict(default='powershell.exe', aliases=['ansible_shell_executable']),
        ),
        supports_check_mode=True
    )

    # Instantiate a ShellModule
    shell_plugin = ShellPlugin()

    # Assertions
    assert isinstance(shell_plugin.SHELL_FAMILY, type(u''))

# Generated at 2022-06-11 16:43:23.336325
# Unit test for constructor of class ShellModule
def test_ShellModule():
    f = ShellModule()
    assert isinstance(f, ShellModule)

# Generated at 2022-06-11 16:43:26.036243
# Unit test for constructor of class ShellModule
def test_ShellModule():
    plugin_instance = ShellModule()

    # Test wrap_for_exec
    assert plugin_instance.wrap_for_exec("dir") == '& dir; exit $LASTEXITCODE'

# Generated at 2022-06-11 16:43:37.014504
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # these tests will fail if there's a default shell set.
    # we need to ensure that there's no default shell.
    import ansible.module_utils
    try:
        del ansible.module_utils._SHELL_DEFAULT
    except AttributeError:
        pass

    # Powershell should be selected for winrm
    assert ShellModule.is_shell_configured(connection='winrm')
    assert ShellModule.is_shell_configured(connection='psrp')
    assert ShellModule.is_shell_configured(connection='ssh', default_shell='powershell')

    # Powershell may not be selected for ssh
    assert not ShellModule.is_shell_configured(connection='ssh')
    assert not ShellModule.is_shell_configured(connection='ssh', default_shell='bash')

# Generated at 2022-06-11 16:43:39.678659
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Test whether ShellModule can be created."""
    # this will raise if the constructor cannot be invoked.
    shell = ShellModule(None)



# Generated at 2022-06-11 16:43:54.541467
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.utils.path import unfrackpath
    from ansible.module_utils._text import to_bytes
    sm = ShellModule(conn=None, tmp_path=unfrackpath("/tmp"))
    assert sm is not None
    assert sm._IS_WINDOWS is True
    b_script = sm.wrap_for_exec("echo STDERR >&2; echo STDOUT; exit 1")
    assert b_script == b'& echo STDERR >&2; echo STDOUT; exit 1; exit $LASTEXITCODE'
    # Windows paths should be returned with forward slashes
    assert sm.join_path("C:/users", "foo\\bar", "hello") == "C:/users\\foo/bar\\hello"

# Generated at 2022-06-11 16:43:55.533035
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()


# Generated at 2022-06-11 16:44:00.350907
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """This function is used to test the constructor of the class."""
    # create object of class Cmd
    cmd = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    powershell_obj = ShellModule(cmd)

    # Assert the instance of class
    assert isinstance(powershell_obj, ShellModule)

# Generated at 2022-06-11 16:44:03.939707
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS is True


# Generated at 2022-06-11 16:44:13.869569
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    assert shell.SHELL_FAMILY == 'powershell'

# Powershell doesn't support stderr redirection, so all stderr output goes to
# the actual stderr.  Also, it doesn't support initial newlines.
#
# For now, we don't support the following things:
#   Becuase $env:HOME isn't set, we don't support ~ expansion.  We do support
#   $env:UserProfile, though.
#
#   There's no way to set the permission bits.  We can emulate it using
#   icacls, but icacls doesn't seem to be installed on 2008R2.  We may support
#   Powershell 3.0 and above in the future, though.
#
#   We don't support umask, since I can't find a

# Generated at 2022-06-11 16:44:24.399272
# Unit test for constructor of class ShellModule
def test_ShellModule():
    args = {}
    args['connection'] = 'ssh'
    args['_ansible_no_log'] = False
    args['_ansible_debug'] = False
    args['_ansible_diff'] = False
    args['_ansible_verbosity'] = 1
    args['_ansible_syslog_facility'] = None
    args['_ansible_socket'] = None
    args['_ansible_shell_executable'] = None
    args['_ansible_selinux_special_fs'] = ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p']
    args['binary_file'] = False
    args['rc'] = 0
    args['stdin'] = None
    args['stdin_add_newline'] = False
    args['warn'] = False

# Generated at 2022-06-11 16:44:27.346642
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    requested_version = False
    assert module.IS_WINDOWS == requested_version

# Generated at 2022-06-11 16:44:32.886094
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # A test case for the constructor of class ShellModule
    # Input of the function
    #   -
    # Output of the function
    #   -
    # The results that are expected to be returned
    #   -
    # The results that are returned
    #   -
    shell_obj = ShellModule(connection=None, run_command_environ_update=None)
    assert shell_obj.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-11 16:44:35.924980
# Unit test for constructor of class ShellModule
def test_ShellModule():
    cls = ShellModule()
    assert cls.SHELL_FAMILY == 'powershell'
    assert cls._IS_WINDOWS == True

# Generated at 2022-06-11 16:44:39.809389
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection='local', tmpdir='/tmp')
    assert shell
    assert shell._connection == 'local'
    assert shell._shell_type == 'powershell'
    assert shell._shebang == 'powershell'


# Generated at 2022-06-11 16:44:56.993950
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Check for an unquoted path.
    assert ShellModule(connection=None)._unquote('C:\\Program Files') == 'C:\\Program Files'
    # Check for a path where one set of quotes is stripped out.
    assert ShellModule(connection=None)._unquote('"C:\\Users\\John Doe"') == 'C:\\Users\\John Doe'
    # Check for a path where one set of quotes is stripped out, with spaces.
    assert ShellModule(connection=None)._unquote('"C:\\Users\\John Doe\\My Documents"') == 'C:\\Users\\John Doe\\My Documents'
    # Check for a path with quotes escaped.

# Generated at 2022-06-11 16:44:58.938252
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:45:00.581091
# Unit test for constructor of class ShellModule
def test_ShellModule():
    plugin = ShellModule('.')
    assert plugin._IS_WINDOWS is True

# Generated at 2022-06-11 16:45:06.267139
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    print(obj)
    assert obj.COMPATIBLE_SHELLS == frozenset()
    assert obj.SHELL_FAMILY == 'powershell'
    assert obj._IS_WINDOWS == True
    assert obj._SHELL_REDIRECT_ALLNULL == '> $null'
    assert obj._SHELL_AND == ';'


# Generated at 2022-06-11 16:45:17.509189
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import json
    import unittest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import ImmutableDict

    immutabledict = ImmutableDict

    class TestShellModule(unittest.TestCase):

        def test_parse_clixml(self):
            from ansible.plugins.shell.powershell import _parse_clixml


# Generated at 2022-06-11 16:45:25.193393
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert hasattr(ShellModule, '_unquote')
    # test value = ''
    assert ShellModule._unquote('') == ''
    # test value = 'somevalue'
    test_value = 'somevalue'
    assert ShellModule._unquote(test_value) == test_value
    # test value = '"somevalue"'
    test_value = '"somevalue"'
    assert ShellModule._unquote(test_value) == 'somevalue'
    # test value = "'somevalue'"
    test_value = "'somevalue'"
    assert ShellModule._unquote(test_value) == 'somevalue'
    # test value = '''somevalue'''
    test_value = '''somevalue'''
    assert ShellModule._unquote(test_value) == 'somevalue'
    # test value = "'''

# Generated at 2022-06-11 16:45:37.254297
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    m = ShellModule()
    assert m.path_has_trailing_slash('C:\\xyz\\')
    assert m.path_has_trailing_slash('C:\\xyz\\abc') is False
    assert m.path_has_trailing_slash('C:\\xyz\\abc\\')
    assert m.path_has_trailing_slash('C:\\xyz\\abc\\def\\')
    assert m.path_has_trailing_slash('C:\\xyz\\abc\\def\\ ')
    assert m.path_has_trailing_slash('C:\\xyz\\abc\\def\\ ') is False
    assert m.path_has_trailing_slash('C:\\xyz\\abc\\def') is False

# Generated at 2022-06-11 16:45:42.941238
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule(connection='winrm')
    assert powershell.SHELL_FAMILY == 'powershell'
    assert powershell._IS_WINDOWS is True
    assert powershell._SHELL_AND == ';'
    assert powershell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert powershell.COMPATIBLE_SHELLS == frozenset()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-vv'])

# Generated at 2022-06-11 16:45:44.260479
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm is not None

# Generated at 2022-06-11 16:45:45.523716
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    assert m

# Generated at 2022-06-11 16:46:03.219044
# Unit test for constructor of class ShellModule
def test_ShellModule():

    bo = ShellModule()

    # Test _escape
    assert bo._escape("string") == "string"
    assert bo._escape("'") == "\'\'\\\'"
    assert bo._escape("\\") == "\\\\"
    assert bo._escape("\\'") == "\\\\\'\\\'"
    assert bo._escape("$string") == "$string"
    assert bo._escape("$'") == "$\'"
    assert bo._escape("$'string") == "$\'string"
    assert bo._escape("$''") == "$\'\'\\\'"

    # Test _unquote
    assert bo._unquote("") == ""
    assert bo._unquote("'") == "'"
    assert bo._unquote("\"") == "\""
    assert bo._unquote("'string'") == "string"
    assert bo._un

# Generated at 2022-06-11 16:46:08.221562
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'

    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS



# Generated at 2022-06-11 16:46:19.602822
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    def get_module(*args, **kwargs):
        return ShellModule(connection=None, *args, **kwargs)

    module = get_module(no_log=True)

    # Test with forward slash
    assert module.path_has_trailing_slash('C:/tmp/foo/')
    assert module.path_has_trailing_slash('C:/tmp/foo//')
    assert module.path_has_trailing_slash('/tmp/foo/')
    assert module.path_has_trailing_slash('/tmp/foo//')
    assert not module.path_has_trailing_slash('C:/tmp/foo')
    assert not module.path_has_trailing_slash('/tmp/foo')

    # Test with back slash
    assert module.path_has_trailing_sl

# Generated at 2022-06-11 16:46:23.502909
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh_module = ShellModule()
    assert sh_module.SHELL_FAMILY == 'powershell'
    assert sh_module.COMPATIBLE_SHELLS in ([], set())
    assert sh_module._IS_WINDOWS

# Generated at 2022-06-11 16:46:31.062353
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule(connection=None)
    assert p.command_has_changed("whoami", "whoami") is False

    p.set_options("whoami")
    assert p.command_has_changed("whoami", "whoami") is False

    p.set_options("whoami")
    assert p.command_has_changed("whoami", "whoami") is False

    p.set_options("whoami")
    assert p.command_has_changed("whoami", "whoami") is False

    p.set_options("whoami")
    assert p.command_has_changed("whoami", "whoami") is False

    assert p.join_path("C:/whoami", "whoami") == "C:\\whoami\\whoami"

# Generated at 2022-06-11 16:46:36.666198
# Unit test for constructor of class ShellModule
def test_ShellModule():
    plugin = ShellModule(connec=None, runner_on_failed=None, runner_on_ok=None,
                         runner_on_unreachable=None, runner_on_async_poll=None,
                         runner_on_async_ok=None, runner_on_async_failed=None,
                         runner_on_file_diff=None)
    assert plugin is not None

# Generated at 2022-06-11 16:46:39.872279
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule().COMPATIBLE_SHELLS == frozenset()
    assert ShellModule().SHELL_FAMILY == 'powershell'
    assert ShellModule()._IS_WINDOWS is True


# Generated at 2022-06-11 16:46:47.373068
# Unit test for constructor of class ShellModule
def test_ShellModule():

    def get_test_instance():
        return ShellModule()

    # The first test verifies that the constuctor is called without arguments
    try:
        # Create a new instance of the class with the default constructor
        test_instance = get_test_instance()
    except TypeError:
        # If the default constructor fails, display the appropriate exception
        print('ShellModule() takes no parameters.')
    except Exception as exception_instance:
        # If any other exception occurs, include the type of exception
        print('ShellModule() threw an exception of type ' + str(type(exception_instance)))

    # The second test verifies that the constuctor is called with one argument

# Generated at 2022-06-11 16:46:48.898769
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod is not None


# Generated at 2022-06-11 16:46:49.874755
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule() is not None

# Generated at 2022-06-11 16:47:08.418276
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Verify that the constructor of PowerShell shells works correctly
    sm = ShellModule('winrm', '', '', None, None, '')
    assert sm


# Generated at 2022-06-11 16:47:12.066781
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():

    args = {
        'path': 'C:\\ansible\\test\\',
        '_uses_shell': False
    }

    assert (ShellModule().path_has_trailing_slash(**args))

# Generated at 2022-06-11 16:47:20.342138
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule(VarsModule())
    assert not shell.path_has_trailing_slash("")
    assert not shell.path_has_trailing_slash("/")
    assert not shell.path_has_trailing_slash("\\")
    assert not shell.path_has_trailing_slash("/path/to/something")
    assert not shell.path_has_trailing_slash("\\path\\to\\something")
    assert shell.path_has_trailing_slash("/path/to/something/")
    assert shell.path_has_trailing_slash("\\path\\to\\something\\")


# Generated at 2022-06-11 16:47:29.218840
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/test/test')
    assert shell.path_has_trailing_slash('/test/test/')
    assert shell.path_has_trailing_slash('test/test')
    assert shell.path_has_trailing_slash('test/test/')
    assert shell.path_has_trailing_slash('c:/test/test')
    assert shell.path_has_trailing_slash('c:/test/test/')
    assert shell.path_has_trailing_slash('z:/test/test')
    assert shell.path_has_trailing_slash('z:/test/test/')
    assert shell.path_has_trailing_slash('z:\\test\\test')

# Generated at 2022-06-11 16:47:38.711564
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Constructor
    module = ShellModule()

    # Ensure that the constructor properly initialized module
    assert hasattr(module, 'COMPATIBLE_SHELLS')
    assert hasattr(module, '_SHELL_REDIRECT_ALLNULL')
    assert hasattr(module, '_SHELL_AND')
    assert hasattr(module, '_IS_WINDOWS')
    assert hasattr(module, 'env_prefix')
    assert hasattr(module, 'join_path')
    assert hasattr(module, 'get_remote_filename')
    assert hasattr(module, 'path_has_trailing_slash')
    assert hasattr(module, 'chmod')
    assert hasattr(module, 'chown')
    assert hasattr(module, 'set_user_facl')
    assert hasattr(module, 'remove')

# Generated at 2022-06-11 16:47:42.723657
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)

    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS
    assert shell._SHELL_AND == ';'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-11 16:47:44.995074
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-11 16:47:48.217309
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell is not None
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True

# Generated at 2022-06-11 16:47:54.808580
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module is not None
    assert not module.COMPATIBLE_SHELLS
    assert module.SHELL_FAMILY == 'powershell'
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module._IS_WINDOWS == True


# Generated at 2022-06-11 16:47:59.003704
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'

    assert sm._IS_WINDOWS is True

    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:48:19.771604
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pytest.importorskip('winrm')
    from ansible.executor.powershell import ShellModule

    shell_obj = ShellModule()
    assert shell_obj._IS_WINDOWS == True
    assert shell_obj.COMPATIBLE_SHELLS == frozenset()
    assert shell_obj.SHELL_FAMILY == 'powershell'
    assert shell_obj._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_obj._SHELL_AND == ';'


# Generated at 2022-06-11 16:48:31.404585
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell._SHELL_REDIRECT_ALLNULL == "> $null"
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS
    assert shell.env_prefix() == ""
    assert shell.join_path() == "."
    assert shell.join_path("/tmp/ansible") == "/tmp/ansible"
    assert shell.join_path("/tmp//ansible") == "/tmp/ansible"
    assert shell.join_path("/tmp", "ansible") == "/tmp/ansible"
    assert shell.join_path(u"C:\\tmp", "ansible") == "C:\\tmp\\ansible"

# Generated at 2022-06-11 16:48:36.845693
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule('/path/to/module', 'utf-8')
    assert shell._connection is None
    assert shell.shebang == "#!powershell"
    assert shell._cleanup_shell is True
    assert shell._socket_path == '/path/to/module'
    assert shell.DEFAULT_EXECUTABLE == 'powershell.exe'
    assert shell._encoding == 'utf-8'
    assert hasattr(shell, '_shell')

# Generated at 2022-06-11 16:48:39.531296
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    for shell_type in ShellModule.COMPATIBLE_SHELLS:
        assert shell.supports_shell(shell_type) is False

# Generated at 2022-06-11 16:48:43.080435
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, add_final_newline=False)
    assert hasattr(shell, '_IS_WINDOWS') is True


# Generated at 2022-06-11 16:48:48.868854
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module._IS_WINDOWS == True
    assert module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-11 16:49:00.579504
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test non-pipelining with shebang
    module = ShellModule()
    cmd = module.build_module_command("some env string", "#!powershell", "a command")
    assert b"bootstrap_wrapper.ps1" in cmd
    assert b'a command' in cmd

    # Test non-pipelining without shebang
    cmd = module.build_module_command("some env string", "", "a command")
    assert b"bootstrap_wrapper.ps1" in cmd
    assert b'a command' in cmd

    # Test pipelining
    cmd = module.build_module_command("some env string", "", "")
    assert b"bootstrap_wrapper.ps1" in cmd
    assert b'$input' in cmd


# Generated at 2022-06-11 16:49:01.804563
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO
    pass

# Generated at 2022-06-11 16:49:13.006803
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell import ShellModule as TestShellModule
    from ansible.module_utils.powershell import is_binary_file
    from ansible.module_utils.powershell import _encode_text
    import sys

    # This is used to encode unicode characters in the script
    # pipelining bypass
    cmd = ''
    assert TestShellModule().build_module_command('', None, None) == TestShellModule().build_module_command('', '', '')

    # non-pipelining
    cmd = '''Get-Command'''
    assert TestShellModule().build_module_command('', None, cmd) == TestShellModule().build_module_command('', '', cmd)
    cmd = '''Get-Command ;'''

# Generated at 2022-06-11 16:49:17.700507
# Unit test for constructor of class ShellModule
def test_ShellModule():
    myShellModule = ShellModule()
    assert myShellModule.COMPATIBLE_SHELLS is not None
    assert myShellModule.SHELL_FAMILY == 'powershell'
    assert myShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert myShellModule._SHELL_AND == ';'
    assert myShellModule._IS_WINDOWS is True


# Generated at 2022-06-11 16:49:54.948923
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    return m.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:50:01.731858
# Unit test for constructor of class ShellModule
def test_ShellModule():
    action = 'helloworld'
    testObj = ShellModule(action)
    assert testObj.COMPATIBLE_SHELLS == frozenset()
    assert testObj.SHELL_FAMILY == 'powershell'
    assert testObj._IS_WINDOWS
    assert testObj._SHELL_REDIRECT_ALLNULL == '> $null'
    assert testObj._SHELL_AND == ';'

# Unit tests for function test_ShellModule.join_path

# Generated at 2022-06-11 16:50:04.018376
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert isinstance(module.SHELL_FAMILY, str)

# Generated at 2022-06-11 16:50:04.763375
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()

# Generated at 2022-06-11 16:50:07.103607
# Unit test for constructor of class ShellModule
def test_ShellModule():

    for key in ['shell_type', 'shebang', '_IS_BINARY', '_IS_WINDOWS']:
        assert hasattr(ShellModule, key)



# Generated at 2022-06-11 16:50:08.143627
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule() is not None

# Generated at 2022-06-11 16:50:12.207761
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._IS_WINDOWS == True



# Generated at 2022-06-11 16:50:14.180819
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Test ShellModule() to ensure it can be created
    """
    module_args = dict()
    shell = ShellModule(module_args)

# Generated at 2022-06-11 16:50:23.332369
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell
    assert repr(shell)
    assert shell._IS_WINDOWS
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'posix'
    assert shell.path_has_trailing_slash('test/')
    assert not shell.path_has_trailing_slash('test')
    assert not shell.path_has_trailing_slash('/test')
    assert not shell.path_has_trailing_slash('C:\\test')
    assert not shell.path_has_trailing_slash('C:\\test\\')
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.py') == 'test.py'


# Generated at 2022-06-11 16:50:26.246357
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

    for key in dir(sm):
        if not key.endswith('__'):
            assert hasattr(ShellBase, key)