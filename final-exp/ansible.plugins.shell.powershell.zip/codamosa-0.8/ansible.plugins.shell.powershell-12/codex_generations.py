

# Generated at 2022-06-11 16:41:39.478262
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    module = ShellModule()
    assert module.expand_user('~') == 'VwByAGkAdABlAHIAIABwAHIAbwBjAG8AbABlAGQAIAB1AHQAaABlAHIA'
    assert module.expand_user('~\\test') == 'VwByAGkAdABlAHIAIABwAHIAbwBjAG8AbABlAGQAIAB1AHQAaABlAHIATwBNAGUAcgBpAGwAZQB0ACAA'

# Generated at 2022-06-11 16:41:41.153003
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

    assert sm


# Generated at 2022-06-11 16:41:42.194072
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule(connection=None) is not None

# Generated at 2022-06-11 16:41:53.770253
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.module_common import module_response
    from ansible.executor.connection_info import ConnectionInformation
    from ansible.module_utils.basic import AnsibleModule

    # Test running a module as a script via the bootstrap wrapper
    module_name = 'TestModule'
    module_args = dict()

    connection = ConnectionInformation('winrm', 'ntdomain\\user', 'pass', 'ntdomain', port=5986)
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False,
        bypass_checks=False,
    )
    shell = ShellModule(connection)

    response, rc = shell.run(module_name, module_args, module.check_mode, module)

    # The module has not been written yet.  Instead of creating a fake module


# Generated at 2022-06-11 16:42:04.754169
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.module_utils.powershell import shell_interface

    def _test_build_module_command(shell_name, module, shebang, remote_host, tmpdir, remote_user='', arg_path='', expected_rc=None, return_postprocessed_cmd=False):
        if not arg_path:
            arg_path = tmpdir

        s = shell_interface.ShellModule(shell_name, remote_host, remote_user, tmpdir, module, shebang, arg_path)

        cmd = s.build_module_command(shebang, module, arg_path)
        if expected_rc is not None:
            assert cmd.strip().endswith('Exit %d' % expected_rc)
        if return_postprocessed_cmd:
            return s.wrap_for_exec(cmd)
        return cmd

# Generated at 2022-06-11 16:42:09.010711
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    obj = ShellModule(command='', prompt=None, new_stdin='', runner=None)
    with pytest.raises(NotImplementedError):
        result = obj.path_has_trailing_slash(path=None)


# Generated at 2022-06-11 16:42:13.522967
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS is True
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm._SHELL_AND == ';'

# Generated at 2022-06-11 16:42:17.902229
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Create a new ShellModule instance
    sm = ShellModule()

    # Create a new Script instance
    script = Script('')

    # Create a new Command instance
    cmd = Command('dir')

    # Obtain the command string for the 'dir' command
    cmd_str = sm.get_command_str(cmd)

    # Print the command string
    print(cmd_str)

    # Obtain the command string for the script
    script_str = sm.get_command_str(script)

    # Print the script string
    print(script_str)

# Generated at 2022-06-11 16:42:24.276055
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    test_shell = ShellModule()
    # Test for Powershell: Expand for user ~/foo/bar
    test_shell.path_exists = lambda path: True
    assert test_shell.expand_user('~') == test_shell._encode_script(script="Write-Output (Get-Location).Path")
    assert test_shell.expand_user('~\\test') == test_shell._encode_script(script="Write-Output ((Get-Location).Path + '\\\\test')")
    assert test_shell.expand_user('\\\\test\\test') == test_shell._encode_script(script="Write-Output '\\\\test\\\\test'")

# Generated at 2022-06-11 16:42:33.260831
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()


# Generated at 2022-06-11 16:42:44.976520
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    module = ShellModule(None)
    assert not module.path_has_trailing_slash('/usr')
    assert not module.path_has_trailing_slash('usr')
    assert not module.path_has_trailing_slash('\\usr')
    assert not module.path_has_trailing_slash('c:\\windows')
    assert not module.path_has_trailing_slash('c:/windows')

    assert module.path_has_trailing_slash('/usr/')
    assert module.path_has_trailing_slash('usr/')
    assert module.path_has_trailing_slash('\\usr\\')
    assert module.path_has_trailing_slash('c:\\windows\\')

# Generated at 2022-06-11 16:42:55.596317
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    assert ShellModule(None).build_module_command('', '', '') == '& type bootstrap_wrapper.ps1; exit $LASTEXITCODE'

    assert ShellModule(None).build_module_command('', '#!/bin/bash\n', '', 'arg_path') == '& bash -c \'\n' \
                                                                                        '            Try\n' \
                                                                                        '            {\n' \
                                                                                        '                \n' \
                                                                                        '                arg_path\n' \
                                                                                        '            }\n' \
                                                                                        '            Catch\n' \
                                                                                        '            {\n' \
                                                                                        '                $_obj = @{ failed = $true }\n' \
                                                                                       

# Generated at 2022-06-11 16:43:07.796872
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert isinstance(module._SHELL_REDIRECT_ALLNULL, str)
    assert isinstance(module.SHELL_FAMILY, str)
    assert module.SHELL_FAMILY == 'powershell'
    assert isinstance(module._IS_WINDOWS, bool)
    assert module._IS_WINDOWS is True
    assert isinstance(module.COMPATIBLE_SHELLS, frozenset)
    assert len(module.COMPATIBLE_SHELLS) == 0
    assert isinstance(module.env_prefix(None), str)
    assert module.env_prefix(None) == ""
    assert isinstance(module.join_path(None, None), str)
    assert isinstance(module.get_remote_filename(None), str)

# Generated at 2022-06-11 16:43:19.200564
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    module = ShellModule(connection=None, play_context=None, shell_executable=None)
    assert module.path_has_trailing_slash('C:\\test\\test.txt') is False
    assert module.path_has_trailing_slash('C:\\test\\test.txt\\') is True
    assert module.path_has_trailing_slash('C:\\test\\') is True
    assert module.path_has_trailing_slash('C:\\test\\test folder') is False
    assert module.path_has_trailing_slash('C:\\test\\test folder\\') is True
    assert module.path_has_trailing_slash('C:\\test\\test\foo') is False

# Generated at 2022-06-11 16:43:24.706139
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule({'no_log': False, '_ansible_no_log': False})
    assert m.SHELL_FAMILY == 'powershell'
    assert m._SHELL_REDIRECT_ALLNULL == '> $null'
    assert m._SHELL_AND == ';'
    assert m._IS_WINDOWS
    assert not hasattr(m, '_is_pipelining')


# Generated at 2022-06-11 16:43:26.185730
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    assert s.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:43:37.326992
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    env_string = '$env:ANSIBLE_MODULE_ARGS = ConvertFrom-Json @"\r\n{"ANSIBLE_MODULE_ARGS": "ANSIBLE_MODULE_ARGS"}\r\n"@'
    shebang = '#!powershell'
    cmd = 'Write-Output $env:ANSIBLE_MODULE_ARGS'
    arg_path = None

# Generated at 2022-06-11 16:43:47.764356
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    '''
    test get_remote_filename method of class ShellModule
    '''
    st_module = ShellModule()

    assert st_module.get_remote_filename('/home/powershell') == 'powershell'
    assert st_module.get_remote_filename('/home/powershell.ps1') == 'powershell.ps1'
    assert st_module.get_remote_filename('/home/powershell.exe') == 'powershell.exe'
    assert st_module.get_remote_filename('/home/powershell.txt') == 'powershell.ps1'
    assert st_module.get_remote_filename('C:\\Documents and Settings\\powershell') == 'powershell'

# Generated at 2022-06-11 16:43:52.506983
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule('windows', 'ansible')
    obj.set_options({'ansible_shell_executable': '/bin/sh', 'ansible_shell_type': 'powershell'})
    assert obj.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:43:56.279551
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm._IS_WINDOWS
    assert sm.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:44:01.832141
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-11 16:44:12.654861
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    bootstrap_wrapper_encoded = to_text(base64.b64encode(bootstrap_wrapper.encode('utf-16-le')), 'utf-8')
    shell = ShellModule()
    cmd = None
    shebang = None
    env_string = None
    arg_path = None

    # Testing with shebang 'powershell'
    # Non-pipeline
    shebang = '#!powershell'
    cmd = '''
            Write-Output "Hello";
            Throw "oops";
        '''
    result = shell.build_module_command(env_string, shebang, cmd, arg_path)

# Generated at 2022-06-11 16:44:23.841950
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test that command is unchanged when shebang is not specified
    obj = ShellModule()
    cmd = 'test_module -a "b c"'
    expected = 'test_module -a "b c"'
    actual = obj.build_module_command('', '', cmd)
    assert expected == actual

    # Test that command is unchanged when shebang is not valid ps shebang
    obj = ShellModule()
    cmd = 'test_module -a "b c"'
    expected = 'test_module -a "b c"'
    actual = obj.build_module_command('', '#!/bin/sh', cmd)
    assert expected == actual

    # Test that command is unchanged when shebang is not specified and binary module
    obj = ShellModule()
    cmd = 'test_module -a "b c"'

# Generated at 2022-06-11 16:44:28.348196
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert hasattr(obj, 'run')
    assert hasattr(obj, 'get_remote_filename')
    assert hasattr(obj, '_escape')
    assert hasattr(obj, '_encode_script')

# Generated at 2022-06-11 16:44:40.274210
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('C:\\hello\\') == True
    assert shell.path_has_trailing_slash('C:\\hello') == False
    assert shell.path_has_trailing_slash('C:\\hello\\close\\') == True
    assert shell.path_has_trailing_slash('C:\\hello\\close') == False
    assert shell.path_has_trailing_slash('C:\\hello\\near\\') == True
    assert shell.path_has_trailing_slash('C:\\hello\\near') == False
    assert shell.path_has_trailing_slash('C:\\hello\\far\\') == True
    assert shell.path_has_trailing_slash('C:\\hello\\far') == False


# Generated at 2022-06-11 16:44:43.130985
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule().SHELL_FAMILY == 'powershell'
    assert ShellModule._IS_WINDOWS is True


# Generated at 2022-06-11 16:44:50.808913
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import os
    from ansible.module_utils.remote_management.shell.powershell import ShellModule
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY2

    if PY2:
        import sys

        reload(sys)
        sys.setdefaultencoding('utf8')

    get_option = os.environ.get
    connection = StringIO()
    shell = ShellModule(connection)

    # Load the module
    module = {}
    module['_ansible_remote_tmp'] = '/tmp/ansible'

    # Test the module constructor
    def test_shell_args(*args, **kwargs):
        return shell._encode_script(*args, **kwargs)


# Generated at 2022-06-11 16:44:51.973895
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()


# Generated at 2022-06-11 16:45:04.145787
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    shell._IS_WINDOWS = True
    assert shell.path_has_trailing_slash('/') is True
    assert shell.path_has_trailing_slash('\\') is True
    assert shell.path_has_trailing_slash('/test/') is True
    assert shell.path_has_trailing_slash('/test\\') is True
    assert shell.path_has_trailing_slash('\\test/') is True
    assert shell.path_has_trailing_slash('\\test\\') is True
    assert shell.path_has_trailing_slash('test/') is True
    assert shell.path_has_trailing_slash('test\\') is True
    assert shell.path_has_trailing_slash('test') is False

# Generated at 2022-06-11 16:45:05.003662
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, shell_type=None)


# Generated at 2022-06-11 16:45:09.962041
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule() is not None

# Generated at 2022-06-11 16:45:21.160352
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # ansible 2.9.0
    # ansible.module_utils.powershell.windows.base_exec
    from ansible.module_utils.powershell.windows.base_exec import (
        escape, _parse_clixml, encode_script
    )

    # _parse_clixml 的输入是 byte 类型
    # assert _parse_clixml(b'#< CLIXML\r\n<Objs...') == b'\r\n'.join(lines)


    # Pre-requisities
    shell_module = ShellModule()

    # assert shell_module.COMPATIBLE_SHELLS == frozenset()
    # assert shell_module._IS_WINDOWS == True
    # assert shell_module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:45:25.116084
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    Validate the object construction of class ShellModule and some of its properties
    '''
    shell_module = ShellModule(connection=None)
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True

# Generated at 2022-06-11 16:45:25.764460
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:45:29.914812
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell1 = ShellModule()
    assert shell1.COMPATIBLE_SHELLS == frozenset()
    assert shell1.SHELL_FAMILY == 'powershell'
    assert shell1._IS_WINDOWS


# Generated at 2022-06-11 16:45:41.228804
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell
    import ansible.plugins.shell
    import ansible.utils.shlex

    cmd = '#!powershell\nWrite-Output "Hello, world from test"'
    encoded = ansible.plugins.shell.ShellModule()._encode_script(cmd)

    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    cmd_parts = [''] + ansible.utils.shlex.split("type a | & " + bootstrap_wrapper + "; exit $LASTEXITCODE")
    assert encoded == ' '.join(cmd_parts)

    cmd = '#!powershell\n/path/to/module.ps1 test op'
    encoded = ansible.plugins.shell.ShellModule()._en

# Generated at 2022-06-11 16:45:52.497605
# Unit test for constructor of class ShellModule
def test_ShellModule():

    import os
    from ansible.context import context

    stdin = os.fdopen(0)
    stdout = os.fdopen(1, 'w')
    stderr = os.fdopen(2, 'w')

    manager = context.CLIContext(stdin=stdin, stdout=stdout, stderr=stderr)

    options = manager.options

    shell_plugin = ShellModule(manager)

    cmd = shell_plugin.build_module_command('env', '#!powershell', 'test.py arg1 arg2')
    assert b"& type 'test.py.ps1' | " in cmd
    assert b"& 'test.py arg1 arg2'" not in cmd


# Generated at 2022-06-11 16:45:55.611765
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_script = ShellModule()
    assert shell_script is not None and repr(shell_script) is not None


# Generated at 2022-06-11 16:46:05.813815
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # pylint: disable=W0110
    # The docstrings below are assigned to the instance of the test_shell
    # plugin.  It is not clear why they are ignored by pylint.
    test_shell = ShellModule()

    test_shell.DOCUMENTATION = '''
        This is the documentation for test_shell.
        '''

    test_shell.EXAMPLES = '''
        This is an example for test_shell.
        '''

    test_shell.RETURN = r'''
        This is the return documentation for test_shell.
        '''

    if test_shell.DOCUMENTATION != '''
        This is the documentation for test_shell.
        ''':
        raise AssertionError('Test assign docstring to DOCUMENTATION failed.')


# Generated at 2022-06-11 16:46:14.952672
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

    shell_obj = ShellModule(None, None)

    # Execute PowerShell pipeline
    result = shell_obj.build_module_command('', None, '', None)
    assert bootstrap_wrapper.decode('utf-8') in to_text(result)

    # Execute PowerShell script
    result = shell_obj.build_module_command('', None, '#!powershell "Get-Process"', None)
    script = '''\
        Try
        {
            type Get-Process | %s
        }
        ''' % bootstrap_wrapper.decode('utf-8')
    assert script in to_text(result)

    # Execute PowerShell script
    result = shell_obj