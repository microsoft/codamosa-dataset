

# Generated at 2022-06-11 16:41:39.549539
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    return_value = ShellModule(connection=None).get_remote_filename('/etc/foo.conf')
    assert return_value == 'foo.conf'
    return_value = ShellModule(connection=None).get_remote_filename('/etc/foo.conf.j2')
    assert return_value == 'foo.conf.j2'



# Generated at 2022-06-11 16:41:50.652934
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module
    assert module.get_remote_filename('') == ''
    assert module.get_remote_filename('/a/b/c.py') == 'c.py'
    assert module.get_remote_filename('/a/b/c.ps1') == 'c.ps1'
    assert module.get_remote_filename('/a/b/c.exe') == 'c.exe'
    assert module.get_remote_filename('/a/b/c') == 'c.ps1'

# Generated at 2022-06-11 16:42:02.800690
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # NOTE: The tests assume that the following directory structure is present
    #       in the test execution environment:
    #
    #       test_user1:
    #           user1_home_dir
    #           user1_home_dir/test_user1_shared_directory
    #       test_user2:
    #           user2_home_dir
    #           user2_home_dir/test_user2_shared_directory

    test_user1_home_dir = os.path.join('c:\\test_user1', 'user1_home_dir')
    test_user1_shared_dir = os.path.join('c:\\test_user1', 'user1_home_dir', 'test_user1_shared_directory')
    test_user1_shared_dir_escaped = test_user1_shared

# Generated at 2022-06-11 16:42:04.268394
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellmodule = ShellModule()
    assert type(shellmodule) is ShellModule


# Generated at 2022-06-11 16:42:14.175859
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell import ShellModule, _parse_clixml
    from ansible.module_utils import six
    from ansible.module_utils._text import to_bytes, to_text

    class MockOptions:
        def __init__(self):
            self.remote_tmp = "$env:TEMP"
            self.module_tmp_dir = self.remote_tmp

    class MockConnection:
        def __init__(self):
            self.options = MockOptions()

        def join_path(self, *args):
            path = args[0]
            for p in args[1:]:
                path = os.path.join(path, p).replace("\\", "\\\\")
            return path


# Generated at 2022-06-11 16:42:17.263746
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    # Test to make sure that the 'shell' variable is initialized as expected
    result = mod.SHELL_FAMILY
    assert (result == 'powershell')

# Generated at 2022-06-11 16:42:21.696174
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    '''Unit test method get_remote_filename of class ShellModule'''
    sm = ShellModule()
    assert sm.get_remote_filename('\\C:\\Windows\\System32\\cmd.exe') == 'cmd.exe'
    assert sm.get_remote_filename('\\C:\\Windows\\System32\\some_script') == 'some_script.ps1'


# Generated at 2022-06-11 16:42:31.221242
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test parsing of pscmdlet_errors
    cmd_output = b'<Objs Version="1.1.0.1" xmlns="http://schemas.microsoft.com/powershell/2004/04"><S S="Error">The specified host name is not valid</S><S S="Error"> + CategoryInfo          : InvalidType: (:) [], CimException\r\n</S><S S="Error"> + FullyQualifiedErrorId : [InvalidOperation]Invalid host name. Specify a valid host name, IP address or URI.</S></Objs>'
    assert False is _parse_clixml(to_bytes('#< CLIXML\r\n%s' % cmd_output)).splitlines()[-1].startswith('+')

# Generated at 2022-06-11 16:42:36.776027
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    sm = ShellModule()
    pathname1 = 'a/b/c/d/e.ps1'
    pathname2 = 'a\\b\\c\\d\\e'
    assert sm.get_remote_filename(pathname1) == 'e.ps1'
    assert sm.get_remote_filename(pathname2) == 'e.ps1'



# Generated at 2022-06-11 16:42:43.372789
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shellmodule = ShellModule()
    assert 'filename.ps1' == shellmodule.get_remote_filename('/path/to/filename.ps1')
    assert 'filename.exe' == shellmodule.get_remote_filename('/path/to/filename.exe')
    assert 'filename.ps1' == shellmodule.get_remote_filename('filename.ps1')
    assert 'filename.exe' == shellmodule.get_remote_filename('filename.exe')
    assert 'filename.ps1' == shellmodule.get_remote_filename('filename')


# Generated at 2022-06-11 16:42:57.815080
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''Create an instance of the ShellModule class
       and assert that the constructor returns an object.'''
    from ansible.module_utils.common.text.template import template

    class TestConnection():
        def __init__(self):
            self.become_method = 'runas'
            self.module_implementation_preferences = ['win_shell', 'win_powershell']

    class TestOptions():
        def __init__(self):
            self.connection = 'local'
            self.remote_tmp = '/tmp'
            self.shell_type = 'powershell'

    test_connection = TestConnection()
    test_options = TestOptions()
    test_module = AnsibleModule(argument_spec=dict())
    test_module._ansible_connection = test_connection
    test_module._ansible_shell = None

# Generated at 2022-06-11 16:43:09.537975
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    plugin = ShellModule()
    # Verify that '~' is expanded to user's home directory
    assert plugin.expand_user('~') == plugin._encode_script('Write-Output (Get-Location).Path')
    # Verify that '~\' is expanded to user's home directory
    assert plugin.expand_user('~\\') == plugin._encode_script('Write-Output ((Get-Location).Path + \'\\\\\')')
    # Verify that '~/' is expanded to user's home directory
    assert plugin.expand_user('~/') == plugin._encode_script('Write-Output ((Get-Location).Path + \'//\')')
    # Verify that '~/bin' is expanded to user's home directory

# Generated at 2022-06-11 16:43:17.899266
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Constructor of class ShellModule takes one argument
    assert "__init__() takes exactly 1 argument (2 given)" in str(Exception("", ShellModule(), ""))

    # Argument (loader) of constructor of class ShellModule must be of type loader.BaseLoader
    assert "Argument (loader) of constructor of class ShellModule must be of type loader.BaseLoader" in str(Exception("", ShellModule(loader=""), ""))

    # Constructor of class ShellModule works correctly
    assert "object" in str(type(ShellModule(loader=object())))



# Generated at 2022-06-11 16:43:19.468650
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(command_timeout=5)
    assert shell.command_timeout == 5

# Generated at 2022-06-11 16:43:20.364197
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass
    # TODO

# Generated at 2022-06-11 16:43:22.517713
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Test creation of a ShellModule object
    """
    cm = ShellModule()
    assert isinstance(cm, ShellModule) is True

# Generated at 2022-06-11 16:43:25.189287
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod._SHELL_REDIRECT_ALLNULL == '> $null'
    assert mod._SHELL_AND == ';'

# Generated at 2022-06-11 16:43:33.192411
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    script = shell.expand_user('~')
    assert 'Write-Output' in script

    script = shell.expand_user('~\\')
    assert 'Write-Output' in script

    script = shell.expand_user('~test\\')
    assert 'Write-Output' in script

    script = shell.expand_user('test')
    assert 'Write-Output' in script

    script = shell.expand_user('test\\')
    assert 'Write-Output' in script

# Generated at 2022-06-11 16:43:34.653623
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj.CHANGED is True

# Generated at 2022-06-11 16:43:36.375892
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # This is a test of the constructor method
    obj = ShellModule()
    assert obj is not None


# Generated at 2022-06-11 16:43:43.221109
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:43:49.593506
# Unit test for constructor of class ShellModule
def test_ShellModule():
    src = to_bytes(pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"))
    b64 = to_text(base64.b64encode(src))
    res = u' '.join([u'PowerShell', u'-NoProfile', u'-NonInteractive', u'-ExecutionPolicy', u'Unrestricted', u'-EncodedCommand', b64])
    s = ShellModule({})
    assert s.build_module_command('', '', '') == res
    assert s.build_module_command('', '#!PowerShell', '', '') == res

# Generated at 2022-06-11 16:43:54.186099
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True



# Generated at 2022-06-11 16:44:01.606355
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    # check if the shell module is compatible with windows
    assert shell_module._IS_WINDOWS is True
    # check if shebang is necessary
    assert shell_module._NEEDS_SHEBANG is False
    # check the default executable
    assert 'cmd.exe' in shell_module._DEFAULT_EXECUTABLE

    # check the module is not compatible with any of the shell in family 'powershell'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()

    # check the shell family that this module belongs to
    assert shell_module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:44:06.052099
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert not shell.HAS_BINARY_FILES
    assert shell._IS_WINDOWS is True

# Generated at 2022-06-11 16:44:14.771892
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test ps1
    ps1_script = '''
        Write-Output "good to go";
        Exit 0;
    '''
    ps1_cmd = ShellModule(shell=False).build_module_command(None,
                                                           '#!powershell',
                                                           ps1_script)
    assert '-EncodedCommand' in ps1_cmd

    # Test for pipelining bypass
    wrapper_cmd = ShellModule(shell=False).build_module_command(None,
                                                               '#!powershell',
                                                               '')
    assert '-EncodedCommand' in wrapper_cmd

    # Test binary
    cmd_parts = ['bar.exe', '-a', 'arg1', 'arg2', 'arg3']
    # binary needs to be quoted because cmd.exe, which is run

# Generated at 2022-06-11 16:44:24.884792
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell = ShellModule(connection=None)
    shell.join_path('C:\\Users', 'username', 'AppData')
    shell.path_has_trailing_slash('C:\\Users\\')

    shell.set_user_facl('C:\\Users', user='user', mode=None)
    shell.remove(path='C:\\Users', recurse=False)
    shell.mkdtemp(basefile='C:\\Users', system=False, mode=None, tmpdir=None)
    shell.expand_user(user_home_path='C:\\Users')


# Generated at 2022-06-11 16:44:27.606745
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Create object and do assertions
    obj = ShellModule()
    assert obj._SHELL_REDIRECT_ALLNULL == '> $null'
    assert obj._SHELL_AND == ';'
    assert obj.COMPATIBLE_SHELLS == frozenset()
    assert obj.SHELL_FAMILY == 'powershell'
    assert obj._IS_WINDOWS

    # Return an instance of ShellModule
    return obj

# Generated at 2022-06-11 16:44:32.208283
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Unit test for constructor of class ShellModule
    """
    shell_module = ShellModule()

    assert isinstance(shell_module, ShellModule)
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-11 16:44:35.634086
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("Testing ShellModule")
    s = ShellModule()
    print("Test passed")


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:44:50.008472
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

    # Mock up a class object for the arguments
    class Temp(object):
        pass

    args = Temp()
    args.connection = 'winrm'
    args.become = False
    args.become_method = 'runas'
    args.become_user = ''
    args.check = False
    args.diff = False
    args.module_name = ''
    args.module_args = ''
    args.module_path = ''
    args.no_log = False
    args.passwords = {}
    args.persistent_connect_timeout = 30
    args.remote_tmp = '$env:TEMP'
    args.searches = {}
    args.shell = False
    args.ssh_executable = ''
    args.stdin = None

# Generated at 2022-06-11 16:44:55.882483
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Constructor for class ShellModule works as expected.
    """
    shell_obj = ShellModule(None)

    assert hasattr(shell_obj, 'check_for_prompt')
    assert shell_obj.check_for_prompt == ShellBase.check_for_prompt
    assert hasattr(shell_obj, '_SHELL_REDIRECT_ALLNULL')



# Generated at 2022-06-11 16:44:56.915028
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()

# Generated at 2022-06-11 16:45:01.507242
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule()
    for shell in powershell.COMPATIBLE_SHELLS:
        assert(shell == 'powershell')
    assert(powershell.SHELL_FAMILY == 'powershell')
    assert(powershell._IS_WINDOWS)



# Generated at 2022-06-11 16:45:10.556725
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_plugin = ShellModule()

    # Test basic shebang
    python_shebang = shell_plugin._encode_script(script='',
                                                 shebang='#!/usr/bin/env python',
                                                 as_list=True,
                                                 strict_mode=False)


# Generated at 2022-06-11 16:45:14.322819
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellobj = ShellModule()
    assert shellobj.SHELL_FAMILY == 'powershell'
    assert shellobj.COMPATIBLE_SHELLS == frozenset()
    assert shellobj._IS_WINDOWS is True

# Generated at 2022-06-11 16:45:15.744039
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellmodule = ShellModule()
    assert isinstance(shellmodule, ShellModule)

# Generated at 2022-06-11 16:45:20.715365
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS
    assert isinstance(shell.SHELL_FAMILY, str)
    assert not isinstance(shell.SHELL_FAMILY, bytes)

# Generated at 2022-06-11 16:45:32.027501
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Test the constructor of class ShellModule.
    """
    sm = ShellModule(None)
    assert isinstance(sm, ShellBase)
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS is True
    assert sm.env_prefix(**{}) == ""
    assert sm.join_path('a', 'b', 'c', 'd') == 'a\\b\\c\\d'
    assert sm.join_path('a/b', 'c\\d') == 'a\\b\\c\\d'
    assert sm.join_path('a/b\\c', 'd/e\\f') == 'a\\b\\c\\d\\e\\f'

# Generated at 2022-06-11 16:45:36.998213
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh = ShellModule(conn=None, tmp=None, *[], **{})
    assert isinstance(sh, ShellModule)
    sh = ShellModule(conn=None, tmp=None, *[], **{})
    assert isinstance(sh, ShellModule)

# Generated at 2022-06-11 16:45:47.603423
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("implement test")
    # TODO: implement test

# Generated at 2022-06-11 16:45:48.773121
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    assert isinstance(s, ShellModule)



# Generated at 2022-06-11 16:45:51.682758
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert 'powershell' == ShellModule().SHELL_FAMILY
    assert 'winrm' == ShellModule().SHELL_NAME

# Generated at 2022-06-11 16:45:54.975507
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import ansible.executor.powershell.ShellModule as shellModule

    shell = shellModule.ShellModule(None)
    assert shell is not None


# Generated at 2022-06-11 16:46:02.726863
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert "powershell" == ShellModule.SHELL_FAMILY
    assert not ShellModule.COMPATIBLE_SHELLS
    assert ShellModule._IS_WINDOWS
    assert bool(re.match(r'Remove-Item \'.*\' -Force -Recurse;', ShellModule(None, None, False).remove('/tmp/foo', recurse=True)))
    assert bool(re.match(r'Remove-Item \'.*\' -Force;', ShellModule(None, None, False).remove('/tmp/foo', recurse=False)))


# Generated at 2022-06-11 16:46:03.838024
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:46:08.089977
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.plugins.shell import ShellModule
    shell_module = ShellModule(connection=None, no_log=False, become_user=None, become_password=None, become_exe=None, become_flags=None, become_info=None)
    assert shell_module

# Generated at 2022-06-11 16:46:11.551273
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('Testing ShellModule() instantiation...')
    shell = ShellModule()
    print('done.')

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:46:22.409328
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import tempfile

    module_dir = os.path.join(tempfile.mkdtemp(), 'lib', 'ansible', 'modules')
    os.makedirs(module_dir)
    module_path = os.path.join(module_dir, 'win_ping.ps1')


# Generated at 2022-06-11 16:46:30.589411
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Constructor of class ShellModule
    powershell = ShellModule()

    # Assert various helper variables
    # There are no compatible shells
    assert powershell.COMPATIBLE_SHELLS == frozenset()
    # The family of shell is powershell
    assert powershell.SHELL_FAMILY == 'powershell'
    # IS_WINDOWS=True
    assert powershell._IS_WINDOWS
    # _SHELL_REDIRECT_ALLNULL = '> $null'
    assert powershell._SHELL_REDIRECT_ALLNULL == '> $null'
    # _SHELL_AND = ';'
    assert powershell._SHELL_AND == ';'

    # Assert that env_prefix works as expected
    # is a no-op for powershell
    assert powershell.env_prefix() == ""

    #

# Generated at 2022-06-11 16:46:57.614099
# Unit test for constructor of class ShellModule
def test_ShellModule():

    modulename = "shell"
    cm = ShellModule(
        prompt=None,
        new_prompt=None,
        add_newline=False,
        response_task_queue=None
    )

    # _SHELL_REDIRECT_ALLNULL
    assert cm._SHELL_REDIRECT_ALLNULL == '> $null'

    # _SHELL_AND
    assert cm._SHELL_AND == ';'

    # _IS_WINDOWS
    assert cm._IS_WINDOWS

    # COMPATIBLE_SHELLS
    assert not cm.COMPATIBLE_SHELLS

    # SHELL_FAMILY
    assert cm.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-11 16:46:59.639909
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Constructor with no parameters
    assert ShellModule()



# Generated at 2022-06-11 16:47:01.765760
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert getattr(ShellModule(), '_SHELL_REDIRECT_ALLNULL') == '> $null'
    assert getattr(ShellModule(), '_SHELL_AND') == ';'

# Generated at 2022-06-11 16:47:04.975639
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.plugins.loader import shell_loader
    sheller = shell_loader.get('powershell')
    assert sheller is not None

    # TODO: Add more tests

# Generated at 2022-06-11 16:47:07.610251
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with empty shell module object
    sm = ShellModule()
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-11 16:47:13.320862
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    # Test for common shell filenames that this plugin handles
    if sm.SHELL_FAMILY:
        sm.COMPATIBLE_SHELLS = frozenset(sm.SHELL_FAMILY)
    assert sm.COMPATIBLE_SHELLS == frozenset('powershell')



# Generated at 2022-06-11 16:47:22.156424
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.shell.common import ShellModule
    from ansible.executor.powershell import EXECUTABLE_CMD_PREFIX

    play_context = PlayContext()
    play_context.connection = 'local'
    shell_type = ShellModule(connection='local', no_log=True, play_context=play_context)
    assert ("python " + EXECUTABLE_CMD_PREFIX) in shell_type.get_option('executable')
    shell_type = ShellModule(connection='ssh', no_log=True, play_context=play_context)
    assert ('sh' in shell_type.get_option('executable')) or ('bash' in shell_type.get_option('executable'))
    play_context.connection

# Generated at 2022-06-11 16:47:25.101935
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO: Add a test here as indicated in
    #       https://groups.google.com/forum/#!topic/ansible-devel/mKDa6gGYG6U
    pass

# Generated at 2022-06-11 16:47:36.217566
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule(connection=None)
    res = module.build_module_command(env_string='', shebang='', cmd='/bin/foo', arg_path='/path/to/arg')
    assert res == "/bin/foo.ps1 /path/to/arg"

    res = module.build_module_command(env_string='', shebang='#!powershell', cmd='/bin/foo', arg_path='/path/to/arg')

# Generated at 2022-06-11 16:47:45.005115
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test constructor of class ShellModule
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._IS_WINDOWS
    assert shell._unquote(u"'value'") == u'value'
    assert shell._unquote(u'"value"') == u'value'
    assert shell._unquote(u'value') == u'value'
    assert shell.wrap_for_exec(u'command') == u'& command; exit $LASTEXITCODE'

# Test _escape method of class ShellModule

# Generated at 2022-06-11 16:48:03.642073
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    options = dict()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._extra_vars = dict()

# Generated at 2022-06-11 16:48:04.485422
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("test: ShellModule")

# Generated at 2022-06-11 16:48:07.842489
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert isinstance(obj, object)
    assert isinstance(obj.COMPATIBLE_SHELLS, frozenset)
    assert isinstance(obj.SHELL_FAMILY, str)
    assert isinstance(obj._IS_WINDOWS, bool)


# Generated at 2022-06-11 16:48:10.035092
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    print("ShellModule test passed")



# Generated at 2022-06-11 16:48:11.284289
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module != None


# Generated at 2022-06-11 16:48:15.863239
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_string = 'powershell'
    shell_instance = ShellModule(connection=None, shell=shell_string)
    assert shell_instance.SHELL_FAMILY == shell_string


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:48:23.678315
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule()
    shebang, env_string, cmd, arg_path = powershell.build_module_command(dict(), '#!/usr/bin/python', 'test', 'testpath')
    assert cmd == '"test.ps1" testpath'
    assert shebang == '#!powershell'
    assert env_string == ''

    shebang, env_string, cmd, arg_path = powershell.build_module_command(dict(), '#!python2', 'test', 'testpath')
    assert cmd == 'python2 "test.ps1" testpath'
    assert shebang == '#!powershell'
    assert env_string == ''


# Generated at 2022-06-11 16:48:24.386047
# Unit test for constructor of class ShellModule
def test_ShellModule():
    return ShellModule()

# Generated at 2022-06-11 16:48:25.908731
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:48:34.580547
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.task_executor import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.plugins.loader import module_loader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Make a shell object
    pc = PlayContext()
    pc.remote_addr = 'localhost'
    pc.become = True
    pc.become_method = 'runas'
    pc.become_user = 'root'
    pc.port = 5985
    pc.connection = 'winrm'

# Generated at 2022-06-11 16:48:59.526025
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS

# Generated at 2022-06-11 16:49:03.395374
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ws = ShellModule()
    assert ws.SHELL_FAMILY == 'powershell'
    assert ws.COMPATIBLE_SHELLS == set()
    assert ws._IS_WINDOWS

# Generated at 2022-06-11 16:49:07.955403
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # execute_powershell_script is not implemented yet
    options = {'remote_tmp': ''}
    connection = ShellModule(None, **options)
    cmd = connection.build_module_command('env_string', 'shebang', 'cmd', 'arg_path')
    print(cmd)

# Generated at 2022-06-11 16:49:08.777424
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh = ShellModule()

# Generated at 2022-06-11 16:49:10.185689
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:49:11.376216
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:49:12.235676
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert 'cmd.exe' in ShellModule.COMPATIBLE_SHELLS

# Generated at 2022-06-11 16:49:13.972310
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

    # Test that the ShellClass is not None
    assert shell is not None



# Generated at 2022-06-11 16:49:17.509662
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(command=None, prompt=None, newline_sequence=None, runner=None)
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module.get_remote_filename('/home/foo/bar') == 'bar'


# Generated at 2022-06-11 16:49:18.634100
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert isinstance(sm, ShellModule)

# Generated at 2022-06-11 16:49:47.610342
# Unit test for constructor of class ShellModule
def test_ShellModule():
    my_shellmodule = ShellModule()
    assert my_shellmodule.COMPATIBLE_SHELLS == frozenset()
    assert my_shellmodule.SHELL_FAMILY == 'powershell'
    assert my_shellmodule._IS_WINDOWS

# Generated at 2022-06-11 16:49:53.324764
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule(connection=None, add_bin_dir=False, shell_type='powershell')
    env_prefix = sm.env_prefix(**dict())
    assert env_prefix == ""
    arg = "'a'"
    assert sm.join_path('a', arg, 'b') == 'a\\a\\b'

# Generated at 2022-06-11 16:50:02.038961
# Unit test for constructor of class ShellModule
def test_ShellModule():

    cls = ShellModule()

    assert hasattr(cls, 'build_module_command')
    assert hasattr(cls, 'exists')
    assert hasattr(cls, 'join_path')
    assert hasattr(cls, 'mkdtemp')
    assert hasattr(cls, 'remove')
    assert hasattr(cls, 'checksum')
    assert hasattr(cls, 'get_remote_filename')
    assert hasattr(cls, 'path_has_trailing_slash')
    assert hasattr(cls, 'expand_user')


# Generated at 2022-06-11 16:50:05.767412
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj.COMPATIBLE_SHELLS == frozenset()
    assert obj.SHELL_FAMILY == 'powershell'
    assert obj._IS_WINDOWS == True


# Generated at 2022-06-11 16:50:06.724342
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert len(ShellModule.__doc__) > 0

# Generated at 2022-06-11 16:50:10.623469
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # This module is only used when winrm is the connection plugin
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule.SHELL_FAMILY == 'powershell'
    # Crete instance of ShellModule
    assert ShellModule()

# Generated at 2022-06-11 16:50:13.566263
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # For code coverage, invoke the constructor and ensure it works.
    try:
        ShellModule()
    except Exception as e:
        assert False, "ShellModule constructor failed: {0}".format(to_text(e))

# Generated at 2022-06-11 16:50:14.569965
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Functional tests are required for this plugin.
    pass

# Generated at 2022-06-11 16:50:17.840327
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shmod = ShellModule()
    assert isinstance(shmod, ShellModule)
    assert shmod.COMPATIBLE_SHELLS == frozenset()
    assert shmod._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shmod._SHELL_AND == ';'
    assert shmod._IS_WINDOWS is True


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:50:20.848470
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("Testing ShellModule constructor")

    print("Testing ShellModule.COMPATIBLE_SHELLS")
    assert not ShellModule.COMPATIBLE_SHELLS
    print("Testing ShellModule.SHELL_FAMILY")
    assert ShellModule.SHELL_FAMILY == 'powershell'
    print("Testing ShellModule._IS_WINDOWS")
    assert ShellModule._IS_WINDOWS


# Generated at 2022-06-11 16:51:10.891191
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod.SHELL_FAMILY == 'powershell'
    assert mod.COMPATIBLE_SHELLS == frozenset()
    assert mod._IS_WINDOWS is True
    assert mod.SHELL_COMMAND_TERMINATOR == ';'
    assert mod.SHELL_REDIRECT_ALLNULL == '> $null'


# Generated at 2022-06-11 16:51:13.532073
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:51:17.289706
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test that the constructor creates a ShellModule object
    # with expected C(SHELL_FAMILY)
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:51:20.207069
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.HAS_PERSISTENT_CONNECTION is False
    assert shell_module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:51:25.851960
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm._IS_WINDOWS == True
    assert '-NoProfile' in sm.env_prefix()
    assert '-NonInteractive' in sm.env_prefix()
    assert '-ExecutionPolicy' in sm.env_prefix()
    assert 'Unrestricted' in sm.env_prefix()

# Unit tests for the _parse_clixml method