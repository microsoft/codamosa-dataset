

# Generated at 2022-06-11 16:41:41.549993
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:41:42.157419
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:41:43.264291
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm

# Generated at 2022-06-11 16:41:54.926643
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    b_wrapper = to_bytes(pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"))
    b_script = to_bytes(to_text(base64.b64encode(b_wrapper)))
    b_cmd = to_bytes('& { %s; exit $LASTEXITCODE }' % b_script)

    # module_command with shebang and cmd is a binary module
    sm = ShellModule(None, None, None)
    shebang = '#!powershell'
    cmd = '/usr/bin/echo'
    arg_path = '"$env:TEMP/ansible_test.txt"'
    invocation = sm.build_module_command(shebang=shebang, cmd=cmd, arg_path=arg_path)

# Generated at 2022-06-11 16:41:58.309980
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    s = ShellModule()
    assert s.get_remote_filename('path/to/some/file.sh') == 'file.sh'



# Generated at 2022-06-11 16:41:59.032186
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule()
    assert powershell is not None

# Generated at 2022-06-11 16:42:03.194946
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # _get_remote_filename should use base filename
    def _get_remote_filename(pathname):
        return 'foo.ps1'

    sh = ShellModule(connection=None, subst=None)
    setattr(sh, '_get_remote_filename', _get_remote_filename)
    assert sh.mkdtemp() == 'powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command "sleep 1; $tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'$env:TEMP\'); $tmp = New-Item -Type Directory -Path $tmp_path -Name \'ansible_test_dir\'; Write-Output -InputObject $tmp.FullName; sleep 1"'
    assert sh.get_remote_filename('C:/foo') == 'foo.ps1'
    assert sh.get

# Generated at 2022-06-11 16:42:11.642715
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    This is the unit test for the constructor of the class ShellModule
    It will take in a connection object and create an object of the ShellPlugin class
    """
    import ansible.plugins.connection.winrm
    shell_obj = ansible.plugins.connection.winrm.Connection("winrm",
                                                            ansible_winrm_server_cert_validation=True)
    shell = ShellModule(shell_obj)
    assert shell.connection == shell_obj
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-11 16:42:19.451370
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    output = shell.join_path('C:\\', 'foo', 'bar\\')
    assert output == 'C:\\foo\\bar'
    output = shell.join_path('/', 'foo', 'bar/')
    assert output == '\\foo\\bar'

    output = shell.join_path('~', 'foo', 'bar\\')
    assert output == '~\\foo\\bar'

    try:
        shell.set_user_facl(None, None, None)
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-11 16:42:30.512857
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.utils import _is_library_path, _load_params, module_loader

    facts = dict()
    is_library_path = True
    params = _load_params(facts, {'_ansible_debug': False,
                                  '_ansible_remote_tmp': '/tmp',
                                  '_ansible_shell_executable': 'powershell',
                                  '_ansible_verbosity': 4,
                                  '_ansible_keep_remote_files': False,
                                  '_ansible_check_byte_string': False})
    path = 'ansible.executor.powershell.ShellModule'
    if not _is_library_path(path):
        # We already have this loaded
        module, path = module_loader.find_plugin(path)
    module = module_loader.load_

# Generated at 2022-06-11 16:42:37.149391
# Unit test for constructor of class ShellModule
def test_ShellModule():
    class _shell(object):
        Shell = ShellModule
    module = _shell()
    shell_module = module.Shell(command_name='echo')
    assert shell_module is not None

# Generated at 2022-06-11 16:42:45.028485
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    # Testing unquoted paths
    assert shell.path_has_trailing_slash('') == False
    assert shell.path_has_trailing_slash('\\') == True
    assert shell.path_has_trailing_slash('C:\\') == True
    assert shell.path_has_trailing_slash('C:\\Windows') == False
    assert shell.path_has_trailing_slash('C:\\Windows\\') == True
    assert shell.path_has_trailing_slash('C:\\Windows\\System32\\') == True
    assert shell.path_has_trailing_slash('C:/') == True
    assert shell.path_has_trailing_slash('C:/Windows') == False
    assert shell.path_has_trailing_slash

# Generated at 2022-06-11 16:42:55.627947
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()

    # Note this is not a complete test, there are a lot more edge cases to deal with.

    # Test for user home directory expansion
    assert shell.expand_user(user_home_path='~') == shell._encode_script("Write-Output (Get-Location).Path")
    assert shell.expand_user(user_home_path='~\\subdir') == shell._encode_script("Write-Output ((Get-Location).Path + 'subdir')")

    # Test path expansion, which is required for the case when "user_home_path" is a relative path.
    assert shell.expand_user(user_home_path=shell.join_path('~', 'subdir')) == shell._encode_script("Write-Output ((Get-Location).Path + 'subdir')")
    assert shell

# Generated at 2022-06-11 16:43:02.271402
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # a file ending with .ps1
    ps = ShellModule(None)
    assert ps.get_remote_filename('test.ps1') == 'test.ps1'

    # a file ending with .exe
    assert ps.get_remote_filename('test.exe') == 'test.exe'

    # a file not ending with .ps1 or .exe
    assert ps.get_remote_filename('test') == 'test.ps1'

# Generated at 2022-06-11 16:43:03.466981
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ''' ShellModule.__init__()'''
    shell = ShellModule()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-11 16:43:04.182001
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()
    assert p.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:43:06.475470
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO: write unit test
    shell = ShellModule()
    shell._display.display('Hello world')

# Generated at 2022-06-11 16:43:14.565009
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.plugins.shell.powershell
    shebang = '#!python'
    cmd = 'script.py arg1 arg2'
    arg_path = '/tmp/test.txt'
    module_cmd = ansible.plugins.shell.powershell.ShellModule(None).build_module_command(None,
                                                                                         shebang,
                                                                                         cmd,
                                                                                         arg_path)
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

# Generated at 2022-06-11 16:43:20.252564
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    assert ShellModule().get_remote_filename('foo.sh') == 'foo.ps1'
    assert ShellModule().get_remote_filename('foo.py') == 'foo.py.ps1'
    assert ShellModule().get_remote_filename('foo') == 'foo.ps1'
    assert ShellModule().get_remote_filename('foo.ps1') == 'foo.ps1'
    assert ShellModule().get_remote_filename('foo.exe') == 'foo.exe'

# Generated at 2022-06-11 16:43:27.544545
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    assert ShellModule().path_has_trailing_slash('C:\\') is True
    assert ShellModule().path_has_trailing_slash('C:\\tmp\\') is True
    assert ShellModule().path_has_trailing_slash('\\') is True
    assert ShellModule().path_has_trailing_slash('/') is True
    assert ShellModule().path_has_trailing_slash('/tmp/') is True
    assert ShellModule().path_has_trailing_slash('/tmp') is False

# Generated at 2022-06-11 16:43:42.131254
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Testing only methods that use PowerShell
    # In the case of connection plugin 'winrm', the shell plugin is
    # referenced by setting remote_shell in the host vars.

    # Testing a binary module using the bootstrap wrapper
    # Method build_module_command(env_string, shebang, cmd, arg_path=None)
    # shebang is the line that tells the OS what the interpreter for the script is
    # cmd is the actual script that needs to be executed
    shell = ShellModule(None)
    shebang = "#!powershell"
    cmd = "Example.psm1"
    # Module file is Example.psm1 with function Example
    cmd = "Example.psm1"
    script = shell.build_module_command('', shebang, cmd)

# Generated at 2022-06-11 16:43:50.330747
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    assert not ShellModule().path_has_trailing_slash('/')
    assert ShellModule().path_has_trailing_slash('/foo/')
    assert not ShellModule().path_has_trailing_slash('/foo')
    assert not ShellModule().path_has_trailing_slash('c:')
    assert not ShellModule().path_has_trailing_slash('c:/')
    assert ShellModule().path_has_trailing_slash('c:/foo/')
    assert not ShellModule().path_has_trailing_slash('c:/foo')
    assert not ShellModule().path_has_trailing_slash('\\')
    assert ShellModule().path_has_trailing_slash('\\foo\\')
    assert not ShellModule().path_has_trailing_slash('\\foo')

# Generated at 2022-06-11 16:44:01.055146
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.six import PY3

    sm = ShellModule()
    assert sm._IS_WINDOWS == True

    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == "powershell"

    # env_prefix() method
    env = sm.env_prefix(**{})
    assert env == ""

    assert sm.join_path("c:\\Users\\ansible", "Ansible") == "c:\\Users\\ansible\\Ansible"

    # TODO: get_remote_filename() fails on windows as no connection is available.
    # assert sm.get_remote_filename("c:/Users/ansible/Ansible/test.txt") == "test.txt"


# Generated at 2022-06-11 16:44:02.076714
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()
    assert True

# Generated at 2022-06-11 16:44:12.830347
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import tempfile

    m = ShellModule()

    fd, arg_path = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-11 16:44:23.916857
# Unit test for constructor of class ShellModule
def test_ShellModule():
    connection_info = dict(
        host='localhost',
        port=50000,
        user='test_user',
        password='test_password'
    )
    task_vars = dict()
    tmp_path_prefix = 'C:\\Temp\\ansible_'
    object_under_test = ShellModule(task_vars, connection_info, tmp_path_prefix)
    print(object_under_test.connection._shell._SHELL_REDIRECT_ALLNULL)
    assert object_under_test.connection._shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert object_under_test.connection._shell._SHELL_AND == ';'
    assert object_under_test.connection._shell._IS_WINDOWS is True
    assert object_under_test.connection._shell.COMPAT

# Generated at 2022-06-11 16:44:33.879231
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    powershell = ShellModule(connection=None, runner_connection=None, hierarchy=None)
    assert powershell.path_has_trailing_slash(path=r'\\server\share\test') is False

# Generated at 2022-06-11 16:44:43.617948
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell is not None
    # Verify class variables
    assert hasattr(shell, '_IS_WINDOWS') and shell._IS_WINDOWS
    # Verify class methods exist
    assert hasattr(shell, 'chmod')
    assert hasattr(shell, 'chown')
    assert hasattr(shell, 'set_user_facl')
    assert hasattr(shell, 'env_prefix')
    assert hasattr(shell, 'join_path')
    assert hasattr(shell, 'get_remote_filename')
    assert hasattr(shell, 'path_has_trailing_slash')
    assert hasattr(shell, 'remove')
    assert hasattr(shell, 'mkdtemp')
    assert hasattr(shell, 'expand_user')
    assert hasattr(shell, 'exists')

# Generated at 2022-06-11 16:44:49.298914
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    '''Test path_has_trailing_slash.'''
    shell = ShellModule(conn=None)
    assert shell.path_has_trailing_slash('C:\\')
    assert shell.path_has_trailing_slash('\\some\dir\\')
    assert shell.path_has_trailing_slash('some\dir/')
    assert not shell.path_has_trailing_slash('some\dir')
    assert not shell.path_has_trailing_slash('some\dir\\  ')


# Generated at 2022-06-11 16:44:52.670735
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import ansible.executor.powershell
    s = ansible.executor.powershell.ShellModule(None, socket_path='foo')
    s.get_option('socket_path') == 'foo'


# Generated at 2022-06-11 16:45:08.020331
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.module_utils.powershell import ShellModule
    shebang = '#!powershell'
    assert ShellModule(None).build_module_command('env_string', '', '', 'arg_path') \
        == ShellModule(None)._encode_script(script="", strict_mode=False, preserve_rc=False)
    assert ShellModule(None).build_module_command('env_string', shebang, '', 'arg_path') \
        == ShellModule(None)._encode_script(script="", strict_mode=True, preserve_rc=False)

    cmd = 'cmd arg1 arg2 arg3'

# Generated at 2022-06-11 16:45:12.060863
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule('winrm', 'user', '123456', 'pass')
    assert ShellModule('psrp', 'user', '123456', 'pass')
    assert not ShellModule('ssh', 'user', '123456', 'pass')


# Generated at 2022-06-11 16:45:22.526786
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    shell.SHELL_FAMILY = 'powershell'
    shell.get_option = lambda x: 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\'
    shell.env_prefix = lambda: ''
    script = 'if( $true ){ exit 0 }'
    encoded_script = shell._encode_script(script, preserve_rc=False)

# Generated at 2022-06-11 16:45:23.247943
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-11 16:45:35.527399
# Unit test for constructor of class ShellModule
def test_ShellModule():
    global _common_args
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    host = Host(name='hostname')

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'hostname',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='echo "hello world"'))
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    tqm = None
    variables = variable_manager.get_vars(play.get_iterator())

# Generated at 2022-06-11 16:45:37.103476
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_shell = ShellModule()
    assert isinstance(test_shell, ShellModule)

# Generated at 2022-06-11 16:45:39.712799
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-11 16:45:42.700142
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, queue=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # TODO: add tests

# Generated at 2022-06-11 16:45:45.102287
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test for constructor of class ShellModule with argument 'conn'
    assert ShellModule(conn=None)

# Generated at 2022-06-11 16:45:49.361489
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod.SHELL_FAMILY == 'powershell'
    assert mod._SHELL_AND == ';'
    assert mod._SHELL_REDIRECT_ALLNULL == '> $null'
    assert mod._IS_WINDOWS
    assert mod.COMPATIBLE_SHELLS == ''

# Generated at 2022-06-11 16:46:01.750004
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    shell_obj._create_shell_commands()
    assert shell_obj.SHELL_FAMILY == 'powershell'
    assert shell_obj.COMPATIBLE_SHELLS == frozenset()
    assert shell_obj._SHELL_REDIRECT_ALLNULL == "> $null"
    assert shell_obj._SHELL_AND == ";"
    assert shell_obj._IS_WINDOWS is True


# Generated at 2022-06-11 16:46:08.348406
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule(connection=None, no_log=True)
    assert shell_obj.connection == None
    assert shell_obj.no_log == True
    assert shell_obj.keep_remote_files == False
    assert shell_obj.remote_tmp == '$env:temp\\ansible-tmp-'
    assert shell_obj.remote_files_dir == '$env:temp\\ansible-tmp'


# Generated at 2022-06-11 16:46:11.417502
# Unit test for constructor of class ShellModule
def test_ShellModule():
    app = ShellModule(connection='local', no_log=True, become=True)
    assert app._shell_type == 'powershell'

# Generated at 2022-06-11 16:46:12.327608
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    print(module)

# Generated at 2022-06-11 16:46:19.843554
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import os
    v = ShellModule()
    assert v.remote_tmp == '~/.ansible/tmp'
    assert v.tmpdir == '/tmp'
    assert v.CHANGED_WHEN == '(?i)^(?:(?:OK)|(?:changed)|(?:VERSION)|(?:STDOUT)|(?:STDERR))$'
    assert v.UNSUPPORTED_TECHNOLOGY == 'Please use `shell` only when `local` is not available'
    assert v.HAS_TTY == False
    assert v._SHELL_REDIRECT_ALLNULL == '> $null'
    assert v._SHELL_AND == ';'
    assert v.COMPATIBLE_SHELLS == frozenset()
    assert v.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:46:21.397161
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None

# Generated at 2022-06-11 16:46:23.208260
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert isinstance(shell, ShellModule)

# Generated at 2022-06-11 16:46:30.905557
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # basic test to make sure we at least don't throw an exception
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.connection.winrm import Connection

    mod = ShellModule(
        connection=Connection(
            play_context=dict(
                # prevent the CLIXML from being parsed by the callback plugin
                output_callback=None,
            ),
            new_stdin=None,
        ),
        no_log=[],
        temporary_data_path=None,
    )
    # make a fake module
    fake_module = ImmutableDict(
        params=dict(
            _raw_params=u'echo -e \'Hello World\'',
        ),
        _connection=mod.connection,
    )


# Generated at 2022-06-11 16:46:39.892959
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection='winrm')

    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == ''
    assert shell._IS_WINDOWS is True
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('bin/foo.exe') == 'foo.exe'
    assert shell.path_has_trailing_slash('C:\\foo') is False
    assert shell.path_has_trailing_slash('C:\\foo\\') is True
    assert shell.get_option('remote_tmp') == '$env:TEMP'
    assert shell._unquote('"C:\\foo"') == 'C:\\foo'

# Generated at 2022-06-11 16:46:43.755775
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule().COMPATIBLE_SHELLS == frozenset()
    assert ShellModule().SHELL_FAMILY == 'powershell'
    assert ShellModule()._IS_WINDOWS == True
    assert ShellModule()._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule()._SHELL_AND == ';'

# Generated at 2022-06-11 16:46:51.918002
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_mod = ShellModule()
    assert shell_mod.SHELL_FAMILY == 'powershell'
    assert shell_mod.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:47:01.375079
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Attempt to instantiate the module
    ShellModule()

    # Check the compatible shells
    assert(ShellModule.COMPATIBLE_SHELLS == frozenset())

    # Check for Windows
    assert(ShellModule._IS_WINDOWS)

    # check for chmod
    try:
        assert(ShellModule.chmod('test', 'test') is not None)
        assert False
    except NotImplementedError:
        assert True

    # check for chown
    try:
        assert(ShellModule.chown('test', 'test') is not None)
        assert False
    except NotImplementedError:
        assert True

    # check for set_user_facl

# Generated at 2022-06-11 16:47:06.794344
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert isinstance(shell.COMPATIBLE_SHELLS, frozenset)
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

# Generated at 2022-06-11 16:47:18.524420
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert hasattr(ShellModule, '_IS_WINDOWS')
    assert hasattr(ShellModule, '_SHELL_REDIRECT_ALLNULL')
    assert hasattr(ShellModule, '_SHELL_AND')
    assert hasattr(ShellModule, 'COMPATIBLE_SHELLS')
    assert hasattr(ShellModule, 'SHELL_FAMILY')
    assert hasattr(ShellModule, 'chmod')
    assert hasattr(ShellModule, 'chown')
    assert hasattr(ShellModule, 'set_user_facl')
    assert hasattr(ShellModule, 'remove')
    assert hasattr(ShellModule, 'mkdtemp')
    assert hasattr(ShellModule, 'expand_user')
    assert hasattr(ShellModule, 'exists')
    assert hasattr(ShellModule, 'checksum')
   

# Generated at 2022-06-11 16:47:23.342063
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, ansible_ssh_executable=None)
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._IS_WINDOWS == True

# Generated at 2022-06-11 16:47:25.442279
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule(None)
    assert(repr(sm) == "<ansible.executor.powershell.ShellModule object at 0x10fc8c450>")

# Generated at 2022-06-11 16:47:27.961003
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    shell_module.exec_command("hostname", "remote_user", "tmpdir")

# Generated at 2022-06-11 16:47:35.293798
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    shell_obj.get_remote_filename('test.sh')
    shell_obj.path_has_trailing_slash('test/')
    shell_obj.chmod('test', 777)
    shell_obj.chown('test', 'test')
    shell_obj.set_user_facl('test', 'test', 777)
    shell_obj.remove('test', True)
    shell_obj._unquote('test')
    shell_obj._escape('test')

# Generated at 2022-06-11 16:47:45.534515
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'

    # Unit test for function env_prefix
    env_string = '$a="hello world"'
    assert shell.env_prefix(environment=env_string) == ''

    # Unit test for function join_path
    assert shell.join_path('C:\\', 'Users', 'Administrator', 'Desktop') == 'C:\\Users\\Administrator\\Desktop'
    assert shell.join_path('C:/', 'Users', 'Administrator', 'Desktop') == 'C:\\Users\\Administrator\\Desktop'
    assert shell.join_path('C:\\\\', 'Users', 'Administrator', 'Desktop') == 'C:\\Users\\Administrator\\Desktop'
    assert shell.join

# Generated at 2022-06-11 16:47:52.556339
# Unit test for constructor of class ShellModule
def test_ShellModule():

    x = ShellModule()
    assert x._SHELL_REDIRECT_ALLNULL == '> $null'
    assert x._SHELL_AND == ';'
    assert x._IS_WINDOWS == True
    assert sorted(x.COMPATIBLE_SHELLS) == sorted([])

    assert x.env_prefix() == ""

    assert x.join_path('C:\\MyDir\\MySubDir', 'MyFileName') == "C:\\MyDir\\MySubDir\\MyFileName"

    assert x.get_remote_filename('MyFileName') == "MyFileName.ps1"
    assert x.get_remote_filename('MyFileName.ps1') == "MyFileName.ps1"
    assert x.get_remote_filename('MyFileName.exe') == "MyFileName.exe"


# Generated at 2022-06-11 16:48:06.454421
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    Validate ShellModule methods
    '''
    import ansible.plugins.shell as shell
    shell_obj = shell.ShellModule(connection=None)
    # Unsupported command
    cmdresult = shell_obj.chown(paths=None, user=None)
    assert cmdresult == "Not implemented"
    # Supported command
    cmdresult = shell_obj.unquote("'test'")
    assert cmdresult == "test"

# Generated at 2022-06-11 16:48:12.812176
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    output = m.join_path('Hello', 'World')
    assert output == 'Hello\\World', "invalid output"
    output = m.get_remote_filename('Hello\\World')
    assert output == 'World.ps1', "invalid output"
    output = m.path_has_trailing_slash('\\Hello\\World')
    assert output == True, "invalid output"
    output = m.path_has_trailing_slash('Hello\\World')
    assert output == False, "invalid output"
    output = m.chmod('', '')
    assert 'not implemented' in output, "invalid output"
    output = m.chown('', '')
    assert 'not implemented' in output, "invalid output"
    output = m.set_user_facl

# Generated at 2022-06-11 16:48:16.056086
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule(connection=None)
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:48:19.537588
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod.COMPATIBLE_SHELLS == frozenset()
    assert mod.SHELL_FAMILY == 'powershell'
    assert mod._IS_WINDOWS == True



# Generated at 2022-06-11 16:48:20.316856
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert True

# Generated at 2022-06-11 16:48:24.788836
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh = ShellModule(connection=None, no_log=True)
    assert sh.COMPATIBLE_SHELLS == frozenset()
    assert sh.SHELL_FAMILY == 'powershell'
    assert sh._IS_WINDOWS == True

# Generated at 2022-06-11 16:48:26.310223
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO: Test for unit-test for constructor
    pass

# Generated at 2022-06-11 16:48:34.752875
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import os
    import tempfile

    module = ShellModule()

    # temp file creation
    fd, pathname = tempfile.mkstemp()
    # close fd
    os.close(fd)
    # delete the temp file
    os.unlink(pathname)

    # test join_path
    assert module.join_path('a', 'b', 'c') == os.path.join('a', 'b', 'c')

    # test get_remote_filename
    assert module.get_remote_filename('a.b') == 'a.b'
    assert module.get_remote_filename('a.b.c.d') == 'a.b.c.d'

    # test path_has_trailing_slash
    assert module.path_has_trailing_slash('/a') == True


# Generated at 2022-06-11 16:48:45.333675
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.plugins import shell_loader

    # Construct an instance of class defined in plugins/connection/Powershell/shell.py
    plugin_obj = shell_loader.get('powershell')

    # Make sure the constructed object is an instance of ShellModule
    assert isinstance(plugin_obj, ShellModule), 'Failed to create an instance of ShellModule'

    # Make sure known class properties have the expect values.
    assert plugin_obj._SHELL_REDIRECT_ALLNULL == '> $null', '_SHELL_REDIRECT_ALLNULL has unexpected value'
    assert plugin_obj._SHELL_AND == ';', '_SHELL_AND has unexpected value'
    assert plugin_obj._IS_WINDOWS is True, '_IS_WINDOWS has unexpected value'

# Generated at 2022-06-11 16:48:49.701802
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.COMPATIBLE_SHELLS == frozenset(), "COMPATIBLE_SHELLS is required"
    assert sm.SHELL_FAMILY == 'powershell', "SHELL_FAMILY is required"
    assert sm._IS_WINDOWS, "_IS_WINDOWS is required"

# Generated at 2022-06-11 16:49:02.669513
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(connection=None)
    assert module is not None

# Generated at 2022-06-11 16:49:05.468898
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # The tests are in the powershell_common_utils.py file, as it needs
    # access to the _parse_clixml() function, as well as the os module.
    pass

# Generated at 2022-06-11 16:49:07.797204
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule(connection=None)
    assert hasattr(shell_module, 'run')

# Generated at 2022-06-11 16:49:11.361217
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod._IS_WINDOWS
    assert mod.SHELL_FAMILY == 'powershell'
    assert mod.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:49:15.759458
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO: check if it's actually possible to instantiate a class from a base class
    shell_module = ShellModule(
        connection='local',
        # TODO: check if it's actually possible to instantiate a class from a base class
        stdin='',
        stdout='',
        stderr='',
        prompt='',
        new_stdin='',
        executable=''
    )
    # TODO: add tests
    return shell_module

# Generated at 2022-06-11 16:49:17.925961
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:49:21.104092
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection="winrm")
    # Assert default options are set as expected
    assert shell.SHELL_FAMILY == "powershell"
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == "> $null"
    assert shell._SHELL_AND == ";"

# Generated at 2022-06-11 16:49:22.233308
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm

# Generated at 2022-06-11 16:49:23.666122
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    assert s.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:49:25.059807
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_ShellModule = ShellModule()
    assert test_ShellModule is not None

# Generated at 2022-06-11 16:49:50.533013
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()


# Generated at 2022-06-11 16:49:51.534077
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()

# Generated at 2022-06-11 16:50:02.474057
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None, no_log=True)
    teststring = "Hello World"

    # Test chmod command
    try:
        shell.chmod(teststring, '777')
        raise
    except NotImplementedError:
        pass

    # Test chown command
    try:
        shell.chown(teststring, 'user')
        raise
    except NotImplementedError:
        pass

    # Test set_user_facl command
    try:
        shell.set_user_facl(teststring, 'user', '777')
        raise
    except NotImplementedError:
        pass

    # Test exists command
    shell.exists(teststring)

    # Test checksum command

# Generated at 2022-06-11 16:50:04.103236
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:50:06.975056
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Make sure that ShellModule can be instantiated.
    This test is not intended to make any assertions. It is used to
    make sure that the import does not throw any exceptions.
    """
    ShellModule()


# Generated at 2022-06-11 16:50:17.216146
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import tempfile

    a = ShellModule()
    assert a.SHELL_FAMILY == 'powershell'
    assert not a.COMPATIBLE_SHELLS
    assert a._IS_WINDOWS
    assert a.get_option('remote_tmp') == '%TEMP%'
    assert a.get_option('remote_port') == ''
    assert a.get_option('remote_addr') == ''

    # test env_prefix()
    assert a.env_prefix() == ''

    # test join_path()
    assert a.join_path('/', '/etc') == '\\etc'
    assert a.join_path('/opt', 'share', 'foo') == '\\opt\\share\\foo'

# Generated at 2022-06-11 16:50:24.963404
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('Test_1 : Start the process')
    shell_module = ShellModule()
    print('Test_1: Success, no exception')

    print('Test_2 : Start the process')
    result = shlex.split('-EncodedCommand', posix=False)
    print('Test_2: Success, result : %s' % result)

    print('Test_3 : Start the process')
    result = shlex.split('-ExecutionPolicy', posix=False)
    print('Test_3: Success, result : %s' % result)

    print('Test_4 : Start the process')
    result = shlex.split('Unrestricted', posix=False)
    print('Test_4: Success, result : %s' % result)

    print('Test_5 : Start the process')

# Generated at 2022-06-11 16:50:27.950032
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'

# Generated at 2022-06-11 16:50:35.412556
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import os
    import stat

    # Set the remote temporary directory
    remote_tmp = os.path.join(os.path.expanduser('~'), '.ansible', 'tmp')

    # Create a ShellModule
    powershell = ShellModule()

    # Set the remote temporary directory as an option
    powershell.set_options(dict(remote_tmp=remote_tmp))

    user_home_path = '~'
    expected_home_path = os.path.expanduser(user_home_path)
    test_home_path = powershell.expand_user(user_home_path)
    assert expected_home_path == test_home_path

    user_home_path = '~/'
    expected_home_path = os.path.expanduser(user_home_path)
    test_home_path

# Generated at 2022-06-11 16:50:38.622125
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_shell_module = ShellModule()
    assert isinstance(test_shell_module, ShellModule)
    assert test_shell_module.SHELL_FAMILY == 'powershell'
    assert test_shell_module._IS_WINDOWS