

# Generated at 2022-06-11 16:41:40.464146
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():

    powershell = ShellModule(shell_type='powershell')

    # Check the local tmpdir
    local_tmpdir = powershell.mkdtemp()
    assert re.search(r'^\$env:TMP\\tmp[0-9a-f]{6}$', local_tmpdir), '%s does not match.' % local_tmpdir

    # Check the remote tmpdir
    remote_tmpdir = powershell.mkdtemp(tmpdir='$env:TEMP')
    assert re.search(r'^\$env:TEMP\\tmp[0-9a-f]{6}$', remote_tmpdir), '%s does not match.' % remote_tmpdir

    # Check the remote tmpdir
    remote_tmpdir = powershell.mkdtemp(tmpdir='$env:TEMP')

# Generated at 2022-06-11 16:41:51.472820
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shebang1 = "#!powershell"
    cmd1 = """
Write-Output 'Hello'
Write-Output 'World'
""".strip()

    shebang2 = "#!/usr/bin/python"
    cmd2 = "/my/python/script.py -a option"

    cmd3 = ""

    env1 = "env1='value1' env2='value2'"

    sm = ShellModule()

    module_cmd = sm.build_module_command(env1, shebang1, cmd1)

# Generated at 2022-06-11 16:42:03.377975
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    plugin = ShellModule()
    # Test if path_has_trailing_slash returns the correct result for specified path
    result = plugin.path_has_trailing_slash('C:\\Users\\test\\')
    assert result == True
    result = plugin.path_has_trailing_slash('C:/Users/test/')
    assert result == True
    result = plugin.path_has_trailing_slash('C:\\Users\\test\\Desktop')
    assert result == False
    result = plugin.path_has_trailing_slash('C:/Users/test/Desktop')
    assert result == False
    result = plugin.path_has_trailing_slash('C:\\Users\\test')
    assert result == False
    result = plugin.path_has_trailing_slash('C:/Users/test')


# Generated at 2022-06-11 16:42:08.660760
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()

    # assert class variables
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'

# Generated at 2022-06-11 16:42:20.197105
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = pkgutil.get_loader('ansible.executor.powershell')
    shell = ShellModule(conn=None, command_timeout=60)
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell.get_remote_filename('test') == 'test.ps1'
    assert shell.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('test.final.ps1') == 'test.final.ps1'
    assert shell.get_remote_filename('test.exe') == 'test.exe'
    assert shell

# Generated at 2022-06-11 16:42:30.734757
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule()

    # Test for attributes
    assert hasattr(powershell, 'COMPATIBLE_SHELLS')
    assert hasattr(powershell, 'SHELL_FAMILY')
    assert hasattr(powershell, '_IS_WINDOWS')
    assert hasattr(powershell, '_SHELL_REDIRECT_ALLNULL')
    assert hasattr(powershell, '_SHELL_AND')

    # Test for methods
    assert hasattr(powershell, 'join_path')
    assert hasattr(powershell, 'get_remote_filename')
    assert hasattr(powershell, 'path_has_trailing_slash')
    assert hasattr(powershell, 'chmod')
    assert hasattr(powershell, 'chown')

# Generated at 2022-06-11 16:42:38.713765
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    from tempfile import gettempdir

    # Don't want to actually create a temporary file
    # so we side step the actual creation.
    _mkdtemp = ShellModule.mkdtemp
    def mkdtemp_side_effect(*args, **kwargs):
        return args[0]

    module = ShellModule()
    module.mkdtemp = mkdtemp_side_effect

    basefile = 'ansible-test-powershell'
    tmpdir = gettempdir()
    mode = None

    # Test with basefile only
    basetmpdir = module.mkdtemp(basefile)
    assert basetmpdir == module.get_option('remote_tmp') + os.sep + basefile

    # Test with basefile / tmp
    basetmpdir = module.mkdtemp(basefile, tmpdir=tmpdir)

# Generated at 2022-06-11 16:42:45.553906
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()

    actual_path = shell.expand_user('~')
    expected_path = 'Write-Output (Get-Location).Path'
    assert actual_path == expected_path

    actual_path = shell.expand_user('~\\')
    expected_path = 'Write-Output ((Get-Location).Path + \'\\\\\')'
    assert actual_path == expected_path

    actual_path = shell.expand_user('~\\file.txt')
    expected_path = 'Write-Output ((Get-Location).Path + \'\\\\file.txt\')'
    assert actual_path == expected_path

    actual_path = shell.expand_user('~/file.txt')
    expected_path = 'Write-Output ((Get-Location).Path + \'\\\\file.txt\')'
    assert actual_

# Generated at 2022-06-11 16:42:47.350465
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test that a ShellModule object is created
    _ = ShellModule()

# Generated at 2022-06-11 16:42:56.551000
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    s = ShellModule()
    assert s.path_has_trailing_slash(r"C:\test\file") == False

# Generated at 2022-06-11 16:43:11.450764
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()

    # pipelining bypass
    cmd = module.build_module_command("", None, "")
    assert cmd.startswith("IyEv")  # cmd should start with shebang

    # non-pipelining
    cmd = module.build_module_command("", None, "Test-Connection")

# Generated at 2022-06-11 16:43:19.634145
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(
        argument_spec={}
    )
    (is_changed, cmd, _, _) = ShellModule(mod).build_module_command(
        '$env:TESTVAR=testval',
        '#!/usr/bin/env python',
        'test.py',
        '/tmp/test')
    assert is_changed
    assert cmd == '& $env:TESTVAR=testval; /usr/bin/env python test.py "/tmp/test"; exit $LASTEXITCODE'

# Generated at 2022-06-11 16:43:30.283327
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    bootstrap_wrapper_utf16 = bootstrap_wrapper.decode('utf-16').encode('utf-8')


# Generated at 2022-06-11 16:43:41.396507
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()

    # Both a forward and back slash at the end should be considered
    # a trailing slash
    test_paths = [
        (r'C:\\foo\\', True),
        (r'C:\\foo\\ ', True),
        (r'\\server\share\ ', True),
        (r'\\server\share', False),
        (r'foo\\', True),
        (r'foo\\ ', True),
        (r'foo', False),
        (r'foo ', False),
        (r'', False),
        (r' ', False),
        (r'   ', False),
    ]

    for (path, expected_result) in test_paths:
        result = shell.path_has_trailing_slash(path)

# Generated at 2022-06-11 16:43:49.972476
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    def returns_expected_value(path=None, expected_value=None):
        return ShellModule().path_has_trailing_slash(path) == expected_value

    assert returns_expected_value(path='', expected_value=False)
    assert returns_expected_value(path='C:', expected_value=False)
    assert returns_expected_value(path='C:\\temp', expected_value=True)
    assert returns_expected_value(path='C:/temp', expected_value=True)
    assert returns_expected_value(path='C:\\temp\\', expected_value=True)
    assert returns_expected_value(path='C:/temp/', expected_value=True)
    assert returns_expected_value(path='C:\\temp\\test', expected_value=False)

# Generated at 2022-06-11 16:43:59.467059
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/path/to/file.txt/')
    assert shell.path_has_trailing_slash('/path/to/dir/')
    assert shell.path_has_trailing_slash('c:\\path\\to\\dir\\')
    assert not shell.path_has_trailing_slash('/path/to/file.txt')
    assert not shell.path_has_trailing_slash('/path/to/dir')
    assert not shell.path_has_trailing_slash('c:\\path\\to\\dir')

# Generated at 2022-06-11 16:44:10.968095
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule(None)
    cmd = shell_module.build_module_command("", "", "copy", arg_path="foo")
    assert cmd == '& =[System.Convert]::FromBase64String((gc foo.ps1 | out-string)); exit $LASTEXITCODE'
    cmd = shell_module.build_module_command("", "", "copy")
    assert cmd == '& =[System.Convert]::FromBase64String((gc - | out-string)); exit $LASTEXITCODE'
    cmd = shell_module.build_module_command("envvar", "#!powershell", "copy", arg_path="foo")

# Generated at 2022-06-11 16:44:22.425707
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common.text.converters import to_bytes
    context = PlayContext()
    context.connection = 'winrm'
    context.connection_user = 'Administrator'
    context.remote_addr = '10.1.1.1'
    context.remote_tmp = 'C:/TEMP'
    context.become = False
    context.become_method = 'runas'
    context.become_user = 'Administrator'
    context.become_pass = 'Password123'
    context.prompt = '[test]:#'
    x = ShellModule(context)
    s = 'echo $HOME; echo $PATH; echo %PATH%'
    print (x.wrap_for_exec(s))

# Generated at 2022-06-11 16:44:27.144776
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Note: we only load the class to see if it initializes without errors, we don't
    run any real tests on the class methods. They are better tested by the integration
    tests.

    """
    ShellModule(connection=None)

# Generated at 2022-06-11 16:44:28.707102
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()
    assert type(p) == ShellModule

# Generated at 2022-06-11 16:44:39.634052
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule(command_name='powershell')
    # Ensure properties of the object are correct, get_remote_filename should be
    # patched and return the expected value
    assert shell_obj.SHELL_TYPE == 'powershell'
    assert shell_obj.get_option('remote_tmp') == '/tmp'



# Generated at 2022-06-11 16:44:44.374951
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    Create a ShellModule object
    '''

    sm = ShellModule()

    # test of attributes
    assert sm.compat_shells == frozenset()
    assert sm.shell_family == 'powershell'
    assert sm._IS_WINDOWS

# Generated at 2022-06-11 16:44:46.070990
# Unit test for constructor of class ShellModule
def test_ShellModule():
    plugin = ShellModule()
    assert plugin


# Test module specific methods

# Generated at 2022-06-11 16:44:48.760066
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test for constructor of class ShellModule
    sm = ShellModule()
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-11 16:44:51.619193
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("test_ShellModule()")
    shell = ShellModule()
    # TODO: Add test of some method in ShellModule


if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-11 16:44:57.090054
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    ps_module = ShellModule()
    module_command = ps_module.build_module_command(env_string='', shebang='', cmd='')

    assert '; exit $LASTEXITCODE' == module_command[-17:]


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 16:44:59.942404
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellModule = ShellModule()
    print(shellModule)

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:45:05.374567
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    assert s._SHELL_REDIRECT_ALLNULL == '> $null'
    assert s._SHELL_AND == ';'
    assert s._IS_WINDOWS
    assert s.COMPATIBLE_SHELLS == frozenset()
    assert s.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:45:05.976762
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

# Generated at 2022-06-11 16:45:16.909750
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.compat.tests import unittest
    from ansible.module_utils.powershell.common import invoked_powershell_script
    from ansible.module_utils.powershell.ps1_to_psm1 import get_psm1_path
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.modules.extras.file
    import os.path
    import importlib.util
    import ansible.plugins.shell.powershell


# Generated at 2022-06-11 16:45:23.606074
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh = ShellModule()
    assert sh.SHELL_FAMILY == 'powershell'
    assert 'powershell' not in sh.COMPATIBLE_SHELLS
    assert sh._IS_WINDOWS

# Generated at 2022-06-11 16:45:24.539936
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    del shell_module

# Generated at 2022-06-11 16:45:37.050946
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Used to test the ShellModule method build_module_command
    # Returns: command: The resulting command after execution of build_module_command
    #          success: True if the command built successfully, False otherwise
    #          error_message: Error message if the command was not built successfully
    from ansible.module_utils.powershell import shell as powershell_shell
    result = dict(
        command='',
        success=False,
        error_message=''
    )
    # Create a PowershellShell object from the class
    test_shell = powershell_shell.ShellModule()
    # Execute the method
    try:
        test_shell.build_module_command('', '#!powershell', '', '')
    except Exception as error:
        print('Failed to build the test command')
        result['error_message'] = str

# Generated at 2022-06-11 16:45:44.967496
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()

    # Test binary module invocation using module_args
    enc_cmd = module.build_module_command('', None, '/usr/bin/python3 /tmp/test.py /tmp/test', arg_path='/tmp/test')
    hex = "0x{0:x}".format(hash(enc_cmd))
    assert hex == '0x4c4b19f', "Failed to encode binary command as expected: %s" % enc_cmd

    # Test binary module invocation using shebang
    enc_cmd = module.build_module_command('', '#!/usr/bin/python3', '/tmp/test.py /tmp/test', arg_path=None)
    hex = "0x{0:x}".format(hash(enc_cmd))

# Generated at 2022-06-11 16:45:53.225158
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    # Run a PowerShell module:

# Generated at 2022-06-11 16:45:56.265908
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sut = ShellModule()
    assert isinstance(sut, ShellBase)



# Generated at 2022-06-11 16:46:06.002141
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.env_prefix() == ''
    assert sm.join_path('test1', 'test2', 'test3') == ntpath.join('test1', 'test2', 'test3')
    assert sm.get_remote_filename('') == ''
    assert sm.get_remote_filename('test.txt') == 'test.txt'
    assert sm.get_remote_filename('test.ps1') == 'test.ps1'
    assert sm.get_remote_filename('test') == 'test.ps1'
    assert sm.get_remote_filename('test.exe') == 'test.exe'
    assert sm.path_has_tra

# Generated at 2022-06-11 16:46:11.724983
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    assert shell_obj.SHELL_FAMILY == 'powershell'
    assert shell_obj.COMPATIBLE_SHELLS == frozenset()
    assert shell_obj._IS_WINDOWS == True
    assert isinstance(shell_obj, ShellBase)

# Generated at 2022-06-11 16:46:22.598887
# Unit test for constructor of class ShellModule
def test_ShellModule():
    args = {}
    args['executable'] = 'powershell.exe'
    args['argument_cache'] = {'_ansible_tmpdir': 'c:\Server'}
    args['is_pipelining'] = False
    args['become_method'] = 'runas'
    args['become_user'] = 'admin'
    args['check'] = False
    sc = ShellModule(**args)
    assert sc is not None
    assert sc.get_remote_filename('') == ''
    assert sc.join_path(r'c:\temp1', r'c:\temp2') == r'c:\temp2'
    assert sc.chmod(r'c:\temp1', 666) is None
    assert sc.chown(r'c:\temp1', 'admin') is None
    assert sc.set_user

# Generated at 2022-06-11 16:46:23.898164
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True

# Generated at 2022-06-11 16:46:30.671561
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ['ShellModule', 'cmd.exe', 'powershell', 'None']
    ShellModule(module)

# Generated at 2022-06-11 16:46:34.588050
# Unit test for constructor of class ShellModule
def test_ShellModule():
    my_shell = ShellModule()
    assert my_shell is not None
    assert my_shell._is_pipelining is False

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-11 16:46:38.917256
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule(connection=None, addl_args=None, runas=None, tmpdir=None, module_compression=None)
    assert hasattr(sm, '_SHELL_REDIRECT_ALLNULL')

# Generated at 2022-06-11 16:46:39.826494
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()

# Generated at 2022-06-11 16:46:41.165423
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module is not None


# Generated at 2022-06-11 16:46:49.144309
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    f = shell.join_path('c:\\', 'foo', 'bar')
    assert f == 'c:\\foo\\bar'

    f = shell.join_path('c:\\', 'foo//', 'bar')
    assert f == 'c:\\foo\\bar'

    f = shell.join_path('c:\\', 'foo/bar//')
    assert f == 'c:\\foo\\bar'

    f = shell.join_path('c:\\', 'foo\\/bar\\//')
    assert f == 'c:\\foo\\bar'

# Generated at 2022-06-11 16:46:58.219213
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """ Runs a constructor test for class ShellModule
    """
    # test for class attributes
    module = ShellModule()
    assert module.SHELL_FAMILY == "powershell"
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS == True

    # test for class methods
    # method join_path
    assert module.join_path("/test","test") == '\\test\test'
    assert module.join_path("/test","/test2") == '\\test\test2'
    assert module.join_path("test","test2") == 'test\test2'
    assert module.join_path("/test2/","test3") == '\\test2\test3'

# Generated at 2022-06-11 16:47:05.515930
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    # Run this method against the class, we don't need an object
    cls = ShellModule()

    # Define the test cases, we will use the shebang to determine what expect

# Generated at 2022-06-11 16:47:07.710938
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    assert shell is not None, 'Creating ShellModule failed!'

# Generated at 2022-06-11 16:47:11.560630
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._IS_WINDOWS

# Generated at 2022-06-11 16:47:23.705578
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import tempfile

    ssh_args = ""

    # Encode to bytecode
    # Python 3: tempfile.gettempdir().encode(sys.getfilesystemencoding())
    # Python 2: tempfile.gettempdir()
    tmp_path_bytes = tempfile.gettempdir()

    sm = ShellModule(None)

    # Check that the method works correctly when shebang is #!powershell
    cmd = "''"
    shebang = '#!powershell'

# Generated at 2022-06-11 16:47:35.005430
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import os
    from ansible.module_utils.powershell import AnsibleCmdletError
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.ansible_release import __version__ as ansible_version

# Generated at 2022-06-11 16:47:45.339694
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # These parameters are not used in this class
    ssh_executable = None
    become_method = 'sudo'
    become_exe = 'sudo'
    become_user = 'root'
    become_pass = None
    sudoable = True
    verbosity = 0
    is_cygwin = False
    create_junction = False

    # Create an instance of class ShellModule
    shell_module = ShellModule(
        ssh_executable,
        become_method,
        become_user,
        become_pass,
        become_exe,
        verbosity,
        sudoable,
        is_cygwin,
        create_junction
    )

    # Use the instance of class ShellModule to process the path and call _unquote

# Generated at 2022-06-11 16:47:46.156039
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

# Generated at 2022-06-11 16:47:47.207480
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

# Generated at 2022-06-11 16:47:50.605950
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-11 16:47:53.355119
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()
    assert p.SHELL_FAMILY == 'powershell'
    assert p._PATH_SEPARATOR == ';'
    assert p._IS_WINDOWS

# Generated at 2022-06-11 16:48:01.655308
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    sc = ShellModule()
    assert sc.build_module_command('env_string', '#!', 'cmd', 'arg_path') == \
        'Type cmd |%s' % pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

# Generated at 2022-06-11 16:48:09.882973
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()
    cmd = module.build_module_command("", "", "command")
    assert "command" in cmd
    assert "System.Management.Automation.PSScriptAnalyzer" not in cmd

    cmd = module.build_module_command("", "", "command arg1 arg2")
    assert "command arg1 arg2" in cmd

    cmd = module.build_module_command("", "#!powershell", "")
    assert "bootstrap_wrapper.ps1" in cmd
    assert "System.Management.Automation.PSScriptAnalyzer" not in cmd

    cmd = module.build_module_command("", "#!powershell", "command")
    assert "[System.Management.Automation.ScriptBlock]::Create(" in cmd
    assert ").InvokeReturnAsIs(" in cmd

# Generated at 2022-06-11 16:48:20.366128
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    """
    This test case checks that the method build_module_command of the class builders.ShellModule
    returns the expected value when called with specific parameters. It also checks the failure
    scenarios of the method when called with invalid parameters.
    """
    from ansible.executor.powershell import ShellModule
    from ansible.errors import AnsibleError


# Generated at 2022-06-11 16:48:34.031421
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shebang_cmd = 'powershell.exe'
    cmd_parts = ['/c', 'SET FOO=bar', '/c', 'FOO']
    path_exists_cmd = ('(Test-Path ', ')')
    create_dir_cmd = ('New-Item ', ' -Type Directory -Force')
    remove_dir_cmd = ('Remove-Item ', ' -Recurse -Force')
    remove_file_cmd = ('Remove-Item ', ' -Force')
    remove_glob_cmd = ('Remove-Item ', ' -Include *.tmp -Recurse -Force')
    fetch_file_cmd = ('(New-Object System.Net.WebClient).DownloadFile("', '", "', '")')
    file_exists_cmd = ('Test-Path ', '| ConvertTo-Json')

# Generated at 2022-06-11 16:48:34.946031
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert isinstance(ShellModule(), ShellModule)

# Generated at 2022-06-11 16:48:37.825932
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Simply instantiate ShellModule and nothing else
    mod_obj = ShellModule(connection=None, shell_executable='powershell.exe')
    assert mod_obj is not None



# Generated at 2022-06-11 16:48:38.479453
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-11 16:48:50.100354
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh = ShellModule()


# Generated at 2022-06-11 16:48:56.218327
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.basic import AnsibleModule
    import json

    module = AnsibleModule(argument_spec={})
    assert module is not None
    shell = ShellModule(module)
    assert shell is not None

    data = shell._encode_script('Write-Output "aaa"')
    assert data is not None



# Generated at 2022-06-11 16:48:57.905498
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert isinstance(obj, ShellModule)

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-11 16:49:02.491936
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Set values for constructor params
    args = dict()
    args['connection'] = None
    args['run_tree'] = dict()
    args['task'] = None
    args['loader'] = None
    args['task_vars'] = dict()

    # Instantiate the class under test
    module_obj = ShellModule(**args)

# Generated at 2022-06-11 16:49:04.923222
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'

# Test function get_remote_filename

# Generated at 2022-06-11 16:49:10.132779
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert not ShellModule()._IS_BINARY
    assert not ShellModule()._CAN_DELEGATE
    assert not ShellModule()._IS_POWERSHELL
    assert ShellModule()._IS_WINDOWS
    assert not ShellModule()._HAS_TTY
    assert ShellModule()._LAST_RC_OK
    assert not ShellModule()._LAST_RC_WARN
    assert not ShellModule()._LAST_RC_FAIL
    assert ShellModule()._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule()._SHELL_AND == ';'

# Generated at 2022-06-11 16:49:19.715809
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    ShellModule unit test
    """
    script = ShellModule()
    assert script.COMPATIBLE_SHELLS == frozenset()
    assert script.SHELL_FAMILY == 'powershell'
    assert script._SHELL_REDIRECT_ALLNULL == '> $null'
    assert script._IS_WINDOWS == True
    assert script._SHELL_AND == ';'



# Generated at 2022-06-11 16:49:30.652883
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule(connection=None)
    sm._create_tmp_path = lambda x: x
    assert sm.get_remote_filename(u"abc") == u"abc.ps1"
    assert sm.get_remote_filename(u"abc.ps1") == u"abc.ps1"
    assert sm.get_remote_filename(u"abc.py") == u"abc.py.ps1"
    assert sm.get_remote_filename(u"http://localhost/downloads/foo") == u"http://localhost/downloads/foo.ps1"
    assert sm.get_remote_filename(u"/c/windows/temp/abc.py") == u"abc.py.ps1"

# Generated at 2022-06-11 16:49:32.219915
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    return shell

# Generated at 2022-06-11 16:49:33.779759
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:49:37.429099
# Unit test for constructor of class ShellModule
def test_ShellModule():
    cls = ShellModule()
    assert len(cls.COMPATIBLE_SHELLS) == 0
    assert cls.SHELL_FAMILY == 'powershell'
    assert cls._IS_WINDOWS  # pylint: disable=protected-access

# Generated at 2022-06-11 16:49:43.884014
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module._IS_WINDOWS is True
    assert shell_module.COMPATIBLE_SHELLS == ('powershell',)
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module.__class__.__name__ == 'ShellModule'

# Generated at 2022-06-11 16:49:45.963958
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule() is not None


# Unit tests for class methods of class ShellModule

# Generated at 2022-06-11 16:49:48.364780
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Test case for constructor of class ShellModule"""
    # Run the powershell module constructor
    assert ShellModule(connection='winrm')

# Generated at 2022-06-11 16:49:58.426183
# Unit test for constructor of class ShellModule
def test_ShellModule():
    reqs = dict(
        deps=['shell_windows'],
        module_utils=['shell_windows'],
        )
    r = ShellModule(**reqs)
    r.path_has_trailing_slash('C:\\Users\\chris.church')
    r.join_path('\\Users\\', 'chris.church\\Desktop')
    r.get_remote_filename('test.ps1')
    r.checksum('test.ps1')
    r.build_module_command('ENV', '#!powershell', 'REQUIREMENTS')
    r.wrap_for_exec('REQUIREMENTS')
    r.get_option('remote_tmp')

# Generated at 2022-06-11 16:50:03.622727
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert to_text(shell_module.SHELL_FAMILY) == 'powershell'
    shell_module = ShellModule(None, False)
    assert to_text(shell_module.SHELL_FAMILY) == 'powershell'
    shell_module = ShellModule(None, True, 3)
    assert to_text(shell_module.SHELL_FAMILY) == 'powershell'

# Generated at 2022-06-11 16:50:15.413783
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:50:16.477714
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module

# Generated at 2022-06-11 16:50:18.664728
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import ansible.executor.powershell as ps

    shell_mod = ps.ShellModule()
    assert shell_mod is not None

# Generated at 2022-06-11 16:50:23.364884
# Unit test for constructor of class ShellModule
def test_ShellModule():
    cmd = "Write-Output 'hello world'"
    sm = ShellModule()
    rc = sm._encode_script(script=cmd)
    assert "PowerShell" in rc, 'cmd not in return code'
    assert "hello world" not in rc, 'plaintext cmd in return code'
    assert "UgBlAGwAIAB0AGgAZQAgACAAVwBy" in rc, 'base64 cmd not in return code'

# Generated at 2022-06-11 16:50:33.145980
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()


# Generated at 2022-06-11 16:50:34.970698
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule('Test')
    assert type(obj) == ShellModule

# Generated at 2022-06-11 16:50:36.601398
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert isinstance(obj, ShellModule)

# Generated at 2022-06-11 16:50:43.324934
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.get_remote_filename('/tmp/test.sh') == 'test.sh'
    assert shell_module.get_remote_filename('/tmp/test.py') == 'test.py'
    assert shell_module.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell_module.get_remote_filename('/tmp/test.ps1.ps1') == 'test.ps1.ps1'
    assert shell_module.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell_module.get_remote_filename('/tmp/test.') == 'test.ps1'
    assert shell_module.get_remote_filename('/tmp/test') == 'test.ps1'



# Generated at 2022-06-11 16:50:46.413660
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module != None
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:50:49.309665
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule(conn=MagicMock(), runner=MagicMock())
    assert p.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:51:11.756732
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.module_common import get_shell_plugin

    # Test that we can assign shell plugin.
    shell_plugin = get_shell_plugin("powershell")
    assert isinstance(shell_plugin, ShellModule)


# Generated at 2022-06-11 16:51:15.240769
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule(connection=None)
    assert mod in vars(ShellModule).values() or mod in vars(ShellModule).keys()

# Generated at 2022-06-11 16:51:24.890498
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    # This method is hard to test due to the command construction with quotes and arguments, so only to some part.
    # This is the base module, pscx, so not much to test.
    powershell_module = ShellModule()

    # Module will be placed in a temp folder for the test.
    # Note that it is prefixed with a '_' because the method get_remote_filename will append ".ps1"
    cmd = "test_module_name"
    arg_path = None
    env_string = ''
    shebang = ''
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    encoded_cmd = powershell_module._encode_script(bootstrap_wrapper)