

# Generated at 2022-06-11 16:41:41.922387
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    module = pkgutil.get_data('ansible.module_utils.powershell', 'basic_script.ps1')
    module_bytes = to_bytes(module, encoding='utf-8')
    module_base64 = to_text(base64.b64encode(module_bytes), encoding='utf-8')

    shebangs = [
        '#!powershell',
        '#!powershell.exe',
        '#!powershell.cmd',
    ]


# Generated at 2022-06-11 16:41:42.998634
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule(None)
    assert sm

# Generated at 2022-06-11 16:41:43.926239
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:41:45.129019
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell is not None

# Generated at 2022-06-11 16:41:55.142688
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Create a ShellModule object
    shell = ShellModule()

    # Test the basic case, path with backslash
    if not shell.path_has_trailing_slash("C:\\foo\\"):
        raise AssertionError("Failed to detect trailing slash")

    # Test the edge case, path with forward slash
    if not shell.path_has_trailing_slash("C:/foo/"):
        raise AssertionError("Failed to detect trailing slash")

    # Test the failure case, path with no trailing slash
    if shell.path_has_trailing_slash("C:\\foo"):
        raise AssertionError("Incorrectly detected trailing slash")



# Generated at 2022-06-11 16:42:03.901524
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash("foo\\")
    assert shell.path_has_trailing_slash("foo/")
    assert shell.path_has_trailing_slash("foo") is False
    assert shell.path_has_trailing_slash("") is False
    assert shell.path_has_trailing_slash("foo\"") is False
    assert shell.path_has_trailing_slash("foo\\'") is False
    assert shell.path_has_trailing_slash("\"'") is False


# Generated at 2022-06-11 16:42:06.328057
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule(connection=None, *args, **kwargs)
    assert s._shell_type == 'powershell'

# Generated at 2022-06-11 16:42:10.844377
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # Make sure that any file without an extension gets .ps1 appended and .exe is preserved
    shell = ShellModule()
    assert shell.get_remote_filename('foo') == 'foo.ps1'
    assert shell.get_remote_filename('foo.ps1') == 'foo.ps1'
    assert shell.get_remote_filename('foo.exe') == 'foo.exe'

# Generated at 2022-06-11 16:42:15.864368
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import ansible_powershell
    import tempfile
    temp_dir = tempfile.gettempdir()
    shell = ansible_powershell.shell.ShellModule(connection=None)
    command = shell.mkdtemp()
    output = shell.run(command)[0].strip()
    assert output.startswith(temp_dir)


# Generated at 2022-06-11 16:42:24.413677
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()

    test_string1 = r'D:\Ansible\Ansible.cfg'
    test_string2 = r'D:\Ansible\Ansible.cfg\\'
    test_string3 = 'D:\\Ansible\Ansible.cfg'
    test_string4 = 'D:\\Ansible\Ansible.cfg//'
    test_string5 = 'D:\Ansible\Ansible.cfg/'
    test_string6 = 'D:\Ansible\Ansible.cfg\\/'
    test_string7 = 'D:\\Ansible\Ansible.cfg/'
    test_string8 = 'D:\\Ansible\Ansible.cfg\\/'


# Generated at 2022-06-11 16:42:39.560364
# Unit test for constructor of class ShellModule
def test_ShellModule():
    script = """
    <#
    # This is a comment!
    #>
    $x = "Hello World!"
    Write-Output $x
    """

    # TODO: what would be a valid call to the ShellModule constructor?
    # sm = ShellModule(connection=None, no_log=False, become_method='', become_user='')

    # cmd = 'PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand %s' % encoded_script
    cmd = "PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand %s" % base64.b64encode(script.encode('utf-16-le'))
    # print(cmd)
    os.system(cmd)

# Generated at 2022-06-11 16:42:40.801077
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_instance = ShellModule()
    assert module_instance is not None



# Generated at 2022-06-11 16:42:52.888194
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.six import imap, StringIO
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.shell.powershell import ShellModule

    # Assert that 'env' is not in the prefix when the shell plugin is Powershell
    assert 'env' not in ShellModule._SHELL_COMMON_ARGUMENTS_ENV_VARS_BLACKLIST

    # Ensure that the unicode handling is correct and the output is a string
    out = to_bytes(ShellModule.join_path('C:\\', 'Users', u'me\u2665'))
    assert out == b'C:\\Users\\me\xe2\x99\xa5'

    # Ensure that windows paths with backslashes are normalized

# Generated at 2022-06-11 16:42:56.633645
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils import winrm
    shell_obj = ShellModule(conn=winrm.WinRM())
    assert shell_obj.SHELL_FAMILY == 'powershell'
    assert shell_obj.COMPATIBLE_SHELLS == frozenset()
    assert shell_obj._IS_WINDOWS is True

# Generated at 2022-06-11 16:43:08.639247
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    from ansible.plugins.shell.powershell import ShellModule
    shell = ShellModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert shell.path_has_trailing_slash('') == False

# Generated at 2022-06-11 16:43:19.805969
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Tests with explicit forward slash at the end
    # (shell.py)
    assert ShellModule().path_has_trailing_slash("C:/Windows/") is True
    assert ShellModule().path_has_trailing_slash("C:/Windows/Temp/") is True
    assert ShellModule().path_has_trailing_slash("C:/Windows/Temp/file.txt") is False
    assert ShellModule().path_has_trailing_slash("C:/Windows/Temp/dir/") is True
    assert ShellModule().path_has_trailing_slash("C:/Windows/Temp/dir/subdir/") is True
    assert ShellModule().path_has_trailing_slash("C:/Windows/Temp/dir/subdir/subsubdir/") is True
    assert ShellModule().path_has_trailing_sl

# Generated at 2022-06-11 16:43:30.459369
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()

# Generated at 2022-06-11 16:43:32.725391
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    s.run(cmd='cmd /c "echo hello world"')

# Generated at 2022-06-11 16:43:43.525353
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    path = 'c:\\test'
    shell_module.join_path(path, 'testing')
    path = 'c:\\test'
    shell_module.path_has_trailing_slash(path)
    path = '~\\test'
    shell_module.expand_user(path)
    path = 'c:\\test'
    shell_module.get_remote_filename(path)
    path = 'c:\\test'
    shell_module.remove(path, recurse=False)
    path = 'c:\\test'
    shell_module.mkdtemp(basefile=None, system=False, mode=None, tmpdir=None)
    path = 'c:\\test'
    shell_module.exists(path)

# Generated at 2022-06-11 16:43:50.566745
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.executor.module_common import ShellModule

    shell = ShellModule(connection=None)
    shell.get_option = lambda a: 'C:\\Users\\All Users'

    # Test expand_user for system temp folder
    assert shell.expand_user('~') == shell._encode_script("Write-Output (Get-Location).Path")

    # Test expand_user for the user's home directory
    assert shell.expand_user('~\\Installs') == shell._encode_script("Write-Output ((Get-Location).Path + '\\Installs')")

    # Test expand_user for a relative path
    assert shell.expand_user('some-path') == shell._encode_script("Write-Output 'some-path'")

# Generated at 2022-06-11 16:44:03.420340
# Unit test for constructor of class ShellModule
def test_ShellModule():

    sm = ShellModule()
    cmd = 'PS C:\\Users\\test>& C:\\Temp\\ansible_test.ps1; exit $LASTEXITCODE'
    shebang = '#!powershell'
    script = 'write-host "Hello, World!"'

    assert(sm.wrap_for_exec('C:\\Temp\\ansible_test.ps1') == cmd)
    assert(sm.build_module_command('', shebang, script) == cmd)
    assert(sm.build_module_command('', '', script) == cmd)
    assert(sm.build_module_command('', shebang, script, '-e') == cmd)
    assert(sm.build_module_command('', '', script, '-e') == cmd)


# Generated at 2022-06-11 16:44:13.598792
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    """
    Test if a command is built properly
    """
    script = """
        if(!(Get-Module -Name win_reboot -ListAvailable)) {
            Install-Module win_reboot -Force;
        }
        Import-Module win_reboot;
        win_reboot;
    """
    shell = ShellModule()
    cmd = shell.build_module_command('', '', script)

    cmd_parts = shlex.split(cmd, posix=False)
    cmd_parts = list(map(to_text, cmd_parts))
    assert cmd_parts[3] == '-NoProfile'
    assert cmd_parts[5] == '-EncodedCommand'

# Generated at 2022-06-11 16:44:15.216056
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

    # Test the constructor
    assert shell


# Generated at 2022-06-11 16:44:18.969918
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Test constructor of ShellModule"""
    shell_module = ShellModule()
    assert shell_module is not None, "failed to create ShellModule"


# Generated at 2022-06-11 16:44:26.497886
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import shlex
    import tempfile
    from ansible.module_utils._text import to_bytes

    def temp_module(path, contents):
        with open(path, 'wb') as f:
            f.write(to_bytes(contents))

    # Create a temporary module to execute
    temp_dir = tempfile.mkdtemp()
    temp_module(temp_dir + '/common.ps1', '$a = 1')
    temp_module(temp_dir + '/module.ps1', '''
$a = 2
Write-Output ($true | ConvertTo-Json -Compress)
''')

    # Create a ShellModule instance to test
    mock_shell = ShellModule(command_name='powershell')
    mock_shell.remote_tmp = temp_dir

    # Test the case of a non-pipelined

# Generated at 2022-06-11 16:44:28.039986
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert 'winrm' == obj.connection


# Generated at 2022-06-11 16:44:36.464513
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh = ShellModule()
    assert sh.SHELL_FAMILY == 'powershell'

    assert sh.env_prefix() == ''

    assert sh.join_path('c:\\', 'windows') == 'c:\\windows'
    assert sh.join_path('c:\\', 'windows', 'system32') == 'c:\\windows\\system32'

    assert sh.path_has_trailing_slash('c:\\') == False
    assert sh.path_has_trailing_slash('c:\\windows\\') == True


# Generated at 2022-06-11 16:44:44.893585
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    m = ShellModule(connection=None)
    assert re.match('[0-9a-zA-Z]{6}', m._generate_temp_dir_name())
    assert re.match('[0-9a-zA-Z]{6}', m._generate_temp_dir_name())
    assert re.match('[0-9a-zA-Z]{6}', m._generate_temp_dir_name())
    assert re.match('[0-9a-zA-Z]{6}', m._generate_temp_dir_name())
    assert re.match('[0-9a-zA-Z]{6}', m._generate_temp_dir_name())

# Generated at 2022-06-11 16:44:46.865586
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert isinstance(shell, ShellModule)

# Generated at 2022-06-11 16:44:58.413505
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    s.unquote('"foo"')
    s.unquote("'foo'")
    s.unquote('foo')
    s.unquote('')
    s.unquote(None)
    s.unquote(u'foo')
    s.unquote(u'"foo"')
    s.unquote(u"'foo'")
    s.escape('foo')
    s.escape('foo bar')
    s.escape('f"oo bar')
    s.escape('f`oo bar')
    s.escape('f\'oo bar')
    s.escape('f\tbar')
    s.escape('f\x7fbar')
    s.encode_script('foo')
    s.encode_script('foo', True)

# Generated at 2022-06-11 16:45:05.321300
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell_instance = ShellModule()
    assert isinstance(powershell_instance, ShellModule)

# Generated at 2022-06-11 16:45:07.696385
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    This method constructs a new ShellModule class and returns an instance
    of the class.

    :return: instance of ShellModule class.
    """
    return ShellModule()

# Generated at 2022-06-11 16:45:19.417653
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    from random import choice
    from string import ascii_lowercase, digits

    # Generate random base string to not hit existing temporary folders
    basefile = "test_dir" + ''.join(choice(ascii_lowercase + digits) for _ in range(8))

    # Get the reference to the method mkdtemp
    shell_module = ShellModule()
    mkdtemp = shell_module.mkdtemp
    mkdtemp_command = mkdtemp(basefile)

    # Execute the command
    try:
        result = shell_module._low_level_execute(
            cmd=mkdtemp_command,
            sudoable=False,
            in_data=None,
            stdin=None,
            executable=None,
            stdin_add_newline=False)
    except Exception as e:
        print

# Generated at 2022-06-11 16:45:23.782950
# Unit test for constructor of class ShellModule
def test_ShellModule():
    for shebang, cmd in (('#!frobnitz', '&{arg}'), ('#!frobnitz', 'arg'), ('#!frobnitz -with_args', 'arg')):
        cmd = ShellModule(cmd, shebang)._build_module_command('env', 'arg')
        assert isinstance(cmd, str) and cmd.startswith('& %SystemRoot%\\system32\\WindowsPowerShell\\')


# Generated at 2022-06-11 16:45:26.370407
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create the ShellModule object and check the args it takes
    ShellModule(connection=None, new_stdin=None, prompt=None, new_stdout=None)



# Generated at 2022-06-11 16:45:38.926534
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    cmd = module._encode_script('Write-Output "hello"')

# Generated at 2022-06-11 16:45:41.285792
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create a temporary ShellModule object for testing.
    test = ShellModule()
    assert test is not None


# Generated at 2022-06-11 16:45:41.908733
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

# Generated at 2022-06-11 16:45:49.503500
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        from ansible_collections.jctanner.cloud_microsoft.plugins.module_utils.Windows.WinRM.WinRMOperations import WinRMOperations
        shell_obj = ShellModule(connection=WinRMOperations(shell_id='test'))
        assert shell_obj.SHELL_FAMILY == 'powershell'
    except ImportError:
        assert True, 'ansible_collections.jctanner.cloud_microsoft.plugins.module_utils.Windows.WinRM.WinRMOperations not found'

# Generated at 2022-06-11 16:45:51.094863
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:45:59.310123
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod.SHELL_FAMILY == 'powershell'
    assert mod._IS_WINDOWS == True
    assert mod.COMPATIBLE_SHELLS == set()
    assert mod.COMPATIBLE_INTERPRETER_PATHS == set()
    assert mod.COMPATIBLE_INTERPRETER_NAMES == set()


# Generated at 2022-06-11 16:46:01.321473
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''Unit test for constructor of class ShellModule'''
    sm = ShellModule()
    assert sm

# Generated at 2022-06-11 16:46:03.702637
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'



# Generated at 2022-06-11 16:46:06.073490
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule(None)
    assert m.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:46:12.408338
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    sheller = ShellModule()
    sheller.get_option = lambda x: None
    script = sheller.mkdtmp('junk')
    assert script.startswith('$tmp_path = [System.Environment]::ExpandEnvironmentVariables(\'\')\n$tmp = New-Item -Type Directory -Path $tmp_path -Name \'junk\'')

# Generated at 2022-06-11 16:46:19.816318
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    module_instance = ShellModule()
    basefile = "ansible-tmp-1550657599.435-83700927262585"
    tmpdir = "C:\\Users\\fred\\AppData\\Local\\Temp"
    mode = None
    system = False

    # Test if the function returns the correct result to be processed by assertEqual
    assertEqual(module_instance.mkdtemp(basefile,system,mode,tmpdir)," $tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Users\\fred\\AppData\\Local\\Temp')  $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-1550657599.435-83700927262585'  Write-Output -InputObject $tmp.FullName ")
    return "Pass"


# Generated at 2022-06-11 16:46:21.349710
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellmodule = ShellModule()
    assert isinstance(shellmodule, ShellModule)

# Generated at 2022-06-11 16:46:23.549033
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(command_timeout=10)
    assert isinstance(module, ShellModule)

# Generated at 2022-06-11 16:46:27.436123
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    assert shell_obj._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_obj._SHELL_AND == ';'
    assert shell_obj._IS_WINDOWS == True


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:46:38.075159
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    script = shell_module._encode_script('Write-Output "Hello"', as_list=False, strict_mode=True)
    assert (' '.join(_common_args + ['-EncodedCommand']) in script)
    assert ('UABvAHcAZQBzACAAUwBvAGYAdAB3AGEAcgBlAA==' in script)

    script = shell_module._encode_script('Write-Output "Hello"', as_list=True, strict_mode=True)
    assert (_common_args + ['-EncodedCommand']) == script

    script = shell_module._encode_script('Write-Output "Hello"', as_list=False, strict_mode=False)
    assert (' '.join(_common_args + ['-EncodedCommand']) in script)

# Generated at 2022-06-11 16:46:50.392610
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:46:51.466680
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Not really much to do here
    assert ShellModule()

# Generated at 2022-06-11 16:46:53.588966
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Unit test for constructor of class ShellModule"""
    # Test constructing a ShellModule object.
    shell = ShellModule()

# Generated at 2022-06-11 16:46:55.823548
# Unit test for constructor of class ShellModule
def test_ShellModule():
    scm = ShellModule()
    print("Passed test_ShellModule")

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:46:58.143842
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh_module = ShellModule()
    print(sh_module)

# Generated at 2022-06-11 16:46:59.034933
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:47:01.628776
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module._IS_WINDOWS

# Generated at 2022-06-11 16:47:04.779892
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule(connection=None, shell_executable='powershell')
    assert shell_obj.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-11 16:47:08.524271
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()
    assert p.COMPATIBLE_SHELLS == frozenset()
    assert p._IS_WINDOWS == True
    assert p.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:47:11.819152
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # If the following line is ever changed, the unit test needs to be changed as well.
    assert ShellModule(None, None).SHELL_FAMILY == 'powershell'


# Generated at 2022-06-11 16:47:23.594912
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert(ShellModule() is not None)

# Generated at 2022-06-11 16:47:24.825435
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_test = ShellModule()
    assert isinstance(module_test, ShellModule)

# Generated at 2022-06-11 16:47:35.966043
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import re
    import pkgutil

    s = ShellModule()

    # get_remote_filename
    assert s.get_remote_filename('/tmp/f') == 'f'
    assert s.get_remote_filename('/tmp/f.ps1') == 'f.ps1'
    assert s.get_remote_filename('/tmp/f.py') == 'f.py.ps1'
    assert s.get_remote_filename('/tmp/f.exe') == 'f.exe'

    # join_path:
    assert s.join_path('C:\\', '\\Windows\\system32') == 'C:\\Windows\\system32'
    assert s.join_path('C:\\', '\\Windows\\') == 'C:\\Windows'

# Generated at 2022-06-11 16:47:39.689808
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert type(ShellModule()) is ShellModule
    assert ShellModule()._IS_WINDOWS is True
    assert ShellModule().COMPATIBLE_SHELLS == frozenset()
    assert ShellModule().SHELL_FAMILY == 'powershell'

# Unit tests for the _unquote function.

# Generated at 2022-06-11 16:47:41.673666
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.COMPATIBLE_SHELLS == set()
    assert sm.SHELL_FAMILY == "powershell"

# Generated at 2022-06-11 16:47:45.928321
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod.COMPATIBLE_SHELLS == frozenset()
    assert mod.SHELL_FAMILY == 'powershell'
    assert mod._IS_WINDOWS is True


# Generated at 2022-06-11 16:47:48.252537
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sut = ShellModule()
    assert sut.SHELL_FAMILY == 'powershell'
    assert sut._IS_WINDOWS

# Unit test to test _unquote

# Generated at 2022-06-11 16:47:51.416036
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule(connection=None)
    assert m.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:47:54.941626
# Unit test for constructor of class ShellModule
def test_ShellModule():
    cmd = "Test-Command"
    shebang = "#!Powershell"

    powershell = ShellModule(cmd,shebang)

    shell_type = isinstance(powershell, ShellBase)
    assert shell_type is True


# Generated at 2022-06-11 16:47:57.393381
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule(command_name='powershell')
    assert 'powershell' == powershell.command_name
    assert isinstance(powershell, ShellModule)

# Generated at 2022-06-11 16:48:18.158497
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Unit test for constructor of class ShellModule"""
    shell_plugin = ShellModule()
    assert shell_plugin._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_plugin._SHELL_AND == ';'

# Generated at 2022-06-11 16:48:20.491853
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:48:21.451761
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    return shell

# Generated at 2022-06-11 16:48:24.242812
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-11 16:48:27.093819
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()

    assert(module.SHELL_FAMILY == 'powershell')
    assert(module._IS_WINDOWS)

# Generated at 2022-06-11 16:48:32.016491
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    assert m.COMPATIBLE_SHELLS == frozenset()
    assert m.SHELL_FAMILY == 'powershell'
    assert m._SHELL_REDIRECT_ALLNULL == '> $null'
    assert m._SHELL_AND == ';'
    assert m._IS_WINDOWS is True
    assert m.env_prefix() == ""


# Generated at 2022-06-11 16:48:34.691325
# Unit test for constructor of class ShellModule
def test_ShellModule():
    my_shell = ShellModule()
    assert my_shell.SHELL_FAMILY == 'powershell'
    assert not my_shell.HAS_UNIX_COMMANDS

# Generated at 2022-06-11 16:48:42.833194
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.powershell import ShellModule
    #test default constructor for ShellModule class
    shell_module = ShellModule()
    print(shell_module)
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    from ansible import context
    assert shell_module.sudoable == context.CLIARGS['become']
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module._IS_WINDOWS == True

# Generated at 2022-06-11 16:48:45.078582
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj._shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:48:48.908431
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_class = ShellModule()
    assert module_class.COMPATIBLE_SHELLS == frozenset()
    assert module_class.SHELL_FAMILY == 'powershell'
    assert module_class._IS_WINDOWS

# Generated at 2022-06-11 16:49:35.306924
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._SHELL_REDIRECT_ALLNULL == '> $null'
    assert sm._SHELL_AND == ';'
    assert sm._IS_WINDOWS == True

# Generated at 2022-06-11 16:49:36.057942
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:49:46.719606
# Unit test for constructor of class ShellModule
def test_ShellModule():
    clixml_data = '''<Objs Version="1.1.0.1" xmlns="http://schemas.microsoft.com/powershell/2004/04">
        <S S="Error">Test Stderr</S>
    </Objs>'''

    unchecked_clixml_data = '''<Objs>
        <S S="Error">Test Stderr</S>
    </Objs>'''

    shell = ShellModule()

    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:49:48.221065
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    shell.join_path('test')

# Generated at 2022-06-11 16:49:49.453618
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()


# Generated at 2022-06-11 16:49:58.158423
# Unit test for constructor of class ShellModule
def test_ShellModule():
    win_shell = ShellModule()
    assert win_shell.COMPATIBLE_SHELLS == frozenset()
    assert win_shell.SHELL_FAMILY == 'powershell'
    assert win_shell.get_option('remote_tmp') == '$env:TEMP'
    assert win_shell.get_option('no_log') is False
    assert win_shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert win_shell._SHELL_AND == ';'
    assert win_shell._IS_WINDOWS is True


# Generated at 2022-06-11 16:50:01.172146
# Unit test for constructor of class ShellModule
def test_ShellModule():
    myshell = ShellModule()
    myshell.become = True
    assert myshell.become == True

# Unit testing for all functions of class ShellModule

# Generated at 2022-06-11 16:50:06.596823
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powershell = ShellModule()
    # set the magic variables
    powershell.shell = 'powershell.exe'
    powershell.connection = 'winrm'
    # init_for_unarchive should not raise an exception
    powershell.init_for_unarchive()
    # clear the instance attributes
    powershell.shell = ''
    powershell.connection = ''

# Generated at 2022-06-11 16:50:10.834322
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module.path_has_trailing_slash('foo\\')

# Generated at 2022-06-11 16:50:20.872280
# Unit test for constructor of class ShellModule
def test_ShellModule():

    sh_obj = ShellModule()

    shebang = "#!powershell"
    cmd = "echo test"

# Generated at 2022-06-11 16:51:05.655731
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()

# Generated at 2022-06-11 16:51:06.666877
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:51:14.847509
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('=== Test ShellModule() ===')

    from ansible import context
    from ansible.cli import CLI
    from ansible.playbook.play_context import PlayContext

    # Initialize configuration and context
    context._init_global_context(CLI.base_parser(False, False, False, description='Ansible Engine'))
    context.CLIARGS = {'connection': 'winrm'}
    play_context = PlayContext()

    # test connection in local mode
    context.CLIARGS = {'connection': 'local'}
    shell = ShellModule(None, 'testhost', play_context)
    assert shell.shell.SHELL_FAMILY == 'powershell'
    assert shell.shell.COMPATIBLE_SHELLS == frozenset()

    # test connection in ssh mode

# Generated at 2022-06-11 16:51:18.382719
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import ansible.executor.module_common
    test_m = ansible.executor.module_common.run_module
    m = ShellModule(command='echo "hello"', shell=None, task_vars=dict())
    assert type(m) == ShellModule, type(m)
    assert m.command == 'echo "hello"', m._command
    assert m.shell == 'powershell', m.shell


# Generated at 2022-06-11 16:51:26.560301
# Unit test for constructor of class ShellModule
def test_ShellModule():
    temp = False
    try:
        from ansible.module_utils.six import PY3
        from io import StringIO
        temp = True
    except ImportError:
        pass
    if hasattr(StringIO, 'StringIO'):
        # python 2.x
        from StringIO import StringIO
        temp = True
    if temp:
        # python 2.x
        o = StringIO()
    else:
        # python 3.x
        o = StringIO()
