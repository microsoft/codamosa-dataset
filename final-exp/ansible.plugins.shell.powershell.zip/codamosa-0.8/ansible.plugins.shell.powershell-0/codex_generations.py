

# Generated at 2022-06-11 16:41:36.737135
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~') == "$((Get-Location).Path)\n"
    assert shell.expand_user('~\\file.txt') == "$((Get-Location).Path)\\file.txt\n"
    assert shell.expand_user('/tmp/file.txt') == "/tmp/file.txt\n"


# Generated at 2022-06-11 16:41:38.167390
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    cmd = ShellModule()
    cmd.expand_user('~\\')

# Generated at 2022-06-11 16:41:43.525388
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    This is a test for the constructor of ShellModule class
    """
    shell_plugin = ShellModule(conn=None)
    assert isinstance(shell_plugin, ShellModule)
    assert isinstance(shell_plugin.SHELL_FAMILY, str)
    assert isinstance(shell_plugin.COMPATIBLE_SHELLS, frozenset)


# Generated at 2022-06-11 16:41:55.090792
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    class Mock(object):
        def __init__(self):
            self.CLIARGS = {'private_data_dir': 'dummy', 'roles_path': 'dummy'}
            self.destinations = ['dummy']
            self.delegate = 'dummy'

    mock_play_context = Mock()

    module = ShellModule(mock_play_context)
    assert module.build_module_command('dummy', None, '') == module._encode_script(script='type . | .\\ansible\executor\powershell\\bootstrap_wrapper.ps1')
    assert module.build_module_command('dummy', '#!powershell', 'ansible.module_utils.basic hello') == '& .\\ansible\executor\powershell\\bootstrap_wrapper.ps1'

# Generated at 2022-06-11 16:42:04.159835
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    assert ShellModule().get_remote_filename("~/test/file.txt") == "file.txt"
    assert ShellModule().get_remote_filename("~/test/file.txt.py") == "file.txt.ps1"
    assert ShellModule().get_remote_filename("~/test/file.txt.py") == "file.txt.ps1"
    assert ShellModule().get_remote_filename("~/test/file.txt.py.ext") == "file.txt.py.ps1"
    assert ShellModule().get_remote_filename("~/test/file.txt.exe") == "file.txt.exe"

# Generated at 2022-06-11 16:42:08.616574
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    assert ShellModule(None).expand_user(u'~/abc') == b"Write-Output 'C:/Users/Administrator/abc'"
    assert ShellModule(None).expand_user(u'~') == b"Write-Output (Get-Location).Path"


# Generated at 2022-06-11 16:42:20.195251
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule(connection=None, shells_dirs=["/tmp/dir/dir2"], _ansible_version='2.9.0')
    assert s.SHELL_FAMILY == 'powershell'
    assert s.COMPATIBLE_SHELLS == frozenset()
    assert s._IS_WINDOWS == True
    assert s._SHELL_REDIRECT_ALLNULL == '> $null'
    assert s._SHELL_AND == ';'
    assert s._connection is None
    assert s._shell is None
    assert s.connection_shell is None
    assert s.DEFAULT_EXECUTABLE == 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'


# Generated at 2022-06-11 16:42:30.720643
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Assumes that ansible module bundle is extracted to working directory
    # Creates two shell objects, one with a shebang and another without a shebang
    sm = ShellModule(shell_type='powershell')
    sm_shebang = ShellModule(shell_type='powershell')
    shebang = '#!powershell'

    # Assumes the module is a powershell module
    ps_module = 'ansible.modules.windows.win_copy.ps1'
    ps_module_path = os.path.join('./ansible/modules/windows/win_copy', ps_module)
    cmd = ''.join([shebang, ' ', ps_module_path])
    cmd_no_shebang = ps_module_path
    # Assumes the module is a binary module, not a powershell module

# Generated at 2022-06-11 16:42:40.303397
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.plugins.shell.powershell import ShellModule

    shell_module = ShellModule()

    # Test Windows paths
    user_home_path = shell_module.expand_user('~')
    assert user_home_path.startswith('#!powershell_ise')

    user_home_path = shell_module.expand_user('~\\test')
    assert user_home_path.startswith('#!powershell_ise')
    assert '.test' in user_home_path

    # Test non-Windows paths
    user_home_path = shell_module.expand_user('~', posix=True)
    assert user_home_path.startswith('#!powershell_ise')

    user_home_path = shell_module.expand_user('~/test', posix=True)

# Generated at 2022-06-11 16:42:46.681715
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    s = ShellModule()

    assert not s.path_has_trailing_slash('/does/not/have/a/trailing/slash')
    assert s.path_has_trailing_slash('has/a/trailing/slash/')
    assert s.path_has_trailing_slash('/has/a/trailing/slash/')


# Generated at 2022-06-11 16:42:56.379905
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('/tmp')
    assert shell.path_has_trailing_slash(r'C:\tmp')
    assert not shell.path_has_trailing_slash('/tmp/')

# Generated at 2022-06-11 16:43:06.310714
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # https://powershell.org/2013/07/24/a-primer-on-the-unix-pipeline-in-powershell/
    shell_obj = ShellModule()
    test_cmd = "Get-ChildItem -Path / -Filter '*.txt' | Select-Object -First 10"
    # Check that the cmd is encoded so that it can be passed to PowerShell with no additional quoting issues.
    encoded_test_cmd = shell_obj._encode_script(test_cmd, strict_mode=False)
    assert re.search(r'^& \-EncodedCommand .*', encoded_test_cmd)



# Generated at 2022-06-11 16:43:07.484081
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()
    assert p

# Generated at 2022-06-11 16:43:18.935956
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import os

    shell_module = ShellModule()

    # Test if converting a non-str or non-unicode object to str or unicode object of specified encoding
    # raise an exception.
    # No exception should be raised when passing a non-str or non-unicode object to e.g. shell_module._escape()
    # as long as to_text returns a non-empty string.
    # So we e.g. pass shell_module.get_option(u'foo')

    assert isinstance(shell_module._unquote(shell_module.get_option(u'system_tmp')), unicode)

    # Test if '|' character can be escaped,
    # e.g. '|'.encode('utf-16-le') --> '\xff\xfe\xa0\xa6\x00\x00'


# Generated at 2022-06-11 16:43:19.481799
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()

# Generated at 2022-06-11 16:43:25.185389
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Tests for path_has_trailing_slash
    shell = ShellModule(connection=None)
    path = r'C:\spam\eggs'
    assert not shell.path_has_trailing_slash(path)
    path = r'C:\spam\eggs\\'
    assert shell.path_has_trailing_slash(path)
    path = r'C:\spam\eggs/'
    assert shell.path_has_trailing_slash(path)
    path = r'C:\spam\eggs\\\"'
    assert shell.path_has_trailing_slash(path)
    path = r'C:\spam\eggs/\"'
    assert shell.path_has_trailing_slash(path)

# Generated at 2022-06-11 16:43:36.333938
# Unit test for constructor of class ShellModule
def test_ShellModule():
    class Options(object):

        def __init__(self, connection):
            self.connection = connection

    class Runner(object):

        def __init__(self, module_name, module_args, module_vars, module_inject):
            self.module_name = module_name
            self.module_args = module_args
            self.module_vars = module_vars
            self.module_inject = module_inject

    args = {
        'connection': 'winrm',
        'module_name': 'fake_powershell_module',
        'module_args': 'fake_powershell_module_args',
        'module_vars': 'fake_powershell_module_vars',
        'module_inject': 'fake_powershell_module_inject'
    }

    pm = ShellModule

# Generated at 2022-06-11 16:43:39.637752
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    for path in [
        "",
        "\\",
        "\\directory\\",
        "//directory/",
        "//directory//",
        "//directory/subdir",
        "//directory/subdir\\",
        "directory\\subdir",
    ]:

        assert ShellModule().path_has_trailing_slash(path) == path.endswith('\\')

# Generated at 2022-06-11 16:43:41.178488
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.shell == 'powershell'

# Generated at 2022-06-11 16:43:45.236751
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.module_common import ModuleBase
    s = ShellModule()
    assert isinstance(s, ModuleBase)
    assert s.SHELL_FAMILY == 'powershell'
    assert s.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:43:57.025619
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert ShellModule._IS_WINDOWS is True
    assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule._SHELL_AND == ';'



# Generated at 2022-06-11 16:44:08.723589
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    assert "& " == ShellModule.build_module_command(
        env_string="", shebang="", cmd="", arg_path=None,
    ).split(";", 1)[0]
    assert "powershell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand" in ShellModule.build_module_command(
        env_string="", shebang="#!powershell", cmd="chdir /tmp", arg_path=None,
    ).split(";", 1)[0].lower()
    assert "powershell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand" in ShellModule.build_module_command(
        env_string="", shebang="#!python", cmd="chdir /tmp", arg_path=None,
    ).split(";", 1)[0].lower()

# Generated at 2022-06-11 16:44:15.783021
# Unit test for constructor of class ShellModule
def test_ShellModule():
    x = ShellModule()
    pathname = 'test/test.txt'
    assert x.get_remote_filename(pathname) == 'test.txt'

# Generated at 2022-06-11 16:44:25.425970
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import tempfile
    from ansible.module_utils.powershell.bootstrap_wrapper import _write_temp_clixml
    shebang = '#!powershell'
    cmd = 'Write-Output "1"; exit 4; Write-Output "2"'
    arg_path = 'C:\\foo\\bar'
    tempfd, tempd = tempfile.mkstemp()
    os.close(tempfd)

# Generated at 2022-06-11 16:44:29.630905
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule is not None, "Failed to import ansible.plugins.shell.powershell.ShellModule"
    shell = ShellModule()
    assert shell is not None, "Failed to instantiate ansible.plugins.shell.powershell.ShellModule"


# Generated at 2022-06-11 16:44:40.922626
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm is not None
    assert "\\" in sm.join_path("a", "b")
    assert sm.get_remote_filename("test.txt") == "test.txt"
    assert sm.get_remote_filename("test") == "test.ps1"
    assert sm.path_has_trailing_slash("C:\Temp\a.txt\\")
    assert sm.path_has_trailing_slash("C:\Temp\a.txt/")
    assert not sm.path_has_trailing_slash("C:\Temp\a.txt")
    assert not sm.path_has_trailing_slash("C:\Temp\a.txt\"")

# Generated at 2022-06-11 16:44:49.869441
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    This is a functional test for the constructor of the class ShellModule.
    """
    shell = ShellModule(None)
    assert shell.path_has_trailing_slash("semicolon ;") == False
    assert shell.path_has_trailing_slash("semicolon;") == False
    assert shell.path_has_trailing_slash("forward/") == True
    assert shell.path_has_trailing_slash("back\\") == True
    assert shell.path_has_trailing_slash("mixed/\\") == True
    assert shell.path_has_trailing_slash("mixed\\/") == True
    assert shell.path_has_trailing_slash("mixed\\/a") == False

# Generated at 2022-06-11 16:44:51.175911
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert hasattr(sm, 'encode_script')

# Generated at 2022-06-11 16:44:53.276990
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellmodule = ShellModule()
    assert shellmodule.SHELL_FAMILY == "powershell"



# Generated at 2022-06-11 16:45:05.516577
# Unit test for constructor of class ShellModule
def test_ShellModule():
    a = ShellModule('/path/to/powershell')
    assert a.path_has_trailing_slash('x') is False
    assert a.path_has_trailing_slash('C:\\Windows\\a\\') is True
    assert a.path_has_trailing_slash('C:\\Windows\\a') is False
    assert a.path_has_trailing_slash('/home/something/') is True
    assert a.path_has_trailing_slash('/home/something') is False
    assert a.get_remote_filename('a') == 'a.ps1'
    assert a.get_remote_filename('b.ps1') == 'b.ps1'
    assert a.get_remote_filename('c.exe') == 'c.exe'
    assert a.mkdtemp

# Generated at 2022-06-11 16:45:46.537751
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import sys
    import os

    # get a copy of the original sys.stdout since we are going to change it for the testing
    real_stdout = sys.stdout
    # Change stdout to a file for testing
    sys.stdout = open(os.devnull, 'w')

    # Create a test
    sm = ShellModule()

    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS is True

    # restore back the stdout to original value
    sys.stdout = real_stdout

# Generated at 2022-06-11 16:45:47.782012
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    print(shell_obj)

# Generated at 2022-06-11 16:45:56.918421
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    sm = ShellModule()

    assert sm.path_has_trailing_slash("C:\\Windows\\")
    assert sm.path_has_trailing_slash("C:\\Windows\\Temp\\")
    assert sm.path_has_trailing_slash("C:\\Windows/")
    assert sm.path_has_trailing_slash("C:\\Windows/Temp/")

    assert not sm.path_has_trailing_slash("C:\\Windows")
    assert not sm.path_has_trailing_slash("C:\\Windows\\Temp")
    assert not sm.path_has_trailing_slash("C:\\Windows\\Temp\\file.txt")
    assert not sm.path_has_trailing_slash("C:\\Windows/file.txt")

# Generated at 2022-06-11 16:46:00.665249
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(None, '', '', '', '', '', '')
    assert isinstance(module, ShellModule)
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:46:02.490193
# Unit test for constructor of class ShellModule
def test_ShellModule():
    x = ShellModule()
    assert x is not None

# Generated at 2022-06-11 16:46:07.289596
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    This function is used to test the constructor of the class ShellModule.
    """
    shell_module = ShellModule(connection='connection', config=dict(),
                               ansible_play_context=None, runner_path=None,
                               **dict())

    assert shell_module.connection == 'connection'

# Generated at 2022-06-11 16:46:10.205100
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.COMPATIBLE_SHELLS == 'powershell'

# Generated at 2022-06-11 16:46:20.800462
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(connection=None, tmpdir=None, become_method=None, become_user=None, become_exe=None,
                         become_flags=None, check=None)
    module.COMPATIBLE_SHELLS.add('powershell')
    module.get_option('remote_tmp').return_value = '/'
    module._unquote('"hello"').return_value = 'hello'
    module.wrap_for_exec('powershell.exe').return_value = '& powershell.exe; exit $LASTEXITCODE'

# Generated at 2022-06-11 16:46:29.862000
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()

    path = 'C:\\Users\\testuser'
    assert not shell.path_has_trailing_slash(path)

    path = 'C:\\Users\\testuser\\'
    assert shell.path_has_trailing_slash(path)

    path = 'C:\\Users\\testuser\\'
    assert shell.path_has_trailing_slash(path)

    path = 'C:\\Users\\testuser\\\\'
    assert shell.path_has_trailing_slash(path)

    path = 'C:\\Users\\testuser\\\\\\'
    assert shell.path_has_trailing_slash(path)


# Generated at 2022-06-11 16:46:33.863426
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()

    assert m.COMPATIBLE_SHELLS == frozenset()

    assert m.SHELL_FAMILY == 'powershell'

# Unit tests for instance methods of class ShellModule

# Generated at 2022-06-11 16:47:49.771694
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:47:58.551069
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_mock = ShellModule(connection=None, shell=None, no_log=True)
    assert shell_mock._escape(u'Not Test String') == 'Not Test String'
    assert shell_mock._escape(u'Not Test String>') == 'Not Test String>'
    assert shell_mock._escape(u'Not Test String"') == 'Not Test String\\"\\"'
    assert shell_mock._escape(u'Not Test String\"') == 'Not Test String\\"\\"'
    assert shell_mock._escape(u'Not Test String\'') == 'Not Test String\\\'\\\''
    assert shell_mock._escape(u'Not Test String\'\'') == 'Not Test String\\\'\\\'\\\'\\\''


# Generated at 2022-06-11 16:48:00.339995
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell__module = ShellModule()
    assert hasattr(shell__module, 'join_path')

# Generated at 2022-06-11 16:48:03.021003
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_AND == ';'

# Generated at 2022-06-11 16:48:03.868434
# Unit test for constructor of class ShellModule
def test_ShellModule():
    c = ShellModule()
    assert c is not None

# Generated at 2022-06-11 16:48:06.909626
# Unit test for constructor of class ShellModule
def test_ShellModule():
    x = ShellModule()
    assert x.SHELL_FAMILY == 'powershell'
    assert x._SHELL_REDIRECT_ALLNULL == '> $null'
    assert x._SHELL_AND == ';'
    assert x._IS_WINDOWS == True


# Generated at 2022-06-11 16:48:13.026355
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shebang = '#!powershell'
    cmd = 'Invoke-Expression "& & \'echo\'"'
    arg_path = '-a args'

    result = ShellModule().build_module_command('', shebang, cmd, arg_path)
    # The module is a PowerShell script
    # The command "& & 'echo'" is still executed
    # The encoding is executed via the standard encoding
    assert result == 'type echo.ps1 | & $PSHOME\\Modules\\PowerShellForAnsible\\PowerShellForAnsible.psm1;' \
                     ' If ($?) { exit ([int]$lastexitcode) } Else { exit 1 }'

    shebang = '#!/bin/bash'
    cmd = '/usr/bin/python -m my_module'
    arg_path = '-a args'



# Generated at 2022-06-11 16:48:16.723925
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS == True

# Generated at 2022-06-11 16:48:18.066978
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell._IS_WINDOWS

# Generated at 2022-06-11 16:48:19.925394
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule(None, 'test')

# Generated at 2022-06-11 16:49:45.963236
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.powershell.connection import Connection
    from ansible.plugins.connections.ssh import Connection as SshConnection
    from ansible.plugins.shell.powershell import ShellModule as PSShellModule
    # The only allowed values for connection are winrm and psrp.
    # These are handled in the Connection plugin, not ShellModule
    connection = Connection(play_context=None)
    shell1 = PSShellModule(connection)
    assert shell1
    # ssh isn't a supported connection type, but we can still test
    # in case this changes in the future
    ssh_connection = SshConnection(play_context=None)
    shell2 = PSShellModule(ssh_connection)
    assert shell2
    assert shell2._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell2._SHELL

# Generated at 2022-06-11 16:49:48.364490
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell is not None

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:50:00.063252
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    output = sm.join_path('c:\\', 'users', 'username')
    assert output == 'c:\\users\\username', "Unexpected output.  Got %s" % output

    output = sm.join_path('c:\\', 'users', 'username', '\\')
    assert output == 'c:\\users\\username', "Unexpected output.  Got %s" % output

    output = sm.join_path('c:\\', 'users', 'username', '\\', '\\')
    assert output == 'c:\\users\\username', "Unexpected output.  Got %s" % output

    output = sm.join_path('c:\\', '\\', 'users', '\\', 'username', '\\', '\\', '\\')

# Generated at 2022-06-11 16:50:07.384489
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert hasattr(ShellModule(), 'IS_WINDOWS')
    assert hasattr(ShellModule(), '_SHELL_REDIRECT_ALLNULL')
    assert hasattr(ShellModule(), 'COMPATIBLE_SHELLS')
    assert hasattr(ShellModule(), 'SHELL_FAMILY')
    assert hasattr(ShellModule(), '_IS_WINDOWS')
    assert hasattr(ShellModule(), 'wrap_for_exec')
    assert hasattr(ShellModule(), '_escape')


# Generated at 2022-06-11 16:50:09.706924
# Unit test for constructor of class ShellModule
def test_ShellModule():

    module = ShellModule()

    assert isinstance(module.SHELL_FAMILY, str)
    assert isinstance(module.COMPATIBLE_SHELLS, frozenset)

# Generated at 2022-06-11 16:50:13.784683
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # If no data was passed in, use None for the data.
    sm = ShellModule()
    # print(sm.SHELL_TYPE)
    # 'powershell'
    # print(sm.SHELL_FAMILY)
    # powershell
    assert True


# Generated at 2022-06-11 16:50:16.237644
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule(connection=None, shell_executable='powershell', become_password='false')
    assert shell_obj is not None

# Generated at 2022-06-11 16:50:24.413217
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import sys
    import tempfile
    import shutil
    import stat

    tmp_path = tempfile.mkdtemp()
    args_path = os.path.join(tmp_path, "args.json")
    tmp_module_path = os.path.join(tmp_path, "module_test")
    tmp_module2_path = os.path.join(tmp_path, "module_test2")
    with open(tmp_module_path, "wb") as f:
        f.write(b'#!python\nprint("Hello from Python")')
    os.chmod(tmp_module_path, stat.S_IREAD | stat.S_IEXEC | stat.S_IWRITE)

# Generated at 2022-06-11 16:50:33.867765
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.six import PY3

    # Test creation
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert module._SHELL_AND == ';'
    assert module._IS_WINDOWS

    # Test init
    assert module.path_has_trailing_slash('C:\\')
    assert not module.path_has_trailing_slash('C:\\foo')
    assert module.path_has_trailing_slash('C:\\foo\\')
    assert not module.path_has_trailing_slash('\\\\foo\\bar')
    assert not module.path_has_trailing_slash('\\\\foo\\bar\\')
    assert module.path_

# Generated at 2022-06-11 16:50:39.083464
# Unit test for constructor of class ShellModule
def test_ShellModule():
    plugin = ShellModule(cli_transform.cli_transform("""
name: powershell
short_description: Windows PowerShell
description:
- The only option when using 'winrm' or 'psrp' as a connection plugin.
- Can also be used when using 'ssh' as a connection plugin and the C(DefaultShell) has been configured to PowerShell.
extends_documentation_fragment:
- shell_windows
"""))
