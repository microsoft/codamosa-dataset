

# Generated at 2022-06-11 16:41:40.358240
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    import os
    import random
    import string
    import tempfile

    random_str = ''.join(random.choice(string.ascii_uppercase) for i in range(10))

    # Some of the tests below do not work on OSX
    if 'darwin' not in str(os.uname()).lower():
        # Create a temporary file to test the get_remote_filename method
        temp_file = tempfile.NamedTemporaryFile()

        # Test an absolute file path
        temp_path = temp_file.name
        remote_filename = ShellModule().get_remote_filename(temp_path)
        assert temp_path == remote_filename

        # Test an absolute file path in a directory with trailing slash
        temp_path = temp_file.name + '\\'
        remote_filename = ShellModule().get_

# Generated at 2022-06-11 16:41:43.370356
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash('c:\\test\\') is True
    assert shell.path_has_trailing_slash('c:\\test') is False

# Generated at 2022-06-11 16:41:55.037238
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('/tmp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('C:/Temp/test.ps1') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.txt') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test.txt') == 'test.ps1'
    assert shell.get_remote_filename('/tmp/test') == 'test.ps1'
    assert shell.get_remote_filename('C:/Temp/test') == 'test.ps1'
    assert shell.get_remote_filename('C:/Temp/test.exe') == 'test.exe'

# Generated at 2022-06-11 16:42:05.472703
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    output = shell.build_module_command("", "#!powershell", "Write-Output \"Hello World!\"")

# Generated at 2022-06-11 16:42:06.289180
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-11 16:42:15.157203
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import ansible.plugins
    plugin = ansible.plugins.shell.ShellModule(connection=None, runner=None)
    plugin._IS_WINDOWS = True
    current_user = os.environ.get('USERNAME', 'bob')

    # test the empty user path
    script = plugin.expand_user('~')
    assert script == b'Write-Output (Get-Location).Path'

    # test the current user home path
    script = plugin.expand_user('~/a')
    assert script == b"Write-Output ((Get-Location).Path + '\\a')"

    # test the specified user home path
    script = plugin.expand_user('~%s/a' % current_user)
    assert script == b"Write-Output ((Get-Location).Path + '\\a')"

    # test the

# Generated at 2022-06-11 16:42:22.826486
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule(connection=None)
    temp_dir = shell.mkdtemp()
    temp_dir = temp_dir.strip()
    # The variable temp_dir should contain a directory name such as C:\Users\majid\AppData\Local\Temp\tmp0bgn8c
    base_name = os.path.basename(temp_dir)
    name, ext = os.path.splitext(base_name.strip())
    if len(name) != 8 or ext != '.ps1':
        raise Exception("The return value %s of method mkdtemp of class ShellModule is invalid" % temp_dir)


# Generated at 2022-06-11 16:42:30.720744
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    _test_mkdtemp_cases = [
        ('C:\\tmp'),
        (''),
        (None),
    ]

    for tmpdir in _test_mkdtemp_cases:
        powershell = ShellModule(connection=None)
        powershell.noop_on_check_mode = True
        powershell.get_option = lambda s: tmpdir
        res = powershell.mkdtemp()
        newdir = powershell.run(res)[1]
        assert len(newdir) > 0
        assert ' ' not in newdir
        powershell.run(powershell.remove(newdir))



# Generated at 2022-06-11 16:42:38.748679
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    class TestShellModule(ShellModule):
        def __init__(self):
            super(ShellModule, self).__init__()
            self.SHELL_FAMILY = 'powershell'

            self.get_option_cache = dict()

        def get_option(self, k):
            if k in self.get_option_cache:
                return self.get_option_cache[k]
            return None

    test_shell_module = TestShellModule()
    test_shell_module.get_option_cache['remote_tmp'] = "C:\\Users\\chandra\\AppData\\Local\\Temp"
    # Test Case 1: No tmpdir Provided

# Generated at 2022-06-11 16:42:45.554316
# Unit test for constructor of class ShellModule
def test_ShellModule():

    s = ShellModule()

    s = ShellModule()

    assert s.SHELL_FAMILY == "powershell"
    assert s.COMPATIBLE_SHELLS == frozenset()
    assert s.env_prefix() == ""

    assert s.join_path('\\foo', 'bar') == ntpath.join(ntpath.normpath('\\foo'), ntpath.normpath('bar'))
    assert s.join_path('\\foo', ' \\bar') == ntpath.join(ntpath.normpath('\\foo'), ntpath.normpath(' \\bar'))
    assert s.join_path('/foo', '/bar') == ntpath.join(ntpath.normpath('\\foo'), ntpath.normpath('\\bar'))

# Generated at 2022-06-11 16:42:55.159256
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_mod = ShellModule()
    assert shell_mod.create_shell_plugin("powershell").__class__.__name__ == "ShellModule"

# Generated at 2022-06-11 16:42:59.361972
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    # This is just a dummy test, this is the only test because this method is the only implemented method in this class
    # Because the main implementation is in the superclass (ShellBase in ansible.plugins.shell.ShellBase)
    assert shell_module is not None

# Generated at 2022-06-11 16:43:01.059807
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule().get_remote_filename('') == ''


# Generated at 2022-06-11 16:43:11.585414
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """This will create a object of ShellModule and check if it loads all the
    modules"""
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            hostname=dict(type='str', required=True),
            port=dict(type='int', required=True),
            protocol=dict(type='str', required=True),
            username=dict(type='str', required=True),
            password=dict(type='str', required=True, no_log=True)
        ),
        supports_check_mode=False,
    )

    # If no error, that means all the module loaded successfully
    shell_module_object = ShellModule(module)


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:43:13.456167
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert isinstance(obj, ShellModule)

# Generated at 2022-06-11 16:43:16.825346
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True
    assert module.COMPATIBLE_SHELLS == frozenset()

# Generated at 2022-06-11 16:43:19.268975
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:43:26.495991
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_name = 'win_ping'
    cmd = ['/bin/sh', '-c', "echo 'Hello World!'"]
    shebang = "#!powershell"
    args = "Hello"
    can_pipeline = True

    tester = ShellModule(module_name, cmd, shebang, args, can_pipeline)
    print(tester.check_powershell())
    result = tester.build_module_command(None, shebang, args)
    assert result[0:10] == '& $env:COMSPEC'
    print(result)

# Generated at 2022-06-11 16:43:30.779845
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    #""" Tests ShellModule.__init__() """
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True


# Generated at 2022-06-11 16:43:32.163876
# Unit test for constructor of class ShellModule
def test_ShellModule():
    x = ShellModule()
    assert x is not None

# Generated at 2022-06-11 16:43:37.988448
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == "powershell"
    assert shell._IS_WINDOWS

# Generated at 2022-06-11 16:43:39.779510
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Check to make sure class doesn't error out
    ShellModule(command_name='shell')

# Generated at 2022-06-11 16:43:41.276381
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.args == []



# Generated at 2022-06-11 16:43:42.038723
# Unit test for constructor of class ShellModule
def test_ShellModule():
   shell = ShellModule()

# Generated at 2022-06-11 16:43:47.091054
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm._unquote("'test'") == 'test'
    assert sm._unquote('"test"') == 'test'
    assert sm._unquote("'test '") == 'test '
    assert sm._unquote("' test '") == ' test '
    assert sm._unquote("' test") == ' test'


# Generated at 2022-06-11 16:43:52.082172
# Unit test for constructor of class ShellModule
def test_ShellModule():
    c = ShellModule()
    assert c.COMPATIBLE_SHELLS == frozenset()
    assert c.SHELL_FAMILY == 'powershell'
    assert c._SHELL_REDIRECT_ALLNULL == '> $null'
    assert c._SHELL_AND == ';'

# Generated at 2022-06-11 16:44:00.133698
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    actual = ShellModule(conn=None, tmpdir=None).expand_user(user_home_path='~')
    assert actual == u"Write-Output (Get-Location).Path"
    actual = ShellModule(conn=None, tmpdir=None).expand_user(user_home_path='~\\foo')
    assert actual == u"Write-Output ((Get-Location).Path + 'foo')"
    actual = ShellModule(conn=None, tmpdir=None).expand_user(user_home_path='foo.txt')
    assert actual == u"Write-Output 'foo.txt'"

# Generated at 2022-06-11 16:44:00.778813
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()

# Generated at 2022-06-11 16:44:11.801945
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # verify default values before we do anything
    assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null', 'Expected _SHELL_REDIRECT_ALLNULL to be initialized properly'
    assert ShellModule._SHELL_AND == ';', 'Expected _SHELL_AND to be initialized properly'
    assert ShellModule._IS_WINDOWS == True, 'Expected _IS_WINDOWS to be initialized properly'

    # verify static field values are immutable
    try:
        ShellModule._SHELL_REDIRECT_ALLNULL = 'foo'
        assert False, 'Expected _SHELL_REDIRECT_ALLNULL to be immutable'
    except AttributeError:
        pass

# Generated at 2022-06-11 16:44:12.376772
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

# Generated at 2022-06-11 16:44:17.458339
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell is not None

# Generated at 2022-06-11 16:44:18.917080
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module

# Generated at 2022-06-11 16:44:24.012944
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = None
    mod_name = 'tests.units.test_win_shell.MyModule'
    argument_spec = dict()
    try:
        module = __import__(mod_name, fromlist=['MyModule'])
    except ImportError:
        pass

    assert module is not None

    shell = ShellModule(None, argument_spec, bypass_checks=True)
    assert shell is not None


# Generated at 2022-06-11 16:44:31.821856
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # test_ShellModule is called by tests/units/shell/windows/test_windows.py
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell._IS_WINDOWS is True
    assert isinstance(shell.COMPATIBLE_SHELLS, frozenset)
    assert shell.SHELL_FAMILY == 'powershell'

    # Checks if the builtin commands of the powershell module execute
    assert shell._encode_script(script='''$hostname = hostname''') is not None

# Generated at 2022-06-11 16:44:37.087041
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(None, 'powershell', 'winrm', 'ansible_winrm_server', 'ansible_winrm_port', 'ansible_winrm_scheme', 'ansible_winrm_transport' , tuple())

    #TODO: add unit tests

# Generated at 2022-06-11 16:44:38.284500
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()


# Generated at 2022-06-11 16:44:46.744006
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.parsing.splitter import parse_kv
    from ansible.utils.vars import combine_vars

    # Find the real site module dir so that we can load example modules
    ansible_module_dir = os.path.join(os.path.dirname(__file__), u'..', u'..', u'lib', u'ansible', u'modules')

    # Initialize a ShellModule with fake_execute
    shell_module = type(u'ShellModule', (ShellModule,), {})()
    shell_module.connection._shell.exec_command = lambda x, y: (0, b'{"rc": 0, "stdout": "", "stderr": "", "changed": false}', b'')

    # Test a module that just works
    res = shell_module.run_command

# Generated at 2022-06-11 16:44:48.921336
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # pylint: disable=unused-variable,invalid-name
    shell = ShellModule()
    pass

# Generated at 2022-06-11 16:44:49.495034
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# Generated at 2022-06-11 16:44:55.685845
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert isinstance(shell.COMPATIBLE_SHELLS, frozenset)
    assert isinstance(shell.SHELL_FAMILY, str)
    assert isinstance(shell._SHELL_REDIRECT_ALLNULL, str)
    assert isinstance(shell._SHELL_AND, str)
    assert isinstance(shell._IS_WINDOWS, bool)


# Unit testing for different modules

# Generated at 2022-06-11 16:45:02.976503
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # The constructor uses the 'powershell' shell plugin and sets no executable.
    shell = ShellModule(None)
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.SHELL_EXECUTABLE == ''



# Generated at 2022-06-11 16:45:03.518958
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell is not None

# Generated at 2022-06-11 16:45:08.094611
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert ShellModule._IS_WINDOWS == True
    assert ShellModule.ENV_PREFIX == ''


# Generated at 2022-06-11 16:45:19.928851
# Unit test for constructor of class ShellModule
def test_ShellModule():  # NoQA
    """Test shell plugin initialization.

    Test that the ShellModule class does not fail in it's __init__
    when given a different args list than it expects.  We use this
    opportunity to test the shell plugin shell subclass to class
    mapping which is done using the COMPATIBLE_SHELLS class member.
    """
    plugin_class = ShellModule  # NoQA

    # start the tests
    class Options(object):
        def __init__(self, **kwargs):
            self._attrs = kwargs

        def __contains__(self, name):
            return name in self._attrs

        def __getattr__(self, name):
            try:
                return self._attrs[name]
            except KeyError:
                raise AttributeError(name)


# Generated at 2022-06-11 16:45:26.148704
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """ShellModule - constructor test"""

    obj = ShellModule()
    assert obj._CHARS_TO_ESCAPE == {'\n': '`n', '\r': '`r', '\t': '`t', '\x1a': '`z', ' ': '` ', '"': '`"'}
    assert obj.COMPATIBLE_SHELLS == frozenset()
    assert obj.SHELL_FAMILY == 'powershell'
    assert obj._IS_WINDOWS



# Generated at 2022-06-11 16:45:27.979443
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''Unit test for constructor of class ShellModule'''
    assert ShellModule() is not None

# Generated at 2022-06-11 16:45:31.316164
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == u'powershell'

# Generated at 2022-06-11 16:45:41.954038
# Unit test for constructor of class ShellModule
def test_ShellModule():
    args = dict(
        binary_module=True,
        create_remote_temp=True,
        executable=None,
        extension=None,
        no_log=None,
        no_target_system_cleanup=None,
        persist_files=None,
        remote_tmp=None,
        remove_tmp=None,
        shell_type="powershell",
        stdin=None,
        stdin_add_newline=None,
        strip_empty_ends=None,
        su=None,
        sudo=None,
        sudo_user=None,
        tmpdir=None,
        umask=None,
        unsafe_writes=None
    )
    shell_plugin = ShellModule(**args)
    assert shell_plugin.SHELL_FAMILY == "powershell"


# Generated at 2022-06-11 16:45:42.614508
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-11 16:45:44.456399
# Unit test for constructor of class ShellModule
def test_ShellModule():
    my_shellmodule = ShellModule()
    assert my_shellmodule is not None

# Generated at 2022-06-11 16:45:50.280366
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule().IS_WINDOWS
    assert ShellModule()._SHELL_REDIRECT_ALLNULL == '> $null'

# Generated at 2022-06-11 16:45:58.453007
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import sys
    import json

    # noinspection PyPep8Naming
    class MockModule(object):
        # noinspection PyShadowingBuiltins
        def __init__(self, name='', **kwargs):
            self.module_name = name
            self.params = kwargs
            # noinspection PyUnresolvedReferences
            self.debug = lambda x: sys.stderr.write(to_bytes(x + '\n'))

    shell_module = ShellModule(connection='winrm')
    assert shell_module.shell_type == 'powershell'

    shell_module = ShellModule(connection='psrp')
    assert shell_module.shell_type == 'powershell'

    # noinspection PyProtectedMember

# Generated at 2022-06-11 16:46:04.028743
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # of type ShellModule
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module._IS_WINDOWS
    # class variable
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule._IS_WINDOWS


# Generated at 2022-06-11 16:46:13.530772
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule(connection=None, no_log=True)
    cmd_parts = module._encode_script(script='''Get-Member -InputObject $null''', as_list=True)
    assert cmd_parts == ['PowerShell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Unrestricted',
                         '-EncodedCommand', 'UwBlAHQALQAtAHMAYQByAGkAcAB0ACkA']

    cmd_parts = module._encode_script(script='-', as_list=True)
    assert cmd_parts == ['PowerShell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Unrestricted', '-Command', '-']


# Generated at 2022-06-11 16:46:15.357195
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sh = ShellModule()
    # create an instance of ShellModule
    assert isinstance(sh, ShellModule)

# Generated at 2022-06-11 16:46:26.323472
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert ShellModule._IS_WINDOWS is True
    assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule._SHELL_AND == ';'

    shell_module = ShellModule()
    assert shell_module.get_remote_filename('test.ps1') == 'test.ps1'
    assert shell_module.get_remote_filename('test') == 'test.ps1'
    assert shell_module.get_remote_filename('test.exe') == 'test.exe'

# Generated at 2022-06-11 16:46:28.507057
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule(ShellBase(), 'winrm', 'winrm', '', 'unix')
    return True

# Generated at 2022-06-11 16:46:30.882872
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test code is in test/units/plugins/connection/test_connection_powershell.py
    pass

# Generated at 2022-06-11 16:46:35.160057
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

    assert not shell.COMPATIBLE_SHELLS
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS


# Unit tests for ShellModule.join_path()

# Generated at 2022-06-11 16:46:36.883183
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert hasattr(ShellModule, 'IS_WINDOWS')

# Generated at 2022-06-11 16:46:46.238820
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Test __init__ method
    shell_instance = ShellModule()
    assert shell_instance

# Generated at 2022-06-11 16:46:49.013795
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY == 'powershell'
    assert module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-11 16:46:53.060645
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mod = ShellModule()
    assert mod.SHELL_FAMILY == 'powershell'
    assert mod._SHELL_REDIRECT_ALLNULL == '> $null'
    assert mod._SHELL_AND == ';'

# Generated at 2022-06-11 16:46:54.073258
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.SHELL_FAMILY is None

# Generated at 2022-06-11 16:46:55.056779
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()

# Generated at 2022-06-11 16:46:56.131260
# Unit test for constructor of class ShellModule
def test_ShellModule():
    the_test = ShellModule('connection')
    del the_test

# Generated at 2022-06-11 16:47:01.004311
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_mod = ShellModule()
    print(shell_mod.get_remote_filename('unit_test_file.txt'))
    print(shell_mod.expand_user('~', 'testuser'))

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:47:04.672714
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Tests the constructor of class ShellModule
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-11 16:47:10.267692
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'
    assert type(module.COMPATIBLE_SHELLS) == frozenset
    assert type(module.SHELL_FAMILY) == str

# Generated at 2022-06-11 16:47:10.969077
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-11 16:47:37.842099
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import sys
    if sys.version_info[0] == 2:
        raise AssertionError("Error: %s module not supported in Python 2" % __name__)

    # Load module parameters
    mock_args = {'ANSIBLE_MODULE_ARGS': {'_uses_shell': True}}
    mock_args['ANSIBLE_MODULE_ARGS']['_ansible_verbosity'] = 0
    mock_args['ANSIBLE_MODULE_ARGS']['_ansible_debug'] = False
    mock_args['ANSIBLE_MODULE_ARGS']['_ansible_check_mode'] = False

    # Initialize
    mock_module = {}
    mock_module['module_utils'] = 'ansible.module_utils.basic'
    mock_module['SupportsAsync'] = True
    mock

# Generated at 2022-06-11 16:47:40.631503
# Unit test for constructor of class ShellModule
def test_ShellModule():
    m = ShellModule()
    assert m.SHELL_FAMILY == 'powershell'
    assert m.COMPATIBLE_SHELLS == frozenset()



# Generated at 2022-06-11 16:47:41.240676
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

# Generated at 2022-06-11 16:47:43.973386
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.plugins.shell.powershell import ShellModule
    sm = ShellModule()
    print("Test for constructor of class ShellModule passed.")

# Generated at 2022-06-11 16:47:45.470240
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell is not None
    assert shell.COMPATIBLE_SHELLS == 'powershell'

# Generated at 2022-06-11 16:47:46.600287
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell is not None

# Generated at 2022-06-11 16:47:57.714954
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    def _assert(shell, shebang, cmd, expected):
        assert expected == shell.build_module_command(env_string='', shebang=shebang, cmd=cmd, arg_path=None)

    shell = ShellModule(connection=None)
    # cmd with no shebang
    _assert(shell, shebang='', cmd='', expected='& \r\n; exit $LASTEXITCODE')
    _assert(shell, shebang='', cmd='a', expected='& a; exit $LASTEXITCODE')

    # cmd with shebang of '#!'
    _assert(shell, shebang='#!', cmd='', expected='& \r\n; exit $LASTEXITCODE')

# Generated at 2022-06-11 16:48:03.604091
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import ansible.plugins.connection.powershell
    d = dict(connection=ansible.plugins.connection.powershell.Connection(),
             no_log=False,
             become_method=None,
             become_user='root',
             check=False,
             diff=False)
    t = ShellModule(**d)
    assert t.SHELL_FAMILY == 'powershell'
    assert t.COMPATIBLE_SHELLS == set()
    assert t._IS_WINDOWS



# Generated at 2022-06-11 16:48:07.583298
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Constructor is essentially a no-op
    module = ShellModule()

    # The two attributes that get set by plugins are
    # shell_type, which is just a string
    assert module.shell_type == "powershell"

    # and terminal which is a boolean.  It is set based
    # on the connection plugin.
    assert not module.terminal



# Generated at 2022-06-11 16:48:10.033529
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import ansible.executor.powershell
    sh_mod = ShellModule(connection='winrm')
    assert isinstance(sh_mod, ShellModule)
    assert hasattr(ansible.executor.powershell, 'ShellModule')



# Generated at 2022-06-11 16:48:40.494488
# Unit test for constructor of class ShellModule
def test_ShellModule():
  """
  Basic constructor test
  """
  m = ShellModule()
  return

# Generated at 2022-06-11 16:48:42.729500
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell = ShellModule()

    assert shell


# Generated at 2022-06-11 16:48:47.705234
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert isinstance(shell, ShellBase)
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-11 16:48:49.519190
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule(connection=None, shell_executable=None)
    return shell_module


# Generated at 2022-06-11 16:48:50.836878
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule('powershell')

# Generated at 2022-06-11 16:48:54.397409
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS == True

# Generated at 2022-06-11 16:49:03.499831
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

    # Test _escape function
    assert shell._escape(u'') == u''
    assert shell._escape(u'echo hello world') == u'echo hello world'
    assert shell._escape(u'echo "hello world"') == u'echo ""hello world""'
    assert shell._escape(u'echo \'hello world\'') == u'echo \'\'hello world\'\''
    assert shell._escape(u'echo ‘hello world’') == u'echo ‘‘hello world’’'
    assert shell._escape(u'echo “hello world”') == u'echo “”hello world””'

    # Test _unquote function
    assert shell._unquote(u'') == u''

# Generated at 2022-06-11 16:49:04.873837
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert hasattr(ShellModule(), 'run')

# Generated at 2022-06-11 16:49:07.102190
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_shell = ShellModule()
    assert type(module_shell) == ShellModule


# Generated at 2022-06-11 16:49:16.165634
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    shell_args = [
        'PowerShell',
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy',
        'Unrestricted'
    ]
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True
    assert module._SHELL_REDIRECT_ALLNULL == "> $null"
    assert module._SHELL_AND == ';'
    assert module.env_prefix() == ""
    assert module.join_path('/root', 'test.txt') == '\\root\\test.txt'

# Generated at 2022-06-11 16:50:29.061010
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """
    Make sure str instantiation of this class works.
    """

    from ansible.plugins.loader import shell_loader
    mod = ShellModule(connection=None)  # pylint: disable=unused-variable



# Generated at 2022-06-11 16:50:35.126253
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule(connection=None)
    assert shell_obj.SHELL_FAMILY == 'powershell'
    assert shell_obj.COMPATIBLE_SHELLS == frozenset()
    assert shell_obj._IS_WINDOWS is True
    assert shell_obj._SHELL_REDIRECT_ALLNULL == "> $null"
    assert shell_obj._SHELL_AND == ";"



# Generated at 2022-06-11 16:50:37.445937
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj = ShellModule()
    assert shell_obj is not None

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-11 16:50:46.278756
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Powershell is handled differently.  It's selected when winrm is the
    # connection.  Let's instantiate the class and use python to patch in
    # the connection info
    ansible_collections = {'ansible.windows': '2.9.0.0'}
    sm = ShellModule()
    new_tmpl = {'winrm':{'transport': 'winrm', 'remote_addr': '127.0.0.1', 'port': 5985, 'remote_user': 'test', 'ansible_winrm_server_cert_validation': 'ignore'}}
    sm.set_options(var_options=new_tmpl, add_ansible_collections=ansible_collections)
    assert sm.connection == 'winrm'
    # Check some other attribures too
    assert sm._IS_

# Generated at 2022-06-11 16:50:54.280399
# Unit test for constructor of class ShellModule
def test_ShellModule():
    plugin = ShellModule()
    assert plugin.option_comment_begin == "'"
    assert plugin.option_comment_end == "\r\n"
    assert plugin.option_delimiter == ' '
    assert plugin._SHELL_REDIRECT_ALLNULL == '> $null'
    assert plugin._SHELL_AND == ';'
    assert plugin._IS_WINDOWS
    assert plugin.COMPATIBLE_SHELLS == frozenset()
    assert plugin.SHELL_FAMILY == 'powershell'

# Unit tests for _parse_clixml function

# Generated at 2022-06-11 16:50:55.955747
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.plugins.connection.local import Connection
    ShellModule(Connection())

# Generated at 2022-06-11 16:51:02.626650
# Unit test for method build_module_command of class ShellModule

# Generated at 2022-06-11 16:51:06.841497
# Unit test for constructor of class ShellModule
def test_ShellModule():
    powerShellShell = ShellModule()
    assert powerShellShell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert powerShellShell._SHELL_AND == ';'
    assert powerShellShell._IS_WINDOWS == True


# Generated at 2022-06-11 16:51:07.818695
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule is not None

# Generated at 2022-06-11 16:51:08.893558
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_mod = ShellModule()
    assert shell_mod

