

# Generated at 2022-06-25 11:48:08.328826
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    basefile = "test_basefile"
    system = False
    mode = None
    tmpdir = None
    ret = shell_module_0.mkdtemp(basefile, system, mode, tmpdir)
    assert ret

# Generated at 2022-06-25 11:48:15.098396
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert isinstance(shell_module_1, ShellModule)
    assert shell_module_1.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_1.SHELL_FAMILY == 'powershell'
    assert shell_module_1._IS_WINDOWS == True
    assert shell_module_1._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_1._SHELL_AND == ';'



# Generated at 2022-06-25 11:48:21.936234
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module = ShellModule()
    assert shell_module.get_remote_filename("/etc/ansible/hosts") == "hosts"
    assert shell_module.get_remote_filename("/etc/ansible/hosts.ps1") == "hosts.ps1"
    assert shell_module.get_remote_filename("/etc/ansible/hosts.exe") == "hosts.exe"


# Generated at 2022-06-25 11:48:23.130438
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:48:31.953358
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_1 = ShellModule()
    # CASE 1
    # Test case setup
    basefile = 'tmpdir.XXXXXX'
    system_0 = False
    mode = None
    # Expected result
    mdtemp_result = shell_module_1._encode_script('''$tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Users\\NISHA~1.GUP\\AppData\\Local\\Temp')
    $tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmpdir.XXXXXX'
    Write-Output -InputObject $tmp.FullName
    ''')
    # Test case execution
    result = shell_module_1.mkdtemp(basefile, system_0, mode)
    # Test case verification
    assert result == mdtemp_result

#

# Generated at 2022-06-25 11:48:36.444726
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:40.277561
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule(None)
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-25 11:48:41.586971
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:44.447368
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert callable(ShellModule)
    assert issubclass(ShellModule, object)
    assert not issubclass(ShellModule, ShellBase)
# Testing the _unquote method

# Generated at 2022-06-25 11:48:50.245680
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # Code for test_case_0
    container = ShellModule()
    pathname = "/tmp/test.ps1"
    expected_result = "test.ps1"
    actual_result = container.get_remote_filename(pathname)

    assert expected_result == actual_result, "Test failed."



# Generated at 2022-06-25 11:49:08.523761
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0
    assert shell_module_0._IS_WINDOWS
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0.env_prefix() == ""
    assert shell_module_0.join_path("C:/Program Files", "Microsoft", "WindowsPowerShell/v1.0") == "C:\\Program Files\\Microsoft\\WindowsPowerShell\\v1.0"
    assert shell_module_0.get_remote_filename("file") == "file.ps1"
    assert shell_module_0.get_remote_filename("file.bat") == "file.bat"
    assert shell_module_0.get_remote_

# Generated at 2022-06-25 11:49:09.907491
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()

# test for function _escape of class ShellModule

# Generated at 2022-06-25 11:49:12.738048
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:49:16.181331
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS == True
    return shell_module_0


# Generated at 2022-06-25 11:49:21.577994
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    myshell = ShellModule()
    assert(myshell.path_has_trailing_slash('c:\\foo\\') == True)
    assert(myshell.path_has_trailing_slash('c:\\foo') == False)


# Generated at 2022-06-25 11:49:32.492010
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_1 = ShellModule()
    env_string_1 = """$env:ANSIBLE_FORCE_COLOR="true";"""
    shebang_1 = """#!powershell"""
    cmd_1 = """$out=@();$all=Get-EventLog -LogName Application -InstanceID 1000;$all|ForEach-Object {$out+=$_.ReplacementStrings};if ($out.Length -ne 0) {$msg=$out[0] + " :: " + $out[1] + " :: " + $out[2];Write-Output $msg};"""
    arg_path_1 = None
    shell_module_1.build_module_command(env_string_1, shebang_1, cmd_1, arg_path_1)


# Generated at 2022-06-25 11:49:39.827665
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # This test does not need to be executed
    pass
    # It is only for generating the test cases
    args_list = []
    # Generating the arguments of the function
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None
    # Executing the function with the arguments
    shell_module_0.env_prefix()
    # Testing the results of the function


# Generated at 2022-06-25 11:49:41.848425
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1") != b''



# Generated at 2022-06-25 11:49:45.574305
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("\n In ShellModule Module \n")
    print("\n Getting ShellModule Details\n")
    shell_module_0 = ShellModule()
    print("\n We've created a instance for ShellModule class\n")



# Generated at 2022-06-25 11:49:47.983049
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:49:58.595011
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_1 = ShellModule()

# Generated at 2022-06-25 11:50:04.689713
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("TestCase::test_ShellModule - Start")
    shell_module = ShellModule()
    assert shell_module is not None
    print("TestCase::test_ShellModule - End")


# Generated at 2022-06-25 11:50:07.340264
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('Testing constructor of class ShellModule...')
    shell_module_1 = ShellModule()
    assert(shell_module_1)


# Generated at 2022-06-25 11:50:11.880335
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_1 = ShellModule()
    result = shell_module_1.expand_user('~/test/path')
    print(result)



# Generated at 2022-06-25 11:50:17.752386
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert tuple(ShellModule.COMPATIBLE_SHELLS) == ()
    # assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert isinstance(shell_module._IS_WINDOWS, bool)



# Generated at 2022-06-25 11:50:24.211528
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    # Pathnames with the tilde character are expanded to the user's home directory.
    # This test case is for the pathname with the tilde character.
    user_home_path = '~'
    assert shell_module_0.expand_user(user_home_path) == shell_module_0._encode_script(script='Write-Output (Get-Location).Path')
    # This test case is for the pathname without the tilde character.
    user_home_path = '~\\'
    assert shell_module_0.expand_user(user_home_path) == shell_module_0._encode_script(script="Write-Output ((Get-Location).Path + '')")
    # This test case is for the pathname without the tilde character and the pathname is not

# Generated at 2022-06-25 11:50:26.558688
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    method_res_0 = shell_module_0.mkdtemp()
    assert isinstance(method_res_0, bytes)


# Generated at 2022-06-25 11:50:30.682476
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # test case for when shell_type is winrm
    shell_module_0 = ShellModule()

    # test case for when shell_type is ssh
    shell_module_1 = ShellModule(shell_type= 'ssh')


# Generated at 2022-06-25 11:50:35.423429
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:50:42.926246
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():

    shell_module = ShellModule()
    assert shell_module.path_has_trailing_slash("C:/cygwin64/home/Administrator/Documents/ansible/") == True
    assert shell_module.path_has_trailing_slash("C:\\cygwin64\\home\\Administrator\\Documents\\ansible\\") == True
    assert shell_module.path_has_trailing_slash("C:\\cygwin64\\home\\Administrator\\Documents\\ansible") == False
    assert shell_module.path_has_trailing_slash("C:\\cygwin64\\home\\Administrator\\Documents\\ansible//") == True



# Generated at 2022-06-25 11:50:52.245197
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.plugins.shell import ShellBase
    from ansible.module_utils.common.remoting import Connection

    connection = Connection(ShellModule())
    assert connection.shell._IS_WINDOWS == True
    assert connection.shell.SHELL_FAMILY == "powershell"



# Generated at 2022-06-25 11:50:54.397916
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-25 11:50:55.863505
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0


# Generated at 2022-06-25 11:51:02.222675
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # test_case_0 is a constructor of the class ShellModule
    shell_module_0 = ShellModule()

    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:51:05.536237
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    if shell_module_1 is None:
        raise AssertionError("Object of type ShellModule is not created")


# Generated at 2022-06-25 11:51:10.446128
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule(connection=None, new_stdin=None,
                               runner_q=None,
                               ansible_shell_type='powershell',
                               ansible_shell_executable='powershell',
                               become_username=None,
                               become_method=None,
                               become_password=None)
    print("ShellModule class successfully instantiated")


# Generated at 2022-06-25 11:51:14.476571
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None


# Generated at 2022-06-25 11:51:15.506971
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:18.245123
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_unittest_instance = ShellModule()


# Generated at 2022-06-25 11:51:21.333719
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.powershell import ShellModule
    shell_module_0 = ShellModule()
    assert ("ShellBase" == shell_module_0.__class__.__bases__[0].__name__)


# Generated at 2022-06-25 11:51:38.062042
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    cmd = shell_module_0._encode_script(script="Write-Output 1-2-3")
    cmd = shell_module_0._encode_script(script="Write-Output 1-2-3", as_list=True)
    cmd = shell_module_0._encode_script(script="Write-Output 1-2-3", strict_mode=False)
    cmd = shell_module_0._encode_script(script="Write-Output 1-2-3", strict_mode=False, preserve_rc=False)
    cmd = shell_module_0.wrap_for_exec(cmd=cmd)
    pathname = shell_module_0.get_remote_filename(pathname="C:\\Users\\MyPC\\Desktop\\test.ps1")
    pathname = shell

# Generated at 2022-06-25 11:51:39.703827
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Unit test of static method _encode_script in class ShellModule

# Generated at 2022-06-25 11:51:45.675094
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    print("test_ShellModule passed")


# Generated at 2022-06-25 11:51:46.822904
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:51:47.905806
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert test_case_0() == None, "Constructor failed"



# Generated at 2022-06-25 11:51:49.182298
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:51:50.526940
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:51:57.079671
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    assert shell_module == ShellModule()
    assert shell_module._IS_WINDOWS == True
    assert shell_module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-25 11:52:04.637606
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()
    print(str_output)

# -------------------------------------------------------------------------------------------------------
#
#               P E R F O R M   T E S T   O N   C L A S S   ShellModule
#
# -------------------------------------------------------------------------------------------------------

# Module name
TEST_MODULE_NAME = 'test_module_00'

# Verbosity level for the test
TEST_VERBOSITY = '-v'

# Global variable to save the command output
str_output = ''

if __name__ == "__main__":
    # sys.argv[0] is the module name
    if len(sys.argv) == 1:
        print('Usage: ' + sys.argv[0] + ' <test-verbosity-level>')

# Generated at 2022-06-25 11:52:16.886560
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module_0 = ShellModule()
    shell_module_0.is_windows()
    shell_module_0.get_option('remote_tmp')
    shell_module_0.join_path('ps_out.ps1.part', 'var', '')
    shell_module_0.get_remote_filename('path/to/module')
    shell_module_0.get_remote_filename('path/to/module.ps1')
    shell_module_0.get_remote_filename('path/to/binary.exe')
    shell_module_0.get_remote_filename('path/to/binary.ps1.exe')
    shell_module_0.path_has_trailing_slash('c:\\')

# Generated at 2022-06-25 11:52:30.172278
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:52:34.351995
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test whether shell_module object is created or not
    shell_module = ShellModule()
    assert shell_module is not None


# Test whether it returns the expected string

# Generated at 2022-06-25 11:52:44.743277
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellModule = ShellModule()

    assert shellModule._IS_WINDOWS == True, "Global variable _IS_WINDOWS has been changed. Please fix"

    assert shellModule.COMPATIBLE_SHELLS == frozenset(), "Global variable COMPATIBLE_SHELLS has been changed. Please fix"

    assert shellModule.SHELL_FAMILY == 'powershell', "Global variable SHELL_FAMILY has been changed. Please fix"

    assert shellModule._SHELL_REDIRECT_ALLNULL == "> $null", "Global variable _SHELL_REDIRECT_ALLNULL has been changed. Please fix"

    assert shellModule._SHELL_AND == ";", "Global variable _SHELL_AND has been changed. Please fix"



# Generated at 2022-06-25 11:52:53.693333
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.loader import connection_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.context import CLIContext

    results = {}
    module = AnsibleModule(
        argument_spec = dict(),
    )

    # set up the module_utils/basic.py objects
    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.become = False
    play_context.become_method = 'default'
    play_context.become_user = False
    play_context.remote_addr = '127.0.0.1'

# Generated at 2022-06-25 11:52:59.667474
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule() # create object of ShellModule Class    
    assert shell_module == shell_module
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module._IS_WINDOWS == True
    assert shell_module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:53:04.400447
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

test_case_0.test_ShellModule = test_ShellModule

# Unit testing for class ShellModule with command-line arguments

# Generated at 2022-06-25 11:53:10.745957
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    if shell_module_1 is not None:
        print("Success: Constructor of class ShellModule")
    else:
        print("Failure: Constructor of class ShellModule")


# Generated at 2022-06-25 11:53:12.867960
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    return shell_module_0


# Generated at 2022-06-25 11:53:16.356904
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('test_ShellModule - BEGIN')
    shell_module_0 = ShellModule()
    print('test_ShellModule - END')

test_ShellModule()

# Generated at 2022-06-25 11:53:19.354014
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'

# Generated at 2022-06-25 11:53:59.703720
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1


# Generated at 2022-06-25 11:54:04.466932
# Unit test for constructor of class ShellModule
def test_ShellModule():

    hostname = 'localhost'
    username = 'bob'
    password = 's3cret!'
    port = 22

    transport = 'winrm'
    connection = Connection(host=hostname, user=username, port=port,
                            passwd=password, transport=transport)

    shell_module = ShellModule(connection)

    assert shell_module.connection == connection
    assert shell_module.no_log == []


# Generated at 2022-06-25 11:54:07.017974
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:54:10.656248
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:54:12.256148
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # it checks the instance type for class ShellModule
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)



# Generated at 2022-06-25 11:54:22.008946
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("\n")
    print("+" * 15)
    print("\nTesting the constructor of ShellModule class")
    shell_module_0 = ShellModule()
    print("\n")

    if shell_module_0.COMPATIBLE_SHELLS == frozenset():
        print("+" * 15)
        print("\nTesting the constructor of ShellModule class PASSED\n")
    else:
        print("+" * 15)
        print("\nTesting the constructor of ShellModule class FAILED\n")


# Generated at 2022-06-25 11:54:23.063984
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print('PASSED: ShellModule instantiated')

# Generated at 2022-06-25 11:54:24.722108
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:28.404239
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:54:31.020198
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()

    if shell_module_1 is not shell_module_0:
        raise AssertionError("Failed to create a singleton instance of Class ShellModule")


# Generated at 2022-06-25 11:55:00.991174
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test case 0 - test successful instantiation of ShellModule
    #shell_module_0 = ShellModule()
    assert shell_module_0 is not None



# Generated at 2022-06-25 11:55:02.263423
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return shell_module_0


# Generated at 2022-06-25 11:55:04.564763
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
        print("pass")
    except Exception as err:
        raise err
    return


# Generated at 2022-06-25 11:55:16.961134
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module._encode_script("echo 'hello world'") == "PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand IABlACgAZwBsAGUAIAB0AGgAZQAgACQAbwBjAGsAaQBuAGUAIAAnAGwAZQB0AGkAbwBuAFwAZQBEAGkAbgBnAF0A"
    assert shell_module.get_remote_filename("/tmp/ansible_shell_test/test_file.txt") == "test_file.txt"
    assert shell_module.get_remote_filename("/tmp/ansible_shell_test/test_file.exe") == "test_file.exe"

# Generated at 2022-06-25 11:55:21.395255
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

# Generated at 2022-06-25 11:55:23.084630
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:55:32.786025
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None
    assert type(shell_module_0) is ShellModule
    assert shell_module_0._SHELL_REDIRECT_ALLNULL is not None
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND is not None
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS is not None
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:55:38.799750
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("##### Test case: ShellModule() #####")
    test_case_0()

# Collect all test cases in this file
test_cases = [
    test_case_0,
]


# Collect all test classes in this file
test_classes = [
    test_ShellModule,
]


# Unit tests to run
# Add class name to run just the specified class.
# Tests can also be filtered by tag.

# Generated at 2022-06-25 11:55:46.188613
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:55:48.483780
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:56:17.246550
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Positive tests
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:56:18.054030
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:56:19.189740
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_var = ShellModule()


# Generated at 2022-06-25 11:56:22.493847
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # AssertionError: expected an object of type <class 'ansible.plugins.shell.powershell.ShellModule'>, got <class 'ansible.plugins.shell.powershell.ShellModule'>
    # assert isinstance(shell_module_0, ansible.plugins.shell.powershell.ShellModule)


# Generated at 2022-06-25 11:56:25.566990
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    test_case_0()


# Generated at 2022-06-25 11:56:31.245322
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == "> $null"
    assert shell_module_0._SHELL_AND == ";"
    assert shell_module_0._IS_WINDOWS is True
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == "powershell"
    return shell_module_0

# unit test for function env_prefix

# Generated at 2022-06-25 11:56:34.185114
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # TODO: Test this in real powershell.
    shell_module_0 = ShellModule()
    var_0 = ''
    var_1 = '#!powershell'
    var_2 = '$x = "test"; Write-Output $x;'
    with pytest.raises(NotImplementedError) as e:
        shell_module_0.build_module_command(var_0, var_1, var_2)


# Generated at 2022-06-25 11:56:39.431950
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module


# Generated at 2022-06-25 11:56:40.347291
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:56:41.233309
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # FIXME: Test will be added later
    pass


# Generated at 2022-06-25 11:57:19.988709
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_c0 = ShellModule()
    print("Instance Type: " + str(type(shell_module_c0)))
    print("mdktemp() = " + shell_mkdtemp())
    print("exists('') = " + shell_exists())
    print("chmod() not implemented")
    print("chown() not implemented")
    print("set_user_facl() not implemented")
    print("get_remote_filename('') = " + shell_get_remote_filename())
    print("path_has_trailing_slash('') = " + str(shell_path_has_trailing_slash()))
    print("expand_user('') = " + shell_expand_user())
    print("checksum('') = " + shell_checksum())

# Generated at 2022-06-25 11:57:21.190343
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print(shell_module_0)


# Generated at 2022-06-25 11:57:24.257348
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('***')
    print('*** TestCase ShellModule ')
    print('***')

    shell_module_0 = ShellModule()
    assert_equals(shell_module_0.get_option('true_command'), '')

    # Calling ShellModule() constructor with an argument is unsupported
    expect_exception(lambda: ShellModule(''))



# Generated at 2022-06-25 11:57:30.841173
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert type(shell_module) == ShellModule
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module.SHELL_TYPE == 'powershell'
    assert shell_module.LANGUAGE == 'powershell'


# Generated at 2022-06-25 11:57:32.209919
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:57:36.045506
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module = ShellModule()
    shell_module_0 = ShellModule()
    assert shell_module != None
    # assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module.COMPATIBLE_SHELLS == set()
    assert shell_module._IS_WINDOWS
    assert shell_module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-25 11:57:41.705642
# Unit test for constructor of class ShellModule
def test_ShellModule():
    if not hasattr(test_ShellModule, 'assert_var'):
        test_ShellModule.assert_var = 0
    test_case_0()
    test_ShellModule.assert_var += 1
    assert shell_module_0 is not None, "null shell_module_0"
    assert var_0 is not None, "null var_0"
    assert shell_module_0._IS_WINDOWS == True, "shell_module_0._IS_WINDOWS is False"
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset(), "shell_module_0.COMPATIBLE_SHELLS is not frozenset()"

# Generated at 2022-06-25 11:57:44.512564
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(isinstance(shell_module_0, ShellModule))


# Generated at 2022-06-25 11:57:49.362874
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module
    assert shell_module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:57:50.362507
# Unit test for constructor of class ShellModule
def test_ShellModule():
    var_0 = ShellModule()
