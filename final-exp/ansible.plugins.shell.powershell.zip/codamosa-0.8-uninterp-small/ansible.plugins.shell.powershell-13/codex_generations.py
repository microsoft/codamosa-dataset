

# Generated at 2022-06-25 11:48:08.711974
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module = ShellModule()
    test_mkdtemp_dir = shell_module.mkdtemp()
    shell_module.rmdir(test_mkdtemp_dir)


# Generated at 2022-06-25 11:48:20.329302
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    output = shell_module_0.build_module_command("", "", "")
    assert output == b"JABmdXNlciA9ICJkb21haW4=\ndXNlciA9ICJkb21haW4=\n"
    output = shell_module_0.build_module_command("", "", "", "")
    assert output == b"JABmdXNlciA9ICJkb21haW4=\ndXNlciA9ICJkb21haW4=\n"
    output = shell_module_0.build_module_command("", "", "", "")

# Generated at 2022-06-25 11:48:21.283697
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:48:26.295506
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("ShellModule.get_remote_filename")
    shell_module_0 = ShellModule()
    shell_module_0.get_remote_filename("C:\\Users\\Administrator\\Ansible\\")
    shell_module_1 = ShellModule()
    shell_module_1.get_remote_filename("C:\\Users\\Administrator\\Ansible\\test.txt")


# Generated at 2022-06-25 11:48:32.638026
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Initialize the object
    shell_module_0 = ShellModule()

    # Set parameters for build_module_command
    arg0 = "asdf"
    arg1 = "sdf"
    arg2 = "asdf"
    arg3 = "sdf"

    # Invoke method
    # TODO: Invoke method and verify the result
    # Result 1:
    # Result 2:
    # Result 3:
    # ...
    # shell_module_0.build_module_command(arg0, arg1, arg2, arg3)


# Generated at 2022-06-25 11:48:43.691753
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    return_value = shell_module_0.get_remote_filename('/tmp/test')
    assert 'test.ps1' == return_value
    return_value = shell_module_0.get_remote_filename('/tmp/test.ps1')
    assert 'test.ps1' == return_value
    return_value = shell_module_0.get_remote_filename('/tmp/test.exe')
    assert 'test.exe' == return_value
    return_value = shell_module_0.get_remote_filename('/tmp/test.py')
    assert 'test.py' == return_value


# Generated at 2022-06-25 11:48:54.665123
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    #
    # Arrange
    #
    # build_module_command(self, env_string, shebang, cmd, arg_path=None)
    #
    shell_module_0 = ShellModule()
    env_string = '$env:ANSIBLE_NET_USERNAME=u\'username\''
    shebang = '#!powershell'
    cmd = 'ping google.com'
    #arg_path = None

    #
    # Act
    #
    expected = shell_module_0.build_module_command(env_string, shebang, cmd)
    print('\nexpected[%s]\n' % expected)
    #
    # Assert
    #
    assert expected
    #assert expected == 'cmd /c echo $env:ANSIBLE_NET_USERNAME=u\'username\' & c:/Users/

# Generated at 2022-06-25 11:49:02.336497
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    test_cases_0 = [
        'base',
        'base.ps1',
        'base.exe',
        'base.',
        '/base',
        'base/',
        '/base/',
        'base.ps1/',
        '/base.ps1/',
        '/base/base.ps1',
        '/base/base.exe',
        '\\base',
        'base\\',
        '\\base\\',
        'base.ps1\\',
        '\\base.ps1\\',
        '\\base\\base.ps1',
        '\\base\\base.exe'
    ]

# Generated at 2022-06-25 11:49:07.716667
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    output = shell_module_0.mkdtemp()
    assert type(output) == dict
    output = shell_module_1.mkdtemp()
    assert type(output) == dict


# Generated at 2022-06-25 11:49:15.225064
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    shell_module_0.get_remote_filename("")
    shell_module_0.get_remote_filename("sample_pathname")
    shell_module_0.get_remote_filename("sample_pathname.ps1")


# Generated at 2022-06-25 11:49:21.733553
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    actual = isinstance(shell_module_0, ShellBase)
    expected = True
    msg = "The instance of the class ShellModule is not an instance ShellBase"
    assert actual == expected, msg


# Generated at 2022-06-25 11:49:24.536497
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    print("shell_module_1: ",shell_module_1)

# Generated at 2022-06-25 11:49:34.718951
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    def mocked_exec_command(self, *args, **kwargs):
        """mocked exec_command for testing mkdtemp method"""
        if 'ansible-tmp' in args[1]:
            stdout = 'c:\\users\\someuser\\AppData\\Local\\Temp\\ansible-tmp-1'
            stderr = ''
            return 0, stdout, stderr
        else:
            stdout = 'c:\\users\\someuser\\AppData\\Local\\Temp\\ansible-tmp-2'
            stderr = ''
            return 0, stdout, stderr

    def mocked_exec_command_undef(*args, **kwargs):
        """mocked exec_command returning undef"""
        raise Exception("exec_command return was undef")


# Generated at 2022-06-25 11:49:39.933650
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    is_trailing_slash = False
    shell_module = ShellModule()
    path = 'C:\\Users\\Administrator\\Desktop\\test'
    is_trailing_slash = shell_module.path_has_trailing_slash(path)

    assert not is_trailing_slash

# Generated at 2022-06-25 11:49:45.449239
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    # Test case for method __str__
    def test_str():
        assert shell_module.__str__() == "ShellModule()"
    test_str()


test_case_0()
test_ShellModule()

# Generated at 2022-06-25 11:49:56.719664
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    options = dict(
        environment=dict(
            ANSIBLE_TEST='1',
            PATH='C:\\ProgramData\\Ansible'
        ),
        remote_tmp='C:\\Users\\UserName\\AppData\\Local\\Temp'
    )

    shell_module_0 = ShellModule(data=None, connection=None, play_context=None)

# Generated at 2022-06-25 11:50:03.065368
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    expected = "Write-Output [System.IO.Path]::GetFullPath([System.IO.Path]::Combine((Get-Location).Path, 'test.tmp'))"

    shell_module_0 = ShellModule()
    s = shell_module_0.mkdtemp()

    # Test that s and expected are equal
    assert s == expected


# Generated at 2022-06-25 11:50:06.898726
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    path = "test\\"
    shell_module_0 = ShellModule()
    ans = shell_module_0.path_has_trailing_slash(path)
    assert ans == True
# test_ShellModule_path_has_trailing_slash()


# Generated at 2022-06-25 11:50:08.820880
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
	shell_module_0 = ShellModule()
	path = u'C:\\Users\\TEMP'
	return_value = shell_module_0.path_has_trailing_slash(path)
	assert return_value == False
	return None


# Generated at 2022-06-25 11:50:15.673499
# Unit test for constructor of class ShellModule
def test_ShellModule():

    temp_shell_module_1 = ShellModule()

    temp_shell_module_2 = ShellModule()

    temp_shell_module_3 = ShellModule()

    temp_shell_module_4 = ShellModule()

    temp_shell_module_5 = ShellModule()

    temp_shell_module_6 = ShellModule()

    temp_shell_module_7 = ShellModule()

    temp_shell_module_8 = ShellModule()

    temp_shell_module_9 = ShellModule()

    temp_shell_module_10 = ShellModule()

    temp_shell_module_11 = ShellModule()

    temp_shell_module_12 = ShellModule()

    temp_shell_module_13 = ShellModule()

    temp_shell_module_14 = ShellModule()

    temp_shell_module_15 = ShellModule()

    temp_shell

# Generated at 2022-06-25 11:50:23.893609
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.__dict__ == {}


# Generated at 2022-06-25 11:50:26.121175
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert_equal(shell_module_0._SHELL_REDIRECT_ALLNULL, u'> $null')



# Generated at 2022-06-25 11:50:28.532188
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("test_ShellModule: constructor")
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:29.747780
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:31.055746
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert isinstance(obj, ShellModule)



# Generated at 2022-06-25 11:50:32.298561
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    test_ShellModule_expand_user_0()


# Generated at 2022-06-25 11:50:35.709452
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(shell_module_0.SHELL_FAMILY is not "powershell")


# Generated at 2022-06-25 11:50:36.946276
# Unit test for constructor of class ShellModule
def test_ShellModule():
    stdout_0 = None
    var_0 = ShellModule()


# Generated at 2022-06-25 11:50:38.499490
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass # TODO: construct ShellModule and verify that it is an instance of ShellModule



# Generated at 2022-06-25 11:50:44.516120
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    user_home_path = "~"
    username = ""
    var_0 = shell_module_0.expand_user(user_home_path, username)

    var_1 = shell_module_0.run(var_0)

    # Check for success
    assert var_1[0] == 0
    # Check for stdout
    assert var_1[1] == "/tmp/test"
    # Check for stderr
    assert var_1[2] == ''


# Generated at 2022-06-25 11:50:50.677798
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp()


# Generated at 2022-06-25 11:51:00.485793
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    # I cannot check for the os.path.basename.  The name of the module is not available.
    # I cannot check for the os.path.dirname.  The name of the module is not available.
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None

# Generated at 2022-06-25 11:51:02.182121
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return shell_module_0


# Generated at 2022-06-25 11:51:12.251786
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    string_0 = shell_module_0.path_has_trailing_slash('a')
    string_1 = shell_module_0.path_has_trailing_slash('ab')
    string_2 = shell_module_0.path_has_trailing_slash('abc')
    string_3 = shell_module_0.path_has_trailing_slash('abcd')
    string_4 = shell_module_0.path_has_trailing_slash('abcde')
    string_5 = shell_module_0.path_has_trailing_slash('z')
    string_6 = shell_module_0.path_has_trailing_slash('zy')
    string_7 = shell_module_0.path_has_trailing_

# Generated at 2022-06-25 11:51:14.381864
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:15.717420
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:51:16.326708
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:18.597773
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:25.684384
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():

    # Setup
    shell_module_0 = ShellModule()
    shell_module_0._IS_WINDOWS = False
    shell_module_0.DEFAULT_EXECUTABLE = '/bin/sh'
    user_home_path_0 = '~'
    var_0 = shell_module_0.expand_user(user_home_path_0)

    # Test actions
    shell_module_0._IS_WINDOWS = True
    user_home_path_1 = '/home/user'
    var_1 = shell_module_0.expand_user(user_home_path_1)

    # Teardown


# Generated at 2022-06-25 11:51:28.581506
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:33.499248
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# Generated at 2022-06-25 11:51:38.088446
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    if not shell_module:
        sys.exit(1)
    sys.exit(0)


# Generated at 2022-06-25 11:51:39.319719
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:51:41.963154
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:43.233279
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test constructor
    shell_module_instance_0 = ShellModule()


# Generated at 2022-06-25 11:51:44.308422
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp()



# Generated at 2022-06-25 11:51:45.195214
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:51:47.541795
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    path_0 = "C:\\temp\\foo"
    res = shell_module_0.path_has_trailing_slash(path_0)
    assert res == False


# Generated at 2022-06-25 11:51:51.676374
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except Exception as exception_0:
        print(exception_0)
    try:
        shell_module_0 = ShellModule(host=host)
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 11:51:57.196732
# Unit test for constructor of class ShellModule
def test_ShellModule():
    instance_0 = ShellModule()
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 11:52:05.079548
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:52:08.953402
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    paths = 'conans'.replace('\'', '')
    # Paths = 'conans'.Replace('\'', '') '
    var_0 = shell_module_0.path_has_trailing_slash(paths)
    assert var_0


# Generated at 2022-06-25 11:52:11.780808
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule.__class__ == type


# Generated at 2022-06-25 11:52:13.117841
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    assert 'Write-Output ((Get-Location).Path + \'/Users/nastra/\')' == ShellModule().expand_user('~/nastra')


# Generated at 2022-06-25 11:52:23.488010
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("Unit test for constructor of class ShellModule")
    shell_module_0 = ShellModule()
    if debug:
        print(shell_module_0.__class__.__name__)
        print(repr(shell_module_0).split('\n')[0])
    assert shell_module_0.__class__.__name__ == "ShellModule"
    assert repr(shell_module_0).split('\n')[0] == "ShellModule(executable='powershell', stdin=None, stdin_add_newline=True, stdout=None, stdout_append=False, stderr=None, stderr_append=False)"
    # Test with positional arguments
    shell_module_1 = ShellModule('powershell', None, True, None, False, None, False)

# Generated at 2022-06-25 11:52:31.576921
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import shutil
    from ansible.modules.system import tempfile
    from ansible.utils.path import unfrackpath
    from tempfile import gettempdir
    from ansible.module_utils.six import string_types

    if os.path.exists('/var/folders/tx/mvp2_4hn4fgdxd1dt0kv5clr0000gn/T/tmpjd0_8l_'):
        shutil.rmtree('/var/folders/tx/mvp2_4hn4fgdxd1dt0kv5clr0000gn/T/tmpjd0_8l_')

    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_option('remote_tmp')

# Generated at 2022-06-25 11:52:34.075663
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj_ShellModule = ShellModule()


# Generated at 2022-06-25 11:52:41.312831
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null', 'Assertion failure on line 25 of test_shell.py'
    assert shell_module_0._IS_WINDOWS == True, 'Assertion failure on line 26 of test_shell.py'
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset(), 'Assertion failure on line 27 of test_shell.py'
    assert shell_module_0._SHELL_AND == ';', 'Assertion failure on line 28 of test_shell.py'
    assert shell_module_0.SHELL_FAMILY == 'powershell', 'Assertion failure on line 29 of test_shell.py'


# Generated at 2022-06-25 11:52:41.977745
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:51.635980
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print("shell_module_0->connection_info: ", shell_module_0.connection_info)
    print("shell_module_0->become: ", shell_module_0.become)
    print("shell_module_0->become_method: ", shell_module_0.become_method)
    print("shell_module_0->become_user: ", shell_module_0.become_user)
    print("shell_module_0->become_pass: ", shell_module_0.become_pass)
    print("shell_module_0->check: ", shell_module_0.check)
    print("shell_module_0->ck_interactive: ", shell_module_0.ck_interactive)

# Generated at 2022-06-25 11:52:59.709294
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    path = 'C:\\windows\\'
    instance = ShellModule()
    # Bool expected = True
    expected = True
    # Bool returned = instance.path_has_trailing_slash(path)
    returned = instance.path_has_trailing_slash(path)
    assert returned == expected


# Generated at 2022-06-25 11:53:03.851276
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Test the method
    shell_module = ShellModule()
    result = shell_module.path_has_trailing_slash('asdf')
    assert result == False
    result = shell_module.path_has_trailing_slash('asdf\\')
    assert result == True
    result = shell_module.path_has_trailing_slash('asdf/')
    assert result == True


# Generated at 2022-06-25 11:53:06.044859
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1._shell_family == "powershell"
    assert shell_module_1._shell_type == "powershell"



# Generated at 2022-06-25 11:53:09.740671
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    temp_0 = shell_module_0


# Generated at 2022-06-25 11:53:11.500701
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0


# Generated at 2022-06-25 11:53:20.184477
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'


# Generated at 2022-06-25 11:53:22.181792
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:26.652540
# Unit test for constructor of class ShellModule
def test_ShellModule():
    unit_test = ShellModule()
    unit_test.join_path()


# Generated at 2022-06-25 11:53:32.701510
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1._encode_script(u"Set-StrictMode -Version Latest\r\n{\r\n    [System.Console]::WriteLine('hello world')\r\n}\r\n") == 'PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand OgBlAHQALQBYAGEAbgBhAGsAIAAoAEwAQQBsAGwAIABDAHUAeABlAGwAbAApAC4ARABvAGMAdQBtAGUAbgB0AA=='


# Generated at 2022-06-25 11:53:34.345531
# Unit test for constructor of class ShellModule
def test_ShellModule():
	pass


# Generated at 2022-06-25 11:53:38.925647
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Call test_case_0()
    test_case_0()


# Generated at 2022-06-25 11:53:43.696154
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash("C:\\test-1")
    assert var_0 is False, "Return value of ShellModule.path_has_trailing_slash() is wrong."
    print("Test case 0 passed")


# Generated at 2022-06-25 11:53:48.928144
# Unit test for constructor of class ShellModule
def test_ShellModule():
    instance0 = ShellModule()
    # Variable to test constructor
    set_attr0 = "test_set_attr0"
    instance0.set_attr0 = set_attr0
    get_attr0 = instance0.get_attr0
    # Verifying if attributes are getting set properly
    if (set_attr0 == get_attr0):
        # nothing to do
        return
    # if the condition fails the test case will fail
    raise Exception("Test case 0 failed")


# Generated at 2022-06-25 11:53:50.049723
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:53.337294
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():


  # Input Parameters:

  #   user_home_path:  The user home path to expand.

  #   username:  The username to match.

  # Expected Return Value:

  #   A string or None. None if the return value is not expected to be changed.


  # Nothing to do here.

  return None


# Generated at 2022-06-25 11:53:57.138741
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    arg_0 = ""
    var_0 = shell_module_0.path_has_trailing_slash(arg_0)
    assert var_0 == False


# Generated at 2022-06-25 11:53:59.785270
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:01.658202
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Testing if the constructor raises a TypeError when invoked with no argument
    try:
        ShellModule()
    except TypeError:
        pass


# Generated at 2022-06-25 11:54:03.595169
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create instance of class ShellModule
    shell_module = ShellModule()
    # Check if instantiation successful
    assert shell_module


# Generated at 2022-06-25 11:54:05.374785
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = check_pathhas_trailing_slash(shell_module_0)


# Generated at 2022-06-25 11:54:13.722884
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert obj._SHELL_AND == ';'
    assert obj._SHELL_REDIRECT_ALLNULL == '> $null'
    assert obj.COMPATIBLE_SHELLS == frozenset()
    assert obj.SHELL_FAMILY == 'powershell'
    assert obj._IS_WINDOWS == True


# Generated at 2022-06-25 11:54:20.253050
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    myobj_0 = ShellModule()
    path_0 = 'C:\\Program Files\\'
    output = myobj_0.path_has_trailing_slash(path_0) # Return value of shell_has_trailing_slash
    assert output


# Generated at 2022-06-25 11:54:24.865170
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_0 = ntpath.join(os.path.expanduser('~'), 'some', 'path')
    var_1 = shell_module_0.expand_user(var_0)
    var_2 = shell_module_0.expand_user('~')


# Generated at 2022-06-25 11:54:32.345389
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    method_list = [('expand_user')]
    test_list_methods = []
    for i in range(0, len(method_list)):
        method_name = method_list[i]
        test_list_methods.append(method_name)
    shell_module_0 = ShellModule()
    if ('expand_user' in test_list_methods):
        var_0 = shell_module_0.expand_user('~')
        var_1 = shell_module_0.expand_user('~\\')


# Generated at 2022-06-25 11:54:33.455101
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(shell_module_0 is not None)



# Generated at 2022-06-25 11:54:41.104935
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    assert shell_module_0._unquote("sdfsdfsdfsdf") == "sdfsdfsdfsdf"
    assert shell_module_0._unquote("C:\\Users\\local_admin\\AppData\\Local\\Temp\\ansible-tmp-1560362279.7609603-12022-4143624741560362279.76-580") == "C:\\Users\\local_admin\\AppData\\Local\\Temp\\ansible-tmp-1560362279.7609603-12022-4143624741560362279.76-580"


# Generated at 2022-06-25 11:54:43.439468
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule('array', 'stderr', 'args')
    assert shell_module_1!=None, "Constructor of ShellModule is broken"


# Generated at 2022-06-25 11:54:45.273488
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)
    assert isinstance(shell_module_0, ShellBase)


# Generated at 2022-06-25 11:54:57.143688
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellmodule_0 = ShellModule()
    var_0 = shellmodule_0.get_option()
    assert var_0 == '-NoProfile'
    shellmodule_1 = ShellModule(preserve_rc=True)
    var_1 = shellmodule_1.get_option()
    assert var_1 == '-NoProfile'
    var_2 = shellmodule_1.get_option()
    assert var_2 == '-NoProfile'
    shellmodule_2 = ShellModule(encoding='utf-16-le')
    var_3 = shellmodule_2.get_option()
    assert var_3 == '-NoProfile'
    var_4 = shellmodule_2.get_option()
    assert var_4 == '-NoProfile'

# Generated at 2022-06-25 11:55:03.087716
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import os
    from ansible.module_utils.six.moves.shutil import which
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    builtins.open = open

    shell_module_0 = ShellModule()
    path_0 = os.getcwd()
    var_0 = shell_module_0.expand_user(path_0)
    assert var_0 == "$env:LANG='en_US.UTF-8';$env:LC_CTYPE='en_US.UTF-8';"

    shell_module_0 = ShellModule()
    path_0 = '~'
    var_0 = shell_module_0.expand_user(path_0)

# Generated at 2022-06-25 11:55:09.068675
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print(ShellModule())


# Generated at 2022-06-25 11:55:09.880181
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:10.868802
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:55:11.848946
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:55:13.897859
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:15.209374
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:55:17.606821
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return shell_module_0

# Generated at 2022-06-25 11:55:19.024884
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None



# Generated at 2022-06-25 11:55:20.108958
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO: Write unit tests for constructor of class ShellModule
    pass


# Generated at 2022-06-25 11:55:21.074266
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:30.672674
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = ntpath.join('$env:SystemRoot', 'system32', 'WindowsPowerShell', 'v1.0', 'Modules')
    var_1 = shell_module_0.path_has_trailing_slash(var_0)
    assert var_1 is False, 'Unexpected value for argument var_1'
    var_2 = ntpath.join('$env:SystemRoot', 'system32', 'WindowsPowerShell', 'v1.0', 'Modules', '')
    var_3 = shell_module_0.path_has_trailing_slash(var_2)
    assert var_3 is True, 'Unexpected value for argument var_3'


# Generated at 2022-06-25 11:55:33.319718
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Argument initialized to []
    arg_0 = []
    # Argument initialized to None
    arg_1 = None
    shell_module_1 = ShellModule(arg_0, arg_1)


# Generated at 2022-06-25 11:55:34.839070
# Unit test for constructor of class ShellModule
def test_ShellModule():
    my_shell_module = ShellModule()


# Generated at 2022-06-25 11:55:37.434879
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Call the constructor of the class to create a object of ShellModule, assing it to a variable and test the output
    shellModule = ShellModule()
    assert shellModule is not None, 'Unable to create object of ShellModule()'
    assert shellModule._SHELL_REDIRECT_ALLNULL == '> $null', 'Unexpected value for global _SHELL_REDIRECT_ALLNULL'


# Generated at 2022-06-25 11:55:39.512922
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Asserting the constructor returns a ShellModule object
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)


# Generated at 2022-06-25 11:55:46.874093
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Test case for path_has_trailing_slash() method
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash('E:\\dev\\ansible-test-cases\\test\\integration\\targets\\win_async\\plugins\\modules')
    assert var_0 == False


# Generated at 2022-06-25 11:55:49.139045
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("test_ShellModule()")

    shell_module_0 = ShellModule()
    print(shell_module_0)


# Generated at 2022-06-25 11:55:58.908924
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0._SHELL_REDIRECT_ALLNULL = str()
    shell_module_0._SHELL_AND = str()
    shell_module_0._IS_WINDOWS = bool()
    shell_module_0.env_prefix()
    shell_module_0.join_path()
    shell_module_0.get_remote_filename()
    shell_module_0.path_has_trailing_slash()
    shell_module_0.chmod()
    shell_module_0.chown()
    shell_module_0.set_user_facl()
    shell_module_0.remove()
    shell_module_0.mkdtemp()
    shell_module_0.expand_user()
    shell_module_0.exists()


# Generated at 2022-06-25 11:56:09.767310
# Unit test for constructor of class ShellModule
def test_ShellModule():
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
    variable_0 = ShellModule()
   

# Generated at 2022-06-25 11:56:11.128998
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:19.525149
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    shell_module_1.DEFAULT_EXECUTABLE = shell_module_0.DEFAULT_EXECUTABLE
    shell_module_1.COMPATIBLE_SHELLS = shell_module_0.COMPATIBLE_SHELLS
    shell_module_1.SHELL_FAMILY = shell_module_0.SHELL_FAMILY
    var_1 = shell_module_1.__class__
    shell_module_1.__init__()
    shell_module_1.ENV_PREFIX = shell_module_0.ENV_PREFIX


# Generated at 2022-06-25 11:56:22.294111
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS
    assert shell_module.env_prefix() == ''


# Generated at 2022-06-25 11:56:26.549747
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except AnsiException:
        return 1
    except:
        return 2

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:56:27.733415
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert True


# Generated at 2022-06-25 11:56:30.123243
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # shell_module_0 = ShellModule()
    # assert(shell_module_0.get_remote_filename() == 'example_0.ps1')
    # assert(shell_module_0 == 'example_0.ps1')
    assert True


# Generated at 2022-06-25 11:56:36.068081
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Init
    shell_module_0 = ShellModule()
    env_string_1 = 'ENV_STRING'
    shebang_1 = 'BANSHEE'
    cmd_1 = 'COMMAND'
    arg_path = 'ARG_PATH'

    # Mocking
    test_build_module_command_mock = MagicMock()
    test_build_module_command_mock.build_module_command = MagicMock()
    expected_result = test_build_module_command_mock.build_module_command(env_string_1, shebang_1, cmd_1, arg_path)
    shell_module_0.build_module_command = test_build_module_command_mock.build_module_command

# Generated at 2022-06-25 11:56:45.924980
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    host = ShellModule()
    host.noop_on_check(host.path_has_trailing_slash('/home/user/'))
    host.noop_on_check(host.path_has_trailing_slash('/home/user'))
    host.noop_on_check(not host.path_has_trailing_slash('/home/user/'))
    host.noop_on_check(host.path_has_trailing_slash('C:/Program Files/'))
    host.noop_on_check(host.path_has_trailing_slash('C:/Program Files'))
    host.noop_on_check(not host.path_has_trailing_slash('C:/Program Files/'))

# Generated at 2022-06-25 11:56:48.019258
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:49.369900
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp()


# Generated at 2022-06-25 11:56:50.400744
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule() # Default constructor call

# Generated at 2022-06-25 11:57:05.413579
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule(None, None, None)
    shell_module_2 = ShellModule(shell_mkdtemp(), shell_connect('localhost'), None)
    shell_module_3 = ShellModule(shell_mkdtemp(), shell_connect('localhost'), 'ansible_host')
    shell_module_4 = ShellModule(shell_mkdtemp(), shell_connect('localhost'), 'ansible_host', 'user')
    shell_module_5 = ShellModule(shell_mkdtemp(), shell_connect('localhost'), 'ansible_host', 'user', 'passwd')
    shell_exec("pwd")
    shell_exec("pwd", False, False)
    shell_exec("pwd", False, True)
    shell_exec("pwd", True, False)
   

# Generated at 2022-06-25 11:57:06.404457
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp()

# Generated at 2022-06-25 11:57:07.902738
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:57:15.091056
# Unit test for constructor of class ShellModule
def test_ShellModule():

    print("generate temp dir name = " + ShellModule._generate_temp_dir_name())

    cmd = 'echo "Hello World!"'

    shell = ShellModule()
    script = shell.build_module_command('', '', cmd, '')

    assert script == '& echo "Hello World!"; exit $LASTEXITCODE'



# Generated at 2022-06-25 11:57:16.673713
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.build_module_command("", "#!/bin/bash", "ping", "")


# Generated at 2022-06-25 11:57:17.386149
# Unit test for constructor of class ShellModule
def test_ShellModule():
    v_0 = ShellModule()


# Generated at 2022-06-25 11:57:24.573066
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset([])
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS
    assert shell_module_0.env_prefix() == ''
    assert shell_module_0.join_path('C:\\Program Files', 'slide') == 'C:\\Program Files\\slide'
    assert shell_module_0.get_remote_filename('hello.txt') == 'hello.txt'
    assert shell_module_0.path_has_trailing_slash('C:\\Program Files\\slide\\')
    assert not shell_module_0.path_has_trailing_slash('C:\\Program Files\\slide')
   

# Generated at 2022-06-25 11:57:25.433218
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:57:26.092527
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:57:28.369207
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:57:39.752545
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    test_case_0()
    assert len(shell_module_0.args) == 6

# Test for get_remote_filename

# Generated at 2022-06-25 11:57:44.140388
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)



# Generated at 2022-06-25 11:57:49.722622
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp()


if __name__ in '__main__':
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp()

# Generated at 2022-06-25 11:57:52.792271
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:57:54.511746
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, object)
    assert isinstance(shell_module, ShellBase)
