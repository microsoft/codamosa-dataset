

# Generated at 2022-06-25 11:48:11.862915
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()

    user_home_path_0 = '~'
    # User home path ~ should get substituted with path from environment variable USERPROFILE
    USERPROFILE = os.environ.get('USERPROFILE')
    if USERPROFILE is not None:
        expected_result_0 = USERPROFILE
    else:
        expected_result_0 = 'C:\\Users\\'
    # In the case of using USERPROFILE as the path to use for home directory, the trailing slash gets dropped
    expected_result_0 = expected_result_0[:-1]
    result_0 = shell_module_0.expand_user(user_home_path_0)

# Generated at 2022-06-25 11:48:17.659900
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS == True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:48:20.188684
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    if not shell_module_1:
        raise AssertionError("ShellModule object creation failed")


# Generated at 2022-06-25 11:48:29.331976
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:48:36.578051
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    shell_module_0 = ShellModule()

    # Test with env_string: '' (empty string), shebang: '#!powershell' and cmd: '"echo hi"'

    actual_cmd = shell_module_0.build_module_command(env_string='', shebang='#!powershell', cmd='"echo hi"')


# Generated at 2022-06-25 11:48:45.750956
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    shebang = '#!powershell'
    env_string = '$env:ANSIBLE_MODULE_ARGS="{\\"ANSIBLE_MODULE_ARGS\\": null}"'
    cmd = 'Test-Module -ArgumentList module_arguments'
    output = shell_module.build_module_command(env_string, shebang, cmd, arg_path=None)
    expected_output = '$env:ANSIBLE_MODULE_ARGS="{\\"ANSIBLE_MODULE_ARGS\\": null}"; & "Test-Module.ps1" -ArgumentList module_arguments; exit $LASTEXITCODE'
    assert output == expected_output


# Generated at 2022-06-25 11:48:56.229414
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shellModule1 = ShellModule();
    result = shellModule1.mkdtemp();

# Generated at 2022-06-25 11:49:06.989116
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    # Test with no shebang
    shell_module_1 = ShellModule()
    env_string = 'y=5 x=10'
    shebang = None
    cmd = 'echo "I am here"'
    result = shell_module_1.build_module_command(env_string, shebang, cmd)

# Generated at 2022-06-25 11:49:07.898424
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:49:11.817648
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    assert shell_module_0.path_has_trailing_slash(path='/etc') == False
    assert shell_module_0.path_has_trailing_slash(path='c:/windows\\') == True
    assert shell_module_0.path_has_trailing_slash(path='/etc/') == True



# Generated at 2022-06-25 11:49:16.477290
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    assert shell_module_0.mkdtemp()


# Generated at 2022-06-25 11:49:18.461537
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    data = shell_module_0.mkdtemp()
    # assert that data is of type bytes
    assert (isinstance(data, bytes))


# Generated at 2022-06-25 11:49:21.105074
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
    except Exception as e:
        print('FAILED: test_ShellModule()')
        raise e

test_ShellModule()

# Generated at 2022-06-25 11:49:27.225207
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_1 = ShellModule()
    assert shell_module_1.get_remote_filename(pathname = "/tmp/file.tmp") == "file.tmp"
    assert shell_module_1.get_remote_filename(pathname = "/tmp/file") == "file.ps1"
    assert shell_module_1.get_remote_filename(pathname = "/tmp/file.exe") == "file.exe"


# Generated at 2022-06-25 11:49:36.875081
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    # Positive test case
    tmpdir = "C:\\Users\\Administrator\\AppData\\Local\\Temp"
    basefile = 'test-7'
    script = shell_module_0.mkdtemp(basefile=basefile, tmpdir=tmpdir)
    # Negative test case
    tmpdir = "C:\\Users\\Administrator\\AppData\\Local\\Temp"
    basefile = 'test-25'
    script = shell_module_0.mkdtemp(basefile=basefile, tmpdir=tmpdir)
    # Negative test case
    tmpdir = "C:\\Users\\Administrator\\AppData\\Local\\Temp"
    basefile = 'test-34'
    script = shell_module_0.mkdtemp(basefile=basefile, tmpdir=tmpdir)

#

# Generated at 2022-06-25 11:49:45.783421
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_1 = ShellModule()
    basetmpdir = "C:/Users/test/ansible"
    basefile = "ansible_test"
    assert shell_module_1.mkdtemp(basefile="ansible_test", tmpdir="C:/Users/test/ansible") == b'''\r\n$tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:/Users/test/ansible')\r\n$tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible_test'\r\nWrite-Output -InputObject $tmp.FullName\r\n'''



# Generated at 2022-06-25 11:49:49.293440
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1._SHELL_REDIRECT_ALLNULL == '> $null'


# Generated at 2022-06-25 11:49:56.431175
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    assert shell_module_0.mkdtemp() == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name '%s'
        Write-Output -InputObject $tmp.FullName
        ''' % (shell_module_0.get_option('remote_tmp'), shell_module_0.__class__._generate_temp_dir_name())


# Generated at 2022-06-25 11:49:57.363147
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert(issubclass(ShellModule, ShellBase))
    assert(ShellModule() != None)



# Generated at 2022-06-25 11:50:09.140459
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    script = shell_module_0.build_module_command("""
                Set-Location 'C:\\users\\Public'
                """, '', '', 'C:\\users\\Public')
    assert script
    script = shell_module_0.join_path('C:\\users', 'Public')
    assert script == 'C:\\users\\Public'
    script = shell_module_0.join_path('C:\\users', 'Public', '')
    assert script == 'C:\\users\\Public'
    script = shell_module_0.join_path('C:\\users', 'Public\\')
    assert script == 'C:\\users\\Public'
    script = shell_module_0.join_path('C:\\users/', '/Public/')

# Generated at 2022-06-25 11:50:13.112367
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert shell_module_0


# Generated at 2022-06-25 11:50:16.858450
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()
    print('ShellModule.py: all tests OK')

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:50:23.825877
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    env_string = ''
    shebang = '#!Powershell'
    cmd = 'win_command'

    # assert that powershell modules are wrapped in the bootstrap wrapper

# Generated at 2022-06-25 11:50:25.728657
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# Unit test run when this file is called directly
if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:50:29.121108
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_plugin = ShellModule()
    test_str = shell_plugin.mkdtemp()
    assert isinstance(test_str, str)


# Generated at 2022-06-25 11:50:31.745022
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    check_value(shell_module._SHELL_REDIRECT_ALLNULL, '> $null')
    check_value(shell_module._SHELL_AND, ';')
    check_value(shell_module._IS_WINDOWS, True)


# Generated at 2022-06-25 11:50:42.115293
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    tmp_path = '/tmp/ansible-tmp-1559652433.45-141686097469069'
    base_file = 'tmp_kYEdgZ'
    var_return_value = None
    var_return_value = shell_module_0.mkdtemp(base_file, system=False, mode=None, tmpdir=tmp_path)

# Generated at 2022-06-25 11:50:43.003603
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:50:44.153046
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:50:46.636871
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-25 11:50:54.576724
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print(ShellModule())

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:51:03.884747
# Unit test for constructor of class ShellModule
def test_ShellModule():
    args = dict()
    args['args'] = dict()
    args['args']['module_name'] = 'shell_module'
    args['args']['module_args'] = dict()
    args['args']['module_args']['can_substitute'] = False
    args['args']['module_args']['cmd'] = 'shell_cmd'
    args['args']['module_args']['chdir'] = '/tmp'
    args['args']['module_args']['creates'] = '/usr/bin'
    args['args']['module_args']['executable'] = '/usr/bin/shell'
    args['args']['module_args']['removes'] = '/etc/shell.conf'

# Generated at 2022-06-25 11:51:06.774949
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print("Unit test for constructor of class ShellModule")
    print("Object instance of ShellModule class is ", shell_module_0)


# Generated at 2022-06-25 11:51:12.981509
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.expand_user('~/test.txt')
    print('first: %s' % var_0)
    var_1 = shell_module_0.expand_user('~/dev/test.txt')
    print('second: %s' % var_1)
    var_2 = shell_module_0.expand_user('~/../test.txt')
    print('third: %s' % var_2)


# Generated at 2022-06-25 11:51:14.450954
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_execute()
    return None


# Generated at 2022-06-25 11:51:15.718267
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:23.538018
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:51:30.378778
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()

    # Should be the first test to clear environment variables
    shell_module_1.env_prefix()

    shell_module_1.join_path()
    shell_module_1.get_remote_filename()
    shell_module_1.path_has_trailing_slash()
    shell_module_1.chmod()
    shell_module_1.chown()
    shell_module_1.set_user_facl()
    shell_module_1.remove()
    shell_module_1.mkdtemp()
    shell_module_1.expand_user()
    shell_module_1.exists()
    shell_module_1.checksum()
    shell_module_1.build_module_command()
    shell_module_1.wrap_for_exec

# Generated at 2022-06-25 11:51:33.368975
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:43.710703
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # 'null' is not a PowerShell script name.
    # Should raise a ValueError
    try:
        shell_module_0.get_remote_filename('null')
    except ValueError as exception_0:
        if exception_0.args[0] == 'null is not a PowerShell script name':
            pass
        else:
            raise

    # 'null' is not a PowerShell script name.
    # Should raise a ValueError
    try:
        shell_module_0.get_remote_filename('null')
    except ValueError as exception_0:
        if exception_0.args[0] == 'null is not a PowerShell script name':
            pass
        else:
            raise



# Generated at 2022-06-25 11:51:49.930886
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print( "Test ShellModule::__init__()")


# Generated at 2022-06-25 11:51:51.117240
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = powershell
    p.__name__ = 'powershell'
    assert p.__name__ == 'powershell'

# Generated at 2022-06-25 11:51:57.001755
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Initialize shell module with parameters
    shell_module_1 = ShellModule()
    assert shell_module_1.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-25 11:51:57.845700
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()


# Generated at 2022-06-25 11:52:01.986010
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    user_home_path_0 = '~'
    username_0 = 'Administrator'
    shell_module_0 = ShellModule()
    script_0 = shell_module_0.expand_user(user_home_path_0, username_0)
    print(script_0)

if __name__ == "__main__":
    test_case_0()
    test_ShellModule_expand_user()

# Generated at 2022-06-25 11:52:11.727660
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test cases:
    # case 0:
    #   object = ShellModule()
    #   assert shell_module.plugin_class == 'powershell'
    #   assert shell_module.plugin_name == 'powershell'
    #   assert shell_module.SHELL_FAMILY == 'powershell'
    # case 1:
    #   object = ShellModule()
    #   assert shell_module.plugin_class == 'powershell'
    #   assert shell_module.plugin_name == 'powershell'
    #   assert shell_module.SHELL_FAMILY == 'powershell'
    assert True


# Generated at 2022-06-25 11:52:20.474247
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    # Test 1 of 2
    try:
        var_0 = shell_module_0.expand_user(' /home/user1')
    except NotImplementedError:
        var_0 = "NotImplementedError"
    assert var_0 == "NotImplementedError"
    # Test 2 of 2
    try:
        var_1 = shell_module_0.expand_user('/home/user1')
    except NotImplementedError:
        var_1 = "NotImplementedError"
    assert var_1 == "NotImplementedError"


# Generated at 2022-06-25 11:52:24.278317
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:29.999245
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.plugins.shell import psrp

    c = psrp.ShellModule()
    assert c.expand_user("~") == c._encode_script("Write-Output (Get-Location).Path")
    assert c.expand_user("~\\path") == c._encode_script("Write-Output ((Get-Location).Path + '\\path')")
    assert c.expand_user("/path") == c._encode_script("Write-Output '/path'")


# Generated at 2022-06-25 11:52:31.112858
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:41.706477
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None
    assert isinstance(shell_module_1, ShellModule)
    assert pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1") is not None
    var_1 = shell_module_1._encode_script("script", as_list=False, strict_mode=True, preserve_rc=True)
    var_2 = shell_module_1.build_module_command("env_string", "shebang", "cmd", arg_path='arg_path')
    var_3 = shell_module_1.checksum("path", recurse=True)
    var_4 = shell_module_1.chmod("paths", mode=1)
    var_5 = shell_module_1._escape

# Generated at 2022-06-25 11:52:47.526940
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # The constructor for the ShellModule class is a part of the
    # generated code.  It is not called directly.  It is called
    # indirectly when an object of the class ShellModule is created.
    # The following test code is not generated.

    shell_module_0 = ShellModule()
    # TODO: Add test code here.
    pytest.raises(NotImplementedError, "shell_module_0.chmod('.', '.')")
    pytest.raises(NotImplementedError, "shell_module_0.chown('.', '.')")
    pytest.raises(NotImplementedError, "shell_module_0.set_user_facl('.', '.', '.')")


# Generated at 2022-06-25 11:52:52.931292
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._checksum_filenames == [u'pipeline']
    assert shell_module_0._no_log_strings == [u'(?i)pass(?-i)', u'(?i)password(?-i)', u'pw']


# Generated at 2022-06-25 11:52:54.930704
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.build_module_command()


# Generated at 2022-06-25 11:52:56.949291
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:57.894078
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()



# Generated at 2022-06-25 11:52:58.931424
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:53:03.141244
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

    assert shell_module_0 is not None


# Generated at 2022-06-25 11:53:09.529202
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Unit test for constructor of class ShellModule():
    shell_module_0 = ShellModule()
    # Unit test for shell_join_path()
    test_case_0()

    # Test for method _unquote(self, value)
    shell_module_0._unquote('/tmp/ansible_qg4hYY/ansible_module_win_copy.ps1')

    # Test for method _escape(self, value)
    shell_module_0._escape('/tmp/ansible_qg4hYY/ansible_module_win_copy.ps1')

    # Test for method _encode_script(self, script, as_list=False, strict_mode=True, preserve_rc=True)

# Generated at 2022-06-25 11:53:11.922820
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.build_module_command("", "", "", "")


# Generated at 2022-06-25 11:53:19.354260
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():

    # Setup the mock environment
    module = MagicMock()
    module.params = PARAMS_FOR_PRESENT

    # Construct the object that will be called
    shell_module_0 = ShellModule()

    # Call the method with the appropriate parameters
    shell_module_0.path_has_trailing_slash(module)

# Generated at 2022-06-25 11:53:21.890023
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # The constructor of ShellModule
    shell_module_0 = ShellModule()
    print("Expected result: ShellModule, Actual result: " + str(type(shell_module_0)))


# Generated at 2022-06-25 11:53:26.791558
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 != "", "ShellModule not initialized correctly"


# Generated at 2022-06-25 11:53:28.663840
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash()


# Generated at 2022-06-25 11:53:34.853420
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    path_0 = "a"
    var_0 = shell_module_0.path_has_trailing_slash(path_0)



# Generated at 2022-06-25 11:53:36.722356
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_1 = ShellModule()
    except Exception as e:
        print('Exception thrown: ' + str(e))


# Generated at 2022-06-25 11:53:42.395684
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert type(shell_module_0.COMPATIBLE_SHELLS) == frozenset
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert type(shell_module_0._IS_WINDOWS) == bool


# Generated at 2022-06-25 11:53:44.012079
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:53:52.134808
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    # Use a predictable set of paths to test with
    # Paths that should return True
    path_list = [
        'C:\\LastFolder\\',
        'C:\\LastFolder\\ ',
        'C:\\LastFolder\\\t',
        'C:\\LastFolder\\\n',
        'C:\\LastFolder\\\r',
        'C:\\LastFolder\\\\',
        'C:\\LastFolder\\\\ ',
        'C:\\LastFolder\\\\\t',
        'C:\\LastFolder\\\\\n',
        'C:\\LastFolder\\\\\r',
    ]

# Generated at 2022-06-25 11:54:02.631818
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    path_1 = "/var/tmp/"
    path_2 = ""
    path_3 = "\\windows"
    path_4 = "linux"
    path_5 = "C:\\windows\\"
    path_6 = "/"
    assert shell_module_0.path_has_trailing_slash(path_1), "'%s' does not have a trailing slash" % path_1
    assert not shell_module_0.path_has_trailing_slash(path_2), "'%s' has a trailing slash" % path_2
    assert not shell_module_0.path_has_trailing_slash(path_3), "'%s' has a trailing slash" % path_3
    assert not shell_module_0.path_has_trailing_slash

# Generated at 2022-06-25 11:54:07.377180
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:14.159138
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0._SHELL_AND

    var_1 = shell_module_0.COMPATIBLE_SHELLS

    var_2 = shell_module_0._SHELL_REDIRECT_ALLNULL

    var_3 = shell_module_0._IS_WINDOWS

    var_4 = shell_module_0.SHELL_FAMILY


# Generated at 2022-06-25 11:54:17.185068
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()



# Generated at 2022-06-25 11:54:22.036804
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.get_option('remote_tmp') == 'c:\\windows\\temp'
    assert sm.get_option('remote_filesystem') == 'Win32_LogicalFileSecuritySetting'

# Generated at 2022-06-25 11:54:23.084676
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module._IS_WINDOWS == True

# Generated at 2022-06-25 11:54:26.561042
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Assertions
    assert isinstance(shell_module_0, ShellModule) == True
    print("Test 1: ShellModule() constructor test - completed successfully")


# Generated at 2022-06-25 11:54:28.111167
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(isinstance(shell_module_0, ShellModule))



# Generated at 2022-06-25 11:54:33.989464
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename()
    var_1 = shell_module_0.chmod()
    var_2 = shell_module_0.chown()
    var_3 = shell_module_0.set_user_facl()
    var_4 = shell_module_0.remove()
    var_5 = shell_module_0.mkdtemp()
    var_6 = shell_module_0.expand_user()
    var_7 = shell_module_0.exists()
    var_8 = shell_module_0.checksum()
    var_9 = shell_module_0.build_module_command()
    var_10 = shell_module_0.wrap_for_exec()
    var_11 = shell_module

# Generated at 2022-06-25 11:54:40.215056
# Unit test for constructor of class ShellModule
def test_ShellModule():
    my_shell = ShellModule()
    assert(my_shell.SHELL_FAMILY == 'powershell')
    assert(my_shell.COMPATIBLE_SHELLS == frozenset())
    assert(my_shell._IS_WINDOWS == True)
    assert(my_shell._SHELL_AND == ';')
    assert(my_shell._SHELL_REDIRECT_ALLNULL == '> $null')


# Generated at 2022-06-25 11:54:46.375022
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert_equals(shell_module_0._SHELL_REDIRECT_ALLNULL, '> $null')
    assert_equals(shell_module_0.SHELL_FAMILY, 'powershell')
    assert_equals(shell_module_0._SHELL_AND, ';')
    assert_equals(shell_module_0._IS_WINDOWS, True)



# Generated at 2022-06-25 11:54:57.131260
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0


# Generated at 2022-06-25 11:55:04.741699
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create an instance of ShellModule
    shell_module_0 = ShellModule()
    # Verify the type of the created object
    assert isinstance(shell_module_0, ShellModule, 'Expected instance of class ShellModule')
    # Verify the attr_name 'join_path' of the created object
    assert shell_module_0.join_path == shell_join_path, 'Expected value shell_join_path'
    # Verify the attr_name 'get_remote_filename' of the created object
    assert shell_module_0.get_remote_filename == get_remote_filename, 'Expected value get_remote_filename'
    # Verify the attr_name 'path_has_trailing_slash' of the created object
    assert shell_module_0.path_has_trailing_slash == path_has_tra

# Generated at 2022-06-25 11:55:16.962117
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename()
    var_1 = shell_module_0.expand_user()
    var_2 = shell_module_0.env_prefix()
    var_3 = shell_module_0.env_prefix()
    var_4 = shell_module_0._unquote()
    var_5 = shell_module_0._escape()
    var_6 = shell_module_0._encode_script()
    var_7 = shell_module_0._encode_script()
    var_8 = shell_module_0.wrap_for_exec()
    var_9 = shell_module_0.checksum()
    var_10 = shell_module_0.chmod()
    var_11 = shell_module_0

# Generated at 2022-06-25 11:55:21.611531
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:33.620643
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.SHELL_FAMILY
    with raises(NotImplementedError):
        shell_module_0.chmod(paths=None, mode=None)
    with raises(NotImplementedError):
        shell_module_0.chown(paths=None, user=None)
    with raises(NotImplementedError):
        shell_module_0.set_user_facl(paths=None, user=None, mode=None)
    shell_module_0.remove(path=None, recurse=False)
    shell_module_0.mkdtemp(basefile=None, system=False, mode=None, tmpdir=None)
    shell_module_0.expand_user(user_home_path=None, username='')

# Generated at 2022-06-25 11:55:34.724247
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Calling constructor of class ShellModule
    shell_module = ShellModule()


# Generated at 2022-06-25 11:55:41.507699
# Unit test for constructor of class ShellModule
def test_ShellModule():

    assert ShellModule.__doc__ == '''
    Base class for all shell plugins.  This implements common methods
    that are generally useful to all shells, plugins which require
    functionality not implemented here should override plugins where possible.
    '''

    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert ShellModule._IS_WINDOWS == True
    assert ShellModule.__name__ == 'ShellModule'
    assert ShellModule.__module__ == 'ansible.plugins.shell.powershell'
    assert ShellModule.__class__ == _ShellModule.ShellModule

    x = ShellModule()



# Generated at 2022-06-25 11:55:50.097463
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:55:59.542313
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    env_string_0 = ''
    shebang_0 = '#!powershell'
    cmd_0 = '"type C:\\Users\\Administrator\\ansible\\.tmp\\ansible-tmp-1531045105.1-27223899573505\\AnsiballZ_time.ps1 | Invoke-Expression"'
    arg_path_0 = None
    shell_module_0.check_for_control_characters = check_for_control_characters_0
    shell_module_0._encode_script = _encode_script_0

# Generated at 2022-06-25 11:56:04.280127
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:25.621515
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None, "ShellModule() with default arguments should return an instance of ShellModule"


# Generated at 2022-06-25 11:56:26.858686
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_case_0 = ShellModule()


# Generated at 2022-06-25 11:56:28.948181
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None


# Generated at 2022-06-25 11:56:30.768511
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    if (shell_module_0 is not shell_module_1):
        print("False")
    else:
        print("True")


# Generated at 2022-06-25 11:56:31.755399
# Unit test for constructor of class ShellModule
def test_ShellModule():
    _shell_module = ShellModule()
    assert _shell_module is not None


# Generated at 2022-06-25 11:56:33.476432
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
        var_0 = shell_join_path()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# Generated at 2022-06-25 11:56:35.441793
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:56:39.454328
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:56:46.698526
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.env_prefix()
    var_1 = shell_module_0._encode_script("", )
    var_2 = shell_module_0.join_path("")
    cmd_1 = shell_module_0.exists("")
    var_3 = shell_module_0.get_option("")
    var_4 = shell_module_0.checksum("")
    var_5 = shell_module_0.build_module_command("", "", "")
    cmd_2 = shell_module_0.wrap_for_exec("")
    var_6 = shell_module_0.get_remote_filename("")

# test for repls should be implemented



# Generated at 2022-06-25 11:56:48.745672
# Unit test for constructor of class ShellModule
def test_ShellModule():
    var_0 = ShellModule()
    assert isinstance(var_0, ShellModule)


# Generated at 2022-06-25 11:57:24.130327
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Testing the constructor
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == {}
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell._SHELL_AND == ';'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-25 11:57:24.770127
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:57:34.780581
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.powershell.common import ShellModule
    __tracebackhide__ = True
    shell_module = ShellModule()
# test for instance attribute 'COMPATIBLE_SHELLS' of class 'ShellModule'

    assert shell_module.COMPATIBLE_SHELLS == frozenset()
# test for instance attribute 'SHELL_FAMILY' of class 'ShellModule'

    assert shell_module.SHELL_FAMILY == 'powershell'
# test for instance attribute '_IS_WINDOWS' of class 'ShellModule'

    assert shell_module._IS_WINDOWS == True

# test for method 'env_prefix' of class 'ShellModule'
_env_prefix_parameters_0 = {'kwargs': {}}


# Generated at 2022-06-25 11:57:38.266388
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:57:42.151185
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellModule = ShellModule()
    if shellModule == None:
        raise Exception("Constructor of class ShellModule is not working")


# Generated at 2022-06-25 11:57:44.755069
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.env_prefix()
    assert var_0 == '', 'Expected values to be equal.'


# Generated at 2022-06-25 11:57:49.254431
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)


# Generated at 2022-06-25 11:57:50.166435
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()

# Generated at 2022-06-25 11:57:53.392101
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:57:55.244357
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # assert expected values
    assert shell_module_0
    assert isinstance(shell_module_0, ShellModule)
