

# Generated at 2022-06-25 11:48:07.447159
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:48:11.696603
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    # Test case with positive result
    assert shell_module_0.path_has_trailing_slash("C:\\Windows") == False
    # Test case with negative result
    assert shell_module_0.path_has_trailing_slash("C:\\Windows\\") == True


# Generated at 2022-06-25 11:48:15.030703
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("### test_ShellModule ###")
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:48:20.099615
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    shell_module_0 = ShellModule()
    shebang = ''
    cmd = 'command_0'
    result = shell_module_0.build_module_command('env_string_0', shebang, cmd)

    assert result is not None



# Generated at 2022-06-25 11:48:23.752110
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'


# Generated at 2022-06-25 11:48:25.035087
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:48:29.984902
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    assert shell_module_0.get_remote_filename("powershell.py") == "powershell.py"
    assert shell_module_0.get_remote_filename("powershell.ps1") == "powershell.ps1"
    assert shell_module_0.get_remote_filename("powershell.sh") == "powershell.sh.ps1"
    assert shell_module_0.get_remote_filename("powershell.exe") == "powershell.exe"
    assert shell_module_0.get_remote_filename("powershell") == "powershell.ps1"


# Generated at 2022-06-25 11:48:35.446618
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    # Prepare the test case data
    shell_module_obj = ShellModule()
    env_string = 'Set-Variable -Name "D" -Value "E" -Scope Global'
    shebang = '#!powershell'
    cmd = 'abcd'
    arg_path = 'arg_path'

    # Perform the operation
    result = shell_module_obj.build_module_command(env_string, shebang, cmd, arg_path)

    # Verify the result
    assert(type(result) == str)

# Generated at 2022-06-25 11:48:39.581782
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    filename_0 = "test"
    shell_module_0 = ShellModule()
    assert shell_module_0.get_remote_filename(filename_0) == "test.ps1", "shell_module_0.get_remote_filename returned wrong value."


# Generated at 2022-06-25 11:48:40.542019
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:48:45.257637
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:48:55.849205
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():

    temp_dir = shell_module_0.mkdtemp()
    res = shell_module_0._run_command(temp_dir)
    assert res["rc"] == 0
    remote_tmp_dir = res["stdout"][0].strip()
    remote_tmp_dir = shell_module_0._unquote(remote_tmp_dir)

    test_dirs = ["dir_1", "dir_2", "dir_3"]
    for test_dir in test_dirs:
        res = shell_module_0.mkdtemp(basefile=test_dir, tmpdir=remote_tmp_dir)
        assert res["rc"] == 0
        remote_dir = res["stdout"][0].strip()
        remote_dir = shell_module_0._unquote(remote_dir)
        temp_file = shell_

# Generated at 2022-06-25 11:48:59.036428
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_1.SHELL_FAMILY == 'powershell'
    assert shell_module_1._IS_WINDOWS == True



# Generated at 2022-06-25 11:49:01.087950
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.COMPATIBLE_SHELLS
    # assert shell_module_0.SHELL_FAMILY == 'powershell'



# Generated at 2022-06-25 11:49:05.846698
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert isinstance(shell_module_1, ShellModule)


# Generated at 2022-06-25 11:49:13.803283
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print("UNIT TEST {}".format("test_ShellModule"))
    print("{}".format("test_ShellModule"))
    print("{}".format("shell_module_0.join_path('C:\\users\\', 'C:\\windows\\')"))
    print("{}".format(shell_module_0.join_path('C:\\users\\', 'C:\\windows\\')))
    print("{}".format("shell_module_0.join_path('C:\\users', 'C:\\windows\\')"))
    print("{}".format(shell_module_0.join_path('C:\\users', 'C:\\windows\\')))

# Generated at 2022-06-25 11:49:18.022860
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print(test_case_0.__doc__)
    test_case_0()

if __name__ == '__main__':
    print('Running the unit tests for {0}'.format(__file__))
    test_ShellModule()
    print('Unit tests for {0} are completed'.format(__file__))

# Generated at 2022-06-25 11:49:21.015550
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1= ShellModule()
    # Assert that the defined shell plugin is Powershell
    assert shell_module_1.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:49:24.231087
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_1 = ShellModule()
    assert True == shell_module_1.path_has_trailing_slash('abc\\')


# Generated at 2022-06-25 11:49:27.061952
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_1 = ShellModule()
    path = "D:\\Program Files\\"
    assert shell_module_1.path_has_trailing_slash(path) == True



# Generated at 2022-06-25 11:49:38.678740
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Populate a variable with the results of the function being tested
    shell_module = ShellModule()
    path_no_slash = to_text(r'c:\temp\test')
    path_fwd_slash = to_text(r'c:\temp\test\\')
    path_bck_slash = to_text(r'c:\temp\test/')
    path_fwd_slash_end = to_text(r'c:\temp\test\\/')
    path_bck_slash_end = to_text(r'c:\temp\test/\\')
    path_fwd_slash_middle = to_text(r'c:\temp\/test')

# Generated at 2022-06-25 11:49:44.560274
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset(), "has to be frozenset()"
    assert shell_module_0.SHELL_FAMILY == 'powershell', "has to be 'powershell'"
    assert shell_module_0._IS_WINDOWS == True, "has to be True"


# Generated at 2022-06-25 11:49:52.421678
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    cmd = '#!/usr/bin/env python'
    arg_path = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0'
    env_string = ""
    shebang = ""
    result = shell_module_0.build_module_command(env_string, shebang, cmd, arg_path)
    assert result == "python " + arg_path + " -"


# Generated at 2022-06-25 11:49:53.972054
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    if not isinstance(shell_module, ShellModule):
        raise Exception('Failed to create instance of ShellModule class')


# Generated at 2022-06-25 11:49:59.737082
# Unit test for constructor of class ShellModule
def test_ShellModule():
    TestShellModule = shell_module_0.build_module_command("env_string", "shebang","cmd", arg_path="arg_path")
    wrapped_for_exec = shell_module_0.wrap_for_exec("cmd")
    assert TestShellModule != ''
    assert wrapped_for_exec != ''
    assert shell_module_0.exists("path") != ''
    assert shell_module_0.join_path("path") != ''
    assert shell_module_0.checksum("path") != ''
    assert shell_module_0.expand_user("user_home_path", username="") != ''
    assert shell_module_0.remove("path", recurse=False) != ''

# Generated at 2022-06-25 11:50:11.093903
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    assert '\\\\' == ShellModule().path_has_trailing_slash('\\\\')
    assert '' == ShellModule().path_has_trailing_slash('')
    assert None == ShellModule().path_has_trailing_slash(None)
    assert '\\test.txt' == ShellModule().path_has_trailing_slash('\\test.txt')
    assert '\\test\\' == ShellModule().path_has_trailing_slash('\\test\\')
    assert '\\test\\\\' == ShellModule().path_has_trailing_slash('\\test\\\\')
    assert '\\test\\\\\\' == ShellModule().path_has_trailing_slash('\\test\\\\\\')
    assert '\\test\\' == ShellModule().path_has_trailing_slash('\\test\\ ')

# Generated at 2022-06-25 11:50:17.340646
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    print('Test for method path_has_trailing_slash of class ShellModule')

    def test_1():
        test_data = '/foo/bar/'
        obj = ShellModule()
        path_has_trailing_slash_result = obj.path_has_trailing_slash(test_data)
        print('\tassert path_has_trailing_slash_result == True')
        assert path_has_trailing_slash_result == True

    def test_2():
        test_data = 'C:\\foo\\bar\\'
        obj = ShellModule()
        path_has_trailing_slash_result = obj.path_has_trailing_slash(test_data)
        print('\tassert path_has_trailing_slash_result == True')
        assert path_has

# Generated at 2022-06-25 11:50:21.889793
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_1 = ShellModule()

    # Test case
    test_case_1_user_home_path = '~'
    test_case_1_username = ''
    expected_1 = 'Write-Output (Get-Location).Path'

    actual_1 = shell_module_1.expand_user(test_case_1_user_home_path, test_case_1_username)
    assert actual_1 == expected_1


# Generated at 2022-06-25 11:50:24.371561
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert isinstance(shell_module_1, ShellModule)


# Generated at 2022-06-25 11:50:32.125565
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_1 = ShellModule()

    assert shell_module_1.path_has_trailing_slash('C:\\Users\\ext\\') == True
    assert shell_module_1.path_has_trailing_slash('C:\\Users\\ext') == False
    assert shell_module_1.path_has_trailing_slash('C:\\Users\\ext\\ ') == True



# Generated at 2022-06-25 11:50:38.121078
# Unit test for constructor of class ShellModule
def test_ShellModule():
    with pytest.raises(NotImplementedError):
        test_case_0()
# ================================================== test case end ==================================================



# Generated at 2022-06-25 11:50:39.822010
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()
    shell = ShellModule()

    return shell


# Generated at 2022-06-25 11:50:41.256897
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1._IS_WINDOWS == True


# Generated at 2022-06-25 11:50:42.937018
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert (isinstance(shell_module_0, ShellModule))



# Generated at 2022-06-25 11:50:45.748221
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert (shell_module_1._unquote('') == '')
    assert (shell_module_1._unquote('') == '')
    assert (shell_module_1._escape('') == '')


# Generated at 2022-06-25 11:50:47.273093
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:50:49.095534
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:50:58.880130
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    env_string = 'env_string'
    shebang = '#!powershell'
    cmd = 'cmd'

# Generated at 2022-06-25 11:51:03.057067
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Case 0
    try:
        test_case_0()
    except Exception as e:
        print("Test Case 0: ")
        print("Exception caught while instantiating class ShellModule")
        print("Exception: ", type(e), str(e))
        return False
    return True

# Generated at 2022-06-25 11:51:12.867003
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # test_case_1:
    shell_module_1 = ShellModule()

    # Assert with expression 1
    assert shell_module_1.COMPATIBLE_SHELLS == frozenset()

    # Assert with expression 2
    assert shell_module_1.SHELL_FAMILY == 'powershell'

    # Assert with expression 3
    assert shell_module_1.HAS_UNIQUE_FILENAMES == False

    # Assert with expression 4
    assert shell_module_1.CAN_BACKGROUND == False

    # Assert with expression 5
    assert shell_module_1.DEFAULT_EXECUTABLE == 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'

    # Assert with expression 6
    assert shell_module_1.BINARY_MOD

# Generated at 2022-06-25 11:51:18.929887
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:51:20.388802
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:51:23.314026
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert 1 == 1

# Generated at 2022-06-25 11:51:24.549588
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module



# Generated at 2022-06-25 11:51:31.070124
# Unit test for constructor of class ShellModule
def test_ShellModule():
    mock_module = Mock()
    mock_module.params = dict(
        remote_tmp='C:\\Users\\test\\AppData\\Local\\Temp',
        remote_uid=1,
        executable='C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe',
        _ansible_debug=False
    )

    mock_shell_plugin = ShellModule(connection=mock_module)
    assert mock_shell_plugin.get_option('remote_tmp') == 'C:\\Users\\test\\AppData\\Local\\Temp'
    assert mock_shell_plugin.get_option('remote_uid') == 1
    assert mock_shell_plugin.get_option('executable') == 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'
    assert mock_shell_plugin

# Generated at 2022-06-25 11:51:34.065839
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print(shell_module_0)



# Generated at 2022-06-25 11:51:38.281176
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert type(shell_module_1) == ShellModule

# Unit tests for function _unquote()

# Generated at 2022-06-25 11:51:47.389316
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Check if constructor throws TypeError, if it does, test is passed.
    # Otherwise, test fails.
    try:
        # Create instance of ShellModule class
        shell_module_1 = ShellModule()
        # If an exception is not thrown, test fails.
        raise Exception("Exception not thrown")
    # TypeError exception thrown, test passed
    except TypeError:
        pass

if __name__ == '__main__':
    test_case_0()
    test_ShellModule()

# Generated at 2022-06-25 11:51:48.356621
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert isinstance(ShellModule(), ShellModule)


# Generated at 2022-06-25 11:51:50.665309
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    script = shell_module_0._encode_script("Write-Output 'Hello World!'")
    cmd = shell_module_0.wrap_for_exec(script)
    #print("cmd = " + cmd)



# Generated at 2022-06-25 11:51:55.845469
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.expand_user('"~/test.txt"')


# Generated at 2022-06-25 11:51:58.597471
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_env_prefix = ShellModule.env_prefix
    # TODO: Come up with test cases for ShellModule.join_path(),
    #       ShellModule.get_remote_filename(), and ShellModule.chmod()


# Generated at 2022-06-25 11:52:01.250197
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_instance = ShellModule(connection)
    shell_instance_0 = ShellModule(connection, no_log)
    shell_instance_1 = ShellModule(connection, no_log, keep_remote_files)


# Generated at 2022-06-25 11:52:07.527968
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.join_path()
    shell_module_0.get_remote_filename()
    shell_module_0.path_has_trailing_slash()
    shell_module_0.chmod()
    shell_module_0.chown()
    shell_module_0.set_user_facl()
    shell_module_0.remove()
    shell_module_0.mkdtemp()
    shell_module_0.expand_user()
    shell_module_0.exists()
    shell_module_0.checksum()
    shell_module_0.build_module_command()
    shell_module_0.wrap_for_exec()
    shell_module_0.get_option()
    shell_module_0.get_bin

# Generated at 2022-06-25 11:52:12.566434
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule(is_windows=True)
    print(shell_module_1.SHELL_FAMILY)
    print(shell_module_1.COMPATIBLE_SHELLS)


# Generated at 2022-06-25 11:52:15.936451
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.env_prefix(**kwargs)

    assert var_0 == ""



# Generated at 2022-06-25 11:52:19.164433
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert True


# Generated at 2022-06-25 11:52:28.409516
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.join_path()
    shell_module_0.get_remote_filename()
    shell_module_0.path_has_trailing_slash()
    shell_module_0.chmod()
    shell_module_0.chown()
    shell_module_0.set_user_facl()
    shell_module_0.remove()
    shell_module_0.mkdtemp()
    shell_module_0.expand_user()


# Generated at 2022-06-25 11:52:30.142559
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:52:36.230387
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.SHELL_FAMILY == 'powershell'



# Generated at 2022-06-25 11:52:41.604787
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_env_prefix()

# Generated at 2022-06-25 11:52:44.488529
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL is '> $null'
    assert shell_module_0._SHELL_AND is ';'
    assert shell_module_0._IS_WINDOWS is True


# Generated at 2022-06-25 11:52:48.503982
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1._unquote("'C:/Windows/System32'") == "C:/Windows/System32"
    assert shell_module_1._unquote("'C:/Windows/System32'") == "C:/Windows/System32"

print("Test Done")

# Generated at 2022-06-25 11:52:58.926595
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Check is_windows with default value
    assert shell_module_0.is_windows
    # Check compatible_shells with default value
    assert shell_module_0.compatible_shells == frozenset()
    # Check shell_family with default value
    assert shell_module_0.shell_family == 'powershell'
    # Check shell_redirect_allnull with default value
    assert shell_module_0.shell_redirect_allnull == '> $null'
    # Check shell_and with default value
    assert shell_module_0.shell_and == ';'
    # Check path_split_sep with default value
    assert shell_module_0.path_split_sep == ';'
    # Check shell_executable with default value
    assert shell_module

# Generated at 2022-06-25 11:53:03.786723
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-25 11:53:05.464482
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1.__class__.__name__ == 'ShellModule'


# Generated at 2022-06-25 11:53:10.665865
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    str_0 = "C:\\Users\\test_user"
    var_0 = shell_module_0.expand_user(str_0)



# Generated at 2022-06-25 11:53:15.752218
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.success_key is None
    assert shell_module_0.path_separator is None
    assert shell_module_0.start_of_output is None
    assert shell_module_0.end_of_output is None
    assert shell_module_0.re_success_status is None
    assert shell_module_0.supports_multiple_commands is None
    assert shell_module_0.output_method is None
    assert shell_module_0.sys_path is None


# Generated at 2022-06-25 11:53:18.384369
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    if (type(shell_module).__name__ != 'ShellModule'):
        raise Exception('Failed to create instance of ShellModule')


# Generated at 2022-06-25 11:53:20.919783
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(type(shell_module_0) == ShellModule)


# Generated at 2022-06-25 11:53:27.996092
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return shell_module_0


# Generated at 2022-06-25 11:53:28.862322
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert True


# Generated at 2022-06-25 11:53:32.722483
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:35.121455
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()

# Unit test against AnsibleFileNotFound error

# Generated at 2022-06-25 11:53:37.300073
# Unit test for constructor of class ShellModule
def test_ShellModule():
    cwdpath = 'C:\\Python27'
    module_0 = ShellModule(cwdpath)
    module_0.get_connection_info()


# Generated at 2022-06-25 11:53:42.182898
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # test case no. 0:
    try:
        assert test_case_0()
    except AssertionError:
        print("Testcase no. 0: AssertionError, unexpected behavior")
    else:
        print("Testcase no. 0: expected behavior")

# Generated at 2022-06-25 11:53:44.308853
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:53:52.370833
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Output:
    # Traceback (most recent call last):
    #   File "/usr/lib/python3.7/runpy.py", line 193, in _run_module_as_main
    #     "__main__", mod_spec)
    #   File "/usr/lib/python3.7/runpy.py", line 85, in _run_code
    #     exec(code, run_globals)
    #   File "/home/christian/.local/lib/python3.7/site-packages/ansible/modules/shell/powershell.py", line 43, in <module>
    #     if __name__ == '__main__':
    #   File "/home/christian/.local/lib/python3.7/site-packages/ansible/module_

# Generated at 2022-06-25 11:53:55.448670
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_env_prefix()
    # Testing inline case
    # Testing blob case



# Generated at 2022-06-25 11:53:58.985363
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:05.375441
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == {}, 'shell_module_0.COMPATIBLE_SHELLS should be empty'


# Generated at 2022-06-25 11:54:06.476560
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:11.126441
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    test_ShellModule_0 = ShellModule()
    var_1 = test_ShellModule_0.expand_user('~')


# Generated at 2022-06-25 11:54:15.228788
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # TODO: Re-construct object after test
    # ShellModule object
    shell_module_0 = ShellModule()
    # User home path
    var_1 = '~'
    # User name
    var_2 = ''
    var_0 = shell_module_0.expand_user(var_1, var_2)
    return var_0


# Generated at 2022-06-25 11:54:17.499438
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:22.028649
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # TODO: assert the class of shell_module_0
    # assert ...
    pass


# Generated at 2022-06-25 11:54:30.160266
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    shell_module_2 = shell_module_0
    shell_module_3 = shell_module_0
    shell_module_4 = shell_module_0
    shell_module_5 = shell_module_0
    shell_module_6 = shell_module_0
    shell_module_7 = shell_module_0
    shell_module_8 = shell_module_0
# TODO: test this with a proper argument value, for real
#    shell_module_0.build_module_command(shell_module_0.get_option('remote_user'), '#!powershell', '', 'C:\\windows\\system32\\inetsrv\\appcmd.exe set backup "C:\Windows\system32\inetsrv\config\\

# Generated at 2022-06-25 11:54:31.274514
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_env_prefix()


# Generated at 2022-06-25 11:54:34.224736
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(isinstance(shell_module_0, ShellModule))

# Generated at 2022-06-25 11:54:36.848570
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellModule = ShellModule()

# Generated at 2022-06-25 11:54:46.846027
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule) == True
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:54:58.312435
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create object for testing.
    shell_module_0 = ShellModule()
    shell_module_0.build_module_command()
    shell_module_0.checksum('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe')
    shell_module_0.chmod('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe','')
    shell_module_0.chown('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe','')
    shell_module_0.exists('C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe')

# Generated at 2022-06-25 11:55:05.562307
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(shell_module_0.module_implementation_preferences == [ 'winrm', 'psrp', 'ssh' ] )
    assert(shell_module_0.default_file_transfer_temp_dir is None )
    assert(shell_module_0.checksum_format == 'sha1' )
    assert(shell_module_0.shell_type == 'powershell' )
    assert(shell_module_0.supports_check_mode == False )
    assert(shell_module_0.supports_no_log == False )
    assert(shell_module_0.unique_id == '3a0a724b49053634a092d2e78c9f7e9e' )

# Generated at 2022-06-25 11:55:09.220544
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:11.347346
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:55:13.040255
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:55:15.606001
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with user supplied arguments
    try:
        shell_module_1 = ShellModule(1, 2)
    # Test with no arguments passed
    except SystemExit:
        shell_module_2 = ShellModule()


# Generated at 2022-06-25 11:55:21.563983
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:55:23.268363
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0


# Generated at 2022-06-25 11:55:31.077822
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)
    assert isinstance(shell_module_0, ShellBase)
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS


# Generated at 2022-06-25 11:55:49.913218
# Unit test for constructor of class ShellModule
def test_ShellModule():
    filename = __file__
    assert ShellModule._make_tmp_path() == ShellModule._make_tmp_path(), 'ShellModule._make_tmp_path() == ShellModule._make_tmp_path()'
    assert ShellModule.SHELL_FAMILY == 'powershell', 'ShellModule.SHELL_FAMILY == "powershell"'
    assert ShellModule.COMPATIBLE_INTERPRETER_NAMES == set(['powershell']), 'ShellModule.COMPATIBLE_INTERPRETER_NAMES == set([\'powershell\'])'
    assert ShellModule._shell_class == 'powershell', 'ShellModule._shell_class == "powershell"'
    assert ShellModule.SHELL_FAMILY == 'powershell', 'ShellModule.SHELL_FAMILY == "powershell"'
    assert ShellModule.COMPATIBLE_

# Generated at 2022-06-25 11:55:59.484963
# Unit test for constructor of class ShellModule
def test_ShellModule():
    with pytest.raises(NotImplementedError):
        shell_module_0 = ShellModule(remote_addr='remote_addr_0', password='password_0')

    with pytest.raises(NotImplementedError):
        shell_module_1 = ShellModule(remote_addr='remote_addr_1', prompt='prompt_1')

    with pytest.raises(NotImplementedError):
        shell_module_2 = ShellModule(prompt='prompt_2', password='password_2')

    with pytest.raises(NotImplementedError):
        shell_module_3 = ShellModule(remote_addr='remote_addr_3')

    with pytest.raises(NotImplementedError):
        shell_module_4 = ShellModule(prompt='prompt_4')


# Generated at 2022-06-25 11:56:04.726917
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(shell_module_0 is not None)


# Generated at 2022-06-25 11:56:11.235661
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.join_path(['', '', '', '', '', '', ''])
    shell_module_0.join_path(['', '', '', '', '', '', '', ''])
    shell_module_0.join_path(['', '', '', '', '', '', '', '', ''])
    shell_module_0.join_path(['', '', '', '', '', '', '', '', '', ''])
    shell_module_0.join_path(['', '', '', '', '', '', '', '', '', '', ''])
    shell_module_0.join_path(['', '', '', '', '', '', '', '', '', '', '', ''])
    shell

# Generated at 2022-06-25 11:56:12.218308
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:56:16.591160
# Unit test for constructor of class ShellModule
def test_ShellModule():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-25 11:56:18.196511
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:56:22.630277
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert_equal(shell_module_0.COMPATIBLE_SHELLS, frozenset())
    assert_equal(shell_module_0.SHELL_FAMILY, 'powershell')
    assert_true(shell_module_0._IS_WINDOWS)
    assert_equal(shell_module_0._SHELL_AND, ';')
    assert_equal(shell_module_0._SHELL_REDIRECT_ALLNULL, '> $null')


# Generated at 2022-06-25 11:56:32.271442
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Make sure the object is of class ShellModule
    assert type(shell_module_0) == ShellModule
    # Make sure the object is not of type bool
    assert not isinstance(shell_module_0, bool)
    # Make sure the object is not of type dict
    assert not isinstance(shell_module_0, dict)
    # Make sure the object is not of type int
    assert not isinstance(shell_module_0, int)
    # Make sure the object is not of type list
    assert not isinstance(shell_module_0, list)
    # Make sure the object is not of type dict
    assert not isinstance(shell_module_0, dict)
    # Make sure the object is not of type set
    assert not isinstance(shell_module_0, set)


# Generated at 2022-06-25 11:56:34.826038
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:47.606389
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:49.419919
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
        shell_module_1 = ShellModule()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 11:56:52.828524
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._shell_redirect_allnull == '> $null'

# Generated at 2022-06-25 11:56:53.890515
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:56:55.808486
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:59.481061
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return shell_module_0

# Generated at 2022-06-25 11:57:06.208240
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.join_path("PATH1", "PATH2")
    shell_module_0._SHELL_REDIRECT_ALLNULL
    shell_module_0._SHELL_AND
    shell_module_0._IS_WINDOWS
    shell_module_0.path_has_trailing_slash("\"")
    shell_module_0.get_remote_filename("")
    shell_module_0.mkdtemp()
    shell_module_0.expand_user("")
    shell_module_0.checksum("PATH")
    shell_module_0.exists("PATH")
    shell_module_0.build_module_command(shell_env_prefix(), "", "")
    shell_module_0.wrap_for_exec("CMD")



# Generated at 2022-06-25 11:57:07.862875
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert True, 'Test Failed'  # TODO: implement your test here


# Generated at 2022-06-25 11:57:12.385073
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_test = ShellModule()
    var_0 = shell_env_prefix()


# Generated at 2022-06-25 11:57:17.354103
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create an instance of ShellModule
    shell_module_0 = ShellModule()
    # Assert that the class name of the instance is ShellModule
    assert shell_module_0.__class__.__name__ == 'ShellModule'



# Generated at 2022-06-25 11:57:42.184852
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)
    assert isinstance(shell_module_0._SHELL_REDIRECT_ALLNULL, str)
    assert isinstance(shell_module_0._SHELL_AND, str)
    assert isinstance(shell_module_0._IS_WINDOWS, bool)
    

# Generated at 2022-06-25 11:57:46.859483
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = None
    var_0 = []
    shell_module_0 = ShellModule(var_0)
    shell_module_0 = ShellModule(var_0, False)
    shell_module_0 = ShellModule(var_0, True)
    shell_module_0 = ShellModule(var_0, False)
    shell_module_0 = ShellModule(var_0, True)
    shell_module_0 = ShellModule(var_0, False)
    shell_module_0 = ShellModule(var_0, True)
    shell_module_0 = ShellModule(var_0)
    shell_module_0 = ShellModule(var_0, False)
    shell_module_0 = ShellModule(var_0, False)
    shell_module_0 = ShellModule(var_0, True)


# Generated at 2022-06-25 11:57:52.547315
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import types
    import ansible.executor.powershell
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ansible.executor.powershell.ShellModule) == True

