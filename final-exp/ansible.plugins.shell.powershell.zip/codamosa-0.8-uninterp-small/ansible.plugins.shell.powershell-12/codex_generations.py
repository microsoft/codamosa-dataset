

# Generated at 2022-06-25 11:48:00.425538
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# Generated at 2022-06-25 11:48:10.664715
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    shebang_0 = '#!powershell'
    cmd_0 = 'switch -Regex (\"x\") { \"y\" {$y=1} default {$y=2} }'
    arg_path_0 = 'C:\\Users\\milk\\Ansible'
    script_0 = '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Users\\milk\\Ansible\\ansible-tmp-1584966167.17-253588213240694')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'switch.ps1'
        Write-Output -InputObject $tmp.FullName
        '''

# Generated at 2022-06-25 11:48:16.689143
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():

    # TODO: Start test
    os.chdir('src\\ansible\\modules\\files')
    cmd_0 = 'c:\\Windows\\system32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command -'
    # exec_rc_0 = shell_module_0._exec_rc(cmd_0)
    # assert(exec_rc_0 == 0)



# Generated at 2022-06-25 11:48:26.656944
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    kwargs = {}
    kwargs['username'] = 'lsv'
    k = ShellModule(**kwargs)
    # user_home_path = '~lsv'
    if (sys.platform == 'win32'):
        # cmd = 'Write-Output (Get-Location).Path'
        cmd = 'Write-Output "' + os.path.expandvars('%userprofile%') + '"'
    else:
        cmd = 'Write-Output $HOME'
    assert k.expand_user(user_home_path="~lsv") == cmd
    # user_home_path = '~'

# Generated at 2022-06-25 11:48:27.830752
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:29.673685
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:48:33.943079
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # Fixture Setup
    file_name = 'test.ps1'
    expected_result = 'test.ps1'
    shell_module_0 = ShellModule()
    # Test Code
    result = shell_module_0.get_remote_filename(file_name)
    # Fixture Teardown
    shell_module_0=None
    # Verify
    assert (result == expected_result)


# Generated at 2022-06-25 11:48:39.914500
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    cmd_parts_0 = ['SJX5p5']
    script_0 = '$eJN'
    ret_value_0 = shell_module_0.build_module_command(cmd_parts_0, script_0)
    print(ret_value_0)


# Generated at 2022-06-25 11:48:40.875257
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:48:44.462126
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    str_0 = 'xuV7J!PQ'
    str_1 = shell_module_0.build_module_command(str_0, None, None)


# Generated at 2022-06-25 11:48:51.606656
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print(shell_module_0)


# Generated at 2022-06-25 11:48:52.553347
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # TODO
    return


# Generated at 2022-06-25 11:49:01.797484
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    shell_module = ShellModule()

    # Case 1
    cmd = "Get-Item C:\\test_folder"
    shebang = "#!powershell"
    expected_result = shell_module.build_module_command("", shebang, cmd)
    assert expected_result == "& Get-Item 'C:\\test_folder'\r\nexit $LASTEXITCODE"

    # Case 2
    cmd = "Get-Item C:\\test_folder"
    shebang = "#!powershell"
    expected_result = shell_module.build_module_command("", shebang, cmd, "params")
    assert expected_result == "& Get-Item 'C:\\test_folder' 'params'\r\nexit $LASTEXITCODE"

    # Case 3

# Generated at 2022-06-25 11:49:11.608349
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    ps_script = 'Write-Host "TEST" '
    # Compress the string and convert to b64
    ps_script_b64 = to_text(base64.b64encode(zlib.compress(ps_script.encode())), 'utf-8')

    shell_module_1 = ShellModule()
    cmd = shell_module_1.build_module_command(env_string="", shebang="", cmd=ps_script, arg_path=None)

    # Compare the b64 of our string with the result of build_module_command
    assert(ps_script_b64 == re.match(".*?-EncodedCommand ([^ $]+)", cmd).group(1))


# Generated at 2022-06-25 11:49:12.666591
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    print(shell_module)


# Generated at 2022-06-25 11:49:18.883796
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_obj_0 = ShellModule()
    path_0 = 'C:\\Users\\user_0\\Desktop\\test_file.txt'
    result_0 = shell_module_obj_0.path_has_trailing_slash(path_0)
    assert (result_0 is False)
    path_1 = 'C:\\Users\\user_0\\Desktop\\test_file.txt\\'
    result_1 = shell_module_obj_0.path_has_trailing_slash(path_1)
    assert (result_1 is True)


# Generated at 2022-06-25 11:49:30.363949
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    reset_module_class()
    test_module_class = pkgutil.get_loader("ansible.plugins.shell.powershell").load_module()
    shell_module_path_has_trailing_slash_0 = test_module_class.ShellModule()
    path_0 = '/path/to/file'
    path_0 = shell_module_path_has_trailing_slash_0._unquote(path_0)
    shell_module_path_has_trailing_slash_0.path_has_trailing_slash(path_0)
    path_1 = u'/path/to/file'
    path_1 = shell_module_path_has_trailing_slash_0._unquote(path_1)

# Generated at 2022-06-25 11:49:38.160403
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Test with no args
    shell_module_0 = ShellModule()
    res = shell_module_0.mkdtemp()
    # Test with args
    shell_module_0 = ShellModule()
    res = shell_module_0.mkdtemp(basefile='basefile')
    # Test with args
    shell_module_0 = ShellModule()
    res = shell_module_0.mkdtemp(basefile='basefile', mode=None)
    # Test with args
    shell_module_0 = ShellModule()
    res = shell_module_0.mkdtemp(basefile='basefile', system=False)
    # Test with args
    shell_module_0 = ShellModule()
    res = shell_module_0.mkdtemp(basefile='basefile', tmpdir=None)
    # Test with args


# Generated at 2022-06-25 11:49:48.855402
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # arrange
    shell_module_0 = ShellModule()
    basefile = "F"
    system = False
    mode = None
    tmpdir = "vxl"

    # act
    result = shell_module_0.mkdtemp(basefile, system, mode, tmpdir)

    # assert
    assert result == 'RwBlAEUAUwBBAC4AYwBvAG0ALgBkAG8AbgBzAC4AdwAvAHUAdwBtAGUAbgB0AAoAQwBoAGUAbABsACAAbwBmACAAdABoAGUAIABSAGUAbAB0AGkAbgBnAAoAUwBJAEQARAAA'


# Generated at 2022-06-25 11:49:51.457180
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert 'powershell' == ShellModule.SHELL_FAMILY
    assert 'windows' == ShellModule.PLATFORM


# Generated at 2022-06-25 11:50:01.769777
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    var = shell_path_has_trailing_slash(shell_module)
    shell_module.get_remote_filename()
    shell_module.checksum()
    shell_module.remove()
    shell_module.exists()
    shell_module.chown()
    shell_module.chmod()
    shell_module.env_prefix()
    shell_module.join_path()
    shell_module.set_user_facl()
    shell_module.build_module_command()
    shell_module.expand_user()


# Generated at 2022-06-25 11:50:05.171718
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.expand_user("~", "")
    print(var_0)


# Generated at 2022-06-25 11:50:06.362527
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 11:50:11.096127
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is None


# Generated at 2022-06-25 11:50:11.883673
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:50:15.271818
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Instance of ShellModule class
    shell_module_0 = ShellModule()
    # Assertion to test if object is successfully created
    assert isinstance(shell_module_0, ShellModule) is True


# Generated at 2022-06-25 11:50:20.862106
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash(path='C:\\\\')
    assert var_0 == False
    var_1 = shell_module_0.path_has_trailing_slash(path='C:\\')
    assert var_1 == True


# Generated at 2022-06-25 11:50:30.289905
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    if shell_user_home_path.startswith("~") :
        var_0 = shell_user_home_path.strip("~")
        var_1 = "Write-Output ((Get-Location).Path + '%s')" % shell_module_0._escape(var_0)
    else:
        var_0 = "Write-Output '%s'" % shell_module_0._escape(shell_user_home_path)
        var_1 = var_0
    assert var_1 == shell_module_0.expand_user(shell_user_home_path, shell_username)


# Generated at 2022-06-25 11:50:32.212929
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(isinstance(shell_module_0, ShellModule))


# Generated at 2022-06-25 11:50:35.628209
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_path_has_trailing_slash(shell_module_0)


# Generated at 2022-06-25 11:50:40.704080
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:50:42.365762
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        clipboard_0 = ShellModule()
    except Exception as err:
        assert False , err


# Generated at 2022-06-25 11:50:43.530326
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None

# Generated at 2022-06-25 11:50:44.685318
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert (isinstance(shell_module, ShellModule))


# Generated at 2022-06-25 11:50:54.921942
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    mod = ShellModule()
    assert mod.expand_user('~') == b'(Get-Location).Path'
    assert mod.expand_user('~\\') == b"((Get-Location).Path + '\\\\')"
    assert mod.expand_user('~\\foo') == b"((Get-Location).Path + '\\\\foo')"
    assert mod.expand_user('~\\foo\\') == b"((Get-Location).Path + '\\\\foo\\\\')"
    assert mod.expand_user('C:\\Temp') == b"'C:\\\\Temp'"
    assert mod.expand_user('\\\\foo\\bar') == b"'\\\\\\\\foo\\\\bar'"
    assert mod.expand_user('/cygdrive/c/foo') == b"'/cygdrive/c/foo'"
    assert mod.expand

# Generated at 2022-06-25 11:50:56.098252
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:50:57.669869
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert isinstance(shell, (ShellModule))


# Generated at 2022-06-25 11:50:59.491543
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:51:02.649883
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    # check for exception
    with pytest.raises(NotImplementedError):
        shell_module_0.expand_user('user_home_path', 'username=')


# Generated at 2022-06-25 11:51:12.550965
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_option("remote_tmp")
    var_1 = shell_module_0.is_powershell_executable(var_0)
    var_2 = shell_module_0.get_option("remote_tmp")
    var_3 = shell_module_0.is_powershell_executable(var_2)
    var_4 = shell_module_0.get_option("remote_tmp")
    var_5 = shell_module_0.is_powershell_executable(var_4)
    var_6 = shell_module_0.get_option("remote_tmp")
    var_7 = shell_module_0.is_powershell_executable(var_6)
    var_8 = shell_module_0.get

# Generated at 2022-06-25 11:51:16.908578
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:51:18.372307
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:19.355117
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:51:27.596375
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = hasattr(shell_module_0, 'shebang')
    var_1 = hasattr(shell_module_0, 'family')
    var_2 = hasattr(shell_module_0, 'executable')
    var_3 = hasattr(shell_module_0, 'binary')
    var_4 = hasattr(shell_module_0, 'get_remote_filename')
    var_5 = hasattr(shell_module_0, 'makedirs')
    var_6 = hasattr(shell_module_0, 'path_has_trailing_slash')
    var_7 = hasattr(shell_module_0, 'expand_user')
    var_8 = hasattr(shell_module_0, 'checksum')
    var_9 = has

# Generated at 2022-06-25 11:51:33.500208
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    print(shell_module_1)

if __name__ == '__main__':
    args = parser.parse_args()
    if args.func.__name__ in globals():
        globals()[args.func.__name__]()
    else:
        parser.print_help()

# Generated at 2022-06-25 11:51:38.861163
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule(connection=None)
    assert shell_module_0 is not None
    assert shell_module_0 == shell_module_1


# Generated at 2022-06-25 11:51:46.722438
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule('user_home_path', 'arg_path')
    var_0 = shell_module_0.get_remote_filename('pathname')
    var_1 = shell_module_0.checksum('path', '*args', '**kwargs')
    var_2 = shell_module_0.path_has_trailing_slash('path')
    var_3 = shell_module_0.set_user_facl('paths', 'user', 'mode')
    var_4 = shell_module_0.chmod('paths', 'mode')
    var_5 = shell_module_0.chown('paths', 'user')
    var_6 = shell_module_0.remove('path', 'recurse')

# Generated at 2022-06-25 11:51:50.167436
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:51:51.020809
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()


# Generated at 2022-06-25 11:51:55.942382
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:05.532363
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():

    shell_module_0 = ShellModule()
    var_0 = shell_path_has_trailing_slash(shell_module_0)

# Generated at 2022-06-25 11:52:11.678904
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    # Test input argument (string)
    var = 'string'
    var_expected = False
    var_actual = shell_path_has_trailing_slash(shell_module)
    assert var_expected == var_actual, 'Expected {}, but got {}'.format(var_expected, var_actual)


# Generated at 2022-06-25 11:52:13.831849
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule() is not None, "Failed to instantiate ShellModule"


# Generated at 2022-06-25 11:52:16.207317
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:52:20.440416
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    args0 = None
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash(args0)
    assert type(var_0) == bool


# Generated at 2022-06-25 11:52:31.258103
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_join_path(shell_module_0)
    # Unit test for static method exists of class ShellModule
    var_1 = ShellModule.exists(var_0)
    # Unit test for static method checksum of class ShellModule
    var_2 = ShellModule.checksum(var_0)
    # Unit test for static method build_module_command of class ShellModule
    var_3 = ShellModule.build_module_command(None, None, 'module_name arg1 arg2', 'arg_path')
    # Unit test for static method wrap_for_exec of class ShellModule
    var_4 = ShellModule.wrap_for_exec(var_3)
    # Unit test for static method _unquote of class ShellModule
    var_5 = ShellModule._unquote

# Generated at 2022-06-25 11:52:34.737215
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:52:35.611345
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    test_case_0()



# Generated at 2022-06-25 11:52:40.809449
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert (isinstance(shell_module, ShellModule))


# Generated at 2022-06-25 11:52:44.868829
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Assign a value to variable expect_value_0
    expect_value_0 = True
    # Call method _is_windows() of object shell_module_0 and assign result to variable result_value_0
    result_value_0 = shell_module_0._is_windows()
    assert result_value_0 == expect_value_0



# Generated at 2022-06-25 11:53:11.184422
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_1 = shell_module_0.wrap_for_exec('pwd')


# Generated at 2022-06-25 11:53:15.083379
# Unit test for constructor of class ShellModule
def test_ShellModule():
    a = ShellModule()
    assert(a)


# Generated at 2022-06-25 11:53:23.455593
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert 'Windows PowerShell' in shell_module_0.get_remote_filename('/path/to/a/powershell/script.ps1')
    assert shell_module_0._IS_WINDOWS == True
    shell_module_0.set_options(direct={'_ansible_no_log': False, '_ansible_debug': False, '_ansible_verbosity': 0, '_ansible_version': '2.9.10', '_ansible_module_name': 'test', '_ansible_module_skeleton': False, '_ansible_diff': False, '_ansible_check_mode': False})
    shell_module_0.reset()


# Generated at 2022-06-25 11:53:25.128501
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    result_bool = shell_module_0.is_windows
    print(result_bool)
    # AssertionError: Expected True


# Generated at 2022-06-25 11:53:26.318537
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_0 = ShellModule()
    is_instance_0 = isinstance(module_0, ShellModule)
    assert is_instance_0 is True


# Generated at 2022-06-25 11:53:34.232718
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._unquote('${HOME}') == "${HOME}"
    shell_module_1 = ShellModule()
    assert shell_module_1._unquote('c:\\foo') == "c:\\foo"
    shell_module_2 = ShellModule()
    assert shell_module_2._unquote('c:\\foo\\bar') == "c:\\foo\\bar"
    shell_module_3 = ShellModule()
    assert shell_module_3._unquote('c:\\foo\\bar\\baz') == "c:\\foo\\bar\\baz"
    shell_module_4 = ShellModule()

# Generated at 2022-06-25 11:53:39.201927
# Unit test for constructor of class ShellModule
def test_ShellModule():
    if not PY2:
        shell_module = ShellModule()
        expected = '#< CLIXML\r\n<Objs Version="1.1.0.1" xmlns="http://schemas.microsoft.com/powershell/2004/04"><S S="Error">test_stderr</S></Objs>\r\n'
        result = _parse_clixml(expected)
        expected = 'test_stderr'
        assert expected == result

# Generated at 2022-06-25 11:53:40.843122
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellBase)



# Generated at 2022-06-25 11:53:43.087080
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:53:44.395071
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:12.053174
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 != None
    assert shell_module_1._SHELL_REDIRECT_ALLNULL == '> $null'


# Generated at 2022-06-25 11:54:17.188148
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    string_0 = "f0WxwdK"
    string_1 = "GkOjD4t"
    string_2 = "YpKj"
    string_3 = "9XN5"
    string_4 = "AzJQKk"
    var_0 = shell_module_0.build_module_command(string_0, string_1, string_2, string_3, string_4)
    # assert var_0 == None


# Generated at 2022-06-25 11:54:26.049286
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
        assert shell_module_0.get_option('remote_tmp') == u'$env:temp'
        assert shell_module_0.get_option('remote_interpreter') == u'$env:windir\\system32\\windowspowershell\\v1.0\\powershell.exe'
        assert shell_module_0.get_option('module_style') == u'powershell'
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 11:54:27.403956
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module_0 = ShellModule()
    assert type(shell_module_0) is ShellModule


# Generated at 2022-06-25 11:54:28.392029
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("Testing method constructor of class ShellModule")


# Generated at 2022-06-25 11:54:29.148581
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()
    

# Generated at 2022-06-25 11:54:30.189087
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test case 0
    t0 = test_case_0()

# Generated at 2022-06-25 11:54:32.125514
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:54:41.647754
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    # Test command execution
    # Setup test data
    var1 = 'test'
    var2 = 'test2'
    var3 = 'test3'

    # Test encode the cmd with out any shebang
    script = shell_module.build_module_command('', '', 'echo "test1"')
    script_encoded = shell_module.wrap_for_exec(script)
    out = shell_module._low_level_execute_command(script_encoded, sudoable=False)
    assert (out == 'test1\n')

    # Test encode the cmd with out any shebang but with the stdout_callback
    encoder = Encoder()
    script = shell_module.build_module_command('', '', 'echo "test1"')
    script_encoded = shell_

# Generated at 2022-06-25 11:54:43.209543
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:55:42.460330
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    local_path_0 = to_bytes('test_file')
    remote_path_0 = shell_module_0.get_remote_filename(local_path_0)
    remote_path_1 = shell_module_0.get_remote_filename(local_path_0)
    path_1 = to_bytes('/foo/bar/')
    var_0 = shell_path_has_trailing_slash(shell_module_0)
    path_0 = to_bytes('/foo/bar')
    var_1 = shell_path_has_trailing_slash(shell_module_0)
    path_1 = to_bytes('/foo/bar/')
    var_2 = shell_path_has_trailing_slash(shell_module_0)
   

# Generated at 2022-06-25 11:55:43.202690
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module != None


# Generated at 2022-06-25 11:55:46.066394
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
        print('Pass')
    except:
        print('Exception raised')
    finally:
        print('Completed')

# Calling unit test function
test_ShellModule()

# Generated at 2022-06-25 11:55:57.417561
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.env_prefix()
    var_1 = shell_module_0.join_path()
    var_2 = shell_module_0.get_remote_filename()
    var_3 = shell_module_0.path_has_trailing_slash()
    var_4 = shell_module_0.chmod()
    var_5 = shell_module_0.chown()
    var_6 = shell_module_0.set_user_facl()
    var_7 = shell_module_0.remove()
    var_8 = shell_module_0.mkdtemp()
    var_9 = shell_module_0.expand_user()
    var_10 = shell_module_0.exists()

# Generated at 2022-06-25 11:55:59.109018
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule) == True


# Generated at 2022-06-25 11:56:03.218090
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:04.724729
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert 0


# Generated at 2022-06-25 11:56:05.851163
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    test_case_0()


# Generated at 2022-06-25 11:56:15.303147
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    script_dir = os.path.dirname(os.path.realpath(__file__))
    script_file = os.path.join(script_dir, "script.txt")
    with open(script_file, "w+") as f:
        f.write("helloworld")


# Generated at 2022-06-25 11:56:16.416870
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)

# Generated at 2022-06-25 11:57:57.564501
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1.get_remote_filename('/path/to/a//file') == 'file'
    assert shell_module_1.get_remote_filename('/path/to/a//file.ps1') == 'file.ps1'
    assert shell_module_1.get_remote_filename('/path/to/a//file.exe') == 'file.exe'
    assert shell_module_1.path_has_trailing_slash('/path/to/a/') == True
    assert shell_module_1.path_has_trailing_slash('/path/to/a') == False