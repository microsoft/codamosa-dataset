

# Generated at 2022-06-25 11:48:20.099770
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_1 = ShellModule()
    env_string = u''
    shebang = u'#!powershell'
    cmd = u'$env:ANSIBLE_MODULE_ARGS=@{}'
    arg_path = u''

# Generated at 2022-06-25 11:48:21.433448
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    path = '~/Ansible-Testing'
    shell_module_1 = ShellModule()
    shell_module_1.expand_user(path)

# Generated at 2022-06-25 11:48:24.291320
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module._IS_WINDOWS == True
    assert shell_module.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-25 11:48:25.341452
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:26.367229
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    result = ShellModule.mkdtemp()
    assert result is not None


# Generated at 2022-06-25 11:48:28.528863
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_1 = ShellModule()
    tmpdir = shell_module_1.mkdtemp()
    assert 0 == len(tmpdir)
    assert 'System.Object' == tmpdir.__class__.__name__



# Generated at 2022-06-25 11:48:36.167483
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module = ShellModule()

    user_home_path = '~'
    expected = shell_module._encode_script('Write-Output (Get-Location).Path')
    assert shell_module.expand_user(user_home_path) == expected

    user_home_path = '~path'
    expected = shell_module._encode_script("Write-Output ((Get-Location).Path + 'path')")
    assert shell_module.expand_user(user_home_path) == expected

    user_home_path = '~\\path'
    expected = shell_module._encode_script("Write-Output ((Get-Location).Path + '\\path')")
    assert shell_module.expand_user(user_home_path) == expected


# Generated at 2022-06-25 11:48:37.989462
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:48:47.650858
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    # basefile='ansible-tmp-1568995295.320469-233876379531939'
    # Check that the script is as expected
    assert shell_module_0.mkdtemp(basefile=None, system=False, mode=None, tmpdir=None) == b"&{ $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TMP')\n$tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-1568995295.320469-233876379531939'\nWrite-Output -InputObject $tmp.FullName\n}"

    shell_module_1 = ShellModule()
    # basefile='ansible-tmp-1568995295.320469-233876

# Generated at 2022-06-25 11:48:53.731731
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    assert shell_module_0.path_has_trailing_slash("") == False
    assert shell_module_0.path_has_trailing_slash("\\") == True
    assert shell_module_0.path_has_trailing_slash("/") == True


# Generated at 2022-06-25 11:49:08.556994
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    # Test: empty data set
    shell_module_0 = ShellModule()
    res_0 = shell_module_0.build_module_command(env_string='', shebang='', cmd='')

# Generated at 2022-06-25 11:49:09.368960
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass


# Generated at 2022-06-25 11:49:12.667016
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    assert shell_module.path_has_trailing_slash('C:/test\\')
    assert shell_module.path_has_trailing_slash('C:/test/')
    assert not shell_module.path_has_trailing_slash('C:/test')


# Generated at 2022-06-25 11:49:19.918356
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    shell_module_1 = ShellModule()
    result = shell_module_1.build_module_command(env_string='', shebang='shebang', cmd='cmd', arg_path='')

# Generated at 2022-06-25 11:49:31.422829
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module = ShellModule()
    assert shell_module.get_remote_filename('/path/to/file.exe') == 'file.exe'
    assert shell_module.get_remote_filename('file.exe') == 'file.exe'
    assert shell_module.get_remote_filename('/path/to/file') == 'file.ps1'
    assert shell_module.get_remote_filename('file') == 'file.ps1'
    assert shell_module.get_remote_filename('file.ps1') == 'file.ps1'
    assert shell_module.get_remote_filename('/path/to/file.ps1') == 'file.ps1'
    assert shell_module.get_remote_filename('/path/to/file.sh') == 'file.sh.ps1'
    assert shell_

# Generated at 2022-06-25 11:49:40.003368
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # Test case shell_module_1 and shell_module_2 tests the two possible paths
    # for get_remote_filename in ShellModule
    shell_module_1 = ShellModule()
    pathname = 'C:\\Users\\travis\\ansible_for_devops_release-0.1.0rc1\\.travis.yml'
    result = shell_module_1.get_remote_filename(pathname)

    assert result == '.travis.yml'



# Generated at 2022-06-25 11:49:45.010857
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    env_string = "Test Value"
    shebang = '#!/usr/bin/python'
    cmd = 'import json; print json.dumps({\"changed\": False, \"msg\": \"Success.\"})'
    arg_path = None
    shell_module_0.build_module_command(env_string, shebang, cmd, arg_path)

# Generated at 2022-06-25 11:49:46.977544
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:49:54.860951
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    env_string = "Set-Variable -Name PSModulePath -Value 'C:/Program Files/WindowsPowerShell/Modules/'"
    shebang = "#!powershell"
    cmd = "echo \"echo hello world\" | Write-Output"
    result = shell_module_0.build_module_command(env_string, shebang, cmd)

    # Output to file
    f0 = open("debug_file.txt", "w")
    f0.write(result)



# Generated at 2022-06-25 11:49:57.953208
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    arg_pathname = 'abc.ps1'
    expected = 'abc.ps1'
    actual = shell_module_0.get_remote_filename(arg_pathname)
    assert actual == expected


# Generated at 2022-06-25 11:50:11.214543
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()

    # Test case # 0 - defaults
    # No exception is raised
    shell_module_0.mkdtemp()

    # Test case # 1 - defaults
    # No exception is raised
    shell_module_0.mkdtemp()

    # Test case # 2 - defaults
    # No exception is raised
    shell_module_0.mkdtemp()

    # Test case # 3 - unique tmp dir
    # No exception is raised
    shell_module_0.mkdtemp()

    # Test case # 4 - unique basefile
    # No exception is raised
    shell_module_0.mkdtemp()

    # Test case # 5 - basefile should not be too long
    # No exception is raised
    shell_module_0.mkdtemp()

    # Test case # 6 - system true


# Generated at 2022-06-25 11:50:12.838750
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:14.487813
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Tests the mkdtemp method
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.mkdtemp()


# Generated at 2022-06-25 11:50:18.279598
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module is not None


# Generated at 2022-06-25 11:50:30.550961
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # TODO: add test for reading of environment variables

    # test for get_remote_filename returns powershell file extension for non-powershell files
    remote_filename_0 = shell_module_0.get_remote_filename(non_ps_file_name)
    assert remote_filename_0 == expected_powershell_filename
    remote_filename_0 = shell_module_0.get_remote_filename(file_name_strip_slash)
    assert remote_filename_0 == expected_powershell_filename_strip_slash
    remote_filename_0 = shell_module_0.get_remote_filename(file_name_strip_backslash)
    assert remote_filename_0 == expected_powershell_filename_strip_backslash

    # test for get_remote_filename leaves existing

# Generated at 2022-06-25 11:50:35.972411
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('\n# TEST: class ShellModule')
    shell_module_1 = ShellModule()
    assert shell_module_1.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_1.SHELL_FAMILY == 'powershell'
    assert shell_module_1._IS_WINDOWS == True


# Generated at 2022-06-25 11:50:38.500425
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = 'path'
    var_0 = shell_module_0.path_has_trailing_slash(var_0)



# Generated at 2022-06-25 11:50:39.632844
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print(shell_module_0)


# Generated at 2022-06-25 11:50:43.077903
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    str_0 = 'basefile'
    str_1 = 'tmpdir'
    str_2 = shell_module_0.mkdtemp(basefile=str_0, tmpdir=str_1)


# Generated at 2022-06-25 11:50:45.094542
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.join_path(None, '5', 'c', '5', '0/2')


# Generated at 2022-06-25 11:50:58.931161
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import os
    import re
    import shlex
    import pkgutil
    import xml.etree.ElementTree as ET
    import ntpath

    # var_0 = ShellModule()

    var_0 = ShellModule()
    var_1 = var_0.path_has_trailing_slash('/tmp')
    assert var_1

    var_1 = var_0.path_has_trailing_slash('/tmp/')
    assert var_1

    var_1 = var_0.path_has_trailing_slash('/tmp\\')
    assert not var_1

    var_1 = var_0.path_has_trailing_slash('/tmp\\\\')
    assert var_1


# Generated at 2022-06-25 11:51:07.727392
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert_equals(shell_module_0.COMPATIBLE_SHELLS, frozenset())
    assert_equals(shell_module_0.SHELL_FAMILY, 'powershell')
    assert_equals(shell_module_0.SHELL_TYPE, 'powershell')
    assert_equals(shell_module_0._IS_WINDOWS, True)
    assert_equals(shell_module_0._SHELL_REDIRECT_ALLNULL, '> $null')
    assert_equals(shell_module_0._SHELL_AND, ';')
# END Unit test for constructor of class ShellModule

# Generated at 2022-06-25 11:51:10.102004
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Test method arguments
    shell_module_0 = ShellModule()

    # Invoke method
    result = shell_module_0.mkdtemp()


# Generated at 2022-06-25 11:51:17.959001
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    try:
        shell_module_0.chown((), ())
    except NotImplementedError:
        pass
    try:
        shell_module_1.chown((), ())
    except NotImplementedError:
        pass



# Generated at 2022-06-25 11:51:19.209975
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:51:21.581368
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    if shell_module_1 is not None:
        pass
    else:
        return 1
    return 0



# Generated at 2022-06-25 11:51:23.858477
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash('testString')



# Generated at 2022-06-25 11:51:26.022768
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except:
        print('Exception raised expected')
    else:
        raise Exception('expected exception not raised')


# Generated at 2022-06-25 11:51:36.449780
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Test class initialization with valid arguments.

if __name__ == '__main__':
    import sys, os
    CWD = os.getcwd()
    sys.path.append(CWD)
    sys.path.append(os.path.join(CWD, 'ansible_collections/ansible/executor/powershell'))
    sys.path.append(os.path.join(CWD, 'ansible_collections/ansible/executor'))

    result = test_ShellModule()
    if result.failures:
        sys.exit(1)
    sys.exit(0)

# Generated at 2022-06-25 11:51:37.591035
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:51:41.782663
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()


# Generated at 2022-06-25 11:51:44.019292
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.shell_env_prefix()
    assert var_0 == ''


# Generated at 2022-06-25 11:51:52.441296
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # _compat_shell = set()
    # _file_transport = 'pscp'
    # _remote_tmp = '$env:TEMP'
    # _windows_shell = None
    # _winrm_dont_write_content_length = [u'Invoke-WebRequest', u'Invoke-RestMethod']
    # _winrm_plugin_options = ['winrm_become_user', 'winrm_become_password']
    assert shell_module_0._compat_shell == set()
    assert shell_module_0._file_transport == 'pscp'
    assert shell_module_0._remote_tmp == '$env:TEMP'
    assert shell_module_0._windows_shell == None
    assert shell_module_0._winrm

# Generated at 2022-06-25 11:51:59.968390
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset([])
    assert shell_module_0.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:52:02.324347
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    var_0 = shell_module_1.env_prefix()
    assert var_0 == ''

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:52:03.428435
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert not None



# Generated at 2022-06-25 11:52:07.410798
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module = ShellModule()
        assert isinstance(shell_module, ShellModule)
    except:
        print("Constructor of class ShellModule not working as expected")


# Generated at 2022-06-25 11:52:19.880600
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._ps_script_wrapper is None
    assert shell_module_0._shell._get_exec_wrapper is None
    assert shell_module_0._shell._rm_tmp_path is None
    assert shell_module_0._shell.DEFAULT_EXECUTABLE == 'powershell'
    assert shell_module_0._shell.DEFAULT_ARGS == '-noprofile -noninteractive -executionpolicy bypass -encodedcommand '
    assert shell_module_0._shell.HAS_PTY is False
    assert shell_module_0._shell.SHELL_FAMILY == 'powershell'
    assert shell_module_0._shell.COMPATIBLE_SHELLS == frozenset(['powershell'])
    assert shell_module_0

# Generated at 2022-06-25 11:52:24.723624
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module = ShellModule()

    # Constructor.
    assert(isinstance(shell_module, ShellBase))



# Generated at 2022-06-25 11:52:26.598164
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-25 11:52:34.534630
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:52:35.451117
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:52:36.896210
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return shell_module_0


# Generated at 2022-06-25 11:52:41.003924
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        assert True
    except:
        raise Exception('Assertion failed')


# Generated at 2022-06-25 11:52:44.260837
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:52:50.719793
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset(), 'Attribute `COMPATIBLE_SHELLS` of class `ShellModule` should be `frozenset()`'
    assert shell_module_0.SHELL_FAMILY == 'powershell', 'Attribute `SHELL_FAMILY` of class `ShellModule` should be `powershell`'
    assert shell_module_0._IS_WINDOWS == True, 'Attribute `_IS_WINDOWS` of class `ShellModule` should be `True`'


# Generated at 2022-06-25 11:52:56.822894
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Case #0
    args = [("ANSI_X3.4-1968")]
    shell_module_0 = ShellModule()
    shell_module_0.DEFAULT_TMP = "/tmp"

# Generated at 2022-06-25 11:52:58.102881
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:52:58.928710
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:06.012781
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # create an instance of the class ShellModule
    shell_module_0 = ShellModule()

    # get the result from calling build_module_command with the arguments below
    result = shell_module_0.build_module_command(env_string, shebang, cmd, arg_path)

    # compare the result to the expected one
    assert result == shell_module_0.shebang + " " + cmd, "Test failed."


# Generated at 2022-06-25 11:53:40.588799
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # case 0
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert not hasattr(shell_module, 'env_prefix')
    assert not hasattr(shell_module, 'join_path')
    assert not hasattr(shell_module, 'get_remote_filename')
    assert not hasattr(shell_module, 'path_has_trailing_slash')
    assert not hasattr(shell_module, 'chmod')
    assert not hasattr(shell_module, 'chown')
    assert not hasattr(shell_module, 'set_user_facl')
   

# Generated at 2022-06-25 11:53:46.111867
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_option('remote_tmp')# Type: string
    var_1 = shell_module_0.get_option('shell_type')# Type: string
    var_2 = shell_module_0.get_option('output_path')# Type: string


# Generated at 2022-06-25 11:53:47.043273
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule) == True


# Generated at 2022-06-25 11:53:48.497427
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0


# Generated at 2022-06-25 11:53:50.509194
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(isinstance(shell_module_0, ShellModule))


# Generated at 2022-06-25 11:53:56.019601
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert type(shell_module_0) == ShellModule

# Generated at 2022-06-25 11:54:06.487399
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule(**{'_executor': {'_loader': {'_connection_info': {}}}})
    with pytest.raises(AnsibleError):
        shell_module_0 = ShellModule(**{'_executor': {'_loader': {'_connection_info': {}}}})
        shell_module_0 = ShellModule(**{'_executor': {'_loader': {'_connection_info': {}}}})
    shell_module_0 = ShellModule()
    shell_module_0 = ShellModule(**{'_executor': {'_loader': {'_connection_info': {}}}})
    shell_module_0 = ShellModule(**{'_executor': {'_loader': {'_connection_info': {}}}})
    shell_module

# Generated at 2022-06-25 11:54:11.475045
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_test = ShellModule()
    # Make sure PowerShell version is at least version 2
    assert module_test.POWERSHELL_VERSION >= 2



# Generated at 2022-06-25 11:54:21.443310
# Unit test for constructor of class ShellModule
def test_ShellModule():

    obj = ShellModule()

    # test for inheritance
    assert issubclass(ShellModule, object), "Class ShellModule does not inherit from object."
    assert issubclass(ShellModule, ShellBase), "Class ShellModule does not inherit from ShellBase."

    # test for constructor attributes
    assert hasattr(obj, 'COMPATIBLE_SHELLS'), "Class ShellModule does not have the attribute COMPATIBLE_SHELLS."
    assert obj.COMPATIBLE_SHELLS == frozenset(), "Class ShellModule attribute COMPATIBLE_SHELLS has incorrect values."
    assert hasattr(obj, 'SHELL_FAMILY'), "Class ShellModule does not have the attribute SHELL_FAMILY."
    assert obj.SHELL_FAMILY == 'powershell', "Class ShellModule attribute SHELL_FAMILY has incorrect values."
   

# Generated at 2022-06-25 11:54:27.103568
# Unit test for constructor of class ShellModule
def test_ShellModule():
    func = ShellModule()
    assert isinstance(func, ShellModule)
    assert_equals(func.COMPATIBLE_SHELLS, frozenset())
    assert_equals(func.SHELL_FAMILY, 'powershell')
    assert func._IS_WINDOWS
    assert_equals(func._SHELL_REDIRECT_ALLNULL, '> $null')
    assert_equals(func._SHELL_AND, ';')


# Generated at 2022-06-25 11:54:57.313316
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert(ShellModule() != None)


# Generated at 2022-06-25 11:54:58.506566
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule.__init__.__doc__


# Generated at 2022-06-25 11:54:59.974618
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    print("ShellModule object shell_module_1 created")

# Generated at 2022-06-25 11:55:01.062944
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:02.898258
# Unit test for constructor of class ShellModule
def test_ShellModule():
    check_exec_output_0 = check_output_0()
    if (check_exec_output_0 != "1"):
        return -1
    return 0


# Generated at 2022-06-25 11:55:03.825651
# Unit test for constructor of class ShellModule
def test_ShellModule():
  # Create instance of class ShellModule
  shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:55:06.482022
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS is True


# Generated at 2022-06-25 11:55:17.104902
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_test = ShellModule()
    assert (shell_module_test.get_option('remote_tmp') == "")
    assert (shell_module_test.get_option('remote_uid') == "")
    assert (shell_module_test.get_option('datastore') == "")
    assert (shell_module_test.get_option('persistent_connect_timeout') == "")
    assert (shell_module_test.get_option('persistent_command_timeout') == "")
    assert (shell_module_test.get_option('become') == False)
    assert (shell_module_test.get_option('become_method') == "")
    assert (shell_module_test.get_option('become_user') == "")

# Generated at 2022-06-25 11:55:22.228268
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

    assert isinstance(shell_module_0, ShellBase) == True
    assert isinstance(shell_module_0._SHELL_REDIRECT_ALLNULL, str) == True
    assert isinstance(shell_module_0._SHELL_AND, str) == True
    assert isinstance(shell_module_0.COMPATIBLE_SHELLS, collections.Container) == True
    assert isinstance(shell_module_0.SHELL_FAMILY, str) == True
    assert isinstance(shell_module_0._IS_WINDOWS, bool) == True


# Generated at 2022-06-25 11:55:25.103400
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:56:17.322608
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._IS_WINDOWS == True

# Generated at 2022-06-25 11:56:18.489363
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:22.174725
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'


# Generated at 2022-06-25 11:56:31.279187
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Construct a args object for testing
    args_0 = {}
    args_0['env_string'] = 'env string'
    args_0['shebang'] = 'shebang'
    args_0['cmd'] = 'cmd'
    args_0['arg_path'] = 'arg path'

    # Construct a instance of class ShellModule for testing
    shell_module_0 = ShellModule()
    # Call method build_module_command of ShellModule on args_0
    return_value_0 = shell_module_0.build_module_command(**args_0)

    # Assert the return value is not None
    assert return_value_0 is not None


# Generated at 2022-06-25 11:56:36.275830
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.join_path('a', 'b')
    var_1 = shell_module_0.join_path('/a/b', 'c')
    var_2 = shell_module_0.join_path('/a/b/', 'c')
    var_3 = shell_module_0.get_remote_filename('a.ps1')
    var_4 = shell_module_0.get_remote_filename('a')
    var_5 = shell_module_0.get_remote_filename('a.sh')
    var_6 = shell_module_0.get_remote_filename('a.bat')
    var_7 = shell_module_0.path_has_trailing_slash('')
    var_8 = shell_

# Generated at 2022-06-25 11:56:38.970084
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellBase)



# Generated at 2022-06-25 11:56:40.265102
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:56:47.556089
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = ''

    # Test code
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset(), 'Expected: %s Actual: %s' % (frozenset(), shell_module_0.COMPATIBLE_SHELLS)
    assert shell_module_0.SHELL_FAMILY == 'powershell', 'Expected: %s Actual: %s' % ('powershell', shell_module_0.SHELL_FAMILY)
    assert shell_module_0._IS_WINDOWS == True, 'Expected: %s Actual: %s' % (True, shell_module_0._IS_WINDOWS)

    # Test code
    assert var_0 == '', 'Expected: %s Actual: %s' % ('', var_0)


# Generated at 2022-06-25 11:56:53.216538
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_mod = ShellModule()
    assert shell_mod.COMPATIBLE_SHELLS == frozenset()
    assert shell_mod.SHELL_FAMILY == 'powershell'
    assert shell_mod._IS_WINDOWS == True
    assert shell_mod._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_mod._SHELL_AND == ';'


# Generated at 2022-06-25 11:56:53.854905
# Unit test for constructor of class ShellModule
def test_ShellModule():

    var_0 = ShellModule()

