

# Generated at 2022-06-25 11:48:17.763181
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():

    shell_module_1 = ShellModule()
    path = shell_module_1.join_path(b'c:\\Users', b'\\Administrator', b'\\Ansible')
    assert path == 'c:\\Users\\Administrator\\Ansible'

    path = shell_module_1.join_path(b'//host/share/', b'subdir/')
    assert path == r'\\host\share\subdir'

    path = shell_module_1.join_path(b'//host/share', b'dir\\', b'\\fname.txt')
    assert path == r'\\host\share\dir\fname.txt'

    path = shell_module_1.join_path(b'//host/share/dir\\', b'\\dir2', b'fname.txt')
    assert path

# Generated at 2022-06-25 11:48:19.072511
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:48:20.538840
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Constructor
    test_case_0()


# Generated at 2022-06-25 11:48:24.553603
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ps = ShellModule()
    assert ps.__class__.__name__ == "ShellModule"
    assert hasattr(ps, 'join_path')
    assert hasattr(ps, 'checksum')
    assert hasattr(ps, 'chmod')

# Unit test to test the existence of functions

# Generated at 2022-06-25 11:48:25.844364
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:34.091276
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.task_result import TaskResult
    print('Executing test_ShellModule()')
    shell_module_0 = ShellModule()
    assert shell_module_0.get_option('remote_tmp') == '/tmp'
    shell_module_0.set_options({'remote_tmp': u'/tmp/'})
    assert shell_module_0.get_option('remote_tmp') == '/tmp/'
    shell_module_0 = ShellModule()
    assert shell_module_0.get_option('remote_tmp') == '/tmp'
    shell_module_0.set_options({'remote_tmp': u'/tmp/'})
    assert shell_module_0.get_option('remote_tmp') == '/tmp/'

# Generated at 2022-06-25 11:48:38.639406
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_1 = ShellModule()

    # Test with bad args
    assert shell_module_1.build_module_command(None, None, None) == "if(1){}; exit $LASTEXITCODE"
    assert shell_module_1.build_module_command("", "", "") == "if(1){}; exit $LASTEXITCODE"

    # Test with normal args
    assert shell_module_1.build_module_command("some env string", None, "some cmd") == "some env string\r\nsome cmd; exit $LASTEXITCODE"


# Generated at 2022-06-25 11:48:40.370667
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0



# Generated at 2022-06-25 11:48:51.948962
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:48:57.939008
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell_module_0 = ShellModule()
    shell_module_0._unquote = lambda x:x
    assert shell_module_0.join_path(r'C:\Program Files\Ansible',r'\Windows\System32\WindowsPowerShell\v1.0') == r'C:\Program Files\Ansible\Windows\System32\WindowsPowerShell\v1.0'
    assert shell_module_0.join_path(r'C:\\Program Files\\Ansible',r'\\Windows\\System32\\WindowsPowerShell\\v1.0') == r'C:\Program Files\Ansible\Windows\System32\WindowsPowerShell\v1.0'


# Generated at 2022-06-25 11:49:08.406440
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# Unit tests for the method ShellModule::env_prefix()

# Generated at 2022-06-25 11:49:16.626219
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_1 = ShellModule()

# Generated at 2022-06-25 11:49:26.081871
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.COMPATIBLE_SHELLS = (frozenset())
    assert shell_module_0.COMPATIBLE_SHELLS == (frozenset())
    shell_module_0.SHELL_FAMILY = 'powershell'
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    shell_module_0._IS_WINDOWS = True
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.env_prefix() == ''


# Generated at 2022-06-25 11:49:27.672921
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
    except Exception as e:
        assert False


# Generated at 2022-06-25 11:49:34.446761
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shebang = '#!powershell'
    cmd = '''$a = "1";'''
    module_path = 'some\\path'
    env_string = '$env:PATH = "path1";'

    shell_module = ShellModule()

    expected_result = '''& { $env:PATH = "path1";& { $a = "1";}; exit $LASTEXITCODE }; exit $LASTEXITCODE'''
    actual_result = shell_module.build_module_command(shebang, cmd, module_path, env_string)
    assert expected_result == actual_result


# Generated at 2022-06-25 11:49:36.273748
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class ShellModule
    test_ShellModule()

# Generated at 2022-06-25 11:49:38.771546
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None

# Generated at 2022-06-25 11:49:48.579449
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_1 = ShellModule()

# Generated at 2022-06-25 11:49:58.646507
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    print("Test - method path_has_trailing_slash")

    shell_module_1 = ShellModule()

    assert shell_module_1.path_has_trailing_slash(path="C:\\Program Files") == False, "Testcase Failed"
    assert shell_module_1.path_has_trailing_slash(path="C:\\Program Files\\") == True, "Testcase Failed"
    assert shell_module_1.path_has_trailing_slash(path="C:\\Program Files\\\\") == True, "Testcase Failed"
    assert shell_module_1.path_has_trailing_slash(path="C:\\Program Files\\\\") == True, "Testcase Failed"

# Generated at 2022-06-25 11:50:04.414100
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("test_ShellModule")
    test_case_0()
    print("test_ShellModule completed")

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:50:13.076239
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert(issubclass(ShellModule, ShellBase))

# Generated at 2022-06-25 11:50:17.999748
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    path = "C:\Windows\System32\drivers\etc"
    expected_result = False
    shell_module_0 = ShellModule()
    result = shell_module_0.path_has_trailing_slash(path)
    assert result == expected_result


# Generated at 2022-06-25 11:50:23.873886
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    print('Start Test for build_module_command...')
    shell_module = ShellModule()
    env_string = ''
    shebang = '#!powershell'
    cmd = '''
    $file = 'test.log'
    $path = 'C:\\Users\\Administrator\\Documents'
    $path = $path + '\\' + $file
    Add-Content $path "test"
    '''
    arg_path = None
    print('testing build_module_command()')
    actual_result = shell_module.build_module_command(env_string, shebang, cmd, arg_path)
    print(actual_result)
    print('End Test for build_module_command...')



# Generated at 2022-06-25 11:50:31.798277
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import imp

    path = os.path.join(os.path.dirname(__file__), "shell_windows.py")
    module = imp.load_source('shell_windows', path)

    shell_module_0 = ShellModule()

    assert shell_module_0.__class__.__name__ == 'ShellModule'
    assert module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:50:35.210551
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellBase) is True


# Generated at 2022-06-25 11:50:37.523523
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:45.909773
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()

    # Test case 1:
    # shebang: "#!powershell"
    # cmd: "type .\\a.ps1 | .\\bootstrap_wrapper.ps1"
    # arg_path: ""

# Generated at 2022-06-25 11:50:47.843434
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert ShellModule._IS_WINDOWS == True


# Generated at 2022-06-25 11:50:49.135853
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert 'class ShellModule'


# Generated at 2022-06-25 11:50:53.827200
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if shell_module_0._SHELL_REDIRECT_ALLNULL != '> $null':
        raise AssertionError
    if shell_module_0._SHELL_AND != ';':
        raise AssertionError


# Generated at 2022-06-25 11:51:01.111935
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    cwd = os.getcwd()
    path = ntpath.realpath(__file__)
    print(path)
    assert str(cwd) == str(test_expand_user)

# Generated at 2022-06-25 11:51:02.055872
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule



# Generated at 2022-06-25 11:51:05.719324
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    var_1 = shell_module_0.get_remote_filename(get_remote_filename)
    assert var_1 == get_remote_filename


# Generated at 2022-06-25 11:51:12.069135
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Testing for expected exceptions
    try:
        raise Exception('fail')
    except Exception:
        pass
    # Testing for expected return value
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)
    # Testing for expected return value
    shell_module_1 = ShellModule()
    assert isinstance(shell_module_1, ShellModule)
    # Testing for expected return value
    shell_module_2 = ShellModule()
    assert isinstance(shell_module_2, ShellModule)


# Generated at 2022-06-25 11:51:13.461055
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    var_0 = shell_get_remote_filename(shell_module_0)


# Generated at 2022-06-25 11:51:21.545990
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    assert shell_module_0.get_remote_filename('test_module.ps1') == 'test_module.ps1'
    assert shell_module_0.get_remote_filename('test_module') == 'test_module.ps1'
    assert shell_module_0.get_remote_filename('test_module.exe') == 'test_module.exe'
    assert shell_module_0.get_remote_filename('test module.exe') == 'test module.exe'


# Generated at 2022-06-25 11:51:25.456867
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    script_0 = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    shell_module_0 = ShellModule()
    remote_filename_0 = shell_module_0.get_remote_filename(script_0)
    assert remote_filename_0 == "bootstrap_wrapper.ps1"

# Generated at 2022-06-25 11:51:37.882627
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename('/etc/resolv.conf')
    var_1 = shell_module_0.get_remote_filename('/tmp/ansible')
    var_2 = shell_module_0.get_remote_filename('/tmp/ansible/')
    var_3 = shell_module_0.get_remote_filename('/tmp/ansible/shell.ps1')
    var_4 = shell_module_0.get_remote_filename('/tmp/ansible/shell.ps1.ps1')
    var_5 = shell_module_0.get_remote_filename('/tmp/ansible/shell.exe')

# Generated at 2022-06-25 11:51:43.156950
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = shell_path_has_trailing_slash(shell_module_0)

    # Return type assertion
    assert isinstance(var_0, bool)


# Generated at 2022-06-25 11:51:44.360930
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_path_has_trailing_slash()



# Generated at 2022-06-25 11:51:55.446320
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None, "ShellModule: object is not instantiated."
    assert shell_path_has_trailing_slash(shell_module) is None, "ShellModule: path_has_trailing_slash method is not implemented."
    assert shell_module.SHELL_FAMILY == 'powershell', "ShellModule: family is not inherited."
    assert shell_module.COMPATIBLE_SHELLS == frozenset(), "ShellModule: compatible shells is not inherited."



# Generated at 2022-06-25 11:51:56.564764
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:58.068537
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_0 = ShellModule()
    assert isinstance(module_0, ShellModule)


# Generated at 2022-06-25 11:52:01.546880
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Ensure that var_0 is not empty
    assert var_0 is not None
    # Ensure that var_0 is of valid type
    assert isinstance(var_0, bool)
    # Ensure that the value of the var_0 is correct
    assert var_0 == False


# Generated at 2022-06-25 11:52:03.540227
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.expand_user("~")
    assert var_0 == "Write-Output (Get-Location).Path"


# Generated at 2022-06-25 11:52:16.806726
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shebang_0 = shell_module_0.get_shebang('/usr/bin/python')
    shebang_1 = shell_module_0.get_shebang('/usr/bin/python2.7')
    shebang_2 = shell_module_0.get_shebang('/usr/bin/python3.6')
    shebang_3 = shell_module_0.get_shebang('/usr/bin/ruby')

    # Test with a path that is not present in the system
    shebang_4 = shell_module_0.get_shebang('/usr/bin/blahblah')

    # Test with a valid path that is present in the system
    shebang_5 = shell_module_0.get_shebang('/usr/bin/python')

   

# Generated at 2022-06-25 11:52:19.529858
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)


# Generated at 2022-06-25 11:52:30.802314
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert _common_args == ['PowerShell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Unrestricted']
    assert _parse_clixml(b'#< CLIXML\r\n<Objs') == b''
    assert _parse_clixml(b'<# CLIXML\r\n<# CLIXML\r\n<Objs') == b''
    assert _parse_clixml(b'<# CLIXML\r\n<# CLIXML\r\n<Objs/>') == b''
    assert _parse_clixml(b'<# CLIXML\r\n<# CLIXML\r\n<Objs><S S="Error">test</S></Objs>') == b'test'


# Generated at 2022-06-25 11:52:34.396387
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.__class__ is ShellModule



# Generated at 2022-06-25 11:52:35.924542
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_var = ShellModule()
    assert isinstance(shell_module_var, ShellModule)


# Generated at 2022-06-25 11:52:41.043259
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(shell_module_0 != None)

# Generated at 2022-06-25 11:52:42.167775
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert type(shell_module_1) == ShellModule


# Generated at 2022-06-25 11:52:43.048428
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:52:53.242196
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from shell_windows import ShellModule
    from textwrap import dedent
    import base64
    import ansible.executor.module_common

    # Stub for method join_path
    def join_path_stub(*args):
        return ''.join(args)

    # Stub for method _escape
    def _escape_stub(value):
        return value

    # Stub for method get_remote_filename
    def get_remote_filename_stub(pathname, extension=None):
        return pathname

    # Stub for method _exec_module

# Generated at 2022-06-25 11:53:04.954874
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.get_remote_filename("")
    assert shell_module_0.path_has_trailing_slash("")
    assert shell_module_0.mkdtemp("")
    assert shell_module_0.build_module_command("", "", "")
    assert shell_module_0.wrap_for_exec("")
    assert shell_module_0._encode_script("")
    assert shell_module_0.env_prefix()
    assert shell_module_0.expand_user("")
    assert shell_module_0.exists("")
    assert shell_module_0.checksum("")
    assert shell_module_0.remove("")
    assert shell_module_0.set_user_facl("", "", "")


# Generated at 2022-06-25 11:53:10.945382
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    str_0 = ''
    # operator overload for '!='
    assert shell_module_0 != shell_module_1


# Generated at 2022-06-25 11:53:15.082965
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:53:16.397058
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    import doctest

    doctest.testmod(verbose=True, report=True)

# Generated at 2022-06-25 11:53:22.369359
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Find out if the function can be called correctly
    user_home_path = '~/Downloads'
    username = ''
    shell_module_0 = ShellModule()
    assert shell_module_0.expand_user(user_home_path, username) is not None
    # Test exception handling of the function
    try:
        shell_module_0.expand_user(user_home_path, username)
    except Exception:
        assert False


# Generated at 2022-06-25 11:53:33.168077
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Path has a trailing slash.
    shell_module_0 = ShellModule()
    # Initialize test class
    path_0 = "'path/'".strip()
    # Call method
    result_check = shell_module_0.path_has_trailing_slash(path_0)
    assert result_check == 1
    # Path doesn't have a trailing slash.
    path_1 = "'path/'".strip()
    # Call method
    result_check = shell_module_0.path_has_trailing_slash(path_1)
    assert result_check == 0
    # Path has an absolute path.
    path_2 = "'/path/'".strip()
    # Call method
    result_check = shell_module_0.path_has_trailing_slash(path_2)
    assert result

# Generated at 2022-06-25 11:53:39.860179
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:53:42.765610
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # shell_module_0 = ShellModule()
    # assert_equal(shell_module_0.SHELL_FAMILY, 'powershell')
    pass

# Generated at 2022-06-25 11:53:44.056789
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:53:45.901526
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(shell_module_0 is not None)


# Generated at 2022-06-25 11:53:50.322660
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None, "Constructor of class ShellModule returned a NULL object"


# Generated at 2022-06-25 11:53:56.725979
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert_equal(ShellModule._SHELL_REDIRECT_ALLNULL, shell_module_0._SHELL_REDIRECT_ALLNULL)
    assert_equal('powershell', shell_module_0._SHELL_FAMILY)
    assert_equal(True, shell_module_0._IS_WINDOWS)
    assert_equal(ShellModule.COMPATIBLE_SHELLS, shell_module_0.COMPATIBLE_SHELLS)
    assert_equal(ShellModule._SHELL_AND, shell_module_0._SHELL_AND)



# Generated at 2022-06-25 11:54:00.380275
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_path_has_trailing_slash(shell_module_0)



# Generated at 2022-06-25 11:54:03.557272
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    if os.name == 'nt':
        shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:54:05.919830
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module = ShellModule()
    user_home_path = '~'
    username = ''
    result = shell_module.expand_user(user_home_path, username)
    assert type(result) == str

# Generated at 2022-06-25 11:54:16.457313
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Try to call constructor with no argument
    shell_module_0 = None
    try:
        shell_module_0 = ShellModule()
    except TypeError:
        pass

    # Call constructor with arguments

# Generated at 2022-06-25 11:54:28.642765
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.getsupported_shell_type()


# Generated at 2022-06-25 11:54:29.671270
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:30.815051
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:54:37.808777
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Assert that the constructor of class ShellModule has succeeded by checking if the member variables of the class ShellModule written to the output console
    assert shell_module_0.SHELL_FAMILY == 'powershell' and shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:54:43.983622
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

    var_0 = shell_module_0.env_prefix()
    assert var_0 == ""

    var_1 = shell_module_0.join_path("E:\\")
    assert var_1 == "E:\\"

    var_2 = shell_module_0.join_path(" ")
    assert var_2 == " "


# Generated at 2022-06-25 11:54:46.417084
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module


# Generated at 2022-06-25 11:54:51.347541
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True

# Generated at 2022-06-25 11:54:53.595428
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename(pathname = "\\\\", )


# Generated at 2022-06-25 11:55:00.036471
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.expand_user('~')
    var_1 = shell_module_0.expand_user('~\\')
    var_2 = shell_module_0.expand_user('~\\filename')
    var_3 = shell_module_0.expand_user('C:\\Users\\user1\\filename')


# Generated at 2022-06-25 11:55:06.645042
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves.urllib.request import Request, urlopen
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common._collections_compat import Set
    tmp = Connection()
    tmp_conn = tmp.exec_command('abcd')
    tmp_connector = tmp.get_connector()

# Generated at 2022-06-25 11:55:19.673232
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None

# Unit tests for verifying attributes of class ShellModule
#

# Generated at 2022-06-25 11:55:20.409083
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:55:21.749690
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return


# Generated at 2022-06-25 11:55:23.468087
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:55:33.282444
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # check if the object is an instance
    assert isinstance(shell_module_0, ShellModule)
    # check if object attributes are related to powershell
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS is True
    # assert the object has been properly initialized
    assert shell_module_0.SHELL_PATH
    assert shell_module_0.SHELL_SEP



# Generated at 2022-06-25 11:55:35.969676
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)


if __name__ == '__main__':
    test_case_0()
    test_ShellModule()

# Generated at 2022-06-25 11:55:43.075144
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    var_0 = (shell_module_0.get_remote_filename() == shell_module_1.get_remote_filename())
    var_1 = (shell_module_0.env_prefix() == shell_module_1.env_prefix())
    var_2 = (shell_module_0.join_path() == shell_module_1.join_path())
    var_3 = (shell_module_0.chmod() == shell_module_1.chmod())
    var_4 = (shell_module_0.chown() == shell_module_1.chown())
    var_5 = (shell_module_0.set_user_facl() == shell_module_1.set_user_facl())
    var_

# Generated at 2022-06-25 11:55:44.356415
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert True


# Generated at 2022-06-25 11:55:45.906009
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:55:47.841319
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-25 11:55:56.210356
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test body would go here
    assert True == True

# Generated at 2022-06-25 11:56:07.182508
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Instantiation of class ShellModule with no argument
    shell_module_0 = ShellModule()
    # Constructor all arguments
    # shell_module_0 = ShellModule(connection=connection, module_name=module_name, task_uuid=task_uuid, wrap_async=wrap_async, no_log=no_log, shebang=shebang, terminal_stdout_path=terminal_stdout_path, terminal_stderr_path=terminal_stderr_path, tmp=tmp, common=common, sudo_user=sudo_user, executable=executable, su=su, su_user=su_user, su_exe=su_exe, become_ask_pass=become_ask_pass, become_exe=become_exe, become_flags=become_flags, become_method=become_method

# Generated at 2022-06-25 11:56:08.465621
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert type(shell_module_0) == ShellModule


# Generated at 2022-06-25 11:56:10.812251
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.export_env_to_child()
    assert type(shell_module_0) is ShellModule



if __name__ == '__main__':
    test_case_0()
    test_ShellModule()

# Generated at 2022-06-25 11:56:12.337808
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:56:15.933208
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print(ShellModule())

# Generated at 2022-06-25 11:56:16.659576
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()



# Generated at 2022-06-25 11:56:18.816991
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
        return shell_module_0
    except Exception as e:
        print (e)
        return


# Generated at 2022-06-25 11:56:19.648758
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()


# Generated at 2022-06-25 11:56:25.115257
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test for constructor of class ShellModule
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:47.608119
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:56:48.334291
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass



# Generated at 2022-06-25 11:56:53.095846
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.env_prefix()
    # Assert
    var_1 = shell_module_0.get_remote_filename()
    #Assert
    var_0 = shell_module_0.exists(var_1)


# Generated at 2022-06-25 11:56:57.367148
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module
    assert shell_module._IS_WINDOWS == True
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'

# TODO
#Unit test for _parse_clixml
#Unit test for env_prefix
#Unit test for join_path
#Unit test for get_remote_filename


# Generated at 2022-06-25 11:57:00.234751
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule) == True


# Generated at 2022-06-25 11:57:04.093724
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.get_remote_filename() == ''
    assert shell_module_0.get_option() == ''
    assert shell_module_0.join_path() == ''
    assert shell_module_0.path_has_trailing_slash() == False
    assert shell_module_0.checksum() == ''


# Generated at 2022-06-25 11:57:06.394592
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:57:08.210653
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

    return shell_module_0


# Generated at 2022-06-25 11:57:12.420136
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:57:16.639632
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.SHELL_FAMILY == 'powershell'



# Generated at 2022-06-25 11:57:38.830112
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.version(shell_module_0)


# Generated at 2022-06-25 11:57:44.623017
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert len(shell_module.COMPATIBLE_SHELLS) == 0
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS


# Generated at 2022-06-25 11:57:48.862453
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:57:52.340013
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)


# Generated at 2022-06-25 11:57:53.146124
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:57:59.173615
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print("Test: shell_add_command_to_end() ...")
    var_0 = shell_add_command_to_end(shell_module_0)
    print("Test: shell_join_path() ...")
    var_1 = shell_join_path(shell_module_0)
    print("Test: shell_split_path() ...")
    var_2 = shell_split_path(shell_module_0)
    print("Test: shell_path_has_trailing_slash() ...")
    var_3 = shell_path_has_trailing_slash(shell_module_0)
    print("Test: shell_expand_user() ...")
    var_4 = shell_expand_user(shell_module_0)