

# Generated at 2022-06-25 11:48:09.540766
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module = ShellModule()
    assert shell_module.get_remote_filename('/tmp/test.py') == 'test.py'
    assert shell_module.get_remote_filename('/tmp/test.ps1') == 'test.ps1'



# Generated at 2022-06-25 11:48:11.530582
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename('encoded_script')


# Generated at 2022-06-25 11:48:14.807312
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    shell_module_0.get_remote_filename()



# Generated at 2022-06-25 11:48:17.553008
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:24.267379
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with a shell_class of CMD
    obj = ShellModule(connection='connection', shell_class='CMD')

    # Test with a shell_class of PSRP
    obj = ShellModule(connection='connection', shell_class='PSRP')

    # Test with a shell_class of WINRM
    obj = ShellModule(connection='connection', shell_class='WINRM')

    # Test with a shell_class of SSH
    obj = ShellModule(connection='connection', shell_class='SSH')

    # Test with no shell_class
    obj = ShellModule(connection='connection')


# Generated at 2022-06-25 11:48:25.090117
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    print("")


# Generated at 2022-06-25 11:48:31.049951
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.env_prefix()
    assert ' ' in var_0
    assert '!' in var_0
    assert '-' in var_0
    assert '.' in var_0
    assert '/' in var_0
    var_0 = shell_module_0.join_path()
    assert ' ' in var_0
    assert '!' in var_0
    assert '-' in var_0
    assert '.' in var_0
    assert '/' in var_0
    var_0 = shell_module_0.get_remote_filename()
    assert ' ' in var_0
    assert '!' in var_0
    assert '-' in var_0
    assert '.' in var_0
    assert '/' in var_0
    var_

# Generated at 2022-06-25 11:48:32.562849
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(isinstance(shell_module_0, ShellModule))

# Generated at 2022-06-25 11:48:36.966064
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module._IS_WINDOWS == True



# Generated at 2022-06-25 11:48:39.260411
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename()


# Generated at 2022-06-25 11:48:47.608048
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import json
    import pkgutil
    from ansible.executor.task_result import TaskResult
    from ansible.executor.action_result import ActionResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_context = {}
    play_context['heuristic'] = None
    play_context['become'] = False

# Generated at 2022-06-25 11:48:51.342106
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:48:52.301139
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# Generated at 2022-06-25 11:48:58.917662
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Constructor of class ShellModule
    shell_module_0 = ShellModule()
    # Check if the private variable '_SHELL_REDIRECT_ALLNULL' is equal to '> $null'
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    # Check if the private variable '_SHELL_AND' is equal to ';'
    assert shell_module_0._SHELL_AND == ';'
    # Check if the private variable '_IS_WINDOWS' is equal to True
    assert shell_module_0._IS_WINDOWS == True
    # Check if the type of the private variable 'COMPATIBLE_SHELLS' is frozenset
    assert type(shell_module_0.COMPATIBLE_SHELLS) is frozenset
    return


# Generated at 2022-06-25 11:49:08.622549
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    """
    Test case for expand_user
    """
    shell_module_0 = ShellModule()
    assert shell_module_0.expand_user("~") == shell_module_0._encode_script("""Write-Output (Get-Location).Path""")
    assert shell_module_0.expand_user("~/") == shell_module_0._encode_script("""Write-Output (Get-Location).Path""")
    assert shell_module_0.expand_user("~\\") == shell_module_0._encode_script("""Write-Output ((Get-Location).Path + '\\')""")
    assert shell_module_0.expand_user("~/ansible") == shell_module_0._encode_script("""Write-Output ((Get-Location).Path + '\\ansible')""")

# Generated at 2022-06-25 11:49:11.333366
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()



# Generated at 2022-06-25 11:49:13.501186
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("Testing method constructor of class ShellModule")
    shell_module = ShellModule()
    param_str = shell_module.env_prefix()
    assert param_str == "", "Wrong Environment prefix"


# Generated at 2022-06-25 11:49:17.854015
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module = ShellModule()
    assert shell_module != None

    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'



# Generated at 2022-06-25 11:49:21.324474
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_1 = ShellModule()
    path_has_trailing_slash_0 = shell_module_1.path_has_trailing_slash('/')
    assert path_has_trailing_slash_0


# Generated at 2022-06-25 11:49:32.614461
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    assert(shell_module_0.path_has_trailing_slash("/root") == False)
    assert(shell_module_0.path_has_trailing_slash("/root/") == False)
    assert(shell_module_0.path_has_trailing_slash("/root\\") == False)
    assert(shell_module_0.path_has_trailing_slash("root/") == True)
    assert(shell_module_0.path_has_trailing_slash("root\\") == True)
    assert(shell_module_0.path_has_trailing_slash("root") == False)
    assert(shell_module_0.path_has_trailing_slash("/root\\\\") == False)

# Generated at 2022-06-25 11:49:39.933470
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:49:47.506162
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
    except Exception as e:
        print("Test case 0: FAILED")
        print(e)
        raise
    print("Test case 0: SUCCESS")


if __name__ == "__main__":
    try:
        test_ShellModule()

    except Exception as e:
        raise

    print("ALL TESTS SUCCESS")

# Generated at 2022-06-25 11:49:50.898975
# Unit test for constructor of class ShellModule
def test_ShellModule():
    instance = ShellModule()
    assert isinstance(instance, ShellModule)

# Unit tests for env_prefix of class ShellModule

# Generated at 2022-06-25 11:49:59.326972
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:50:03.631808
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:50:08.263862
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
        if shell_module_0 == None:
            raise Exception("cannot create class ShellModule")
        else:
            print("create ShellModule class successful")
    except Exception as e:
        print("Exception in creating class ShellModule")
        print(str(e))


# Generated at 2022-06-25 11:50:10.680473
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule


# Generated at 2022-06-25 11:50:15.422163
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    if shell_module is not None:
        print("TestCase22: ShellModule is not None")
    if not shell_module:
        print("TestCase23: ShellModule is not None")
    if shell_module:
        print("TestCase24: ShellModule is not None")


# Generated at 2022-06-25 11:50:19.029423
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert(ShellModule.COMPATIBLE_SHELLS == frozenset())
    assert(ShellModule.SHELL_FAMILY == 'powershell')
    assert(ShellModule._IS_WINDOWS == True)


# Generated at 2022-06-25 11:50:24.213256
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Variables for the constructor of class ShellModule
    module_0 = None

    # Instatiation of object ShellModule
    shell_module_0 = ShellModule(module_0)
    # These tests validate that the class constructor of ShellModule is working. It should not raise any exceptions
    test_case_0()


# Generated at 2022-06-25 11:50:29.797003
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:31.099253
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:32.337537
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:50:42.697286
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.build_module_command(None, None, '', None)
    shell_module_0._unquote(None)
    shell_module_0._escape(None)
    shell_module_0._encode_script(None, False, False, False)
    shell_module_0.checksum(None, None, None)
    shell_module_0.set_user_facl(None, None, None)
    shell_module_0.wrap_for_exec(None)
    shell_module_0.chmod(None, None)
    shell_module_0.get_remote_filename(None)
    shell_module_0.remove(None, False)
    shell_module_0.env_prefix(None)

# Generated at 2022-06-25 11:50:44.218057
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.shebang is None
    assert shell_module_0.cmd is None


# Generated at 2022-06-25 11:50:48.606050
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print("Class(ShellModule): {0}".format(shell_module_0))
    print("ShellModule: {0}".format(shell_module_0.SHELL_FAMILY))
    print("ShellModule: {0}".format(dir(shell_module_0)))
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:50:51.638398
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.join_path() == '', 'Unexpected result for ShellModule()'



# Generated at 2022-06-25 11:50:54.506438
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # just exercising the class for now
    shell_0 = ShellModule()


# Generated at 2022-06-25 11:50:55.682792
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:51:01.021000
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Replace ansible.module_utils.basic.AnsibleModule.run_command with mock_run_command
    module_utils.basic.AnsibleModule.run_command = mock_run_command

    shell_module = ShellModule()
    shell_module.build_module_command("env_string", "shebang", "cmd", "arg_path")

    assert("shebang cmd arg_path" == last_command[4])


# Generated at 2022-06-25 11:51:08.109096
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_join_path()
    return var_0


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:51:10.147746
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename()


# Generated at 2022-06-25 11:51:14.223544
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    pass


# Generated at 2022-06-25 11:51:17.790694
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._IS_WINDOWS



# Generated at 2022-06-25 11:51:18.526988
# Unit test for constructor of class ShellModule
def test_ShellModule():

  # Call constructor
  ShellModule()



# Generated at 2022-06-25 11:51:19.797330
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:23.565714
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Local declarations
    shell_module_0 = ShellModule()
    env_string = ''
    shebang = ''
    cmd = ''
    arg_path = ''
    var_0 = shell_module_0.build_module_command(env_string, shebang, cmd, arg_path)


# Generated at 2022-06-25 11:51:28.132492
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        assert shell_module.__init__ != None
        assert shell_module != None
        assert (shell_module.COMPATIBLE_SHELLS == frozenset())
        assert shell_module.SHELL_FAMILY == 'powershell'
        assert shell_module._IS_WINDOWS == True
        assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    except Exception as e:
        print("Exception found: ", e)



# Generated at 2022-06-25 11:51:29.727695
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_join_path()


# Generated at 2022-06-25 11:51:31.358463
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.build_module_command("setup", "", "", "/bin/ping")


# Generated at 2022-06-25 11:51:42.834538
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    # AssertionError: AssertionError: frozenset() != frozenset(['powershell'])
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.get_remote_filename(pathname='') == '.ps1'
    assert shell_module_0.path_has_trailing_slash(path='') == False
    assert shell_module_0.env_prefix() == ''
    assert shell_module_0.join_path('') == ''
    assert shell_module_0.join_path('', '') == ''
    assert shell_module

# Generated at 2022-06-25 11:51:46.007545
# Unit test for constructor of class ShellModule
def test_ShellModule():
    original_shell_module_1 = ShellModule()
    shell_module_0 = ShellModule()

    command_0 = shell_module_0._encode_script('', False, False, False)

    command_1 = shell_module_0._encode_script('', False, False, False)


# Generated at 2022-06-25 11:51:47.771770
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename()



# Generated at 2022-06-25 11:51:52.290882
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_0 = to_bytes('#!/bin/bash\n')
    var_1 = to_bytes('/usr/bin/python')
    var_2 = 'my_arg_path'
    var_3 = shell_module_0.build_module_command(var_0, var_1, var_2)


# Generated at 2022-06-25 11:51:57.883529
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    for test_1 in [0]:
        shell_module_0 = ShellModule()
        var_0 = shell_module_0.build_module_command('', '', '', '')


# Generated at 2022-06-25 11:52:00.509808
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.__class__.__bases__[0].__name__ == 'ShellBase'



# Generated at 2022-06-25 11:52:07.128866
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()

    # test ansible.module_utils.powershell.bootstrap_wrapper.ps1
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")

    # test method with path = 'C:\\Users\\Test\\AppData\\Local\\Temp\\ansible-tmp-1537128417.48-231089076722254\\ansible_modlib.ps1',
    tmp_path = 'C:\\Users\\Test\\AppData\\Local\\Temp\\ansible-tmp-1537128417.48-231089076722254\\ansible_modlib.ps1'
    shebang = '#!powershell'

# Generated at 2022-06-25 11:52:08.423089
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:10.950109
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:52:12.717395
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:19.565823
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print(shell_module_0)


# Generated at 2022-06-25 11:52:27.925215
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._IS_WINDOWS
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'



# Generated at 2022-06-25 11:52:30.075427
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1.__class__.__name__ == 'ShellModule'


# Generated at 2022-06-25 11:52:40.039242
# Unit test for method build_module_command of class ShellModule

# Generated at 2022-06-25 11:52:42.192990
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Setup
    shell_module_0 = ShellModule()

    # Testing
    var_0 = shell_module_0.build_module_command()



# Generated at 2022-06-25 11:52:47.278093
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:52:58.185567
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Initialize class
    shell_module = ShellModule()
    # Create a string with value 'ansible.module_utils.powershell._ps1_1'
    shebang = 'ansible.module_utils.powershell._ps1_1'
    # Create a string with value 'hello'
    cmd = 'hello'
    # Create a string with value 'ansible.module_utils.powershell._ps1_1'
    shebang = 'ansible.module_utils.powershell._ps1_1'
    # Create a string with value 'hello'
    cmd = 'hello'
    res = shell_module.build_module_command(env_string, shebang, cmd)
    if res:
        sys.exit(0)
    else:
        sys.exit(1)



# Generated at 2022-06-25 11:53:03.923713
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Create a ShellModule object
    shell_module_0 = ShellModule()

    # Call method build_module_command
    ret = shell_module_0.build_module_command()

    # Assertions
    assert ret is None
    assert False


# Generated at 2022-06-25 11:53:10.783471
# Unit test for constructor of class ShellModule
def test_ShellModule():
    """Arguments: 'self'
    Variable in test: shell_module_0
    Variable in test: shell_join_path_0
    """
    shell_module_0 = ShellModule()
    assert shell_module_0.__class__.__bases__[0].__name__ == 'ShellBase'

# Generated at 2022-06-25 11:53:16.667612
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Test file and shebang are not provided
    shell_module = ShellModule()
    cmd_result = shell_module.build_module_command("env_string","#!","command")
    assert(cmd_result.startswith('& '))
    assert(cmd_result.endswith('exit $LASTEXITCODE'))
    # Test file and shebang are provided
    shell_module = ShellModule()
    cmd_result = shell_module.build_module_command("env_string","#!","command",arg_path = "file")
    assert(cmd_result.startswith('& '))
    assert(cmd_result.endswith('exit $LASTEXITCODE'))



# Generated at 2022-06-25 11:53:22.717587
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:29.489721
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    shell_module_2 = ShellModule()

    cmd_0 = shell_module_0.build_module_command()
    cmd_1 = shell_module_1.build_module_command()
    cmd_2 = shell_module_2.build_module_command()

# Generated at 2022-06-25 11:53:32.752472
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:34.810620
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:39.630378
# Unit test for constructor of class ShellModule
def test_ShellModule():
    for _ in range(100000):
        shell_module_0 = ShellModule()
        get_remote_filename()
        env_prefix()
        path_has_trailing_slash()
        checksum()
        join_path()
        chmod()
        chown()
        expand_user()
        mkdtemp()
        set_user_facl()
        remove()
        build_module_command()
        wrap_for_exec()
        exists()


# Generated at 2022-06-25 11:53:43.535875
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    script = shell_module.build_module_command(script='', shebang='#!powershell', cmd='', arg_path='')
    assert script.startswith('&')


# Generated at 2022-06-25 11:53:46.112117
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # initialization of the ShellModule object
    shell_module_0 = ShellModule()
    # assertions
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:53:47.856760
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:53:49.072737
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()



# Generated at 2022-06-25 11:53:50.487465
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except SystemExit:
        pass


# Generated at 2022-06-25 11:53:57.445064
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.join_path()


# Generated at 2022-06-25 11:54:01.565845
# Unit test for constructor of class ShellModule
def test_ShellModule():
    #try 1:
    assert ShellModule()
    #try 2:
    assert ShellModule()


# Generated at 2022-06-25 11:54:05.339005
# Unit test for constructor of class ShellModule
def test_ShellModule():
    log_info('Test start for construction of ShellModule')
    try:
        shell_module_0 = ShellModule()
    except Exception as e:
        log_error(e.message)
        log_error('Test failed for construction of ShellModule')
        pass
    else:
        log_info('Test passed for construction of ShellModule')


# Generated at 2022-06-25 11:54:06.984570
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule(None, shells=None, exe=None, command_timeout=None)



# Generated at 2022-06-25 11:54:10.965364
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._IS_WINDOWS



# Generated at 2022-06-25 11:54:16.384710
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0_0 = ShellModule()
    shell_module_0_1 = ShellModule()
    shell_module_0_1.set_shell_options('command_terminators', '>', ';', '\\')
    shell_module_0_1.set_shell_options('chmod_special_cases', 'chmod', 'chown')
    shell_module_0_1.set_shell_options('delete_remote_tmp', False)
    shell_module_0_1.set_shell_options('remote_tmp', '~/.ansible/tmp')
    shell_module_0_1.set_shell_options('stdin_add_newline', True)
    shell_module_0_1.set_shell_options('send_special_vars', True)

# Generated at 2022-06-25 11:54:17.446288
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass


# Generated at 2022-06-25 11:54:17.992557
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ShellModule()

# Generated at 2022-06-25 11:54:26.790081
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        cmd = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
        # test if cmd is base64 encoded
        if to_text(base64.b64encode(cmd.encode('utf-16-le'))) != cmd:
            return False

        if cmd.strip() != to_text(base64.b64decode(cmd), 'utf-16-le').strip():
            return False
    except:
        return False
    return True



# Generated at 2022-06-25 11:54:29.869281
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_0 = "winrm"
    var_1 = "#!powershell"
    var_2 = "ping -n 2 127.0.0.1"
    shell_module_0.build_module_command(var_0, var_1, var_2)

# Generated at 2022-06-25 11:54:40.921506
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Assert that .COMPATIBLE_SHELLS is a frozenset
    assert isinstance(ShellModule.COMPATIBLE_SHELLS, frozenset)
    # Assert that .SHELL_FAMILY is a string
    assert isinstance(ShellModule.SHELL_FAMILY, str)
    # Assert that ._IS_WINDOWS is a boolean
    assert isinstance(ShellModule._IS_WINDOWS, bool)


# Generated at 2022-06-25 11:54:42.700975
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return shell_module_0


# Generated at 2022-06-25 11:54:44.305470
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("Testing ShellModule constructor")
    shell_module_0 = ShellModule()
    assert(shell_module_0 is not None)


# Generated at 2022-06-25 11:54:47.532046
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module != None, 'Failed to create ShellModule object.'


# Generated at 2022-06-25 11:54:52.369203
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.build_module_command()
    var_1 = shell_module_0.checksum()
    var_2 = shell_module_0.chmod()
    var_3 = shell_module_0.chown()
    var_4 = shell_module_0.env_prefix()
    var_5 = shell_module_0.exists()
    var_6 = shell_module_0.expand_user()
    var_7 = shell_module_0.join_path()
    var_8 = shell_module_0.mkdtemp()
    var_9 = shell_module_0.path_has_trailing_slash()
    var_10 = shell_module_0.remove()
    var_11 = shell_module_

# Generated at 2022-06-25 11:54:59.935576
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(len(shell_module_0.COMPATIBLE_SHELLS) == 0) and \
        (shell_module_0.SHELL_FAMILY == 'powershell') and \
        (shell_module_0._IS_WINDOWS == True) and \
        (shell_module_0.env_prefix() == '')
test_ShellModule()


# Generated at 2022-06-25 11:55:05.587381
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # testing with bad input
    try:
        shell_module_0 = ShellModule(5.5, 6.5)
    except:
        assert False

    # testing with good input
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None


# Generated at 2022-06-25 11:55:11.858478
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    try:
        assert_equal(isinstance(shell_module_0, ShellModule), True)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 11:55:13.931041
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:15.523075
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.shebang == '#!powershell'



# Generated at 2022-06-25 11:55:23.469028
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print(shell_module_0)


# Generated at 2022-06-25 11:55:28.029605
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:33.900107
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0.COMPATIBLE_SHELLS.__len__() == 0



# Generated at 2022-06-25 11:55:40.855323
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename("")
    var_1 = shell_module_0.build_module_command("", "", "", "")
    var_2 = shell_module_0.mkdtemp("")
    var_3 = shell_module_0.expand_user("", "")
    var_4 = shell_module_0.checksum("", "", "", "", "", "", "", "", "", "")
    var_5 = shell_module_0.remove("", False)
    var_6 = shell_module_0.exists("")


# Generated at 2022-06-25 11:55:44.232448
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1


# Generated at 2022-06-25 11:55:46.371430
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule() # Constructor
    assert isinstance(shell_module_0, ShellModule) == True


# Generated at 2022-06-25 11:55:48.533323
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:50.177520
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0


# Generated at 2022-06-25 11:55:52.356007
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:55.514625
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'


# Generated at 2022-06-25 11:56:13.196624
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_0 = ShellModule()
    assert isinstance(module_0, ShellModule) == True


# Generated at 2022-06-25 11:56:17.612737
# Unit test for constructor of class ShellModule
def test_ShellModule():
    case_1 = ShellModule()
    case_2 = ShellModule()
    assert case_1 == case_2


# Generated at 2022-06-25 11:56:19.066419
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:56:20.718552
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert (isinstance(shell_module_0, ShellModule))


# Generated at 2022-06-25 11:56:30.904712
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0
    var_0 = shell_module_0.join_path()
    shell_module_0.normalize_path()
    shell_module_0.expand_user()
    shell_module_0.path_has_trailing_slash()
    shell_module_0.chmod()
    shell_module_0.chown()
    shell_module_0.set_user_facl()
    shell_module_0.remove()
    shell_module_0.mkdtemp()
    shell_module_0.exists()



# Generated at 2022-06-25 11:56:33.096983
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._shell_type == 'powershell', "shell_module_0._shell_type == 'powershell'"
    assert shell_module_0._IS_WINDOWS is True, "shell_module_0._IS_WINDOWS is True"


# Generated at 2022-06-25 11:56:34.872320
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:56:39.193741
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    return shell_module


# Generated at 2022-06-25 11:56:49.668539
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

    print(shell_module_0.get_remote_filename())
    print(shell_module_0.checksum())
    print(shell_module_0.env_prefix())
    print(shell_module_0.set_user_facl())
    print(shell_module_0.mkdtemp())
    print(shell_module_0.build_module_command())
    print(shell_module_0.remove())
    print(shell_module_0.expand_user())
    print(shell_module_0.wrap_for_exec())
    print(shell_module_0.exists())
    print(shell_module_0.chown())
    print(shell_module_0.chmod())



# Generated at 2022-06-25 11:56:54.141571
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # For Check
    with open('./test/unit/executor/powershell/join_path/test_case_0.txt', 'r') as f:
        expected = f.read()
    output = shell_join_path()
    assert output == expected


# Generated at 2022-06-25 11:58:02.650524
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.env_prefix()
    var_1 = shell_module_0.join_path()
    var_2 = shell_module_0.join_path()
    var_3 = shell_module_0.join_path()
    var_4 = shell_module_0.join_path()
    var_5 = shell_module_0.join_path()
    var_6 = shell_module_0.join_path()
    var_7 = shell_module_0.join_path()
    var_8 = shell_module_0.join_path()
    var_9 = shell_module_0.join_path()
    var_10 = shell_module_0.join_path()
    var_11 = shell_module_0.join