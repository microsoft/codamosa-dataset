

# Generated at 2022-06-25 11:48:19.210451
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    assert shell_module.path_has_trailing_slash('C:\\')
    assert not shell_module.path_has_trailing_slash('C:\\SomePath')
    assert shell_module.path_has_trailing_slash('C:\\SomePath\\')
    assert not shell_module.path_has_trailing_slash('C:\\SomePath\\file.txt')
    assert shell_module.path_has_trailing_slash('C:\\SomePath\\file.txt\\')

    # Test with forward slashes
    assert shell_module.path_has_trailing_slash('C:/')
    assert not shell_module.path_has_trailing_slash('C:/SomePath')
    assert shell_module.path_has_trailing_sl

# Generated at 2022-06-25 11:48:24.426476
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    result = shell_module_0.mkdtemp()
    assert result == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmp'
        Write-Output -InputObject $tmp.FullName
        '''


# Generated at 2022-06-25 11:48:26.418325
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_1 = ShellModule()
    assert shell_module_1.mkdtemp() is not None



# Generated at 2022-06-25 11:48:30.142180
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:48:32.683006
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module = ShellModule()

    user_home_path = '~\Temp'
    username = ''
    shell_module.expand_user(user_home_path, username)


# Generated at 2022-06-25 11:48:37.757677
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
# No error
    shell_module_0.expand_user(user_home_path='~/bin', username='')



# Generated at 2022-06-25 11:48:40.097218
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    assert shell_module_0.mkdtemp() is not None


# Generated at 2022-06-25 11:48:43.990993
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_1 = ShellModule()
    assert shell_module_1.get_remote_filename("/tmp/foo.sh") == "foo.sh"
    assert shell_module_1.get_remote_filename("/tmp/foo") == "foo.ps1"


# Generated at 2022-06-25 11:48:46.029213
# Unit test for constructor of class ShellModule
def test_ShellModule():
    case_0 = test_case_0
    case_0()

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:48:56.459567
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shmod = ShellModule()
    env_string = '$env:TESTVAR = "TESTVALUE"'
    shebang = '#!powershell'
    cmd = 'Get-ChildItem'
    arg_path = None

# Generated at 2022-06-25 11:49:13.022910
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    configdata = dict()
    configdata['module_name'] = 'win_file'

# Generated at 2022-06-25 11:49:13.827695
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()


# Generated at 2022-06-25 11:49:20.772689
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()

    # Testing a string that starts with "~"
    test_1 = shell_module_0.expand_user('~test/test1')
    assert test_1 == shell_module_0._encode_script('Write-Output (Get-Location).Path + "test/test1"')

    # Testing a string that starts with "~\"
    test_2 = shell_module_0.expand_user('~\\test2')
    assert test_2 == shell_module_0._encode_script('Write-Output (Get-Location).Path + "\\test2"')

    # Testing a string that does not start with ~
    test_3 = shell_module_0.expand_user('test3')

# Generated at 2022-06-25 11:49:26.212671
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0._IS_WINDOWS, bool)
    assert shell_module_0._IS_WINDOWS
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:49:29.513143
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    temp = ShellModule()
    assert temp.get_remote_filename("example.ps1") == "example.ps1"


# Generated at 2022-06-25 11:49:39.933935
# Unit test for method expand_user of class ShellModule

# Generated at 2022-06-25 11:49:45.693305
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    M = 'C:\\Program Files\\MySQL\\MySQL Server 5.5'
    C = 'M'
    assert shell_module_0.expand_user(M, '') == C


# Generated at 2022-06-25 11:49:47.343532
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:49:53.126325
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_1 = ShellModule()
    pathname = "/tmp/abc.txt"
    out_1 = shell_module_1.get_remote_filename(pathname)
    assert out_1 == "abc.txt", "Failed to get remote filename"
    assert out_1 is not None, "Failed to get remote filename"


# Generated at 2022-06-25 11:49:57.356922
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    path = 'C:\\\\'
    assert shell_module_0.path_has_trailing_slash(path) == True
    path = 'C:\\\\test'
    assert shell_module_0.path_has_trailing_slash(path) == False
#TODO: test module argument: mode


# Generated at 2022-06-25 11:50:11.383679
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_1 = ShellModule()
    user_home_path_1 = 'c:\\test'
    assert shell_module_1.expand_user(user_home_path_1) == shell_module_1._encode_script("Write-Output 'c:\\test'")

    shell_module_2 = ShellModule()
    user_home_path_2 = '~\\test'
    assert shell_module_2.expand_user(user_home_path_2) == shell_module_2._encode_script("Write-Output ((Get-Location).Path + '\\test')")

    shell_module_3 = ShellModule()
    user_home_path_3 = '~'
    assert shell_module_3.expand_user(user_home_path_3) == shell_module_3._en

# Generated at 2022-06-25 11:50:17.680672
# Unit test for constructor of class ShellModule
def test_ShellModule():

    print("test_ShellModule: starting")

    shell_module = ShellModule()

    if shell_module == None:
        print("test_ShellModule: Failed to instantiate ShellModule")
        fail
    else:
        print("test_ShellModule: instantiated ShellModule")
        pass

    del shell_module

    print("test_ShellModule: exiting")


# Generated at 2022-06-25 11:50:22.185036
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    assert shell_module_0.expand_user(user_home_path='~/abc') == '''Write-Output ((Get-Location).Path + '\\abc')'''


# Generated at 2022-06-25 11:50:25.297813
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()

    # Check for namespace
    assert shell_module_1.SHELL_FAMILY == 'powershell'



# Generated at 2022-06-25 11:50:32.258838
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()

    assert shell_module_0.path_has_trailing_slash('C:/Program Files/My Folder/') == True
    assert shell_module_0.path_has_trailing_slash('C:\\Program Files\\My Folder\\') == True
    assert shell_module_0.path_has_trailing_slash('./') == True
    assert shell_module_0.path_has_trailing_slash('..\\') == True


# Generated at 2022-06-25 11:50:42.613207
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    shell_module_1 = ShellModule()
    env_string = "ThisIsTheEnv"
    shebang = "#!"
    cmd = "This is the command"
    arg_path = "This is the arg"
    returned_value = shell_module_1.build_module_command(env_string, shebang, cmd, arg_path)

# Generated at 2022-06-25 11:50:43.388330
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()


# Generated at 2022-06-25 11:50:49.609568
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module.env_prefix() == ""
    assert shell_module.join_path("a","b") == ntpath.join("a","b")
    assert shell_module.get_remote_filename("file.exe") == "file.exe"
    assert shell_module.get_remote_filename("file") == "file.ps1"
    assert shell_module.path_has_trailing_slash("/abc/") == True
    assert shell_module.path_has_trailing_slash("/abc") == False
    assert shell_module.path_has_tra

# Generated at 2022-06-25 11:50:54.287376
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:50:55.751130
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 11:51:01.635183
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert TEST_CASE_0 == shell_module_0.__init__()



# Generated at 2022-06-25 11:51:11.768630
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_1 = ShellModule()

    cmd = '"C:\Windows\System32\WindowsPowerShell\\v1.0\powershell.exe"; exit $lastexitcode'

# Generated at 2022-06-25 11:51:15.149565
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'



# Generated at 2022-06-25 11:51:18.148417
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module


# Generated at 2022-06-25 11:51:19.687223
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:51:21.161099
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:31.115850
# Unit test for method build_module_command of class ShellModule

# Generated at 2022-06-25 11:51:35.963189
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    path_has_trailing_slash = shell_module_0.path_has_trailing_slash("/home/ubuntu/output/")
    assert path_has_trailing_slash == True


# Generated at 2022-06-25 11:51:40.514551
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_cmd_0 = "powershell.exe"
    shell_options_0 = " -NoProfile -NonInteractive -ExecutionPolicy Unrestricted"
    shell_module_0 = ShellModule(
        command_name=shell_cmd_0, command_options=shell_options_0)
    assert shell_module_0.command_name == shell_cmd_0
    assert shell_module_0.command_options == shell_options_0

# Unit tests for method ShellModule.env_prefix of class ShellModule

# Generated at 2022-06-25 11:51:42.071244
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None

# Generated at 2022-06-25 11:51:51.180368
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# Validating our documentation example:
import ansible.modules.system.setup
if __name__ == '__main__':
    success, total = ansible.modules.system.setup.main()
    print('SUCCESS: %i out of %i' % (success, total))

# Generated at 2022-06-25 11:51:57.699053
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with default kwargs
    shell_module_0 = ShellModule()

    # Test with default kwargs, but with a different display name
    shell_module_1 = ShellModule(display_name="shell_module_1")



# Generated at 2022-06-25 11:52:02.435945
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0._IS_WINDOWS
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
# END unit test for constructor of class ShellModule


# Generated at 2022-06-25 11:52:05.373204
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    #assert shell_module_0.SHELL_FAMILY == 'powershell'
    #assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:52:12.838649
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    expected = shell_module_0._encode_script(script=pkgutil.get_data('ansible.executor.powershell', 'bootstrap_wrapper.ps1'), strict_mode=False, preserve_rc=False)
    actual = shell_module_0.build_module_command('', '', '')
    print("expected: %s" % expected)
    print("actual: %s" % actual)
    assert expected == actual


# Generated at 2022-06-25 11:52:23.393722
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    cmd = 'import-module ansiblecommon; import-module ansible.executor.powershell; '
    cmd += 'try { write-output ([System.Text.Encoding]::UTF8.GetString(([Convert]::FromBase64String((Invoke-Expression -Command $args[1]).trim())))); } catch { "ERROR!"; exit 1; }'
    cmd += 'exit $LASTEXITCODE'
    cmd_parts = ['PowerShell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Unrestricted', '-Command', cmd]
    assert shell_module_0._encode_script(script='write-output "Hello world"') == ' '.join(cmd_parts)
    print('test_ShellModule passed')


# Generated at 2022-06-25 11:52:24.722078
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:26.611417
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:31.114060
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    if shell_module is not None:
        print("Constructor for class ShellModule is working.")
    else:
        print("Constructor for class ShellModule is not working.")


# Generated at 2022-06-25 11:52:34.740053
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass
    #test_case_0()

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:52:40.507705
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    # Unit test for class ShellModule
    test_ShellModule()

# Generated at 2022-06-25 11:52:50.556158
# Unit test for constructor of class ShellModule
def test_ShellModule():
    role_name = "httpd"
    job_name = "ansible-httpd"
    user_name = "chris"
    command = "ansible-httpd"
    excludes = ["~/.ansible"]
    roles_path = "home/roles"
    job_id = "123"
    shell = ShellModule(role_name=role_name, job_name=job_name, user_name=user_name, command=command, excludes=excludes, roles_path=roles_path, job_id=job_id)
    assert shell.role_name == "httpd"
    assert shell.job_name == "ansible-httpd"
    assert shell.user_name == "chris"
    assert shell.command == "ansible-httpd"

# Generated at 2022-06-25 11:52:54.668116
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_0 = ''
    var_1 = ''
    var_2 = ''
    var_3 = 'arg_path'
    shell_module_0.build_module_command(var_0,var_1,var_2,var_3)


# Generated at 2022-06-25 11:52:56.691620
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_env_prefix()

# Generated at 2022-06-25 11:53:04.624671
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module0_env_string = ''
    module0_shebang = ''
    module0_cmd = 'aws_ec2 --version'
    module0_arg_path = None
    shell_module_0 = ShellModule()
    shell_module_0.get_option = lambda x: '/home/shiv/ansible'
    var_0 = shell_module_0.build_module_command(module0_env_string, module0_shebang, module0_cmd, module0_arg_path)


# Generated at 2022-06-25 11:53:15.516066
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from shell_windows import ShellModule
    from ansible.module_utils._text import to_bytes, to_text
    import shlex

    shell_module_0 = ShellModule()

    # Check default value for strict_mode
    assert shell_module_0.strict_mode is True

    # Check default value for preserve_rc
    assert shell_module_0.preserve_rc is True

    # Call method get_remote_filename()
    var_0 = shell_module_0.get_remote_filename('pathname')

    # Check value of var_0
    assert var_0 == 'pathname.ps1'

    # Call method get_remote_filename()
    var_0 = shell_module_0.get_remote_filename('pathname.ps1')

    # Check value of var_0

# Generated at 2022-06-25 11:53:16.926152
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:53:24.960140
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_0 = ShellModule()
    var_0 = module_0.__class__._generate_temp_dir_name()
    module_0.COMPATIBLE_SHELLS = frozenset()
    var_1 = module_0.__class__.COMPATIBLE_SHELLS
    module_0.SHELL_FAMILY = 'powershell'
    var_2 = module_0.__class__.SHELL_FAMILY
    var_3 = module_0.__class__._IS_WINDOWS
    var_4 = shell_env_prefix(**{'module_0': module_0})
    var_5 = module_0._encode_script(**{'script': ' '})
    var_6 = module_0._escape(**{'value': ' '})
    var_7 = module

# Generated at 2022-06-25 11:53:31.787810
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    arg_0 = 'variable_0'
    arg_1 = None
    arg_2 = 'variable_2'
    arg_3 = None
    arg_4 = 'variable_4'
    arg_5 = None
    arg_6 = 'variable_6'
    arg_7 = 'variable_7'
    arg_8 = 'variable_8'
    arg_9 = None
    arg_10 = 'variable_10'
    arg_11 = None
    arg_12 = 'variable_12'
    arg_13 = None
    arg_14 = 'variable_14'
    var_0 = shell_module_0.build_module_command(arg_0, arg_1, arg_2, arg_3)
    var_1 = shell_module_0.checksum

# Generated at 2022-06-25 11:53:33.493495
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, object)


# Generated at 2022-06-25 11:53:53.193017
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.env_prefix()
    var_1 = shell_module_0.join_path()
    var_2 = shell_module_0.join_path()
    var_3 = shell_module_0.join_path()
    var_4 = shell_module_0.join_path()
    var_5 = shell_module_0.join_path()
    var_6 = shell_module_0.join_path()
    var_7 = shell_module_0.join_path()
    var_8 = shell_module_0.join_path()
    var_9 = shell_module_0.join_path()
    var_10 = shell_module_0.join_path()
    var_11 = shell_module_0.join

# Generated at 2022-06-25 11:53:59.507244
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:54:01.656460
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = ShellModule()
    assert isinstance(var_0, ShellModule) == True


# Generated at 2022-06-25 11:54:05.596711
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Invalid parameters should be handled.
    # Test for exception.
    try:
        var_0 = shell_env_prefix()
    except Exception as err:
        raise AssertionError("Test raised unexpected exception error: %s" % err)
    else:
        # Test successful no exception raised.
        pass


# Generated at 2022-06-25 11:54:06.707093
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module


# Generated at 2022-06-25 11:54:14.830754
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    as_null_0 = test_pop_none()
    as_array_0 = test_pop_none()
    var_0 = shell_env_prefix()
    str_0 = test_pop_none()
    str_1 = test_pop_none()
    str_2 = test_pop_none()
    var_1 = shell_module_0.build_module_command(var_0, str_0, str_1, str_2)


# Generated at 2022-06-25 11:54:17.715317
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellBase)


# Generated at 2022-06-25 11:54:22.001139
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0
    var_0 = shell_env_prefix()
    return var_0

# Generated at 2022-06-25 11:54:22.772884
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass


# Generated at 2022-06-25 11:54:26.757666
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    var_0 = str(shell_module_1)
    assert var_0 == '<ansible.plugins.shell.powershell.ShellModule object at 0x7f8fad57a050>'



# Generated at 2022-06-25 11:54:48.280621
# Unit test for constructor of class ShellModule
def test_ShellModule():
    args_0 = {}
    test_case_0(args_0)


# Generated at 2022-06-25 11:54:53.339260
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()

    env_string = ""
    shebang = "#!powershell"
    cmd = "Test"
    arg_path = "Test"
    result = shell_module.build_module_command(env_string, shebang, cmd, arg_path)
    print(result)


# Generated at 2022-06-25 11:54:57.550650
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test case #0
    assert test_case_0() == '', 'test_case_0()#1 failed'

test_ShellModule()

# Generated at 2022-06-25 11:54:58.760935
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:03.510337
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert isinstance(obj, ShellModule)


# Generated at 2022-06-25 11:55:06.829040
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename('/home')
    var_1 = shell_module_0.join_path('/home', 'ansible', 'module.py')
    assert var_0 == 'module.py'
    assert var_1 == '/home\\ansible\\module.py'


# Generated at 2022-06-25 11:55:11.620351
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Call ShellModule() and check that it throws no exception
    try:
        ShellModule()
    except Exception:
        assert False, 'Unable to instantiate class ShellModule'



# Generated at 2022-06-25 11:55:14.302463
# Unit test for constructor of class ShellModule
def test_ShellModule():
    p = ShellModule()
    assert type(p.COMPATIBLE_SHELLS) == frozenset
    assert type(p.SHELL_FAMILY) == str
    assert type(p._IS_WINDOWS) == bool


# Generated at 2022-06-25 11:55:22.228258
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Make sure shell module is of class ShellModule
    assert shell_module_0.__class__.__name__ == 'ShellModule'
    # Make sure it is of type ShellBase
    assert isinstance(shell_module_0, ShellBase)
    # Make sure it is of type object
    assert isinstance(shell_module_0, object)

    # Test that environment prefix is empty and has a length of 0
    assert shell_module_0.env_prefix() == ''
    assert len(shell_module_0.env_prefix()) == 0

    # Test that the dictionary of env variables is empty and has 0 length
    assert len(shell_module_0.no_log_values) == 0
    assert not shell_module_0.no_log_values



# Generated at 2022-06-25 11:55:23.427677
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:37.285867
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test default constructor
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:38.090804
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    pass


# Generated at 2022-06-25 11:55:44.376354
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if (not hasattr(shell_module_0, '_SHELL_REDIRECT_ALLNULL')):
        return 1
    if (not hasattr(shell_module_0, '_SHELL_AND')):
        return 1
    if (not hasattr(shell_module_0, '_IS_WINDOWS')):
        return 1
    if (not hasattr(shell_module_0, '_encode_script')):
        return 1
    if (not hasattr(shell_module_0, 'build_module_command')):
        return 1
    if (not hasattr(shell_module_0, 'checksum')):
        return 1
    if (not hasattr(shell_module_0, 'chmod')):
        return 1

# Generated at 2022-06-25 11:55:49.655452
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:55:51.951552
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:54.607411
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'


# Generated at 2022-06-25 11:55:55.940539
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:55:57.791595
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:55:59.343017
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        var_0 = ShellModule()
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-25 11:56:10.110945
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    list_1 = _common_args
    cmd_text_1 = shell_module_1.wrap_for_exec(' '.join(list_1))
    assert cmd_text_1 == u"& PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted; exit $LASTEXITCODE"

    # Create a PowerShell command line by stringing together the args in `_common_args`
    cmd_text_2 = shell_module_1._encode_script('')
    assert cmd_text_2 == u"& PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command -"

    cmd_text_3 = shell_module_1._encode_script('Invoke-Command')

# Generated at 2022-06-25 11:56:49.261690
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:50.493997
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Unit test for method __init__
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:53.663519
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:56:54.432986
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass


# Generated at 2022-06-25 11:56:59.548405
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:57:01.398876
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None, 'ShellModule instance not created'


# Generated at 2022-06-25 11:57:05.197753
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-25 11:57:09.172443
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
# test the inherited methods
    assert(isinstance(obj, ShellBase))

if __name__ == '__main__':
    setattr(__builtins__, '__openstack_ansible_debug', True)
    if len(sys.argv)>2:
        vars()[sys.argv[1]](*sys.argv[2:])
    else:
        vars()[sys.argv[1]]()

# Generated at 2022-06-25 11:57:15.993594
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:57:16.913949
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
