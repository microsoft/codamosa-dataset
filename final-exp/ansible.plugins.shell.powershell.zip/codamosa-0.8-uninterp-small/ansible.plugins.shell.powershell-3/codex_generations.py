

# Generated at 2022-06-25 11:48:12.623632
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # set and fetch remote_tmp
    shell_module_0 = ShellModule()
    shell_module_0.remote_tmp = '/var/tmp'
    assert shell_module_0.remote_tmp == '/var/tmp', 'Wrong remote_tmp'


# Generated at 2022-06-25 11:48:14.208906
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:25.344992
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    assert shell_module.path_has_trailing_slash(path="/path/to/somewhere/") == True
    assert shell_module.path_has_trailing_slash(path="/path/to/somewhere") == False
    assert shell_module.path_has_trailing_slash(path="C:\\path\\to\\somewhere\\") == True
    assert shell_module.path_has_trailing_slash(path="C:\\path\\to\\somewhere") == False
    assert shell_module.path_has_trailing_slash(path="/path/to\\somewhere") == False  # Escaped backslash is not a trailing slash

# Generated at 2022-06-25 11:48:29.178831
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    shell_module_1 = ShellModule()
    if PY3:
        data = '$str = "this is a test string"\r\n$str\r\n'
    else:
        data = '$str = "this is a test string"\r\n$str\r\n'
    result = shell_module_1.get_remote_filename(data).strip()
    expected = 'test_string'
    assert result == expected

# Unit tests for method join_path of class ShellModule

# Generated at 2022-06-25 11:48:32.709569
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():

    _shell = ShellModule()
    _shell.get_remote_filename('/home/user/test.sh')
    try:
        _shell.get_remote_filename('/home/user/test.sh')
        assert(False)
    except NotImplementedError:
        assert(True)


# Generated at 2022-06-25 11:48:38.349469
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # create an object of the class ShellModule
    shell_module_1 = ShellModule()
    # compare type of the object with the ShellModule class
    assert isinstance(shell_module_1, ShellModule)


# Generated at 2022-06-25 11:48:40.098032
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert type(shell_module_0) == ShellModule

# Generated at 2022-06-25 11:48:44.853818
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert_true( "set_user_facl is not implemented for Powershell" in repr(shell_module_1.set_user_facl))
    assert_true( "chown is not implemented for Powershell" in repr(shell_module_1.chown))
    assert_true( "chmod is not implemented for Powershell" in repr(shell_module_1.chmod))
    assert_equal(shell_module_1.COMPATIBLE_SHELLS, frozenset())
    assert_equal(shell_module_1.SHELL_FAMILY, 'powershell')
    assert_equal(shell_module_1._IS_WINDOWS, True)
    assert_true( "exists is not implemented for Powershell" in repr(shell_module_1.exists))

#

# Generated at 2022-06-25 11:48:50.351732
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    result = shell_module_0.path_has_trailing_slash("C:\\test")
    print("test_ShellModule_path_has_trailing_slash() returned: " + str(result))
    assert(type(result) == bool)


# Generated at 2022-06-25 11:48:51.697004
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Constructor
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:49:07.530559
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    print("\n{0}".format(test_ShellModule_build_module_command.__name__))

    shell_module_1 = ShellModule()

    # Case 0.
    env_string_0 = "envVar0=Test_Environment_Var0"
    shebang_0 = "#!powershell"
    cmd_0 = "Test_Command_0"
    arg_path_0 = "Test_Arg_Path_0"

# Generated at 2022-06-25 11:49:15.192767
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    user_home_path_0 = '~'
    var_0 = shell_module_0.expand_user(user_home_path_0, username='')
    assert var_0 == b'Write-Output (Get-Location).Path'


# Generated at 2022-06-25 11:49:28.030721
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module = ShellModule()
    assert shell_module.get_remote_filename('test_script.ps1') == 'test_script.ps1'
    assert shell_module.get_remote_filename('C:\test_script.ps1') == 'test_script.ps1'
    assert shell_module.get_remote_filename('C:\test_script.ps1              ') == 'test_script.ps1'
    assert shell_module.get_remote_filename('C:\test_script') == 'test_script.ps1'
    assert shell_module.get_remote_filename('C:\test_script              ') == 'test_script.ps1'
    assert shell_module.get_remote_filename('C:\test_script.exe') == 'test_script.exe'
    assert shell_module.get_remote_

# Generated at 2022-06-25 11:49:31.172808
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:49:38.737536
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_1 = ShellModule()
    var_1 = 'C:\Windows\Temp\ansible-tmp-1516099201.48-157047662212398\powershellModule.ps1'
    expected_1 = 'powershellModule.ps1'
    var_2 = 'C:\Windows\Temp\ansible-tmp-1516099201.48-157047662212398\powershellModule'
    expected_2 = 'powershellModule.ps1'
    var_3 = 'C:\Windows\Temp\ansible-tmp-1516099201.48-157047662212398\powershellModule.exe'
    expected_3 = 'powershellModule.exe'
    assert_1 = shell_module_1.get_remote_filename(var_1)
    assert_2 = shell_module_

# Generated at 2022-06-25 11:49:40.670363
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellBase)
    assert isinstance(shell_module, ShellModule)


# Generated at 2022-06-25 11:49:51.456709
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    # Create a temporary file for use with the method
    tf = tempfile.NamedTemporaryFile(mode="w+b")
    # Write some data to the temporary file
    tf.write(b"This is some data\n")
    # Ensure writable buffer is written to file system
    tf.flush()
    # Seek to start of file
    tf.seek(0, 0)

    # Create another temporary file for use with the method
    fd, arg_path = tempfile.mkstemp()
    os.close(fd)

    # Call the method
    results = shell_module.build_module_command(env_string="env", shebang="#!powershell", cmd=tf.name, arg_path=arg_path)

    # Check the results
    assert results



# Generated at 2022-06-25 11:49:54.081576
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Test case 1: tilde is root
    # Result: Full path to root folder
    path = "~"
    shell_module_1 = ShellModule()
    result = shell_module_1.expand_user(path)

    expected_result = "Write-Output (Get-Location).Path"
    assert result == expected_result


# Generated at 2022-06-25 11:49:59.807067
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    assert shell_module_0.expand_user("~", "user_name") == shell_module_0._encode_script("Write-Output (Get-Location).Path")
    assert shell_module_0.expand_user("~\\user_name", "user_name") == shell_module_0._encode_script("Write-Output ((Get-Location).Path + '\\user_name')")
    assert shell_module_0.expand_user("~\\", "user_name") == shell_module_0._encode_script("Write-Output ((Get-Location).Path + '\\')")
    assert shell_module_0.expand_user("~abc", "user_name") == shell_module_0._encode_script("Write-Output '~abc'")
   

# Generated at 2022-06-25 11:50:04.023084
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    # TODO: Implement test for class constructor


# Generated at 2022-06-25 11:50:10.715859
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()



# Generated at 2022-06-25 11:50:12.778884
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1.get_name() == 'powershell'


# Generated at 2022-06-25 11:50:14.514097
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:50:23.668908
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_1 = ShellModule()
    result_0 = shell_module_1.build_module_command('', '', '', '')
    result_1 = shell_module_1.build_module_command('', '#!powershell', '', '')
    result_2 = shell_module_1.build_module_command('', '#!python -f', '', '')
    result_3 = shell_module_1.build_module_command('', '', 'dir ', '')
    result_4 = shell_module_1.build_module_command('', '', 'dir', '')
    result_5 = shell_module_1.build_module_command('', '', 'type', 'file_0')

# Generated at 2022-06-25 11:50:26.597451
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # test code goes here
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    my_path = shell_module_0.mkdtemp(basefile="my_path")
    print(my_path)


# Generated at 2022-06-25 11:50:31.014788
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()
    try:
        for attr in ShellModule._parameter_cache.keys():
            print(attr)
    except Exception as e:
        print(e)

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:50:36.089622
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0.PATH_SEP == ';'


# Generated at 2022-06-25 11:50:37.614559
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:50:38.873249
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:50:43.039819
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule(connection='ssh', no_log=True, keep_remote_files=True, module_implementation_preferences=None)
    assert shell_module_1.SHELL_FAMILY is None
    assert shell_module_1._SHELL_REDIRECT_ALLNULL is None
    assert shell_module_1._SHELL_AND is None
    assert shell_module_1._IS_WINDOWS is True


# Generated at 2022-06-25 11:50:51.808524
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_1 = ShellModule()
    var_1 = shell_module_1.build_module_command(None, None, None, None)
    assert '$' in var_1


# Generated at 2022-06-25 11:50:53.460800
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_2 = ShellModule()
    if not isinstance(shell_module_2, ShellModule):
        print("Class ShellModule is not instance of ShellModule")
        raise Exception("ShellModule test failed")


# Generated at 2022-06-25 11:50:54.918264
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert str(shell_module).__contains__('ShellModule')


# Generated at 2022-06-25 11:50:56.663227
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_2 = ShellModule()
    var_1 = shell_module_2.mkdtemp(False, False)


# Unit test

# Generated at 2022-06-25 11:51:01.020950
# Unit test for constructor of class ShellModule
def test_ShellModule():
  shell_module_4 = ShellModule()
  print('test_ShellModule')
  print(shell_module_4.COMPATIBLE_SHELLS)
  print(shell_module_4._IS_WINDOWS)

if __name__ == '__main__':
  test_case_0()

  test_ShellModule()

# Generated at 2022-06-25 11:51:11.005440
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    shell_module_0._encode_script(script='')

    env_string, shebang, cmd, arg_path = '','','',''
    shell_module_0.build_module_command(env_string, shebang, cmd, arg_path)

    shell_module_3 = ShellModule()
    shell_module_3._encode_script(script=None)

    env_string, shebang, cmd, arg_path = '','','',''
    shell_module_3.build_module_command(env_string, shebang, cmd, arg_path)

    shell_module_6 = ShellModule()
    shell_module_6._encode_script(script=1)

    env_string, shebang, cmd, arg_path = '','','',''
   

# Generated at 2022-06-25 11:51:14.029117
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()



# Generated at 2022-06-25 11:51:17.796176
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule(None)


# Generated at 2022-06-25 11:51:19.280938
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:51:23.649704
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_2 = ShellModule()
    env_string = u'env_string'
    shebang = u'shebang'
    cmd = u'cmd'
    arg_path = u'arg_path'
    var_1 = shell_module_2.build_module_command(env_string, shebang, cmd, arg_path)

# Generated at 2022-06-25 11:51:29.791777
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:51:32.253397
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if not isinstance(shell_module_0, ShellModule):
        raise RuntimeError('Failed to create instance of class ShellModule')
    if not isinstance(shell_module_0, object):
        raise RuntimeError('Failed to inherit object')

# Test case 1 for method build_module_command()

# Generated at 2022-06-25 11:51:34.561075
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_2 = ShellModule()
    assert shell_module_2 is not None, "ShellModule constructor failed"


# Generated at 2022-06-25 11:51:44.285014
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    m = ShellModule()
    method_return_value_0 = m.build_module_command('', '', '', None)
    method_return_value_1 = m.build_module_command('', '#!powershell', '', None)
    method_return_value_2 = m.build_module_command('', '#!/bin/python', '', None)
    # TODO: The lines below should be uncommented when the _unquote method is implemented
    # method_return_value_3 = m.build_module_command('', '', '"module"', None)
    # method_return_value_4 = m.build_module_command('', '', 'module', None)


# Generated at 2022-06-25 11:51:45.926703
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

# Generated at 2022-06-25 11:51:47.101937
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:51:48.746374
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:51:49.956132
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:51:53.997937
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # AssertionError if the command is not a string
    with pytest.raises(AssertionError):
        cmd = 42
        shell_module_0.build_module_command(cmd='', shebang='#!', cmd='cmd')
    # TemplateNotFound Exception if the script is not found in the package
    with pytest.raises(TemplateNotFound) as excinfo:
        script = 'bootstrap_wrapper'
        shell_module_0._encode_script(script)
    assert "bootstrap_wrapper" in str(excinfo.value)


# Generated at 2022-06-25 11:51:55.648901
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()



# Generated at 2022-06-25 11:52:00.914404
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None




# Generated at 2022-06-25 11:52:02.361808
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('Executing constructor')
    shell = ShellModule()
    assert shell is not None


# Generated at 2022-06-25 11:52:05.732211
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        assert ShellModule
    except NameError:
        print("Class ShellModule does not exist")
        return
    try:
        shell_module_0 = ShellModule()
        assert shell_module_0
    except NotImplementedError:
        print("Class ShellModule is not implemented")
        return
    else:
        print("Class ShellModule is implemented")


# Generated at 2022-06-25 11:52:06.856665
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module



# Generated at 2022-06-25 11:52:10.541313
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    #test_case_0(shell_module_0)

test_ShellModule()

# Generated at 2022-06-25 11:52:13.289920
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    shell_module.__class__.__name__ == 'ShellModule'



# Generated at 2022-06-25 11:52:16.416631
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.checksum()
    var_1 = shell_module_0.join_path()


# Generated at 2022-06-25 11:52:18.967420
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    if shell_module is None:
        print('Failed to create an instance of ShellModule!')


# Generated at 2022-06-25 11:52:20.044093
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return


# Generated at 2022-06-25 11:52:27.498952
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Add your test code here.
    s = ShellModule()
    assert_equals(s.get_option('chdir'), None)

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(ShellModuleTest))
    unittest.TextTestRunner().run(suite)

# Generated at 2022-06-25 11:52:40.922084
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_1 = 'bootstrap_wrapper.ps1'
    # Check if the wrapped module command is a valid pipeline mode command (i.e. has the form 'module_name | bootstrap_wrapper.ps1').
    result = shell_module_0.build_module_command('', '', '', var_1)
    assert result[:21] == 'type  | bootstrap_wrapper'


# Generated at 2022-06-25 11:52:43.048904
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_expand_user(shell_module_0)
    print(var_0)


# Generated at 2022-06-25 11:52:46.734432
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert 'cmd' == shell_module_0._SHELL_REDIRECT_ALLNULL
    assert ';' == shell_module_0._SHELL_AND
    assert True == shell_module_0._IS_WINDOWS


# Generated at 2022-06-25 11:52:57.426016
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert_equal(shell_module_0.get_remote_filename(), 'ansible_module_%s.ps1' % (shell_module_0))
    assert_equal(shell_module_0.get_remote_filename(), 'ansible_module_%s.ps1' % (shell_module_0))
    assert_equal(shell_module_0.get_remote_filename(), 'ansible_module_%s.ps1' % (shell_module_0))
    assert_equal(shell_module_0.get_remote_filename(), 'ansible_module_%s.ps1' % (shell_module_0))

# Generated at 2022-06-25 11:53:00.222883
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except Exception as exception_0:
        print('Traceback (most recent call last):')
        print(repr(exception_0))


# Generated at 2022-06-25 11:53:01.800858
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:53:08.845865
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Make sure the function to expand user is properly created
    assert hasattr(ShellModule, "expand_user")

    # Make sure the module does not contain important variables
    shell_module_0 = ShellModule()
    assert not hasattr(shell_module_0, "_SHELL_REDIRECT_ALLNULL")
    assert not hasattr(shell_module_0, "_SHELL_AND")


# Generated at 2022-06-25 11:53:11.600795
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_expand_user(shell_module_0)
    assert var_0 == "Write-Output '\\$HOME'"


# Generated at 2022-06-25 11:53:23.084464
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Test the method join_path of class ShellModule
    var_0 = shell_module_0.join_path(to_bytes('/var'), to_bytes(''), to_bytes('/file.txt'))
    var_1 = shell_module_0.join_path(to_bytes('/var/path///'), to_bytes('/file.txt'))
    var_2 = shell_module_0.join_path(to_bytes('/var/path/'))
    # Test the method get_remote_filename of class ShellModule
    var_3 = shell_module_0.get_remote_filename(to_bytes('/local/file.ps1'))
    var_4 = shell_module_0.get_remote_filename(to_bytes('/local/file'))

# Generated at 2022-06-25 11:53:33.873279
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.join_path('foo/bar', '/etc')
    assert var_0 == 'foo\\bar\\etc'
    var_1 = shell_module_0.join_path('/usr/local', 'bin', '/etc')
    assert var_1 == 'bin\\etc'
    var_2 = shell_module_0.join_path('/foo', 'bar')
    assert var_2 == 'foo\\bar'
    var_3 = shell_module_0.join_path('foo', 'bar/')
    assert var_3 == 'foo\\bar\\'
    var_4 = shell_module_0.join_path('foo//', 'bar/')
    assert var_4 == 'foo\\\\bar\\'


# Generated at 2022-06-25 11:53:47.180158
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:48.595170
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print(type(shell_module_0))


# Generated at 2022-06-25 11:53:49.433476
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# Generated at 2022-06-25 11:53:52.559832
# Unit test for constructor of class ShellModule
def test_ShellModule():
    var_0 = ShellModule()
    assert var_0 is not None
    assert var_0._IS_WINDOWS == True
    assert var_0.COMPATIBLE_SHELLS == frozenset()
    assert var_0.SHELL_FAMILY == u'powershell'


# Generated at 2022-06-25 11:53:56.089250
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Testing for shell module (build_module_command)
    shell_module_0 = ShellModule()
    var_0 = shell_build_module_command(env_string='', shebang='', cmd='', arg_path='')


# Generated at 2022-06-25 11:54:00.630714
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule().__class__.__name__ == 'ShellModule'
    # Test that the class can be instantiated.
    ShellModule()



# Generated at 2022-06-25 11:54:01.809854
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:54:03.439788
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:54:05.224568
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if shell_module_0 is not None:
        print("Test 0: OK")


# Generated at 2022-06-25 11:54:06.027152
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

# Generated at 2022-06-25 11:54:37.035228
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_1 = ''
    var_2 = ''
    var_3 = ''
    var_4 = ''
    shell_module_0.build_module_command(var_1, var_2, var_3, var_4)



# Generated at 2022-06-25 11:54:41.582621
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:43.210919
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:54:44.422280
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert True


# Generated at 2022-06-25 11:54:56.716813
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = to_text(shell_module_0.get_remote_filename("setup.py"))
    assert var_0 == "setup.ps1"
    var_0 = to_text(shell_module_0.build_module_command("", "", "cd /usr/bin; ./configure --without-tcl --without-tk --without-x", "_; cd /tmp"))

# Generated at 2022-06-25 11:54:57.801772
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create an object of the ShellModule class
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)


# Generated at 2022-06-25 11:55:05.240983
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_test = ShellModule(connection)

    assert shell_module_test.get_remote_filename('C:/path/to/file') == 'file'
    assert shell_module_test.get_remote_filename('C:/path/to/file.txt') == 'file.txt'
    assert shell_module_test.get_remote_filename('C:/path/to/file.txt.tmp') == 'file.txt.tmp'
    assert shell_module_test.get_remote_filename('C:/path/to/file.txt', '.tmp') == 'file.txt'
    assert shell_module_test.get_remote_filename('C://path//to//file') == 'file'
    assert shell_module_test.get_remote_filename('C:/path/to/file.txt') == 'file.txt'
   

# Generated at 2022-06-25 11:55:09.472004
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert 1 == shell_module_0.get_option('remote_tmp')



# Generated at 2022-06-25 11:55:16.742949
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # tests for attribute of ShellModule
    #assert shell_module_0.COMPATIBLE_SHELLS == "CONSTANT_VALUE"
    #assert shell_module_0.SHELL_FAMILY == "CONSTANT_VALUE"
    #assert shell_module_0._IS_WINDOWS == "CONSTANT_VALUE"
    #assert shell_module_0._SHELL_REDIRECT_ALLNULL == "CONSTANT_VALUE"
    #assert shell_module_0._SHELL_AND == "CONSTANT_VALUE"


# Generated at 2022-06-25 11:55:18.676374
# Unit test for constructor of class ShellModule
def test_ShellModule():
    var_0 = ShellModule()
    assert (isinstance(var_0, ShellModule) == True)


# Generated at 2022-06-25 11:56:21.092563
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._IS_WINDOWS is True
    assert shell_module_0._SHELL_FAMILY == 'powershell'
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0.get_option('SHELL_FAMILY') == 'powershell'
    assert shell_module_0.get_option('COMPATIBLE_SHELLS') == frozenset()
    assert shell_module_0.get_option('SHELL_AND') == ';'

# Generated at 2022-06-25 11:56:25.435266
# Unit test for constructor of class ShellModule
def test_ShellModule():
    var_0 = ShellModule()
    assert isinstance(var_0, ShellModule)


# Generated at 2022-06-25 11:56:27.630817
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert not hasattr(shell_module_0, '__class__'), 'This case is not implemented'



# Generated at 2022-06-25 11:56:29.372908
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:32.177862
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
        assert shell_module_0._IS_WINDOWS is True
        assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
        assert shell_module_0.SHELL_FAMILY == 'powershell'
    except Exception as ex:
        assert type(ex) == AttributeError
    else:
        assert False


# Generated at 2022-06-25 11:56:37.110734
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    # Arrange
    shell_module_0 = ShellModule()
    env_string_0 = 'env_string_0'
    shebang_0 = 'shebang_0'
    cmd_0 = 'cmd_0'
    arg_path_0 = 'arg_path_0'

    # Act
    ret_val_0 = shell_module_0.build_module_command(env_string_0, shebang_0, cmd_0, arg_path_0)

    # Assert

# Generated at 2022-06-25 11:56:40.196816
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.__class__.__name__ == 'ShellModule'
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:56:49.370867
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    var_1 = shell_module_1.expand_user('~')
    var_1 = shell_module_1.expand_user('~', '')
    var_1 = shell_module_1.mkdtemp(basefile='var_1', system=False, mode=None, tmpdir=None)
    var_1 = shell_module_1.expand_user('~\\a')
    var_1 = shell_module_1.expand_user('~\\a', '')
    shell_module_1.join_path('', '')


# Generated at 2022-06-25 11:56:50.370004
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('test_ShellModule')
    test_case_0()



# Generated at 2022-06-25 11:56:53.238859
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
