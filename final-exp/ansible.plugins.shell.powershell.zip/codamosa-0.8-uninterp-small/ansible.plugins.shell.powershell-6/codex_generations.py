

# Generated at 2022-06-25 11:48:10.666253
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module = ShellModule()
    pathname = "C:\\Users\\Administrator\\Desktop\\Desktop\\tecmint_sub.sh"
    expected_result = "tecmint_sub.sh"
    test_result = shell_module.get_remote_filename(pathname=pathname)
    assert expected_result == test_result


# Generated at 2022-06-25 11:48:17.710500
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # When
    result = ShellModule().mkdtemp(basefile="ansible_test_case_ShellModule_mkdtemp", system=False, mode=None, tmpdir=None)

    # Then
    assert shell_module_0.mkdtemp(basefile="ansible_test_case_ShellModule_mkdtemp", system=False, mode=None, tmpdir=None) == result


# Generated at 2022-06-25 11:48:21.848684
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test cases for constructor of class ShellModule
    print('\n\nTesting constructor of class ShellModule')
    test_case_0()
    print('\n\nTest cases for constructor of class ShellModule done')

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:48:30.972157
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Assert the shell module instance
    shell_module = ShellModule(
        connection='local',
        become_method=None,
        become_user=None,
        check_rc=True,
        command_timeout=10,
        executable='/bin/sh',
        no_log=False,
        remote_tmp='/tmp',
        remote_uid=None,
        sudo_flags='-H',
        sudo_pass=None,
        sudoable=True,
        verbosity=0
    )

    # Test the bootstrap wrapper type
    shell_module.build_module_command(env_string=None, shebang='#!powershell.exe',
                                      cmd="$PSVersionTable.PSVersion.Major -gt 5", arg_path=None)

    # Test the bootstrap wrapper type with a script name, this will

# Generated at 2022-06-25 11:48:35.587213
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    print("Input for get_remote_filename : \"" + "testfile.ps1" + "\", output : " + str(shell_module_0.get_remote_filename("testfile.ps1")))
    print("Input for get_remote_filename : \"" + "testfile.sh" + "\", output : " + str(shell_module_0.get_remote_filename("testfile.sh")))
    print("Input for get_remote_filename : \"" + "testfile.exe" + "\", output : " + str(shell_module_0.get_remote_filename("testfile.exe")))


# Generated at 2022-06-25 11:48:38.464492
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    cmd = 'yadayadayada'
    arg_path = 'yadayadayada'
    env_string = 'yadayadayada'
    shebang = 'yadayadayada'
    result = shell_module_0.build_module_command(env_string, shebang, cmd, arg_path)


# Generated at 2022-06-25 11:48:41.242474
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module = ShellModule()
    file_name = shell_module.get_remote_filename('xyz.ps1')
    assert file_name == 'xyz.ps1'



# Generated at 2022-06-25 11:48:42.599112
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0 = ShellModule(**{'_shell': ShellModule({})})
    return


# Generated at 2022-06-25 11:48:44.273048
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:45.927878
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:48:52.853640
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    assert module is not None

# Generated at 2022-06-25 11:48:58.613962
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    user_home_path_0 = ("", ".\\", "bin", "~", "~\\")
    for i in range(0, 5):
        assert shell_module_0.expand_user(user_home_path_0[i]) == ("Write-Output '{0}'".format(user_home_path_0[i]), )


# Generated at 2022-06-25 11:49:02.775863
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(shell_module_0.SHELL_FAMILY == 'powershell')
    assert(shell_module_0.COMPATIBLE_SHELLS == frozenset())


# Generated at 2022-06-25 11:49:06.504060
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module=ShellModule()
    assert shell_module


# Generated at 2022-06-25 11:49:07.972724
# Unit test for constructor of class ShellModule
def test_ShellModule():
    return test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:49:18.117100
# Unit test for constructor of class ShellModule

# Generated at 2022-06-25 11:49:21.345156
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()

    # CASE 1
    path_0 = "C:/Windows/"
    shell_module_0 = ShellModule()
    assert shell_module_0.path_has_trailing_slash(path_0)

    # CASE 2
    path_0 = "C:/Windows\\"
    shell_module_0 = ShellModule()
    assert shell_module_0.path_has_trailing_slash(path_0)
    return

# Generated at 2022-06-25 11:49:30.621188
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_2 = ShellModule()
    assert shell_module_2.expand_user('~') == 'VwByAGkAdABlAHIALgBwAGwAbwA='
    assert shell_module_2.expand_user('~hello') == "JwByAGkAdABlAHIALgBwAGwAbwA9J2hlbGxvJw=="
    assert shell_module_2.expand_user('~\\hello') == "VwByAGkAdABlAHIALgBwAGwAbwAvaGVsbG8="


# Generated at 2022-06-25 11:49:32.531806
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    assert shell_module_0.expand_user('""') == 'Write-Output ""'


# Generated at 2022-06-25 11:49:34.455183
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('test_ShellModule():')
    test_case_0()

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:49:40.811694
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 != None, "ShellModule failed to instantiate"

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:49:44.239871
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:49:47.297036
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
    except Exception as e:
        print("Test Case 0: ", e)

# runs the unit tests
test_ShellModule()

# Generated at 2022-06-25 11:49:50.760881
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

    assert shell_module_0 is not None, 'Unit test failed because shell_module_0 is None'


# Generated at 2022-06-25 11:49:52.241300
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:49:54.573480
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)

# Generated at 2022-06-25 11:49:56.146595
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:49:58.495859
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except Exception as err:
        print("Failed case test_ShellModule")
        print(err)
        assert(1 == 0)


# Generated at 2022-06-25 11:50:04.142696
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    env_string = ''
    shebang = '#!/usr/bin/env python'
    cmd = 'ping -n 1 -w 1 127.0.0.1 > NUL'
    arg_path = None
    cmd_result_0 = shell_module.build_module_command(env_string, shebang, cmd, arg_path)

# Generated at 2022-06-25 11:50:05.697423
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_obj = ShellModule()


# Generated at 2022-06-25 11:50:11.095841
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:13.023694
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:50:21.616325
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    cmd = 'echo "Hello Ansible!"'
    actual_output = shell_module_0.build_module_command('', '', cmd)

# Generated at 2022-06-25 11:50:32.419573
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()

    # Example command strings to test
    cmd = ''''import-module "$PSScriptRoot\\..\\..\\..\\..\\..\\Test\\Legacy\\Windows\\Ansible\\Remoting\\winrm_wrapper.psm1" -DisableNameChecking; winrm_wrapper -endpoint winrm.psexec.host 'winrm://admin:password@winrm.psexec.host:5985/' -username admin -password password -command TEST_ARGV_SKIP_PS1_ONLY -command_arguments '-a ""echo TESTCMD_ARG_SKIP_PS1_ONLY"""';'''
    shebang = '#!powershell'
    env_string = None
    arg_path = None

    # Invoke build_module_command method

# Generated at 2022-06-25 11:50:35.507406
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:50:38.276934
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except:
        shell_module_0 = None
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:50:39.687493
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0

# Generated at 2022-06-25 11:50:41.799919
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1.shell_type == 'powershell'


# Generated at 2022-06-25 11:50:42.588916
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:50:43.872908
# Unit test for constructor of class ShellModule
def test_ShellModule():
    result = ShellModule()
    assert_is_instance(result, ShellBase)


# Generated at 2022-06-25 11:51:00.532281
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    cmd_name = "win_ping"
    shebang = "#!powershell"
    env_string = ""
    module_name = "win_ping"

# Generated at 2022-06-25 11:51:04.640096
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # foo_o returns a ShellModule object.
    try:
        shell_module_0 = ShellModule()
    except Exception as e:
        # When the constructor fails, foo_o returns a Null
        print("Error: " + str(e))
        return 0
    return 1



# Generated at 2022-06-25 11:51:14.461514
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()

# Generated at 2022-06-25 11:51:15.421690
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule != None


# Generated at 2022-06-25 11:51:25.755878
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    # Mocking for test case 'test_case_0'
    shell_module_0 = ShellModule()
    shell_module_0._unquote = MagicMock(return_value=None)
    shell_module_0._escape = MagicMock(return_value=None)

    # Mocking for test case 'test_case_1'
    shell_module_1 = ShellModule()
    shell_module_1._unquote = MagicMock(return_value=None)
    shell_module_1._escape = MagicMock(return_value=None)

    # Mocking for test case 'test_case_2'
    shell_module_2 = ShellModule()
    shell_module_2._unquote = MagicMock(return_value=None)

# Generated at 2022-06-25 11:51:30.496710
# Unit test for constructor of class ShellModule
def test_ShellModule():
    global shell_module_0
    print("In test_ShellModule()")

    if shell_module_0 is not None:
        print("Testcase Passed : ShellModule()")
    else:
        print("Testcase Failed : ShellModule()")


# Generated at 2022-06-25 11:51:40.290442
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shellModule = ShellModule()
    assert shellModule.SHELL_FAMILY == 'powershell', "ShellModule SHELL_FAMILY is not 'powershell'"
    assert shellModule.COMPATIBLE_SHELLS == frozenset(), "ShellModule COMPATIBLE_SHELLS is not empty set"
    assert shellModule._IS_WINDOWS == True, "ShellModule _IS_WINDOWS is not True"
    assert shellModule._SHELL_AND == ";"
    assert shellModule._SHELL_REDIRECT_ALLNULL == "> $null"
    assert shellModule.get_remote_filename(pathname = 'C:\\Users\\Vamshi\\Desktop\\abc') == 'abc.ps1',\
        "ShellModule get_remote_filename method is not working"

# Generated at 2022-06-25 11:51:45.209601
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    success = True
    msg = ""
    try:
        shell_module_1.get_option(None)
        shell_module_1.get_option('')
        shell_module_1.get_option('remote_tmp')
    except Exception as err:
        success = False
        msg = str(err)
    assert success == False, 'test_ShellModule - get_option failed with Exception %s' % msg


# Generated at 2022-06-25 11:51:46.998967
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:51:48.944850
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule(), "Constructor of class ShellModule returned None."


# Generated at 2022-06-25 11:52:01.499676
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_0 = 'VAR_0'
    var_1 = 'VAR_1'
    var_2 = 'VAR_2'
    var_3 = 'VAR_3'
    var_4 = 'VAR_4'
    shell_module_0.build_module_command(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 11:52:06.821004
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    var_0 = None
    var_1 = '#!powershell'
    var_2 = '$SuccessPreference=$null;Write-Output "Hello World"'
    var_3 = 'F:\\test.ps1'

    # Invoking build_module_command
    var_0 = ShellModule.build_module_command(var_0, var_1, var_2, var_3)
    print("test_ShellModule_build_module_command result: %s" % var_0)


if __name__ == '__main__':
    test_case_0()
    test_ShellModule_build_module_command()

# Generated at 2022-06-25 11:52:07.956400
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass


# Generated at 2022-06-25 11:52:11.199571
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp()


# Generated at 2022-06-25 11:52:13.516250
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:52:18.427782
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    env_string_0 = ''

    assert shell_module_0.build_module_command(env_string_0, '', '') == _encode_script(script=bootstrap_wrapper, strict_mode=False, preserve_rc=False)

# Generated at 2022-06-25 11:52:23.566136
# Unit test for constructor of class ShellModule

# Generated at 2022-06-25 11:52:24.900905
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_mkdtemp()
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:26.165116
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-25 11:52:30.052209
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:46.691673
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj_0 = ShellModule()

# Generated at 2022-06-25 11:52:47.697839
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:49.811148
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert (isinstance(shell_module, ShellModule))


# Generated at 2022-06-25 11:52:56.164022
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert not (shell_module_0.COMPATIBLE_SHELLS)
    assert shell_module_0._IS_WINDOWS is True
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'


# Generated at 2022-06-25 11:52:57.978236
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_var = ShellModule()
    assert shell_module_var


# Generated at 2022-06-25 11:52:58.811304
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:05.594751
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_ = shell_module()
    assert shell_module_._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_._IS_WINDOWS is True
    assert shell_module_._SHELL_AND == ';'
    assert shell_module_.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-25 11:53:09.344806
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:12.992114
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.get_option('remote_tmp') == '$env:temp'
    assert shell_module_0.get_option('shell_type') == 'powershell'
    assert shell_module_0.get_option('comment_char') == '#'
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:53:15.282404
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:53:44.687519
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:53:46.004666
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:50.461882
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert_equal(shell_module_0.SHELL_FAMILY, 'powershell')
    assert_equal(shell_module_0.COMPATIBLE_SHELLS, frozenset())
    assert_equal(shell_module_0._IS_WINDOWS, True)
    assert_equal(shell_module_0._SHELL_REDIRECT_ALLNULL, '> $null')


# Generated at 2022-06-25 11:53:52.434078
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.module_utils.powershell import ShellModule

    # create instance of ShellModule using default args
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:54:03.095794
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    current_0 = TestCase.get_current()
    output_0 = current_0.get_output_for('mod', 'unittest')
    assert True # executed command is `ShellModule;`
    output_1 = current_0.get_output_for('mod', 'unittest')
    assert True # executed command is `ShellModule;`
    output_2 = current_0.get_output_for('mod', 'unittest')
    assert True # executed command is `ShellModule;`
    output_3 = current_0.get_output_for('mod', 'unittest')
    assert True # executed command is `ShellModule;`
    output_4 = current_0.get_output_for('mod', 'unittest')
    assert True # executed command is `

# Generated at 2022-06-25 11:54:05.887827
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:11.864991
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    # Test being run in a PowerShell environment
    var_0 = to_text(os.getenv("__shell__"))
    if (var_0 != "powershell"):
        raise Exception("build_module_command: Test running in PowerShell environment")
    var_1 = to_text(shell_module_0.build_module_command("PATH='C:\\Users\\g48zsm\\.ansible\\tmp';TEMP='C:\\Users\\g48zsm\\.ansible\\tmp';TMP='C:\\Users\\g48zsm\\.ansible\\tmp';ANSIBLE_REMOTE_TEMP='C:\\Users\\g48zsm\\.ansible\\tmp'", "", "", None))

# Generated at 2022-06-25 11:54:13.777485
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()

    assert module
    assert module.COMPATIBLE_SHELLS == frozenset()
    assert module.SHELL_FAMILY == 'powershell'
    assert module._IS_WINDOWS == True


# Generated at 2022-06-25 11:54:23.776167
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Setup the arguments
    module_path = '/var/lib/awx/projects/_8__ansible_pull_scratch/callback_plugins/profile_tasks.py'
    wrap_async = False
    shebang = '#!profile_tasks.py'
    arg_path = u'/home/michael/workspace/ansible_tower/venv/lib/python3.5/site-packages/ansible/module_utils/urls.py'
    persist_files = False
    rm_tmp = True
    # Execute the logic
    result = ShellModule().build_module_command(module_path, shebang, wrap_async, arg_path, persist_files, rm_tmp)
    # Assert the result
    assert isinstance(result, str)
    pass


# Generated at 2022-06-25 11:54:29.236565
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # test for case 0
    try:
        test_case_0()
    except AssertionError:
        pass
    except Exception:
        pass

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:55:27.806981
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_mkdtemp()


# Generated at 2022-06-25 11:55:36.422059
# Unit test for constructor of class ShellModule

# Generated at 2022-06-25 11:55:37.615905
# Unit test for constructor of class ShellModule
def test_ShellModule():
    var_0 = create_instance(ShellModule)


# Generated at 2022-06-25 11:55:38.790583
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # No commands should be run here
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:55:43.590134
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:45.450363
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('test_ShellModule()')
    shellModule = ShellModule()
    assert shellModule is not None


# Generated at 2022-06-25 11:55:48.409667
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None

# Generated at 2022-06-25 11:55:49.508966
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    pass


# Generated at 2022-06-25 11:55:52.758604
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = to_text(shell_module_0)
    assert var_0!=None


# Generated at 2022-06-25 11:55:54.835724
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule) is True


# Generated at 2022-06-25 11:57:01.988767
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0

# Generated at 2022-06-25 11:57:05.773943
# Unit test for constructor of class ShellModule
def test_ShellModule():
    _test_shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:57:06.690539
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("test")
    test_case_0()
    print("test done")

# Generated at 2022-06-25 11:57:11.823952
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():

    shell_module_0 = ShellModule()
    cmd = 'echo test'
    var_0 = shell_module_0.build_module_command('', '', cmd)


# Generated at 2022-06-25 11:57:18.462469
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.DEFAULT_EXECUTABLE == 'powershell.exe'
    assert isinstance(shell_module_0._SHELL_REDIRECT_ALLNULL, str)
    assert isinstance(shell_module_0._IS_WINDOWS, bool)

# Generated at 2022-06-25 11:57:19.666452
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp()


# Generated at 2022-06-25 11:57:20.638961
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:57:26.914075
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    assert shell_module_0._ISC_CONNECTION == "local"
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == "> $null"
    assert shell_module_0._SHELL_AND == ";"
    assert shell_module_0._SHELL_EXECUTABLE == "shell"
    assert shell_module_0._SHELL_FAMILY == "powershell"
    assert shell_module_0._SHELL_BINARY == ""
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == "> $null"
    assert shell_module_1._SHELL_AND == ";"
    assert shell_module_1._SHELL_BINARY == ""
    assert shell_module

# Generated at 2022-06-25 11:57:30.938611
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:57:32.459305
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return
