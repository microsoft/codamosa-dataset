

# Generated at 2022-06-25 11:48:18.410567
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    env_str = '$Env:ANSIBLE_MODULE_ARGS="{}"\n'
    shebang = '#!powershell'
    cmd = '$Env:ANSIBLE_MODULE_ARGS'
    module_arg_path = '-argument'
    # expected_cmd is bootstrap_wrapper.ps1 script base64 encoded 

# Generated at 2022-06-25 11:48:21.679523
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    print(shell_module_0.expand_user('~'))

if __name__ == '__main__':
    test_case_0()
    test_ShellModule_expand_user()

# Generated at 2022-06-25 11:48:23.573387
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert isinstance(ShellModule(), ShellModule), "Failed to create object of class ShellModule"


# Generated at 2022-06-25 11:48:25.926889
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    test_ShellModule
    '''
    shell_module = ShellModule()
    assert shell_module.__class__.__name__ == 'ShellModule'


# Generated at 2022-06-25 11:48:27.390296
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None, 'ShellModule object cannot be initialized'


# Generated at 2022-06-25 11:48:31.180065
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()

    test_case_name = "unit test case 0"
    basefile = ''
    system = False
    mode = None
    tmpdir = None

    shell_module_0.mkdtemp(basefile, system, mode, tmpdir)



# Generated at 2022-06-25 11:48:34.428422
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module = ShellModule()
    user_home_path = '~\\Ansible'
    result = shell_module.expand_user(user_home_path)
    result_script = to_bytes("""
    Write-Output ((Get-Location).Path + '\\\\Ansible')
    """)
    result_script = shell_module._encode_script(result_script.strip())
    assert result == result_script


# Generated at 2022-06-25 11:48:45.367039
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    # test case 1: shebang=False, cmd=''
    env_string = '$env:ANSIBLE_MODULE_ARGS=""'
    shebang = False
    cmd = ''
    arg_path = ''

# Generated at 2022-06-25 11:48:46.320242
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:48:48.714800
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module = ShellModule()
    script = shell_module.mkdtemp()
    assert script != None


# Generated at 2022-06-25 11:48:54.324790
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:59.926202
# Unit test for method get_remote_filename of class ShellModule

# Generated at 2022-06-25 11:49:05.586264
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    file_name_1 = "test_module.py"
    assert shell_module_0.get_remote_filename(file_name_1) == "test_module.py"


# Generated at 2022-06-25 11:49:10.050325
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_object = ShellModule()
    print(shell_module_object)
    print(shell_module_object.COMPATIBLE_SHELLS)
    print(shell_module_object.SHELL_FAMILY)
    print(shell_module_object._IS_WINDOWS)
    print(shell_module_object._SHELL_REDIRECT_ALLNULL)
    print(shell_module_object._SHELL_AND)


# Generated at 2022-06-25 11:49:12.275315
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    shell_module_2 = ShellModule()

    assert shell_module_1 is not None
    assert shell_module_2 is not None


# Generated at 2022-06-25 11:49:18.037181
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_1 = ShellModule()
    test_case_args_0 = [
        "C:\\ansible\\ansible\\hacking\\env-setup",
        "",
        "",
        "C:\\ansible\\ansible\\lib\\ansible\\module_utils\\powershell\\PsExec.ps1",
        ""
    ]
    expected_result_0 = "''"
    assert shell_module_1.build_module_command(*test_case_args_0) == expected_result_0

test_case_0()
test_ShellModule_build_module_command()

# Generated at 2022-06-25 11:49:23.103352
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    remote_file_name = ShellModule().get_remote_filename("/home/user/MyFile")
    assert remote_file_name == "MyFile.ps1"
    remote_file_name = ShellModule().get_remote_filename("/home/user/MyFile.py")
    assert remote_file_name == "MyFile.py.ps1"
    remote_file_name = ShellModule().get_remote_filename("/home/user/MyFile.exe")
    assert remote_file_name == "MyFile.exe"
    remote_file_name = ShellModule().get_remote_filename("/home/user/MyFile.ps1")
    assert remote_file_name == "MyFile.ps1"



# Generated at 2022-06-25 11:49:33.568843
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # declare the values to be used in the test
    shebang = "#!powershell"
    cmd = "Get-Process"
    arg_path = "Get-Process"
    env_string = "ls"

    # get the current instance of the ShellModule class
    shell_module = ShellModule()

    # run the method
    result_0 = shell_module.build_module_command(env_string, shebang, cmd, arg_path)

    # check the result
    # check the value of the result
    value_check_0 = "type 'Get-Process' | "
    # check that the result is the same as the expected value
    assert result_0.startswith(value_check_0)


# Generated at 2022-06-25 11:49:38.653454
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except Exception:
        print('Exception: No exception expected!')


# Generated at 2022-06-25 11:49:42.639368
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('Testing module ShellModule')
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None, 'Method constructor of class ShellModule returned None'
    print('Module ShellModule tests passed')


# Generated at 2022-06-25 11:49:52.286489
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Instantiate the Shell module
    shell_module = ShellModule()
    # Call the mkdtemp with valid inputs
    temp_dir = shell_module.mkdtemp(basefile="test", tmpdir="tmp")
    # Assert that the temp directory is not None
    assert temp_dir is not None

# Generated at 2022-06-25 11:49:54.989565
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert repr(shell_module_0) == "<ansible.module_utils.powershell.ShellModule object at 0x7fd1fd2ae9d0>"


# Generated at 2022-06-25 11:50:00.627683
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    if not isinstance(shell_module_1.SHELL_FAMILY, str):
        raise AssertionError('Expected str but got %s' % type(shell_module_1.SHELL_FAMILY))
    if not isinstance(shell_module_1.COMPATIBLE_SHELLS, frozenset):
        raise AssertionError('Expected frozenset but got %s' % type(shell_module_1.COMPATIBLE_SHELLS))
    if not isinstance(shell_module_1._SHELL_REDIRECT_ALLNULL, str):
        raise AssertionError('Expected str but got %s' % type(shell_module_1._SHELL_REDIRECT_ALLNULL))

# Generated at 2022-06-25 11:50:06.695053
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    basefile = "powershell_test_case_1"
    system = True
    mode = "777"
    tmpdir = "powershell_test_case_1"
    t = ShellModule()
    t.mkdtemp(basefile, system, mode, tmpdir)





# Generated at 2022-06-25 11:50:11.449630
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
    except BaseException as e:
        print(e)
        return False

    return True



# Generated at 2022-06-25 11:50:13.379519
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Instantiating a ShellModule
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:20.064509
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    mkdtemp_shell_module = ShellModule()
    basefile = 'temp_`date +%s`'
    result_mkdtemp_shell_module = mkdtemp_shell_module.mkdtemp(basefile)
    assert result_mkdtemp_shell_module


# Generated at 2022-06-25 11:50:24.172059
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # First call to constructor of class ShellModule
    assert isinstance(shell_module_0, ShellModule)
#     test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:50:33.685267
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule.COMPATIBLE_SHELLS == frozenset(), "Incorrect value of COMPATIBLE_SHELLS"
    assert ShellModule.SHELL_FAMILY == 'powershell', "Incorrect value of SHELL_FAMILY"
    shell_module = ShellModule()
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null', "Incorrect value of _SHELL_REDIRECT_ALLNULL"
    assert shell_module._SHELL_AND == ';', "Incorrect value of _SHELL_AND"
    assert shell_module._IS_WINDOWS == True, "Incorrect value of _IS_WINDOWS"



# Generated at 2022-06-25 11:50:37.890803
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == "powershell"



# Generated at 2022-06-25 11:50:45.555785
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
    except Exception as e:
        print("Error in test_case_0: " + str(e))
        assert False


# Generated at 2022-06-25 11:50:46.270328
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()


# Generated at 2022-06-25 11:50:48.529654
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:58.302676
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Test attribute remote_tmp

    assert shell_module_0.remote_tmp == ""
    # Test attribute _SHELL_REDIRECT_ALLNULL

    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    # Test attribute SHELL_FAMILY

    assert shell_module_0.SHELL_FAMILY == 'powershell'
    # Test attribute _SHELL_AND

    assert shell_module_0._SHELL_AND == ';'
    # Test attribute _IS_WINDOWS

    assert shell_module_0._IS_WINDOWS == True
    # Test attribute COMPATIBLE_SHELLS

    #assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    # Test method wrap_for_exec()



# Generated at 2022-06-25 11:51:02.412574
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_name = 'ShellModule'
    test_case_0()


# Generated at 2022-06-25 11:51:07.537519
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

    # check is_windows is true
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'



# Generated at 2022-06-25 11:51:10.276659
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('Testing ShellModule() constructor')
    test_case_0()
    print('Done')

# Using an existing shell module, call the method to be tested

# Testing _unquote()

# Generated at 2022-06-25 11:51:14.476505
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:51:22.527185
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    shell_module_2 = ShellModule()
    shell_module_3 = ShellModule()
    shell_module_4 = ShellModule()
    shell_module_5 = ShellModule()
    shell_module_6 = ShellModule()
    shell_module_7 = ShellModule()
    shell_module_8 = ShellModule()
    shell_module_9 = ShellModule()
    shell_module_10 = ShellModule()
    shell_module_11 = ShellModule()
    shell_module_12 = ShellModule()
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.shell.powershell import _parse_clixml

# Generated at 2022-06-25 11:51:25.647203
# Unit test for constructor of class ShellModule
def test_ShellModule():
        shell_module_0 = ShellModule()
        assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
        assert shell_module_0.SHELL_FAMILY == 'powershell'
        assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:51:33.046877
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert repr(ShellModule())


# Generated at 2022-06-25 11:51:35.236555
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('')
    # print exec((shell_module_0
    print('TESTING ShellModule')


# Generated at 2022-06-25 11:51:38.281884
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None

# Generated at 2022-06-25 11:51:42.209825
# Unit test for constructor of class ShellModule
def test_ShellModule():
    my_shell_module = ShellModule()
    result = my_shell_module.get_option('remote_tmp')
    if result != '%USERPROFILE%':
        return False
    return True


# Generated at 2022-06-25 11:51:46.634788
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

if __name__ == '__main__':
    test_case_0()
    test_ShellModule()

# Generated at 2022-06-25 11:51:51.965970
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_instance = ShellModule()
    assert(module_instance.COMPATIBLE_SHELLS == frozenset())
    assert(module_instance.SHELL_FAMILY == 'powershell')
    assert(_common_args.index('-NoProfile') == 1)
    assert(_common_args.index('-NonInteractive') == 2)
    assert(_common_args.index('-ExecutionPolicy') == 3)
    assert(_common_args.index('Unrestricted') == 4)
    assert(module_instance._IS_WINDOWS)
    assert(module_instance._SHELL_REDIRECT_ALLNULL == '> $null')
    assert(module_instance._SHELL_AND == ';')


# Generated at 2022-06-25 11:51:57.125885
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None
    assert shell_module_1.SHELL_FAMILY == 'powershell'
    assert shell_module_1._IS_WINDOWS == True



# Generated at 2022-06-25 11:52:04.670093
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert hasattr(ShellModule, '_SHELL_REDIRECT_ALLNULL'), "Class ShellModule does not have attribute '_SHELL_REDIRECT_ALLNULL'"
    assert hasattr(ShellModule, '_SHELL_AND'), "Class ShellModule does not have attribute '_SHELL_AND'"
    assert hasattr(ShellModule, 'COMPATIBLE_SHELLS'), "Class ShellModule does not have attribute 'COMPATIBLE_SHELLS'"
    assert type(ShellModule.COMPATIBLE_SHELLS) is frozenset, "Attribute 'COMPATIBLE_SHELLS' should be of type 'frozenset'"
    assert hasattr(ShellModule, 'SHELL_FAMILY'), "Class ShellModule does not have attribute 'SHELL_FAMILY'"

# Generated at 2022-06-25 11:52:06.126845
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:08.124075
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:52:15.107504
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:52:19.890205
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
        print("Test Case 0 Finished")
    except:
        print("Test Case 0 Failed")


# Generated at 2022-06-25 11:52:26.008874
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module = ShellModule()
    except:
        raise AssertionError(
            "The object of the class ShellModule is not created")

# Unit Test for env_prefix of class ShellModule

# Generated at 2022-06-25 11:52:38.757334
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    ## get_name test
    shell_module_0.get_name()
    ## get_option test
    shell_module_0.get_option(None)
    ## get_option test
    shell_module_0.get_option('remote_tmp')
    ## set_option test
    shell_module_0.set_option('remote_tmp', None)
    ## set_options test
    shell_module_0.set_options(None)
    ## set_options test
    shell_module_0.set_options({})
    ## set_remote_user test
    shell_module_0.set_remote_user(None)
    ## normalize_path test
    shell_module_0.normalize_path(None)
    ## normalize_path test
    shell_

# Generated at 2022-06-25 11:52:41.800960
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()

    except:
        # if any exception was thrown, we failed
        return False

    # if we got here, we passed
    return True

# Generated at 2022-06-25 11:52:49.232737
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-25 11:52:53.398512
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except Exception as err:
        print("\nException when calling ShellModule():\n{0}".format(err))
        raise err

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:53:05.095022
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    # Case 1
    script = """
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('%s')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name '%s'
        """ % (shell_module.get_option('remote_tmp'), shell_module.__class__._generate_temp_dir_name())

    cmd = shell_module._encode_script(script.strip())
    assert cmd

    # Case 2
    script = """
        %s
        %s
        """ % (shell_module.env_prefix(), shell_module.join_path('~', 'downloads'))
    cmd = shell_module.build_module_command(shell_module.env_prefix(), '', script)
    assert cmd

    # Case 3

# Generated at 2022-06-25 11:53:10.625519
# Unit test for constructor of class ShellModule
def test_ShellModule():

    assert ShellModule()._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule()._SHELL_AND == ';'
    assert ShellModule()._IS_WINDOWS is True


# Generated at 2022-06-25 11:53:17.134514
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    tmp_dir = os.path.expandvars('$TEMP\\ansible')
    # this module tests to ensure that we add '.ps1' to the end of a module
    # if it is not provided
    command = "foo bar"
    # this module tests to make sure that we don't add '.ps1' to the end of
    # a module if it is already there
    command2 = "foo.ps1 bar"
    # this module tests to make sure we don't add '.ps1' to the end of a
    # module if it is not needed
    command3 = "foo.bar"
    # this module tests to make sure we add a shebang for powershell
    command4 = "foo bar"
    # this module tests to make sure that we don't replace an existing shebang
    command

# Generated at 2022-06-25 11:53:23.375485
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
    except NotImplementedError:
        assert False, 'Test case 0 of class ShellModule failed'
    return

# Generated at 2022-06-25 11:53:27.836466
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:53:35.086146
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    # START: Assignment of local variables for test
    env_string_0 = ''
    shebang_0 = ''
    cmd_0 = 'test.exe -i test.ini'
    arg_path_0 = 'test.json'
    # END: Assignment of local variables for test

    # START: Code snippet generated by test
    #cmd_parts_0 = shlex.split(cmd_0, posix=False)
    #assert type(cmd_parts_0) is list
    #cmd_parts_0 = list(map(to_text, cmd_parts_0))
    #assert type(cmd_parts_0) is list
    #if shebang_0 and shebang_0.lower() == '#!powershell':
    #    if not shell_module_0._unquote

# Generated at 2022-06-25 11:53:36.152650
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None

# Generated at 2022-06-25 11:53:40.438758
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module = ShellModule()
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 11:53:42.634633
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:47.345964
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    test_object = ShellModule()
    env_string = "string"
    shebang = "#!powershell"
    cmd = "string"
    arg_path = "string"
    assert test_object.build_module_command(env_string, shebang, cmd, arg_path) is not None
    assert test_object.build_module_command(env_string, shebang, cmd) is not None


# Generated at 2022-06-25 11:53:48.484496
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert (shell_module)

# Generated at 2022-06-25 11:53:51.152878
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule(loader=None, shared_loader_obj=None, path_info=None)

if __name__ == '__main__':
    test_case_0()
    test_ShellModule()

# Generated at 2022-06-25 11:53:54.931415
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Instance creation
    shell_module = ShellModule()


# Generated at 2022-06-25 11:54:05.641957
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    shell_module_2 = ShellModule()
    assert shell_module_1.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_1.SHELL_FAMILY == 'powershell'
    assert shell_module_1._IS_WINDOWS == True
    assert shell_module_2.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_2.SHELL_FAMILY == 'powershell'
    assert shell_module_2._IS_WINDOWS == True


# Generated at 2022-06-25 11:54:16.261403
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    output = shell_module_0.env_prefix(**{u'system_install': False})
    assert output == ""
    output = shell_module_0._IS_WINDOWS
    assert output is True
    output = shell_module_0.build_module_command(**{u'env_string': '$env:TEMP = "D:\\tmp"', u'cmd': 'D:\\tmp\\ansible_tmp_1469265374.36-205912481364413\\ec2.ps1', u'shebang': '#!powerShell'})

# Generated at 2022-06-25 11:54:23.918442
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    config = {
        'remote_tmp': "$env:temp"}

# Generated at 2022-06-25 11:54:27.339812
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.shell_utils import ShellModule

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 11:54:29.085239
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    shell_module_0.build_module_command('env_string','','','arg_path')


# Generated at 2022-06-25 11:54:30.129662
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:31.638928
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'

# Generated at 2022-06-25 11:54:41.056082
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Initialize the object
    shell_module_1 = ShellModule()

    # call the function to be tested
    shebang_2 = "#!powershell"
    cmd_3 = "Get-ChildItem -Recurse | Select-Object FullName | Export-Csv -Encoding UTF8 -NoTypeInformation c:\\test.csv"
    arg_path_4 = ""
    output_5 = shell_module_1.build_module_command("",shebang_2,cmd_3,arg_path_4)
    assert output_5 == "& $PSHOME\\Modules\\ansible\\ansible\\executor\\powershell\\bootstrap_wrapper.ps1; exit $LASTEXITCODE"


# Generated at 2022-06-25 11:54:49.654258
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert (shell_module.COMPATIBLE_SHELLS == frozenset())
    assert (shell_module.SHELL_FAMILY == 'powershell')
    assert (shell_module._IS_WINDOWS == True)
    assert (isinstance(shell_module._SHELL_REDIRECT_ALLNULL, str))
    assert (shell_module._SHELL_REDIRECT_ALLNULL == '> $null')
    assert (isinstance(shell_module._SHELL_AND, str))
    assert (shell_module._SHELL_AND == ';')


# Generated at 2022-06-25 11:54:59.574556
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    shell_module_2 = ShellModule()
    assert(shell_module_1 == shell_module_2)

    # test __eq__
    shell_module_3 = ShellModule()
    shell_module_4 = ShellModule()
    assert (shell_module_3 == shell_module_4)

    # test __ne__
    shell_module_5 = ShellModule()
    shell_module_6 = ShellModule()
    assert (shell_module_5 != shell_module_6)

    # test __hash__
    shell_module_7 = ShellModule()
    shell_module_8 = ShellModule()
    assert (shell_module_7 != shell_module_8)

    # test __nonzero__
    shell_module_9 = ShellModule()

# Generated at 2022-06-25 11:55:07.792489
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert_equals(shell_module_0._SHELL_AND, ';')
    assert_equals(shell_module_0.COMPATIBLE_SHELLS, frozenset())
    assert_equals(shell_module_0._SHELL_REDIRECT_ALLNULL, '> $null')
    assert_equals(shell_module_0._IS_WINDOWS, True)
    assert_equals(shell_module_0.SHELL_FAMILY, 'powershell')


# Generated at 2022-06-25 11:55:17.182890
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test exception case
    with pytest.raises(Exception, match='not implemented for Powershell'):
        shell_module_1 = ShellModule()
        var_1 = shell_module_1.chmod('paths', 'mode')
    # Test exception case
    with pytest.raises(Exception, match='not implemented for Powershell'):
        shell_module_2 = ShellModule()
        var_2 = shell_module_2.chown('paths', 'user')
    # Test exception case
    with pytest.raises(Exception, match='not implemented for Powershell'):
        shell_module_3 = ShellModule()
        var_3 = shell_module_3.set_user_facl('paths', 'user', 'mode')
    # Test exception case

# Generated at 2022-06-25 11:55:21.658294
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test for function shell_mkdtemp
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp()
    assert var_0 == ''
    assert True

if __name__ == "__main__":
    import __main__
    import inspect

    frame_records = inspect.getouterframes(inspect.currentframe())
    current_test_case = frame_records[1][3]

    if current_test_case == "test_case_0":
        test_case_0()
        
    elif current_test_case == "test_ShellModule":
        test_ShellModule()
        
    else:
        raise Exception("Test case not found")

# Generated at 2022-06-25 11:55:23.387743
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:55:35.416314
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Initialize input and output data structures
    i = {'env_string': 'env_string', 'shebang': 'shebang', 'cmd': 'cmd', 'arg_path': 'arg_path'}
    o = {}

    # Test for presence of required params
    for i_name in i:
        o[i_name] = i[i_name]

    # Check for this module's required params
    required_params = []
    missing_required_params = []
    for required_param in required_params:
        if required_param not in o:
            missing_required_params.append(required_param)
    if missing_required_params:
        # Fail the module if any required params are missing
        module.fail_json(msg=(", ".join(missing_required_params)) + " required for this module")

    #

# Generated at 2022-06-25 11:55:37.018396
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Check the valid value for the path argument
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:55:43.697459
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create an instance of class ShellModule
    shell_module_0 = ShellModule()
    try:
        # Invoke the constructor of class ShellModule
        assert shell_module_0 is not None
        # Invoke the destructor of class ShellModule
        shell_module_0 = ShellModule()
        del shell_module_0
    except Exception as inst:
        print(inst)
        assert False
    # Test for successful assignment of private member _PCOUNT = 1
    assert shell_module_0._PCOUNT == 1
    # Test for successful assignment of private member _PID = 1
    assert shell_module_0._PID == 1
    # Test for successful assignment of private member _PCOUNT = 2
    assert shell_module_0._PCOUNT == 2
    # Test for successful assignment of private member _PID = 2
    assert shell_module

# Generated at 2022-06-25 11:55:45.905737
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Var 'shell_module_0' is declared but is never used


# Generated at 2022-06-25 11:55:57.065223
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.verbatim_arguments == ['ssh', '-tt', '-t'], 'Incorrect attribute value for verbatim_arguments'
    assert shell_module_0.no_log == ['ASSERT', 'PYTHONIOENCODING', 'LC_ALL', 'LANG', 'LC_MESSAGES', 'LC_CTYPE'], 'Incorrect attribute value for no_log'
    assert shell_module_0.SHELL_FAMILY == 'powershell', 'Incorrect attribute value for SHELL_FAMILY'
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset([]), 'Incorrect attribute value for COMPATIBLE_SHELLS'


# Generated at 2022-06-25 11:56:05.970396
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0.SHELL_NAME == 'powershell'


# Generated at 2022-06-25 11:56:12.477364
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with default value of arguments
    shell_module_0 = ShellModule()

    # Test with explicit value of arguments
    # TODO: Test with explicit value of arguments


# Generated at 2022-06-25 11:56:17.248250
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    assert isinstance(shell_module, ShellModule)



# Generated at 2022-06-25 11:56:18.416238
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:56:19.262624
# Unit test for constructor of class ShellModule
def test_ShellModule():
    var_0 = ShellModule()

# Generated at 2022-06-25 11:56:21.155447
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)
    assert isinstance(shell_module_0, type(None))


# Generated at 2022-06-25 11:56:24.110968
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:56:25.650889
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:56:26.898110
# Unit test for constructor of class ShellModule
def test_ShellModule():
    args = "basefile"
    obj = ShellModule(args)


# Generated at 2022-06-25 11:56:29.869273
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    var_1 = shell_module_1.do_expand_user(user_home_path = 'test', username = '')


# Generated at 2022-06-25 11:56:30.526487
# Unit test for constructor of class ShellModule
def test_ShellModule():
    var_1 = ShellModule()

# Generated at 2022-06-25 11:56:40.212220
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp()


# Generated at 2022-06-25 11:56:41.202126
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:56:44.376456
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("Inside test_ShellModule test")
    # Create an instance of ShellModule
    shell_module_inst_0 = ShellModule()



# Generated at 2022-06-25 11:56:47.513163
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:49.926716
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if isinstance(shell_module_0, ShellBase):
        pass
    else:
        raise Exception('Test case 0 failed')



# Generated at 2022-06-25 11:56:55.451817
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Testing default value of attribute
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module._IS_WINDOWS is True
    assert shell_module.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:56:59.448826
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:57:02.048955
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule) == True

# Unit tests for ShellModule methods

# Generated at 2022-06-25 11:57:07.907482
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS == True
    assert not hasattr(shell_module_0, 'binary')


# Generated at 2022-06-25 11:57:17.830000
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule
    str_0 = shell_module_0.build_module_command()
    str_1 = shell_module_0.build_module_command(env_string=str_0)
    str_2 = shell_module_0.build_module_command(env_string=str_1, shebang="test_value")
    str_3 = shell_module_0.build_module_command(env_string=str_2, shebang="test_value", cmd="test_value")
    str_4 = shell_module_0.build_module_command(env_string=str_3, shebang=str_0, cmd=str_1, arg_path="test_value")

# Generated at 2022-06-25 11:57:52.453464
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:57:54.198421
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert_true(isinstance(shell_module_0, ShellModule))


# Generated at 2022-06-25 11:57:59.972337
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = getattr(shell_module_0, "IS_PATH_ON_WINDOWS")
    var_1 = getattr(shell_module_0, "IS_WINDOWS")
    var_2 = getattr(shell_module_0, "SUPPORTS_KWARGS")