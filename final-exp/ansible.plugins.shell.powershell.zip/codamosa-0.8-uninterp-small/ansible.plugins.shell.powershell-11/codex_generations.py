

# Generated at 2022-06-25 11:48:08.922311
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    if shell_module_1.SHELL_FAMILY != 'powershell':
        raise ValueError("Failed to create object instance of class ShellModule")


# Generated at 2022-06-25 11:48:16.773291
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    shebang = "#!powershell"
    cmd = "hello.ps1"
    env_string = shell_module.env_prefix()
    ret_val = shell_module.build_module_command(env_string,shebang,cmd)[0]
    assert(ret_val == True)

if __name__ == "__main__":
    test_case_0()
    test_ShellModule_build_module_command()

# Generated at 2022-06-25 11:48:20.480647
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module


# Generated at 2022-06-25 11:48:24.915004
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    basetmpdir = "C:\\Users\\USERNAME\\AppData\\Local\\Temp"
    basefile = "ansible-tmp-1549002647.39-147919052693480"

    shell_module_0 = ShellModule()
    script = shell_module_0.mkdtemp(basefile, tmpdir=basetmpdir)
    # check the output of the script (parsing out any randomness)
    m = re.match(r"^$env:TEMP\\ansible-tmp-\d+-\d+$", script)
    assert m



# Generated at 2022-06-25 11:48:26.174761
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:27.363824
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    pass


# Generated at 2022-06-25 11:48:30.456982
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    assert ShellModule().expand_user('~') == 'Write-Output (Get-Location).Path'
    assert ShellModule().expand_user('~/test') == 'Write-Output ((Get-Location).Path + \'\\\\test\')'


# Generated at 2022-06-25 11:48:37.302042
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Initialization of target object
    shell_module_0 = ShellModule()
    # Initialization of test variables
    user_home_path = '~'
    username = ''
    with shell_module_0.run_command_environ_update(_common_args + ["-Command", shell_module_0._encode_script("Write-Output (Get-Location).Path")]):
        cmd_output = shell_module_0._execute_module(module_name='shell', module_args=shell_module_0.expand_user(user_home_path, username=username), tmp=None, task_vars=dict(), wrap_async=None)
        assert cmd_output['rc'] == 0
        assert cmd_output['stdout'] == '/home/linux_user'
        assert cmd_output['stderr'] == ''


# Generated at 2022-06-25 11:48:41.068807
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:48:51.643697
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_1 = ShellModule()
    assert(shell_module_1.mkdtemp() is not None)
    assert(shell_module_1.mkdtemp(basefile='basefile_0') is not None)
    assert(shell_module_1.mkdtemp(basefile='basefile_1', system=True) is not None)
    assert(shell_module_1.mkdtemp(basefile='basefile_2', system=True, mode='mode_2') is not None)
    assert(shell_module_1.mkdtemp(basefile='basefile_3', system=True, mode='mode_3', tmpdir='tmpdir_3') is not None)


# Generated at 2022-06-25 11:48:57.505217
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:49:02.707979
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    # The build_module_command method of module ShellModule should return a string.
    assert_true(isinstance(shell_module_0.build_module_command("","",""),str))

# Generated at 2022-06-25 11:49:12.797176
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    script = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    arg = "command arg1 arg2 arg3 arg4 arg5 arg6 arg7 arg8 arg9"
    arg = arg.encode('utf-16-le')
    encoded_str = to_text(base64.b64encode(arg), 'utf-8')
    expected_cmd = '''& { Set-StrictMode -Version Latest; $var1 = Invoke-Command @{ ScriptBlock = [ScriptBlock]::Create("Arg1"); }); $var1; If (-not $?) { If (Get-Variable LASTEXITCODE -ErrorAction SilentlyContinue) { exit $LASTEXITCODE } Else { exit 1 } } }'''
    t_cmd

# Generated at 2022-06-25 11:49:14.196134
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("Running test for constuctor of ShellModule class")
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:49:17.096871
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
        print('\nShell Module Test Passed\n')
    except Exception as e:
        print('\nException in Shell Module Test: %s' % str(e))

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:49:18.521228
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
        print("Constructor of class ShellModule works correctly")
    except Exception:
        raise


# Generated at 2022-06-25 11:49:25.686982
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.powershell.aecmd import AEcmd
    from ansible.executor.powershell import aecmd_wrapper
    from ansible.executor.powershell.get_appid import GetAppid

    # test ShellModule constructor
    shell_module = ShellModule()
    shell_module.get_remote_filename('hello')

    # test ShellModule._encode_script method
    shell_module._encode_script('hello')

# Test ShellModule.get_remote_filename method

# Generated at 2022-06-25 11:49:31.834753
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    env_string_0 = 'foo'
    shebang_0 = '#!/usr/bin/python'
    cmd_0 = 'bar'
    arg_path_0 = None
    shell_module_0.build_module_command(env_string_0, shebang_0, cmd_0, arg_path_0)


# Generated at 2022-06-25 11:49:39.218932
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    # Check the value of remote_user
    assert(shell_module_1.remote_user == shell_module_1.get_remote_user())
    # Check the value of remote_pass
    assert(shell_module_1.remote_pass == shell_module_1.get_remote_pass())
    # Check the value of transport_set
    assert(shell_module_1.transport_set == shell_module_1.get_transport_set())
    # Check the value of remote_port
    assert(shell_module_1.remote_port == shell_module_1.get_remote_port())
    # Check the value of host
    assert(shell_module_1.host == shell_module_1.get_host())
    # Check the value of remote_tmp

# Generated at 2022-06-25 11:49:50.946668
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print ("test_ShellModule")
    shell_module = ShellModule()
    cmd = 'cmd'
    print(shell_module.build_module_command(cmd,cmd))
    print(shell_module.get_remote_filename('test.ps1'))
    try:
        shell_module.checksum('test')
    except NotImplementedError:
        print('test_checksum')
    try:
        shell_module.chmod('test')
    except NotImplementedError:
        print('test_chmod')
    try:
        shell_module.chown('test')
    except NotImplementedError:
        print('test_chown')
    print (shell_module.env_prefix())

# Generated at 2022-06-25 11:49:55.744080
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:50:02.306521
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_1 = ShellModule()
    basefile = 'ansible'
    system = False
    mode = None
    tmpdir = 'C:\\Windows\\Temp\\'
    rval = shell_module_1.mkdtemp(basefile=basefile, system=system, mode=mode, tmpdir=tmpdir)
    expected_rval = u"& ([ScriptBlock]::Create(\"$tmp_path = [System.Environment]::ExpandEnvironmentVariables('C:\\Windows\\Temp\\')\r\n$tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible'\r\nWrite-Output -InputObject $tmp.FullName\r\n\"))"
    assert rval == expected_rval, "Test case failed for method \"mkdtemp\" of class \"ShellModule\""



# Generated at 2022-06-25 11:50:04.644197
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    assert shell_module_0.path_has_trailing_slash("test") == (False)


# Generated at 2022-06-25 11:50:10.714046
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    # User home directory is root.
    user_home_path_0 = '~'
    username_0 = 'admin'
    shell_module_0.expand_user(user_home_path_0, username_0)
    # User home directory is root.
    user_home_path_0 = '~'
    username_0 = 'admin'
    shell_module_0.expand_user(user_home_path_0, username_0)


# Generated at 2022-06-25 11:50:11.626236
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

test_ShellModule()

# Generated at 2022-06-25 11:50:13.949520
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0
    assert isinstance(shell_module_0, ShellModule)

# test for method env_prefix

# Generated at 2022-06-25 11:50:17.765856
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert(True)


# Generated at 2022-06-25 11:50:22.658912
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    assert shell_module.path_has_trailing_slash("/home/abc") is True
    assert shell_module.path_has_trailing_slash("/home/abc/") is True
    assert shell_module.path_has_trailing_slash("C:\\Program Files\\abc") is False
    assert shell_module.path_has_trailing_slash("C:\\Program Files\\abc\\") is True
    assert shell_module.path_has_trailing_slash("/home/abc\\") is False
    assert shell_module.path_has_trailing_slash("C:\\Program Files\\abc/") is False


# Generated at 2022-06-25 11:50:24.390227
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print("Test Case Empty Constructor of ShellModule")
    if shell_module_0 is not None:
        raise AssertionError("Object not created")


# Generated at 2022-06-25 11:50:33.007469
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# import module snippets.  This are required
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.basic import env_fallback
# import module snippets.  This are required
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.basic import env_fallback
# import module snippets.  This are required
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.basic import env_fallback


# Generated at 2022-06-25 11:50:41.783049
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:50:43.900387
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    str_0 = ''
    var_0 = shell_module_0.expand_user(str_0)


# Generated at 2022-06-25 11:50:44.998547
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:46.786153
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    str_0 = "/test"
    var_0 = path_has_trailing_slash(str_0)


# Generated at 2022-06-25 11:50:47.997611
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    return shell_module_1


# Generated at 2022-06-25 11:50:58.988972
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    str_0 = 'hello'
    shell_module_0 = ShellModule()
    
    var_0 = shell_module_0.get_user_home_dir(str_0)
    var_1 = 'C:\\Users\\' + str_0
    assert var_0 == var_1
    
    var_2 = shell_module_0.expand_user('~')
    assert var_2 == 'C:\\Users\\' + str_0
    
    var_3 = shell_module_0.expand_user('~\\hello')
    assert var_3 == 'C:\\Users\\' + str_0 + '\\hello'
    
    str_1 = 'C:\\Users\\' + str_0 + '\\hello'

# Generated at 2022-06-25 11:51:00.449044
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    str_0 = 'C:\\'
    var_0 = shell_module_0.path_has_trailing_slash(str_0)


# Generated at 2022-06-25 11:51:03.057185
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()

# unit test for method get_option()
#def test_ShellModule_get_option():
 #   assert ShellModule.get_option()

# Generated at 2022-06-25 11:51:12.878715
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_test_1 = ShellModule()
    assert isinstance(shell_module_test_1, ShellModule)
    str_test_1 = 'hello'
    assert shell_get_remote_filename(str_test_1) == 'hello.ps1'
    str_test_2 = 'hello.ps1'
    assert shell_get_remote_filename(str_test_2) == 'hello.ps1'
    str_test_3 = 'hello.txt'
    assert shell_get_remote_filename(str_test_3) == 'hello.ps1'
    str_test_4 = 'hello.bat'
    assert shell_get_remote_filename(str_test_4) == 'hello.ps1'
    str_test_5 = 'hello.exe'
    assert shell_get_remote_filename

# Generated at 2022-06-25 11:51:18.347383
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print(shell_module_0)
    shell_module_1 = ShellModule(connection=None, shell_type=None, no_log=False)
    print(shell_module_1)


# Generated at 2022-06-25 11:51:26.153534
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    """
    Test if the respective ansible module is actually installed.

    """
    from ansible.modules.windows.win_ping import build_module_command
    
    assert hasattr(build_module_command,"__call__")



# Generated at 2022-06-25 11:51:28.864300
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:51:31.937133
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    var_0 = './src/ansible/plugins/shell/powershell.py'
    var_1 = shell_module_0.get_remote_filename(var_0)
    var_2 = 'powershell.py'
    assert var_1 == var_2, 'var_1 == var_2'

# Generated at 2022-06-25 11:51:33.543676
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # TODO: init ShellModule

    pass

# Generated at 2022-06-25 11:51:37.890913
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_mkdtemp(shell_module_0)


# Generated at 2022-06-25 11:51:39.093454
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()

test_case_0()

# Generated at 2022-06-25 11:51:50.962138
# Unit test for method build_module_command of class ShellModule

# Generated at 2022-06-25 11:52:02.583972
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shebang = "#!powershell"
    cmd = "-Type 'Foo'"
    arg_path = "C:/tmp/Test.ps1"
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    remote_path = "{0}\\{1}".format(tempfile.gettempdir(), "Test.ps1")

    shell_module_0 = ShellModule()
    var_0 = shell_module_0.build_module_command('', shebang, cmd, arg_path)
    var_1 = shell_module_0.normalize_path(var_0)
    var_2 = shell_module_0.normalize_path(bootstrap_wrapper)

    assert var_0.strip() == var_1.strip() and var_1

# Generated at 2022-06-25 11:52:06.971638
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null', 'Failed to create ShellModule object'
    assert shell_module_0._SHELL_AND == ';', 'Failed to create ShellModule object'



# Generated at 2022-06-25 11:52:10.541366
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_1 = ShellModule()
    assert shell_module_1.path_has_trailing_slash(r'c:\\') == True

# Generated at 2022-06-25 11:52:19.165170
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:52:24.591766
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_1 = ShellModule()
    var_1 = shell_get_remote_filename(shell_module_1, pathname='...')
    assert var_1 == '...'


# Generated at 2022-06-25 11:52:27.770816
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO: Add your code here.
    # Check if the shell module is created.
    shell_module_0 = ShellModule()
    return shell_module_0.SHELL_FAMILY


# Generated at 2022-06-25 11:52:34.611191
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    if is_private_func(ShellModule, 'get_remote_filename'):
        return
    shell_module_0 = ShellModule()
    var_0 = 'wKeJH'
    assert shell_module_0.get_remote_filename(var_0) == 'wKeJH.ps1'


# Generated at 2022-06-25 11:52:37.010050
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    pathname = 'test'
    assert shell_module_0.get_remote_filename(pathname) == 'test.ps1'


# Generated at 2022-06-25 11:52:41.645296
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash('%TEMP%')


# Generated at 2022-06-25 11:52:43.125295
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:52:53.240332
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert callable(getattr(shell_module_0, 'env_prefix', None))
    assert callable(getattr(shell_module_0, 'join_path', None))
    assert callable(getattr(shell_module_0, 'get_remote_filename', None))
    assert callable(getattr(shell_module_0, 'path_has_trailing_slash', None))
    assert callable(getattr(shell_module_0, 'chmod', None))
    assert callable(getattr(shell_module_0, 'chown', None))
    assert callable(getattr(shell_module_0, 'set_user_facl', None))
    assert callable(getattr(shell_module_0, 'remove', None))

# Generated at 2022-06-25 11:52:56.994303
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash(path='C:\\Users\\XYZ')
    assert var_0 == True



# Generated at 2022-06-25 11:52:57.989096
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:53:15.696786
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0._SHELL_REDIRECT_ALLNULL
    var_1 = shell_module_0.COMPATIBLE_SHELLS
    var_2 = shell_module_0.SHELL_FAMILY
    var_3 = shell_module_0._IS_WINDOWS
    var_4 = shell_module_0.env_prefix()
    var_5 = shell_module_0.join_path(var_0, var_3)
    var_6 = shell_module_0.get_remote_filename(var_5)
    var_7 = shell_module_0.path_has_trailing_slash(var_5)
    var_8 = shell_module_0.chmod(var_6, var_2)
    var_

# Generated at 2022-06-25 11:53:17.634862
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:53:18.953487
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert True


# Generated at 2022-06-25 11:53:22.407564
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # check if the ShellModule object is constructed
    return True


# Generated at 2022-06-25 11:53:29.851337
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_instance = ShellModule()
    # Try to access the following module attributes:
    # shell_module_instance.SHELL_FAMILY
    # shell_module_instance.COMPATIBLE_SHELLS
    # shell_module_instance._SHELL_REDIRECT_ALLNULL
    # shell_module_instance._SHELL_AND
    # shell_module_instance._IS_WINDOWS


# Generated at 2022-06-25 11:53:31.929100
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    if isinstance(shell_module, ShellModule):
        print(True)
    else:
        print(False)


# Generated at 2022-06-25 11:53:41.007612
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_0 = ShellModule()
    pathname_0 = "~/dir1/dir2/abcdef.plays.sh"
    shell_module_0.get_remote_filename(pathname_0)
    pathname_0 = ".vimrc"
    shell_module_0.get_remote_filename(pathname_0)
    pathname_0 = "abs/path/with/trailing/slash/"
    shell_module_0.get_remote_filename(pathname_0)
    pathname_0 = "file.ps1"
    shell_module_0.get_remote_filename(pathname_0)
    pathname_0 = "file.exe"
    shell_module_0.get_remote_filename(pathname_0)
    pathname_0 = "file.sh"
    shell

# Generated at 2022-06-25 11:53:44.206924
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert isinstance(shell_module_1, ShellModule)


# Generated at 2022-06-25 11:53:46.332396
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:53:50.353549
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_chmod(shell_module_0)


# Generated at 2022-06-25 11:54:00.986455
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        result_0 = ShellModule()
    except Exception as e:
        print(e)
        print('TEST FAIL : test_ShellModule()')
        return

    print('TEST SUCCESS : test_ShellModule()')


# Generated at 2022-06-25 11:54:03.270378
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert(shell_module_1.get_option('_shell_type') == 'powershell')


# Generated at 2022-06-25 11:54:06.208857
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.__class__.__name__ == 'ShellModule'
    assert shell_module_0.__class__.__bases__[0].__name__ == 'ShellBase'


# Generated at 2022-06-25 11:54:10.208613
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:54:11.366095
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:54:12.741690
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module != None

# Generated at 2022-06-25 11:54:23.713363
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_option("remote_tmp")
    var_1 = shell_module_0.get_option("_ansible_check_mode")
    var_2 = shell_module_0.get_option("_ansible_remote_tmp")
    var_3 = shell_module_0.get_option("_ansible_keep_remote_files")
    var_4 = shell_module_0.get_option("_ansible_tmpdir")
    var_5 = shell_module_0.get_option("_ansible_no_log")
    var_6 = shell_module_0.get_option("_ansible_verbosity")
    var_7 = shell_module_0.get_option("_ansible_version")
    var

# Generated at 2022-06-25 11:54:29.013966
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.set_options()
    shell_module_0.chown('/var/log/ansible', 'username')



# Generated at 2022-06-25 11:54:30.271502
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # TODO: add a test case
    # ShellModule()
    pass


# Generated at 2022-06-25 11:54:33.912860
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None
    assert shell_module_1._IS_WINDOWS
    assert shell_module_1._SHELL_AND == ';'
    assert shell_module_1._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_1.SHELL_FAMILY == 'powershell'
    assert shell_module_1.COMPATIBLE_SHELLS == frozenset()


# Generated at 2022-06-25 11:54:48.869177
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if (not (isinstance(shell_module_0, ShellModule))):
        raise Exception('Failed to instantiate class ShellModule')


# Generated at 2022-06-25 11:54:59.210903
# Unit test for constructor of class ShellModule
def test_ShellModule():
    cwd = os.path.dirname(os.path.dirname(__file__))
    conf = {}
    conf['EXECUTABLE'] = '/usr/bin/powershell'
    conf['ARGS'] = '-c'
    conf['REMOTE_TMP'] = '/tmp/tmp_zquh_T'
    conf['TMP_DIR'] = '/tmp/tmp_zquh_T'
    conf['LOCAL_TMP'] = '/tmp/tmp_zquh_T'
    conf['REMOTE_TMP'] = '/tmp/tmp_zquh_T'
    conf['DEFAULT_TMPFILE_PLUGIN'] = 'tmp_zquh_T'
    conf['MODULE_COMPLEX_ARGS'] = 'tmp_zquh_T'

# Generated at 2022-06-25 11:55:04.014599
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:55:07.920472
# Unit test for constructor of class ShellModule
def test_ShellModule():
    script = "# This is the shebang.\necho Hello World\n"
    c = ShellModule()
    # validate that ShellModule.build_module_command() doesn't throw an exception
    # and returns None if script is None
    command = c.build_module_command('', '', None)
    assert command is None
    command = c.build_module_command('', '', script)
    assert command is not None



# Generated at 2022-06-25 11:55:09.400225
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Call function to test
    test_case_0()



# Generated at 2022-06-25 11:55:11.770291
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:55:18.799908
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # create an instance of class ShellModule
    shell_module_0 = ShellModule()

    # get the value of variables
    var_0 = shell_path_has_trailing_slash(shell_module_0)
    var_1 = shell_get_remote_filename(shell_module_0, str)
    var_2 = shell_join_path(shell_module_0, str)
    var_3 = shell_set_user_facl(shell_module_0, str)
    var_4 = shell_chmod(shell_module_0, str)
    var_5 = shell_chown(shell_module_0, str)
    var_6 = shell_expand_user(shell_module_0, str)
    var_7 = shell_exists(shell_module_0, str)
    var_

# Generated at 2022-06-25 11:55:19.836470
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:21.041001
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)

# Generated at 2022-06-25 11:55:22.916049
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # We should be able to instantiate an object of ShellModule
    shell_module = ShellModule()
    assert shell_module



# Generated at 2022-06-25 11:55:44.102261
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellModule)


# Generated at 2022-06-25 11:55:45.620185
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:57.380670
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        _inherited_from_ShellBase = issubclass(ShellModule, ShellBase)
    except NameError:
        _inherited_from_ShellBase = False

    assert _inherited_from_ShellBase == True, 'Inheritance Error: ShellModule did not inherited from ShellBase'

    shell_module_0 = ShellModule()
    var_0 = to_text(shell_module_0._SHELL_REDIRECT_ALLNULL, 'utf-8')
    var_0 = to_text(shell_module_0._SHELL_AND, 'utf-8')

    # TODO: check the attributes
    # assert var_0 == '> $null', 'Wrong or Missing Value'
    # assert var_0 == ';', 'Wrong or Missing Value'


# Generated at 2022-06-25 11:55:59.642055
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    try:
        os.path.abspath(shell_module_0)
    except Exception:
        print ("Exception in test_ShellModule")


# Generated at 2022-06-25 11:56:06.834010
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    normal_xml_0 = shell_build_module_command(shell_module_0)
    var_0 = shell_path_has_trailing_slash(shell_module_0)

if __name__ == '__main__':
    test_ShellModule()
    test_case_0()

# Generated at 2022-06-25 11:56:07.967190
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test 1
    assert test_case_0()


# Generated at 2022-06-25 11:56:09.208376
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.environment



# Generated at 2022-06-25 11:56:10.954142
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Constructor of class ShellModule
    global shell_module_0
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:15.910799
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_path_has_trailing_slash(shell_module_0)
    return None


# Generated at 2022-06-25 11:56:23.050545
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    var_1 = shell_module_1.build_module_command()
    var_1 = shell_module_1.env_prefix()
    var_1 = shell_module_1.join_path()
    var_1 = shell_module_1.get_remote_filename()
    var_1 = shell_module_1.path_has_trailing_slash()
    var_1 = shell_module_1.chmod()
    var_1 = shell_module_1.chown()
    var_1 = shell_module_1.set_user_facl()
    var_1 = shell_module_1.remove()
    var_1 = shell_module_1.mkdtemp()
    var_1 = shell_module_1.expand_user()
    var

# Generated at 2022-06-25 11:57:00.268385
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:57:06.898830
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0._escape('C:\\users\\dhirst')
# unit tests end here

if __name__ == '__main__':
    import sys
    import inspect
    import __main__

    if len(sys.argv) > 1:
        # run only the selected tests
        module_selected = True
        tests = inspect.getmembers(sys.modules[__main__], inspect.isfunction)
        # remove all tests that do not start with "test"
        tests = dict((k, v) for k, v in tests if k.startswith("test_"))
        # run only the selected tests
        for test in tests:
            if test == sys.argv[1]:
                print("running test " + test)
                tests[test]()
                module_selected

# Generated at 2022-06-25 11:57:11.156647
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert(not shell_module_1 is None)


# Generated at 2022-06-25 11:57:12.909834
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:57:17.146908
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule('ssh')
    # Check if the plugin has been initialized correctly
    assert shell.run() == "ssh -tt"


# Generated at 2022-06-25 11:57:18.850548
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:57:20.020689
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert type(shell_module_0) is ShellModule


# Generated at 2022-06-25 11:57:21.942718
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    print(shell_module_1)

if __name__ == "__main__":
    # test_case_0()
    test_ShellModule()

# Generated at 2022-06-25 11:57:27.947008
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_executor_0 = ShellModule()
    assert shell_executor_0._encode_script(script='test')
    assert shell_executor_0._unquote(shell_executor_0)
    assert shell_executor_0._escape(shell_executor_0)
    assert shell_executor_0.get_remote_filename(pathname='')
    assert shell_executor_0.join_path('')
    assert shell_executor_0.env_prefix()
    assert shell_executor_0.exists(path='')

# Generated at 2022-06-25 11:57:31.674417
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.__class__.__name__ == 'ShellModule'