

# Generated at 2022-06-25 11:48:07.828191
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # call the constructor
    shell_module = ShellModule()
    assert shell_module.__doc__ is not None



# Generated at 2022-06-25 11:48:19.251473
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    shebang_0 = '#!powershell'
    cmd_0 = 'win_ping'
    subproc_1, rc_1 = shell_module_0.build_module_command('', shebang_0, cmd_0, arg_path='\'')
    assert subproc_1[0][0] == 'PowerShell'
    assert subproc_1[0][7] == '$res = $null;'
    assert subproc_1[0][8] == '$res = $PsCmdlet.Runspace.SessionStateProxy.InvokeCommand.ExpandString("{ { $res = { { & $script_ps1; exit $res } } } }")'

# Generated at 2022-06-25 11:48:21.072013
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
    except Exception as msg:
        print(msg)


# Generated at 2022-06-25 11:48:24.027596
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    result = ShellModule().expand_user('~')
    assert '''$Env:UserProfile''' in result.decode()

# Need a way to mock a connection


# Generated at 2022-06-25 11:48:25.616973
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None, "Testing constructor of class ShellModule"


# Generated at 2022-06-25 11:48:28.922366
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module = ShellModule()
    assert(shell_module.SHELL_FAMILY == 'powershell')
    # assert(shell_module.COMPATIBLE_SHELLS == frozenset(['C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe', 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'])

# Generated at 2022-06-25 11:48:31.914301
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_obj = ShellModule()
    test_val_0 = shell_module_obj.expand_user('~')
    # assertion
    assert test_val_0  == 'Write-Output (Get-Location).Path'


# Generated at 2022-06-25 11:48:33.544181
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 11:48:37.059557
# Unit test for constructor of class ShellModule
def test_ShellModule():
    global shell_module_0
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:48:40.851323
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    test_case_0()
    shell_module_0 = ShellModule()
    path_0 = "C:\\"
    assert(shell_module_0.path_has_trailing_slash(path=path_0) == True)


# Generated at 2022-06-25 11:48:55.882380
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    print("Test: mkdtemp method of ShellModule")
    shell_module_0 = ShellModule()
    invariant_0 = shell_module_0.__class__.SHELL_FAMILY
    invariant_1 = shell_module_0.COMPATIBLE_SHELLS
    invariant_2 = shell_module_0._SHELL_REDIRECT_ALLNULL
    invariant_3 = shell_module_0._IS_WINDOWS
    invariant_4 = shell_module_0._SHELL_AND
    print("Result:", shell_module_0.mkdtemp())
    print("Result:", shell_module_0.mkdtemp(basefile="basefile_value_0"))
    print("Result:", shell_module_0.mkdtemp(system=True))

# Generated at 2022-06-25 11:48:59.331423
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert ShellModule._IS_WINDOWS
    assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule._SHELL_AND == ';'


# Generated at 2022-06-25 11:49:01.405344
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:49:10.255042
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
#
# The following kwargs will be used for test:
# basefile=None, system=False, mode=None, tmpdir=None
#
# The following exception will be raised during this test:
# NotImplementedError -> chmod is not implemented for Powershell
#
    shell_module_0 = ShellModule()
    basefile = None
    system = False
    mode = None
    tmpdir = None

    try:
        shell_module_0.mkdtemp(None, None)
        assert(False)
    except Exception as e:
        assert(True)


# Generated at 2022-06-25 11:49:12.985362
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        assert True == isinstance(ShellModule(), ShellBase)
    except AssertionError as e:
        print("Error: Expected ShellBase to be the instance of ShellModule...")
        print(type(ShellModule()))
        raise e


# Generated at 2022-06-25 11:49:19.044680
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # create object of class ShellModule
    shell_module_0 = ShellModule()
    # tests for class method get_remote_filename
    pathname = "test.sh"
    assert (shell_module_0.get_remote_filename(pathname) == 'test.ps1')
    pathname = "test.py"
    assert (shell_module_0.get_remote_filename(pathname) == 'test.ps1')
    pathname = "test.exe"
    assert (shell_module_0.get_remote_filename(pathname) == 'test.exe')



# Generated at 2022-06-25 11:49:21.147716
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_obj = ShellModule()
    print('mkdtemp():')
    print(shell_module_obj.mkdtemp())


# Generated at 2022-06-25 11:49:25.063353
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
    except Exception as e:
        print("Exception caught in unit test: " + repr(e))
        assert False

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:49:28.755609
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    env_string_0 = to_text(ShellModule._encode_script('$env:ANSIBLE_VAR=1', preserve_rc=False))
    shebang_0 = ''
    cmd_0 = to_text('/usr/local/bin/ansible-connection --local')
    arg_path_0 = None
    assert shell_module_0.build_module_command(env_string_0, shebang_0, cmd_0, arg_path_0) == u'& /usr/local/bin/ansible-connection --local; exit $LASTEXITCODE'


# Generated at 2022-06-25 11:49:30.002612
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None


# Generated at 2022-06-25 11:49:40.248397
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # str
    shebang = "#!powershell"
    cmd = "type test1.ps1 | $env:ANSIBLE_POWERSHELL_SHIM"
    arg_path = None

    expected_cmd = "& type test1.ps1 | $env:ANSIBLE_POWERSHELL_SHIM; exit $LASTEXITCODE"
    expected_rc = 0

    shell_module_0 = ShellModule()
    cmd = shell_module_0.build_module_command("", shebang, cmd, arg_path)
    cmd_rc = shell_module_0.run(cmd)

    if cmd_rc == expected_rc:
        return 0
    else:
        return 1

if __name__ == '__main__':
    import sys

# Generated at 2022-06-25 11:49:45.955379
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    cmd = u'.\\Example_PowerShell_Script.ps1 -Arg1 Test_Value'
    arg_path = None
    shebang = u'#!powershell'
    env_string = u''
    expected_result = u'.\\Example_PowerShell_Script.ps1 -Arg1 Test_Value'
    assert expected_result == shell_module.build_module_command(env_string, shebang, cmd, arg_path)



# Generated at 2022-06-25 11:49:57.128252
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True
    assert shell_module.build_module_command(str(),str(),str(),str()) == to_bytes('& \r\n; exit $LASTEXITCODE')
    assert shell_module.env_prefix() == ''
    assert shell_module.join_path('\\a','b') == '\\a\\b'

# Generated at 2022-06-25 11:49:57.952750
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # TODO: implement test



# Generated at 2022-06-25 11:50:04.607436
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    basefile = 'test_basefile'
    system = True
    mode = 'test_mode'
    tmpdir = 'test_tmpdir'
    shell_module_0.mkdtemp(basefile, system, mode, tmpdir)


# Generated at 2022-06-25 11:50:07.575063
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    # Test value of attribute COMPATIBLE_SHELLS
    assert(shell_module.COMPATIBLE_SHELLS == frozenset())

# Generated at 2022-06-25 11:50:19.668046
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    assert shell_module_0.path_has_trailing_slash("test_string") == False
    assert shell_module_0.path_has_trailing_slash("C:\\Windows\\Temp") == False
    assert shell_module_0.path_has_trailing_slash("C:\\Temp") == False
    assert shell_module_0.path_has_trailing_slash("\\Temp") == False
    assert shell_module_0.path_has_trailing_slash("") == False
    assert shell_module_0.path_has_trailing_slash("\\") == True
    assert shell_module_0.path_has_trailing_slash("\\\\") == True
    assert shell_module_0.path_has_trailing_slash

# Generated at 2022-06-25 11:50:20.836427
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    assert 0 == 0 # Placeholder for fix.


# Generated at 2022-06-25 11:50:23.596088
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Create mock object
    test_case_0()

    ShellModule.expand_user("", "")


# Generated at 2022-06-25 11:50:34.993794
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_1 = ShellModule()
    # True check
    result_bool_1 = shell_module_1.expand_user(user_home_path='~', username=None) == u'Write-Output (Get-Location).Path'
    result_bool_2 = shell_module_1.expand_user(user_home_path='~\\a', username=None) == u'Write-Output ((Get-Location).Path + \'a\')'
    result_bool_3 = shell_module_1.expand_user(user_home_path='~\\a\\c', username=None) == u'Write-Output ((Get-Location).Path + \'a\\\\c\')'
    # False check

# Generated at 2022-06-25 11:50:38.832073
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:41.712840
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if not isinstance(shell_module_0, ShellModule):
        raise Exception("#1 shell_module_0 is not instance of ShellModule")


# Generated at 2022-06-25 11:50:42.655977
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:50:43.941023
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None


# Generated at 2022-06-25 11:50:47.036661
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    string_0 = u'%systemroot%\\Temp\\ansible-tmp-1482507282.7-175338755213449\\'
    
    shell_module_0 = ShellModule()
    assert(shell_module_0.path_has_trailing_slash(string_0) == True)


# Generated at 2022-06-25 11:50:50.261380
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename('/root/ansible/test/test_module.py')
    assert var_0 == 'test_module.ps1'

    var_1 = shell_module_0.get_remote_filename('/root/ansible/test/test_module.exe')
    assert var_1 == 'test_module.exe'


# Generated at 2022-06-25 11:50:54.049935
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert(True)


# Generated at 2022-06-25 11:50:55.370284
# Unit test for constructor of class ShellModule
def test_ShellModule():
    t0 = ShellModule()
    assert isinstance(t0, ShellModule)

# Generated at 2022-06-25 11:50:57.162701
# Unit test for constructor of class ShellModule
def test_ShellModule():
    with pytest.raises(NotImplementedError):
        assert ShellModule.get_remote_filename("") == ""


# Generated at 2022-06-25 11:51:00.490546
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test for constructor of class ShellModule
    shell_module_0 = ShellModule()

    # Test for function wrap_for_exec
    output_0 = shell_wrap_for_exec(shell_module_0)


# Generated at 2022-06-25 11:51:08.770657
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    var_1 = shell_module_1.get_remote_filename('file_name.extension')
    assert var_1 == 'file_name.extension'
    var_1 = shell_module_1.get_remote_filename('file_name')
    assert var_1 == 'file_name.ps1'

# Generated at 2022-06-25 11:51:11.082641
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    obj = ShellModule()
    path = 'test/dir/'
    assertTrue(path, obj.path_has_trailing_slash(path))


# Generated at 2022-06-25 11:51:21.038466
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash("""a""")
    assert var_0 == ("""False""")
    var_0 = shell_module_0.path_has_trailing_slash("""a\b""")
    assert var_0 == ("""False""")
    var_0 = shell_module_0.path_has_trailing_slash("""/""")
    assert var_0 == ("""True""")

# Generated at 2022-06-25 11:51:22.663603
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0


# Generated at 2022-06-25 11:51:24.508281
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None, "Failed to instantiate ShellModule"

# Generated at 2022-06-25 11:51:26.767751
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash("C:\Windows\System32")
    assert var_0 == False



# Generated at 2022-06-25 11:51:37.995118
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import unittest

    class test_ShellModule(unittest.TestCase):
        shell_module_0 = ShellModule()
        print(ShellModule.COMPATIBLE_SHELLS)
        print(ShellModule.SHELL_FAMILY)
        print(ShellModule._IS_WINDOWS)
        print(ShellModule._SHELL_REDIRECT_ALLNULL)
        print(ShellModule._SHELL_AND)

        # Unit test for method env_prefix
        def test_env_prefix(self):
            shell_module_0.env_prefix()

        # Unit test for method join_path
        def test_join_path(self):
            shell_module_0.join_path('', '')

        # Unit test for method get_remote_filename
        def test_get_remote_filename(self):
            shell_

# Generated at 2022-06-25 11:51:39.287416
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()



# Generated at 2022-06-25 11:51:49.263377
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    my_sheller = ShellModule()
    my_sheller.path_has_trailing_slash('c:/path')
    my_sheller.path_has_trailing_slash('c:/path ')
    my_sheller.path_has_trailing_slash('c:/path "')
    my_sheller.path_has_trailing_slash('c:/path /')
    my_sheller.path_has_trailing_slash('c:/path \\')
    my_sheller.path_has_trailing_slash('c:/path "\\')


# Generated at 2022-06-25 11:51:51.432274
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash('')


# Generated at 2022-06-25 11:51:57.246342
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:51:58.179549
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert test_case_0() == None

# Generated at 2022-06-25 11:52:01.069415
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Testing constructor for a class ShellModule, with arg list
    shell_module_0 = ShellModule()
    # Testing constructor for a class ShellModule, with arg dict
    shell_module_1 = ShellModule()
    return shell_module_0, shell_module_1


# Generated at 2022-06-25 11:52:04.766654
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule().COMPATIBLE_SHELLS == frozenset()
    assert ShellModule()._IS_WINDOWS == True
    assert ShellModule()._SHELL_AND == ';'
    assert ShellModule()._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule().SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:52:06.453094
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 != None


# Generated at 2022-06-25 11:52:08.214777
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_2 = ShellModule()
    assert shell_module_2


# Generated at 2022-06-25 11:52:19.744681
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with default arguements.
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0.can_pipeline == True
    assert shell_module_0.STREAM_OUTPUT_SEPARATOR == '\r\n'

    return shell_module_0


# Generated at 2022-06-25 11:52:31.006954
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_join_path(shell_module_0)
    shell_expand_user(shell_module_0)
    shell_exists(shell_module_0)
    shell_checksum(shell_module_0)
    shell_build_module_command(shell_module_0)
    shell_wrap_for_exec(shell_module_0)
    shell_chmod(shell_module_0)
    shell_chown(shell_module_0)
    shell_set_user_facl(shell_module_0)
    shell_path_has_trailing_slash(shell_module_0)
    shell_get_remote_filename(shell_module_0)
    shell_env_prefix(shell_module_0)

# Generated at 2022-06-25 11:52:35.011191
# Unit test for constructor of class ShellModule
def test_ShellModule():
    '''
    Ensure that __init__() does not raise any errors.
    '''
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:39.802361
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0.__class__._IS_WINDOWS == True
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'


# Generated at 2022-06-25 11:52:55.704350
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # argument number 1 (as_list): False
    # argument number 2 (strict_mode): True
    # argument number 3 (preserve_rc): True
    shell_module_1 = ShellModule()
    arg_1 = False
    arg_2 = True
    arg_3 = True
    shell_module_1.wrap_for_exec(arg_1)
    shell_module_1.build_module_command(arg_1, arg_2, arg_3)
    shell_module_1.join_path(arg_1, arg_2, arg_3)
    shell_module_1.get_remote_filename(arg_1)
    shell_module_1.path_has_trailing_slash(arg_1)
    shell_module_1.chmod(arg_1, arg_2)
    shell

# Generated at 2022-06-25 11:52:58.260848
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_remove(shell_module_0)


# Generated at 2022-06-25 11:52:59.109854
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:53:08.653730
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.path_has_trailing_slash('')
    var_1 = shell_module_0.join_path('')
    var_2 = shell_module_0.checksum('')
    var_3 = shell_module_0.mkdtemp('')
    var_4 = shell_module_0.expand_user('')
    var_5 = shell_module_0.exists('')
    var_6 = shell_module_0.get_remote_filename('')
    var_7 = shell_module_0.env_prefix()
    # Unreachable code
    # var_8 = shell_module_0.remove('')
    # var_9 = shell_module_0.chmod(

# Generated at 2022-06-25 11:53:15.972463
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    # Unit test for join_path of class ShellModule
    var_1 = shell_join_path(shell_module_1, "", "")
    assert var_1 == ""
    var_1 = shell_join_path(shell_module_1, ".")
    assert var_1 == "."
    var_1 = shell_join_path(shell_module_1, "..")
    assert var_1 == ".."
    var_1 = shell_join_path(shell_module_1, "foo")
    assert var_1 == "foo"
    var_1 = shell_join_path(shell_module_1, ".\\foo")
    assert var_1 == "foo"
    var_1 = shell_join_path(shell_module_1, "foo\\")


# Generated at 2022-06-25 11:53:22.636350
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_name = "ShellModule"
    try:
        script_contents = "my test script"
        shell_module_1 = ShellModule()
        shell_module_1.checksum()
        shell_module_1.set_user_facl()
        shell_module_1.chown()
        shell_module_1.build_module_command()
        shell_module_1.mkdtemp()
        shell_module_1.join_path()

    except:
        print ("constructor of class ShellModule threw")


# Generated at 2022-06-25 11:53:27.835836
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:53:28.289856
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-25 11:53:29.801782
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:53:31.541364
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    var_1 = shell_remove(shell_module_1)


# Generated at 2022-06-25 11:53:45.911297
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_remove(shell_module_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:53:54.937639
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Verify that the remove function is properly implemented
    shell_remove_0 = ShellModule()
    var_0 = shell_remove_0
    if var_0 == 0:
        print("Test 1 passed")
    else:
        print("Test 1 failed")

    shell_remove_1 = ShellModule()
    var_1 = shell_remove_1
    if var_1 == 0:
        print("Test 2 passed")
    else:
        print("Test 2 failed")

    shell_remove_2 = ShellModule()
    var_2 = shell_remove_2
    if var_2 == 0:
        print("Test 3 passed")
    else:
        print("Test 3 failed")

    shell_remove_3 = ShellModule()
    var_3 = shell_remove_3

# Generated at 2022-06-25 11:54:05.868132
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._module_implementation is not None, 'ShellModule'
    assert shell_module_0._options is None, 'ShellModule'
    assert shell_module_0.SHELL_FAMILY == 'powershell', 'ShellModule'
    assert shell_module_0._shell_type == 'powershell', 'ShellModule'
    assert (shell_module_0.COMPATIBLE_SHELLS == frozenset()), 'ShellModule'
    assert (list(shell_module_0.COMPATIBLE_SHELLS) == []), 'ShellModule'

# Function test_case_0
# {
#     ShellModule shell_module_0;
#     String var_0;
#     var_0 = shell_remove(shell_module_0);
#

# Generated at 2022-06-25 11:54:07.179970
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1 is not None


# Generated at 2022-06-25 11:54:08.158680
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:54:10.776029
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_mod = ShellModule()

test_ShellModule()
test_case_0()

# Generated at 2022-06-25 11:54:11.929931
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("test_ShellModule")
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:54:21.927746
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Verify that the class instantiates
    assert shell_module_0 is not None
    # Verify that the shell_module_0.build_module_command() throws a NotImplementedError exception
    with pytest.raises(NotImplementedError):
        shell_module_0.build_module_command('env_string', 'shebang', 'cmd', 'arg_path')
    # Verify that the shell_module_0.get_remote_filename() returns a string
    var_0 = shell_module_0.get_remote_filename('pathname')
    assert type(var_0) == str
    # Verify that the shell_module_0.join_path() function returns a string
    var_1 = shell_module_0.join_path('*args')

# Generated at 2022-06-25 11:54:30.068182
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    shell_module_2 = ShellModule()


# Generated at 2022-06-25 11:54:40.072832
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Verifying that the value of base attribute '_SHELL_REDIRECT_ALLNULL' is "> $null".
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == "> $null"
    # Verifying that the value of base attribute '_SHELL_AND' is ";".
    assert shell_module_0._SHELL_AND == ";"
    # Verifying that the value of base attribute '_IS_WINDOWS' is True.
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:55:09.505454
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 != None


# Generated at 2022-06-25 11:55:13.559699
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        # Assigning values to variables for testing
        shell_module_0 = ShellModule()
    except Exception:
        # Raising exception in case of error
        raise RuntimeError("Failed to create an object of type ShellModule")



# Generated at 2022-06-25 11:55:14.626616
# Unit test for constructor of class ShellModule
def test_ShellModule():
    _obj_var_1 = ShellModule('')



# Generated at 2022-06-25 11:55:17.567067
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert(perform_shell_checks(shell_module_1))


# Generated at 2022-06-25 11:55:18.365182
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    pass

# Generated at 2022-06-25 11:55:21.083098
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert isinstance(obj, ShellModule)
    assert isinstance(obj._SHELL_REDIRECT_ALLNULL, str)
    assert isinstance(obj._SHELL_AND, str)
    assert obj._IS_WINDOWS
    assert isinstance(obj._common_args, list)

# Generated at 2022-06-25 11:55:22.679374
# Unit test for constructor of class ShellModule
def test_ShellModule():
    if not isinstance(ShellModule(), ShellModule):
        print("Not isinstance of ShellModule")


# Generated at 2022-06-25 11:55:27.634541
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except Exception as exception:
        assert True



# Generated at 2022-06-25 11:55:36.153819
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor.powershell.common import shell_remove

    shell_module_0 = ShellModule()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset([])
    assert shell_module_0.path_has_trailing_slash('C:\\Users\\Administrator\\Documents\\') == True
    assert shell_module_0.path_has_trailing_slash('C:\\Users\\Administrator\\Documents') == False

# Generated at 2022-06-25 11:55:38.268588
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:56:31.407887
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Print the name of the test
    print('\n\n*** Test shell_powershell/ShellModule.py:\n')

    # Call the test case
    test_case_0()



# Generated at 2022-06-25 11:56:32.040139
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_remove(ShellModule())


# Generated at 2022-06-25 11:56:35.118146
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_remove(shell_module_0)


# Generated at 2022-06-25 11:56:39.703434
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Return type: ShellModule
    arg_0 = {}
    shell_module_0 = ShellModule(arg_0)


# Generated at 2022-06-25 11:56:50.186326
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_join_path(shell_module_0)
    var_1 = shell_path_has_trailing_slash(shell_module_0)
    var_2 = shell_get_remote_filename(shell_module_0)
    var_3 = shell_set_user_facl(shell_module_0)
    var_4 = shell_chmod(shell_module_0)
    var_5 = shell_chown(shell_module_0)
    var_6 = shell_exists(shell_module_0)
    var_7 = shell_checksum(shell_module_0)
    var_8 = shell_mkdtemp(shell_module_0)
    var_9 = shell_expand_user(shell_module_0)


# Generated at 2022-06-25 11:56:55.876134
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-25 11:56:57.405656
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:57:06.339182
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.build_module_command(arg_path ="simple_dir")
    var_1 = shell_module_0.checksum(path ="simple_dir")
    var_2 = shell_module_0.chmod(paths ="simple_dir")
    var_3 = shell_module_0.chown(paths ="simple_dir")
    var_4 = shell_module_0.exists(path ="simple_dir")
    var_5 = shell_module_0.get_remote_filename(pathname ="simple_dir")
    var_6 = shell_module_0.join_path(arg ="simple_dir")

# Generated at 2022-06-25 11:57:17.082563
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Inferred assignment of var_0
    var_0 = ShellModule(None)
    # Inferred assignment of var_1
    var_1 = ShellModule(None)
    # Inferred assignment of var_2
    var_2 = ShellModule(None)
    # Inferred assignment of var_3
    var_3 = ShellModule(None)
    # Inferred assignment of var_4
    var_4 = ShellModule(None)
    # Inferred assignment of var_5
    var_5 = ShellModule(None)
    # Inferred assignment of var_6
    var_6 = ShellModule(None)
    # Inferred assignment of var_7
    var_7 = ShellModule(None)
    # Inferred assignment of var_8
    var_8 = ShellModule(None)
    # Inferred assignment of var_9


# Generated at 2022-06-25 11:57:19.284977
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule) == True
