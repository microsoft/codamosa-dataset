

# Generated at 2022-06-25 11:48:19.515603
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.module_utils import powershell

    shell_module_1 = powershell.ShellModule()

    assert shell_module_1.expand_user('~') == b'Write-Output (Get-Location).Path'
    assert shell_module_1.expand_user('~\\a') == b"Write-Output ((Get-Location).Path + '\\\\a')"
    assert shell_module_1.expand_user('a') == b"Write-Output 'a'"
    assert shell_module_1.expand_user('a\\b') == b"Write-Output 'a\\\\b'"
    assert shell_module_1.expand_user('~b') == b"Write-Output '~b'"

# Generated at 2022-06-25 11:48:26.213745
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_1 = ShellModule()
    for path in ['C:\\', 'D:\\a\\b\\c\\', 'E:\\', 'C:\\dir1\\\\dir2\\']:
        assert True == shell_module_1.path_has_trailing_slash(path)


# Generated at 2022-06-25 11:48:29.093578
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    assert shell_module.build_module_command(env_string='Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process -Force', shebang=None, cmd='test1 test2 test3') == '& test1 test2 test3; exit $LASTEXITCODE'


# Generated at 2022-06-25 11:48:32.030468
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    script_path = '~/bin/mkdir'
    expanded_path = shell_module_0.expand_user(script_path)
    assert '~' not in expanded_path


# Generated at 2022-06-25 11:48:36.490930
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:48:39.880701
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():

    shell_module_0 = ShellModule()

    expected = shell_module_0.build_module_command("", "", shell_module_0.mkdtemp())
    assert expected == "$tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')\n$tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-1532481547.8-294133394001859'\nWrite-Output -InputObject $tmp.FullName"

# Generated at 2022-06-25 11:48:43.086024
# Unit test for constructor of class ShellModule
def test_ShellModule():
    var_0 = ShellModule()
    # Assertion: ShellPluginBase instance var_0
    if not isinstance(var_0, ShellBase):
        raise AssertionError()

# Unit test sample case for method chmod of class ShellModule

# Generated at 2022-06-25 11:48:51.606814
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module_data = """#Fake PowerShell Script
    $var = 1
    echo "This is a fake PowerShell Script."
    echo $var
    exit 3"""
    module_path = 'test_script.ps1'
    # Open a file to write the ansible module
    module_file = open(module_path, 'w')
    # Write module to file
    module_file.write(module_data)
    # Close the file after writing to it
    module_file.close()
    # Instantiate a ShellModule object
    shell_module_1 = ShellModule()
    # Assert that the ShellModule object is not None
    assert shell_module_1 is not None
    # Call the build_module_command method from the ShellModule object

# Generated at 2022-06-25 11:48:59.396616
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    f = ShellModule()
    assert f.get_remote_filename('/test/with/slashes') == 'with_slashes.ps1'
    assert f.get_remote_filename('C:\\test\\with\\slashes') == 'with_slashes.ps1'
    assert f.get_remote_filename('C:\\test\\without\\slashes.exe') == 'without_slashes.exe.ps1'
    assert f.get_remote_filename('with_ext.exe') == 'with_ext.exe'
    assert f.get_remote_filename('with_ext.ps1') == 'with_ext.ps1'



# Generated at 2022-06-25 11:49:01.215723
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()

    res = shell_module_0.mkdtemp()

    print('mkdtemp : ' + res)



# Generated at 2022-06-25 11:49:11.499916
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    '''
    Test for method `mkdtemp` of class `ShellModule` which is used to create directories.

    :return: no return value
    '''
    shell_module = ShellModule()
    try:
        # execute the method under test
        shell_module.mkdtemp()
    except NotImplementedError as e:
        assert False, "Unit test for method `mkdtemp` of class `ShellModule` failed."
        print(e)
    else:
        pass
    finally:
        pass


# Generated at 2022-06-25 11:49:12.900855
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:49:20.097557
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_1 = ShellModule()
    # Case 1: Test successful execution
    env_string = ''
    shebang = '#!powershell'
    cmd = 'Get-ChildItem'
    arg_path = ''

# Generated at 2022-06-25 11:49:21.897205
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:49:26.327676
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()
    try:
        shell_module_0.mkdtemp()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 11:49:28.614035
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()

    assert shell_module._options is not None
    assert shell_module._tunnel is None



# Generated at 2022-06-25 11:49:30.901734
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    assert (not shell_module.path_has_trailing_slash('test'))
    assert shell_module.path_has_trailing_slash('test/')
    assert shell_module.path_has_trailing_slash('test\\')

# Generated at 2022-06-25 11:49:33.394496
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    result = shell_module_0.build_module_command(env_string=None, shebang=None, cmd='', arg_path=None)
    assert result is not None


# Generated at 2022-06-25 11:49:41.386131
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module_0 = ShellModule()

    assert shell_module_0.COMPATIBLE_SHELLS == ShellModule.COMPATIBLE_SHELLS
    assert shell_module_0.SHELL_FAMILY == ShellModule.SHELL_FAMILY
    assert shell_module_0._IS_WINDOWS == ShellModule._IS_WINDOWS
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == ShellModule._SHELL_REDIRECT_ALLNULL
    assert shell_module_0._SHELL_AND == ShellModule._SHELL_AND


# Generated at 2022-06-25 11:49:44.536653
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print(shell_module_0)


# Generated at 2022-06-25 11:49:58.824795
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module_0 = ShellModule()

    # Invoke method
    tmp_path = "/tmp"
    basefile = "_tmp"
    answer = shell_module_0.mkdtemp(basefile, tmpdir=tmp_path)

    # Check for expected answer

# Generated at 2022-06-25 11:50:07.999150
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    shebang = '#!powershell'
    cmd = 'type mymodule.ps1'
    result = shell_module_0.build_module_command('', shebang, cmd)
    assert "type mymodule.ps1 | " in result
    # Verify the length of the base64-encoded script string
    assert len(result.split(u' ')[-1]) == 247


# Generated at 2022-06-25 11:50:14.734692
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module = ShellModule()
    env_string = ""
    shebang = ""
    cmd = "Test-Path -Path 'C:\\Windows\\System32\\ServerManager.exe'"
    arg_path = ""
    res = shell_module.build_module_command(env_string, shebang, cmd, arg_path)
    # TODO: Add asserts


# Generated at 2022-06-25 11:50:22.239452
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()

    # Try to test that a class variable '_SHELL_REDIRECT_ALLNULL' of the class ShellModule is defined
    # I suppose this variable is defined in the class ShellBase
    assert hasattr(shell_module_1, '_SHELL_REDIRECT_ALLNULL'), "No variable _SHELL_REDIRECT_ALLNULL was found in class ShellModule"

    # Try to test that a class variable '_SHELL_AND' of the class ShellModule is defined
    assert hasattr(shell_module_1, '_SHELL_AND'), "No variable _SHELL_AND was found in class ShellModule"

    # Try to test that a class variable '_IS_WINDOWS' of the class ShellModule is defined

# Generated at 2022-06-25 11:50:32.037692
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Test for Windows paths
    assert (ShellModule().path_has_trailing_slash("C:/testfolder\\") == True)
    assert (ShellModule().path_has_trailing_slash("C:/testfolder") == False)

    # Test for relative Windows paths
    assert (ShellModule().path_has_trailing_slash("testfolder\\") == True)
    assert (ShellModule().path_has_trailing_slash("testfolder") == False)

    # Test for Linux paths
    assert (ShellModule().path_has_trailing_slash("/testfolder/") == True)
    assert (ShellModule().path_has_trailing_slash("/testfolder") == False)


# Generated at 2022-06-25 11:50:42.414677
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()

    env_string = "KEY1=Value1;KEY2=Value2"
    shebang = None
    cmd = "\"TestCommand\""
    arg_path = None
    result = shell_module_0.build_module_command(env_string, shebang, cmd, arg_path)
    assert result == "& 'TestCommand'; exit $LASTEXITCODE"

    env_string = "KEY1=Value1;KEY2=Value2"
    shebang = "#!{0}"
    cmd = "\"TestCommand\""
    arg_path = None
    result = shell_module_0.build_module_command(env_string, shebang, cmd, arg_path)
    assert result == "& 'TestCommand'; exit $LASTEXITCODE"

    env

# Generated at 2022-06-25 11:50:45.252265
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Simple test for mkdtemp
    shell_module_0 = ShellModule()
    # Test empty basefile
    shell_module_0.mkdtemp()
    # Test tmpdir
    shell_module_0.mkdtemp(tmpdir = "C:\\Users\\test\\test_test")


# Generated at 2022-06-25 11:50:46.697462
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # This test fails
    shell_module = ShellModule()
    assert "PowerShell" == shell_module.DEFAULT_EXECUTABLE



# Generated at 2022-06-25 11:50:48.595554
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
        print("test_case_0 passed")
    except Exception as exception:
        print("test_case_0 failed: " + str(exception))

test_ShellModule()

# Generated at 2022-06-25 11:50:58.385075
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()

    assert shell_module_0.path_has_trailing_slash("C:\\Windows\\System32\\") == True, \
        "Expected True, got " + test_ShellModule_path_has_trailing_slash()

    assert shell_module_0.path_has_trailing_slash("C:\\Windows\\System32") == False, \
        "Expected False, got " + test_ShellModule_path_has_trailing_slash()

    assert shell_module_0.path_has_trailing_slash("C:\\Windows\\system32") == False, \
        "Expected False, got " + test_ShellModule_path_has_trailing_slash()


# Generated at 2022-06-25 11:51:12.631065
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_2 = ShellModule()

    shell_module_1 = ShellModule()
    shell = 'powershell'
    _IS_WINDOWS = True
    _SHELL_REDIRECT_ALLNULL = '> $null'
    _SHELL_AND = ';'

    assert shell_module_1.SHELL_FAMILY == shell
    assert shell_module_1._IS_WINDOWS == _IS_WINDOWS
    assert shell_module_1._SHELL_REDIRECT_ALLNULL == _SHELL_REDIRECT_ALLNULL
    assert shell_module_1._SHELL_AND == _SHELL_AND


# Generated at 2022-06-25 11:51:15.199307
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("test_ShellModule")
    shell_module_0 = ShellModule()


if __name__ == '__main__':
    test_case_0()
    test_ShellModule()

# Generated at 2022-06-25 11:51:25.576416
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()
    assert_true(isinstance(obj, ShellModule))

    # Unit test for method env_prefix
    def test_env_prefix():
        obj = ShellModule()
        assert_equals('', obj.env_prefix(**{}))

    # Unit test for method join_path
    def test_join_path():
        obj = ShellModule()
        assert_equals(u'C:\\Windows\\System32\\WindowsPowerShell\\v1.0',
                      obj.join_path(u'C:\\Windows\\System32', u'WindowsPowerShell\\v1.0'))

    # Unit test for method get_remote_filename
    def test_get_remote_filename():
        obj = ShellModule()

# Generated at 2022-06-25 11:51:32.874326
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    assert not shell_module_0.path_has_trailing_slash("test")


if __name__ == "__main__":
    test_case_0()
    test_ShellModule_path_has_trailing_slash()

# Generated at 2022-06-25 11:51:34.777581
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if shell_module_0.SHELL_FAMILY == 'powershell':
        pass

# Generated at 2022-06-25 11:51:38.242427
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# Run all unit tests for this class

# Generated at 2022-06-25 11:51:39.891588
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert isinstance(shell_module_1, ShellModule)


# Generated at 2022-06-25 11:51:48.003024
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule._IS_WINDOWS == True
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert ShellModule.COMPATIBLE_SHELLS == frozenset()
    assert ShellModule.SHELL_FAMILY == 'powershell'
    assert ShellModule._SHELL_REDIRECT_ALLNULL == '> $null'
    assert ShellModule._SHELL_AND == ';'


# Generated at 2022-06-25 11:51:50.105122
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    module_name = str((shell_module_0).__class__.__name__)
    assert module_name == 'ShellModule'


# Generated at 2022-06-25 11:51:50.849317
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:51:56.292778
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.__init__()


# Generated at 2022-06-25 11:51:58.409588
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    result = shell_module.path_has_trailing_slash("/home/abc/")
    assert result == True



# Generated at 2022-06-25 11:52:03.568693
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Execute the default constructor of class ShellModule and check the result
    shell_module_1 = ShellModule()
    assert shell_module_1._IS_WINDOWS == True
    assert shell_module_1._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_1._SHELL_AND == ';'
    assert shell_module_1.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_1.SHELL_FAMILY == 'powershell'
    return True


# Generated at 2022-06-25 11:52:06.599524
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module != None
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-25 11:52:10.636443
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('Unit test for constructor of class ShellModule')
    shell_module_0 = ShellModule()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:52:21.125753
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._pc_module_version == '0.1'
    assert shell_module_0._shell == 'powershell'
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0.DEFAULT_EXECUTABLE == 'powershell'

# Generated at 2022-06-25 11:52:26.653584
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    shell_module_1.COMPATIBLE_SHELLS
    shell_module_1.SHELL_FAMILY
    shell_module_1._IS_WINDOWS


# Generated at 2022-06-25 11:52:30.929082
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    assert shell_module.path_has_trailing_slash(path=r"C:\test\testfile.txt") == False

# Generated at 2022-06-25 11:52:34.216663
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:36.715574
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'



# Generated at 2022-06-25 11:52:42.662999
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# runs test if this is the top level module
if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:52:48.001091
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass
#    shell_module_obj = ShellModule()
#    print shell_module_obj
#    assert shell_module_obj is not None


# Generated at 2022-06-25 11:52:49.588543
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:51.382838
# Unit test for constructor of class ShellModule
def test_ShellModule():
    return shell_module_0

# Generated at 2022-06-25 11:52:52.677774
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:52:54.270966
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert isinstance(shell_module_1, ShellModule)


# Generated at 2022-06-25 11:52:56.690591
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:52:57.635927
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert ShellModule()


# Generated at 2022-06-25 11:53:03.667017
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()

    assert shell_module_1.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_1.SHELL_FAMILY == 'powershell'
    assert shell_module_1._IS_WINDOWS == True


# Generated at 2022-06-25 11:53:04.807139
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:09.892561
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if not isinstance(shell_module_0, ShellModule):
        raise RuntimeError("Was not able to create object ShellModule")


# Generated at 2022-06-25 11:53:21.998945
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_mkdtemp = ShellModule().mkdtemp

    # test for get_remote_filename
    print("Test for get_remote_filename")
    print("--------------------------")

    print("\nTest 0")
    shell_mkdtemp()

    # test for join_path
    print("Test for join_path")
    print("-----------------")

    print("\nTest 0")
    print(ShellModule().join_path("a", "b"))

    print("\nTest 1")
    print(ShellModule().join_path("a", "/", "b"))

    print("\nTest 2")
    print(ShellModule().join_path("a", "//", "b"))

    # test for path_has_trailing_slash
    print("Test for path_has_trailing_slash")

# Generated at 2022-06-25 11:53:25.053484
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, object)



# Generated at 2022-06-25 11:53:26.503746
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print()
    print("****test_ShellModule****")

    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:27.958703
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # AssertionError
    shell_module_0.checksum("")

# Generated at 2022-06-25 11:53:34.024250
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert(shell_module_0.__class__ is ShellModule)

    shell_module_1 = ShellModule(connection=Connection(module_name='winrm'))
    assert(shell_module_1.__class__ is ShellModule)

    shell_module_2 = ShellModule(connection=Connection(module_name='psrp'))
    assert(shell_module_2.__class__ is ShellModule)

    shell_module_3 = ShellModule(connection=Connection(module_name='ssh'))
    assert(shell_module_3.__class__ is ShellModule)

    shell_module_4 = ShellModule(connection=Connection(module_name='netconf'))
    assert(isinstance(shell_module_4, ShellModule))


# Generated at 2022-06-25 11:53:36.721247
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    var = shell_mkdtemp()
    assert var == shell_module.mkdtemp(basefile=None, system=False, mode=None, tmpdir=None)


# Generated at 2022-06-25 11:53:44.725678
# Unit test for constructor of class ShellModule
def test_ShellModule():
    file_handle = open('test_cases/test_case_0.txt', 'r')
    file_content = file_handle.readlines()
    input_str = ''
    for line in file_content:
        input_str = input_str + line
    shell_module_0 = ShellModule()
    shell_mkdtemp_0 = shell_module_0.mkdtemp()
    test_case_0.shell_mkdtemp = shell_mkdtemp_0
    # print('shell_mkdtemp_0: ' + shell_mkdtemp_0)
    shell_module_0.run(input_str)
    file_handle.close()

test_ShellModule()

# Generated at 2022-06-25 11:53:50.121099
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    with pytest.raises(NotImplementedError):
        shell_module_0.chown('paths', 'user')
    with pytest.raises(NotImplementedError):
        shell_module_0.chmod('paths', 'mode')
    with pytest.raises(NotImplementedError):
        shell_module_0.set_user_facl('paths', 'user', 'mode')
    return


# Generated at 2022-06-25 11:53:51.261906
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:53:56.079420
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module is not None


# Generated at 2022-06-25 11:53:59.344465
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:54:00.260236
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert shell_module_0 != None


# Generated at 2022-06-25 11:54:01.558375
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass


# Generated at 2022-06-25 11:54:04.086865
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Create new ShellModule object
    shell_module_0 = ShellModule()
    # See if the object is of class ShellModule
    assert (shell_module_0.__class__ == ShellModule)

# Generated at 2022-06-25 11:54:08.039631
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    var_0 = 'some-env-string'
    var_1 = 'some-shebang'
    var_2 = 'some-command'
    var_3 = 'some-arg-path'
    var_4 = shell_module_0.build_module_command(var_0, var_1, var_2, var_3)


# Generated at 2022-06-25 11:54:11.076578
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('Test Shell Module')
    # test_case_0()
    print('Shell Module Test Done')



# Generated at 2022-06-25 11:54:11.909199
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:54:21.925570
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._unquote('arg') == 'arg'
    assert shell_module_0._unquote("'arg'") == 'arg'
    assert shell_module_0._unquote('"arg"') == 'arg'

    assert shell_module_0._escape("'") == "''"
    assert shell_module_0._escape("''") == "''''"
    assert shell_module_0._escape("'hello'") == "''hello''"

    assert shell_module_0._escape("\u2018") == "\u2018\u2018"
    assert shell_module_0._escape("\u2018\u2018") == "\u2018\u2018\u2018\u2018"

# Generated at 2022-06-25 11:54:30.078456
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.get_remote_filename('/home/vagrant/.bashrc')
    if var_0 != '.bashrc.ps1':
        raise Exception('var_0 should be ".bashrc.ps1"')
    
    var_1 = shell_module_0.join_path('/tmp', 'test')
    if var_1 != '/tmp\\test':
        raise Exception('var_1 should be "/tmp\\test"')
    
    var_2 = shell_mkdtemp()
    var_3 = shell_mkdtemp('test')
    var_4 = shell_mkdtemp(system=True)
    var_5 = shell_mkdtemp(mode='test')
    var_6 = shell_mkdtemp(tmpdir='test')


# Generated at 2022-06-25 11:54:42.624470
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('\nUnit test for constructor of class ShellModule')
    from ansible.executor.powershell.shell import ShellModule
    shell_module_0 = ShellModule()
    if not isinstance(shell_module_0, ShellModule):
        raise AssertionError('Unable to create instance of ShellModule')
    print('PASSED: test_ShellModule')



# Generated at 2022-06-25 11:54:45.330639
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.__class__ == ShellModule
    assert repr(shell_module_0) == '<ansible.executor.powershell.ShellModule object at 0x7f5a5dcf1fd0>'


# Generated at 2022-06-25 11:54:47.968831
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.SHELL_FAMILY == 'powershell'



# Generated at 2022-06-25 11:54:50.264577
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._shell_type == 'powershell'


# Generated at 2022-06-25 11:54:50.866860
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:51.663032
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:52.711325
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

test_ShellModule()

# Generated at 2022-06-25 11:54:55.386575
# Unit test for constructor of class ShellModule
def test_ShellModule():
    var_0 = ShellModule()


# Generated at 2022-06-25 11:54:58.034354
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None


# Generated at 2022-06-25 11:55:05.413748
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert not hasattr(shell_module_0, 'exec_rc')
    assert not hasattr(shell_module_0, 'supports_exec')
    assert not hasattr(shell_module_0, 'supports_rc)')
    assert not hasattr(shell_module_0, 'supports_pipelining')
    assert not hasattr(shell_module_0, 'supports_redirect')
    assert not hasattr(shell_module_0, 'exec_rc')
    assert not hasattr(shell_module_0, 'supports_exec')
    assert not hasattr(shell_module_0, 'supports_rc')
    assert not hasattr(shell_module_0, 'supports_pipelining')

# Generated at 2022-06-25 11:55:14.262394
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_obj_0 = ShellModule()

if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:55:18.651909
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_1.SHELL_FAMILY == 'powershell'
    assert shell_module_1._IS_WINDOWS == True


# Generated at 2022-06-25 11:55:19.473190
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:55:20.527422
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:55:21.263061
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:55:33.546002
# Unit test for constructor of class ShellModule

# Generated at 2022-06-25 11:55:36.927018
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
        shell_mkdtemp()
    except NameError:
        msg_0 = "NameError: name 'shell_mkdtemp' is not defined in test_case_0"
        assert False, msg_0


# Generated at 2022-06-25 11:55:37.841056
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:55:38.624332
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:55:44.281285
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        assert_raises(Exception, ShellModule, 'foo')
    except SystemExit:
        pass


# Generated at 2022-06-25 11:56:04.425139
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert isinstance(shell_module, ShellBase)


# Generated at 2022-06-25 11:56:05.335134
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:56:10.189114
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:56:12.748797
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:56:22.835079
# Unit test for constructor of class ShellModule
def test_ShellModule():
    temp_dir_path = tempfile.gettempdir()
    if os.path.exists(temp_dir_path):
        # We can only test that the generated temp dir starts with the value
        # we passed in since we don't know what other process may have created
        # a file at the same time.
        temp_dir = ShellModule().mkdtemp('ansible-tmp-')
        # Encode in posix to remove the leading `.\` on Windows
        assert temp_dir.startswith(posixpath.join(temp_dir_path, 'ansible-tmp-'))
    else:
        # No point in trying to create a temp dir if the temp dir path is invalid
        assert ShellModule().mkdtemp('ansible-tmp-') == ''


if __name__ == '__main__':
    case_main()

# Generated at 2022-06-25 11:56:23.575309
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

test_case_0()

# Generated at 2022-06-25 11:56:32.477137
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:56:39.819363
# Unit test for constructor of class ShellModule
def test_ShellModule():
    global TEST_CASE
    test_cnt = 0

    test_case_0()
    test_cnt += 1

    print("TEST PASSED " + str(test_cnt) + " out of " + str(1) + ": " + str(test_cnt/1*100) + "%")


# unit test shell
if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-25 11:56:40.848731
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return



# Generated at 2022-06-25 11:56:47.372487
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()
    shell_module_2 = ShellModule()
    shell_module_3 = ShellModule()
    shell_module_4 = ShellModule()
    shell_module_5 = ShellModule()
    shell_module_6 = ShellModule()


# Generated at 2022-06-25 11:57:32.107690
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if (shell_module_0.SHELL_FAMILY != "powershell"):
        return 1
    return 0


# Generated at 2022-06-25 11:57:33.155016
# Unit test for constructor of class ShellModule
def test_ShellModule():
  print('')
  ShellModule()


# Generated at 2022-06-25 11:57:39.204998
# Unit test for constructor of class ShellModule
def test_ShellModule():
    basefile = "ansible-tmp-1523470037.36-26124942927219"
    system = False
    mode = None
    tmpdir = None
    shell_module_0 = ShellModule()
    shell_mkdtemp_0 = shell_module_0.mkdtemp(basefile, system, mode, tmpdir)

# Generated at 2022-06-25 11:57:44.354926
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)



# Generated at 2022-06-25 11:57:49.956663
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'


# Generated at 2022-06-25 11:57:53.567273
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print('Running test_ShellModule...')
    shell_module_0 = ShellModule()
    assert shell_module_0 is not None
