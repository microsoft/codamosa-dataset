

# Generated at 2022-06-25 11:48:22.760034
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_1 = ShellModule()
    user_home_path = "$HOME"
    username = "Administrator"
    expected = shell_module_1._encode_script("Write-Output ((Get-Location).Path + '$HOME')")
    actual = shell_module_1.expand_user(user_home_path, username)
    assert actual == expected


# Generated at 2022-06-25 11:48:31.598805
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    new_user_home_path_0 = shell_module_0.expand_user('/etc/ansible', 'vagrant')
    new_user_home_path_1 = shell_module_0.expand_user('/home/vagrant/.ansible/tmp', 'vagrant')
    new_user_home_path_2 = shell_module_0.expand_user('/home/vagrant/.ansible/tmp/ansible-tmp-1489804728.18-232469135566746', 'vagrant')
    new_user_home_path_3 = shell_module_0.expand_user('~', 'vagrant')

# Generated at 2022-06-25 11:48:36.851040
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    # Verify if user home dir is returned when the user_home_path is "~"
    test_cases = {
        'test_case_0':
            {
                'input': '~',
                'output': None
            },
        'test_case_1':
            {
                'input': '~/test',
                'output': None
            },
        'test_case_2':
            {
                'input': '~test',
                'output': None
            }
    }

    for key in test_cases:
        res = shell_module_0.expand_user(user_home_path=test_cases[key]['input'])
        print("res: ", res)
        assert res is not None
        # assert res == test_cases[key][

# Generated at 2022-06-25 11:48:39.539516
# Unit test for constructor of class ShellModule
def test_ShellModule():

    shell_module_1 = ShellModule()
    from ansible.plugins.shell import ShellBase
    isinstance(shell_module_1, ShellBase)


# Generated at 2022-06-25 11:48:41.242554
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return shell_module_0


# Generated at 2022-06-25 11:48:43.038902
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert(shell_module != None)


# Generated at 2022-06-25 11:48:47.112563
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_module_1 = ShellModule()
    print(shell_module_1.get_remote_filename('test.sh'))
    print(shell_module_1.get_remote_filename('test.ps1'))
    print(shell_module_1.get_remote_filename('test.exe'))

# Generated at 2022-06-25 11:48:49.559881
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()

# Generated at 2022-06-25 11:48:53.329771
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    user_home_path = '~'
    username = ''
    # Output: """Write-Output (Get-Location).Path"""
    print(shell_module_0.expand_user(user_home_path, username))


# Generated at 2022-06-25 11:48:54.514434
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:49:07.754609
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    print("### test_ShellModule() ###")
    print(shell_module)
    print("[type:%s]" % type(shell_module))

if __name__ == "__main__":
    test_ShellModule()

# Generated at 2022-06-25 11:49:08.867027
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:49:11.086657
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()
    path_0 = ' '
    var_0 = shell_module_0.path_has_trailing_slash(path_0)


# Generated at 2022-06-25 11:49:12.434174
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        test_case_0()
    except:
        print("test case 0 failed")



# Generated at 2022-06-25 11:49:17.023448
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule(connection=None)
    shell_module_0._shell = None
    shell_module_0._is_pipelining_enabled = False
    env_string = ' '
    shebang = '#!powershell'
    cmd = 'Get-Module -ListAvailable'
    arg_path = None
    result = shell_module_0.build_module_command(env_string, shebang, cmd, arg_path)
    print(result)


# Generated at 2022-06-25 11:49:20.156303
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print ("\tTesting test_ShellModule()")
    test_case_0()
    print ("\tDone Testing test_ShellModule()")


if __name__ == '__main__':

    print ("Running tests...")
    print ("=================")
    test_ShellModule()
    print ("=================")
    print ("Done.")

# Generated at 2022-06-25 11:49:21.146914
# Unit test for constructor of class ShellModule
def test_ShellModule():
    test_case_0()


# Generated at 2022-06-25 11:49:23.273979
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_1 = ShellModule()

# Generated at 2022-06-25 11:49:28.343876
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_1 = ShellModule()
    assert(shell_module_1.expand_user(user_home_path='~', username='') == 'Write-Output (Get-Location).Path')


# Generated at 2022-06-25 11:49:36.469422
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule(connection='winrm', module_name='win_ping', module_args=None, task_uuid='123-456-789', become_method='runas', become_exe='runas.exe', become_user='0', become_pass=None, become_flags=None, no_log=None, stdin=None, stdin_add_newline=True, strip_empty_ends=True, executable=None, suppress_warning=False, binary_data=False, timeout=60, shell_type='powershell', socket_path=None)
    print(shell_module_0)


# Generated at 2022-06-25 11:49:42.385685
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module = ShellModule()
    assert "C:\\User\\user" == shell_module._unquote(shell_module.expand_user(user_home_path='~'))


# Generated at 2022-06-25 11:49:48.501964
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert_equal(shell_module_1.COMPATIBLE_SHELLS, frozenset())
    assert_equal(shell_module_1.SHELL_FAMILY, 'powershell')
    assert_equal(shell_module_1._IS_WINDOWS, True)
    assert_equal(shell_module_1._SHELL_REDIRECT_ALLNULL, '> $null')
    assert_equal(shell_module_1._SHELL_AND, ';')


# Generated at 2022-06-25 11:49:58.580410
# Unit test for constructor of class ShellModule
def test_ShellModule():
    os.environ['ANSIBLE_PIPELINING'] = 'True'
    shell_module = ShellModule()
    assert shell_module._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module._SHELL_AND == ';'
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS
    assert shell_module.get_remote_filename("test_path") == 'test_path.ps1'
    assert shell_module.get_remote_filename("test_path.ps1") == 'test_path.ps1'
    assert shell_module.get_remote_filename("test_path.exe") == 'test_path.exe'
    assert shell

# Generated at 2022-06-25 11:50:02.855302
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert(ShellModule())


# Generated at 2022-06-25 11:50:11.411567
# Unit test for method expand_user of class ShellModule

# Generated at 2022-06-25 11:50:12.738169
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:50:18.101028
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    # Test for some of the conditions defined in the build_module_command method
    # TODO: this method has more conditions
    # TODO: add conditions for the other if clauses
    arg_path = "/tmp/ansible_test_88_828_ansible_tmp_ansible-tmp-1474667810.265393-182353267098946/arg"
    shebang = "#!powershell"
    cmd = "/tmp/ansible_test_88_828_ansible_tmp_ansible-tmp-1474667810.265393-182353267098946/hello"
    env_string = "echo"

# Generated at 2022-06-25 11:50:21.066957
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:50:25.454928
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    assert shell_module_1.COMPATIBLE_SHELLS==frozenset()
    assert shell_module_1.SHELL_FAMILY == 'powershell'
    assert shell_module_1._IS_WINDOWS == True


# Generated at 2022-06-25 11:50:36.870710
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():

    shell_module_0 = ShellModule()

    argument1_0 = "C:\\Users\\Administrator\\AppData\\Local\\Temp\\9\\ansible-tmp-1501338541.98-209013039360938\\test_path.ps1"
    argument2_0 = "C:\\Users\\Administrator\\AppData\\Local\\Temp\\9\\ansible-tmp-1501338541.98-209013039360938\\test_path.ps1\\"
    argument3_0 = "C:\\Users\\Administrator\\AppData\\Local\\Temp\\9\\ansible-tmp-1501338541.98-209013039360938\\test_path.ps1\\"

    assert shell_module_0.path_has_trailing_slash(argument1_0) == False
    assert shell_

# Generated at 2022-06-25 11:50:42.172583
# Unit test for constructor of class ShellModule
def test_ShellModule():
    global shell_module_0
    shell_module_0 = ShellModule()
    global shell_module_1
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:50:44.505154
# Unit test for constructor of class ShellModule
def test_ShellModule():
    ret = run_main(test_case_0)
    assert ret == 0, "Return code should be 0"


if __name__ == "__main__":
    ret = run_main(test_case_0)
    sys.exit(ret)

# Generated at 2022-06-25 11:50:50.692635
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_1 = ShellModule()
    # with value for user_home_path = '~'
    user_home_path_1 = '~'
    # with value for username = ''
    username_1 = ''
    script_1 = shell_module_1.expand_user(user_home_path=user_home_path_1, username=username_1)

    # with value for user_home_path = 'C:\\Users\\testuser'
    user_home_path_2 = 'C:\\Users\\testuser'
    # with value for username = ''
    username_2 = ''
    script_2 = shell_module_1.expand_user(user_home_path=user_home_path_2, username=username_2)

    # with value for user_home_path = '~'

# Generated at 2022-06-25 11:50:51.561231
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert shell_module_0

# Generated at 2022-06-25 11:50:55.331809
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module.COMPATIBLE_SHELLS == frozenset()
    assert shell_module.SHELL_FAMILY == 'powershell'
    assert shell_module._IS_WINDOWS == True


# Generated at 2022-06-25 11:50:56.174129
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:50:58.756819
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    if shell_module_0.__class__ == ShellModule:
        print("Testcase 0 passed")
    else:
        print("Testcase 0 failed")


# Generated at 2022-06-25 11:51:06.284315
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0.CAN_DELETE_TMP_FILE == False
    assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:51:13.355874
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module = ShellModule()
    res = shell_module.expand_user(user_home_path='~')
    assert res.decode('utf-8').strip() == 'Get-Location'
    res = shell_module.expand_user(user_home_path='~\\subdir')
    assert res.decode('utf-8').strip() == '((Get-Location).Path + \'subdir\')'
    res = shell_module.expand_user(user_home_path='subdir')
    assert res.decode('utf-8').strip() == '\'subdir\''


# Generated at 2022-06-25 11:51:19.139262
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # return shell_module_0.expand_user(user_home_path=u'/home/ansible/')
    shell_module_0 = ShellModule()
    print(shell_module_0.expand_user(user_home_path=u'/home/ansible/'))


# Generated at 2022-06-25 11:51:27.717759
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # Assert that build_module_command() accepts an empty command, which allows
    # the bootstrap (and nothing else) to run.
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.build_module_command('', '', '')
    assert var_0 == bootstrap_wrapper


# Generated at 2022-06-25 11:51:29.344266
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.expand_user(None, None)
    print(var_0)


# Generated at 2022-06-25 11:51:39.757162
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.checksum()
    var_1 = shell_module_0.chmod()
    var_2 = shell_module_0.mkdtemp()
    var_3 = shell_module_0._encode_script(str_0='0')
    var_4 = shell_module_0._unquote()
    var_5 = shell_module_0.chown()
    var_6 = shell_module_0._escape()
    var_7 = shell_module_0._SHELL_REDIRECT_ALLNULL
    var_8 = shell_module_0.remove()
    var_9 = shell_module_0.set_user_facl()
    var_10 = shell_module_0.env_prefix()

# Generated at 2022-06-25 11:51:46.255543
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module_0 = ShellModule()

# Generated at 2022-06-25 11:51:48.192789
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module == ShellModule()
    assert shell_module is not None
    assert isinstance(shell_module, ShellBase)


# Generated at 2022-06-25 11:51:49.231399
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    test_case_0()

# Unit test runner for ShellModule class

# Generated at 2022-06-25 11:51:53.899338
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shell_module_0 = ShellModule()
    except Exception:
        var_0 = False
    else:
        var_0 = True
    # assert var_0


# Generated at 2022-06-25 11:51:59.229890
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellBase)

if __name__ == '__main__':
    script_dir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(script_dir)
    test_ShellModule()

# Generated at 2022-06-25 11:52:00.650373
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # Test with default value of argument:
    shell_module_1 = ShellModule()



# Generated at 2022-06-25 11:52:06.651301
# Unit test for constructor of class ShellModule
def test_ShellModule():

    # create ShellModule here
    shell_module = ShellModule()

    # check method b_path_has_trailing_slash
    assert(shell_module.path_has_trailing_slash('/etc/ansible/ansible.cfg'))

    # check method mkdtemp
    assert(shell_module.mkdtemp(basefile='tmp', system=False, mode=None, tmpdir=None).strip() == "mktemp -d /tmp/ansible_tmpHGtEuk")

    # check method join_path
    assert(shell_module.join_path('/etc/ansible/ansible.cfg', 'tmp') == '/etc/ansible/ansible.cfgtmp')

# Generated at 2022-06-25 11:52:16.847328
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = str(shell_module_0)

# Generated at 2022-06-25 11:52:18.349141
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass


# Generated at 2022-06-25 11:52:19.637605
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_obj = ShellModule()
    assert isinstance(shell_module_obj, ShellModule)


# Generated at 2022-06-25 11:52:26.402618
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_get_remote_filename(shell_module_0)

#####################################################################
# Main
#
if __name__ == '__main__':
    test_ShellModule()
    test_case_0()

# Generated at 2022-06-25 11:52:30.044746
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == u'> $null'



# Generated at 2022-06-25 11:52:40.023963
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Getting the parameters for test case test_case_0
    shell_module_0 = ShellModule()
    # Setting up mock
    class TestClass():
        def get_option(self, module):
            options = dict({})
            options['remote_tmp'] = '/var/lib/awx/tmp'
            options['executable'] = None
            return options[module]
    TestClass_instance = TestClass()
    shell_module_0.get_option = TestClass_instance.get_option
    # Test the call to ShellModule.mkdtemp()
    # Test function call
    var_0 = shell_mkdtemp(shell_module_0)

# Generated at 2022-06-25 11:52:42.933988
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_1 = shell_module_0.expand_user("~/test")
    print("var_1: " + var_1)


# Generated at 2022-06-25 11:52:47.577104
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Class constructor
    shell_module_0 = ShellModule()
    assert shell_module_0 != None

# Generated at 2022-06-25 11:52:58.518127
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.set_options(remote_tmp='/tmp/ansible-tmp-1566422475.93-21875615163856')
    shell_module_0.set_options(remote_tmp='/tmp/ansible-tmp-1566422475.93-21875615163856')
    shell_module_0.set_options(remote_tmp='/tmp/ansible-tmp-1566422475.93-21875615163856')
    shell_module_0.set_options(remote_tmp='/tmp/ansible-tmp-1566422475.93-21875615163856')

# Generated at 2022-06-25 11:52:59.707997
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:39.979390
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:53:42.551998
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    return shell_module_0


# Generated at 2022-06-25 11:53:43.126854
# Unit test for constructor of class ShellModule
def test_ShellModule():
    pass

# Generated at 2022-06-25 11:53:44.435486
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule()
    assert shell_module


# Generated at 2022-06-25 11:53:46.269713
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # Test for __init__.py
    assert shell_module_0

# Generated at 2022-06-25 11:53:54.959611
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Check if object is correctly initialized
    shell_module_0 = ShellModule()
    assert shell_module_0.__class__.COMPATIBLE_SHELLS == frozenset(), "Expected: <frozenset()>, Actual: {shell_module_0.__class__.COMPATIBLE_SHELLS}"
    assert shell_module_0.__class__._SHELL_REDIRECT_ALLNULL == '> $null', "Expected: <'> $null'>, Actual: {shell_module_0.__class__._SHELL_REDIRECT_ALLNULL}"
    assert shell_module_0.__class__._SHELL_AND == ';', "Expected: <';'>, Actual: {shell_module_0.__class__._SHELL_AND}"
    assert shell_module_0.__class__

# Generated at 2022-06-25 11:53:59.030085
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0



# Generated at 2022-06-25 11:54:00.905884
# Unit test for constructor of class ShellModule
def test_ShellModule():
    try:
        shellModule = ShellModule()
        assert True
    except Exception:
        assert False, "Could not instantiate a ShellModule Object"


# Generated at 2022-06-25 11:54:05.111330
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell_module_0 = ShellModule()
    env_string_0 = ''
    shebang_0 = '#!python'
    cmd_0 = 'ansible-test'
    var_0 = shell_module_0.build_module_command(env_string_0, shebang_0, cmd_0)


# Generated at 2022-06-25 11:54:06.487381
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    assert '/home/name' == ShellModule.expand_user('/home/name', 'name')

# Generated at 2022-06-25 11:54:32.266701
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.build_module_command('', '', '', 0)
    var_1 = shell_module_0.chmod('', 0)
    var_2 = shell_module_0.chown('', '')
    var_3 = shell_module_0.checksum('')
    var_4 = shell_module_0.join_path('', '')
    var_5 = shell_module_0.mkdtemp('', True, 0, 0)
    var_6 = shell_module_0.path_has_trailing_slash('')
    var_7 = shell_module_0.remove('')
    var_8 = shell_module_0.set_user_facl('', '', 0)
    var_9

# Generated at 2022-06-25 11:54:33.172059
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()


# Generated at 2022-06-25 11:54:37.371373
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._IS_WINDOWS == True


# Generated at 2022-06-25 11:54:41.857751
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    # import pdb; pdb.set_trace()


# Generated at 2022-06-25 11:54:46.460419
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    print("shell_module_0 type: " + str(type(shell_module_0)))
    assert isinstance(shell_module_0, ShellModule)
    print("shell_module_0 value: %s\n" % shell_module_0)


# Generated at 2022-06-25 11:54:47.532684
# Unit test for constructor of class ShellModule
def test_ShellModule():
    obj = ShellModule()


# Generated at 2022-06-25 11:54:51.130000
# Unit test for constructor of class ShellModule
def test_ShellModule():
    cmd_0 = bytearray(b'')

    script_0 = shell_build_module_command(cmd_0)
    test_case_0()

# Generated at 2022-06-25 11:54:53.985806
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert (shell_module_0.SHELL_FAMILY == 'powershell')
    assert (shell_module_0.COMPATIBLE_SHELLS == frozenset())


# Generated at 2022-06-25 11:54:58.243417
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # This test should not raise an exception
    try:
        shell_module_0 = ShellModule()
    except Exception as exception_0:
        print('Test failed: ', exception_0)


# Generated at 2022-06-25 11:55:00.886157
# Unit test for constructor of class ShellModule
def test_ShellModule():
    print("Test for constructor of class ShellModule")
    try:
        #Test case where an instance of the class ShellModule is created
        ShellModule()
    except Exception as e:
        print("Exception due to invalid arguments", e)


# Generated at 2022-06-25 11:55:37.221874
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()
    var_1 = shell_path_has_trailing_slash(shell_module_1)

# Generated at 2022-06-25 11:55:46.874558
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    #assert shell_module_0.COMPATIBLE_SHELLS == frozenset()
    #assert shell_module_0.SHELL_FAMILY == 'powershell'
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0.SHELL_NAME == 'powershell'
    assert shell_module_0.BINARY == 'powershell'


# Generated at 2022-06-25 11:55:48.837879
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule)


# Generated at 2022-06-25 11:55:58.639566
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert shell_module_0._IS_WINDOWS == True
    assert shell_module_0._SHELL_AND == ';'
    assert shell_module_0._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_module_0.check_command("command -a 3", "cmd", add=None) == "command -a 3"
    assert shell_module_0.get_remote_filename(pathname=None) == "ansible_powershell_put_script.ps1"
    assert shell_module_0.join_path("a", "b") == "a\\b"
    assert shell_module_0.path_has_trailing_slash("") == False
    shell_module_1 = ShellModule()
    assert shell_module_1._IS

# Generated at 2022-06-25 11:56:05.888079
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    shell_module_0.get_option = get_option
    # Unit test for get_remote_filename()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 11:56:10.131199
# Unit test for constructor of class ShellModule
def test_ShellModule():
    a = ShellModule()
    assert a is not None


# Generated at 2022-06-25 11:56:11.665448
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.expand_user('~', 'username')


# Generated at 2022-06-25 11:56:13.110436
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_2 = ShellModule()
    assert isinstance(shell_module_2, ShellModule) == True


# Generated at 2022-06-25 11:56:18.781060
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Replace with your own code
    shell_module_0 = ShellModule()
    shell_module_0._IS_WINDOWS = True
    username = 'ansible'
    var_0 = shell_module_0.expand_user('~', username)


# Generated at 2022-06-25 11:56:20.928884
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_1 = ShellModule()
    # Check if we can find the path of the current directory using the
    # expand_user method of class ShellModule
    var_1 = shell_module_1.expand_user('~')
    assert('$res = (Get-Location).Path' in var_1)


# Generated at 2022-06-25 11:57:43.035994
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule(connection='connection_1')

    shell_module_2 = ShellModule(connection='connection_2', no_log=True)


# Generated at 2022-06-25 11:57:43.788796
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_1 = ShellModule()


# Generated at 2022-06-25 11:57:45.088311
# Unit test for constructor of class ShellModule
def test_ShellModule():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-25 11:57:49.638975
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
    assert isinstance(shell_module_0, ShellModule) is True


# Generated at 2022-06-25 11:57:53.602409
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module_0 = ShellModule()
    var_0 = shell_module_0.expand_user('~')
    print(var_0)

# Generated at 2022-06-25 11:57:58.553855
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module_0 = ShellModule()
