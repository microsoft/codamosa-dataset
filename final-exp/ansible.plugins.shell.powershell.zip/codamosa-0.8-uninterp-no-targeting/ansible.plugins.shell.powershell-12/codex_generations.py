

# Generated at 2022-06-21 07:09:03.063327
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    m = ShellModule()
    # Test no leading or trailing whitespace
    t = "& cmd1; cmd2"
    assert m.wrap_for_exec(t) == t
    # Test leading whitespace
    t = "    & cmd1; cmd2"
    assert m.wrap_for_exec(t) == "& cmd1; cmd2"
    # Test trailing whitespace
    t = "& cmd1; cmd2   "
    assert m.wrap_for_exec(t) == "& cmd1; cmd2"
    # Test leading and trailing whitespace
    t = "    & cmd1; cmd2  "
    assert m.wrap_for_exec(t) == "& cmd1; cmd2"
    # Test multiple trailing semicolons
    t = "& cmd1; cmd2; ; ; ; ;"


# Generated at 2022-06-21 07:09:16.659422
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    """
    Unit test function for module_utils/powershell._ansiballz_main module
    module: ShellModule
    method: exists
    """

    # Try to create an instance of ShellModule class
    try:
        shell = ShellModule()
    except Exception:
        print('Could not create an instance of ShellModule class.')
        return False

    # Test invalid path
    path = 'a'
    try:
        result = shell._ansiballz_main.exists(path)
        if result:
            print('Test for invalid path failed.')
            return False
    except Exception:
        print('Test for invalid path failed.')
        return False

    # Test valid path

# Generated at 2022-06-21 07:09:18.772568
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    mod = ShellModule()
    assert mod.env_prefix() == ''


# Generated at 2022-06-21 07:09:25.405334
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    powershell = ShellModule()
    res = powershell.remove("'C:/windows'", True) 
    assert res == "PowerShell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command Remove-Item 'C:/windows' -Force -Recurse;"


# Generated at 2022-06-21 07:09:27.539353
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule()
    # Test with no args
    assert shell.env_prefix() == ""

# Generated at 2022-06-21 07:09:33.026314
# Unit test for constructor of class ShellModule
def test_ShellModule():
    assert isinstance(ShellModule(), ShellModule)


# Generated at 2022-06-21 07:09:40.682092
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    s = ShellModule(connection=None, shell_type='powershell')
    assert s.run(s.expand_user('~')) == '/home/foo'
    assert s.run(s.expand_user('~/bar')) == '/home/foo/bar'
    assert s.run(s.expand_user('\\')) == '/home/foo'
    assert s.run(s.expand_user('\\foo\\')) == '/home/foo/foo'
    assert s.run(s.expand_user('\\foo\\bar')) == '/home/foo/foo/bar'
    assert s.run(s.expand_user('~/')) == '/home/foo'
    assert s.run(s.expand_user('~\\')) == '/home/foo'
    assert s

# Generated at 2022-06-21 07:09:44.827324
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    test_obj = ShellModule()
    result = test_obj.env_prefix()

    assert result == ''


# Generated at 2022-06-21 07:09:57.611851
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Test with empty string (should return the current directory)
    sm = ShellModule()
    assert sm.expand_user('') == "Write-Output (Get-Location).Path"

    # Test with '~' (should return the current directory)
    sm = ShellModule()
    assert sm.expand_user('~') == "Write-Output (Get-Location).Path"

    # Test with '~\path' (should return the current directory + path)
    # Test with '~\\path' (should return the current directory + path)
    # Test with '~\path/' (should return the current directory + path)
    # Test with '~/path' (should return the current directory + path)
    # Test with '~//path' (should return the current directory + path)
    # Test with '~/path/' (should

# Generated at 2022-06-21 07:10:11.378882
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    plugin = ShellModule()

    # Test with content
    path = 'dummy.txt'
    checksum = plugin.checksum(path)
    assert type(checksum) == to_bytes

# Generated at 2022-06-21 07:10:22.836170
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    module = ShellModule()
    # test exception
    try:
        module.set_user_facl('path', 'user', 'mode')
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-21 07:10:32.651769
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import json
    import tempfile
    import sys
    import stat

    from ansible.module_utils.powershell import ShellModule

    tmp_dir = tempfile.mkdtemp()


# Generated at 2022-06-21 07:10:44.203439
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()

    assert shell.join_path('c:\\', 'users', 'me', 'myfile.txt') == 'c:\\users\\me\\myfile.txt'
    assert shell.join_path('c:\\', 'users', 'me\\', '\\myfile.txt') == 'c:\\users\\me\\myfile.txt'
    assert shell.join_path('c:\\', 'users', 'me', '\\') == 'c:\\users\\me'
    assert shell.join_path('c:\\', 'users', 'me\\\\', '\\') == 'c:\\users\\me'
    assert shell.join_path('c:\\users\\') == 'c:\\users'
    assert shell.join_path('c:\\users') == 'c:\\users'
    assert shell.join_

# Generated at 2022-06-21 07:10:55.140249
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Create a dummy instance of ShellModule()
    shell = ShellModule(None)
    assert shell.expand_user("~") == b'Write-Output (Get-Location).Path'
    assert shell.expand_user("~\\") == b'Write-Output ((Get-Location).Path + \'\\\\\')'
    assert shell.expand_user("~/") == b'Write-Output ((Get-Location).Path + \'\\\\\')'
    assert shell.expand_user("~\\foo\\bar") == b"Write-Output ((Get-Location).Path + '\\\\foo\\\\bar')"
    assert shell.expand_user("~/foo/bar") == b"Write-Output ((Get-Location).Path + '\\\\foo\\\\bar')"

# Generated at 2022-06-21 07:11:04.479593
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # The test fails if the result is not expected.
    assert ShellModule.get_remote_filename('path/to/file.ps1') == 'file.ps1'
    assert ShellModule.get_remote_filename('path/to/file.ps2') == 'file.ps2.ps1'
    assert ShellModule.get_remote_filename('path/to/file.ps3') == 'file.ps3.ps1'
    assert ShellModule.get_remote_filename('path/to/file.ps2.ps1') == 'file.ps2.ps1'
    assert ShellModule.get_remote_filename('path/to/file.ps1.ps1') == 'file.ps1.ps1'

# Generated at 2022-06-21 07:11:12.145920
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()
    # Test paths that would result in joining of absolute paths
    # in a different order than what the ntpath.join would do
    path1 = 'C:\\Users\\username\\Ansible'
    path2 = 'C:\\Program Files\\'
    path3 = 'C:\\Program Files (x86)\\'
    path = '..\\..\\..\\..\\Program Files\\Python 3.6\\Python.exe'
    path = shell.join_path(path1, path2, path3, path)
    assert path == 'C:\\Program Files\\Python 3.6\\Python.exe'

    path = '..\\..\\..\\..\\Program Files (x86)\\Python 3.6\\Python.exe'

# Generated at 2022-06-21 07:11:13.766777
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    assert 1==1

# Generated at 2022-06-21 07:11:25.467345
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    powershell_shell = ShellModule()
    assert(powershell_shell.path_has_trailing_slash("C:\\temp\\ansible\\test\\"))
    assert(powershell_shell.path_has_trailing_slash("C:\\temp/ansible\\test/"))
    assert(powershell_shell.path_has_trailing_slash("C:\\temp\\ansible/test/"))
    assert(not powershell_shell.path_has_trailing_slash("C:\\temp\\ansible\\test"))
    assert(not powershell_shell.path_has_trailing_slash("C:\\temp\\ansible/test"))
    assert(not powershell_shell.path_has_trailing_slash("C:\\temp/ansible/test"))


# Generated at 2022-06-21 07:11:27.645280
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    module = ShellModule()
    paths = {"test.txt"}
    user = "user"
    x = module.chown(paths, user)
    assert x == NotImplementedError('chown is not implemented for Powershell')

# Generated at 2022-06-21 07:11:40.423237
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():

    # create a class for testing ShellModule
    class _test_shell_module_remove(ShellModule):
        def _exec_rc(self, cmd):
            return 1

        def _exec_raw(self, cmd, stdin, sudoable=True):
            return 0, '', '', ''

    # using the module to test remove method
    test_shell_module_remove = _test_shell_module_remove()

    # initialize params
    path = "C:/temp/test.txt"
    recurse = True

    # return shell commands and then get the first command
    command = test_shell_module_remove.remove(path, recurse).split(';')[0]

    # check if the command is correct and print the result

# Generated at 2022-06-21 07:11:56.224325
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    # Unit test for checksum method of class ShellModule
    #
    # ##############################################################################
    # Function: test_ShellModule_checksum()
    # Purpose: Test checksum method of class ShellModule
    #
    # Parameters: None
    # Returns: None
    # Exceptions raised: None
    # ##############################################################################

    plugin = ShellModule(connection=None, module_name='fake', module_args='fake_args')

# Generated at 2022-06-21 07:12:06.347435
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    pwsm = ShellModule()

    cmd_test_data = (
        # shebang, cmd, arg_path, expected_cmd
        ('', '', ''),
        ('#!python', '', ''),
        ('#!/usr/bin/python', '', ''),
        ('', 'foo.py', ''),
        ('#!python', 'foo.py', ''),
        ('#!/usr/bin/python', 'foo.py', ''),
        ('', 'foo.ps1', ''),
        ('#!powershell', 'foo.ps1', ''),
        ('#!powershell', 'foo', 'arg_path'),
        ('#!/usr/bin/python', 'bar.ps1', ''),
    )


# Generated at 2022-06-21 07:12:15.107059
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_plugin = ShellModule()

    assert shell_plugin._shell_executable == 'powershell.exe'
    assert shell_plugin.IS_WINDOWS == True

    assert shell_plugin.COMPATIBLE_SHELLS == frozenset()
    assert shell_plugin.SHELL_FAMILY == 'powershell'

    assert shell_plugin._SHELL_REDIRECT_ALLNULL == '> $null'
    assert shell_plugin._SHELL_AND == ';'



# Generated at 2022-06-21 07:12:28.717752
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    remote_tmp = '/ansible_test'
    shell = ShellModule(command_timeout=5, become_method=None, become_user=None, become_exe=None, become_flags=None, become_pass=None,
                        connection=None, no_log=None, persistent_command_timeout=5, remote_tmp=remote_tmp, binary_modes=None)

    # TODO: rewrite test to not rely on actual connection
    if shell.connection.transport == 'winrm':
        # Windows paths always use backslash

        # User home directory
        result_script = shell.expand_user('~')
        assert result_script == shell._encode_script('''Write-Output (Get-Location).Path''')

        # Relative paths

# Generated at 2022-06-21 07:12:33.188501
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()

    # common shell filenames that this plugin handles
    assert sm.COMPATIBLE_SHELLS == frozenset()

    # family of shells this has
    assert sm.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-21 07:12:41.727068
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()

# Generated at 2022-06-21 07:12:45.331180
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    assert shell.set_user_facl(paths=None, user=None, mode=None) is None

# Generated at 2022-06-21 07:12:47.478765
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    obj = ShellModule()
    assert obj.env_prefix() == ""

# Generated at 2022-06-21 07:12:55.515225
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    from ansible.utils.hashing import checksum


# Generated at 2022-06-21 07:12:59.064681
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    module = ShellModule()
    # pylint: disable=protected-access
    result = module.set_user_facl("", "", "")
    assert result is not None

# Generated at 2022-06-21 07:13:10.517757
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule()
    assert shell is not None
    data = shell.env_prefix()
    assert data == ""

# Generated at 2022-06-21 07:13:12.534284
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    obj = ShellModule()
    assert True

# Generated at 2022-06-21 07:13:21.195133
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    # Create a test object
    sh = ShellModule(command_executor=None)
    # test remove
    assert sh.remove(path='/path/to/nowhere') == b"Remove-Item '/path/to/nowhere' -Force;"
    assert sh.remove(path='/path/to/nowhere', recurse=True) == b"Remove-Item '/path/to/nowhere' -Force -Recurse;"



# Generated at 2022-06-21 07:13:30.428910
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    assert 'test' == ShellModule(None).get_remote_filename('test')
    assert 'test.ps1' == ShellModule(None).get_remote_filename('test.ps1')
    assert 'test.exe' == ShellModule(None).get_remote_filename('test.exe')
    assert 'test.ps1' == ShellModule(None).get_remote_filename('test')


# Generated at 2022-06-21 07:13:41.820786
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Create shell module instance
    shell_module = ShellModule()

    # Test expand_user with valid path
    user_home_path = '~\\Documents'
    result = shell_module.expand_user(user_home_path)
    # Check that result is expected
    assert result == shell_module._encode_script(script="Write-Output ((Get-Location).Path + '\Documents')")

    # Test expand_user with invalid path
    user_home_path = '~\\Favorite'
    result = shell_module.expand_user(user_home_path)
    # Check that result is expected
    assert result == shell_module._encode_script(script="Write-Output ((Get-Location).Path + '\Favorite')")

    # Test expand_user with valid path
    user_home_path = '~'


# Generated at 2022-06-21 07:13:46.424866
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    """Test wrap_for_exec functionality."""

    test_obj = ShellModule()
    cmd = 'dir'
    exp_cmd = '& dir; exit $LASTEXITCODE'
    assert test_obj.wrap_for_exec(cmd) == exp_cmd

# Generated at 2022-06-21 07:13:59.488304
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    context = dict()

# Generated at 2022-06-21 07:14:06.906963
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shellMod = ShellModule(None)

    try:
        shellMod.set_user_facl("test", "user", "mode")
    except NotImplementedError as e:
        assert str(e) == "set_user_facl is not implemented for Powershell"
    else:
        raise Exception("test failed to raise 'NotImplementedError'")



# Generated at 2022-06-21 07:14:20.549720
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.executor.powershell import ShellModule
    shell = ShellModule()

# Generated at 2022-06-21 07:14:23.728978
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    assert shell.expand_user('~'), 'Test user home dir'
    assert shell.expand_user('~\\some_dir'), 'Test subdir of user home dir'

# Generated at 2022-06-21 07:14:43.563720
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()

    # Test to ensure that expand_user returns current user if path is '~'
    # Assumes that directory exists to correctly determine the current user's home directory
    #  Possible failure condition: user has no valid home directory
    res = shell.expand_user('~')
    assert res is not None
    assert res != '~'

    # Test to ensure that expand_user returns correct expanded path if path is '~\\<something>'
    # Assumes that directory exists to correctly determine the current user's home directory
    #  Possible failure condition: user has no valid home directory
    res = shell.expand_user('~\\My Documents')
    assert res is not None
    assert res != '~\\My Documents'
    assert res.endswith('My Documents')

    # Test to ensure that expand_user returns quoted path un

# Generated at 2022-06-21 07:14:51.037716
# Unit test for constructor of class ShellModule
def test_ShellModule():
    b = ShellModule()
    assert b.family == 'powershell'
    assert b.COMPATIBLE_SHELLS == frozenset()
    assert b._SHELL_REDIRECT_ALLNULL == '> $null'
    assert b._SHELL_AND == ';'

    assert b.env_prefix() == ''



# Generated at 2022-06-21 07:14:56.569128
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    tmp = ShellModule()
    try:
        tmp.chown()
    except NotImplementedError as exc:
        assert exc.args[0] == "chown is not implemented for Powershell"
    else:
        assert False



# Generated at 2022-06-21 07:15:04.986663
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    """Test Method exists of class ShellModule"""

# Generated at 2022-06-21 07:15:07.528159
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    assert(False)


# Generated at 2022-06-21 07:15:18.350415
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_result import TaskResultError
    from ansible.executor.task_include import TaskInclude
    # We need to create a play context and a task result to do some testing
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None

# Generated at 2022-06-21 07:15:23.957614
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    from mock import patch, Mock
    mod = ShellModule(Mock())
    with patch.object(mod, '_execute_module') as modexecute:
        mod.chown(None, None)
        modexecute.assert_called_once_with(
            module_name='win_file',
            module_args=dict(path=None, owner=None, recurse=False)
        )



# Generated at 2022-06-21 07:15:33.387201
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    # Set up mock parameters
    paths = 'paths'
    user = 'user'
    mode = 'mode'

    # Set up return value of the method
    exception = Exception('set_user_facl is not implemented for Powershell')

    with pytest.raises(Exception, match=r'^set_user_facl is not implemented for Powershell$'):
        shell_obj = ShellModule(dict())
        shell_obj.set_user_facl(paths, user, mode)



# Generated at 2022-06-21 07:15:45.785911
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    import unittest
    import sys
    import os

    class ShellModule_env_prefix_TestCase(unittest.TestCase):
        ''' test for method "env_prefix" of class "ShellModule" '''

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_basic(self):
            powershell = ShellModule()
            self.assertEqual(powershell.env_prefix(), "")

    unit_test = unittest.TestSuite()
    unit_test.addTest(ShellModule_env_prefix_TestCase("test_basic"))

    runner = unittest.TextTestRunner()
    runner.run(unit_test)


# Generated at 2022-06-21 07:15:49.562380
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule()
    path = 'c:\\Users\\Administrator\\python\\test_file'
    user = 'someuser'
    try:
        result = shell.chown(path, user)
    except NotImplementedError as e:
        pass


# Generated at 2022-06-21 07:16:22.121602
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    from ansible.plugins.shell import ShellModule
    from ansible.module_utils.common.text.converters import to_bytes
    shell = ShellModule(connection='winrm')
    shell.noop_on_check(True)
    shell.become(True)
    shell.become_method('runas')
    shell.become_user('some_other_user')
    as_admin = shell.build_become_command()

    shell.prompt = to_bytes(shell.prompt, encoding=shell._output_encoding)
    shell.success_key = to_bytes(shell.success_key, encoding=shell._output_encoding)
    shell.set_type_to_windows()

    shell.chmod('some_file', '0777')

# Generated at 2022-06-21 07:16:33.306744
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    # Create instance
    m = ShellModule()

    # Create test data
    path = "'fsadfsa%2bfasdfas"

    # Invoke the method
    result = m.exists(path)

    # Verify the results
    assert isinstance(result, str)

# Generated at 2022-06-21 07:16:36.836172
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    try:
        module = ShellModule()
        module.chmod('/home/user', 777)
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-21 07:16:45.054314
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    print('')

    obj = None
    try:
        obj = ShellModule()
    except Exception:
        print('Caught unexpected exception')
        return

    # chown(self, paths, user)
    print('Testing chown')
    try:
        obj.chown('paths', 'user')
    except NotImplementedError:
        pass
    except Exception:
        print('Caught unexpected exception')
    print('')


# Generated at 2022-06-21 07:16:53.533919
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    from ansible.module_utils.six import PY3
    from ansible.plugins.shell import ShellModule

    # Create an instance of ShellModule class
    sm = ShellModule()

    # Check if the object is an instance of ShellModule class
    assert isinstance(sm, ShellModule), 'test_ShellModule_remove() Failed: object is not an instance of ShellModule class'

    # Test remove method of ShellModule class
    if PY3:
        assert sm.remove("'C:\\Users\\aamir.sharif.TAL\\AppData\\Local\\Temp\\tmpo0jd0hv7'", True) == b"Remove-Item 'C:\\Users\\aamir.sharif.TAL\\AppData\\Local\\Temp\\tmpo0jd0hv7' -Force -Recurse;"

# Generated at 2022-06-21 07:16:55.448776
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    shellmod = ShellModule()
    assert 'chmod is not implemented for Powershell' == shellmod.chmod('a', 'b')


# Generated at 2022-06-21 07:16:59.142454
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell_module = ShellModule()

    try:
        shell_module.set_user_facl("test", "test", "test")
    except Exception as e:
        assert type(e) == NotImplementedError


# Generated at 2022-06-21 07:17:06.402875
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module = ShellModule()
    assert re.match(r'^.*?\d+$', shell_module.mkdtemp('tmp'))
    assert re.match(r'^.*?\d+$', shell_module.mkdtemp('tmp', tmpdir='C:\\tmp'))


# Generated at 2022-06-21 07:17:11.695269
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    module = ShellModule()
    script = module.exists("\\temp\\test.txt")
    assert b'If (Test-Path' in script
    assert b"$res = 1;" in script
    assert b"$res = 0;" in script
    assert b"Exit $res;" in script


# Generated at 2022-06-21 07:17:18.918806
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_module = ShellModule('/tmp')
    # Check if the instance is created successfully or not
    assert isinstance(shell_module, ShellModule)

    # Check if it is true that SHELL_FAMILY is 'powershell' as expected
    assert shell_module.SHELL_FAMILY == 'powershell'

    # Check if it is true that the instance doesn't support binary plugins
    assert not shell_module.supports_binary

# Generated at 2022-06-21 07:18:26.134255
# Unit test for constructor of class ShellModule
def test_ShellModule():
    module = ShellModule()
    # Assert default ShellModule
    assert module is not None
    assert module._SHELL_REDIRECT_ALLNULL is not None
    assert module._SHELL_AND is not None
    assert module._IS_WINDOWS is not None
    assert module.COMPATIBLE_SHELLS is not None
    assert module.SHELL_FAMILY is not None

# Unit tests for common shell filenames that this plugin handles

# Generated at 2022-06-21 07:18:28.843102
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell_module = ShellModule()
    assert shell_module.env_prefix() == ''


# Generated at 2022-06-21 07:18:33.799704
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    plugin = ShellModule()
    assert plugin.path_has_trailing_slash('"C:\\Users\\ansible\\Documents"') == False
    assert plugin.path_has_trailing_slash('"C:\\Users\\ansible\\Documents" /') == True
    assert plugin.path_has_trailing_slash('"C:\\Users\\ansible\\Documents" \\') == True

# Generated at 2022-06-21 07:18:42.454843
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Test with a unicode path that has  backslash
    path = u'C:\\Program Files\\example'
    shell = ShellModule()
    assert shell.join_path(path, '/') == u'C:\\Program Files\\example/'
    assert shell.join_path(path, '\\') == u'C:\\Program Files\\example\\'
    assert shell.join_path(path, '\\') == u'C:\\Program Files\\example\\'
    assert shell.join_path(path, u'\\') == u'C:\\Program Files\\example\\'
    assert shell.join_path('\\', path) == u'\\C:\\Program Files\\example'
    assert shell.join_path('\\\\', path) == u'\\\\C:\\Program Files\\example'