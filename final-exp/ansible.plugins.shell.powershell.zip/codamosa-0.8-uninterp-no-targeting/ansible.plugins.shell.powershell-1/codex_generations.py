

# Generated at 2022-06-21 07:08:56.159822
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    assert(ShellModule(connection=None).wrap_for_exec('some command') == '& some command; exit $LASTEXITCODE')

# Generated at 2022-06-21 07:09:01.010552
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    print('Test ShellModule join_path method')
    shell_module = ShellModule()
    path = shell_module.join_path('c:\\unittest\\', '\\test\\')
    print('Expect path: ' + path)
    if path != 'c:\\unittest\\test\\':
        raise Exception('ShellModule join_path method test failed. Actual result: %s' % path)

# Generated at 2022-06-21 07:09:06.714758
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset(), 'Failed to create instance of ShellModule class'
    assert shell.SHELL_FAMILY == 'powershell', 'Failed to create instance of ShellModule class'



# Generated at 2022-06-21 07:09:17.764422
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    from ansible_collections.ansible.builtin.plugins.module_utils.powershell import powershell

    # Test for basic case, where recurse=True.
    module = powershell.ShellModule()
    script = module.remove("C:\\ansible\\dummy\\folder", recurse=False)

    assert to_text("Remove-Item 'C:\\ansible\\dummy\\folder' -Force;") in script

    # Test for basic case, where recurse=False.
    module = powershell.ShellModule()
    script = module.remove("C:\\ansible\\dummy\\folder", recurse=False)

    assert to_text("Remove-Item 'C:\\ansible\\dummy\\folder' -Force;") in script



# Generated at 2022-06-21 07:09:30.009056
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # requires a mock module under /tmp named foo.ps1
    module = ShellModule()
    fake_shebang = '#!powershell'
    fake_cmd = 'foo.ps1'
    result = module.build_module_command('', fake_shebang, fake_cmd)
    expected = '''type "foo.ps1" | & { Set-StrictMode -Version Latest\r\nif(!$?) { if(Get-Variable -Name LastExitCode -ErrorAction SilentlyContinue) { exit $LastExitCode } else { exit 1 } }\r\n'Write-Output "Hello from module wrapper";$global:ShowArgs $global:Args\r\nExit $LASTEXITCODE }'''
    assert result == expected

# Generated at 2022-06-21 07:09:43.201395
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    fake_schema = {
        'type': 'object',
        'properties': {
            'path': {'type': 'string'},
            'user': {'type': 'string'}
        },
        'additionalProperties': False,
        'required': ['path', 'user']
    }

# Generated at 2022-06-21 07:09:48.672000
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell_module = ShellModule(connection=None)
    cmd = 'Write-Host "Hello"'
    wrapped_cmd = shell_module.wrap_for_exec(cmd)
    assert wrapped_cmd == '& Write-Host "Hello"; exit $LASTEXITCODE'

# Generated at 2022-06-21 07:09:57.285675
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.shell import ShellModule

    module = AnsibleModule(
        argument_spec = dict(),
    )

    p = ShellModule(module=module)
    try:
        p.chown('/path/foo', 'user')
    except NotImplementedError as e:
        assert(e.args[0] == 'chown is not implemented for Powershell')


# Generated at 2022-06-21 07:10:00.775211
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    obj = ShellModule()

    try:
        obj.chmod(1, 1)
    except Exception as exc:
        assert isinstance(exc, NotImplementedError)


# Generated at 2022-06-21 07:10:12.074093
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    # Positive tests
    assert ShellModule().wrap_for_exec("echo hello") == "& echo hello; exit $LASTEXITCODE"
    assert ShellModule().wrap_for_exec("exit 123") == "& exit 123; exit $LASTEXITCODE"

    # Negative tests
    # test wrap_for_exec with invalid input
    try:
        ShellModule().wrap_for_exec("echo hello > C:\\Users\\user\\Documents\\hello.txt")
    except Exception as e:
        assert "does not support writing" in to_text(e)

    try:
        ShellModule().wrap_for_exec("$out = echo hello")
    except Exception as e:
        assert "does not support piping" in to_text(e)



# Generated at 2022-06-21 07:10:26.298128
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule(connection=None, runner=None, shell=None)
    assert sm._SHELL_REDIRECT_ALLNULL == "> $null"
    assert sm._SHELL_AND == ";"
    assert sm.join_path("foo", "bar") == "foo\\bar"
    assert sm.get_remote_filename("foo.txt") == "foo.ps1"
    assert sm.get_remote_filename("C:/foo/bar.txt") == "bar.ps1"
    assert sm.get_remote_filename("C:/bar.ps1") == "bar.ps1"
    assert sm.get_remote_filename("foo/bar.txt") == "bar.ps1"
    assert sm.get_remote_filename("foo/bar") == "bar.ps1"
    assert sm.get_remote_filename

# Generated at 2022-06-21 07:10:36.242281
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.powershell.connection import Connection


# Generated at 2022-06-21 07:10:38.045417
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()


if __name__ == '__main__':
    test_ShellModule()

# Generated at 2022-06-21 07:10:41.688964
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell = ShellModule()
    remove_result = shell.remove(path="~\\Desktop\\file.txt")
    assert remove_result == '''Remove-Item '"~\\Desktop\\file.txt"' -Force;'''


# Generated at 2022-06-21 07:10:54.948012
# Unit test for constructor of class ShellModule
def test_ShellModule():
    import types
    import os
    import sys

    if sys.version_info[:2] < (2,7):
        import unittest2 as unittest
    else:
        import unittest

    class TestShellModule(unittest.TestCase):
        def setUp(self):
            '''setup and instantiate class to be tested'''
            self.plugin_instance = ShellModule()
        def test_type(self):
            '''test type of object returned by constructor'''
            self.assertEqual(type(self.plugin_instance), types.InstanceType)
        def test_obj_name(self):
            '''test name of object returned by constructor'''
            self.assertEqual(self.plugin_instance.__class__.__name__, 'ShellModule')

# Generated at 2022-06-21 07:11:02.252261
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    sm = ShellModule(load_options=dict())

    # Test path with neither forward nor back slash
    assert not sm.path_has_trailing_slash('testing')

    # Test path with forward slash
    assert sm.path_has_trailing_slash('test/')

    # Test path with back slash
    assert sm.path_has_trailing_slash('test\\')

    # Test path with both forward and back slash
    assert sm.path_has_trailing_slash('test/\\')

# Generated at 2022-06-21 07:11:06.232218
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    sm = ShellModule()
    assert sm.env_prefix() == ""



# Generated at 2022-06-21 07:11:09.106581
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule()
    cmd = '& echo hello'
    expected = cmd + '; exit $LASTEXITCODE'
    assert shell.wrap_for_exec(cmd) == expected

# Generated at 2022-06-21 07:11:17.657719
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # the test case data
    data = [
        (b'c:\\', False),
        (b'c:\\foo\\', True),
        (b'c:\\foo\\bar\\', True),
        (b'c:\\foo\\bar\\ ', True),
        (b'c:/', False),
        (b'c:/foo', False),
        (b'c:/foo/', True),
        (b'c:/foo/bar/', True),
        (b'c:/foo/bar', False),
        (b'c:/foo//bar/', True),
        (b'c:/foo\\bar/', True),
    ]

    # create an instance of the module
    sm = ShellModule()

    # perform the tests
    for path, expected in data:
        result = sm.path_has_trailing

# Generated at 2022-06-21 07:11:25.376980
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # [1] Test for module command specified in Windows path format
    module_name = 'C:\\Program Files\\Ansible\\test_module.ps1'
    shebang = '#!powershell'
    cmd = ShellModule.build_module_command(ShellModule(), module_name, shebang=shebang)
    assert cmd.startswith('type "C:\\Program Files\\Ansible\\test_module.ps1" | ')
    # [2] Test for module command specified in Unix path format
    module_name = '/usr/local/bin/test_module.ps1'
    cmd = ShellModule.build_module_command(ShellModule(), module_name, shebang=shebang)
    assert cmd.startswith('type "/usr/local/bin/test_module.ps1" | ')
    # [3

# Generated at 2022-06-21 07:11:42.508302
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    module = ShellModule()

    # Test with shebang == #!powershell
    shebang = '#!powershell'

# Generated at 2022-06-21 07:11:53.525070
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    _mod = ShellModule()
    _mod.connection = 'local'

# Generated at 2022-06-21 07:12:02.638235
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    # Test data
    path = "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"
    # Test
    s = ShellModule()
    r = s.checksum(path)
    assert to_text(r) == u"70EB74C6D30C56DF48892EF2E07BC663EA9E9B57"


# Generated at 2022-06-21 07:12:11.944113
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    import tempfile
    from ansible.module_utils.common.text.converters import to_bytes

    # Initialize a file-like object to store the results of the mkdtemp call
    result_file = tempfile.TemporaryFile()

    module = ShellModule(connection=None)
    module.no_log = True

    # Specfiy the tmp location to use for the test
    tmp_path = tempfile.mkdtemp()
    tmp_path = to_bytes(tmp_path, encoding='utf-8')

    # Initialize the local test variables to be used by the shell module method
    basefile = "test_powershell_file"
    system = False
    mode = None
    tmpdir = "$env:TEMP"

    # Call the method under test

# Generated at 2022-06-21 07:12:15.221348
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule('/dev/null')
    assert shell.expand_user(u'~/abc') == shell._encode_script("Write-Output ((Get-Location).Path + '%s')" % shell._escape(u'\\abc'))

# Generated at 2022-06-21 07:12:28.718448
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    sm = ShellModule()

    # Test cases for single trailing backslash
    result = sm.expand_user("~\\", 'username')
    assert result == sm._encode_script("Write-Output ((Get-Location).Path + '\\')")

    result = sm.expand_user("~\\test\\", 'username')
    assert result == sm._encode_script("Write-Output ((Get-Location).Path + '\\test\\')")

    # Test cases for single trailing slash
    result = sm.expand_user("~/", 'username')
    assert result == sm._encode_script("Write-Output ((Get-Location).Path + '/')")

    result = sm.expand_user("~/test/", 'username')

# Generated at 2022-06-21 07:12:37.331885
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    """powershell shell module"""
    from ansible.compat.tests.mock import patch, MagicMock

    os_path_exists_mock = MagicMock(return_value=True)
    with patch.dict('ansible.plugins.action.environment.os.path.exists', os_path_exists_mock, clear=True):
        shell_module = ShellModule()
        assert shell_module.env_prefix(FOO='foo', BAR='bar') == ''


# Generated at 2022-06-21 07:12:47.977146
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    """
    This test case is to test the checksum method in class ShellModule for multiple file types.
    1. It will create a *.txt and *.tmp file in the local test path.
    2. It will create a folder in the local test path.
    3. It will create a notExistFile in the local test path.
    4. It will test the checksum() of the above created files and folder.
    """
    from ansible.utils.path import makedirs_safe
    from ansible.errors import AnsibleError
    import os

    shell_module = ShellModule()
    temp_path = os.path.abspath('/tmp/test/')
    makedirs_safe(temp_path)
    # create a text file

# Generated at 2022-06-21 07:12:55.591516
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    powershell = ShellModule(None)
    assert not powershell.path_has_trailing_slash('c:\\temp')
    assert powershell.path_has_trailing_slash('c:\\temp\\')
    assert not powershell.path_has_trailing_slash('c:\\temp\\\\')
    assert powershell.path_has_trailing_slash('c:\\temp\\\\\\')
    assert not powershell.path_has_trailing_slash('c:\\temp\\\\\\ ')
    assert powershell.path_has_trailing_slash('c:\\temp\\\\\\ \\')
    assert not powershell.path_has_trailing_slash('c:\\temp////// ')

# Generated at 2022-06-21 07:13:00.589045
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    # Test ShellModule.__init__()
    assert shell is not None
    assert isinstance(shell, ShellModule)
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'


# Generated at 2022-06-21 07:13:06.557776
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    test_class_instance = ShellModule()
    with pytest.raises(NotImplementedError) as err:
        test_class_instance.chmod('/test/path', 0o777)
    assert str(err.value) == 'chmod is not implemented for Powershell'


# Generated at 2022-06-21 07:13:15.925615
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    test_file = 'WindowsPowerShell\\v1.0\\powershell.exe'
    sm = ShellModule()
    result = sm.checksum(test_file)
    script = result.split(' ')[-1]

    # Get the script and remove the return parameter ($res)
    script = '\n'.join([line for line in script.split('\n') if not line.strip().startswith('Write-Output')])
    script = script.replace('\r', '') + '\nWrite-Output $res'
    script = script.replace('\n', '\r\n')

    ps_script = base64.b64encode(script.encode('utf-16-le'))

# Generated at 2022-06-21 07:13:17.170185
# Unit test for constructor of class ShellModule
def test_ShellModule():
    s = ShellModule()
    pass

# Generated at 2022-06-21 07:13:21.420438
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    test_ShellModule = ShellModule()
    assert test_ShellModule.env_prefix() == ""


# Generated at 2022-06-21 07:13:34.751061
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell_module = ShellModule()

    # if recurse is False and path ends with '\'

# Generated at 2022-06-21 07:13:37.049555
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    from ansible.errors import AnsibleError
    from ansible.plugins.shell import ShellModule

    shell_obj = ShellModule()

    assert shell_obj.env_prefix(FOO='bar') == ''

# Generated at 2022-06-21 07:13:46.387428
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # Test for Windows
    module = ShellModule()
    assert module.expand_user('~\\test') == 'Write-Output ((Get-Location).Path + \'\\\\test\')'
    # Test for Posix
    module.SHELL_FAMILY = 'posix'
    module.COMPATIBLE_SHELLS = ('posix', )
    assert module.expand_user('~') == "Write-Output (Get-Location).Path"
    assert module.expand_user('~\\test') == 'Write-Output \'\\\\test\''
    # Reset values to Windows
    module.SHELL_FAMILY = 'powershell'
    module.COMPATIBLE_SHELLS = frozenset()

# Generated at 2022-06-21 07:13:50.968212
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule(connection=None, become_method='sudo', become_user='root')
    assert shell.env_prefix() == ""



# Generated at 2022-06-21 07:13:58.570481
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    s = ShellModule()
    cmd = s.exists(r'C:\Temp\dummy.txt')
    assert to_bytes(cmd).strip().decode('utf-8') == to_bytes('''
            If (Test-Path 'C:\\Temp\\dummy.txt')
            {
                $res = 0;
            }
            Else
            {
                $res = 1;
            }
            Write-Output '$res';
            Exit $res;
         '''.strip())

# Generated at 2022-06-21 07:14:08.461979
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    sm = ShellModule()
    cmd, rc = sm.remove('c:/tmp/foo.txt')
    assert cmd == b"Remove-Item 'c:/tmp/foo.txt' -Force;", cmd
    assert rc == 0, rc

    cmd, rc = sm.remove('c:/tmp/foo.txt', recurse=True)
    assert cmd == b"Remove-Item 'c:/tmp/foo.txt' -Force -Recurse;", cmd
    assert rc == 0, rc


# Generated at 2022-06-21 07:14:23.469407
# Unit test for method join_path of class ShellModule

# Generated at 2022-06-21 07:14:34.246144
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    cmds = [
        (r'echo "hello"', 'echo "hello"'),
        (r'echo $(pwd)', 'echo $(pwd)'),
        (r'echo ' + r' `$(pwd)`', 'echo ' + r' `$(pwd)`'),
        (r'echo ' + r' `$(pwd)`' + r' `$(pwd)`', 'echo ' + r' `$(pwd)`' + r' `$(pwd)`'),
        ('cmd /c echo "hello"', 'cmd /c echo "hello"'),
    ]
    for cmd, expected_output in cmds:
        test_cmd = ShellModule.wrap_for_exec(ShellModule(), cmd)

# Generated at 2022-06-21 07:14:44.272693
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    obj = ShellModule()
    assert obj.path_has_trailing_slash('/tmp/')
    assert obj.path_has_trailing_slash('/tmp') is False
    assert obj.path_has_trailing_slash('/tmp\\')
    assert obj.path_has_trailing_slash('\\tmp\\')
    assert obj.path_has_trailing_slash('tmp') is False
    assert obj.path_has_trailing_slash('tmp\\')
    assert obj.path_has_trailing_slash('\\\\server\\share') is False
    assert obj.path_has_trailing_slash('\\\\server\\share\\')
    assert obj.path_has_trailing_slash('C:\\tmp\\')

# Generated at 2022-06-21 07:14:47.644468
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    '''Unit test for method get_remote_filename of class ShellModule'''
    ps_shell = ShellModule(connection=None, play_context=None, shell_type='powershell')
    remote_filename = ps_shell.get_remote_filename('test.ps1')

    assert remote_filename == 'test.ps1'

# Generated at 2022-06-21 07:14:56.819226
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    shell_module = ShellModule(conn=None)

    # Test checksum of a file using checksum method of ShellModule
    path = shell_module._escape(shell_module._unquote('c:\\users\\administrator\\hello.txt'))

# Generated at 2022-06-21 07:15:01.202554
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    # arrange
    shell_ = ShellModule()

    # act
    path = shell_.join_path(r"C:/a/b", r"c:\d\e", r"\f", "g")

    # assert
    assert path == r"C:\a\b\c\d\e\f\g"

# Generated at 2022-06-21 07:15:06.881091
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    powershell_shell = ShellModule()
    assert powershell_shell.wrap_for_exec(u'& { Set-Alias foo bar }') == u'& { Set-Alias foo bar }; exit $LASTEXITCODE'


# Generated at 2022-06-21 07:15:10.185729
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    module = ShellModule()
    path = 'C:\\Windows\\Temp\\';
    script = module.remove(path=path, recurse=True);
    assert script == b'Remove-Item \'C:\\Windows\\Temp\\\' -Force -Recurse;'

# Generated at 2022-06-21 07:15:19.375690
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    from ansible.plugins.shell import ShellModule
    shell_module = ShellModule()

    assert shell_module.join_path('C:\\test', 'test', 'test_file.txt') == 'C:\\test\\test\\test_file.txt'
    assert shell_module.join_path('C:\\test', 'test\\test_file.txt') == 'C:\\test\\test\\test_file.txt'
    assert shell_module.join_path('C:\\test', '', 'test\\test_file.txt') == 'C:\\test\\test\\test_file.txt'
    assert shell_module.join_path('\\test\\', '\\test\\test_file.txt') == '\\test\\test\\test_file.txt'

# Generated at 2022-06-21 07:15:26.786955
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    """Test method join_path of class ShellModule"""
    import pytest

    # Test paths without trailing slashes
    path_one = 'C:\\Windows\\System32\\WindowsPowerShell'
    path_two = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0'
    result = ShellModule().join_path(path_one, path_two)
    assert result == path_two

    # Test paths with trailing slashes
    path_one = 'C:\\Windows\\System32\\WindowsPowerShell\\'
    path_two = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\'
    result = ShellModule().join_path(path_one, path_two)
    assert result == path_two

    # Test paths with extra slashes

# Generated at 2022-06-21 07:15:34.987571
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    test_cases = [
        ('test.bat', 'test.bat'),
        ('test.exe', 'test.exe'),
        ('test.ps1', 'test.ps1'),
        ('test.py', 'test.py.ps1'),
        ('test.j2', 'test.j2.ps1')
    ]
    for case, expected in test_cases:
        assert shell.get_remote_filename(case) == expected

# Generated at 2022-06-21 07:15:45.786553
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Construct a new instance of ShellModule for the unit test
    shell_module = ShellModule()
    assert shell_module.path_has_trailing_slash("C:\\Path\\With\\Trailing\\Slash\\")
    assert shell_module.path_has_trailing_slash("C:\\Path\\With\\TrailingSlash\\")
    assert not shell_module.path_has_trailing_slash("C:\\Path\\With\\No\\Trailing\\Slash")
    assert not shell_module.path_has_trailing_slash("C:\\Path\\WithNoTrailingSlash")


# Generated at 2022-06-21 07:15:52.660323
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    command = "Get-UICulture | select -ExpandProperty DisplayName"
    exp_command = '& Get-UICulture | select -ExpandProperty DisplayName; exit $LASTEXITCODE'
    result = ShellModule.wrap_for_exec(ShellModule, command)
    print("Expected: %s\nGot: %s" % (exp_command, result))
    assert result == exp_command
    print("Success")

if __name__ == '__main__':
    test_ShellModule_wrap_for_exec()

# Generated at 2022-06-21 07:16:05.192700
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    import sys
    import os
    import base64
    dummy_module_path = sys.modules[__name__].__file__
    dummy_module_path = os.path.dirname(dummy_module_path)
    def get_fixture(name):
        filename = os.path.join(dummy_module_path, '../../../../test/units/modules/fixtures/checksum/{}'.format(name))
        with open(filename, 'rb') as f:
            data = f.read()
        return data

    assert get_fixture('file1').decode('utf-8').strip() == to_text(base64.b64decode(ShellModule(None, None).checksum('file1', 'sha1')))
    assert get_fixture('file2').decode('utf-8').strip

# Generated at 2022-06-21 07:16:09.334553
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    sh_module = ShellModule()
    try:
        sh_module.chmod()
        failed = False
    except NotImplementedError:
        failed = True
    if not failed:
        raise Exception('Expected NotImplementedError from ShellModule.chmod()')


# Generated at 2022-06-21 07:16:21.334307
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    assert ShellModule().mkdtemp() == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('$env:TEMP')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmp'
        Write-Output -InputObject $tmp.FullName
        '''
    assert ShellModule().mkdtemp(basefile="tmp", tmpdir="/tmp/") == '''
        $tmp_path = [System.Environment]::ExpandEnvironmentVariables('/tmp/')
        $tmp = New-Item -Type Directory -Path $tmp_path -Name 'tmp'
        Write-Output -InputObject $tmp.FullName
        '''

# Generated at 2022-06-21 07:16:32.855542
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # TODO: convert this to a pytest test
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    shell_plugin = ShellModule(module)
    user_home = '~'
    script = shell_plugin.expand_user(user_home)

# Generated at 2022-06-21 07:16:35.506706
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    shell = ShellModule()
    assert shell.chmod == NotImplemented


# Generated at 2022-06-21 07:16:47.070326
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    shell = ShellModule(connection=None, no_log=None, _new_stdin=None, _new_stdout=None, _new_stderr=None)

    script = shell.exists('C:/')
    cmd = shell._encode_script(script=script)
    encoded_cmd = cmd.split()[-1]
    decoded_cmd = base64.b64decode(encoded_cmd).decode('utf-16-le')
    assert decoded_cmd.strip() == '''
            If (Test-Path 'C:/')
            {
                $res = 0;
            }
            Else
            {
                $res = 1;
            }
            Write-Output '$res';
            Exit $res;
         '''.strip()

# Generated at 2022-06-21 07:16:56.278962
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    from ansible.module_utils._text import to_text
    # bypass the self.get_option in AnsibleModule, which coming from the
    # connection plugin
    connect_params = dict(no_log=True, become_method='runas', become_user='system')
    connection = ShellModule(shell_type='powershell',
                             modulename='git',
                             args=dict(creates='C:\\test'),
                             task_uuid=None,
                             runner_uuid=None,
                             ansible_module_class=None,
                             connect_params=connect_params)
    pathname = 'C:\\Scripts\\Script.ps1'
    result = connection.get_remote_filename(pathname)

# Generated at 2022-06-21 07:17:05.536949
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell_module = ShellModule('', '', '')
    wrapped_cmd = shell_module.wrap_for_exec("command")
    assert wrapped_cmd == '& command; exit $LASTEXITCODE'



# Generated at 2022-06-21 07:17:09.346517
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    # Asserts the number of arguments for wrap_for_exec
    module = ShellModule()
    assert 1 == len(inspect.getargspec(module.wrap_for_exec)[0])


# Generated at 2022-06-21 07:17:15.671442
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    shell.paths = dict()
    result = shell.set_user_facl()
    assert result == NotImplementedError

# Generated at 2022-06-21 07:17:17.095023
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    with pytest.raises(NotImplementedError):
        shell.set_user_facl('', '', '')

# Generated at 2022-06-21 07:17:22.242508
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shellmod = ShellModule()

    pathname = 'C:\\Some\\Path\\To\\A\\File.Ext'
    assert shellmod.get_remote_filename(pathname) == 'File.Ext'

    pathname = 'C:\\Some\\Path\\To\\A\\File'
    assert shellmod.get_remote_filename(pathname) == 'File.ps1'

    pathname = 'C:\\Some\\Path\\To\\A\\File.ps1'
    assert shellmod.get_remote_filename(pathname) == 'File.ps1'

    pathname = 'C:\\Some\\Path\\To\\A\\File.EXE'
    assert shellmod.get_remote_filename(pathname) == 'File.EXE'


# Generated at 2022-06-21 07:17:31.405333
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    from ansible.plugins.shell import ShellModule
    resp = ShellModule(connection=None, no_log=False, ansible_winrm_scheme='http', ansible_winrm_server_cert_validation='ignore', ansible_host='host', ansible_winrm_transport='kerberos', ansible_winrm_port=5985, **dict(connection=None, no_log=False, ansible_winrm_scheme='http', ansible_winrm_server_cert_validation='ignore', ansible_host='host', ansible_winrm_transport='kerberos', ansible_winrm_port=5985))
    result = resp.expand_user(user_home_path='~', username='')

# Generated at 2022-06-21 07:17:37.692358
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    script = ShellModule().chown('C:\\temp', 'test')
    assert script == b"powershell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -command \" 'C:\\\\temp'  | Set-Acl -User test; "


# Generated at 2022-06-21 07:17:42.740440
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    from ansible.plugins.shell import ShellModule
    from ansible.module_utils.common._collections_compat import MutableMapping
    # pylint: disable=unused-variable
    mock_self = MutableMapping()
    mock_self.runner = MutableMapping()
    mock_self.runner.get_option = lambda x, y, z=None: '/tmp/'
    assert ShellModule.mkdtemp(mock_self) is not None

# Generated at 2022-06-21 07:17:51.962869
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.executor.task_result import TaskResult
    powershell_shell_shell_module = ShellModule(None, None, None)
    env_string = None
    shebang = 'test shebang'
    cmd = 'test cmd'
    arg_path = None
    expected_output = b'#!powershell\ntype test cmd.ps1 | & $input | iex; exit $LASTEXITCODE;'
    assert powershell_shell_shell_module.build_module_command(env_string, shebang, cmd, arg_path) == expected_output

# Generated at 2022-06-21 07:18:02.832826
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert (shell.path_has_trailing_slash(r'\temp'))

# Generated at 2022-06-21 07:18:22.027941
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule()

    cmd = shell.wrap_for_exec('echo hi')
    assert cmd == '& echo hi; exit $LASTEXITCODE'
    cmd = shell.wrap_for_exec('')
    assert cmd == '& ; exit $LASTEXITCODE'
    cmd = shell.wrap_for_exec(None)
    assert cmd == '& ; exit $LASTEXITCODE'
    cmd = shell.wrap_for_exec("\"'&<>")
    assert cmd == "& \"'&<>; exit $LASTEXITCODE"
    cmd = shell.wrap_for_exec("cmd")
    assert cmd == "& cmd; exit $LASTEXITCODE"

# Generated at 2022-06-21 07:18:26.000776
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    assert False, "Test if the method works correctly."


# Generated at 2022-06-21 07:18:28.764840
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule(connection=None)
    assert shell.SHELL_FAMILY == 'powershell'

# Generated at 2022-06-21 07:18:36.132231
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    script = '''
            If (Test-Path 'c:/Temp/test')
            {
                $res = 0;
            }
            Else
            {
                $res = 1;
            }
            Write-Output '$res';
            Exit $res;
         '''
    encoded_script = to_text(base64.b64encode(script.encode('utf-16-le')), 'utf-8')
    encoded_script = "PowerShell.exe -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand %s" % encoded_script
    cmd_parts = "powershell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand %s" % encoded_script
    return cmd_parts



# Generated at 2022-06-21 07:18:41.881255
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    # TODO: create test_module_utils
    #setup_module_args(dict(path='foo', recurse=True))
    #mod = AnsibleModule(argument_spec=module_args)
    #shell = ShellModule(mod)
    #result = shell.remove()
    #assert result == "Remove-Item 'foo' -Force -Recurse;"
    pass

# Generated at 2022-06-21 07:18:53.486499
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    plugin = ShellModule(connection=None)
    remote_filename = plugin.get_remote_filename('/tmp/test.ps1')
    assert remote_filename == "/tmp/test.ps1"
    remote_filename = plugin.get_remote_filename('C:\\Windows\\System32\\test.exe')
    assert remote_filename == "test.exe"
    remote_filename = plugin.get_remote_filename('C:\\Windows\\System32\\test')
    assert remote_filename == "test.ps1"
    remote_filename = plugin.get_remote_filename('C:\\Windows\\System32\\test.ps1')
    assert remote_filename == "test.ps1"