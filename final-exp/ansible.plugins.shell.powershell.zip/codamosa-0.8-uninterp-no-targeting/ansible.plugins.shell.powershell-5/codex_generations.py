

# Generated at 2022-06-21 07:09:02.175457
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    import os
    import tempfile

    # Return value for expand_user for success scenario
    def expand_user_success(user_home_path, username=''):
        script = "Write-Output '%s'\r\n" % os.path.expanduser(user_home_path)
        encoded_script = to_text(base64.b64encode(script.encode('utf-16-le')), 'utf-8')
        cmd_parts = _common_args + ['-EncodedCommand', encoded_script]
        return ' '.join(cmd_parts)

    # Return value for expand_user for failure scenario
    def expand_user_failure(user_home_path, username=''):
        script = "Write-Output '%s'\r\n" % user_home_path

# Generated at 2022-06-21 07:09:11.810190
# Unit test for method checksum of class ShellModule

# Generated at 2022-06-21 07:09:22.678717
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    from ansible.plugins.shell.powershell import ShellModule

    shell_module = ShellModule()

    # Test join_path with various input combinations
    # Expected results are based on the behavior of the underlying ntpath.join
    assert shell_module.join_path('', '') == ''
    assert shell_module.join_path('', '', '') == ''
    assert shell_module.join_path('', 'test') == 'test'
    assert shell_module.join_path('', 'test', 'test') == 'test\\test'
    assert shell_module.join_path('', 'test', 'test', '') == 'test\\test'
    assert shell_module.join_path('', 'test\\', 'test\\') == 'test\\test'

# Generated at 2022-06-21 07:09:28.325107
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    ref_shell = ShellModule(None)
    module_checksum = ref_shell.checksum("test.ps1")

    test_shell = type("", (object,), {
        "_ShellModule__encode_script": lambda self, script, *args, **kwargs: script,
        "_ShellModule__escape": lambda self, value: value,
        "_ShellModule__unquote": lambda self, value: value,
        "get_option": lambda self, *args, **kwargs: ""
    })()
    assert module_checksum == test_shell.checksum("test.ps1")


# Generated at 2022-06-21 07:09:40.031864
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    # Bootstrap ShellModule
    class OptionsModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Task(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class PlayContext(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Play(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class VariablesModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-21 07:09:51.200741
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    def _escape(value):
        return re.compile(u"(['\u2018\u2019\u201a\u201b])").sub(u'\\1\\1', value)
    test_path = "test.xml"
    expected_cmd = "& Remove-Item 'test.xml' -Force\n"
    sm = ShellModule()
    assert(sm.remove(test_path) == expected_cmd)
    expected_cmd = "& Remove-Item 'test.xml' -Force -Recurse\n"
    assert(sm.remove(test_path, recurse=True) == expected_cmd)


# Generated at 2022-06-21 07:10:00.595189
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    # A subclass of ShellModule to expose the protected set_user_facl method for unit testing
    class TestShellModule(ShellModule):
        def __init__(self):
            pass

        def set_user_facl(self, paths, user, mode):
            return super(TestShellModule, self).set_user_facl(paths, user, mode)

    shell = TestShellModule()
    try:
        shell.set_user_facl("./test_path", "user01", "+x")
    except NotImplementedError:
        pass
    else:
        assert True, "Test failed: ShellModule.set_user_facl raises a NotImplementedError"


# Generated at 2022-06-21 07:10:11.336230
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    sh = ShellModule()
    cmd = sh.build_module_command('', '#!powershell', 'ansible-doc -t copy')
    assert cmd == 'type ansible-doc.ps1 | $PSHOME\\powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand IABlAG4AdABlACAAcwBhAGcAZQBsAGwAIAAoACQAbQBzAC4AcABkAGYADwAaAAwACgAKQAgAC8AbwByAHQAZQBuAHQAKAApAC4AdwBlAHIAcwBhAGwAbABvAGcAKAAnACkA'


# Generated at 2022-06-21 07:10:24.469799
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    # Check if tmpdir is set to an empty string (inherit_env option), the
    # resulting command includes an empty string
    assert ShellModule().mkdtemp('', tmpdir='') == b"& { $tmp_path = [System.Environment]::ExpandEnvironmentVariables(''); $tmp = New-Item -Type Directory -Path $tmp_path -Name 'ansible-tmp-'; Write-Output -InputObject $tmp.FullName; }; exit $LASTEXITCODE"

    # This test is only valid on Windows
    if os.name != 'nt':
        return

    # Don't test when environment variable TEMP is not set
    if 'TEMP' not in os.environ:
        return

    # Create a temporary file and set tmpdir to this file, expect an error

# Generated at 2022-06-21 07:10:30.229814
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    # init shell plugin
    powershell = ShellModule()

    assert 'test.ps1' == powershell.get_remote_filename('test')
    assert 'test.ps1' == powershell.get_remote_filename('test.ps1')
    assert 'foo.exe' == powershell.get_remote_filename('foo.exe')



# Generated at 2022-06-21 07:10:41.691668
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    encoded_script = shell.mkdtemp("ansible_test")
    script = encoded_script.split(" ")[-1]
    assert script.startswith("powershell")
    assert "New-Item" in script
    assert "Base64" not in script
    assert "Type Directory" in script
    assert "PathType Container" not in script
    assert "|" not in script
    assert "ansible_test" in script

# Generated at 2022-06-21 07:10:44.709603
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    sm = ShellModule()
    result = sm.env_prefix()
    assert result == ''

# Generated at 2022-06-21 07:10:48.094604
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule()

    # Default parameter test
    result = shell.env_prefix()
    assert result == ""


# Generated at 2022-06-21 07:10:52.554942
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    import os
    import pytest

    obj = ShellModule()

    test_filename = 'tmp_script.sh'
    expected_result = 'tmp_script.sh'

    result = obj.get_remote_filename(test_filename)

    assert result == expected_result

# Generated at 2022-06-21 07:11:01.194761
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()
    assert shell._unquote('c:\\temp') == 'c:\\temp'
    assert shell._unquote('c:\\\\temp') == 'c:\\temp'
    assert shell._unquote('c:/temp') == 'c:\\temp'
    assert shell._unquote('c:\\temp\\') == 'c:\\temp'
    assert shell._unquote('c:\\temp\\\\') == 'c:\\temp'
    assert shell._unquote('/temp/') == '\\temp'

# Generated at 2022-06-21 07:11:03.612716
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    module_method = ShellModule().set_user_facl
    assert module_method('/tmp/ansible_foo') is None

# Generated at 2022-06-21 07:11:11.877705
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    args = {
        '_ansible_debug': True,
        '_ansible_keep_remote_files': False,
        '_ansible_remote_tmp': 'C:/Users/xdf7c/AppData/Local/Temp',
        '_ansible_shell_executable': '"C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"',
        '_ansible_tmpdir': 'C:/Users/xdf7c/AppData/Local/Temp',
        '_ansible_verbosity': 0,
        '_uses_shell': True
    }

# Generated at 2022-06-21 07:11:24.948090
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.module_utils.powershell import ModuleStub

    module = ModuleStub()
    shell_plugin = ShellModule(module)

    # bootstrap wrapper
    cmd, shebang, cmd_parts = shell_plugin.build_module_command(
        env_string='',
        shebang='#!powershell',
        cmd='test-command.ps1 arg1 arg2',
        arg_path=None,
    )
    assert shebang == '#!powershell'

# Generated at 2022-06-21 07:11:36.072132
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    from ansible.plugins import shell_loader
    from ansible.plugins.loader import find_plugin
    from ansible.utils.display import Display
    plugin = find_plugin(shell_loader, 'powershell')
    display = Display()
    new_shell = plugin(display)
    try:
        import ansible.executor.powershell
        tmpdir = ansible.executor.powershell.__file__.rsplit(os.sep, 1)[0]
    except:
        tmpdir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

    def _make_nested_temps():
        tmp = new_shell.mkdtemp(basefile='test_ShellModule_mkdtemp', tmpdir=tmpdir)

# Generated at 2022-06-21 07:11:37.438554
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    pass


# Generated at 2022-06-21 07:11:49.008001
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    ''' Unit test for method checksum of class ShellModule '''
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    # Get instance of ShellModule class
    sm = ShellModule()

    # Test with file path
    # Test the method with file that exists
    # file_path = 'C:/Users/MyUserName/Ansible/temp/bacon.csv'
    file_path = 'C:/Users/MyUserName/Ansible/temp/bacon.csv'
    file_path = file_path.replace('/', '\\')

# Generated at 2022-06-21 07:11:53.968790
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule()
    assert shell.wrap_for_exec('"echo 1"') == '& echo 1; exit $LASTEXITCODE'
    assert shell.wrap_for_exec('') == '&  exit $LASTEXITCODE'
    assert shell.wrap_for_exec('') == '&  exit $LASTEXITCODE'


# Generated at 2022-06-21 07:12:03.599312
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    module = ShellModule()
    path = 'C:\\Users\\Public\\Documents'
    test_path = r"'C:\\Users\\Public\\Documents'"
    assert module.exists(path) == "If (Test-Path " + test_path + ")\n            {\n                $res = 0;\n            }\n            Else\n            {\n                $res = 1;\n            }\n            Write-Output '$res';\n            Exit $res;"


# Generated at 2022-06-21 07:12:16.561011
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    import sys
    import subprocess
    with open(os.devnull, 'w') as devnull:
        original_stdout = sys.stdout
        original_stderr = sys.stderr
        try:
            sys.stdout = devnull
            sys.stderr = devnull
            subprocess.check_call('powershell.exe -Command "Set-ExecutionPolicy RemoteSigned"')
        finally:
            sys.stdout = original_stdout
            sys.stderr = original_stderr


    import os
    import tempfile
    import shutil
    shells = {
        'ansible.builtin.shell_windows.ShellModule' : 'ShellModule',
    }


# Generated at 2022-06-21 07:12:27.397431
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    ansible_module_instance = ShellModule(None)
    args_for_build_module_command = [
        '$Env:ANSIBLE_MODULE_ARGS',
        '#!powershell',
        '$Env:ANSIBLE_MODULE_ARGS',
        'arg_path',
    ]
    expected_result = ansible_module_instance._encode_script(
        '$Env:ANSIBLE_MODULE_ARGS', preserve_rc=False
    )
    result = ansible_module_instance.build_module_command(
        *args_for_build_module_command
    )
    assert result == expected_result

# Generated at 2022-06-21 07:12:30.546896
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    assert(ShellModule().wrap_for_exec('foo') == '& foo; exit $LASTEXITCODE')

# Generated at 2022-06-21 07:12:40.659971
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell_module = ShellModule()

    class ConnectionMock(object):
        def __init__(self):
            self.shell = shell_module
    
    def test_case_1():
        module_args = dict(
            _ansible_connection_type = 'winrm',
            _ansible_winrm_server_cert_validation = 'ignore',
            path = 'C:\\Users\\User\\Desktop\\File.txt',
            recurse = False)
        test_ansible_module = ConnectionMock()
        test_result = shell_module.remove(test_ansible_module, module_args)

# Generated at 2022-06-21 07:12:47.917139
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell_module = ShellModule()
    assert shell_module.path_has_trailing_slash("C:\\users\\foo\\") is True
    assert shell_module.path_has_trailing_slash("C:\\users\\foo") is False
    assert shell_module.path_has_trailing_slash("C:\\users\\foo\\") is True
    assert shell_module.path_has_trailing_slash("C:\\users\\foo") is False
    assert shell_module.path_has_trailing_slash("C:/users/foo/") is True
    assert shell_module.path_has_trailing_slash("C:/users/foo") is False

# Generated at 2022-06-21 07:12:55.563210
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.executor import module_common
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import ImmutableDict

    def _mock_pass(self):
        pass

    Display.verbosity = 4
    # Try a few if True/False combinations of different options

# Generated at 2022-06-21 07:13:03.260485
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():

    # the module's expand_user method only supports the scenario of expanding the
    # user's home directory, eg:
    #   ~ -> C:\Users\ansible
    #   ~/foo/bar -> C:\Users\ansible\foo\bar
    #   ~ansible/foo/bar -> C:\Users\ansible\foo\bar
    #   ~\foo/bar -> C:\Users\ansible\foo\bar

    # create an instance of the powershell shell module
    powershell_shell = ShellModule(connection=None)

    assert powershell_shell.expand_user('foo') == 'Write-Output foo'
    assert powershell_shell.expand_user('~') == 'Write-Output (Get-Location).Path'

# Generated at 2022-06-21 07:13:14.944828
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    env_string = "Get-Process"
    shebang = "#!powershell"
    cmd = "Test-Module"
    arg_path = "arg_path"

    shell_module = ShellModule()
    result = shell_module.build_module_command(env_string, shebang, cmd, arg_path)

    assert result == 'type "Test-Module.ps1" | & { $ErrorActionPreference = \'Stop\'; . ([ScriptBlock]::Create( [Convert]::FromBase64String( \'JAB0AGEAbgBNAG8AYQByAHkATgBhAG0AZQBzAAAAAAA=\' ))) }'



# Generated at 2022-06-21 07:13:24.522647
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()

    assert shell.expand_user('~') == shell._encode_script(script='Write-Output (Get-Location).Path', strict_mode=False, preserve_rc=False)
    assert shell.expand_user('~\\') == shell._encode_script(script="Write-Output ((Get-Location).Path + '')", strict_mode=False, preserve_rc=False)
    assert shell.expand_user('~\\data') == shell._encode_script(script="Write-Output ((Get-Location).Path + '\\data')", strict_mode=False, preserve_rc=False)

# Generated at 2022-06-21 07:13:31.488284
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()
    s = 'C:\\Program Files\\Git\\bin\\'
    # '\\' is the separator for windows
    assert shell.join_path(s, 'sh.exe') == s + 'sh.exe'
    assert shell.join_path(s, '\\sh.exe') == s + '\\sh.exe'
    assert shell.join_path(s, '\\sh.exe') == s + '\\sh.exe'
    assert shell.join_path(s, '\\', 'sh.exe') == s + '\\sh.exe'



# Generated at 2022-06-21 07:13:41.896348
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule()
    assert shell.join_path("C:\\", "dir", "dir2") == "C:\\dir\\dir2"
    assert shell.join_path("C:\\", "dir\\", "dir2") == "C:\\dir\\dir2"
    assert shell.join_path("C:\\", "dir", "") == "C:\\dir"
    assert shell.join_path("C:\\", "", "dir2") == "C:\\dir2"
    assert shell.join_path("C:\\", "", "") == "C:\\"
    assert shell.join_path("\\\\server\\share", "dir", "dir2") == "\\\\server\\share\\dir\\dir2"

# Generated at 2022-06-21 07:13:46.186793
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    parameters = dict()
    plugin = ShellModule(parameters=parameters)
    try:
        plugin.chmod("path", "mode")
        assert False
    except NotImplementedError as e:
        assert True


# Generated at 2022-06-21 07:13:50.058167
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell_module = ShellModule()
    assert shell_module.env_prefix() == ""


# Generated at 2022-06-21 07:13:59.519007
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    from ansible.utils.unicode import to_bytes
    sut = ShellModule()
    sut.shell = None

    data = [
        ('/tmp/test.ps1', 'test.ps1'),
        ('/tmp/test', 'test.ps1'),
        ('/tmp/test.py', 'test.py')
    ]

    for (pathname, expected) in data:
        actual = sut.get_remote_filename(pathname)
        assert expected == actual, "ShellModule.get_remote_filename(pathname='%s') ended up with '%s'. Expected: '%s'." % (pathname, actual, expected)



# Generated at 2022-06-21 07:14:06.244225
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    p = ShellModule()
    result = p.mkdtemp()
    assert result is not None

    result = p.mkdtemp(tmpdir=u'$env:windir')
    assert result is not None

    result = p.mkdtemp(tmpdir=u'C:\\Windows')
    assert result is not None

# Generated at 2022-06-21 07:14:08.884135
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    m = ShellModule()
    assert not m.env_prefix()


# Generated at 2022-06-21 07:14:15.180999
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():

    class TestShell(ShellModule):
        pass

    # Instantiate TestShell
    t = TestShell()

    # Test shell.expand_user('~')
    assert t.expand_user('~') == t._encode_script('Write-Output (Get-Location).Path')

    # Test shell.expand_user('~\\')
    cmd = t._encode_script('''Write-Output ((Get-Location).Path + '\\')''')
    assert t.expand_user('~\\') == cmd

    # Test shell.expand_user('~\\Desktop')
    cmd = t._encode_script('''Write-Output ((Get-Location).Path + '\\Desktop')''')
    assert t.expand_user('~\\Desktop') == cmd

    # Test shell.expand_user('~\\Desktop

# Generated at 2022-06-21 07:14:30.652505
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    # pylint: disable=line-too-long
    shell_module = ShellModule()
    script = '''If ( Test-Path "%s" ) { write-output "exists" } Else { write-output "not exists" }'''

    # test shebang line handling
    assert shell_module.build_module_command('', '#!/opt/foo/ansible-test -ss', '', '') == shell_module._encode_script(script.strip())
    assert shell_module.build_module_command('', '#!/opt/foo/ansible-test -ss', '', '') == shell_module._encode_script(script.strip())

    # test arg_path handling (for binary modules like yum, apt, etc.)

# Generated at 2022-06-21 07:14:43.073725
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    from ansible import errors
    from ansible.plugins.shell.powershell import ShellModule

    shell = ShellModule(connection=None)

    # Just unquote and escape the path
    assert shell.remove("this'\\is/a/test") == "Remove-Item 'this`\\is/a/test' -Force;"

    # If recurse is specified, include the -Recurse arg
    assert shell.remove("path/to/file", recurse=True) == "Remove-Item 'path/to/file' -Force -Recurse;"

    # Path should be quoted
    assert shell.remove("with;semicolons") == "Remove-Item 'with;semicolons' -Force;"

    # Invalid uses of recurse should result in errors

# Generated at 2022-06-21 07:14:46.427381
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.SHELL_FAMILY == 'powershell'
    assert not shell.COMPATIBLE_SHELLS

# Generated at 2022-06-21 07:14:50.732474
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell_module = ShellModule()
    results = shell_module.chown('/path/to/file', 'user')



# Generated at 2022-06-21 07:15:00.616597
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    class FakeShellModule(ShellModule):
        def __init__(self):
            self.SHELL_TYPE = 'powershell'
            self.get_option = lambda self, x: 'powershell'

    shell = FakeShellModule()
    assert shell.path_has_trailing_slash('C:/foo\\bar\\')

    shell.SHELL_TYPE = 'posh'
    assert not shell.path_has_trailing_slash('C:/foo\\bar\\')

# Generated at 2022-06-21 07:15:03.801024
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    shell.set_user_facl('/home/user/testfile.txt', 'testuser', 'r')



# Generated at 2022-06-21 07:15:16.490828
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    # Test invalid params
    # ValueError: cmd is required
    try:
        ShellModule().wrap_for_exec(cmd=None)
    except ValueError as e:
        assert "cmd is required" in str(e)

    # Test wrap_for_exec
    # cmd = 'test'
    result = ShellModule().wrap_for_exec(cmd='test')
    assert result == '& test; exit $LASTEXITCODE'

    # cmd = 'test1' and 'test2'
    result = ShellModule().wrap_for_exec(cmd=['test1', 'test2'])
    assert result == '& test1; exit $LASTEXITCODE |& test2; exit $LASTEXITCODE'



# Generated at 2022-06-21 07:15:26.237455
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    module = ShellModule(connection=None)

    # Case: Windows path does have a trailing slash.
    path = "C:\\Windows\\"
    assert module.path_has_trailing_slash(path)

    # Case: Windows path has a trailing backslash.
    path = "C:\\Windows\\"
    assert module.path_has_trailing_slash(path)

    # Case: Windows path has no trailing slash.
    path = "C:\\Windows"
    assert not module.path_has_trailing_slash(path)

    # Case: POSIX path does have a trailing slash.
    path = "/usr/bin/"
    assert module.path_has_trailing_slash(path)

    # Case: POSIX path has no trailing slash.
    path = "/usr/bin"

# Generated at 2022-06-21 07:15:29.910319
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    mod = ShellModule()
    assert mod.chown("/path/to/foo", "someone") == ''



# Generated at 2022-06-21 07:15:38.679429
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    test_script = pkgutil.get_data('ansible.executor.powershell', 'pshell_test.ps1')
    base_name = "test_script"
    node = ShellModule()
    script = node.checksum(base_name, data=test_script)
    script = script.replace("\n", "").strip()
    returncode, output = node._execute_module('shell', script, node.tmpdir, '')
    checksum = output.strip().replace("\r", "").replace("\n", "")
    expected_checksum = 'aeba1d5bac0c3e0e3c3b824d93a2a5a5f2c2e36d'
    #print("checksum output: %s" % output)
    #print("checksum expected: %

# Generated at 2022-06-21 07:15:48.296908
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    s = ShellModule()
    s.chown('/path/to/file', user='nobody')


# Generated at 2022-06-21 07:15:51.367832
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    x = ShellModule()
    assert 'chown is not implemented for Powershell' in x.chown(paths = "", user = "")


# Generated at 2022-06-21 07:15:57.546043
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell = ShellModule(connection=None, sobject=None)

    # Test for recurse parameter is False
    assert shell.remove("C:\\test\\test.txt", False) == "#!powershell\nRemove-Item 'C:\\test\\test.txt' -Force;\n"

    # Test for recurse parameter is True
    assert shell.remove("C:\\test\\test.txt", True) == "#!powershell\nRemove-Item 'C:\\test\\test.txt' -Force -Recurse;\n"


# Generated at 2022-06-21 07:16:03.747733
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    expected = NotImplementedError('chown is not implemented for Powershell')
    actual = None
    shell = ShellModule()
    try:
        shell.chown("/test/test.txt", "test")
    except NotImplementedError as e:
        actual = e
    assert expected == actual


# Generated at 2022-06-21 07:16:09.158235
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule(connection=None)
    res = shell.mkdtmp(basefile=None, system=False, mode=None, tmpdir=None)
    assert type(res) is str

# Generated at 2022-06-21 07:16:21.251150
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    test_path = '/tmp/test_file_1'

    # test error code
    script_error = '''
        If (Test-Path -PathType Leaf '%(path)s')
        {
            $res = 1;
        }
        ElseIf (Test-Path -PathType Container '%(path)s')
        {
            $res = 2;
        }
        Else
        {
            $res = 0;
        }
        Write-Output $res;
        Exit $res;
    ''' % dict(path=test_path)
    script_error_bytes = to_bytes(script_error)

    test = ShellModule()

    # test error code
    res = test._low_level_exec_command(script_error_bytes)

# Generated at 2022-06-21 07:16:27.452655
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    module = ShellModule()

# Generated at 2022-06-21 07:16:31.152917
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule()
    assert shell.get_remote_filename('test_script.ps1') == 'test_script.ps1'
    assert shell.get_remote_filename('test script') == 'test script.ps1'
    assert shell.get_remote_filename('test_script.exe') == 'test_script.exe'


# Generated at 2022-06-21 07:16:41.922965
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    sm = ShellModule()
    assert('Test1' == sm._unquote(sm._unquote('Test1'))), 'expand_user test 1 failed'
    assert('C:\\Users\\Test2' == sm._unquote(sm.expand_user('~\\Test2'))), 'expand_user test 2 failed'
    assert('C:\\Test3' == sm._unquote(sm.expand_user('C:\\Test3'))), 'expand_user test 3 failed'
    assert('C:\\Test4' == sm._unquote(sm.expand_user('C:/Test4'))), 'expand_user test 4 failed'

# Generated at 2022-06-21 07:16:51.763925
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    module = ShellModule()
    # Test checksum of a file
    sha1 = 'a8a6bba00d117b84c766a6d8a6b34209e4b3209f'
    script = module.checksum('test_file', checksum_algorithm='sha1')
    result = module._run_parts(script, preserve_rc=True, as_list=True)  # pylint: disable=protected-access
    assert sha1 in result[-1]

    # Test checksum of a directory
    dir_script = module.checksum('test_dir', checksum_algorithm='sha1')
    dir_result = module._run_parts(dir_script, preserve_rc=True, as_list=True)  # pylint: disable=protected-access
    assert dir_result

# Generated at 2022-06-21 07:17:16.686141
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell = ShellModule(connection=None, shell_executable=None)
    assert shell.get_remote_filename('lyrics.txt') == 'lyrics.txt'
    assert shell.get_remote_filename(u'lyrics.txt') == 'lyrics.txt'
    assert shell.get_remote_filename('lyrics.ps1') == 'lyrics.ps1'
    assert shell.get_remote_filename(u'lyrics.ps1') == 'lyrics.ps1'
    assert shell.get_remote_filename('lyrics') == 'lyrics.ps1'
    assert shell.get_remote_filename(u'lyrics') == 'lyrics.ps1'

# Generated at 2022-06-21 07:17:18.665663
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell = ShellModule()
    script = to_bytes(shell.remove('/foo/bar'))
    assert script == to_bytes(shell._encode_script('''Remove-Item '\\foo\\bar' -Force;'''))


# Generated at 2022-06-21 07:17:28.607774
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    com = ShellModule()
    assert not com.path_has_trailing_slash(".\\test")
    assert not com.path_has_trailing_slash("test")
    assert com.path_has_trailing_slash(".\\test\\")
    assert com.path_has_trailing_slash("test\\")
    assert com.path_has_trailing_slash("")
    assert com.path_has_trailing_slash("\\\\?\\test\\")
    assert not com.path_has_trailing_slash("\\\\?\\test")

# Generated at 2022-06-21 07:17:38.435046
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    module = ShellModule(connection=None)
    assert module.get_remote_filename('C:\\temp\\test.ps1') == 'test.ps1'
    assert module.get_remote_filename('C:\\temp\\test.py') == 'test.ps1'
    assert module.get_remote_filename('C:\\temp\\test') == 'test.ps1'
    assert module.get_remote_filename('C:\\temp\\test.exe') == 'test.exe'

# Generated at 2022-06-21 07:17:51.811180
# Unit test for method expand_user of class ShellModule

# Generated at 2022-06-21 07:17:55.284617
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    # TODO: test chown
    pass


# Generated at 2022-06-21 07:17:58.095139
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    assert ShellModule.env_prefix() == ""



# Generated at 2022-06-21 07:18:04.459467
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    stdout = b'a76fcb7118fdaa2c95ee78e8ebe955f7aac2cd2c'
    stderr = b''
    paths = [
        '/path',
        '/path/to/file',
        'C:\\Path\\To\\File',
        'C:\\Path\\To\\File.txt'
    ]
    for path in paths:
        cmd = ShellModule(conn=None, tmpdir=None, become_method='test').checksum(path=path)
        p = Popen(cmd, stdout=PIPE, stderr=PIPE)
        stdout, stderr = p.communicate()
        assert stdout == stdout
        assert stderr == stderr


# Generated at 2022-06-21 07:18:16.399433
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    # file at path exists and is a file
    path = "C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe"
    shell = ShellModule(connection=None, no_log=True)
    result = shell.exists(path)
    assert b'0' in result

    # file at path exists and is a directory
    path = "C:/Windows/System32/WindowsPowerShell"
    shell = ShellModule(connection=None, no_log=True)
    result = shell.exists(path)
    assert b'2' in result

    # file at path does not exist
    path = 'C:/Windows/System32/nonexistentfile.sh'
    shell = ShellModule(connection=None, no_log=True)
    result = shell.exists(path)

# Generated at 2022-06-21 07:18:24.560511
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    sh = ShellModule()
    cmd = sh.remove('C:\\temp\\ansible-test\\bar.txt', True)
    assert shlex.split(' '.join(cmd)) == [u'PowerShell', u'-NoProfile', u'-NonInteractive',
                                          u'-ExecutionPolicy', u'Unrestricted',
                                          u'-Command', u'Remove-Item \'C:\\temp\\ansible-test\\bar.txt\' -Force -Recurse;']

    cmd = sh.remove('C:\\temp\\ansible-test\\bar.txt')