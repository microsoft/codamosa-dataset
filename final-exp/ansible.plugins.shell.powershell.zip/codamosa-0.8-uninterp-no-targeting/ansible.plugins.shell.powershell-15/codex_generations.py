

# Generated at 2022-06-21 07:08:53.818241
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    module = ShellModule()
    assert module.mkdtemp() == "New-Item -Type Directory -Path $env:APPDATA -Name 'tmp*' | Select -Expand FullName | Write-Output"
    assert module.mkdtemp('foo') == "New-Item -Type Directory -Path $env:APPDATA -Name 'foo*' | Select -Expand FullName | Write-Output"
    assert module.mkdtemp('foo', tmpdir='/tmp') == "New-Item -Type Directory -Path '/tmp' -Name 'foo*' | Select -Expand FullName | Write-Output"


# Generated at 2022-06-21 07:09:00.406120
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    path = 'c:\\test\\test.txt'
    user = 'Administrator'
    mode = '0710'

    ps = ShellModule()
    result = ps.set_user_facl(path, user, mode)

    # The result should be "1" because it should raise a NotImplementedError
    if result != '1':
        raise Exception("The result of the function set_user_facl should be '1' but is %s" % result)

# Generated at 2022-06-21 07:09:11.110319
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    class MockModule(object):
        def __init__(self):
            self.params = {'_ansible_check_mode': False}
            self.args = ''

        def _executable_exists(self, path):
            return True

    # Tests for different path and recurse configurations

# Generated at 2022-06-21 07:09:19.684612
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    import unittest
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3

    # Note:
    # - In Python3, get_exception() is deprecated and only returns the last exception instead of the chain
    # - In Python2, no chain is returned at all

    # Create a test class and run the test against it
    class TestShellModule(ShellModule):
        # Overwrite the method, so that no escape is performed
        def _escape(self, value):
            return value
    sm = TestShellModule()

    # the command `Remove-Item C:\test -Recurse -Force` should not produce an error
    # (on Windows, C:\test might not exist)
    cmd=sm.remove(r'C:\test', True)
    assert cmd

# Generated at 2022-06-21 07:09:27.221807
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    from ansible.plugins.shell.powershell import ShellModule

    shell = ShellModule()

    # Test module code
    code = "This is the module code"
    expected = "%s" % shell._encode_script(code)
    result = shell.build_module_command(
        env_string="",
        shebang=None,
        cmd=code,
        arg_path=None)
    assert expected == result

    # Test module command
    cmd = "This is the command"
    expected = "%s" % shell._encode_script(cmd)
    result = shell.build_module_command(
        env_string="",
        shebang=None,
        cmd=cmd,
        arg_path=None)
    assert expected == result

    # Test module code with shebang
    shebang = "#!powershell"

# Generated at 2022-06-21 07:09:36.569950
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    checksum_test = ShellModule()
    checksum_test.get_option = lambda x: None
    checksum_test.PATH_SEP = '\\'


# Generated at 2022-06-21 07:09:38.971068
# Unit test for constructor of class ShellModule
def test_ShellModule():
    from ansible.plugins.shell import ShellBase
    from ansible.plugins.shell.powershell import ShellModule

    assert issubclass(ShellModule, ShellBase)

# Generated at 2022-06-21 07:09:52.135527
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    module = ShellModule(connection=None, shell_type="powershell")

    # test ~
    user_home_path = "~"
    expected = module._encode_script(module._escape(module._unquote(user_home_path)))
    assert expected == module.expand_user(user_home_path), "ShellModule.expand_user failed for user_home_path {0}".format(user_home_path)

    # test ~\some_path
    user_home_path = "~\some_path"
    expected = module._encode_script(module._escape(module._unquote(user_home_path)))
    assert expected == module.expand_user(user_home_path), "ShellModule.expand_user failed for user_home_path {0}".format(user_home_path)

# Generated at 2022-06-21 07:09:56.332778
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_obj = ShellModule(connection=None, add_final_quote=True, no_log=False)
    cmd = shell_obj.mkdtemp(basefile="mytemp")
    assert cmd.startswith("$tmp_path = [System.Environment]::ExpandEnvironmentVariables('")
    assert cmd.endswith("'); $tmp = New-Item -Type Directory -Path $tmp_path -Name 'mytemp'; Write-Output -InputObject $tmp.FullName;")
    assert cmd.find("+ 'mytemp'") > 0

# Generated at 2022-06-21 07:10:04.081041
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    _shell = ShellModule()
    _shell._debug = True

    _shell.connection = 'local'
    _shell.no_log = False
    _shell.prompt = '[$#] '

    try:
        _shell.chown('/tmp/foo', 'root')
    except Exception as e:
        assert e.message == 'chown is not implemented for Powershell'


# Generated at 2022-06-21 07:10:26.403719
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell_module = ShellModule()

# Generated at 2022-06-21 07:10:34.067234
# Unit test for constructor of class ShellModule
def test_ShellModule():
    a = ShellModule()
    assert a.SHELL_FAMILY == 'powershell'

    assert a.get_remote_filename('hell.ps1') == 'hell.ps1'
    assert a.get_remote_filename('hell.py') == 'hell.ps1'
    assert a.get_remote_filename('hell.bat') == 'hell.ps1'
    assert a.get_remote_filename('hell.sh') == 'hell.ps1'
    assert a.get_remote_filename('hell.pl') == 'hell.ps1'
    assert a.get_remote_filename('hell.rb') == 'hell.ps1'



# Generated at 2022-06-21 07:10:38.786748
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    test_obj = ShellModule()
    assert test_obj.chown(paths='', user='') == NotImplementedError('chown is not implemented for Powershell')


# Generated at 2022-06-21 07:10:44.137915
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    shell_module = ShellModule()
    assert shell_module.exists('/tmp/something') == b"If (Test-Path '/tmp/something')\r\n            {\r\n                $res = 0;\r\n            }\r\n            Else\r\n            {\r\n                $res = 1;\r\n            }\r\n            Write-Output '$res';\r\n            Exit $res;\r\n         "

# Generated at 2022-06-21 07:10:49.297788
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    import os
    import tempfile
    from ansible.module_utils._text import to_str

    class TestShellModule(ShellModule):
        def _encode_script(self, script, as_list=False, strict_mode=True, preserve_rc=True):
            return script

    module = TestShellModule()

    # test with pipelining bypass
    module.no_log = False
    cmd_result = module.wrap_for_exec('')
    assert cmd_result == '& ; exit $LASTEXITCODE'
    cmd_result = module.wrap_for_exec('   ')
    assert cmd_result == '& ; exit $LASTEXITCODE'


# Generated at 2022-06-21 07:10:57.741848
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    obj = ShellModule(None, '')
    test_cases = {
        r'C:\Windows\temp\test.ps1': r'test.ps1',
        r'C:\Windows\temp\test.bat': r'test.bat.ps1',
        r'\\path\to\file.exe': r'file.exe',
        r'\\path\to\file.vbs': r'file.vbs.ps1'
    }
    for test_input, expected in test_cases.items():
        assert obj.get_remote_filename(test_input) == expected


# Generated at 2022-06-21 07:11:03.587277
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    import pytest
    sm = ShellModule()

    from sys import platform
    if platform != "win32":
        pytest.skip("Test is windows-only")

    with pytest.raises(NotImplementedError):
        sm.set_user_facl('path', 'user', 'mode')

# Generated at 2022-06-21 07:11:13.628650
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    '''Test get_remote_filename()'''

    # Create dummy module
    module = create_ansible_module()

    # Get instance of ShellModule
    shell = ShellModule(conn=module, tmpdir='')

    # Test cases
    test_cases = [
        ('shell_output', 'shell_output.ps1'),
        ('shell_error', 'shell_error.ps1'),
        ('shell_output.ps1', 'shell_output.ps1'),
        ('shell_output.exe', 'shell_output.exe'),
        ('shell_output.py', 'shell_output.py.ps1')
    ]

    # Set remote_tmp
    shell.set_options({'remote_tmp': 'a/b/c'})

    for path, expected_result in test_cases:
        returned_result = shell

# Generated at 2022-06-21 07:11:23.670284
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    tests = [
        (None, u'ansible_%s.ps1' % ShellModule._generate_temp_dir_name()),
        (u'test.sh', u'test.ps1'),
        (u'C:\\test.sh', u'test.ps1'),
        (u'C:\\test.exe', u'test.exe')
    ]

    sm = ShellModule()

    for (fname, expected) in tests:
        actual = sm.get_remote_filename(fname)
        assert actual == expected, "%s expected %s, actual %s" % (fname, expected, actual)

# Generated at 2022-06-21 07:11:32.667558
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    test_object = ShellModule()
    assert test_object.get_remote_filename("/tmp/test.txt") == "test.txt"
    assert test_object.get_remote_filename("/tmp/test.ps1") == "test.ps1"
    assert test_object.get_remote_filename("/tmp/test.bat") == "test.bat.ps1"
    assert test_object.get_remote_filename("/tmp/test") == "test.ps1"

# Generated at 2022-06-21 07:11:41.083079
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule(connection=None)
    result = shell.env_prefix()
    assert result == ""

# Generated at 2022-06-21 07:11:45.452702
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    class ShellModuleTestClass(ShellModule):
        def __init__(self, *args, **kwargs):
            pass

    shellobj = ShellModuleTestClass()
    assert shellobj.env_prefix() == ''
    assert shellobj.env_prefix(FOO='BAR') == ''

# Generated at 2022-06-21 07:11:55.476406
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():

    shell_module = ShellModule()

    # test one argument
    assert shell_module.join_path('folder') == 'folder'

    # test multiple arguments with forward and backslash
    assert shell_module.join_path('folder', 'test\\test2') == 'folder\\test\\test2'
    assert shell_module.join_path('folder', '\\test\\test2') == 'folder\\test\\test2'

    # test multiple arguments with quotes
    assert shell_module.join_path('folder', '"test test2"') == 'folder\\test test2'
    assert shell_module.join_path('folder', '"test\\test2"') == 'folder\\test\\test2'

    # test multiple arguments with quotes and forward and backslash

# Generated at 2022-06-21 07:11:58.288317
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    # check that a NotImplementedError is raised
    shell = ShellModule(connection=None)
    try:
        shell.set_user_facl('folder', 'user', '755')
    except NotImplementedError:
        return
    assert False

# Generated at 2022-06-21 07:12:09.302784
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    """This function is here to allow us to test the set_user_facl method
    with pytest. It is not used if the module is loaded by Ansible as a
    real shell plugin.
    """

    # Create a mock module object
    class MockModule(object):
        def __init__(self, noop=False):
            self._noop = noop

        @property
        def noop(self):
            return self._noop

        @noop.setter
        def noop(self, val):
            self._noop = val

    module = MockModule()
    shell = ShellModule(None, load_options_json=False)

    # Fail to set a file's permissions for a nonexistent user
    path = 'C:\\Windows\\System32\\drivers\\etc\\hosts'
    user = 'nouser'

# Generated at 2022-06-21 07:12:13.505062
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils._text import to_bytes
    import ansible.plugins.shell.powershell
    ansible.plugins.shell.powershell.ShellModule.__bases__ = (object,)
    conn = Connection(shell=ansible.plugins.shell.powershell.ShellModule)
    assert "chown is not implemented for Powershell" in to_bytes(conn.chown("/usr/bin/hostname", "root"))


# Generated at 2022-06-21 07:12:19.009944
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.inventory.host import Host

    test_module = AnsibleModule(argument_spec={})
    test_host = Host(name='testhost')
    test_shell = ShellModule(connection='psrp', no_log=True, become_method='runas', become_user='username', become_password='password', module=test_module, host=test_host)

    assert test_shell.env_prefix() == ''

# Generated at 2022-06-21 07:12:22.967609
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == "powershell"
    assert shell._IS_WINDOWS == True


# Generated at 2022-06-21 07:12:25.305917
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    cd = ShellModule(None)
    assert cd.env_prefix(test='test') == ''


# Generated at 2022-06-21 07:12:32.037307
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell_module = ShellModule()
    try:
        shell_module.chown(paths=None, user=None)
    except NotImplementedError as err:
        assert "chown is not implemented for Powershell" == str(err)


# Generated at 2022-06-21 07:12:49.596584
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    shell_plugin = ShellModule(connection=None, shell_executable=None)

    #Confirm executable name ends with .exe
    executable_name = shell_plugin.get_remote_filename('test.exe')
    assert executable_name == 'test.exe'

    #Confirm script name ends with .ps1
    script_name = shell_plugin.get_remote_filename('test.ps1')
    assert script_name == 'test.ps1'

    #Confirm unknown filename ends with .ps1
    unknown_name = shell_plugin.get_remote_filename('test')
    assert unknown_name == 'test.ps1'

    #Confirm unknown filename ends with .ps1
    unknown_name_with_spaces = shell_plugin.get_remote_filename('test test')

# Generated at 2022-06-21 07:12:56.131624
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    import ansible.modules.windows.win_stat
    sm = ansible.modules.windows.win_stat.ShellModule()
    assert sm.get_remote_filename("/tmp/host_file.txt") == "host_file.txt"


# Generated at 2022-06-21 07:13:04.847600
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    m = ShellModule({})
    assert m.wrap_for_exec("") == "& ; exit $LASTEXITCODE"
    assert m.wrap_for_exec("simple") == "& simple; exit $LASTEXITCODE"
    assert m.wrap_for_exec("'s;s'") == "& 's;s'; exit $LASTEXITCODE"
    assert m.wrap_for_exec("\"s;s\"") == "& \"s;s\"; exit $LASTEXITCODE"
    assert m.wrap_for_exec("\"s 's' s\"") == "& \"s 's' s\"; exit $LASTEXITCODE"

# Generated at 2022-06-21 07:13:15.150165
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell = ShellModule()

    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS == True

    # ShellModule.env_prefix
    assert shell.env_prefix() == ''

    # ShellModule.join_path
    assert shell.join_path('/home/user', 'file.txt') == '/home/user/file.txt'
    assert shell.join_path('/home/user', '/file.txt') == '/file.txt'
    assert shell.join_path('/home/user', '\\file.txt') == '/file.txt'
    assert shell.join_path('/home/user/', 'file.txt') == '/home/user/file.txt'

# Generated at 2022-06-21 07:13:24.981713
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import io
    module_name = 'test_module'
    arg_path = 'test_path'
    shebang = None
    env_string = 'test env_string'
    cmd = 'test cmd'

    powershell_test_module = io.BytesIO(b'echo "sub test module"')
    powershell_test_module.name = module_name
    powershell_test_module.seek(0)

    powershell_test_module_arg = io.BytesIO(b'echo "sub test module"')
    powershell_test_module_arg.name = module_name + '.ps1'
    powershell_test_module_arg.seek(0)


# Generated at 2022-06-21 07:13:26.136120
# Unit test for constructor of class ShellModule
def test_ShellModule():
    # Just construct an instance; it has no public methods
    ShellModule()

# Generated at 2022-06-21 07:13:35.111132
# Unit test for method build_module_command of class ShellModule

# Generated at 2022-06-21 07:13:41.399142
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    test_cases = (
        # test_input, expected_output
        ('~\\test\\testfile.txt', "Write-Output ((Get-Location).Path + '\\test\\testfile.txt')"),
        ('~testfile.txt', "Write-Output ((Get-Location).Path + 'testfile.txt')"),
        ('testfile.txt', "Write-Output 'testfile.txt'")
    )
    shellmodule = ShellModule()

    for test_input, expected_output in test_cases:
        assert shellmodule.expand_user(test_input) == shellmodule._encode_script(expected_output)


# Generated at 2022-06-21 07:13:46.749546
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    def mock_ansible_module_fail_json(msg):
        print(msg)
        assert False, msg

    shell.ansible_module.fail_json = mock_ansible_module_fail_json
    shell.set_user_facl('path1', 'user1', 'mode1')

# Generated at 2022-06-21 07:13:55.964026
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    m = ShellModule()
    path = '/some/path'
    user = 'jeff'
    mode = 'rwx'
    try:
        m.set_user_facl(path, user, mode)
        raise Exception("Module should not allow set_user_facl")
    except NotImplementedError:
        pass  # Expected Exception


# Generated at 2022-06-21 07:14:16.295355
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    assert '& %s; exit $LASTEXITCODE' % 'foo' == ShellModule(None).wrap_for_exec('foo')

# Generated at 2022-06-21 07:14:17.928756
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    assert False, "Test if the method chown of class ShellModule works."


# Generated at 2022-06-21 07:14:30.619876
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    powershell_shell = ShellModule()
    assert not powershell_shell.path_has_trailing_slash('/var/tmp')
    # The trailing slash is stripped off the path before processing
    assert powershell_shell.path_has_trailing_slash('/var/tmp/')
    assert powershell_shell.path_has_trailing_slash('/var/tmp//')

    assert not powershell_shell.path_has_trailing_slash('C:\\Windows')
    assert powershell_shell.path_has_trailing_slash('C:\\Windows\\')
    assert powershell_shell.path_has_trailing_slash('C:\\Windows\\\\')

    assert not powershell_shell.path_has_trailing_slash('""')
    assert powershell_shell.path_has_

# Generated at 2022-06-21 07:14:43.054672
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    shell = ShellModule()
    test_file_path = shell._escape(shell._unquote("C:\\test.txt"))
    test_folder_path = shell._escape(shell._unquote("C:\\test"))

    script = '''
        If (Test-Path '{0}')
        {{
            $res = 0;
        }}
        Else
        {{
            $res = 1;
        }}
        Write-Output '$res';
        Exit $res;
        '''

    assert shell.exists("C:\\test.txt") == '& ' + shell._encode_script(script=script.format(test_file_path), preserve_rc=False)

# Generated at 2022-06-21 07:14:50.453200
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    a = ShellModule()
    assert a.exists('C:\\Windows') == b'If (Test-Path \'C:\\Windows\') { $res = 0; } Else { $res = 1; } Write-Output \'$res\'; Exit $res; '


# Generated at 2022-06-21 07:15:03.012232
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():

    #file = file(test_data_path + 'shell/powershell/test_ShellModule_remove.yml')

    obj = ShellModule()

    # File exists
    #path = 'test_data_path + shell/powershell/test_file_exists.txt'

    # Expected results: stdout is '0', stderr is '' and rc is 0
    test_data = {
        'path': r'C:\Windows\Temp\test_ShellModule_remove.txt',
        'recurse': False,
        'check_rc': False,
        'removes': True
    }

    # Call the method under test
    (rc, stdout, stderr) = obj.remove(**test_data)


# Generated at 2022-06-21 07:15:16.213082
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell_obj = ShellModule()

    # Test using shell_obj.join_path()
    assert 'C:\\Users\\me\\file.txt' == shell_obj.join_path('C:/Users/me', '\\file.txt')
    assert 'C:\\Users\\me\\file.txt' == shell_obj.join_path('C:/Users/me', '\\file.txt')
    assert 'C:\\Users\\me\\file.txt' == shell_obj.join_path('C:\\Users\\me\\', '\\file.txt')
    assert 'C:\\Users\\me\\file.txt' == shell_obj.join_path('C:\\Users\\me\\', 'file.txt')

    # Test using os.path.join()

# Generated at 2022-06-21 07:15:21.656380
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule({}, None)
    assert shell.join_path(b'c:\\', b'\\etc\\') == b'c:\\etc'
    assert shell.join_path(b'\\\\', b'\\etc\\') == b'\\\\etc'

# Generated at 2022-06-21 07:15:24.840946
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    shell = ShellModule()
    assert shell.chmod("C:\Windows", 1) == "Cannot change mode on Windows"


# Generated at 2022-06-21 07:15:31.019162
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule(connection=None, no_log=True)
    cmd = shell.wrap_for_exec('& "c:\\temp\\foo.ps1"')
    assert cmd == '& & "c:\\\\temp\\\\foo.ps1"; exit $LASTEXITCODE'

# Generated at 2022-06-21 07:15:51.512351
# Unit test for constructor of class ShellModule
def test_ShellModule():
    sm = ShellModule()
    assert sm.COMPATIBLE_SHELLS == frozenset()
    assert sm.SHELL_FAMILY == 'powershell'
    assert sm._IS_WINDOWS is True


# Generated at 2022-06-21 07:16:03.905883
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    sm = ShellModule()
    # Powershell modules must end with .ps1
    assert sm.get_remote_filename('test module') == 'test module.ps1'
    assert sm.get_remote_filename('test_module') == 'test_module.ps1'
    assert sm.get_remote_filename('test_module.exe') == 'test_module.exe'
    assert sm.get_remote_filename('c:\\folder\\test_module.exe') == 'test_module.exe'
    assert sm.get_remote_filename('/folder/test_module.exe') == 'test_module.exe'
    assert sm.get_remote_filename('  test module.exe  ') == 'test module.exe'

# Generated at 2022-06-21 07:16:17.604954
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    shell_module = ShellModule()
    # Test if the method join_path succeeds to concatenate the paths passed as parameters
    assert shell_module.exists('C:/code/ansible/test') == shell_module._encode_script("""if(Test-Path C:/code/ansible/test)
    {
        $res = 0
    }
    else
    {
        $res = 1
    }
    Write-Output '$res'
    Exit $res""")
    # Test the behavior when no path is passed
    assert shell_module.exists('') == shell_module._encode_script("""if(Test-Path '')
    {
        $res = 0
    }
    else
    {
        $res = 1
    }
    Write-Output '$res'
    Exit $res""")

# Generated at 2022-06-21 07:16:24.938182
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    """
    This is a unit test to exercise method chmod of class ShellModule.
    """
    shell_module = ShellModule()

    # Test that method chmod not implemented
    with pytest.raises(NotImplementedError):
        shell_module.chmod("path", "mode")


# Generated at 2022-06-21 07:16:28.204570
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule()
    assert shell.env_prefix() == ""


# Generated at 2022-06-21 07:16:39.964449
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    from ansible.module_utils.facts.system.windows.powershell import ShellModule
    powershell = ShellModule()
    path = "c:\\Users\\myuser\\Documents\\ansible"
    path2 = "c:/Users/myuser/Documents/ansible"
    assert powershell.join_path(path) == path
    assert powershell.join_path(path2) == path
    assert powershell.join_path(path2, 'test') == path + '\\test'
    assert powershell.join_path(path, 'test', 'test2') == path + '\\test\\test2'
    assert powershell.join_path(path, 'test', 'test2\\') == path + '\\test\\test2'

# Generated at 2022-06-21 07:16:50.793914
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    sm = ShellModule(None)

    # Test non-pipelining
    result = sm.build_module_command('', '#!/usr/bin/python', '/user/bin/foo', '/usr/local/ansible')

    assert result.endswith('; exit $LASTEXITCODE')

    bootstrap_cmd = result.split(';')[0]

    assert bootstrap_cmd.startswith('powershell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand')
    assert bootstrap_cmd.endswith("'")


# Generated at 2022-06-21 07:16:59.907051
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    assert 'C:\\path\\to\\file' == ShellModule().join_path('C:\\', '\\path\\', '/to/', '\\', 'file')
    assert 'C:\\path\\to\\file' == ShellModule().join_path('C:/path/', './to/', 'file')
    assert 'C:\\path\\to\\file' == ShellModule().join_path('C:\\', '\\path\\', '/to/', '\\', '\\file\\')
    assert '\\\\host\\share\\file' == ShellModule().join_path('\\\\host\\share\\', 'file')
    assert '\\\\host\\share\\file' == ShellModule().join_path('\\\\host\\share', '\\file')
    assert '\\\\host\\share\\file' == ShellModule().join_path('\\\\host/share', '/file')


# Generated at 2022-06-21 07:17:12.691872
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    sheller = ShellModule(None, None)
    tmpdir = sheller.mkdtemp("shelltest", tmpdir="/tmp")
    assert tmpdir.startswith("powershell.exe -NonInteractive -NoProfile -ExecutionPolicy Unrestricted -EncodedCommand UwB0AGUAbABsAFMAdAByAGUAZAAgAEkATwAuAFcAZQBiAEMAbABpAGUAbgB0AC4ATwBwAGUAbgB0AA==")

    # The tmpdir should be created in /tmp
    tmpdir = sheller.mkdtemp("shelltest", tmpdir="/tmp/")

# Generated at 2022-06-21 07:17:24.197301
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    sm = ShellModule()
    encoded = sm.build_module_command(None, None, 'test.exe arg1 arg2 arg3')
    assert encoded == '& test.exe arg1 arg2 arg3; exit $LASTEXITCODE'
    encoded = sm.build_module_command(None, '#!/bin/python', 'test.py arg1 arg2 arg3')
    assert encoded == '& /bin/python test.py arg1 arg2 arg3; exit $LASTEXITCODE'

    encoded = sm.build_module_command(None, None, 'test.exe arg1 "arg2 arg3" "arg4"')
    assert encoded == '& test.exe arg1 "arg2 arg3" "arg4"; exit $LASTEXITCODE'


# Generated at 2022-06-21 07:17:55.285288
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    powershell = ShellModule(connection=None)
    assert powershell.join_path('c:/foo', 'bar/baz') == 'c:\\foo\\bar\\baz'
    assert powershell.join_path('c:/foo/', 'bar/baz') == 'c:\\foo\\bar\\baz'
    assert powershell.join_path('c:/foo', '/bar/baz') == 'c:\\foo\\bar\\baz'
    assert powershell.join_path('c:/foo/', '/bar/baz') == 'c:\\foo\\bar\\baz'
    assert powershell.join_path('C:/foo/', '\\bar/baz') == 'c:\\foo\\bar\\baz'
    # Test long paths
    long_path = "longpath" * 50 + "long"
   

# Generated at 2022-06-21 07:18:04.554841
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    # new_stdin used to mock stdin
    new_stdin = '~\\test'
    shell = ShellModule(connection=None, new_stdin=new_stdin)
    home = shell.get_option('remote_tmp')
    cmd = shell.expand_user(new_stdin)
    cmd = shell._unquote(cmd)

    # cmd will be something like C:\Users\\test or \\\\windows\\temp\\test
    assert cmd.startswith((home, '\\\\'))

    # Windows does not have an equivalent for the system temp files,
    # so home should always be the result.
    new_stdin = '~'
    cmd = shell.expand_user(new_stdin)
    cmd = shell._unquote(cmd)

# Generated at 2022-06-21 07:18:09.537297
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    module = ShellModule()
    assert_raises(NotImplementedError, module.chmod, "path", 0o600)


# Generated at 2022-06-21 07:18:16.683268
# Unit test for method get_remote_filename of class ShellModule
def test_ShellModule_get_remote_filename():
    from ansible.executor.powershell.powershell import ShellModule
    # TODO: fix
    # assert shell.get_remote_filename(pathname) == 'test.ps1'
    # assert shell.get_remote_filename(pathname) == 'test.exe'
    pass



# Generated at 2022-06-21 07:18:20.225680
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    plugin = ShellModule()
    test_path = '/tmp/test_file'
    test_user = 'test_user'
    test_mode = '0640'
    assert plugin.set_user_facl(test_path, test_user, test_mode)



# Generated at 2022-06-21 07:18:22.266374
# Unit test for constructor of class ShellModule
def test_ShellModule():
  assert ShellModule()

# Generated at 2022-06-21 07:18:27.157855
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    module = ShellModule()
    file_ = "File"
    dir_ = "Directory"
    ext_ = "File.ext"
    module.checksum(file_)
    module.checksum(dir_)
    module.checksum(ext_)

# Generated at 2022-06-21 07:18:29.885070
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    test = ShellModule()
    assert test.exists(path='/tmp') == ''
    # should return ''


# Generated at 2022-06-21 07:18:38.898697
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    # Set up the class object
    shell = ShellModule()
    # Test that correct exception is raised
    try:
        shell.set_user_facl("/path/to/file", "user", "0755")
    except NotImplementedError as e:
        assert "set_user_facl is not implemented for Powershell" in str(e)


# Generated at 2022-06-21 07:18:43.673130
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    '''Check the return value of ShellModule.wrap_for_exec(cmd)'''
    cmd = '& echo hello ; exit $LASTEXITCODE'
    expected = '''& if ($?) { $global:AnsibleInvocationStatus = $LASTEXITCODE }; { echo hello ; exit $LASTEXITCODE }; if ($?) { exit $global:AnsibleInvocationStatus }'''
    shell = ShellModule()
    assert shell.wrap_for_exec(cmd) == expected
