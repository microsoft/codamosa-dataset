

# Generated at 2022-06-21 07:08:58.900145
# Unit test for constructor of class ShellModule
def test_ShellModule():
    shell_plugins = []

    shell = ShellModule(connection=None, shell_type='powershell', no_log=False)
    # TODO: Make this work for Python 2 as well
    # assert_equal(shell.__class__.__name__, 'ShellModule')
    assert isinstance(shell, ShellModule)
    assert shell.COMPATIBLE_SHELLS == frozenset()
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell._IS_WINDOWS is True


# Generated at 2022-06-21 07:09:10.416248
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell = ShellModule()

    # Test recurse=False, path contains spaces
    path = 'C:\\Program Files (x86)\\test'
    expected_output = "Remove-Item 'C:\\Program Files (x86)\\test' -Force;"
    assert shell.remove(path) == shell._encode_script(expected_output)

    # Test recurse=True, path contains spaces
    path = 'C:\\Program Files (x86)\\test'
    expected_output = "Remove-Item 'C:\\Program Files (x86)\\test' -Force -Recurse;"
    assert shell.remove(path, recurse=True) == shell._encode_script(expected_output)

    # Test recurse=False, path is single quoted
    path = "'C:\\Program Files (x86)\\test'"
    expected

# Generated at 2022-06-21 07:09:15.615596
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    # Basic path joining
    assert(ShellModule().join_path("foo", "bar") == "foo\\bar")
    assert(ShellModule().join_path("foo\\", "bar") == "foo\\bar")
    assert(ShellModule().join_path("foo/", "bar") == "foo\\bar")
    assert(ShellModule().join_path("foo", "\\bar") == "foo\\bar")
    assert(ShellModule().join_path("foo", "/bar") == "foo\\bar")

    # Relative paths, no drive letter
    assert(ShellModule().join_path("", "bar") == "bar")
    assert(ShellModule().join_path("..", "bar") == "..\\bar")
    assert(ShellModule().join_path("..\\", "bar") == "..\\bar")

# Generated at 2022-06-21 07:09:23.214830
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    tscript = 'Write-Host "Hello World"'
    result = '& %s; exit $LASTEXITCODE' % ShellModule._encode_script(tscript)

# Generated at 2022-06-21 07:09:31.118244
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell_module = ShellModule()
    pathname = shell_module.mkdtemp()
    pathname = to_text(pathname)
    pathname = pathname[2:]  # remove 'powershell -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command ' from the beginning
    pathname = pathname[:-1]  # remove trailing ' from the end
    pathname = pathname.replace('"', '')  # remove " from the string
    assert 'Write-Output' in pathname  # the string contains Write-Output
    assert '$res' not in pathname  # the string does not contain $res, since we're not in an error scenario

# Generated at 2022-06-21 07:09:34.906366
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    shell = ShellModule(connection=None, shell_executable=None, become_method=None)
    assert shell.chown('path','user') == NotImplementedError('chown is not implemented for Powershell')


# Generated at 2022-06-21 07:09:44.374980
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.executor.powershell as powershell_module

    def get_shell_module_mock(self):
        return powershell_module

    import ansible.plugins.shell.powershell as powershell
    powershell_orig = powershell.ShellModule
    powershell.ShellModule = get_shell_module_mock


# Generated at 2022-06-21 07:09:53.955151
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    # Tests to make sure that the join_path method converts slashes to backslashes
    powershell = ShellModule()


# Generated at 2022-06-21 07:09:58.063908
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    module = ShellModule()
    paths = '/tmp/somepath'
    user = 'someuser'
    mode = 'somemode'
    result = module.set_user_facl(paths, user, mode)
    assert result is None

# Generated at 2022-06-21 07:10:11.499117
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shebang = '#!Powershell'
    script = u'my_script.ps1'
    other_arg = u'--this_is_an=arg'

# Generated at 2022-06-21 07:10:24.751434
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell = ShellModule()

    assert shell.remove(path="'D:\\Temp Dir\\File.txt'", recurse=True) == shell._encode_script('''Remove-Item 'D:\\Temp Dir\\File.txt' -Force -Recurse;''')
    assert shell.remove(path="'D:\\Temp Dir\\File.txt'", recurse=False) == shell._encode_script('''Remove-Item 'D:\\Temp Dir\\File.txt' -Force;''')

# Generated at 2022-06-21 07:10:26.654211
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    module = ShellModule()
    assert module.wrap_for_exec('echo 1') == '& echo 1; exit $LASTEXITCODE'


# Generated at 2022-06-21 07:10:37.101771
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()

    assert shell.path_has_trailing_slash('test\\test')

    assert shell.path_has_trailing_slash('test/test')

    assert shell.path_has_trailing_slash('test/test/')

    assert shell.path_has_trailing_slash('test\\test\\')

    assert not shell.path_has_trailing_slash('test\\test\\test')

    assert not shell.path_has_trailing_slash('test/test/test')

# Generated at 2022-06-21 07:10:45.961247
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    powershell_shell = ShellModule()

    # Windows paths contain either forward or back slashes, or a combination

# Generated at 2022-06-21 07:10:48.733680
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    x = ShellModule()

    assert x.chown("test", "foo") == x.join_path("test")

# Generated at 2022-06-21 07:10:57.416681
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    # import module snippets
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule
    # initialize needed objects
    connection = ShellModule(
        run_command=lambda cmd, tmp_path, sudo_user: None,
        _is_pipelining_enabled=lambda: False,
    )
    # execute the function under test
    result = connection.wrap_for_exec('pwsh -c "\'Test\'"')
    # check results
    assert result == '& pwsh -c "\'Test\'"; exit $LASTEXITCODE', result

# Generated at 2022-06-21 07:11:03.611870
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    assert shell.mkdtmp().endswith('.ps1')
    assert shell.mkdtmp().startswith('$tmp = New-Item -Type Directory -Path')
    assert shell.mkdtmp().find('-Name') > 0
    assert shell.mkdtmp().find('|') < 0

# Generated at 2022-06-21 07:11:05.410912
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell_module = ShellModule()
    assert shell_module.wrap_for_exec("test") == "& test; exit $LASTEXITCODE"

# Generated at 2022-06-21 07:11:17.598765
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    """Test method wrap_for_exec of class ShellModule"""

    shell_module = ShellModule()

    # Test method with a command which ends with an exit clause
    command = '& C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -ExecutionPolicy Unrestricted -Command \"-NoLogo -Sta -NoProfile -NonInteractive'
    result = shell_module.wrap_for_exec(command)
    assert result == command + '; exit $LASTEXITCODE'

    # Test method with a command which does not end with an exit clause
    command = '& C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -ExecutionPolicy Unrestricted -Command \"-NoLogo -Sta -NoProfile -NonInteractive'
    result = shell_module.wrap_

# Generated at 2022-06-21 07:11:19.747865
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    assert ShellModule.chmod.__doc__ is not None



# Generated at 2022-06-21 07:11:35.636340
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    ''' Ensure that ShellModule returns True for paths that end with backslashes '''

    # Execute one test for each of the path separators Windows accepts
    for s in ['\\', '/']:
        # Initialize a ShellModule object
        sm = ShellModule(connection=None, add_ext_args=None, run_in_check_mode=False, no_log=False,
                         conditional=False, always_pipeline=False, become_method=None, become_user=None)

        # Test two invalid paths
        assert not sm.path_has_trailing_slash(s + 'SomeName' + s)
        assert not sm.path_has_trailing_slash(s + 'SomeName')

        # Test two valid paths
        assert sm.path_has_trailing_slash(s + s)

# Generated at 2022-06-21 07:11:45.397256
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    mock_ansible_module = unittest.mock.Mock()
    mock_ansible_module.params = unittest.mock.Mock()
    mock_ansible_module.params.get.side_effect = ['value_from_params']
    mock_ansible_module.fail_json.side_effect = Exception('fail_json_method called')
    mock_ansible_module.check_mode = False
    mock_ansible_module._diff = False
    mock_ansible_module.no_log = False
    mock_ansible_module.async_val = 5
    mock_ansible_module.debug = False

    mock_ansible_module._debug = True

    shell_module = ShellModule(mock_ansible_module)


# Generated at 2022-06-21 07:11:55.439829
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    shell = ShellModule()
    test_path = pkgutil.get_data("ansible.executor.powershell", "test_path.ps1")
    script = '[System.IO.Path]::GetFullPath(%s)' % shell.mkdtemp()
    cmd = shell._encode_script(script)
    test_path = to_bytes(test_path)
    cmd = test_path + b' | ' + cmd
    returned_stdout, _, _ = shell._connection.exec_command(cmd)
    output = to_text(returned_stdout.read(), errors='surrogate_or_strict')
    assert output.strip()
    shell.remove(output.strip())

# Generated at 2022-06-21 07:11:57.918823
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    obj = ShellModule()
    assert obj.set_user_facl('test', 'test', 'test') == NotImplementedError('set_user_facl is not implemented for Powershell')

# Generated at 2022-06-21 07:12:04.909351
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.shell.powershell import ShellModule

    SM = ShellModule()

    assert SM.env_prefix() == ""
    assert isinstance(SM.env_prefix(test_var=123), AnsibleUnsafeText)
    assert SM.env_prefix(test_var=123) == ""

    assert SM.env_prefix(test_var="test_var") == ""
    assert SM.env_prefix(test_var="test_var", test_var2="test_var2") == ""

# Generated at 2022-06-21 07:12:08.126854
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    sm = ShellModule()
    assert sm.env_prefix() == ''


# Generated at 2022-06-21 07:12:18.970432
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # create a mock connection and a mock shell.
    c = Connection(None)
    c._shell = ShellModule(c._connection)

    # Test for trailing slash
    assert (c._shell.path_has_trailing_slash(u'C:/test/') == True)

    # Test for no trailing slash
    assert (c._shell.path_has_trailing_slash(u'C:/test') == False)

    # Test for trailing slash
    assert (c._shell.path_has_trailing_slash(u'C:/test\\') == True)

    # Test for no trailing slash
    assert (c._shell.path_has_trailing_slash(u'C:/test\\') == True)

    # Test for trailing slash

# Generated at 2022-06-21 07:12:24.754187
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    # The expected result is cmd with &, <space>, and ; appended
    cmd = 'powershell.exe -Executionpolicy Unrestricted -EncodedCommand PGh0bWw+PC9odG1sPg=='
    expected_result = '& powershell.exe -Executionpolicy Unrestricted -EncodedCommand PGh0bWw+PC9odG1sPg==; exit $LASTEXITCODE'
    shell = ShellModule()
    result = shell.wrap_for_exec(cmd)
    assert result == expected_result

# Generated at 2022-06-21 07:12:37.212192
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # create an instance of class ShellModule
    shell = ShellModule()

    assert shell.path_has_trailing_slash(path='/tmp/file') is False
    assert shell.path_has_trailing_slash(path='\\tmp\\file') is False
    assert shell.path_has_trailing_slash(path='/tmp/file/') is True
    assert shell.path_has_trailing_slash(path='\\tmp\\file\\') is True
    assert shell.path_has_trailing_slash(path='/tmp\\file/') is True
    assert shell.path_has_trailing_slash(path='\\tmp\\file/') is True

# Generated at 2022-06-21 07:12:43.630797
# Unit test for method chown of class ShellModule
def test_ShellModule_chown():
    import pytest
    from ansible.plugins.shell import ShellModule

    shell_plugin = ShellModule()

    with pytest.raises(NotImplementedError):
        shell_plugin.chown('testfile', 'testuser')


# Generated at 2022-06-21 07:13:04.679981
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()
    assert shell.path_has_trailing_slash(path="\\a\\b\\")
    assert shell.path_has_trailing_slash(path="c:\\abc\\def\\")
    assert shell.path_has_trailing_slash(path="c:\\")
    assert shell.path_has_trailing_slash(path="\\\\remote\\share\\dir")
    assert shell.path_has_trailing_slash(path="\\\\remote\\share")
    assert shell.path_has_trailing_slash(path="\\\\remote\\")
    assert shell.path_has_trailing_slash(path="\\\\")

    assert not shell.path_has_trailing_slash(path="\\a\\b")
    assert not shell.path_has_trailing_slash

# Generated at 2022-06-21 07:13:12.957987
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    shell_mock = ShellModule()
    script_recurse = shell_mock.remove('/test/file', recurse=True)
    script_no_recurse = shell_mock.remove('/test/file', recurse=False)

    assert script_recurse == u'Remove-Item \'/test/file\' -Force -Recurse;'
    assert script_no_recurse == u'Remove-Item \'/test/file\' -Force;'



# Generated at 2022-06-21 07:13:23.898208
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()
    mock_remote_path = "C:\\Users\\Mockusername\\Ansible"
    cmd = shell.expand_user('~', 'mockusername')
    assert cmd == "''"+mock_remote_path+"'"
    cmd = shell.expand_user('~testuser')
    assert cmd == "''"+mock_remote_path+"'"
    cmd = shell.expand_user('~\\testuser')
    assert cmd == "''"+mock_remote_path+"\\testuser'"
    cmd = shell.expand_user('~testuser\\.ssh\\test')
    assert cmd == "''"+mock_remote_path+"\\.ssh\\test'"
    cmd = shell.expand_user('~\\.ssh')

# Generated at 2022-06-21 07:13:33.461133
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    from ansible.module_utils.powershell import ShellModule
    shell_module = ShellModule()

    def assert_checksum(path, expected_result, fail_message=None):
        result = shell_module.checksum(path)
        assert result == expected_result, fail_message or 'Expected %s for checksum of %s, got %s' % (expected_result, path, result)

    # File checksums
    assert_checksum(
        path=u'C:\\windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe',
        expected_result=u'9071bd19c7d9a6b8a6b126e631b21d0b41463c98')

# Generated at 2022-06-21 07:13:41.427027
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    # Test method exists of class ShellModule
    script = '''
        If (Test-Path '%s')
        {
            $res = 0;
        }
        Else
        {
            $res = 1;
        }
        Write-Output '$res';
        Exit $res;
     ''' % 'c:\\test'
    script = script.strip()
    test_shellModule = ShellModule()
    test_shellModule._encode_script(script)

    # Test that the value of path is escaped
    script = '''
        If (Test-Path '%s')
        {
            $res = 0;
        }
        Else
        {
            $res = 1;
        }
        Write-Output '$res';
        Exit $res;
     ''' % 'c:\\tes t'
   

# Generated at 2022-06-21 07:13:51.065739
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    s = ShellModule()
    print(s.expand_user(to_bytes('~'), username='foo'))
    print(s.expand_user(to_bytes('~/test'), username='foo'))
    print(s.expand_user(to_bytes('~\\test'), username='foo'))
    print(s.expand_user(to_bytes('test'), username='foo'))


# Generated at 2022-06-21 07:14:00.732440
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    shell = ShellModule()
    script = '$foo = 1; Write-Output "bar";'
    result = shell.build_module_command(env_string='', shebang='', cmd=script, arg_path='')

    bootstrap_wrapper = pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1")
    result_parts = shlex.split(result, posix=False)
    cmd_parts = shlex.split('type ' + result_parts[2] + ' | ' + bootstrap_wrapper, posix=False)
    cmd_parts = list(map(to_text, cmd_parts))

    assert cmd_parts[0] == 'PowerShell'
    assert cmd_parts[1] == '-NoProfile'

# Generated at 2022-06-21 07:14:10.189012
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    # method tested is part of class ShellModule and is executed via the connection
    # pylint: disable=protected-access
    shell = ShellModule()
    shell.wrap_for_exec(shell._escape(r"""c:\Users\user\My Document with spaces\test.ps1 'C:\Users\user\My Document with spaces' """)  )
    shell.wrap_for_exec(shell._escape(r"""C:\Users\user\My Document with spaces\test.ps1 "C:\Program Files\WindowsPowerShell\Modules" """)  )
    shell.wrap_for_exec(shell._escape(r"""C:\Program Files\WindowsPowerShell\Modules\test.ps1 'C:\Users\user\My Document with spaces' """) )

# Generated at 2022-06-21 07:14:21.913013
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import os

    filename = 'test_shellmodule_build_module_command.ps1'
    filepath = os.path.abspath(__file__)
    test_dir = os.path.dirname(filepath)

    module_name = 'test_module'
    module_arg_path = os.path.join(test_dir, module_name)

    # Define the test cases we want to run.
    # Each test case should be a dictionary with the following keys:
    #   descr - A human readable description of the test case.
    #   shebang - The shebang to be used with the test case.
    #   cmd - The command line to be used with the test case.
    #   expected - The expected result of the test case.

# Generated at 2022-06-21 07:14:24.460356
# Unit test for method chmod of class ShellModule
def test_ShellModule_chmod():
    s = ShellModule()

# Generated at 2022-06-21 07:14:36.911338
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    sm = ShellModule()
    try:
        sm.set_user_facl("path", "user", "mode")
    except NotImplementedError as e:
        assert True

# Generated at 2022-06-21 07:14:47.468498
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule(None)


# Generated at 2022-06-21 07:14:55.781610
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    shell = ShellModule()

    # Run method
    ret = shell.expand_user(u'~/foo')

    # Validate method
    assert to_text(ret) == '''
        $res = "";
        Write-Output '$res';
        Exit $res;
        '''.strip()

    # Run method
    ret = shell.expand_user(u'~\\foo')

    # Validate method
    assert to_text(ret) == '''
        $res = "";
        Write-Output '$res';
        Exit $res;
        '''.strip()

    # Run method
    ret = shell.expand_user(u'~/')

    # Validate method

# Generated at 2022-06-21 07:15:04.704693
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    from ansible.module_utils.six import StringIO
    cm = ShellModule(connect=None)
    path = "C:\\temp\\test\\test.txt"
    assert cm.remove(path) == u"Remove-Item 'C:\\temp\\test\\test.txt' -Force;"
    assert cm.remove(shlex.quote(path)) == u"Remove-Item 'C:\\temp\\test\\test.txt' -Force;"
    assert cm.remove(path, recurse=True) == u"Remove-Item 'C:\\temp\\test\\test.txt' -Force -Recurse;"
    assert cm.remove(path, True) == u"Remove-Item 'C:\\temp\\test\\test.txt' -Force -Recurse;"

# Generated at 2022-06-21 07:15:16.926112
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    def test(test_case, expected_out):
        obj = ShellModule()
        res = obj.join_path(*test_case)
        assert res == expected_out


# Generated at 2022-06-21 07:15:25.508035
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    module = ShellModule()
    cmd = "foo bar"
    result = module.wrap_for_exec(cmd)
    expected = '& foo bar; exit $LASTEXITCODE'
    assert result == expected
    # test for command with embedded single quote
    cmd = "foo 'bar'"
    expected = "& foo ''bar'' ; exit $LASTEXITCODE"
    result = module.wrap_for_exec(cmd)
    assert result == expected
    # test for command with embedded double quote
    cmd = 'foo "bar"'
    expected = "& foo \"bar\" ; exit $LASTEXITCODE"
    result = module.wrap_for_exec(cmd)
    assert result == expected

# Generated at 2022-06-21 07:15:37.062239
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    # Test 1 - path is relative filename
    # Create new instance of ShellModule
    sm = ShellModule()
    print("Starting test 1")
    print("Testing if ShellModule.path_has_trailing_slash works correctly when path is a relative filename")
    # Get value of path_has_trailing_slash for a path that is a relative filename
    path_has_trailing_slash1 = sm.path_has_trailing_slash(path="samplefile.txt")
    # Assert the above value is false
    assert (path_has_trailing_slash1 == False)

    # Test 2 - path is absolute filename
    print("Starting test 2")
    print("Testing if ShellModule.path_has_trailing_slash works correctly when path is an absolute filename")
    # Get value of path_has_trailing

# Generated at 2022-06-21 07:15:38.761445
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    sh = ShellModule()
    cmd = sh.exists("$env:TEST_VAR")
    assert cmd == "$res=0;Write-Output '$res';Exit $res;"

# Generated at 2022-06-21 07:15:41.497111
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    shell.set_user_facl(paths='test', user='test', mode='test')

# Generated at 2022-06-21 07:15:47.806259
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    import pytest

    # Path parts to join
    path_parts = [
        'C:\\foo',
        '\\bar',
        '..\\baz',
        'C:\\qux\\quux'
    ]
    # Expected result
    expected = 'C:\\foo\\baz\\qux\\quux'

    # Create the object
    shell = ShellModule()

    # Join the path
    path = shell.join_path(*path_parts)

    # Check the result
    assert path == expected


# Generated at 2022-06-21 07:16:09.433871
# Unit test for method exists of class ShellModule
def test_ShellModule_exists():
    powershell_shell = ShellModule(None)
    script = powershell_shell.exists("""'C:\\Users\\Administrator\\AppData\\Local\\Temp\\ansible-tmp-88lIoWKO\\8'""")
    assert script == b'If (Test-Path \'C:\\Users\\Administrator\\AppData\\Local\\Temp\\ansible-tmp-88lIoWKO\\8\')\r\n            {\r\n                $res = 0;\r\n            }\r\n            Else\r\n            {\r\n                $res = 1;\r\n            }\r\n            Write-Output \'$res\';\r\n            Exit $res;\r\n         '


# Generated at 2022-06-21 07:16:16.583941
# Unit test for method remove of class ShellModule
def test_ShellModule_remove():
    # Create an instance of class ShellModule
    shell = ShellModule()

    # test remove with recurse = True
    result = shell.remove('/path', True)
    assert result == b"Remove-Item (\"'/path'\" -Force -Recurse);"

    # test remove with recurse = False
    result = shell.remove('/path', False)
    assert result == b"Remove-Item (\"'/path'\" -Force);"


# Generated at 2022-06-21 07:16:27.900477
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():
    from ansible.executor.powershell.test.test_module_utils import TestShellModule
    checksum = TestShellModule.checksum
    run = checksum('fake_path', 'sha1')
    assert run == '''SHA1 fake_path'''
    run = checksum('fake_path', 'md5')
    assert run == '''MD5 fake_path'''
    run = checksum('fake_path', 'sha256')
    assert run == '''Get-FileHash -Algorithm SHA256 -Path 'fake_path' | Select-Object -ExpandProperty Hash'''
    run = checksum('fake_path', 'sha512')
    assert run == '''Get-FileHash -Algorithm SHA512 -Path 'fake_path' | Select-Object -ExpandProperty Hash'''



# Generated at 2022-06-21 07:16:39.812620
# Unit test for method join_path of class ShellModule
def test_ShellModule_join_path():
    shell = ShellModule(con=None, tmpdir='', **{'no_log': True})

# Generated at 2022-06-21 07:16:41.344331
# Unit test for method env_prefix of class ShellModule
def test_ShellModule_env_prefix():
    shell = ShellModule()
    assert shell.env_prefix() == ''

# Generated at 2022-06-21 07:16:44.314493
# Unit test for method set_user_facl of class ShellModule
def test_ShellModule_set_user_facl():
    shell = ShellModule()
    assert shell.set_user_facl('/tmp/test', 'bob', 'rw') is None


# Generated at 2022-06-21 07:16:50.712524
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    '''Test for cases where expand_user() returns the right result. '''
    import pdb

    shell_module = ShellModule()

    # Test 1: User specifies ~
    user_home_path = '~'
    username = ''
    assert shell_module.expand_user(user_home_path, username) == ''.encode('utf-16-le')

    # Test 2: User specifies ~<username>
    user_home_path = '~<username>'
    username = ''
    assert shell_module.expand_user(user_home_path, username) == user_home_path.encode('utf-16-le')

    # Test 3: User specifies ~\<username>
    user_home_path = '~\\<username>'
    username = ''
    assert shell_module.expand_user

# Generated at 2022-06-21 07:16:54.888756
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    shell = ShellModule()
    assert shell.wrap_for_exec('cd "C:\\Program Files\\Microsoft\\VS Code"\necho a b c') == '& cd "C:\\Program Files\\Microsoft\\VS Code"; echo a b c; exit $LASTEXITCODE'



# Generated at 2022-06-21 07:17:04.151964
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    def _assert_equal(result, expected_result=None, expected_msg=None):
        if expected_result is not None:
            assert result == expected_result, expected_msg
        else:
            assert result is not None
            assert isinstance(result, bytes)

    module_mock = ShellModule(connection='winrm')
    result = module_mock.build_module_command(
        env_string='',
        shebang='#!powershell',
        cmd='echo hello',
        arg_path='C:\\Test.ps1'
    )

    _assert_equal(result, expected_msg='#!powershell does not work as expected.')


# Generated at 2022-06-21 07:17:17.537917
# Unit test for method expand_user of class ShellModule
def test_ShellModule_expand_user():
    """
    Unit test for method expand_user of class ShellModule
    """
    shell = ShellModule()

    for user_home_path, expected_value in (
        (u'', u'(Get-Location).Path'),
        (u'~', u'(Get-Location).Path'),
        (u'~\\', u'((Get-Location).Path + \'\\\\\')'),
        # user_home_path containing '~\' will be treated as a string literal
        (u'~\\foo', u'\'~\\\\foo\''),
        (u'~\\foo\\bar', u'\'~\\\\foo\\\\bar\''),
    ):
        assert expected_value + '\r\n' == shell.expand_user(user_home_path=user_home_path)

# Generated at 2022-06-21 07:17:39.209302
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    for i in range(50):
        s = ShellModule()
        basetemp = 'C:/windows/temp'
        basefile = 'ansible-tmp-%s-%s' % (s.get_option('remote_user'), ''.join([random.choice(string.ascii_letters) for _ in range(8)]))
        cmd = s.mkdtemp(basefile, system=False, mode=None, tmpdir=basetemp)
        assert len(cmd) > 0
        assert '\\' not in cmd

# Generated at 2022-06-21 07:17:52.247302
# Unit test for method checksum of class ShellModule
def test_ShellModule_checksum():

    # Create the object
    obj = ShellModule()

    # Successfully checksum of the file

# Generated at 2022-06-21 07:18:04.012600
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    """
    :return:
    """
    test = ShellModule()
    # test null cmd
    cmd = ''
    assert test.build_module_command("", "#!", cmd) == test._encode_script(script=pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"))

    # test #!powershell
    cmd = 'Testscript.ps1'
    assert test.build_module_command("", "#!powershell", cmd) == 'type "Testscript.ps1" | ' + test._encode_script(script=pkgutil.get_data("ansible.executor.powershell", "bootstrap_wrapper.ps1"))

    # test empty shebang
    cmd = 'Testscript.exe'
    assert test.build_module_command("", "", cmd) == test

# Generated at 2022-06-21 07:18:11.876511
# Unit test for method wrap_for_exec of class ShellModule
def test_ShellModule_wrap_for_exec():
    path = ntpath.join('C:', 'foo', 'bar')

    # Test parsing of quotes and escaping of single quotes.

# Generated at 2022-06-21 07:18:23.291897
# Unit test for method mkdtemp of class ShellModule
def test_ShellModule_mkdtemp():
    class MockModule(object): pass

    shell = ShellModule(MockModule)

    tmpdir = 'C:\Windows\Temp'
    basetmpdir = 'C:\Windows\TEMP'
    basefile = 'ansible-command'

    shell.get_option = Mock(return_value=tmpdir)
    assert tmpdir in shell.mkdtemp(basefile=basefile, tmpdir=basetmpdir)
    assert basefile in shell.mkdtemp(basefile=basefile, tmpdir=basetmpdir)
    assert tmpdir not in shell.mkdtemp(basefile=basefile, tmpdir=basetmpdir)
    assert tmpdir not in shell.mkdtemp(basefile=basefile, tmpdir=basetmpdir)
    assert tmpdir not in shell.mkdtemp()

# Generated at 2022-06-21 07:18:29.111209
# Unit test for method build_module_command of class ShellModule
def test_ShellModule_build_module_command():
    import ansible.plugins.shell as shell_plugins
    ansible_vars = dict(
        ansible_powershell_shell=dict(
            env={"foo": "bar"},
        ),
    )

    shebang = "#!someprogram"
    cmd = "some_command with \"quoted string\" and 'other quoted string'"
    expected = '''& someprogram some_command with "quoted string" and 'other quoted string'; exit $LASTEXITCODE'''
    cmd_parts = shell_plugins.powershell.ShellModule(connection=None).build_module_command(ansible_vars, shebang, cmd)
    assert cmd_parts == expected

    shebang = "#!powershell"
    cmd = "some_command with \"quoted string\" and 'other quoted string'"

# Generated at 2022-06-21 07:18:42.801825
# Unit test for method path_has_trailing_slash of class ShellModule
def test_ShellModule_path_has_trailing_slash():
    shell = ShellModule()

    assert shell.path_has_trailing_slash('/home/username') == False
    assert shell.path_has_trailing_slash('/home/username/') == True
    assert shell.path_has_trailing_slash('/home\\username\\') == True
    assert shell.path_has_trailing_slash('C:\\Users\\my-username\\') == True
    assert shell.path_has_trailing_slash('C:/Users/my-username/') == True
    assert shell.path_has_trailing_slash('C:/Users/my-username') == False
    assert shell.path_has_trailing_slash('C:\\\\Users\\\\my-username\\\\') == True