

# Generated at 2022-06-25 03:48:42.762950
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    data_loader_0 = DataLoader()
    temp_file_path = "/tmp/ansible_temp_file.txt"
    temp_file_content = "Hello World"
    create_temp_file(temp_file_path, temp_file_content)
    real_file = data_loader_0.get_real_file(temp_file_path)
    assert(compare_content(real_file, temp_file_content))
    data_loader_0.cleanup_all_tmp_files()
    delete_temp_file(temp_file_path)


# Generated at 2022-06-25 03:48:47.306673
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    data_loader = DataLoader()

    fname = "test_data/core/loader/test_loader_0.yml"
    raw_data = data_loader.load_from_file(filename=fname)
    assert raw_data == {'data_0': 0}


# Generated at 2022-06-25 03:48:53.195843
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    print("\n\nTesting DataLoader_get_real_file")
    data_loader_0 = DataLoader()
    var_0 = data_loader_0.get_real_file("some_param_0")
    var_0 = data_loader_0.get_real_file("some_param_1")
    print("Execution of get_real_file successful")


# Generated at 2022-06-25 03:49:00.689261
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    data_loader_0 = DataLoader()
    var_0 = data_loader_0.get_real_file("/etc/passwd")
    var_1 = data_loader_0.cleanup_all_tmp_files()


# Generated at 2022-06-25 03:49:07.250957
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    data_loader = DataLoader()
    try:
        data_loader.get_real_file("", decrypt=True)
    except Exception as e:
        print("Exception expected: " + str(e))
    try:
        data_loader.get_real_file("abc", decrypt=True)
    except Exception as e:
        print("Exception expected: " + str(e))
    try:
        data_loader.get_real_file("/etc/passwd", decrypt=True)
    except Exception as e:
        print("Exception expected: " + str(e))
    try:
        data_loader.get_real_file("data_loader.py", decrypt=True)
    except Exception as e:
        print("Exception expected: " + str(e))


# Generated at 2022-06-25 03:49:11.241747
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    data_loader_1 = DataLoader()
    var_1 = data_loader_1.load_from_file('sample')


# Generated at 2022-06-25 03:49:17.323059
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    data_loader_0 = DataLoader()
    file_path_0 = 'abc'
    decrypt_0 = False
    var_0 = data_loader_0.get_real_file(file_path_0, decrypt_0)


# Generated at 2022-06-25 03:49:20.970310
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():

    # Setup Ansible module_utils parameters
    data_loader_0 = DataLoader()
    file_path_0 = "/etc/ansible/roles/role0/tasks/main.yml"
    decrypt_0 = True

    # Run tested method
    real_file_0 = data_loader_0.get_real_file(file_path_0, decrypt_0)



# Generated at 2022-06-25 03:49:28.217338
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():

    # Creates "ansible/module_utils/ansible/module_utils/basic.py" file in current directory
    handle_0 = open('./ansible/module_utils/ansible/module_utils/basic.py', 'rb')

    # Creates "/tmp/ansible_loader_get_real_file_0.tmp" file with content from "ansible/module_utils/ansible/module_utils/basic.py"
    handle_1 = open('./ansible/module_utils/ansible/module_utils/basic.py', 'rb')
    handle_1_contents = handle_1.read()
    handle_1.close()
    handle_2 = open('/tmp/ansible_loader_get_real_file_0.tmp', 'wb+')

# Generated at 2022-06-25 03:49:40.285074
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():

    # create an instance of DataLoader with default values
    data_loader_1 = DataLoader()

    # Set up the args that would be parsed
    paths_1 = [
        '.',
        '..',
        '../..',
        '../../..',
        '../../../..',
    ]
    paths_2 = [
        '/abc/def',
        '/abc/def/ghi',
        '/abc/def/ghi/jkl',
        '/abc/def/ghi/jkl/mno',
        '/abc/def/ghi/jkl/mno/pqr',
    ]
    dirname_1 = 'test'
    source_1 = 'status.txt'
    source_2 = 'test/status.txt'
    source_3 = '../test/status.txt'



# Generated at 2022-06-25 03:49:52.215990
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    dl = DataLoader()
    f_path = dl.get_real_file('./containers/container_test.yml')
    with open(f_path, 'r') as f:
        data = f.read()
    print(data)


# Generated at 2022-06-25 03:50:01.367526
# Unit test for method path_dwim of class DataLoader
def test_DataLoader_path_dwim():
    from units.mock.path import mock_unfrackpath_noop, mock_open_if_exists

    dl = DataLoader()
    dl._unfrackpath = mock_unfrackpath_noop
    dl._is_file = mock_open_if_exists

    # two paths
    assert dl.path_dwim("/var/temp/bar.conf", "/var/temp")
    assert dl.path_dwim("../bar.conf", "/var/temp")

    # three paths
    assert dl.path_dwim("/var/temp/bar.conf", "/var/temp", "/var/temp")
    assert dl.path_dwim("../bar.conf", "/var/temp", "/var/temp")

# Generated at 2022-06-25 03:50:05.655027
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader_1 = DataLoader()
    result_1 = data_loader_1.cleanup_all_tmp_files()


# Generated at 2022-06-25 03:50:15.472313
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # Create a temporary file containing test data and encrypt it
    fd, content_tempfile = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    f = os.fdopen(fd, 'wb')
    content = to_bytes("""---
test_key: test_value
...
""")
    try:
        f.write(content)
    except Exception as err:
        os.remove(content_tempfile)
        raise Exception(err)
    finally:
        f.close()

    vault_password_file = '~/.ansible-vault-password-file'
    vault_password = 'test_vault_password'
    vault_password_str = "%s\n" % vault_password

# Generated at 2022-06-25 03:50:19.730983
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader = DataLoader()
    file_path = data_loader._create_content_tempfile("temp content")
    data_loader._tempfiles.add(file_path)
    data_loader.cleanup_tmp_file(file_path)
    assert data_loader._tempfiles == set()


# Generated at 2022-06-25 03:50:30.093616
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    data_loader_0 = DataLoader()
    file_path_0 = '~/.ansible/tmp/ansible-tmp-14671-18984-4b4/test/test_module_arguments.py'
    decrypt_0 = True
    # get_real_file call
    try:
        result_0 = data_loader_0.get_real_file(file_path_0, decrypt_0)
    except Exception as err:
        print(err)
        # get_real_file call
        try:
            result_0 = data_loader_0.get_real_file(file_path_0, decrypt_0)
        except Exception as err:
            print(err)


# Generated at 2022-06-25 03:50:35.305266
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='localhost')
    variable_manager.set_inventory(inventory)
    playbook = loader.load_from_file('./test_playbooks/test_playbook.yml')
    # playbook = load_from_file('./test_playbooks/test_playbook.yml')
    print(playbook)

# Generated at 2022-06-25 03:50:44.762614
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    # Test with a real file
    file_path = '/tmp/potato.file'
    try:
        open(file_path, 'w').write('hello world')
        data_loader_0 = DataLoader()
        data_loader_0._tempfiles.add(file_path)
        data_loader_0.cleanup_all_tmp_files()
        assert not os.path.exists(file_path)
    finally:
        try:
            os.remove(file_path)
        except OSError:
            pass


# Generated at 2022-06-25 03:50:51.079205
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():

    data_loader_1 = DataLoader()
    # define and create a new file
    os.system('touch newfile')

    # add the file to the temporary files list _tempfiles of the object
    newfile_path = data_loader_1.get_real_file('newfile')
    data_loader_1._tempfiles.add(newfile_path)

    # call the method to remove the file
    data_loader_1.cleanup_tmp_file(newfile_path)

    # check if the file is still present
    assert not os.path.isfile(newfile_path)


# Generated at 2022-06-25 03:51:02.580860
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # NOTE: test_case_0 has to run first to create the object data_loader_0
    # Create an object of class DataLoader
    data_loader_1 = DataLoader()
    # Call method find_vars_files of data_loader_1
    # First argument is a path to a directory
    # Second argument is a name of the valrs file
    # Third argument is a valid extensions for the vars file
    # Fourth argument decides if directories are allowed for vars files
    # Return value is a list of the vars files in the given path
    result = data_loader_1.find_vars_files('/home/anirudha/awx/home/',
                                           'main.yml',
                                           C.YAML_FILENAME_EXTENSIONS,
                                           True)

# Generated at 2022-06-25 03:51:13.070783
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader_1 = DataLoader()
    data_loader_1.cleanup_all_tmp_files()

if __name__ == "__main__":
    test_DataLoader_cleanup_all_tmp_files()

# Generated at 2022-06-25 03:51:21.796598
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    data_loader = DataLoader()
    try:
        data_loader.get_real_file("/tmp/test_dir/tasks/main.yml")
    except AnsibleParserError:
        assert True
    else:
        assert False

    try:
        data_loader.get_real_file("/tmp/test_dir/main.yml")
    except AnsibleParserError:
        assert True
    else:
        assert False

    try:
        data_loader.get_real_file("/tmp/test_dir/group_vars/group/ci.yml")
    except AnsibleParserError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 03:51:24.205947
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    test_case_0()
    assert hasattr(DataLoader, "cleanup_all_tmp_files")


# Generated at 2022-06-25 03:51:32.290192
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    with NamedTemporaryFile(delete=False) as f:
        # Setup named temporary file and ensure it is deleted
        data_to_write = "This is some data to test decrypt_file"
        f.write(to_bytes(data_to_write))
        file_name = f.name
        f.flush()
    try:
        with open(file_name, 'wb') as f:
            f.write(to_bytes("$ANSIBLE_VAULT;1.1;AES256\n" + binascii.b2a_base64(b'\x00' * 3 * 16)))
        # Test should fail, the file is encrypted
        dl = DataLoader()
        assert(dl.get_real_file(file_name))
    finally:
        os.unlink(file_name)

    #

# Generated at 2022-06-25 03:51:42.398837
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():

    data_loader = DataLoader()
    if data_loader is None:
        print("Failed to instantiate DataLoader")
        return False

    def check_real_file(fname, valid):
        try:
            test_path = data_loader.get_real_file(fname)
        except AnsibleFileNotFound as e:
            if valid:
                print("AnsibleFileNotFound exception raised when not expected")
                return False
            else:
                return True
        except:
            print("Error raised when not expected")
            return False

        if valid:
            if not os.path.exists(test_path):
                print("Path returned by get_real_file doesn't exist")
                return False
            else:
                return True
        else:
            print("Path returned by get_real_file not expected")

# Generated at 2022-06-25 03:51:49.111376
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    try:
        from ansible.parsing.vault import VaultLib
    except:
        return

    # Initialize variables
    data_loader = DataLoader()
    file_path = None
    decrypt = False
    data_loader.get_real_file(file_path, decrypt)


# Generated at 2022-06-25 03:51:52.014058
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader_1 = DataLoader()
    with pytest.raises(AnsibleParserError) as e:
        data_loader_1.cleanup_tmp_file("")

# Generated at 2022-06-25 03:51:57.150777
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    data_loader_1 = DataLoader()
    path = './'
    name = 'something'
    extensions = ['yml']
    allow_dir = True
    found = data_loader_1.find_vars_files(path, name, extensions, allow_dir)
    assert len(found) >= 0

test_case_0()
test_DataLoader_find_vars_files()

# Generated at 2022-06-25 03:51:59.125848
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    class_0 = DataLoader()
    path = 'test_file'
    class_0.load_from_file(path)


# Generated at 2022-06-25 03:52:01.031396
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    test_case_0()
    data_loader_0 = DataLoader(basedir='/home/pankaj')


# Generated at 2022-06-25 03:52:16.092619
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # Tests that the files are not encrypted or exist.
    data_loader_1 = DataLoader()
    try:
        data_loader_1.get_real_file('/etc/passwd')
    except AnsibleFileNotFound:
        pass
    else:
        assert False

    try:
        data_loader_1.get_real_file('/etc/passwd', decrypt=False)
    except AnsibleFileNotFound:
        pass
    else:
        assert False

    try:
        data_loader_1.get_real_file('/etc/passwd', decrypt=True)
    except AnsibleFileNotFound:
        pass
    else:
        assert False


# Generated at 2022-06-25 03:52:21.733716
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader = DataLoader()
    data_loader.cleanup_all_tmp_files()

if __name__ == "__main__":
    test_case_0()
    test_DataLoader_cleanup_all_tmp_files()

# Generated at 2022-06-25 03:52:26.511512
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    import os
    data_loader_0 = DataLoader()

    path_src = '/usr/bin/python'

    dirname_src = 'python'

    source_src = 'python3'

    is_role_src = None
    src_2 = data_loader_0.path_dwim_relative(path_src, dirname_src, source_src, is_role_src)

    assert src_2 == '/usr/bin/python3'


# Generated at 2022-06-25 03:52:31.058056
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    # Objects
    data_loader_1 = DataLoader()
    assert data_loader_1.cleanup_tmp_file('/tmp/test.txt') is None


# Generated at 2022-06-25 03:52:33.358384
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    """DataLoader - load_from_file - Load variables from a file, given a filename and optional vault secrets."""
    filename = 'test/unittest_loader/test_DataLoader/load_from_file.yaml'
    data_loader = DataLoader()
    data = data_loader.load_from_file(filename)
    assert data == {
        'data': 'loaded'
    }


# Generated at 2022-06-25 03:52:42.725936
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    dir_name = "foo"
    data_loader = DataLoader(dir_name)

    # create a dummy file
    file_name = "test_file_1"
    file_content = "ABCD"

    file_path = os.path.join(dir_name, file_name)
    f1 = open(file_path, "w")
    f1.write(file_content)
    f1.close()

    data_loader.get_real_file(file_path, decrypt=False)
    data_loader.cleanup_tmp_file(file_path)

    # The test fails only when the file exists at the end of the test
    assert not os.path.exists(file_path)


# Generated at 2022-06-25 03:52:46.472926
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():

    data_loader = DataLoader()
    data_loader.path_exists = lambda x: True
    data_loader.is_file = lambda x: True
    data_loader.get_real_file = lambda x: True
    data_loader.cleanup_tmp_file = lambda x: True
    data_loader.cleanup_all_tmp_files()



# Generated at 2022-06-25 03:52:56.085759
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader_0 = DataLoader()
    # create a temporary file
    tmp_file_content = data_loader_0._create_content_tempfile("temporary content")
    assert os.path.exists(tmp_file_content)
    # call cleanup_tmp_file with the temporary file path
    data_loader_0.cleanup_tmp_file(tmp_file_content)
    assert not os.path.exists(tmp_file_content)
    # call cleanup_tmp_file with a file that does not exist
    try:
        data_loader_0.cleanup_tmp_file("/tmp/does_not_exist")
    except Exception as e:
        assert "No such file or directory" in to_text(e)


# Generated at 2022-06-25 03:53:06.911426
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    data_loader_1 = DataLoader()
    # This test case is taken from test case-18 of https://github.com/dpocock/ansible-vault/blob/master/tests/test_encrypt.py
    with open(os.path.dirname(os.path.realpath(__file__)) + '/test.txt', 'r+') as f:
        d = f.read()
        f.seek(0)
        f.truncate()
        vault = VaultLib()
        vault.secrets = ['test']
        d = vault.encrypt(d)
        f.write(d.decode())

        print(data_loader_1.get_real_file('test.txt'))

# Generated at 2022-06-25 03:53:14.143914
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    data_loader_0 = DataLoader()

    # Valid input
    data_loader_0.set_basedir('/tmp')
    test_file = data_loader_0.load_from_file('/tmp/test')

    # Not a file
    with pytest.raises(AnsibleFileNotFound) as excinfo0:
        data_loader_0.load_from_file('/tmp/test/test')
    assert 'file_name=\'/tmp/test/test\', paths=\[\'/tmp/test/test\'\]' in to_native(excinfo0.value)



# Generated at 2022-06-25 03:53:32.115349
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    b_path = to_bytes('./test/data')
    name = 'test'
    extensions = ['yaml', 'yml', 'json', 'ini', 'txt']
    allow_dir = True

    found = []
    if isinstance(extensions, list):
        # Look for file with no extension first to find dir before file
        extensions = [''] + extensions
    # add valid extensions to name
    for ext in extensions:

        if '.' in ext:
            full_path = b_path + to_bytes(ext)
        elif ext:
            full_path = b'.'.join([b_path, to_bytes(ext)])
        else:
            full_path = b_path


# Generated at 2022-06-25 03:53:41.085704
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader = DataLoader()
    assert_equal(data_loader.cleanup_tmp_file(os.path.join(C.DEFAULT_LOCAL_TMP, "tasks")), None)
    assert_equal(data_loader.cleanup_tmp_file(C.DEFAULT_LOCAL_TMP), None)
    assert_equal(data_loader.cleanup_tmp_file(True), None)
    assert_equal(data_loader.cleanup_tmp_file(10.5), None)
    assert_equal(data_loader.cleanup_tmp_file("abc"), None)

# Generated at 2022-06-25 03:53:45.604127
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    # Test for case 0
    test_case_0()


if __name__ == '__main__':
    # Run the test cases
    test_DataLoader_cleanup_tmp_file()

# Generated at 2022-06-25 03:53:53.252198
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    """ Test to load a file from the filesystem. """
    data_loader_1 = DataLoader()

    # Test 1. Obtain a reference to a file that does not exist
    file_path = os.path.join('/tmp/ansible_test_1', 'module')
    if os.path.isfile(file_path):
        os.remove(file_path)

    if os.path.isdir(os.path.dirname(file_path)):
        shutil.rmtree(os.path.dirname(file_path))

    text = data_loader_1.load_from_file(file_path)
    assert text == ''

    # Test 2. Create a file and test the load

# Generated at 2022-06-25 03:54:02.679628
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():

    file_path_1 = "../../../../../../../etc/hosts" # Non-existant file
    dir_path_1 = "../../../../../../../etc"        # Non-existant dir

    file_path_2 = "~/.profile"                    # Existant file
    dir_path_2 = "~/"                             # Existant dir

    file_path_3 = "/etc/hosts"                    # Existant file
    dir_path_3 = "/etc"                           # Existant dir

    file_path_4 = "~/../../../../../../etc/hosts" # Non-existant file
    dir_path_4 = "~/../../../../../../etc"        # Non-existant dir

    file_path_5 = "/home/user/.profile"           # Existant file
    dir

# Generated at 2022-06-25 03:54:07.237741
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader = DataLoader()
    test_file_path = data_loader._create_content_tempfile("data")

    assert os.path.exists(test_file_path)
    data_loader.cleanup_all_tmp_files()
    assert not os.path.exists(test_file_path)


# Generated at 2022-06-25 03:54:12.526951
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    '''
    DataLoader:find_vars_files test stub
    '''
    data_loader = DataLoader()
    
    # Set the following values
    path = "" 
    name = "" 
    extensions = None 
    allow_dir = False

    # Invoke method
    response = data_loader.find_vars_files(
        path,
        name,
        extensions,
        allow_dir
    )


# Generated at 2022-06-25 03:54:17.494230
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    # Arrange
    data_loader_0 = DataLoader()
    expected_file_not_deleted = os.path.join(data_loader_0.get_basedir(), "README.md")

    # Act
    data_loader_0.cleanup_all_tmp_files()

    # Assert
    try:
        assert(os.path.isfile(expected_file_not_deleted))
    except AssertionError:
        raise AssertionError("test_DataLoader_cleanup_all_tmp_files failed: expected file not deleted")


# Generated at 2022-06-25 03:54:22.884475
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader_1 = DataLoader()
    data_loader_1.get_real_file('/usr/local/lib/python2.7/dist-packages/pytest/__init__.pyc')
    data_loader_1.get_real_file('/usr/local/lib/python2.7/dist-packages/pytest/__init__.pyc')
    data_loader_1.get_real_file('/usr/local/lib/python2.7/dist-packages/pytest/__init__.pyc')
    data_loader_1.cleanup_tmp_file('/tmp/tmpqJsndi')
    data_loader_1.cleanup_tmp_file('/tmp/tmp1lwBe7')

# Generated at 2022-06-25 03:54:26.984381
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader_0 = DataLoader()
    data_loader_0.cleanup_all_tmp_files()


# Generated at 2022-06-25 03:54:36.633840
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    test_case_0()


# Generated at 2022-06-25 03:54:39.343863
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    file_path = "~/path/to/somefile"
    data_loader_0 = DataLoader()
    data_loader_0.cleanup_tmp_file(file_path)


# Generated at 2022-06-25 03:54:40.956524
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    loader = DataLoader()
    loader.cleanup_all_tmp_files()


# Generated at 2022-06-25 03:54:45.477245
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader_0 = DataLoader()
    data_loader_0.cleanup_all_tmp_files()


# Generated at 2022-06-25 03:54:54.729355
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    vault_secret = '123'
    vault_password = '456'
    fd, content_tempfile_1 = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    fd, content_tempfile_2 = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    fd, content_tempfile_3 = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)

    f = os.fdopen(fd, 'wb')
    content = 'This is a test'
    try:
        f.write(content)
    except Exception as err:
        os.remove(content_tempfile_1)
        raise Exception(err)
    finally:
        f.close()


# Generated at 2022-06-25 03:54:58.086222
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    # Test case 0:
    try:
        data_loader_0 = DataLoader()
        # The cleanup_all_tmp_files() method of class DataLoader is not used.
    except Exception as e:
        display.warning("Exception raised:\n{}".format(to_text(e)))


# Generated at 2022-06-25 03:55:04.770647
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader_0 = DataLoader()
    data_loader_0.cleanup_all_tmp_files()


# Generated at 2022-06-25 03:55:13.189133
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    import tempfile
    from ansible.parsing.vault import VaultLib

    # Create encryption password
    vault_password = tempfile.NamedTemporaryFile(delete=False)
    vault_password.write(b'ansible')
    vault_password.close()
    vault_password_path = vault_password.name

    # Create temp files and encrypt
    f = tempfile.NamedTemporaryFile()
    f.write(b'random_content')
    f.seek(0)
    f2 = tempfile.NamedTemporaryFile()
    f2.write(b'random_content_2')
    f2.seek(0)
    vault = VaultLib(vault_password_path)
    f1_encrypted = vault.encrypt_bytes(f.read())
    f2_encrypted = vault.enc

# Generated at 2022-06-25 03:55:15.571608
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader_1 = DataLoader()
    data_loader_1.cleanup_all_tmp_files()

# Generated at 2022-06-25 03:55:17.001152
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader_0 = DataLoader()
    pass



# Generated at 2022-06-25 03:55:30.245962
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # Setup the test case
    data_loader_1 = DataLoader()
    # Setup the mocks
    tempfile_mock_1 = Mock()
    tempfile_mock_1.mkstemp.return_value=('fd', 'content_tempfile')
    # Setup the replacements
    data_loader_1.tempfile = tempfile_mock_1
    is_encrypted_file_mock_1 = Mock()
    data_loader_1.is_encrypted_file = is_encrypted_file_mock_1
    data_loader_1._vault = Mock()
    # Run the tested method
    data_loader_1.get_real_file('file_path')
    # Run asserts on the method

# Generated at 2022-06-25 03:55:36.717928
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():

    # Create data loader instance
    data_loader = DataLoader()

    # Test for correct functionality when correct path is passed
    assert data_loader.get_real_file("../testdata/test_DataLoader_get_real_file.yml") != None

    # Test for correct functionality when incorrect path is passed
    with pytest.raises(AnsibleFileNotFound):
        assert data_loader.get_real_file("../testdata/test_DataLoader_get_real_file_not_present.yml")

    # Test for correct functionality when None is passed
    with pytest.raises(AnsibleParserError):
        assert data_loader.get_real_file(None)

# Generated at 2022-06-25 03:55:47.705759
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    print("Testing cleanup_all_tmp_files")
    data_loader_1 = DataLoader()

    assert len(data_loader_1._tempfiles) == 0

    # Create one temporary file to test cleanup
    fd, content_tempfile = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    f = os.fdopen(fd, 'wb')
    content = u'This is a test'
    data = content
    try:
        f.write(to_bytes(data, errors='surrogate_or_strict'))
    except Exception as err:
        os.remove(content_tempfile)
        raise Exception(err)
    finally:
        f.close()

    # Add temporary file to list of temporary files to be cleaned up
    data_loader_1._tempfiles.add

# Generated at 2022-06-25 03:55:53.156430
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader_0 = DataLoader()
    data_loader_0.cleanup_tmp_file(u'/tmp/test-files-0/test-files-0-content-0.txt')


# Generated at 2022-06-25 03:56:02.623013
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    # data_loader_1 will acquire a lock preventing data_loader_0 from exiting
    # until it releases the lock
    data_loader_1 = DataLoader()
    data_loader_1._cleanup_lock = weakref.ref(data_loader_1._cleanup_lock)()

    t = threading.Thread(target=test_case_0)
    t.daemon = True
    t.start()

    # give a chance for test_case_0 to run and finish
    time.sleep(1)




# Generated at 2022-06-25 03:56:09.310399
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    data_loader_0 = DataLoader()
    result = data_loader_0.path_dwim_relative_stack(['/a/b/c', '/a/b/c'], '/d/e/f', 'g/h/i/j', True)
    assert result == '/a/b/c/d/e/f/g/h/i/j'


# Generated at 2022-06-25 03:56:11.189910
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader_0 = DataLoader()
    file_path_0 = '/tmp/temp_file_name'
    data_loader_0.cleanup_tmp_file(file_path_0)


# Generated at 2022-06-25 03:56:21.148041
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():

    print('[UNITTEST] Running test_DataLoader_path_dwim_relative')
    cur_basedir = os.path.dirname(os.path.abspath(__file__))

    print('[UNITTEST] test_DataLoader_path_dwim_relative: test 1')
    path = os.path.join(cur_basedir, 'test_DataLoader_path_dwim_relative_test_dir', 'roles', 'test_role1', 'tasks')
    dirname = 'tasks'
    source = 'test_task1.yml'
    is_role = True

# Generated at 2022-06-25 03:56:29.208967
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    # setup test
    data_loader_1 = DataLoader()
    file_path = data_loader_1._create_content_tempfile("hello")
    assert os.path.exists(file_path)
    assert file_path in data_loader_1._tempfiles

    data_loader_1.cleanup_tmp_file(file_path)
    assert not os.path.exists(file_path)
    assert file_path not in data_loader_1._tempfiles


# Generated at 2022-06-25 03:56:37.973722
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    # Setup
    data_loader_1 = DataLoader()
    data_loader_1._find_file_in_paths = MagicMock(return_value=['/home/testuser/ansible_test/test/test_test.yaml'])
    data_loader_1.path_exists = MagicMock(return_value=True)

    # Action
    with patch('os.path.exists') as mock_os_path_exists:
        data_loader_1.load_from_file('test_test.yaml')

    # Assertions
    assert mock_os_path_exists.called


# Generated at 2022-06-25 03:56:46.907903
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    # Create an instance of DataLoader class
    data_loader = DataLoader()
    # Try to cleanup all temporary files
    data_loader.cleanup_all_tmp_files()


# Generated at 2022-06-25 03:56:52.235481
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    data_loader = DataLoader()
    data_loader.path_exists = Mock(return_value = True)
    data_loader.is_directory = Mock(return_value = True)
    data_loader.get_real_file = Mock(return_value = 'test_file.yml')

    result = data_loader.load_from_file('/mock_path/file.yml')

    assert result == 'test content'


# Generated at 2022-06-25 03:56:54.691208
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    file_path = "test/test_ansible_loader.py"
    loader = DataLoader()
    file_data = loader.load_from_file(file_path)
    assert file_data == loader._get_file_contents(file_path)

# Unit Test for method path_exists of class DataLoader

# Generated at 2022-06-25 03:57:07.315488
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():

    # Test case 0
    data_loader_0 = DataLoader()
    result_0 = data_loader_0.find_vars_files('test_vars_files_path', 'test_vars_files_name', ['test_vars_files_extensions_0'], True)

    # Test case 1
    data_loader_1 = DataLoader()
    result_1 = data_loader_1.find_vars_files('test_vars_files_path', 'test_vars_files_name', ['test_vars_files_extensions_1'], True)

    # Test case 2
    data_loader_2 = DataLoader()

# Generated at 2022-06-25 03:57:10.279351
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader_1 = DataLoader()
    file_path_1 = '/home/mock/test/mock'
    data_loader_1.cleanup_tmp_file(file_path_1)


# Generated at 2022-06-25 03:57:15.845604
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader_0 = DataLoader()
    data_loader_0.cleanup_all_tmp_files()
    data_loader_0.cleanup_tmp_file('tmp_file')

if __name__ == "__main__":
    test_case_0()
    test_DataLoader_cleanup_all_tmp_files()

# Generated at 2022-06-25 03:57:24.112305
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    loader = DataLoader()
    path_1 = './hints'
    path_2 = './library'
    path_3 = './module_utils'
    path_4 = './callback_plugins'
    path_5 = './lookup_plugins'
    assert loader.get_real_file(path_1) == path_1
    assert loader.get_real_file(path_2) == path_2
    assert loader.get_real_file(path_3) == path_3
    assert loader.get_real_file(path_4) == path_4
    assert loader.get_real_file(path_5) == path_5


# Generated at 2022-06-25 03:57:37.730432
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    class AnsibleOptions:
        def __init__(self, vault_password_file='foo'):
            self.vault_password_file = vault_password_file

    class AnsibleVault:
        def __init__(self, options):
            self.options = options

        secrets = []

    test_data_loader = DataLoader()
    test_data_loader.set_vault_secrets([])

    config = {}
    config['ANSIBLE_CONFIG'] = 'foo'
    config['ANSIBLE_FORCE_COLOR'] = 'foo'
    config['ANSIBLE_HOST_KEY_CHECKING'] = 'foo'
    config['ANSIBLE_LIBRARY'] = 'foo'
    config['ANSIBLE_MODULE_UTILS'] = 'foo'

# Generated at 2022-06-25 03:57:42.136579
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
   data_loader_0 = DataLoader()
   data_loader_0.cleanup_all_tmp_files()



# Generated at 2022-06-25 03:57:45.472260
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader_1 = DataLoader()

    data_loader_1.cleanup_all_tmp_files()

if __name__ == "__main__":
    test_case_0()
    test_DataLoader_cleanup_all_tmp_files()

# Generated at 2022-06-25 03:58:00.021975
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader_1 = DataLoader()
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_loader_1 = AnsibleLoader(None, data_loader=data_loader_1, base_loader=None)

# Generated at 2022-06-25 03:58:08.646755
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    test_file_name = 'yaml_test_case.yaml'
    test_file_path = os.path.join(os.path.dirname(__file__), test_file_name)
    test_file = open(test_file_path, 'r')
    try:
        data_loader_1 = DataLoader()
        output = data_loader_1.load_from_file(test_file)
        assert output == {'test_list': [1, 2, 3], 'test_str': 'str', 'test_int': 1, 'test_dict': {'key1': 'value1', 'key2': 'value2'}, 'test_unicode': 'test'}, 'test_DataLoader_load_from_file() failed'
    finally:
        test_file.close()
