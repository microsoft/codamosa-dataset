

# Generated at 2022-06-11 08:29:14.616777
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    with patch('os.path.isfile') as mock_isfile:
        with patch('ansible.parsing.vault.VaultLib.decrypt') as mock_decrypt:
            with patch('ansible.parsing.vault.VaultLib.is_encrypted_file') as mock_is_encrypted_file:
                test_loader = DataLoader()

                # Case 1: Vault file
                mock_isfile.return_value = True
                mock_is_encrypted_file.return_value = True
                mock_decrypt.return_value = u'foo'
                assert test_loader.get_real_file(u'vault.yml')

                # Case 2: Non Vault File
                mock_isfile.return_value = True
                mock_is_encrypted_file.return_value = False
                mock_

# Generated at 2022-06-11 08:29:16.315187
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    assert False, "Test if the DataLoader's method get_real_file is working."



# Generated at 2022-06-11 08:29:16.913026
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
  pass

# Generated at 2022-06-11 08:29:18.340331
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    # TODO: needs to be implemented
    pass


# Generated at 2022-06-11 08:29:29.958610
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    import textwrap
    import tempfile
    import shutil
    import random
    import string
    import textwrap
    import sys

    extension_list = ['.yml', '.yaml', '.jsn', '.json', '']

    def create_var_file(d, name, ext, is_dir=False):
        if is_dir:
            fd, fp = tempfile.mkstemp(dir=d)
        else:
            fd, fp = tempfile.mkstemp(dir=d, suffix=ext)
        os.close(fd)
        if is_dir:
            os.rmdir(fp)
        else:
            os.unlink(fp)

        dir_var_file = os.path.join(d, name)
        if is_dir:
            os.makedirs

# Generated at 2022-06-11 08:29:39.540388
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    from ansible.utils import py3compat
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vault_loader
    from ansible.constants import DEFAULT_VAULT_IDENTITY_LIST

    loader = DataLoader()
    vm = VariableManager()
    # Construct inventory object to test with
    inventory = InventoryManager(loader=loader, sources=["tests/inventories/test_inventory"])

# Generated at 2022-06-11 08:29:48.845961
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    passes = 0

# Generated at 2022-06-11 08:30:00.268417
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    # Setup
    #
    # These tests assume that we're running from the root of the Ansible
    # source tree, and that the source tree is actually a Git checkout.
    #
    # For example:
    #
    # $ git clone git://github.com/ansible/ansible.git
    # $ cd ansible
    # $ python ./test/units/plugins/test_loader.py

    # Ensure that there is a local Git checkout.
    #
    # If there isn't, then this test is pointless -- we can't test anything
    # meaningful.
    with pytest.raises(ConfigError):
        repo = Repo('./')

    # Create a temporary directory, which will be the Ansible configuration
    # directory. We'll point ansible.cfg to it.
    ansible_dir = tempfile.mkdtemp

# Generated at 2022-06-11 08:30:09.063379
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    loader = DataLoader()
    fname = 'test.yaml'
    path = 'test.yaml'

    try: loader.load_from_file(fname)
    except AnsibleParserError: pass
    else: raise ValueError("AnsibleParserError not raised")

    try: loader.load_from_file(path)
    except AnsibleParserError: pass
    else: raise ValueError("AnsibleParserError not raised")

    try: loader.load_from_file(fname, vault_password='vault_password')
    except AnsibleParserError: pass
    else: raise ValueError("AnsibleParserError not raised")

    try: loader.load_from_file(path, vault_password='vault_password')
    except AnsibleParserError: pass

# Generated at 2022-06-11 08:30:19.452583
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
  with patch('ansible.parsing.yaml.loader.AnsibleLoader'):
    data_loader = DataLoader()

    # Test with invalid path
    try:
      found = data_loader.find_vars_files("/tmp", "main.yaml")
      assert found == []
    except Exception as err:
      display.warning("Unexpected exception when searching for vars file in an invalid path")
      raise

    # Test with empty path
    try:
      found = data_loader.find_vars_files("/tmp", "")
      assert found == []
    except Exception as err:
      display.warning("Unexpected exception when searching for vars file with empty name")
      raise

    # Test with valid path but empty file

# Generated at 2022-06-11 08:30:41.684826
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    dl = DataLoader()
    assert_raises(AnsibleParserError, dl.get_real_file, '/nonexistent')


# Generated at 2022-06-11 08:30:42.772966
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    loader = DataLoader()


# Generated at 2022-06-11 08:30:45.813936
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    dl = DataLoader()
    assert dl.get_real_file(None) == None

test_DataLoader_get_real_file()

# Generated at 2022-06-11 08:30:54.385008
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    # Tested cases
    # --------------
    # 1. If a file exists with the given source
    # 2. If a file doesn't exists with the given source

    # Test case 1
    # Create a temporary file
    fd, file_path = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    f = os.fdopen(fd, 'wb')
    try:
        # Write "test" content to the temporary file
        f.write(b'test')
    except Exception as err:
        os.remove(file_path)
        raise Exception(err)
    finally:
        f.close()

    # Load provided file
    loader = DataLoader()
    content = loader.load_from_file(file_path)

    # Verify the content loaded
    assert content == b'test'

# Generated at 2022-06-11 08:30:59.338057
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader = DataLoader()
    file_path = data_loader.get_real_file("blah")
    data_loader.cleanup_tmp_file(file_path)
    data_loader.cleanup_tmp_file(file_path)
    data_loader.cleanup_all_tmp_files()


# Generated at 2022-06-11 08:31:00.954510
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    # TODO: Write a unit test which will test the method cleanup_tmp_file of class DataLoader
    pass


# Generated at 2022-06-11 08:31:11.165380
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile._get_default_tempdir()
    url = 'file://' + tmpdir
    path = os.path.join(tmpdir, 'test-get_real_file')
    os.makedirs(path)

    # Setup
    dl = DataLoader()
    dl._vault = VaultLib([])

    # Test: bad arguments
    try:
        dl.get_real_file(None)
        raise Exception('Expected ValueError')
    except ValueError:
        pass

    try:
        dl.get_real_file(True)
        raise Exception('Expected ValueError')
    except ValueError:
        pass

    # Test: bad file_path

# Generated at 2022-06-11 08:31:15.661428
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    dl = DataLoader()
    f = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    os.remove(f[1])
    dl.cleanup_tmp_file(f[1])
    assert not os.path.exists(f[1])



# Generated at 2022-06-11 08:31:16.586411
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    return True


# Generated at 2022-06-11 08:31:27.304318
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    # Setup arguments and context
    args = (([u'/tmp'], u'tasks', u'foo.yml', True),)
    # No exception is raised
    result = DataLoader().path_dwim_relative_stack(*args[0])
    assert result == u'/tmp/tasks/foo.yml'

    # Setup arguments and context
    args = (([u'/tmp/foo'], u'tasks', u'foo.yml', True),)
    # No exception is raised
    result = DataLoader().path_dwim_relative_stack(*args[0])
    assert result == u'/tmp/foo/tasks/foo.yml'

    # Setup arguments and context
    args = (([u'/tmp/foo'], u'tasks', u'foo', True),)
    # No exception is raised

# Generated at 2022-06-11 08:31:53.404101
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    '''
    Unit test for method DataLoader.cleanup_all_tmp_files
    '''
    # (1)
    loader = DataLoader()
    # (2)
    assert len(loader._tempfiles) == 0, 'unexpected tmpfiles'
    # (3)
    loader.cleanup_all_tmp_files()

# Generated at 2022-06-11 08:32:02.632167
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # set up args
    file_path = b'/home/vagrant/ansible/lib/ansible/module_utils/module_helper.py'
    # set up return values
    ret_tempfile_num = 'ret_tempfile_num'
    ret_tempfile_name = 'ret_tempfile_name'
    # set up function stubs
    tempfile_mkstemp = Mock(return_value=(ret_tempfile_num, ret_tempfile_name))
    os_fdopen = Mock()
    os_remove = Mock()
    # set up class stubs
    to_bytes = Mock()
    path_exists = Mock(return_value=True)
    is_file = Mock(return_value=True)
    # set up context
    context = globals().copy()

# Generated at 2022-06-11 08:32:08.726847
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    loader = DataLoader()
    # must be a tempfile that is not cleaned up yet
    temp_file = tempfile.mkstemp()[1]
    loader._tempfiles.add(temp_file)
    # cleanup_all_tmp_files should be able to find such files and delete
    loader.cleanup_all_tmp_files()
    assert not os.path.isfile(temp_file)
    for temp_file in loader._tempfiles:
        assert not os.path.isfile(temp_file)


# Generated at 2022-06-11 08:32:12.910068
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    loader = DataLoader()
    loader.get_basedir = lambda: '/etc/ansible'

    # Set up mocks
    mock_path = '/etc/ansible/test/test.yaml'
    mock_temp = '/tmp/test.yaml'
    loader.path_exists = lambda x: True
    loader.is_file = lambda x: True
    loader.get_real_file = MagicMock(return_value=mock_temp)
    loader.cleanup_tmp_file = MagicMock()
    loader._tempfiles.add(mock_temp)

    # Test
    loader.get_real_file(mock_path, decrypt=False)
    loader.cleanup_all_tmp_files()

    # Verify results
    loader.cleanup_tmp_file.assert_called_once_with

# Generated at 2022-06-11 08:32:22.546938
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    import os
    try:
        import ansible.parsing.vault
    except ImportError:
        ansible.parsing.vault = None
    try:
        import ansible.module_utils.six
    except ImportError:
        ansible.module_utils.six = None
    try:
        import ansible.module_utils.urls
    except ImportError:
        ansible.module_utils.urls = None
    try:
        import ansible.module_utils.parsing.convert_bool
    except ImportError:
        ansible.module_utils.parsing.convert_bool = None
    try:
        import ansible.module_utils.parsing.convert_unicode
    except ImportError:
        ansible.module_utils.parsing.convert_unic

# Generated at 2022-06-11 08:32:28.731812
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():

    # Initialize data loader

    _data_loader = DataLoader()

    # path_dwim_relative with the following args
    # 1st arg: a path, 2nd arg: a directory name, 3rd arg: a source
    _data_loader.path_dwim_relative(
        os.path.join(os.getcwd(),  'test-files'), 'files/foo/',  'x.txt')

# Generated at 2022-06-11 08:32:39.516314
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    from units.compat import file_types
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        u'data': {
            u'files': {
                u'two': u'---\ntwo',
                u'three': u'---\nthree',
            },
            u'tempfiles': [
                u'tempfile1',
                u'tempfile2'
            ]
        },
        u'non-data': {
            u'files': {
                u'one': u'---\none',
                u'two': u'---\nTWO',
            },
            u'tempfiles': [
                u'tempfile3',
                u'tempfile4'
            ]
        },
    })
    # Test default state
    assert os.path.ex

# Generated at 2022-06-11 08:32:51.914071
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    dl = DataLoader()
    data_dir = os.path.dirname(dl.path_dwim(__file__))
    playbook = {
        'hosts': 'localhost',
        'vars': {'a': '{{b}}', 'b': 'b'}
    }
    data = dl.load_from_file(os.path.join(data_dir, 'loader/vars.yml'))
    assert isinstance(data, dict)
    assert data == {'foo': 'bar'}
    data = dl.load_from_file(os.path.join(data_dir, 'loader/vars.yaml'))
    assert isinstance(data, dict)
    assert data == {'foo': 'bar'}

# Generated at 2022-06-11 08:33:02.585155
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # create a temporary vault file with the correct vault ID
    filename = 'ansible-vault-data-loader-file.yml'
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 08:33:12.186244
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    from unittest import mock
    from ansible.parsing.vault import VaultLib
    with mock.patch('ansible.parsing.vault.get_file_vault_secret'), mock.patch('ansible.parsing.dataloader.get_file_vault_secret'):
        dataloader = DataLoader()
        dataloader._tempfiles.add('/path/to/tmp/file.yml')
        with mock.patch.object(os, 'unlink') as mock_unlink:
            dataloader.cleanup_all_tmp_files()
            mock_unlink.assert_called_once_with('/path/to/tmp/file.yml')

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-11 08:34:03.643816
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    # Check for FALSE POSITIVE
    pass

# Generated at 2022-06-11 08:34:04.723561
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    loader = DataLoader()
    pass

# Generated at 2022-06-11 08:34:11.196419
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    DataLoader.__module__ = 'ansible'
    import tempfile
    from ansible.utils.path import unfrackpath
    from ansible.parsing.vault import VaultLib
    vault_password = "vault_password"
    fake_loader = DataLoader()
    fake_loader._vault = VaultLib(password=vault_password)
    fake_loader._tempfiles.add(tempfile.mktemp())
    fake_loader.path_exists = MagicMock(return_value=True)
    fake_loader.is_file = MagicMock(return_value=True)
    fake_loader._create_content_tempfile = MagicMock(return_value=unfrackpath("/tmp/test_file_path"))

# Generated at 2022-06-11 08:34:16.047922
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    # This is to test the DataLoader.cleanup_tmp_file method
    loader = DataLoader()
    file_path = file_utils.write_temp_file('This is a temporary file')

    loader.cleanup_tmp_file('file_path')

    # This is to test the file actually removed or not
    assert not os.path.exists(file_path)


# Generated at 2022-06-11 08:34:24.216056
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    play_context = PlayContext()
    play_context.vault_password = 'secret'
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    vault_secrets = [VaultSecret('secret', 'secret')]

    # Create first task
    task = dict(action=dict(module='setup', args=''))

# Generated at 2022-06-11 08:34:26.489946
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():  # noqa
    '''
    Test DataLoader.cleanup_all_tmp_files
    '''
    dataloader = DataLoader()


# Generated at 2022-06-11 08:34:35.814048
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # Load the class under test
    dl = DataLoader()

    # Create a test file
    content = u'{"test": true}'
    test_path = dl._create_content_tempfile(content)
    dl._tempfiles = set()

    # Call the class under test
    real_file = dl.get_real_file(test_path)
    assert real_file.endswith('.json')
    with open(real_file, 'rb') as f:
        assert content == to_text(f.read())

    # Clean
    dl.cleanup_all_tmp_files()
    os.remove(test_path)

# Generated at 2022-06-11 08:34:39.306345
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    # Basic testing
    dl = DataLoader()
    assert dl.path_exists('/etc')
    assert dl.path_exists('/etc/passwd')


# Generated at 2022-06-11 08:34:49.430196
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    args = dict(file_path="test/test_file.yml", decrypt=True)
    result = None

    # Case: test file exists, no exception
    try:
        result = DataLoader().get_real_file(**args)
        assert isinstance(result, text_type)
    except Exception as e:
        assert False, "DataLoader().get_real_file raised exception: {}".format(e)

    # Case: test file does not exist, raises exception
    args['file_path'] = 'non-existent_file.yml'

# Generated at 2022-06-11 08:34:57.567831
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    file_path = os.path.join(tempfile.mkdtemp(), "whatever")
    open(file_path, "w").close()
    loader = DataLoader()
    try:
        assert os.path.exists(file_path)
        loader.cleanup_tmp_file(file_path)
        assert not os.path.exists(file_path)
        try:
            loader.cleanup_tmp_file(file_path)
            assert False, "should have raised exception"
        except AnsibleParserError:
            pass

    finally:
        shutil.rmtree(os.path.dirname(file_path))



# Generated at 2022-06-11 08:36:18.588299
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    DataLoader()

# Generated at 2022-06-11 08:36:28.986695
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    C = config.ConfigParser()
    l = DataLoader(path_root=b'/path/root', settings=C)
    assert isinstance(l.load_from_file(b'content'), dict)
    assert isinstance(l.load_from_file(b'content', True), dict)
    assert isinstance(l.load_from_file(b'content', True), dict)
    assert isinstance(l.load_from_file(b'content', True, 'utf-8'), dict)
    assert isinstance(l.load_from_file(b'content', True, 'utf-8', b'content'), dict)
    assert isinstance(l.load_from_file(b'content', True, 'utf-8', b'content', False), dict)


# Generated at 2022-06-11 08:36:34.512047
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    '''Test the DataLoader class'''
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    d = DataLoader()
    assert(d.get_real_file('./yaml_loader.py') == './yaml_loader.py')
    assert(d.get_real_file('./yaml_loader.py', decrypt=False) == './yaml_loader.py')
    assert(isinstance(d.get_real_file('./ansible_postgres_enc_vault_test.yml'), basestring))
    assert(isinstance(d.get_real_file('./ansible_postgres_enc_vault_test.yml', decrypt=False), basestring))

# Generated at 2022-06-11 08:36:39.157832
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    data_loader = DataLoader()
    path = to_bytes('test_path')
    name = 'test_name'
    extensions = ['test_extensions']
    allow_dir = True
    result = data_loader.find_vars_files(path, name, extensions, allow_dir)




# Generated at 2022-06-11 08:36:49.612078
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    root_path = Path("tests/fixtures/test_ansible_loader/")
    dl = DataLoader()
    dl.set_basedir(root_path)
    visited_paths = []
    def mock_is_file(path):
        if path in (
            root_path/"nested_dir"/"vars_dir"/"nested_var_file.yml",
            root_path/"nested_dir"/"nested_var_file.yml",
            root_path/"nested_dir"/"vars_dir"/"var_file.yml",
            root_path/"nested_dir"/"var_file.yml",
            root_path/"nested_dir"/"vars_dir",
            root_path/"nested_dir",
        ):
            return True
        return

# Generated at 2022-06-11 08:36:59.584487
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    loader = DataLoader()

    # setup vault password and file
    test_file_name = 'test_file'
    tmp_test_file = u'%s/%s' % (C.DEFAULT_LOCAL_TMP, test_file_name)
    with open(tmp_test_file, 'wb') as f:
        f.write(b'this is an encrypted data file')
    vault_password = u'password'

    # create encrypted file
    vault = VaultLib(vault_password)
    kwargs = {
        u'vault_password': vault_password,
        u'format': u'yaml',
        u'vault_id': u'env_vault_password',
    }
    vault_encrypted_file = vault.encrypt(tmp_test_file, **kwargs)

   

# Generated at 2022-06-11 08:37:09.237692
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    import os
    from ansible.vars.reserved import Reserved
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.path import unfrackpath
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    host = Host(name="127.0.0.1")
    group = Group(name="ungrouped")
    group.add_child(host)
    inventory = InventoryManager(loader=loader, sources=['sources.yml'])
    inventory.add_group(group)
    inventory.add_host(host)
    inventory

# Generated at 2022-06-11 08:37:13.152499
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    # test load_from_file method
    data_loader = DataLoader()
    assert data_loader.load_from_file("/dev/null") is None
    assert data_loader.load_from_file("/dev/null", loader=SafeConstructor()) is None


# Generated at 2022-06-11 08:37:18.029042
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    d = DataLoader()
    # todo: write more tests
    assert d.load_from_file(None) == {}
    assert d.load_from_file('') == {}
    assert d.load_from_file(b'asdf') == {}
    assert d.load_from_file(u'asdf') == {}


# Generated at 2022-06-11 08:37:26.317301
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    from ansible.parsing import vault
    import textwrap
    import tempfile
    import shutil
    with tempfile.NamedTemporaryFile(delete=False) as original_file:
        encrypted_file_path = original_file.name
    with tempfile.NamedTemporaryFile(delete=False) as original_file:
        unencrypted_file_path = original_file.name
    with tempfile.NamedTemporaryFile(delete=False) as original_file:
        original_file_path = original_file.name

# Generated at 2022-06-11 08:38:25.277363
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    d = DataLoader()
    test_file_1 = d.find_file("test_output/datatest/test-vars1")
    test_file_2 = d.find_file("test_output/datatest/test-vars2")
    path_1 = d.get_real_file(test_file_1)
    with open(path_1,"r") as f:
        assert f.read() == "Message\n"

    path_2 = d.get_real_file(test_file_2)
    with open(path_2,"r") as f:
        assert f.read() == "Message\n"


# Generated at 2022-06-11 08:38:29.545355
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    loader = DataLoader()

    tmpfile = to_bytes(loader._create_content_tempfile('test'))
    assert os.path.exists(tmpfile)
    loader.cleanup_tmp_file(tmpfile)
    assert not os.path.exists(tmpfile)
