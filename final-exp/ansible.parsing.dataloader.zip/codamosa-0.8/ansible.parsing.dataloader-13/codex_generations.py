

# Generated at 2022-06-11 08:28:53.354036
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    _test_dir = os.path.dirname(__file__)
    test_dir = os.path.normpath(os.path.join(_test_dir, '../../lib/ansible/playbook/play_context.py'))
    data = DataLoader()
    output = data.load_from_file(test_dir)
    assert output[1] == 'JinjaLoader'
    assert output[0].startswith('#!/usr/bin/python')
    test_dir = os.path.normpath(os.path.join(_test_dir, '../../HISTORY.rst'))
    output = data.load_from_file(test_dir)
    assert output[1] == 'YamlLoader'
    assert output[0].startswith('Change history for Ansible')


# Generated at 2022-06-11 08:29:02.323245
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # Only do these tests if YAML is installed
    try:
        from yaml import load, dump, FullLoader # type: ignore
    except ImportError:
        return

    # Create a temp dir and write two test files
    tmpdir = tempfile.mkdtemp()
    test_vars_file = os.path.join(tmpdir, "vars", "main.yml")
    test_vars_file2 = os.path.join(tmpdir, "vars", "test")
    test_env_file = os.path.join(tmpdir, "env.yml")
    test_tasks_file = os.path.join(tmpdir, "tasks", "test.yml")
    os.makedirs(os.path.dirname(test_vars_file))

# Generated at 2022-06-11 08:29:03.678138
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # TODO: Modify as needed
    pass


# Generated at 2022-06-11 08:29:14.576059
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    def load_file(file_name):
        return load_file_to_dict(file_name)

    def load_file_to_dict(file_name):
        data = load_file(file_name)
        return json.loads(json.dumps(data))

    def test_environment():
        os.name = "posix"
        os.sep = "/"
        os.altsep = "/"
        os.pathsep = ":"
        os.curdir = "."

    def test_loader():

        # dir /home/func_test/data/ansible
        home = '/home/func_test'
        ansible_base_dir = os.path.join(home, 'data/ansible')
        # dir /home/func_test/data/ansible/inventory
        inventory_

# Generated at 2022-06-11 08:29:16.942772
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    loader = DataLoader()
    display.verbosity = 3
    display.debug('foo')
    assert isinstance(loader.load_from_file('foo'), dict)

# Generated at 2022-06-11 08:29:24.814086
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    arguments = [
        ('',),
        ('/dev/null',),
        ('/etc/passwd',),
        ('/etc/group',),
        ('/etc/shadow',),
        ('/etc/gshadow',),
        ('/etc/subuid',),
        ('/etc/subgid',),
    ]
    for args in arguments:
        try:
            dl = DataLoader()
            dl.load_from_file(*args)
        except AnsibleParserError:
            pass

# Generated at 2022-06-11 08:29:30.321936
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    dl = DataLoader()
    f = dl.get_real_file('/etc/group', decrypt=False)
    assert dl._tempfiles == set([f])
    dl.cleanup_tmp_file(f)
    assert dl._tempfiles == set()
    assert dl.cleanup_tmp_file(f) is None



# Generated at 2022-06-11 08:29:39.798273
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    # Testing that the DataLoader code creates a temporary file.
    # This is accomplished by creating a temporary file, adding it to the
    # list of temporary files, and then calling cleanup_all_tmp_files which
    # deletes them.
    dl = DataLoader()

    # Create a temporary file.
    fd, content_tempfile = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    f = os.fdopen(fd, 'wb')
    f.close()

    # Add the file to the list of temporary files.
    dl._tempfiles.add(content_tempfile)

    # Call the cleanup function.
    dl.cleanup_all_tmp_files()

    # Test that the file has been deleted.

# Generated at 2022-06-11 08:29:49.058964
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    ##############################################
    # Unit test for method cleanup_tmp_file of class DataLoader
    ##############################################

    ##
    ## PARAMETERS
    ##
    # File name to test clean up
    test_file_name = "DataLoader-cleanup_tmp_file-test-file"
    # Variables to test
    test_vars = dict(
        test_var1=1,
        test_var2=2,
        test_var3=3,
    )
    # Data to test

# Generated at 2022-06-11 08:30:00.496776
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    '''
    Ensure DataLoader().cleanup_tmp_file() works as expected.
    '''
    import unittest

    class TestCleanupTmpFile(unittest.TestCase):
        '''
        Test DataLoader().cleanup_tmp_file()
        '''

        def setUp(self):
            # test that the DataLoader is empty before test
            test_loader = DataLoader()
            self.assertFalse(test_loader.tempfiles)
            # create a file that will be used by all tests
            fd, test_file = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
            self.test_file_path = test_file  # save as a class variable
            f = os.fdopen(fd, 'wb')
            f.write(to_bytes("Test"))

# Generated at 2022-06-11 08:30:31.894640
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    loader = DataLoader().load_from_file('/opt/ansible/docker/manifest/roles/dev/defaults/main.yml')
    loader.get_real_file('/opt/ansible/docker/manifest/include/core.yml')
    loader.cleanup_all_tmp_files()

# Generated at 2022-06-11 08:30:37.304403
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    dloader = DataLoader()
    fake_loader = '---\n- hosts: localhost\ntasks:\n  - debug: msg={{ giblets }}\n'
    assert dloader.load_from_file(to_bytes(fake_loader, errors='strict')) == [{'hosts': 'localhost', 'tasks': [{'debug': {'msg': '{{ giblets }}'}}]}], 'Incorrect load_from_file data'


# Generated at 2022-06-11 08:30:48.685709
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # Create the object
    from ansible.plugins.loader import DataLoader
    from ansible.cli.playbook import PlaybookCLI
    from ansible.plugins.loader import load_plugins
    from ansible.config.manager import ConfigManager
    from ansible.constants import CONFIG_DATA_SOURCES
    from ansible.constants import DEFAULTS
    from collections import namedtuple

    # To make sure the default value of look_for_vars_files is True
    config_data_sources = namedtuple('ConfigDataSources', 'look_for_vars_files')(True)

    config_manager = ConfigManager(load_sources=config_data_sources,
                                   config_file=DEFAULTS.plugins_path[0] + '/../../test/vars_files.cfg')


# Generated at 2022-06-11 08:30:52.008260
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # Loader find_vars_files()

    # Method is only defined in DataLoader class but not other classes so we skip test
    pass

# Generated at 2022-06-11 08:31:02.497544
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # mock class
    class MockVault(object):
        def __init__(self, secrets):
            self.secrets = secrets

        def decrypt(self, src, filename=None):
            return src

    class_loader = DataLoader()
    class_loader._vault = MockVault(secrets=None)
    filepath = "testfile.yml"
    with pytest.raises(AnsibleParserError) as excinfo:
        class_loader.get_real_file(None)
    assert "Invalid filename: 'None'" in str(excinfo.value)
    with pytest.raises(AnsibleParserError) as excinfo:
        class_loader.get_real_file(1)
    assert "Invalid filename: '1'" in str(excinfo.value)

# Generated at 2022-06-11 08:31:08.440192
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # init dataloader
    dataloader = DataLoader()
    # init name
    name = 'test'
    # init path
    path = './'
    assert dataloader.find_vars_files(path, name) == ['./test']

    # init path
    path = '~/'
    assert dataloader.find_vars_files(path, name) == ['~/test']


# Generated at 2022-06-11 08:31:18.353726
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    dl = DataLoader()
    assert dl.path_dwim_relative("/tmp", "templates", "abc") == "/tmp/templates/abc"
    assert dl.path_dwim_relative("/tmp", "templates", "abc", is_role=True) == "/tmp/templates/abc"
    assert dl.path_dwim_relative("/tmp/roles/myrole/tasks", "templates", "abc", is_role=True) == "/tmp/roles/myrole/templates/abc"
    assert dl.path_dwim_relative("/tmp/roles/myrole/tasks", "templates", "abc") == "/tmp/roles/myrole/templates/abc"

# Generated at 2022-06-11 08:31:20.261620
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    assert False, "No test written for DataLoader.find_vars_files"

# Generated at 2022-06-11 08:31:27.198216
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    data_loader = DataLoader()

    try:
        data_loader.cleanup_tmp_file(None)
    except AnsibleParserError:
        pass

    try:
        data_loader.cleanup_tmp_file("")
    except AnsibleParserError:
        pass

    fake_file = "/tmp/fake_file"
    try:
        data_loader.cleanup_tmp_file(fake_file)
    except AnsibleParserError:
        pass


# Generated at 2022-06-11 08:31:35.873898
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    loader= DataLoader()
    assert loader.find_vars_files(u'/Users/andrew/Downloads/ansible-2.6.5/lib/ansible/plugins/action',u'debug') == ['/Users/andrew/Downloads/ansible-2.6.5/lib/ansible/plugins/action/debug.yaml','/Users/andrew/Downloads/ansible-2.6.5/lib/ansible/plugins/action/debug.json']
    path = './ansible/plugins/lookup/'
    assert loader.find_vars_files(path,u'vault') == [path+u'vault.py']

# Generated at 2022-06-11 08:31:59.376313
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    content = b'File content'
    encrypted_content = b'!vault |\n' + encrypt_bytes(content, b'password')

    # With incorrect file path
    dl = DataLoader()
    with pytest.raises(AnsibleFileNotFound):
        dl.get_real_file(None)
    with pytest.raises(AnsibleFileNotFound):
        dl.get_real_file(1)
    with pytest.raises(AnsibleFileNotFound):
        dl.get_real_file(True)
    with pytest.raises(Exception):
        dl.get_real_file(set())

    # With incorrect file
    dl = DataLoader()
    with pytest.raises(AnsibleFileNotFound):
        dl.get_real_

# Generated at 2022-06-11 08:32:03.407657
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    #create empty object of class DataLoader
    obj = DataLoader()
    #check if the method cleanup_all_tmp_files of class DataLoader is working correctly
    try:
        #try to delete all the temporary files
        obj.cleanup_all_tmp_files()
    except Exception as e:
        ansible_module_fail_json(e)

# Generated at 2022-06-11 08:32:12.658695
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():

    loader = DataLoader()
    basedir = os.path.join(os.path.dirname(__file__), '..', 'data', 'test_vars_files')
    path = os.path.join(basedir, 'project')
    extension = 'yml'


# Generated at 2022-06-11 08:32:16.563312
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    '''
    Unit test for method cleanup_all_tmp_files of class DataLoader
    '''
    loader = DataLoader()

    try:
        test_cleanup_all_tmp_files(loader)
    finally:
        loader.cleanup_all_tmp_files()



# Generated at 2022-06-11 08:32:19.182428
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    DataLoader.get_real_file(file_path, decrypt=True)
    DataLoader.get_real_file(file_path, decrypt=False)

# Generated at 2022-06-11 08:32:19.742855
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    assert True
    

# Generated at 2022-06-11 08:32:24.847470
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
  # Initialize a DataLoader object
  load = DataLoader()

  # test_paths_1:
  #     Relative paths to play in eval_data_from_path
  test_paths_1 = [
    '../../playbook.yml',
    '../../roles/foo/tasks/bar.yml',
    '../../roles/foo/meta/main.yml'
    ]

  # test_ basedir_1:
  #     base directory for test_paths_1
  test_basedir_1 = '/Users/user01/ansible/roles/test/tasks'

  # test_dirname_1:
  #     Dirname to be prepended to the source file
  test_dirname_1 = 'templates'

  # test_file_1:
  #    

# Generated at 2022-06-11 08:32:35.559002
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    display = Display()
    display.verbosity = 2
    loader = DataLoader()
    def mock_load_resource(cls, path):
        return '{"a":[]}'
    loader.load_resource = types.MethodType(mock_load_resource, loader)
    def mock_path_exists(cls, path):
        return True
    loader.path_exists = types.MethodType(mock_path_exists, loader)
    def mock_is_file(cls, path):
        return True
    loader.is_file = types.MethodType(mock_is_file, loader)
    def mock_os_unlink(path):
        print(path)
    os.unlink = mock_os_unlink

# Generated at 2022-06-11 08:32:47.450428
# Unit test for method cleanup_all_tmp_files of class DataLoader

# Generated at 2022-06-11 08:32:56.068487
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # Test with file that is not encrypted
    content = "This is unencrypted test content"
    fd, path = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    f = os.fdopen(fd, 'wb')
    f.write(content)
    f.close()

    data_loader = DataLoader()
    data_loader._tempfiles = set()
    real_path = data_loader.get_real_file(path)

    # Check that the file was not decrypted
    with open(real_path, 'rb') as f:
        data = f.read()

    assert data == content

    # Test with file that is encrypted
    content = "This is encrypted test content"

# Generated at 2022-06-11 08:33:24.846821
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    """
    Tests method path_dwim_relative_stack of class DataLoader
    """
    print("\nTESTING path_dwim_relative_stack:")

    with open(test_file_name, "w") as f:
        f.close()

    loader = DataLoader()
    print("default basedir: %s" % loader.get_basedir())
    print("default path: %s" % os.path.abspath(test_file_name))

    assert loader.get_basedir() == CWD
    assert os.path.abspath(test_file_name) == loader.path_dwim_relative_stack([os.path.abspath(test_file_name)], 'templates', test_file_name)

    # Change basedir, then change back
    os.ch

# Generated at 2022-06-11 08:33:33.354928
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
  import tempfile
  dl = DataLoader()
  tempfiles = []
  for i in range(2):
    tempfiles.append(tempfile.mkstemp(prefix="test_dataloade_cleanup_all_tmp_files", dir=C.DEFAULT_LOCAL_TMP)[1])
  dl._tempfiles = set(tempfiles)
  assert len(dl._tempfiles) == 2
  dl.cleanup_all_tmp_files()
  assert len(dl._tempfiles) == 0
  for t in tempfiles:
    assert not os.path.exists(t)


# Generated at 2022-06-11 08:33:37.367634
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    data_loader = DataLoader()
    data_loader._tempfiles.add('/tmp/myfile')
    assert len(data_loader._tempfiles) == 1
    data_loader.cleanup_all_tmp_files()
    assert len(data_loader._tempfiles) == 0

# Generated at 2022-06-11 08:33:44.033373
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
  path = 'c:/def/a.txt'
  try:
    os.remove(path)
  except:
    pass
  with open(path, 'w') as f:
    f.write('xyz')
  file_loader = DataLoader()
  f = file_loader.get_real_file(path)
  assert file_loader.is_file(f)
  assert file_loader.get_real_file(path) == f
  file_loader.cleanup_all_tmp_files()
  assert file_loader.get_real_file(path) != f
  assert not file_loader.is_file(f)



# Generated at 2022-06-11 08:33:55.304205
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    vault_pass = None
    loader = DataLoader()
    vars_mgr = VariableManager(loader=loader)
    loader.set_vault_secrets(['vault-pass'])
    vault_id = VaultLib('vault-pass', loader=loader)
    # pylint: disable=unused-variable
    def _get_real_file(filename, decrypt=True):
        return loader.get_real_file(filename, decrypt)
    # pylint: disable=unused-variable
    def _cleanup_tmp_file(filename):
        return loader.cleanup_tmp_file(filename)
    # pylint: disable=unused-variable

# Generated at 2022-06-11 08:33:58.151406
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    loader = DataLoader()
    file_path = loader.get_real_file('/playbooks/playbook1.yml')
    loader.cleanup_tmp_file(file_path)

# Generated at 2022-06-11 08:34:08.035162
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    # Unit tests for DataLoader.cleanup_all_tmp_files
    # These tests are a bit slower than the others so we'll only run them if specifically requested
    import os
    import tempfile

    class DummyLoader(DataLoader):
        '''
        Dummy loader to test the cleanup, initializes and returns a test set class
        '''
        def __init__(self, basedir):
            self.paths = []
            self.basedir = basedir
            self.set_basedir(basedir)

        def _create_content_tempfile(self, content):
            ''' Create a tempfile containing defined content '''
            fd, content_tempfile = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
            f = os.fdopen(fd, 'wb')

# Generated at 2022-06-11 08:34:12.089645
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    loader = DataLoader()
    assert isinstance(loader, DataLoader)

    new_tempfile = loader._create_content_tempfile('This is a test')
    assert os.path.isfile(new_tempfile)
    assert new_tempfile in loader._tempfiles

    loader.cleanup_tmp_file(new_tempfile)
    assert new_tempfile not in loader._tempfiles
    assert not os.path.isfile(new_tempfile)


# Generated at 2022-06-11 08:34:15.485674
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    arg1 = None
    arg2 = None
    arg3 = None
    arg4 = None
    loader = DataLoader()
    loader.path_dwim_relative_stack(arg1, arg2, arg3, arg4)


# Generated at 2022-06-11 08:34:23.841881
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # ensures that calling find_vars_files will return a list of filepaths
    # that match the filename pattern and suffixes passed in.
    mock_loader = DataLoader()

    # get a temp directory to work with
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_dir = os.path.dirname(tmp_file.name)
    tmp_file.close()

    # create mock dir with yaml/json files to search
    mock_dirname = os.path.join(tmp_dir, 'mock_vars_files')
    os.makedirs(mock_dirname)


# Generated at 2022-06-11 08:35:25.666579
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    DataLoader = Mock()
    DataLoader._tempfiles = set()
    DataLoader.cleanup_tmp_file = Mock(return_value=None)
    DataLoader.cleanup_all_tmp_files()

# Generated at 2022-06-11 08:35:36.044088
# Unit test for method cleanup_all_tmp_files of class DataLoader

# Generated at 2022-06-11 08:35:43.986861
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    from collections import defaultdict
    from ansible.parsing.vault import VaultLib
    # Encrypted data
    test_data = b'$ANSIBLE_VAULT;1.1;AES256'
    # Set up a test vault to read the data
    test_vault = VaultLib(b'my-secret', loader=DataLoader())
    # Perform the decryption
    test_decrypted = test_vault.decrypt(test_data)
    # Create the temp file
    test_tmp_file = DataLoader()._create_content_tempfile(test_decrypted)
    # Load the temp file
    test_tmp_data = DataLoader().load_from_file(test_tmp_file)

    assert test_decrypted == test_tmp_data
    # Remove the temp file
    DataLoader().cleanup_tmp

# Generated at 2022-06-11 08:35:54.671048
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    loader = DataLoader()
    # Create a temp file
    fd, content_tempfile = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    f = os.fdopen(fd, 'wb')
    s = 'test file content'
    f.write(s)
    f.close()
    # Add temp file to tempfiles of loader
    loader._tempfiles.add(content_tempfile)
    # Call cleanup
    loader.cleanup_all_tmp_files()
    assert not loader._tempfiles
    # Check if file is no longer present
    assert not os.path.isfile(content_tempfile)

# Generated at 2022-06-11 08:36:01.468566
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    dl = DataLoader()
    paths = dl.find_vars_files(u'.', u'../test/test_data', extensions=u'.yaml')
    assert paths == [b'../test/test_data/test_vars_files.yaml', b'../test/test_data/test_vars_files.yml'], "Failed to find file ../test/test_data/test_vars_files.yaml and ../test/test_data/test_vars_files.yml in path ./"



# Generated at 2022-06-11 08:36:11.124233
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    #
    # Unit test for method cleanup_tmp_file of class DataLoader
    #
    # setup
    loader = DataLoader()

    cache = {
        'files': [],
        'temppaths': []
    }

    from ansible.parsing import vault
    vault_secrets = ['SOME_PASSWORD']
    vault_password_files = ['SOME_PASSWORD_FILE']
    vault_mixed = ['SOME_PASSWORD', 'SOME_PASSWORD_FILE']

    # test the read_vaulted_files decorator
    @loader.read_vaulted_files
    def my_func_vault_decorator_1(files, cache):
        cache['files'].extend(files)


# Generated at 2022-06-11 08:36:20.595791
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    ''' test the DataLoader cleanup_all_tmp_files method '''

    loader = ansible.parsing.dataloader.DataLoader()
    #this should work with a blank array
    loader._tempfiles.clear()

    #create a duplicate array to ensure it's resets after the call
    test_files = loader._tempfiles.copy()
    loader.cleanup_all_tmp_files()
    assert test_files == loader._tempfiles

    # This is a blank array at this point but lets reset it
    loader._tempfiles.clear()
    test_files = loader._tempfiles.copy()
    # Lets put some files in it
    fd, test_file1 = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    if fd:
        os.close(fd)


# Generated at 2022-06-11 08:36:31.579962
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():

    # Testing with a mock object which has an attribute 'path' and 'path_module'
    class mock_obj:
        def __init__(self, path, path_module):
            self.path = path
            self.path_module = path_module

    # Testing with a mock object which has an attribute 'path' and 'path_module'
    class mock_role_obj:
        def __init__(self, path):
            self.path = path

    # Tests with a test datalist and expected result list

# Generated at 2022-06-11 08:36:32.730110
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    raise NotImplementedError()

# Generated at 2022-06-11 08:36:33.409750
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    pass

# Generated at 2022-06-11 08:38:15.521263
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    # create a DataLoader object
    data_loader_obj = DataLoader()
    # call the cleanup_tmp_file() method to clean the temporary files
    data_loader_obj.cleanup_tmp_file('tempfile')
    # verify that an error has been raised
    assert False

# Generated at 2022-06-11 08:38:24.856776
# Unit test for method cleanup_all_tmp_files of class DataLoader

# Generated at 2022-06-11 08:38:29.912465
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    try:
        DataLoader.get_real_file("/tmp/.ansible/tmp/ansible-local-74096ra2flr/tmpNrjJuB")
    except SystemExit:
        assert False

    try:
        DataLoader.get_real_file(".ssh/id_rsa")
    except SystemExit:
        assert True

