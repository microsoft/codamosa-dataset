

# Generated at 2022-06-20 23:07:13.374998
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    cli = Mock()
    cli.get_opt.return_value = True
    cli.options = Mock()
    cli.options.tags = None
    loader = DataLoader()
    loader.set_vault_secrets(['default'])
    ret = loader.is_file('/tmp/ansible-test/fake')
    assert ret == True



# Generated at 2022-06-20 23:07:14.479915
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
    pass # test scaffolding

# Generated at 2022-06-20 23:07:26.735688
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # Test function with valid arguments
    # Other valid cases:
    # * path: '/a/b/c', name: 'x/y/z', extensions=['']
    # * path: '/a/b/c', name: 'x', extensions=['a','b','c']
    # * path: '/a/b/c', name: 'x', extensions=[]
    # * path: '/a/b/c', name: '', extensions=['a','b','c']
    path='/a/b/c'
    name='x'
    extensions=['', 'a', 'b', 'c']
    result = DataLoader().find_vars_files(path, name, extensions)
    assert result == [], 'Incorrect result returned: %s' % result
    return



# Generated at 2022-06-20 23:07:35.642059
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    from ansible.parsing import vault
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleParserError
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    import os.path
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    def test_data_resolve():
        ds = DataSource(basedir='.', vault_password='secret')
        ds.set_basedir('/etc/ansible/roles/test')

# Generated at 2022-06-20 23:07:48.861561
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedString
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    import tempfile
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-20 23:07:52.169170
# Unit test for method set_vault_secrets of class DataLoader
def test_DataLoader_set_vault_secrets():
    loader = DataLoader()
    secrets = {"fake_client": "fake-secret"}
    loader.set_vault_secrets(secrets)
    assert loader._vault.secrets == secrets


# Generated at 2022-06-20 23:07:54.654357
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    # FIXME: Implement
    # Called from RoleInclude.load to load data from a file or directory
    pass

# Generated at 2022-06-20 23:07:56.531724
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    loader = DataLoader()
    print (loader.list_directory('./'))

# Generated at 2022-06-20 23:07:59.254226
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    data_loader = DataLoader()
    if data_loader.is_directory("/a"):
        print("is_directory() is working.")
    else:
        print("is_directory() is not working.")

# Generated at 2022-06-20 23:08:10.858577
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    ################################################################################
    # Unit test for method is_file of class DataLoader
    #------------------------------------------------------------------------------
    # This method will return true if the file exists, false otherwise

    # create a test directory
    path = tempfile.mkdtemp()
    base_name = os.path.basename(path)
    name = 'test.yml'
    full_name = os.path.join(path, name)
    d = DataLoader()
    os.mkdir(full_name)

    # a path to a non existing file
    result = d.is_file(base_name + 'nofile.yml')
    assert False == result, 'is_file should return False if the file does not exist'

    # a directory
    result = d.is_file(base_name)

# Generated at 2022-06-20 23:08:29.042632
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    """Test for method path_dwim_relative of class DataLoader."""
    # pylint: disable=no-self-use
    from ansible.errors import AnsibleError
    a = DataLoader()
    b = a.path_dwim_relative('/my/path/to/tasks/main.yml', 'templates', 'stuff.j2')
    assert b == '/my/path/to/templates/stuff.j2'
    c = a.path_dwim_relative('/my/path/to', 'templates', 'stuff.j2')
    assert c == '/my/path/to/templates/stuff.j2'
    d = a.path_dwim_relative('/my/path/to', 'templates', '../stuff.j2')

# Generated at 2022-06-20 23:08:31.677541
# Unit test for method get_basedir of class DataLoader
def test_DataLoader_get_basedir():
    dl = DataLoader()
    assert dl.get_basedir() == '.'


# Generated at 2022-06-20 23:08:33.141169
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    expected = True
    path = '/etc/ansible'
    loader = DataLoader('./tests/fixtures/ansible')
    assert loader.is_directory(path) == expected, 'is_directory failed'

# Generated at 2022-06-20 23:08:33.829843
# Unit test for constructor of class DataLoader
def test_DataLoader():
    pass

# Generated at 2022-06-20 23:08:38.205629
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    # Test function...

    # Test basic function (no match)
    loader = DataLoader()
    loader.path_dwim_relative_stack(['paths/', 'paths/not tasks'], 'dirname', 'source', is_role=False)


# Generated at 2022-06-20 23:08:44.346915
# Unit test for method is_executable of class DataLoader
def test_DataLoader_is_executable():
    dl = DataLoader()
    assert dl.is_executable('/bin/ls') == True
    assert dl.is_executable('/bin/ls1', False) == False
    assert dl.is_executable('/bin/ls1') == False
    assert dl.is_executable('/bin/dummy_file') == False
    assert dl.is_executable('/dummy/dummy_file') == False
    assert dl.is_executable('/bin/') == False
    assert dl.is_executable('/') == False
    assert dl.is_executable('') == False
    assert dl.is_executable(None) == False


# Generated at 2022-06-20 23:08:50.820736
# Unit test for method load of class DataLoader
def test_DataLoader_load():

    dl = DataLoader()

    # noinspection PyUnusedLocal
    def test_loader_load(path):
        # type: (str) -> str
        return "test_loader_load"

    dl._loader = {
        'test_loader': test_loader_load
    }

    assert dl.load("test_loader://testing") == "test_loader_load"


# Generated at 2022-06-20 23:09:03.202731
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    from ansible.errors import AnsibleParserError
    from ansible.plugins.loader import vars_loader

    dl = DataLoader()
    vars_loader.add_directory(dl, os.path.join(os.path.dirname(__file__), u'vars_loader'))
    dl.set_basedir(os.path.join(os.path.dirname(__file__), u'vars_loader'))

    assert dl.find_vars_files(u'roles/role2', u'role2.vars') == [os.path.join(os.path.dirname(__file__), u'vars_loader/roles/role2/role2.vars.yml')]

# Generated at 2022-06-20 23:09:11.799787
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    yaml_vars_files = '''
- test.yml
- test2.yml
- test.yaml
- .test
- .test.yml
- .test.yaml
- test~
- ~test.yml
- ~test.yaml
- ~test
- test/.test
- test/test.yml
- test/test.yaml
- test/test
- test/.test.yml
- test/.test.yaml
- test/~test.yml
- test/~test.yaml
- test/.test
- test/~test
'''.split()

    mock_list_directory = Mock(return_value=yaml_vars_files)
    with patch.object(DataLoader, 'list_directory'):
        DataLoader.list_directory = mock_list_directory



# Generated at 2022-06-20 23:09:14.710881
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    loader = DataLoader()
    file_path = 'roles/common/tasks/main.yml'
    assert loader.is_file(file_path) == True


# Generated at 2022-06-20 23:09:49.307495
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    loader = DataLoader()

    module_utils_paths = ('/a:/b:/c:/d:/e', '/x:/y:/z:/w')
    module_utils_paths = [to_bytes(p, errors='surrogate_or_strict') for p in module_utils_paths]

    data = to_bytes("""{
    "module_utils_paths": "%s"
}
""" % ','.join(module_utils_paths))

    res = loader.load_from_file(data)
    assert res['module_utils_paths'] == module_utils_paths



# Generated at 2022-06-20 23:09:59.686695
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    loader = DataLoader()
    res = loader.path_dwim_relative_stack(["/etc/ansible/roles/role1/tasks/main.yml", "/etc/ansible/roles/role1/tasks"], "templates", "foo.j2")
    assert res == "/etc/ansible/roles/role1/templates/foo.j2", res
    res = loader.path_dwim_relative_stack(["/etc/ansible/roles/role1/tasks/main.yml", "/etc/ansible/roles/role1/tasks"], "templates", "/etc/foo.j2")
    assert res == "/etc/foo.j2", res

# Generated at 2022-06-20 23:10:12.136461
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    def test_impl(path, dirname, source, is_role):
        dl = DataLoader()
        dl.set_basedir('/var/vcap/packages/k8s-api-server/charts')
        return dl.path_dwim_relative(path, dirname, source, is_role)

    assert test_impl('/var/vcap/packages/k8s-api-server/charts/k8s-api-server', 'templates', 'kubeconfig.yaml', True) == '/var/vcap/packages/k8s-api-server/charts/templates/kubeconfig.yaml'

# Generated at 2022-06-20 23:10:22.940577
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    dl = DataLoader()
    fpath = dl._create_content_tempfile('wibble')
    assert os.path.exists(fpath)
    dl._tempfiles.add(fpath)
    dl.cleanup_all_tmp_files()
    assert not os.path.exists(fpath)
    assert not dl._tempfiles

    # Test removing a file that does not exist (no exception should be raised)
    dl._tempfiles.add('/does/not/exist')
    dl.cleanup_all_tmp_files()
    assert not dl._tempfiles

# Generated at 2022-06-20 23:10:28.971364
# Unit test for method get_basedir of class DataLoader
def test_DataLoader_get_basedir():
    from ansible.utils import path
    #path.FILENAME_CACHE = dict()
    file_name = "foo"
    dl = DataLoader()

    # Setup arguments
    # Doesn't use args

    # Test
    result = dl.set_basedir(file_name)

    # Verify
    assert result == dl._basedir


# Generated at 2022-06-20 23:10:32.192459
# Unit test for method is_executable of class DataLoader
def test_DataLoader_is_executable():
    # Create a new DataLoader(c) instance
    c = AnsibleContext(loader_class=DataLoader)
    dl = DataLoader.load(c)

    # No path is given
    assert dl.is_executable(None) == False

    # Path to executable is given
    assert dl.is_executable('/bin/bash') == True


# Generated at 2022-06-20 23:10:39.137948
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
    # test existing file
    file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test', 'fixtures', 'examples', 'ansible.cfg')
    dl = DataLoader()
    assert dl.path_exists(file_path), "path_exists should return True for an existing file"
    
    # test non existing file
    file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'test', 'fixtures', 'examples', 'ansible.cf')
    dl = DataLoader()
    assert not dl.path_exists(file_path), "path_exists should return False for an non existing file"
    
    # test existing directory
    file_path = os.path

# Generated at 2022-06-20 23:10:40.869725
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    pass # nothing to test

# Generated at 2022-06-20 23:10:45.395958
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # Test a non-existing filename
    file_path = 'non-existing'
    loader = DataLoader()
    with pytest.raises(AnsibleFileNotFound):
        loader.get_real_file(file_path)
    return


# Generated at 2022-06-20 23:10:55.278517
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    import os
    import json

    data = DataLoader()
    data.set_basedir("/home/work/ansible/testdir/")
    # return a tuple of (loader, list_of_tasks, cache)
    loader, tasks, cache = data.load("/home/work/ansible/testdir/test.yaml")

    assert loader

    if os.path.exists("/home/work/ansible/testdir/test.py"):
        os.remove("/home/work/ansible/testdir/test.py")

    if os.path.exists("test.pyc"):
        os.remove("test.pyc")


# Generated at 2022-06-20 23:11:23.500858
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    # Instantiate the specified class
    class_instance = DataLoader()
    # Always use class-level setup and teardown methods
    @classmethod
    def setup_class():
        pass
    @classmethod
    def teardown_class():
        ansible_vault_cleanup()
    class_instance.setup_class = setup_class
    class_instance.teardown_class = teardown_class
    # Use a non-default Ansible vault password file
    if hasattr(class_instance, '_vault'):
        class_instance._vault.password_file = os.path.join(
            ansible_vault_dir, 'password_file'
        )
    # Instantiate the arguments
    path = '/foo/bar/baz'
    dirname = 'meta'

# Generated at 2022-06-20 23:11:37.285559
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    test_dir = tempfile.mkdtemp()
    test_dir_path = os.path.join(test_dir, 'mydir')
    test_dir_path_with_dot = os.path.join(test_dir, '.mydir')
    test_dir_path_with_dot_2 = os.path.join(test_dir, 'mydir.py')
    test_dir_path_with_dot_3 = os.path.join(test_dir, 'mydir.py_dev')
    os.chdir(test_dir)
    os.makedirs(test_dir_path)
    os.makedirs(test_dir_path_with_dot)
    # make files with different extensions
    temp = tempfile.NamedTemporaryFile(dir=test_dir, suffix='.yml')


# Generated at 2022-06-20 23:11:42.088788
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
    '''
    Check if `DataLoader` can find a path.
    '''
    loader = DataLoader()
    fake_path = 'does/not/exist'
    assert not loader.path_exists(fake_path)
    # Unit test for method list_directory of class DataLoader

# Generated at 2022-06-20 23:11:51.552362
# Unit test for method path_dwim of class DataLoader
def test_DataLoader_path_dwim():
    data = u'foo: bar\n'
    (test_dir, test_path) = tempfile.mkstemp()
    test_dir = to_text(test_dir)
    test_path = to_text(test_path)

    with open(to_bytes(test_path), 'wb') as tmp_file:
        tmp_file.write(to_bytes(data))

    dloader = DataLoader()

    assert dloader.path_dwim(test_path) == test_path

    os.remove(to_bytes(test_path))

    # ensure the test_path does not exist
    assert not os.path.exists(to_bytes(test_path))

    os.rmdir(to_bytes(test_dir))

# Generated at 2022-06-20 23:11:54.951820
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # Test is role
    # Test find file with extension
    # Test find file with no extension
    # Test find dir first (no path)
    # Test find dir first (with path)
    pass



# Generated at 2022-06-20 23:12:01.546478
# Unit test for constructor of class DataLoader
def test_DataLoader():
    loader = DataLoader()
    # no basedir; should not raise
    loader.path_exists('')

    loader = DataLoader(basedir='/foo')
    # non-existant path under basedir; should not raise
    loader.path_exists('')

    with pytest.raises(AnsibleFileNotFound):
        loader.path_exists('/bar')



# Generated at 2022-06-20 23:12:13.236775
# Unit test for method path_dwim of class DataLoader
def test_DataLoader_path_dwim():
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    subfolder_file_name = 'test.txt'
    subfolder_file_path = cur_dir + '/' + subfolder_file_name
    parentfolder_file_path = os.path.dirname(cur_dir) + '/' + subfolder_file_name
    subfolder_file_path_in_parentfolder = 'tests/' + subfolder_file_name
    subfolder_file_path_in_curfolder = './' + subfolder_file_name
    subfolder_file_path_in_dots_folder = '././tests/./test.txt'
    file_path_in_dot_dot_folder = '../test.txt'


# Generated at 2022-06-20 23:12:14.536461
# Unit test for method set_basedir of class DataLoader
def test_DataLoader_set_basedir():
    loader = DataLoader()
    loader.set_basedir('/tmp')

# Generated at 2022-06-20 23:12:21.376028
# Unit test for method path_dwim of class DataLoader
def test_DataLoader_path_dwim():
    args = []
    if len(args) == 0:
        args.append(None)
    if len(args) == 1:
        args.append(None)
    with mock.patch.object(builtins, 'open') as mock_open:
        mock_open.return_value = None
        dl = DataLoader()
        assert dl.path_dwim(*args) == None

# Generated at 2022-06-20 23:12:29.158043
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    arguments = [
        [
            os.path.join('dir1', 'dir2', 'dir3', 'dir4', 'file.yml'),
            True
        ]
    ]
    return_value = None
    with mock.patch('os.path.isfile') as patched_isfile:
        patched_isfile.return_value = True
        for args in arguments:
            return_value = DataLoader._is_file(*args)
            assert return_value == arguments[0][1]


# Generated at 2022-06-20 23:12:57.401696
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    with pytest.raises(AnsibleParserError):
        dl = DataLoader()
        dl.load_from_file(1)

# Generated at 2022-06-20 23:13:06.287273
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    loader = DataLoader()

    # Test when neither tasks/meta are in the path
    assert '[Errno 2] No such file or directory' not in loader.path_dwim_relative('/path/to/role', 'files', 'file_relative_to_role')
    assert loader.path_dwim_relative('/path/to/role', 'files', 'file_relative_to_role') == '/path/to/role/files/file_relative_to_role'

    # Test when tasks is in the path
    assert '[Errno 2] No such file or directory' not in loader.path_dwim_relative('/path/to/role/tasks', 'files', 'file_relative_to_role')

# Generated at 2022-06-20 23:13:10.263732
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    tmp_file = '/tmp/tmp_file'
    open(tmp_file, 'w').close()
    loader = DataLoader()
    loader._tempfiles = set([tmp_file])
    loader.cleanup_tmp_file(tmp_file)
    assert len(loader._tempfiles) == 0
    os.remove(tmp_file)

# Generated at 2022-06-20 23:13:16.180928
# Unit test for method path_dwim of class DataLoader
def test_DataLoader_path_dwim():
    data_loader = DataLoader()
    # File exists, no special characters or spaces
    path = 'some/path'
    result = data_loader.path_dwim(path)
    assert type(result) == text_type
    assert result == path
    # File does not exist, exists when expanded
    path = '~/some/path'
    expected_result = expanduser('~') + '/some/path'
    result = data_loader.path_dwim(path)
    assert type(result) == text_type
    assert result == expected_result
    # File exists, contains special characters
    path_with_spaces = 'some/path with spaces'
    path_without_spaces = 'some/path\ with\ spaces'
    result = data_loader.path_dwim(path_with_spaces)

# Generated at 2022-06-20 23:13:24.865289
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    # Given
    data_loader = DataLoader()

    # When
    # DataLoader.load_from_file is not implemented

    # Then
    with pytest.raises(NotImplementedError) as excinfo:
        data_loader.load_from_file('test_file_path')
    assert 'The load_from_file class method must be implemented by the subclass.' == str(excinfo.value)


# Generated at 2022-06-20 23:13:29.425594
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    fixture = os.path.join(fixtures_path, 'loader', 'is_file')
    loader = DataLoader()

    tests = [
        ('existing_file.yaml', True),
        ('existing_directory', False),
        ('existing_directory/subdir', False),
        ('existing_directory/subdir/subsubdir', False),
        ('existing_directory/subdir/subsubdir/file.yml', True),
        ('existing_directory/subdir/subsubdir/file.yaml', False),
        ('existing_directory/subdir/subsubdir/missing_file.yaml', False),
        ('existing_directory/subdir/subsubdir/missing_directory', False),
        ('missing_file.yaml', False),
        ('missing_directory', False),
    ]


# Generated at 2022-06-20 23:13:32.097461
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    loader = DataLoader()
    path = './tests/loader_tests/'
    assert loader.is_directory(path) == True

# Generated at 2022-06-20 23:13:41.789111
# Unit test for method is_executable of class DataLoader
def test_DataLoader_is_executable():
    # Create the mocker
    mocker = Mocker()

    # Set up the mocks
    data = mocker.mock(DataLoader)

    # Path to be queried
    path = os.path.join(ROOT_PATH, 'fixtures', 'facts')

    # Path exists
    expect(os.path.exists(to_bytes(path, errors='surrogate_or_strict'))).result(True)
    
    # Path is executable
    expect(os.access(to_bytes(path, errors='surrogate_or_strict'), os.X_OK)).result(True)

    # Replay the mocks
    with mocker:
        assert data.is_executable(path)


# Generated at 2022-06-20 23:13:51.832952
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    from ..constants import DEFAULT_VAULT_ID_MATCH
    from ..vault import VaultLib
    from ..plugins.loader import get_all_plugin_loaders, get_loader_by_path
    from ..parsing.validate import (
        validate_extra_vars,
        validate_limit,
        validate_inventory_directories,
        validate_tags,
        validate_skip_tags,
    )
    from ..parsing.dataloader import DataLoader
    from ..parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import re

    pattern = re.compile(DEFAULT_VAULT_ID_MATCH, re.IGNORECASE)
    vault_secrets = ['']


# Generated at 2022-06-20 23:14:02.036044
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():

    loader = DataLoader()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()
    f = os.fdopen(fd, 'wb')
    try:
        f.write(b'content')
    except Exception as err:
        os.remove(temp_file)
        raise Exception(err)
    finally:
        f.close()

    # Check the tempfile exists
    assert os.path.isfile(temp_file)

    # Call the cleanup method for the temp_file
    loader.cleanup_tmp_file(temp_file)

    # Check the tempfile doesn't exist anymore
    assert not os.path.isfile(temp_file)


# Generated at 2022-06-20 23:14:40.566000
# Unit test for method path_dwim of class DataLoader
def test_DataLoader_path_dwim():
    loader = DataLoader()
    # Test cases with input arguments:
    #   String filename
    #   String filename, String dirname
    #   String filename, List<String> searchpaths
    #   String filename, String dirname, List<String> searchpaths
    # Test cases with expected output:
    #   Cwd/filename
    #   Cwd/dirname/filename
    #   /path/in/searchpaths/filename
    #   /path/in/searchpaths/dirname/filename
    #   /path/in/searchpaths/filename if not dirname
    #   /path/in/searchpaths/dirname/filename if not dirname
    #   Cwd/filename if not searchpaths
    #   Cwd/dirname/filename if not searchpaths

# Generated at 2022-06-20 23:14:49.149062
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.utils.yaml import from_yaml, to_yaml

    my_vault_secret = 'bogus'
    my_vault_password = 'myvaultpassword'

# Generated at 2022-06-20 23:15:01.510544
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.path import unfrackpath

    # locale.getpreferredencoding is not the same always
    # so, let's force the encoding to be utf-8
    reload(sys)
    sys.setdefaultencoding('utf-8')


# Generated at 2022-06-20 23:15:05.171934
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    # Setup test DataLoader object
    dataLoader = DataLoader()
    dataLoader._basedir = ''

    # Test with default arguments
    dataLoader.is_file('/tmp/sample.yml')


# Generated at 2022-06-20 23:15:06.508254
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    with pytest.raises(AnsibleParserError):
        dl = DataLoader()
        dl.load_from_file('/foo')


# Generated at 2022-06-20 23:15:08.522180
# Unit test for method set_vault_secrets of class DataLoader
def test_DataLoader_set_vault_secrets():
    loader = DataLoader()
    result = loader.set_vault_secrets(u'file')
    assert(result == loader)


# Generated at 2022-06-20 23:15:15.198665
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    print('Testing find_vars_files')
    from ansible.utils.shlex import shlex_split

    # Path is None and empty
    for p in [None, b'']:
        d = DataLoader()
        with pytest.raises(AnsibleParserError) as excinfo:
            d.find_vars_files(p, b'hosts')
        assert 'Invalid filename' in to_text(excinfo.value.message)

    # Fake name
    d = DataLoader()
    assert d.find_vars_files(b'test/integration/', 'hosts') == []

    # Fake name
    d = DataLoader()
    assert d.find_vars_files(b'test/integration/', 'fake') == []

    # Real name
    d = DataLoader()
    assert d

# Generated at 2022-06-20 23:15:21.090771
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    loader = DataLoader()

    # Build tempfile
    _, tf = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    # Add tempfile to DataLoader._tempfiles
    loader._tempfiles.add(tf)

    # Call the loader.cleanup_all_tmp_files() method
    loader.cleanup_all_tmp_files()

    assert tf not in loader._tempfiles



# Generated at 2022-06-20 23:15:32.394879
# Unit test for method path_dwim_relative of class DataLoader

# Generated at 2022-06-20 23:15:44.151230
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # Loader is needed only in this test
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader, sources='')
    play_context = PlayContext()
    loader.set_inventory(inventory)
    loader.set_play_context(play_context)

    # Path is needed only in this test
    path = tempfile.mkdtemp()

    # First test: no directory or file
    # Returned value must be []
    extensions = ['yml','yaml','vars','json','fact','dat','txt','retry']
    assert loader.find_vars_files(path, 'dummy', extensions) == []

    # Second test: only directory
    # Returned value must be []
    os.mk

# Generated at 2022-06-20 23:16:10.810798
# Unit test for method set_vault_secrets of class DataLoader
def test_DataLoader_set_vault_secrets():
    results = []
    loader = DataLoader()
    answers = [
        'foo',
    ]
    results.append(loader.set_vault_secrets(answers))
    return results[0] == answers[0]

# Generated at 2022-06-20 23:16:15.642478
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    loader = DataLoader()
    path = loader.get_real_file("ansible/test/test.yml")
    loader.cleanup_tmp_file(path)

test_DataLoader_cleanup_tmp_file()

# Generated at 2022-06-20 23:16:26.459168
# Unit test for method is_directory of class DataLoader