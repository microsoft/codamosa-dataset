

# Generated at 2022-06-20 23:06:56.648307
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    loader = DataLoader()
    path = os.getcwd()
    assert False, "Test not implemented"

# Generated at 2022-06-20 23:07:05.121327
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
    from ansible.module_utils._text import to_bytes
    from .file_common import TestAnsibleModule

    # Test with a regular file
    # Test without a trailing slash
    with TestAnsibleModule() as t:
        assert t.loader.path_exists('test/testfile')

    with TestAnsibleModule() as t:
        # Test with a trailing slash
        assert t.loader.path_exists('test/testfile/')

    # Test with a directory
    with TestAnsibleModule() as t:
        assert t.loader.path_exists('test')

    # Test with a directory with a trailing slash
    with TestAnsibleModule() as t:
        assert t.loader.path_exists('test/')

    # Test with a file that does not exist

# Generated at 2022-06-20 23:07:15.567481
# Unit test for constructor of class DataLoader

# Generated at 2022-06-20 23:07:19.031404
# Unit test for method get_basedir of class DataLoader
def test_DataLoader_get_basedir():
    args = {}
    cur_dir = os.getcwd()
    loader = DataLoader()
    result = loader.get_basedir()
    assert result == cur_dir


# Generated at 2022-06-20 23:07:30.739862
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # Mock paths for files and directories to test with
    # Get root path for the project.
    root_path = os.path.dirname(os.path.abspath(__file__))
    # Expected results

# Generated at 2022-06-20 23:07:43.529371
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    dl = DataLoader()
    assert dl.list_directory('/nonexistent/path/') == False
    assert dl.list_directory('./test/lib/data_loader/test_data/test_dir') == sorted(['test_file_1', 'test_file_2', 'test_file_2.txt', 'test_file_3', 'test_file_3.txt', 'test_file_4', 'test_file_4.txt'])

    # Unit test for method path_dwim of class DataLoader
    dl = DataLoader()
    assert dl.path_dwim('/nonexistent/path') == '/nonexistent/path'
    assert dl.path_dwim('~/nonexistent/path') == '~/nonexistent/path'
    assert d

# Generated at 2022-06-20 23:07:44.632342
# Unit test for method get_basedir of class DataLoader
def test_DataLoader_get_basedir():
    loader = DataLoader()
    assert loader.get_basedir() == "~/ansible"


# Generated at 2022-06-20 23:07:56.299621
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    print(current_dir)
    test_playbook = os.path.join(os.path.dirname(current_dir), "playbooks", "test_playbook.yml")
    print(test_playbook)
    loader = DataLoader()
    loader._basedir = current_dir
    print(loader.path_dwim_relative_stack([current_dir], "vars", "role_level_vars.yml", True))
    print(loader.path_dwim_relative_stack([current_dir], "defaults", "role_level_defaults.yml", True))
    print(loader.path_dwim_relative_stack([current_dir], "lib", "library.py", True))

# Generated at 2022-06-20 23:07:56.954101
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    pass

# Generated at 2022-06-20 23:08:03.565273
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    tmp_files = set()
    # Create a test file
    fd, unique_path = tempfile.mkstemp()
    os.close(fd)
    # Make sure the test file is created
    assert(os.path.exists(unique_path))
    # Create a DataLoader object and cleanup
    DataLoader(None, None, None, None, tmp_files).cleanup_tmp_file(unique_path)
    # Test the test file does not exist anymore
    assert(not os.path.exists(unique_path))
    # Test the test file does not exist in the tempfile set anymore
    assert(unique_path not in tmp_files)


# Generated at 2022-06-20 23:08:13.345475
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    d = DataLoader()
    assert d.load({}, u"a_variable") is None


# Generated at 2022-06-20 23:08:25.465067
# Unit test for method set_vault_secrets of class DataLoader
def test_DataLoader_set_vault_secrets():
    # NOTE(galstrom21): New functions should be tested here if they are added to
    # the DataLoader class
    # TODO(galstrom21): Create tests for the rest of the DataLoader class

    display = Display()
    filename = os.path.join(C.DEFAULT_LOCAL_TMP, "vault_passwords.txt")

    # Be sure the temp file is removed, even if the test fails
    @atexit.register
    def remove_file():
        try:
            os.remove(filename)
        except OSError:
            pass

    # Test that the secrets from a vault secrets file are read correctly
    with open(filename, 'w+') as f:
        os.fchmod(f.fileno(), 0o600)
        f.write("vault_password_1\n")
        f

# Generated at 2022-06-20 23:08:33.278338
# Unit test for method set_vault_secrets of class DataLoader
def test_DataLoader_set_vault_secrets():
    d = DataLoader()
    assert d._vault.secrets, []
    d.set_vault_secrets(['vault_secret'])
    assert d._vault.secrets, ['vault_secret']
    d.set_vault_secrets(['vault_secret1', 'vault_secret2'])
    assert d._vault.secrets, ['vault_secret1', 'vault_secret2']


# Generated at 2022-06-20 23:08:36.428253
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # Test for method get_real_file(file_path, decrypt = True).
    # Test DataLoader.get_real_file()
    pass

# Generated at 2022-06-20 23:08:43.781542
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
  dl_obj = DataLoader()
  try:
    os.mkdir(os.path.join(os.path.dirname(__file__), 'test_directory'))

    dl_obj.is_directory(os.path.join(os.path.dirname(__file__), 'test_directory'))
  finally:
    os.rmdir(os.path.join(os.path.dirname(__file__), 'test_directory'))

  try:
    dl_obj.is_directory(os.path.join(os.path.dirname(__file__), 'test_directory'))
    assert False, "test failed"
  except AnsibleFileNotFound:
    # success if exception is thrown
    pass



# Generated at 2022-06-20 23:08:50.768948
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
    print ("Testing path_exists")

    # Verify that False is returned if the given path does not exist
    dl = DataLoader()
    assert not dl.path_exists("path/does/not/exist")

    # Verify that True is returned if the given path exists
    dl = DataLoader()
    assert dl.path_exists(os.path.join(os.getcwd(), "test_loader.py"))


# Generated at 2022-06-20 23:09:03.150755
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    input_paths_as_list = [
        u'home/user/ansible/library',
        u'home/user/ansible/library/mymodule',
        u'home/user/ansible/library/mymodule/in_library_dir.sh'
    ]
    input_dirname = u'scripts'
    input_source = u'in_library_dir.sh'
    # Expect output
    expected_output = u'home/user/ansible/library/scripts/in_library_dir.sh'
    # Actual output the function under test
    actual_output = DataLoader().path_dwim_relative_stack(
        input_paths_as_list, input_dirname, input_source
    )
    # TODO: This file test_loader.py is a "test stub".
    #

# Generated at 2022-06-20 23:09:11.135504
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    import tempfile
    tempdir = tempfile.mkdtemp()
    test_file = os.path.join(tempdir, "test_dir/test_file.txt")
    os.makedirs(os.path.dirname(test_file))
    open(test_file, 'a').close()
    test_file2 = os.path.join(tempdir, "test_dir/test_file2.txt")
    open(test_file2, 'a').close()
    dl = DataLoader()
    expected = [u'test_file.txt', u'test_file2.txt']
    actual = dl.list_directory(os.path.join(tempdir, 'test_dir'))
    assert expected == actual
    os.remove(test_file)
    os.remove(test_file2)

# Generated at 2022-06-20 23:09:11.858295
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    pass

# Generated at 2022-06-20 23:09:15.457016
# Unit test for method set_basedir of class DataLoader
def test_DataLoader_set_basedir():
    # get_loader(loader_name)
    dl = DataLoader()
    dl.set_basedir(u'/tmp')
    assert dl._basedir == u'/tmp'

# Generated at 2022-06-20 23:09:31.553933
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
    dl = DataLoader()
    assert dl.path_exists('.') == True
    assert dl.path_exists('/') == True
    assert dl.path_exists('non-existing-dir') == False
    assert dl.path_exists(None) == False



# Generated at 2022-06-20 23:09:43.734652
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    """
    is_file function is used to check that the provided path is of file.
    """
    # Testing is_file function with a file path
    upath = unfrackpath('tests/unit/cli/fixtures/loader_datastructure_dir/roles/ROLE_NAME_2/tasks/main.yml')
    loader = DataLoader()
    assert loader.path_exists(upath) is True
    assert loader.is_file(upath) is True
    assert loader.is_directory(upath) is False
    # Testing is_file function with a directory path
    upath = unfrackpath('tests/unit/cli/fixtures/loader_datastructure_dir/roles/ROLE_NAME_2/tasks')
    assert loader.path_exists(upath) is True
    assert loader

# Generated at 2022-06-20 23:09:47.165581
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    # Note: This method is used indirectly by other tests
    assert os.path.isfile(os.path.join(C.DEFAULT_MODULE_PATH, 'ping.py'))

# Generated at 2022-06-20 23:09:50.239002
# Unit test for constructor of class DataLoader
def test_DataLoader():
    # Test constructor with base dir
    dl = DataLoader(None, base_path=u'base')
    assert dl.get_basedir() == u'base'


# Generated at 2022-06-20 23:09:56.018285
# Unit test for method set_basedir of class DataLoader
def test_DataLoader_set_basedir():
    """
    DataLoader.set_basedir:
    """

    set_basedir = AnsibleLoader().set_basedir
    basedir = '/var/lib/awx/venv/ansible-3.2.0/lib/python3.6/site-packages/awx/plugins/loader.py'
    set_basedir(basedir)
    assert basedir == AnsibleLoader().set_basedir()



# Generated at 2022-06-20 23:10:09.300706
# Unit test for constructor of class DataLoader
def test_DataLoader():

    # test load playbook
    yml_playbook = os.path.join(os.path.dirname(__file__), 'test_data', 'plays', 'test2.yml')
    test_playbook_file = DataLoader().load_from_file(yml_playbook)
    assert test_playbook_file == [
        '---\n',
        '- hosts: all\n',
        '  remote_user: root\n',
        '  tasks:\n',
        '    - debug: msg="ok"\n'
    ]

    # test load inventory
    test_inventory_file = DataLoader().load_from_file(os.path.join(os.path.dirname(__file__), 'test_data', 'inventory'))

# Generated at 2022-06-20 23:10:15.017117
# Unit test for method get_basedir of class DataLoader
def test_DataLoader_get_basedir():
    dataloader_class = DataLoader
    dataloader = dataloader_class()
    rv = dataloader.get_basedir()
    assert rv is None
    assert dataloader.get_basedir() is None
    dataloader = dataloader_class('/tmp')
    rv = dataloader.get_basedir()
    assert rv == '/tmp'
    assert dataloader.get_basedir() == '/tmp'


# Generated at 2022-06-20 23:10:27.724054
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    # This is the expected data
    expected = [
        {'foo': 3, 'bar': 2},
        {'foo': 1, 'bar': 'something'},
        {'foo': 2, 'bar': True},
        {'foo': 12, 'bar': None, 'baz': 'hello'}
    ]

    # This is the actual data
    loader = DataLoader()
    path = os.path.join(os.path.dirname(__file__), 'fixtures', 'vars', 'test.yml')
    actual = loader.load_from_file(path)

    assert expected == actual, 'Expected: {0} Actual: {1}'.format(expected, actual)



# Generated at 2022-06-20 23:10:33.969134
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    class TestDataLoader(DataLoader):
        def __init__(self):
            pass
    for directory in ["/etc","/a/b/c"]:
        try:
            TestDataLoader().list_directory(directory)
        except OSError as err:
            print(err, ": ", directory)

if __name__ == "__main__":
    test_DataLoader_list_directory()

# Generated at 2022-06-20 23:10:37.900555
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    loader = DataLoader()
    assert loader.list_directory('/') == ['']
    assert loader.list_directory('/tmp') == ['']

# Generated at 2022-06-20 23:11:00.552582
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    '''
    Unit test for method list_directory of class DataLoader
    '''
    test_loader = DataLoader()
    dir_name = 'tests/data/loader/list_content'
    expected_list = ['.dot_file.yml', 'ansible.cfg', 'dynamic_inventory.py',
                     'host_vars', 'host_vars_overridden', 'hosts',
                     'inventory', 'inventory_dir', 'inventory_dir_2',
                     'inventory_dir_3', 'inventory_dir_4', 'playbook.yaml',
                     'playbook.yml', 'plugin', 'plugin_docs', 'vault']
    detached_list = test_loader.list_directory(dir_name)
    detached_list.sort()

# Generated at 2022-06-20 23:11:02.337816
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    def test_DataLoader_cleanup_tmp_file(self, file_path):
        if file_path in self._tempfiles:
            os.unlink(file_path)
            self._tempfiles.remove(file_path)

# Generated at 2022-06-20 23:11:04.107859
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    dataloader = DataLoader()
    assert dataloader is not None
    result = dataloader.is_directory('.\examples')
    assert result


# Generated at 2022-06-20 23:11:16.752117
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
    # Testing with a directory path
    dl = DataLoader()
    assert dl.path_exists("../../lib/ansible/plugins/callback/default.py") == True
    assert dl.path_exists("../../lib/ansible/plugins/callback/default.pyc") == True
    assert dl.path_exists("../../lib/ansible/plugins/callback/default.pyt") == False
    assert dl.path_exists("../../lib/ansible/plugins/callback/default.pyx") == False
    print("Test 1: OK")
        
    # Testing with a file path
    dl = DataLoader()
    assert dl.path_exists("../../lib/ansible/plugins/action/apt.py") == True

# Generated at 2022-06-20 23:11:19.335074
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():

    # Test fixture data
    data = TestData()

    # Unit Test
    with patch.object(os, 'unlink', return_value=None) as mock_unlink:
        data.loader.cleanup_all_tmp_files()

        assert mock_unlink.call_count == len(data.loader._tempfiles)
        assert mock_unlink.call_count == 1

# Generated at 2022-06-20 23:11:28.983168
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    # Setup, initial state
    temp_dir = tempfile.mkdtemp()
    test_file_path = os.path.join(temp_dir, 'TestFile.txt')
    test_file_contents = 'test_DataLoader_load'
    with open(test_file_path, 'w+') as test_file:
        test_file.write(test_file_contents)

    # Exercise code
    loader = DataLoader()
    data = loader.load_from_file(test_file_path)
    # Assert, post-conditions
    assert data == test_file_contents

    # Teardown
    os.remove(test_file_path)
    os.rmdir(temp_dir)



# Generated at 2022-06-20 23:11:41.818831
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    '''
    Unit test for load method of class data_loader
    ''' 
    # #
    # # Test Raise error
    # #
    # dr = data_loader()
    # with pytest.raises(Exception) as e:
    #     dr.load()
    # assert str(e.value) == 'Not implemented!'
    # 
    # #
    # # Test call private method
    # #
    # dr = data_loader()
    # with pytest.raises(Exception) as e:
    #     dr._is_role('/home/test')
    # assert str(e.value) == "Not implemented!"
    #
    #
    # #
    # # Test call private method
    # #
    # dr = data_loader()
    # with pytest.raises(Exception)

# Generated at 2022-06-20 23:11:51.660515
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    d = DataLoader()
    f = d.get_real_file(os.path.join(C.DEFAULT_LOCAL_TMP, "test_DataLoader_get_real_file"))
    assert f is None
    f = d.get_real_file(C.ANSIBLE_TEST_DATA_ROOT)
    assert f is None
    f = d.get_real_file(os.path.join(C.ANSIBLE_TEST_DATA_ROOT, "filter_plugins"))
    assert f is None
    f = d.get_real_file(os.path.join(C.ANSIBLE_TEST_DATA_ROOT, "filter_plugins", "test_do_tolower.py"))
    assert os.path.isfile(f)



# Generated at 2022-06-20 23:11:55.060550
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    # TODO: improve test coverage
    dl = DataLoader()
    file_path = dl.get_real_file('files/fakedata.yml')
    # no error should have been thrown


# Generated at 2022-06-20 23:11:59.767084
# Unit test for method get_basedir of class DataLoader
def test_DataLoader_get_basedir():
    '''
        Test to This gets the basedir
    '''
    try:
        dataloader = DataLoader()
        assert dataloader.get_basedir() == u'/etc/ansible/'
    except Exception:
        assert False


# Generated at 2022-06-20 23:12:14.334577
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    assert_raises(AttributeError, lambda: DataLoader().path_dwim_relative.__globals__)
    assert isinstance(DataLoader().path_dwim_relative(), types.FunctionType)


# Generated at 2022-06-20 23:12:20.322498
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    test_dl = DataLoader()
    real_path = test_dl.get_real_file('/tmp/sample.yml', decrypt=True)
    test_dl.cleanup_tmp_file(real_path)
    #
    # TODO: Need to write a test to ensure that the file is gone.
    #


# Generated at 2022-06-20 23:12:25.082639
# Unit test for method is_executable of class DataLoader
def test_DataLoader_is_executable():
    assert DataLoader.is_executable(u'/home/user/.ssh/id_rsa') == False, 'should be False'
    assert DataLoader.is_executable(u'/home/user/.ssh/id_rsa', u'0600') == True, 'should be True'


# Generated at 2022-06-20 23:12:29.558749
# Unit test for method set_basedir of class DataLoader
def test_DataLoader_set_basedir():
    loader = DataLoader()
    assert loader.get_basedir() == os.path.expanduser('~')
    loader.set_basedir('foo')
    assert loader.get_basedir() == 'foo'



# Generated at 2022-06-20 23:12:39.996272
# Unit test for method set_vault_secrets of class DataLoader
def test_DataLoader_set_vault_secrets():
  # Initializing test DataLoader
  vault_pass = "test_vault_pass"
  test_loader = DataLoader(vault_pass)
  # Various test cases
  test_cases = ["test_vault_pass", "test_vault_pass", "test_vault_pass", "test_vault_pass"]
  test_exp_results = ["test_vault_pass", "test_vault_pass", "test_vault_pass", "test_vault_pass"]
  test_results = [test_loader.set_vault_secrets(vault_pass), test_loader.get_vault_secrets()]
  assert test_results == test_exp_results, "Expected %s, Received %s" % (test_exp_results, test_results)

# Generated at 2022-06-20 23:12:52.394918
# Unit test for constructor of class DataLoader
def test_DataLoader():
    """
    Test loading a valid YML file.
    """

    from ansible.parsing.dataloader import DataLoader
    myloader = DataLoader()

    # FIXME: the current dataloader does not support yaml files that are not UTF-8 encoded
    #        but we need to support that in the future
    mydata = myloader.load_from_file("test/test_loader.yml")
    assert mydata == {'foo':'bar'}

    # FIXME: the current dataloader does not support yaml files that are not UTF-8 encoded
    #        but we need to support that in the future
    #mydata = myloader.load_from_file("test/test_loader_weird_charset.yml")
    #assert mydata == {u'foo': u'\

# Generated at 2022-06-20 23:12:56.735350
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    loader = DataLoader()
    file_path = loader.get_real_file(u'myfile', decrypt=True)
    loader.cleanup_tmp_file(file_path)
    assert(file_path not in loader._tempfiles)

# Generated at 2022-06-20 23:13:00.759697
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    loader = DataLoader()
    path = loader.get_real_file('tests/unit/loader/vault.yml')
    loader.cleanup_tmp_file(path)
    assert os.path.exists(path) == False

# Generated at 2022-06-20 23:13:01.570860
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    assert DataLoader().is_directory("")

# Generated at 2022-06-20 23:13:05.055575
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    data_loader = DataLoader()
    # assert path_dwim_relative_stack successfully returns an absolute path
    assert data_loader.path_dwim_relative_stack([u'/foo/'], '', 'set_fact.yml') == '/foo/set_fact.yml'


# Generated at 2022-06-20 23:14:04.008013
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    # TODO: Write unit test
    pass


# Generated at 2022-06-20 23:14:11.542417
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    loader = DataLoader()
    context.CLIARGS = ImmutableDict(vault_password=None)
    loader._vault.secrets = ['dummy']
    file_path = u'/'
    assert loader.get_real_file(file_path) == to_bytes(file_path)
    file_path = u'/etc/hosts'
    assert loader.get_real_file(file_path) == loader.path_dwim(file_path)

    # create a test file
    import tempfile
    temp = tempfile.NamedTemporaryFile(delete=False)
    temp.write(b'$ANSIBLE_VAULT;1.2;AES256;dummy\n3456789123456789123456789\n')
    temp.close()


# Generated at 2022-06-20 23:14:23.716002
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import builtins

    mock_open = mock_unfrackpath_noop = mock_isfile = mock_isdir = mock_islink = mock_exists = None
    # save the original open builtin
    open_builtin = builtins.open

    def setUp():
        # override the open builtin for data access
        builtins.open = mock_open
        DataLoaderModule.unfrackpath = mock_unfrackpath_noop
        DataLoaderModule.exists = mock_exists
        DataLoaderModule.isdir = mock_isdir
        DataLoaderModule.isfile = mock_isfile
        DataLoaderModule.islink = mock_islink


# Generated at 2022-06-20 23:14:30.118081
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    dl = DataLoader()
    dl_list_directory_result = dl.list_directory("/etc")
    assert type(dl_list_directory_result) == list
    for item in dl_list_directory_result:
        assert isinstance(item, text_type)
    assert len(dl_list_directory_result) > 0
    assert u'fstab' in dl_list_directory_result

# Generated at 2022-06-20 23:14:30.944541
# Unit test for method set_vault_secrets of class DataLoader
def test_DataLoader_set_vault_secrets():
  loader = DataLoader()
  loader.set_vault_secrets(dict())


# Generated at 2022-06-20 23:14:41.358141
# Unit test for method set_basedir of class DataLoader
def test_DataLoader_set_basedir():
    # We need to use a real ansible-runner object to test this, which means we need to make it run as a standalone Python program
    test_runner = importlib.import_module(os.environ['TEST_MODULE'])
    test_class = os.environ.get('TEST_CLASS')
    if test_class:
        test_class = getattr(test_runner, test_class)
    else:
        test_class = test_runner.CliAnsible

    # Set up a mock ansible-connection plugin to use.
    test_conf = {u'runner': {u'env': {u'ANSIBLE_PERSISTENT_CONNECTION_CONNECTION': u'test_runner'}}}
    test_conf = AnsibleConfig(config_dict=test_conf)
    test_runner.plugin_

# Generated at 2022-06-20 23:14:45.585569
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    # Read in the fixture
    fixture_data = read_fixture_file('DataLoader_load.py')

    # Create the loader
    loader = DataLoader()

    # Attempt to load the data
    result = loader.load(fixture_data['input'])

    assert result == fixture_data['expected']


# Generated at 2022-06-20 23:14:57.854710
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    """
    Verify output of DataLoader.list_directory()
    """
    loader = DataLoader()
    testdir = tempfile.mkdtemp()

# Generated at 2022-06-20 23:15:01.966046
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    dl = DataLoader()
    assert isinstance(dl, DataLoader)
    dl.cleanup_all_tmp_files()

    # Test call cleanup_all_tmp_files with args and named args
    dl.cleanup_all_tmp_files()




# Generated at 2022-06-20 23:15:11.792870
# Unit test for constructor of class DataLoader
def test_DataLoader():
    '''
    Constructor for DataLoader class should get the following values
    - base_basedir (directory where the playbook is located)
    - class (actual class)
    - config ({'paths', 'role_paths', 'roles_path'})
    '''
    def _constructor_test(config=None, variable_manager=None):
        data_loader = DataLoader(config, variable_manager=variable_manager)

        assert data_loader.base_basedir is not None
        assert len(data_loader.base_basedir) > 0
        assert isinstance(data_loader, DataLoader)
        assert isinstance(data_loader.config, dict)
        assert 'paths' in data_loader.config
        assert 'role_paths' in data_loader.config
        assert 'roles_path' in data

# Generated at 2022-06-20 23:16:24.458216
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    loader = DataLoader()
    data = loader.load_from_file('[redacted]')

    hostvars = data['_meta']['hostvars']
    assert len(hostvars) == 1

    hostvar = next(iter(hostvars.values()))
    assert 'Foo' in hostvar
    assert hostvar['Foo']['Bar'] == 'Baz'