

# Generated at 2022-06-20 23:07:10.998528
# Unit test for method is_executable of class DataLoader
def test_DataLoader_is_executable():
    '''
    Unit test for method is_executable of class DataLoader
    '''
    # Load the sample file
    with open('/tmp/testl0g5.json', 'r') as f:
        data = json.load(f)

    # Grab the DataLoader class
    DataLoader = data.get('DataLoader')

    # Load the class
    DataLoader = loading.load_class(DataLoader.get('fully_qualified_name'))

    # Create an instance of the DataLoader class, and set the basedir
    data_loader = DataLoader()
    data_loader.set_basedir('/tmp')

    # Call method
    result = data_loader.is_executable('/tmp/ansible_test')

    # do the assert
    assert type(result) == bool
    assert result == True
# Unit

# Generated at 2022-06-20 23:07:24.716650
# Unit test for method path_dwim of class DataLoader
def test_DataLoader_path_dwim():
    loader = DataLoader()
    # Boolean assertion using environment variable CWD
    assert loader.path_dwim("") == os.path.normpath("{}/".format(os.getcwd()))
    assert loader.path_dwim(".") == os.path.normpath("{}/".format(os.getcwd()))
    # Boolean assertion using environment variable HOME
    assert loader.path_dwim("~") == os.path.normpath("{}/".format(os.environ.get("HOME")))
    # Boolean assertion using environment variable HOME
    assert loader.path_dwim("~/") == os.path.normpath("{}/".format(os.environ.get("HOME")))
    # Boolean assertion using environment variable CWD

# Generated at 2022-06-20 23:07:26.366823
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    loader = DataLoader()
    loader.cleanup_all_tmp_files()



# Generated at 2022-06-20 23:07:35.699962
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    failed = False

# Generated at 2022-06-20 23:07:40.122249
# Unit test for constructor of class DataLoader
def test_DataLoader():
    '''
    data_loader = DataLoader()
    print(data_loader.get_basedir())
    print(data_loader.get_vault_secret())
    '''
    pass


# Generated at 2022-06-20 23:07:43.536827
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    data = DataLoader()
    assert data.is_directory('/etc') == True
    assert data.is_directory('/nofile') == False

# Generated at 2022-06-20 23:07:45.453715
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    DataLoader.path_exists = mock.Mock(return_value=True)
    DataLoader.is_directory = mock.Mock(return_value=True)
    assert DataLoader().is_file('') == False

# Generated at 2022-06-20 23:07:57.121335
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    data_loader = DataLoader()
    actual = data_loader.is_file('/root/git/ansible/test/files/test_module.py')
    expected = True
    assert actual == expected

    actual = data_loader.is_file('/root/git/ansible/test/files/__init__.py')
    expected = True
    assert actual == expected

    actual = data_loader.is_file('/root/git/ansible/test')
    expected = False
    assert actual == expected

    actual = data_loader.is_file('/root/git/ansible')
    expected = False
    assert actual == expected

    actual = data_loader.is_file('/')
    expected = False
    assert actual == expected

    actual = data_loader.is_file('')
    expected = False


# Generated at 2022-06-20 23:08:04.520833
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleAbstractClassError

    test_file = u'red_rover'
    test_file_content = u'This is a test of the test system'
    test_vault_password_file = u'vault.key'
    test_vault_password_file_content = u'This is a test of the test vault password file'
    test_vault_password = u'This is a test of the test vault password'
    test_variable_manager = VariableManager()
    test_display = Display()

# Generated at 2022-06-20 23:08:14.280006
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    loader = DataLoader()
    assert loader.is_directory('./test/unit/lib/ansible/modules/files')

    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor


    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['./test/unit/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    playbook_path = './test/unit/hacking/test_playbook_lookup_plugin.yml'

# Generated at 2022-06-20 23:08:25.975144
# Unit test for method set_vault_secrets of class DataLoader
def test_DataLoader_set_vault_secrets():
    cls = DataLoader()
    cls.set_vault_secrets(vault_secrets=['value1'])
    assert cls.vault_secrets == ['value1']


# Generated at 2022-06-20 23:08:27.088640
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
	pass


# Generated at 2022-06-20 23:08:31.068357
# Unit test for constructor of class DataLoader
def test_DataLoader():

    # Allowing loading module_utils if they exist
    loader = DataLoader()

    # Disallowing loading module_utils if they exist
    loader = DataLoader(False)


# Generated at 2022-06-20 23:08:41.435105
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    my_dl = DataLoader()
    my_dl._basedir = os.path.dirname(os.path.abspath(__file__))

    # test success
    data = my_dl.load_from_file('test_data/loader/dl_good.yaml')
    assert isinstance(data, dict), 'DataLoader.load_from_file should return a dict.'
    assert data['a'] == 'hello', 'DataLoader.load_from_file should return the expected data.'

    # test invalid
    bad_file_data = None

# Generated at 2022-06-20 23:08:48.438322
# Unit test for method set_vault_secrets of class DataLoader
def test_DataLoader_set_vault_secrets():
    # set_vault_secrets doesn't return anything
    # This loader accepts vault secrets for decrypting data files
    #
    # A dictionary of vault secrets to use for decryption.  This is the
    # '--vault-password-file' or '--ask-vault-pass' options to ansible-playbook
    #
    # This is set from the command line with the @vault_secrets decorator
    assert True == True


# Generated at 2022-06-20 23:08:55.212976
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    loader = DataLoader()
    data = loader.load_from_file("/home/carlos/Escritorio/ansible_training/my_ansible/inventory_file_ini")
    data2 = loader.load_from_file("/home/carlos/Escritorio/ansible_training/ansible_playbooks/playbook.yml")
    print(data)
    print(data2)


# Generated at 2022-06-20 23:09:01.027251
# Unit test for method is_file of class DataLoader
def test_DataLoader_is_file():
    ''' Test case for DataLoader.is_file '''
    obj = DataLoader()

    # Check method is_file with normal path
    assert obj.is_file(b'/home/user/test.txt') is True

    # Check method is_file with fake path
    assert obj.is_file('./fake/path') is False


# Generated at 2022-06-20 23:09:06.924803
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    # Create a DataLoader object
    dl = DataLoader()
    dl.set_vault_secrets(["/etc/ansible/vault-password-file"])
    dl.set_vault_password("ansible")

    # Check the return of load method
    assert dl.load("/etc/ansible/hosts") == {}
    assert dl.load("/not/exist") is None


# Generated at 2022-06-20 23:09:18.560849
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    import tempfile
    tmp = tempfile.mkdtemp()

# Generated at 2022-06-20 23:09:21.626047
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    """
    :return:
    """
    loader = DataLoader()
    # print(loader.list_directory(loader.get_basedir()))


# Generated at 2022-06-20 23:09:43.062283
# Unit test for constructor of class DataLoader
def test_DataLoader():
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()
    assert dl



# Generated at 2022-06-20 23:09:51.577061
# Unit test for constructor of class DataLoader
def test_DataLoader():
    from ansible.parsing.dataloader import DataLoader

    # Test loading data from an ansible-configured path (CWD, in this case)
    dl = DataLoader()
    assert dl.get_basedir() == os.path.abspath(os.curdir)

    # Test loading data from a new path
    tmp_path = os.path.abspath(os.curdir)
    dl = DataLoader(path=tmp_path)
    assert dl.get_basedir() == tmp_path



# Generated at 2022-06-20 23:09:55.389850
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    """Test list_directory."""
    loader = DataLoader()
    assert loader.list_directory("/src/path/file") == [], "list_directory: return value is not as expected"

if __name__ == "__main__":
    test_DataLoader_list_directory()

# Generated at 2022-06-20 23:10:08.621547
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():

    # Prepare test objects
    dl = DataLoader()
    called = []

    # Replace os.remove for the duration of this test
    orig_remove = os.remove
    def remove(path):
        called.append(path)
        orig_remove(path)
    os.remove = remove


# Generated at 2022-06-20 23:10:16.539248
# Unit test for method is_executable of class DataLoader
def test_DataLoader_is_executable():
    dl = DataLoader()

    # Test when file doesn't exist.
    assert dl.is_executable('a1') == False

    # Test when file is executable
    assert dl.is_executable('a2') == True

    # Test when file is not executable
    assert dl.is_executable('a3') == False

    # Test when file has wrong permission type
    assert dl.is_executable('a4') == False

    # Test when path is not a file
    assert dl.is_executable('a5') == False

    # Test when dir is executable
    assert dl.is_executable('a6') == True

    # Test when dir is not executable
    assert dl.is_executable('a7') == False

    # Test when dir has wrong permission type

# Generated at 2022-06-20 23:10:26.717056
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    dataloader = DataLoader()
    assert dataloader.is_directory(u'/etc') == True, "get_basedir: DataLoader().is_directory(u'/etc') != True"
    assert dataloader.is_directory(u'does-not-exist') == False, "get_basedir: DataLoader().is_directory(u'/etc') != True"
    assert dataloader.is_directory(u'/dev/tty') == False, "get_basedir: DataLoader().is_directory(u'/dev/tty') != False"


# Generated at 2022-06-20 23:10:30.559727
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
    loader = DataLoader()
    path = to_bytes('/tmp')
    y = loader.path_exists(path)
    assert path_exists(path) == y


# Generated at 2022-06-20 23:10:32.337345
# Unit test for method set_basedir of class DataLoader
def test_DataLoader_set_basedir():
    # Call method set_basedir of class DataLoader
    pass


# Generated at 2022-06-20 23:10:33.340570
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    # TODO: Implement this
    pass

# Generated at 2022-06-20 23:10:35.726562
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
    data_loader = DataLoader()
    data_loader.path_exists("test")


# Generated at 2022-06-20 23:11:03.760852
# Unit test for method is_directory of class DataLoader
def test_DataLoader_is_directory():
    # TODO implement
    return


# Generated at 2022-06-20 23:11:16.313800
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.vault import get_file_vault_secret
    from distutils.dir_util import mkpath
    # Test with normal file

# Generated at 2022-06-20 23:11:24.874958
# Unit test for method path_dwim_relative of class DataLoader
def test_DataLoader_path_dwim_relative():
    args = dict(
        path=u'/home/user/playbooks',
        dirname=u'templates',
        source=u'hello',
    )
    assert DataLoader.path_dwim_relative(**args) == u'/home/user/playbooks/templates/hello'

    args = dict(
        path=u'/home/user/playbooks',
        dirname=u'templates',
        source=u'/home/user/templates/hello',
    )
    assert DataLoader.path_dwim_relative(**args) == u'/home/user/templates/hello'

    args = dict(
        path=u'/home/user/playbooks',
        dirname=u'templates',
        source=u'~/templates/hello',
    )
    assert DataLoader.path

# Generated at 2022-06-20 23:11:38.762396
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    '''
    Test if DataLoader.cleanup_all_tmp_files() cleans up temporary files.
    '''
    # Create a temporary role
    role_name = 'testrole'
    role_path = tempfile.mkdtemp()
    role_module_path = os.path.join(role_path, 'library')
    os.makedirs(role_module_path)
    with open(os.path.join(role_module_path, '__init__.py'), 'w') as f:
        f.write('# test module\n')
    with open(os.path.join(role_path, 'meta', 'main.yml'), 'w') as f:
        f.write('# test\n')

    # Create a loader with the temporary role path in its search path
    loader = DataLoader()


# Generated at 2022-06-20 23:11:49.934822
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    
    # init the test environment
    data_loader = DataLoader()
    loader_module_path = '/tmp/playbooks-ansible/lib/ansible/config'
    data_loader.set_basedir(loader_module_path)

    # define stack

# Generated at 2022-06-20 23:12:01.896729
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    from ansible.utils.vars import combine_vars
    dl = DataLoader()
    fixture = u'file.yml'
    content = """
    foo: bar
    bam:
      baz: 2
    """
    dl = DataLoader()
    fixed_path = dl.path_dwim(fixture)
    dl.set_basedir(u'.')
    with open(fixed_path, 'w') as f:
        f.write(content)
    try:
        dl.get_real_file(fixed_path)
        data = dl.load_from_file(fixed_path)
        assert data == {u'foo': u'bar', u'bam': {u'baz': 2}}
    finally:
        os.remove(fixed_path)



# Generated at 2022-06-20 23:12:13.453067
# Unit test for method load of class DataLoader
def test_DataLoader_load():
    from ansible import errors
    import os

    # First create a data loader
    loader = DataLoader()

    # Now test the load() method
    # This should return an AnsibleFileNotFound error if the file doesn't exist
    try:
        loader.load_from_file('/some/bad/path')
    except errors.AnsibleFileNotFound:
        pass
    else:
        raise Exception('unhandled AnsibleFileNotFound exception')

    # This should return an AnsibleParserError if the yaml file
    # is badly formatted.
    try:
        loader.load_from_file(os.path.join(os.path.dirname(__file__), 'test_data', 'bad.vars'))
    except errors.AnsibleParserError:
        pass

# Generated at 2022-06-20 23:12:18.030563
# Unit test for method get_basedir of class DataLoader
def test_DataLoader_get_basedir():
    dl = DataLoader()
    dl.set_basedir(u"/home/user/ansible/playbook.yml")
    assert dl.get_basedir() == u'/home/user/ansible', dl.get_basedir()


# Generated at 2022-06-20 23:12:24.824833
# Unit test for method set_basedir of class DataLoader
def test_DataLoader_set_basedir():
    tmp_loader = DataLoader()
    base_dir = unfrackpath("/home/user/path/to/file")
    tmp_loader.set_basedir(base_dir)
    assert tmp_loader.path_exists("/home/user/path/to/file")
    assert tmp_loader._basedir == base_dir
    assert tmp_loader.get_basedir() == base_dir

# Generated at 2022-06-20 23:12:30.750243
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    args = []
    if len(args) == 1:
        path = args[0]
        dl = DataLoader()
        try:
            result = dl.list_directory(path)
        except Exception as e:
            print(e)
    else:
        print('Please provide the path to list')


# Generated at 2022-06-20 23:12:53.675270
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():

    # Remove the following line and any code above it.
    raise AssertionError('No test code has run.')


# Generated at 2022-06-20 23:13:04.430239
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    import pytest
    with pytest.raises(AnsibleParserError) as err:
        x = DataLoader()
        x.cleanup_tmp_file(None)
    assert err.value.message == "Invalid filename: 'None'"
    with pytest.raises(AnsibleFileNotFound) as err:
        x = DataLoader()
        x.cleanup_tmp_file('/k2/CloudForms/jenkins/workspace/ansible-integration-master-394/inventory/ansible/group_vars/vars_file_path'.encode())
        x.cleanup_tmp_file('/k2/CloudForms/jenkins/workspace/ansible-integration-master-394/inventory/ansible/group_vars/vars_file_path')
    assert err.value.message

# Generated at 2022-06-20 23:13:12.761179
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    import os
    import tempfile
    import shutil
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    manager = VariableManager()
    manager.set_inventory(Inventory(loader=DataLoader()))
    r = os.sep.join(('roles','test','tasks','main.yml'))
    a = tempfile.mkdtemp()
    a_ = os.path.join(a, 'roles')
    b = a_
    b_ = os.path.join(b, 'test')
    c = b_
    c_ = os.path.join(c, 'tasks')
    f = os.path.join(c_, 'main.yml')

# Generated at 2022-06-20 23:13:13.813479
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
    assert False, "No test"


# Generated at 2022-06-20 23:13:27.558765
# Unit test for method path_dwim_relative_stack of class DataLoader
def test_DataLoader_path_dwim_relative_stack():
    module = AnsibleModule(
        argument_spec = dict()
    )
    # put your test code here
    from ansible.utils.path import unfrackpath

    # Tasks dir in a role
    paths = [
        '/home/awx/awx_devel/awx/projects/test/roles/test/tasks/main.yml',
        '/home/awx/awx_devel/awx/projects/test/roles/test/tasks'
    ]
    dirname = 'files'
    source = 'test.txt'
    result = DataLoader().path_dwim_relative_stack(paths, dirname, source, is_role=True)

# Generated at 2022-06-20 23:13:28.861922
# Unit test for constructor of class DataLoader
def test_DataLoader():
    '''
    TBD
    '''
    loader = DataLoader()
    print("Dataloader1: ",loader)
    # DataLoader()



# Generated at 2022-06-20 23:13:34.271932
# Unit test for method cleanup_tmp_file of class DataLoader
def test_DataLoader_cleanup_tmp_file():
    # test different combinations of file_path and self._tempfiles
    # file_path in self._tempfiles
    # file_path not in self._tempfiles
    # NOTE: file_path and self._tempfiles could be list, tuple or set
    
    # assert file_path in self._tempfiles, test the case that `if file_path in self._tempfiles` is True
    # assert file_path not in self._tempfiles, test the case that `if file_path in self._tempfiles` is False
    
    for file_path, self._tempfiles in (([1,2,3], 1), ([1,2,3], (1,2)), ((1,2,3), {1,2})):
        try:
            raise Exception
        except Exception as e:
            assert file_path not in self._tempfiles

# Generated at 2022-06-20 23:13:39.377824
# Unit test for method set_vault_secrets of class DataLoader
def test_DataLoader_set_vault_secrets():
    print('test_DataLoader_set_vault_secrets')
    loader = DataLoader()
    loader.set_vault_secrets(['3qewqd'], False)
    loader.set_vault_secrets(['3qewqd'], True)

if __name__ == '__main__':
    test_DataLoader_set_vault_secrets()

# Generated at 2022-06-20 23:13:46.304473
# Unit test for method get_real_file of class DataLoader
def test_DataLoader_get_real_file():
    import sys
    import tempfile
    import shutil
    import os
    import warnings
    import pytest
    import ansible.constants
    import ansible.parsing.vault
    import ansible.parsing.vault.VaultLib
    from ansible.parsing.vault import VaultLib

    sys.path.append(os.path.join(os.path.dirname(__file__), '../../'))
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../vars'))
    from units.mock.loader import DictDataLoader
    from units.mock.vault import mock_vault


# Generated at 2022-06-20 23:13:58.718964
# Unit test for method path_exists of class DataLoader
def test_DataLoader_path_exists():
  filename = 'testfile.txt'
  file_content = 'This is a test'
  # Create a temp file
  fd, content_tempfile = tempfile.mkstemp(dir=C.DEFAULT_LOCAL_TMP)
  f = os.fdopen(fd, 'wb')
  file_content = to_bytes(file_content)
  try:
    f.write(file_content)
  except Exception as err:
    os.remove(content_tempfile)
    raise err
  finally:
    f.close()
  # Set up the DataLoader object
  module_loader = DictDataLoader({u'tmp': {u'roles': {u'role1': {u'files': {filename: content_tempfile}}}}})
  module_loader.set_basedir('tmp')
  #

# Generated at 2022-06-20 23:14:17.568285
# Unit test for method load_from_file of class DataLoader
def test_DataLoader_load_from_file():
    mock_data = b"hello world"
    mock_file = io.BytesIO(mock_data)
    fake_file = "/path/to/fake.file"
    fake_loader = DataLoader()

    with patch("io.open"):
        fake_loader._open = mock_open(mock_file, 'rb')
        output = fake_loader.load_from_file(fake_file)
        assert output == mock_data.decode('utf-8')



# Generated at 2022-06-20 23:14:20.427849
# Unit test for method is_executable of class DataLoader
def test_DataLoader_is_executable():
    data_loader = DataLoader()
    cmd = "ls"
    cmd = to_text(cmd)
    data_loader.get_executable(cmd)

# Generated at 2022-06-20 23:14:25.201403
# Unit test for method path_dwim of class DataLoader
def test_DataLoader_path_dwim():
    from ansible.utils.path import unfrackpath
    dl = DataLoader()
    test_path = unfrackpath('/etc/ansible/hacking/env-setup')
    assert dl.path_dwim(test_path) == test_path
    test_path = os.path.basename(test_path)
    assert dl.path_dwim(test_path) == os.path.join(dl.get_basedir(), test_path)


# Generated at 2022-06-20 23:14:31.668098
# Unit test for method path_dwim of class DataLoader
def test_DataLoader_path_dwim():
    loader = DataLoader()
    assert loader.path_dwim("./foo") == os.path.join(os.getcwd(), "foo")
    assert loader.path_dwim("/tmp") == "/tmp"
    assert loader.path_dwim("/foo/bar.conf") == "/foo/bar.conf"

# Generated at 2022-06-20 23:14:40.400961
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files(): # noqa: E302
    import tempfile
    
    # read binary data file
    with open(__file__, "rb") as f:
        data = f.read()
    
    # create temp file
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, "wb") as f:
        f.write(data)

    # create DataLoader instance and add tempfile
    dl = DataLoader()
    dl._tempfiles.add(path)

    # do cleanup and check if file no longer exists
    dl.cleanup_all_tmp_files()
    assert not os.path.exists(path)


# Generated at 2022-06-20 23:14:47.801400
# Unit test for method find_vars_files of class DataLoader
def test_DataLoader_find_vars_files():
    # Getting current directory
    current_directory = os.path.dirname(__file__)

    # Creating a DataLoader
    data_loader = DataLoader()
    data_loader.set_basedir(current_directory)

    path = data_loader.path_dwim('playbooks/roles/docker/')
    name = 'vars'
    extensions = ['.yml', '.yaml', '.json']
    allow_dir = True
    result = data_loader.find_vars_files(path, name, extensions, allow_dir)

    assert result == ['playbooks/roles/docker/vars/main.yml']


# Generated at 2022-06-20 23:14:51.741271
# Unit test for method set_basedir of class DataLoader
def test_DataLoader_set_basedir():
    loader = DataLoader()
    loader.set_basedir('/home/joe')
    assert loader._basedir == '/home/joe'


# Generated at 2022-06-20 23:14:54.372145
# Unit test for method list_directory of class DataLoader
def test_DataLoader_list_directory():
    dl = DataLoader(None, None)
    assert dl.list_directory("/tmp") == []


# Generated at 2022-06-20 23:15:04.623552
# Unit test for method cleanup_all_tmp_files of class DataLoader
def test_DataLoader_cleanup_all_tmp_files():
    loader = DataLoader()
    loader.add_caching_plugin( FileCacheModule('/tmp/ansible-filecache', 'ansible-loader') )
    content = '''---
a: 1
b:
  - 2
  - 3
c: 4
'''
    filename = '/tmp/test_DataLoader_cleanup_all_tmp_files'
    with open(filename, 'w') as f:
        f.write(content)
    real_path = loader.get_real_file(filename, decrypt=False)
    loader.cleanup_all_tmp_files()
    assert not os.path.exists(real_path)


# Generated at 2022-06-20 23:15:13.122601
# Unit test for method is_executable of class DataLoader