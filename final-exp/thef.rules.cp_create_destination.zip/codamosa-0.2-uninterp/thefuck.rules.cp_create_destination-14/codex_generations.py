

# Generated at 2022-06-18 07:39:37.623822
# Unit test for function match
def test_match():
    assert match(Command('cp abc.txt /tmp/abc.txt', 'cp: cannot stat abc.txt: No such file or directory'))
    assert match(Command('cp abc.txt /tmp/abc.txt', 'cp: cannot stat abc.txt: No such file or directory'))
    assert match(Command('cp abc.txt /tmp/abc.txt', 'cp: cannot stat abc.txt: No such file or directory'))
    assert match(Command('cp abc.txt /tmp/abc.txt', 'cp: cannot stat abc.txt: No such file or directory'))
    assert match(Command('cp abc.txt /tmp/abc.txt', 'cp: cannot stat abc.txt: No such file or directory'))

# Generated at 2022-06-18 07:39:47.028998
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))

# Generated at 2022-06-18 07:39:51.043836
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory ‘foo’ does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))


# Generated at 2022-06-18 07:40:01.296325
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist\n"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist\n"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
   

# Generated at 2022-06-18 07:40:12.241841
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert not match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))

#

# Generated at 2022-06-18 07:40:24.399315
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt /tmp/test.txt', 'cp: cannot stat \'test.txt\': No such file or directory'))
    assert match(Command('cp test.txt /tmp/test.txt', 'cp: cannot stat \'test.txt\': No such file or directory'))
    assert match(Command('cp test.txt /tmp/test.txt', 'cp: cannot stat \'test.txt\': No such file or directory'))
    assert match(Command('cp test.txt /tmp/test.txt', 'cp: cannot stat \'test.txt\': No such file or directory'))
    assert match(Command('cp test.txt /tmp/test.txt', 'cp: cannot stat \'test.txt\': No such file or directory'))

# Generated at 2022-06-18 07:40:34.282793
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory\n'))

# Generated at 2022-06-18 07:40:40.626131
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))

# Generated at 2022-06-18 07:40:49.858722
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert match(Command('mv test.txt test/', 'mv: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('mv test.txt test/', 'mv: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: Permission denied'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: Is a directory'))

# Generated at 2022-06-18 07:40:59.429681
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))

# Generated at 2022-06-18 07:41:11.371059
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory file2 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert not match(Command('cp file1 file2', 'cp: directory file2 does not exist\n'))

# Generated at 2022-06-18 07:41:21.953851
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt /tmp/foo/bar/baz", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt /tmp/foo/bar/baz", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt /tmp/foo/bar/baz", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt /tmp/foo/bar/baz", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt /tmp/foo/bar/baz", "cp: cannot stat 'test.txt': No such file or directory\n"))

# Generated at 2022-06-18 07:41:30.969569
# Unit test for function match
def test_match():
    assert match(Command('cp /tmp/test.txt /tmp/test2.txt', 'cp: cannot stat \'/tmp/test.txt\': No such file or directory'))
    assert match(Command('mv /tmp/test.txt /tmp/test2.txt', 'mv: cannot stat \'/tmp/test.txt\': No such file or directory'))
    assert match(Command('cp /tmp/test.txt /tmp/test2.txt', 'cp: directory \'/tmp/test2.txt\' does not exist'))
    assert match(Command('mv /tmp/test.txt /tmp/test2.txt', 'mv: directory \'/tmp/test2.txt\' does not exist'))

# Generated at 2022-06-18 07:41:40.369858
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:41:46.173412
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': Permission denied"))
    assert not match(Command("mv test.txt test", "mv: cannot stat 'test.txt': Permission denied"))
    assert not match(Command("cp test.txt test", "cp: directory 'test' does not exist"))


# Generated at 2022-06-18 07:41:56.998927
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test/", "cp: cannot create regular file 'test/': No such file or directory"))
    assert match(Command("mv test.txt test/", "mv: cannot create regular file 'test/': No such file or directory"))
    assert match(Command("cp test.txt test/", "cp: directory 'test/' does not exist"))
    assert not match(Command("cp test.txt test/", "cp: cannot create regular file 'test/': Permission denied"))
    assert not match(Command("mv test.txt test/", "mv: cannot create regular file 'test/': Permission denied"))
    assert not match(Command("cp test.txt test/", "cp: cannot create regular file 'test/': File exists"))

# Generated at 2022-06-18 07:42:07.100567
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:42:14.974095
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:42:25.641311
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('mv test.txt test/', 'mv: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert match(Command('mv test.txt test/', 'mv: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory\n'))

# Generated at 2022-06-18 07:42:33.990089
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:42:42.631593
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory '/home/user/foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': Permission denied"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': Is a directory"))


# Generated at 2022-06-18 07:42:49.656587
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))


# Generated at 2022-06-18 07:43:00.434675
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('mv test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert match(Command('mv test.txt test', 'cp: directory `test\' does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert not match(Command('mv test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))

# Generated at 2022-06-18 07:43:07.075539
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))


# Generated at 2022-06-18 07:43:12.887111
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))


# Generated at 2022-06-18 07:43:23.502384
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('mv test.txt test/', 'mv: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert match(Command('mv test.txt test/', 'mv: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: Permission denied'))

# Generated at 2022-06-18 07:43:34.176625
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))

# Generated at 2022-06-18 07:43:42.226315
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert not match(Command("cp test.txt test", "cp: directory 'test' does not exist\n"))

# Generated at 2022-06-18 07:43:50.050961
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: directory 'foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': Permission denied"))
    assert not match(Command("mv foo bar", "mv: cannot stat 'foo': Permission denied"))


# Generated at 2022-06-18 07:44:00.687021
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert match(Command("mv file1 file2", "mv: directory 'file2' does not exist"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert not match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert not match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))

# Generated at 2022-06-18 07:44:12.869647
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert not match(Command('cp file1 file2', 'cp: directory `file2\' does not exist\n'))

# Generated at 2022-06-18 07:44:19.646694
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp -r dir1 dir2', 'cp: directory dir1 does not exist'))
    assert match(Command('mv -r dir1 dir2', 'mv: directory dir1 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: Permission denied'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: Permission denied'))

# Generated at 2022-06-18 07:44:29.316383
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert not match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))


# Generated at 2022-06-18 07:44:40.399374
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist\n"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("mv test.txt test", "mv: directory 'test' does not exist"))

# Generated at 2022-06-18 07:44:48.346785
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:44:53.913735
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))


# Generated at 2022-06-18 07:45:04.662188
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))

# Generated at 2022-06-18 07:45:14.023102
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/file.txt /home/user/file2.txt', 'cp: cannot stat \'/home/user/file.txt\': No such file or directory'))
    assert match(Command('cp /home/user/file.txt /home/user/file2.txt', 'cp: cannot stat \'/home/user/file.txt\': No such file or directory\n'))
    assert match(Command('cp /home/user/file.txt /home/user/file2.txt', 'cp: cannot stat \'/home/user/file.txt\': No such file or directory\n'))

# Generated at 2022-06-18 07:45:17.155355
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))


# Generated at 2022-06-18 07:45:27.086803
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert not match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert not match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))


# Generated at 2022-06-18 07:45:39.362797
# Unit test for function match
def test_match():
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory"))
    assert match(Command("mv a b", "mv: cannot stat 'a': No such file or directory"))
    assert match(Command("cp a b", "cp: directory 'a' does not exist"))
    assert match(Command("mv a b", "mv: directory 'a' does not exist"))
    assert not match(Command("cp a b", "cp: cannot stat 'a': No such file or directory"))
    assert not match(Command("mv a b", "mv: cannot stat 'a': No such file or directory"))
    assert not match(Command("cp a b", "cp: directory 'a' does not exist"))
    assert not match(Command("mv a b", "mv: directory 'a' does not exist"))

# Generated at 2022-06-18 07:45:46.126776
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp -r dir1 dir2', 'cp: directory dir1 does not exist'))
    assert match(Command('mv -r dir1 dir2', 'mv: directory dir1 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory\n'))

# Generated at 2022-06-18 07:45:56.649596
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:46:04.587428
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test2.txt', 'cp: cannot stat test.txt: No such file or directory'))
    assert match(Command('mv test.txt test2.txt', 'mv: cannot stat test.txt: No such file or directory'))
    assert match(Command('cp test.txt test2.txt', 'cp: directory test2.txt does not exist'))
    assert not match(Command('cp test.txt test2.txt', 'cp: cannot stat test.txt: No such file or directory'))
    assert not match(Command('mv test.txt test2.txt', 'mv: cannot stat test.txt: No such file or directory'))
    assert not match(Command('cp test.txt test2.txt', 'cp: directory test2.txt does not exist'))


# Generated at 2022-06-18 07:46:08.659826
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))


# Generated at 2022-06-18 07:46:18.216484
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))

# Generated at 2022-06-18 07:46:29.003540
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: directory 'foo' does not exist"))
    assert not match(Command("cp foo bar", ""))
    assert not match(Command("mv foo bar", ""))


# Generated at 2022-06-18 07:46:38.961477
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('mv test.txt test', 'mv: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory ‘test’ does not exist'))
    assert match(Command('mv test.txt test', 'mv: directory ‘test’ does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: No such file or directory\n'))
    assert not match(Command('mv test.txt test', 'mv: cannot stat ‘test.txt’: No such file or directory\n'))
   

# Generated at 2022-06-18 07:46:48.660801
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))

# Generated at 2022-06-18 07:46:59.684930
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:47:08.582322
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert not match(Command("cp test.txt test", "cp: directory 'test' does not exist\n"))

# Generated at 2022-06-18 07:47:15.847071
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('mv test.txt test', 'mv: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))


# Generated at 2022-06-18 07:47:25.742191
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test1.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test1.txt", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test1.txt", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test1.txt", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test1.txt", "cp: cannot stat 'test.txt': No such file or directory\n"))

# Generated at 2022-06-18 07:47:35.538377
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match

# Generated at 2022-06-18 07:47:40.782995
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))

# Generated at 2022-06-18 07:47:50.306212
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))
    assert match(Command('mv foo bar', 'mv: directory ‘bar’ does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert not match(Command('mv foo bar', 'mv: cannot stat ‘foo’: No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))

# Generated at 2022-06-18 07:47:59.725482
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('mv test.txt test', 'mv: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert match(Command('mv test.txt test', 'mv: directory `test\' does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert not match(Command('mv test.txt test', 'mv: cannot stat `test.txt\': No such file or directory'))

# Generated at 2022-06-18 07:48:07.987160
# Unit test for function match
def test_match():
    assert match(Command('cp a b', 'cp: cannot stat ‘a’: No such file or directory'))
    assert match(Command('mv a b', 'mv: cannot stat ‘a’: No such file or directory'))
    assert match(Command('cp a b', 'cp: directory ‘a’ does not exist'))
    assert match(Command('mv a b', 'mv: directory ‘a’ does not exist'))
    assert not match(Command('cp a b', 'cp: cannot stat ‘a’: No such file or directory'))
    assert not match(Command('mv a b', 'mv: cannot stat ‘a’: No such file or directory'))
    assert not match(Command('cp a b', 'cp: directory ‘a’ does not exist'))

# Generated at 2022-06-18 07:48:17.205115
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt',
                         'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt',
                         'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt',
                         'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))

# Generated at 2022-06-18 07:48:28.873808
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:48:40.593543
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2` does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory `file2` does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert not match(Command('cp file1 file2', 'cp: directory `file2` does not exist\n'))

# Generated at 2022-06-18 07:48:51.987027
# Unit test for function match
def test_match():
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n", ""))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n", "", ""))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n", "", "", ""))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n", "", "", "", ""))

# Generated at 2022-06-18 07:49:01.736661
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist\n'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist\n'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:49:10.447727
# Unit test for function match
def test_match():
    assert match(Command("cp /tmp/test /tmp/test2", "cp: cannot stat '/tmp/test': No such file or directory"))
    assert match(Command("cp /tmp/test /tmp/test2", "cp: cannot stat '/tmp/test': No such file or directory\n"))
    assert match(Command("cp /tmp/test /tmp/test2", "cp: cannot stat '/tmp/test': No such file or directory\n"))
    assert match(Command("cp /tmp/test /tmp/test2", "cp: cannot stat '/tmp/test': No such file or directory\n"))
    assert match(Command("cp /tmp/test /tmp/test2", "cp: cannot stat '/tmp/test': No such file or directory\n"))

# Generated at 2022-06-18 07:49:17.247000
# Unit test for function match
def test_match():
    assert match(Command(script="cp file1 file2", output="cp: cannot stat 'file1': No such file or directory"))
    assert match(Command(script="cp file1 file2", output="cp: directory 'file2' does not exist"))
    assert match(Command(script="mv file1 file2", output="mv: cannot stat 'file1': No such file or directory"))
    assert match(Command(script="mv file1 file2", output="mv: directory 'file2' does not exist"))
    assert not match(Command(script="cp file1 file2", output="cp: cannot stat 'file1': No such file or directory"))
    assert not match(Command(script="cp file1 file2", output="cp: directory 'file2' does not exist"))

# Generated at 2022-06-18 07:49:26.351497
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist\n'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory\n'))

# Generated at 2022-06-18 07:49:35.914811
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat file1: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory file2 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))
    assert not match(Command('cp file1 file2', 'cp: directory file2 does not exist\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat file1: No such file or directory\n'))
