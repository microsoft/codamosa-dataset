

# Generated at 2022-06-18 07:40:05.653302
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))

# Generated at 2022-06-18 07:40:13.594007
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))


# Generated at 2022-06-18 07:40:24.798475
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))

# Generated at 2022-06-18 07:40:34.639004
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match

# Generated at 2022-06-18 07:40:40.753653
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('mv test.txt test', 'mv: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory ‘test’ does not exist'))
    assert match(Command('mv test.txt test', 'mv: directory ‘test’ does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: No such file or directory'))
    assert not match(Command('mv test.txt test', 'mv: cannot stat ‘test.txt’: No such file or directory'))

# Generated at 2022-06-18 07:40:49.947040
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('mv test.txt test/', 'mv: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert match(Command('mv test.txt test/', 'mv: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: Permission denied'))

# Generated at 2022-06-18 07:40:59.501730
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:41:10.013305
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist\n"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: directory 'test' does not exist\n"))

# Generated at 2022-06-18 07:41:18.089848
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': Permission denied"))
    assert not match(Command("mv foo bar", "mv: cannot stat 'foo': Permission denied"))
    assert not match(Command("cp foo bar", "cp: directory 'foo' does exist"))


# Generated at 2022-06-18 07:41:27.776221
# Unit test for function match
def test_match():
    assert match(Command('cp a b', 'cp: cannot stat ‘a’: No such file or directory'))
    assert match(Command('mv a b', 'mv: cannot stat ‘a’: No such file or directory'))
    assert match(Command('cp a b', 'cp: directory ‘a’ does not exist'))
    assert match(Command('mv a b', 'mv: directory ‘a’ does not exist'))
    assert not match(Command('cp a b', 'cp: cannot stat ‘a’: No such file or directory\n'))
    assert not match(Command('mv a b', 'mv: cannot stat ‘a’: No such file or directory\n'))

# Generated at 2022-06-18 07:41:39.379915
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory\n'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist\n'))

# Generated at 2022-06-18 07:41:46.131766
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt /tmp/test.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt /tmp/test.txt", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt /tmp/test.txt", "cp: directory '/tmp/test.txt' does not exist"))
    assert match(Command("mv test.txt /tmp/test.txt", "mv: directory '/tmp/test.txt' does not exist"))
    assert not match(Command("cp test.txt /tmp/test.txt", "cp: cannot stat 'test.txt': Permission denied"))

# Generated at 2022-06-18 07:41:57.004225
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert match(Command("mv foo bar", "mv: directory 'foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': Permission denied"))
    assert not match(Command("mv foo bar", "mv: cannot stat 'foo': Permission denied"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': Is a directory"))
    assert not match(Command("mv foo bar", "mv: cannot stat 'foo': Is a directory"))



# Generated at 2022-06-18 07:42:07.105747
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert not match(Command("cp test.txt test", "cp: directory 'test' does not exist\n"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))

# Generated at 2022-06-18 07:42:14.979732
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist\n'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist\n'))

# Generated at 2022-06-18 07:42:19.653643
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory '/home/user/foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': Permission denied"))


# Generated at 2022-06-18 07:42:29.021458
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:42:38.388646
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory\n"))
    assert match(Command("cp foo bar", "cp: directory 'bar' does not exist"))
    assert match(Command("cp foo bar", "cp: directory 'bar' does not exist\n"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory\n"))
    assert match(Command("mv foo bar", "mv: directory 'bar' does not exist"))

# Generated at 2022-06-18 07:42:44.744824
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))


# Generated at 2022-06-18 07:42:53.962574
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file '
                         '‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file '
                         '‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file '
                             '‘test/’: Permission denied'))


# Generated at 2022-06-18 07:42:57.806827
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))


# Generated at 2022-06-18 07:43:07.420750
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat file1: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory file2 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat file1: No such file or directory'))

# Generated at 2022-06-18 07:43:15.977614
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('mv test.txt test', 'mv: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory ‘test’ does not exist'))
    assert match(Command('mv test.txt test', 'mv: directory ‘test’ does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: Permission denied'))
    assert not match(Command('mv test.txt test', 'mv: cannot stat ‘test.txt’: Permission denied'))

# Generated at 2022-06-18 07:43:21.879107
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))


# Generated at 2022-06-18 07:43:32.549816
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2` does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory `file2` does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory\n'))

# Generated at 2022-06-18 07:43:39.266648
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file2’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory\ncp: cannot stat ‘file2’: No such file or directory'))


# Generated at 2022-06-18 07:43:49.391446
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))
    assert match(Command('mv foo bar', 'mv: directory ‘bar’ does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert not match(Command('mv foo bar', 'mv: cannot stat ‘foo’: No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))

# Generated at 2022-06-18 07:44:00.067059
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:44:10.277043
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))

# Generated at 2022-06-18 07:44:18.293054
# Unit test for function match
def test_match():
    assert match(Command(script="cp test.txt test", stderr="cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command(script="mv test.txt test", stderr="mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command(script="cp test.txt test", stderr="cp: directory 'test' does not exist"))
    assert match(Command(script="mv test.txt test", stderr="mv: directory 'test' does not exist"))
    assert not match(Command(script="cp test.txt test", stderr="cp: cannot stat 'test.txt': No such file or directory"))

# Generated at 2022-06-18 07:44:31.790809
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:44:43.574896
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:44:52.597935
# Unit test for function match
def test_match():
    assert match(Command('cp /tmp/foo /tmp/bar', 'cp: cannot stat \'/tmp/foo\': No such file or directory'))
    assert match(Command('mv /tmp/foo /tmp/bar', 'mv: cannot stat \'/tmp/foo\': No such file or directory'))
    assert match(Command('cp /tmp/foo /tmp/bar', 'cp: directory \'/tmp/bar\' does not exist'))
    assert match(Command('mv /tmp/foo /tmp/bar', 'mv: directory \'/tmp/bar\' does not exist'))
    assert not match(Command('cp /tmp/foo /tmp/bar', 'cp: cannot stat \'/tmp/foo\': Permission denied'))

# Generated at 2022-06-18 07:45:03.249092
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2` does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory `file2` does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1`: Permission denied'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1`: Permission denied'))

# Generated at 2022-06-18 07:45:10.700432
# Unit test for function match

# Generated at 2022-06-18 07:45:18.146545
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('mv test.txt test/', 'mv: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert match(Command('mv test.txt test/', 'mv: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: Permission denied'))

# Generated at 2022-06-18 07:45:29.277867
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:45:39.402012
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:45:46.145354
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))

# Generated at 2022-06-18 07:45:56.691399
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))

# Generated at 2022-06-18 07:46:05.150089
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))

# Generated at 2022-06-18 07:46:14.385214
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert match(Command("mv file1 file2", "mv: directory 'file2' does not exist"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert not match(Command("cp file1 file2", "cp: directory 'file2' does not exist\n"))

# Generated at 2022-06-18 07:46:22.486648
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert not match(Command("cp foo bar", "cp: directory 'foo' does not exist"))


# Generated at 2022-06-18 07:46:29.422326
# Unit test for function match
def test_match():
    assert match(Command('cp a b', 'cp: cannot stat ‘a’: No such file or directory'))
    assert match(Command('cp a b', 'cp: cannot stat ‘a’: No such file or directory'))
    assert match(Command('cp a b', 'cp: directory ‘b’ does not exist'))
    assert not match(Command('cp a b', 'cp: cannot stat ‘a’: No such file or directory'))


# Generated at 2022-06-18 07:46:39.209949
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt /tmp/test.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt /tmp/test.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt /tmp/test.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt /tmp/test.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt /tmp/test.txt", "cp: cannot stat 'test.txt': No such file or directory"))

# Generated at 2022-06-18 07:46:48.816501
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory\n"))

# Generated at 2022-06-18 07:46:59.842783
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `foo\' does not exist'))

# Generated at 2022-06-18 07:47:07.752829
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))

# Generated at 2022-06-18 07:47:14.019124
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))


# Generated at 2022-06-18 07:47:19.730946
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))


# Generated at 2022-06-18 07:47:32.462672
# Unit test for function match
def test_match():
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory"))
    assert match(Command("mv a b", "mv: cannot stat 'a': No such file or directory"))
    assert match(Command("cp a b", "cp: directory '/home/user/a' does not exist"))
    assert not match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert not match(Command("cp a b", "cp: directory '/home/user/a' does not exist\n"))
    assert not match(Command("cp a b", "cp: directory '/home/user/a' does not exist\n"))
    assert not match(Command("cp a b", "cp: directory '/home/user/a' does not exist\n"))

# Generated at 2022-06-18 07:47:37.521834
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory ‘test’ does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: No such file or directory'))


# Generated at 2022-06-18 07:47:45.210329
# Unit test for function match
def test_match():
    assert match(Command("cp /home/user/test.txt /home/user/test2.txt", "cp: cannot stat '/home/user/test.txt': No such file or directory\n"))
    assert match(Command("cp /home/user/test.txt /home/user/test2.txt", "cp: cannot stat '/home/user/test.txt': No such file or directory\n"))
    assert match(Command("cp /home/user/test.txt /home/user/test2.txt", "cp: cannot stat '/home/user/test.txt': No such file or directory\n"))
    assert match(Command("cp /home/user/test.txt /home/user/test2.txt", "cp: cannot stat '/home/user/test.txt': No such file or directory\n"))

# Generated at 2022-06-18 07:47:54.941452
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2` does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory `file2` does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1`: Permission denied'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1`: Permission denied'))


# Generated at 2022-06-18 07:48:01.813112
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:48:07.914283
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('mv test.txt test/', 'mv: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: Permission denied'))


# Generated at 2022-06-18 07:48:17.057564
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory\n'))

# Generated at 2022-06-18 07:48:22.127126
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': Permission denied"))


# Generated at 2022-06-18 07:48:31.496712
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))
    assert match(Command('mv foo bar', 'mv: directory ‘bar’ does not exist'))
    assert not match(Command('cp foo bar', 'cp: directory ‘bar’ does exist'))
    assert not match(Command('mv foo bar', 'mv: directory ‘bar’ does exist'))


# Generated at 2022-06-18 07:48:41.041698
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert match(Command("mv file1 file2", "mv: directory 'file2' does not exist"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert not match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory\n"))

# Generated at 2022-06-18 07:48:53.954417
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat test.txt: No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory test does not exist'))
    assert match(Command('mv test.txt test', 'mv: cannot stat test.txt: No such file or directory'))
    assert match(Command('mv test.txt test', 'mv: directory test does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat test.txt: No such file or directory'))
    assert not match(Command('cp test.txt test', 'cp: directory test does not exist'))
    assert not match(Command('mv test.txt test', 'mv: cannot stat test.txt: No such file or directory'))

# Generated at 2022-06-18 07:49:02.780564
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))

# Generated at 2022-06-18 07:49:11.282292
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file2’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file1’ does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file2’: No such file or directory'))

# Generated at 2022-06-18 07:49:17.368383
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:49:26.409692
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory\n'))

# Generated at 2022-06-18 07:49:35.957548
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test/", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test/", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test/", "cp: directory 'test/' does not exist"))
    assert not match(Command("cp test.txt test/", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert not match(Command("cp test.txt test/", "cp: directory 'test/' does not exist\n"))
    assert not match(Command("cp test.txt test/", "cp: cannot stat 'test.txt': No such file or directory\n"))

# Generated at 2022-06-18 07:49:45.242168
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))

# Generated at 2022-06-18 07:49:52.827381
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))