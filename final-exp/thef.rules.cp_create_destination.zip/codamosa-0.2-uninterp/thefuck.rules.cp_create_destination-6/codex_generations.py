

# Generated at 2022-06-18 07:40:02.601201
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist\n'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist\n'))

# Generated at 2022-06-18 07:40:12.779972
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))

# Generated at 2022-06-18 07:40:20.000752
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))
    assert not match(Command('cp file1 file2', 'cp: directory file2 does not exist\n'))


# Generated at 2022-06-18 07:40:30.717810
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))

# Generated at 2022-06-18 07:40:38.684778
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))
    assert match(Command('mv foo bar', 'mv: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('mv foo bar', 'mv: directory ‘bar’ does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory\n'))
    assert not match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist\n'))

# Generated at 2022-06-18 07:40:48.435586
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test2.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test2.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test2.txt\': No such file or directory'))


# Generated at 2022-06-18 07:40:52.584876
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': Permission denied"))


# Generated at 2022-06-18 07:41:01.222697
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))

# Generated at 2022-06-18 07:41:11.339461
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt',
                         'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt',
                         'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt',
                         'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))

# Generated at 2022-06-18 07:41:21.913695
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert match(Command("mv foo bar", "mv: directory 'foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory\n"))
    assert not match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory\n"))
    assert not match(Command("cp foo bar", "cp: directory 'foo' does not exist\n"))

# Generated at 2022-06-18 07:41:33.115417
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist\n"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist\n"))
    assert match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))

# Generated at 2022-06-18 07:41:41.742237
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2 file3', '', 'cp: cannot stat ‘file3’: No such file or directory'))
    assert match(Command('mv file1 file2 file3', '', 'mv: cannot stat ‘file3’: No such file or directory'))
    assert match(Command('cp file1 file2 file3', '', 'cp: directory ‘file3’ does not exist'))
    assert match(Command('mv file1 file2 file3', '', 'mv: directory ‘file3’ does not exist'))
    assert not match(Command('cp file1 file2 file3', '', 'cp: cannot stat ‘file3’: No such file or directory'))

# Generated at 2022-06-18 07:41:49.665660
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match

# Generated at 2022-06-18 07:42:01.040419
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))

# Generated at 2022-06-18 07:42:07.705494
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', '', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', '', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', '', 'cp: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', '', 'cp: cannot stat `file1\': No such file or directory'))


# Generated at 2022-06-18 07:42:15.368998
# Unit test for function match
def test_match():
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))

# Generated at 2022-06-18 07:42:26.035252
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory\n'))

# Generated at 2022-06-18 07:42:34.635006
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory\n'))

# Generated at 2022-06-18 07:42:39.388970
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test/", "cp: cannot create regular file 'test/': No such file or directory"))
    assert match(Command("cp test.txt test/", "cp: directory 'test/' does not exist"))
    assert not match(Command("cp test.txt test/", "cp: cannot create regular file 'test/': Permission denied"))


# Generated at 2022-06-18 07:42:49.931780
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2` does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory `file2` does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: directory `file2` does not exist'))

# Generated at 2022-06-18 07:43:02.088190
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))

# Generated at 2022-06-18 07:43:10.574657
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))

# Generated at 2022-06-18 07:43:21.286660
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))

# Generated at 2022-06-18 07:43:31.974111
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))

# Generated at 2022-06-18 07:43:40.589370
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp -r dir1 dir2', 'cp: directory dir1 does not exist'))
    assert match(Command('mv -r dir1 dir2', 'mv: directory dir1 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: Permission denied'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: Permission denied'))

# Generated at 2022-06-18 07:43:50.493188
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))

# Generated at 2022-06-18 07:44:01.115988
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert match(Command("mv foo bar", "mv: directory 'foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert not match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert not match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert not match(Command("mv foo bar", "mv: directory 'foo' does not exist"))

# Generated at 2022-06-18 07:44:07.619074
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))


# Generated at 2022-06-18 07:44:16.300073
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist\n"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))

# Generated at 2022-06-18 07:44:25.470017
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat /home/user/test.txt: No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat /home/user/test.txt: No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat /home/user/test.txt: No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat /home/user/test.txt: No such file or directory'))

# Generated at 2022-06-18 07:44:34.831049
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))


# Generated at 2022-06-18 07:44:45.688684
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:44:54.493888
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2` does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory `file2` does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory\n'))

# Generated at 2022-06-18 07:45:03.544147
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert match(Command("mv foo bar", "mv: directory 'foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': Permission denied"))
    assert not match(Command("mv foo bar", "mv: cannot stat 'foo': Permission denied"))


# Generated at 2022-06-18 07:45:13.127264
# Unit test for function match

# Generated at 2022-06-18 07:45:17.017950
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))


# Generated at 2022-06-18 07:45:25.703047
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert not match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))


# Generated at 2022-06-18 07:45:36.125939
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test/", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test/", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test/", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test/", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test/", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test/", "cp: cannot stat 'test.txt': No such file or directory\n"))

# Generated at 2022-06-18 07:45:43.191066
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert match(Command("mv file1 file2", "mv: directory 'file2' does not exist"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert not match(Command("cp file1 file2", "cp: directory 'file2' does not exist\n"))

# Generated at 2022-06-18 07:45:48.578710
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat file1: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))


# Generated at 2022-06-18 07:45:59.968980
# Unit test for function match
def test_match():
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory"))
    assert match(Command("mv a b", "mv: cannot stat 'a': No such file or directory"))
    assert match(Command("cp a b", "cp: directory 'a' does not exist"))
    assert not match(Command("cp a b", "cp: directory 'a' does not exist"))
    assert not match(Command("cp a b", "cp: directory 'a' does not exist"))
    assert not match(Command("cp a b", "cp: directory 'a' does not exist"))


# Generated at 2022-06-18 07:46:07.967636
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:46:17.131755
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat \'file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat \'file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat \'file1\': No such file or directory\n'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat \'file1\': No such file or directory\n'))
    assert not match(Command('cp file1 file2', 'cp: directory file2 does not exist\n'))


# Generated at 2022-06-18 07:46:27.421675
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))

# Generated at 2022-06-18 07:46:38.420298
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test/',
                         'cp: cannot create regular file ‘/home/user/test/’: No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test/',
                         'cp: cannot create regular file ‘/home/user/test/’: No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test/',
                         'cp: directory ‘/home/user/test/’ does not exist'))

# Generated at 2022-06-18 07:46:48.077684
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', '', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', '', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('mv /home/user/test.txt /home/user/test2.txt', '', 'mv: cannot stat \'/home/user/test.txt\': No such file or directory'))

# Generated at 2022-06-18 07:46:59.099911
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat file1: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))
    assert not match(Command('cp file1 file2', 'cp: directory file2 does not exist\n'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))
    assert not match(Command('cp file1 file2', 'cp: directory file2 does not exist\n'))
   

# Generated at 2022-06-18 07:47:04.972266
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))


# Generated at 2022-06-18 07:47:13.509953
# Unit test for function match
def test_match():
    assert match(Command("cp -r /home/user/test /home/user/test2", "cp: cannot stat '/home/user/test': No such file or directory\n"))
    assert match(Command("cp -r /home/user/test /home/user/test2", "cp: cannot stat '/home/user/test': No such file or directory\n"))
    assert match(Command("cp -r /home/user/test /home/user/test2", "cp: cannot stat '/home/user/test': No such file or directory\n"))
    assert match(Command("cp -r /home/user/test /home/user/test2", "cp: cannot stat '/home/user/test': No such file or directory\n"))

# Generated at 2022-06-18 07:47:23.245342
# Unit test for function match
def test_match():
    assert match(Command('cp /tmp/foo /tmp/bar', '', 'cp: cannot stat \'/tmp/foo\': No such file or directory'))
    assert match(Command('cp /tmp/foo /tmp/bar', '', 'cp: cannot stat \'/tmp/foo\': No such file or directory\n'))
    assert match(Command('cp /tmp/foo /tmp/bar', '', 'cp: directory \'/tmp/bar\' does not exist'))
    assert match(Command('cp /tmp/foo /tmp/bar', '', 'cp: directory \'/tmp/bar\' does not exist\n'))
    assert match(Command('mv /tmp/foo /tmp/bar', '', 'mv: cannot stat \'/tmp/foo\': No such file or directory'))

# Generated at 2022-06-18 07:47:30.780495
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test2.txt", "cp: cannot stat 'test.txt': No such file or directory"))

# Generated at 2022-06-18 07:47:38.512613
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:47:47.425802
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:47:56.909517
# Unit test for function match
def test_match():
    assert match(Command("cp /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory"))
    assert match(Command("cp /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))
    assert match(Command("cp /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))
    assert match(Command("cp /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))
    assert match(Command("cp /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))

# Generated at 2022-06-18 07:48:02.494376
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))

# Generated at 2022-06-18 07:48:10.284860
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert match(Command('mv test.txt test/', 'mv: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('mv test.txt test/', 'mv: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: Permission denied'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: Is a directory'))

# Generated at 2022-06-18 07:48:16.109492
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))


# Generated at 2022-06-18 07:48:27.547845
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))

# Generated at 2022-06-18 07:48:37.672437
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert match(Command("mv file1 file2", "mv: directory 'file2' does not exist"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert not match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert not match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))

# Generated at 2022-06-18 07:48:44.838599
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))

# Generated at 2022-06-18 07:48:58.077305
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('mv test.txt test', 'mv: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory ‘test’ does not exist'))
    assert match(Command('mv test.txt test', 'mv: directory ‘test’ does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat ‘test.txt’: Permission denied'))
    assert not match(Command('mv test.txt test', 'mv: cannot stat ‘test.txt’: Permission denied'))


# Generated at 2022-06-18 07:49:07.314998
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))

# Generated at 2022-06-18 07:49:15.206929
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:49:21.547088
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))


# Generated at 2022-06-18 07:49:30.353126
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))


# Generated at 2022-06-18 07:49:38.001484
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': Permission denied"))
    assert not match(Command("mv file1 file2", "mv: cannot stat 'file1': Permission denied"))
    assert not match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))


# Generated at 2022-06-18 07:49:46.946371
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert match(Command("mv test.txt test", "mv: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': Permission denied"))
    assert not match(Command("mv test.txt test", "mv: cannot stat 'test.txt': Permission denied"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': Is a directory"))

# Generated at 2022-06-18 07:49:55.220797
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))