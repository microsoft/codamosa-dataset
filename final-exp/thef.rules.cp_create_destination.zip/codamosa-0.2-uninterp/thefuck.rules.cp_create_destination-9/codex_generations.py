

# Generated at 2022-06-18 07:40:00.440492
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))


# Generated at 2022-06-18 07:40:11.410195
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("mv file1 file2", "mv: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))

# Generated at 2022-06-18 07:40:19.513714
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))


# Generated at 2022-06-18 07:40:26.570708
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))


# Generated at 2022-06-18 07:40:36.122453
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist\n'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory\n'))

# Generated at 2022-06-18 07:40:46.441144
# Unit test for function match
def test_match():
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))
    assert match(Command("cp a b", "cp: cannot stat 'a': No such file or directory\n"))

# Generated at 2022-06-18 07:40:57.313782
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt /tmp/test.txt', 'cp: cannot stat \'test.txt\': No such file or directory'))
    assert match(Command('mv test.txt /tmp/test.txt', 'mv: cannot stat \'test.txt\': No such file or directory'))
    assert match(Command('cp test.txt /tmp/test.txt', 'cp: directory /tmp/test.txt does not exist'))
    assert match(Command('mv test.txt /tmp/test.txt', 'mv: directory /tmp/test.txt does not exist'))
    assert not match(Command('cp test.txt /tmp/test.txt', 'cp: cannot stat \'test.txt\': No such file or directory'))

# Generated at 2022-06-18 07:41:08.092845
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:41:14.417567
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file2’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file1’ does not exist'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory\ncp: cannot stat ‘file2’: No such file or directory'))

# Generated at 2022-06-18 07:41:25.145545
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert match(Command("mv foo bar", "mv: directory 'foo' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert not match(Command("mv foo bar", "mv: cannot stat 'foo': No such file or directory"))
    assert not match(Command("cp foo bar", "cp: directory 'foo' does not exist"))
    assert not match(Command("mv foo bar", "mv: directory 'foo' does not exist"))

# Generated at 2022-06-18 07:41:36.299425
# Unit test for function match
def test_match():
    assert match(Command(script="cp -r /home/user/test /home/user/test2", output="cp: cannot stat '/home/user/test': No such file or directory"))
    assert match(Command(script="cp -r /home/user/test /home/user/test2", output="cp: directory '/home/user/test' does not exist"))
    assert not match(Command(script="cp -r /home/user/test /home/user/test2", output="cp: directory '/home/user/test' does not exist"))


# Generated at 2022-06-18 07:41:43.950021
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': Permission denied"))
    assert not match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert not match(Command("mv test.txt test", "mv: cannot stat 'test.txt': Permission denied"))

# Generated at 2022-06-18 07:41:53.986292
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat \'/home/user/test.txt\': No such file or directory\n'))

# Generated at 2022-06-18 07:42:04.151292
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))

# Generated at 2022-06-18 07:42:09.629353
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist\n'))


# Generated at 2022-06-18 07:42:16.541295
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:42:27.224137
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert not match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert not match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))

# Generated at 2022-06-18 07:42:32.759743
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))
    assert match(Command('cp test.txt test', 'cp: directory `test\' does not exist'))
    assert not match(Command('cp test.txt test', 'cp: cannot stat `test.txt\': No such file or directory'))


# Generated at 2022-06-18 07:42:42.673116
# Unit test for function match
def test_match():
    assert match(Command('cp a b', 'cp: cannot stat `a\': No such file or directory'))
    assert match(Command('cp a b', 'cp: cannot stat `a\': No such file or directory'))
    assert match(Command('mv a b', 'mv: cannot stat `a\': No such file or directory'))
    assert match(Command('cp a b', 'cp: cannot stat `a\': No such file or directory'))
    assert match(Command('cp a b', 'cp: cannot stat `a\': No such file or directory'))
    assert match(Command('cp a b', 'cp: cannot stat `a\': No such file or directory'))
    assert match(Command('cp a b', 'cp: cannot stat `a\': No such file or directory'))

# Generated at 2022-06-18 07:42:54.304034
# Unit test for function match
def test_match():
    assert match(Command("cp -r /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory"))
    assert match(Command("cp -r /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))
    assert match(Command("cp -r /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))
    assert match(Command("cp -r /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))
    assert match(Command("cp -r /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))

# Generated at 2022-06-18 07:43:07.734156
# Unit test for function match
def test_match():
    assert match(Command("cp /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory"))
    assert match(Command("cp /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))
    assert match(Command("cp /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))
    assert match(Command("cp /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))
    assert match(Command("cp /tmp/foo /tmp/bar", "cp: cannot stat '/tmp/foo': No such file or directory\n"))

# Generated at 2022-06-18 07:43:13.365354
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp -r dir1 dir2', 'cp: directory `dir1` does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory\n'))


# Generated at 2022-06-18 07:43:19.654099
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))


# Generated at 2022-06-18 07:43:31.542285
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:43:37.670989
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))


# Generated at 2022-06-18 07:43:43.454753
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', ''))
    assert not match(Command('mv file1 file2', ''))


# Generated at 2022-06-18 07:43:53.872713
# Unit test for function match
def test_match():
    assert match(Command('cp /tmp/foo /tmp/bar', 'cp: cannot stat \'/tmp/foo\': No such file or directory'))
    assert match(Command('cp /tmp/foo /tmp/bar', 'cp: cannot stat \'/tmp/foo\': No such file or directory'))
    assert match(Command('cp /tmp/foo /tmp/bar', 'cp: cannot stat \'/tmp/foo\': No such file or directory'))
    assert match(Command('cp /tmp/foo /tmp/bar', 'cp: cannot stat \'/tmp/foo\': No such file or directory'))
    assert match(Command('cp /tmp/foo /tmp/bar', 'cp: cannot stat \'/tmp/foo\': No such file or directory'))

# Generated at 2022-06-18 07:44:03.747545
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:44:13.809186
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert not match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert not match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))

# Generated at 2022-06-18 07:44:20.068814
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:44:35.460059
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist"))
    assert match(Command("cp file1 file2", "cp: directory 'file2' does not exist\n"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))
    assert not match(Command("cp file1 file2", "cp: directory 'file2' does not exist\n"))
    assert not match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory\n"))

# Generated at 2022-06-18 07:44:42.840745
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))


# Generated at 2022-06-18 07:44:50.402822
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:45:00.478462
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))

# Generated at 2022-06-18 07:45:11.211559
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory ‘file2’ does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: directory ‘file2’ does not exist'))

# Generated at 2022-06-18 07:45:18.291233
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist\n"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory\n"))


# Generated at 2022-06-18 07:45:29.455687
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat file1: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory file2 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat file1: No such file or directory'))

# Generated at 2022-06-18 07:45:39.558377
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp -r dir1 dir2', 'cp: omitting directory `dir1\'\ncp: directory `dir2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': Permission denied'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1\': Permission denied'))

# Generated at 2022-06-18 07:45:44.956805
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: cannot stat ‘test.txt’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot stat ‘test.txt’: No such file or directory'))


# Generated at 2022-06-18 07:45:51.584697
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))


# Generated at 2022-06-18 07:46:07.152405
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))

# Generated at 2022-06-18 07:46:16.705129
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))

# Generated at 2022-06-18 07:46:26.982481
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:46:35.070935
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))


# Generated at 2022-06-18 07:46:43.819618
# Unit test for function match
def test_match():
    assert match(Command('cp -r /home/user/test/ /home/user/test2/', 'cp: cannot stat \'/home/user/test/\': No such file or directory'))
    assert match(Command('cp -r /home/user/test/ /home/user/test2/', 'cp: cannot stat \'/home/user/test/\': No such file or directory'))
    assert match(Command('cp -r /home/user/test/ /home/user/test2/', 'cp: cannot stat \'/home/user/test/\': No such file or directory'))
    assert not match(Command('cp -r /home/user/test/ /home/user/test2/', 'cp: cannot stat \'/home/user/test/\': No such file or directory'))


# Generated at 2022-06-18 07:46:54.828944
# Unit test for function match

# Generated at 2022-06-18 07:47:04.692767
# Unit test for function match
def test_match():
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match(Command("cp file1 file2", "cp: cannot stat 'file1': No such file or directory"))
    assert match

# Generated at 2022-06-18 07:47:13.159617
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:47:18.903301
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory ‘bar’ does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat ‘foo’: No such file or directory'))


# Generated at 2022-06-18 07:47:29.036933
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))

# Generated at 2022-06-18 07:47:43.748281
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1\': No such file or directory\n'))

# Generated at 2022-06-18 07:47:54.162971
# Unit test for function match
def test_match():
    assert match(Command('cp a b', 'cp: cannot stat ‘a’: No such file or directory'))
    assert match(Command('cp a b', 'cp: cannot stat ‘b’: No such file or directory'))
    assert match(Command('mv a b', 'mv: cannot stat ‘a’: No such file or directory'))
    assert match(Command('mv a b', 'mv: cannot stat ‘b’: No such file or directory'))
    assert match(Command('cp a b', 'cp: directory ‘b’ does not exist'))
    assert match(Command('mv a b', 'mv: directory ‘b’ does not exist'))

# Generated at 2022-06-18 07:47:58.080074
# Unit test for function match
def test_match():
    assert match(Command("cp foo bar", "cp: cannot stat 'foo': No such file or directory"))
    assert match(Command("cp foo bar", "cp: directory 'bar' does not exist"))
    assert not match(Command("cp foo bar", "cp: cannot stat 'foo': Permission denied"))


# Generated at 2022-06-18 07:48:03.315914
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2\' does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1\': No such file or directory'))


# Generated at 2022-06-18 07:48:10.798203
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/test.txt’: No such file or directory'))
    assert match(Command('mv test.txt test/', 'mv: cannot create regular file ‘test/test.txt’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert match(Command('mv test.txt test/', 'mv: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/test.txt’: Permission denied'))

# Generated at 2022-06-18 07:48:21.099390
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))

# Generated at 2022-06-18 07:48:31.639580
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory file2 does not exist'))
    assert match(Command('mv file1 file2', 'mv: cannot stat file1: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: directory file2 does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat file1: No such file or directory\n'))
    assert not match(Command('cp file1 file2', 'cp: directory file2 does not exist\n'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat file1: No such file or directory\n'))


# Generated at 2022-06-18 07:48:41.127526
# Unit test for function match
def test_match():
    assert match(Command('cp -r /home/user/test /home/user/test2', 'cp: cannot stat \'/home/user/test\': No such file or directory'))
    assert match(Command('cp -r /home/user/test /home/user/test2', 'cp: cannot stat \'/home/user/test\': No such file or directory'))
    assert match(Command('cp -r /home/user/test /home/user/test2', 'cp: directory \'/home/user/test\' does not exist'))
    assert match(Command('mv /home/user/test /home/user/test2', 'mv: cannot stat \'/home/user/test\': No such file or directory'))

# Generated at 2022-06-18 07:48:48.644356
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))


# Generated at 2022-06-18 07:48:58.039967
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))
    assert match(Command('cp file1 file2', 'cp: directory `file2` does not exist'))
    assert match(Command('mv file1 file2', 'mv: directory `file2` does not exist'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat `file1`: No such file or directory'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat `file1`: No such file or directory'))

# Generated at 2022-06-18 07:49:14.228402
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert match(Command('mv test.txt test/', 'mv: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('mv test.txt test/', 'mv: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: Permission denied'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: File exists'))


# Generated at 2022-06-18 07:49:21.415212
# Unit test for function match
def test_match():
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat ‘/home/user/test.txt’: No such file or directory'))
    assert match(Command('cp /home/user/test.txt /home/user/test2.txt', 'cp: cannot stat ‘/home/user/test.txt’: No such file or directory'))
    assert match(Command('mv /home/user/test.txt /home/user/test2.txt', 'mv: cannot stat ‘/home/user/test.txt’: No such file or directory'))

# Generated at 2022-06-18 07:49:32.048009
# Unit test for function match
def test_match():
    assert match(Command("cp test.txt test", "cp: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("mv test.txt test", "mv: cannot stat 'test.txt': No such file or directory"))
    assert match(Command("cp test.txt test", "cp: directory 'test' does not exist"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': Permission denied"))
    assert not match(Command("mv test.txt test", "mv: cannot stat 'test.txt': Permission denied"))
    assert not match(Command("cp test.txt test", "cp: cannot stat 'test.txt': Is a directory"))
    assert not match(Command("mv test.txt test", "mv: cannot stat 'test.txt': Is a directory"))

# Generated at 2022-06-18 07:49:41.302943
# Unit test for function match
def test_match():
    assert match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: No such file or directory'))
    assert match(Command('cp -r dir1 dir2', 'cp: omitting directory ‘dir1’'))
    assert match(Command('mv -r dir1 dir2', 'mv: omitting directory ‘dir1’'))
    assert not match(Command('cp file1 file2', 'cp: cannot stat ‘file1’: Permission denied'))
    assert not match(Command('mv file1 file2', 'mv: cannot stat ‘file1’: Permission denied'))

# Generated at 2022-06-18 07:49:48.552973
# Unit test for function match
def test_match():
    assert match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory'))
    assert match(Command('cp foo bar', 'cp: directory `bar\' does not exist'))
    assert match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory'))
    assert match(Command('mv foo bar', 'mv: directory `bar\' does not exist'))
    assert not match(Command('cp foo bar', 'cp: cannot stat `foo\': No such file or directory\n'))
    assert not match(Command('cp foo bar', 'cp: directory `bar\' does not exist\n'))
    assert not match(Command('mv foo bar', 'mv: cannot stat `foo\': No such file or directory\n'))

# Generated at 2022-06-18 07:49:54.702250
# Unit test for function match
def test_match():
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
    assert match(Command('cp test.txt test/', 'cp: directory ‘test/’ does not exist'))
    assert not match(Command('cp test.txt test/', 'cp: cannot create regular file ‘test/’: No such file or directory'))
