

# Generated at 2022-06-26 05:35:47.148186
# Unit test for function match
def test_match():
    input_0 = b"cp: cannot stat 'loch': No such file or directory"
    output_true = match(input_0)
    input_1 = b'cp: directory "/Users/loch/Projects/test" does not exist'
    output_false = match(input_1)
    assert output_true != output_false


# Generated at 2022-06-26 05:35:49.273291
# Unit test for function match
def test_match():
    command = Command(script=bytes_0, output=bytes_0)
    assert match(command)


# Generated at 2022-06-26 05:35:57.783159
# Unit test for function match
def test_match():
    assert match(Command(script="cp 'test.txt' 'test/'", output="cp: directory 'test/' does not exist"))
    assert not match(Command(script="cp 'test.txt' 'test/'", output="cp: 'test/' and 'test/' are the same file"))
    assert match(Command(script="mv 'test.txt' 'test/'", output="mv: cannot move 'test.txt' to 'test/': No such file or directory"))
    assert not match(Command(script="mv 'test.txt' 'test/'", output="mv: cannot move 'test.txt' to 'test/': Not a directory"))


# Generated at 2022-06-26 05:36:03.117798
# Unit test for function match
def test_match():
  bytes_0 = b'\xfb7;\xb9\xb3\x99\x9f\x84z\xeeD\x05\xee\xa5\xa1\x03\x02\xed\xc13'
  var_0 = match(bytes_0)
  assert var_0 == False


# Generated at 2022-06-26 05:36:10.758057
# Unit test for function match
def test_match():
    assert match(u"cp: directory '/sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf' does not exist")
    assert match(u"cp: directory '/sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf' does not exist")
    assert match(u"cp: directory /sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf does not exist")

# Generated at 2022-06-26 05:36:19.864115
# Unit test for function match
def test_match():
    print("Test match")
    # Test match function works
    match_bytes_0 = b'\xfb7;\xb9\xb3\x99\x9f\x84z\xeeD\x05\xee\xa5\xa1\x03\x02\xed\xc13'
    match_var_0 = match(match_bytes_0)
    print("Test match works", match_var_0)
    # Test match function is None
    match_var_1 = match(None)
    assert match_var_1 is None, "ERROR: match(None) = {}, want {}".format(match_var_1, None)
    print("Test match None successful.")
    # Test match function is false
    match_var_2 = match(False)

# Generated at 2022-06-26 05:36:22.801461
# Unit test for function match
def test_match():
    assert match(b'\xfb7;\xb9\xb3\x99\x9f\x84z\xeeD\x05\xee\xa5\xa1\x03\x02\xed\xc13') == True


# Generated at 2022-06-26 05:36:30.674453
# Unit test for function match
def test_match():
    assert(isinstance(match("mkdir -p ~/foo\n"), bool))
    assert(isinstance(match("cp -f ~/foo/*.txt ~/bar/\n"), bool))
    assert(isinstance(match("mv /home/foo/bar ~/bar\n"), bool))
    assert(isinstance(match("cp -f /home/foo/*.txt /home/foo/\n"), bool))
    assert(isinstance(match("cp -f /home/foo/*.txt /home/bar/\n"), bool))
    assert(isinstance(match("cp /home/foo/bar ~/bar\n"), bool))
    assert(isinstance(match("cp /home/foo/bar ~/.config/bar\n"), bool))


# Generated at 2022-06-26 05:36:35.540820
# Unit test for function match
def test_match():
    returned_value = match('')
    assert returned_value == False
    assert match('') == False
    assert match('') == False
    assert match('ABC') == False
    assert match('ABC') == False
    assert match('ABC') == False
    assert match('ABC') == False
    assert match('ABC') == True
    assert match('ABCD') == False


# Generated at 2022-06-26 05:36:42.110780
# Unit test for function match
def test_match():
    assert match((b'cp: cannot create regular file `/sdcard/tools/fb/fb.txt\': No such file or directory\n', b'', 1)) == True
    assert match((b'cp: cannot create regular file `/sdcard/tools/fb/fb.txt\': No such file or directory\n', b'', 1)) == True
    assert match((b"cp: directory '/home/mabu/documents' does not exist\n", b'', 1)) == True
    assert match((b'cp: cannot create regular file `/sdcard/tools/fb/fb.txt\': No such file or directory\n', b'', 1)) == True
    assert match((b"cp: directory '/home/mabu/documents' does not exist\n", b'', 1)) == True

# Generated at 2022-06-26 05:36:54.255131
# Unit test for function match
def test_match():
    assert not match(Command('ls hh', ''))
    assert not match(Command('ls hh', 'ls: hh: No such file or directory'))
    assert not match(Command('ls hh', 'ls: hh: No such file or directory\n'))
    assert match(Command('ls hh', 'ls: hh: No such file or directory\nmkdir: hh: File exists'))
    assert not match(Command('ls hh', 'ls: hh: No such file or directory\nls: hh: No such file or directory\n'))
    assert match(Command('ls hh', 'ls: hh: No such file or directory\nls: hh: File exists\n'))

# Generated at 2022-06-26 05:37:03.831587
# Unit test for function match

# Generated at 2022-06-26 05:37:08.402470
# Unit test for function match
def test_match():
    # Control flow: if-else statement
    bytes_0 = b'\xfb7;\xb9\xb3\x99\x9f\x84z\xeeD\x05\xee\xa5\xa1\x03\x02\xed\xc13'
    var_0 = match(bytes_0)
    
    # Control flow: if-else statement

# Generated at 2022-06-26 05:37:12.102923
# Unit test for function match
def test_match():
    command_0 = Command('mv /tmp/foo/documents/* /tmp/bar/documents/', 'mv: cannot stat \'/*\': No such file or directory')
    var_0 = match(command_0)
    assert var_0 == True



# Generated at 2022-06-26 05:37:14.624251
# Unit test for function match
def test_match():
    assert match(b"cp: directory '/tmp/123' does not exist")
    assert not match(b"cp: cannot stat '/tmp/123': No such file or directory")


# Generated at 2022-06-26 05:37:19.910916
# Unit test for function match
def test_match():
    bytes_0 = b'\xfb7;\xb9\xb3\x99\x9f\x84z\xeeD\x05\xee\xa5\xa1\x03\x02\xed\xc13'
    expected = True
    actual = match(bytes_0)
    assert actual == expected


# Generated at 2022-06-26 05:37:26.851833
# Unit test for function match

# Generated at 2022-06-26 05:37:33.589540
# Unit test for function match
def test_match():
    test = 'cp -r /Users/htz/Desktop/test/ /Users/htz/Desktop/test1/'
    output = 'cp: /Users/htz/Desktop/test: No such file or directory'
    command = Command(test, output)
    assert match(command)
    test = 'cp -r /Users/htz/Desktop/test/ /Users/htz/Desktop/test1/'
    output = 'cp: directory /Users/htz/Desktop/test does not exist'
    command = Command(test, output)
    assert match(command)
    test = 'mv .ssh/authorized_keys .ssh/authorized_keys.bak'
    output = 'mv: .ssh/authorized_keys: No such file or directory'
    command = Command(test, output)
    assert match(command)


# Generated at 2022-06-26 05:37:39.286358
# Unit test for function match
def test_match():
    bytes_0 = b'cp: omitting directory `/usr/local/Cellar/node/0.10.36/bin/node-waf\''
    command_0 = Command(script = "cp foo /usr/local/Cellar/node/0.10.36/bin/node-waf", stdout = bytes_0)
    assert match(command_0) == True
    bytes_1 = b'cp: omitting directory `/usr/local/Cellar/node/0.10.36/bin/node-waf\''
    command_1 = Command(script = "cp foo /usr/local/Cellar/node/0.10.36/bin/node-waf", stderr = bytes_1)
    assert match(command_1) == False


# Generated at 2022-06-26 05:37:50.638141
# Unit test for function match
def test_match():
    assert match(b'/home/user/random_project/trunk/babylon/build/tmp/babylon/babylon_web/lib/babylon-2.0.0.js') == "No such file or directory"
    assert match(b'/home/user/random_project/trunk/babylon/build/tmp/babylon/babylon_web/lib/babylon-2.0.0.js') == "cp: directory /home/user/random_project/trunk/babylon/build/tmp/babylon/babylon_web/lib/babylon-2.0.0.js does not exist"

# Generated at 2022-06-26 05:37:59.918315
# Unit test for function match
def test_match():
    b'\xfb7;\xb9\xb3\x99\x9f\x84z\xeeD\x05\xee\xa5\xa1\x03\x02\xed\xc13'
    assert match() == False


# Generated at 2022-06-26 05:38:09.474191
# Unit test for function match
def test_match():
    command = Command("cp foo/bar/baz.py $HOME/..")
    assert match(command) is True
    command = Command("cp foo/bar/baz.py $HOME/../")
    assert match(command) is True
    command = Command("cp foo/bar/baz.py $HOME/../quux.py")
    assert match(command) is True
    command = Command("cp foo/bar/baz.py $HOME/../../")
    assert match(command) is False
    command = Command("cp foo/bar/baz.py $HOME/../../../")
    assert match(command) is False
    command = Command("cp foo/bar/baz.py $HOME/../quux/weeb/")
    assert match(command) is True

# Generated at 2022-06-26 05:38:19.517151
# Unit test for function match
def test_match():
    assert match("ls -lh") is None
    assert match("cp -R / /") is None

    assert match("cp: target `/' is not a directory") is True
    assert match("cp: target `dir' is not a directory") is True
    assert match("cp: target `dir/' is not a directory") is True
    assert match("cp: target `/dir' is not a directory") is True
    assert match("cp: target `/dir/' is not a directory") is True
    assert match("cp: directory `/dir/' does not exist") is True
    assert match("cp: directory `/dir' does not exist") is True
    assert match("cp: cannot stat `/': No such file or directory") is True
    assert match("cp: target `dir/' is not a directory") is True

# Generated at 2022-06-26 05:38:20.154123
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 05:38:30.833369
# Unit test for function match
def test_match():
    bytes_0 = b'\xfb7;\xb9\xb3\x99\x9f\x84z\xeeD\x05\xee\xa5\xa1\x03\x02\xed\xc13'
    var_0 = match(bytes_0)
    assert var_0 == False
    bytes_1 = b'\xfb7;\xb9\xb3\x99\x9f\x84z\xeeD\x05\xee\xa5\xa1\x03\x02\xed\xc13'
    var_1 = match(bytes_1)
    assert var_1 == False


# Generated at 2022-06-26 05:38:32.861711
# Unit test for function match
def test_match():
    # !
    assert match("mv /tmp/1 /tmp/2") == True
    # !
    assert match("mv /tmp/1 /tmp/2") == True



# Generated at 2022-06-26 05:38:43.173024
# Unit test for function match
def test_match():
    bytes_0 = b"~\xe5$\xd5\x88\x0b\x8c\xb1\x1a\x1f\xa0\xa2\xff\xf9\x15\x91\x8a,\x01\x16\xd4\xc1O8\xfd\xe9\x10\x1c\xbb\xeb\x14/\xf2\xe3\x1c\x9a\x1f\x03"
    var_0 = match(bytes_0)


# Generated at 2022-06-26 05:38:43.850532
# Unit test for function match
def test_match():
    assert match(bytes_0)==False

# Generated at 2022-06-26 05:38:48.011832
# Unit test for function match
def test_match():
    var_0 = match(Command('vim test.txt', 'vim: cannot open test.txt: No such file or directory', ''))
    assert var_0 and var_0.new_command == "mkdir -p test.txt && vim test.txt"


# Generated at 2022-06-26 05:38:51.467331
# Unit test for function match
def test_match():
    bytes_0 = b'\xfb7;\xb9\xb3\x99\x9f\x84z\xeeD\x05\xee\xa5\xa1\x03\x02\xed\xc13'
    var_0 = match(bytes_0)


# Generated at 2022-06-26 05:39:00.750948
# Unit test for function match
def test_match():
    assert match("cp foo bar", "cp: cannot stat ‘foo’: No such file or directory")
    assert match("cp foo bar", "cp: directory ‘bar’ does not exist")
    assert not match("cp foo bar", "no such file")
    assert match("mv foo bar", "cp: cannot stat ‘foo’: No such file or directory")
    assert not match("mv foo bar", "no such file")

# Generated at 2022-06-26 05:39:10.758974
# Unit test for function match
def test_match():
    str_0 = '#@0Bt(F<7\x0c'
    var_0 = match(str_0)
    str_1 = 'c%`B\n'
    var_1 = match(str_1)
    str_2 = 'v\x0b'
    var_2 = match(str_2)
    str_3 = '1#6U'
    var_3 = match(str_3)
    str_4 = 'w@|\r'
    var_4 = match(str_4)
    str_5 = '\x0c|'
    var_5 = match(str_5)
    str_6 = '`bk`'
    var_6 = match(str_6)
    str_7 = 'F|"Y'

# Generated at 2022-06-26 05:39:15.641910
# Unit test for function match
def test_match():
    pass_0 = r'#!/usr/bin/env bash\n\n# Overwrite destination file if it exists, without asking.\ncp -f $1 $2'
    var_0 = match(pass_0)


# Generated at 2022-06-26 05:39:18.831484
# Unit test for function match
def test_match():
    str_0 = 'KjZLzHmMD$4d\x0b'
    var_0 = match(str_0)

# Generated at 2022-06-26 05:39:21.448844
# Unit test for function match
def test_match():
    assert (
        "No such file or directory" in "cp: cannot stat '../files/text': No such file or directory"
    ) is True


# Generated at 2022-06-26 05:39:33.620149
# Unit test for function match
def test_match():
    assert match("cp: directory 'Files/' does not exist")
    assert match("cp: directory 'I/' does not exist")
    assert match("cp: omitting directory 'xxx/'")
    assert match("cp: target 'a' is not a directory")
    assert match("mv: cannot move 'src/' to a subdirectory of itself, 'src/src/'")
    assert match("cp: 'xxx': No such file or directory")
    assert match("mv: 'asd': No such file or directory")
    assert not match("cp: cannot stat 'xxx': No such file or directory")
    assert not match("mv: cannot stat 'xxx': No such file or directory")
    assert not match("cp: cannot stat 'src/': Not a directory")

# Generated at 2022-06-26 05:39:36.419001
# Unit test for function match
def test_match():
    assert not match("mv file target/dir")
    assert match("mv file target/dir/")

# Generated at 2022-06-26 05:39:37.924896
# Unit test for function match
def test_match():
    assert match(str_0)


# Generated at 2022-06-26 05:39:39.126677
# Unit test for function match
def test_match():
    assert match(None) == False


# Generated at 2022-06-26 05:39:46.897023
# Unit test for function match
def test_match():
    # Unit test for function get_new_command
    assert callable(get_new_command)
    assert isinstance(get_new_command(""), str)
    assert (
        get_new_command("mkdir -p /tmp/foo/bar; cp /tmp/foo/baz /tmp/foo/bar").
        startswith("mkdir -p")
    )
    assert (
        get_new_command("mkdir -p /tmp/foo/bar; mv /tmp/foo/baz /tmp/foo/bar").
        startswith("mkdir -p")
    )

# Generated at 2022-06-26 05:39:55.944003
# Unit test for function match
def test_match():
    assert match(1) == True


# Generated at 2022-06-26 05:40:01.695953
# Unit test for function match
def test_match():
    assert match(command="cp -r smth1/ smth2/", output="cp: directory ‘smth2/’ does not exist") == True
    assert match(command="mv smth1/ smth2/", output="mv: cannot move ‘smth1/’ to ‘smth2/’: No such file or directory") == True
    assert match(command="cp smth1/ smth2/", output="cp: cannot create regular file ‘smth2/’: No such file or directory") == True

# Generated at 2022-06-26 05:40:05.533877
# Unit test for function match
def test_match():
    # Assert that the match returned by match the correct matching command
    assert match("cp -v /home/void/projects/thefuck/thefuck/* /home/void/projects/thefuck/tests/") == True
    assert match("cp /home/void/projects/thefuck/thefuck/* /home/void/projects/thefuck/tests/") == False

# Generated at 2022-06-26 05:40:07.254895
# Unit test for function match
def test_match():
    test_case = 'HkN`Y\nMogOV0'
    res = match(test_case)
    assert str(res).startswith('') == True


# Generated at 2022-06-26 05:40:09.342356
# Unit test for function match
def test_match():
    assert(None) == match(str_0)



# Generated at 2022-06-26 05:40:16.624586
# Unit test for function match
def test_match():
    str_0 = '\x02\n-\x00\x8d\x00\x00\x00\x00\x00\x00\x08\x00\x00'
    str_1 = '\x0c\x00\x00\x00\x00\x00\x00\x08\x00\x00'
    var_0 = match(str_0, str_1)

    assert var_0 == 'cp: omitting directory'
    # assert len(var_0) == 0 # ??
    print(var_0)


# Generated at 2022-06-26 05:40:20.596167
# Unit test for function match
def test_match():
    union_0 = match('XsYsJdOcNj')
    print(union_0)


# Generated at 2022-06-26 05:40:23.353211
# Unit test for function match
def test_match():
    assert match('Qz0yOpfF`2M\x0c5') == True


# Generated at 2022-06-26 05:40:32.570442
# Unit test for function match
def test_match():
    str_0 = 'cp -r'
    assert not match(str_0)
    str_0 = 'ssh'
    assert match(str_0)
    str_0 = 'ls -l'
    assert not match(str_0)
    str_0 = 'cd'
    assert not match(str_0)
    str_0 = 'zip -r'
    assert not match(str_0)
    str_0 = 'mv -v'
    assert not match(str_0)
    str_0 = 'mkdir'
    assert not match(str_0)
    str_0 = 'find'
    assert not match(str_0)
    str_0 = 'rm'
    assert not match(str_0)
    str_0 = 'tar'
    assert not match(str_0)


# Generated at 2022-06-26 05:40:33.332241
# Unit test for function match
def test_match():
    assert (match('')) == False


# Generated at 2022-06-26 05:41:01.380163
# Unit test for function match
def test_match():
    str_0 = 'JB6U5o6lY\x0c23l\x0cZ'
    var_0 = match(str_0)
    assert var_0 == False

    str_0 = 'Qz0yOpfF`2M\x0c5'
    var_0 = match(str_0)
    assert var_0 == False

    str_0 = '\x0caKA\x0cwGoj\x0c\x0c'
    var_0 = match(str_0)
    assert var_0 == False

    str_0 = '\x0cbS\x0c`'
    var_0 = match(str_0)
    assert var_0 == False


# Generated at 2022-06-26 05:41:03.944417
# Unit test for function match
def test_match():
    #if __name__ == '__main__':
    str_0 = "teest"
    var_0 = match(str_0)
    assert var_0 == True

# Generated at 2022-06-26 05:41:06.495440
# Unit test for function match
def test_match():
    var_1 = u'cp -r /non/existent /tmp'
    var_2 = match(var_1)
    assert var_2 is False


# Generated at 2022-06-26 05:41:08.709147
# Unit test for function match
def test_match():
    var_0 = match(str_0)

    assert var_0 == True


# Generated at 2022-06-26 05:41:13.233973
# Unit test for function match
def test_match():
    # The pattern string is 'No such file or directory'
    assert_true(match('No such file or directory  '))

    assert_false(match("No such file or director"))
    assert_false(match("No such file or directoryX"))
    assert_false(match("No such file or directoy"))



# Generated at 2022-06-26 05:41:20.619481
# Unit test for function match
def test_match():
    assert match('')
    assert match('No such file or directory\n')
    assert match('cp: directory\n')
    assert match('cp: directory\n')
    assert match('cp: directory\n')
    assert match('cp: directory\n')
    assert match('cp: directory\n')
    assert match('cp: directory\n')
    assert match('cp: directory\n')

# Generated at 2022-06-26 05:41:30.647358
# Unit test for function match

# Generated at 2022-06-26 05:41:32.120629
# Unit test for function match
def test_match():
    assert match("Qz0yOpfF`2M\x0c5") == True


# Generated at 2022-06-26 05:41:37.132090
# Unit test for function match
def test_match():
    func = match

# Generated at 2022-06-26 05:41:40.090267
# Unit test for function match
def test_match():
    str_0 = 'N7|wI>~A\x1a\x1f'

    var_0 = match(str_0)



# Generated at 2022-06-26 05:42:27.168788
# Unit test for function match
def test_match():
    # unit test for match
    str_1 = 'N0QF\x0b\x1c-\x14\x06U/'
    var_1 = match(str_1)
    assert var_1 == True
    str_2 = '\x07+\x1f\x0c8*\x13\x10\x1e\x0f\x05'
    var_2 = match(str_2)
    assert var_2 == False
    str_3 = '\x1f`R\x0c/\x14\x1e-\x13\x15\x0b'
    var_3 = match(str_3)
    assert var_3 == False

# Generated at 2022-06-26 05:42:38.340738
# Unit test for function match
def test_match():
    str_0 = 'fHGnqPL/9W}'
    str_1 = 'N6Pw\x7fI\x0c'
    str_2 = '9{QY\x0b\x7f'
    str_3 = "DjKyt{y\x7f"
    str_4 = "wT['.A"
    str_5 = '\x7fqG%\x0c'
    str_6 = 'U6Pw\x7fI\x0c'
    str_7 = str_2
    str_8 = 'cp: directory {}/{} does not exist'.format(str_0, str_1)
    str_9 = '\x7fqG%\x0c'

# Generated at 2022-06-26 05:42:46.440379
# Unit test for function match
def test_match():
    assert match('2bNR`zd\x0b6p')
    assert match('!6e!E6U\x0b[')
    assert match('P41_6b\x0cF~')
    assert match('4O7b\x0c~12|')
    assert match('V7@dp#\x0bB1')
    assert match('C`2N"\x0b&3g')
    assert match('\x0b@7+@27\x0bJ')
    assert match('Xe!E6\x0c~Fv')
    assert match('\x0b6U\x0b[2N"\x0b&3')
    assert match('Dp#\x0bB1V7@')

# Generated at 2022-06-26 05:42:52.717727
# Unit test for function match
def test_match():
    assert match('echo ''')
    assert match('echo ')
    assert match('echo a')
    assert match('echo abc')
    assert match('echo abc abc')
    assert match('echo abcdefghijklmnopqrstuvwxyz')
    assert match('echo ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert match('echo 0123456789')
    assert match('echo 0123456789')
    assert match("echo abc def 'ghi jkl' mno")
    assert match("echo abc def 'ghi jkl'mno")
    assert match("echo abc def 'ghi jkl'  mno")
    assert match("echo abc def 'ghi jkl'\tmno")

# Generated at 2022-06-26 05:42:53.812509
# Unit test for function match
def test_match():
    assert match(None) == None


# Generated at 2022-06-26 05:42:55.200629
# Unit test for function match
def test_match():
    assert match(str_0) == True


# Generated at 2022-06-26 05:43:03.039999
# Unit test for function match
def test_match():
    var_0 = 'cp: target \'wP\x0bQ"L"\' is not a directory'
    str_0 = 'GwoHkyb]~K\x0e'
    str_0.output = var_0
    var_0 = match(str_0)
    assert var_0 is True


# Generated at 2022-06-26 05:43:14.295371
# Unit test for function match
def test_match():
    assert match(Command('echo foo', 'echo foo\nfoo: No such file or directory'))
    assert match(Command('echo foo', 'echo foo\n() [foo: No such file or directory'))
    assert match(Command('echo foo', 'echo foo\nfoo: No such file or directory ()'))
    assert not match(Command('echo', 'echo foo\nfoo'))
    assert match(Command('echo foo', 'echo foo\ncp: Directory `foo1\' does not exist'))
    assert not match(Command('echo foo', 'echo foo\nfoo'))
    assert not match(Command('echo foo', 'echo foo\nfoo: No such file or directory\nfoo: No such file or directory'))
    assert match(Command('echo', 'mkdir -p a/b/c/d\necho'))


# Generated at 2022-06-26 05:43:23.447028
# Unit test for function match
def test_match():
    str_0 = 'Qz0yOpfF`2M\x0c5'
    var_0 = match(str_0)
    assert(var_0 == False)
    str_1 = 'Vo7DYFyjtnV\x0c5'
    var_1 = match(str_1)
    assert(var_1 == True)
    str_2 = 'f$lk0_G^6q)U\x0c5'
    var_2 = match(str_2)
    assert(var_2 == True)

# Generated at 2022-06-26 05:43:26.587478
# Unit test for function match
def test_match():
    str_0 = 'Qz0yOpfF`2M\x0c5'
    var_0 = match(str_0)


# Generated at 2022-06-26 05:44:53.695454
# Unit test for function match
def test_match():
    pass
    # assert False


# Generated at 2022-06-26 05:45:01.128616
# Unit test for function match
def test_match():
    str_0 = 'Qz0yOpfF`2M\x0c5'
    str_1 = "No such file or directory"
    str_2 = 'Qz0yOpfF`2M\x0c5'
    str_3 = 'cp: directory'
    str_4 = 'Qz0yOpfF`2M\x0c5'
    str_5 = 'does not exist'
    var_0 = match(str_0)
    var_1 = match(str_1)
    var_2 = match(str_2)
    var_3 = match(str_3)
    var_4 = match(str_4)
    var_5 = match(str_5)


# Generated at 2022-06-26 05:45:08.431517
# Unit test for function match
def test_match():
    assert match('cp foo bar')
    assert match('cp foo bar', 'cp: target `bar\' is not a directory')
    assert match('mv foo bar')
    assert match('mv foo bar', 'mv: target `bar\' is not a directory')
    assert match('mv foo bar', 'mv: cannot stat ‘foo’: No such file or directory')
    assert not match('cp foo bar/')
    assert not match('cp foo bar', 'cp: target `bar\' is not a directory\ncp: error')
    assert not match('mv foo bar/')
    assert not match('mv foo bar', 'mv: target `bar\' is not a directory\nmv: error')

# Generated at 2022-06-26 05:45:09.070386
# Unit test for function match
def test_match():
    assert match("command") == False

# Generated at 2022-06-26 05:45:14.692671
# Unit test for function match
def test_match():
    str_0 = 'V\x0cF\x00N\x00\'\x00n\x00'
    var_0 = match(str_0)
    var_1 = match(var_0)


# Generated at 2022-06-26 05:45:17.234443
# Unit test for function match
def test_match():
    str_0 = 'mkdir: g: No such file or directory'
    var_0 = match(str_0)
    assert var_0


# Generated at 2022-06-26 05:45:20.786429
# Unit test for function match
def test_match():
    str_0 = 'mkdir -p $HOME/.aws/credentials'
    var_0 = match(str_0)
    str_1 = 'mkdir -p $HOME/.aws/credentials'
    var_1 = match(str_1)

if __name__ == '__main__':
	test_match()

# Generated at 2022-06-26 05:45:28.692824
# Unit test for function match
def test_match():
    var_1 = ("\x1b[?25h\x1b[Kcp: cannot stat \x1b[01;31m\x1b[K'\x1b[m\x1b[Ktest.rb\x1b[m\x1b[K': No such file or directory\n", ' ')
    var_2 = match(var_1)
    str_1 = 'cgMkF\x7fA^'
    var_3 = match(str_1)

# Generated at 2022-06-26 05:45:30.973211
# Unit test for function match
def test_match():
    assert match('') == False
    assert match('') == False


# Generated at 2022-06-26 05:45:35.946396
# Unit test for function match
def test_match():
    expected_0 = '^cp: cannot stat '
    expected_1 = ': No such file or directory\r\ncp: cannot stat '
    expected_3 = ': No such file or directory\r\ndoes not exist'
    expected_2 = ': No such file or directory\r\nNo such file or directory'
    expected_4 = ': No such file or directoryr\nNo such file or directory'
    expected_5 = ': No such file or directo'
    expected_6 = ': No such file or directory\r\nNo such file or'
    expected_7 = ': No such file or directory\r\nNo such '
    expected_8 = ': No such file or directory\r\n'
    expected_9 = ': No such file or directory\r\nNo such file or directory'
