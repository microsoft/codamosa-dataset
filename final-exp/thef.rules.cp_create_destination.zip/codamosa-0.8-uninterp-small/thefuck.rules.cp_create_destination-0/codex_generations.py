

# Generated at 2022-06-26 05:35:46.881705
# Unit test for function match
def test_match():
    from thefuck.rules.mkdir_missing_directory import match
    result = match('Text')
    assert result == 'Text'


# Generated at 2022-06-26 05:35:54.251951
# Unit test for function match
def test_match():
    str_0 = 'ylyE0KAn@4j\rAd1+ILf\x0b'
    var_0 = match(str_0)

    str_1 = 'i5wH^pVGKP|\n'
    str_2 = 'P(a]K\x0b=z>'
    if ((var_0 != 0) or(not os.path.exists(str_1))):
        var_0 = False
        if (os.path.exists(str_2)):
            var_0 = True
    assert var_0 == True


# Generated at 2022-06-26 05:36:05.648490
# Unit test for function match
def test_match():
    var_0 = u'cp xxx yyy'
    var_1 = 'No such file or directory'
    str_0 = 'cp: cannot stat \'xxx\': No such file or directory'
    str_1 = 'cp: cannot stat \'yyy\'\x07: No such file or directory'
    str_4 = 'cp: cannot stat \'xxx\': No such file or directory\r'
    str_5 = 'cp: omitting directory \'yyy\'\x07'
    str_6 = 'cp: omitting directory \'yyy\'\x07\r'
    var_2 = not_match(var_0, var_1, str_0)
    var_3 = match(var_0, var_1, str_1)
    var_3 = match(var_0, var_1, str_4)

# Generated at 2022-06-26 05:36:10.685170
# Unit test for function match
def test_match():
    str_0 = 'ylyE0KAn@4j\rAd1+ILf\x0b'
    var_0 = match(str_0)
    passed = False
    passed = True
    return passed


# Generated at 2022-06-26 05:36:14.767054
# Unit test for function match
def test_match():
    assert match(var_0) == True
    assert match(var_0) == True
    assert match(var_0) == True
    assert match(var_0) == True
    assert match(var_0) == True


# Generated at 2022-06-26 05:36:19.323169
# Unit test for function match
def test_match():
    str_0 = 'ed27c1bfd75fc114c95d6d68897b9eab'
    int_0 = get_new_command(str_0)
    assert(int_0 == 'mkdir -p ed27c1bfd75fc114c95d6d68897b9eab && ylyE0KAn@4j\rAd1+ILf\x0b')


# Generated at 2022-06-26 05:36:20.027282
# Unit test for function match
def test_match():
  i = match(True)


# Generated at 2022-06-26 05:36:20.763879
# Unit test for function match
def test_match():
    test_case_0()

# Generated at 2022-06-26 05:36:24.844324
# Unit test for function match
def test_match():
    str_0 = 'ylyE0KAn@4j\rAd1+ILf\x0b'
    var_0 = match(str_0)

# Generated at 2022-06-26 05:36:27.116171
# Unit test for function match
def test_match():
    assert match(command) == "No such file or directory"


# Generated at 2022-06-26 05:36:37.135624
# Unit test for function match
def test_match():
    assert match('cp /a/b/c /tmp/path_not_exists/logs.bak') == True
    assert match('cp /a/b/c /tmp/path_not_exists/logs.bak\rA') == True
    assert match('cp /a/b/c /tmp/path_not_exists/logs.bak\rA\t') == True
    assert match('cp /a/b/c /tmp/path_not_exists/logs.bak\rA\n') == True
    assert match('cp /a/b/c /tmp/path_not_exists/logs.bak\rA\v') == True

# Generated at 2022-06-26 05:36:48.101741
# Unit test for function match
def test_match():
    assert match(
        Command(script="cps x.txt y", stdout="cp: cannot stat 'x.txt': No such file or directory")
    )
    assert match(
        Command(
            script="cp x.txt y",
            stdout="cp: omitting directory 'x.txt', a destination "
            "directory already exists",
        )
    )
    assert match(
        Command(
            script="cp -r foo bar",
            stdout="cp: omitting directory 'foo', a destination "
            "directory already exists",
        )
    )
    assert match(
        Command(
            script="mv x.txt y",
            stdout="mv: cannot stat 'x.txt': No such file or directory",
        )
    )

# Generated at 2022-06-26 05:36:52.021618
# Unit test for function match
def test_match():
    # str_0 = 'ylyE0KAn@4j\rAd1+ILf\x0b'
    # test_case_0(str_0)

    str_0 = '\r'
    var_0 = match(str_0)

    # assert (expected, actual)
    assert 'function' == type(var_0).__name__



# Generated at 2022-06-26 05:36:53.273886
# Unit test for function match
def test_match():
    assert match(u'fds\x7f\x7f') == None


# Generated at 2022-06-26 05:37:01.604506
# Unit test for function match
def test_match():
    command = Command('cp a /tmp/does/not/exist/', '', 'cp: target `/tmp/does/not/exist/\' is not a directory')
    assert match(command)

    command = Command('cp A /tmp/does/not/exist/', '', 'cp: cannot create regular file `/tmp/does/not/exist/\': No such file or directory')
    assert match(command)

    command = Command('mv A /tmp/does/not/exist/', '', 'mv: cannot move `A\' to `/tmp/does/not/exist/\': No such file or directory')
    assert match(command)

# Generated at 2022-06-26 05:37:02.555489
# Unit test for function match
def test_match():
    assert match("cp -p /tmp/foo /tmp/bar/")
    assert not match("cp -p /tmp/foo/ /tmp/bar")


# Generated at 2022-06-26 05:37:04.200101
# Unit test for function match
def test_match():
    str_0 = 't4m@4m4b1l4'
    var_0 = match(str_0)
    var_0 = match(str_0)

# Generated at 2022-06-26 05:37:06.523579
# Unit test for function match
def test_match():
    try:
        assert match([u'cp', u'zX9F4+4a', u'ylyE0KAn@4j'])
        assert not match([u'zhW9R8xv', u'ylyE0KAn@4j'])
    except:
        print("Test failed")


# Generated at 2022-06-26 05:37:10.089637
# Unit test for function match
def test_match():
    try:
        str_0 = 'ylyE0KAn@4j\rAd1+ILf\x0b'
        var_0 = match(str_0)
    except BaseException as exception_0:
        print(exception_0)


# Generated at 2022-06-26 05:37:12.759190
# Unit test for function match
def test_match():
    str_0 = "cp -r /var/www /var/wwwbak; echo \"test\""
    var_0 = match(str_0)


# Generated at 2022-06-26 05:37:20.107525
# Unit test for function match
def test_match():
    assert match('cp -R\xa0/Users/vutondss/Videos/uDemy\xa0/udemy\xa0/Practice\xa0/mysql-for-begginers /Users/vutondss/Videos/uDemy\xa0/udemy\xa0/Practice/mysql-for-begginers') == True

# Generated at 2022-06-26 05:37:24.384416
# Unit test for function match
def test_match():
    str_1 = "No such file or directory"
    str_2 = "cp: directory"
    str_0 = 'ylyE0KAn@4j\rAd1+ILf\x0b'
    str_3 = "does not exist"
    str_0 = str_1 + str_2 + str_3
    str_0 = match(str_0)
    str_0 = str_0 + str_3


# Generated at 2022-06-26 05:37:28.863328
# Unit test for function match
def test_match():
	assert match('No such file or directory') == True
	assert match('cp: directory') == True

# Generated at 2022-06-26 05:37:35.197670
# Unit test for function match
def test_match():
    var_0 = Command('cp /etc/hosts /does/not/exist')
    var_0.set_output('cp: omitting directory `/does/not/exist\'')
    var_1 = Command('cp /etc/hosts /')
    var_1.set_output('cp: omitting directory `/\'')
    assert match(var_0)
    assert match(var_1)


# Generated at 2022-06-26 05:37:38.211179
# Unit test for function match
def test_match():
    # my_dict_0: {'cmd': 'cp aasdfasdf/ asdf/', 'script_parts': ['cp', 'aasdfasdf/', 'asdf/'], 'stderr': Empty pipe, 'stdout': Empty pipe}
    my_dict_0 = match(my_dict_0)
    assert my_dict_0 == None

# Generated at 2022-06-26 05:37:49.742322
# Unit test for function match
def test_match():
    # Check for positive match
    assert match('cp -R this_path_does_not_exist /some/other/path')
    assert match('mv -R this_path_does_not_exist /some/other/path')
    assert match('cp this_file_does_not_exist /some/other/path')
    assert match('mv this_file_does_not_exist /some/other/path')
    assert match('This command would generate a lot of output that would be used '
                 'elsewhere but the path does_not_exist doesn\'t exist yet.')
    assert match('cp: directory this_path_does_not_exist/some/other/path does not exist')

    # Check for negative match
    assert not match('mv some_path/another_path/this_file /some/other/path')


# Generated at 2022-06-26 05:37:50.957083
# Unit test for function match
def test_match():
    assert str_0 == get_new_command(str_0)

# Generated at 2022-06-26 05:37:53.344247
# Unit test for function match
def test_match():
    var_0 = 'mkdir'
    out_0 = shell.and_('mkdir -p dir1', 'cp dir /dir1')
    test = match(var_0)
    assert test == out_0


# Generated at 2022-06-26 05:37:57.175516
# Unit test for function match
def test_match():
    assert match('ylyE0KAn@4j\rAd1+ILf\x0b')


# Generated at 2022-06-26 05:38:07.182479
# Unit test for function match
def test_match():
    # Input 1
    str_0 = 'z3ssYbXIbn\t=+F\x0bUM-?\x0b\x0b'
    var_0 = match(str_0)

    # Expected output 1
    str_1 = True

    # Input 2
    str_2 = 'N9X5v5hc,\x0cq1\x0c\x0cyR\x0c\x0b;+1'
    var_1 = match(str_2)

    # Expected output 2
    str_3 = False

    # Input 3
    str_4 = 'ylyE0KAn@4j\rAd1+ILf\x0b'
    var_2 = match(str_4)

    # Expected output 3
    str_5 = False

# Generated at 2022-06-26 05:38:19.247228
# Unit test for function match
def test_match():
    str_0 = 'mv /home/saurabh/Downloads/Screen\x0b'
    str_1 = 'Shot\x0b'
    str_2 = "2015-08-10\x0b"
    str_3 = '10.55.55.png /home/saurabh/Documents/Screen\x0b'
    str_4 = 'Shot\x0b'
    str_5 = "2015-08-10\x0b"
    str_6 = '10.55.55.png'
    obj_0 = Command(str_0 + str_1 + str_2 + str_3 + str_4 + str_5 + str_6, "cp: cannot stat \x0b'Screen\x0b': No such file or directory\n")
    assert match(obj_0)

# Generated at 2022-06-26 05:38:21.141250
# Unit test for function match
def test_match():
    str_0 = 'o_^YH#I:[4e`\t"g\x0b'
    var_0 = match(str_0)
    assert var_0 == False

# Generated at 2022-06-26 05:38:24.078876
# Unit test for function match
def test_match():
    assert True == match('x\x0cW8/v6&\x0e+;\t3F&8\\\x0e')


# Generated at 2022-06-26 05:38:29.232893
# Unit test for function match
def test_match():
    str_0 = 'ylyE0KAn@4j\rAd1+ILf\x0b'
    str_1 = 'No such file or directory'
    assert compare(match(str_0), str_1)


# Generated at 2022-06-26 05:38:36.733413
# Unit test for function match
def test_match():
    assert match({'script_parts': ['/a/b/c/d/e', '/a/b/c/d/f'], 'script': '/a/b/c/d/e /a/b/c/d/f', 'output': 'cp: /a/b/c/d/e: No such file or directory\r\ncp: /a/b/c/d/f: No such file or directory'}) == True


# Generated at 2022-06-26 05:38:37.715669
# Unit test for function match
def test_match():
    assert match(str_0)


# Generated at 2022-06-26 05:38:45.736359
# Unit test for function match
def test_match():

    cp_0 = Command(script="cp '1.py'",)
    var_0 = match(cp_0)

    cp_1 = Command(script="cp '1.py'",)
    var_1 = match(cp_1)

    cp_2 = Command(script="cp '1.py'",)
    var_2 = match(cp_2)

    cp_3 = Command(script="cp '1.py'",)
    var_3 = match(cp_3)

    cp_4 = Command(script="cp '1.py'",)
    var_4 = match(cp_4)

    cp_5 = Command(script="cp '1.py'",)
    var_5 = match(cp_5)

    cp_6 = Command(script="cp '1.py'",)
   

# Generated at 2022-06-26 05:38:54.940536
# Unit test for function match
def test_match():
    # Our test arguments.

    # Strip out any potential whitespace
    # before testing function.
    str_0 = '0\x0b_'
    str_0 = str_0.strip()
    var_0 = match(str_0)
    assert var_0 == 0
    print("Expected output: 0 \nActual output: {}".format(var_0))

    str_0 = 'TJfvE+\x0b\x0b'
    str_0 = str_0.strip()
    var_0 = match(str_0)
    assert var_0 == 0
    print("Expected output: 0 \nActual output: {}".format(var_0))

    str_0 = 'x"tc\x0b\x0b'
    str_0 = str_0.strip()

# Generated at 2022-06-26 05:38:58.105515
# Unit test for function match
def test_match():
    str_0 = 'ylyE0KAn@4j\rAd1+ILf\x0b'
    SystemUnderTest = match(str_0)


# Generated at 2022-06-26 05:39:02.769768
# Unit test for function match
def test_match():
    assert match(
        "mv: cannot stat ‘1.ex’: No such file or directory"
    )  # <=0ylyE0KAn@4j\rAd1+ILf\x0b
    assert match(
        "cp: omitting directory 'a/b/c'\ncp: omitting directory 'a/b/c'"
    )  # <=0
    assert not match(
        "cp: omitting directory 'a/b/c'\ncp: omitting directory 'a/b/c'\n"
    )  # <=0


# Generated at 2022-06-26 05:39:07.325678
# Unit test for function match
def test_match():
    assert match(str_0)

# Generated at 2022-06-26 05:39:12.934041
# Unit test for function match
def test_match():
    arguments = {}
    if 'output' in arguments:
        output = arguments['output']
    else:
        output = "var"
    parsed_script = '2'
    script = '3'
    res = match(arguments, parsed_script, script)
    assert res == False
    assert robocop.match('1') == False
    assert robocop.match('str_0') == False
    assert robocop.match('str_1') == False
    assert robocop.match('str_2') == False
    assert robocop.match('str_3') == False
    return


# Generated at 2022-06-26 05:39:17.113557
# Unit test for function match
def test_match():
	str_0 = "cp '1.py'"
	str_1 = "xx.py"
	str_2 = "cp '1.py' "
	str_3 = "cp '1.py'   '2.py'"
	str_4 = "cp '1.py'   '2.py/'"

	assert match(str_0) == True
	assert match(str_1) == False
	assert match(str_2) == False
	assert match(str_3) == False
	assert match(str_4) == False


# Generated at 2022-06-26 05:39:28.490503
# Unit test for function match
def test_match():
    str_0 = "cp '1.py'"
    str_1 = "cp: cannot stat '1.py': No such file or directory"
    str_2 = "cp './1.py'"
    str_3 = "cp: cannot stat './1.py': No such file or directory"
    str_4 = "mv '1.py'"
    str_5 = "mv: cannot stat '1.py': No such file or directory"
    str_6 = "mv './1.py'"
    str_7 = "mv: cannot stat './1.py': No such file or directory"
    parm_0 = Command(script=str_0, stdout=str_1)
    parm_1 = Command(script=str_2, stdout=str_3)
    parm_2 = Command

# Generated at 2022-06-26 05:39:37.971266
# Unit test for function match
def test_match():
    str_0 = "cp '1.py'"
    str_1 = "mv '1.py'"
    str_2 = "cp: directory"
    str_3 = "cp: directory2"
    str_4 = "cp: directory2_1"
    str_5 = "mkdir -p 1"
    str_6 = "cp 1.py"
    str_7 = "mv 1.py"
    str_8 = "cp: directory"
    str_9 = "cp: directory2"
    str_10 = "cp: directory2_1"

    # Test with assertion
    assert match(Command(str_0, str_1, str_2)) == False
    assert match(Command(str_3, str_4, str_5)) == False

# Generated at 2022-06-26 05:39:39.909339
# Unit test for function match
def test_match():
    str_0 = "cp '1.py'"
    assert match(str_0) == \
           False


# Generated at 2022-06-26 05:39:40.968217
# Unit test for function match
def test_match():
	assert match(str_0) == True

# Generated at 2022-06-26 05:39:44.245744
# Unit test for function match
def test_match():
    input_0 = "cp '1.py'"
    expected_value = True
    actual_value = match(input_0)
    assert expected_value == actual_value


# Generated at 2022-06-26 05:39:53.775590
# Unit test for function match
def test_match():
    str_0 = "cp: cannot stat '1.py': No such file or directory"
    str_1 = "cp: cannot stat '1.py': No such file or directory"
    str_2 = "cp: cannot stat '1.py': No such file or directory"
    str_3 = "cp: cannot stat '1.py': No such file or directory"
    str_4 = "cp: cannot stat '1.py': No such file or directory"
    str_5 = "cp: cannot stat '1.py': No such file or directory"
    str_6 = "cp: cannot stat '1.py': No such file or directory"
    str_7 = "cp: cannot stat '1.py': No such file or directory"
    str_8 = "cp: cannot stat '1.py': No such file or directory"
   

# Generated at 2022-06-26 05:39:55.689724
# Unit test for function match
def test_match():
    assert test_case_0() == get_new_command()


# Generated at 2022-06-26 05:39:58.884795
# Unit test for function match
def test_match():
    str_0 = "mkdir: cannot create directory \"/dev/output\": File exists"
    return match(str_0)

# Generated at 2022-06-26 05:40:00.870557
# Unit test for function match
def test_match():
    assert match(str_0) == True

# Generated at 2022-06-26 05:40:05.205799
# Unit test for function match
def test_match():
    args_0 = 'cp No such file or directory'
    args_1 = 'mv: cannot remove \'1.py\': No such file or directory'
    assert match(args_0)
    assert not match(args_1)


# Generated at 2022-06-26 05:40:12.894336
# Unit test for function match
def test_match():
    command_0 = Command(script="cp '1.py'", output="cp: cannot stat '1.py': No such file or directory")
    command_1 = Command(script="cp '1.py'", output="cp: directory '/home/sdgf' does not exist")
    command_2 = Command(script="cp '1.py'", output="cp: directory '/home/sdgf' does not exist")
    #assert match(command_0) == True
    #assert match(command_1) == True
    #assert match(command_2) == False
    pass


# Generated at 2022-06-26 05:40:20.730314
# Unit test for function match
def test_match():
    path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    a = subprocess.Popen("cd "+path+" && cp '1.py'", shell=True)
    a.wait()
    a = subprocess.Popen("cd "+path+" && cp '1.py'", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    std_out = a.stdout.read().decode("utf-8")
    std_err = a.stderr.read().decode("utf-8")
    assert (match(Command(script="cp '1.py'", stdout=std_out, stderr=std_err)))

# Generated at 2022-06-26 05:40:26.782416
# Unit test for function match
def test_match():
    print("Running function match")
    str_0 = "cp '1.py'"
    ret_val_0 = match(str_0)
    assert ret_val_0 == 0
    str_1 = "cp '1.py'"
    ret_val_1 = match(str_1)
    assert ret_val_1 == 0
    

# Generated at 2022-06-26 05:40:34.915905
# Unit test for function match
def test_match():
    str_0 = "cp '1.py'"
    str_1 = "cp: cannot stat '1.py': No such file or directory"
    str_2 = "mv '1.py'"
    str_3 = "mv: cannot stat '1.py': No such file or directory"
    str_4 = "cp DIR DIR"
    str_5 = "cp: directory DIR does not exist"
    str_6 = "mv DIR DIR"
    str_7 = "mv: directory DIR does not exist"
    Command_0 = Command(script=str_0, stdout=str_1)
    Command_1 = Command(script=str_2, stdout=str_3)
    Command_2 = Command(script=str_4, stdout=str_5)
    Command_3

# Generated at 2022-06-26 05:40:38.915387
# Unit test for function match
def test_match():
    # raise NotImplementedError()
    command = Command(str_0, None)
    # check if match to cp: cannot stat '1.py': No such file or directory 
    assert match(command) == False

    

# Generated at 2022-06-26 05:40:40.346749
# Unit test for function match
def test_match():
    assert match(str_0) == False


# Generated at 2022-06-26 05:40:41.176417
# Unit test for function match
def test_match():
    assert () == match()


# Generated at 2022-06-26 05:40:49.617686
# Unit test for function match
def test_match():
    cmd0 = Command(script="cp '1.py'", args=["cp", "'1.py'"])
    cmd1 = Command(script="cp '1.py' 2.py", args=["cp", "'1.py'", "2.py"])
    assert match(cmd0)
    assert not match(cmd1)


# Generated at 2022-06-26 05:40:51.464270
# Unit test for function match
def test_match():
    # NOTE: generated test cases must be tested manually.
    pass


# Generated at 2022-06-26 05:40:55.687472
# Unit test for function match
def test_match():
    cmd = Command('cd /tmp/thefuck-123fc', '', '')
    assert match(cmd)
    cmd = Command('cp 1.py /tmp/thefuck-123fc', '', '')
    assert match(cmd)


# Generated at 2022-06-26 05:41:05.565895
# Unit test for function match
def test_match():
    args_0 = "cp '1.py'"
    output_0 = "/bin/cp: target '1.py' is not a directory"

    assert match(Command(script=args_0, output=output_0))

    args_1 = "cp '1.py'"
    output_1 = "/bin/cp: cannot stat '1.py': No such file or directory"

    assert match(Command(script=args_1, output=output_1))

    args_2 = "cp foo bar"
    output_2 = "/bin/cp: cannot stat 'foo': No such file or directory"

    assert match(Command(script=args_2, output=output_2))

    args_3 = "cp -t foo bar"
    output_3 = "/bin/cp: target 'foo' is not a directory"

    assert not match

# Generated at 2022-06-26 05:41:16.265323
# Unit test for function match
def test_match():
    str_0 = "cp '1.py'"
    str_1 = "cp '1'"
    str_2 = "mv '1'"
    cmd_0 = thefuck.types.Command(script=str_0,
                                                 stderr="cp: cannot stat '1.py': No such file or directory",
                                                 stdout='',
                                                 argv=[],
                                                 script_parts=str_0.split(' '),
                                                 stderr_parts=[],
                                                 stdout_parts=[])
    assert match(cmd_0)

# Generated at 2022-06-26 05:41:17.643840
# Unit test for function match
def test_match():
    cmd = Command(script = str_0)
    assert match(cmd) == False



# Generated at 2022-06-26 05:41:21.202063
# Unit test for function match
def test_match():
    str_0 = "cp '1.py'"
    str_1 = "No such file or directory"
    str_2 = "cp '1.py'\nmv '1.py' 'src/'"
    str_3 = "cp: omitting directory '1.py'"
    assert match(str_0 + str_1) == False
    assert match(str_2 + str_3) == True


# Generated at 2022-06-26 05:41:25.087633
# Unit test for function match
def test_match():
    str_0 = "cp '1.py'"
    assert match(Command(2, 3, str_0)) == False
    return


# Generated at 2022-06-26 05:41:27.300598
# Unit test for function match
def test_match():
    output0 = test_case_0()
    print(output0)

# Generated at 2022-06-26 05:41:32.551157
# Unit test for function match
def test_match():
    f = open("input.txt", "r")
    lines = f.readlines()
    str_1 = lines[0]
    f.close()

    assert match(str_1) == False


# Generated at 2022-06-26 05:41:39.128229
# Unit test for function match
def test_match():
    var_0 = (
        "No such file or directory" in 'poo'
        or 'poo'.startswith("cp: directory")
        and 'poo'.rstrip().endswith("does not exist")
    )
    assert var_0 == {'output': 'poo'}


# Generated at 2022-06-26 05:41:51.886017
# Unit test for function match
def test_match():
    subprocess.check_output = check_output_mock_matches
    command = 'cp file.txt folder/'
    assert match(command)
    command.output = 'cp: directory \'folder/\' does not exist: No such file or directory\n'
    assert match(command)
    command.output = 'cp: directory \'folder/\' does not exist: No such file or directory\n'
    assert match(command)
    command.output = 'cp: directory \'folder/\' does not exist: No such file or directory\n'
    assert match(command)
    command.output = 'cp: directory \'folder/\' does not exist: No such file or directory\n'
    assert match(command)
    command.output = 'cp: directory \'folder/\' does not exist: No such file or directory\n'

# Generated at 2022-06-26 05:41:59.574660
# Unit test for function match
def test_match():
    assert match("a: No such file or directory")
    assert match("cp: omitting directory 'sample_dir'")
    assert match("cp: cannot create directory 'sample_dir': No such file or directory")
    assert match("cp: cannot create directory 'sample_dir_2': No such file or directory")
    assert match("cp: cannot stat 'a.sample': No such file or directory")
    assert match("cp: cannot stat 'a.sample.yy': No such file or directory")
    assert match("cp: cannot stat 'a.sample.yy.in': No such file or directory")
    assert match("cp: cannot stat 'a.sample.yy.out': No such file or directory")
    assert match("cp: cannot stat 'a.sample.yy.yy.c': No such file or directory")

# Generated at 2022-06-26 05:42:00.892678
# Unit test for function match
def test_match():
	assert match("cp /tmp/dir/dir /tmp/dir/dir\n")

# Generated at 2022-06-26 05:42:02.480935
# Unit test for function match
def test_match():
    str_0 = "ifconfig"
    var_0 = match(str_0)


# Generated at 2022-06-26 05:42:07.864531
# Unit test for function match
def test_match():
    command = Command()
    command.script = "cp from to"
    command.output = "cp: cannot stat 'from': No such file or directory"
    assert match(command)

    command.script = "cp from to"
    command.output = "cp: cannot stat 'to': No such file or directory"
    assert match(command)

    command.script = "cp -r from to"
    command.output = "cp: cannot stat 'from': No such file or directory"
    assert match(command)

    command.script = "cp -r from to"
    command.output = "cp: cannot stat 'to': No such file or directory"
    assert match(command)

    command.script = "mv from to"
    command.output = "mv: cannot stat 'from': No such file or directory"

# Generated at 2022-06-26 05:42:16.580261
# Unit test for function match
def test_match():
    assert match("cp -r /src/Dir /dst/Dir") is True
    assert match("cp -r /src/Dir /dst") is True
    assert match("mv /src/File /dst/File") is True
    assert match("mv -r /src/Dir /dst/Dir") is True
    assert match("mv /src/File /dst") is True
    assert match("mv -r /src/Dir /dst") is False
    assert match("mv /src/Dir /dst") is False
    assert match("mv /src/File /dst/Dir") is False
    assert match("cp -r /src/Dir") is False
    assert match("cp -r /src") is False
    assert match("mv /src/File") is False

# Generated at 2022-06-26 05:42:22.504975
# Unit test for function match
def test_match():
    assert match(command=Command(script='cp abc def'))
    assert match(command=Command(script='cp abc def', output='cp: directory `def\' does not exist'))
    assert not match(command=Command(script='mv abc def'))
    assert not match(command=Command(script='cp abc def', output='cp: cannot stat `abc\': No such file or directory'))
    assert match(command=Command(script='cp abc def', output='cp: cannot create regular file `def\': No such file or directory'))

# Generated at 2022-06-26 05:42:24.957293
# Unit test for function match
def test_match():
    assert True == match("\x0bX-O@r\\\r")


# Generated at 2022-06-26 05:42:26.775975
# Unit test for function match
def test_match():
    # delete when not None
    if False:
        test_case_0()

# Generated at 2022-06-26 05:42:35.847431
# Unit test for function match
def test_match():
    str_0 = 'q\t\tl\\'
    var_0 = match(str_0)


# Generated at 2022-06-26 05:42:40.062897
# Unit test for function match
def test_match():
    assert match(str_0) == bool_0
    assert match(str_0) == bool_1


# Generated at 2022-06-26 05:42:42.924265
# Unit test for function match
def test_match():
    var_1 = "     $ cp from from/to\n cp: from/to: No such file or directory"
    var_2 = match(var_1)


# Generated at 2022-06-26 05:42:47.204132
# Unit test for function match
def test_match():
    str_0 = '1Scp: cannot create directory `/tmp/c4Xo4.tmp\': File exists\n'
    bool_0 = match(str_0)
    assert bool_0 is False


# Generated at 2022-06-26 05:42:50.536675
# Unit test for function match
def test_match():
    var_0 = Command('cp -r /etc/netplan /etc/netplan.bak', 'cp: cannot stat \'/etc/netplan\': No such file or directory\r\r')
    var_0 = match(var_0)
    assert var_0 == True
    

# Generated at 2022-06-26 05:42:52.853195
# Unit test for function match
def test_match():
    # Case 0
    str_0 = '4Kj1sX9k'
    test_case_0(str_0)


test_match()

# Generated at 2022-06-26 05:43:01.930582
# Unit test for function match
def test_match():
    test_case_0()
    test_case_0()

if __name__ == '__main__':
    assert match('ylyE0KAn@4j\rAd1+ILf\x0b') == 'ylyE0KAn@4j\rAd1+ILf\x0b'
    assert match('ylyE0KAn@4j\rAd1+ILf\x0b') == 'ylyE0KAn@4j\rAd1+ILf\x0b'
    assert match('ylyE0KAn@4j\rAd1+ILf\x0b') == 'ylyE0KAn@4j\rAd1+ILf\x0b'

# Generated at 2022-06-26 05:43:13.379965
# Unit test for function match
def test_match():
    str_0 = 'h\x0bvln\x0e\r'
    var_0 = match(str_0)
    str_1 = '\x0e\x0e<\x0b\x0b'
    var_1 = match(str_1)
    str_2 = '\x0f\x0e\x0f'
    var_2 = match(str_2)
    str_3 = '\x0b\x0b\x0b'
    var_3 = match(str_3)
    str_4 = 'm\x0b\x0b\x0b'
    var_4 = match(str_4)
    str_5 = 'n\x0b\x0b\x0b'
    var_5 = match(str_5)

# Generated at 2022-06-26 05:43:20.929810
# Unit test for function match
def test_match():
    assert match(r"cp: cannot stat 'test.py': No such file or directory")
    assert match(r"cp: cannot stat 'test.py': No such file or directory")
    assert not match(r"usage: cp [-R [-H | -L | -P]] [-fi | -n] [-apvX] source_file target_file")

# Generated at 2022-06-26 05:43:24.682601
# Unit test for function match
def test_match():
    str_0 = 'mv ylyE0KAn@4j\rAd1+ILf\x0b ylyE0KAn@4j\rAd1+ILf\x0b'
    output_0 = "mv: directory ylyE0KAn@4j\rAd1+ILf\x0b does not exist"
    assert match(str_0) == output_0


# Generated at 2022-06-26 05:43:36.057788
# Unit test for function match
def test_match():
    assert match()



# Generated at 2022-06-26 05:43:44.364763
# Unit test for function match
def test_match():
    assert match('cp abc /home/xyz\n') == False
    assert match('cp: cannot stat \'a\': No such file or directory\n') == True
    assert match('cp: cannot stat \'a\': No such file or directory\n') == True
    assert match('cp: directory target does not exist\n') == True
    assert match('mv: cannot stat \'dir\': No such file or directory\n') == True
    assert match('mv: u: No such file or directory\n') == False
    assert match('fuck you\n') == False


# Generated at 2022-06-26 05:43:53.471468
# Unit test for function match
def test_match():
    var_0 = "No such file or directory"
    var_1 = "cp: target `test' is not a directory"
    var_2 = "cp: directory `test' does not exist"

    var_3 = match(var_0)
    var_4 = match(var_1)
    var_5 = match(var_2)

    assert var_3 == True
    assert var_4 == False
    assert var_5 == True

# Generated at 2022-06-26 05:44:01.227404
# Unit test for function match
def test_match():
    args_0 = '\x18\t\x07\x0b\x18\t\x1a\x0e\x0b\x1b\x18\t\x0b\x0b\x18\x1b\x0b\x1a\n\x1b\n\x18\t\x18\x0b\x0b\x1a\x18\t\x0b\x0b\x1a\x1c\x0b\x0b\x18\x0b\x18\t\x1b\x0b\x07\x1c\x18\x07\x0b\x1c\x0b\x07\x18\x1a\x0e\x0b\x1b'
    var_0 = match

# Generated at 2022-06-26 05:44:10.100310
# Unit test for function match
def test_match():
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('i do not understand') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command') == False
    assert match('some command')

# Generated at 2022-06-26 05:44:13.216984
# Unit test for function match
def test_match():
    str_0 = '/Lm\x0bR7$\x16\x03\x1d'
    var_0 = match(str_0)


# Generated at 2022-06-26 05:44:14.075974
# Unit test for function match
def test_match():
    test_case_0()


# Generated at 2022-06-26 05:44:21.653270
# Unit test for function match
def test_match():
    test_object = 'No such file or directory'
    test_object_1 = 'cp: directory '
    test_object_2 = 'does not exist'
    var_1 = match(test_object, test_object_1, test_object_2)
    assert var_1 == None


# Generated at 2022-06-26 05:44:24.099166
# Unit test for function match
def test_match():
    str_0 = 'gJ\x06\x0c\x1dz\\lA)Gt\rH'
    var_0 = match(str_0)
    assert var_0 == True

# Generated at 2022-06-26 05:44:27.804199
# Unit test for function match
def test_match():
    assert match('cp /tmp/foo /tmp/bar/')
    assert match('cp /tmp/foo /tmp/bar/\n cp: target `/tmp/bar/\' is not a directory')


# Generated at 2022-06-26 05:44:59.367808
# Unit test for function match
def test_match():
    var_1 = match('z3q\t1B;4#4@RwR%c)^\tcp -v a b')
    assert var_1 == False
    var_2 = match('z3q\t1B;4#4@RwR%c)^\tcp -v a b')
    assert var_2 == False
    var_3 = match('z3q\t1B;4#4@RwR%c)^\tcp -v a b')
    assert var_3 == False
    var_4 = match('z3q\t1B;4#4@RwR%c)^\tcp -v a b')
    assert var_4 == False

# Generated at 2022-06-26 05:45:02.053494
# Unit test for function match
def test_match():
    var_0 = "cp: cannot stat 'file.txt': No such file or directory"
    var_1 = "cp file.mp3 file.txt"
    var_2 = Command(var_1, var_0)
    var_3 = match(var_2)
    assert var_3 == True


# Generated at 2022-06-26 05:45:08.791161
# Unit test for function match
def test_match():
    assert match(u'cp foo bar/')
    assert match(u'mv foo bar/')
    assert match(u"mv cantmv bar/")
    assert match(u'cp foo /bar/')
    assert match(u'cp foo /bar/foo/')
    assert match(u'cp foo /bar/foo/')
    assert match(u'cp cantcp /bar/foo/')
    assert match(u'cp foo /bar/foo/')
    assert match(u'mv foo /bar/foo/')
    assert match(u'mv cantmv /bar/foo/')
    assert match(u'mv foo /bar/foo/')
    assert match(u'cp foo /bar/foo/')
    assert match(u'cp cantcp /bar/foo/')

# Generated at 2022-06-26 05:45:09.437137
# Unit test for function match
def test_match():
    assert match(str_0), var_0

# Generated at 2022-06-26 05:45:14.148014
# Unit test for function match
def test_match():
    assert match('ylyE0KAn@4j\rAd1+ILf\x0b') == False


# Generated at 2022-06-26 05:45:17.908323
# Unit test for function match

# Generated at 2022-06-26 05:45:20.842760
# Unit test for function match
def test_match():
    assert (match(str_0) == (
        "No such file or directory" in str_0
        or str_0.output.startswith("cp: directory")
        and str_0.output.rstrip().endswith("does not exist")
    ))

# Generated at 2022-06-26 05:45:25.138942
# Unit test for function match
def test_match():
    assert True == match(
        "cp: cannot create directory ‘c/’: No such file or directory")
    assert False == match(
        "cp: cannot create directory ‘c/’: No such file or directory")

# Generated at 2022-06-26 05:45:26.760886
# Unit test for function match
def test_match():
    assert match(str_0)


# Generated at 2022-06-26 05:45:30.928705
# Unit test for function match
def test_match():
    assert match('cp -Rv  a/ b/\ncp: directory `a/b/c\' does not exist\n') == True
    assert match('./test_match.py: line 1: b/c: No such file or directory\n') == True
