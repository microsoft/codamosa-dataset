

# Generated at 2022-06-26 05:35:56.688227
# Unit test for function match

# Generated at 2022-06-26 05:36:07.080369
# Unit test for function match
def test_match():
    complex_0 = Command(script="cp -v /etc/hosts /tmp/hosts", output="cp: directory /tmp/hosts does not exist")
    assert match(complex_0) == True
    complex_1 = Command(script="cp /etc/hosts /tmp/hosts", output="cp: directory /tmp/hosts does not exist")
    assert match(complex_1) == True
    complex_2 = Command(script="cp /etc/hosts /tmp/hosts", output="cp: /tmp/hosts: No such file or directory")
    assert match(complex_2) == True
    complex_3 = Command(script="cp /etc/hosts /tmp/hosts", output="cp: /tmp/hosts: Directory nonexistent")
    assert match(complex_3) == True

# Generated at 2022-06-26 05:36:08.634012
# Unit test for function match
def test_match():
    assert callable(match)


# Generated at 2022-06-26 05:36:13.339694
# Unit test for function match
def test_match():

    # Assign values to the following variables for testing purpose.
    complex_0 = None
    var_0 = match(complex_0)

    # Write your own unit test
    print("Unit test for function match")


# Generated at 2022-06-26 05:36:14.647155
# Unit test for function match
def test_match():
    assert match(complex_0) == var_0


# Generated at 2022-06-26 05:36:18.522335
# Unit test for function match
def test_match():
    complex_command = "cp -r ../{}/src/ ./src"
    var_match = match(complex_command)
    assert var_match == False
    
    complex_command = "cp -r ../{}/src ./src"
    var_match = match(complex_command)
    assert var_match == True
    

# Generated at 2022-06-26 05:36:20.157200
# Unit test for function match
def test_match():
    complex_1 = None
    var_1 = match(complex_1)


# Generated at 2022-06-26 05:36:23.435427
# Unit test for function match
def test_match():
    complex_1 = None
    var_1 = match(complex_1)
    assert u"No such file or directory" in complex_1.output.lower() or complex_1.output.lower().startswith(u"cp: directory") and complex_1.output.lower().rstrip().endswith(u"does not exist")


# Generated at 2022-06-26 05:36:35.022287
# Unit test for function match
def test_match():
    class Complex_0:
        def __init__(self, script, output):
            self.script = script
            self.output = output

    complex_0 = Complex_0(script="cp -v /home/user/Documents/foo.txt /home/user/Documents/foo/", output="cp: cannot stat '/home/user/Documents/foo.txt': No such file or directory")
    assert match(complex_0)
    complex_0 = Complex_0(script="cp -a /home/user/foo.txt /home/user/Documents/foo/", output="cp: cannot stat '/home/user/Documents/foo.txt': No such file or directory")
    assert not match(complex_0)

# Generated at 2022-06-26 05:36:42.038984
# Unit test for function match
def test_match():
    assert match({'script_parts': ["cp", "args0", "args1"], 'output': "cp: cannot stat 'args0': No such file or directory", 'script': "cp args0 args1"}) == True
    assert match({'script_parts': ["cp", "args0", "args1"], 'output': "cp: cannot stat 'args0': No such file or directory", 'script': "cp args0 args1"}) == True
    assert match({'script_parts': ["cp", "args0", "args1"], 'output': "cp: cannot stat 'args0': No such file or directory", 'script': "cp args0 args1"}) == True

# Generated at 2022-06-26 05:36:47.056330
# Unit test for function match
def test_match():
    mock_output = "cp: cannot stat 'nepal/': No such file or directory"
    assert match(None) == False
    mock_output2 = "cp: cannot stat 'ne/': No such file or directory"
    assert match(None) == False



# Generated at 2022-06-26 05:36:50.087488
# Unit test for function match
def test_match():
    # func: match
    # param: command
    # return: type
    var_1 = None
    as_1 = match(var_1)
    # assert that as_1 is a string or not empty
    assert type(as_1) is str or as_1


# Generated at 2022-06-26 05:36:57.539875
# Unit test for function match
def test_match():
    # assert not match(Command("mv test/ /etc/", "mv: cannot stat `test/': No such file or directory\n"))
    assert not match(Command("mv test/ /etc/", "mv: cannot stat `test/': No such file or directory\n"))
    assert match(Command("cp test/ /etc/", "cp: cannot stat `test/': No such file or directory\n"))
    assert match(Command("mv test /etc/", "mv: cannot stat `test': No such file or directory\n"))


# Generated at 2022-06-26 05:36:59.399436
# Unit test for function match
def test_match():
    assert match(command1) is False
    assert match(command2) is True
    assert match(command3) is True



# Generated at 2022-06-26 05:37:00.235389
# Unit test for function match
def test_match():
    test_case_0()
# END Unit test

# Generated at 2022-06-26 05:37:02.028410
# Unit test for function match
def test_match():
    args = [
    ]
    if __name__ == '__main__':
        pytest.main(args)


# Generated at 2022-06-26 05:37:11.066868
# Unit test for function match
def test_match():
    command = "mkdir: cannot create directory ‘/root/repos’: Permission denied"
    assert match(command)
    command = "cp: cannot create directory ‘/root/repos’: Permission denied"
    assert match(command)
    command = "cp: cannot create regular file ‘/root/repos/test.txt’: Permission denied"
    assert match(command)
    command = "cp: cannot stat ‘test.txt’: No such file or directory"
    assert match(command)
    command = "mv: cannot stat ‘test.txt’: No such file or directory"
    assert match(command)
    command = "cp: cannot stat ‘/root/test.txt’: No such file or directory"
    assert match(command)



# Generated at 2022-06-26 05:37:11.974842
# Unit test for function match
def test_match():
    
    assert var_0 == False


# Generated at 2022-06-26 05:37:14.200651
# Unit test for function match
def test_match():
    assert match(None) == False
    assert match("No such file or directory") == True
    assert match("cp: directory") == True

# Generated at 2022-06-26 05:37:15.975070
# Unit test for function match
def test_match():
    command = None
    var_0 = match(command)


# Generated at 2022-06-26 05:37:19.669975
# Unit test for function match
def test_match():
    list_0 = []
    var_0 = match(list_0)


# Generated at 2022-06-26 05:37:26.698759
# Unit test for function match

# Generated at 2022-06-26 05:37:31.336622
# Unit test for function match
def test_match():
    # Case:
    list_1 = ["No such file or directory"]
    var_0 = match(list_1)
    assert var_0 == True
    # Case:
    list_2 = ["cp: directory"]
    var_0 = match(list_2)
    assert var_0 == True
    # Case:
    list_3 = ["does not exist"]
    var_0 = match(list_3)
    assert var_0 == True


# Generated at 2022-06-26 05:37:32.295070
# Unit test for function match
def test_match():
    assert match("abc") == True


# Generated at 2022-06-26 05:37:42.729621
# Unit test for function match
def test_match():
    assert BaseCommand.match([""], "") == False
    assert BaseCommand.match([""], """cp: cannot stat './no_such_dir/': No such file or directory""") == True
    assert BaseCommand.match([""], """cp: directory './no_such_dir/' does not exist""") == True
    assert BaseCommand.match([""], """cp: directory './no_such_dir/' does not exist
""") == True
    assert BaseCommand.match([""], """cp: directory 'no_such_dir/' does not exist
""") == True
    assert BaseCommand.match([""], """cp: directory 'no_such_dir/' does not exist""") == True
    assert BaseCommand.match([""], """cp: cannot stat 'no_such_dir/': No such file or directory""") == True


# Generated at 2022-06-26 05:37:46.401813
# Unit test for function match
def test_match():
    list_0 = ["cp 'test' /tmp/"]
    list_1 = "No such file or directory:"
    var_0 = match(list_0, list_1)


# Generated at 2022-06-26 05:37:49.063854
# Unit test for function match
def test_match():

    if match(list_0)==False:
        print("Test Case 1 failed")
    else:
        print("Test Case 1 Passed")

if __name__ == '__main__':

    test_match()

# Generated at 2022-06-26 05:37:51.275243
# Unit test for function match
def test_match():
    list_0 = []
    var_0 = match(list_0)
    assert var_0 == False

test_case_0()
test_match()

# Generated at 2022-06-26 05:37:52.766709
# Unit test for function match
def test_match():
    assert match(list_0) is True


# Generated at 2022-06-26 05:37:56.118269
# Unit test for function match
def test_match():
    assert match(['cp', '-a', 'test', 'tst2']) is True

test_match()

# Generated at 2022-06-26 05:38:08.640659
# Unit test for function match
def test_match():
    assert match(["cp, ", "no_such_file_or_directory"]) == False
    assert match(["mv, ", "no_such_file_or_directory"]) == False
    assert match(["no_such_file_or_directory, ", "cp, "]) == False
    assert match(["cp, ", "no_such_file_or_directory, "]) == True
    assert match(["cp, ", "cp: ", "directory", " ", "does", " ", "not", " ", "exist"]) == True
    assert match(["mv, ", "cp: ", "directory", " ", "does", " ", "not", " ", "exist"]) == True
    assert match(["mv, ", "mv: ", "directory", " ", "does", " ", "not", " ", "exist"]) == True

# Generated at 2022-06-26 05:38:18.794013
# Unit test for function match
def test_match():
    # Assert that match returns True for commands that start with `cp` and contain an output containing 'No such file or directory'.
    output = 'cps.txt: No such file or directory'
    assert match(Command(script='cp s.txt d.txt', output=output))
    assert match(Command(script='mkdir s.txt d.txt', output=output))
    assert match(Command(script='cp /source/s.txt /destination/d.txt', output=output))
    assert match(Command(script='mv /source/s.txt /destination/d.txt', output=output))

    # Assert that match returns True for commands that start with `cp` and contain an output containing 'cannot stat'.
    output = 'cp: cannot stat '

# Generated at 2022-06-26 05:38:24.862178
# Unit test for function match
def test_match():
    assert (match('Cp: Directory {0} does not exist\n'.format('test.py'))) == True
    assert (match('Cp: Directory {0} does not exist\n'.format('test.py'))) == True
    assert (match('Cp: Directory {0} does not exist\n'.format('test.py'))) == True
    assert (match('Cp: Directory {0} does not exist\n'.format('test.py'))) == True
    assert (match('Cp: Directory {0} does not exist\n'.format('test.py'))) == True
    assert (match('Cp: Directory {0} does not exist\n'.format('test.py'))) == True
    assert (match('Cp: Directory {0} does not exist\n'.format('test.py'))) == True

# Generated at 2022-06-26 05:38:26.275759
# Unit test for function match
def test_match():
    assert match(list_0) == False


# Generated at 2022-06-26 05:38:31.669752
# Unit test for function match
def test_match():
    list_2 = []
    var_2 = match(list_2)


# Generated at 2022-06-26 05:38:36.656581
# Unit test for function match
def test_match():
    list_0 = []
    var_0 = match(list_0)


# Generated at 2022-06-26 05:38:38.550832
# Unit test for function match
def test_match():
    list_0 = ["cp: directory '/a/d/f' does not exist"]
    assert (True == match(list_0))



# Generated at 2022-06-26 05:38:42.501518
# Unit test for function match
def test_match():
    list_0 = ["cp", "path/to/file.ext", "path/to/file.ext.bak"]
    assert_equals(match(list_0), False)


# Generated at 2022-06-26 05:38:43.923166
# Unit test for function match
def test_match():
    list_0 = [cp, mv]
    var_0 = match(list_0)
    print(var_0)


# Generated at 2022-06-26 05:38:53.426197
# Unit test for function match
def test_match():
    assert (match(['No such file or directory']) == True)
    assert (match(['cp: directory foo does not exist']) == True)
    assert (match(['cp: directory foo does not exist']) == True)
    assert (match(['cp: directory foo does not exist']) == True)
    assert (match(['cp: directory foo does not exist']) == True)
    assert (match(['cp: directory foo does not exist']) == True)
    assert (match(['cp: directory foo does not exist']) == True)
    assert (match(['cp: directory foo does not exist']) == True)
    assert (match(['cp: directory foo does not exist']) == True)
    assert (match(['cp: directory foo does not exist foo']) == True)

# Generated at 2022-06-26 05:39:01.573975
# Unit test for function match
def test_match():
    list_0 = []
    parameter_0 = match(list_0)
    assert parameter_0 == False


# Generated at 2022-06-26 05:39:05.731753
# Unit test for function match
def test_match():
    assert match("cp: cannot stat '/etc/app/app.conf.bak': No such file or directory") == True
    assert match("cp: cannot stat '/etc/app/app.conf.bak': Not a directory") == False
    assert match("cp: directory '/etc/app/app.conf.bak' does not exist") == True

# Generated at 2022-06-26 05:39:08.040364
# Unit test for function match
def test_match():
    assert match(list_0) == None


# Generated at 2022-06-26 05:39:10.378095
# Unit test for function match
def test_match():
    list_0 = ["cp", "lol", "lollol", "-r", "./lalala"]
    var_0 = match(list_0)
    assert var_0 is None


# Generated at 2022-06-26 05:39:13.656108
# Unit test for function match
def test_match():
    list_0 = ["cp", "src", "dest"]
    list_1 = ["mv"]
    var_0 = match(list_0)
    var_1 = match(list_1)

test_match()

# Generated at 2022-06-26 05:39:14.513747
# Unit test for function match
def test_match():
    assert match(list_0) == True

# Generated at 2022-06-26 05:39:16.982644
# Unit test for function match
def test_match():
    assert match(list_0), "Test case match"



list_0 = []
var_0 = get_new_command(list_0)
test_case_0()
test_match()

# Generated at 2022-06-26 05:39:21.542577
# Unit test for function match
def test_match():
    assert (match(["cp", "No such file or directory"]))
    assert (not match(["not cp", "No such file or directory"]))
    assert (match(["cp", "cp: directory"]))
    assert (not match(["not cp", "cp: directory"]))

# Generated at 2022-06-26 05:39:22.890484
# Unit test for function match
def test_match():
    list_0 = []
    var_0 = match(list_0)
    assert var_0 == False

# Generated at 2022-06-26 05:39:26.975364
# Unit test for function match
def test_match():
    # prep
    list_0 = []
    # act
    var_0 = match(list_0)
    # assert
    assert var_0 == None


# Generated at 2022-06-26 05:39:40.070629
# Unit test for function match
def test_match():
    case_0 = "mv: cannot stat ‘test’: No such file or directory"
    assert match(case_0) == False


# Generated at 2022-06-26 05:39:44.127142
# Unit test for function match
def test_match():
    assert(match([]) == False)
    assert(match(['No such file or directory']) == True)
    assert(match(['cp: directory']) == False)
    assert(match(['cp: directory does not exist']) == True)

# Generated at 2022-06-26 05:39:45.187013
# Unit test for function match
def test_match():
    assert match() == True


# Generated at 2022-06-26 05:39:48.639256
# Unit test for function match
def test_match():
    script = "cp abc.txt abc.txt"
    output = """
cp: cannot stat 'abc.txt': No such file or directory
"""
    command = Command(script, output)
    assert match(command)

# Generated at 2022-06-26 05:39:56.642683
# Unit test for function match
def test_match():
	import sys
	sys.stdout = open('./tests/tmp/out', 'w')
	command = match()
	assert command.output == 'No such file or directory: dir_notfound_tests'
	assert command.script == 'cp -r ./tests/tmp/file1 ./tests/tmp/file2 ./tests/tmp/dir_notfound_tests'

# Generated at 2022-06-26 05:40:04.946231
# Unit test for function match
def test_match():
    list = []
    var = match(list)
    assert var == False
    list = ["cp 1.txt t1.txt"]
    var = match(list)
    assert var == False
    list = ["cp 1.txt  t1.txt"]
    var = match(list)
    assert var == False
    list = ["cp  t1.txt 1.txt"]
    var = match(list)
    assert var == False
    list = ["cp 1.txt t1.txt", "t1.txt"]
    var = match(list)
    assert var == False
    list = ["cp 1.txt t1.txt", "t1.txt"]
    var = match(list)
    assert var == False
    list = ["cp 1.txt t1.txt", "t1.txt"]

# Generated at 2022-06-26 05:40:09.770046
# Unit test for function match
def test_match():
    cmd = Command(
        "",
        "cp: cannot stat '/path/to/some/where': No such file or directory",
    )
    assert match(cmd)

    cmd = Command(
        "",
        "cp: directory '/path/to/some/where' does not exist",
    )
    assert match(cmd)

    cmd = Command("", "encountered argument 'f' that wasn't expected")
    assert not match(cmd)

# Generated at 2022-06-26 05:40:13.442660
# Unit test for function match
def test_match():
    command_0 = "mv: cannot stat 'dir_0': No such file or directory\n"
    command_0 = Command(command_0)
    assert match(command_0)


# Generated at 2022-06-26 05:40:23.083096
# Unit test for function match
def test_match():
    assert match(['cp', '-a', 'source/', 'dest']) == False
    assert match(['mv', 'destination/', 'destination/']) == False
    assert match(['cp', '-a', 'source/', 'destination']) == False
    assert match(['cp', '-a', '-r', 'source/', 'destination/']) == False
    assert match(['mv']) == False
    assert match(['cp', '/source/', 'destination/']) == False
    assert match(['cp', '-a', '/source/', 'destination/']) == False
    assert match(['cp', '-a', '/source/', 'destination/']) == False
    assert match(['cp', '-a', 'source/', '/destination/']) == False


# Generated at 2022-06-26 05:40:29.183099
# Unit test for function match
def test_match():
    command = Command("cp -R a/b c", "cp: directory a/b does not exist")
    assert match(command)
    command = Command("cp -R a/b c", "cp: omitting directory a/b")
    assert not match(command)
    command = Command("mv -R a/b c", "mv: directory a/b does not exist")
    assert match(command)
    command = Command("mv -R a/b c", "mv: omitting directory a/b")
    assert not match(command)


# Generated at 2022-06-26 05:40:57.184191
# Unit test for function match
def test_match():
    var_0 = "cp: cannot stat 'firefox.desktop': No such file or directory"
    var_1  = match(var_0)
    assert var_1 == True


# Generated at 2022-06-26 05:41:00.392817
# Unit test for function match
def test_match():
    input_str = "No such file or directory"
    output_str = match(input_str)
    assert output_str.rstrip() == "cp: directory '/tmp' does not exist"
    

# Generated at 2022-06-26 05:41:01.130656
# Unit test for function match
def test_match():
    assert match([]) is False


# Generated at 2022-06-26 05:41:03.985717
# Unit test for function match
def test_match():
    var_0 = Command('cp -a /etc /tmp/etc', u'cp: cannot stat \u2018/etc\u2019: No such file or directory')
    assert match(var_0) == True


# Generated at 2022-06-26 05:41:05.716037
# Unit test for function match
def test_match():
    list_0 = []
    var_0 = match(list_0)
    assert var_0 == False



# Generated at 2022-06-26 05:41:08.405743
# Unit test for function match
def test_match():
    assert match(list_0) == False
    assert match(list_0) == True

# Generated at 2022-06-26 05:41:09.989607
# Unit test for function match
def test_match():
    list_0 = 'lsa'
    var_0 = match(list_0)
    assert var_0 == False

# Generated at 2022-06-26 05:41:11.752503
# Unit test for function match
def test_match():
    assert match(list_0) == "No such file or directory"

# Generated at 2022-06-26 05:41:13.643001
# Unit test for function match
def test_match():
    assert match(['cp foo bar'])
    assert match(['cp -r dir1 dir2'])


# Generated at 2022-06-26 05:41:17.571033
# Unit test for function match
def test_match():
    # == START ==
    assert match("cp: cannot stat '/banana/banana/foo.txt': No such file or directory")
    assert match("cp: cannot stat '/banana/banana/foo.txt': No such file or directory\n")
    assert match("cp: directory '/banana/banana' does not exist\n")
    # == END ==


# Generated at 2022-06-26 05:42:08.984635
# Unit test for function match
def test_match():
    assert not(match("""cp: cannot open '/folder/file.txt' for reading: No such file or directory"""))


# Generated at 2022-06-26 05:42:10.512730
# Unit test for function match
def test_match():
    print("Test case 0 [No such file or directory found]")
    test_case_0()

# Generated at 2022-06-26 05:42:15.993020
# Unit test for function match
def test_match():
    assert match(['cp /homme/example/fruit.txt /homme/example/vegetables.txt', 'mv /homme/example/fruit.txt /homme/example/vegetables.txt']) == False
    assert match(['cp /homme/example/fruit.txt /homme/example/vegetables.txt', 'mv /homme/example/fruit.txt /homme/example/vegetables.txt']) == False


# Generated at 2022-06-26 05:42:22.130916
# Unit test for function match
def test_match():
    # Match case
    assert match('mkdir not_existing_dir\ncp file not_existi|ng_dir/')
    assert match('mkdir not_existing_dir\nmv file not_existi|ng_dir/')
    assert match('cp file not_existi|ng_dir/')
    assert match('mv file not_existi|ng_dir/')

    # No match case
    assert not match('mv file not_existi|ng_dir')


# Generated at 2022-06-26 05:42:30.306415
# Unit test for function match
def test_match():
    assert match("cp: cannot stat 'foo': No such file or directory")
    assert match("mv: cannot stat 'foo': No such file or directory")
    assert match("cp: omitting directory '/tmp/does not exist'")
    assert match("mv: omitting directory '/tmp/does not exist'")

    assert not match("No such file or directory")
    assert not match("cp: cannot stat 'foo'")
    assert not match("mv: cannot stat 'foo'")
    assert not match("cp: directory '/tmp/' does not exist")
    assert not match("mv: directory '/tmp/' does not exist")
    assert not match(
        "cp: omitting directory '/tmp/does not exist'; not copying file 'foo'"
    )

# Generated at 2022-06-26 05:42:36.684349
# Unit test for function match
def test_match():

    # Test type and properties
    assert isinstance(get_new_command, FunctionType)
    assert match.__name__ == 'match'
    assert match.__doc__ == 'Automatically mkdir the path if the error is "No such file or directory"\n        or "cp: directory ...", i.e. if the directory doesn\'t exist.'


# Generated at 2022-06-26 05:42:43.120131
# Unit test for function match
def test_match():
    # Case 1
    command = "cp: cannot stat 'TODO': No such file or directory"
    assert match(command) is True, "Case 1 failed!"

    # Case 2
    command = "cp: cannot stat 'TODO': No such file or director"
    assert match(command) is False, "Case 2 failed!"


# Generated at 2022-06-26 05:42:46.730803
# Unit test for function match
def test_match():
    list_0 = []
    list_0 = "No such file or directory" in list_0
    assert (list_0 == False)


# Generated at 2022-06-26 05:42:52.904336
# Unit test for function match
def test_match():
    assert match("cp: cannot stat 'a.txt': No such file or directory\n")
    assert match("mv: cannot stat 'a.txt': No such file or directory\n")
    assert not match("'a.txt': No such file or directory\n")
    assert match("cp: cannot stat 'a/b.txt': No such file or directory\n")
    assert match("cp: cannot stat 'a/x/b.txt': No such file or directory\n")
    assert match("cp: cannot stat 'a/b.txt': No such file or directory\n")
    assert match("cp: cannot stat 'a/x/b.txt': No such file or directory\n")
    assert match("cp: cannot stat './a/b.txt': No such file or directory\n")

# Generated at 2022-06-26 05:42:55.165893
# Unit test for function match
def test_match():
    list_0 = []
    var_0 = match(list_0)
    assert var_0 == False


# Generated at 2022-06-26 05:44:59.783884
# Unit test for function match
def test_match():
    pass

# Generated at 2022-06-26 05:45:02.549430
# Unit test for function match

# Generated at 2022-06-26 05:45:03.282594
# Unit test for function match
def test_match():
    assert match('')


# Generated at 2022-06-26 05:45:04.069980
# Unit test for function match
def test_match():
    assert bool(match())


# Generated at 2022-06-26 05:45:05.158314
# Unit test for function match
def test_match():
    list_0 = []
    assert match(list_0) == False


# Generated at 2022-06-26 05:45:15.210904
# Unit test for function match
def test_match():
    list_0 = []
    list_0.script = "python thefuck/types.py"
    list_1 = "No such file or directory"
    list_2 = "mv: cannot create regular file 'thefuck/types.py': Argument list"
    list_3 = list_2[0:24]
    list_4 = ("No such file or directory" in list_2)
    list_5 = "cp: cannot stat 'thefuck/types.py': No such file or directory"
    list_6 = list_5[0:24]
    list_7 = ("No such file or directory" in list_5)
    list_8 = "cp: directory 'thefuck/types.py' does not exist"
    list_9 = list_8[0:27]

# Generated at 2022-06-26 05:45:20.923852
# Unit test for function match
def test_match():
    assert True == match('cp -p -R /src/* /dst')
    assert True == match('mv -R /src/* /dst')
    assert True == match('cp -p -R /src/* /dst\n cp: cannot stat ‘/src/*’: No such file or directory\n')
    assert False == match('cp local-filename.txt ~/target-folder/')
    assert False == match('mv local-filename.txt ~/target-folder/')

# Generated at 2022-06-26 05:45:23.862823
# Unit test for function match
def test_match():
    command = Command(script='cp', stdout='')
    var_0 = match(command)

# Generated at 2022-06-26 05:45:28.457796
# Unit test for function match
def test_match():
    list_0 = ["cp: cannot stat ‘/etc/fdsafdas/’: No such file or directory"]
    var_0 = match(list_0)


# Generated at 2022-06-26 05:45:35.329051
# Unit test for function match