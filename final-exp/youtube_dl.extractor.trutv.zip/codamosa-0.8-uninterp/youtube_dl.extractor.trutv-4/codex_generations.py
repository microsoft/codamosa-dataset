

# Generated at 2022-06-14 17:16:32.141598
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-14 17:16:33.701457
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(isinstance(TruTVIE, TurnerBaseIE))

# Generated at 2022-06-14 17:16:35.631408
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  test = TruTVIE()
  print("TruTVIE class constructor test passed")


# Generated at 2022-06-14 17:16:43.577465
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-14 17:16:44.575842
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE


# Generated at 2022-06-14 17:16:46.367927
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTvIE', 'TruTVIE', TruTVIE._VALID_URL)

# Generated at 2022-06-14 17:16:53.498848
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-14 17:16:59.666038
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Calling constructor of class TruTVIE: ")
    # URL and info_dict arguments are optional
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
#     url = TruTVIE._TEST['url']
    info_dict = TruTVIE._TEST['info_dict']
#     print(TruTVIE._TEST)
    test = TruTVIE(url, info_dict)
    print(type(test))
    return test
    

# Generated at 2022-06-14 17:17:02.649396
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html", "swag")

# Generated at 2022-06-14 17:17:10.684073
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.extract('https://www.trutv.com/full-episodes/1555904/the-carbonaro-effect-sunlight-activated-flower-season-1-ep-106.html')
    ie.extract('https://www.trutv.com/full-episodes/1555904/the-carbonaro-effect-sand-over-the-glass-season-1-ep-106.html')

# Generated at 2022-06-14 17:17:22.409260
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test URL: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    # series_slug: the-carbonaro-effect
    # clip_slug: sunlight-activated-flower
    # video_id: None
    assert TruTVIE._match_id(TruTVIE._TEST['url']) == ('the-carbonaro-effect', 'sunlight-activated-flower', None)

# Generated at 2022-06-14 17:17:24.630548
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-14 17:17:34.595011
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # Access protected variables for testing purposes
    assert ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie._TEST['info_dict'] == {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
    }

test_TruTVIE()

# Generated at 2022-06-14 17:17:41.277523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  # create object 
  TruTVIE_obj = TruTVIE()
  print(TruTVIE_obj._VALID_URL)
  print(TruTVIE_obj._TEST['url'])
  print(TruTVIE_obj._TEST['info_dict'])
  print(TruTVIE_obj._TEST['params'])
   
# Call function
test_TruTVIE()

# Generated at 2022-06-14 17:17:41.922487
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-14 17:17:53.752621
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tt = TruTVIE()
    assert tt._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-14 17:17:56.699844
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-14 17:17:57.962002
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()



# Generated at 2022-06-14 17:18:05.048872
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #__init__(self, host, series_id, api_key, app_code, publisher_token, series_slug, clip_slug=None):
    TruTVIE('www.trutv.com', '38', '', '', '', 'im-sorry', 'clip-1')
    TruTVIE('www.trutv.com', '38', '', '', '', 'im-sorry')


# Generated at 2022-06-14 17:18:12.187950
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == TruTVIE._VALID_URL
    assert instance._TEST == TruTVIE._TEST
    assert instance._extract_ngtv_info == TruTVIE._extract_ngtv_info
    assert instance._call_api == TruTVIE._call_api
    assert instance._download_json == TruTVIE._download_json
    assert instance.ie_key() == 'TruTV'
    assert instance._real_extract == TruTVIE._real_extract
    assert instance._real_initialize == TruTVIE._real_initialize

# Generated at 2022-06-14 17:18:22.803430
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.constructor(None) == TruTVIE


# Generated at 2022-06-14 17:18:29.773939
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert "truTV" in trutv.ie_key()
    assert "truTV" in trutv.site_name()
    assert "tv" in trutv.ie_key()
    assert "tv" in trutv.site_name()
    assert "turner" in trutv.ie_key()
    assert "turner" in trutv.site_name()

# Generated at 2022-06-14 17:18:38.887252
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable(TruTVIE._VALID_URL) is True
    assert TruTVIE.suitable('http://ixxx.com/video-123') is False
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is True
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/123') is True
    assert TruTVIE.suitable('https://www.trutv.com/full-episodes/the-carbonaro-effect/123') is True
    assert TruTVIE.suitable('https://www.trutv.com/shows/impractical-jokers/videos/jokers-halloween-special.html') is True
   

# Generated at 2022-06-14 17:18:42.259779
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    turntv_ie = TruTVIE()
    turntv_ie._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-14 17:18:49.756072
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE instance with url
    trutv_ie = TruTVIE()

    # Check if the url is valid
    assert trutv_ie._match_id('https://www.trutv.com/full-episodes/1002902/impractical-jokers-s06e04-a-little-salmon-under-the-sea.html')

    # Check if the extracted info is valid
    assert trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/2292')

# Generated at 2022-06-14 17:18:57.209902
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    if __name__ == '__main__':
        import sys
        from youtube_dl.utils import youtubedl

        youtube_dl = youtubedl(params={})
        TruTVIE.youtube_dl = youtube_dl
        cls = TruTVIE(params={})
        print('TruTVIE.params', cls.params)
        url = 'https://www.trutv.com/shows/how-to-be-a-grownup/videos/college-graduation.html'
        info = cls._real_extract(url)
        print('url', info)

# Generated at 2022-06-14 17:18:58.142342
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-14 17:19:00.103919
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    metadata_object = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-14 17:19:01.373661
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.download(ie._TEST['url'])

# Generated at 2022-06-14 17:19:02.626059
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert(trutv.IE_NAME == "TruTV")

# Generated at 2022-06-14 17:19:24.652769
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test data
    url = "https://www.trutv.com/shows/full-episodes/videos/pawn-shop-champs-champ-of-chumps.html"
    TruTVIE.test(url)

# Generated at 2022-06-14 17:19:25.865632
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-14 17:19:26.918490
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().__class__.__name__ == 'TruTVIE'


# Generated at 2022-06-14 17:19:29.549988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("\nTesting TruTVIE constructor")
    trutv_ie = TruTVIE()
    print(trutv_ie)
    print("Done testing TruTVIE constructor")



# Generated at 2022-06-14 17:19:31.679361
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    print(trutvIE.get_info())

# Generated at 2022-06-14 17:19:32.272102
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-14 17:19:41.323257
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.TEST = {'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'info_dict': {'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'ext': 'mp4', 'title': 'Sunlight-Activated Flower', 'description': "A customer is stunned when he sees Michael's sunlight-activated flower."}, 'params': {'skip_download': True}}
    TruTVIE()

# Generated at 2022-06-14 17:19:44.165796
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t is not None
    assert t.getId() == "trutv"

# Generated at 2022-06-14 17:19:52.837600
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor:
    try:
        from .turner import TruTVIE
    except ImportError:
        return
    test = TruTVIE( Tester() )
    assert test.ie_key() == 'TruTV'
    assert test.ie_name() == 'TruTV'

    # Test TruTVIE constructor with an instance of InfoExtractor:
    test2 = TruTVIE( Tester(), ie=InfoExtractor() )
    assert test2.ie_key() == 'TruTV'
    assert test2.ie_name() == 'TruTV'


# Generated at 2022-06-14 17:19:57.078790
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test1 = TruTVIE()
    test2 = TruTVIE()
    assert test1 == test2

# Generated at 2022-06-14 17:20:40.763378
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Valid URL
    test_TruTVIE = TruTVIE(TruTVIE._TEST)
    assert test_TruTVIE

    # Invalid URL
    TruTVIE("http://www.trutv.com")

# Generated at 2022-06-14 17:20:43.184089
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-14 17:20:43.808485
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-14 17:20:44.770763
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE();

# Generated at 2022-06-14 17:20:48.522326
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    obj._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-14 17:20:49.598551
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.get_name() == 'trutv'

# Generated at 2022-06-14 17:21:01.891035
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z\-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z\-]+)|(?P<id>\d+))'

# Generated at 2022-06-14 17:21:06.261189
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ie.IE_NAME == 'TruTV'

# Generated at 2022-06-14 17:21:07.100409
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)

# Generated at 2022-06-14 17:21:09.106885
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._extract_url(test['url'])

# Generated at 2022-06-14 17:22:47.061175
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-14 17:22:55.979881
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__doc__ == TruTVIE._TEST['__doc__']
    assert TruTVIE.suitable(TruTVIE._TEST['url']) == TruTVIE._TEST['suitable']
    assert TruTVIE.IE_DESC == 'truTV'
    assert TruTVIE.ie_key() == 'TruTV'
    assert TruTVIE._TESTS == []
    TruTVIE._downloader = None
    assert TruTVIE._real_extract(TruTVIE._TEST['url']) == TruTVIE._TEST['info_dict']


# Generated at 2022-06-14 17:22:56.575364
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-14 17:22:59.794139
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-14 17:23:02.219108
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1")


# Generated at 2022-06-14 17:23:04.406829
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE)

# Generated at 2022-06-14 17:23:10.525701
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('TruTV')._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-14 17:23:14.898599
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This test simply verifies that the TruTVIE constructor works
    # properly.
    assert TruTVIE


# Generated at 2022-06-14 17:23:16.558498
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().suitable("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") == True

# Generated at 2022-06-14 17:23:17.662571
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    True