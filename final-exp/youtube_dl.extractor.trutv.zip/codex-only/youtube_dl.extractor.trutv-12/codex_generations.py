

# Generated at 2022-06-24 13:18:51.368605
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:18:53.084744
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'

# Generated at 2022-06-24 13:18:58.518915
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    tt = TruTVIE()
    assert tt.ie_key() == "trutv"
    assert tt.ie_name() == "truTV"
    assert TruTVIE.ie_key() == "trutv"
    assert TruTVIE.ie_name() == "truTV"
    assert tt.SUCCESS == TruTVIE.SUCCESS


# Generated at 2022-06-24 13:19:00.578936
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE
    assert TurnerBaseIE

# Generated at 2022-06-24 13:19:03.379422
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	print("def test_TruTVIE()")
	#assert TruTVIE.__bases__[0] == generic_download


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:19:04.328322
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:04.899044
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:06.682363
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_ie = TruTVIE()
    assert isinstance(ttv_ie, TruTVIE)

# Generated at 2022-06-24 13:19:08.651132
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # URL found from the website.
    TruTVIE('TruTVIE', True)
    # No exception raised.
    print("OK")

# Generated at 2022-06-24 13:19:09.846423
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  trutv_video = TruTVIE()

# Generated at 2022-06-24 13:19:10.352198
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:20.374363
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None)._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE(None)._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE(None)._TEST['params'] == {'skip_download': True}

# Generated at 2022-06-24 13:19:21.402379
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test no exceptions raised
    TruTVIE()

# Generated at 2022-06-24 13:19:23.620215
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Class TruTVIE exists and contains a constructor without parameters
    """
    assert TruTVIE is not None

# Generated at 2022-06-24 13:19:24.789571
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(TruTVIE._TEST)

# Generated at 2022-06-24 13:19:32.761142
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-24 13:19:36.472668
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Construct object with working arguments
    TruTVIE('https://api.trutv.com/v2/web/series/clip/' +
            'top-20-most-shocking/neighborhood-dog-attack')

    # Construct object with non-working arguments
    TruTVIE('https://www.trutv.com/shows/the-car' +
            'bonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:19:38.342624
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST == TruTVIE._TEST
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:19:38.899925
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:45.835982
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor of TruTVIE
    ie = TruTVIE()
    # check attribute '_VALID_URL' of class TruTVIE
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:46.827668
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t is not None

# Generated at 2022-06-24 13:19:50.469429
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttv_ie = TruTVIE()
    ttv_ie._real_extract(url)
    pass

# Generated at 2022-06-24 13:19:57.304574
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tvi = TruTVIE()
    assert tvi._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert tvi._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:20:00.138236
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert TruTVIE._VALID_URL == trutv._VALID_URL
    assert TruTVIE._TEST == trutv._TEST

# Generated at 2022-06-24 13:20:01.280700
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()

# Generated at 2022-06-24 13:20:05.562596
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    if (trutv_ie):
        print("Successfully created class TruTVIE")
    else:
        print("Failed to create class TruTVIE")
        
if __name__ == '__main__':
    test_TruTVIE()


# Generated at 2022-06-24 13:20:09.163825
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # instance of TruTVIE class
    trutvIE = TruTVIE()
    # assert statement is used to check if the expression returns True
    # assert is used here to check if the variable "true" is True or False
    assert isinstance(trutvIE,TruTVIE)
    
test_TruTVIE()

# Generated at 2022-06-24 13:20:09.680707
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-24 13:20:10.684546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    print("Test TruTVIE OK!")


# Generated at 2022-06-24 13:20:12.297523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trueTV = TruTVIE()
    assert trueTV
    assert not trueTV.isWorking()

# Generated at 2022-06-24 13:20:14.215307
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()

# Generated at 2022-06-24 13:20:15.041574
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-24 13:20:17.165796
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE is not None

# Generated at 2022-06-24 13:20:18.124384
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-24 13:20:18.686579
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIEIE()

# Generated at 2022-06-24 13:20:20.019262
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE();



# Generated at 2022-06-24 13:20:20.438565
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:25.791421
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.name == "TruTV"
    assert trutv.description == "truTV"
    assert trutv.extract_ngtv_info is not None
    assert trutv.format_ngtv_url is not None
    assert trutv.is_logged_in is not None
    assert trutv.login is not None
    assert trutv.logout is not None
    assert trutv.notes == "Requires authentication to watch full episodes."
    assert trutv.authentication == True
    print("Completed test_TruTVIE()")


# Generated at 2022-06-24 13:20:26.710225
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(TruTVIE())

# Generated at 2022-06-24 13:20:36.561710
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Tests trutv.com full episodes URL
    test_url = TruTVIE._TEST['url']
    expected_id = TruTVIE._TEST['info_dict']['id']
    result = TruTVIE(_download_json = lambda url, display_id: {}) \
        ._extract_ngtv_info(expected_id, {}, {'url': test_url, 'site_name': 'truTV'})
    assert result['url'] == test_url
    assert result['id'] == expected_id

    # Tests trutv.com clips URL
    test_url = TruTVIE._TEST['url'] \
        .replace('shows/the-carbonaro-effect/videos', 'full-episodes') \
        .replace('/sunlight-activated-flower.html', '/')
    expected_id

# Generated at 2022-06-24 13:20:37.624471
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(TruTVIE._downloader)

# Generated at 2022-06-24 13:20:40.289964
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
# Test successful case
test_TruTVIE()._real_extract(test_TruTVIE()._TEST['url'])

# Generated at 2022-06-24 13:20:49.185390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Assert that the constructor of class TruTVIE
    # accepts a valid URL and not vice versa
    assert TruTVIE.suitable(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    assert TruTVIE.suitable(
        'https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    assert TruTVIE.suitable(
        'https://www.trutv.com/full-episodes/the-carbonaro-effect/273581/sunlight-activated-flower.html') == True

# Generated at 2022-06-24 13:20:50.357011
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	tt = TruTVIE({})


# Generated at 2022-06-24 13:20:53.397215
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:20:54.062461
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:02.894134
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    def test_mock_download(path):
        print('testing mock download')
        print('path: ' + path)
        return {'episode': {'mediaId': '12345678'}}
    TruTVIE._download_json = test_mock_download
    instance = TruTVIE()
    assert instance.IE_NAME == 'trutv:trutv'
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:05.706366
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case = TruTVIE()._TEST
    url = test_case['url']
    ie = TruTVIE(url)
    assert ie._VALID_URL == TruTVIE._VALID_URL
    assert ie._TEST == test_case

# Generated at 2022-06-24 13:21:07.094058
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video = TruTVIE()
    assert video.ie_key() == 'truTV'

# Generated at 2022-06-24 13:21:07.997121
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:09.293548
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE IE
    TruTVIE()

# Generated at 2022-06-24 13:21:17.581645
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Testing URL
    test = TruTVIE()
    test._download_json = lambda url: {'episode': {'title': 'Sunlight-Activated Flower', 'description': "A customer is stunned when he sees Michael's sunlight-activated flower."}}
    test._extract_ngtv_info = lambda media_id, params, info: {'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'ext': 'mp4'}
    test._real_extract(url)

    # Test for title
    print(test.title)
    assert test.title == 'Sunlight-Activated Flower'

    # Test

# Generated at 2022-06-24 13:21:19.054082
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:21:25.951441
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    result = TruTVIE()._real_extract(test_url)
    # print result
    assert result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert result['duration'] == 1565
    assert result['title'] == 'Sunlight-Activated Flower'

# Generated at 2022-06-24 13:21:36.252400
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_test = TruTVIE()
    # Check
    assert ttv_test._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }


# Generated at 2022-06-24 13:21:37.214140
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:39.259218
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE()._TEST == TruTVIE._TEST)


# Generated at 2022-06-24 13:21:40.701143
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test constructor of class TruTVIE
    """
    TruTVIE(None)

# Generated at 2022-06-24 13:21:41.772532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('TruTV') is not None


# Generated at 2022-06-24 13:21:51.703244
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    p = re.match(t._VALID_URL, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert p.group(1) == 'the-carbonaro-effect'
    assert p.group(2) == 'sunlight-activated-flower'
    assert p.group(3) is None

# Generated at 2022-06-24 13:21:58.574329
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an object of class TruTVIE
    trutv_ie = TruTVIE()
    assert trutv_ie is not None
    # Test for the trutv's URL pattern
    trutv_ie._VALID_URL = 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:07.893399
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    inst = TruTVIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert inst.IE_NAME == 'trutv'
    assert inst.FILE_SUFFIX == '?device=html5'
    assert inst.BRIGHTCOVE_URL_TEMPLATE == 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=%s'


# Generated at 2022-06-24 13:22:12.768252
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:22:15.419009
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE constructor"""

    assert(re.match(TruTVIE._VALID_URL, TruTVIE._TEST['url']) is not None)


# Generated at 2022-06-24 13:22:23.140459
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:26.720811
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable("Url of site to be tested")
    assert not ie.suitable("Url of site not to be tested")
    print("Unit test MalIE: \t\t OK")


# Generated at 2022-06-24 13:22:32.334872
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_class_name = TruTVIE.__name__
    test_class = TruTVIE
    test_urls = TruTVIE._TEST
    for url in test_urls:
        print("TESTING: " + test_class_name + " for url: " + url)
        test_class_instance = test_class()
        assert test_class_instance



# Generated at 2022-06-24 13:22:33.050428
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:22:42.960414
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # unit test for constructor
    from .. import TruTVIE
    trutv_ie = TruTVIE()
    trutv_ie = TruTVIE(
        turner_client='turner_client',
        turner_client_id='turner_client_id',
        turner_api_key='turner_api_key',
        turner_beacon_id='turner_beacon_id',
        turner_beacon_key='turner_beacon_key',
    )
    assert trutv_ie.client_id == 'turner_client'
    assert trutv_ie.client_id == 'turner_client_id'
    assert trutv_ie.api_key == 'turner_api_key'

# Generated at 2022-06-24 13:22:44.372041
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE by calling its constructor and check if result is correct
    TruTVIE()



# Generated at 2022-06-24 13:22:46.127704
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:22:47.148036
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:22:48.023875
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	explorer = TruTVIE()

# Generated at 2022-06-24 13:22:51.162126
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # just ensure the constructor of class TruTVIE is valid
    trutv_ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:52.503123
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert(trutv_ie.ie_key() == 'TruTV')

# Generated at 2022-06-24 13:22:55.118530
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://api.trutv.com/v2/web/series/clip/impractical-jokers/tiger-house-cat/a5f5c54740004f8f88505b365f4d4fa9")

# Generated at 2022-06-24 13:22:57.490152
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:58.687449
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert(isinstance(TruTVIE, object))


# Generated at 2022-06-24 13:23:01.410178
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html");


# Generated at 2022-06-24 13:23:08.115988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            'skip_download': True,
        }
    }

# Generated at 2022-06-24 13:23:09.537276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	trutv = TruTVIE()
	assert(trutv)	# Constructor should return

# Generated at 2022-06-24 13:23:11.604137
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE is not None

# Generated at 2022-06-24 13:23:14.599578
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): sample_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"; TruTVIE()._real_extract(sample_url)

# Generated at 2022-06-24 13:23:19.024426
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()._get_info(url)
    test_dict = trutv_ie.__dict__
    assert test_dict['_TEST']['url'] == url



# Generated at 2022-06-24 13:23:19.550568
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-24 13:23:20.365415
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:20.855795
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:23:30.184867
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttv = TruTVIE(url)
    assert ttv is not None
    assert ttv.url == url
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:40.146232
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    temp = TruTVIE()
    assert temp._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert temp._TEST.get('url') == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert temp._TEST.get('info_dict').get('id') == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert temp._TEST.get

# Generated at 2022-06-24 13:23:40.997245
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

test_TruTVIE()

# Generated at 2022-06-24 13:23:41.868577
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-24 13:23:45.020335
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	try:
		# Initialize TruTVIE constructor
		truTV = TruTVIE(True)

	except Exception as e:
		print(str(e))
		return False

	return True


# Generated at 2022-06-24 13:23:50.085888
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check type of class TruTVIE
    assert TruTVIE, 'TruTVIE is object type'
    # Check arguments in constructor of class TruTVIE
    assert TruTVIE.__init__, 'TruTVIE have __init__ method'
    # Check if number of argument in __init__ method is correct
    assert TruTVIE.__init__.__code__.co_argcount == 6, 'Number of arguments is not correct'


# Generated at 2022-06-24 13:23:50.770621
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:23:52.589132
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	#get class object
	obj = TruTVIE()
	#assert instance of class
	assert(isinstance(obj, TruTVIE))

# Generated at 2022-06-24 13:23:54.286183
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video = TruTVIE()

    assert(video.name() == "trutv")

# Test the run function

# Generated at 2022-06-24 13:23:56.807090
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    _ = TruTVIE(url)
    return True

# Generated at 2022-06-24 13:23:59.955815
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Constructor of class TruTVIE.
    """
    TruTVIE(TurnerBaseIE._downloader, TurnerBaseIE._downloader.context)

# Generated at 2022-06-24 13:24:02.139138
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:24:05.120006
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url_test = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()._real_extract(url_test)

# Generated at 2022-06-24 13:24:13.812355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:17.644426
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE constructor")

    # Create dummy test object with valid url.
    testObj = TruTVIE()
    testObj.url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert testObj.url == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html", "Expected url did not matched"

# Generated at 2022-06-24 13:24:18.843566
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    c = TruTVIE()

# Generated at 2022-06-24 13:24:24.166089
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video_url_1 = 'https://www.trutv.com/full-episodes/91297/truTV-presents-worlds-dumbest-videos-gorilla-cam-ep-161.html'
    video_url_2 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    video_url_3 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    video_data_1 = TruTVIE()._real_extract(video_url_1)
    video_data_2 = TruTVIE()._real_extract(video_url_2)

# Generated at 2022-06-24 13:24:25.608611
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:24:28.194941
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract(('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
    assert ie
    return ie

# Generated at 2022-06-24 13:24:29.312826
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:24:30.452766
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test_TruTVIE = TruTVIE()

# Generated at 2022-06-24 13:24:32.414415
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None


# Generated at 2022-06-24 13:24:35.801495
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.host == "trutv.com"
    assert ie.name == "truTV"
    assert ie.ie_key() == "trutv"

# Generated at 2022-06-24 13:24:45.752267
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ttv._TEST['info_dict'] == {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
    }
    return True

# Generated at 2022-06-24 13:24:47.438038
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor takes in a YouTubeIE object called yt
    TruTVIE("youtube")


# Generated at 2022-06-24 13:24:48.193971
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:55.710908
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Testing TruTVIE')
    # Create instance for unit test
    trutv_ie = TruTVIE()
    assert trutv_ie.name == 'TruTVIE'
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:00.364962
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    UnitTest class for TruTVIE
    """
    # Test regular case
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    vm = TruTVIE()
    assert vm._TEST.get("url", "") == url
    assert vm._TEST.get("params", "") == {'skip_download': True}

# Generated at 2022-06-24 13:25:00.925217
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:02.833459
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj_TruTVIE = TruTVIE()
    assert obj_TruTVIE.extract("") == None;

# Generated at 2022-06-24 13:25:06.939541
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    print(ie)
    TruTVIE.IE_NAME = 'TruTVIE'
    print(ie.ie_key())
    print(ie.ie_key())
    assert ie.ie_key() == 'TruTVIE'
    # assert ie.extract_urls()


# Generated at 2022-06-24 13:25:16.908932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for TruTVIE class
    """
    from ..utils import TestCase
    from .common import common_result

    class TruTVTestCase(TestCase):
        class TruTVInstance(object):
            """
            Create a custom TruTVIE instance to test with
            """
            def __init__(self, results=None):
                self.true_results = results

            def _real_extract(self, url):
                """
                Override TruTVIE._real_extract() to return the results given
                """
                return self.true_results

        def test_IE_extract_all_urls(self):
            """
            Iterate through all of the test cases, initializing the IE and
            calling extract() with the expected results from the test
            """
            for key in common_result:
                ie

# Generated at 2022-06-24 13:25:26.426052
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv:trutv'
    assert ie.IE_DESC == 'truTV'
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Unit test, runs every method except _real_extract()
from unittest import TestCase

from .common import BaseTest


# Generated at 2022-06-24 13:25:36.889201
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:44.838629
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.ie_key() == "TruTV"
    assert obj.ie_name() == "TruTV"
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:45.629696
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:55.081278
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("do unit test for constructor of class TruTVIE")
    print("test url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'")
    print("goal :")

    _VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:58.772757
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.ie_key() == 'trutv'
    assert TruTVIE.ie_key() in TruTVIE.supported_ie()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:26:00.122133
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    object = TruTVIE()

# Generated at 2022-06-24 13:26:09.166567
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tv_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ep_url = 'https://www.trutv.com/shows/the-carbonaro-effect/episodes/82/10-feet-tall-cabinet.html'

    trutv_tv = TruTVIE()
    trutv_tv._VALID_URL = TruTVIE._VALID_URL
    trutv_tv._TEST = TruTVIE._TEST
    info = trutv_tv._real_extract(tv_url)

    assert info['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:26:14.243335
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:15.561281
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .TruTVIE import TruTVIE
    from .TurnerBaseIE import TurnerBaseIE
    assert TruTVIE.__bases__ == (TurnerBaseIE,)

# Generated at 2022-06-24 13:26:16.503733
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  TruTVIE(None)

# Generated at 2022-06-24 13:26:17.767580
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.valid

# Generated at 2022-06-24 13:26:19.295983
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() != None

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:26:20.452979
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'

# Generated at 2022-06-24 13:26:32.002201
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    assert truTV.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')['display_id'] == 'sunlight-activated-flower'
    assert truTV.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')['title'] == 'Sunlight-Activated Flower'
    assert truTV.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-24 13:26:42.251936
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiate TruTVIE class
    trutv_ie = TruTVIE()


# Generated at 2022-06-24 13:26:47.146889
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE().extract('https://www.trutv.com/full-episodes/72347/jugular-wrestling-specials-june-24-2018-season-3-episode-2.html')

# Generated at 2022-06-24 13:26:49.871391
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST


# Generated at 2022-06-24 13:26:51.277900
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()
    assert(truTVIE!=None)

# Generated at 2022-06-24 13:26:51.881909
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:57.518096
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE._TEST['url']
    actual_info = TruTVIE()._real_extract(url)
    expected_info = TruTVIE._TEST['info_dict']
    assert actual_info['id'] == expected_info['id']
    assert actual_info['title'] == expected_info['title']
    assert actual_info['description'] == expected_info['description']

# Generated at 2022-06-24 13:26:59.688435
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # string case
    instance = TruTVIE()
    instance = TruTVIE(instance)

test_TruTVIE()

# Generated at 2022-06-24 13:27:00.680980
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE()

# Generated at 2022-06-24 13:27:05.146135
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TruTVIE._downloader)._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:07.315064
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    test = TruTVIE()

    test._download_json()
    test._extract_ngtv_info()
    test._real_extract()
    test._TEST()

#TODO: add more unit tests

test_TruTVIE()

# Generated at 2022-06-24 13:27:08.302613
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:19.607908
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case without optional argument 'video_id'
    try:
        TruTVIE(TruTVIE._VALID_URL.replace('(?P<id>\d+))', ''))
    except(TypeError):
        print("TypeError is raised as expected")
    # Test case without optional argument 'clip_slug'
    try:
        TruTVIE(TruTVIE._VALID_URL.replace('(?P<clip_slug>[0-9A-Za-z-]+)', ''))
    except(TypeError):
        print("TypeError is raised as expected")
    # Test case with both optional arguments 'video_id' and 'clip_slug' missing

# Generated at 2022-06-24 13:27:26.694516
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable('https://www.trutv.com/index.html')
    assert TruTVIE.suitable('https://www.trutv.com/index')
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/full-episodes/123456')
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/123456')

# Generated at 2022-06-24 13:27:27.245927
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:37.793621
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor of class TruTVIE
    # Case 1: TruTVIE is instantiated and the URL is valid
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutvie = TruTVIE(url)

    assert trutvie._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"
    assert trutvie.url == url

# Generated at 2022-06-24 13:27:47.309927
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__bases__ == (TurnerBaseIE,)
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:55.228854
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTV = TruTVIE()
	assert isinstance(truTV, TruTVIE)
	trutv2 = TruTVIE.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
	#assert trutv2.get("title") == "Sunlight-Activated Flower"
	#assert trutv2.get("description") == "A customer is stunned when he sees Michael\'s sunlight-activated flower."

test_TruTVIE()

# Generated at 2022-06-24 13:27:55.820297
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:06.553332
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from pycaption import DFXPReader
    import requests
    import json
    import os
    import re
    import urllib
    import sys
    from .turner import TurnerBaseIE

    # Set up the correct input and output arguments
    mediaId = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    
    # The parent directory of the mediaId
    folderName = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # The TruTVIE class
    trutvie = TruTVIE()

    # The absolute path to the local file
    path = trutvie._download_ngtv_media(mediaId, folderName)

    # Unit test

# Generated at 2022-06-24 13:28:09.452219
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        assert 0, "Cannot create TruTVIE object: %s" % e


# Generated at 2022-06-24 13:28:09.804380
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:28:12.355682
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_TruTVIE import TruTVIE
    ie = TruTVIE()
    ie.download(ie._VALID_URL)
    assert ie == ie.get_info()

# Generated at 2022-06-24 13:28:23.367066
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
#     url = TruTVIE()._TEST['url']
#     video_data = TruTVIE()._real_extract(url)
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_url2 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/some-other-video.html'
    test_url3 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/10034498'
    test_url4 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/10034498?play=true'

# Generated at 2022-06-24 13:28:31.530669
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	import os
	from .common import make_url_test 
	
	ex_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
	truTVIE = TruTVIE()

	assert "TruTVIE" == truTVIE.ie_key()
	assert ex_url == truTVIE.url
	assert "info" == truTVIE.info
	assert True == truTVIE.suitable(ex_url)
	assert "TruTVIE" == truTVIE.IE_NAME

# Generated at 2022-06-24 13:28:33.249449
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie_info = ie.IE_NAME + " " + ie.IE_DESC
    assert ie_info == "TruTV TruTV"


# Generated at 2022-06-24 13:28:33.974752
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:35.145202
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv is not None


# Generated at 2022-06-24 13:28:36.566618
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE constructor"""
    test_obj = TruTVIE()
    assert test_obj


# Generated at 2022-06-24 13:28:37.777359
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    pass

# Generated at 2022-06-24 13:28:39.298713
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:48.658663
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # Should download the video https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    ie.download('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Should download the video http://www.trutv.com/full-episodes/92385/the-carbonaro-effect-s2-ep1-sandy-clips.html
    ie.download('http://www.trutv.com/full-episodes/92385/the-carbonaro-effect-s2-ep1-sandy-clips.html')
    # Should raise error
    # ie.download('https://www.trutv.com/shows/the-carbonaro-