

# Generated at 2022-06-24 13:18:52.756355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()

    assert trutv_ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:18:55.261345
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """TruTVIE entry point should return an instance of TurnerBaseIE when called"""
    turnerBaseIE = TruTVIE()
    assert isinstance(turnerBaseIE, TurnerBaseIE)

# Generated at 2022-06-24 13:19:00.357564
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_class = TruTVIE('TruTVIE')
    assert test_class._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:01.360922
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:02.357069
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE();
    assert ie;

# Generated at 2022-06-24 13:19:04.766224
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make an object of class TruTVIE
    test_obj = TruTVIE()
    assert not test_obj is None
    assert hasattr(test_obj, '_real_extract')

# Generated at 2022-06-24 13:19:12.932135
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Test TruTVIE.extract with a valid url
    # ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Test TruTVIE.extract with a invalid url
    # ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Test TruTVIE.extract with a invalid url, _VALID_URL is set to _TEST
    # ie.extract('https://www.trutv.com/shows/the-carbonaro-

# Generated at 2022-06-24 13:19:13.542715
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:14.537791
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:19:25.719045
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE.IE_DESC == 'truTV'
    assert TruTVIE.IE_NAME == 'truTV'

# Generated at 2022-06-24 13:19:27.526089
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  """
  Unit test for constructor of class TruTVIE
  """
  ie = TruTVIE()
  ie.extract(_make_url_result())
  assert True


# Generated at 2022-06-24 13:19:29.852272
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Assert that the TruTVIE class is instantiable
    truvt = TruTVIE()
    assert type(truvt) == TruTVIE


# Generated at 2022-06-24 13:19:30.473880
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:35.890576
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .ttv import TruTVIE  # class TruTVIE
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:19:37.350904
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE(None);

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:19:37.858628
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:39.574463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  # Test1: The constructor of class TruTVIE should return an instance
  assert TruTVIE(None) is not None

# Generated at 2022-06-24 13:19:48.652872
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE._TEST['url']
    obj = TruTVIE._TEST
    info_dict = obj['info_dict']
    info_dict['timestamp'] = 1558128000000
    assert TruTVIE._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'
    assert TruTVIE()._real_extract(url) == info_dict

# Generated at 2022-06-24 13:19:51.143883
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        truTVIE = TruTVIE()
        print("Run TruTVIE.test_TruTVIE completed")
    except:
        raise


# Generated at 2022-06-24 13:19:51.587131
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:55.902540
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create instance of class TruTVIE with default arguments
    ie = TruTVIE()

    assert ie.url == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie.display_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert ie.title == 'Sunlight-Activated Flower'
    assert ie.description == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-24 13:19:56.800812
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:07.340559
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:20:07.899604
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:10.417300
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TurnerBaseIE)._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE(TurnerBaseIE).__name__ == 'TruTV'
    assert TruTVIE(TurnerBaseIE)._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:20:16.890668
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:20:18.318628
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE()._call_api("episode/the-carbonaro-effect/29304444")

    assert result == 'TruTVIE._call_api_result'

# Generated at 2022-06-24 13:20:18.920463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:19.510938
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:19.925087
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:22.277418
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL
    assert TruTVIE()._TEST
    assert TruTVIE()._real_extract
    

# Generated at 2022-06-24 13:20:30.560920
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-24 13:20:31.135714
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:20:41.987928
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert re.search(TruTVIE._VALID_URL, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is not None
    assert re.search(TruTVIE._VALID_URL, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower/videos/goodbye-shoes.html') is not None
    assert re.search(TruTVIE._VALID_URL, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.tk') is None

# Generated at 2022-06-24 13:20:44.490748
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    assert TruTVIE._VALID_URL == TruTVIE.__module__
    test_TruTVIE()

# Generated at 2022-06-24 13:20:46.968364
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor of class TruTVIE with valid params
    trutv = TruTVIE({})
    assert trutv is not None

# Generated at 2022-06-24 13:20:54.301289
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    trutv_ie = TruTVIE(TruTVIE._downloader)
    trutv_ie._download_webpage = lambda *args, **kwargs: ''
    trutv_ie._download_json = lambda *args, **kwargs: {'episode': {}, 'info': {}}
    assert trutv_ie._extract_ngtv_info('', {}, {}) == {}

# Generated at 2022-06-24 13:20:57.727891
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_name = 'TruTVIE('
    assert class_name in globals(), 'Class %s not found as global variable' % class_name
    clazz = globals()[class_name]
    instance = clazz()

# Generated at 2022-06-24 13:20:59.376914
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert isinstance(obj, TruTVIE)
    assert TruTVIE._VALID_URL

# Generated at 2022-06-24 13:21:07.783544
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert(trutv.get_media_id("f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1") == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1")
    assert(trutv.get_media_id("abcdefghijklmnopqrstuvwxyz") == "abcdefghijklmnopqrstuvwxyz")

# Generated at 2022-06-24 13:21:10.390310
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Test for TruTVIE """
    test = TruTVIE()
    test_class = test.__class__.__name__
    assert test_class == "TruTVIE"

# Generated at 2022-06-24 13:21:11.254682
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        TruTVIE()



# Generated at 2022-06-24 13:21:16.355826
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()._downloader.ies[0]
    # Test for TruTVIE._VALID_URL
    match = re.match(trutv_ie._VALID_URL, trutv_ie._TEST['url'])
    assert match
    # Test for TruTVIE._extract_ngtv_info
    # Test for TruTVIE._extract_trutv_info
    # Test for TruTVIE._real_extract

# Generated at 2022-06-24 13:21:17.773249
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE_extractor = TruTVIE()
	assert TruTVIE_extractor is not None


# Generated at 2022-06-24 13:21:24.445048
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    if __name__ == '__main__':
        tester = TruTVIE()
        url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
        info = tester.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
        print("Title:", info['title'])
        print("ID:", info['id'])
        print("Description:", info['description'])
        print("URL:", info['url'])
        print("Ext:", info['ext'])
        print("Timestamp:", info['timestamp'])
        print("Season Number:", info['season_number'])
        print("Episode Number:", info['episode_number'])

# Generated at 2022-06-24 13:21:26.431378
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    print(trutv_ie)


# Generated at 2022-06-24 13:21:37.621166
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from json import loads, JSONDecodeError
    from pprint import pprint

    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    print("Fetching TruTVIE(%s)" % url)
    trutv_ie = TruTVIE()
    video_id = "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"

    data = trutv_ie._download_json(
        'https://api.trutv.com/v2/web/%s/%s/%s' % (
            'series/clip', 'the-carbonaro-effect', 'sunlight-activated-flower'), video_id
    )


# Generated at 2022-06-24 13:21:44.599925
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:21:46.864287
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:21:56.480485
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of TruTVIE
    _TruTVIE = TruTVIE()
    # Check if variable _VALID_URL has been defined
    assert _TruTVIE._VALID_URL is not None
    # Check if variable _TEST has been defined
    assert _TruTVIE._TEST is not None
    # Check if method _real_extract() has been defined
    assert _TruTVIE._real_extract is not None
    # Check if method _extract_ngtv_info() has been defined
    assert _TruTVIE._extract_ngtv_info is not None
    # Check if method _extract_ngtv_formats() has been defined
    assert _TruTVIE._extract_ngtv_formats is not None
    # Check if method _extract_smil_formats

# Generated at 2022-06-24 13:21:59.005651
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie_obj = TruTVIE()
    print(ie_obj.ie_key())

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-24 13:22:08.047212
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Define class for test
    class TruTVIETest(TruTVIE):
        # Define static method for test
        @staticmethod
        def _extract_ngtv_info(
                media_id, webpage, ngtv_request_data, ngtv_response):
            # We just return a dummy value here
            return 'Foobar'
    # Create an instance of class TruTVIETest
    ttvie_test = TruTVIETest()
    # Validate if TruTVIETest._real_extract() works
    assert ttvie_test._real_extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:16.376138
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make sure TruTVIE object was properly constructed
    object = TruTVIE()
    assert object.IE_NAME == 'trutv:trutv'
    assert object._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Unit tests for _real_extract() of class TruTVIE
# NOTE: These tests use the TruTVIE object created in test_TruTVIE()

# Generated at 2022-06-24 13:22:19.949686
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()
    assert i._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:22:21.066157
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 13:22:22.086988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    assert truTV is not None

# Generated at 2022-06-24 13:22:24.138007
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE_class = TruTVIE()
    assert TruTVIE_class

# Generated at 2022-06-24 13:22:28.650591
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:22:29.567446
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:22:40.483911
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-24 13:22:47.575493
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:50.656534
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST['info_dict']['title'] == TruTVIE._VALID_URL
    TruTVIE(TruTVIE._TEST['url'])._real_extract(TruTVIE._TEST['url'])

# Generated at 2022-06-24 13:22:54.689383
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE_instance = TruTVIE()
    TruTVIE_instance.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE_instance.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:55.689155
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_instance = TruTVIE()

# Generated at 2022-06-24 13:23:03.806497
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.ie_key() == 'TruTV'
    assert TruTVIE.ie_key() == 'trutv'
    assert TruTVIE.ie_key() == 'trutv.com'
    assert TruTVIE.ie_key() == 'truTV'
    assert TruTVIE.ie_key() == 'truTV.com'
    assert TruTVIE.ie_key() == 'truTV.com:truTV'
    assert TruTVIE.ie_key() == 'truTV.com:truTV'
    assert TruTVIE.ie_key() == 'trutv.com:trutv'
    assert TruTVIE.ie_key() == 'trutv.com:truTV'

# Generated at 2022-06-24 13:23:04.344965
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:07.460267
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    test_TruTVIE._extract_ngtv_info('mediaId', {}, {'url':'url', 'site_name':'sitename'} )
    test_TruTVIE._extract_ngtv_info('mediaId', {}, {} )

# Generated at 2022-06-24 13:23:09.324232
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert ie.IE_DESC == 'truTV.com'   


# Generated at 2022-06-24 13:23:11.058716
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.test()

# Generated at 2022-06-24 13:23:18.127602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.ie_key() == 'trutv'
    assert TruTVIE.ie_key() != 'turner'
    assert TruTVIE.ie_key() != 'cnn'
    assert TruTVIE.ie_key() != 'tbs'
    assert TruTVIE.ie_key() != 'tnt'
    assert TruTVIE.ie_key() != 'adultswim'
    assert TruTVIE.ie_key() != 'cartoonnetwork'
    assert TruTVIE.ie_key() != 'boomerang'

# Generated at 2022-06-24 13:23:18.742457
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:28.074133
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
# Check TruTVIE constructor
    TruTVIE("TruTVIE")
# Check TruTVIE constructor
    assert TruTVIE("TruTVIE")
# Check TruTVIE constructor
    TruTVIE("TruTVIE")._VALID_URL
# Check TruTVIE constructor
    assert TruTVIE("TruTVIE")._VALID_URL
# Check TruTVIE constructor
    TruTVIE("TruTVIE")._TEST
# Check TruTVIE constructor
    assert TruTVIE("TruTVIE")._TEST
# Check TruTVIE constructor
    TruTVIE("TruTVIE")._download_json
# Check TruTVIE constructor
    assert TruTVIE("TruTVIE")._download_json
# Check TruTVIE constructor
    TruTVIE("TruTVIE")._real_extract
# Check TruTV

# Generated at 2022-06-24 13:23:30.022681
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    trutv._VALID_URL = TruTVIE._VALID_URL
    trutv._TEST = TruTVIE._TEST

# Generated at 2022-06-24 13:23:39.976367
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # GOOD
    TruTVIE_1 = TruTVIE()
    assert TruTVIE_1._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    TruTVIE_2 = TruTVIE()

# Generated at 2022-06-24 13:23:40.516967
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-24 13:23:49.544441
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Unit test for constructor of class TruTVIE """

    # Create instance of class TruTVIE
    trutv_ie = TruTVIE()

    # Verify the initialized value of class variables
    # For instance of TruTVIE, the regular expression for valid URL
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Verify the regular expression for the URL with sample clip

# Generated at 2022-06-24 13:23:50.112838
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:23:50.789218
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-24 13:23:53.168602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE instance creation
    trutv = TruTVIE()
    assert trutv is not None

# Tests for the method _real_extract of class TruTVIE

# Generated at 2022-06-24 13:24:03.275925
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:03.824009
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    True

# Generated at 2022-06-24 13:24:04.499898
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:13.103662
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.ie_key() == 'trutv'
    assert ie.ie_name() == 'TruTV'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:13.499158
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-24 13:24:14.013121
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:17.215537
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Turn on test flag for testing
    TruTVIE._TEST = True
    # Test for class methods
    assert TruTVIE._real_extract(
        TruTVIE(), "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:24:23.705933
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._VALID_URL = TruTVIE._VALID_URL
    ie._TEST = TruTVIE._TEST
    ie._download_json = TruTVIE._download_json
    ie._extract_ngtv_info = TruTVIE._extract_ngtv_info
    ie._real_extract = TruTVIE._real_extract
    ie.__call__ = TruTVIE.__call__

# Generated at 2022-06-24 13:24:24.728042
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  assert TruTVIE == TruTVIE



# Generated at 2022-06-24 13:24:27.747587
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for constructor of class TruTVIE
    url = "http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    ie = TruTVIE()
    assert ie._TEST == ie.extract(url)

# Generated at 2022-06-24 13:24:28.318113
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:28.851349
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:29.619988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:31.601832
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Passing a test case
    TruTVIE()
    # Passing another test case
    TruTVIE()

# Generated at 2022-06-24 13:24:33.256304
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVExtractor', 'TruTVExtractor').test()

# Generated at 2022-06-24 13:24:40.385334
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .common import TestCommon
    result = TruTVIE()._real_extract(
        TruTVIE()._VALID_URL.replace("truTV", "truTV.com"))
    TestCommon.simple_assert(
        result,
        'id',
        'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    TestCommon.simple_assert(
        result,
        'title',
        'Sunlight-Activated Flower')

# Generated at 2022-06-24 13:24:49.761641
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:50.595097
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t is not None

# Generated at 2022-06-24 13:24:58.466209
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test constructor of class TruTVIE"""
    # First test invalid URLs

    # Test a malformed URL
    aMalformedURL = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower'
    try:
        trutvIE = TruTVIE(url=aMalformedURL)
    except AssertionError:
        print("Good news! It correctly throws an exception with a malformed URL")
    else:
        print("ERROR: It should raise an exception with a malformed URL")

    # Test URLS with invalid show IDs
    anInvalidShowIdURL = 'https://www.trutv.com/full-episodes/123456789/videos/more-weird-news.html'

# Generated at 2022-06-24 13:24:59.001661
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:59.529496
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:00.407203
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    c = TruTVIE()
    c.suite()

# Generated at 2022-06-24 13:25:09.440384
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    # Unit test for function _real_extract
    f = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    f_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    ttv._download_webpage = lambda *args, **kwargs: '{}'
    ttv._extract_ngtv_info = lambda *args, **kwargs: {'id': f_id, 'ext': 'mp4'}
    assert f_id == ttv._real_extract(f)['id']

    # Unit test for function _real_extract if video_id is given

# Generated at 2022-06-24 13:25:19.067706
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:25:20.633598
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:25:21.652288
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:26.238547
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test invalid URL
    invalid_url = "invalid url"
    assert TruTVIE._VALID_URL.match(invalid_url) == None

    # test valid URL
    valid_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    valid_url_match = TruTVIE._VALID_URL.match(valid_url)
    assert valid_url_match.group('series_slug') == 'the-carbonaro-effect'
    assert valid_url_match.group('clip_slug') == 'sunlight-activated-flower'
    assert valid_url_match.group('id') == None

    # test valid URL
    valid_url = "https://www.trutv.com/full-episodes/16070"

# Generated at 2022-06-24 13:25:29.831499
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    filename = './test/test_sites/trutv.py'
    exec(compile(open(filename, "rb").read(), filename, 'exec'), locals(), globals())


# Generated at 2022-06-24 13:25:30.800439
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor
    TruTVIE() # No exception

# Generated at 2022-06-24 13:25:31.363583
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:32.043520
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:35.189128
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Should not raise exception
    # url is https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    truTVIE = TruTVIE()

# Generated at 2022-06-24 13:25:36.113028
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-24 13:25:36.650779
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:37.848251
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE(None)
    assert ie


# Generated at 2022-06-24 13:25:39.178471
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTV.assertTrue(truTV())

# Generated at 2022-06-24 13:25:40.155312
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t is not None


# Generated at 2022-06-24 13:25:41.066671
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

test_TruTVIE()

# Generated at 2022-06-24 13:25:42.667316
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	try:
		TruTVIE
		print("Class TruTVIE exists")
	except:
		print("Error: Class TruTVIE doesn't exist")


# Generated at 2022-06-24 13:25:48.213920
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    for constructor in (TruTVIE, ):
        ie = constructor('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
        ie = constructor('http://www.trutv.com/full-episodes/1272/the-carbonaro-effect-season-3-episode-1-ho.html')

# Generated at 2022-06-24 13:25:52.963804
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # True if the IE's name was registered
    assert ie.suitable('trutv.com')
    # True if the IE can handle the URL
    assert ie.suitable(TruTVIE._VALID_URL)
    # True if the IE has working extraction capabilities
    assert ie.extract(TruTVIE._VALID_URL)

# Generated at 2022-06-24 13:25:57.313535
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This is a test for the constructor of class TruTVIE.
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    assert ie.suitable(url), 'Not a valid URL'

# Generated at 2022-06-24 13:26:00.873124
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE is not None
    return

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:26:01.887390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-24 13:26:02.481286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:26:03.275952
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass  # TruTVIE()

# Generated at 2022-06-24 13:26:04.226392
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE class
    TruTVIE()

# Generated at 2022-06-24 13:26:04.878463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:10.024309
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    match = re.match(TruTVIE._VALID_URL, url)
    assert match.groups() == ('the-carbonaro-effect', 'sunlight-activated-flower', None)

# Generated at 2022-06-24 13:26:11.481492
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    c = TruTVIE()
    # Assert
    assert c

# Generated at 2022-06-24 13:26:18.217812
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    trutv._download_webpage('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'Downloading webpage')
    
test_TruTVIE()

# Generated at 2022-06-24 13:26:19.493502
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:26:20.561160
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    assert TruTVIE != None


# Generated at 2022-06-24 13:26:22.315017
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    print(trutv)

# Generated at 2022-06-24 13:26:23.359851
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:24.828665
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    win = TruTVIE()

# Generated at 2022-06-24 13:26:29.555598
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        # Test the class TruTVIE initialization
        test_TruTVIE = TruTVIE()
        test_TruTVIE.extract()
        print("Success: test_TruTVIE class initialized")
    except:
        print("Error: test_TruTVIE initialization")


# Generated at 2022-06-24 13:26:30.102282
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("a", "b", "c")

# Generated at 2022-06-24 13:26:35.678164
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    assert str(type(test)) == "<class 'youtube_dl.extractor.trutv.TruTVIE'>"

if __name__ == '__main__':
    test_object = TruTVIE()
    test_object.download("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:26:37.577904
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert(ttv.ie_key() == "turner_video")
    assert(ttv.ie_name() == "truTV")
    assert(ttv.ie_desc() == "Turner Broadcasting System, Inc.")

# Generated at 2022-06-24 13:26:42.382389
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import gen_extractors
    ydl = YoutubeDL(gen_extractors())
    assert TruTVIE.suitable(ydl.url_result('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))

# Generated at 2022-06-24 13:26:49.795051
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test for constructor of class TruTVIE
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:26:51.927888
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    print(trutv)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:26:56.687335
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("http://www.trutv.com/shows/the-carbonaro-effect/episodes/index.html#episode=766903&season=3")
    TruTVIE("https://www.trutv.com/shows/southwest-florida-crime/videos/a-woman-defends-her-property.html")


# Generated at 2022-06-24 13:26:59.550736
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE if TruTVIE.__doc__ is not None else TruTVIE

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:27:07.800898
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import json
    url_TruTv = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    tuple_TruTv = ('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    valid_url_TruTv = TruTVIE._VALID_URL
    temp = re.match(valid_url_TruTv, url_TruTv)
    series_slug_TruTv = temp.group('series_slug')
    id_TruTv = temp.group('id')
    clip_slug

# Generated at 2022-06-24 13:27:09.069078
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.test()

# Generated at 2022-06-24 13:27:12.698229
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor of class TruTVIE without fail
    try:
        TruTVIE()
    except:
        assert False
    # Unit test for constructor of class TruTVIE with fail
    try:
        TruTVIE()
        assert False
    except:
        assert True

# Generated at 2022-06-24 13:27:14.676383
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru = TruTVIE()
    assert tru



# Generated at 2022-06-24 13:27:16.347566
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_tv = TruTVIE()
    assert tru_tv is not None

# Generated at 2022-06-24 13:27:18.103974
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('TruTVIE', 'TruTV')

# Generated at 2022-06-24 13:27:18.573624
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:27.605922
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:38.170856
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE Constructor ")
    obj_TruTVIE = TruTVIE()
    print(obj_TruTVIE)
    print("Testing for _VALID_URL ")
    if obj_TruTVIE._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))':
        print("Test Passed")
    else:
        print("Test Failed")
    print("Testing for _TEST ")

# Generated at 2022-06-24 13:27:45.033823
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    ttv.url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    vid_in = ttv.url
    vid_out = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert ttv._TEST['url'] == vid_in
    assert True == ttv._TEST['info_dict']['id'] == vid_out

# Generated at 2022-06-24 13:27:48.072988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE('TruTV')
        TruTVIE('TruTVIE')
        TruTVIE('TruTVIE.TruTVIE')
    except:
        print("Exception in TruTVIE")
        assert False, "Failed to initialize TruTVIE"

# Generated at 2022-06-24 13:27:50.497942
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor
    x = TruTVIE()
    assert(x.constructor == 'TruTVIE')

# Generated at 2022-06-24 13:27:53.433542
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_webpage('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:27:54.509173
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None

# Generated at 2022-06-24 13:27:56.895606
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:28:07.904580
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE.__doc__ is not None
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:13.605846
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test case 1
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()._real_extract(url)

    # test case 2
    url = 'https://www.trutv.com/full-episodes/5282716/the-carbonaro-effect-sneak-attack.html'
    TruTVIE()._real_extract(url)

# Generated at 2022-06-24 13:28:24.288815
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test for constructor of class TruTVIE
    tt_ie = TruTVIE()
    assert tt_ie is not None
    assert tt_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:25.169219
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:28:27.419802
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None

# Generated at 2022-06-24 13:28:34.748552
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE constructor
    # TruTVIE object creation for input url
    trutv_object = TruTVIE()

    # Test for assertEqual
    assert trutv_object._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:28:35.267082
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:37.537305
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Create a TruTVIE instance and check parameters
	# (initialization of _TEST)
	assert TruTVIE._TEST['info_dict']['title'] ==  'Sunlight-Activated Flower'

# Generated at 2022-06-24 13:28:39.814924
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.__class__.__name__ == 'TruTVIE'

# Generated at 2022-06-24 13:28:48.963168
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing the constructor of TruTVIE.
    # Please note that it's not possible to test the class TruTVIE directly from this test function.
    # These tests just check that the constructor of class TruTVIE is doing what's expected.
    # The behavior of the other class methods is tested in different test functions.
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutv = TruTVIE(url)
    assert isinstance(trutv, TruTVIE)