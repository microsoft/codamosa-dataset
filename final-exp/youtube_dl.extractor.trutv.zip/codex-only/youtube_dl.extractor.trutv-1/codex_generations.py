

# Generated at 2022-06-24 13:18:43.175080
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:49.092811
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("Sunlight-Activated Flower", "A customer is stunned when he sees Michael's sunlight-activated flower.","https://api.trutv.com/v2/web/%s/%s/%s", "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1")

# Generated at 2022-06-24 13:18:57.768348
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make object TruTVIE
    trutv = TruTVIE()
    # Test method _extract_ngtv_info
    assert True == trutv._extract_ngtv_info(
        'media_id', {}, {
            'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
            'site_name': 'truTV',
            'auth_required': True,
        })
    # Test method _real_extract
    assert True == trutv._real_extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:18:58.674117
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # assertion: the class TruTVIE has been successfully constructed
    assert (TruTVIE(TurnerBaseIE()))

# Generated at 2022-06-24 13:18:59.835731
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:01.169690
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-24 13:19:01.787157
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:02.409709
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:03.002705
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-24 13:19:03.910488
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()


# Generated at 2022-06-24 13:19:07.206229
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()._download_webpage(url, None)
    return

# Generated at 2022-06-24 13:19:08.066972
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  obj = TruTVIE()
  assert obj.__class__.__name__ == 'TruTVIE'

# Generated at 2022-06-24 13:19:14.699930
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE class constructor

    Some of the tests are commented out because it requires a valid access token and a valid video ID.
    """

# Generated at 2022-06-24 13:19:15.398250
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:20.324059
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST
    assert TruTVIE()._real_extract == TruTVIE._real_extract

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:19:30.318990
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    # only check the key and value
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:31.556735
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE class.
    """
    pass

# Generated at 2022-06-24 13:19:32.138580
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-24 13:19:37.694681
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
    }

# Generated at 2022-06-24 13:19:38.938093
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TestIE = TruTVIE()
    TestIE.test()

# Generated at 2022-06-24 13:19:39.576586
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:43.463074
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.ie_key() == 'trutv'
    assert trutv_ie.ie_name() == 'TruTV'
    assert trutv_ie.ie_alias() is None

# Generated at 2022-06-24 13:19:53.305552
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .common import InfoExtractor
    from .common import unescapeHTML
    from ..utils import parse_duration
    #
    ie = InfoExtractor(TruTVIE.ie_key())

    clip = (ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/a-hologram-cell-phone.html'))
    assert clip['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert clip['ext'] == 'mp4'
    assert clip['title'] == 'A Hologram Cell Phone'
    assert clip['description'] == unescapeHTML(
        "A customer gets the shock of her life when Michael turns a cell phone into a hologram.")

# Generated at 2022-06-24 13:19:54.868646
# Unit test for constructor of class TruTVIE
def test_TruTVIE():  # noqa: F811
  trutv_ie = TruTVIE()
  print(trutv_ie)

# Generated at 2022-06-24 13:20:02.777206
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Given
    test_options = {
        'username': 'testuser',
        'password': 'testpassword',
        'video_password': 'testvideopassword',
    }

    trutvIE = TruTVIE(test_options)
    assert(trutvIE.username == 'testuser')
    assert(trutvIE.password == 'testpassword')
    assert(trutvIE.video_password == 'testvideopassword')

# Generated at 2022-06-24 13:20:04.188866
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'

# Generated at 2022-06-24 13:20:08.696203
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TRU_TV_URL = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url = TruTVIE._VALID_URL
    match = re.match(url, TRU_TV_URL)
    assert match is not None, 'match is None for {0}'.format(TRU_TV_URL)
    assert match.groups() is not None, 'No matching groups for {0}'.format(TRU_TV_URL)
    series_slug, clip_slug, video_id = match.groups()
    assert series_slug is not None, 'series_slug is None'
    assert clip_slug is not None, 'clip_slug is None'
    assert video_id is None, 'video_id is not None'



# Generated at 2022-06-24 13:20:10.146952
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  try:
    TruTVIE()
  except Exception as e:
    print("Error inside test_TruTVIE: %s" % e)

# Generated at 2022-06-24 13:20:13.973838
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # If no TrueTV show was found, then TrueTVIE(None) should raise an exception
    # This test ensures that __init__ does raise an exception when no TrueTV show was found
    try:
        TruTVIE(None)
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-24 13:20:20.756358
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    # Test the case where the URL contains the video ID
    trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/979321')
    # Test the case where the URL contains the clip slug
    trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:20:24.994547
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.NAME == 'truTV'
    assert t.SITE_NAME == 'truTV'
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:20:26.047622
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert hasattr(TruTVIE, '_real_extract')


# Generated at 2022-06-24 13:20:26.601525
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:27.446363
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    o = TruTVIE()
    assert o is not None

# Generated at 2022-06-24 13:20:28.258281
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-24 13:20:28.771193
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:30.599254
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE."""
    # TruTVIE is an abstract class, those tests are executed in derived classes
    pass

# Generated at 2022-06-24 13:20:32.472145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert isinstance(a, TruTVIE)


# Generated at 2022-06-24 13:20:33.479761
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:20:43.313505
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('test TruTVIE')
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    trutv_ie.suitable(test_url)
    trutv_ie.extract(test_url)
    test_url = 'https://www.trutv.com/full-episodes/1121'
    trutv_ie.suitable(test_url)
    trutv_ie.extract(test_url)
    print('passed')

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:20:45.650797
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._VALID_URL
    ie._download_json()
    ie._download_webpage()

# Generated at 2022-06-24 13:20:46.461678
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:20:49.522398
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == "trutv.com"
    assert ie.IE_DESC == "TruTV.com"



# Generated at 2022-06-24 13:20:59.964720
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:09.210493
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:21:15.254394
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:21.067065
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from pprint import pprint
    from . import TruTVIE

    TruTVIE_instance = TruTVIE(None)
    # Testing for the type of the object created
    assert(isinstance(TruTVIE_instance, TruTVIE))
    # Testing TruTVIE method

# Generated at 2022-06-24 13:21:30.694704
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    assert test._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:34.321703
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor without arguments
    TruTVIE()

    # Test constructor with arguments
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:21:37.305392
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TODO: Needs some more dynamic testing
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:21:38.940431
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor_test_helper(TruTVIE, TruTVIE._TEST)

# Generated at 2022-06-24 13:21:46.365786
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_cases = [
        "TrueTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')",
        "TrueTVIE('https://www.trutv.com/full-episodes/473643/videos/sunlight-activated-flower.html')",
        "TrueTVIE('https://www.trutv.com/full-episodes/473643.html')",
    ]
    for test_case in test_cases:
        exec(test_case)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:21:56.055084
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SUITABLE(URL_VALID_TEST_TRUTVIE["url"])
    assert not ie.SUITABLE(URL_INVALID_TEST_TRUTVIE["url"])
    assert ie._VALID_URL == URL_VALID_TEST_TRUTVIE["validdomain"]
    return True


# Generated at 2022-06-24 13:21:56.586486
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:57.983881
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    TruTVIE()
    TruTVIE()

# Generated at 2022-06-24 13:22:04.402385
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert re.search(TruTVIE._VALID_URL, 'https://www.trutv.com/full-episodes/221830105').groups() == (
        'the-last-ship', '', '221830105')
    assert re.search(TruTVIE._VALID_URL, 'https://www.trutv.com/shows/the-last-ship/videos/crossing-the-line.html').groups() == (
        'the-last-ship', 'crossing-the-line', '')

# Generated at 2022-06-24 13:22:10.563155
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')['id'] is not None
    assert trutv.extract('https://www.trutv.com/full-episodes/53934/Impractical-Jokers-S06E08-Blast-From-The-Past.html')['id'] is not None

# Generated at 2022-06-24 13:22:11.179422
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.test()

# Generated at 2022-06-24 13:22:12.303130
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE(None)
    assert m is not None

# Unit tests for TruTVIE

# Generated at 2022-06-24 13:22:13.826565
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:22:16.618212
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    TruTVIE(None)._real_extract(url)

# Generated at 2022-06-24 13:22:18.451345
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.new_ie_code == 'trutv'
    assert ie.ie_key == 'TruTV'
    assert ie.name == 'truTV'

# Generated at 2022-06-24 13:22:19.428410
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv is not None

# Generated at 2022-06-24 13:22:24.662284
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:25.743731
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global TruTVIE
    t = TruTVIE()
    assert(t != None)

# Generated at 2022-06-24 13:22:36.097457
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:45.273018
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test case 1
    video_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_case_type = "Series"
    test_case = TruTVIE(test_case_type, video_url)
    assert test_case._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:46.790567
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:22:47.304552
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:48.556752
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    TruTVIE()

# Generated at 2022-06-24 13:22:50.152839
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert(ttv)

# Unit test with good url

# Generated at 2022-06-24 13:22:50.867315
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE != None

# Generated at 2022-06-24 13:22:51.275833
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:56.524381
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	"""
	Unit test for constructor of class TruTVIE
	"""
	assert TruTVIE.__name__ == 'TruTVIE'
	assert TruTVIE._VALID_URL ==  r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:57.370640
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test = TruTVIE()
	test.test()

# Generated at 2022-06-24 13:22:58.036111
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:59.444461
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE = TruTVIE(None)


# Generated at 2022-06-24 13:23:01.657812
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE constructor")
    obj = TruTVIE()
    print("TruTVIE object created.")
    assert obj is not None


# Generated at 2022-06-24 13:23:02.821825
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_ie = TruTVIE()
    assert "TruTVIE"

# Generated at 2022-06-24 13:23:03.342701
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:07.466926
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._downloader.params['forceurl'] is True
    assert TruTVIE()._downloader.params['forcetitle'] is True
    assert TruTVIE()._downloader.params['forcejson'] is True
    assert TruTVIE()._downloader.params['simulate'] is True
    assert TruTVIE()._downloader.params['noplaylist'] is True

# Generated at 2022-06-24 13:23:07.956070
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:09.061758
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'

# Generated at 2022-06-24 13:23:15.105181
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Unit tests for TruTVIE
    '''
    TruTVIE_test = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    match_result = TruTVIE_test._VALID_URL.match(url)
    TruTVIE_test._real_extract(url)

# Generated at 2022-06-24 13:23:22.690019
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    import youtube_dl
    from youtube_dl.extractor.trutv import TruTVIE

    class TestTruTVIE(unittest.TestCase):
        def test_constructor(self):
            """ Check that TruTVIE constructor works as expected """
            url = 'https://trutv.com/shows/the-jokers-wild/videos/dice-roll.html'
            # Test TruTVIE constructor
            trutv = TruTVIE(youtube_dl.YoutubeDL())
            self.assertIsInstance(trutv, TruTVIE)
            # Test TruTVIE._VALID_URL (TruTVIE.VALID_URL)
            self.assertTrue(trutv._VALID_URL(url))
       
    unittest.main()

test_TruTVIE

# Generated at 2022-06-24 13:23:28.441678
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    loader = TruTVIE()
    # test valid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert loader.suitable(url)
    # test invalid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/vidoes/sunlight-activated-flower.html'
    assert not loader.suitable(url)

# Generated at 2022-06-24 13:23:37.718117
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    series_slug = 'the-carbonaro-effect'
    clip_slug = 'sunlight-activated-flower'
    url_match = re.match(TruTVIE._VALID_URL, url)
    assert url_match
    assert url_match.groupdict()['series_slug'] == series_slug
    assert url_match.groupdict()['clip_slug'] == clip_slug

    video_id = '206623'
    url = 'https://www.trutv.com/shows/impractical-jokers/videos/' + video_id + '.html'

# Generated at 2022-06-24 13:23:38.766887
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-24 13:23:39.142907
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:41.037602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check construction
    trutvIE = TruTVIE()
    assert(trutvIE != None)
# End test for constructor of class TruTVIE

# Generated at 2022-06-24 13:23:41.909775
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  dl = TruTVIE()

# Generated at 2022-06-24 13:23:47.077332
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for valid URL
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    match = re.match(trutv._VALID_URL, test_url)
    if match is None:
        raise AssertionError('Valid URL did not match.')


# Generated at 2022-06-24 13:23:53.598533
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_input = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    expected_series_slug = "the-carbonaro-effect"
    expected_clip_slug = "sunlight-activated-flower"
    expected_video_id = None
    output = re.match(TruTVIE._VALID_URL, test_input).groups()
    series_slug, clip_slug, video_id = output

    assert expected_series_slug == series_slug
    assert expected_clip_slug == clip_slug
    assert expected_video_id == video_id


# Generated at 2022-06-24 13:24:00.049554
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_obj = TruTVIE()
    result = test_obj._real_extract(url)
    assert result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert result['display_id'] == 'sunlight-activated-flower'

# Generated at 2022-06-24 13:24:00.636515
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:02.093713
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj
    pass



# Generated at 2022-06-24 13:24:06.978690
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:15.750406
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''Test constructor of class TruTVIE'''
    # Parameter 'url'
    TurnerBaseIE()._real_extract(TruTVIE._TEST['url'])

    # Parameter 'url'
    TruTVIE()._real_extract(TruTVIE._TEST['url'])

    url = TruTVIE._TEST['url']
    match = re.match(TruTVIE._VALID_URL, url)
    series_slug = match.group('series_slug')
    clip_slug = match.group('clip_slug')
    video_id = match.group('id')

    # Parameter 'url'
    TruTVIE()._real_extract(TruTVIE._TEST['url'])


# Generated at 2022-06-24 13:24:16.765322
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:27.468831
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# input
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	
	# expected output
	expected_series_slug = 'the-carbonaro-effect'
	expected_clip_slug = 'sunlight-activated-flower'
	expected_video_id = None
	
	# actual output
	actual_series_slug, actual_clip_slug, actual_video_id = re.match(TurnerBaseIE._VALID_URL, url).groups()

	# check if actual output matches with expected output
	assert actual_series_slug == expected_series_slug
	assert actual_clip_slug == expected_clip_slug
	assert actual_video_id == expected_video_id



# Generated at 2022-06-24 13:24:29.268070
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST['url'] == TruTVIE(TruTVIE._TEST)._TEST['url']

# Generated at 2022-06-24 13:24:30.406872
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:37.422179
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TODO: Blackbox test, not unit test
    from .test_utils import FakeYDL
    fake_ydl = FakeYDL()
    TruTVIE().extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', fake_ydl)
    assert fake_ydl.result == ['f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1']

# Generated at 2022-06-24 13:24:45.541709
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    valid_cases = [
        "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html",
        "https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html",
        "https://www.trutv.com/shows/the-carbonaro-effect/98880-laser-etching.html",
        "https://www.trutv.com/full-episodes/the-carbonaro-effect/98880-laser-etching.html"
    ]
    for url in valid_cases:
        assert TruTVIE._VALID_URL == TruTVIE._match_id(url)
        ie = TruTVIE(url)

# Generated at 2022-06-24 13:24:50.053418
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    study = TruTVIE()
    assert study.suitable(url) is True
    assert study.IE_NAME == 'trutv:video'
    assert 'Sunlight-Activated Flower' == study.extract(url).get('title')

# Generated at 2022-06-24 13:24:57.102917
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .generic import InfoExtractor
    import re
    '''
    Tests if TruTVIE is loaded correctly
    '''
    ie = InfoExtractor.for_site('trutv')
    assert ie.__class__.__name__ == TruTVIE.__name__
    assert ie._VALID_URL == TruTVIE._VALID_URL
    assert ie._TEST == TruTVIE._TEST
    assert ie._TEST.get('url') == TruTVIE._TEST.get('url')
    assert ie._TEST.get('info_dict').get('id') == TruTVIE._TEST.get(
        'info_dict').get('id')
    assert re.match(ie._VALID_URL, TruTVIE._TEST.get('url'))
    assert ie._download_json == TruTVIE

# Generated at 2022-06-24 13:24:57.654318
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:06.249528
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._WEBSITE == 'truTV'
    assert TruTVIE._TURNER_ENVIRONMENT == 'PROD'
    assert TruTVIE._mso_codes == (('Comcast', 'COM'),)
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._is_logged_in is None

# Generated at 2022-06-24 13:25:07.808617
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    grunt = True
    assert grunt

# Generated at 2022-06-24 13:25:12.482707
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # Test channel.
    channel = ie._channel
    assert channel.id == 'truTV'
    assert channel.name == 'truTV'
    # Test API endpoint.
    assert ie._api_endpoint == 'https://api.trutv.com/v2/web/'
    # Test API key.
    assert ie._api_key == 'truTV'

# Generated at 2022-06-24 13:25:14.301381
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of TruTVIE
    TruTVIE()

# Generated at 2022-06-24 13:25:17.710251
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test example from TruTVIE._TEST
    TruTVIE()._download_webpage(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', '1')

# Generated at 2022-06-24 13:25:20.919599
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Testing video')
    video1 = TruTVIE(TurnerBaseIE._VALID_URL)
    print('Done')


test_TruTVIE()

# Generated at 2022-06-24 13:25:29.588572
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for the TruTVIE class
    """
    test_url = 'https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_TruTVIE = TruTVIE()
    test_params = {
        # m3u8 download
        'skip_download': True
    }
    test_info_dict = {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower."
    }

# Generated at 2022-06-24 13:25:33.877289
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert TruTVIE._VALID_URL == trutv._VALID_URL
    assert TruTVIE._TEST == trutv._TEST
    # Actual test is performed in the parent class,
    # since this is an extraction from the same API


# Generated at 2022-06-24 13:25:34.880214
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:25:36.805505
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:25:39.137539
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from inspect import isabstract
    assert isabstract(TurnerBaseIE)
    assert not isabstract(TruTVIE)

# Generated at 2022-06-24 13:25:41.026693
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV_IE_instance = TruTVIE()

# Generated at 2022-06-24 13:25:42.728889
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:25:43.508323
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:45.890649
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTVIE = TruTVIE(TurnerBaseIE._create_get_url)
	assert truTVIE != None


# Generated at 2022-06-24 13:25:47.980251
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # The TruTVIE class is an abstract base class,
    # so we cannot instantiate it directly.
    pass

# Generated at 2022-06-24 13:25:51.645751
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__doc__ != None
    assert TruTVIE._VALID_URL.__doc__ != None
    assert TruTVIE._TEST.__doc__ != None
    assert TruTVIE._real_extract.__doc__ != None

# Generated at 2022-06-24 13:25:53.933690
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:25:55.343169
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t == None


# Generated at 2022-06-24 13:26:05.969978
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:10.194354
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE
    b = a._TEST
    c = b['info_dict']
    d = c['id']
    e = c['ext']
    f = c['title']
    g = c['description']

# Check if class TruTVIE is using the name of class TurnerBaseIE as parent

# Generated at 2022-06-24 13:26:13.488740
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE("www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert isinstance(ie, TruTVIE)


# Generated at 2022-06-24 13:26:17.609401
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE({})._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-24 13:26:22.386301
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test constructor of class TruTVIE with a valid URL to video and
    # without a episode ID
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # Test constructor of class TruTVIE with a valid URL to video and
    # with a episode ID
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/1548636')

# Generated at 2022-06-24 13:26:24.558321
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        
    obj = TruTVIE()
    assert isinstance(obj, TruTVIE) == True

# Generated at 2022-06-24 13:26:30.634794
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'



# Generated at 2022-06-24 13:26:31.592781
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t != None

# Generated at 2022-06-24 13:26:41.813239
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """

    Test constructor of class TruTVIE

    """
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:26:42.223267
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:44.080168
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #create object
    temp_object = TruTVIE()
    #check if object created
    assert temp_object != None



# Generated at 2022-06-24 13:26:51.062676
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    video = TruTVIE(url)
    assert video._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:52.150675
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-24 13:26:53.113616
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()(TruTVIE._TEST)

# Generated at 2022-06-24 13:26:54.210261
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        instance = TruTVIE()
    except:
        return False
    return True

# Generated at 2022-06-24 13:26:55.069484
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ie = TruTVIE()

# Generated at 2022-06-24 13:26:56.526664
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    inst = TruTVIE()
    assert inst.name == 'TruTV'

# Generated at 2022-06-24 13:26:57.914890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:06.726483
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test with nonexistent url
    nonexistent_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    try:
        trutv_ie = TruTVIE(nonexistent_url)
        assert False
    except AssertionError:
        assert True

    # Test with a valid url
    valid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE(valid_url)

# Generated at 2022-06-24 13:27:18.470286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of TruTVIE
    trutv_ie = TruTVIE()
    assert isinstance(trutv_ie, TruTVIE)

    # Call the extract method
    trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # Call the extract method again
    trutv_ie.extract('https://www.trutv.com/full-episodes/126637/the-carbonaro-effect-full-episodes-the-truth-about-puppies-and-rainbows.html')

    # Call the extract method with a wrong url

# Generated at 2022-06-24 13:27:27.475134
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.url_result('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
                         'TruTV') == {'_type': 'url',
                                      'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
                                      'ie_key': 'TruTV',
                                      'display_id': 'sunlight-activated-flower',
                                      'series_slug': 'the-carbonaro-effect'}
    # Test for TruTVIE constructor for www.trutv.com/episodes/ID URLs

# Generated at 2022-06-24 13:27:29.260953
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable(TruTVIE._TEST['url']) == TruTVIE

# Generated at 2022-06-24 13:27:30.306522
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()


# Generated at 2022-06-24 13:27:32.882845
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Test TruTVIE constructor """
    turner = TruTVIE()
    assert turner.IE_NAME == "TruTV"

# Generated at 2022-06-24 13:27:37.980558
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("")._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:39.719444
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Check that variable 'data' is not None
	assert TruTVIE._TEST is not None


# Generated at 2022-06-24 13:27:47.039569
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    ie._real_extract(url)
    assert ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-24 13:27:49.530269
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:27:57.308307
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Testing TruTVIE...')
    url = 'https://www.trutv.com/full-episodes/1436/most-shock-o-ween-countdown/videos/top-10-creepiest-footage-countdown.html'
    video = TruTVIE()
    print('Testing TruTVIE: extract: %s' % (video.suitable(url)))
    print('Testing TruTVIE: title: %s' % (video.extract(url)))

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:28:05.411718
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Turns out that writing the test_module.py is easier than doing the
    # test in youtube-dl itself
    ie = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie.suitable(url)
    data = ie.extract(url)
    assert data['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert data['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-24 13:28:06.023570
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:09.119083
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    t.test()

# Generated at 2022-06-24 13:28:16.601586
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutv = TruTVIE()

# Generated at 2022-06-24 13:28:17.821890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()


# Generated at 2022-06-24 13:28:20.397127
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test to confirm that TruTVIE class can be instantiated
    """
    video = TruTVIE()
    assert video is not None

# Generated at 2022-06-24 13:28:20.997283
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:24.185689
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
  obj = TruTVIE()
  t = obj._real_extract(url)
  print(t)

if __name__ == '__main__':
  test_TruTVIE()

# Generated at 2022-06-24 13:28:31.901599
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

    assert ie.IE_NAME == 'trutv:tv'
    assert ie.IE_DESC == 'TruTV'
    # test URL
    assert ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-24 13:28:35.427176
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Verify if TruTVIE is instance of TurnerBaseIE
    assert isinstance(TruTVIE, TurnerBaseIE)

    # Verify if TruTVIE's constructor is TruTVIE.__new__
    assert TruTVIE.__new__ == TurnerBaseIE.__new__


# Generated at 2022-06-24 13:28:46.235973
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check if TruTVIE is able to create instance of itself
    t = TruTVIE()
    # Assert if class TruTVIE is a object of TurnerBaseIE
    assert isinstance(t, TurnerBaseIE)
    # Assert if class TruTVIE class variable '_VALID_URL' is correct
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Assert if class TruTVIE class variable '_TEST' is correct