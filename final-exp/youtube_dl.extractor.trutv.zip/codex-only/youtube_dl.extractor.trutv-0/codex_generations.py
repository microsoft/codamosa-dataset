

# Generated at 2022-06-24 13:18:47.521760
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:18:48.130211
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-24 13:18:48.743427
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-24 13:18:49.406994
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:18:59.112668
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    
    # https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    video1_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    video1_expected = "Sunlight-Activated Flower"
    video1_test = TruTVIE(test_TruTVIE)
    video1_test_data = video1_test._real_extract(video1_url)
    assert video1_test_data['title'] == video1_expected
    
    # https://www.trutv.com/shows/the-carbonaro-effect/videos/the-carbonaro-effect-junior.html

# Generated at 2022-06-24 13:18:59.944366
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:00.827681
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return

# Generated at 2022-06-24 13:19:01.459068
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    True

# Generated at 2022-06-24 13:19:10.611175
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    # tests for function _get_tbs_url
    url1 = ttv._get_tbs_url('abc')
    url2 = ttv._get_tbs_url('efg')
    assert url1 == 'https://www.tbs.com/italy/tbs-italy-partner-configs/tbs_italy_profile.json?test=abc'
    assert url2 == 'https://www.tbs.com/italy/tbs-italy-partner-configs/tbs_italy_profile.json?test=efg'
    # tests for function _get_tru_url
    url3 = ttv._get_tru_url('abc')
    url4 = ttv._get_tru_url('efg')
    assert url

# Generated at 2022-06-24 13:19:14.286990
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    parser = TruTVIE()._parse_info(video_url)
    assert parser.__class__.__name__ == 'TruTVIE'


# Generated at 2022-06-24 13:19:15.344961
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE == type(TruTVIE)

# Generated at 2022-06-24 13:19:26.395835
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert not TruTVIE.suitable('http://www.trutv.com/shows/storage-wars/videos/storage-wars-a-time-for-everything-and-everyone.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/hack-my-life/videos/hack-my-life-s3-ep6-no-pain-no-gain.html')

# Generated at 2022-06-24 13:19:26.986528
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:28.166842
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    instance = TruTVIE()

# Generated at 2022-06-24 13:19:35.345940
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for constructor of class TruTVIE for this test case
    assert TruTVIE._VALID_URL == re.compile(r"^https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))$")

# Generated at 2022-06-24 13:19:39.183187
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    print("\nTesting TruTVIE constructor..")

    trutv_ie = TruTVIE()

    print(vars(trutv_ie))
    assert isinstance(trutv_ie, TruTVIE)
    assert isinstance(trutv_ie, TurnerBaseIE)

    print("\nTesting TruTVIE constructor is successful.")


# Generated at 2022-06-24 13:19:42.019924
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', expected_status=None)



# Generated at 2022-06-24 13:19:43.295353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    truTVIE = TruTVIE()

# Generated at 2022-06-24 13:19:45.391057
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert "TruTVIE" in dir(obj)


# Generated at 2022-06-24 13:19:53.598700
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiate and return a TruTVIE object
    c1 = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    c1._real_extract(url)
    # Call one function in TruTVIE
    url = 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    c1._real_extract(url)
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    c1._real_extract(url)

# Generated at 2022-06-24 13:19:54.098852
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:05.980697
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._download_json = lambda url, display_id: {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
    }

# Generated at 2022-06-24 13:20:07.317828
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._extract_url_info()
    TruTVIE()._extract_ngtv_info()

test_TruTVIE()

# Generated at 2022-06-24 13:20:08.996988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")



# Generated at 2022-06-24 13:20:09.946563
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """"
    Unit test for TruTVIE
    """
    TruTVIE()

# Generated at 2022-06-24 13:20:11.765377
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE
    if __name__ == "__main__":
        obj = TruTVIE()
    return obj


# Generated at 2022-06-24 13:20:22.316434
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor_object = TruTVIE()

# Generated at 2022-06-24 13:20:22.897064
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:31.017218
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Tests TruTVIE class constructor
    :return:
    """
    tr = TruTVIE()
    assert tr._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert tr._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:20:32.524736
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE



# Generated at 2022-06-24 13:20:43.724470
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Get the TruTVIE instance
    trutv_ie = TruTVIE()

    # Actual url to be tested
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

    # Unit test for the method _real_extract
    info = trutv_ie._real_extract(url)
    assert info[0] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    assert info[1] == "mp4"
    assert info[5] == "Sunlight-Activated Flower"
    assert info[11] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert info[22] == "Sunlight-Activated Flower"
   

# Generated at 2022-06-24 13:20:44.670057
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    return ()

# Generated at 2022-06-24 13:20:45.357259
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:55.052512
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test TruTVIE
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutvie = TruTVIE()._extract(url)
    assert(trutvie['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    assert(trutvie['ext'] == 'mp4')
    assert(trutvie['title'] == 'Sunlight-Activated Flower')
    assert(trutvie['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower.")

# Generated at 2022-06-24 13:20:59.164282
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    URL = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutvInstance = TruTVIE()
    assert trutvInstance is not None
    assert trutvInstance._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:21:02.695320
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video = TruTVIE()._real_extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert video['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:21:04.875940
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:21:06.755239
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE(None)
    assert instance is not None

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:21:07.479376
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:10.116839
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE','https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:21:11.335228
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    with pytest.raises(TypeError):
        TruTVIE(None)

# Generated at 2022-06-24 13:21:14.869117
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract(The_Carbonaro_Effect_sunlight_activated_flower_url)


The_Carbonaro_Effect_sunlight_activated_flower_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:21:18.094156
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    trutv_ie = TruTVIE()
    assert(isinstance(trutv_ie, TruTVIE))

    trutv_ie = TurnerBaseIE()
    assert(isinstance(trutv_ie, TurnerBaseIE))

# Generated at 2022-06-24 13:21:18.983798
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj is not None

# Generated at 2022-06-24 13:21:24.510847
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Input
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Output
    dict_out = {'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'ext': 'mp4', 'title': 'Sunlight-Activated Flower', 'description': "A customer is stunned when he sees Michael's sunlight-activated flower."}
    # Test
    assert TruTVIE()._real_extract(url) == dict_out

# Generated at 2022-06-24 13:21:27.268615
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a.url == "https://www.trutv.com/"
    assert a.ie_key == "truTV"

# Generated at 2022-06-24 13:21:27.956714
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:31.533286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE
    truTV_ie = TruTVIE()
    truTV_ie.download_webpage('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:21:32.517241
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()

# Generated at 2022-06-24 13:21:37.529221
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE()
    print(ttvie._TEST)
    print(ttvie._VALID_URL)
    #ttvie._real_extract('https://www.trutv.com/shows/carbonaro-effect/videos/emotional-support-pig.html')

# Generated at 2022-06-24 13:21:41.176089
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #IE_TEST = TruTVIE()
    #print(IE_TEST._download_json(IE_TEST._TEST['url']))
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')



# Generated at 2022-06-24 13:21:41.993421
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:51.996922
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    IE = TruTVIE()
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

# Generated at 2022-06-24 13:21:53.519973
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/full-episodes/my-dumb-questions.html'
    TruTVIE(url)

# Generated at 2022-06-24 13:21:53.970218
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:54.477049
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:00.154605
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'


# Generated at 2022-06-24 13:22:01.935599
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t is not None
#test_TruTVIE()

# Generated at 2022-06-24 13:22:03.192134
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert(trutvIE != None)

# Generated at 2022-06-24 13:22:05.913357
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.get_description() == "extracts videos and clips from trutv.com"


# Test TruTVIE class with a variety of inputs

# Generated at 2022-06-24 13:22:06.918662
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()

# Generated at 2022-06-24 13:22:09.806770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    "Unit test for constructor of class TruTVIE"
    trutv = TruTVIE()
    
    # Check for valid class instance
    assert trutv, "Class instance validation failed"
    return True


# Generated at 2022-06-24 13:22:13.954938
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_turner import test_smil_content_req, test_auth_required
    test_smil_content_req('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    test_auth_required('https://www.trutv.com/shows/the-last-og/videos/trevors-girlfriend-doesnt-like-his-debt.html')

# Generated at 2022-06-24 13:22:19.554730
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url = 'https://www.trutv.com/full-episodes/32627'
    trutvIE = TruTVIE()
    trutvIE.extract(url)


if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG)
    test_TruTVIE()

# Generated at 2022-06-24 13:22:24.479201
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    if TruTVIE.__name__ != 'TruTVIE':
        raise ValueError('Unit test for TruTVIE failed')
    if TruTVIE._TEST is None:
        raise ValueError('Unit test for TruTVIE failed')
    if TruTVIE._VALID_URL is None:
        raise ValueError('Unit test for TruTVIE failed')
    if TruTVIE.IE_NAME is None:
        raise ValueError('Unit test for TruTVIE failed')
    if TruTVIE.IE_DESC is None:
        raise ValueError('Unit test for TruTVIE failed')

# Generated at 2022-06-24 13:22:25.097471
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:35.333129
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TurnerBaseIE())._VALID_URL == TruTVIE._VALID_URL
    # Test with video_id

# Generated at 2022-06-24 13:22:36.761092
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(isinstance(TruTVIE(), TurnerBaseIE))


# Generated at 2022-06-24 13:22:45.779765
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert isinstance(ie, TruTVIE)
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:46.858451
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-24 13:22:55.090206
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE._TEST = {'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
    test = TruTVIE()
    test._real_extract(TruTVIE._TEST['url'])

# Generated at 2022-06-24 13:23:03.497332
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
	trutv_ie = TruTVIE()
	assert (trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
	assert (trutv_ie._TEST['url'] == test_url)

# Generated at 2022-06-24 13:23:11.012244
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import logging

    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(levelname)s: %(message)s',
        filename='test_TruTVIE.log'
    )
    logging.getLogger().addHandler(logging.StreamHandler())

    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_result = TruTVIE()._real_extract(test_url)
    logging.info(test_result)

# Test method
test_TruTVIE()

# Generated at 2022-06-24 13:23:12.117172
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:23:12.709940
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:16.718366
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Success case
    from .travis_test import travis_test
    
    assert(travis_test('''
    from .trutv_ie import TruTVIE
    TruTVIE.__module__ 
    ''') == 'youtube_dl.extractor.trutv')

# Generated at 2022-06-24 13:23:17.620752
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() != None


# Generated at 2022-06-24 13:23:24.894496
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
  test_path = "episode"
  test_display_id = "12345"
  test_series_slug = "the-carbonaro-effect"
  test_clip_slug = "sunlight-activated-flower"
  test_video_id = "12345"
  test_dict = {
    'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
    'ext': 'mp4',
    'title': 'Sunlight-Activated Flower',
    'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
  }
  test_show_cool = TruTV

# Generated at 2022-06-24 13:23:30.303709
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:23:35.212524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:36.101353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-24 13:23:38.245793
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # t.extract
    # t.extract_from_m3u8_formats

# Generated at 2022-06-24 13:23:40.186179
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TODO: Add a proper unit test for TruTVIE
    test_obj = TruTVIE()
    pass

# Generated at 2022-06-24 13:23:40.718678
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:41.586829
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:23:43.238775
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-24 13:23:44.713511
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE', 'TruTVIE', 'TruTVIE', 'TruTVIE')

# Generated at 2022-06-24 13:23:46.624530
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.get_browser()
    ie.get_title()

# Generated at 2022-06-24 13:23:48.400592
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE(TurnerBaseIE._downloader)
    assert(isinstance(obj, TruTVIE))
    assert(isinstance(obj, TurnerBaseIE))


# Generated at 2022-06-24 13:23:49.274048
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t_TruTVIE = TruTVIE()

# Generated at 2022-06-24 13:23:54.324562
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    resp = TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

test_TruTVIE()


import deepdish as dd
test = dd.io.load("test.h5")

# Generated at 2022-06-24 13:23:54.832606
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:05.036955
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    t = TurnerBaseIE()
    assert t._VALID_URL is None
    assert t._TEST is None
    t = TruTVIE()
    assert isinstance(t, TruTVIE) is True
    assert isinstance(t, TurnerBaseIE) is True
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert len(t._TEST) == 3

# Generated at 2022-06-24 13:24:07.626839
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    instance = TruTVIE()
    info = instance._real_extract(url)
    print(info)

# Generated at 2022-06-24 13:24:08.779618
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        assert(False)

# Generated at 2022-06-24 13:24:17.430356
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	youtube_link = TruTVIE()
	assert youtube_link.__class__.__name__ == 'TruTVIE'
	assert youtube_link._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
	assert youtube_link._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:24:19.501369
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert "true" == "true"
    

# Generated at 2022-06-24 13:24:29.392881
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    extractor = TruTVIE()
    m = re.match(extractor._VALID_URL, url)
    assert m is not None
    assert m.groupdict()['series_slug'] == 'the-carbonaro-effect'
    assert m.groupdict()['clip_slug'] == 'sunlight-activated-flower'
    assert m.groupdict()['id'] is None

    url2 = 'https://www.trutv.com/full-episodes/15876087/impractical-jokers-season-5-episode-1-the-witness-torture.html'
    m = re.match(extractor._VALID_URL, url2)
   

# Generated at 2022-06-24 13:24:30.504311
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(TurnerBaseIE())

# Generated at 2022-06-24 13:24:31.549476
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__doc__ is not None

# Generated at 2022-06-24 13:24:37.747151
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test with valid URL
    t = TruTVIE()
    assert t.match("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    # Test with invalid URL
    t = TruTVIE()
    assert not t.match("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower")

# Generated at 2022-06-24 13:24:40.339018
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(_download_json=lambda x, y: {'episode': {'mediaId': '12345'}, 'info': {'mediaId': '12345'}})

# Generated at 2022-06-24 13:24:49.719394
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    obj = TruTVIE(TruTVIE.create_ie(), url)

    assert obj.url == url
    assert obj.video_id == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    assert obj.display_id == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    assert obj.series_slug == 'the-carbonaro-effect'
    assert obj.clip_slug is None

# Generated at 2022-06-24 13:24:56.433026
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html" 
    data = TruTVIE()._real_extract(url)
    assert data['url'] == url
    assert data['display_id'] == 'sunlight-activated-flower'
    assert data['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert data['title'] == 'Sunlight-Activated Flower'
    assert data['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert data['site_name'] == 'truTV'
    assert data['auth_required'] == True

# Generated at 2022-06-24 13:24:57.306997
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    t.match()

# Generated at 2022-06-24 13:24:59.966173
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE()
    assert result.get_valid_url() == TruTVIE._VALID_URL
    assert result.get_test() == TruTVIE._TEST


# Generated at 2022-06-24 13:25:09.140555
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTv = TruTVIE()
    assert  TruTv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    m = TruTv._VALID_URL.match
    assert m("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") is not None

# Generated at 2022-06-24 13:25:10.702069
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.get_name() == "trutv"

# Generated at 2022-06-24 13:25:20.187950
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE class"""
    t = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert t.URL == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert t.VALID_URL == "https://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"


# Generated at 2022-06-24 13:25:28.787583
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SUITABLE == '<TurnerBaseIE>'
    assert ie.IE_NAME == 'Turner:trutv'
    assert ie.VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie.LOGIN_URL == 'https://www.trutv.com/login'
    assert ie.LOGIN_SUMMARY == 'Requires logging in'

# Generated at 2022-06-24 13:25:30.375353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    c = TruTVIE()
    assert c.__class__ == TruTVIE

# Generated at 2022-06-24 13:25:31.305743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:25:33.166951
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert re.match(TruTVIE._VALID_URL, TruTVIE._TEST["url"])

# Generated at 2022-06-24 13:25:41.896407
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert t.suitable('https://www.trutv.com/full-episodes/the-carbonaro-effect/2527176/sunlight-activated-flower.html')
    assert not t.suitable('https://www.trutv.com/shows/the-car-effect/videos/sunlight-activated-flower.html')
    assert not t.suitable('https://www.blah.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not t.suitable('test.ts')

# Generated at 2022-06-24 13:25:44.162259
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE class constructor"""
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:25:54.266299
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .common import fake_urlopen
    from .turner import TurnerBaseIE
    import unittest
    import json

    class FakeUrlTest(unittest.TestCase):
        def setUp(self):
            self.ie = TruTVIE()
            self.ie._download_json = fake_urlopen(json.dumps({
                'episode': {
                    'mediaId': "1",
                    'title': "2",
                    'description': "3",
                    'images': [{
                        'srcUrl': "4",
                        'width': 5,
                        'height': 6
                    }],
                    'publicationDate': "7",
                    'showTitle': "8",
                    'seasonNum': 9,
                    'episodeNum': 10,
                    'isAuthRequired': True
                }
            }))


# Generated at 2022-06-24 13:25:55.596893
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    thistest = TruTVIE()
    print(thistest)

# Generated at 2022-06-24 13:25:58.429707
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video = TruTVIE()
    video.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:26:01.174397
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    from . import TruTVIE
    trutvIE = TruTVIE()

# Generated at 2022-06-24 13:26:03.330518
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SUFFIX == 'trutv.com'
    assert ie.NAME == 'truTV'

# Generated at 2022-06-24 13:26:10.124458
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from ytdl.TruTVIE import TruTVIE
    # Test with a video link
    TruTVIE().extract(
        r'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Test with a full episode link
    TruTVIE().extract(r'https://www.trutv.com/full-episodes/132408/the-carbonaro-effect-sunlight-activated-flower/')


# Generated at 2022-06-24 13:26:11.576851
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TurnerBaseIE()
    t = TruTVIE()

# Generated at 2022-06-24 13:26:13.273239
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE("")
    assert isinstance(test, TruTVIE)

# Generated at 2022-06-24 13:26:15.309860
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.name


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:26:16.369680
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None


# Generated at 2022-06-24 13:26:16.934260
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:19.146651
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert t is not None

# Generated at 2022-06-24 13:26:19.774881
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:24.582747
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# IO: specify a url and a extractor
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	extractor = TruTVIE()

	# extract data with extractor
	data = extractor._real_extract(url)

	# print some information that is expected to be extracted
	print(data['id'])
	print(len(data['formats']))
	for i in range(len(data['formats'])):
		print(data['formats'][i]['url'])

# Generated at 2022-06-24 13:26:29.401365
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Create instance TruTVIE
    trutv_ie = TruTVIE()

    # Create instance TruTVIE.
    assert trutv_ie.__class__.__name__ == TruTVIE.__name__
    assert isinstance(trutv_ie, TruTVIE)


# Generated at 2022-06-24 13:26:30.497753
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None


# Generated at 2022-06-24 13:26:36.821553
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTV_ie = TruTVIE()
    try:
        TruTV_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    except Exception as e:
        print('Raised an exception: ' + str(e))
        success = False
    else:
        success = True
    assert success

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:26:38.257501
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:26:43.597674
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:26:54.061330
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    testcase = TruTVIE()
    assert testcase._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:59.594239
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._extract_ngtv_info('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',{},{'url':'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html','site_name':'truTV','auth_required':False})


# Generated at 2022-06-24 13:27:01.279160
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert TruTVIE._VALID_URL == t._VALID_URL

# Generated at 2022-06-24 13:27:06.547320
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create instance of TruTVIE
    trutv_ie = TruTVIE()
    # Check that url is valid
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:18.353825
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:26.578821
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# t = TruTVIE({'url':'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
	# 			 'info_dict':{'id':'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
	# 						  'ext':'mp4',
	# 				 		  'title':'Sunlight-Activated Flower',
	# 				 		  'description':"A customer is stunned when he sees Michael's sunlight-activated flower.",},
	# 			 'params':{'skip_download':True,},})
	pass

# Generated at 2022-06-24 13:27:35.069367
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()

# Generated at 2022-06-24 13:27:45.118832
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:46.009272
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:27:48.596898
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	test = TruTVIE()
	test_real_extract = test._real_extract(url)

# Generated at 2022-06-24 13:27:51.376768
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    TODO: test TruTVIE, we currently get error "TypeError: object() takes no parameters"
    """
    pass


# Generated at 2022-06-24 13:28:00.337296
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    # Test fields in class TruTVIE
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:11.235602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/impractical-jokers/full-episodes/episode-1408.html')
    test_ie = TruTVIE()
    result = test_ie.extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert re.match(r'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', result['id'])

# Generated at 2022-06-24 13:28:22.293856
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv_ie._TEST['url'] == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

# Generated at 2022-06-24 13:28:29.243321
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.IE_NAME == 'truTV'
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:34.827939
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'



# Generated at 2022-06-24 13:28:41.192965
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    t1 = TruTVIE()
    t1._real_extract(url)
    t2 = TruTVIE()
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    t2._real_extract(url)

# Generated at 2022-06-24 13:28:43.755966
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(object(), "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:28:44.485494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:49.638011
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test valid and invalid URL separately, if it works as expected"""