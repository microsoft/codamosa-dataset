

# Generated at 2022-06-24 13:18:46.518272
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    TruTVIE()
    return


# Generated at 2022-06-24 13:18:56.541562
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:18:57.375785
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TurnerBaseIE())._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:18:58.986845
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE("", "", "")
    assert (t != None)


# Generated at 2022-06-24 13:19:00.626942
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass


# Generated at 2022-06-24 13:19:01.974084
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for method TruTVIE()
    TruTVIE()

# Generated at 2022-06-24 13:19:04.004702
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV_object = TruTVIE('www.trutv.com')
    print(truTV_object._VALID_URL)


# Generated at 2022-06-24 13:19:12.479759
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE.__doc__ is not None
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:12.996965
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  TruTVIE()

# Generated at 2022-06-24 13:19:18.351750
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.extract('https://www.trutv.com/full-episodes/552889/americas-funniest-home-videos-s28-e05.html')

# Generated at 2022-06-24 13:19:28.853506
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	user_agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.82 Safari/537.36'
	url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

# Generated at 2022-06-24 13:19:35.768056
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
        t = TruTVIE()
        # Test the url validity
        if t.suitable(test_url):
            print('The url %s is valid' % test_url)
        else:
            print('The url %s is invalid' % test_url)
        # Test the extraction
        t.extract(test_url)
    except Exception as e:
        print ('An exception occurred: %s' % (str(e)))

# Generated at 2022-06-24 13:19:42.401914
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    TruTVIE subclass unit test

    Verifies that the TruTVIE subclass defines the TruTVIE class' basic functionality
    """

    trutv_ie = TruTVIE()

    # Make sure that the TrueTVIE class defines the necessary attributes
    assert hasattr(trutv_ie, "_VALID_URL")
    assert trutv_ie._VALID_URL
    assert hasattr(trutv_ie, "_TEST")
    assert trutv_ie._TEST
    assert hasattr(trutv_ie, "_download_ngtv_api_sdk")
    assert trutv_ie._download_ngtv_api_sdk
    assert hasattr(trutv_ie, "_extract_ngtv_info")
    assert trutv_ie._extract_ngtv_info
    assert has

# Generated at 2022-06-24 13:19:43.295084
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('')

# Generated at 2022-06-24 13:19:51.967116
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-24 13:19:52.683139
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTV')

# Generated at 2022-06-24 13:19:58.617608
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    u = TruTVIE()
    assert u._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:20:00.638494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test for TruTVIE
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)

# Generated at 2022-06-24 13:20:02.487071
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE(None)
    assert(result is not None)


# Generated at 2022-06-24 13:20:09.522854
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Basic tests for the TruTVIE constructor.
    """
    ie = TruTVIE()
    assert ie._VALID_URL == TruTVIE._VALID_URL
    assert ie._TEST == TruTVIE._TEST
    assert str(ie) == "u'TruTV'"
    assert ie.ie_key() == 'TruTV'
    assert ie.ie_key() in TruTVIE.ie_key()
    assert ie.extra_ie() == [u'Turner', u'TNT']
    assert hasattr(ie, '_extract_ngtv_info')



# Generated at 2022-06-24 13:20:12.154102
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    try:
        assert(ie is not None)
        return True
    except AssertionError:
        return False

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:20:14.022843
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .TruTVIE import TruTVIE
    # Test valid URL of API
    TruTVIE()

# Generated at 2022-06-24 13:20:24.338149
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import json
    tv = TruTVIE()
    # Check if the method works correctly
    assert(tv.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True)
    assert(tv.suitable('https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True)
    assert(tv.suitable('https://www.trutv.com/shows/the-carbonaro-effect/946') == True)
    assert(tv.suitable('https://www.trutv.com/full-episodes/the-carbonaro-effect/946') == True)

# Generated at 2022-06-24 13:20:25.065072
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.suite()

# Generated at 2022-06-24 13:20:26.561116
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_truTV = TruTVIE()
    import pdb
    pdb.set_trace()

# Generated at 2022-06-24 13:20:29.011681
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        print("Unit test for TruTVIE: SUCCESS")
    except:
        print("Unit test for TruTVIE: FAIL")


# Generated at 2022-06-24 13:20:29.499671
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:29.988523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:20:31.987748
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Testing for constructor TruTVIE by using a valid url
    trutv = TruTVIE()
    assert trutv != None


# Generated at 2022-06-24 13:20:32.772360
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:33.768740
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None, None)

# Generated at 2022-06-24 13:20:44.873612
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    # Success case
    test_case = {
    "url": "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html",
    "info_dict": {
        "id": "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1",
        "ext": "mp4",
        "title": "Sunlight-Activated Flower",
        "description": "A customer is stunned when he sees Michael's sunlight-activated flower.",
    },
    "params": {
        # m3u8 download
        "skip_download": True,
    }
    }
    TruTVIE()._test_case(test_case)
    # Failure

# Generated at 2022-06-24 13:20:50.517039
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor of class TruTVIE
    arg = ["https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"]
    if __name__ == '__main__':
        print('[+] Testing with ' + str(arg))
        TruTVIE()._real_extract(arg[0])

# Generated at 2022-06-24 13:20:53.549521
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    print("Testing constructor of class TruTVIE")
    assert(type(trutv) == TruTVIE)


# Generated at 2022-06-24 13:20:56.111749
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TestCase
    from .test_trutv import test_TruTVIE as tt

    class TruTVIETestCase(TestCase):

        def setUp(self):
            self.TRUTV = TruTVIE()

    tt(TruTVIETestCase)

# Generated at 2022-06-24 13:20:57.817409
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE([])
    except Exception as e:
        print(repr(e))

# Generated at 2022-06-24 13:20:58.779589
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:59.961465
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST.get('url') == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:21:00.804485
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:21:03.888356
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    # testing if TruTVIE is a subclass of TurnerBaseIE
    assert issubclass(type(ttv), TurnerBaseIE), "TruTVIE is not a subclass of TurnerBaseIE"

# Generated at 2022-06-24 13:21:04.430031
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:07.833370
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_json(
        'https://api.trutv.com/v2/web/series/clip/trutv-top-funniest-fright-night',
        'trutv-top-funniest-fright-night')

# Generated at 2022-06-24 13:21:09.121600
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:21:10.033890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST


# Generated at 2022-06-24 13:21:17.367798
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # create test object
    trutv = TruTVIE()
    # set of missing items in collections (items may be empty)
    missing = set(trutv.__dict__.keys())
    # loop through all keys in __dict__ of parent class
    for key in TurnerBaseIE.__dict__.keys():
        # if key is present in missing and not private key
        if key in missing and not key.startswith('_'):
            # remove from missing
            missing.remove(key)
    # if missing is not empty, then throw error
    if missing:
        raise AssertionError('object %s is missing members: %s' % (
            repr(trutv), repr(missing)))

# Generated at 2022-06-24 13:21:18.218359
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:21:25.389610
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    test_dict = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

    test_dict['info_dict']['thumbnail'] = 're:^https?://.*'

# Generated at 2022-06-24 13:21:36.111953
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:21:44.153771
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

    # test TruTVIE.ie_key
    assert ie.ie_key() == 'trutv'

    # test TruTVIE._VALID_URL
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie._VALID_URL == TruTVIE._VALID_URL
    assert ie._match_id(url) == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

    # test TruTVIE._download_json
    # Note: This json file is not a valid one.
    invalid_json = '''
    {
        "info": {
        }
    }
    '''
    assert ie._download_json

# Generated at 2022-06-24 13:21:47.236539
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test object creation
    try:
        trutv_video = TruTVIE()
    except:
        trutv_video = None
    assert(trutv_video is not None)


# Generated at 2022-06-24 13:21:48.766020
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE = TruTVIE()
    assert TruTVIE != None


# Generated at 2022-06-24 13:21:49.414524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:56.816090
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE._VALID_URL
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test for TruTVIE._TEST

# Generated at 2022-06-24 13:21:57.396575
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:06.965657
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:12.537649
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test constructor
    instance = TruTVIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert isinstance(instance, TurnerBaseIE)

# Generated at 2022-06-24 13:22:13.327255
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:21.703749
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Simple case: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    instance = TruTVIE()
    instance._real_extract(url)

    # Case with video_id = None: https://www.trutv.com/full-episodes/the-daredevils/videos/a-barrel-full-of-lead-bullets.html
    url = 'https://www.trutv.com/full-episodes/the-daredevils/videos/a-barrel-full-of-lead-bullets.html'
    instance = TruTVIE()
    instance._real_extract

# Generated at 2022-06-24 13:22:23.514576
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'Turner:truTV'

# Generated at 2022-06-24 13:22:25.029665
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE()
    assert(result)

# Generated at 2022-06-24 13:22:29.610373
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a=TruTVIE()
    try:
        a=TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    except Exception as e:
        print(e)
    print(a.url)
    print(a._TEST)
    print(a._VALID_URL)


# Generated at 2022-06-24 13:22:31.292082
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Test constructor of class TruTVIE"""
    TruTVIE()

# Generated at 2022-06-24 13:22:32.234746
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:34.197551
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Without assert
    TruTVIE()
    # With assert
    assert TruTVIE is not None

# Generated at 2022-06-24 13:22:37.697734
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    expected = TruTVIE
    assert isinstance(instance,expected)



# Generated at 2022-06-24 13:22:38.353662
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:22:47.005713
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Value of _VALID_URL, a regular expression
    TruTVIE._VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Value of _TEST, a dictionary

# Generated at 2022-06-24 13:22:48.233864
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Test for TruTVIE
    '''
    TruTVIE()

# Generated at 2022-06-24 13:22:51.658990
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TruTVIE should not be instantiated
    # it has download methods, but it is a base class for other downloader
    # classes which is automatically detected
    # the code should not reach the line which raises an exception
    TruTVIE()
    raise Exception('Attainable exception')

# Generated at 2022-06-24 13:22:52.847312
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print(TruTVIE('TruTVIE', False))


# Generated at 2022-06-24 13:22:57.492330
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    YouTubeIE._call_api = YouTubeIE._download_json
    trutv = TruTVIE()
    trutv._download_json = TruTVIE._download_json
    trutv._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:23:03.872366
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    # pylint: disable=protected-access, unused-argument

    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    # Assert that TruTVIE matches the url
    assert trutv_ie._match_id(url) == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:23:04.765820
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test the construction of TruTVIE class
    TruTVIE()

# Generated at 2022-06-24 13:23:11.331951
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for TruTVIE
    # Constructor without parameters

    # Constructor with parameters
    trutv_ie = TruTVIE(TruTVIE._VALID_URL)

    # test return result
    assert trutv_ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:11.937390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:23:20.058390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test whether TruTVIE class is working properly."""
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttv = TruTVIE()
    ttv_test = ttv._real_extract(url)
    assert ttv_test['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert ttv_test['ext'] == 'mp4'
    assert ttv_test['title'] == 'Sunlight-Activated Flower'
    assert ttv_test['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-24 13:23:27.198805
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # A test url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Retriving html source from url
#    source = urllib.urlopen(url).read()
    # Creating instance of class TruTVIE.
    test = TruTVIE()
#    test._download_json(url)
    # Testing if the url is supported by the IE.
    assert test._VALID_URL == re.match(test._VALID_URL, url).groupdict()

# Generated at 2022-06-24 13:23:27.735520
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:29.273194
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TruTVIE)

# Generated at 2022-06-24 13:23:30.397210
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.ie_key() == 'TruTV'

# Generated at 2022-06-24 13:23:31.196194
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test.suite()

# Generated at 2022-06-24 13:23:31.998316
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("test", "test")

# Generated at 2022-06-24 13:23:39.767455
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert t.key == 'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower'
    assert t.clip_slug == 'sunlight-activated-flower'
    assert t.series_slug == 'the-carbonaro-effect'
    assert t.video_id == None

## Unit test for _extract_trutv_info

# Generated at 2022-06-24 13:23:40.312125
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:49.351923
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Initialize an instance of the class
    test_tru_tv_instance = TruTVIE()

    # Check value of private field '_VALID_URL'
    if TruTVIE._VALID_URL != r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))':
        raise AssertionError('_VALID_URL has unexpected value')

    # Check value of private field '_TEST'

# Generated at 2022-06-24 13:23:49.898892
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._TEST

# Generated at 2022-06-24 13:23:50.693296
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    return

# Generated at 2022-06-24 13:23:51.232392
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:56.110143
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # URL for test
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Test constructor of class TruTVIE
    ie_test = TruTVIE(url)
    print("Unit test of constructor of class TruTVIE")
    # Print URL that is being tested
    print("URL: " + url)
    # Test the URL
    if ie_test.test() == url:
        print("URL OK")
    else:
        print("URL not match")
    # Print class TruTVIE
    print(TruTVIE)

test_TruTVIE()

# Generated at 2022-06-24 13:24:05.926269
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("test constructor of class TruTVIE")
    # given
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # when
    extracted = TruTVIE._real_extract(TruTVIE(), url)
    # then
    assert extracted['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert extracted['title'] == 'Sunlight-Activated Flower'
    assert extracted['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert extracted['display_id'] == 'sunlight-activated-flower'
    print("test constructor of class TruTVIE: OK!")

# Generated at 2022-06-24 13:24:06.416546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:24:07.216393
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.suite()

# Generated at 2022-06-24 13:24:08.659067
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:24:10.959368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except AssertionError:
        pass
    except:
        raise AssertionError

# Generated at 2022-06-24 13:24:11.906382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:12.312733
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:14.100764
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	TruTVIE()

# Generated at 2022-06-24 13:24:15.006699
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj

# Generated at 2022-06-24 13:24:15.718059
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:17.071985
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    TruTVIE()


# Generated at 2022-06-24 13:24:20.390088
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = TruTVIE._TEST['url']
    ie = TruTVIE()
    ie.extract(test_url)
    assert ie.extract(test_url) is not None

# Generated at 2022-06-24 13:24:28.578302
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    assert(trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(trutv.suitable(url) == True)

# Generated at 2022-06-24 13:24:29.844840
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()

# Generated at 2022-06-24 13:24:30.626276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:32.158179
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None) is not None


# Generated at 2022-06-24 13:24:32.895205
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:33.577633
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:44.045915
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE._VALID_URL == re.compile(r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:24:52.813843
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE().extract('https://www.trutv.com/full-episodes/591878/the-carbonaro-effect-sunlight-activated-flower.html')
    assert not TruTVIE().supports_url('https://www.trutv.com/shows/full-episodes/the-carbonaro-effect/591878/the-carbonaro-effect-sunlight-activated-flower.html')
    assert not TruTVIE().supports_url('https://www.trutv.com/shows/full-episodes/the-carbonaro-effect/591878')

# Generated at 2022-06-24 13:24:53.545786
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:24:55.045220
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:24:56.565695
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Constructor test for class TruTVIE"""
    obj = TruTVIE()
    print(obj)

# Generated at 2022-06-24 13:25:06.170361
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:25:16.596023
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE with all possible combinations

    # https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    trutv_sunlight_activated_flower = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv_sunlight_activated_flower.series_sl

# Generated at 2022-06-24 13:25:17.177331
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:17.759230
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:28.186410
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test with valid URL
    trutv_ie = TruTVIE()
    trutv_ie._VALID_URL = TruTVIE._VALID_URL
    assert trutv_ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv_ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/114072/videos/sunlight-activated-flower.html')

    # test with invalid URL
    assert not trutv_ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower')

# Generated at 2022-06-24 13:25:31.019478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'

# Generated at 2022-06-24 13:25:36.402280
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Constructor of class TruTVIE.
    """
    # No input
    truTV_ie = TruTVIE()

    # Input is None
    truTV_ie = TruTVIE(None)

    # Input is str
    truTV_ie = TruTVIE('id')

    # Input is list
    truTV_ie = TruTVIE(['id'])


# Generated at 2022-06-24 13:25:44.528179
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test for TruTVIE class with valid and in valid input.
    """
    import unittest
    from youtube_dl.utils import ExtractorError
    from youtube_dl.utils import WARNING

    class TestTruTVIE(unittest.TestCase):
        def setUp(self):
            self.truTVIEInstance = TruTVIE()

        def test_TruTVIE_valid(self):
            """
            Test for TruTVIE class with valid input.
            """
            self.assertEqual(
                self.truTVIEInstance._match_id('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'),
                ('the-carbonaro-effect', 'sunlight-activated-flower', None))


# Generated at 2022-06-24 13:25:45.499937
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	True

# Generated at 2022-06-24 13:25:48.025938
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor
    ie = TruTVIE()
    assert ie.SUCCESSFULLY_TESTED



# Generated at 2022-06-24 13:25:49.041353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()

# Generated at 2022-06-24 13:25:52.659752
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutv = TruTVIE(url)
    print(trutv)
    assert trutv != None


# Generated at 2022-06-24 13:26:03.284185
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Success cases
    obj = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert 'trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower' == obj._API_BASE_URL
    assert 'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower' == obj._download_webpage(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'sunlight-activated-flower')

# Generated at 2022-06-24 13:26:13.800524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:26:14.376224
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-24 13:26:17.895315
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    s = TruTVIE()
    #assert(s.name == 'test')
    assert (s.ie_key() == 'trutv')
    assert (s.test() is False)
    assert (s.supported_domains == ['TruTV'])

# Generated at 2022-06-24 13:26:20.505786
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        print("Unit test successfull for class TruTVIE")
    except Exception as e:
        print("ERROR:")
        print("Unit test for class TruTVIE failed!")
        print(type(e))
        print(e.args)
        print(e)
test_TruTVIE()

# Generated at 2022-06-24 13:26:21.831540
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t != None

# Generated at 2022-06-24 13:26:27.825483
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """

    """
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutvIE = TruTVIE()
    result = trutvIE.extract(url)
    assert 'id' in result
    assert 'title' in result
    assert 'description' in result

# Generated at 2022-06-24 13:26:28.821693
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert (TruTVIE() is not None)

# Generated at 2022-06-24 13:26:34.934564
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE

    Make sure the constructor of the class TruTVIE works properly.
    """

    import youtube_dl.extractor.trutv

    TruTVIE = youtube_dl.extractor.trutv.TruTVIE('self')

    for url_attr in ('_VALID_URL', '_TEST'):
        assert(getattr(TruTVIE, url_attr, None) is not None)

# Generated at 2022-06-24 13:26:44.476684
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:26:47.674902
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE(None)
        assert False, 'Constructor of class TruTVIE raised exception'
    except:
        assert True, 'Constructor of class TruTVIE did not raise exception'

# Generated at 2022-06-24 13:26:51.208379
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing constructor of class TruTVIE")
    test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_TruTVIE = TruTVIE(test_url)
    print(test_TruTVIE)
    print("Testing TvShow constructor of class TruTVIE completed")


# Generated at 2022-06-24 13:26:53.525088
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.name == 'TruTV'
    assert ie._VALID_URL == ie._TEST['url']

# Generated at 2022-06-24 13:27:03.216405
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.IE_NAME == 'trutv'
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:04.543618
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE._TEST['url']
    TruTVIE(TruTVIE._TEST).extract(url)

# Generated at 2022-06-24 13:27:10.218859
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE('TruTVIE', True, 'http://example.com', 'http://example2.com')
    assert i.name() == 'TruTVIE'
    assert i.is_suitable('http://example.com') is True
    assert i.is_suitable('http://other.com') is False

# Tests for extract method of class TruTVIE

# Generated at 2022-06-24 13:27:13.771611
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from collections import namedtuple
    from .tests.test_turner import TurnerBaseIETest
    TurnerBaseIETest.test_constructor(TruTVIE())


# Unit tests for methods of class TruTVIE

# Generated at 2022-06-24 13:27:16.952254
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTV = TruTVIE()
	assert truTV._VALID_URL is not None
	assert truTV._TEST is not None
	assert truTV.IE_NAME is not None

# Generated at 2022-06-24 13:27:17.810249
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Constructor of class TruTVIE

# Generated at 2022-06-24 13:27:19.056898
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Constructor for TruTVIE class should run without error."""
    TruTVIE()


# Generated at 2022-06-24 13:27:28.249866
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test if TruTVIE is a subclass of TurnerBaseIE
    assert issubclass(TruTVIE, TurnerBaseIE)

    # Test if the constructor of TruTVIE creates the expected object
    test_truTVIE = TruTVIE()

    # Check if the member variables of TruTVIE hold the expected value
    assert test_truTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:36.343011
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvIE = TruTVIE();

    assert ttvIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


test = TruTVIE()
test.download("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:27:37.563280
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:27:41.663259
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert isinstance(trutv_ie, TruTVIE)
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:42.249126
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:49.695775
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }


# Generated at 2022-06-24 13:27:59.176923
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    response = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
    # test_TruTVIE() should return True
    assert TruTVIE()._real_extract(response['url'])==response

# Generated at 2022-06-24 13:28:10.114380
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_video = TruTVIE()
    assert test_video.extractor_key == 'trutv'
    assert test_video.IE_NAME == 'trutv'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:17.390179
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:18.256284
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == "TruTVIE"

# Generated at 2022-06-24 13:28:23.694533
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("test_TruTVIE: running...")

    test_object = TruTVIE()
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_object._real_extract(test_url)

test_TruTVIE()
print("test_TruTVIE: done")

# Generated at 2022-06-24 13:28:34.589314
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    obj = TruTVIE()
    assert obj._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-24 13:28:35.429063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:28:38.474374
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?P<id>\d+)'


# Generated at 2022-06-24 13:28:39.496789
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:28:40.179462
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:28:40.918877
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:45.121525
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # tests for constructor
    ttv = TruTVIE()
    # tests for class variables
    print('class variables')
    print('VALID_URL: ' + str(TruTVIE._VALID_URL))
    print('TEST: ' + str(TruTVIE._TEST))