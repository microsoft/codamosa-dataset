

# Generated at 2022-06-24 13:18:55.258971
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    

# Generated at 2022-06-24 13:19:03.223008
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """

    # Check for any invalid values for TruTVIE.name
    assert TruTVIE.name == "TruTV"

    # Check for any invalid values for TruTVIE.ie_key
    assert TruTVIE.ie_key == "TruTV"

    # Check for any invalid values for TruTVIE._VALID_URL
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Check for any invalid values for TruTVIE._

# Generated at 2022-06-24 13:19:11.955750
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing TruTVIE
    expected_series_slug = 'Impractical-Jokers'
    expected_clip_slug = 'sal-gets-a-splinter'
    expected_episode_id = '1524194'
    TruTVIE_obj = TruTVIE()
    assert re.match(TruTVIE_obj._VALID_URL, 'https://www.trutv.com/shows/Impractical-Jokers/videos/sal-gets-a-splinter.html')
    assert re.match(TruTVIE_obj._VALID_URL, 'https://www.trutv.com/full-episodes/1524194')

# Generated at 2022-06-24 13:19:15.250224
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.VALID_URL == TruTVIE._VALID_URL
    assert obj.IE_NAME == TruTVIE._IE_NAME
    assert obj.TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:19:16.245661
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:19:17.053564
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:18.913351
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    object_TruTVIE = TruTVIE()
    print(object_TruTVIE)

# Generated at 2022-06-24 13:19:24.888814
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test for full episode
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/3-leggers-and-scales-oh-my.html')
    # test for video clip
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:19:33.067610
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # A valid URL
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/full-episodes/193737/titanic-titanic')

    # An invalid URL
    assert not TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/')
    assert not TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/')

    # Test TruTVIE.ie_key() for TruTVIE
    assert TruTVIE.ie_key() == 'TruTV'

    # Test TruTVIE._extract_entries()

# Generated at 2022-06-24 13:19:37.883715
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        # Initializing TruTVIE object
        TruTVIE()
    except:
        print("Unable to initialize TruTVIE object")
        return False
    return True

# Run TruTVIE tests if true
if test_TruTVIE():
    from .dev_Server import dev_Server
    from .test_TruTVIE import test_TruTVIE
    dev_Server.start(test_TruTVIE)

# Generated at 2022-06-24 13:19:38.474461
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:39.833685
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for class TruTVIE"""
    TruTVIE()



# Generated at 2022-06-24 13:19:41.285021
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj is not None


# Generated at 2022-06-24 13:19:51.619925
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from youtube_dl.utils import DateRange
    from datetime import datetime


# Generated at 2022-06-24 13:19:55.988989
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	video_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	assert TruTVIE(TruTVIE.create_ie()).extract_info(video_url)

# Generated at 2022-06-24 13:19:57.823863
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_test = TruTVIE()
    assert(trutv_test)

# Generated at 2022-06-24 13:20:02.435820
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    while True:
        instance = TruTVIE()
        result = instance._real_extract(url)
        print(result)
        break


# Generated at 2022-06-24 13:20:03.040583
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:06.342205
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    
    print("\n\n")
    ie = TruTVIE()
    ie = TruTVIE(ie.ie_key())
    print("\n\n")
    assert ie.ie_key() == 'truTV'

# Generated at 2022-06-24 13:20:13.811325
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    testVars = {}
    testVars['url'] = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    testVars['info_dict'] = {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
    }
    testVars['params'] = {'skip_download': True}
    test_TruTVIE = TruTVIE()

# Generated at 2022-06-24 13:20:17.308724
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == TRU_TV_VALID_URL
    assert TruTVIE._TEST == TRU_TV_TEST


# Generated at 2022-06-24 13:20:19.748605
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        assert(TruTVIE(None) is not None)
    except:
        raise AssertionError("TruTVIE failed to initialize")


# Generated at 2022-06-24 13:20:20.384497
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        pass

# Generated at 2022-06-24 13:20:20.992863
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:29.571635
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:20:30.432717
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:31.411275
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:20:37.881608
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case = TruTVIE()

    pattern = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert re.match(pattern, test_case._VALID_URL)



# Generated at 2022-06-24 13:20:40.488110
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE', 'TruTVIE.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:20:49.303573
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:20:59.800858
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    test_values = [t._VALID_URL, t._TEST]


# Generated at 2022-06-24 13:21:02.387704
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ test TruTVIE class constructor """
    # assert TruTVIE is not None
    try:
        assert TruTVIE
    except NameError:
        print('NameError: assert TruTVIE')
    TruTVIE

# Generated at 2022-06-24 13:21:04.225549
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == _VALID_URL
    assert TruTVIE()._TEST == _TEST

# Generated at 2022-06-24 13:21:06.031900
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:21:15.149012
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

    # Type of class TruTVIE
    assert ie.__class__.__name__ == "TruTVIE"

    # Test method "suitable"
    assert ie.suitable(url) == True

    # Test method "extract"

# Generated at 2022-06-24 13:21:15.563748
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:21:21.792002
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # 1. Test TruTVIE._real_extract with a valid URL to extract
    truTVInstance = TruTVIE()

    res = truTVInstance._real_extract(TruTVIE._TEST['url'])

    # Make sure that the extracted media ID is correct
    assert res['id'] == TruTVIE._TEST['info_dict']['id']

    # Make sure that the extracted media title is correct
    assert res['title'] == TruTVIE._TEST['info_dict']['title']

    # Make sure that the extracted media description is correct
    assert res['description'] == TruTVIE._TEST['info_dict']['description']

# Generated at 2022-06-24 13:21:22.920670
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.module_name == 'trutv'

# Generated at 2022-06-24 13:21:32.961896
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Default constructor test
    ie = TruTVIE()
    # Test initialization for TruTVIE class
    obj = TruTVIE('http://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html',
                  'trutv.com')
    print(ie._TEST, "\n")

    # Test initialization for TruTVIE class
    obj = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
                  'trutv.com')
    print(obj._TEST, "\n")

    # Test initialization for TruTVIE class

# Generated at 2022-06-24 13:21:33.777467
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:42.965714
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Test case 1
	ie = TruTVIE()
	assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
	#assert ie._TEST ==
	assert ie.IE_NAME == 'trutv'
	assert ie.IE_DESC == 'TruTV'
	#assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=%s'
	assert ie._

# Generated at 2022-06-24 13:21:53.149357
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    result = TruTVIE()
    assert result._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:55.305806
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.ie_key = 'TurnerBase'
    assert ie.ie_key == 'TurnerBase'


# Generated at 2022-06-24 13:21:59.075712
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:08.929295
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from ..jsinterp import JSInterpreter
    js_interp = JSInterpreter(open('test/turner.js').read())
    
    # Unit test TruTVIE to make sure that it is properly constructed. 
    r = TruTVIE("TruTVIE", "1")
    assert(r._VALID_URL==r"https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))")

# Generated at 2022-06-24 13:22:10.563130
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TrueTVIE.extract_info with extractors that do not provide IE_DESC
    True

# Generated at 2022-06-24 13:22:13.203277
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE("http://www.trutv.com/full-episodes/tosh.0/videos/kitten-climbing.html")
    assert trutvIE.url == "http://www.trutv.com/full-episodes/tosh.0/videos/kitten-climbing.html"

# Generated at 2022-06-24 13:22:17.979026
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE class."""
    trutv = TruTVIE()
    assert TruTVIE._VALID_URL == trutv._VALID_URL
    assert TruTVIE._TEST == trutv._TEST
    assert TruTVIE.__name__ == trutv.__class__.__name__
    assert TruTVIE.suite() == trutv._TEST.keys()

# Generated at 2022-06-24 13:22:18.674582
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    dl = TruTVIE()

# Generated at 2022-06-24 13:22:25.307398
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert re.match(trutv_ie._VALID_URL, trutv_ie._TEST['url'])
    assert trutv_ie._download_json(
        'https://api.trutv.com/v2/web/%s/%s/%s' % (
            'episode', 'the-carbonaro-effect', 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'),
        'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

# Generated at 2022-06-24 13:22:27.507198
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()(url)

# Generated at 2022-06-24 13:22:28.440312
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE')

# Generated at 2022-06-24 13:22:29.321552
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:22:40.217007
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-24 13:22:40.657669
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:41.526589
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True #TODO: implement your test here

# Generated at 2022-06-24 13:22:44.432154
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tc = TurnerBaseIE()
    ue = TruTVIE()
    #assert ue.tc is tc, 'TruTVIE constructor fails'


if __name__ == '__main__':
    import sys
    sys.exit(test_TruTVIE())

# Generated at 2022-06-24 13:22:45.272761
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()

# Generated at 2022-06-24 13:22:54.801365
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:57.491540
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    print("test_TruTVIE")
    print("TruTVIE: " + str(test_TruTVIE))


# Generated at 2022-06-24 13:23:02.902132
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    :return: none
    """
    # Print test case name
    print("\n--- start of test ---\n")

    # Constructor test
    print(" Constructor test")
    try:
        TruTVIE()
    except:
        assert False

    # Print results
    print("\n--- end of test ---\n")


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:23:04.085046
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE', 'TruTV')


# Generated at 2022-06-24 13:23:05.612735
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    assert(test_TruTVIE.__name__ == 'test_TruTVIE')

# Generated at 2022-06-24 13:23:15.543952
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_downloader_test = TruTVIE()
    assert (ttv_downloader_test._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))")

# Generated at 2022-06-24 13:23:16.785288
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:23:17.445321
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:23:20.506155
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SUCCESS == True

if __name__ == "__main__":
    # Unit test
    i = TruTVIE()

    video_url = i.extract(i._TEST['url'])['url']
    print(video_url)

# Generated at 2022-06-24 13:23:22.844768
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    TruTVIE("testTruTVIE")
    # Test TruTVIE constructor with an empty parameter
    TruTVIE("")

# Generated at 2022-06-24 13:23:25.295380
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert hasattr(trutv, '_VALID_URL')
    assert hasattr(trutv, '_TEST')


# Generated at 2022-06-24 13:23:26.619953
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:23:27.816784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE', True)



# Generated at 2022-06-24 13:23:28.887625
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_ie = TruTVIE()
    print("TruTVIE created")


# Generated at 2022-06-24 13:23:30.677451
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:23:32.388106
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing init of class")
    trutv = TruTVIE()
    assert trutv is not None



# Generated at 2022-06-24 13:23:35.436073
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ie  = TruTVIE()
	url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
	ie.extract(url)

# Generated at 2022-06-24 13:23:38.113825
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

    # Try the right type
    assert isinstance(obj, TruTVIE)

    # Try the right type
    assert isinstance(obj, TurnerBaseIE)

# Generated at 2022-06-24 13:23:43.478919
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import re
    test_case_first = TruTVIE._VALID_URL
    test_case_second = TruTVIE._TEST
    test_case_third = TruTVIE._real_extract
    assert isinstance(test_case_first, re.__class__)
    assert type(test_case_second) == dict
    assert type(test_case_third) == TruTVIE._real_extract.__class__

# Generated at 2022-06-24 13:23:44.001765
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TurnerBaseIE()

# Generated at 2022-06-24 13:23:44.523139
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:47.278055
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Run
    ie = TruTVIE()
    # Check
    assert ie._TEST['info_dict']['title'] == 'Sunlight-Activated Flower'

# Generated at 2022-06-24 13:23:50.911108
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE
    test_TruTVIE = TruTVIE._TEST
    url = test_TruTVIE['url']

    # Calling constructor of TruTVIE with url as argument
    ie = TruTVIE(url)
    # Calling _real_extract method of TruTVIE with url as argument
    ie.extract(url)

# Generated at 2022-06-24 13:24:00.909075
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_object = TruTVIE()
    test_result = test_object._VALID_URL
    
    assert test_result == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))', \
        'test of TruTVIE._VALID_URL failed'
    assert test_object._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', \
        'test of TruTVIE._TEST[\'url\'] failed'
    assert test_object._

# Generated at 2022-06-24 13:24:02.000652
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:24:05.644276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(_download_json=lambda *args, **kwargs: {}, _extract_ngtv_info=lambda *args, **kwargs: {})._real_extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:24:14.361712
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    result = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }


# Generated at 2022-06-24 13:24:16.085798
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor of class TruTVIE
    trutvIE = TruTVIE()
    print(trutvIE)


# Generated at 2022-06-24 13:24:27.082698
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'



# Generated at 2022-06-24 13:24:27.596927
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:29.421564
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    t.extract(TruTVIE._TEST.get('url'))

# Generated at 2022-06-24 13:24:30.926607
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test.unit_test()

# Generated at 2022-06-24 13:24:33.815444
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE(None)
    except ValueError:
        pass
    TruTVIE("http://a.b.c/d/e.f")

# Generated at 2022-06-24 13:24:37.797093
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE(url)
    trutv.extract()

# Generated at 2022-06-24 13:24:39.764787
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
	TruTVIE()._real_extract(url)

# Generated at 2022-06-24 13:24:40.572533
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:42.703510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE('s', 'e', 't')
    except Exception as e:
        print(e)


# Generated at 2022-06-24 13:24:43.255030
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:44.179349
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("url")

# Generated at 2022-06-24 13:24:50.177462
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE('turner:ngtv:f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    assert t._VALID_URL == TruTVIE._VALID_URL
    assert t._TEST['url'] == TruTVIE._TEST['url']
    assert t._TEST['info_dict'] == TruTVIE._TEST['info_dict']
    assert t._TEST['params'] == TruTVIE._TEST['params']

# Generated at 2022-06-24 13:24:51.660525
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make sure that the class can be constructed
    ie = TruTVIE()
    ie = TruTVIE(True)

# Generated at 2022-06-24 13:24:52.184371
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:56.731952
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:24:57.599439
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None, {})


# Generated at 2022-06-24 13:25:04.808505
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.ie_key() == 'turner:trutv'
    assert t.ie_url() == 'http://www.trutv.com/'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:09.353023
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:25:10.574761
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj is not None


# Generated at 2022-06-24 13:25:20.078902
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:20.683229
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:22.557274
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        vtr = TruTVIE()
        assert isinstance(vtr, TruTVIE)

# Generated at 2022-06-24 13:25:24.417013
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.IE_NAME == 'trutv'

# Generated at 2022-06-24 13:25:30.745979
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:40.597680
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # TruTVIE.ie_key = 'TruTV'
    assert ie.ie_key() == 'TruTV'
    # TruTVIE._VALID_URL = https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))

# Generated at 2022-06-24 13:25:43.510347
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    class TruTVIETest(unittest.TestCase):
        
        # Unit test for constructor
        def test_constructor(self):
            # Assert
            self.assertIsNotNone(TruTVIE())
    
    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-24 13:25:44.039140
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:51.021067
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE instance
    trutv_ie = TruTVIE()
    # Test the class name
    assert 'TruTVIE' == trutv_ie.IE_NAME
    # Test if the class is a subclass of TurnerBaseIE
    assert issubclass(TruTVIE, TurnerBaseIE)
    # Test if the class is a subclass of InfoExtractor
    # TODO: Need to find out why it fails
    # assert issubclass(TruTVIE, InfoExtractor)

# Generated at 2022-06-24 13:25:54.619891
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST["info_dict"]["url"] == TruTVIE._VALID_URL
    assert TruTVIE._TEST["info_dict"]["id"] == TruTVIE._TEST["url"]

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-24 13:26:02.819039
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert TruTVIE._VALID_URL =='https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE.ie_key() == 'trutv'
    assert ttv is not None

# Generated at 2022-06-24 13:26:13.273660
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE when video id is available
    test_video_id = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
    trutv = TruTVIE()
    trutv._downloader = DummyDownloader()
   

# Generated at 2022-06-24 13:26:17.852966
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    ttv.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    ttv.extract("https://www.trutv.com/full-episodes/129375/the-carbonaro-effect-season-1-episode-4-video.html")

# Generated at 2022-06-24 13:26:20.644784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._VALID_URL = TruTVIE._VALID_URL
    ie._TEST = TruTVIE._TEST
    ie._real_extract(TruTVIE._TEST['url'])

# Generated at 2022-06-24 13:26:26.653996
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:37.230682
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:26:37.847771
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:46.580623
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE."""

    # test TruTVIE.IE_NAME
    assert TruTVIE.IE_NAME == 'trutv'
    assert TruTVIE.IE_DESC == 'truTV'

    # test TruTVIE._VALID_URL pattern
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # test that it accepts valid URL
    TruTVIE._VALID_URL_regex.match(url)
    # test the match groups
    match = TruTVIE._VALID_URL_regex.match(url)
    assert match.group('series_slug') == 'the-carbonaro-effect'

# Generated at 2022-06-24 13:26:47.238494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:51.880137
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    #assert result.__dict__ == TruTVIE._TEST
    assert result.VALID_URL == TruTVIE._VALID_URL
    assert result.TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:26:54.143860
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for instantiation of class TruTVIE
    TruTVIE('test_instance', 'TruTVIE')

# Generated at 2022-06-24 13:26:56.785476
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        from ..utils import TestCase
        from .common import InfoExtractor

        class TruTVIETestCase(TestCase):
            IE = TruTVIE

            def test_TruTVIE(self):
                self.assertIsInstance(self.IE(InfoExtractor), TruTVIE)
    except ImportError as e:
        pass

# Generated at 2022-06-24 13:27:05.864548
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # We have to initialize a class for testing its methods
    trutv_ie = TruTVIE()

    # Testing TruTVIE._extract_ngtv_info method

# Generated at 2022-06-24 13:27:06.506002
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._TEST

# Generated at 2022-06-24 13:27:18.357650
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()
    assert m._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:24.651846
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru = TruTVIE()
    assert(tru.name == 'trutv:tv')
    assert(tru._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:27:25.963740
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    res = TruTVIE()
    print(res)
    assert res

# Generated at 2022-06-24 13:27:26.843532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Code should not throw exception
    TruTVIE()

# Generated at 2022-06-24 13:27:31.645003
# Unit test for constructor of class TruTVIE
def test_TruTVIE():


    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    IE = TruTVIE()
    video_info = IE._real_extract(url)

# Generated at 2022-06-24 13:27:32.255938
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:34.735290
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test case for TruTVIE.py"""

    site = TruTVIE()
    assert "TruTVIE" in str(type(site))

# Generated at 2022-06-24 13:27:44.743919
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Basic test to check class constructor
    """
    t = TruTVIE()

    assert t.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    assert t.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower') == True
    assert t.suitable('https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/season-5/episode-5/the-carbonaro-effect-season-5-episode-5.html') == True

# Generated at 2022-06-24 13:27:45.397649
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == "trutv"

# Generated at 2022-06-24 13:27:45.850741
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:52.371965
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html');
    assert trutv.get_site_name() == 'truTV'
    assert trutv.get_media_id() == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1';
    assert trutv.get_url() == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html';
    assert trutv.get_title() == 'Sunlight-Activated Flower';
    assert trutv.get_description() == "A customer is stunned when he sees Michael's sunlight-activated flower.";

# Generated at 2022-06-24 13:27:57.585862
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Successful construction of the object
    t = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html" == t.url


# Generated at 2022-06-24 13:28:08.401977
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import sys
    import unittest
    from .test_downloader import _FakeYDL
    from .test_downloader import FakeYDL
    from .test_downloader import _make_result

    # Override constructor of class TruTVIE
    class TestTruTVIE(TruTVIE):
        def __init__(self, ydl):
            self.ydl = ydl

    # Override constructor of class TruTVIE.TruTVIE
    class TestTruTVIE_TruTVIE(TruTVIE):
        def __init__(self, ydl):
            TruTVIE.__init__(self, ydl)

    # Override constructor of class TruTVIE.TruTVIE.TurnerBaseIE

# Generated at 2022-06-24 13:28:09.121689
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:10.448845
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE();
    assert(x != None)

# Generated at 2022-06-24 13:28:17.580671
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    return TruTVIE().suitable(url)
# test_TruTVIE()

# Constructor of class TruTVIE
ie = TruTVIE()
# ie

# Test method _real_extract of class TruTVIE
url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
display_id = 'sunlight-activated-flower'
if ie.suitable(url):
    info = ie._real_extract(url)
    print(info)
# info

# Test download

# Generated at 2022-06-24 13:28:18.502166
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 13:28:27.605063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert ie.IE_DESC == 'Turner TV Networks'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:29.148037
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    print(t)

# Unit test

# Generated at 2022-06-24 13:28:38.055476
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    trutvIE = TruTVIE()
    assert trutvIE._VALID_URL ==\
        r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:39.726499
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a is not None


# Generated at 2022-06-24 13:28:47.836957
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test case for parameter 'url'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # test case for parameter '_TEST'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

