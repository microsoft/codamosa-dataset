

# Generated at 2022-06-24 13:18:53.136404
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
        Unit test for constructor of class TruTVIE
        The purpose of this test is to make sure a TruTVIE object was constructed correctly
    """
    trutvIE = TruTVIE()

    assert trutvIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutvIE.IE_NAME == 'trutv'
    assert trutvIE.IE_DESC == 'truTV'

# Generated at 2022-06-24 13:19:01.787885
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_test = TruTVIE()
    assert trutv_test._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv_test._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:19:10.898713
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Test TruTVIE constructor
    '''
    # Test with a valid URL
    ttv = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Check if type is correct
    try:
        assert isinstance(ttv, TruTVIE)
    # If not, print error message
    except AssertionError:
        print('ttv is not an instance of TruTVIE')
    # Test with an invalid URL
    ttv2 = TruTVIE('this is not a valid url')
    # Check if type is correct

# Generated at 2022-06-24 13:19:11.433285
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:21.746610
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    from ..utils import TestCase
    from .common import FakeTestCase
    from .ccztv import CCZTVIE

    class TruTVTestCase(TestCase, FakeTestCase):
        server_url = 'http://localhost:8383/'
        def test_TruTVIE(self):
            self.assertEqual(
                TruTVIE._VALID_URL,
                'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))')

    unittest.main(argv=[''])



# Generated at 2022-06-24 13:19:24.146843
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:19:25.147834
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:19:26.657463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test TruTVIE's constructor
    TruTVIE(TruTVIE.create_geo_verification_proxy({}))

# Generated at 2022-06-24 13:19:27.389758
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TODO
    pass

# Generated at 2022-06-24 13:19:28.630302
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TurnerBaseIE._build_ngtv_config('TruTV')

# Generated at 2022-06-24 13:19:29.140456
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:30.588160
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE({})
    assert isinstance(i, TruTVIE)

# Generated at 2022-06-24 13:19:33.285421
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('http://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:19:34.945355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().to_screen("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:19:35.809501
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-24 13:19:36.271628
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:37.166889
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('', '')

# Generated at 2022-06-24 13:19:37.638592
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-24 13:19:40.249629
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_webpage("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:19:42.520549
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru = TruTVIE()
    output = "TruTVIE"
    assert tru.ie_key() == output


# Generated at 2022-06-24 13:19:43.421279
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	obj = TruTVIE()
	assert obj is not None

# Generated at 2022-06-24 13:19:45.541702
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Create TruTVIE object to be tested.
    """
    TruTVIE_obj = TruTVIE()

# Generated at 2022-06-24 13:19:47.389974
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        assert True
    except:
        assert False

# Generated at 2022-06-24 13:19:55.652787
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert TruTVIE._VALID_URL == TruTVIE._TEST['url']
    assert TruTVIE._TEST['info_dict']['id'] == TruTVIE._TEST['info_dict']['id']
    assert TruTVIE._TEST['info_dict']['ext'] == TruTVIE._TEST['info_dict']['ext']
    assert TruTVIE._TEST['info_dict']['title'] == TruTVIE._TEST['info_dict']['title']
    assert TruTVIE._TEST['info_dict']['description'] == TruTVIE._TEST['info_dict']['description']

# Generated at 2022-06-24 13:20:06.787158
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from pyquery import PyQuery

    # TruTVIE with valid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    urlMatch = re.match(TruTVIE._VALID_URL, url)
    assert urlMatch

    # TruTVIE with invalid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower'
    urlMatch = re.match(TruTVIE._VALID_URL, url)
    assert not urlMatch

    # Should raise ExtractorError for unsupported url
    from youtube_dl import ExtractorError

# Generated at 2022-06-24 13:20:07.993701
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ttvIE = TruTVIE()
	assert ttvIE is not None

# Generated at 2022-06-24 13:20:10.404448
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert(trutv_ie.ie_key() == "trutv")
    assert(trutv_ie.ie_name() == "truTV")

# Generated at 2022-06-24 13:20:19.799437
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/45891-the-carbonaro-effect-beer-goggles.html')
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/45891-the-carbonaro-effect-beer-goggles.html')

# Generated at 2022-06-24 13:20:26.984632
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # test url is valid, using url_result
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    result = TruTVIE._url_result(url)
    assert result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

    # test url is invalid, using url_result
    url = 'https://www.trutv.com/shows/the-carbonaro-effect.html'
    result = TruTVIE._url_result(url)
    assert result is None

# Generated at 2022-06-24 13:20:27.489119
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:37.571176
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    t.ie_key='truTV'
    t.ie_name='truTV'
    t.ie_id='trutv'
    t._html_search_regex='[^<]*'
    t.NEXTONE_VOD_URL='https://api.trutv.com/v2/web/episode/%s'
    t.NEXTONE_INFO_URL='http://content.uplynk.com/channel/%s.%s.json'
    t.TBS_VOD_URL='http://link.theplatform.com/s/NnzsPC/media/guid/%s?format=SMIL&Tracking=true&Embedded=true'

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:20:38.184292
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:40.384593
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:20:45.848959
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:20:57.182278
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # NOTE - TruTV has password-protected videos.
    # Video is loaded from API but then a player error is shown:
    # 'This video is only available for authenticated users.'
    # Also, API response contains 'isAuthRequired': True
    trutvIE = TruTVIE()
    assert trutvIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:20:59.550156
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().extract_info_from_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:21:05.652070
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.ie_key()=='TruTV'
    assert trutv_ie.ie_name()=='TruTV'
    assert trutv_ie._VALID_URL==r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:06.229627
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:08.583533
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert "TruTVIE" in str(trutv_ie)


# Generated at 2022-06-24 13:21:09.463771
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE.__name__ == "TruTVIE"

# Generated at 2022-06-24 13:21:17.719923
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE(TurnerBaseIE._build_downloader({}))
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:18.147840
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:21.777966
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.name == 'trutv'
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:22.273324
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:22.768050
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:23.707301
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	pass


# Generated at 2022-06-24 13:21:24.479920
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:21:35.458254
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Basic tests
    main_test_cases = [
        # Basic test with valid URL
        {
            'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
        }
    ]

    for test_case in main_test_cases:
        yield TruTVIE._test_base, test_case


# Generated at 2022-06-24 13:21:37.677494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(TestCase(), TruTVIE._TEST['url'])



# Generated at 2022-06-24 13:21:38.095615
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:42.700658
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create new instance of TruTVIE class
    trutvIE = TruTVIE()
    # Assert if value being returned is a string
    assert isinstance(trutvIE.IE_NAME, str)
    # Assert if value being returned is a string
    assert isinstance(trutvIE._VALID_URL, str)
    # Assert if value being returned is a string
    assert isinstance(trutvIE._TEST, dict)

# Generated at 2022-06-24 13:21:43.521937
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None;


# Generated at 2022-06-24 13:21:53.063967
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    TruTVIE._TEST = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
    return

# Generated at 2022-06-24 13:21:59.065516
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance
    trutv = TruTVIE()

    # Check if url is valid for TruTVIE
    testurl = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert TruTVIE._VALID_URL == trutv._match_id(testurl)[0]
    # Check for extractor functions
    assert TruTVIE._TEST['url'] == TruTVIE._TEST['url']
    assert TruTVIE._TEST['info_dict'] == TruTVIE._TEST['info_dict']

# Generated at 2022-06-24 13:22:01.008717
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TruTVIE", "TruTV")
    
# Test for method _real_extract of class TruTVIE

# Generated at 2022-06-24 13:22:06.829214
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.ie_key() == 'truTV'
    assert TruTVIE.ie_key() in TruTVIE.suitable()
    assert TruTVIE.suitable()['truTV']
    assert TruTVIE(TruTVIE.ie_key()).extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:16.333067
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    module = TruTVIE
    instance = TruTVIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert instance._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:22:20.028749
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.suitable('https://www.trutv.com/full-episodes/2808517/the-carbonaro-effect-episode-301.html')

# Generated at 2022-06-24 13:22:20.925673
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:22.223401
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE(TurnerBaseIE._downloader)
    print(trutv)

# Generated at 2022-06-24 13:22:27.436808
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Given URL
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # When
    trutvIE = TruTVIE(url)
    # Then
    assert(trutvIE.name == 'trutv.com')
    assert(trutvIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(len(trutvIE._TESTS) == 1)


# Generated at 2022-06-24 13:22:31.951671
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Return the singleton instance. If 'cls' is a derived class, the
    # correct instance is created.
    test = TruTVIE.get_info(None, {})
    assert test.name == 'truTV'
    assert test.number == 4
    assert test.color == '000'



# Generated at 2022-06-24 13:22:42.195192
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.valid_url("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") == True
    assert trutv.valid_url("https://www.trutv.com/shows/mexicos-toughest-prisons/videos/mexicos-toughest-prisons-s1-e1.html") == True
    assert trutv.valid_url("https://www.trutv.com/shows/the-carbonaro-effect/videos/the-carbonaro-effect-s01-e02-video.html") == True

# Generated at 2022-06-24 13:22:43.392174
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == "TruTVIE"



# Generated at 2022-06-24 13:22:52.444960
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:52.852559
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:53.368031
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:53.873408
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:58.638163
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    trutv = TruTVIE()
    #Test the constructor of class TruTVIE
    assert(TruTVIE._VALID_URL == trutv._VALID_URL), "TruTVIE is not initialized"
    assert(TruTVIE._TEST == trutv._TEST), "TruTVIE is not initialized"
    assert(TruTVIE.IE_NAME == trutv.IE_NAME), "TruTVIE is not initialized"
    assert(TruTVIE.IE_DESC == trutv.IE_DESC), "TruTVIE is not initialized"

# Generated at 2022-06-24 13:22:59.364777
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:01.574161
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        ttvie = TruTVIE();
        assert(True)
    except:
        print("TruTVIE class not implemented")
        assert(False)

# Generated at 2022-06-24 13:23:02.107199
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:11.239318
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV_ie = TruTVIE()
    url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    video_id='f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    media_id='f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    series_slug='the-carbonaro-effect'
    clip_slug='sunlight-activated-flower'
    # Test url

# Generated at 2022-06-24 13:23:12.759289
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check that the correct class is being constructed
    assert TruTVIE is True

# Generated at 2022-06-24 13:23:14.553807
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert isinstance(trutvIE, TruTVIE)

# Generated at 2022-06-24 13:23:17.321713
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .turner import TurnerBaseIE
    from .common import InfoExtractor
    assert issubclass(TruTVIE, TurnerBaseIE)
    assert issubclass(TruTVIE, InfoExtractor)

# Generated at 2022-06-24 13:23:19.786659
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiates an TruTVIE object
    ie = TruTVIE()
    # Verifies that the test url is valid
    assert re.match(ie._VALID_URL, ie._TEST['url'])


# Generated at 2022-06-24 13:23:29.196999
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case 1:
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    extracted_info = TruTVIE().extract(url)
    assert extracted_info['id'] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    assert extracted_info['display_id'] == "sunlight-activated-flower"
    assert extracted_info['title'] == "Sunlight-Activated Flower"
    assert extracted_info['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert extracted_info['series'] == "The Carbonaro Effect"
    assert extracted_info['season_number'] == 1

# Generated at 2022-06-24 13:23:32.902106
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert 1==1
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:34.209633
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    inst = TruTVIE()
    assert inst


# Generated at 2022-06-24 13:23:35.165955
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-24 13:23:45.020772
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE Constructor"""
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:53.245846
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.extractor_key == 'truTV'
    assert t.ie_key == 'trutv.com'
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:54.091014
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()

# Generated at 2022-06-24 13:23:58.265863
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE(TruTVIE.get_suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
    except TypeError:
        raise TypeError
    else:
        return True

# Generated at 2022-06-24 13:24:00.363956
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:24:01.335080
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('test')

# Generated at 2022-06-24 13:24:09.403422
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    example = TruTVIE(_test_downloader)
    _test_case = example._TEST['url']
    _test_result = True
    _msg = ''
    try:
        assert example._VALID_URL == TruTVIE._VALID_URL
        assert example._TEST == TruTVIE._TEST
        assert example._downloader == _test_downloader
        assert example._real_extract == TruTVIE._real_extract
    except AssertionError as e:
        _test_result = False
        _msg = str(e)
    finally:
        _result = {
            'test_case': _test_case,
            'test_result': _test_result,
            'msg': _msg,
            'extractor': 'TruTV'
        }
        return _result

# Generated at 2022-06-24 13:24:17.976306
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test TruTVIE class constructor
    s = TruTVIE()
    s = TruTVIE('trutv')
    s = TruTVIE(None)
    s = TruTVIE(None, 'trutv')
    s = TruTVIE(url='www.trutv.com')
    s = TruTVIE(url='www.trutv.com', video_id='trutv')
    s = TruTVIE('trutv', url='www.trutv.com', video_id='trutv')

    # Test TruTVIE class constructor with error
    try:
        s = TruTVIE(url=None)
    except Exception as e:
        assert isinstance(e, TypeError)


# Generated at 2022-06-24 13:24:19.232978
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	print( TruTVIE.__doc__);

# Generated at 2022-06-24 13:24:22.657736
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    _TruTV_test = TruTVIE(TruTVIE._TEST['url'])
    assert _TruTV_test._VALID_URL == TruTVIE._TEST['url']

# Generated at 2022-06-24 13:24:24.116274
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE('test_TruTVIE')
    assert(t != None)

# Generated at 2022-06-24 13:24:31.755690
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    # Instantiate class TruTVIE
    trutvie = TruTVIE()
    # trutvie.Trutv.com/shows/how-to-be-a-grownup/videos
    assert trutvie.suitable('http://www.trutv.com/shows/how-to-be-a-grownup/videos') is True
    # trutvie.trutv.com/full-episodes/how-to-be-a-grownup
    assert trutvie.suitable('http://www.trutv.com/full-episodes/how-to-be-a-grownup') is True
    # trutvie.trutv.com/videos/storage-wars/the-bully.html
   

# Generated at 2022-06-24 13:24:32.465971
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:38.646204
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	prog = "TruTVIE"
	progClass = TruTVIE
	url = "https://www.trutv.com/shows/impractical-jokers/videos/inside-jokes-dumber-dumbbells.html"
	TruTVIE.unitTest(prog, progClass, url);

if __name__ == '__main__':
	test_TruTVIE()

# Generated at 2022-06-24 13:24:42.228024
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    _TEST = {
        'url': 'https://www.trutv.com/full-episodes/13481/The-Carbonaro-Effect-Ep-301-Sunlight-Activated-Flower.html'
    }
    a = TruTVIE()

# Generated at 2022-06-24 13:24:42.814600
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:48.118356
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import logging

    # Disable embedded HTTP server logging
    logging.getLogger('werkzeug').setLevel(logging.ERROR)

    # Init YouTubeIE instance
    test_inst = TruTVIE()
    assert test_inst

    # Test TruTVIE constructor
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-24 13:24:49.761041
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check if TruTVIE class can be initialized
    assert TruTVIE('TruTVIE','TruTVIE')

# Generated at 2022-06-24 13:24:56.073844
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_webpage('http://www.trutv.com', 'tested_obj')
    assert TruTVIE()._download_webpage.called
    TruTVIE()._download_json('http://www.trutv.com', 'tested_obj')
    assert TruTVIE()._download_json.called
    TruTVIE()._extract_ngtv_info('http://www.trutv.com', {}, {})
    assert TruTVIE()._extract_ngtv_info.called
    TruTVIE()._real_extract('http://www.trutv.com')
    assert TruTVIE()._real_extract.called

# Generated at 2022-06-24 13:25:05.718614
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_ie = TruTVIE({'url': 'https://www.trutv.com/full-episodes/impractical-jokers/videos/scaredy-cat-scare.html'})
    assert ttv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:16.417931
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Constructor unit test for class TruTVIE
    """
    # Should pass for all these urls

# Generated at 2022-06-24 13:25:17.708841
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()
    assert(truTVIE is not None)

# Generated at 2022-06-24 13:25:28.149423
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:37.848409
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor of class TruTVIE
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url = TruTVIE._VALID_URL
    assert re.match(url, test_url)
    test_series_slug, test_clip_slug, test_video_id = re.match(
        url, test_url).groups()
    assert test_series_slug == 'the-carbonaro-effect'
    assert test_clip_slug == 'sunlight-activated-flower'
    assert test_video_id is None
    assert TruTVIE._TEST['url'] is test_url
    assert TruTVIE._TEST['info_dict']['id'] is not None

# Generated at 2022-06-24 13:25:40.546660
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Verify test TruTVIE._TEST with TruTVIE._VALID_URL
    obj = TruTVIE('test')
    assert(obj._TEST == TruTVIE._TEST)

# Generated at 2022-06-24 13:25:41.969261
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:25:42.747550
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TODO: implement this test
    TruTVIE()

# Generated at 2022-06-24 13:25:43.793247
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTV constructor"""
    return TruTVIE

# Generated at 2022-06-24 13:25:50.053555
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE class with url values and validations
    url = "http://www.trutv.com/shows/the-carbonaro-effect"
    obj = TruTVIE()
    assert obj._VALID_URL == TruTVIE._VALID_URL
    assert obj._TEST == TruTVIE._TEST
    assert obj._real_extract(url) == TruTVIE._real_extract(url)

# Generated at 2022-06-24 13:25:50.655065
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-24 13:25:57.529159
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:07.417333
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE
    # Check URL is valid
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._VALID_URL == url

    # Check if data is valid
    # test_TruTVIE.py:14: error: {'series_slug': 'the-carbonaro-effect', 'clip_slug': 'sunlight-activated-flower', 'id': None} != {'clip_slug': 'sunlight-activated-flower', 'id': None, 'series_slug': 'the-carbonaro-effect'}
    assert TruTVIE._TEST['url'] == url

# Generated at 2022-06-24 13:26:08.846682
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """TruTVIE constructor test."""
    TruTVIE()


# Generated at 2022-06-24 13:26:14.576479
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    truTv = TruTVIE()
    truTv.suitable(url)
    #truTv.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:26:20.383279
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/full-episodes/2763/jailbait/episode-1.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/jailbait/videos/in-da-house/episode-1.html')

# Generated at 2022-06-24 13:26:31.956654
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test main constructor
    test_TruTVIE = TruTVIE()

    assert(test_TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(test_TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:26:32.831706
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-24 13:26:35.433114
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    if trutv:
        print ('TruTVIE constructed successfully')
    else:
        print ('Failed to construct TruTVIE')

# Generated at 2022-06-24 13:26:44.822997
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE();
    assert(t.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == {'_type': 'url_transparent', 'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'display_id': 'sunlight-activated-flower', 'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'title': 'Sunlight-Activated Flower', 'description': "A customer is stunned when he sees Michael's sunlight-activated flower."})

# Generated at 2022-06-24 13:26:47.398521
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:26:57.931118
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Class variable TIMESTAMP_RE in TruTVIE has a bug, it should start with r'\d{4}-\d{2}-\d{2}'
    TruTVIE.TIMESTAMP_RE = r'\d{4}-\d{2}-\d{2}'
    # Class variable _VALID_URL in TruTVIE is not valid in Python 3.4,
    # replace the r'(?P<id>\d+)' with r'(?P<id>\d+)' or r'(?P<id>\d+)'

# Generated at 2022-06-24 13:26:58.471706
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:01.751152
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_ie = TruTVIE()
    ttv_ie.get_info(True)
    ttv_ie.get_info(True, True)
    ttv_ie.get_info(True, True, True)

# Generated at 2022-06-24 13:27:02.626920
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE_obj = TruTVIE()

# Generated at 2022-06-24 13:27:03.176506
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:08.721883
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor of class TruTVIE
    # Check object TruTVIE has the right attributes
    TruTVIE_test = TruTVIE()
    assert TruTVIE_test._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:19.751856
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/1739')
    assert ie.suitable('https://www.trutv.com/full-episodes/the-carbonaro-effect/1739')
    assert ie.suitable('https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/')

# Generated at 2022-06-24 13:27:21.234393
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE_test = TruTVIE()

# Generated at 2022-06-24 13:27:22.650336
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'

# Generated at 2022-06-24 13:27:25.196138
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    h = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert h.ie == 'Turner'

# Generated at 2022-06-24 13:27:35.407183
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Test 1
	try:
		object = TruTVIE()
	except:
		print("Error in creating object of class TruTVIE")
		assert(False)
	print("Created object successfully")
	assert(True)
	
	# Test 2
	try:
		object = TruTVIE(url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
	except:
		print("Error in creating object of class TruTVIE")
		assert(False)
	print("Created object successfully")
	assert(True)
	
	# Test 3
	try:
		object = TruTVIE(url = "abcd")
	except:
		print("Error in creating object of class TruTVIE")

# Generated at 2022-06-24 13:27:36.345455
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE() == TruTVIE

# Generated at 2022-06-24 13:27:46.288745
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for TruTVIE"""
    # HTTP test page contains an odd mix of valid, invalid, and duplicate URLs
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    # Assert that the TruTVIE constructor returns an instance of the TruTVIE class
    assert isinstance(trutv_ie, TruTVIE)
    expected_result = ('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'mp4', 'Sunlight-Activated Flower', "A customer is stunned when he sees Michael's sunlight-activated flower.")
    test_result = trutv_ie._real_extract(url)

# Generated at 2022-06-24 13:27:52.240068
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Construct test object
    trutv_obj = TruTVIE()
    # Run some tests
    print ('Testing TruTVIE...')
    assert hasattr(trutv_obj, '_download_json')
    assert hasattr(trutv_obj, '_extract_urls')
    assert hasattr(trutv_obj, '_extract_ngtv_info')
    print ('It seems to be Ok!')

# Generated at 2022-06-24 13:27:53.017412
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:57.021544
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE class constructor goes through without an error
    """
    try:
        # Initialize the TruTVIE class
        TruTVIE()
    except Exception as inst:
        assert False, inst
    else:
        assert True


# Generated at 2022-06-24 13:28:00.612628
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create instance
    ttv = TruTVIE()
    # Check if TruTVIE is subclass of TurnerBaseIE
    assert ttv.__class__.__bases__[0].__name__ == TurnerBaseIE.__name__

# Generated at 2022-06-24 13:28:11.451907
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE();
    info = t._extract_ngtv_info('bTbycjw2E6GzfMyhRxSDx4', {}, {'url': 'http://www.trutv.com/video/nba-on-tnt/last-two-minutes-report-game-1-cavaliers-vs-pacers.html', 'site_name': 'truTV'});
    assert info['id'] == 'bTbycjw2E6GzfMyhRxSDx4'
    assert info['display_id'] == 'last-two-minutes-report-game-1-cavaliers-vs-pacers'
    assert info['title'] == 'Last Two Minutes Report: Game 1 Cavaliers vs Pacers'

# Generated at 2022-06-24 13:28:20.895484
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for TruTVIE
    """
    # Initializing test data
    item = {
        '_type': 'url_transparent',
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'ie_key': 'TruTV',
    }
    # Initializing TruTVIE object
    trutv_class = TruTVIE()
    # Testing extract method of class TruTVIE
    trutv_class.extract(item)
    # Checking the value of TruTVIE.extract method
    assert True == trutv_class.extract(item)

# Generated at 2022-06-24 13:28:22.952799
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for constructor of class TruTVIE
    ie = TruTVIE()
    assert ie.get_creator() == ie.__class__.__name__

# Generated at 2022-06-24 13:28:31.710047
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url = 'http://www.trutv.com/shows/carbonaro-effect/videos/what-the-deal-with-pizza/index.html'
    #url = 'https://www.trutv.com/shows/tacoma-fd/videos/1.html?playlistId=tacoma-fd'
    ie = TruTVIE()
    ie_result = ie.extract(url)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:28:39.597830
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test TruTVIE._real_extract()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    data = ie._real_extract(url)
    print(data)

# Generated at 2022-06-24 13:28:40.813450
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE()


# Generated at 2022-06-24 13:28:49.412431
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'