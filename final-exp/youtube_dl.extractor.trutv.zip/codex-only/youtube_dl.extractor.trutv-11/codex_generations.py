

# Generated at 2022-06-24 13:18:40.509098
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()

# Generated at 2022-06-24 13:18:43.668360
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE class constructor
    """
    url = TruTVIE._TEST['url']
    url_obj = TruTVIE._TEST['url_obj']
    ie = TruTVIE._TEST['ie']
    assert isinstance(url, basestring)
    assert isinstance(url_obj, urlparse.ParseResult)
    assert isinstance(ie, TruTVIE)


# Generated at 2022-06-24 13:18:46.612496
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.download('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') # Test download of TruTV.com clips
    ie.download('https://www.trutv.com/full-episodes/5273529/the-carbonaro-effect-sunlight-activated-flower.html') # Test download of TruTV.com full episodes

# Generated at 2022-06-24 13:18:47.279574
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:49.553954
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tt = TruTVIE(TurnerBaseIE.__name__, TurnerBaseIE.valid_url)
    tt.suitable('url')

# Generated at 2022-06-24 13:18:50.162203
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:18:50.771056
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:51.421455
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:55.080143
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')['title']=='Sunlight-Activated Flower'

# Generated at 2022-06-24 13:19:03.097913
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:11.863352
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html";
    trutvIE = TruTVIE();
    result = trutvIE._real_extract(url);
    assert result['id'] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1";
    assert result['display_id'] == "sunlight-activated-flower";
    assert result['title'] == "Sunlight-Activated Flower";
    assert result['description'] == u"A customer is stunned when he sees Michael's sunlight-activated flower.";
    assert result['series'] == "The Carbonaro Effect";
    assert result['season_number'] == 0;
    assert result['episode_number'] == 0;

# Generated at 2022-06-24 13:19:12.420539
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:23.383310
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    t = TruTVIE()
    assert t != None

    # valid URL
    turl = 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    t._download_json = lambda url, display_id, fatal=True: str(url)
    t._extract_ngtv_info = lambda media_id, info, context: {'url':url, 'test':'test'}
    assert t.suitable(turl)
    tinfo = t._real_extract(turl)
    assert tinfo['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert tinfo['url'] == turl
    assert tinfo['test'] == 'test'



# Generated at 2022-06-24 13:19:24.149179
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:24.725707
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert(TruTVIE)

# Generated at 2022-06-24 13:19:28.268784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Given
    # test_TruTVIE is a test to check if TruTVIE is correctly related with a url
    

    # When
    TruTVIE()

    # Then
    # see if the tested class exists
    # see if the tested class has a constructor



# Generated at 2022-06-24 13:19:29.857836
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check if the class constructor works properly
    try:
        TruTVIE()
    except Exception:
        assert False

# Generated at 2022-06-24 13:19:32.227501
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE()
    assert test_obj._VALID_URL == TruTVIE._VALID_URL
    assert test_obj._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:19:37.159079
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

    obj = TruTVIE()
    result = obj._real_extract(url)
    assert result['id'] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"

# Generated at 2022-06-24 13:19:41.451313
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert len(TruTVIE._TESTS) == 1

# Generated at 2022-06-24 13:19:45.443465
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make sure that the constructor of TruTVIE doesn't error
    assert TruTVIE(TruTVIE()) is not None
    # Make sure that the constructor doesn't error out when creating a TruTVIE that isn't actually an TruTVIE
    assert TruTVIE({}) is not None

# Generated at 2022-06-24 13:19:46.783139
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an object of TruTVIE
    TruTVIE(None)

# Generated at 2022-06-24 13:19:47.908271
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:48.654881
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:52.780368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    w = TruTVIE()._TEST
    result = TruTVIE()._real_extract(url)
    for key in w.keys():
        if key not in {'url', 'info_dict'}:
            assert result[key] == w[key]
    for key in w['info_dict'].keys():
        assert result['info_dict'][key] == w['info_dict'][key]
test_TruTVIE()

# Generated at 2022-06-24 13:19:53.598856
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()

# Generated at 2022-06-24 13:19:57.151510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
  trutvIE = TruTVIE()
  assert(trutvIE._match_id(url) == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
  assert(trutvIE._match_id('nothing') == None)

# Generated at 2022-06-24 13:19:58.234916
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('videoId')

# Generated at 2022-06-24 13:19:59.801439
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Just to run constructor ...
    TruTVIE()
    return True

# Generated at 2022-06-24 13:20:00.591052
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-24 13:20:01.237113
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:20:06.252180
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    expected = "TruTVIE"
    actual = TruTVIE._VALID_URL
    assert expected in actual
    expected = TruTVIE._TEST['url']
    actual = test_url
    assert expected == actual

# Generated at 2022-06-24 13:20:06.832483
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:08.035703
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        return False

    return True

# Generated at 2022-06-24 13:20:14.891184
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.IE_NAME == 'TruTV'
    assert t.IE_DESC == 'truTV video'
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert t._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:20:17.392758
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.__class__ == TruTVIE


# Generated at 2022-06-24 13:20:17.809299
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:18.411814
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:19.005132
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() != None

# Generated at 2022-06-24 13:20:20.520112
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:20:21.319450
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:23.341038
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .trutv import TruTVIE
    deprecation_message = TruTVIE()
    assert deprecation_message == __doc__

# Generated at 2022-06-24 13:20:23.915574
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:29.916480
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:20:33.310147
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Test case 1
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    referer = 'https://www.trutv.com/watch/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()._download_webpage(url, None, headers = {'Referer': referer})

# Generated at 2022-06-24 13:20:37.257106
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test script for TruTVIE
    url_test = "http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test = TruTVIE()
    test._extract(url_test)

# Generated at 2022-06-24 13:20:47.441007
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/full-episodes/the-gravy-train-with-todd-lubar/videos/episode-108.htmlhttps://www.trutv.com/shows/full-episodes/the-gravy-train-with-todd-lubar/videos/episode-108.html"
    trutv = TruTVIE()
    assert(str(trutv) == "class TruTVIE - subclass of (class IE)")
    assert(trutv.suitable(url) == True)
    assert(trutv.IE_NAME == 'trutv:trutv')
    assert(trutv.IE_DESC == 'TruTV')

# Generated at 2022-06-24 13:20:49.153280
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert False
    assert True

# Generated at 2022-06-24 13:20:54.351369
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ tests the TruTVIE class from trutv.py
    """
    from .devtests.test_turner import run_constructor_test
    run_constructor_test(TruTVIE, [
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ])

# Generated at 2022-06-24 13:20:56.665615
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)

# Test for TruTVIE.suitable()

# Generated at 2022-06-24 13:21:03.133388
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # It should be okay to call its constructor with an empty argument
    trutv_instance = TruTVIE()
    assert(trutv_instance._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

    # Call its _real_extract function with a valid URL
    results = trutv_instance._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert('id' in results)

# Generated at 2022-06-24 13:21:06.657565
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except ReferenceError as e:
        print("NOK - TruTVIE is not defined: ", e)
    else:
        print("OK - TruTVIE is defined.")

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:21:07.731561
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("test")


# Generated at 2022-06-24 13:21:10.695925
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Example: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    assert TruTVIE.test(TruTVIE._TEST)

# Generated at 2022-06-24 13:21:11.217892
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:12.445827
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert hasattr(instance, "base_url")

# Generated at 2022-06-24 13:21:18.786332
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert ie.suitable("https://www.trutv.com/full-episodes/834/the-carbonaro-effect-hot-property/index.html")
    assert not ie.suitable("https://www.trutv.com/clips/the-carbonaro-effect-hot-property/index.html")
    assert not ie.suitable("https://www.trutv.com/shows/the-carbonaro-effect/index.html")

# Generated at 2022-06-24 13:21:27.268638
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    input = {'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'info_dict':{'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'ext': 'mp4', 'title': 'Sunlight-Activated Flower', 'description': "A customer is stunned when he sees Michael's sunlight-activated flower."}, 'params':{'skip_download': True}}
    test_TruTVIE = TruTVIE(input)
    assert test_TruTVIE.url == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:21:30.081667
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    implet = TruTVIE()
    assert implet.suitable("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert not implet.suitable("NOT IS VALID URL")
    assert implet.IE_NAME == 'trutv:video'
    assert implet.IE_DESC == 'Turner Broadcasting video services'

# Generated at 2022-06-24 13:21:30.867049
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:31.490822
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:35.646264
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._VALID_URL == url
    o = TruTVIE(url)
    assert isinstance(o, TruTVIE)

# Generated at 2022-06-24 13:21:43.911265
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    file_name_1 = './local_files/trutv_clip.mp4'
    file_name_2 = './local_files/trutv_episode.mp4'
    file_name_3 = './local_files/trutv_auth_required.mp4'

    # Check TruTVIE constructor
    trutv_ie_1 = TruTVIE()
    trutv_ie_2 = TruTVIE()
    trutv_ie_3 = TruTVIE()

    # Validate TruTVIE
    trutv_ie_1.url_result(file_name_1)
    trutv_ie_2.url_result(file_name_2)
    trutv_ie_3.url_result(file_name_3)

    # Print TruTVIE

# Generated at 2022-06-24 13:21:46.945243
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for constructor of class TruTVIE
    obj = TruTVIE()
    # If no exception is thrown all is good
    print('Unit test for constructor of class TruTVIE: pass')


# Generated at 2022-06-24 13:21:47.538286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:48.995945
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    # Dummy test to see if TruTVIE is initialized
    assert (test_TruTVIE != None)

# Unit test TruTVIE.extract

# Generated at 2022-06-24 13:21:51.504678
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_object = TruTVIE()
    assert 'TruTVIE' == type(test_object).__name__


# Generated at 2022-06-24 13:21:53.859947
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_constructor = TruTVIE('dummy_value')
    assert trutv_constructor.turner_base_ie == 'dummy_value'

# Generated at 2022-06-24 13:21:56.400733
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE constructor
    """

    assert TruTVIE._TEST['info_dict'] == TruTVIE()._real_extract(TruTVIE._TEST['url'])

# Generated at 2022-06-24 13:21:57.424833
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert (t is not None)

# Generated at 2022-06-24 13:22:03.017543
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test_TruTVIE.assertEqual(test._VALID_URL, r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    

# Generated at 2022-06-24 13:22:12.573683
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    input_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    data_test = TruTVIE(({'url': input_url},) )._extract(input_url)

    assert data_test['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert data_test['ext'] == 'mp4'
    assert data_test['title'] == 'Sunlight-Activated Flower'
    assert data_test['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert data_test['site_name'] == 'truTV'

# Generated at 2022-06-24 13:22:13.327243
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:19.665026
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
        assert TruTVIE()._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:22:22.404892
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing constructor of class TruTVIE
    truTVIE = TruTVIE()
    # Test method
    truTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:25.376453
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:25.982122
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:36.406777
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert trutv._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert trutv

# Generated at 2022-06-24 13:22:37.443118
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:41.327125
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Note: This is just an example.
    # To test this individual file, run:
    #   $ python -m youtube_dl.extractor.trutv
    from youtube_dl.test.test_youtube_dl import TestYoutubeDL

    TestYoutubeDL.run_constructor_test(TruTVIE)

# Generated at 2022-06-24 13:22:46.354068
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/hollywood-divas/videos/hollywood-divas-228.html"
    trutv = TruTVIE()
    assert re.match(trutv._VALID_URL, url)
    #assert trutv.suitable(url)
    #assert trutv.IE_NAME == 'trutv:shows:hollywood-divas:videos:hollywood-divas-228'
    assert trutv._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:22:54.950546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:57.324596
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t_ie = TruTVIE;
    assert(t_ie.__name__ == "TruTVIE");
    assert(t_ie.__module__ == "trutvIE");

# Generated at 2022-06-24 13:22:57.998526
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:58.496520
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-24 13:22:59.267510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:00.835149
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    return ttv.__class__.__name__



# Generated at 2022-06-24 13:23:05.276429
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:23:05.724636
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:12.116651
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Normal test
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE.suitable(test_url), 'Normal test is not passed'

    # Unsupported url
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/sunlight-activated-flower.html'
    assert not TruTVIE.suitable(test_url), 'Unsupported url test is not passed'

    # url without html
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower'
    assert not TruTVIE.suitable(test_url), 'url without html test is not passed'

    # Empty url
   

# Generated at 2022-06-24 13:23:13.840314
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """test for constructor for TruTVIE"""
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:23:15.503003
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of TruTVIE
    my_TruTVIE = TruTVIE()

    # Check that my_TruTVIE is an instance of TruTVIE
    assert type(my_TruTVIE) == TruTVIE


# Generated at 2022-06-24 13:23:16.729334
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t != None

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:23:19.345543
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test URL in the above comment
    # Test the constructor of the class
    test_TruTVIE = TruTVIE()
    assert TruTVIE != None

# Unit Test for method _real_extract of class TruTVIE

# Generated at 2022-06-24 13:23:20.152891
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(object())



# Generated at 2022-06-24 13:23:22.806041
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()
    assert truTVIE._VALID_URL is not None
    assert truTVIE._TEST is not None


# Generated at 2022-06-24 13:23:28.882364
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    IE = TruTVIE()
    # test sample url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # get data from url and convert to json
    data = IE.extract_f4m(url)
    # write data to .json file
    filename = 'TruTVIE.json'
    with open(filename, 'w') as f:
        f.write(data)
test_TruTVIE()

# Generated at 2022-06-24 13:23:38.374132
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:39.274840
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:48.406245
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert a._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert a._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:23:51.680078
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:53.356901
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    test_TruTVIE.suite()

# Generated at 2022-06-24 13:24:03.501420
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import TruTVIE

    # Test TruTVIE.test_TruTVIE.test__real_extract.test_truTVIE.test_extract_ngtv_info_auth_required.test_trutv.test_slug.test_base
    if __name__ == "__main__":
        TruTVIE()._TEST

    # Test TruTVIE.test_TruTVIE.test__real_extract.test_trutvIE.test_extract_ngtv_info_auth_required.test_trutv.test_slug.test_base
    if __name__ == "__main__":
        TruTVIE()._TEST

    # Test TruTVIE.test_TruTVIE.test__real_extract.test_trutvIE.test_extract_ngtv_info

# Generated at 2022-06-24 13:24:04.623281
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:05.990314
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_utils import test_TruTVIE
    test_TruTVIE()


# Generated at 2022-06-24 13:24:06.487945
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:08.188202
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST['info_dict'] == TruTVIE()._real_extract(TruTVIE._TEST['url'])

# Generated at 2022-06-24 13:24:12.295225
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    extractor = TruTVIE()
    print(extractor.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
    
if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-24 13:24:12.819310
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:13.365900
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:20.428510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case 1: Nont ad URL
    url = 'http://www.trutv.com/shows/south_beach_tow/videos/bumping-up-the-price.html'
    assert TruTVIE._VALID_URL.match(url)
    video_id = TruTVIE._VALID_URL.match(url).groups()[2]

    # Test case 2: Ad URL
    url = 'http://www.trutv.com/shows/south_beach_tow/episodes/a-rich-tow-on-south-beach/videos/bumping-up-the-price.html'
    assert TruTVIE._VALID_URL.match(url)
    video_id = TruTVIE._VALID_URL.match(url).groups()[2]

    # Test case 3:

# Generated at 2022-06-24 13:24:29.906002
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Test TruTVIE.__init__()
    """
    # Initialize class object to tests
    trutv_ie = TruTVIE()

    # Test extract function of class object
    assert trutv_ie._real_extract(url=
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    assert trutv_ie._real_extract(url=
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/blame-it-on-the-magic/'
        'jet-black-unicorn-blood.html')


# Generated at 2022-06-24 13:24:31.079286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-24 13:24:32.207921
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:24:33.356556
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    print (test)

# Generated at 2022-06-24 13:24:34.367920
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:24:40.653743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test TruTVIE.__init__(self, url)
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # test out of the TruTVIE.__init__
    TruTVIE.__init__('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    return True

# Generated at 2022-06-24 13:24:50.017661
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:50.556539
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:57.598752
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:58.958437
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        return False
    return True

# Generated at 2022-06-24 13:24:59.488699
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:03.564090
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE class constructor"""
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_instance = TruTVIE()
    assert test_instance.suitable(test_url)

# Generated at 2022-06-24 13:25:04.529154
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:25:11.419885
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:18.399829
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Setup an example TruTVIE object
    trutv_ie = TruTVIE()
    # Test TruTVIE object type
    assert type(trutv_ie) == TruTVIE
    # Test TruTVIE outputs (mocked) json data
    assert type(trutv_ie._download_json('test', 'test')) == dict
    # Test TruTVIE outputs (mocked) ngtv info
    assert type(trutv_ie._extract_ngtv_info('test', {}, {'test': 'test'})) == dict

# Generated at 2022-06-24 13:25:28.696540
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test case 1
    trutvIE = TruTVIE()
    trutvIE._VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    series_slug, clip_slug, id = trutvIE._VALID_URL.match("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html").groups()
    assert series_slug == "the-carbonaro-effect"
    assert clip_slug == "sunlight-activated-flower"

# Generated at 2022-06-24 13:25:29.942840
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:33.269387
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create object with valid URL
    trutv_ie = TruTVIE()
    trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Create object with invalid URL
    try:
        trutv_ie = TruTVIE()
        trutv_ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
        assert False, 'Invalid URL should throw an exception'
    except:
        assert True

# Generated at 2022-06-24 13:25:42.539525
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Nonsense html page
    TEST_URL = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Make sure malformed url could be handled
    assert TruTVIE().suitable(TEST_URL) is True
    assert TruTVIE().working() is True

    # Test regular url
    TEST_URL = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE().suitable(TEST_URL) is True
    assert TruTVIE().working() is True

    # Test malformed url
    TEST_URL = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower'
    assert Tru

# Generated at 2022-06-24 13:25:49.609046
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    trutv = TruTVIE()
    # print all attributes
    # for attri in dir(TruTVIE):
    #     print "%s = %s" % (attri, getattr(TruTVIE, attri))
    # print all methods
    # for method in dir(trutv):
    #     print "method name is %s" % method
    #     print "attr is %s" % getattr(trutv, method)

# Generated at 2022-06-24 13:25:51.300195
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert len(ie.IE_NAME)>0


# Generated at 2022-06-24 13:25:51.870526
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:58.074360
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.ie_key() == 'TruTV'
    example_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    parsed_url = ie._match_id(example_url)
    assert parsed_url == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    example_url = 'https://www.trutv.com/shows/carbonaro-effect/videos/pop-pop-goes-the-weasel.html'
    parsed_url = ie._match_id(example_url)

# Generated at 2022-06-24 13:25:58.678000
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:59.625316
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:26:02.772198
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TruTVIE._downloader)._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE(TruTVIE._downloader)._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:26:04.136603
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    player = TruTVIE()
    assert(player.name == "TruTVIE")

# Generated at 2022-06-24 13:26:05.397608
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .TruTVIE import TruTVIE
    ttv = TruTVIE()

# Generated at 2022-06-24 13:26:09.400385
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'TruTV'
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._WORKING
    assert ie._download_json
    assert ie._extract_ngtv_info

# Generated at 2022-06-24 13:26:19.067076
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()

# Generated at 2022-06-24 13:26:20.256056
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE != None

# Generated at 2022-06-24 13:26:20.938458
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:23.458784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE constructor."""
    from .test_turner import test_TurnerBaseIE
    test_TurnerBaseIE(TruTVIE)

# Generated at 2022-06-24 13:26:25.495936
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test.
    """

    TruTVIE()

# Generated at 2022-06-24 13:26:28.714397
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as ex:
        assert False, 'Failed to create TruTVIE object from TruTVIE.__init__: ' + str(ex)

# Generated at 2022-06-24 13:26:34.047831
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE with valid URL
    ie = TruTVIE()
    assert ie.suitable("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") == True
    # Test TruTVIE with invalid URL
    ie = TruTVIE()
    assert ie.suitable("https://www.softonic.com") == False

# Generated at 2022-06-24 13:26:43.719451
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    print(t._TEST['url'])
    assert(t._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    test = t._download_json(t._TEST['url'], 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    print(test)
    episode = test[0]
    print(episode)
    episode_title = episode['title']
    print(episode_title)
    assert(episode_title == 'The Carbonaro Effect')
    episode_show_title = episode['showTitle']
    print(episode_show_title)

# Generated at 2022-06-24 13:26:46.953782
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        tru = TruTVIE()
    except Exception as e:
        print(e)
        assert False
    assert True

# Unit test to fetch download url (media) of a TruTVIE video

# Generated at 2022-06-24 13:26:54.670311
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/jon-benjamin-has-a-van/videos/jon-benjamin-has-a-van---antibiotics-and-fire-suits.html'  # NOQA
    # To test TruTVIE() module
    try:
        from urllib.request import urlopen
    except ImportError:
        from urllib2 import urlopen
    try:
        urlopen(url)
    except IOError as e:
        # Give up
        return True
    # Test completed
    return TruTVIE().suitable(url)

# Generated at 2022-06-24 13:26:56.101978
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:26:58.868880
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_webpage('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', None)

# Generated at 2022-06-24 13:27:07.470949
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
	assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:27:08.968748
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE("TruTVIE")

# Generated at 2022-06-24 13:27:09.557214
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:11.325652
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert isinstance(obj, TruTVIE)


# Generated at 2022-06-24 13:27:18.737041
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    truTVIE = TruTVIE()
    ret = truTVIE.suitable(test_url)
    print ("suitable:", ret)
    if ret:
        try:
            info = truTVIE._real_extract(test_url)
            print (info)
        except Exception as err:
            print (err)


# Generated at 2022-06-24 13:27:19.504188
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.test()
    

# Generated at 2022-06-24 13:27:21.321510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t != None
    assert TruTVIE != None


# Generated at 2022-06-24 13:27:23.404517
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ """
    test_TruTVIE = TruTVIE()._TEST
    print(test_TruTVIE)



# Generated at 2022-06-24 13:27:27.978503
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test for TruTVIE.suitable
    instance = TruTVIE()
    assert instance.suitable(instance._VALID_URL) == True

    # test for TruTVIE._real_extract
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    data = instance._real_extract(url)
    assert data['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    #assert data['ext'] == 'mp4'
    assert data['title'] == 'Sunlight-Activated Flower'
    assert data['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-24 13:27:38.544890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    clip_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    episode_url = 'https://www.trutv.com/shows/the-carbonaro-effect/352433-full-episode/videos/the-mugged-by-a-raccoon-effect.html'
    episode_id = '352433'
    episode_slug = 'the-mugged-by-a-raccoon-effect'

    TruTVIE(None, clip_url)
    TruTVIE(None, episode_url)

    assert TruTVIE.suitable(clip_url) == True
    assert TruTVIE.suitable(episode_url) == True
    assert TruTVIE.suitable(episode_id) == True
   

# Generated at 2022-06-24 13:27:39.548739
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None

# Generated at 2022-06-24 13:27:40.259098
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:41.188254
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:27:46.652109
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == ('https?://(?:www\.)?trutv\.com/'
                             + '(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:27:48.864763
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_ie = TruTVIE()
    test_ie.extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    )

# Generated at 2022-06-24 13:27:50.450445
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)

# Generated at 2022-06-24 13:27:51.216503
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:00.229436
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import sys

    sys.path.append('..')
    from resources.lib.utils import parse_duration
    from tests.mocks import mock

    # TODO: improve this tests.
    # Assert response is of type TruTVIE
    assert isinstance(TruTVIE(), TruTVIE)

    # Assert response is of type TruTVIE
    mock_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert isinstance(TruTVIE(), TruTVIE)

    # Assert response is of type TruTVIE
    mock_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/the-carbonaro-effect-canceled.html'

# Generated at 2022-06-24 13:28:07.813509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE(None, {})
    assert t.name == 'TruTV'
    assert t.url_re == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert t.info_dict is None
    assert t.params is None

# Generated at 2022-06-24 13:28:08.586906
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("")

# Generated at 2022-06-24 13:28:12.167503
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Construction of class TruTVIE"""
    trutv_ie = TruTVIE()
    assert type(trutv_ie) == TruTVIE
    assert type(trutv_ie._VALID_URL) == str
    assert type(trutv_ie._TEST) == dict

# Generated at 2022-06-24 13:28:12.640454
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:15.875463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(hasattr(TruTVIE, "_TEST"))
    assert(hasattr(TruTVIE, "_VALID_URL"))
# Unit test to check TruTVIE class's real_extract() method

# Generated at 2022-06-24 13:28:16.924866
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:17.980580
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.__class__.__name__ == "TruTVIE"

# Generated at 2022-06-24 13:28:20.545965
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Test instantiation of main class TruTV()
	test_instance = TruTVIE()
	assert isinstance(test_instance, TruTVIE)

# Generated at 2022-06-24 13:28:21.142004
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:28:21.756714
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:22.692409
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        TruTVIE()._test_ngtv_info()

# Generated at 2022-06-24 13:28:23.159136
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:23.717932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:34.589226
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    obj_TruTVIE = TruTVIE()

    obj_TruTVIE._real_extract("",{"key1":"value1"})
    obj_TruTVIE._real_initialize()
    obj_TruTVIE._real_extract("")
    obj_TruTVIE._real_initialize()
    obj_TruTVIE._real_extract("")
    obj_TruTVIE._real_initialize()
    obj_TruTVIE._real_extract("")
    obj_TruTVIE._real_initialize()
    obj_TruTVIE._real_extract("")
    obj_TruTVIE._real_initialize()
    obj_TruTVIE._real_extract("")
    obj_TruTVIE._real_initialize()

    obj_T

# Generated at 2022-06-24 13:28:43.756072
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # tests
    test_cases = [
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/125817/1'
    ]
    trutv = TruTVIE()

    # testing _real_extract
    for test in test_cases:
        # _real_extract(url)
        trutv._real_extract(test)


# Test TruTVIE()
if __name__ == '__main__':
    test_TruTVIE()