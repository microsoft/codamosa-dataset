

# Generated at 2022-06-24 13:18:39.687257
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:42.909936
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert (obj._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))")

# Generated at 2022-06-24 13:18:54.202539
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert test._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:18:59.193518
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    "Make sure that the TruTVIE constructor works"
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    try:
        TruTVIE(True).extract(url)
        assert True
    except AssertionError as e:
        assert False, e
    except Exception as e:
        assert True


# Generated at 2022-06-24 13:19:05.533265
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # unit test for constructor of class TruTVIE
    inst = TruTVIE({})
    assert(inst._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:19:10.354126
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    input_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    extractor = TruTVIE()
    assert TruTVIE._VALID_URL == extractor.VALID_URL
    assert TruTVIE._TEST == extractor.TEST
    assert TruTVIE.__name__ == extractor.IE_NAME


# Generated at 2022-06-24 13:19:20.374574
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TruTVIE)
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:30.356550
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_tv_ie = TruTVIE()
    assert tru_tv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:36.460428
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == TruTVIE._VALID_URL, "failed"
    assert trutv._TEST['url'] == TruTVIE._TEST['url'], "failed"
    assert trutv._TEST['info_dict'] == TruTVIE._TEST['info_dict'], "failed"
    assert trutv._TEST['params'] == TruTVIE._TEST['params'], "failed"
    assert trutv.name == "TruTV"


# Generated at 2022-06-24 13:19:39.489663
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case for TruTVIE()
    # if __name__ == '__main__':
    #     test_TruTVIE()
    extractor1 = TruTVIE()

    # Test case for TruTVIE._real_extract()
    url1 = TruTVIE._TEST['url']
    extractor2 = TruTVIE()
    extractor2.extract(url1)

# Generated at 2022-06-24 13:19:40.689794
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE_object = TruTVIE()

# Generated at 2022-06-24 13:19:42.198570
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    _test = TruTVIE()
    print(_test._extract_ngtv_info)

# Generated at 2022-06-24 13:19:42.790212
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:43.672907
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TruTVIE")

# Generated at 2022-06-24 13:19:50.984590
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # Unit test for _VALID_URL
    t._VALID_URL = 'TrutvIE_UnitTest_'
    # Unit test for _TEST
    t._TEST = 1
    # Unit test for TruTVIE._extract_ngtv_info
    t._extract_ngtv_info = 1
    # Unit test for TruTVIE._download_json
    t._download_json = 1
    # Unit test for TruTVIE._real_extract
    t._real_extract = 1

# Generated at 2022-06-24 13:19:52.121505
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # make sure TruTVIE is constructed properly
    TruTVIE()

# Generated at 2022-06-24 13:19:52.904526
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE


# Generated at 2022-06-24 13:19:53.353072
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:54.631204
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE().ie_key() == 'TruTV'

# Generated at 2022-06-24 13:19:58.188113
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/full-episodes/2400518/index.html')

# Generated at 2022-06-24 13:20:01.130192
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE("www.trutv.com/", "some_thing_special")
    assert trutv.turner_name == "trutv"



# Generated at 2022-06-24 13:20:01.703302
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:02.967976
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        c = TruTVIE()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-24 13:20:11.668975
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Test function
	def trutv_ie_constructor_test(trutv_instance):
		assert trutv_instance.ie_key() == 'truTV'
		assert trutv_instance.ie_id() == 'truTV'
		assert trutv_instance.SUFFIX == '.mp4'
		assert trutv_instance.BASE_URL == 'https://api.trutv.com/v2/web'
		assert trutv_instance._PLAYER_TEMPLATE == 'https://www.trutv.com/player/%s/videos/%s.html'

# Generated at 2022-06-24 13:20:12.196552
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:13.699128
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE().IE_NAME == 'trutv'

# Generated at 2022-06-24 13:20:14.310139
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-24 13:20:15.590471
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:20:17.305156
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE


# Generated at 2022-06-24 13:20:17.762425
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:26.148858
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import pytest
    #TruTVIE(TurnerBaseIE) should be an instance of TruTVIE and TurnerBaseIE
    assert isinstance(TruTVIE(TurnerBaseIE), TruTVIE) and isinstance(TruTVIE(TurnerBaseIE), TurnerBaseIE)
    # constructor with invalid type parameter should raise an exception
    with pytest.raises(TypeError):
        TruTVIE(3)
    # test get_extractor with valid and invalid urls
    TruTVIE.get_extractor('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    with pytest.raises(TypeError):
        TruTVIE.get_extractor(3)

# Generated at 2022-06-24 13:20:27.288536
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj



# Generated at 2022-06-24 13:20:27.804414
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:33.814768
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test with a valid URL string
    test_TruTVIE_validURL('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # Test with an invalid URL string
    test_TruTVIE_invalidURL('https://www.trutv.com/shows/-/videos/test.html')

# Function that performs the unit test for class TruTVIE with a valid URL

# Generated at 2022-06-24 13:20:36.139716
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception:
        # This should not trigger an error.
        assert False
    assert True

# Generated at 2022-06-24 13:20:38.876370
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:20:39.815286
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:20:40.436233
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:42.789593
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__module__ == '__main__'
    assert TruTVIE.__name__ == 'TruTVIE'


# Generated at 2022-06-24 13:20:45.406346
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_turner import test_turner
    test_turner(TruTVIE)

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-24 13:20:48.033236
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This type of constructor call is used in the TruTVIE class and the following line is one of the examples in the code
    TruTVIE('trutv')

# Generated at 2022-06-24 13:20:50.573016
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    print(obj._VALID_URL)
    print(obj._TEST)



# Generated at 2022-06-24 13:21:00.683247
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    assert trutv._VALID_URL == re.compile(r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:21:10.156057
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    arg = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Making an instance of class TruTVIE
    t = TruTVIE(arg)
    # Check if values in TruTVIE class are correct
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert t.format_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
   

# Generated at 2022-06-24 13:21:11.655598
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvIE = TruTVIE()
    assert 'details' == ttvIE.IE_NAME

# Generated at 2022-06-24 13:21:19.468588
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of class TruTVIE
    test_instance = TruTVIE()
    print('Type of test_instance: ', type(test_instance))
    print('test_instance.name: ', test_instance.name)
    # Find if the url 'http://www.trutv.com/shows/full-episodes/videos/3202-tru-tv-top-funniest-puke-a-zoid.html?linkId=2' meets the format of this class
    match = test_instance._VALID_URL_RE.search('http://www.trutv.com/shows/full-episodes/videos/3202-tru-tv-top-funniest-puke-a-zoid.html?linkId=2')
    # Test whether the result is expected one
    assert match
    # Test

# Generated at 2022-06-24 13:21:20.115602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    TruTVIE()


# Generated at 2022-06-24 13:21:21.201145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:21:22.268171
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Will throw error if fails.
    obj = TruTVIE()

# Generated at 2022-06-24 13:21:23.821318
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    type = 'TruTVIE'
    test = TruTVIE()
    assert( type == test._type )

# Generated at 2022-06-24 13:21:24.303167
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:21:34.801132
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE.suitable()
    valid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE.suitable(valid_url) is True
    # Test TruTVIE._real_extract(url)
    assert TruTVIE._real_extract(valid_url) is not None
    
    # Test TruTVIE.suitable()
    valid_url = 'https://www.trutv.com/full-episodes/12/1/9857/'
    assert TruTVIE.suitable(valid_url) is True
    # Test TruTVIE._real_extract(url)
    assert TruTVIE._real_extract(valid_url) is not None

# Generated at 2022-06-24 13:21:37.917683
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert(ie._VALID_URL == TruTVIE._VALID_URL)
    assert(ie._TEST == TruTVIE._TEST)

# Generated at 2022-06-24 13:21:41.690245
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Bad url for TruTVIE
    bad_url = "http://www.trutv.com"
    TruTVIE.suitable(bad_url)

    # Works fine
    good_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutv = TruTVIE.suitable(good_url)
    assert(isinstance(trutv, TruTVIE) == True)


# Generated at 2022-06-24 13:21:51.605264
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case where all the elements are present
    trutv_video = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Test case where only the required elements are present
    trutv_video2 = TruTVIE('https://www.trutv.com/shows/jokers-wild/videos/keep-your-eyes-on-the-prize.html')
    # Test case for a video that is not full length
    trutv_video3 = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/cheesy-puffs-in-a-can.html')
    # Test case for a video with a invalid id

# Generated at 2022-06-24 13:21:58.451617
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check default attribute and function
    trutv_ie = TruTVIE()
    assert trutv_ie.ie_key() == 'TruTV'
    assert TruTVIE.ie_key() == 'TruTV'
    assert trutv_ie.suitable(None) == False
    assert TruTVIE.suitable(None) == False
    assert trutv_ie.suitable(TruTVIE._VALID_URL) == True
    assert TruTVIE.suitable(TruTVIE._VALID_URL) == True
    assert TruTVIE.working() == True
    # Check private attribute and function
    assert trutv_ie._VALID_URL == TruTVIE._VALID_URL
    assert trutv_ie._TEST == TruTVIE._TEST
    assert TruTVIE._TEST

# Generated at 2022-06-24 13:21:58.972319
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:03.861395
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #TruTVIE.test()
    test = TruTVIE()
    result = test._download_json(
        'https://api.trutv.com/v2/web/series/clip/stone-cold-steak-house',
        '62cc1348b4c6d0fdc4f4f3f3c20db46b2c2c3d1b')
    print(result)

# Generated at 2022-06-24 13:22:05.346885
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE({}) is not None


# Generated at 2022-06-24 13:22:06.103270
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:15.714620
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test URL construction
    assert TruTVIE._make_url({
      'type': 'episode',
      'series_slug': 'the-carboneiro-effect',
      'video_id': '123456',
    }) == "https://www.trutv.com/shows/the-carboneiro-effect/123456"
    assert TruTVIE._make_url({
      'type': 'clip',
      'series_slug': 'the-carboneiro-effect',
      'clip_slug': 'cool-clip',
    }) == "https://www.trutv.com/shows/the-carboneiro-effect/videos/cool-clip.html"
    # Test _VALID_URL

# Generated at 2022-06-24 13:22:16.500066
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_ = TruTVIE
    assert class_ != None


# Generated at 2022-06-24 13:22:19.881694
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
  instance = TruTVIE()
  instance._real_extract(url)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:22:21.818917
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv == TruTVIE()

# Unit testing method extract_ngtv_info()

# Generated at 2022-06-24 13:22:29.878344
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check 1
    check1 = TurnerBaseIE
    check2 = TruTVIE._VALID_URL
    check3 = TruTVIE._TEST
    check4 = TruTVIE._real_extract
    tt = TruTVIE()
    assert type(tt) == type(check1), 'the constructor of class TruTVIE does not return a class TurnerBaseIE'
    assert type(tt._VALID_URL) == check2, 'the VALID_URL of class TruTVIE has wrong type'
    assert type(tt._TEST) == check3, 'the _TEST of class TruTVIE has wrong type'
    assert type(tt._real_extract) == check4, 'the real_extract of class TruTVIE has wrong type'


# Generated at 2022-06-24 13:22:39.086904
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Create a TruTVIE object
    trutv_object = TruTVIE()

    assert trutv_object != None
    assert isinstance(trutv_object, TruTVIE)
    assert hasattr(trutv_object, '_VALID_URL')
    assert hasattr(trutv_object, '_TEST')
    assert hasattr(trutv_object, '_download_webpage')
    assert hasattr(trutv_object, '_download_json')
    assert hasattr(trutv_object, '_extract_ngtv_info')
    assert hasattr(trutv_object, '_real_extract')

# Generated at 2022-06-24 13:22:46.534262
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert_equal(TruTVIE._VALID_URL, r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:22:52.927928
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    vid = TruTVIE()
    vid._extract_ngtv_info("1", {}, {})
    vid._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    vid._real_extract("https://www.trutv.com/full-episodes/105249/hack-my-life-s3-e1-hacking-snacks.html")

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:22:54.791473
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == TruTVIE._VALID_URL
    assert ie._TEST == TruTVIE._TEST


# Generated at 2022-06-24 13:22:58.082316
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except AssertionError as ret:
        print("Test of TruTVIE class constructor has failed: {}".format(ret))
    else:
        print("Test of TruTVIE class constructor was completed successfully")


# Generated at 2022-06-24 13:22:59.526223
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    r = TruTVIE()
    assert r
    assert type(r) == TruTVIE

# Generated at 2022-06-24 13:23:00.091000
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:03.220039
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:23:12.321059
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # data comes from website
    webpage_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    series_slug = 'the-carbonaro-effect'
    clip_slug = 'sunlight-activated-flower'
    video_id = None

    assert TruTVIE._VALID_URL.match(webpage_url)

    turnerbase_ie = TurnerBaseIE()
    trutv_ie = TruTVIE(turnerbase_ie)
    assert trutv_ie._VALID_URL == TruTVIE._VALID_URL
    assert trutv_ie._TEST == TruTVIE._TEST
    assert trutv_ie._downloader == turnerbase_ie._downloader

# Generated at 2022-06-24 13:23:21.203298
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-24 13:23:24.220408
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    class TestTruTVIE:
        def __init__(self, TruTVIE):
            self.trutvIE = TruTVIE

    TestTruTVIE(TruTVIE)


# Generated at 2022-06-24 13:23:32.507345
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of TruTVIE
    trutv = TruTVIE()
    # Extract data from valid url
    data = trutv._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    # Check for id
    assert data['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    # Check for title
    assert data['title'] == 'Sunlight-Activated Flower'
    # Check for description
    assert data['description'] != ''
    assert data['description'] is not None
    # Check for episode number (for testing data type)
    assert data['episode_number'] is not None
    assert data['episode_number'] > 0
    #

# Generated at 2022-06-24 13:23:33.551930
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert('TruTVIE')

# Generated at 2022-06-24 13:23:42.763792
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	#test the constructor by giving a valid url
	testURL = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
	testTruTvIE = TruTVIE()
	assert isinstance(testTruTvIE, TruTVIE)
	assert testTruTvIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:23:51.518838
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'
    assert trutv_ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'


# Generated at 2022-06-24 13:24:01.562072
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:24:02.141985
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:03.452642
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE
    assert result == TruTVIE


# Generated at 2022-06-24 13:24:04.826192
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'

# Generated at 2022-06-24 13:24:07.067517
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._extract_mrss_url(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:24:13.313904
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	obj = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
	assert(obj._VALID_URL==r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:24:18.042092
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    item = TruTVIE(TurnerBaseIE._downloader, TurnerBaseIE._downloader.urlopen, TurnerBaseIE._downloader.cache)
    assert item.ie_key() == 'trutv'
    assert item.suitable(item.ie_key())
    assert item.suitable('something_else') == False
    assert item.get_info('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:24:28.617705
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Boolean used to check if there are any errors
    error = False

    # Check if _VALID_URL string is defined
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    try:
        TruTVIE(url)
    except:
        print("Failure. TruTVIE._VALID_URL string is not defined.")
        error = True

    # Check if _TEST dict is defined
    try:
        TruTVIE._TEST
    except:
        print("Failure. TruTVIE._TEST dict is not defined.")
        error = True

    # Check if _TEST dict has the required elements

# Generated at 2022-06-24 13:24:38.964923
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Arrange
    from .test_main import main
    from .extractors import ExtractorList, get_info_extractor
    from .extractor import gen_extractors

    # Act
    gen_extractors()
    trutv_ie = get_info_extractor('trutv')
    extractor_list = ExtractorList(None)
    extractor_list.add_info_extractor(trutv_ie)
    # Assert
    assert trutv_ie._downloader.params.get('noplaylist', True) == True
    assert trutv_ie._downloader.params.get('nocheckcertificate', True) == True


# Generated at 2022-06-24 13:24:39.927499
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test.suite()

# Generated at 2022-06-24 13:24:49.334215
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:24:50.798085
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test case for testing the constructor of class TruTVIE.
    """
    TruTVIE()

# Generated at 2022-06-24 13:24:52.566288
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Init TruTVIE
    test_constructor(TruTVIE, 0)
    # Run TruTVIE test
    test_run(TruTVIE, 1)

# Generated at 2022-06-24 13:24:57.222908
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test URL that is True
    trutvIE = TruTVIE()
    assert trutvIE._VALID_URL
    # Test URL that is False
    trutvIE = TruTVIE()
    assert not TruTVIE._VALID_URL
    # Test valid URL's
    assert TruTVIE._VALID_URL == TruTVIE._TEST['url']
    # Test valid URL's
    assert TruTVIE._VALID_URL

# Generated at 2022-06-24 13:25:03.655401
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test construction of the TruTVIE class with TruTV URLs
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == TruTVIE._VALID_URL
    assert trutv_ie._TEST == TruTVIE._TEST
    assert trutv_ie._downloader._download_json == TruTVIE._downloader._download_json
    assert trutv_ie._real_extract == TruTVIE._real_extract


# Generated at 2022-06-24 13:25:10.191837
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE.IE_DESC == 'truTV'
    assert TruTVIE.__doc__ is None
    assert isinstance(TruTVIE._VALID_URL, str)
    assert TruTVIE._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"


# Generated at 2022-06-24 13:25:11.077807
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE = TruTVIE()


# Generated at 2022-06-24 13:25:12.702273
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Start of TruTVIE tests
# Test TruTVIE constructor

# Generated at 2022-06-24 13:25:13.691365
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:22.084658
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE()._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE()._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:25:24.416854
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor of class TruTVIE should return an instance of class TruTVIE
    assert isinstance(TruTVIE(),TruTVIE)

# Generated at 2022-06-24 13:25:25.002940
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:28.123152
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:25:30.282476
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # Make sure TruTVIE exists
    assert t is not None

# Generated at 2022-06-24 13:25:31.744687
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_json(
        'https://api.trutv.com/v2/web/episode/hack-my-life/378881/70139294',
        '70139294')

# Generated at 2022-06-24 13:25:34.970269
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL is not None,"_VALID_URL of TruTVIE is not initialized."
    assert TruTVIE._TEST is not None, "_TEST of TruTVIE is not initialized."

# Generated at 2022-06-24 13:25:41.633379
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.get_url() == TruTVIE._VALID_URL
    assert obj.get_test() == TruTVIE._TEST
    assert obj.get_title() == TruTVIE._TEST['info_dict']['title']
    assert obj.get_id() == TruTVIE._TEST['info_dict']['id']
    assert obj.get_description() == TruTVIE._TEST['info_dict']['description']
    obj.get_video_url(TruTVIE._TEST['url'])

# Generated at 2022-06-24 13:25:43.507214
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:25:45.454177
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try: 
        TruTVIE()
    except:
        assert False



# Generated at 2022-06-24 13:25:46.116556
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:55.313983
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This test is written to check that the class TruTVIE 
    #   is created as described in the assignment and doesn’t 
    #   change in future. 
    #
    # Here, the name of the class being tested is passed as the 
    #   input to the constructor of the class tester.
    #
    # This class tester will check that the class TruTVIE inherits 
    #   the class TurnerBaseIE. For more information regarding 
    #   the class tester, please check the analyze-video.py file.
    tester = Tester(ie=TruTVIE)
    #
    # This line asserts that the class should be subclass of TurnerBaseIE. 
    #   If it fails, the test will be considered failed. 
    #
    # For more information regarding assertions, please check the 


# Generated at 2022-06-24 13:25:57.803031
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE(TurnerBaseIE())
    assert str(trutv_ie) == '<TruTVIE>'

# Generated at 2022-06-24 13:25:58.429490
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:26:00.173633
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._download_json('url', 'display_id')

# Generated at 2022-06-24 13:26:02.911456
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert(x.ie_key() == 'trutv')
    assert(x.ie_name() == 'TruTV')

# Generated at 2022-06-24 13:26:04.723521
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:26:05.715238
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:12.177998
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_json('https://api.trutv.com/v2/web/episode/the-carbonaro-effect/139294/139298', '139298')
    TruTVIE()._download_json('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

# Generated at 2022-06-24 13:26:21.238182
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TBSIE extractor."""
    success = True
    assert TurnerBaseIE

    # Create instance from URL
    try:
        TruTVIE(TurnerBaseIE._downloader, 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    except Exception as e:
        success = False
        print("Error creating instance of TruTVIE: " + str(e))

    # Check if extractor can be used with URL
    try:
        TruTVIE._html_webpage_read_content(TruTVIE._downloader, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    except TypeError as e:
        success = False

# Generated at 2022-06-24 13:26:22.026017
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:24.602801
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:26:26.283893
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.ie_key() == 'TruTV'

# Generated at 2022-06-24 13:26:27.477925
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    return

# Generated at 2022-06-24 13:26:28.130535
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:30.585000
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:26:40.133267
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.suitable("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

    assert ie.url_result("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert ie.url_result("https://www.trutv.com/shows/impractical-jokers/6-season/1-episode/impractical-jokers-the-long-arm-of-the-law/index.html")
    assert ie.url_result("https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:26:48.130685
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE(TurnerBaseIE._create_get_url())
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:50.668583
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert x.char_class == 'TruTV', 'char_class of TruTVIE is not correctly initialized'
    assert x.ie_key == 'TruTV', 'ie_key of TruTVIE is not correctly initialized'

# Generated at 2022-06-24 13:26:53.766223
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Test the constructor of the class TruTVIE
    test_TruTVIE = TruTVIE()
    assert test_TruTVIE != None, "TruTVIE object was not created"


# Generated at 2022-06-24 13:26:54.627440
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()

# Generated at 2022-06-24 13:26:55.702186
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()


# Generated at 2022-06-24 13:26:57.426420
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE.__doc__)


# Generated at 2022-06-24 13:27:06.199351
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # The example video URL in this test has been taken from the documentation
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    truTVIE = TruTVIE()
    assert truTVIE._VALID_URL == re.compile(r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:27:18.313546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Load constructor of TruTVIE
    constructor = TruTVIE()
    # Check if TruTVIE implements TurnerBaseIE
    assert issubclass(TruTVIE, TurnerBaseIE)
    assert isinstance(constructor, TruTVIE)
    # Check if TurnerBaseIE implements InfoExtractor
    assert issubclass(TurnerBaseIE, InfoExtractor)
    assert isinstance(constructor, InfoExtractor)

    # Check if website is TruTV
    assert constructor._SITE_NAME == 'TruTV'
    assert constructor._SITE_URL == 'trutv.com'

    # Check if video ID is generated correctly

# Generated at 2022-06-24 13:27:18.790573
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:24.033245
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://api.trutv.com/v2/web/series/clip/american-dummies/american-dummies-kicked-off-prematurely-adam-eget.json')
    TruTVIE('https://api.trutv.com/v2/web/episode/hardcore-pawn/hardcore-pawn-s6-e6-the-pawn-that-roared.json')

# Generated at 2022-06-24 13:27:24.602786
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    construct = TruTVIE()

# Generated at 2022-06-24 13:27:34.828578
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:36.175502
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv != None


# Generated at 2022-06-24 13:27:46.130841
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:47.567775
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('test_TruTVIE')
    t = TruTVIE()
    print(t)

# Generated at 2022-06-24 13:27:58.293599
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:09.308358
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV_ie = TruTVIE()

    # test method _extract_ngtv_info

# Generated at 2022-06-24 13:28:10.253852
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None

# Generated at 2022-06-24 13:28:16.209969
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # print('Testing TruTVIE')
    ie = TruTVIE()
    ie.download('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.download('https://www.trutv.com/full-episodes/4446233/the-carbonaro-effect-jun-15-2016/videos/sunlight-activated-flower.html')


# Generated at 2022-06-24 13:28:17.359689
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:17.958696
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:20.946619
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True

# Generated at 2022-06-24 13:28:21.573011
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-24 13:28:22.866382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)

# Generated at 2022-06-24 13:28:29.645330
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:28:31.002879
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV_IE = TruTVIE()
    return truTV_IE

# Generated at 2022-06-24 13:28:33.203834
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_object = TruTVIE()
    assert(trutv_object.name == 'trutv')


# Generated at 2022-06-24 13:28:37.345887
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:40.489733
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
