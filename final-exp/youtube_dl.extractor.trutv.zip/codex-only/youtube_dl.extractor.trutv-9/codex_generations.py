

# Generated at 2022-06-24 13:18:40.860702
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:50.008233
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    trutv.ie_key = 'trutv'
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv.ie_key == 'trutv'
    trutv.ie_key = 'turner'
    assert trutv.ie_key == 'turner'

# Generated at 2022-06-24 13:18:56.405301
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE
    t = TruTVIE()
    assert t.IE_NAME == 'trutv:play'
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:18:57.009284
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:59.313881
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE({})._download_json('https://api.trutv.com/v2/web/episode/impractical-jokers/18965')


# Generated at 2022-06-24 13:19:09.222089
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE(None)
    assert test_TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:09.666719
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:10.960829
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:19:11.473878
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:16.899776
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.name == 'trutv'
    assert trutv_ie.ie_key() == 'trutv'
    assert trutv_ie.title() == 'TruTV'
    assert trutv_ie.description() == 'trutv.com videos'
    assert trutv_ie.test() is None

# Generated at 2022-06-24 13:19:19.972163
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE()._TEST['url'] == ('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
	return True


# Generated at 2022-06-24 13:19:20.590826
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:30.555682
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:32.537730
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE instantiation
    obj = TurnerBaseIE()
    assert obj.__class__.__name__ == "TurnerBaseIE"

# Generated at 2022-06-24 13:19:33.000652
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:34.519475
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE
    """
    TruTVIE()
    assert TruTVIE.__doc__



# Generated at 2022-06-24 13:19:34.948857
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:44.132655
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test when video doesn't require authentication
    TruTVIE()._extract_ngtv_info(
        'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', {}, {
            'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
            'site_name': 'truTV',
            'auth_required': False,
        })

    # Test when video requires authentication

# Generated at 2022-06-24 13:19:47.060212
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE().name == 'truTV'
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:19:55.476908
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()

    test._download_json('https://api.trutv.com/v2/web/clip/rattlesnake-handshake', display_id = 'rattlesnake-handshake')
    assert test.data['info']['title'].strip() == 'Rattlesnake Handshake'
    assert test.data['info']['descriptio'] == 'A customer watches in horror as Michael uses his hands to close a rattlesnake bite kit.'
    assert test.data['info']['showTitle'] == 'Impractical Jokers'

    test._download_json('https://api.trutv.com/v2/web/episode/138863', display_id = '138863')
    assert test.data['episode']['title'].strip() == 'The Big Time'

# Generated at 2022-06-24 13:20:04.138755
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie._downloader is not None
    assert ie._type == 'video'
    assert ie._2010 is True
    assert ie._WORKING is True



# Generated at 2022-06-24 13:20:12.415083
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    with open('tests/internetexplorer/turner.json') as f:
        turnerBaseIE_json = json.load(f)
        turnerBaseIE_data = turnerBaseIE_json['entries'][0]
    with open('tests/internetexplorer/trutv.json') as f:
        TruTVIE_json = json.load(f)
        TruTVIE_data = TruTVIE_json['entries'][0]

    TruTV = TruTVIE()


# Generated at 2022-06-24 13:20:13.182042
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:14.535692
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._VALID_URL

# Generated at 2022-06-24 13:20:16.935870
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE(None)
    assert TruTVIE == test.__class__

# Generated at 2022-06-24 13:20:19.748931
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/full-episodes/videos/sunlight-activated-flower.html"
    obj = TruTVIE()
    assert obj.suitable(url)

# Generated at 2022-06-24 13:20:24.602206
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video = TruTVIE()
    assert video._VALID_URL =="https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))"

# Generated at 2022-06-24 13:20:30.517861
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor of TurnerBaseIE class calls _download_json()
    # function, which require internet connection,
    # so we can't run this test without it
    try:
        test = TurnerBaseIE()
        test.suite()
    except RuntimeError:
        pass

    # Constructor of TruTVIE class calls TurnerBaseIE's constructor,
    # so we can't run this test without it
    try:
        test_TruTVIE = TruTVIE()
        test_TruTVIE.suite()
    except RuntimeError:
        pass

# Generated at 2022-06-24 13:20:35.065931
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # test TruTVIE constructor
    trutv = TruTVIE()

    expected_trutv = True
    expected_ngtv = True

    assert isinstance(trutv, TurnerBaseIE) == expected_trutv
    assert isinstance(trutv, TruTVIE) == expected_trutv



# Generated at 2022-06-24 13:20:39.971430
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from utils import Url

    # Test constructor of class TruTVIE
    assert TruTVIE(Url("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")).__class__.__name__ == "TruTVIE"

# Generated at 2022-06-24 13:20:49.001523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    instance = TruTVIE()
    assert(instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:20:52.580913
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie__name__ == 'TruTV'
    assert ie__description__ == 'truTV Video'
    assert ie__ie_slug__ == 'trutv'

# Generated at 2022-06-24 13:21:01.884538
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor test
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:03.029414
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:21:04.876498
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        t = TruTVIE()
    except:
        raise AssertionError('TruTVIE constructor not working!')

# Generated at 2022-06-24 13:21:14.024620
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test instatiation of class TruTVIE
    trutv = TruTVIE()

    # Test _VALID_URL of class TruTVIE
    test_VALID_URL = trutv._VALID_URL 
    assert test_VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Test _TEST of class TruTVIE
    test_TEST = trutv._TEST 

# Generated at 2022-06-24 13:21:20.440809
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    print("Unit test for constructor of class TruTVIE")

    # Check name of IE
    trutv_IE = TruTVIE()
    assert trutv_IE.ie_key() == 'TruTV'

    # Check _VALID_URL
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:21:20.859010
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:22.081479
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from ykdl.compact import compact_bytes
    assert compact_bytes('truTV', 'utf-8') == b'truTV'

# Generated at 2022-06-24 13:21:32.061213
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .generic_constructor import GenericIE
    from .test_thumbnail_storage import test_thumbnail_storage
    from utils import url_or_none
    # Test if the class TruTVIE inherits the class GenericIE
    assert issubclass(TruTVIE, GenericIE)
    print("TruTVIE inherits GenericIE")
    # Test if the class TruTVIE has attribute _VALID_URL
    assert hasattr(TruTVIE, "_VALID_URL")
    print("class TruTVIE has attribute _VALID_URL")
    # Test if the class TruTVIE has attribute _TEST
    assert hasattr(TruTVIE, "_TEST")
    print("class TruTVIE has attribute _TEST")
    # Test if the class TruTVIE has method real_extract

# Generated at 2022-06-24 13:21:32.660424
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  TruTVIE()

# Generated at 2022-06-24 13:21:40.243308
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == "trutv"
    assert ie.IE_DESC == "truTV"
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:40.888628
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-24 13:21:43.200773
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(None)._real_extract(test_url)

# Generated at 2022-06-24 13:21:48.189993
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Tests TruTVIE constructor.

    Unit test for TruTVIE.
    """
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert TruTVIE.suitable(url) == True

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-24 13:21:49.162819
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    isinstance(TruTVIE(), TruTVIE)

# Generated at 2022-06-24 13:21:50.364546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    print(test)

# Generated at 2022-06-24 13:21:51.154728
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:59.267038
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	t = TruTVIE()
	print

# Generated at 2022-06-24 13:22:04.621598
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:22:05.420299
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:06.595878
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor_test_for(TruTVIE)

# Generated at 2022-06-24 13:22:16.132006
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global TruTVIE
    trutv_ie = TruTVIE()

    # Test for _download_json
    trutv_ie._download_json('https://www.trutv.com/')
    trutv_ie.report_warning('')

    # Test for _extract_ngtv_info
    trutv_ie._extract_ngtv_info('')

    # Test for _real_extract
    trutv_ie._real_extract('https://www.trutv.com/')
    trutv_ie._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:16.978787
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tv = TruTVIE()
    assert tv is not None

# Generated at 2022-06-24 13:22:19.148423
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_fixture = TruTVIE()

if __name__ == '__main__':
    # Unit test for constructor of class TruTVIE
    test_TruTVIE()

# Generated at 2022-06-24 13:22:22.079871
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE_instance = TruTVIE()
    assert TruTVIE_instance.suitable(TruTVIE_instance._TEST['url'])
    assert TruTVIE_instance._TEST['info_dict'] == TruTVIE_instance._real_extract(TruTVIE_instance._TEST['url'])

# Generated at 2022-06-24 13:22:22.997521
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Tests that it can be successfully constructed."""
    TruTVIE(object())

# Generated at 2022-06-24 13:22:30.590200
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_1 = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert test_1.url == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert test_1.valid_url() == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert test_1.valid_url(test_1.url) == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:22:41.153271
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case for TruTVIE
    # TODO: Change to test TruTVIE
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Video ID is passed into TruTVIE
    # TODO: Change to test TruTVIE
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:22:42.211790
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TurnerBaseIE()._constructor_check() == "trutv"

# Generated at 2022-06-24 13:22:48.854242
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE();
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:51.945145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test.url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert test.match(test.url) == True

# Generated at 2022-06-24 13:22:52.342607
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:59.123113
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:59.659804
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-24 13:23:07.995165
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:23:18.128517
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:23:19.277198
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Litmus Test for TruTVIE
    assert TruTVIE() is not None

# Generated at 2022-06-24 13:23:26.639734
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # First test TruTVIE constructor given a url not matched by TruTVIE.VALID_URL
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE(TruTVIE._downloader)
    # check if this TruTVIE instance matches the TruTVIE.VALID_URL
    assert ie.suitable(ie.extract(url)) is True
    # check if this TruTVIE instance is not suitable for other urls
    assert ie.suitable(url + '?foo=bar') is False

# Generated at 2022-06-24 13:23:29.807212
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL is not None
    assert TruTVIE._TEST is not None
    ttvie = TruTVIE()
    assert not hasattr(ttvie, "_downloader")
    assert not hasattr(ttvie, "_download_webpage")

# Generated at 2022-06-24 13:23:33.485593
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:23:34.071475
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:35.436675
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tt = TruTVIE()
    assert tt is not None

# Generated at 2022-06-24 13:23:37.381467
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE = TruTVIE()

# Generated at 2022-06-24 13:23:44.400150
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE(TruTVIE._downloader)
    # Testing with valid URL
    test_url = TruTVIE._TEST['url']
    expected_result = TruTVIE._TEST['info_dict']
    result = TruTVIE._real_extract(ie,test_url)
    assert result == expected_result
    # Testing with invalid URL
    test_url = 'https://www.youtube.com/watch?v=8WYHDfJDPDc'
    expected_result = False
    result = TruTVIE._real_extract(ie, test_url)
    assert expected_result == result

# Generated at 2022-06-24 13:23:45.137515
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    True

# Generated at 2022-06-24 13:23:52.556817
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Ensure that object is being initialized
    # TruTVIE is used to extract video information
    ie = TruTVIE()
    # This integer is used to store length of downloaded video
    length = int(ie.download(ie.url_result("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"))['test_result']['total_bytes'])
    assert ie.url_result("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")['_type'] == 'url_transparent', 'video is not being extracted from URL'
    assert length > 0, 'video must be downloaded'

# Generated at 2022-06-24 13:23:54.245426
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()   
    # test_TruTVIE should return null.
    assert obj == None

# Generated at 2022-06-24 13:23:54.757039
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:02.544302
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test constructor of class TruTVIE with valid url
    tv_ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert isinstance(tv_ie, TurnerBaseIE)

    # test constructor of class TruTVIE with invalid url
    try:
        TruTVIE('https://www.invalid.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    except AssertionError:
        assert True
        return
    assert False


# Generated at 2022-06-24 13:24:05.160891
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert TruTVIE._VALID_URL == trutvIE._VALID_URL
    assert TruTVIE._TEST == trutvIE._TEST

# Generated at 2022-06-24 13:24:13.852184
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test using trutv.com/shows/impractical-jokers/videos/jokers-wild.html
    test1 = TurnerBaseIE._build_url_result(
        TurnerBaseIE._TEST_BASE_URL,
        '/shows/impractical-jokers/videos/jokers-wild.html',
        '1'
    )

    test1_dict = {
    "protocol": "https",
    "domain": "trutv.com",
    "path": "/shows/impractical-jokers/videos/jokers-wild.html",
    "series_slug": "impractical-jokers",
    "clip_slug": "jokers-wild",
    "id": None
    }

    assert test1[0] == test1_dict

    # Test using trutv.com/full-

# Generated at 2022-06-24 13:24:19.875485
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE(url)
    assert ie.url == url
    assert ie.series_slug == 'the-carbonaro-effect'
    assert ie.clip_slug == 'sunlight-activated-flower'
    assert ie.video_id == None

    url = 'https://www.trutv.com/full-episodes/3137003/the-carbonaro-effect-episode-102/videos/sunlight-activated-flower.html'
    ie = TruTVIE(url)
    assert ie.url == url
    assert ie.series_slug == '3137003/the-carbonaro-effect-episode-102'

# Generated at 2022-06-24 13:24:25.318015
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE();
    assert trutv.ie_key() == 'trutv';
    assert trutv.ie_name() == 'truTV';
    assert trutv.valid_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html');

# Generated at 2022-06-24 13:24:27.139436
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:24:28.314119
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert False

# Generated at 2022-06-24 13:24:28.850716
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:34.010941
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()
    # define a string that contains uri of a show
    uri = 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # test function _real_extract
    truTVIE._real_extract(uri)

# Generated at 2022-06-24 13:24:35.237504
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE();
    assert t != None

# Generated at 2022-06-24 13:24:42.040731
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._extract_ngtv_info(
        media_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        info_dict = {},
        additional_data = {
            'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
            'site_name': 'truTV',
            'auth_required': False,
        })

# Generated at 2022-06-24 13:24:42.662786
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:51.689662
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Running test for TruTVIE')
    test_url = 'https://www.trutv.com/shows/hacking-the-system/videos/hacking-the-fbi.html'
    trutv_ie = TruTVIE()
    trutv_ie._TEST = {}
    trutv_ie._TEST['info_dict'] = {}
    trutv_ie._TEST['params'] = {}
    trutv_ie._TEST['params']['skip_download'] = True
    trutv_ie._TEST['url'] = test_url
    test_func = lambda: trutv_ie._real_extract(test_url)
    result = test_func()

# Generated at 2022-06-24 13:24:59.927199
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SUBSCRIBER_URL == 'http://www.trutv.com/true-access/auth.html'
    assert ie.LOGIN_URL == 'http://www.trutv.com/true-access/auth.html'
    assert ie.REQUESTOR_ID == '4279569396'
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:00.838084
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:02.834907
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_ie = TruTVIE()
    assert ttv_ie is not None

# Generated at 2022-06-24 13:25:07.672524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:09.929890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tech=TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    print(tech)

# Generated at 2022-06-24 13:25:11.869935
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:25:12.786841
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('test')

# Generated at 2022-06-24 13:25:14.157485
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:25:15.338998
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.test()

# Generated at 2022-06-24 13:25:20.221994
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert isinstance(m, dict)
    assert 'id' in m, "id is needed."
    assert 'ext' in m, "ext is needed."
    assert 'title' in m, "title is needed."
    assert 'description' in m, "description is needed."

# Generated at 2022-06-24 13:25:22.932088
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    mytruTV = TruTVIE()
    TruTVIE.__module__ = "youtube_dl.extractor.trutv"

# Generated at 2022-06-24 13:25:23.522626
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:29.272121
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import sys
    import os
    import inspect

    current_filename = os.path.abspath(inspect.getfile(inspect.currentframe()))
    sys.path.append(os.path.dirname(os.path.abspath(current_filename)))
    import test_utils
    test_utils.get_content_type('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', TruTVIE)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:25:36.402085
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    x.IE_NAME
    assert x.IE_NAME == 'trutv.com'
    assert x._VALID_URL is not None
    x._TEST.get('url')
    assert x._TEST.get('url') is not None
    x._TEST.get('info_dict')
    assert x._TEST.get('info_dict') is not None
    x._TEST.get('params')
    assert x._TEST.get('params') is not None

# Generated at 2022-06-24 13:25:39.053246
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.ie_key() == 'TruTV'
    assert ie.ie_name() == 'truTV'

# Generated at 2022-06-24 13:25:45.797593
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_class = TruTVIE()
    assert ttv_class._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:52.051273
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	print("\nConstructor Test")
	r = TruTVIE()
	assert(r._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')



# Generated at 2022-06-24 13:25:55.937153
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    yt = TruTVIE()
    assert yt._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:06.355848
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:09.139120
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


if __name__ == '__main__':
    # Invoke the following command to test the module:
    TruTVIE().download_playlist()

# Generated at 2022-06-24 13:26:12.792572
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for capabilities of TruTVIE.
    """
    assert TruTVIE.suitable("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:26:21.522186
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:22.244235
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:27.353733
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()

    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

    ttv.extract(url)
    extracted_info = ttv.extract(url)

    assert extracted_info is not None

# Generated at 2022-06-24 13:26:27.777140
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:38.256889
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Given the following parameters
    path = "series/clip"
    series_slug = "impractical-jokers"
    clip_slug = "charades"
    display_id = "charades"
    # When I try to instantiate the TruTVIE class
    trutv = TruTVIE(path, series_slug, clip_slug, display_id)
    # Then the instance variable path should be set correctly
    assert trutv.path == "series/clip"
    # Then the instance variable series_slug should be set correctly
    assert trutv.series_slug == "impractical-jokers"
    # Then the instance variable clip_slug should be set correctly
    assert trutv.clip_slug == "charades"
    # Then the instance variable page_id should be set correctly
    assert tr

# Generated at 2022-06-24 13:26:41.631052
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from youtube_dl.extractor.trutv import TruTVIE
    assert TruTVIE("The Carbonaro Effect : Sunlight-Activated Flower")._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-24 13:26:45.180408
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    ttv.extract("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    ttv.extract("http://www.trutv.com/full-episodes/the-carbonaro-effect/season-2/episode-202.html")

# Generated at 2022-06-24 13:26:47.716185
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE()
    assert test_obj.__class__.__name__ == 'TruTVIE'


# Generated at 2022-06-24 13:26:58.214021
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:27:04.134477
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert isinstance(trutv_ie, TurnerBaseIE)
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:04.769761
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('TruTVIE')

# Generated at 2022-06-24 13:27:06.859578
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    assert truTV is not None and truTV.trutv_login is not None and truTV.trutv_user is not None

# Generated at 2022-06-24 13:27:09.408027
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Function to check TruTVIE constructor."""
    # Instance of class TruTVIE
    TruTVIE()

# Generated at 2022-06-24 13:27:11.180784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE constructor"""
    trutv_ie = TruTVIE()
    trutv_ie

# Generated at 2022-06-24 13:27:15.288205
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tt = TruTVIE()
    tt.download("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Test function for TruTVIE

# Generated at 2022-06-24 13:27:20.827837
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE();
    assert(instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))');


# Generated at 2022-06-24 13:27:22.693970
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract(TruTVIE()._TEST['url'])

# Generated at 2022-06-24 13:27:23.239241
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:25.541509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == "trutv"
    assert ie.turner_secure_site_url == "https://www.trutv.com"

# Generated at 2022-06-24 13:27:26.147527
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE('TruTVIE')

# Generated at 2022-06-24 13:27:26.528626
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:29.393371
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.ie_key() == 'trutv'
    assert trutv_ie.ie_name() == 'truTV'

# Generated at 2022-06-24 13:27:32.611218
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    for key,value in TruTVIE._TEST.items():
        assert TruTVIE._TEST[key] == TruTVIE._test(test_TruTVIE, True)[key]


# Generated at 2022-06-24 13:27:37.477346
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.IE_NAME == "TruTV"
    assert TruTVIE.IE_DESC == "TruTV"
    assert TruTVIE._VALID_URL == TruTVIE._TEST['url']
    assert TruTVIE._TEST['info_dict']['id'] == TruTVIE._TEST['url']

# Generated at 2022-06-24 13:27:39.593815
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    data = TruTVIE._TEST
    ie = TruTVIE()
    ie._real_extract(data['url'])

# Generated at 2022-06-24 13:27:40.298954
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:27:41.235685
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:42.197373
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None)


# Generated at 2022-06-24 13:27:47.157354
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    data = TruTVIE._download_json(
            'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower',
            TruTVIE._TEST)
    assert data['status'] == 'success'

# Generated at 2022-06-24 13:27:57.924996
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:59.320950
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert(obj)

# Generated at 2022-06-24 13:28:05.084484
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    testUrl = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    resultUrl = re.match(TruTVIE._VALID_URL, testUrl).groups()
    expectedUrl = ('the-carbonaro-effect', 'sunlight-activated-flower', None)

    assert(resultUrl == expectedUrl)


# Generated at 2022-06-24 13:28:13.457943
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    # Test case where url is good
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    obj.suitable(url)
    # Test case where url is bad
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.htm"
    obj.suitable(url)
    # Test case where url is bad
    url = "https://www.trutv.co/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    obj.suitable(url)

# Generated at 2022-06-24 13:28:17.868329
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url_object = TruTVIE(url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', request_data=None, headers=None)
    # Return True if the test passes, and False if not.
    return True

# Generated at 2022-06-24 13:28:19.521500
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    myTruTVIE = TruTVIE()
    assert myTruTVIE

# Generated at 2022-06-24 13:28:20.545894
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:27.638383
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    print("Running unit tests for TruTVIE")
    print("URL: " + test_TruTVIE._TEST['url'])
    print("ID: " + test_TruTVIE._TEST['info_dict']['id'])
    print("Ext: " + test_TruTVIE._TEST['info_dict']['ext'])
    print("Title: " + test_TruTVIE._TEST['info_dict']['title'])
    print("Description: " + test_TruTVIE._TEST['info_dict']['description'])
    return
test_TruTVIE()

# Generated at 2022-06-24 13:28:28.386496
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:30.156132
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        assert TruTVIE.test()
    except Exception as e:
        raise e


# Generated at 2022-06-24 13:28:30.822617
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None, None, None, None)

# Generated at 2022-06-24 13:28:33.119155
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	"""
	Unit test for constructor of class TruTVIE
	"""
	test_instance = TruTVIE()
	assert test_instance is not None

# Generated at 2022-06-24 13:28:37.503189
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert not ie.suitable("http://www.fakeurl.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert ie.IE_NAME == "Turner: TruTV"

# Generated at 2022-06-24 13:28:42.891067
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    assert trutv._TEST['url'] == url
    assert trutv._TEST['params']['skip_download']