

# Generated at 2022-06-24 13:18:49.599826
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == "TruTV"
    assert ie.IE_DESC == "TruTV"
    assert ie._VALID_URL == TruTVIE._VALID_URL
    assert ie._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:18:51.417813
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("http://sdfsdfsdfsdf.edu", {}) is not None

# Generated at 2022-06-24 13:18:52.031162
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:56.872221
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:18:59.192970
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().to_screen('https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:19:01.126338
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    logging.basicConfig(level=logging.DEBUG)
    TruTVIE()

# Generated at 2022-06-24 13:19:02.867245
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """To Test TruTVIE Constructor"""
    TruTVIE("Test", "Test", "Test")
    return

# Generated at 2022-06-24 13:19:04.896988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        return False
    return True

from .. import ydl


# Generated at 2022-06-24 13:19:06.296423
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv is not None

# Generated at 2022-06-24 13:19:11.496666
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/full-episodes/723357/')

    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/full-episodes/723357')

# Generated at 2022-06-24 13:19:12.033170
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:19:12.913939
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t != None

# Generated at 2022-06-24 13:19:18.631387
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Testing this TruTVIE video extractor for video "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    TruTVIE_extractor = TruTVIE()
    TruTVIE_extractor.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:19:25.858096
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    # test class variables
    assert(ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(type(ttv._TEST) == dict)

# Generated at 2022-06-24 13:19:34.356939
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    print(trutv._download_json('https://api.trutv.com/v2/web/clip/catfish-parody-commercial/12924f88d9232daf69ad3cc09e0eefd0454bac45', '12924f88d9232daf69ad3cc09e0eefd0454bac45'))
    print(trutv._extract_ngtv_info('12924f88d9232daf69ad3cc09e0eefd0454bac45', {}, {'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'site_name': 'truTV', 'auth_required': False}))
    print()


# Generated at 2022-06-24 13:19:40.375074
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.host == 'truTV'
    assert ie.name == 'truTV'
    assert ie.domain == 'trutv.com'
    assert ie.logo == 'https://upload.wikimedia.org/wikipedia/en/f/f7/TruTV_logo.png'
    assert ie.logo_thumbnail == 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f7/TruTV_logo.png/200px-TruTV_logo.png'
    assert ie.logo_banner == 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f7/TruTV_logo.png/500px-TruTV_logo.png'

# Generated at 2022-06-24 13:19:45.928183
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/how-to-be-a-grownup/videos/why-dont-you-understand-me.html')
    ie.extract('https://www.trutv.com/full-episodes/2339951/how-to-be-grownup/why-dont-you-understand-me.html')

# Generated at 2022-06-24 13:19:46.546614
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:52.463992
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for the TruTVIE
    """
    if __name__ != "__main__":
        import pytest
        pytest.skip("TruTVIE is not available in an isolated environment")

    TruTVIE()._real_extract("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")


if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-24 13:19:53.004049
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:53.816541
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.test()

# Generated at 2022-06-24 13:19:54.834564
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-24 13:20:06.656979
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:20:09.476151
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:20:18.174992
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url = 'https://www.trutv.com/full-episodes/641618/carbonaro-effect-big-fish-big-pond.html'
    #video_id = '641618'
    #video_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    # TruTVIE()._download_video_info(url, video_id)
    TruTVIE()._real_extract(url)


# Generated at 2022-06-24 13:20:23.351143
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # TruTVIE uses a custom URL to extract information
    trutv_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Download the JSON file with information about this video
    trutv_json = TruTVIE._download_json(
            TruTVIE._search_regex(
                TruTVIE._VALID_URL,
                trutv_url,
                'episode'),
            trutv_identifier)

    # Extract the information from the downloaded JSON file
    trutv_json_extracted = TruTVIE._extract_ngtv_info(
            TruTVIE._search_regex(
                TruTVIE._VALID_URL,
                trutv_url,
                'episode'))

    # Decide if

# Generated at 2022-06-24 13:20:25.064301
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()
    assert i.name == 'trutv.com:series:clip'
    assert i.name == 'trutv.com:episode'

# Generated at 2022-06-24 13:20:25.549249
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:35.018687
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-24 13:20:37.092660
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    success = TruTVIE()
    success.is_extractable(TruTVIE._TEST)

# Generated at 2022-06-24 13:20:38.534081
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    construct_test_object(TruTVIE, [], True)



# Generated at 2022-06-24 13:20:48.312196
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv_ie.num_ie == 1

# Generated at 2022-06-24 13:20:59.077503
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Unit test for TruTVIE class
    '''
    import sys
    import os
    import unittest
    
    # Set environment variables
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../bin/')))
    
    from yt_dl import youtube_dl
    from TruTVIE import TruTVIE
    from extractors import youtube_dl as ytdl
    import re

    class TestTruTVIE(unittest.TestCase):
        def test_TruTVIE_constructor(self):
            '''
            Test TruTVIE constructor
            '''
            url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'


# Generated at 2022-06-24 13:20:59.968494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-24 13:21:09.211684
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert re.match(TruTVIE._VALID_URL, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is not None
    assert re.match(TruTVIE._VALID_URL, 'https://www.trutv.com/full-episodes/1525690/most-shocking-mousetrap-ever.html') is not None
    assert re.match(TruTVIE._VALID_URL, 'https://www.trutv.com/full-episodes/the-carbonaro-effect/1525690/most-shocking-mousetrap-ever.html') is not None

# Generated at 2022-06-24 13:21:17.513452
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor = TruTVIE
    module = TruTVIE.__name__.split('.')[-1] # Get name of module
    func = TruTVIE.__name__.split('.')[-1]  # Get name of function
    # Set values to be compared against
    display_id = "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    title = "Sunlight-Activated Flower"
    description = "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-24 13:21:24.883273
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    match = re.compile(TruTVIE._VALID_URL).match(url)
    assert match.group(0) == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert match.group(1) == 'the-carbonaro-effect'
    assert match.group(2) == 'sunlight-activated-flower'
    assert match.group(3) == None
    test = TruTVIE._TEST
    assert test['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:21:35.833755
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()
    url = m._TEST['url']
    assert m._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert m._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:21:36.443717
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:38.171138
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:39.055428
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor test
    assert TruTVIE()


# Generated at 2022-06-24 13:21:40.248257
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:21:40.888499
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:42.281122
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert isinstance(obj, TruTVIE)
    obj.suite()

# Generated at 2022-06-24 13:21:43.725049
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.ie_key() == 'truTV'

# Generated at 2022-06-24 13:21:44.685519
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(TurnerBaseIE())

# Generated at 2022-06-24 13:21:54.713492
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE({})
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:55.785406
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'

# Generated at 2022-06-24 13:21:58.573927
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE constructor")
    test_1 = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert(isinstance(test_1, TruTVIE))

# Generated at 2022-06-24 13:22:00.481770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        raise AssertionError("Could not create TruTVIE instance")


# Generated at 2022-06-24 13:22:01.010889
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:22:01.864366
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:22:02.755582
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()

# Generated at 2022-06-24 13:22:12.330068
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Create an instance of TruTVIE
    test_TruTVIE = TruTVIE()

    # Check the VALID_URL property
    valid_url = re.match(test_TruTVIE._VALID_URL, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    (test_TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))' == True)
    print("test Passed. VALID_URL matches.")

    #

# Generated at 2022-06-24 13:22:13.868900
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL
    assert TruTVIE._TEST

# Generated at 2022-06-24 13:22:16.659548
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None,{})._real_extract(
        "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")


# Generated at 2022-06-24 13:22:24.025498
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE constructor"""
    trutv = TruTVIE()
    assert 'TruTVIE' == trutv.IE_NAME
    assert 'trutv.com' == trutv.host
    assert 'https://api.trutv.com/v2/web/%s/%s/%s' == trutv.base_url
    assert 'https://tve.turner.com/a/authenticate.html' == trutv.auth_url
    assert 'http://www.trutv.com/e/%s.html' == trutv.embed_url

# Generated at 2022-06-24 13:22:25.500151
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t is not None
    

# Generated at 2022-06-24 13:22:30.094584
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:37.697774
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE()
    assert isinstance(ttvie, TruTVIE)
    assert isinstance(ttvie, TurnerBaseIE)
    assert hasattr(ttvie, "_VALID_URL")
    assert hasattr(ttvie, "_download_json")
    assert hasattr(ttvie, "_extract_ngtv_info")
    assert hasattr(ttvie, "_real_extract")
    assert hasattr(ttvie, "IE_NAME")
    assert hasattr(ttvie, "TEST")

# Generated at 2022-06-24 13:22:38.671619
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None


# Generated at 2022-06-24 13:22:40.941663
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        str(TruTVIE)
        return TruTVIE, 'TruTVIE'
    except:
        print("Error: instantiating TruTVIE")

# Generated at 2022-06-24 13:22:44.149030
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_TruTVIE = TruTVIE()._real_extract(test_url)
    print(test_TruTVIE)


# Generated at 2022-06-24 13:22:46.475616
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test import run_test
    ### You can test it by
    ### $ python -m doctest -v youtube_dl/extractor/trutv.py
    ### >>> TruTVIE
    run_test(TruTVIE)

# Generated at 2022-06-24 13:22:47.262230
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('/')

# Generated at 2022-06-24 13:22:55.724993
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE = TruTVIE()
    assert TruTVIE is not None, "Failed to create TruTVIE instance"

    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:56.282804
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:05.046796
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case with http://www.trutv.com/shows/full-episodes/lizard-lick-towing/videos/lizard-lick-vs-mechanic-hells-kitchen.html
    trutv = TruTVIE()
    m = re.match(trutv._VALID_URL, "http://www.trutv.com/shows/full-episodes/lizard-lick-towing/videos/lizard-lick-vs-mechanic-hells-kitchen.html")
    assert m
    series_slug, clip_slug, video_id = m.groups()
    assert series_slug == "lizard-lick-towing"
    assert clip_slug == "lizard-lick-vs-mechanic-hells-kitchen"
   

# Generated at 2022-06-24 13:23:05.690016
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test without fail
    TruTVIE()

# Generated at 2022-06-24 13:23:09.023191
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_downloader import get_testcases
    # Get all testcases from the parent class
    testcases = get_testcases(TurnerBaseIE)

    # Get the testcases for this class and add them to the global list
    testcases += get_testcases(TruTVIE)

    # Return all the testcases
    return testcases

# Generated at 2022-06-24 13:23:12.708364
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    assert TruTVIE  # If the test fails, no report will be generated

# Unit testing for _real_extract function of class TruTVIE

# Generated at 2022-06-24 13:23:14.136206
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_name = TruTVIE.__name__
    class_obj = TruTVIE
    assert class_name == "TruTVIE"
    assert class_obj != None

# Generated at 2022-06-24 13:23:15.095506
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor_test_for(TruTVIE)

# Generated at 2022-06-24 13:23:15.482478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:19.106187
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_obj = TruTVIE()
    test_obj.initialize()
    test_obj.test(test_url)


# Generated at 2022-06-24 13:23:19.639191
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:20.109448
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:21.075712
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None

# Generated at 2022-06-24 13:23:22.929753
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE
    TruTVIE_test = TruTVIE()
    expectedOutput = TruTVIE
    assert TruTVIE_test.__class__ == expectedOutput


# Generated at 2022-06-24 13:23:25.014630
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:23:25.623865
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): TruTVIE()

# Generated at 2022-06-24 13:23:26.203472
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:23:26.895132
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert(True)

# Generated at 2022-06-24 13:23:27.444937
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:28.033944
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:28.882785
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() is not None

# Generated at 2022-06-24 13:23:30.973250
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    data = {"_TEST": {}}
    TrueTVIE = TruTVIE(data)
    assert TrueTVIE._VALID_URL  
    assert TrueTVIE._TEST

# Generated at 2022-06-24 13:23:40.958785
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:42.963779
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    >>> TruTVIE()
    <TruTVIE(id=None, url=None)>
    """

# Generated at 2022-06-24 13:23:44.756382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:23:50.237982
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ie.suitable('https://www.trutv.com/full-episodes/6256/impractical-jokers-the-impractical-jokers-masquerade.html')
    assert ie.suitable('https://www.trutv.com/full-episodes/6563.html')

# Generated at 2022-06-24 13:23:51.937265
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test for constructor of class TruTVIE"""
    ies = TruTVIE()
    assert isinstance(ies, TruTVIE)


# Generated at 2022-06-24 13:23:52.423049
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:52.903017
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:59.129419
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TODO: Add more test for TruTVIE
    a = TruTVIE()
    assert a._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:59.763851
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:00.323175
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:08.798904
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie._BUILD_SIG_BASE == 'pymtru5'
    assert ie._BUILD_SIG_STRING == '8e46340a1b75f9b281efb9fd8fd7e88b'
    assert ie._BUILD_TEMPLATE == 'build/ngtv-splayer.b0ea6d1{}.js'
    assert ie._BUILD_TEM

# Generated at 2022-06-24 13:24:11.508550
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        # Check is TruTVIE is initialized properly
        obj = TruTVIE()
    except:
        assert(0), "Failed to initialize TruTVIE"

# Generated at 2022-06-24 13:24:12.085895
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-24 13:24:13.930624
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # constructor of class TruTVIE must be able to
    # create an instance of class TruTVIE without raising any exception
    TruTVIE()

# Generated at 2022-06-24 13:24:14.440607
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:14.968944
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:17.235865
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.name in TruTVIE._ALL_IE_LIST

# Generated at 2022-06-24 13:24:18.844477
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        assert False
    except:
        assert True

# Generated at 2022-06-24 13:24:20.391071
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): 
    m = TruTVIE()
    assert m != None


# Generated at 2022-06-24 13:24:25.671916
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv_ie.ie_key() == 'TruTV'
    assert trutv_ie.ie_id() == TruTVIE.ie_key()
    assert trutv_ie.title() == 'TruTV'
    assert trutv_ie.description() == 'http://www.trutv.com/'
    assert trutv_ie.can_extract_id('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True

# Generated at 2022-06-24 13:24:27.328641
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Test constructor of TruTVIE")
    obj = TruTVIE()
    assert obj is not None


# Generated at 2022-06-24 13:24:27.829055
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:39.192155
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.name == "trutv"
    assert ie.ie_key() == 'trutv'
    assert ie.valid_url('https://www.trutv.com/shows/hackers/videos/hacked-kids-phones.html')
    assert ie.valid_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ie.valid_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/fake-earthquake.html')
    assert not ie.valid_url('https://www.trutv.com/shows/hackerville/cast/julieta-nicolau.html')

# Generated at 2022-06-24 13:24:40.158975
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:24:42.659553
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:24:46.218239
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # unit test for constructor of class TruTVIE
    TruTVIE()
    # unit test for extract method of class TruTVIE
    TruTVIE()._real_extract(
            'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:24:46.796760
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:49.202403
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE
    # TruTVIE should be an instance of class TruTVIE
    assert isinstance(TruTVIE(), TruTVIE)

# Generated at 2022-06-24 13:24:49.694380
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:51.806092
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Basic test case for class TruTVIE.
    """
    trutv_ie = TruTVIE()

    assert trutv_ie is not None

# Generated at 2022-06-24 13:24:52.758307
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE();
    print("Succesful testing of TruTVIE class");

# Generated at 2022-06-24 13:24:54.836503
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    print(ie.ie_key())
    print(ie.SUITES)
    print(ie._VALID_URL)
    print(ie._TEST)


# Generated at 2022-06-24 13:24:55.697241
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()

# Generated at 2022-06-24 13:24:56.212209
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:05.499696
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ie = TruTVIE()
	url_test1 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	url_test2 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	url_test3 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	info1 = ie._real_extract(url_test1)
	info2 = ie._real_extract(url_test2)
	info3 = ie._real_extract(url_test3)
	assert info1 == info2 == info3
	#print info3

# Generated at 2022-06-24 13:25:06.976193
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TruTVIE)

# Generated at 2022-06-24 13:25:08.516984
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    return trutv

# Generated at 2022-06-24 13:25:09.387694
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # should not raise an exception
    TruTVIE()

# Generated at 2022-06-24 13:25:12.002545
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create TruTVIE instance to test TruTVIE functionality.
    trutv_ie = TruTVIE()

    # Test TruTVIE initialization
    assert isinstance(trutv_ie, TruTVIE)

# Generated at 2022-06-24 13:25:21.120819
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")._T

# Generated at 2022-06-24 13:25:27.316955
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()

# Generated at 2022-06-24 13:25:32.044498
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    ie = TruTVIE()
    ie._download_json(ie._extract_video_data(url)['url'], ie._VALID_URL)
    assert True



# Generated at 2022-06-24 13:25:34.463609
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing class instantiation
    truTV = TruTVIE()
    assert truTV is not None
    assert truTV.site_name == 'truTV'

# Generated at 2022-06-24 13:25:40.597692
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    url = 'https://www.trutv.com/shows/full-episodes/videos/sunlight-activated-flower.html'
    result = re.search(test._VALID_URL, url)
    if result is None:
        print('result is None')
    print(result.groups()[0])
    print(result.groups()[1])
    print(result.groups()[2])

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:25:42.157825
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test for TruTVIE (see: https://github.com/ytdl-org/youtube-dl/issues/6472)
    TruTVIE()

# Generated at 2022-06-24 13:25:44.517778
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''Unit test for TruTVIE'''
    trutv = TruTVIE()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:25:52.704836
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    data = m._real_extract(url)
    assert data['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert data['display_id'] == 'sunlight-activated-flower'
    assert data['title'] == 'Sunlight-Activated Flower'
    assert data['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-24 13:25:58.824014
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv:tv'
    assert ie.ie_key() == 'TruTV'

    # TODO: Unit test for methods: _real_extract
    # TODO: Unit test for methods: _extract_ngtv_info
    # TODO: Unit test for methods: _extract_ngtv_formats
    # TODO: Unit test for methods: _extract_ngtv_subtitles

# Generated at 2022-06-24 13:26:08.365399
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:26:08.933432
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:10.531233
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    inst = TruTVIE()
    assert isinstance(inst, TruTVIE)


# Generated at 2022-06-24 13:26:20.098321
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIEInstance = TruTVIE()
    assert TruTVIEInstance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIEInstance._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:26:31.684808
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    # Checking if URL is valid
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Checking class funtions with test parameters

# Generated at 2022-06-24 13:26:37.692619
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.name == "truTV"
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:42.468695
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test for TruTVIE instantiation
    trutv_ie = TruTVIE()
    # test for TruTVIE url_result()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    output = TruTVIE().url_result(url)
    assert output == True


# Generated at 2022-06-24 13:26:52.752000
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from unittest import main
    from ._test_utils import TEST_SITE_INSTANCES_IDENTICAL_SITE_CASES, TEST_SITE_INSTANCES_DIFFERENT_SITE_CASES
    from ._test_utils import TEST_SITE_INSTANCES_IDENTICAL_SITE_CASE_TESTS
    from .test_utils import tst_val_eq_fnc_args

    ####
    # Test TruTVIE class variables

# Generated at 2022-06-24 13:26:53.179474
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:26:55.069503
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test class constructor with valid URL
    TruTVIE(TruTVIE._TEST.copy())

test_TruTVIE()

# Generated at 2022-06-24 13:26:57.703806
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:27:05.531083
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test import mock_browser
    from . import TruTVIE

    url = 'https://www.trutv.com/shows/impractical-jokers/full-episodes/s7-ep11-museum-of-natural-mourning.html'

    with mock_browser(url) as b:
        trutv = b.open(url, TruTVIE)

    assert TruTVIE.suitable(url)
    assert TruTVIE._TEST['url'] == trutv.url
    assert TruTVIE._TEST['info_dict']['id'] == trutv.video_id
    assert TruTVIE._TEST['info_dict']['title'] == trutv._TITLE

# Generated at 2022-06-24 13:27:06.179575
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()

# Generated at 2022-06-24 13:27:09.020208
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(True, {'method': 'test_value'})._METHOD == 'test_value'

# Generated at 2022-06-24 13:27:10.030669
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().get_test_cases()

# Generated at 2022-06-24 13:27:20.693190
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Checking the constructor of class TruTVIE
    # Initialize constructor of class TruTVIE by passing the url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE(url)
    # Check for valid url
    assert trutv_ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Check for valid series slug

# Generated at 2022-06-24 13:27:22.651040
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert False
    assert True


# Generated at 2022-06-24 13:27:32.250724
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test_obj = TruTVIE()
	assert test_obj.extract('https://www.trutv.com/shows/hacking-the-system/videos/hacking-the-system---hacking-the-california-drought.html') is not None
	assert test_obj.extract('https://www.trutv.com/shows/adam-ruins-everything/videos/adam-ruins-photography.html') is not None
	assert test_obj.extract('https://www.trutv.com/shows/full-episodes/hacking-the-system/videos/hacking-the-system---hacking-the-california-drought.html') is not None

# Generated at 2022-06-24 13:27:42.469329
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE(url)
    # Test URL
    assert trutv_ie._url == url
    # Test the regex match
    regex_result = re.match(trutv_ie._VALID_URL, url)
    # Test series slug
    assert regex_result.group('series_slug') == 'the-carbonaro-effect'
    assert trutv_ie._series_slug == 'the-carbonaro-effect'
    # Test clip slug
    assert regex_result.group('clip_slug') == 'sunlight-activated-flower'
    assert trutv_ie._clip_slug == 'sunlight-activated-flower'
   

# Generated at 2022-06-24 13:27:44.742975
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/impractical-jokers/videos/the-butt-of-the-joke.html')

# Generated at 2022-06-24 13:27:51.762181
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36'
    sess = TruTVIE.get_session(user_agent)

# Generated at 2022-06-24 13:27:54.558803
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:27:56.576431
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TruTVIE)


# Generated at 2022-06-24 13:28:05.638808
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    # Test media id
    test_media_id = "test_media_id"
    trutv_ie._extract_ngtv_info(test_media_id, {}, {})

    # Test url
    test_url = "http://test.com"
    trutv_ie._download_ngtv_formats(test_url, None)

    # Test site
    test_site_name = "test_site"
    trutv_ie._extract_ngtv_info(None, {}, {'site_name': test_site_name})

# Test TruTVIE object
test_TruTVIE()

# Generated at 2022-06-24 13:28:07.769031
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE', 'TruTVIE.test_TruTVIE', TruTVIE._TEST)

# Generated at 2022-06-24 13:28:16.163525
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()
    # test TruTVIE.ie_key
    assert(truTVIE.ie_key() == 'trutv')
    # test TruTVIE._VALID_URL
    assert(truTVIE._VALID_URL == TruTVIE._VALID_URL)
    # test TruTVIE._TEST
    assert(truTVIE._TEST == TruTVIE._TEST)
    # test TruTVIE._download_json()
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:28:19.072614
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:28:22.867277
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except IOError:
        print("constructor of class TruTVIE threw an IOError, but that's fine.")
    except:
        assert False, "unexpected exception type when constructing a TruTVIE object"


# Generated at 2022-06-24 13:28:23.659349
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    h = TruTVIE()


# Generated at 2022-06-24 13:28:24.703551
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL

# Generated at 2022-06-24 13:28:27.017844
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert isinstance(ie, TruTVIE)


# Generated at 2022-06-24 13:28:36.641293
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:28:42.545524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE.
    """
    trutv_ie = TruTVIE()
    assert trutv_ie.ie_key() == 'TruTV'
    assert trutv_ie.ie_name() == 'TruTV'
    assert trutv_ie.ie_description() == 'TruTV'

# Generated at 2022-06-24 13:28:44.760915
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._downloader.urlopen = lambda a: None
    TruTVIE()._real_extract('')


# Generated at 2022-06-24 13:28:46.214836
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE is not None)
    return TruTVIE