

# Generated at 2022-06-24 13:18:42.284970
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_obj = TruTVIE()
    print(ttv_obj._VALID_URL)

# Generated at 2022-06-24 13:18:43.061372
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:54.433538
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv_ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:18:55.034925
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:59.587389
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE._download_json = lambda x, y: {}
    TruTVIE._extract_ngtv_info = lambda *args: {'_type': 'url_transparent'}
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')._type == 'url_transparent'

# Generated at 2022-06-24 13:19:00.530862
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:09.891081
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._BASE_URL == 'https://api.trutv.com/v2/mobile/'
    assert trutv._NGTV_AUTH_QUERY == {'partner': 'ngtv'}
    assert trutv._NGTV_URLS == {
        'ngtv_url': 'https://api.trutv.com/v2/mobile/series/ngtv?seriesId=%s'
    }

# Generated at 2022-06-24 13:19:12.952050
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    truTVIE = TruTVIE()
    print(truTVIE._real_extract(url))

# Generated at 2022-06-24 13:19:15.645083
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        test_obj = TruTVIE()
    except:
        assert False, "Failed to create constructor for class TruTVIE"


test_TruTVIE()

# Generated at 2022-06-24 13:19:16.899812
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    dl = TruTVIE()

# Generated at 2022-06-24 13:19:27.553135
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:29.085747
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constants = {'TruTVIE': TruTVIE}
    return constants


# Generated at 2022-06-24 13:19:34.016276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:34.455762
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:43.131477
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case = TruTVIE()._TEST
    # extract() of TruTVIE

# Generated at 2022-06-24 13:19:50.515243
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE('https://www.trutv.com/full-episodes/1602164/craziest-social-experiments-1-full-episode.html')
    #TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/1602164/craziest-social-experiments-1-full-episode.html')

# Generated at 2022-06-24 13:19:51.070013
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:52.196524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t is not None

# Generated at 2022-06-24 13:20:03.828944
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # The constructor of class TruTVIE should accept either a video id and a series slug,
    # or a video slug, but not neither or both.
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(url)
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/2345.html'
    TruTVIE(url)
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/2345.html'
    TruTVIE(url)
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/2345.html'
    TruTVIE(url)

# Generated at 2022-06-24 13:20:06.699586
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    trutv._real_extract('http://trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:20:07.583317
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
# /Unit test for constructor of class TruTVIE


# Generated at 2022-06-24 13:20:13.130241
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(isinstance(TruTVIE(), TruTVIE))

# Acceptance test (non-regression)
if(__name__ == '__main__'):
    # Get URL of test video
    test_video_url = TruTVIE()._TEST['url']
    print("Test video URL: " + test_video_url)

    # Get info for test video
    test_video_info = TruTVIE()._TEST['info_dict']
    print("Test video info: %s" % repr(test_video_info))

    # Get downloader's real info
    real_test_video_info = TruTVIE().extract(test_video_url)

    # Assert video title
    assert(test_video_info['title'] == real_test_video_info['title'])

    # Assert video

# Generated at 2022-06-24 13:20:23.515075
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_ie = TruTVIE()
    assert ttv_ie.IE_NAME == 'trutv'
    assert ttv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:20:25.817274
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:20:28.258088
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_ = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert class_.test

# Generated at 2022-06-24 13:20:29.081789
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()

# Generated at 2022-06-24 13:20:39.972036
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert(obj.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
    assert(not obj.suitable('https://www.trutv.com/shows/the-carbonaro-effect/'))
    assert(obj.suitable('https://www.trutv.com/full-episodes/170189/the-carbonaro-effect-may-11-2016.html'))
    assert(not obj.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', False))

# Generated at 2022-06-24 13:20:40.355456
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:43.815153
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    ie._real_extract(url)

# Generated at 2022-06-24 13:20:44.403536
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:56.007854
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    unit_test_TruTVIE = TruTVIE()
    assert unit_test_TruTVIE._download_json('https://api.trutv.com/v2/web/series/clip/movies-you-didnt-know-were-based-on-true-stories/a-league-of-their-own-was-a-hit-at-the-box-office-and-also-with-critics')['info']['title'] == "Movies You Didn't Know Were Based on True Stories: A League of Their Own Was a Smash at the Box Office and with Critics"

# Generated at 2022-06-24 13:20:57.362964
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'

# Generated at 2022-06-24 13:21:00.922235
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from ..utils import test_xpath_extract
    from ..extractors import ExtractorGenericTestCase

    class TruTVTestCase(ExtractorGenericTestCase):
        IE = TruTVIE

    # Test for TruTVIE constructor
    TruTVTestCase(
        TruTVIE,
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:21:04.225521
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html","Sunlight-Activated Flower", "A customer is stunned when he sees Michael's sunlight-activated flower."
                                                                                                      "")

# Generated at 2022-06-24 13:21:06.392743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:21:08.132484
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:21:16.925709
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    obj.url = "hello"
    obj.series_slug = "hello"
    obj.clip_slug = "hello"
    obj.video_id = "hello"
    obj.path = "hello"
    obj.display_id = "hello"
    obj.data = "hello"
    obj.video_data = "hello"
    obj.media_id = "hello"
    obj.title = "hello"
    obj.info = "hello"
    obj.thumbnails = "hello"
    obj.image = "hello"
    obj.image_url = "hello"

# Generated at 2022-06-24 13:21:20.470494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of the class
    test_obj = TruTVIE()

    # Check that the the class constructor returns an instance of the class itself and not None
    # By default, assertEqual does an equality test
    # If the two arguments differ, the test will fail with a specified message.
    assert test_obj is not None, "TruTVIE class constructor should return a class instance and not None"


# Generated at 2022-06-24 13:21:22.114841
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('www.trutv.com/full-episodes/112233/videos/112233')

# Generated at 2022-06-24 13:21:24.551825
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest

    class Test_TruTVIE(unittest.TestCase):
        def test_TruTVIE(self):
            self.assertTrue(TruTVIE)

    unittest.main()

# Generated at 2022-06-24 13:21:31.245087
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from tests.test_downloader import TestDownloader
    from utils import encode_data_uri
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.version import __version__
    downloader = TestDownloader()
    TruTVIE()
    encode_data_uri({}, 'unknown')
    InfoExtractor._print_debug_info()
    downloader.close()
    downloader.download(['url'])
    __version__.split('-')

# Generated at 2022-06-24 13:21:34.091781
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract("f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1")
    assert True

# Generated at 2022-06-24 13:21:43.141615
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ctor = TruTVIE
    ctor.__name__ = "rrrrr"
    assert ctor.__name__ == "rrrrr"
    assert ctor._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ctor.ie_key() == 'TruTV'
    assert ctor.site_url() == 'trutv.com'
    assert ctor.sever_funcname() == '_extract_ngtv_info'

# Generated at 2022-06-24 13:21:52.670658
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    _TEST = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
    TruTVIE()._real_extract(_TEST['url'])

# Generated at 2022-06-24 13:21:59.542450
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:00.207048
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:01.415636
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    return True

# Generated at 2022-06-24 13:22:02.436302
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

test_TruTVIE()

# Generated at 2022-06-24 13:22:07.007390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Verify that the constructor is working
    trutv_ie = TruTVIE()
    assert(trutv_ie.IE_NAME == 'truTV')
    assert(trutv_ie.TURNER_DATA_URL == 'http://www.trutv.com/video-clips.html')


# Generated at 2022-06-24 13:22:07.662034
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(True)

# Generated at 2022-06-24 13:22:10.101258
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(url)

# Generated at 2022-06-24 13:22:10.650659
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:16.093119
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == "https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))"
    assert TruTVIE.__name__ == "TruTVIE"

# Generated at 2022-06-24 13:22:16.620960
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:17.140735
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:23.726897
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Tests TruTVIE constructor"""
    test_url = "http://www.trutv.com/shows/big-bang-theory/videos/wolowitz-attempts-to-show-off.html"
    tv = TruTVIE(test_url)
    assert(tv.url == test_url)
    assert(tv.VIDEO_URL_BASE == "https://api.trutv.com/v2/web/%s/%s/%s")
    assert(tv.SERIES_URL_BASE == "https://api.trutv.com/v2/web/series/%s")
    assert(tv.media_id is None)
    assert(tv.series_slug is None)
    assert(tv.clip_slug is None)

# Generated at 2022-06-24 13:22:26.414516
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST['info_dict']['id'] == TruTVIE._extract_info(TruTVIE._TEST['url'])['id']

# Generated at 2022-06-24 13:22:28.355324
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	import TruTVIE
	truTV = TruTVIE.TruTVIE()
	return truTV # test that constructor returns object

# Generated at 2022-06-24 13:22:29.611566
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__doc__ is not None



# Generated at 2022-06-24 13:22:40.172362
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check if TruTVIE object is created
    try:
        TruTVIE(None)
    except Exception:
        assert False, "Object is not created"

    # Check if _VALID_URL variable is present in TruTVIE object
    try:
        TruTVIE._VALID_URL
    except Exception:
        assert False, "Validated URL variable is not present"

    # Check if _TEST variable is present in TruTVIE object
    try:
        TruTVIE._TEST
    except Exception:
        assert False, "Test variable is not present"

    # Check if _real_extract function is present in TruTVIE object
    try:
        TruTVIE._real_extract
    except Exception:
        assert False, "_real_extract function is not present"

# Generated at 2022-06-24 13:22:47.315628
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:48.233904
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj is not None

# Generated at 2022-06-24 13:22:54.278065
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test a valid json file
    import os
    from ..utils import load_json, compat_urlparse
    from ..compat import compat_etree_parse

    def extract_info(input_json):
        return TruTVIE()._extract_ngtv_info(input_json)

    file_name = os.path.join(os.path.dirname(__file__), 'data', 'test_trutv_video.json')
    json_fpath = load_json(file_name)
    video_site = TruTVIE()
    video_site._extract_ngtv_info(json_fpath['mediaId'], json_fpath)
    # test a invalid json file

    extract_info(json_fpath['mediaId'])

# Generated at 2022-06-24 13:22:55.050663
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().test()

# Generated at 2022-06-24 13:23:03.430361
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case #1
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower'
    truTV = TruTVIE()
    truTV._download_page = lambda x: '<html/>'
    truTV.extract(url)
    assert truTV.display_id == 'sunlight-activated-flower'

    # Test case #2
    url = 'https://www.trutv.com/full-episodes/1864878/impractical-jokers-inside-jokes-friendship-is-magic-season-6-ep-615.html'
    truTV = TruTVIE()
    truTV._download_page = lambda x: '<html/>'
    truTV.extract(url)

# Generated at 2022-06-24 13:23:04.336262
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

test_TruTVIE()



# Generated at 2022-06-24 13:23:11.203065
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Usage: test_TruTVIE(url)
    #   @param url: the URL to be tested
    #   @return returns a dictionary containing all information of the video in the URL
    TruTVIEurl = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    # Actual test for TruTVIE begins here
    TruTVIE_test = TruTVIE(TruTVIEurl)
    TruTVIE_test_extract = TruTVIE_test._real_extract(TruTVIEurl)
    print("TruTVIE_test_extract : ", TruTVIE_test_extract)

# Generated at 2022-06-24 13:23:15.847409
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Example:
    # https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.h
    TruTVIE()._real_extract(
            'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.h')

# Generated at 2022-06-24 13:23:18.126382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create object of TruTVIE class
    trutv_module = TruTVIE()

    assert(trutv_module != None)
    return

# Generated at 2022-06-24 13:23:19.549541
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:23:28.326302
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    import logging
    class TruTVIETest(unittest.TestCase):
        def test_truTV(self):
            video_info = TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
            print(video_info)
            print("Episode Name: " + video_info['title'])
            print("Video ID: " + video_info['id'])

    suite = unittest.TestLoader().loadTestsFromTestCase(TruTVIETest)
    unittest.TextTestRunner(verbosity=2).run(suite)

test_TruTVIE()

# Generated at 2022-06-24 13:23:30.095150
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Simple test case to confirm that the TruTVIE
    constructor is invoked correctly
    """
    trutv = TruTVIE()

# Generated at 2022-06-24 13:23:33.136771
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    test_url = TruTVIE._TEST['url']
    if t.suitable(test_url):
        result = t.extract(test_url)
        assert 'm3u8' in result

# Generated at 2022-06-24 13:23:33.742887
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:35.711501
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:23:45.218209
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor on TruTVIE class
    test_TruTVIE = TruTVIE()
    assert_equal(test_TruTVIE._VALID_URL, r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))') #pylint: disable=protected-access

# Generated at 2022-06-24 13:23:45.977814
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:46.988421
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:23:49.116631
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Make sure that construction of class TruTVIE works
    '''
    trutv = TruTVIE()
    assert trutv is not None


# Generated at 2022-06-24 13:23:52.040934
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_name = "TruTVIE"

    # Instantiation of object TruTVIE
    trutvIE_instance = TruTVIE()
    assert trutvIE_instance is not None
    assert type(trutvIE_instance).__name__ == class_name

# Generated at 2022-06-24 13:24:02.272365
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Example url for testing
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Create an instance of the class TruTVIE
    t = TruTVIE()
    if TruTVIE is not None:
        pass
    else:
        raise AssertionError("Could not create instance of class TruTVIE")

    # Execute _real_extract() to extract information from the url
    t._real_extract(url)
    if t._real_extract(url) is not None:
        pass
    else:
        raise AssertionError("Could not extract information from " + url)

    # Find the manifest url

# Generated at 2022-06-24 13:24:04.252489
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Check TruTVIE Constructor"""
    trutvInstance = TruTVIE()
    trutvInstance._VALID_URL

# Generated at 2022-06-24 13:24:08.036828
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:08.899353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:24:17.531976
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'(?x)https?://(?:www\.|mobile\.)?trutv\.com/full-episodes/(?P<series_slug>[0-9A-Za-z-]+)/(?P<id>\d+)'
    assert TruTVIE._TEST['url'] == 'http://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert TruTVIE._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:24:19.192417
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tro = TruTVIE()
    assert isinstance(tro, TruTVIE)

# Generated at 2022-06-24 13:24:19.827770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:20.941859
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    return 0


# Generated at 2022-06-24 13:24:28.332947
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()
    assert truTVIE.suitable("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") == "TruTV"
    assert truTVIE.suitable("http://www.trutv.com/shows/the-carbonaro-effect/full-episodes/episode-106.html") == "TruTV"
    # assert truTVIE.suitable("") == "TruTV"
    # assert truTVIE.suitable("") == "TruTV"

# Generated at 2022-06-24 13:24:29.941777
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()


test_TruTVIE()

# Generated at 2022-06-24 13:24:30.722368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:31.757485
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:24:42.611010
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    input_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    expected_display_id = "sunlight-activated-flower"
    expected_path = "series/clip"
    expected_series_slug = "the-carbonaro-effect"
    expected_clip_slug = "sunlight-activated-flower"
    expected_video_id = ""

    obj = TruTVIE(TruTVIE.ie_key())
    (series_slug, clip_slug, video_id) = re.match(obj._VALID_URL, input_url).groups()

    assert (series_slug == expected_series_slug)
    assert (clip_slug == expected_clip_slug)

# Generated at 2022-06-24 13:24:44.625352
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert isinstance(ie, TruTVIE)

# Install TruTVIE as a plugin

# Generated at 2022-06-24 13:24:45.976151
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_class = TruTVIE()
    assert test_class

# Generated at 2022-06-24 13:24:54.251985
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:54.726414
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:56.171152
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()
    assert m._VALID_URL is not None


# Generated at 2022-06-24 13:24:57.061199
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    _TruTV = TruTVIE()

# Generated at 2022-06-24 13:25:02.560502
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))' 
    return 1

# Generated at 2022-06-24 13:25:03.332675
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:10.838737
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    # assert trutv.TurnerBaseIE.__init__()
    assert trutv._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-24 13:25:11.386653
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:12.307074
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:25:12.877033
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:20.289569
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Url from test video
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    
    # Create instance of YoutubeIE
    TruTVIE_instance = TruTVIE()

    # Create expected result
    expected_result = TruTVIE_instance._real_extract(url)

    # Check if data match
    if expected_result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1':
        return True
    return False

# Generated at 2022-06-24 13:25:29.270812
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    from youtube_dl import YoutubeDL
    from youtube_dl.extractor import Extractor
    from utils import jsontree
    ydl = YoutubeDL(params={'debug_printtraffic': True})
    req = ydl.urlopen(url)
    res = req.read()
    #print(res)
    # res is a string, which encodes in utf-8 by default
    data = ydl.extract_info(res, download=False)
    # data is a user-defined dictionary
    #print(data)
    json_tree = jsontree.loads(str(data))
    #print(json_tree)

# Generated at 2022-06-24 13:25:39.507074
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test 1: Construct a TruTVIE object with a valid URL through the constructor.
    trutvIE_test1 = TruTVIE(url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert True # It didn't throw any error, so that's good news.
    # Now we have to make sure that the constructor actually parsed the given URL correctly.
    assert trutvIE_test1._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:40.349749
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE is not None

# Generated at 2022-06-24 13:25:41.526329
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE', True) #Constructor of class TruTVIE

# Generated at 2022-06-24 13:25:41.967444
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-24 13:25:43.612727
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv != None
    assert type(trutv) == TruTVIE

# Generated at 2022-06-24 13:25:44.758818
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie=TruTVIE()
    print(ie)


# Generated at 2022-06-24 13:25:54.119812
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Some valid URL for the class to be tested
    test_url = TruTVIE._TEST['url']
    # Expected id from TruTVIE._TEST
    expected_id = TruTVIE._TEST['info_dict']['id']
    # Create instance of the class using _TEST
    instance = TruTVIE()

    # Test TruTVIE.suitable and it should return True
    assert instance.suitable(test_url) is True

    # Test TruTVIE._real_initialize and make sure the id is correct
    assert instance._real_initialize(test_url) == expected_id

    # Test TruTVIE._real_extract
    assert instance._real_extract(test_url) is not None

# Generated at 2022-06-24 13:25:55.121173
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-24 13:25:57.264521
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-24 13:25:58.674301
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """

    TruTVIE()

# Generated at 2022-06-24 13:25:59.625064
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:08.760634
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:12.746860
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        test_TruTVIE = TruTVIE()
    except Exception as exception:
        print("Error encountered in constructor of class TruTVIE, constructor threw an exception.")
        print("Exception thrown: " + str(exception))
        exit(1)


# Generated at 2022-06-24 13:26:13.323579
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:17.894009
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Test TruTVIE constructor')
    trutv_ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    trutv_ie.trutv_ie_run()

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-24 13:26:18.313581
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:18.727208
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-24 13:26:25.025106
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.suitable('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not obj.suitable('http://www.trutv.com')
    assert obj.IE_NAME == 'trutv'
    assert obj.IE_DESC == 'truTV'
    assert obj.VIDEO_DOMAIN == 'trutv.com'
    assert obj.TURNEREVENT_URL_TEMPLATE == 'http://api.trutv.com/v3/trutv-event/%s/%s.js'
    assert obj.TURNER_BRIGHTCOVE_TOKEN == '5634444041001'
    assert obj.TURNER_BRIGHTCOVE_POLICY

# Generated at 2022-06-24 13:26:35.773721
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV_object = TruTVIE()
    assert truTV_object._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:39.551625
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    except TypeError as e:
        assert str(e) == 'TruTVIE constructor only accepts TruTVIE objects'

# Generated at 2022-06-24 13:26:39.945388
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	return TruTVIE()

# Generated at 2022-06-24 13:26:44.378742
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SUCCESS == True
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    

# Generated at 2022-06-24 13:26:50.086714
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    r = TruTVIE()
    assert r._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:51.884731
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    trutv_ie = TruTVIE()

# Generated at 2022-06-24 13:26:54.468373
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:26:58.082596
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    try:
        t.suite()
    except AttributeError:
        assert True
    else:
        assert False

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:27:03.696778
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Arrange
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()

    # Act
    ie._extract_ngtv_info(
            'media_id', {}, {
                'url': url,
                'site_name': 'truTV',
                'auth_required': False,
            })

    # Assert
    # No error is thrown

# Generated at 2022-06-24 13:27:04.838591
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_url = TruTVIE()
    trutv_url.ie_key

# Generated at 2022-06-24 13:27:09.556206
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_search import TestSearchIE
    from .test_turner import TestTurnerBaseIE
    test = TestSearchIE(TruTVIE)
    test.run('TruTVIE')
    test = TestTurnerBaseIE(TruTVIE)
    test.run('TruTVIE')

# Generated at 2022-06-24 13:27:10.206047
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:11.566326
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    print(trutv)



# Generated at 2022-06-24 13:27:21.682770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_ = TruTVIE
    instance = class_('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:26.535345
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case = TruTVIE()
    assert test_case._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:30.586598
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._extract_ngtv_info('mediaid', {}, {'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'}) == test_TruTVIE()._TEST['info_dict']

# Generated at 2022-06-24 13:27:41.138269
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE object"""
    import sys

    if sys.version_info[0] >= 3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_object = TruTVIE(MagicMock())

    # These variables should exist
    assert test_object._VALID_URL
    assert test_object._TEST
    assert TruTVIE._TESTS
    assert test_object._download_webpage
    assert test_object._downloader

    # These variables should not exist
    assert not hasattr(TruTVIE, 'ie_key')

# Generated at 2022-06-24 13:27:46.289389
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # test constructor with ytSearchURL
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # test constructor with ytSearchURL
    TruTVIE('https://www.trutv.com/full-episodes/6397741/impractical-jokers-season-8-episode-19-car-warz.html')

# Generated at 2022-06-24 13:27:46.808935
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:47.242720
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:49.329977
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert x.__class__.__name__ == 'TruTVIE'

# Generated at 2022-06-24 13:27:50.356330
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:27:54.514268
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Example from test of the main class
    TruTVIE()._real_extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Test of the TruTVIE class
    TruTVIE()

# Generated at 2022-06-24 13:27:56.158192
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None

# Generated at 2022-06-24 13:27:58.092465
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert type(obj) == TruTVIE
    return

# Generated at 2022-06-24 13:28:02.097293
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # To test a basic integration of TruTVIE class
    test_obj = TruTVIE()
    # test extract function
    test_obj.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:28:12.554412
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:14.145264
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Unit tests for TruTVIE._real_extract

# Generated at 2022-06-24 13:28:22.781162
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    valid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_obj = TruTVIE()
    trutv_obj._real_extract(valid_url)
    assert trutv_obj.media_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert trutv_obj.display_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:28:24.741540
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Tests TruTV IE"""
    from .test_turner import test_TurnerBaseIE
    test_TurnerBaseIE('TruTV')

# Generated at 2022-06-24 13:28:35.383519
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Create a TruTVIE instance called trutv_instance
    trutv_instance = TruTVIE()

    # Test TruTVIE._VALID_URL
    assert trutv_instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test TruTVIE._TEST
    assert trutv_instance._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert trutv_instance._T

# Generated at 2022-06-24 13:28:45.278081
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Example to test TruTVIE constructor
    tt = TruTVIE()

    # Example to test if valid URL given
    tt.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Should be True
    # assert TruTVIE().suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # Example to test if invalid URL given
    tt.suitable('https://www.trutv.com')
    # Should be False
    # assert TruTVIE().suitable('https://www.trutv.com')

