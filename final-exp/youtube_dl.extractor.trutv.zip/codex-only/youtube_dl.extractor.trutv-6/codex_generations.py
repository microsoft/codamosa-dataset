

# Generated at 2022-06-24 13:18:45.569403
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:46.165624
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:48.376764
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTV = TruTVIE(TurnerBaseIE())
	if truTV:
		print('done')
	else:
		print('failed')

# Generated at 2022-06-24 13:18:49.399946
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    assert True

# Generated at 2022-06-24 13:18:50.009219
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:50.619000
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:55.081941
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    def test_media_id(media_id):
        trutv_ie = TruTVIE()
        trutv_ie.extract(media_id)
    
    # Full (1h) episodes
    test_media_id('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

# Generated at 2022-06-24 13:18:56.497345
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test._download_webpage()
    return

# Generated at 2022-06-24 13:18:57.411705
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass


# Generated at 2022-06-24 13:18:57.762251
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:08.856773
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:09.311494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-24 13:19:13.420907
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_instance = TruTVIE()
    assert trutv_instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:24.587573
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	_VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
	assert re.match(TruTVIE._VALID_URL, url)

# Generated at 2022-06-24 13:19:28.811569
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE('https://www.trutv.com/full-episodes/77483/the-carbonaro-effect-sun-activated-flower-close-up-magic-video.html')

# Generated at 2022-06-24 13:19:29.316188
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:37.466514
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	# Test TruTVIE constructor

# Generated at 2022-06-24 13:19:41.665978
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.__class__.__name__ == 'TruTVIE'
    assert t._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:19:47.058966
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
test_TruTVIE()

# Generated at 2022-06-24 13:19:49.358062
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    #assert str(type(TruTVIE())) == "<class 'yt_trutv.TruTVIE'>"

# Generated at 2022-06-24 13:19:53.493169
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test of TruTVIE
    """
    # Test instance creation
    trutv_test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE(trutv_test_url)
    assert trutv.IE_NAME == 'trutv:shows'
    assert trutv.ie_key() == 'trutv'
    assert trutv.ie_url() == 'https://www.trutv.com'

# Generated at 2022-06-24 13:19:53.983507
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:58.523164
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    inst = TurnerBaseIE.create('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert(type(inst) == TruTVIE)

# Generated at 2022-06-24 13:20:00.537784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case = TruTVIE()
    assert test_case._VALID_URL is not None

# Generated at 2022-06-24 13:20:02.027217
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing that object created successfully
    TruTVIE()


# Generated at 2022-06-24 13:20:03.037659
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE != TruTVIE.__base__

# Generated at 2022-06-24 13:20:07.086611
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-e' \
          'ffect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    info = ie._real_extract(url)
    assert 'ext' in info.keys()

# Generated at 2022-06-24 13:20:12.811368
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:20:14.306489
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .common import TestCommon
    return TruTVIE()._TEST

# Generated at 2022-06-24 13:20:17.074738
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Just try to create an instance of class TruTVIE.
    # No need to check anything.
    TruTVIE()

# Generated at 2022-06-24 13:20:26.191003
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie_obj = TruTVIE()
    # unit test for _real_extract
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    info_dict = {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
    }
    params = {
        # m3u8 download
        'skip_download': True,
    }
    assert_raises(AttributeError, ie_obj._real_extract, url)


# Generated at 2022-06-24 13:20:27.370030
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert [True if TruTVIE is not None else False][0]



# Generated at 2022-06-24 13:20:33.284338
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    print("Unit test for constructor TruTVIE() passed.")


# Generated at 2022-06-24 13:20:36.401933
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    # Should have a valid TruTVIE object
    ttv_ie = TruTVIE()
    assert ttv_ie



# Generated at 2022-06-24 13:20:37.043467
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:40.078563
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TestClass = type('TestClass', (TruTVIE,), {})
    test_obj = TestClass()
    assert test_obj.__name__ == TruTVIE.__name__

# Generated at 2022-06-24 13:20:48.840743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE(url)
    # Check _VALID_URL
    try:
        m = re.search(ie._VALID_URL, url)
        assert m is not None
    except:
        print("test_TruTVIE() FAILED")
        return False
    # Check _TEST
    if (ie._TEST['url'] != url):
        print("test_TruTVIE() FAILED")
        return False
    print("test_TruTVIE() PASSED")
    return True

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-24 13:20:59.465182
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .cbsinteractive import CbsInteractiveIE
    from .turner import NGCIE
    # name of class
    ie = TruTVIE
    # initialization with url
    TruTV = ie(url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # check if instance is of the right type
    assert TruTV._type == 'playlist'
    # check if instance has the right subclasses
    assert TruTV._downloader is not None
    assert TruTV._playlist_result is None
    assert TruTV._playlist_entries is None
    assert TruTV._player_urls is None
    # assert TruTV._player_url is None
    assert TruTV._video_urls is None
    assert TruTV._video_ids is None


# Generated at 2022-06-24 13:21:00.042303
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    temp = TruTVIE()
    return

# Generated at 2022-06-24 13:21:04.716150
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:13.852602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:14.288338
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:15.708242
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .. import TruTVIE
    from . import TurnerBaseIE
    assert issubclass(TruTVIE, TurnerBaseIE)

# Generated at 2022-06-24 13:21:16.169043
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:18.533905
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.test()
    assert ie._get_available_subtitles(None, None) == []
    assert ie.get_access_token(None) is None

# Generated at 2022-06-24 13:21:19.373504
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:28.584772
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert obj._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:21:29.194402
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:29.911173
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:21:30.693096
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:33.822603
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST.get("url") == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"


# Generated at 2022-06-24 13:21:34.417607
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:37.352724
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    print(vars(test_TruTVIE))

# Unit test of _real_extract method of class TruTVIE

# Generated at 2022-06-24 13:21:42.272372
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    assert truTV._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:52.360360
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    trutv_ie.returns = dict()
    trutv_ie.add_to_returns("Sunlight-Activated Flower")
    trutv_ie.add_to_returns("A customer is stunned when he sees Michael's sunlight-activated flower.")
    trutv_ie.add_to_returns("f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1")
    trutv_ie.add_to_returns("mp4")

    TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

    # Check the title is correct

# Generated at 2022-06-24 13:21:53.432538
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        print('Error: TruTVIE tests failed')

# Generated at 2022-06-24 13:22:00.096986
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    # Create object
    constructor_test = TruTVIE(None)
    # Check instance created successfully
    assert constructor_test

    # Check attribute _VALID_URL
    expected_result = re.compile(
        r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    )
    actual_result = constructor_test._VALID_URL
    assert actual_result == expected_result

    # Check attribute _TEST

# Generated at 2022-06-24 13:22:09.976075
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert a._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert a._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:22:10.591756
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE(None) is not None)

# Generated at 2022-06-24 13:22:16.701712
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    uid = "TruTVIE"
    username = "TruTVIE"
    password = "TruTVIE"
    try: 
        # Initialize the unit test for TruTVIE
        unittest = TruTVIE(uid=uid, username=username, password=password)

    except Exception as exc:
        print(exc);
    else:
        print('Successfully Tested TruTVIE')

# Unit test to invoke test method for TruTVIE
test_TruTVIE()

# Generated at 2022-06-24 13:22:19.068889
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Imports the TruTVIE module
    from youtube_dl.extractor.trutv import TruTVIE
    # The TruTVIE class should be a subclass of TurnerBaseIE
    assert issubclass(TruTVIE, TurnerBaseIE)


# Generated at 2022-06-24 13:22:19.595436
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:20.457957
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE')

# Generated at 2022-06-24 13:22:22.302586
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    example = TruTVIE()
    example.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:27.626669
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    valid_url = TruTVIE._VALID_URL
    valid_id = TruTVIE._TEST['info_dict']['id']
    url = TruTVIE._TEST['url']
    s = TruTVIE()
    s._VALID_URL = valid_url
    match = re.match(valid_url, url)
    assert(match.group('series_slug') == 'the-carbonaro-effect')
    assert(match.group('clip_slug') == 'sunlight-activated-flower')
    assert(not match.group('id'))
    s._real_extract(url)
    url = url.replace(match.group('clip_slug'), match.group('id'))
    assert(s._real_extract(url)['id'] == valid_id)
    s._real_

# Generated at 2022-06-24 13:22:31.049999
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttvIE = TruTVIE(None)
    assert ttvIE.suitable(url)

# Generated at 2022-06-24 13:22:41.240879
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	trutv = TruTVIE()
	assert trutv._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
# Test for TruTVIE.initialize()

# Generated at 2022-06-24 13:22:41.701368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:49.075666
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Constructor of TruTVIE
    trutv = TruTVIE()

    # Properties
    print(trutv.IE_NAME)
    print(trutv.IE_DESC)
    print(trutv._VALID_URL)
    print(trutv._downloader)
    print(trutv._download_webpage_handle)
    print(trutv._html_search_regex)
    print(trutv._hidden_inputs)
    print(trutv._form_regex)
    print(trutv._TESTS)
    print(trutv._video_extensions)
    print(trutv._video_extensions)
    print(trutv._WORKING)

# Generated at 2022-06-24 13:22:51.161288
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test constructor of class TruTVIE
    """
    trutvIE = TruTVIE()
    assert trutvIE

# Generated at 2022-06-24 13:22:58.332410
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__=="TruTVIE", "----------------------"  # check class name changed
    assert TruTVIE.__module__=="__main__", "----------------------" # check class module changed
    assert TruTVIE.__doc__ == TurnerBaseIE.__doc__, "----------------------"  # check class doc changed

# Generated at 2022-06-24 13:22:59.799767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == "TruTVIE"



# Generated at 2022-06-24 13:23:04.253999
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # assert TruTVIE._TEST['info_dict'] == TruTVIE()._real_extract(TruTVIE._TEST['url'])
    # FIXME The test fails because the video is not publicly-accessible.
    assert TruTVIE._TEST['info_dict']['id'] in TruTVIE()._real_extract(TruTVIE._TEST['url'])['id']

# Generated at 2022-06-24 13:23:06.410269
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        print ("test_TruTVIE failed: " + repr(e))
        assert False


# Generated at 2022-06-24 13:23:09.819997
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for class TruTVIE
    """
    trutv_ie = TruTVIE()
    trutv_ie._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert None, "Unit test for class TruTVIE passed."

# Generated at 2022-06-24 13:23:11.284175
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): 
    TruTVIE().extract()

# Generated at 2022-06-24 13:23:20.555776
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
	assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:23:22.922101
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    A test for the class TruTVIE
    """

    """
    Creates object of the class
    """
    TruTVIE()

# Generated at 2022-06-24 13:23:30.219294
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test TruTVIE class constructor on valid input
    trutvIE = TruTVIE('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutvIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    return True

test_TruTVIE()

# Generated at 2022-06-24 13:23:31.347110
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
   assert TruTVIE().IE_NAME == 'trutv'


# Generated at 2022-06-24 13:23:34.257328
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # Test download
    ie.download_n_test('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:23:35.857848
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
# Test TruTVIE import
test_TruTVIE()

# Generated at 2022-06-24 13:23:37.008709
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:23:37.585448
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-24 13:23:39.545425
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert isinstance(trutv_ie, TruTVIE)

# Generated at 2022-06-24 13:23:48.642158
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:50.408734
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # It will return code error if this line is not correct
    args = [TurnerBaseIE(), 'https', 'www.trutv.com', 'path/to/api', 'path/to/schema.json']
    assert TruTVIE(*args)

# Generated at 2022-06-24 13:24:00.185715
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:08.707944
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor
    trutv_ie = TruTVIE()
    assert trutv_ie

    url = 'https://www.trutv.com/shows/hack-my-life/videos/countdown-to-hack-my-life.html'
    data = {
        'site_name': 'truTV',
        'auth_required': False,
        'url': url
    }
    media_id = 'digital-media-player'

# Generated at 2022-06-24 13:24:09.574047
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:24:10.326623
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:12.663228
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(url)



# Generated at 2022-06-24 13:24:19.959159
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test constructor of class TruTVIE
    """
    from .trutv import TruTVIE
    import re
    import os

    _VALID_URL = re.compile(
        r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
        )
    ttvie = TruTVIE()
    assert _VALID_URL == ttvie._VALID_URL
    assert "TurnerBaseIE" == ttvie.IE_NAME
    assert ttvie._TEST != {}
    assert "TurnerBaseIE" == ttv

# Generated at 2022-06-24 13:24:21.104363
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('http://www.trutv.com/shows/lizard-lick-towing/full-episodes/episode-7-out-of-control.html')

# Generated at 2022-06-24 13:24:21.749234
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-24 13:24:26.946199
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a new instance of TruTVIE
    trutv_ie = TruTVIE()
    # Check whether the video_url is valid
    is_valid = trutv_ie._TEST.get('url').startswith('https://www.trutv')
    trutv_ie.extract(trutv_ie._TEST.get('url'))


# Generated at 2022-06-24 13:24:37.534754
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiation of class TruTVIE with url of video
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    video_url = TruTVIE(url)
    # Extract ydl of class TruTVIE
    ydl = video_url._TEST
    assert ydl['url'] == url
    assert ydl['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert ydl['info_dict']['ext'] == 'mp4'
    assert ydl['info_dict']['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-24 13:24:38.384405
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert 'TruTVIE' in globals()

# Generated at 2022-06-24 13:24:41.659474
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:24:44.760004
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test instantiate of TruTVIE
    t = TruTVIE()
    # Test function _extract_ngtv_info for TruTVIE
    t._extract_ngtv_info("VID", {}, {'test':'test'})

# Generated at 2022-06-24 13:24:53.361402
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test on a valid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE_instance = TruTVIE()
    TruTVIE_instance._downloader = None

    proper_extract = TruTVIE_instance._extract_ngtv_info('f5d039eeb1f6bcef6c96a6d3f6f3a3a1ebf97655', {}, 
        {'url' : url, 'site_name' : 'truTV', 'auth_required' : True})

    extracted_info = TruTVIE_instance._real_extract(url)
    for key, value in proper_extract.items():
        assert extracted_info[key] == value

    #

# Generated at 2022-06-24 13:25:02.515991
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  ttv = TruTVIE()
  assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:05.130417
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTV=TruTVIE()
	expected_result = "truTV"
	assert truTV._NETRC_MACHINE == expected_result, "Should return truTV"

# Generated at 2022-06-24 13:25:07.407707
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor tests
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL, "Instance variable for TruTVIE has not been initialized correctly"
    assert TruTVIE()._TEST == TruTVIE._TEST, "Instance variable for TruTVIE has not been initialized correctly"

# Generated at 2022-06-24 13:25:08.028226
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:09.595397
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    assert(test_TruTVIE)

# Generated at 2022-06-24 13:25:14.109276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Check if the constructor of class TruTVIE works properly"""
    url = 'http://www.trutv.com/full-episodes/how-to-be-a-grown-up/howto-be-a-grown-up-214-8-24-1850/index.html'
    TruTVIE()(url)

# Generated at 2022-06-24 13:25:14.898516
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:16.268465
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE()
    assert trutvie

# Generated at 2022-06-24 13:25:19.451081
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    res = TurnerBaseIE._call_api('episode', 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', None, {'isAuthRequired': False})
    assert len(res) == 0


# Generated at 2022-06-24 13:25:29.117518
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test case for making sure that TruTVIE's constructor works properly"""
    TruTVIE = TruTVIE()
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:38.515828
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of TruTVIE
    ie = TruTVIE()
    # if the constructor is working,
    # the url should be valid
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # the test for valid url should return True
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True

# Generated at 2022-06-24 13:25:38.917932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:41.803933
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TurnerBaseIE()
    assert trutvIE.ie_key() == 'truTV'
    assert trutvIE.ie_name() == "truTV"

    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutvIE = TruTVIE()
    trutvIE._real_extract(url)

# Generated at 2022-06-24 13:25:43.720124
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test to ensure that the constructor of the TruTVIE class exists
    assert hasattr(TruTVIE, '__init__')


# Generated at 2022-06-24 13:25:53.857187
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Construct the trutv class
    trutv = TruTVIE()

    # Check if url is valid
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))', 'Incorrect _VALID_URL.'

# Generated at 2022-06-24 13:26:04.670783
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    inst = TruTVIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:10.153353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test with a valid show link
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # Test with a valid show link
    TruTVIE('https://www.trutv.com/full-episodes/150928-season-1-episode-7-making-it-rain.html')

# Generated at 2022-06-24 13:26:13.800985
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TrutvIE
    ttv = TruTVIE('trutv', 'abc')
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE.__doc__ == 'TruTV.com support'

# Generated at 2022-06-24 13:26:15.080184
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()



# Generated at 2022-06-24 13:26:18.217682
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == TruTVIE._VALID_URL
    assert ie._TEST == TruTVIE._TEST
    assert ie.__name__ == TruTVIE.__name__

# Generated at 2022-06-24 13:26:20.683781
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        truTVIE = TruTVIE()
        print(truTVIE.extract_info(test_TruTVIE.__test__['url'],True))
#test_TruTVIE()

# Generated at 2022-06-24 13:26:24.909200
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """This function tests that the constructors of the trutv module are working """
    # This test will fail if the constructor of the class TruTVIE is not working

    trutv = TruTVIE()
    assert trutv is not None

# Generated at 2022-06-24 13:26:25.229829
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:26.713570
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert (TruTVIE.__doc__ is not None)
	assert(True)

# Generated at 2022-06-24 13:26:30.295154
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test the TruTVIE constructor
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv_ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:26:30.641947
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-24 13:26:31.221531
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:26:36.720202
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    #test with a sample video
    assert t.suitable("http://www.trutv.com/shows/south_beach_tow/videos/new-tow-truck-paint-job.html")
    #try an unsupported video
    assert not t.suitable("http://www.youtube.com/watch?v=GxgqpCdOKak")

# Generated at 2022-06-24 13:26:38.152284
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.generate_extractors()

# Generated at 2022-06-24 13:26:42.030352
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	print("Start testing")
	test_dict = {
		"url" : "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html",
		"info_dict" : {
			"id": "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1",
			"ext": "mp4",
			"title": "Sunlight-Activated Flower",
			"description": "A customer is stunned when he sees Michael's sunlight-activated flower.",
		},
		"params" : {
		# m3u8 download
			"skip_download": True,
		},
	}
	TruTVIE(test_dict)

# Generated at 2022-06-24 13:26:49.538858
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    trutv = TruTVIE()
    trutv_info = trutv._download_json(
            'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower',
            'the-carbonaro-effect/sunlight-activated-flower')

    print('_download_json test: trutv - ' + str(trutv_info.keys()))

    # Assertion to compare expected and actual result

# Generated at 2022-06-24 13:26:50.090037
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:50.749281
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:51.374743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:52.839742
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert isinstance(x, TruTVIE)

# Generated at 2022-06-24 13:26:53.594762
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:03.297142
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:13.689366
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:15.625240
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor with sample url
    TruTVIE()


# Generated at 2022-06-24 13:27:16.023376
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(True)

# Generated at 2022-06-24 13:27:18.146662
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert str(t) == 'truTV:truTV'


# Generated at 2022-06-24 13:27:22.039511
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.get_info('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.get_info('https://www.trutv.com/full-episodes/1943/the-carbonaro-effect/S03E03.html')

# Generated at 2022-06-24 13:27:22.823164
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-24 13:27:32.430055
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-24 13:27:34.347220
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This test is for authenticating whether or not TruTVIE is correctly built.
    from totv.extractor import TruTVIE

# Generated at 2022-06-24 13:27:35.407181
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Passed without error
    TruTVIE()

# Generated at 2022-06-24 13:27:37.703783
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:27:47.232775
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for TruTVIE class
    """
    # Test TruTVIE object construction
    test_object = TruTVIE()
    test_data = test_object._TEST
    re_match = test_object._VALID_URL
    re_match = re.match(re_match, test_data['url'])
    series_slug = re_match.group('series_slug')
    clip_slug = re_match.group('clip_slug')
    video_id = re_match.group('id')

    # Test TruTVIE._download_json()
    data = test_object._download_json(f'https://api.trutv.com/v2/web/series/clip/{series_slug}/{clip_slug}', clip_slug)

    # Test Tru

# Generated at 2022-06-24 13:27:47.717553
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:58.473162
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj_TruTVIE = TruTVIE()
    assert obj_TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:00.575851
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    print(test_TruTVIE)
    assert test_TruTVIE


# Generated at 2022-06-24 13:28:03.284473
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:28:05.451488
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert type(trutv) == TruTVIE
    assert trutv.NAME == 'trutv.com'

# Generated at 2022-06-24 13:28:06.015021
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:15.231404
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    Instance = TruTVIE()

    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    series_slug, clip_slug, video_id = re.match(Instance._VALID_URL, url).groups()
    if video_id:
        path = 'episode'
        display_id = video_id
    else:
        path = 'series/clip'
        display_id = clip_slug

    assert Instance._download_json(
        'https://api.trutv.com/v2/web/%s/%s/%s' % (path, series_slug, display_id),
        display_id).keys() == ['episode']


# Generated at 2022-06-24 13:28:25.894226
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	"""Unit test for constructor of class TruTVIE"""
	info_dict = {'id': 'id', 'description': 'description', 'ext': 'ext', 'title': 'title', 'season_number': 10, 'episode_number': 10, 'series': 'series', 'display_id': 'display_id', 'timestamp': 'timestamp', 'thumbnails': 'thumbnails'}
	url = 'url'
	series_slug = 'series_slug'
	clip_slug = 'clip_slug'
	video_id = 'video_id'

	url = TruTVIE._VALID_URL
	series_slug, clip_slug, video_id = re.match(TruTVIE._VALID_URL, url).groups()
	assert series_slug == 'clip_slug'
	assert clip_slug

# Generated at 2022-06-24 13:28:35.927548
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:38.708929
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    test_ie = TruTVIE()
    print(test_ie.__name__)

# Generated at 2022-06-24 13:28:40.541290
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE as TruTVIE
    assert TruTVIE is not None
    assert TruTVIE

# Generated at 2022-06-24 13:28:41.299892
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:43.884478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.__class__.__name__ == 'TruTVIE'
