

# Generated at 2022-06-24 13:18:47.164778
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except NameError:
        print("NameError exception thrown during testing of constructor for class TruTVIE")
    except TypeError:
        print("TypeError exception thrown during testing of constructor for class TruTVIE")


# Generated at 2022-06-24 13:18:54.109609
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_TruTVIE = TruTVIE()
    # Test the constructor and the correct class of the instance.
    assert isinstance(test_TruTVIE, TruTVIE), "Instance is not of TruTVIE class"
    # Test the method _real_extract(url) of the instance.
    TruTVIE._real_extract(test_TruTVIE, url)


# Generated at 2022-06-24 13:18:54.710019
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:55.304830
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:00.667728
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    # Test a valid JSON response
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert obj.suitable(url)
    # Test a valid JSON response
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/unique-selling-points.html'
    assert obj.suitable(url)

# Generated at 2022-06-24 13:19:02.406015
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    o = TruTVIE()
    assert isinstance(o, TruTVIE)

# Generated at 2022-06-24 13:19:04.423413
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE(None, None)
    except TypeError as e:
        assert False
        print(e)

# Generated at 2022-06-24 13:19:05.357430
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	a = TruTVIE()

# Generated at 2022-06-24 13:19:06.014655
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:06.627793
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:07.603190
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:19:13.691213
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:19:23.526760
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tester = TruTVIE('3afb4ab97cc8fad9c9e2d7ba31e30f1f8a74aecb', 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', {'site_name': 'truTV'})
    assert tester
    assert tester.data['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert tester.data['site_name'] == 'truTV'
    # TODO: Test other parameter
    # TODO: Test initilizer, extractor

# Generated at 2022-06-24 13:19:24.300851
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:19:32.671850
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    myTest = TruTVIE()
    assert(myTest._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(myTest._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert(myTest._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

# Generated at 2022-06-24 13:19:33.969555
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test = TruTVIE()
	test._VALID_URL

# Generated at 2022-06-24 13:19:40.372095
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-24 13:19:50.814820
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # unit test for constructor of TruTVIE
    # access a video in the trutv website
    TEST_INPUT = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_TruTVIE = TruTVIE(TEST_INPUT)
    # check the _VALID_URL
    assert '_VALID_URL' in test_TruTVIE.__dict__
    # check the _TEST
    assert '_TEST' in test_TruTVIE.__dict__
    # check the _download
    assert '_download' in test_TruTVIE.__dict__
    # check the _download_json
    assert '_download_json' in test_TruTVIE.__dict__
    # check the _extract

# Generated at 2022-06-24 13:19:52.750910
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing constructor of class TruTVIE
    t = TruTVIE()

    # Testing init of class TurnerBaseIE
    t.init()
    assert type(t) == TruTVIE


# Generated at 2022-06-24 13:19:53.809297
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None

# Generated at 2022-06-24 13:20:01.337947
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    url = test.url
    assert url == 'https://www.trutv.com/full-episodes/the-carbonaro-effect/sunlight-activated-flower'

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:20:05.980587
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test_url = TruTVIE._VALID_URL
    series_slug, clip_slug, video_id = re.match(test._VALID_URL, test_url).groups()
    print(series_slug)
    print(clip_slug)
    print(video_id)


# Generated at 2022-06-24 13:20:06.384065
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:12.402939
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url']     == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:20:13.558409
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Verify TruTVIE constructor
    TruTVIE()

# Generated at 2022-06-24 13:20:14.169829
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:20.237152
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:20:20.827052
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:22.534417
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE constructor..."),
    print("PASSED!")
    print('')

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:20:23.653493
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None


# Generated at 2022-06-24 13:20:31.306314
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    test_TruTVIE._TEST = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
    print(test_TruTVIE)

# Generated at 2022-06-24 13:20:42.277022
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """

    # Check for some general valid URL
    url = 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE(url)
    assert isinstance(trutv_ie, TruTVIE)

    # Check the correct values of _VALID_URL & _TEST
    valid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._VALID_URL == valid_url

# Generated at 2022-06-24 13:20:45.967638
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert ie.IE_DESC == 'TruTV'
    assert TruTVIE._VALID_URL == ie._VALID_URL
    assert TruTVIE._TEST == ie._TEST

# Generated at 2022-06-24 13:20:46.882322
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE() # Constructor doesn't take any argument

# Generated at 2022-06-24 13:20:56.662505
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Test for True case
    obj = TruTVIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    #Test for False case
    obj = TruTVIE()
    assert obj._VALID_URL != 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'



# Generated at 2022-06-24 13:20:57.233609
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:21:03.684579
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    IE = TruTVIE()
    # Tests for TruTVIE._VALID_URL
    assert IE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Tests for TruTVIE._TEST

# Generated at 2022-06-24 13:21:04.875212
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    return trutv

# Generated at 2022-06-24 13:21:05.703379
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:12.900051
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TruTVIE)
    assert trutv.ie_key() == 'trutv'
    assert re.match(trutv._VALID_URL, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert re.match(trutv._VALID_URL, 'https://www.trutv.com/shows/most-messed-up/videos/stolen-leathers-and-sticks-and-stones.html')


# Generated at 2022-06-24 13:21:14.104410
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test with empty url
    TruTVIE()


# Generated at 2022-06-24 13:21:14.688537
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:21:18.730486
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test if class TruTVIE is initialized
    t = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Test if URL is valid
    assert(t._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    # Test with a working URL
    t._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Test with

# Generated at 2022-06-24 13:21:20.607420
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Create object of class TruTVIE
    trutv_instance = TruTVIE()

    # Test if the object is an instance of class TruTVIE
    assert isinstance(trutv_instance, TruTVIE)

# Generated at 2022-06-24 13:21:21.756815
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # Assert boolean value of true
    assert True

# Generated at 2022-06-24 13:21:23.935190
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:21:28.809446
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a._TEST == {
        'url' : 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict' : {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-24 13:21:29.502601
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:32.564618
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE()._VALID_URL == TruTVIE._VALID_URL)
    assert(TruTVIE()._TEST == TruTVIE._TEST)


# Generated at 2022-06-24 13:21:34.848595
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.ie_key() == 'trutv'

# Generated at 2022-06-24 13:21:36.595242
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TurnerBaseIE)

# Generated at 2022-06-24 13:21:39.221110
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make sure TruTVIE class is called with a valid url
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:21:48.551053
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert(trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:21:50.504323
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	"""
	Tests TruTVIE constructor
	"""
	truTV = TruTVIE()
	return trutv

# Generated at 2022-06-24 13:21:58.933411
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:00.521072
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.name == 'Turner TruTV'



# Generated at 2022-06-24 13:22:03.018491
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ie = TruTVIE()
	assert ie.SUCCESS_TEST == TruTVIE._TEST
# Testing TruTVIE constructor
test_TruTVIE()

# Generated at 2022-06-24 13:22:12.573974
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .common import InfoExtractor
    from .common import unescapeHTML
    import re


# Generated at 2022-06-24 13:22:21.266719
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #TestCase 1: trutv.com/shows/full-episodes/impractical-jokers/videos/sunlight-activated-flower.html
    test_case1 = TruTVIE();
    test_url1 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_case1._real_extract(test_url1)

    #TestCase 2: trutv.com/shows/full-episodes/impractical-jokers/254462/un-happy-medium.html
    test_case2 = TruTVIE();
    test_url2 = 'https://www.trutv.com/shows/impractical-jokers/254462/un-happy-medium.html'

# Generated at 2022-06-24 13:22:27.997513
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case_1 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_case_2 = 'https://www.trutv.com/full-episodes/14FNfA/the-carbonaro-effect-impractical-jokers-season-2-ep-11'
    
    # non-config mode
    trutv = TruTVIE()
    trutv.extract(test_case_1)
    trutv.extract(test_case_2)

# Generated at 2022-06-24 13:22:32.601916
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Testing TruTVIE constructor for valid url
    """
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(TruTVIE._downloader)
    TruTVIE._real_initialize(url)

# Generated at 2022-06-24 13:22:36.197558
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert TruTVIE("https://www.trutv.com/full-episodes/123456")

# Generated at 2022-06-24 13:22:37.234992
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global TruTVIE
    assert TruTVIE is not None

# Generated at 2022-06-24 13:22:39.722135
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-24 13:22:48.125693
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case passed
    truTV = TruTVIE()
    assert(truTV._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')


# Generated at 2022-06-24 13:22:50.066411
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        print("Error initializing TruTVIE")
        assert False



# Generated at 2022-06-24 13:22:52.444005
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_webpage('http://www.trutv.com/shows/greatest-ever/videos/get-ripped.html', 'none', 'none')

# Generated at 2022-06-24 13:22:52.852069
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:59.418166
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:02.265887
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTV = TruTVIE(TurnerBaseIE._create_get_url_impl(TruTVIE))
    print(TruTV)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:23:03.048118
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None

# Generated at 2022-06-24 13:23:12.515158
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Testing initalization of TruTVIE class
    '''
    # test_path = os.path.dirname(os.path.abspath(__file__))
    # print(test_path)


# Generated at 2022-06-24 13:23:13.365982
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()

# Generated at 2022-06-24 13:23:14.734290
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('test_TruTVIE', 'test_TruTVIE')

# Generated at 2022-06-24 13:23:22.929434
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor of class TruTVIE
    assert TruTVIE._VALID_URL == "https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))"
    # Test TruTVIE._TEST

# Generated at 2022-06-24 13:23:24.266303
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    c = TruTVIE()

# Generated at 2022-06-24 13:23:25.252863
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:26.724236
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.name == 'trutv'

# Generated at 2022-06-24 13:23:27.607776
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiate
    TruTVIE()

# Generated at 2022-06-24 13:23:29.158657
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE('', '')
    print(trutv_ie)


# Generated at 2022-06-24 13:23:29.659670
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	return TruTVIE()

# Generated at 2022-06-24 13:23:33.053125
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from distutils.version import StrictVersion
    import youtube_dl
    assert TruTVIE.__name__ == "TruTVIE", "Incorrect name"
    assert StrictVersion(turner_base) <= StrictVersion(youtube_dl.version.__version__)

# Generated at 2022-06-24 13:23:42.963979
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:23:50.463459
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_instance = TruTVIE()
    assert test_instance._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower."
        },
        'params': {
            'skip_download': True
        }
    }

# Generated at 2022-06-24 13:23:53.961382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test.initialize()
    assert(isinstance(test.to_screen, object))
    assert(isinstance(test.report_warning, object))
    assert(isinstance(test.report_error, object))
    assert(isinstance(test.report_extraction, object))

# Generated at 2022-06-24 13:23:54.987732
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIEInstance = TruTVIE()
    assert TruTVIEInstance is not None


# Generated at 2022-06-24 13:23:59.934100
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie.suitable(url)
    assert ie.IE_NAME == 'TruTV'
    assert ie.VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie.IE_DESC == 'Turner Broadcasting System'
    assert ie.DISPLAY_ID == 'sunlight-activated-flower'

# Generated at 2022-06-24 13:24:08.511154
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    trutv._downloader.params.update({'cachedir': None})
    clip = trutv._real_extract(url)
    assert clip['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert clip['title'] == "Sunlight-Activated Flower"
    assert clip['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert clip['display_id'] == "sunlight-activated-flower"
    assert clip['ext'] == "mp4"
    assert clip['series'] == 'The Carbonaro Effect'

# Generated at 2022-06-24 13:24:10.769450
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 13:24:18.705738
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r"https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"
    assert obj._TEST['url'] == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert obj._TEST['info_dict']['id'] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"

# Generated at 2022-06-24 13:24:28.934648
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    myTest = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    title = 'Sunlight-Activated Flower'
    match = myTest._VALID_URL.match(url)
    data = myTest._download_json(
        'https://api.trutv.com/v2/web/series/clip/%s/%s' % (match.group('series_slug'), match.group('clip_slug')),
        match.group('clip_slug')
    )

    assert data['info']['title'].strip() == title
    assert data['info']['showTitle'] == 'The Carbonaro Effect'

# Generated at 2022-06-24 13:24:34.417779
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:41.416365
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    r = TruTVIE()

    # Test extraction of TrueTV URL to check if it finds video
    test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_media_id = "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    extract = r._real_extract(test_url)
    assert test_media_id == extract.get('id')

# Generated at 2022-06-24 13:24:50.626792
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:24:58.465532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:59.645342
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.download()
    assert(True)

# Generated at 2022-06-24 13:25:00.879735
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test for constructor of class TruTVIE"""
    TruTVIE

# Generated at 2022-06-24 13:25:02.044672
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()

# Generated at 2022-06-24 13:25:03.563719
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    # Expected: TruTVIE object created

# Generated at 2022-06-24 13:25:10.959359
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv:series:clip'
    assert ie.IE_DESC == 'truTV'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:11.913871
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().test()

# Generated at 2022-06-24 13:25:12.486471
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:13.833180
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:25:19.529001
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert(obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(obj._TEST is not {})

# Generated at 2022-06-24 13:25:23.849090
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE = TruTVIE()
    assert TruTVIE
    assert TruTVIE._VALID_URL
    assert TruTVIE._TEST
    assert TruTVIE._real_extract
    assert TruTVIE._download_webpage

# Generated at 2022-06-24 13:25:24.421275
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-24 13:25:25.410494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:25:36.608808
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:44.663333
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    assert(trutv._VALID_URL == TruTVIE._VALID_URL)
    assert(trutv._TEST['url'] == TruTVIE._TEST['url'])
    assert(trutv._TEST['params'] == TruTVIE._TEST['params'])
    assert(trutv._TEST['info_dict'] == TruTVIE._TEST['info_dict'])

# Generated at 2022-06-24 13:25:47.006870
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("\nTESTING TruTVIE.py")
    TruTVIE('', {})

# Generated at 2022-06-24 13:25:49.658378
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_download import _TestDownload
    with _TestDownload() as test:
        TruTVIE().download(test.get_url(TruTVIE._TEST))



# Generated at 2022-06-24 13:25:57.046896
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == """https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"""
    assert TruTVIE()._TEST['url'] == """https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"""
    assert TruTVIE()._TEST['info_dict']['id'] == """f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"""

# Generated at 2022-06-24 13:26:07.044205
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:17.163042
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:18.701655
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert 'TruTV' == trutv._SITE_NAME

# Generated at 2022-06-24 13:26:20.835027
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE(None)
    except:
        assert False, "Constructor throws unexpected exception"
    assert True  # Nothing happens



# Generated at 2022-06-24 13:26:31.549275
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiate the class object
    test_truTVIE = TruTVIE()
    # Set the TruTV IE to its own variable
    test_truTVIE_IE = test_truTVIE._VALID_URL
    # Assert that the TruTV IE is correctly formatted
    assert "The TruTV IE is not correctly formatted" == test_truTVIE_IE
    # Assert that the TEST attributes is correctly formatted
    assert test_truTVIE._TEST
    # Assert that the TruTV IE can handle TruTV URLs
    assert test_truTVIE.suitable("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")


# Generated at 2022-06-24 13:26:41.813108
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from utils import Test
    t = Test()

    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    t.assertEqual(TruTVIE._match_id(url), 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    t.assertEqual(TruTVIE._match_id("https://www.trutv.com/shows/im-sorry/videos/im-sorry-trailer.html"), None)
    url = "https://www.trutv.com/full-episodes/868879/tba/im-sorry-trailer.html"

# Generated at 2022-06-24 13:26:43.470277
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert (TruTVIE(None)._TEST['info_dict']==TruTVIE(None)._TEST['info_dict'])

# Generated at 2022-06-24 13:26:46.923809
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.validite('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert t.download('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:26:48.198454
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    construct = TruTVIE()
    construct._VALID_URL
    construct._TEST
    construct._real_extract

# Generated at 2022-06-24 13:26:52.705937
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # initializing the class
    trutv = TruTVIE()

    # the class has been initialized successfully
    assert (trutv is not None)

    # the class has the required methods
    assert (hasattr(trutv, "_real_extract") and callable(trutv._real_extract))

# Generated at 2022-06-24 13:26:55.643382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not t.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/')
    assert t.IE_NAME == 'TruTV'

# Generated at 2022-06-24 13:26:56.566931
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.suite()

# Generated at 2022-06-24 13:26:58.996946
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Test that TruTVIE is successful in extracting a valid media-id from a
# TruTV episode

# Generated at 2022-06-24 13:27:01.573998
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        tr = TruTVIE()
    except Exception as e:
        print("TruTVIE constructor test failed: {}", e.args)


# Generated at 2022-06-24 13:27:02.127891
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:09.355491
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()

# Generated at 2022-06-24 13:27:10.597930
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .youtube_dl.test import make_test_url_result

    TruTVIE(make_test_url_result(TruTVIE._TEST))

# Generated at 2022-06-24 13:27:11.183581
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:27:21.426552
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # partial match for valid url
    assert TruTVIE._match_id("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    # full match for valid url
    assert TruTVIE._match_id("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    # full match for valid url
    assert TruTVIE._match_id("https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html")

    # partial match for invalid url
    assert TruTVIE._match_id("https://www.trutv.com/shows/the-carbonaro-effect/videos") is None
    # full match for invalid url

# Generated at 2022-06-24 13:27:22.861308
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert(t is not None)


# Generated at 2022-06-24 13:27:23.407005
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    True

# Generated at 2022-06-24 13:27:24.194402
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for TruTVIE.
    """
    TruTVIE()

# Generated at 2022-06-24 13:27:26.167276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  try:
    TruTVIE()
  except Exception as e:
    print("Could not construct class, error: ", str(e))



# Generated at 2022-06-24 13:27:26.852845
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert True

# Generated at 2022-06-24 13:27:27.828738
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:27:28.819244
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE()

# Generated at 2022-06-24 13:27:33.306872
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._download_json = lambda x,y: {}
    ie._extract_ngtv_info = lambda x, y, z: {}
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:27:37.171331
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Simple unit test for TruTVIE.
    """
    # When creating an instance of TruTVIE we expect that TruTVIE.suitable
    instance = TruTVIE()
    assert instance.suitable(TruTVIE._TEST['url']) == True


# Generated at 2022-06-24 13:27:38.170329
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:27:43.606057
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:27:51.057872
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # URL: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    # Series-slug: the-carbonaro-effect
    # Clip-slug: sunlight-activated-flower
    # Video-id: 

    # (1) Ensure that the URL works.
    ttv = TruTVIE()
    ttv_result = ttv._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:27:52.513179
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert 'TruTVIE' in globals()


# Generated at 2022-06-24 13:27:53.159303
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:56.059608
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE constructor
    """
    trutv_ie = TruTVIE()
    assert len(trutv_ie.IE_NAME) > 0

# Generated at 2022-06-24 13:28:06.800890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_cases = [
        (
            'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
            'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
        ),
    ]
    for url, video_id in test_cases:
        assert TruTVIE().suitable(url) == True
        assert re.match(TruTVIE._VALID_URL, url) is not None
        _, series_slug, clip_slug, video_id = TruTVIE()._extract_url_info(url)
        test_obj = TruTVIE()

# Generated at 2022-06-24 13:28:07.903344
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:28:16.223053
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:24.014492
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert instance.IE_NAME == 'trutv'
    assert instance.IE_DESC == 'Turner Broadcasting System - truTV'
    assert instance._TESTS

# Generated at 2022-06-24 13:28:28.613635
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert (TruTVIE._VALID_URL is TruTVIE._TEST['url'])
    assert (TruTVIE._TEST['info_dict']['id'] ==
            TruTVIE._real_extract(TruTVIE._TEST['url']))

# Generated at 2022-06-24 13:28:34.300696
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj_TruTVIE = TruTVIE();
    assert obj_TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))';

# Generated at 2022-06-24 13:28:40.330314
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TurnerBaseIE())._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:28:41.499154
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tvie = TruTVIE()

# Generated at 2022-06-24 13:28:49.711553
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # initialize TruTVIE object
    TruTVIE_obj = TruTVIE(object)
    # test for _VALID_URL
    TruTVIE_obj._VALID_URL = TruTVIE_obj._TEST['url']
    series_slug, clip_slug, video_id = re.match(TruTVIE_obj._VALID_URL, TruTVIE_obj._VALID_URL).groups()
    # test for _download_json
    TruTVIE_obj._download_json(
        'https://api.trutv.com/v2/web/%s/%s/%s' % ('episode', series_slug, video_id),
        video_id)