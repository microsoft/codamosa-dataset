

# Generated at 2022-06-24 13:18:47.749123
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:18:57.679124
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    clip_id = 'a36e92688ad19bb2d347af8a0b2f2b47708cb5cb'
    clip_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    rv = TruTVIE._download_json(
        "https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower", clip_id)
    assert rv['info']['mediaId'] == clip_id
    assert rv['info']['clips'][0]['mediaId'] == clip_id
    clip_info = TruTVIE._extract_ngtv_info(clip_id, {})
    assert clip_info['id'] == clip_

# Generated at 2022-06-24 13:19:02.178987
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = [
        ('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
            {
                'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
            }
        ),
        ('https://www.trutv.com/full-episodes/83090/the-carbonaro-effect-season-2-ep-216.html',
            {
                'id': '83090'
            }
        ),
    ]
    for url, test_dict in test_TruTVIE:
        ie = TruTVIE()
        result_dict = ie._real_extract(url)

# Generated at 2022-06-24 13:19:02.775298
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:03.340960
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:03.912711
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:04.523459
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:05.910745
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-24 13:19:06.487412
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:07.007292
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  t = TruTVIE()
  return t

# Generated at 2022-06-24 13:19:07.596237
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:14.429600
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    videoID = TruTVIE("https://www.trutv.com/shows/hospitals-hackers-and-hayrides/videos/hospitals-hackers-and-hayrides-haunted-hayride-of-horrors.html")
    assert videoID._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:25.611969
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit testing for TruTVIE class
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIEInstance = TruTVIE()
    TruTVIEInstance._extract_ngtv_info = lambda media_id, video_info, video_params: video_info
    result = TruTVIEInstance._real_extract(url)
    assert result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert result['ext'] == 'mp4'
    assert result['title'] == 'Sunlight-Activated Flower'
    assert result['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-24 13:19:28.645782
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    args = "http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutv = TruTVIE()
    print (trutv._VALID_URL)

# Generated at 2022-06-24 13:19:31.791246
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._test_extraction()
    TruTVIE()._test_extraction(
        'https://www.trutv.com/shows/impractical-jokers/videos/the-impractical-jokers-come-clea.html')

# Generated at 2022-06-24 13:19:34.817336
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        # Instantiating the TruTVIE class
        TruTVIE()
    except Exception as e:
        # Asserting that the TruTVIE class is instantiated with no errors
        print(e.__class__)
        assert(False)

# Generated at 2022-06-24 13:19:36.965291
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:19:37.746382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:42.020297
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	ie = TruTVIE()
	print(ie._real_extract(url))

if __name__ == "__main__":
	test_TruTVIE()

# Generated at 2022-06-24 13:19:42.961869
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:19:49.082411
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    video = TruTVIE()
    video.initialize(url)
    info_dict = video.extract(url)
    assert info_dict["id"] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:19:54.965042
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("TruTVIE")
    assert TruTVIE().Match('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE().Match('https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/the-magic-word-is-compromise.html')
    assert TruTVIE().Match('https://www.trutv.com/full-episodes/the-magic-word-is-compromise.html')

# Generated at 2022-06-24 13:20:01.180585
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .. import TruTVIE
    url = 'https://www.trutv.com/shows/impractical-jokers/videos/murr-almost-gets-hurt-segment-1.html'
    TruTVIE(url)._real_extract(url)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:20:05.030313
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert 'Turner Base' == t.ie_key()
    assert 'Turner Base' == t.ie_key(TruTVIE)
    assert 'Turner Base' == t.ie_key(TruTVIE())

# Generated at 2022-06-24 13:20:10.962251
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = 'http://www.trutv.com/shows/the-chris-gethard-show/videos/fun-with-salt-bae.html?linkId=27223680'
    # test url
    m9 = re.search(TruTVIE._VALID_URL, test_url)
    # print(m9.group('series_slug'))
    # print(m9.group('clip_slug'))

    # print(TruTVIE._real_extract(TruTVIE(), test_url))

# Generated at 2022-06-24 13:20:12.681317
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of TruTVIE and test it
    tIE = TruTVIE()
    print(tIE.test())

# Generated at 2022-06-24 13:20:14.166791
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Tests for TruTVIE
    TruTVIE()._get_url_result()

# Generated at 2022-06-24 13:20:24.512779
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  import re
  from .turner import TurnerBaseIE
  from ..utils import (
    int_or_none,
    parse_iso8601,
  )

  class TruTVIE(TurnerBaseIE):
    _VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:20:25.545690
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()


# Generated at 2022-06-24 13:20:30.343982
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'



# Generated at 2022-06-24 13:20:31.804657
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    new_test = TruTVIE()
    assert new_test.__class__.__name__ == 'TruTVIE'


# Generated at 2022-06-24 13:20:34.880642
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.extractor_key() == 'TruTV'
    # Execute the code inside the class constructor
    obj.__init__()
    assert obj.downloader is not None

# Generated at 2022-06-24 13:20:39.762031
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutvie = TruTVIE(True, True)
    trutvie._extract(test_url)
    assert True


# Generated at 2022-06-24 13:20:40.390927
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:20:44.809850
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE.__module__ == '__main__'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:20:46.287725
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE.ie = TruTVIE()



# Generated at 2022-06-24 13:20:47.267755
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('test_url', 'test_action')

# Generated at 2022-06-24 13:20:48.619143
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:20:52.140828
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert TruTVIE._VALID_URL == ie._VALID_URL
    assert TruTVIE._TEST == ie._TEST

# Generated at 2022-06-24 13:20:52.992021
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:00.994590
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # x = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    expected_return = {"id": 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
                       "ext": 'mp4',
                       "title": 'Sunlight-Activated Flower',
                       "description": "A customer is stunned when he sees Michael's sunlight-activated flower.",
                       "params": {
                           'skip_download': True,
                       }
    }
    assert TruTVIE()._real_extract(url) == expected_return

# Generated at 2022-06-24 13:21:10.161289
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert(test_obj._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-24 13:21:10.698910
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:21:18.722529
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:27.032334
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test class attribute _VALID_URL
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Test class attribute _TEST

# Generated at 2022-06-24 13:21:38.491266
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:40.207355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert isinstance(t, TruTVIE)

# Generated at 2022-06-24 13:21:49.508814
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:50.257472
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        TruTVIE()

# Generated at 2022-06-24 13:21:52.537952
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Creating test instance
    TruTVIE_test_instance = TruTVIE()
    assert TruTVIE_test_instance is not None

# Generated at 2022-06-24 13:21:59.200303
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # test invalid URL
    assert t.suitable('www.trutv.com') is False
    assert t.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower')
    assert t.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # ensure that TruTVIE fails when given a URL that it cannot extract from
    assert t._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:01.169480
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:11.041229
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test with a series url
    url = 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    result = TruTVIE()._real_extract(url)
    assert result['display_id'] == 'sunlight-activated-flower'
    assert result['series'] == 'The Carbonaro Effect'
    assert result['title'] == 'Sunlight-Activated Flower'

    # Test with an episode url
    url = 'https://www.trutv.com/full-episodes/923396/flipping-out.html'
    result = TruTVIE()._real_extract(url)
    assert result['display_id'] == '923396'
    assert result['series'] == 'Flipping Out'

# Generated at 2022-06-24 13:22:11.884496
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:22:12.458901
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:14.907049
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:15.464495
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:16.008228
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:18.174369
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")


# Generated at 2022-06-24 13:22:21.944910
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Arrange
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    video = TruTVIE()

    # Act
    video_title = video._real_extract(url)

    # Assert
    assert "Sunlight-Activated Flower" == video_title['title']

# Generated at 2022-06-24 13:22:25.207946
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Constructor for TruTVIE."""
    try:
        TruTVIE()
    except TypeError:
        assert False, "Failed to instantiate TruTVIE"

# Generated at 2022-06-24 13:22:26.094855
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None, None)


# Generated at 2022-06-24 13:22:36.554795
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert(trutv_ie._VALID_URL == r"https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))")
    assert(trutv_ie._API_VERSIONS == {})
    assert(trutv_ie.IE_NAME == 'trutv:trutv')
    assert(trutv_ie.IE_DESC == 'truTV')
    assert(trutv_ie.TURNER_BASE_URL == 'https://www.trutv.com')

# Generated at 2022-06-24 13:22:45.622474
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize TruTVIE class
    trutv_obj = TruTVIE()

    # Validate _VALID_URL
    test_dict = {
        'TruTVIE._VALID_URL is set to correct value':
            trutv_obj._VALID_URL ==
            r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    }

# Generated at 2022-06-24 13:22:46.739579
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    my_ie = TruTVIE()
    assert my_ie is not None

# Generated at 2022-06-24 13:22:47.548644
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:22:49.510200
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_turner import test_TurnerBaseIE
    test_TurnerBaseIE(TruTVIE)


# Generated at 2022-06-24 13:22:50.242874
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:22:50.553848
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:51.165334
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:51.871577
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE("TruTVIE")

# Generated at 2022-06-24 13:23:00.255124
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:06.650789
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    turn = TruTVIE(url)
    assert turn._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert turn._TEST['url'] == url

# Generated at 2022-06-24 13:23:07.202458
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:09.056797
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE('Api.V2.Web', 'show', 'trutv.com')
    assert trutv._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:23:17.278054
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # default case
    test_case = "http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    ttv = TruTVIE()
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:23:24.672510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable('https://www.trutv.com/shows/southbeach-tow/videos/robbed---pistol-whipped.html')
    assert ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'Sunlight-Activated Flower'

# Generated at 2022-06-24 13:23:27.918600
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == (
        r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/'
        r'(?P<series_slug>[0-9A-Za-z-]+)/'
        r'(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    )

# Generated at 2022-06-24 13:23:31.512669
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Declare TruTVIE object
    test_obj = TruTVIE()
    # Check value of VALID_URL
    assert test_obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:34.119179
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(url)

# Generated at 2022-06-24 13:23:37.722187
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE_test = TruTVIE()
    TruTVIE_test.test()
    TruTVIE_test.test_result()
    
if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-24 13:23:38.826419
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__doc__ is not None

# Generated at 2022-06-24 13:23:44.474281
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  
    # Check if can instantiate class TruTVIE
    t = TruTVIE()
    # Test if can get parameters of class TruTVIE
    t.get_parameters()
    # Test if can get host of class TruTVIE
    t.get_host()
    # Test if can get webpage of class TruTVIE
    t.get_webpage()
    # Test if can extract ID from class TruTVIE
    t.extract_id()
    # Test if can extract title from class TruTVIE
    t.extract_title()
    # Test if can extract description from class TruTVIE
    t.extract_description()
    # Test if can extract thumbnail from class TruTVIE
    t.extract_thumbnail()
    # Test if can extract upload date from class TruTVIE
    t.extract_upload_date

# Generated at 2022-06-24 13:23:46.115866
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE._TEST.get('url')
    TruTVIE(url)

# Generated at 2022-06-24 13:23:51.495454
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Constructor test of class TruTVIE"""
    # Case 1: URL of video including video ID
    trutv_url_video_id = TruTVIE(
        TruTVIE._VALID_URL % (
            'the-carbonaro-effect', 'sunlight-activated-flower', None))
    assert trutv_url_video_id

    # Case 2: URL of clip including clip slug
    trutv_url_clip_slug = TruTVIE(
        TruTVIE._VALID_URL % (
            'the-carbonaro-effect', None, 'the-best-of-the-carbonaro-effect'))
    assert trutv_url_clip_slug

# Generated at 2022-06-24 13:23:56.814416
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import json
    from .trutv import TruTVIE
    testData = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
    testExtract = TruTVIE().extract(testData['url'])
    #print(json.d

# Generated at 2022-06-24 13:24:06.901376
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Unit test for TruTVIE.TruTVIE")
    print("Test for TruTVIE.__init__")
    ie = TruTVIE()
    assert ie._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

    print("Test for TruTVIE._real_extract")
    print("TruTVIE._real_extract is not tested.")
    # ie._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:24:07.697747
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-24 13:24:09.178910
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract(TruTVIE._TEST['url'])

# Generated at 2022-06-24 13:24:09.744226
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:11.424429
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test 1: check TruTVIE constructor
    TruTVIE()


# Generated at 2022-06-24 13:24:12.978754
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    try:
        TruTVIE('trutv.com')
    except:
        return False
    return True

# Generated at 2022-06-24 13:24:13.536107
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:24:16.793027
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .mtv import MTVIE
    from .common import InfoExtractor
    # Class must be defined before instantiation
    assert MTVIE.ie_key() in InfoExtractor._ies
    tt = TruTVIE()
    # test presence of several fields
    assert tt.SUCCESS_REGEX is not None
    assert tt.FAILURE_REGEX is not None
    assert tt._format_id is not None

# Generated at 2022-06-24 13:24:17.753101
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE constructor"""
    TruTVIE()

# Generated at 2022-06-24 13:24:19.449014
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert x is not None


# Generated at 2022-06-24 13:24:22.869763
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(url)._real_extract(url)

# Generated at 2022-06-24 13:24:25.894785
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        test_TruTVIE.ie = TruTVIE()
        print('Successfully initialized TruTVIE')
    except:
        print('Failed to initialize TruTVIE')


# Generated at 2022-06-24 13:24:36.705896
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:46.427410
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    # Full Episodes
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:24:48.474998
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:24:49.542385
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL



# Generated at 2022-06-24 13:24:50.727889
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv != None

# Generated at 2022-06-24 13:24:51.101437
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:24:51.482546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:52.147790
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:55.384256
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Test for constructor of class TruTVIE
    test_data = TruTVIE()
    assert(re.compile('TurnerBaseIE').search(str(type(test_data)))) == None
    assert(re.compile('TruTVIE').search(str(type(test_data)))) != None

# Generated at 2022-06-24 13:24:59.364450
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_ = TruTVIE
    print ('\nClass %s constructor tests: ' % class_.__name__)
    instance = class_()

    # Check if _VALID_URL is a String
    assert(isinstance(instance._VALID_URL, str))


if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-24 13:24:59.889681
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-24 13:25:00.453833
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:01.606566
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:25:03.882158
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')



# Generated at 2022-06-24 13:25:04.853837
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE")
    TruTVIE()

# Generated at 2022-06-24 13:25:10.863572
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv_ie.IE_NAME == 'trutv:full_episodes'

# Generated at 2022-06-24 13:25:15.679220
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

    expected_attrs = {
        '_VALID_URL': TruTVIE._VALID_URL,
        '_TEST': TruTVIE._TEST
    }

    for attr in expected_attrs:
        assert expected_attrs[attr] ==  getattr(ie, attr)



# Generated at 2022-06-24 13:25:17.752060
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._extract_ngtv_info('video_id', {},{})
    ie._real_extract('url')

# Generated at 2022-06-24 13:25:19.294910
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'

# Generated at 2022-06-24 13:25:25.723121
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL ==r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:36.649608
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	"""Tests implementation on TruTVIE class, including initialization of class
	and calling of instance methods.

	:return: None
	:rtype: None
	"""
	# Importing modules locally
	from modules.IE import module_ytdl
	import utils

	###################################
	# Testing constructor of class TruTVIE
	###################################

	# Intializing the instance with url parameter
	instance = TruTVIE(module_ytdl.YTDLDriver(), "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

	# Testing if the instance is correctly initialized
	assert type(instance) == TruTVIE
	assert instance.base_url == "https://www.trutv.com"

	# Testing if the instance methods are correctly registered
	assert hasattr

# Generated at 2022-06-24 13:25:37.178520
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:25:42.644492
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    # Check that the class name matches the definition
    assert(repr(trutv) == "<class 'youtube_dl.extractor.trutv.TruTVIE'>")
    # Check that the type of _VALID_URL is str
    assert(isinstance(trutv._VALID_URL, str))
    # Check that the type of _TEST is dict
    assert(isinstance(trutv._TEST, dict))

# Generated at 2022-06-24 13:25:43.505843
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-24 13:25:43.983948
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-24 13:25:46.025701
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv._VALID_URL is not None


# Generated at 2022-06-24 13:25:47.200907
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:25:50.227059
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        # check for TruTVIE's instance
        assert TruTVIE()._TEST['url']
    except Exception:
        raise AssertionError('TruTVIE instance does not exist')

# Generated at 2022-06-24 13:25:57.307899
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ie = TruTVIE()
	assert ie.SUITABLE == (u'url', )
	assert ie.IE_NAME == u'truTV'
	assert ie.BRAND == u'truTV'

# Generated at 2022-06-24 13:25:58.721685
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	obj = TruTVIE()
	print(obj)
	return


# Generated at 2022-06-24 13:26:08.293395
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    func = TruTVIE
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    key = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url_valid = TruTVIE._VALID_URL
    a = re.match(url_valid, key)
    target = TruTVIE(func,key,url)
    target.key = key
    target.url = url
    target.match = a
    assert target.key == key
    assert target.url == url

# Generated at 2022-06-24 13:26:14.693042
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Class to test
    testClass = TruTVIE()

    # Assert that expected class name is returned
    assert testClass.IE_NAME == "trutv"

    # Assert valid object URL is returned
    assert testClass.valid_url("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") == True

    # Assert invalid object URL is returned
    assert testClass.valid_url("https://www.trutv.com/") == False

# Generated at 2022-06-24 13:26:15.296915
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:21.552904
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url = 'https://www.trutv.com/full-episodes/128296/the-carbonaro-effect-season-3-ep-6-my-house-is-playing-tricks-on-me/'
    ie = TruTVIE()
    ie.initialize()
    print(ie.extract(url))

# Unit test
if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:26:22.693883
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    return True

# Generated at 2022-06-24 13:26:25.547741
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(str(TruTVIE) == '<class \'__main__.TruTVIE\'>')


# Generated at 2022-06-24 13:26:27.150619
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #test constructor
    TruTVIE()


# Generated at 2022-06-24 13:26:28.519709
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
   # Test case 1
   # Class is initialised using constructor
   # Test that the instance is created
   trutv = TruTVIE()
   assert trutv
   assert trutv._TEST

# Generated at 2022-06-24 13:26:30.072803
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("TruTVIE", "TruTV") is not None

# Generated at 2022-06-24 13:26:31.459559
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    print(ie)

# Generated at 2022-06-24 13:26:32.675120
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()


# Generated at 2022-06-24 13:26:33.284662
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:34.697546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ create object of class TruTVIE """
    TruTVIE()

# Generated at 2022-06-24 13:26:44.285218
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:26:44.804831
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:48.034576
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None
    assert hasattr(trutv, '_VALID_URL')
    assert hasattr(trutv, '_TEST')

# Generated at 2022-06-24 13:26:56.317458
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # Test for "id" extraction
    assert ie._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    # Test for "clip_slug" and "display id" extraction
    assert ie._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/17538')['display_id'] == '17538'


# Generated at 2022-06-24 13:26:57.204101
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:00.901892
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE_Test = TruTVIE()
    TruTVIE_Test.list_categories()

test = TruTVIE()
test.download_playlist('https://www.trutv.com/shows/truTV_Top_Funniest_Clips.html')

# Generated at 2022-06-24 13:27:03.468886
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()._real_extract(url)

# Generated at 2022-06-24 13:27:10.233482
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Instantiate class
    trutv = TruTVIE()

    # Test regular expressions in _VALID_URL
    series_slug, clip_slug, video_id = re.match(trutv._VALID_URL, trutv._TEST['url']).groups()
    assert series_slug == 'the-carbonaro-effect' and not clip_slug and not video_id

    # Test class properties
    assert trutv._SITE_NAME == 'truTV'
    assert TruTVIE._SITE_NAME == 'truTV'
    assert TruTVIE._NETRC_MACHINE == 'trutv'
    assert TruTVIE._API_BASE_URL == 'https://api.trutv.com/v2/web'

# Generated at 2022-06-24 13:27:10.847369
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE();

# Generated at 2022-06-24 13:27:19.894124
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    This test helps to verify that all code branches are executed in the
    constructor of class TruTVIE.
    """
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    TruTVIE("https://www.trutv.com/full-episodes/34761/the-carbonaro-effect-the-carbonaro-effect-s4-ep7/")
    TruTVIE("https://www.trutv.com/full-episodes/34761/the-carbonaro-effect-the-carbonaro-effect-s4-ep7")

# Generated at 2022-06-24 13:27:20.398057
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:23.822692
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor of class TruTVIE
    t = TruTVIE()

    # test attribute _VALID_URL
    assert isinstance(t._VALID_URL, str)
    assert t._VALID_URL


# Generated at 2022-06-24 13:27:25.453936
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except ImportError:
        assert False
    assert True

# Generated at 2022-06-24 13:27:35.682391
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:27:36.943259
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Tested TruTVIE class and methods
    TruTVIEToTest = TruTVIE()

# Generated at 2022-06-24 13:27:40.687694
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_minimal = TruTVIE()
    assert ttv_minimal.IE_NAME == "trutv"
    assert ttv_minimal.IE_DESC == "truTV.com"
    assert ttv_minimal._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:45.885358
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:27:47.039466
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result2 = TruTVIE().result()
    assert result2 == {}


# Generated at 2022-06-24 13:27:47.854964
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:58.579778
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import logging
    import requests
    from mpyy_utils.url_utils import isUrlValid
    from mpyy_utils.http_utils import openURL

    # Set logging to DEBUG
    logging.basicConfig(level=logging.DEBUG)

    urls = [
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'https://www.trutv.com/full-episodes/284045/the-carbonaro-effect-season-2-episode-8.html'
    ]

    for url in urls:
        # Test if URL is valid
        assert(isUrlValid(url) == True)

        # Test TruTVIE class

# Generated at 2022-06-24 13:28:09.451685
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:10.815842
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global trutvie
    trutvie = TruTVIE()



# Generated at 2022-06-24 13:28:11.405593
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:12.247417
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:18.694220
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_cases = [{
        'url': 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'expected_id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'expected_title': 'Sunlight-Activated Flower',
    }, {
        'url': 'http://www.trutv.com/full-episodes/43394-carbonaro-effect-transported-sign-disappearing-suitcase-video.html',
        'expected_id': '43394',
        'expected_title': 'Transported Sign, Disappearing Suitcase',
    }]
    for test_case in test_cases:
        trutv_ie = TruTVIE()


# Generated at 2022-06-24 13:28:20.744592
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        import TruTVIE
        assert True
    except ImportError:
        assert False

# Generated at 2022-06-24 13:28:26.493264
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")._extract_ngtv_info("507379c9a468f3a20c0038b5")
    TruTVIE("https://www.trutv.com/full-episodes/886742/the-carbonaro-effect-jul-27-2017-season-1-ep-18-episode-18.html")._extract_ngtv_info("886742")

# Generated at 2022-06-24 13:28:28.613939
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE(None)
    assert isinstance(trutv_ie, TruTVIE)

# Generated at 2022-06-24 13:28:29.580835
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()    

# Generated at 2022-06-24 13:28:38.351517
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:45.474455
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTV_instance = TruTVIE()
	if(isinstance(truTV_instance, TruTVIE)):
		print("Success - Initialized TruTVIE object")
		if(isinstance(truTV_instance, TurnerBaseIE)):
			print("Success - TruTVIE is a TurnerBaseIE object")
	else:
		print("Problem - Could not initialize TruTVIE object")

print("\n--------1--------\n")
test_TruTVIE()
