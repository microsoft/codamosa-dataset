

# Generated at 2022-06-24 13:18:42.984221
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:18:44.519873
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")


# Generated at 2022-06-24 13:18:55.302401
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # It should be valid
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:19:03.253277
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # First, we need to create an instance of the class
    trutv_ie = TruTVIE()
    # Then we download the webpage which contain the json
    json_data = trutv_ie._download_webpage(
        'https://api.trutv.com/v2/web/episode/impractical-jokers/514691/514691/', None, '514691',
        fatal=False)
    # We check if the video is available online.
    if json_data is False:
        return False
    # We extract the json from the webpage.
    data = trutv_ie._parse_json(json_data, '514691', transform_source=False)
    # We extract the media id of the video.
    assert 'episode' in data
    assert 'mediaId' in data['episode']
    media_

# Generated at 2022-06-24 13:19:06.489598
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE")
    try:
        dir(TruTVIE())
        print("TruTVIE class testing: PASS")
    except:
        print("TruTVIE class testing: FAIL")


# Unit test to extract data

# Generated at 2022-06-24 13:19:07.937356
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:19:14.023917
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert obj._TEST['url'] == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert obj._TEST['info_dict']['id'] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"

# Generated at 2022-06-24 13:19:14.644946
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:19:18.803474
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    This test checks TruTV video feature for each video
    """

    # One video
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    TruTVIE()._real_download(url)

# Generated at 2022-06-24 13:19:29.137027
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert t._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:19:30.545754
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    print(repr(t))

# Generated at 2022-06-24 13:19:32.180457
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE class.

    Test TruTVIE.__init__ method
    """
    TruTVIE()

# Generated at 2022-06-24 13:19:33.111957
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() is not None

# Generated at 2022-06-24 13:19:33.416286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-24 13:19:39.630108
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test some of the methods of class TruTVIE
    trutv_ie = TruTVIE()

    # Test get_metad() method
    assertEqual(trutv_ie.get_metad().get('id'), 'B7AEF83BB8BAB7B0')

    # Test _call_api() method
    assertIsNotNone(trutv_ie._call_api('GET', 'https://api.trutv.com/v2/web/home'))

    # Test _extract_ngtv_info() method
    assertIsNotNone(trutv_ie._extract_ngtv_info('B7AEF83BB8BAB7B0'))

    # Test _extract_ngtv_formats() method

# Generated at 2022-06-24 13:19:47.438267
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructing a TruTVIE
    """

    # Test URL
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Construct and return a TruTVIE object
    trutv_ie = TruTVIE()

    # Check if the instance is valid
    assert isinstance(trutv_ie, TruTVIE)

    # Extract information from URL and return the information
    return trutv_ie.extract(test_url)


# Generated at 2022-06-24 13:19:50.561368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    _TEST_URL = TruTVIE._TEST
    _TEST_URL_encrypted = TruTVIE._TEST
    TruTVIE(TruTVIE._TEST)
    True


# Generated at 2022-06-24 13:19:51.191298
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:52.051792
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TruTVIE", "trutv")

# Generated at 2022-06-24 13:19:52.583150
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:19:54.671567
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except TypeError:
        assert False, "Test failed since TruTVIE object is not being constructed properly"



# Generated at 2022-06-24 13:20:06.523855
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv_ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:20:10.627992
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor of class TruTVIE
    try:
        info = TruTVIE()._real_extract(
            "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
        # Unit test for constructor of class TruTVIE
        assert info["id"] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-24 13:20:13.880426
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:20:24.194371
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test creating a true tv object
    url = 'https://www.trutv.com/shows/truTV_Top_funniest/videos/mean-tweets-with-darkwing-duck-and-other-90s-stars.html'
    true_tv_obj = TruTVIE(url)

    # test the series_slug and clip_slug of the created object
    assert true_tv_obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert true_tv_obj._T

# Generated at 2022-06-24 13:20:31.929591
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize TruTVIE
    trutv_ie = TruTVIE()

    # Check if URL is valid
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Check if URL is valid
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-24 13:20:42.991268
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test of TruTVIE constructor
    """

    trutv = TruTVIE()

    assert trutv.url == None
    assert trutv.display_id == None
    assert trutv.series_slug == None
    assert trutv.clip_slug == None
    assert trutv.video_id == None
    assert trutv.media_id == None
    assert trutv.path == None
    assert trutv.display_id == None
    assert trutv.title == None
    assert trutv.description == None
    assert trutv.width == None
    assert trutv.height == None
    assert trutv.timestamp == None
    assert trutv.series == None
    assert trutv.season_number == None
    assert trutv.episode_

# Generated at 2022-06-24 13:20:44.131424
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("test");

# Generated at 2022-06-24 13:20:45.689244
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except TypeError:
        pass


# Generated at 2022-06-24 13:20:57.136517
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE('https://www.trutv.com/full-episodes/1500/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE('https://www.trutv.com/full-episodes/1500/the-carbonaro-effect/1500/')
    assert TruTVIE('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE('http://www.trutv.com/full-episodes/1500/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:21:01.418451
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_test = TruTVIE()

    # Test for TruTVIE
    assert trutv_test._VALID_URL is not None
    assert trutv_test._TEST is not None
    assert trutv_test.IE_NAME is not None
    assert trutv_test.ie is not None
    assert trutv_test.gen_extractors is not None

# Generated at 2022-06-24 13:21:05.467711
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    trutv_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Setup TruTVIE Object for testing
    trutv_obj = TruTVIE()

    # Test extraction of TruTVIE
    # trutv_obj._real_extract(trutv_url)



# Generated at 2022-06-24 13:21:06.349854
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:21:07.433271
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-24 13:21:08.577285
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()


# Generated at 2022-06-24 13:21:10.198089
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	from truTVIE import TruTVIE
	from test.util import compat_urllib_request
	TruTVIE()

# Generated at 2022-06-24 13:21:11.057544
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:21:16.497660
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor of class TruTVIE
    test_TruTVIE = TruTVIE()
    # Check if constructor return correct value
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:18.298434
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        print('Fail')
    else:
        print('Success')


# Generated at 2022-06-24 13:21:26.066072
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .utils import Match
    from . import TruTVIE

    # Check if TruTVIE inherited from TurnerBaseIE
    assert isinstance(TruTVIE, TurnerBaseIE)

    # Checking Regex for URL
    valid_url_url_pair = [
        (
            "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html",
            "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
        )
    ]


# Generated at 2022-06-24 13:21:30.543127
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Valid URL
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    TruTVIE(url)
    # Invalid URL
    url = "https://www.youtube.com"
    TruTVIE(url)


# Generated at 2022-06-24 13:21:31.532493
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t is not None

# Generated at 2022-06-24 13:21:33.502295
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	my_TruTVIE = TruTVIE()
	print('TruTVIE constructor called')

# Generated at 2022-06-24 13:21:42.851305
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:21:53.019556
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Video:
	# https://www.trutv.com/shows/the-carbonaro-effect/videos/fishing-for-a-car.html
	# https://www.trutv.com/shows/impractical-jokers/videos/4598046/impractical-jokers--sneaking-into-the-super-bowl.html
	 trutv_video_urls = ["https://www.trutv.com/shows/the-carbonaro-effect/videos/fishing-for-a-car.html", "https://www.trutv.com/shows/impractical-jokers/videos/4598046/impractical-jokers--sneaking-into-the-super-bowl.html"]
	# Episode:
	# https://www.trutv.com/shows/the-carbonaro-effect

# Generated at 2022-06-24 13:21:56.741303
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutv = TruTVIE()
    assert trutv.suitable(video_url) == True
    assert trutv.extract(video_url) 


# Generated at 2022-06-24 13:22:01.733678
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing constructor of class TruTVIE")
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    crawler = TruTVIE()
    result = crawler._match_id(url)
    expected = (u'sunlight-activated-flower', u'', u'')
    assert result == expected
    print("Success")

# Generated at 2022-06-24 13:22:04.357187
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Constructor of TruTVIE doesn't raise exception for correct url"""
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:10.186535
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    YouTubeIE._VALID_URL = TruTVIE._VALID_URL

    YouTubeIE._TEST = TruTVIE._TEST

    # pytest --capture=no test/test_youtube_dl/test_youtube_ie.py -k test_TruTVIE

# Generated at 2022-06-24 13:22:12.043124
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-24 13:22:20.964434
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  assert TruTVIE._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"
  assert TruTVIE._TEST['url'] == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
  assert TruTVIE._TEST['info_dict']['id'] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"

# Generated at 2022-06-24 13:22:22.769545
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:22:30.327702
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'


# Generated at 2022-06-24 13:22:30.910435
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:22:36.968221
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    Test = TruTVIE()
    assert Test._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-24 13:22:38.043127
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE


# Generated at 2022-06-24 13:22:46.777988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert ie.IE_DESC == 'truTV'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:22:53.483919
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE({})
    video_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert(trutv._extract_id(video_id) == video_id)
    uri = 'https://stream.trutv.com/m3u8/z0hhLiIqL52qZWtl/140/'
    assert(trutv._extract_id(uri) == None)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:23:01.793895
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE
    from ..utils import extract_attributes

    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert t.IE_NAME == 'truTV'
    assert t.IE_DESC == 'truTV'

# Generated at 2022-06-24 13:23:07.272941
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test for TruTVIE
    """
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    tests = [
        {
            'url': url,
            'info_dict': {
                'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
                'ext': 'mp4',
                'title': 'Sunlight-Activated Flower',
                'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
            },
            'params': {
                # m3u8 download
                'skip_download': True,
            },
        }
    ]

    for test in tests:
        _, info = TruTVIE().ext

# Generated at 2022-06-24 13:23:09.881156
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test constructor of class TruTVIE"""
    extractor = TruTVIE()
    assert TruTVIE._TEST == extractor.test('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:23:13.005789
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	try:
		TruTVIE('TruTVIE')
	except:
		assert False
	else:
		assert True


# Generated at 2022-06-24 13:23:15.542175
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(url)

# Generated at 2022-06-24 13:23:16.109280
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:16.948630
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()

# Generated at 2022-06-24 13:23:20.684854
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:23:30.152419
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    token = 'c7648b32992f4130a8d47dd89f43c22f'
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    extractor = TruTVIE()
    json_url = 'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower'
    episode_id = extractor._extract_episode_id(url, json_url)
    assert episode_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    media_id = extractor._extract_media_id(episode_id)

# Generated at 2022-06-24 13:23:31.272962
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_set = TruTVIE()
    print(test_set)

# Generated at 2022-06-24 13:23:41.303947
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        trutv = TruTVIE()
        assert trutv._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))' 

# Generated at 2022-06-24 13:23:42.640902
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test that can create an instance of the class
    TruTVIE()

# Generated at 2022-06-24 13:23:44.760828
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract(TruTVIE._TEST['url'])

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:23:45.380863
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:23:53.501888
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
    }

# Generated at 2022-06-24 13:24:03.669539
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    # Make class TruTVIE instance
    trutv_ie = TruTVIE()
    # Test _VALID_URL
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test _TEST

# Generated at 2022-06-24 13:24:12.376323
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Unit test for constructor of class TruTVIE
	# Using a link with a valid video ID
	truTV = TruTVIE('https://www.trutv.com/shows/the-jokers-wild/videos/jokers-wild-clip-come-on-down.html')
	assert trutv._VALID_URL == r'https?://(?:www\.)?trutv.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:24:13.570885
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie

# Generated at 2022-06-24 13:24:16.232040
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE();
    # Test download_json
    assert t._download_json('http://www.google.com', None) == None
    assert t._download_json('http://www.google.com', None, 'GET') == None

# Generated at 2022-06-24 13:24:27.214957
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is True
    ie.suitable('https://www.trutv.com/full-episodes/1234567') is True
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/2345678') is True
    ie.suitable('https://www.trutv.com/full-episodes/1234567') is True

    # URL with invalid slug
    assert ie.suitable('https://www.trutv.com/shows/fake-slug/videos/123') is False
    # URL with invalid show slug

# Generated at 2022-06-24 13:24:27.750260
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:39.100180
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Check TruTVIE
    trutv_ie = TruTVIE()

    # Check TruTVIE._VALID_URL
    valid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert re.match(TruTVIE._VALID_URL, valid_url)

    # Check TruTVIE._TEST

# Generated at 2022-06-24 13:24:48.520271
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test TruTVIE
    TruTVIE_object = TruTVIE()
    # Verify that class TruTVIE only accepts certain strings as URLs
    assert TruTVIE_object._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Verify that certain dictionaries are returned by class TruTVIE

# Generated at 2022-06-24 13:24:49.224258
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:52.517745
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .turner_test import TurnerBaseIETest
    TruTV = TurnerBaseIETest(TruTVIE)
    TruTV._api_conf['key'] = 'my-key'
    TruTV._TEST_NGTV_CONFIG = 'my-config'
    TruTV.run()

# Generated at 2022-06-24 13:24:52.987934
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:53.710903
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-24 13:24:54.470879
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:24:54.947057
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:04.390739
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    assert trutv_ie == TruTVIE()
    assert trutv_ie != TurnerBaseIE()
    assert trutv_ie.suitable(url) is True
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:04.995088
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:25:05.921870
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_ie = TruTVIE()


# Generated at 2022-06-24 13:25:08.811273
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        assert True
    except:
        print("test TruTVIE failed")
        assert False


# Generated at 2022-06-24 13:25:10.707366
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:25:20.222252
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-24 13:25:22.930106
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', None)

# Generated at 2022-06-24 13:25:30.191957
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert obj._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert obj._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:25:35.646703
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:25:36.406755
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Ensure the constructor of TruTVIE passes
    TruTVIE()

# Generated at 2022-06-24 13:25:39.385790
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor of class TruTVIE
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:25:42.714530
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE._TEST[u"url"]
    # Assert that the test returns a dictionary,
    # and that the dictionary is not empty
    assert(type(TruTVIE.extract_info(url)) == dict)
    assert(TruTVIE.extract_info(url))

# Generated at 2022-06-24 13:25:44.124103
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()

# Generated at 2022-06-24 13:25:47.693934
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_truTV = TruTVIE()
    assert TruTVIE._VALID_URL == test_truTV._VALID_URL
    assert TruTVIE._TEST == test_truTV._TEST

# Generated at 2022-06-24 13:25:54.929447
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable("http://www.trutv.com/shows/primer-impacto-us/videos/primer-impacto-us-on-59170908.html")
    assert ie.suitable("http://www.trutv.com/shows/tanks-giving/videos/tanks-giving-tanksgiving-ep-110.html")
    assert ie.suitable("http://www.trutv.com/videos/tanks-giving/index.html")
    assert ie.suitable("http://www.trutv.com/full-episodes/tanksgiving/index.html")

# Generated at 2022-06-24 13:26:05.606114
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert(trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(trutv._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:26:10.805884
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutvIE = TruTVIE()
    trutvIE.extract(url)
    trutvIE.extract_folder(url=url, test=True)
    trutvIE.show_results()

# Generated at 2022-06-24 13:26:12.923842
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:26:13.894729
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-24 13:26:14.457981
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:18.301922
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # If assertion fails, then __init__ function doesn't work properly
    assert isinstance(trutvIE, TruTVIE)

# Generated at 2022-06-24 13:26:19.817130
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE('', {})
    except:
        pass


# Generated at 2022-06-24 13:26:31.321664
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj1 = TruTVIE()
    assert obj1._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-24 13:26:32.353155
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None, None)

# Generated at 2022-06-24 13:26:33.433866
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-24 13:26:43.228303
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""

    # Case for TruTVIE ( -- )

# Generated at 2022-06-24 13:26:44.762706
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    from . import TruTVIE
    trutv = TruTVIE()

# Generated at 2022-06-24 13:26:46.561593
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE.__name__ == 'TruTVIE'


# Generated at 2022-06-24 13:26:47.192685
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:26:48.706691
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert unicode(ie) == 'TruTV'


# Generated at 2022-06-24 13:26:57.745501
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    # Test with video ID
    truTV_url = 'https://www.trutv.com/shows/full-episodes/41262'
    truTV_video_id = '41262'
    assert truTV._match_id(truTV_url) == truTV_video_id
    # Test with clip ID
    truTV_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    truTV_clip_slug = 'sunlight-activated-flower'
    assert truTV._match_id(truTV_url) == truTV_clip_slug

# Generated at 2022-06-24 13:26:58.305134
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:03.255329
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This instance is not recognized as a TruTVIE one
    # when created with a URL of a show
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/index.html")
    # This one should be OK
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-24 13:27:03.867361
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:27:13.605677
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Unit test for the constructor of class TruTVIE
    '''
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    result0 = TruTVIE._VALID_URL
    result1 = TruTVIE._TEST
    expected0 = TruTVIE._VALID_URL
    expected1 = TruTVIE._TEST
    TruTVIETest = TruTVIE(url)
    assert TruTVIETest._VALID_URL == expected0
    assert TruTVIETest._TEST == expected1
    assert TruTVIETest._VALID_URL == result0
    assert TruTVIETest._TEST == result1


# Generated at 2022-06-24 13:27:21.092504
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.download_webpage = lambda url, *args, **kwargs: u"{}".format(url)
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', download=True)
    ie.extract('https://www.trutv.com/full-episodes/2115')

# Generated at 2022-06-24 13:27:30.446918
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:36.214510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    inst = TruTVIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:27:46.171162
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    trutvIE = TruTVIE()
    assert(trutvIE._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))')
    assert(trutvIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-24 13:27:47.308259
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test creating instance of TruTVIE class
    truTVIE = TruTVIE()

# Generated at 2022-06-24 13:27:48.534685
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Otherwise, place this import later

# Generated at 2022-06-24 13:27:50.895953
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().IE_NAME == "trutv"
    assert TruTVIE()._VALID_URL is True

# Generated at 2022-06-24 13:27:52.376418
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  trutv = TruTVIE()
  return trutv


# Generated at 2022-06-24 13:27:53.955463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t != None, "TruTVIE constructor failed!"

# Generated at 2022-06-24 13:28:00.090328
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    trutv = TruTVIE()
    assert trutv is not None
    assert trutv.name == 'trutv'
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-24 13:28:01.191206
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE('<url>')

# Generated at 2022-06-24 13:28:02.571754
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()

# Generated at 2022-06-24 13:28:06.803793
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE()
    test_1 = TruTVIE._TEST
    test_1['url'] = TruTVIE._VALID_URL
    test_1['url']
    test_2 = TruTVIE._RE_URL
    assert trutvie.ie_key() == 'TruTV'

# Generated at 2022-06-24 13:28:07.414061
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(0, 'test', 'test', 'test')

# Generated at 2022-06-24 13:28:08.904082
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Unit test: extract video information

# Generated at 2022-06-24 13:28:16.713857
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None)._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    out = TruTVIE(None)._TEST
    assert out['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert out['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-24 13:28:26.493727
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    import sys
    if sys.version_info < (3, 0):
        # Python 2 can't handle unicode.
        TruTVIE.__name__ = b'TruTVIE'
    class TestTruTVIE(unittest.TestCase):
        def setUp(self):
            self.ie = TruTVIE()
        def tearDown(self):
            self.ie = None

        def test_constructor(self):
            self.assertEqual(self.ie.IE_NAME, 'trutv.com')
            self.assertEqual(self.ie._VALID_URL, TruTVIE._VALID_URL)


# Generated at 2022-06-24 13:28:28.613921
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(True)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-24 13:28:33.160661
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Assert that the URL from the test case can be used to create the class
    assert TruTVIE._is_valid_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', TruTVIE()), "URL could not be used to create the class"


# Generated at 2022-06-24 13:28:34.506333
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    v = TruTVIE()
    assert v



# Generated at 2022-06-24 13:28:35.030043
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-24 13:28:40.707091
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test whether url is valid
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    # Unit test
    expected_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    # Get url
    url_test = TruTVIE._TEST['url']
    # Get _VALID_URL
    regex = TruTVIE._VALID_URL
    
    # Test _VALID_URL
    assert re.match(regex, url)
    # Test url
    assert url_test == expected_url


# Generated at 2022-06-24 13:28:49.140364
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

	test = TruTVIE()
	assert (test._TEST['url']) == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
	assert (test._TEST['info_dict']['id']) == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
	assert (test._TEST['info_dict']['ext']) == "mp4"
	assert (test._TEST['info_dict']['title']) == "Sunlight-Activated Flower"
	assert (test._TEST['info_dict']['description']) == "A customer is stunned when he sees Michael's sunlight-activated flower."
