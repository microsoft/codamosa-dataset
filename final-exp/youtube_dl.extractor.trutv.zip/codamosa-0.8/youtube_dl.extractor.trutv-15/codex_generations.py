

# Generated at 2022-06-12 18:27:55.295471
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)

# Generated at 2022-06-12 18:28:01.982342
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    'See https://github.com/ytdl-org/youtube-dl/pull/12969'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:07.645364
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    obj = TruTVIE()
    #assert obj.validate_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    #assert not obj.validate_url('https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/the-sky-is-falling.html')

# Generated at 2022-06-12 18:28:10.723957
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()

    # Test if all required properties are defined
    assert hasattr(ttv, '_VALID_URL')
    assert hasattr(ttv, '_TEST')
    assert hasattr(ttv, '_real_extract')

# Generated at 2022-06-12 18:28:12.421779
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test True or False Return Statement 
    assert True

# Generated at 2022-06-12 18:28:15.208916
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import TruTVIE
    # Should not fail if constructor called without parameters
    i = TruTVIE.TruTVIE()
    assert i.ie_key() == 'TruTV'

# Generated at 2022-06-12 18:28:18.567551
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/1826928')

# Generated at 2022-06-12 18:28:20.116229
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except TypeError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-12 18:28:25.745033
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create instance
    trutv_instance = TruTVIE()

    # Check attributes of instance
    assert trutv_instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:33.249511
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE = TruTVIE()
    assert TruTVIE.is_supported("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") is True
    assert TruTVIE.is_supported("http://www.trutv.com/shows/a-legal-mind/videos/a-hacker-hell.html") is True
    assert TruTVIE.is_supported("http://www.trutv.com/shows/a-legal-mind/full-episodes/a-hacker-hell.html") is False
    assert TruTVIE.is_supported("http://www.trutv.com/shows/a-legal-mind/") is False


# Generated at 2022-06-12 18:28:38.700837
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:44.308063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create constructor of class TruTVIE
    instance_TruTVIE = TruTVIE()

    # Real extract test
    assert instance_TruTVIE._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') != None
    assert instance_TruTVIE._real_extract('https://www.trutv.com/full-episodes/6686-1.html') != None

# Generated at 2022-06-12 18:28:46.849945
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE()
    assert trutvie.ie_key() == 'truTV'

# Generated at 2022-06-12 18:28:54.590052
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert ttvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    ttvie = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/5769302/sunlight-activated-flower.html")

# Generated at 2022-06-12 18:28:56.615188
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video = TruTVIE()
    video._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:29:02.382109
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_tv = TruTVIE()
    assert tru_tv.mdoc is not None
    assert tru_tv.mdoc.get('name') == 'trutv'
    assert tru_tv.mdoc.get('title') == 'truTV'
    assert tru_tv.mdoc.get('url') == 'http://trutv.com/'

# Generated at 2022-06-12 18:29:04.509468
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert TruTVIE.suitable(TruTVIE._TEST['url'])
    assert TruTVIE.IE_DESC == 'TruTV'

# Generated at 2022-06-12 18:29:05.208627
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:06.304936
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie

# Generated at 2022-06-12 18:29:10.886214
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'



# Generated at 2022-06-12 18:29:26.826780
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test with a video from a series as input
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    test_title = "Sunlight-Activated Flower"
    test_description = "A customer is stunned when he sees Michael's sunlight-activated flower."
    
    result = TruTVIE()._real_extract(test_url)

    assert result['id'] == test_id
    assert result['title'] == test_title
    assert result['description'] == test_description
    assert result['url'] == test_url

    # Test with an episode as input

# Generated at 2022-06-12 18:29:28.721073
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-12 18:29:29.304846
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:31.746591
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract(url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:29:34.926527
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE().download_playlist("https://www.trutv.com/shows/the-carbonaro-effect/videos.html")
    print(ie)

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-12 18:29:38.510629
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
        TruTVIE class constructor test.
        This test will make sure that the class constructor is working.
    """
    # Creating an instance of TruTVIE class
    test_TruTVIE = TruTVIE()

    # Testing whether instance is created or not
    assert test_TruTVIE is not None

# Generated at 2022-06-12 18:29:40.003323
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TruTVIE)

# Generated at 2022-06-12 18:29:41.173705
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for the module's constructor.
    """
    TruTVIE()

# Generated at 2022-06-12 18:29:41.942539
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("")


# Generated at 2022-06-12 18:29:44.712392
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Constructor of class TruTVIE should return instance of class TruTVIE
    assert isinstance(TruTVIE(), TruTVIE)
    # Constructor of class TruTVIE should not return instance of class TurnerBaseIE
    assert isinstance(TruTVIE(), TurnerBaseIE) is not True

# Generated at 2022-06-12 18:30:05.079114
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE

# Create instance of class TruTVIE
TrutvIE = TruTVIE

# Generated at 2022-06-12 18:30:11.207463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
   test_instance = TruTVIE()
   assert test_instance.get_url() == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
   assert test_instance.get_configuration() == {
                                'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
                                'series_slug': 'the-carbonaro-effect',
                                'title': 'Sunlight-Activated Flower',
                                'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
                                'site_name': 'truTV',
                                'auth_required': False,
                                'clip_slug': 'sunlight-activated-flower'
                             }

# Generated at 2022-06-12 18:30:13.975084
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tm = TruTVIE();
    assert(tm.__class__.__name__ == 'TruTVIE')
    assert(tm.test() == True)


# Generated at 2022-06-12 18:30:19.062429
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    IE = TruTVIE()
    # Testing TruTVIE, see https://github.com/rg3/youtube-dl/issues/7031
    result = IE._make_valid_jsonp_callback_name('a_string_of_characters_for_testing')
    assert result == 'a_string_of_characters_for_testing'
    result = IE._make_valid_jsonp_callback_name('')
    assert result == ''

# Generated at 2022-06-12 18:30:22.926472
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_downloader import TestDownloader
    from .common import Common

    # Called when the script is run directly from the command-line
    Common.parse_args(
    )

    TestDownloader.downloader_test(TruTVIE(TestDownloader.YDL()))

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:30:23.679968
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-12 18:30:26.403320
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    module = TurnerBaseIE()
    assert module != None 

    module = TruTVIE()
    assert module != None 


# Generated at 2022-06-12 18:30:27.428615
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:30.824228
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    except:
        assert False


# Generated at 2022-06-12 18:30:40.644963
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-12 18:31:23.441611
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL is not None
    assert trutv_ie._TEST is not None
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    result = trutv_ie._real_extract(url)

# Generated at 2022-06-12 18:31:24.175912
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()

# Generated at 2022-06-12 18:31:24.664526
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:30.340520
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test_dict = test._TEST
    tru = TruTVIE._download_json(test_dict['url'], 'id')
    test_id = tru['episode']['mediaId']
    test_ext = tru['episode']['videoAssets'][0]['videoFormat']
    test_title = tru['episode']['title'].strip()
    test_description = tru['episode']['description']

# Generated at 2022-06-12 18:31:32.633134
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiate an object of class TruTVIE
    obj = TruTVIE()
    assert obj is not None


# Generated at 2022-06-12 18:31:38.539087
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:31:40.471451
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor of class TruTVIE
    pass


# Test_TruTVIE()


# Generated at 2022-06-12 18:31:47.100834
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    object_TruTVIE = TruTVIE()

    # Test TruTVIE._VALID_URL
    url_1 = TruTVIE._VALID_URL
    url_2 = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert url_1 == url_2

    # Test TruTVIE._TEST
    test_1 = TruTVIE._TEST

# Generated at 2022-06-12 18:31:49.889202
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  # Note: Cannot test TruTVIE right now because of unknown TruTV API
  x = TruTVIE('')
  x._real_extract('')

# Generated at 2022-06-12 18:31:50.557647
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:33:21.928990
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        print("Set up of class TruTVIE is successful")
        return
    except Exception as e:
        print("Set Up of class TruTVIE is unsuccessful")
        print("Error encountered: " + str(e))
        return



# Generated at 2022-06-12 18:33:24.003167
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check for class __init__
    new_TruTVIE = TruTVIE()
    return

# Generated at 2022-06-12 18:33:24.722675
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:33:35.013471
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    import os

    class TruTVIETest(unittest.TestCase):
        def test_TruTV_IE(self):
            trutvIE = TruTVIE()
            self.assertIsNotNone(TruTVIE)
            print(trutvIE)
            print(repr(trutvIE))
        def test_TruTV_IE_DEFAULT(self):
            trutvIE = TruTVIE(DEFAULT_DUMP=True)
            self.assertIsNotNone(TruTVIE)
            print(trutvIE)
            print(repr(trutvIE))
        def test_TruTV_IE_DUMP_EXTRACTOR(self):
            trutvIE = TruTVIE(DUMP_EXTRACTOR=True)
            self

# Generated at 2022-06-12 18:33:35.550534
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__doc__



# Generated at 2022-06-12 18:33:39.391071
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert False
    assert True

# Generated at 2022-06-12 18:33:40.096667
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:33:43.293223
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert x._TEST['params']['skip_download'] == True
    assert x._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-12 18:33:49.402138
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert ie.IE_DESC == 'truTV'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:33:53.440386
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import requests
    from .tests.test_TruTVIE import TruTVIE
    from .tests.test_common import FakeYDL
    ydl = FakeYDL()
    TruTVIE.constructor(ydl)
    assert(ydl.request.called == True)
    assert(isinstance(ydl.request.call_args[0][0], requests.Request))