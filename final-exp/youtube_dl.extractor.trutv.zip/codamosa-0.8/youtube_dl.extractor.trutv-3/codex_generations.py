

# Generated at 2022-06-12 18:28:04.809589
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    t_props = vars(t)

    # Verify that instance variables are properly set
    assert t_props['_VALID_URL'] == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert t_props['_TEST']['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:28:06.161458
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert True


# Generated at 2022-06-12 18:28:18.124554
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutvIE = TruTVIE()
    assert trutvIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutvIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert trutvIE._TEST['info_dict']

# Generated at 2022-06-12 18:28:19.827781
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:24.986780
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video_id = "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    ie = TruTVIE()
    ie.initialize()
    assert url == ie._VALID_URL
    assert 'Sunlight-Activated Flower', ie._TEST['title']
    assert 'Sunlight-Activated Flower', ie._TEST['description']
    assert video_id == ie._TEST['info_dict']['id']
    assert 'mp4' == ie._TEST['info_dict']['ext']

# Generated at 2022-06-12 18:28:33.190101
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    control = TruTVIE()

    # Test ID extracted from URL
    clip_slug = 'sunlight-activated-flower'
    data_clip = control._extract_video_id(control._VALID_URL % ('the-carbonaro-effect', clip_slug, ''))
    assert data_clip == 'clip/the-carbonaro-effect/' + clip_slug, 'Invalid ID for TruTVIE [Clip]'

    series_slug = 'impractical-jokers'
    episode_id = '6674'
    data_episode = control._extract_video_id(control._VALID_URL % (series_slug, '', episode_id))
    assert data_episode == episode_id, 'Invalid ID for TruTVIE [Episode]'

    # Test invalid URL

# Generated at 2022-06-12 18:28:39.362606
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  print("Unit test for constructor of class TruTVIE")
  test_TruTVIE.url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
  test_TruTVIE.ie = TruTVIE()
  test_TruTVIE.ie.url = test_TruTVIE.url
  test_TruTVIE.ie.extract()

# Generated at 2022-06-12 18:28:39.997507
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-12 18:28:49.803890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:53.128342
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TrutvIE = TruTVIE()
    assert TrutvIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True

# Generated at 2022-06-12 18:29:05.896453
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert t.display_id == 'sunlight-activated-flower'
    assert t.url == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert t.series_slug == 'the-carbonaro-effect'
    assert t.clip_slug == 'sunlight-activated-flower'

# Generated at 2022-06-12 18:29:17.744881
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test invalid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower'
    ttv = TruTVIE(url)
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:24.555298
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiation
    trutv = TruTVIE()

    # Test VALID_URL
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    mtch = re.match(trutv._VALID_URL, url)
    assert mtch is not None

    series_slug = mtch.group(1)
    clip_slug = mtch.group(2)
    video_id = mtch.group(3)
    assert series_slug
    assert clip_slug
    assert video_id



# Generated at 2022-06-12 18:29:26.856466
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._VALID_URL = 'https://www.trutv.com/shows/full-episodes/videos/sunlight-activated-flower.html'
    ie.test()

# Generated at 2022-06-12 18:29:31.366670
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/tru-tv-top-funniest/videos/top-funniest-fail-gifs.html')


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:29:32.564046
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-12 18:29:40.947595
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize TruTVIE
    ttv = TruTVIE()
    # Check the URL of TruTVIE
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Check if the extraction works properly
    assert ttv.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not ttv.suitable('https://www.trutv.com/')

# Generated at 2022-06-12 18:29:44.697606
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_TruTVIE = TruTVIE()
    test_TruTVIE._real_extract(url)

# Generated at 2022-06-12 18:29:47.184878
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._extract_ngtv_info(None)

# Generated at 2022-06-12 18:29:49.773325
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None

# Generated at 2022-06-12 18:30:08.619258
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-12 18:30:15.706183
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Unit test for constructor of class TruTVIE
    '''
    trutvIE = TruTVIE()
    if trutvIE.url_result['url'] == TruTVIE._TEST['url']:
        print("Unit test for constructor of class TruTVIE is passed")
        exit(1)
    else:
        print("Unit test for constructor of class TruTVIE is failed")
        exit(0)


# Generated at 2022-06-12 18:30:16.264983
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-12 18:30:20.080048
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    print(repr(trutv))
    assert (repr(trutv)) == "<class 'youtube_dl.extractor.trutv.TruTVIE'>"


# Generated at 2022-06-12 18:30:22.652022
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    data = {
        'urls': {
            'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        },
    }
    TruTVIE(data)

# Generated at 2022-06-12 18:30:28.535058
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    object_TruTVIE = TruTVIE()
    assert object_TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert object_TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert object_Tru

# Generated at 2022-06-12 18:30:30.673140
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        obj = TruTVIE()
        assert isinstance(obj, TruTVIE)
    except:
        return False

    return True

# Generated at 2022-06-12 18:30:32.166057
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv != None

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:30:33.967005
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE()
    print(trutvie)
    assert trutvie
    pass

# Generated at 2022-06-12 18:30:35.238747
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Asserts for the url.
    assert TruTVIE._VALID_URL is not None # Ensure it has a value.


# Generated at 2022-06-12 18:30:55.604256
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE constructor...")
    try:
        TruTVIE()
    except Exception as e:
        print("Failed to construct TruTVIE class\n" + str(e))


# Generated at 2022-06-12 18:31:02.723059
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert(ie.IE_NAME == ie.__class__.__name__)
    assert(ie._VALID_URL == ie.__class__._VALID_URL)
    assert(ie._downloader._request_webpage.im_func.func_code == ie._request_webpage.im_func.func_code)
    assert(ie._downloader.urlopen.im_func.func_code == ie.urlopen.im_func.func_code)

# Generated at 2022-06-12 18:31:05.639422
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-12 18:31:07.465149
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-12 18:31:08.890161
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'


# Generated at 2022-06-12 18:31:09.378072
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:10.323271
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

# Generated at 2022-06-12 18:31:13.787272
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

    # Test TruTVIE on valid URL
    assert type(ie) == TruTVIE
    assert ie.ie_key() == 'trutv'
    assert ie.SUCCEEDED == True
    assert ie.SUCCEEDED == True


# Generated at 2022-06-12 18:31:19.778239
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test 1
    test1_url = 'http://www.trutv.com/shows/greatest-ever/videos/greatest-ever-dumb-tv-shows.html'
    test1_expected_valid_url = True
    test1_expected_display_id = 'greatest-ever-dumb-tv-shows'
    test1_expected_series_slug = 'greatest-ever'
    test1_expected_clip_slug = 'greatest-ever-dumb-tv-shows'
    test1_expected_video_id = None
    test1_expected_is_live = False
    test1_expected_title = 'Greatest Ever: Dumbest TV Shows'

    test1_trutv = TruTVIE(test1_url)
    test1_result_valid_url = test1_

# Generated at 2022-06-12 18:31:20.561423
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-12 18:32:02.655040
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Ensure that constructor without parameters doesn't fail
    TruTVIE()

# Generated at 2022-06-12 18:32:04.579078
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
# Unit test ends


# Generated at 2022-06-12 18:32:14.059163
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import requests
    import time
    import json
    import random
    from urlparse import urlparse

    class MockResponse(object):
        def __init__(self, content, status_code=200):
            self.content = content
            self.status_code = status_code

    from .common import InfoExtractor
    from ..downloader.http import HttpRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HttpRequest


# Generated at 2022-06-12 18:32:15.484324
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:32:21.143790
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    with open('trutvie.json') as f:
        data = json.loads(f.read())

    ttvie = TruTVIE()
    for d in data:
        assert ttvie.check_url(d['url'])

        t=TEST(tvie.extract_content, d['url'])
    # assert keeplist == keep_list


# Generated at 2022-06-12 18:32:22.930525
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.get_url_regex() == TruTVIE._VALID_URL

# Generated at 2022-06-12 18:32:24.785756
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

# Generated at 2022-06-12 18:32:36.254381
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test first level of hierarchy in TruTVIE
    trakt_ie = TruTVIE()
    assert(trakt_ie.IE_NAME == TruTVIE.ie_key())
    assert(trakt_ie.IE_DESC == TruTVIE.ie_key())
    assert(trakt_ie._VALID_URL == TruTVIE._VALID_URL)
    assert(trakt_ie._TEST == TruTVIE._TEST)
    assert(trakt_ie._downloader.params.get('noplaylist', True))
    assert(trakt_ie._TESTS == [])

    # Test second level of hierarchy
    turner_base_ie = trakt_ie.turner_base_ie
    assert(turner_base_ie.IE_NAME == 'turnerbase')

# Generated at 2022-06-12 18:32:36.760673
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:32:37.529683
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-12 18:34:23.121933
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    if ie is None:
        raise Exception("TruTVIE does not exist")

# Generated at 2022-06-12 18:34:29.789053
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    url = 'https://api.trutv.com/v2/g1/web/series/clip/impractical-jokers/joker-face-off/11a8b8d6bddc6e77a7540e55601b8ebfe5fd5305'
    t._extract_ngtv_info('11a8b8d6bddc6e77a7540e55601b8ebfe5fd5305', {}, {'beta': False})

# Generated at 2022-06-12 18:34:35.333063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE
    import unittest

    class TestTruTVIE(unittest.TestCase):
        def test_trutv_recognise_url(self):
            self.assertTrue(TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
            self.assertFalse(TruTVIE.suitable('https://www.trutv.com/'))
    unittest.main()


# Generated at 2022-06-12 18:34:39.329659
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    A unit test for testing TruTVIE class constructor
    '''
    ie = TruTVIE()
    ie.download('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:34:40.990319
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        raise Exception("Exception in TruTVIE constructor") from e


# Generated at 2022-06-12 18:34:41.758776
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert(TruTVIE)


# Generated at 2022-06-12 18:34:46.629150
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit Tests for TruTVIE class

    This function automatically detects all methods starting with 'test' and
    executes them.
    """
    import sys
    import unittest
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(globals()['TruTVIE'])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:34:56.692969
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/'
    constructor_1 = TruTVIE(url);
    # Test for the return value of method _download_webpage
    url2 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    webpage = constructor_1._download_webpage(url2, 'The Carbonaro Effect, Season 6, Episode 21')
    assert webpage, 'TruTV: Cannot download webpage of given url'
    # Test for the return value of method _real_extract
    constructor_2 = TruTVIE(url2)
    info = constructor_2._real_extract(url2)
    assert info, 'TruTV: Cannot extract info of given url'

# Generated at 2022-06-12 18:35:01.504417
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # class TruTVIE inherits from class TurnerBaseIE
    assert issubclass(TruTVIE, TurnerBaseIE)
    # class TurnerBaseIE inherits from class InfoExtractor
    assert issubclass(TurnerBaseIE, InfoExtractor)

# Generated at 2022-06-12 18:35:01.974770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()