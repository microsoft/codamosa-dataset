

# Generated at 2022-06-12 18:28:02.372696
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # with valid url
    trutv_test1 = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # with invalid url
    try:
        trutv_test2 = TruTVIE('https://www.example.com/')
    except TruTVIE._VALID_URL:
    # check if the exception is thrown
        assert TruTVIE._VALID_URL is None


# Generated at 2022-06-12 18:28:02.895674
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:03.386165
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:06.408916
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Set up the unit test
    ttv = TruTVIE()
    # Check that TruTVIE constructor is called successfully
    assert ttv is not None


# Generated at 2022-06-12 18:28:06.947381
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:08.479919
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE(None)
    assert isinstance(trutv, TruTVIE)

# Generated at 2022-06-12 18:28:09.951196
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)._real_extract(TruTVIE._TEST['url'])

# Generated at 2022-06-12 18:28:21.084124
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:21.622642
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-12 18:28:23.738217
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-12 18:28:43.376580
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:28:44.399226
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.constructor()
    ie.result()

# Generated at 2022-06-12 18:28:51.139142
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://api.trutv.com/v2/web/series/clip/the_carbonaro_effect/sunlight-activated-flower"
    ie = TruTVIE(url)
    obj = ie._download_json(url)
    # Test case 1
    assert obj["showTitle"] == "The Carbonaro Effect"
    # Test case 2
    assert obj["info"]["mediaId"] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"

# Generated at 2022-06-12 18:28:54.062362
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj in TruTVIE.ie_keymap.values()
    assert obj.ie_key() == 'trutv'
    assert obj.ie_key_type() == 'key_ie'

# Generated at 2022-06-12 18:29:03.366588
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Test all URL patterns of class TruTVIE
    '''
    import os
    import yaml
    from .test_utils import assert_expected_items

    # Load all test data of class TruTVIE, then iterate through each test case
    tests = yaml.load(open(os.path.join(os.path.dirname(__file__), "TruTV.yml")))['tests']

# Generated at 2022-06-12 18:29:04.194531
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test = TruTVIE
	assert test

# Generated at 2022-06-12 18:29:05.364471
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie

# Generated at 2022-06-12 18:29:06.455846
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE_obj = TruTVIE()
    assert TruTVIE_obj is not None

# Generated at 2022-06-12 18:29:07.960581
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(123,456,1,2)

# Generated at 2022-06-12 18:29:08.760253
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    return

# Generated at 2022-06-12 18:29:37.367278
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor of class TruTVIE
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:45.233597
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:51.288063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    assert ie.can_extract(url) == True

# Generated at 2022-06-12 18:29:58.709575
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

    assert ie.IE_NAME == 'trutv:trutv'
    assert ie.IE_DESC == 'truTV'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-12 18:30:01.661060
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # create test object
    obj = TruTVIE()
    assert obj is not None


# Generated at 2022-06-12 18:30:09.766044
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# if the unittest was called from the command line, use the basic config
	import sys
	if __name__ == '__main__':
		sys.argv.append('--no-resultlog')
		sys.argv.append('--verbose')
		sys.argv.append('--unit')

	# prepare for a unittest
	import unittest
	from ytdl.YoutubeDL import YoutubeDL

	# inherit from unittest.TestCase
	class TruTVIETests(unittest.TestCase):

		def test_constructor(self):
			self.assertEqual(TruTVIE.IE_NAME, 'trutv')
			self.assertEqual(TruTVIE.IE_DESC, 'truTV')

# Generated at 2022-06-12 18:30:16.390269
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  #test regular video
  churl = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
  ie = TruTVIE()
  ie._extract_ngtv_info(None,{},{'url':churl})  
  #test episode

# Generated at 2022-06-12 18:30:17.938007
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Unit test for constructor of class TruTVIE
    '''
    TruTVIE()

# Generated at 2022-06-12 18:30:25.350524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv._downloader.params['headers']['User-Agent'] == 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.1 Safari/603.1.30'
    assert trutv._downloader.params['force-proxy'] == False
    assert trutv

# Generated at 2022-06-12 18:30:27.113680
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """TruTVIE_test
    """
    TruTVIE()


# Generated at 2022-06-12 18:31:12.371965
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    assert test.name == 'trutv:video'
    assert test._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:31:19.304610
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    true = True
    false = False

    # Tests the constructor of class TruTVIE
    ie = TruTVIE()

    # Tests of instance ie of class TruTVIE
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:31:20.382026
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Will create a TruTVIE object and returns it
    TruTVIE()

# Generated at 2022-06-12 18:31:22.939746
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Testing TruTVIE...')
    try:
        test_case = TruTVIE()
        print('Success!')
    except:
        print('Error!')

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:31:24.462687
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert(trutv.extract(TruTVIE._TEST['url']))

# Generated at 2022-06-12 18:31:24.918850
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:30.552427
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test that TruTVIE's constructor of class TruTVIE checks for a proper URL
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test that TruTVIE's constructor of class TruTVIE checks for a proper _TEST dictionary

# Generated at 2022-06-12 18:31:32.403027
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    Test.assertTrue(isinstance(obj, TruTVIE))


# Generated at 2022-06-12 18:31:33.743981
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert(trutv_ie != None)

# Generated at 2022-06-12 18:31:34.400505
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:32:15.873443
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Test example 1
	test_TruTVIE_1 = TruTVIE()
	assert(test_TruTVIE_1)

	# Test example 2
	test_TruTVIE_2 = TruTVIE()
	assert(test_TruTVIE_2)


# Generated at 2022-06-12 18:32:18.901861
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-12 18:32:27.327293
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of TruTVIE
    trutv_ie = TruTVIE()
    # Using the public property, _VALID_URL, test if it is a regex
    assert(hasattr(trutv_ie, '_VALID_URL'))
    assert(isinstance(trutv_ie._VALID_URL, type(re.compile(''))))
    # Test if the property, _VALID_URL is using the flags, DOTALL and IGNORECASE
    assert((trutv_ie._VALID_URL.flags & re.DOTALL) > 0)
    assert((trutv_ie._VALID_URL.flags & re.IGNORECASE) > 0)
    # Using the public method, suitable() with valid URL

# Generated at 2022-06-12 18:32:29.660532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    assert hasattr(test_TruTVIE, '_extract_ngtv_info')

# Generated at 2022-06-12 18:32:32.775904
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert(trutv.IE_NAME == 'TruTV')

# Generated at 2022-06-12 18:32:36.217932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    ie._real_extract(url)


# Generated at 2022-06-12 18:32:45.393710
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiate a TruTVIE instance
    trutv_ie = TruTVIE()

    # Download the video with the given video ID
    # trutv_ie.download_by_videoid("f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1")
    # Download the video with the given URL
    trutv_ie.download_by_url("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    #trutv_ie.download_by_url("https://www.trutv.com/shows/the-carbonaro-effect/876569/sunlight-activated-flower.html")
    #trutv_ie.download_by_url("https://www.trutv

# Generated at 2022-06-12 18:32:55.984586
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    t._VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:32:57.366109
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import inspect
    print("In test_TruTVIE")
    assert inspect.ismethod(TruTVIE.__init__)

# Generated at 2022-06-12 18:33:00.334231
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == TruTVIE._VALID_URL
    assert trutv._TEST == TruTVIE._TEST



# Generated at 2022-06-12 18:34:43.080777
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Unit test for TruTVIE class
    '''
    trutv_ie = TruTVIE(None)
    # Test for the existence of TruTVIE _EXTRACTOR_KEY
    assert trutv_ie._EXTRACTOR_KEY == 'turner'

# Generated at 2022-06-12 18:34:44.698816
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trtv_ie = TruTVIE()
    trtv_ie.extract(url)

# Generated at 2022-06-12 18:34:46.170463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except NameError:
        assert False, 'Could not construct an TruTVIE instance'

# Generated at 2022-06-12 18:34:46.986125
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    return t

# Generated at 2022-06-12 18:34:48.843722
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    mocker = Mocker()
    True

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:34:50.266940
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:58.887287
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    valid_url1 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    valid_url2 = 'https://www.trutv.com/full-episodes/4378/impractical-jokers/season-6/episode-611.html'
    valid_url3 = 'https://www.trutv.com/full-episodes/4378/impractical-jokers.html'
    assert(trutv._VALID_URL == TruTVIE._VALID_URL)
    assert(trutv._TEST == TruTVIE._TEST)
    assert(trutv._download_json(None, 'None') == None)

# Generated at 2022-06-12 18:35:02.642387
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.REGEX == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:35:03.869496
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    TruTVIE()
    TruTVIE()
    TruTVIE()
    TruTVIE()

# Generated at 2022-06-12 18:35:05.116950
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True