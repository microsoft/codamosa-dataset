

# Generated at 2022-06-12 18:27:57.840383
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(_test_match=True)._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE(_test_match=True)._TEST == TruTVIE._TEST

# Generated at 2022-06-12 18:28:05.135414
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize TruTVIE class
    trutv_ie = TruTVIE()

    # Get video url
    url = trutv_ie._TEST['url']

    # Check if extract method can get right video info
    video_info = trutv_ie._real_extract(url)
    assert video_info['id'] == trutv_ie._TEST['info_dict']['id']
    assert video_info['title'] == trutv_ie._TEST['info_dict']['title']
    assert video_info['description'] == trutv_ie._TEST['info_dict']['description']

# Generated at 2022-06-12 18:28:08.360653
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().match('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not TruTVIE().match('https://www.trutv.com/shows/the-carbonaro-effect/')

# Generated at 2022-06-12 18:28:09.540768
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()

# Generated at 2022-06-12 18:28:10.072365
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:13.023959
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-12 18:28:14.471509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # pylint: disable=W0212
    TruTVIE()

# Generated at 2022-06-12 18:28:15.318249
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:25.091145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    check_url = TruTVIE.check_url(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert check_url is True
    t = TruTVIE()
    assert t.check_url(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is True
    assert t.check_url(
        'https://www.trutv.com/shows/the-carbonaro-effect/1187958/full-episodes.html') is False

# Generated at 2022-06-12 18:28:30.553894
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize object of class TruTVIE
    trutv = TruTVIE()

    # Test _VALID_URL
    _VALID_URL_pattern = re.compile(trutv._VALID_URL)
    _VALID_URL_matches = _VALID_URL_pattern.match(trutv._TEST['url'])
    assert _VALID_URL_matches is not None

    # Test _TEST
    trutv._TEST

# Generated at 2022-06-12 18:28:43.041036
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/tacoma-fd/videos/brawl-in-the-hall.html'
    TruTVIE(None)._real_extract(url)

# Generated at 2022-06-12 18:28:46.586145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.extract_info(('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))

# Generated at 2022-06-12 18:28:47.626521
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    assert truTV

# Generated at 2022-06-12 18:28:55.799223
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test.
    """
    import re

    # Must not match
    assert TruTVIE._VALID_URL.match('http://www.trutv.com/shows/impractical-jokers/episodes/extras-inside-jokes.html') is None
    assert TruTVIE._VALID_URL.match('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is not None

    # Test for TruTVIE
    ie = TruTVIE()
    ie.download('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:28:58.975944
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.ie_key() == 'TruTV'
    assert ie.ie_url() == 'http://www.trutv.com/'

# Generated at 2022-06-12 18:29:00.246962
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()
    assert TruTVIE()._VALID_URL

# Generated at 2022-06-12 18:29:08.002753
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-12 18:29:10.629067
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-12 18:29:21.605385
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE instance
    ie = TruTVIE()

    # Test _VALID_URL
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    pattern = re.compile(ie._VALID_URL)
    match = pattern.match(url)
    assert match.groups()[0:3] == ('the-carbonaro-effect', 'sunlight-activated-flower', None)
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/689036/coffee-shop-jackpot.html'
    match = pattern.match(url)
    assert match.groups()[0:3] == ('the-carbonaro-effect', None, '689036')

    # Test _ext

# Generated at 2022-06-12 18:29:29.603865
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE()
    assert trutvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutvie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert trutvie._TEST['info_dict']['title'] == 'Sunlight-Activated Flower'

# Generated at 2022-06-12 18:29:49.246132
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t

# Generated at 2022-06-12 18:29:57.854792
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    IE = TruTVIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:30:04.582062
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    class_instance = TruTVIE()
    pattern = class_instance._VALID_URL
    m = re.match(pattern, url)
    print(m.groups())

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:30:07.903770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-12 18:30:09.281276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    print(t)


# Generated at 2022-06-12 18:30:19.712861
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    info = trutv._real_extract(trutv_url)
    assert info['display_id'] == 'sunlight-activated-flower'
    assert info['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert info['title'] == 'Sunlight-Activated Flower'
    assert info['series'] == 'The Carbonaro Effect'
    assert info['season_number'] == 1
    assert info['episode_number'] == 16
    assert info['auth_required'] == True

# Generated at 2022-06-12 18:30:20.577029
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-12 18:30:23.645829
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._get_entry_id('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-12 18:30:34.802523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE object
    TruTVIE_object = TruTVIE()

    # Check whether the object is correctly instantiated
    assert TruTVIE_object._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Check whether the class attributes is correctly specified
    assert TruTVIE_object.IE_NAME == 'TruTV'
    assert TruTVIE_object.IE_DESC == 'truTV'
    assert TruTVIE_object.BRANDING_NAME == 'truTV'
    assert TruTV

# Generated at 2022-06-12 18:30:43.283498
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case for the class
    truTV = TruTVIE()
    assert truTV._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:31:25.124771
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor_test_base(TruTVIE, 'www.trutv.com', 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-12 18:31:25.591888
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:34.620039
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # test url params
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert t._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # test url input validity
    assert t._VALID_URL.search(url)

# Generated at 2022-06-12 18:31:38.038276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:31:40.762163
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test_TruTVIE_constructor
    true_out = TruTVIE()
    assert(isinstance(true_out, TruTVIE))


# Generated at 2022-06-12 18:31:47.191676
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE()._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:31:50.834207
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_ = TruTVIE
    assert class_ is not None, "TruTVIE class not defined."
    assert class_.__name__ == "TruTVIE", "TruTVIE class not named TruTVIE."

# Generated at 2022-06-12 18:31:57.474405
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE();
    link = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    link = ie._match_id(link)
    assert link == ('the-carbonaro-effect', '', None)

    link = 'https://www.trutv.com/shows/the-carbonaro-effect/116220/'
    link = ie._match_id(link)
    assert link == ('the-carbonaro-effect', None, '116220')

# Generated at 2022-06-12 18:32:01.099382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv is not None
    # Just test that TruTVIE has some class member (private and public)
    assert hasattr(ttv, '_VALID_URL') and hasattr(ttv, '_TEST')
    assert hasattr(ttv, '_extract_ngtv_info') and hasattr(ttv, '_real_extract')

# Generated at 2022-06-12 18:32:01.778689
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    True

# Generated at 2022-06-12 18:33:48.364316
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test real URL
    TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

    # test fake URL
    try:
        TruTVIE()._real_extract("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
        assert False
    except:
        assert True

    # test with non-existing item
    try:
        TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/fake.html")
        assert False
    except:
        assert True

# Generated at 2022-06-12 18:33:51.520602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test case for TruTVIE.
    """
    trutv_test = TruTVIE()
    trutv_test._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:33:53.553791
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TruTVIE","https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")


# Generated at 2022-06-12 18:33:55.736271
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = "https://www.trutv.com/shows/the-carbo.."
	obj = TruTVIE()
	obj._real_extract(url)

# Generated at 2022-06-12 18:34:04.193452
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

        # Constructor of class TruTVIE
        t = TruTVIE()

        # Exercise assert statements in constructor of class TruTVIE
        assert t.ie_key() == "TruTV"
        assert t.ie_id() == "trutv.com"
        # assert t._VALID_URL == ""
        assert t._TEST.get('url') == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

# Generated at 2022-06-12 18:34:15.130424
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import re
    from .truTV import TruTVIE
    VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:34:17.084546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:34:20.414820
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Unit test for constructor of class TruTVIE
    '''
    # Create an object of TruTVIE
    obj = TruTVIE()
    # Check if object is of type TruTVIE
    assert isinstance(obj, TruTVIE)

# Generated at 2022-06-12 18:34:23.322129
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'http://www.trutv.com/full-episodes/09_pZmh7/02_xMbB7/1_EPISODE_TITLE_HERE.html'
    assert TruTVIE._VALID_URL == url

# Generated at 2022-06-12 18:34:25.743217
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    link = TruTVIE()
    assert link
    assert link.is_usable()


# Generated at 2022-06-12 18:36:32.525807
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.ie_key() == 'truTV'
    assert ie.ie_info()['title'] == 'truTV'
    assert ie.ie_info()['description'] == 'truTV - TV Shows, Movies & Funny Videos'
    assert ie.ie_info()['_type'] == 'video'
    assert ie.ie_info()['report_urls'] == True

# Generated at 2022-06-12 18:36:37.618308
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test TruTVIE class member methods
    # Test TruTVIE class member methods
    module = TruTVIE()
    assert module._TEST
    assert module._VALID_URL
    assert module._real_extract
    assert module._extract_ngtv_info
    assert module.suitable
    assert module.IE_NAME

# Generated at 2022-06-12 18:36:38.473654
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert(ttv)

# Generated at 2022-06-12 18:36:40.793014
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL
    assert TruTVIE()._TEST
    assert TruTVIE()._download_json


# Generated at 2022-06-12 18:36:46.919361
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._VALID_URL = r'https?://(?:www\.)?trutv\.com/shows/tru-tv-top-funniest/videos/tru-tv-top-funniest-season-2-episode-2'

# Generated at 2022-06-12 18:36:54.815097
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor of TruTVIE is predefined in __init__.py
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:36:56.348944
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	print("Testing class TruTVIE")
	truTVIE = TruTVIE()
	print("Passed class TruTVIE")


# Generated at 2022-06-12 18:36:58.760840
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import TruTVIE
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    obj = TruTVIE.TruTVIE()
    obj.extract(url)

# Generated at 2022-06-12 18:37:00.916984
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST
    assert TruTVIE()._download_json == TruTVIE._download_json

# Generated at 2022-06-12 18:37:06.944755
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    assert test._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'