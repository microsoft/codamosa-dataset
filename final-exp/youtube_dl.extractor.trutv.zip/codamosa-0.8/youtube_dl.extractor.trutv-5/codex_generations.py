

# Generated at 2022-06-12 18:28:01.367474
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-12 18:28:08.717175
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    # We need to make sure that the regular expression matches with the URL
    assert ttv._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # The line below raises an exception, so the test fails
    # assert ttv._VALID_URL == 'asdf'

# Generated at 2022-06-12 18:28:12.583260
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.IE_NAME == 'trutv'
    assert trutv_ie.IE_DESC == 'truTV'
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:13.819377
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:23.512161
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	try:
		assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
	except AssertionError:
		raise AssertionError("TruTVIE constructor is broken (1/2)")

# Generated at 2022-06-12 18:28:25.179534
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv:series'



# Generated at 2022-06-12 18:28:30.934817
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    # Assert the values of True if the IE is successfully created
    assert trutv_ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-12 18:28:42.369525
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:45.070286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE.__doc__ == 'truTV video extractor'


# Generated at 2022-06-12 18:28:53.667069
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test for TruTVIE"""
    
    # Test for the case where the video id is supplied
    video_id = '1685581'
    expected_url = 'https://api.trutv.com/v2/web/episode/the-carbonaro-effect/' + video_id

# Generated at 2022-06-12 18:29:00.522135
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv.IE_NAME == 'trutv:tv'

# Generated at 2022-06-12 18:29:02.732379
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE Class
    """
    ie = TruTVIE()
    assert ie.SUCCESS == 200

# Generated at 2022-06-12 18:29:10.751399
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:11.229525
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-12 18:29:12.271060
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().regex == TruTVIE._VALID_URL

# Generated at 2022-06-12 18:29:13.002997
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-12 18:29:13.713405
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-12 18:29:19.045248
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Test url with video ID
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	result = TruTVIE().extract(url)
	assert(result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
	assert(result['title'] == 'Sunlight-Activated Flower')
	assert(result['site_name'] == 'truTV')

	# Test url with clip slug
	url = 'https://www.trutv.com/shows/tacoma-fd/full-episodes/episode-04.html'
	result = TruTVIE().extract(url)

# Generated at 2022-06-12 18:29:24.555110
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    # Number of times parse method is invoked
    # TruTVIE.parse() is never invoked
    assert obj._parse_calls == 0
    # Number of times _download_webpage_handle method is invoked
    # TruTVIE._download_webpage_handle() is never invoked
    assert obj._download_webpage_handle_calls == 0
    # Number of times _download_json method is invoked
    # TruTVIE._download_json() is never invoked
    assert obj._download_json_calls == 0

# Generated at 2022-06-12 18:29:30.612848
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE object, and extract data from the given URL
    ie = TruTVIE()

    # Asserts
    def _asserts(result, url, series_slug, clip_slug, video_id):
        assert ie._VALID_URL == url
        assert ie._download_json.return_value == result
        ie._download_json.assert_called_once_with(
            'https://api.trutv.com/v2/web/' + ('episode' if video_id else 'series/clip') + '/' + series_slug + '/' + (video_id if video_id else clip_slug),
            video_id if video_id else clip_slug)

    # Call _real_extract with a valid URL

# Generated at 2022-06-12 18:29:42.053227
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL is not None
    assert TruTVIE._TEST is not None



# Generated at 2022-06-12 18:29:42.845733
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv

# Generated at 2022-06-12 18:29:43.319602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:43.795490
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:50.452326
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # No need to test all values, as this is a wrapper class
    t._VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:52.834470
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract(TruTVIE._TEST['url'])


# Test for test function with arguments url

# Generated at 2022-06-12 18:29:54.078347
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE() # Just for check if it runs without exceptions

# Run all test

# Generated at 2022-06-12 18:29:54.939388
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-12 18:30:06.584488
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:30:07.976835
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #test case: test TruTVIE constructor
    from . import TruTVIE
    assert TruTVIE

# Generated at 2022-06-12 18:30:28.610393
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None


# Generated at 2022-06-12 18:30:30.093600
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv

# Generated at 2022-06-12 18:30:31.084510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return_value = TruTVIE()
    return return_value

# Generated at 2022-06-12 18:30:36.841369
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:30:42.680469
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize TruTVIE class
    trutv = TruTVIE()
    # Test URL
    test_url = TruTVIE._TEST['url']
    display_id = TruTVIE._TEST['info_dict']['id']
    # Test valid URL
    assert trutv._match_id(test_url) != None, 'Valid URL not matched'
    # Test valid path
    assert trutv._real_extract(test_url)['id'] == display_id, 'Valid URL returned invalid media ID'

# Generated at 2022-06-12 18:30:52.926376
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert obj._TEST.get('url') == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert obj._TEST.get('info_dict').get('id') == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert obj._TEST.get

# Generated at 2022-06-12 18:30:53.466639
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:55.775100
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)

# Module test method for TruTVIE

# Generated at 2022-06-12 18:31:04.528419
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:31:09.028843
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert(trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-12 18:31:53.002041
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:56.857719
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable('https://www.trutv.com/shows/adam-ruins-everything/videos/adam-ruins-the-suburbs.html') == True
    assert TruTVIE.suitable('This is a nonsense url') == False


# Generated at 2022-06-12 18:32:03.351537
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print(TruTVIE.__name__)

# Generated at 2022-06-12 18:32:04.840478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(0)

# Generated at 2022-06-12 18:32:13.670709
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing...")
    assert TruTVIE.name == 'TruTV'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    ie = TruTVIE()
    ie._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:32:15.185716
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()
    print(m)

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-12 18:32:17.594509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    if __name__ == '__main__':
        from .test_TruTVIE import test_TruTVIE
    test_TruTVIE(TruTVIE)

# Generated at 2022-06-12 18:32:18.664988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:32:23.485045
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE(url)._VALID_URL == url
    url = 'https://www.trutv.com/full-episodes/26135'
    assert TruTVIE(url)._VALID_URL == url

# Generated at 2022-06-12 18:32:23.847562
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:14.166016
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:14.810553
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:15.873633
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-12 18:34:17.116795
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'


# Generated at 2022-06-12 18:34:22.497664
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    yt = TruTVIE()
    assert yt._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-12 18:34:24.915933
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()
    assert m.ie_key() == 'truTV'


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:34:26.795178
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        print("TruTVIE instantiated !")
    except AssertionError as ae:
        print(ae)
        print("TruTVIE instantiation failed !")


if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-12 18:34:28.347451
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception:
        return False
    return True


# Generated at 2022-06-12 18:34:29.836748
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:34:34.528859
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # The test case of TruTVIE
    test_case = TruTVIE._TEST
    # The extracted information
    info = TruTVIE()._real_extract(test_case['url'])
    # Asserts
    assert info['id'] == test_case['info_dict']['id']
    assert info['display_id'] == 'sunlight-activated-flower'
    assert info['title'] == test_case['info_dict']['title']
    assert info['description'] == test_case['info_dict']['description']
    assert info['site_name'] == 'truTV'
    assert info['auth_required'] == False