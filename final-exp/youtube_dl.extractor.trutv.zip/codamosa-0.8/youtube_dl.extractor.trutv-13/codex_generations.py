

# Generated at 2022-06-12 18:28:05.337654
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    # This is testing that the class does not error out on
    # construction.
    assert a is not None
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:05.875911
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-12 18:28:08.716689
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE._real_extract() method
    TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-12 18:28:09.533045
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-12 18:28:10.992058
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.suite()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:28:13.232294
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        raise AssertionError('UnitTest for TruTVIE.__init__() has failed.')

# Generated at 2022-06-12 18:28:17.153057
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE("https://www.trutv.com/full-episodes/727713/its-possible-videos/hilariously-bad-infomercials")
    except Exception as e:
        assert "Invalid URL" in str(e)

# Generated at 2022-06-12 18:28:19.500839
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    myTruTVIE = TruTVIE()

    #TruTVIE.ie_key()
    myTruTVIE.ie_key()

    #TruTVIE._VALID_URL
    myTruTVIE._VALID_URL

    #TruTVIE._TEST
    myTruTVIE._TEST

    #TruTVIE._real_extract()
    myTruTVIE._real_extract(myTruTVIE._TEST['url'])

# Generated at 2022-06-12 18:28:24.466718
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create mock object for argument 'url'
    url = MockURL(url=TruTVIE._TEST['url'])

    # Create instance of class TurnerBaseIE
    turnerbase = TruTVIE(url)

    # Test for required attributes
    assert turnerbase._VALID_URL == TruTVIE._VALID_URL
    assert turnerbase._TEST == TruTVIE._TEST

# Generated at 2022-06-12 18:28:25.400865
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:31.279694
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE != None


# Generated at 2022-06-12 18:28:42.708988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert x._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:28:47.418199
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    true_video_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert TruTVIE._TEST['info_dict']['id'] == true_video_id

# Generated at 2022-06-12 18:28:56.614681
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Check constructor of the class
    try:
        truTV_ie = TruTVIE()
    except:
        assert False, 'Could not create an instance of TruTVIE'

    # Check if the _VALID_URL is set to the appropriate data
    truTV_url_regex = 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._VALID_URL == truTV_url_regex, '_VALID_URL is not set to the appropriate data'


# Generated at 2022-06-12 18:29:06.972121
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    line = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    line2 = 'https://www.trutv.com/full-episodes/221397/the-carbonaro-effect-jun-05-2019/videos/sunlight-activated-flower.html'
    line3 = 'https://www.trutv.com/full-episodes/221397'
    trutvIE = TruTVIE(True)
    print("The clip slug for the given url(https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html) is:")
    print(trutvIE._real_extract(line).get("clip_slug",None))

# Generated at 2022-06-12 18:29:18.626439
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
# Test download of Sunlight-Activated Flower
    ttv.download_webpage(url="https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
# Test download of The Carbonaro Effect: Inside Carbonaro - Season 3, Episode 3
    ttv.download_webpage(url="https://www.trutv.com/full-episodes/151229/the-carbonaro-effect-inside-carbonaro-season-3-episode-3.html")
# Test download of The Carbonaro Effect: Inside Carbonaro - Season 1, Episode 1

# Generated at 2022-06-12 18:29:20.224906
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global TruTVIE
    assert TruTVIE.__name__ == 'TruTVIE'

# Generated at 2022-06-12 18:29:24.858981
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj!=None
    assert isinstance(obj, TruTVIE)
    assert obj._VALID_URL==r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:33.073418
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-12 18:29:39.451456
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-12 18:29:49.632375
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST
    assert TruTVIE()._downloader == None
    assert TruTVIE()._TYPE == TruTVIE._TYPE
    assert TruTVIE().IE_DESC == TruTVIE.IE_DESC
    assert TruTVIE().IE_NAME == TruTVIE.IE_NAME
    assert TruTVIE()._TESTS == TruTVIE._TESTS
    assert TruTVIE()._WORKING == TruTVIE._WORKING
test_TruTVIE()


# Generated at 2022-06-12 18:29:51.341178
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    assert test
    # test_TruTVIE()

# Generated at 2022-06-12 18:29:54.901677
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE_extractor = TruTVIE()
    
    result = TruTVIE_extractor.match("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

    assert result is not None

# Generated at 2022-06-12 18:30:04.329825
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Valid url
    url = 'https://www.trutv.com/full-episodes/136008/videos/sunlight-activated-flower.html'
    test_TruTVIE = TruTVIE()
    print(test_TruTVIE._TEST)

    # Invalid url
    url = 'https://www.trutv.com/full-episodes/136008/videos/sunlight-activated-flower.html'
    test_TruTVIE = TruTVIE()
    print(test_TruTVIE._TEST)

test_TruTVIE()

# Generated at 2022-06-12 18:30:06.146959
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert 0, 'Could not create instance of TruTVIE'


# Generated at 2022-06-12 18:30:06.669370
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:07.458674
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): TruTVIE()

# Generated at 2022-06-12 18:30:18.020052
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test that TruTVIE works with constructor
    ttv = TruTVIE()
    ttvUrl ="https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    ttvData = ttv._real_extract(ttvUrl)
    assert 'id' in ttvData
    assert ttvData['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert 'ext' in ttvData
    assert ttvData['ext'] == 'mp4'
    assert 'title' in ttvData
    assert ttvData['title'] == 'Sunlight-Activated Flower'
    assert 'description' in ttvData

# Generated at 2022-06-12 18:30:20.237725
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test function for constructor of class TruTVIE"""
    trutv_ie = TruTVIE()
    assert isinstance(trutv_ie, TruTVIE)

# Generated at 2022-06-12 18:30:22.396342
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_class = TruTVIE()
    assert hasattr(test_class, '_VALID_URL')
    assert hasattr(test_class, '_TEST')

# Generated at 2022-06-12 18:30:32.790357
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    print(t)

# Generated at 2022-06-12 18:30:38.718769
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE on various inputs"""
    import youtube_dl
    ydl = youtube_dl.YoutubeDL({})
    ie = ydl.extract_info('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', download=False)
    assert ie.get('id') == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-12 18:30:39.122274
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:46.507369
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    res = TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert res['title'] == 'Sunlight-Activated Flower'
    assert res['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert res['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-12 18:30:49.110380
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    expected_TruTVIE = TruTVIE
    actual_TruTVIE = TruTVIE
    assert expected_TruTVIE == actual_TruTVIE

# Generated at 2022-06-12 18:30:56.512568
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Construct a dummy instance of class TruTVIE
    test_case = TruTVIE()
    # Check the value of (private) variable '_VALID_URL'
    assert test_case._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Check the value of (private) variable '_TEST'

# Generated at 2022-06-12 18:30:58.845199
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert type(ie).__name__ == "TruTVIE"

# Generated at 2022-06-12 18:31:02.257745
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert(x.test(test_url) == None) # True when url is a valid url
    assert(x.test(test_url) != None) # True when url is not a valid url


# Generated at 2022-06-12 18:31:05.129736
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE object
    truTVIE = TruTVIE()
    assert truTVIE != None



# Generated at 2022-06-12 18:31:07.019178
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:35.983428
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    import sys
    import os
    import types
    import inspect

    this_module = sys.modules[__name__]
    trutv_ie = this_module.TruTVIE(None)
    
    assert isinstance(trutv_ie,this_module.TruTVIE)
    assert isinstance(trutv_ie.get_url_re(), types.RegexType)

    attributes = dir(trutv_ie)
    for attr in attributes:
        if attr == 'get_url_re':
            continue
        attr_obj = getattr(trutv_ie, attr)
        if inspect.isfunction(attr_obj):
            assert len(inspect.getargspec(attr_obj).args) == 2

# Generated at 2022-06-12 18:31:37.600142
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie != None

# Generated at 2022-06-12 18:31:41.208257
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE("http://www.trutv.com/shows/full-episodes/code-black/videos/code-black-101-pilot-1.html")
    assert i.name == "TruTV"

# Generated at 2022-06-12 18:31:41.914900
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:49.343177
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._TEST = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-12 18:31:58.885509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r"https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-12 18:32:02.557403
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TruTVIE())._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE(TruTVIE())._TEST == TruTVIE._TEST

# Generated at 2022-06-12 18:32:12.807579
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import trutv
    # test TruTVIE by downloading a Clip video (not an Episode)
    info_dict = trutv.extract('https://www.trutv.com/shows/impractical-jokers/videos/hell-diving-across-america.html')
    assert info_dict['site_name'] == 'truTV'
    assert info_dict['display_id'] == 'hell-diving-across-america'
    assert info_dict['id'] == '82bdaa2e1a7d4c9d9f7c1d89b396582c4a3fefa7'
    # test TruTVIE by downloading an Episode (not a Clip video)

# Generated at 2022-06-12 18:32:17.567964
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Tests the constructor of class TruTVIE
    # Making the following assumptions:
    #    series_slug = 'series_slug'
    #    clip_slug = 'clip_slug'
    #    video_id = 'video_id'

    #Arrange
    import re
    from youtube_dl.extractor.trutv import TruTVIE

    trutv = TruTVIE('http://www.trutv.com/shows/series-slug/videos/clip-slug')

    #Assert

# Generated at 2022-06-12 18:32:25.794328
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE('https://www.trutv.com/full-episodes/1708565/carbonaro-effect-season-2-episode-40/index.html')
    TruTVIE('https://www.trutv.com/shows/at-home-with-amy-sedaris/videos/pbr-cooler.html')
    TruTVIE('https://www.trutv.com/full-episodes/2040180/at-home-with-amy-sedaris-season-2-episode-0/index.html')

# Generated at 2022-06-12 18:33:17.696515
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TruTVIE.TruTVIE(self, url)
    # test init
    # test dataflow
    t=TruTVIE()
    t.result()




# Generated at 2022-06-12 18:33:20.299394
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:33:24.467686
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('trutv', 'www.trutv.com', 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html').test() is True


# Generated at 2022-06-12 18:33:26.839850
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('TruTVIE', 'TruTVIE.py', True)


# Generated at 2022-06-12 18:33:29.386757
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:33:30.695268
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE({})

# Generated at 2022-06-12 18:33:37.291077
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test method for TruTVIE.
    If a new class is added, write test method for it.
    If a method is added or modified, write test method for it.
    If attributes are added or modified, write test method for them.
    """
    # Initialize
    extractor = TruTVIE()
    # Check attributes
    assert extractor._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:33:44.887958
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv.site_name == "truTV"
    assert trutv.series_slug == "the-carbonaro-effect"
    assert trutv.clip_slug == "sunlight-activated-flower"

# Generated at 2022-06-12 18:33:50.141678
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiating object of class TruTVIE
    trutv= TruTVIE()
    # Valid URL for testing extractions
    test_url= 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Testing the extraction of URL
    assert (trutv._real_extract(test_url) != None)

# Generated at 2022-06-12 18:33:51.520355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor for TruTVIE
    a = TruTVIE()

# Test the data extraction for a TruTV episode

# Generated at 2022-06-12 18:35:36.170440
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.expected_errors == [404]
    assert ie.suitable(ie.ie_key(), "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") == True


# Generated at 2022-06-12 18:35:39.193268
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:35:40.122144
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TestObj = TruTVIE()
    TestObj.test()

# Generated at 2022-06-12 18:35:40.643876
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('embed')

# Generated at 2022-06-12 18:35:41.649368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # pylint: disable=R0904,W0612
    TruTVIE()

# Generated at 2022-06-12 18:35:42.667905
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test if it can be constructed
    assert TruTVIE() is not None

# Generated at 2022-06-12 18:35:49.777753
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE();

    # Test TruTV version of methods
    ie._extract_ngtv_info = TurnerBaseIE._extract_ngtv_info
    ie._extract_mvpd_auth = TurnerBaseIE._extract_mvpd_auth
    ie.extract = TurnerBaseIE.extract
    ie.get_url_contents = TurnerBaseIE.get_url_contents
    ie._download_ngtv_info = TurnerBaseIE._download_ngtv_info
    ie._extract_vod_ngtv_smil = TurnerBaseIE._extract_vod_ngtv_smil
    ie._download_smil = TurnerBaseIE._download_smil

# Generated at 2022-06-12 18:35:50.576390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:35:51.041358
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-12 18:35:57.724479
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'