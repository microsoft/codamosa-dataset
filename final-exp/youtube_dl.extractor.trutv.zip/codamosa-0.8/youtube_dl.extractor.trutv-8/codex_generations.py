

# Generated at 2022-06-12 18:27:56.941261
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Test the constructor of class TruTVIE by making sure it can construct a valid TruTVIE object
    :return: void
    '''
    assert TruTVIE().ie_key() == 'trutv'


# Generated at 2022-06-12 18:28:05.803961
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # check if this file is being executed as the "main" python
    # script instead of being used as a module by some other python script
    # or being executed by a dedicated testing tool
    # to be able to use special test code for this unit test, we have to use this
    # line as this file serves as both, the test module and the test script
    if __name__ == "__main__":
        ttv = TruTVIE()

        url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
        result = ttv._real_extract(url)
        assertEqual(result['id'], 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

# Generated at 2022-06-12 18:28:13.648817
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test = TruTVIE('test', 'test', 'test')
	assert test.bounding_box == [[0.0, 0.0], [1.0, 1.0]]
	assert test.width == 32
	assert test.heigth == 32
	assert test.is_fully_conv == True
	assert test.f_map == 8
	assert test.loss_type == 'mse'
	assert test.learning_rate == 0.0002
	assert test.learning_decay == 'true'
	assert test.momentum == 0.5
	assert test.nesterov == True
	assert test.batch_norm == 'true'
	assert test.dropout == 1
	assert test.regularization_rate == 0
	assert test.save == 'true'
	assert test.load == False
	assert test.pat

# Generated at 2022-06-12 18:28:20.630460
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test with a TruTV show
    assert TruTVIE._TEST['info_dict']['id'] == TruTVIE._real_extract(TruTVIE._TEST['url'])['id']
    # Test with a TruTV episode
    assert 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1' == TruTVIE._real_extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/102.html')['id']

# Generated at 2022-06-12 18:28:22.991233
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    # assert that parser is functional
    TruTVIE()._extract_ngtv_info('e6d728a55ccc776917dc0e042a8e1b45f7b397f0', '', {})

# Generated at 2022-06-12 18:28:27.580366
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Base Test
    video_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    base_extract = TruTVIE()._real_extract(video_url)
    # Test with asserts
    assert base_extract['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert base_extract['ext'] == 'mp4'
    assert base_extract['title'] == 'Sunlight-Activated Flower'
    assert base_extract['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert base_extract['site_name'] == 'truTV'

# Generated at 2022-06-12 18:28:29.538175
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert isinstance(x, TruTVIE)

# Unit test to check if video number is extracted

# Generated at 2022-06-12 18:28:34.143994
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    # Check assignment of TruTVIE.VALID_URL
    expected = TruTVIE._VALID_URL
    actual = ttv._VALID_URL
    assert expected == actual
    assert expected == ttv.VALID_URL


# Generated at 2022-06-12 18:28:41.326775
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Given
    # An URL: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html

    # When
    result = TruTVIE()._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # Then
    assert result['id'], 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-12 18:28:42.279567
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:01.172058
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE")
    ie = TruTVIE()
    ie.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    # Shouldn't raise any exceptions for these cases

# Generated at 2022-06-12 18:29:02.426873
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE = TruTVIE()

# Generated at 2022-06-12 18:29:05.847240
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:08.687577
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # This is a basic test to check if this function is working
    test = TurnerBaseIE()
    test.add_ie(TruTVIE)

    # Ensure that the test passes
    assert test.run()[0] is True

# Generated at 2022-06-12 18:29:10.613814
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE instance of class TruTVIE
    ttv = TruTVIE()
    # Check the class
    assert isinstance(ttv, TruTVIE)

# Generated at 2022-06-12 18:29:11.360358
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('trutv')


# Generated at 2022-06-12 18:29:11.867762
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:13.651462
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TruTVIE)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:29:15.694257
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    ttv.url_result()

# Generated at 2022-06-12 18:29:17.915791
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except NameError as e:
        assert e is not None
    else:
        assert False

# Generated at 2022-06-12 18:29:37.206029
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()



# Generated at 2022-06-12 18:29:43.427220
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit tests for constructor of class TruTVIE
    """
    # Case: video
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttvie = TruTVIE()
    ttvie._real_extract(url)
    # Case: episode
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/episode-6.html'
    ttvie = TruTVIE()
    ttvie._real_extract(url)

# Generated at 2022-06-12 18:29:49.056862
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:51.536511
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()

# Generated at 2022-06-12 18:29:52.090882
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("test_constructor")

# Generated at 2022-06-12 18:29:54.446255
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:30:04.242963
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    test for _extract_trutv_info

    """
    def _extract_trutv_info(media_id, info, ie_info):
        return {
            'url': 'https://api.trutv.com/v2/web/episode/tru-tv-tease/video/1188',
            'site_name': 'truTV',
            'auth_required': True
        }
    trutv_ie = TruTVIE()
    trutv_ie.trutv_ie = _extract_trutv_info

# Generated at 2022-06-12 18:30:09.752552
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import datetime
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    data = TruTVIE()._real_extract(url)
    assert data['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert data['title'] == 'Sunlight-Activated Flower'
    assert data['description'] == 'A customer is stunned when he sees Michael\'s sunlight-activated flower.'
    assert data['timestamp'] == datetime.datetime(2020, 2, 24, 0, 0)
    assert data['series'] == 'The Carbonaro Effect'
    assert data['season_number'] == 2
    assert data['episode_number'] == 10

# Generated at 2022-06-12 18:30:17.408842
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert re.match(TruTVIE._VALID_URL, TruTVIE._TEST['url'])
    assert TruTVIE._TEST['title'] == TruTVIE._TEST['info_dict']['title']
    assert TruTVIE._TEST['description'] == TruTVIE._TEST['info_dict']['description']
    assert TruTVIE._TEST['id'] == TruTVIE._TEST['info_dict']['id']
    assert TruTVIE._TEST['ext'] == TruTVIE._TEST['info_dict']['ext']

# Generated at 2022-06-12 18:30:25.019440
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()

    url_1 = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    expected_1 = ["f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"]
    url_2 = "https://www.trutv.com/shows/the-carbonaro-effect/videos/the-cats-pajamas.html"
    expected_2 = ["c0eef6d1b6d8bf6a71f6c2d077cb6592dd8e5b9d"]
    url_3 = "https://www.trutv.com/shows/the-carbonaro-effect/videos/going-for-braces.html"


# Generated at 2022-06-12 18:30:49.553358
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for webpage: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    TruTV_webpage_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE_ins = TruTVIE()
    TruTVIE_ins.extract(TruTV_webpage_url)

# Generated at 2022-06-12 18:30:50.022528
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-12 18:30:50.675520
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-12 18:30:59.026987
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

# Generated at 2022-06-12 18:31:02.098960
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
#test_TruTVIE()

# Generated at 2022-06-12 18:31:07.070614
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('The Carbonaro Effect', 'Sunlight-Activated Flower', 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

# Generated at 2022-06-12 18:31:07.663611
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:11.236632
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # First test
    TruTVIE()
    # Make sure TruTVIE is a subclass of TurnerBaseIE.
    assert issubclass(TruTVIE, TurnerBaseIE)
    # Make sure TruTVIE is a subclass of InfoExtractor.
    assert issubclass(TruTVIE, InfoExtractor)


# Generated at 2022-06-12 18:31:12.172563
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiation
    ie = TruTVIE()
    assert ie

# Generated at 2022-06-12 18:31:16.340899
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #arrange
    url = "https://www.trutv.com/shows/impractical-jokers/videos/randomly-generated-names.html"
    #expected
    expected_result = True
    #action
    actual_result = TruTVIE._VALID_URL.match(url)
    #assert
    assert actual_result == expected_result

# Generated at 2022-06-12 18:31:40.333177
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:44.276129
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    if trutv_ie.match("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"):
        print("TruTVIE: THE GOOD")
    else:
        print("TruTVIE: THE BAD")

# Generated at 2022-06-12 18:31:47.495435
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE('https://www.trutv.com/full-episodes/1015881/the-carbonaro-effect-season-1-episode-1/4006443')


# Generated at 2022-06-12 18:31:52.024769
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()
    assert truTVIE.__class__.__name__ == TruTVIE.__name__
    assert truTVIE._TEST == TruTVIE._TEST
    assert truTVIE._VALID_URL == TruTVIE._VALID_URL


# Generated at 2022-06-12 18:31:57.526287
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    # _VALID_URL should be a valid regex
    assert re.match(trutv_ie._VALID_URL, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is not None
    # _TEST should be a valid json
    json.loads(trutv_ie._TEST)

# Generated at 2022-06-12 18:31:59.789497
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-12 18:32:08.129385
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    trutv_ie._TEST = 'Fake data'
    assert trutv_ie._TEST == 'Fake data'

# Generated at 2022-06-12 18:32:09.351543
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Unit test for constructor of class TruTVIE")
    TruTVIE()

# Generated at 2022-06-12 18:32:17.418628
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    assert test._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:32:18.856466
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE
    assert instance

# Generated at 2022-06-12 18:33:07.754110
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_ie = TruTVIE()
    ttv_ie.download(url)
    print(ttv_ie)

# test url
url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Test
if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:33:17.170933
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:33:18.118763
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # check if it could initialize TruTVIE instance
    TruTVIE()

# Generated at 2022-06-12 18:33:19.279076
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	a = TruTVIE()
	b = a.__init__()

# Generated at 2022-06-12 18:33:27.714094
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-12 18:33:31.035621
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("\nunit test for TruTVIE")
    x = TruTVIE()
    print("url = {}".format(x._VALID_URL))
    print("test = {}".format(x._TEST))


# Generated at 2022-06-12 18:33:32.318918
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
       Test if the constructor can load the TruTVIE
    """
    TruTVIE()

# Generated at 2022-06-12 18:33:34.006502
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	try:
		assert TruTVIE()
	except AssertionError:
		print("TruTVIE not constructed")

# Generated at 2022-06-12 18:33:37.911913
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # videos/clip-slug
    TruTVIE()._real_extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # full-episodes/series-slug/id
    TruTVIE()._real_extract(
        'https://www.trutv.com/full-episodes/the-carbonaro-effect/599091/sunlight-activated-flower.html'
    )

# Generated at 2022-06-12 18:33:40.493754
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    ie = TruTVIE()
    ie.extract(url)

# Generated at 2022-06-12 18:35:30.284634
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_ = TruTVIE
    instance = class_()
    assert instance.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    assert instance.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    assert instance.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    assert instance.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True

# Generated at 2022-06-12 18:35:36.844531
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-12 18:35:39.969145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_obj = TruTVIE()
    assert tru_obj


# Generated at 2022-06-12 18:35:41.040754
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test TruTVIE instance is created
    TruTVIE()



# Generated at 2022-06-12 18:35:48.958690
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor
    ie = TruTVIE()
    # the 'constructor' attributes
    # URL
    assert ie.url == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test us using the 'Test-cases'
    for case in ie._TEST.items():
        url = case[1]['url']
        info_dict = case[1]['info_dict']
        # Check the 'id'
        assert ie._real_extract(url)['id'] == info_dict['id']
        # Check the 'ext

# Generated at 2022-06-12 18:35:56.157628
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_ = TruTVIE
    # Correct input
    instance = class_('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert instance.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert instance.get_url() == 'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower'
    assert instance.get_id() == 'sunlight-activated-flower'
    assert instance.get_display_id() == 'sunlight-activated-flower'

    # Invalid input

# Generated at 2022-06-12 18:35:57.592452
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    assert truTV._help() != None

# Generated at 2022-06-12 18:36:04.222919
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_ = TruTVIE
    trutv_ie = class_('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert(trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(type(trutv_ie) == type(class_))
    assert(hasattr(trutv_ie, '_downloader'))

# Generated at 2022-06-12 18:36:11.332368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    regex = re.compile(r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert regex.match('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert regex.match('https://www.trutv.com/shows/impractical-jokers/videos/q-gets-caught-in-the-crossfire.html')

# Generated at 2022-06-12 18:36:18.204733
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_object =  TruTVIE()
    assert test_object._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'