

# Generated at 2022-06-12 18:28:05.168039
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/81728/the-obstacle-in-the-obstacle-course.html') == True

# Generated at 2022-06-12 18:28:06.361826
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("video.url.gioi-thieu")

# Generated at 2022-06-12 18:28:13.994397
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:23.781508
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # url was valid
    url_valid = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # url was invalid
    url_invalid = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.htmls'
    test_truTVIE_valid = TruTVIE._TEST
    # create object
    TruTVIE_valid = TruTVIE(test_truTVIE_valid)
    TruTVIE_invalid = TruTVIE(test_truTVIE_valid)
    # test expected result

# Generated at 2022-06-12 18:28:28.326122
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'truTV'
    assert ie._VALID_URL == TruTVIE._VALID_URL
    assert ie.IE_DESC == 'truTV'
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_POLICY_KEY

# Generated at 2022-06-12 18:28:34.861923
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:35.860396
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('truTV') is not None

# Generated at 2022-06-12 18:28:38.841409
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    obj.test()



# Generated at 2022-06-12 18:28:40.232637
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global TruTVIE
    assert TruTVIE


# Generated at 2022-06-12 18:28:42.323788
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._type() == "TruTV"
    assert TruTVIE._title() == "TruTV"


# Generated at 2022-06-12 18:28:54.700553
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    
# Test TruTVIE constructor with url of type video
    test = TruTVIE()
    test.suite()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    expected_result = {'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
                       'ext': 'mp4',
                       'title': 'Sunlight-Activated Flower',
                       'description': "A customer is stunned when he sees Michael's sunlight-activated flower."
    }
    result = test.ie(url)
    assert result == expected_result

# Test TruTVIE constructor with url of type full episode
    test = TruTVIE()
    test.suite()

# Generated at 2022-06-12 18:28:55.539317
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.suite()

# Generated at 2022-06-12 18:28:56.126204
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:05.549743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor of class TruTVIE
    trutv = TruTVIE()

    # Test method of class TruTVIE: _real_extract
    test_cases = [
        {
            'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
            'info_dict': {
                'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
                'ext': 'mp4',
                'title': 'Sunlight-Activated Flower',
                'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
            },
        },
    ]
    for case in test_cases:
        url = case['url']
        dict_out = trut

# Generated at 2022-06-12 18:29:06.343394
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None

# Generated at 2022-06-12 18:29:18.252775
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()
    test = TruTVIE()

# Generated at 2022-06-12 18:29:25.149967
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    ie = TruTVIE()
    assert ie
    # Test TruTVIE url_result
    url_result = TruTVIE._match_id(TruTVIE._TEST)
    assert url_result
    # Test TruTVIE _real_extract
    # Note: trutv is not reliable
    # webpage = ie._download_webpage(
    #    TruTVIE._TEST, 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    # info = ie._real_extract(TruTVIE._VALID_URL, webpage)
    # assert info

# Generated at 2022-06-12 18:29:26.989590
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")


# Generated at 2022-06-12 18:29:34.972503
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # create object
    trutv = TruTVIE()
    print(type(trutv))
    # object is instance of class TruTVIE
    assert isinstance(trutv, TruTVIE)
    # object is instance of superclass YoutubeIE
    assert isinstance(trutv, TurnerBaseIE)
    # object is instance of class InfoExtractor
    assert isinstance(trutv, ie.InfoExtractor)
    # object is instance of class YoutubeBaseInfoExtractor
    assert isinstance(trutv, ie.YoutubeBaseInfoExtractor)



# Generated at 2022-06-12 18:29:35.498847
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-12 18:29:45.071892
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:49.821864
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE()
    print('test_obj=', test_obj)
    # TODO: complete the test here

# Generated at 2022-06-12 18:29:50.625056
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = ""
    TruTVIE(url)

# Generated at 2022-06-12 18:29:58.414815
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    inst = TruTVIE()
    assert inst.__class__.__name__ == "TruTVIE"
    assert inst._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:30:04.673205
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        info = TruTVIE._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
        print("Extraction is successful, info: %s" % info['title'])
    except Exception as e:
        print("Extraction is not successful, error: %s" % str(e))

# Generated at 2022-06-12 18:30:06.203309
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test that the TruTVIE class can be constructed, but we don't test any other methods
    ie = TruTVIE()
    ie.IE_NAME

# Generated at 2022-06-12 18:30:10.403022
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-12 18:30:11.469846
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:17.912532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None, None)

# Generated at 2022-06-12 18:30:18.770147
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().constructor()

# Generated at 2022-06-12 18:30:43.722139
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE.test.__name__ == 'test_TruTVIE'

    # Testing TruTVIE class constructor
    debug_dict_info = {}
    debug_dict_info['url'] = None
    debug_dict_info['info_dict'] = None
    debug_dict_info['params'] = None
    debug_dict_info['player_url'] = None
    debug_dict_info['tbr'] = None
    debug_dict_info['fatal'] = None
    debug_dict_info['video_id'] = None
    assert TruTVIE._TEST == debug_dict_info

# Generated at 2022-06-12 18:30:53.647519
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ref_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    ttv = TruTVIE()
    assert ttv.IE_NAME == 'trutv:shows'
    assert ttv.ie_key() == 'trutv'
    assert ttv.IE_DESC == 'Turner Entertainment sites'

# Generated at 2022-06-12 18:30:58.885785
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    t = TruTVIE()
    assert t._VALID_URL == TruTVIE._VALID_URL
    assert t._TEST == TruTVIE._TEST


# Generated at 2022-06-12 18:31:02.529485
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """TruTVIE unit test"""
    # Check for valid URL for constructor
    assert TruTVIE.suitable("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") == True


# Generated at 2022-06-12 18:31:07.215681
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor test
    TruTVIE('turner', 'turner')
    TruTVIE('turner', 'turner', 16)
    TruTVIE('turner', 'turner', 32)

# Generated at 2022-06-12 18:31:09.922309
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
        Test for constructor of TruTVIE
    """
    ttv = TruTVIE(None)
    assert TruTVIE == type(ttv)
    assert isinstance(ttv, TurnerBaseIE)

# Generated at 2022-06-12 18:31:10.383473
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:11.737455
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == "truTV"


# Generated at 2022-06-12 18:31:16.374529
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:31:16.828246
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:32:02.968412
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-12 18:32:04.162186
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-12 18:32:09.394136
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST
    assert TruTVIE()._real_extract(TruTVIE()._TEST['url'])

# Unit test - main
if __name__ == "__main__":
    print(TruTVIE()._TEST)

# Generated at 2022-06-12 18:32:11.120691
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE(TurnerBaseIE())
    t.extract()
    assert True

# Generated at 2022-06-12 18:32:11.669583
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:32:18.772906
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Import TruTV class
    from .truTV import TruTVIE

    # Create instance of TruTV class
    TruTVInstance = TruTVIE()

    # Verify that it is instance of TruTV class
    assert isinstance(TruTVInstance, TruTVIE)

    # Check for some specific class members
    assert TruTVInstance.IE_NAME == 'trutv'
    assert TruTVInstance.TEST.get('url') == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Check for specific class members

# Generated at 2022-06-12 18:32:27.264483
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ''' Test constructor of class TruTVIE '''
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:32:31.321640
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''Test construction of a class TruTVIE'''

# Generated at 2022-06-12 18:32:32.776664
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-12 18:32:34.277767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert len(obj._VALID_URL) is not 0

# Generated at 2022-06-12 18:34:26.829543
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url = 'https://www.trutv.com/shows/impractical-jokers/full-episodes/episode-301-grandma-the-bird-and-the-babies---pumpkin-patch.html'
    TruTVIE()._download_json(url, 'tmpv1.txt')

# Generated at 2022-06-12 18:34:31.344421
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Note: the URL is not valid
    actual = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert actual.series_slug == 'the-carbonaro-effect'
    assert actual.clip_slug == 'sunlight-activated-flower'
    assert actual.video_id == None
    assert actual.display_id == 'sunlight-activated-flower'

# Generated at 2022-06-12 18:34:32.017202
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)



# Generated at 2022-06-12 18:34:33.338745
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == "TruTVIE"



# Generated at 2022-06-12 18:34:40.503115
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for invalid URL
    for url in ('https://www.trutv.com/shows/impractical-jokers/videos',
                'https://www.trutv.com/shows/impractical-jokers/'):
        with pytest.raises(ExtractorError):
            TruTVIE().suitable(url)

    # Test for valid URL
    url = 'https://www.trutv.com/shows/impractical-jokers/videos/permanent-record-wrecker.html'
    TruTVIE().suitable(url)

# Generated at 2022-06-12 18:34:46.947744
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # String -> String
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # String -> String
    assert TruTVIE._TEST['info_dict']['id'] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    # String -> String
    assert TruTVIE._TEST['info_dict']['ext'] == "mp4"
    # String -> String
    assert TruTVIE._TEST['info_dict']['title'] == "Sunlight-Activated Flower"
    # String -> String

# Generated at 2022-06-12 18:34:50.185607
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor_object = TruTVIE(TurnerBaseIE._downloader, TurnerBaseIE._download_webpage, TurnerBaseIE._download_json)
    assert constructor_object


# Generated at 2022-06-12 18:34:58.858055
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST['params']['skip_download'] == True
    assert TruTVIE._TEST['info_dict']['title'] == 'Sunlight-Activated Flower'

# Generated at 2022-06-12 18:34:59.277931
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-12 18:35:01.263161
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')