

# Generated at 2022-06-12 18:27:53.843634
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:27:54.568887
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True == True

# Generated at 2022-06-12 18:28:04.411595
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test type TruTVIE (class)
    trutv = TruTVIE()
    assert(type(trutv) is TruTVIE)

    # Test type _TEST (dictionary) within test_TruTVIE()
    # NOTE: _TEST is within the class TruTVIE so it is a class attribute
    assert(type(trutv._TEST) is dict)
    assert(trutv._TEST['url'] == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert(trutv._TEST['info_dict']['id'] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1")

# Generated at 2022-06-12 18:28:05.435082
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:06.002082
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:06.539143
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:07.382944
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:10.211783
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE("TruTVIE", "TvGuide")
    assert("TruTVIE" == test_obj.name)
    assert("TvGuide" == test_obj.ie_key())


# Generated at 2022-06-12 18:28:12.328932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test __init__()
    assert TruTVIE


# Generated at 2022-06-12 18:28:22.465005
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE
    trutv = TruTVIE()
    (trutvClassName, trutvSuperClass) = trutv.__class__.__bases__
    assert (trutvClassName.__name__ == 'TurnerBaseIE')
    assert (trutvSuperClass.__name__ == 'InfoExtractor')
    # Test _VALID_URL
    assert (TruTVIE._VALID_URL == trutv._VALID_URL)
    # Test _TEST
    assert(TruTVIE._TEST == trutv._TEST)
    # Test _extract_ngtv_info
    assert(callable(trutv._extract_ngtv_info))
    # Test _real_extract
    assert(callable(trutv._real_extract))




# Generated at 2022-06-12 18:28:29.513353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    myTruTVIE = TruTVIE()
    assert myTruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:30.649068
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for TruTVIE class
    """
    trutv = TruTVIE()
    assert True

# Generated at 2022-06-12 18:28:42.243567
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from ..utils import urljoin
    tru = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    video_id = tru._match_id(url)
    assert video_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    info = tru.extract(url)
    assert info['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert info['title'] == 'Sunlight-Activated Flower'
    thumbnail_url = urljoin(url, info['thumbnail'])

# Generated at 2022-06-12 18:28:43.126232
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass


# Generated at 2022-06-12 18:28:47.018007
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.get_full_url(True) == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"


# Generated at 2022-06-12 18:28:57.129988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IS_TURNER == True, "IS_TURNER should be True"
    assert ie.SDK_URL == 'https://video.cnevids.com/json/ooyala/3.json', "SDK_URL should be the correct value"
    assert ie.META_URL == 'https://meta.api.cnevids.com/v1/content/%s', "META_URL should be the correct value"
    assert ie.TURNERTEN_URL == 'https://turner.api.cnevids.com/v1/tlogin', "TURNERTEN_URL should be the correct value"
    assert ie.TURNERTEN_AUTH == 'trutv', "TURNERTEN_AUTH should be the correct value"

# Generated at 2022-06-12 18:28:57.647017
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:59.350340
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:00.445066
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from utils import DummyClass
    TruTVIE(DummyClass())

# Generated at 2022-06-12 18:29:04.908511
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    instance._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    instance._real_extract("https://www.trutv.com/full-episodes/4867310/atv-speed-wobbles.html")

# Generated at 2022-06-12 18:29:17.094861
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from unit.test_downloader import EXAMPLE_URL, TestDownloader

    # Test TruTV constructor and extractor
    IE = TruTVIE()
    TestDownloader().run(IE, [EXAMPLE_URL])
    IE = TruTVIE(info_dict={})
    TestDownloader().run(IE, [EXAMPLE_URL])
    IE = TruTVIE(info_dict={}, params={})
    TestDownloader().run(IE, [EXAMPLE_URL])

# Generated at 2022-06-12 18:29:17.592399
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:23.082286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.get_id() == 'trutv'
    assert trutv_ie.get_name() == 'TruTV'
    assert trutv_ie.get_description() == 'Turner Broadcasting System online content'
    assert trutv_ie.get_thumbnail() == 'https://www.trutv.com/templates/trutv/icons/apple-touch-icon-ipad.png'

# Generated at 2022-06-12 18:29:24.535261
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        TruTVIE()

# Generated at 2022-06-12 18:29:27.083346
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-12 18:29:35.088464
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test with valid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ydl = TruTVIE()
    assert ydl.suitable(url)
    assert ydl._real_extract(url) is not None
    # Test with invalid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.aspx'
    ydl = TruTVIE()
    assert ydl.suitable(url) is False

# Generated at 2022-06-12 18:29:38.387665
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv_ie = TruTVIE()
    assert ttv_ie._VALID_URL
    assert ttv_ie._TEST
    assert ttv_ie.IE_NAME
    assert ttv_ie._TESTS
    assert ttv_ie._download_json

# Generated at 2022-06-12 18:29:45.889808
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test the TruTV constructor to see if the trutvIE instance was created
    try:
        info = TruTVIE()
    except:
        assert False, 'Failed to create trutvIE instance'

    assert hasattr(info, "suitable") and info.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'), \
        'The trutvIE instance is not suitable'

    assert hasattr(info, "extract") and callable(info.extract), 'No extract method exists'

    assert hasattr(info, "_download_json") and callable(info._download_json), 'No download_json method exists'


# Generated at 2022-06-12 18:29:52.257253
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._extract_ngtv_info('asd',{},'')
    ie._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:29:55.710108
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL is not None, 'TruTVIE URL has not been updated.'
    assert TruTVIE._TEST is not None, 'TruTVIE Test has not been updated.'
    assert TruTVIE._TESTS is not None, 'TruTVIE Test has not been updated.'

# Generated at 2022-06-12 18:30:22.009150
# Unit test for constructor of class TruTVIE
def test_TruTVIE():	
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:30:24.140399
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:29.214153
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    global TruTVIE
    test_suite = unittest.TestSuite()
    test_suite.addTest(TruTVIE('test_real_extract'))
    print(test_suite)
    unittest.TextTestRunner().run(test_suite)

# Generated at 2022-06-12 18:30:39.288456
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:30:50.306147
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:30:50.628130
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:51.164784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-12 18:30:52.925807
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    assert isinstance(test_TruTVIE, TruTVIE)


# Generated at 2022-06-12 18:30:53.468210
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-12 18:30:59.260891
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ie.extract(
        'https://www.trutv.com/full-episodes/416922/inside-amish-atrocities.html')

# Generated at 2022-06-12 18:31:47.996560
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import requests_mock
    from .test_downloader import FakeDownloader
    from .tvtracker_tests import TestTVTracker
    from .tvtracker import TestTVTrackerBaseIE

    TestTVTracker.TEST_DATA = TestTVTrackerBaseIE.TVT_TEST_DATA


# Generated at 2022-06-12 18:31:58.494734
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:32:10.073234
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE(TruTVIE._create_get_request(url))
    assert ie.__class__.__name__ == "TruTVIE" # check if the name of class is correct
    assert ie.ie_key() == "TruTVIE"
    urls = ie.extract(url)

# Generated at 2022-06-12 18:32:14.097656
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for the class TruTVIE()
    """
    try:
        TruTVIE()
    except NotImplementedError as e:
        g.print_error(e)
        return
    # Unit tests are not set up for TruTVIE
    g.print_error("Failed to raise NotImplementedError")
    return

# Generated at 2022-06-12 18:32:14.766621
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:32:17.101858
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        print("Can instantiate object successfully.")
    except:
        print("Cannot instantiate object.")

# Test the TruTVIE class

# Generated at 2022-06-12 18:32:19.969295
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
# Test for method '_real_extract' of class TruTVIE

# Generated at 2022-06-12 18:32:27.757285
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        from youtube_dl.extractor import VideoExtractor
        from youtube_dl.utils import ExtractorError
    except ImportError as e:
        print('There was an error importing the required modules in test_TruTVIE. Error: '+str(e))
    else:
        print("Successfully imported required modules in test_TruTVIE.")
        # Test for the constructor of TruTVIE class
        extractor = TruTVIE('test', 'test')
        assert isinstance(extractor, TruTVIE)
        assert isinstance(extractor, VideoExtractor)

        # Check for correct type of TruTVIE object
        extractor = TruTVIE('test', 'test')
        assert isinstance(extractor, TruTVIE)
        assert isinstance(extractor, VideoExtractor)

# Generated at 2022-06-12 18:32:31.323233
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    turner_ie = TruTVIE()
    assert turner_ie
    print(turner_ie)


# Generated at 2022-06-12 18:32:32.424831
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:13.705288
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-12 18:34:23.213728
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): 
    trutv = TruTVIE()
    assert trutv._VALID_URL == re.compile(r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert trutv._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:34:23.731985
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:32.626531
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test constructor for the class TruTVIE
    """
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()

    assert (trutv._VALID_URL ==
            r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')


# Generated at 2022-06-12 18:34:33.018996
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:33.904532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(True)

# Generated at 2022-06-12 18:34:35.797424
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE with constructor method
    t = TruTVIE()

# Generated at 2022-06-12 18:34:37.509617
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        return True
    except:
        return False

# Generated at 2022-06-12 18:34:43.620686
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for TruTVIE class in youtube_dl/extractor/trutv.py
    """

    # test class TruTVIE
    ttvie = TruTVIE()
    assert TruTVIE._VALID_URL == TruTVIE.VALID_URL

    # test class TurnerBaseIE
    tbeie = TruTVIE()
    assert TruTVIE != TurnerBaseIE

    # test real_extract()
    tbeie.real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-12 18:34:52.444601
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Unit test for TruTVIE constructor
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    extractor = TruTVIE()
    extractor.suitable(url)
    #extractor.extract(url)

    # Unit test for TruTVIE constructor
    url = 'https://www.trutv.com/full-episodes/48'
    extractor = TruTVIE()
    extractor.suitable(url)
    #extractor.extract(url)

if __name__ == '__main__':
    test_TruTVIE()