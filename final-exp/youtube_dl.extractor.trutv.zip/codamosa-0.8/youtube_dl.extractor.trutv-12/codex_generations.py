

# Generated at 2022-06-12 18:27:54.572621
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-12 18:28:01.656831
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    # test URL 
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert(obj._VALID_URL == url)
    return(obj)


if __name__ == "__main__":
    obj = test_TruTVIE()
    obj.download('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:28:02.280443
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:03.087382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE(None)

# Generated at 2022-06-12 18:28:12.111441
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  
  # Interaction with package
  import youtube_dl
  import youtube_dl.extractor.common as extractor_common
  import youtube_dl.utils as extractor_utils
  import youtube_dl.extractor.trutv as trutv_extractor

  # Create TruTVIE object from the URL
  url_to_test = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
  TruTVIE_obj = TruTVIE(trutv_extractor.TruTVIE(), url_to_test)

  # Validate the URL
  assert (TruTVIE_obj._VALID_URL == trutv_extractor.TruTVIE._VALID_URL)

  # Validate regex match
  regex_match_test = Tru

# Generated at 2022-06-12 18:28:22.225217
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:23.406526
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check the instatiation of TruTVIE
    assert TruTVIE()

# Generated at 2022-06-12 18:28:27.292323
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Test TruTVIE constructor """
    assert TruTVIE._VALID_URL is not None
    ttv = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ttv is not None


# Generated at 2022-06-12 18:28:34.437969
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv.name == 'truTV'
    assert ttv.domain_name == 'trutv.com'
    assert ttv.prefix == 'trutv'
    assert ttv.url_template == 'https://www.trutv.com/shows/%s/videos/%s'
    assert ttv.video_id_template == '%s'
    assert ttv.video_alt_id_template == '%s'
    assert ttv.series_id_template == '%s'
    assert ttv.page_id_template == '%s'
    assert ttv.page_key_template == '%s'
    assert ttv.page_key_page_of_template == '%s'

# Generated at 2022-06-12 18:28:36.540955
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    This is a simple test to determine that an instance of class TruTVIE can be created.
    """
    TruTVIE()


# Generated at 2022-06-12 18:28:47.588197
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:51.041376
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # testing the construction of TruTVIE class
    # If the constructor is correct then it will return a object of class TruTVIE
    assert TruTVIE is TruTVIE('trutv.TruTVIE').__class__

# Generated at 2022-06-12 18:28:52.386611
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)._extract_ngtv_info('Test')

# Generated at 2022-06-12 18:28:52.917911
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:55.128976
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for class TurnerBaseIE's constructor
    """
    test_obj = TruTVIE()
    assert isinstance(test_obj, TurnerBaseIE)

# Generated at 2022-06-12 18:28:56.244985
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SUCCESS == True


# Generated at 2022-06-12 18:29:04.869205
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Testing TruTVIE constructor')
    tru_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    tru_data = TruTVIE()._real_extract(tru_url)
    assert tru_data['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert tru_data['title'] == 'Sunlight-Activated Flower'
    assert tru_data['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    print('Passed all tests')

# Generated at 2022-06-12 18:29:05.373931
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-12 18:29:05.878529
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    True

# Generated at 2022-06-12 18:29:09.184922
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert(obj.name == 'truTV')
    assert(obj._VALID_URL == TruTVIE._VALID_URL)
    assert(obj._TEST == TruTVIE._TEST)


# Generated at 2022-06-12 18:29:19.536749
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:25.120045
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE(None)
    assert ttvie.name == "TruTV"
    assert ttvie.ie_key() == "trutv"
    assert ttvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:35.088841
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    # Unit test for valid url
    url = 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    expected_result = {'series_slug': 'the-carbonaro-effect', 'clip_slug': 'sunlight-activated-flower', 'id': None}
    actual_result = ttv._match_id(ttv._VALID_URL, url)
    assert expected_result == actual_result
    # Unit test for valid url with video id
    url = 'https://www.trutv.com/full-episodes/1740533/impractical-jokers-s5-e1-episode-501--jokers-playhouse.html'

# Generated at 2022-06-12 18:29:40.946585
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check that _TEST works
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TestIE.test(TruTVIE._TEST, 'Test TruTVIE._TEST')
    TestIE.test(TruTVIE._TEST, 'Test TruTVIE._TEST', url=url)
    # Check that TruTVIE constructor works
    TruTVIE(TestIE.create_dummy_ie(TruTVIE._TEST), url)

# Generated at 2022-06-12 18:29:42.961014
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()

# Generated at 2022-06-12 18:29:45.860909
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # assert test_TruTVIE[0] == TruTVIE._TEST.get('url')
    assert TruTVIE._TEST.get('info_dict').get('id') == \
        TruTVIE().extract(TruTVIE._TEST.get('url')).get('id')

# Generated at 2022-06-12 18:29:48.950650
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()


# Generated at 2022-06-12 18:29:53.515975
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not TruTVIE()._TEST == t._TEST


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:29:54.755024
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_instance = TruTVIE()
    assert test_instance is not None

# Generated at 2022-06-12 18:29:56.246414
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.NAME == "TruTV"

# Generated at 2022-06-12 18:30:16.723815
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-12 18:30:17.288648
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:18.809884
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #if there's no error raised
    #then test is considered success
    TruTVIE()


# Generated at 2022-06-12 18:30:25.990243
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-12 18:30:27.578658
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    assert truTV != None


# Generated at 2022-06-12 18:30:30.236394
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Test TruTVIE')

    test_instance = TruTVIE()
    print(test_instance.ie_key())
    


# Generated at 2022-06-12 18:30:36.239524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  """Test for constructor of class TruTVIE
  
  Raises:
    AssertionError: if test fails
  """
  turner_base_ie = TurnerBaseIE(
      'AOL',
      'http://aol.com',
      {'auth_required': False},
      '05d53cde5f84557fb92d9add1e5e5bac',
      True
  )
  trutv_ie = TruTVIE(turner_base_ie._downloader, turner_base_ie)

# Generated at 2022-06-12 18:30:39.882353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert test_case.test() == True, "test_case.test() did not return True"

# Generated at 2022-06-12 18:30:45.208853
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST['info_dict'] == {'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'ext': 'mp4',
        'title': 'Sunlight-Activated Flower', 'description': "A customer is stunned when he sees Michael's sunlight-activated flower."}
    assert TruTVIE._TEST['params'] == {'skip_download': True}

# Generated at 2022-06-12 18:30:46.219491
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        import TruTVIE
        assert TruTVIE

# Generated at 2022-06-12 18:31:28.804590
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:33.100075
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    ttv._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:31:35.304604
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    obj = TruTVIE()
    result = obj.suitable(url)
    assert result == True

# Generated at 2022-06-12 18:31:45.313282
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._VALID_URL == TruTVIE._VALID_URL
    series_slug, clip_slug, video_id = re.match(TruTVIE._VALID_URL, url).groups()
    if video_id:
        path = 'episode'
        display_id = video_id
    else:
        path = 'series/clip'
        display_id = clip_slug
    assert path == 'series/clip'
    assert display_id == 'sunlight-activated-flower'

# Generated at 2022-06-12 18:31:47.958800
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.get_test()['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-12 18:31:58.450360
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Setup environment for testing
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test = TruTVIE()._TEST
    TrutvIE = TruTVIE()
    # Test TruTVIE constructor
    assert TrutvIE._VALID_URL
    assert TrutvIE._TEST['url']
    assert TrutvIE._TEST['info_dict']
    assert TrutvIE._TEST['params']
    # Test TruTVIE.extract method
    info_dict = TrutvIE._real_extract(url)
    assert info_dict['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-12 18:31:59.882811
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:32:09.182942
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv.get_url_re() == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ttv.get_site_name() == 'truTV'
    assert ttv.get_context_url() == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:32:17.288527
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Constructor test.

    Unit tests for the TruTVIE class.
    """
    class_names = ["TurnerBaseIE", "TruTVIE"]
    if not TruTVIE.__doc__:
        assert TruTVIE.__doc__, "You may want to add __doc__ to your class"
    assert TruTVIE.__doc__, "You may want to add __doc__ to your class"

    # is class a subclass of TurnerBaseIE
    assert issubclass(TruTVIE, TurnerBaseIE), "You may want to extend TurnerBaseIE"

    # check str
    assert isinstance(str(TruTVIE), str), "You may want to add __str__ to your class"

    # check str

# Generated at 2022-06-12 18:32:26.693115
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test a TruTVIE url, and verify that the correct class is returned.
    match = TruTVIE._VALID_URL.match('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # assert isinstance(match.groupdict()['id'], str)
    # assert isinstance(match.groupdict()['series_slug'], str)
    # assert isinstance(match.groupdict()['clip_slug'], str)

    # Test a TruTVIE url that does not contain a clip_slug, and verify that the correct class is returned.
    match = TruTVIE._VALID_URL.match('https://www.trutv.com/shows/the-carbonaro-effect/17112')
    # assert isinstance(match.groupdict

# Generated at 2022-06-12 18:34:20.411766
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# create an object of class TruTVIE
	test_object = TruTVIE()
	test_object.test_test_true()
	print("TruTVIE object created")


# Generated at 2022-06-12 18:34:30.088328
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test = TruTVIE()._real_extract(url)
    #print(test)

# Generated at 2022-06-12 18:34:30.822555
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert()


# Generated at 2022-06-12 18:34:31.287057
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:31.929447
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()


# Generated at 2022-06-12 18:34:34.626955
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TruTVIE must be constructed with an IE name.
    # Calling the constructor with no arguments will raise an exception.
    try:
        trutvIE = TruTVIE()
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-12 18:34:43.765051
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor of class TruTVIE
    # test url: http://www.trutv.com/shows/jokers-wild/videos/jokers-wild-bile-em-cabbage-patch.html
    test_url = 'http://www.trutv.com/shows/jokers-wild/videos/jokers-wild-bile-em-cabbage-patch.html'
    # instantiate class
    trutv = TruTVIE()
    # call _real_extract
    test_dict = trutv._real_extract(test_url)
    # check keys
    assert test_dict['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert test_dict['ext'] == 'mp4'
   

# Generated at 2022-06-12 18:34:45.071213
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE', 'TruTVIE')

# Generated at 2022-06-12 18:34:47.118224
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')

# Generated at 2022-06-12 18:34:54.421030
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
