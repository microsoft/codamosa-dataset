

# Generated at 2022-06-12 18:27:59.868670
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()._real_extract(url)

# Generated at 2022-06-12 18:28:06.619809
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert TruTVIE._VALID_URL == trutv._VALID_URL
    assert TruTVIE._TEST == trutv._TEST
    assert TruTVIE.__doc__ == trutv.__doc__
    assert TruTVIE.IE_NAME == trutv.IE_NAME
    assert TruTVIE. _real_extract == trutv._real_extract

# Generated at 2022-06-12 18:28:09.111064
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert TruTVIE._VALID_URL is not None
    assert TruTVIE._TEST is not None
    assert trutv_ie._real_extract is not None

# Generated at 2022-06-12 18:28:15.366590
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Usage of constructor for class TruTVIE
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    trutv_ie._download_json(url)

    #Test
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:22.700115
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie_list = ie._available_constructors
    ie_list_keys = list(ie_list.keys())
    ie_list_values = list(ie_list.values())

    assert len(ie_list) == len(ie_list_keys)
    assert len(ie_list_values) == len(ie_list_keys)

    assert ie_list_keys[0] == 'TruTV'
    assert ie_list_keys[1] == 'TruTVClips'
    assert ie_list_keys[2] == 'TruTVEmbed'
    assert ie_list_keys[3] == 'TruTVSeriesIE'

    assert ie_list_values[0] == TruTVIE
    assert ie_list_values[1] == TruTVIE
    assert ie_list

# Generated at 2022-06-12 18:28:31.578504
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:42.749003
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #TEST 1: test if the class is able to scrape
    _TEST1 = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

    # Test the TruTVIE class constructor
    truTV = TruTVIE()
    #TEST 2

# Generated at 2022-06-12 18:28:45.854283
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiation
    # unit test of constructor of class
    test_ie = TruTVIE()
    assert test_ie != None
    return


# Generated at 2022-06-12 18:28:51.513890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE constructor"""
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_obj = TruTVIE(test_url)
    test_obj._real_extract(test_url)

# Generated at 2022-06-12 18:28:52.106232
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:09.813112
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE() # get an object TruTVIE

    assert trutv_ie.js_to_json('{test: "unit test"}') == '{test: "unit test"}'

    assert trutv_ie.turner_to_id('abcdef') == 'abcdef'

    assert trutv_ie._extract_title('abcdef') == 'abcdef'

    assert trutv_ie.turner_to_id('abcdef') == 'abcdef'

    assert trutv_ie._extract_description('abcdef') == 'abcdef'

    assert trutv_ie._extract_ngtv_video_ident({}) == {}

    assert trutv_ie._extract_ngtv_entitlement({}) == {}

    assert trutv_ie._extract_

# Generated at 2022-06-12 18:29:10.579811
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-12 18:29:16.838507
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    b = TruTVIE('https://www.trutv.com/shows/kidd-nation/videos/kidd-krusaders-presents-gullibles-travels.html')
    c = TruTVIE('https://www.trutv.com/full-episodes/5527/impractical-jokers-season-2-the-q-man-can/index.html')
    d = TruTVIE('https://www.trutv.com/full-episodes/5092/kidd-nation/index.html')

# Generated at 2022-06-12 18:29:17.745431
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a is not None

# Generated at 2022-06-12 18:29:27.511724
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE()
    pattn_url = r'^https://api\.trutv\.com/v2/web/series/clip/[0-9A-Za-z-]+/[0-9A-Za-z-]+$'
    assert re.match(pattn_url, ttvie._TEST['url']) is not None
    assert ttvie._TEST['info_dict']['description'] is not None
    assert ttvie._TEST['info_dict']['description'].startswith('A customer')
    assert 'episode' not in ttvie._TEST['url']
    # Check that the class constructor works monolithically
    ttvie._real_extract(ttvie._TEST['url'])


# Generated at 2022-06-12 18:29:37.528845
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()
    assert i._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:41.098483
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    data_url = 'https://api.trutv.com/v2/web/episode/jokers/1572956/1572956'
    story = TruTVIE()
    file = story._download_json(data_url,'1572956')
    print(file['episode'])


# Generated at 2022-06-12 18:29:41.581281
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("")

# Generated at 2022-06-12 18:29:42.055159
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-12 18:29:48.212430
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Trivial case
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/episodes/season-1/peter-pan-is-going-to-die.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/episodes/season-1/peter-pan-is-going-to-die.html')

# Generated at 2022-06-12 18:29:58.733957
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-12 18:30:02.470399
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie is not None

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:30:03.069484
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:04.665620
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

TruTVIE = TruTVIE()

# Generated at 2022-06-12 18:30:06.463944
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        raise AssertionError("TruTVIE() constructor failed")

# Generated at 2022-06-12 18:30:12.311164
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    fileToRead = 'extractors/trutv.py'
    testTR = TruTVIE

    testTR._VALID_URL = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

# Generated at 2022-06-12 18:30:14.208932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for extracting 1 TruTV video
    TruTVIE().extract(TruTVIE._TEST['url'])

# Generated at 2022-06-12 18:30:16.878141
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #TruTVIE()
    #TruTVIE(TurnerBaseIE)
    #TruTVIE(TurnerBaseIE, TruTVIE)
    print("Hello World")
    return

# Generated at 2022-06-12 18:30:24.979741
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Mock the constructor function
    classMock = Mock(spec=TruTVIE)

    # Test with a valid URL
    assert TruTVIE._VALID_URL.match('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is not None

    # Test with an invalid URL
    assert TruTVIE._VALID_URL.match('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is None

    # Test with a valid test
    TruTVIE._TEST['url'] = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:30:30.542965
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:30:48.666873
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:49.553572
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-12 18:30:51.059711
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    input_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    btest = TurnerBaseIE()
    test = TruTVIE()

# Generated at 2022-06-12 18:30:51.399762
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:58.855982
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE()._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:31:02.529848
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutv_ie = TruTVIE()
    result_dict = trutv_ie.extract(url)
    pr

# Generated at 2022-06-12 18:31:03.600719
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:07.418302
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test constructor
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-12 18:31:08.301082
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("TruTVIE")

# Generated at 2022-06-12 18:31:09.274225
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:56.437250
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.get_id() == "truTV"
    assert obj.get_domain() == "trutv.com"
    assert obj.get_url() == "https://api.trutv.com/v2/iosapi/auth/platform/adobe?device=ipad&domain=api.trutv.com&player=ngtv&uuid=00000000-77bb-0eee-d699-77fd00eef8c9"
    assert obj.get_url_extractor() == TruTVIE._VALID_URL

# Generated at 2022-06-12 18:31:56.926635
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TruTVIE")

# Generated at 2022-06-12 18:31:58.253675
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj is not None


# Generated at 2022-06-12 18:32:09.884593
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:32:13.258967
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test for invalid url
    TruTVIE('https://www.trutv.com/index.html')

    # test for valid url
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:32:13.839263
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:32:14.264262
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:32:14.957855
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:32:18.103199
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
# Constructor will not return any value as it is set as _call_()
# print(test_TruTVIE())
    return test_TruTVIE


# Generated at 2022-06-12 18:32:18.954405
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:33:59.965319
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-12 18:34:01.075602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.test(test_TruTVIE)

# Generated at 2022-06-12 18:34:02.767918
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    cls = TruTVIE()
    #truTVIE = TruTVIE()

    #truTVIE._real_extract()

# Generated at 2022-06-12 18:34:04.524450
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiate class to run unit tests
    test = TruTVIE()
    test.test()

# Main function that runs unit tests
if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:34:05.249456
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-12 18:34:16.083182
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from json import loads
    from .common import expected
    from .common import expected_with_skip_download
    from .common import extractor_for_class

    # Verify TruTVIE can be created with its constructor
    ie = extractor_for_class(TruTVIE)
    assert ie.__name__ == 'TruTVIE'
    assert ie.IE_NAME == 'trutv:trutv'
    assert ie.IE_DESC == 'truTV'

    # Test TruTVIE extractors:
    expected_test = expected.copy()
    expected_test['description'] = 'A customer is stunned when he sees Michael\'s sunlight-activated flower.'
    expected_test['series'] = 'The Carbonaro Effect'
    expected_test['season_number'] = 3
    expected_test['episode_number'] = 4


# Generated at 2022-06-12 18:34:16.655469
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:17.507453
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()

# Generated at 2022-06-12 18:34:18.510838
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE"""

    TruTVIE()

# Generated at 2022-06-12 18:34:20.281331
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Initializing class
	test_instance = TruTVIE()

# Test pattern of class