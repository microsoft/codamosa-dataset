

# Generated at 2022-06-12 18:28:04.483722
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert(x._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:28:12.701624
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    extractor = TruTVIE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:15.128188
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:28:24.867787
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test URL construction for TruTVIE
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Test if TruTVIE is able to extract info from given link

# Generated at 2022-06-12 18:28:27.596234
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This test case will check if the instance of TruTVIE class is created successfully
    class_instance = TruTVIE()
    assert isinstance(class_instance, TruTVIE)


# Generated at 2022-06-12 18:28:28.657050
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:28:33.249088
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/tru-tv-top-funniest/videos/animal-antics.html")
    TruTVIE("https://www.trutv.com/shows/tru-tv-top-funniest/videos/animal-antics.html")
    TruTVIE("https://www.trutv.com/shows/tru-tv-top-funniest/videos/animal-antics.html")

# Generated at 2022-06-12 18:28:37.522425
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor = TruTVIE.__mro__[2].__init__
    instance1 = constructor(TruTVIE)
    assert isinstance(instance1, TruTVIE)
    assert TruTVIE.__mro__[2].__name__ == 'TurnerBaseIE'

# Generated at 2022-06-12 18:28:46.630053
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tvie = TruTVIE()
    assert tvie.extract_id('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert tvie.extract_id('https://www.trutv.com/full-episodes/87311/the-carbonaro-effect-the-carbonaro-effect-full-episode.html') == '4a4c0e8d5d650a5b5a9f0f8d874259c0aae32f29'


# Generated at 2022-06-12 18:28:52.390661
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
	assert TruTVIE().__name__ == 'TruTV'
	assert TruTVIE().IE_NAME == 'trutv:clip'


# Generated at 2022-06-12 18:28:59.471086
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE()
    return trutvie

# Generated at 2022-06-12 18:29:07.340658
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.download_webpage('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    info = ie._extract_ngtv_info('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', {}, {'url':'https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'site_name':'truTV', 'auth_required':False})
    assert info['timestamp'] == 1527974800

# Generated at 2022-06-12 18:29:14.506216
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    valid_urls = (
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'https://www.trutv.com/full-episodes/videos/912',
    )
    for url in valid_urls:
        assert TruTVIE._VALID_URL == TruTVIE._match_id(url)

# Generated at 2022-06-12 18:29:16.311553
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor for TruTVIE
    trutvIE = TruTVIE()

# Generated at 2022-06-12 18:29:24.802666
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:29:25.153089
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:26.017666
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None

# Generated at 2022-06-12 18:29:36.398765
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    t = TruTVIE()
    assert TruTVIE._VALID_URL == t._VALID_URL

    # Unit test for _extract_ngtv_info()
    m = re.match(t._VALID_URL, video_url)
    assert m is not None
    series_slug, clip_slug, video_id = m.groups()

    if video_id:
        path = 'episode'
        display_id = video_id
    else:
        path = 'series/clip'
        display_id = clip_slug


# Generated at 2022-06-12 18:29:44.402077
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor of TruTVIE class
    # test_TruTVIE()
    trutv = TruTVIE()
    print(re.match(r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))', trutv._VALID_URL))

# Generated at 2022-06-12 18:29:45.226189
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()

# Generated at 2022-06-12 18:29:53.738000
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_video = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert trutv_video != None

# Generated at 2022-06-12 18:29:55.226606
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)._download_webpage(None, None, query={'foo': 'bar'})

# Generated at 2022-06-12 18:29:57.916476
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie == TruTVIE()
    assert ie.IE_NAME == 'truTV'

# Generated at 2022-06-12 18:30:01.783053
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
# Unit test URL : https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html

# Generated at 2022-06-12 18:30:02.425928
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-12 18:30:03.069235
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:04.665693
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() is not None, "It should create object of TruTVIE class"

# Generated at 2022-06-12 18:30:05.947978
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    print(test_TruTVIE)


# Generated at 2022-06-12 18:30:06.831411
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() is not None

# Generated at 2022-06-12 18:30:08.218767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None



# Generated at 2022-06-12 18:30:25.261421
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:30:28.424343
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test TruTVIE class from __init__.py
    assert TruTVIE.test() == TruTVIE._TEST.get('info_dict')

# Generated at 2022-06-12 18:30:29.353510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ie = TruTVIE()
	print ("********Successfully tested constructor of TruTVIE class**********")


# Generated at 2022-06-12 18:30:33.805390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    p = TruTVIE()
    assert p._VALID_URL == TruTVIE._VALID_URL
    assert p._TEST == TruTVIE._TEST
    assert p._real_extract == TruTVIE._real_extract

# Unit test to verify TruTVIE class is not null

# Generated at 2022-06-12 18:30:34.695227
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tr = TruTVIE()
    tr.extract('')

# Generated at 2022-06-12 18:30:37.982951
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # check constructor
    assert TruTVIE.__name__ == 'TruTVIE'

    # check if it is an instance of TurnerBaseIE
    assert isinstance(TruTVIE(), TurnerBaseIE)

# Generated at 2022-06-12 18:30:42.425513
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'


# Generated at 2022-06-12 18:30:51.001290
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    clip1 = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    clip2 = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/120964/sunlight-activated-flower.html")
    episode1 = TruTVIE("https://www.trutv.com/full-episodes/120964/episode-13-mini-master/trutv.html")
    episode2 = TruTVIE("https://www.trutv.com/full-episodes/120964/")

# Generated at 2022-06-12 18:30:51.525355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	pass

# Generated at 2022-06-12 18:30:52.660882
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None

# Generated at 2022-06-12 18:31:21.064760
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

	# Test initialization with valid URL
	test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	test_obj = TruTVIE(url=test_url)

	# Test get_url_info
	info_dict = test_obj.get_url_info(test_url)
	assert info_dict['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
	assert info_dict['sponsor'] == 'truTV'
	assert info_dict['timestamp'] == '20171103070000'
	assert info_dict['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-12 18:31:23.043315
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.ie_key() == 'trutv'
    assert ie.ie_name() == 'TruTV'

# Generated at 2022-06-12 18:31:26.900642
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make sure TruTVIE is initialized correctly and can be used to extract information from a valid url
    # This particular url is for "Sunlight-Activated Flower" from the program "The Carbonaro Effect"
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_TruTVIE = TruTVIE()
    test_TruTVIE._real_extract(test_url)
    return True

# Generated at 2022-06-12 18:31:29.873867
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing TruTVIE constructor:
    # 1. create an object of TruTVIE
    # 2. check the type of object by using isinstance
    # 3. check the type of object by using assertEqual
    truTV_object = TruTVIE()
    isinstance(truTV_object, TruTVIE)
    assertEqual(type(truTV_object), TruTVIE)


# Generated at 2022-06-12 18:31:34.528329
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv is not None
    ttv = TruTVIE('http://trutv.com')
    assert ttv is not None
    ttv = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ttv is not None

# Generated at 2022-06-12 18:31:45.809708
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:31:47.036067
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    assert truTV is not None

# Generated at 2022-06-12 18:31:48.193627
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass  ## TODO

## Unit tests for TruTVIE

# Generated at 2022-06-12 18:31:49.686723
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:55.623617
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test for constructor of TruTVIE"""
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttvie = TruTVIE()
    ttvie._download_webpage('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'asdf')
    ttvie._real_extract(url)

# Generated at 2022-06-12 18:32:42.477610
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # Test case 1
    TruTVIE.test(ie,
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Test case for the constructor of class PGAIE
    TruTVIE.test(ie,
        'https://www.trutv.com/full-episodes/48035/impractical-jokers-episode-12.html')

# Generated at 2022-06-12 18:32:48.021870
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Make sure trutv.com web page is reachable
    try:
        _ = TruTVIE._download_webpage(url, None)  # pylint: disable=protected-access
    except:  # pylint: disable=bare-except
        print('INFO: Could not download web page: ' + url)
        print('INFO: Test of trutv.com web page skipped')
        return

    # Test TruTVIE constructor
    TruTVIE(None)  # pylint: disable=no-value-for-parameter

# Generated at 2022-06-12 18:32:57.113989
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE()._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE()._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-12 18:33:02.523276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:33:03.027981
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-12 18:33:12.052224
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:33:15.630848
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test URL
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    # Test constructor
    TruTVIE(TruTVIE._downloader, url)

# Generated at 2022-06-12 18:33:16.557093
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    assert True

# Generated at 2022-06-12 18:33:16.994226
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:33:21.161378
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'


# Generated at 2022-06-12 18:35:10.439157
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()

# Generated at 2022-06-12 18:35:11.703186
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    extractor = TruTVIE()
    assert extractor._TEST == TruTVIE._TEST

# Generated at 2022-06-12 18:35:14.121180
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE("test_ie")
    print("test_ie: ",ttv)
    # Expected
    # <TruTVIE yt-uix-sessionlink yt-valign">test_ie</a>

# Generated at 2022-06-12 18:35:14.814956
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE
    TruTVIE()

# Generated at 2022-06-12 18:35:18.259316
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ################################################################################
    # Test TruTVIE constructor
    ################################################################################
    ttv = TruTVIE();
    # Test TruTVIE.ie_key
    assert(ttv.ie_key() == 'truTV')
    # Test TruTVIE.video_id
    assert(ttv.video_id() == '')


# Generated at 2022-06-12 18:35:18.645643
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:35:20.182597
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TurnerBaseIE()
    assert t.ie_key() == 'trutv'
    assert t._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-12 18:35:22.215455
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert "TruTV" in TruTVIE.IE_NAME

# Generated at 2022-06-12 18:35:30.538238
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
        Test TruTVIE constructor
        This test will check the TruTVIE constructor with the TruTVIE._TEST.
    """
    print("Testing constructor with TruTVIE._TEST...")
    url = r"https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_video_pattern = TruTVIE._TEST
    test_video_pattern['url'] = url
    test_video_pattern_copy = test_video_pattern.copy()
    del test_video_pattern_copy['params']
    test_video_pattern_copy['url'] = url
    # Loads the content of TruTVIE._TEST into the TruTVIE class.
    test_video = TruTVIE(url, test_video_pattern)
    # Checks if the

# Generated at 2022-06-12 18:35:37.100498
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'