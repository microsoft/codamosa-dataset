

# Generated at 2022-06-12 18:27:58.983509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert isinstance(ie, TruTVIE)

# Generated at 2022-06-12 18:28:03.012516
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._extract_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:28:05.653834
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Just a constructor test to see if class TruTVIE is defined
    instance = TruTVIE()
    print(instance)

# Generated at 2022-06-12 18:28:10.110514
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("\nUnit test for constructor of class TruTVIE")
    assert TruTVIE._TEST.get("url").strip() == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert TruTVIE._TEST.get("info_dict").get("title").strip() == "Sunlight-Activated Flower"


# Generated at 2022-06-12 18:28:11.801758
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1') is not None

# Generated at 2022-06-12 18:28:12.769039
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-12 18:28:22.876631
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._valid_url('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv._valid_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv._valid_url('http://www.trutv.com/full-episodes/the-carbonaro-effect/4849/sunlight-activated-flower.html')
    assert trutv._valid_url('https://www.trutv.com/full-episodes/the-carbonaro-effect/4849/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:28:24.884449
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tt = TruTVIE()
    assert tt.site_name == 'truTV'
    assert tt.auth_required == True

if __name__ == "__main__":
    # Unit test for class TruTVIE
    test_TruTVIE()

# Generated at 2022-06-12 18:28:30.043341
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-12 18:28:41.549915
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    # for testing purpose, set _VALID_URL
    TruTVIE._VALID_URL = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # for testing purpose, set _TEST

# Generated at 2022-06-12 18:28:52.024017
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:52.594934
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:54.493562
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL != ""
    assert obj._TEST != ""


# Generated at 2022-06-12 18:28:55.022867
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:55.519507
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-12 18:29:01.623788
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #example: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    TruTVIE.suitable(url)
    ie = TruTVIE()
    ie._real_extract(url)

# Generated at 2022-06-12 18:29:06.597413
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE()._VALID_URL
    m = re.match(url, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    series_slug, clip_slug, video_id = m.groups()
    assert series_slug == 'the-carbonaro-effect'
    assert clip_slug == 'sunlight-activated-flower'
    assert video_id == None
    m = re.match(url, 'https://www.trutv.com/full-episodes/the-carbonaro-effect/96659')
    series_slug, clip_slug, video_id = m.groups()
    assert series_slug == 'the-carbonaro-effect'
    assert clip_slug == None
    assert video

# Generated at 2022-06-12 18:29:07.137855
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-12 18:29:07.964360
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test TruTVIE
    TruTVIE()

# Generated at 2022-06-12 18:29:19.620530
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # URL without id
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-12 18:29:38.671108
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("\n=== Begin TruTVIE class test ===")

    test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_url2 = "https://www.trutv.com/shows/the-carbonaro-effect/videos/episode-101-season-1.html"
    test_url3 = "https://www.trutv.com/shows/hacksaw-ridge-the-real-life-war-hero/videos/bonus-clip-the-real-desmond-doss.html"

    truTVIE = TruTVIE() 
    # test _real_extract method of class TruTVIE
    info_dict = truTVIE._real_extract(test_url)
    assert info_dict['url']

# Generated at 2022-06-12 18:29:41.184596
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST['url']
    assert TruTVIE._VALID_URL
    assert TruTVIE._TEST['info_dict']
    assert TruTVIE._TEST['params']

# Generated at 2022-06-12 18:29:43.437318
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert('trutv' in trutv_ie._WORKING_URL)
    assert('trutv.com' in trutv_ie._WORKING_URL)

# Generated at 2022-06-12 18:29:45.728431
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Testing TruTVIE')
    instance = TruTVIE('/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    instance.download()
    instance.dump()

# Generated at 2022-06-12 18:29:48.550223
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

	truTVIE = TruTVIE()
	assert isinstance(truTVIE, TruTVIE)

	try:
		truTVIE.suitable('http://www.trutv.com/full-episodes/some-text.html')
	except RegexNotFoundError as e:
		print(e)

# Generated at 2022-06-12 18:29:53.148139
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-12 18:29:53.696412
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:59.380098
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    ie = TruTVIE()
    ie._files = ie._files.copy()
    ie._files['player.js'] = "var html5Settings = { 'ngtv_player_api_domain' : 'ngtv.service.brightcove.com', 'ngtv_player_api_base' : 'https://ngtv.service.brightcove.com/v1/accounts/', 'ngtv_player_api_key' : 'ngtv-api-key', 'ngtv_player_api_secret' : 'ngtv-api-secret'};"
    ie.download(url)

# Generated at 2022-06-12 18:30:04.539535
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert str(type(trutv_ie)) == "<class 'youtube_dl.extractor.trutv.TruTVIE'>"
    assert trutv_ie._VALID_URL is not None
    assert trutv_ie._TEST is not None

# Generated at 2022-06-12 18:30:07.580573
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    except Exception as e:
        print(e)
        raise AssertionError("TruTVIE constructor failed")

# Generated at 2022-06-12 18:30:27.582419
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:30.862076
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(url, 'TruTVIE')

# Generated at 2022-06-12 18:30:35.264411
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    from .ttv_video_embed import TruTvEmbedIE
    from .ttv_mini_player import TruTvMiniPlayerIE

    # test TruTVIE in constructor
    assert TruTVIE == TruTVIE._build_ie()

    # test TruTvEmbedIE in constructor
    assert TruTvEmbedIE == TruTvEmbedIE._build_ie()

    # test TruTvMiniPlayerIE in constructor
    assert TruTvMiniPlayerIE == TruTvMiniPlayerIE._build_ie()

# Generated at 2022-06-12 18:30:39.126278
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize TruTVIE with url as "url" and assign it to trutv_ie
    trutv_ie = TruTVIE(url='url')
    # Assert that trutv_ie is not null
    assert trutv_ie is not None

# Generated at 2022-06-12 18:30:42.291752
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
        test = TruTVIE(url)
        assert test.extract(url) == True
    except:
        print("test_TruTVIE failed")

# Generated at 2022-06-12 18:30:43.174829
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:47.783319
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url="https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    obj=TruTVIE()
    #obj._real_extract(url)
#test_TruTVIE()

# Generated at 2022-06-12 18:30:48.361429
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:51.763613
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    ttv._VALID_URL = r"https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert ttv._VALID_URL

# Generated at 2022-06-12 18:30:59.087263
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:31:43.471510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-12 18:31:44.314839
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test = TruTVIE()
	test

# Generated at 2022-06-12 18:31:50.428334
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    assert ie._match_id(url) == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert ie._match_id('https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/episode-1-its-a-puppet-9.html') == '9'
    assert ie._match_id('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == None

# Generated at 2022-06-12 18:31:51.617958
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    raise Exception("Please write unit test for constructor of class TruTVIE")


# Generated at 2022-06-12 18:31:57.351752
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	regex = TruTVIE._VALID_URL
	assert re.match(TruTVIE._VALID_URL, url).groupdict() == {'series_slug': 'the-carbonaro-effect', 'clip_slug': 'sunlight-activated-flower', 'id': None}

# Generated at 2022-06-12 18:31:58.884473
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert isinstance(trutv_ie, TruTVIE)

# Generated at 2022-06-12 18:32:10.110995
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Valid data for 'url'
    test_TruTVIE.url = [
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/the-carbonaro-effect-s5-ep1-drop-bears-revealed.html'
    ]
    # Valid data for 'expected_results'

# Generated at 2022-06-12 18:32:17.938428
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:32:21.231187
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST
# end of unit test for constructor of class TruTVIE

# Generated at 2022-06-12 18:32:21.873092
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:20.490210
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:34:22.086645
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-12 18:34:24.300428
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:34:25.676651
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:33.438053
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._VALID_URL = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:34:42.977974
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST is not None
    assert TruTVIE._VALID_URL is not None
    assert TruTVIE._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower."
        },
        'params': {
            'skip_download': True
        }
    }

# Generated at 2022-06-12 18:34:45.073161
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert 'TruTVIE' in globals(), "Class TruTVIE is not defined"
    trueTVIE = TruTVIE()
    assert '_VALID_URL' in trueTVIE._TEST, '_VALID_URL is not defined.'

# Generated at 2022-06-12 18:34:46.584499
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t
    assert TruTVIE._VALID_URL
    assert TruTVIE._TEST
    assert TruTVIE._real_extract

# Generated at 2022-06-12 18:34:50.932786
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:34:53.597164
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')