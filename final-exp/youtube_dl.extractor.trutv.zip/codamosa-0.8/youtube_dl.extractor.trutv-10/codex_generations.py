

# Generated at 2022-06-12 18:27:57.293137
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST['url']
    t = TruTVIE(TruTVIE._TEST['url'])
    assert t._VALID_URL == TruTVIE._TEST['url']


# Generated at 2022-06-12 18:28:03.568715
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Set non-default argument values
    test_obj = TruTVIE('test')
    # assert
    assert test_obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-12 18:28:09.885165
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-12 18:28:12.476465
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE(None)
    except TypeError as e:
        assert "argument 1 must be an instance of an" in str(e)
    else:
        raise AssertionError("Failure")


# Generated at 2022-06-12 18:28:22.592891
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for TruTVIE
    # Timestamp for testing
    timestamp = '2018-05-22T09:00:00.000-07:00'
    # Episode data for testing
    episode = {'seasonNum': 1, 'episodeNum': 2, 'showTitle': 'Test Show', 'publicationDate': timestamp, 'title': 'Test Title', 'description': 'Hi, I am testing', 'mediaId': '123456789'}
    # Clip data for testing
    clip = {'title': 'Test Title', 'showTitle': 'Test Show', 'publicationDate': timestamp, 'description': 'Hi, I am testing', 'mediaId': '123456789'}
    # Images data for testing

# Generated at 2022-06-12 18:28:24.283407
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_TruTVIE = TruTVIE(None, {}, {})
    assert class_TruTVIE is not None

# Generated at 2022-06-12 18:28:31.083684
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Following test cases are for verifying TruTVIE
    # 1. tv name and url are both legal
    url1 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    trutv.suitable(url1)
    # 2. url is legal but tv name is illegal
    url2 = 'https://www.trutv.com/shows/carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv.suitable(url2)


# Generated at 2022-06-12 18:28:35.957565
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test constructor of class TruTVIE"""
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert ie.IE_DESC == 'TruTV Videos'
    assert ie._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-12 18:28:36.539239
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:38.355496
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)._extract_ngtv_info(None,None,None)

# Generated at 2022-06-12 18:28:44.337814
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv is not None


# Generated at 2022-06-12 18:28:47.669146
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_json('https://api.trutv.com/v2/web/episode/the-carbonaro-effect/2788400', '2788400')

# Generated at 2022-06-12 18:28:48.850965
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("\nTesting TruTVIE ...\n")
    assert True



# Generated at 2022-06-12 18:28:53.128355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    t.ie_key = 'TruTV'
    t.turner_api_key = 'A' * 5
    t.api_id = t.turner_api_key
    t.rights_key = 'A' * 36

# Generated at 2022-06-12 18:28:54.981245
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Creating object of class TruTVIE")
    test = TruTVIE()
    print("Object of TruTVIE created")
    return


# Generated at 2022-06-12 18:28:56.100940
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Assume that object construction always succeeds
    video = TruTVIE()
    return video

# Generated at 2022-06-12 18:28:58.076613
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-12 18:29:07.772438
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url = 'https://www.trutv.com/full-episodes/12693/carbonaro-effect-S2-episode-1.html'
    # url = 'https://www.trutv.com/full-episodes/12630/carbonaro-effect-S2-episode-6.html'
    # url = 'https://www.trutv.com/shows/carbonaro-effect/videos/stolen-art.html'
    # url = 'https://api.trutv.com/v2/web/episode/the-carbonaro-effect/12693'
    # url = 'https://api.trutv.com/v2/web/episode/the

# Generated at 2022-06-12 18:29:11.129910
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Asserts that the constructor of class TruTVIE is working properly
    ttvie = TruTVIE()
    assert ttvie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ttvie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:29:12.169375
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    print(x)


# Generated at 2022-06-12 18:29:25.206297
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE(None, 'mock_url')
    assert m.get_url() == 'mock_url'

# Generated at 2022-06-12 18:29:25.585686
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:28.774335
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/full-episodes/american-hoggers/videos/american-hoggers-4201.html')

# Generated at 2022-06-12 18:29:37.968003
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_turner import turner_test

# Generated at 2022-06-12 18:29:39.151440
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    ttv.TruTVIE()

# Generated at 2022-06-12 18:29:39.689908
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:46.802743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test the constructor
    def run_test(url):
        try:
            TruTVIE._real_extract(TruTVIE(), url)
        except:
            print("\nFailed at url: ", url)
            return False
        return True

    # Test with an url
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert (run_test(url) is True), "\nFailed at url: " + url

    # Test with a few urls from different shows

# Generated at 2022-06-12 18:29:48.562690
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:50.232676
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._VALID_URL == True

# Generated at 2022-06-12 18:29:50.832838
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:04.243447
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-12 18:30:05.119585
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("", "")

# Generated at 2022-06-12 18:30:10.282725
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.class_name == 'TruTVIE'
    assert ie.class_type == 'trutv'
    assert ie.class_slug == 'trutv'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-12 18:30:20.123776
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Simulate TruTVIE object
    trutv = TruTVIE()
    # Simulate two valid TruTV urls
    assert(trutv._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(re.match(trutv._VALID_URL, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') != None)

# Generated at 2022-06-12 18:30:26.818373
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:30:32.694522
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of class TruTVIE
    trutv = TruTVIE()
    # Check if URL is valid, assert true or false
    assert('(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))' in trutv._VALID_URL) is True
    # Check if info_dict has key and value, assert true or false
    assert(trutv._TEST.get('info_dict').__contains__('id')) is True
    # Check if info_dict has key and value, assert true or false
    assert(trutv._TEST.get('info_dict').__contains__('ext')) is True
    # Check if info

# Generated at 2022-06-12 18:30:34.316648
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE();
    assert ttv.title() == 'TruTVIE'


# Generated at 2022-06-12 18:30:42.916686
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_result = ie.extract(test_url)
    assert test_result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert test_result['title'] == 'Sunlight-Activated Flower'
    assert test_result['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert test_result['series'] == 'The Carbonaro Effect'
    assert test_result['season_number'] == 4
    assert test_result['episode_number'] == 1

# Generated at 2022-06-12 18:30:43.517969
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:44.111721
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:09.664546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    obj = TruTVIE()
    try:
        obj.extract(url)
    except Exception as ex:
        print('Error: ' + str(ex))
        assert(False)

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-12 18:31:10.238733
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:17.188197
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    ie._download_json = lambda i, j: {'episode': {'mediaId': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'}}

    ie._extract_ngtv_info = lambda i, j, k: {'id': i}
    video = ie.extract(url)
    assert video.get('id') == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-12 18:31:25.641962
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:31:35.474878
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    assert truTV._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:31:36.902125
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj=TruTVIE()


# Generated at 2022-06-12 18:31:43.228793
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Simple test case to verify that the constructor of class TruTVIE
    is not broken and gives correct values
    """
    trutv_ie = TruTVIE()
    trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')



# Generated at 2022-06-12 18:31:43.880559
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:31:45.531188
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:31:47.443610
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE(TurnerBaseIE())
    assert type(trutv) == TruTVIE

test_TruTVIE()

# Generated at 2022-06-12 18:32:29.424136
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().extract('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE().extract('https://www.trutv.com/full-episodes/73413/the-carbonaro-effect-episode-201/videos/sunlight-activated-flower.html')

# Generated at 2022-06-12 18:32:39.513272
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE.ie_key() == 'trutv'
    assert TruTVIE.TESTS[0]['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE.TESTS[0]['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert TruTVIE.TESTS[0]['info_dict']['ext'] == 'mp4'
    assert TruTVIE.TESTS[0]['info_dict']['title'] == 'Sunlight-Activated Flower'
    assert TruTVIE.T

# Generated at 2022-06-12 18:32:42.134341
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    globals()['TruTVIE'] = TruTVIE
    globals()['re'].match = re.match
    fixture = sys.modules['__main__'].test_TruTVIE
    ies = construct_IE(globals(), 'TruTVIE', fixture['url'])
    assert isinstance(ies, TruTVIE)



# Generated at 2022-06-12 18:32:48.617122
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import re

    # Test for TruTVIE._TEST
    obj = TruTVIE()
    test = obj._TEST
    assert test['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert test['info_dict'] == {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower."
    }
    assert test['params'] == {'skip_download': True}

    # Test for TruTVIE._VALID_URL

# Generated at 2022-06-12 18:32:54.010779
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:32:57.142049
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test link is trutv.com
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    o = TruTVIE(url)
    # Verify the object is a TruTVIE object
    assert(isinstance(o, TruTVIE))

# Generated at 2022-06-12 18:32:58.579284
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:33:00.093018
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = 'import unittest; t = unittest.TestCase("__init__"); t.assertEqual(1, 1)'
    exec(t)


# Generated at 2022-06-12 18:33:04.910038
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    response = ie._real_extract(url)
    assert response['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-12 18:33:05.766355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-12 18:34:47.416231
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:34:57.523338
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv_ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-12 18:34:58.034195
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:35:05.833665
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# def test_get_series_slug():
#     expected = 'the-carbonaro-effect'
#     actual = TruTVIE._get_series_slug.__func__('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
#     assert actual == expected

# def test_get_clip_slug():
#     expected = 'sunlight-activated-

# Generated at 2022-06-12 18:35:06.583532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:35:11.495581
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Example usage of extractor
# i = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
# i.download_info

# Get information about the video
# i.get_info()

# Generated at 2022-06-12 18:35:18.364456
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	from __main__ import TruTVIE
	truTVIE = TruTVIE(None)
	test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	_VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:35:22.460497
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

    assert str(trutv) == "<TruTVIE(https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html)>"


# Generated at 2022-06-12 18:35:30.644898
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:35:37.161103
# Unit test for constructor of class TruTVIE