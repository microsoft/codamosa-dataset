

# Generated at 2022-06-12 18:27:59.426088
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    trutv_instance = TruTVIE()

    assert isinstance(trutv_instance, TurnerBaseIE)

# Generated at 2022-06-12 18:28:10.490732
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv_ie.suitable('https://www.trutv.com/full-episodes/158879/jokers-wild-season-1-episode-1-jokers-wild/videos/episode-1-jokers-wild.html') is False
    assert trutv_ie.suitable('https://www.trutv.com/full-episodes/158879/jokers-wild-season-1-episode-1-jokers-wild/videos/episode-1-jokers-wild-') is False

# Generated at 2022-06-12 18:28:17.659110
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.ie_key() == 'trutv'
    assert t.ie_name() == 'truTV'
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    

# Generated at 2022-06-12 18:28:27.596599
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:28:28.546383
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-12 18:28:29.110134
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:35.150943
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from ..utils import (
        compat_urllib_request,
        compat_urllib_error,
        compat_http_client,
    )
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    opener = compat_urllib_request.build_opener(compat_urllib_request.HTTPCookieProcessor())
    request = compat_urllib_request.Request(url)
    request.add_header('User-Agent', 'Mozilla/5.0')

# Generated at 2022-06-12 18:28:35.761394
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:41.787991
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor
    assert TruTVIE(None)._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-12 18:28:42.371872
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:28:53.533519
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global TruTVIE
    TruTVIE()

# Generated at 2022-06-12 18:28:55.404845
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTV = TruTVIE()
	print(truTV.extract_t_and_s())

test_TruTVIE()

# Generated at 2022-06-12 18:28:56.300864
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE != None
    

# Generated at 2022-06-12 18:28:59.325860
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    http_mock = TruTVIE()
    assert http_mock.http_request("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")


# Generated at 2022-06-12 18:29:01.876519
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	tru_tv = TruTVIE()
	assert(isinstance(tru_tv, TruTVIE) )



# Generated at 2022-06-12 18:29:10.090739
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # note: url, content and test_cases are tuples
    url = ("https://www.trutv.com/shows/impractical-jokers/videos/special-delivery.html",
          "https://www.trutv.com/shows/full-episodes/129881/impractical-jokers-special-delivery/videos.html",
          "https://www.trutv.com/shows/full-episodes/129881/impractical-jokers-special-delivery.html",
          "https://www.trutv.com/shows/full-episodes/129881/impractical-jokers-special-delivery/videos/a-wedding-with-no-wine.html")
    content = (None, None, None, None)

# Generated at 2022-06-12 18:29:10.817988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    return

# Generated at 2022-06-12 18:29:11.296229
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:29:16.167512
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # assert TruTVIE()._TEST['url'] == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    try:
        video = TruTVIE()._TEST['url']
        assert isinstance(video, str)
    except:
        print("Error importing TruTVIE.")
        return False
    return True

if __name__ == '__main__':
    import sys
    import pytest
    if not pytest.main([sys.argv[0]]):
        from IPython import embed
        embed()

# Generated at 2022-06-12 18:29:21.321331
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE,
    which returns an object of class TruTVIE if the given url points
    to a webpage containing valid information.
    """
    try:
        TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-12 18:29:35.696940
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ####################################################################################################
    # Test TruTVIE class constructor with different valid and invalid input
    ####################################################################################################
    # Test TruTVIE class constructor with valid input
    TruTVIE(TurnerBaseIE())
    # Test TruTVIE class constructor with invalid input
    # TruTVIE(None)

# Generated at 2022-06-12 18:29:43.813931
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE
    tIE = TruTVIE;
    tIE.className = "TruTVIE";
    tIE.__init__();
    assert tIE.className == "TruTVIE";
    assert tIE.name == "trutv";
    assert tIE.ie_key() == "trutv";
    assert tIE.info_dict['id'] == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1";
    assert tIE.info_dict['ext'] == "mp4";
    assert tIE.info_dict['title'] == "Sunlight-Activated Flower";
    assert tIE.info_dict['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower.";
    assert tIE.params

# Generated at 2022-06-12 18:29:50.477548
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # if the test fails, we will have an error message telling us that there is no such file called test_turner.py
    import os
    import sys
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    sys.path.append('..')
    # instantiate an object of the TruTVIE class, 'ie' represents "info extractor"
    ie = TruTVIE()
    # the test youtube url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # we call the _real_extract() method of TruTVIE class
    result = ie._real_extract(url)
    # print the information about the video
    print('video info = ' + str(result))

# Generated at 2022-06-12 18:29:52.477014
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    print(test_TruTVIE);

# Generated at 2022-06-12 18:29:54.446934
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        assert False
    else:
        assert True


# Generated at 2022-06-12 18:29:55.924566
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()

# Generated at 2022-06-12 18:30:00.330201
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-12 18:30:01.109922
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:05.421026
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE object and test the name
    try:
        video = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
        print(video.name);
    except Error as err:
        print(err.args)

# Generated at 2022-06-12 18:30:06.091585
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-12 18:30:27.175796
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:29.867976
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import utils
    # create an instance of TruTVIE class
    utils.test_class(TruTVIE)

# Generated at 2022-06-12 18:30:31.774417
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.ie_key() == 'trutv'
    assert TruTVIE.ie_key() == 'trutv'


# Generated at 2022-06-12 18:30:37.313686
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-12 18:30:38.435149
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    assert test


# Generated at 2022-06-12 18:30:40.565486
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html');

# Generated at 2022-06-12 18:30:46.767666
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test that the parameter url has setted up correctly
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test that the function _real_extract is called
    assert TruTVIE._TEST.get('url') != None
    assert TruTVIE._TEST.get('info_dict') != None
    assert TruTVIE._TEST.get('params') != None
    # Test that the variable id has setted up correctly

# Generated at 2022-06-12 18:30:47.389508
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:48.044316
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-12 18:30:49.028948
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TruTVIE.dict())

# Generated at 2022-06-12 18:31:35.230260
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        assert False, e


# Generated at 2022-06-12 18:31:37.992367
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie is not None


# Generated at 2022-06-12 18:31:46.830538
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE().suitable(url) is True
    assert TruTVIE()._type() is None
    assert TruTVIE()._TEMPLATE_URL(url) == 'http://www.trutv.com/full-episodes/{0}/index.html'
    assert TruTVIE()._VALID_URL.findall(url)[0] == ('the-carbonaro-effect', 'sunlight-activated-flower', None)

    # Test for TruTVIE constructor
    assert TruTVIE(TruTVIE())._type() == 'video'

# Generated at 2022-06-12 18:31:48.000963
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    testResult = TruTVIE()
    assert testResult is not None


# Generated at 2022-06-12 18:31:55.570613
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE(TurnerBaseIE._WORKER_POOL)
    assert isinstance(obj, TruTVIE)
    assert isinstance(obj, TurnerBaseIE)
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:31:56.900414
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TODO: test it
    TruTVIE(None)

# Generated at 2022-06-12 18:31:58.371030
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == "TruTVIE"

# Generated at 2022-06-12 18:32:10.029397
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    t._extract_ngtv_info('8a1e3477-a0e0-49b7-912c-e', {}, {})
#
# require "spec_helper"
#
# describe TruTVIE do
#   describe "#extract" do
#     context "with a clip URL" do
#       before do
#         @clip = TruTVIE.new
#         allow(@clip).to receive(:_get_video_json) { {
#           "episode" => {
#             "mediaId" => "8a1e3477-a0e0-49b7-912c-e",
#             "isAuthRequired" => true,
#             "title" => "Sunlight-Activated Flower",
#             "description" => "A customer is stunned

# Generated at 2022-06-12 18:32:14.671743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:32:15.330466
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE is not None

# Generated at 2022-06-12 18:34:10.390474
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE is not None)

# Generated at 2022-06-12 18:34:11.254390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()

# Generated at 2022-06-12 18:34:12.646682
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test basic properties of constructor
    TruTVIE()
    assert(True)

# Generated at 2022-06-12 18:34:19.538348
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert ie.IE_DESC == 'truTV'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-12 18:34:29.480375
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    This test is to make sure that the class is created with the right parameters.
    It tests the __init__ constructor of the class.

    """
    #Arrange
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    #Act
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    #Assert

# Generated at 2022-06-12 18:34:32.569620
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #create class object
    trutv = TruTVIE()
    # call real_extract() method of class TruTVIE
    trutv._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# test call
test_TruTVIE()

# Generated at 2022-06-12 18:34:35.628854
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        video = TruTVIE()
        video()
        print('Unit test for TruTVIE constructor is passed')
    except:
        print('Unit test for TruTVIE constructor is failed')


# Generated at 2022-06-12 18:34:37.014368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert False
    assert True

# Generated at 2022-06-12 18:34:38.371010
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global TruTVIE
    TruTVIE(None,url="http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-12 18:34:39.734925
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    assert True # test passed