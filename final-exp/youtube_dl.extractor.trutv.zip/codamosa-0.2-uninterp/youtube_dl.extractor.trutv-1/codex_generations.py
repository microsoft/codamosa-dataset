

# Generated at 2022-06-18 14:55:48.347432
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:49.852541
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-18 14:55:50.461377
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:51.012630
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:51.684748
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:52.206480
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:52.731312
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:53.525463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE
    TruTVIE()

# Generated at 2022-06-18 14:55:54.108276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:54.623070
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:05.014670
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:11.749860
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST
    assert TruTVIE()._download_json == TruTVIE._download_json
    assert TruTVIE()._extract_ngtv_info == TruTVIE._extract_ngtv_info
    assert TruTVIE()._real_extract == TruTVIE._real_extract

# Generated at 2022-06-18 14:56:12.253122
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:13.151497
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:13.731422
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:14.235266
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:14.745225
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:15.297743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:16.130618
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    TruTVIE()

# Generated at 2022-06-18 14:56:16.655858
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:37.461024
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:39.625852
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:40.190254
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:40.808068
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:41.366553
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:41.924896
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:42.537699
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:43.526361
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:44.041386
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:44.702948
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:31.006372
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST


# Generated at 2022-06-18 14:57:31.586676
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:32.102030
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:32.739725
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:33.263037
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:33.783248
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:34.300425
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:34.875902
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:35.313188
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE
    TruTVIE()

# Generated at 2022-06-18 14:57:35.833870
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:07.580056
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:08.614309
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:08.952185
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:18.693280
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-18 14:59:25.924870
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST
    assert TruTVIE()._download_json == TurnerBaseIE._download_json
    assert TruTVIE()._extract_ngtv_info == TurnerBaseIE._extract_ngtv_info
    assert TruTVIE()._real_extract == TruTVIE._real_extract
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST
    assert TruTVIE()._download_json == TurnerBaseIE._download_json
    assert TruTVIE()._extract_ngtv_info == TurnerBaseIE._extract_ngtv_info
    assert TruTVIE()._real_ext

# Generated at 2022-06-18 14:59:26.878218
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    TruTVIE()

# Generated at 2022-06-18 14:59:29.041118
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST


# Generated at 2022-06-18 14:59:29.464799
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:29.895865
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:31.608507
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE.__init__()
    # Test for TruTVIE.suitable()
    # Test for TruTVIE._real_extract()
    pass

# Generated at 2022-06-18 15:01:16.070353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:01:16.573500
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:01:17.038091
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:01:21.624879
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST
    assert TruTVIE()._download_json == TruTVIE._download_json
    assert TruTVIE()._extract_ngtv_info == TruTVIE._extract_ngtv_info
    assert TruTVIE()._real_extract == TruTVIE._real_extract

# Generated at 2022-06-18 15:01:22.102108
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:01:22.577753
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:01:23.088973
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:01:23.526880
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:01:24.040887
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:01:24.521336
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:05:10.369873
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:05:10.796017
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:05:11.194485
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:05:11.578006
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:05:11.986680
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:05:12.368916
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:05:12.751599
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:05:13.226026
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:05:13.613871
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:05:14.010347
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()