

# Generated at 2022-06-18 14:55:48.717949
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:49.449299
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:50.035136
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:50.599376
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:55:59.818281
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-18 14:56:00.301760
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:00.856739
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:01.717488
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    TruTVIE()

# Generated at 2022-06-18 14:56:02.794890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:03.359638
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:13.960357
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:14.469311
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:14.974819
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:15.495953
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:16.013475
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:16.535846
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:23.663003
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-18 14:56:24.118601
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:24.574742
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:25.473938
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    TruTVIE()

# Generated at 2022-06-18 14:56:35.552771
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:36.129899
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:39.936399
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE._real_extract
    TruTVIE()._real_extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE()._real_extract(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-18 14:56:40.894331
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    TruTVIE()

# Generated at 2022-06-18 14:56:41.448367
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:42.008541
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:42.578770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:43.673447
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:56:44.653207
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE
    TruTVIE()

# Generated at 2022-06-18 14:56:45.178157
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:08.472125
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:08.756272
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:09.034681
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:09.307746
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:09.710390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE
    TruTVIE()

# Generated at 2022-06-18 14:57:10.368522
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:16.595566
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-18 14:57:17.097346
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:17.558366
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:19.111445
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:58.691286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:59.223571
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:57:59.697700
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:58:00.155346
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:58:00.636894
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:58:01.116761
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:58:01.664036
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:58:02.108170
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:58:02.590495
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:58:04.516651
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    TruTVIE()

# Generated at 2022-06-18 14:59:35.576580
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:36.061278
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:36.559682
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:37.051264
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:38.333613
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:39.013808
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:39.483769
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:40.392894
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    TruTVIE()

# Generated at 2022-06-18 14:59:40.867254
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 14:59:41.895422
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    TruTVIE()


# Generated at 2022-06-18 15:03:10.673519
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:03:11.821826
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:03:12.340692
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:03:13.123720
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    TruTVIE()

# Generated at 2022-06-18 15:03:13.578121
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:03:14.025015
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:03:14.590100
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:03:23.371207
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for constructor of class TruTVIE
    # Test for TruTVIE._VALID_URL
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test for TruTVIE._TEST

# Generated at 2022-06-18 15:03:23.796752
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-18 15:03:24.200354
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()