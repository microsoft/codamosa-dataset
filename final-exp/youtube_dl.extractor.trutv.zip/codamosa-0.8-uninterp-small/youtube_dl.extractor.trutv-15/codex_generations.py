

# Generated at 2022-06-26 12:51:59.221323
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case_0()

# Generated at 2022-06-26 12:52:04.076742
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    tru_t_v_i_e.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-26 12:52:05.312336
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE() is not None)


# Generated at 2022-06-26 12:52:13.997364
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url_0 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    data_0 = tru_t_v_i_e_0.extract(url_0)
    assert data_0['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert data_0['title'] == 'Sunlight-Activated Flower'
    assert data_0['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert data_0['series'] == 'The Carbonaro Effect'

# Generated at 2022-06-26 12:52:18.438422
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE()
    assert trutvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))', "Constructor of TruTVIE class is invalid"

# Generated at 2022-06-26 12:52:30.390000
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_1 = TruTVIE()
    tru_t_v_i_e_2 = TruTVIE()
    assert tru_t_v_i_e_1._downloader is not None
    assert tru_t_v_i_e_1._VERSION is not None
    assert tru_t_v_i_e_2._downloader is not None
    assert tru_t_v_i_e_2._VERSION is not None
    assert tru_t_v_i_e_1._downloader == tru_t_v_i_e_2._downloader
    assert tru_t_v_i_e_1._VERSION == tru_t_v_i_e_2._VERSION

# Generated at 2022-06-26 12:52:37.109718
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    if not tru_t_v_i_e_0._extract_url(url):
        assert(False)
    tru_t_v_i_e_0._real_extract(url)
test_case_0()
test_TruTVIE()

# Generated at 2022-06-26 12:52:43.231443
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test1 = TruTVIE()
    test2 = TruTVIE()
    assert TruTVIE == type(test1)
    assert TruTVIE == type(test2)
    assert test1._VALID_URL == test2._VALID_URL


# Generated at 2022-06-26 12:52:45.732463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Constructor")
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:52:49.877442
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  tru_t_v_i_e_0 = TruTVIE()
  tru_t_v_i_e_1 = TruTVIE()


# Generated at 2022-06-26 12:52:56.538294
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # NEED_IMPL: construct test code
    assert False, 'Unimplimented test case for constructor of class TruTVIE.'


# Generated at 2022-06-26 12:53:00.968843
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    arg0 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    tru_t_v_i_e = TruTVIE(arg0)

# Generated at 2022-06-26 12:53:10.480136
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t_t_v_i_e = TruTVIE()
    assert(t_t_v_i_e.turner_key == 'Tru-TV')
    assert(t_t_v_i_e.turner_channel == 'truTV')
    assert(t_t_v_i_e.turner_channel_id == 'e18e7b96d1fc48a8a2b67f83a1a18a65')
    assert(t_t_v_i_e.turner_url == 'https://api.trutv.com/v1.4/')
    assert(t_t_v_i_e.turner_package_name == 'com.turner.trutv')

# Generated at 2022-06-26 12:53:11.605570
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()


# Generated at 2022-06-26 12:53:16.061427
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:18.516524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()


# Generated at 2022-06-26 12:53:20.446691
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:53:21.754307
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    assert tru_t_v_i_e.name() == 'TruTV'


# Generated at 2022-06-26 12:53:24.781001
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()

"""
import sys
sys.exit(test_TruTVIE())
"""

# Generated at 2022-06-26 12:53:31.365218
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case 0
    # Test with url from TruTV website
    try:
        tru_t_v_i_e_0 = TruTVIE()
        # Test for constructor
        assert tru_t_v_i_e_0 is not None
    except Exception as e:
        print(e)



# Generated at 2022-06-26 12:53:48.564586
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    result = ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert result == True, 'test_TruTVIE assert #1 has failed!'
    result = ie.suitable('https://www.trutv.com/shows/jokers-wild/videos/1930258/jokers-wild---baby-on-board.html')
    assert result == True, 'test_TruTVIE assert #2 has failed!'
    result = ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower')
    assert result == True, 'test_TruTVIE assert #3 has failed!'

# Generated at 2022-06-26 12:53:59.077174
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# First test
	url1 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	test1 = TruTVIE().suitable(url1)
	assert test1 == True
	# Second test
	url2 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower'
	test2 = TruTVIE().suitable(url2)
	assert test2 == True
	# Third test
	url3 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/'
	test3 = TruTVIE().suitable(url3)
	assert test3 == False

# Generated at 2022-06-26 12:53:59.802497
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._build_request()

# Generated at 2022-06-26 12:54:02.133169
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	trutv_ie = TruTVIE()
	assert trutv_ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:54:02.751073
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:07.173517
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case1: "http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    # Test case2: "http://www.trutv.com/shows/south_beach-tow/videos/238"
    assert TruTVIE(TruTVIE.test_video_id).test()

# Generated at 2022-06-26 12:54:18.612235
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert obj._TEST['url'] == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

# Generated at 2022-06-26 12:54:29.051003
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .truTV import TruTVIE
    from ..utils import (
        compat_urlparse,
        get_testcases_for_extractor,
    )
    ie = TruTVIE()
    ie_name = ie.IE_NAME
    result = get_testcases_for_extractor(ie_name)
    for test_case in result:
        url = test_case['url']
        query = compat_urlparse.urlparse(url).query
        title = test_case.get('title')
        test_case_res = ie.extract(url)
        # title
        if title:
            assert test_case_res.get('title') == title
        # query
        if query:
            query_dict = compat_urlparse.parse_qs(query)

# Generated at 2022-06-26 12:54:32.650201
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ test_TruTVIE.py: Testing TruTVIE constructor """
    tru_test = TruTVIE("test_path")
    tru_test.test_download()

# Generated at 2022-06-26 12:54:39.134335
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttv_ie = TruTVIE()
    assert ttv_ie._VALID_URL == TruTVIE._VALID_URL

    series_slug, clip_slug, video_id = re.match(TruTVIE._VALID_URL, url).groups()
    assert series_slug == 'the-carbonaro-effect'
    assert clip_slug == 'sunlight-activated-flower'
    assert video_id == None

# Generated at 2022-06-26 12:54:51.732818
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.suitable('') == True

# Generated at 2022-06-26 12:54:56.761174
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:59.275235
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_turner import TurnerBaseIETestCase
    TruTVIE(TurnerBaseIETestCase(), {})

# Generated at 2022-06-26 12:55:06.301667
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    ############################################################################
    #                   $ python -m unittest tests.test_TruTVIE                #
    ############################################################################

    from __main__ import TruTVIE
    
    from .test_TurnerBaseIE import test_TurnerBaseIE
    
    expected_results = [
        TruTVIE(),
    ]

    # test_TurnerBaseIE(cls, expected_results)
    test_TurnerBaseIE(TruTVIE, expected_results)

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-26 12:55:10.115235
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert False, 'Failed to instantiate TruTVIE'


# Generated at 2022-06-26 12:55:10.976275
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:18.244584
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    data = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            'skip_download': True,
        },
    }
    
    # Test case 1: url is valid and url is not

# Generated at 2022-06-26 12:55:28.861569
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE_inst = TruTVIE()
    assert TruTVIE_inst._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:55:30.288972
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception:
        # print("Exception encountered while creating TruTVIE object")
        return (False)
    return (True)


# Generated at 2022-06-26 12:55:32.069809
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-26 12:56:02.721927
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Initialization of TruTVIE
    trutv_ie_tester = TruTVIE()

    #Testing whether the initialization has been successful
    assert trutv_ie_tester.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv_ie_tester.suitable('https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/ep-001-part-1.html')


# Generated at 2022-06-26 12:56:04.263355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE({})
    # assert TruTVIE, add more info later...
    assert TruTVIE

# Generated at 2022-06-26 12:56:05.201470
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()


# Generated at 2022-06-26 12:56:15.288412
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  assert TruTVIE.__name__ == "TruTVIE"
  # Test valid URL
  test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
  assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:56:15.806524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:16.674771
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:56:21.953873
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test the constructor of class TruTVIE.
    """
    im = TruTVIE
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


test_TruTVIE()

# Generated at 2022-06-26 12:56:24.251215
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    print("TEST: url: %s" % ie.url)
    assert ie._TEST['url'] == ie.url

# Generated at 2022-06-26 12:56:33.395113
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    ie = TruTVIE()

    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    assert ie._VALID_URL == TruTVIE._VALID_URL, '_VALID_URL should match TruTVIE._VALID_URL'
    assert ie._TEST['url'] == TruTVIE._TEST['url'], '_TEST should match TruTVIE._TEST'

    # This is actually of class TurnerBaseIE
    assert ie._NETRC_MACHINE == 'turner', '_NETRC_MACHINE should match turner'

    assert ie._API_BASE == 'https://api.trutv.com', '_API_BASE should match https://api.trutv.com'

    assert ie._GEO_

# Generated at 2022-06-26 12:56:33.889071
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:57:28.957634
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:57:29.888591
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie = TruTVIE()

# Generated at 2022-06-26 12:57:30.565507
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('trutv')

# Generated at 2022-06-26 12:57:30.909827
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:57:31.430030
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:57:32.225458
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE...")
    TruTVIE()


# Generated at 2022-06-26 12:57:32.605265
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:57:36.215957
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    # test case to test constructor of class TruTVIE
    class TestTruTVIE(unittest.TestCase):
        # test case to test constructor of class TruTVIE
        # test method is run without any arguments
        def test_no_arguments(self):
            # create an instance of class TruTVIE
            inst = TruTVIE()
            # return True if the object is an instance of class TruTVIE
            return isinstance(inst, TruTVIE)

    # run all the unit tests in class TestTruTVIE
    unittest.main()

# Generated at 2022-06-26 12:57:36.749198
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:57:38.454753
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TruTVIE class is not a testable class
    # because it is a base class of other IE classes
    # so we need to use a dummy function to get a class object
    class_obj = TruTVIE(None)
    assert class_obj.ie_key() == 'trutv'

# Generated at 2022-06-26 12:59:22.699777
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global TruTVIE
    TruTVIE(_download_json, _extract_ngtv_info)

# Generated at 2022-06-26 12:59:24.494289
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# vim: ft=python ts=4 sw=4 sts=4 expandtab

# Generated at 2022-06-26 12:59:27.536643
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE.test_TruTVIE()['url']
    TruTVIE(True).extract(url)

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-26 12:59:28.995558
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert isinstance(ie, TruTVIE)


# Generated at 2022-06-26 12:59:30.168835
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    cls = TruTVIE()
    assert cls


# Generated at 2022-06-26 12:59:31.922754
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = TruTVIE()._VALID_URL
    result = TruTVIE().result(test_url)
    assert(result == True)

# Generated at 2022-06-26 12:59:33.684719
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # call TruTVIE class constructor
    TruTVIE()

# Generated at 2022-06-26 12:59:38.215538
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This is a test to check the constructor
    trutv_ie = TruTVIE()
    # If it is able to run this method without errors,
    # then it is correct
    trutv_ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:59:39.282977
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

test_TruTVIE()

# Generated at 2022-06-26 12:59:41.237703
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    obj = TruTVIE()
    assert obj is not None