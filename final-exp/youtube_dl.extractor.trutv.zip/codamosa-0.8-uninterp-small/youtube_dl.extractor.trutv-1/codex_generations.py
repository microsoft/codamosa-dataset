

# Generated at 2022-06-26 12:51:59.607804
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True



# Generated at 2022-06-26 12:52:05.141202
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert re.search(TruTVIE._VALID_URL, TruTVIE._TEST['url']) is not None
    assert TruTVIE._TEST['info_dict']['id'] == TruTVIE._TEST['info_dict']['title']
    assert TruTVIE._TEST['params']['skip_download'] is False

# Generated at 2022-06-26 12:52:07.544588
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    assert tru_t_v_i_e


# Generated at 2022-06-26 12:52:14.393039
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST == {'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'info_dict': {'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'ext': 'mp4', 'title': 'Sunlight-Activated Flower', 'description': "A customer is stunned when he sees Michael's sunlight-activated flower."}, 'params': {'skip_download': True}}

# Generated at 2022-06-26 12:52:15.306457
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE != None


# Generated at 2022-06-26 12:52:16.113686
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:52:19.588435
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_tv_i_e = TruTVIE()
    assert tru_tv_i_e



# Generated at 2022-06-26 12:52:24.091236
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL
    assert TruTVIE._TEST
    assert TruTVIE._download_json
    assert TruTVIE._extract_ngtv_info


# Generated at 2022-06-26 12:52:25.440256
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass # No need to check anything, as the constructor does nothing

# Generated at 2022-06-26 12:52:26.754658
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()

# Generated at 2022-06-26 12:52:32.949619
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()

# Generated at 2022-06-26 12:52:40.467175
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:46.417628
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Initialize TruTVIE object and call it's methods"""
    TruTVIE_object = TruTVIE()
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

# Generated at 2022-06-26 12:52:48.251470
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()

# Generated at 2022-06-26 12:52:53.450309
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Testing constructor of class TruTVIE extracts information from the url.
    """
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    IE = TruTVIE()
    result = IE._real_extract(url)
    assert result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert result['title'] == 'Sunlight-Activated Flower'
    assert result['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-26 12:53:05.824749
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    module = TruTVIE()
    assert(module._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-26 12:53:07.081613
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test TruTVIE.__init__()
    TruTVIE()

# Generated at 2022-06-26 12:53:07.622081
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:08.962199
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == "TruTVIE"


# Generated at 2022-06-26 12:53:10.954648
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:53:26.043718
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.ie_key() in ie_map
    assert TruTVIE.ie_key() in ie_gen
    ie = TruTVIE()
    assert ie.test()
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ie.suitable('https://www.trutv.com/full-episodes/1234')
    assert ie.suitable('https://www.trutv.com/full-episodes/1234/videos/1234')
    assert not ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/')

# Generated at 2022-06-26 12:53:38.545216
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    file_url = TruTVIE()
    assert TruTVIE._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-26 12:53:48.892028
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url = 'https://www.trutv.com/full-episodes/1661/the-carbonaro-effect-the-carbonaro-effect-the-carbonaro-effect-dine-and-dash-dater/index.html'
    ttv_ie = TruTVIE()
    assert ttv_ie

# Generated at 2022-06-26 12:53:51.859311
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TrutvIE()._real_extract(TruTVIE._TEST)
    return True

# Generated at 2022-06-26 12:53:52.740168
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-26 12:53:56.099112
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert (ie.ie_key() == 'trutv:')
    assert (ie.ie_key() in globals())

# Generated at 2022-06-26 12:54:07.561877
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE._TEST['url']
    _VALID_URL = TruTVIE._VALID_URL
    response = TruTVIE._download_webpage(url, None)
    assert TruTVIE._extract_url_result(response.url, url) == url
    match = re.match(_VALID_URL, url)
    assert match is not None
    (series_slug, clip_slug, video_id) = match.groups()
    assert series_slug == 'the-carbonaro-effect'
    assert clip_slug == 'sunlight-activated-flower'
    assert video_id is None

# Generated at 2022-06-26 12:54:17.786289
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .turner import TurnerBaseIE
    from .ngtv import NGTVIE

    import youtube_dl.extractor
    youtube_dl.extractor.InfoExtractor
    youtube_dl.extractor.InfoExtractor.check_url
    youtube_dl.extractor.InfoExtractor.suitable

    TruTVIE.__bases__[0].__bases__[0].__bases__[0] == youtube_dl.extractor.InfoExtractor
    TruTVIE.__bases__[0].__bases__[0].__bases__[1] == TurnerBaseIE
    TruTVIE.__bases__[0].__bases__[1] == NGTVIE

# Generated at 2022-06-26 12:54:19.460744
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-26 12:54:24.225206
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    e = TruTVIE()
    assert(t._VALID_URL == e._VALID_URL)
    assert(t._TEST == e._TEST)


# Generated at 2022-06-26 12:54:44.125929
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    ie.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-26 12:54:45.394156
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:57.227047
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
   assert TruTVIE().match("https://www.trutv.com/shows/full-episodes/how-to-be-a-g-m/episode-3.html") is True
   assert TruTVIE().match("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") is True
   assert TruTVIE().match("https://www.trutv.com/shows/full-episodes/how-to-be-a-g-m/3.html") is True
   assert TruTVIE().match("https://www.trutv.com/shows/full-episodes/how-to-be-a-g-m/3") is True

# Generated at 2022-06-26 12:54:58.639236
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    instance.suite()

# Generated at 2022-06-26 12:55:02.935062
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie_unit_test = TruTVIE('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-26 12:55:03.765865
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-26 12:55:14.294561
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# This automatically fetches all the unit tests present in this file
# and appends them to the global test suite
from ..test_utils import unittest_suite_from_module
suite = unittest_suite_from_module(__name__)

if __name__ == '__main__':
    # If called directly, this will run all the test associated with this file
    import sys
    from ..test_utils import TestRunner
    result = TestRunner().run(suite)
    sys.exit(not result.wasSuccessful())

# Generated at 2022-06-26 12:55:15.266110
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-26 12:55:26.123080
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:55:27.112115
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE()
    assert result is not None

# Generated at 2022-06-26 12:56:10.268508
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie != None


# Generated at 2022-06-26 12:56:13.114306
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    assert TruTVIE.__doc__.startswith('TruTV')


# Generated at 2022-06-26 12:56:13.653591
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:14.180225
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:16.217286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:56:18.027953
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert repr(ie).count('TurnerBaseIE') == 1
    assert repr(ie).count('TurnerIE') == 1

# Generated at 2022-06-26 12:56:19.097399
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None, None)



# Generated at 2022-06-26 12:56:19.609004
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:25.857325
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    try:
        obj = TruTVIE(url)
        print("TruTVIE(%s) passed." % url)
    except:
        print("TruTVIE(%s) test failed." % url)

# # Unit test for IE object's get_video() method
# def test_TruTVIE_get_video():
#     url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
#     try:
#         obj = TruTVIE(url)
#         video = obj.get_video()
#         print("%s get_video() passed." % url)
#     except

# Generated at 2022-06-26 12:56:26.848957
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #The test for TruTVIE is done in test_turner.py
    pass

# Generated at 2022-06-26 12:58:21.501518
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        raise

# Generated at 2022-06-26 12:58:23.128379
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	try:
		TruTVIE()
	except: return False
	return True


# Generated at 2022-06-26 12:58:35.076312
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor Test
    test_ie = TruTVIE()

    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == r'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-26 12:58:38.701163
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	try:
		TruTVIE()
	except:
		return False
	return True

# Generated at 2022-06-26 12:58:46.237314
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    ttv = TruTVIE()

    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:58:49.166621
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None


# Generated at 2022-06-26 12:58:50.011536
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:55.530530
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/bong-appetit/videos/dangerous-donuts.html'
    clip_info = TruTVIE()._real_extract(url)
    # media_id should be 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1' == clip_info['id'], "media id check failed!"
    return True


# Generated at 2022-06-26 12:58:56.437689
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:59.923180
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # use constructor of class TruTVIE
    t = TruTVIE()
    # run unit test of class TruTVIE
    t._run_test()
