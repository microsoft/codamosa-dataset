

# Generated at 2022-06-26 12:51:59.947296
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()
    assert tru_t_v_i_e_0 is not None


# Generated at 2022-06-26 12:52:11.370818
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:13.361134
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()
    assert(tru_t_v_i_e_0 is not None)

# Generated at 2022-06-26 12:52:20.463868
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._VALID_URL == re.compile(r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))') 
    assert TruTVIE._TEST['url'] == url

# Generated at 2022-06-26 12:52:22.736545
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()

# Generated at 2022-06-26 12:52:23.451029
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()

# Generated at 2022-06-26 12:52:35.845367
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    
    # Test case where we pass invalid video_id in URL as video-id
    invalid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Test case where we pass invalid video_id in URL as clip-id
    invalid_url = 'https://www.trutv.com/shows/tru-tv-top-funniest/videos/clip-trutv-top-funniest-best-of-puzzled-look.html'

    # Test case where we pass valid video_id in URL as video-id
    valid_url = 'https://www.trutv.com/shows/tru-tv-top-funniest/videos/episode-1-countdown-to-craziness.html'

    # Test

# Generated at 2022-06-26 12:52:37.676442
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case_0()
    pass

# Generated at 2022-06-26 12:52:42.150215
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Unit test for constructor of class TruTVIE')
    assert TruTVIE() != None

# Uncomment to run unit test
test_TruTVIE()

# Generated at 2022-06-26 12:52:44.101314
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'


# Generated at 2022-06-26 12:52:49.492715
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-26 12:52:50.755169
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE constructor
    """
    assert(TruTVIE.__name__ == "TruTVIE")

# Generated at 2022-06-26 12:52:51.169827
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:52:53.566995
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    test._download_json
    test._extract_ngtv_info

# Generated at 2022-06-26 12:53:04.028140
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Construct the argument
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Obtain an instance of the class
    trutvIE = TruTVIE()

    # Call the method
    info = trutvIE._real_extract(url)

    # Verify the result
    assert(info['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    assert(info['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower.")

# Generated at 2022-06-26 12:53:04.589281
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('trutv.com', {})

# Generated at 2022-06-26 12:53:16.086714
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tester = TruTVIE()
    assert tester._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'
    assert tester._TEST['url']== 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert tester._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-26 12:53:17.095293
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:17.923843
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:25.517675
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable(TruTVIE._VALID_URL)
    assert TruTVIE.suitable("https://www.trutv.com/shows/hacking-robotics/videos/hacking-robotics-episode-1.html")
    assert TruTVIE.suitable("https://www.trutv.com/shows/hacking-robotics/videos/hacking-robotics-episode-1.html")
    assert TruTVIE.suitable("https://www.trutv.com/shows/hacking-robotics/videos/hacking-robotics-episode-1.html")
    assert TruTVIE.suitable("https://www.trutv.com/shows/hacking-robotics/videos/hacking-robotics-episode-1.html")
    assert Tru

# Generated at 2022-06-26 12:53:35.290395
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:48.150378
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:58.609787
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Description: This function checks if TruTVIE class created with a valid url
    Parameters: None
    Returns: None
    """
    instance = TruTVIE()
    instance._VALID_URL = TruTVIE._VALID_URL
    instance._download_json = lambda *args, **kwargs: None
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    if not isinstance(instance, TruTVIE):
        raise AssertionError("Failed to create TruTVIE instance")

    if not re.match(instance._VALID_URL, test_url):
        raise AssertionError("Invalid test url")

# Generated at 2022-06-26 12:54:05.613490
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE()
    assert ttvie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:17.549832
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_utils import run_testcases

    testcases = [{
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }]
    run_testcases(TruTVIE(), testcases)

# Generated at 2022-06-26 12:54:23.760598
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttv = TruTVIE()
    ttv.suitable(url)
    ttv.extract(url)

# Generated at 2022-06-26 12:54:28.872610
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize TruTVIE
    trutv = TruTVIE()

    # Initialize url
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

    # Check if TruTVIE's constructor is able to extract URL 
    assert TruTVIE._VALID_URL == trutv._VALID_URL
    assert TruTVIE._TEST["url"] == trutv._TEST["url"]
    
    

# Generated at 2022-06-26 12:54:32.044503
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.download('http://www.trutv.com/shows/nba/index.html')

# Generated at 2022-06-26 12:54:36.283531
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # create an instance of TruTVIE
    trutv_ie = TruTVIE()
    # check if TruTVIE is instance of TurnerBaseIE class
    assert isinstance(trutv_ie, TurnerBaseIE)
    # check if constructor has required parameters
    assert len(trutv_ie._TEST) > 0

# Generated at 2022-06-26 12:54:37.015479
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:06.246033
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create object TruTVIE with dummy url
    trutv = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Assert extraction of valid URL
    assert trutv._VALID_URL == 'https?://(?:www\\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Assert content of test

# Generated at 2022-06-26 12:55:15.054777
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    if __name__ == '__main__':
        test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
        result = TruTVIE()._real_extract(test_url)
        assert result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
        assert result['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-26 12:55:24.969737
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutvIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert trutvIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'


# Generated at 2022-06-26 12:55:28.383955
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    try:
        assert trutvIE.ie_key() == 'trutv'
    except AssertionError as e:
        raise AssertionError(e)

# Generated at 2022-06-26 12:55:36.178877
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:55:37.711447
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    # test for instance of class
    assert isinstance(ttv, TruTVIE)


# Generated at 2022-06-26 12:55:45.253551
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    function = TruTVIE()
    function._ALL_SITES
    function._CS_KEY
    function._DRM_SERVER
    function._SERVICE_PROVIDER
    function._SITE_NAME
    function._SITE_NAME_SUFFIX

    res = function._extract_video_id(function._TEST["url"])
    assert type(function._extract_video_id(function._TEST["url"])) == str
    assert isinstance(function._extract_video_id(function._TEST["url"]), str)
    assert function._extract_video_id(function._TEST["url"]) == function._TEST["info_dict"]["id"]


# Generated at 2022-06-26 12:55:46.285121
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert isinstance(TruTVIE(), TruTVIE)

# Generated at 2022-06-26 12:55:53.874472
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    print(ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
    print(ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
    print(ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
    print(ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))

# Generated at 2022-06-26 12:55:55.092280
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()
	

# Generated at 2022-06-26 12:56:44.809961
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

	test = TruTVIE._TEST
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	assert test['url'] == url
	assert test['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-26 12:56:45.094782
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:45.869694
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert True

# Generated at 2022-06-26 12:56:46.630323
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:51.541107
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor_object = TruTVIE()
    assert constructor_object.name == 'truTV'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:56:52.051087
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:58.164793
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    e = TruTVIE()

    # test if TruTVIE class is correctly initialized
    assert e.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert e.IE_NAME == 'trutv'
    assert e.turner_platform == 'ngtv'
    assert e.IE_DESC == 'truTV'
    assert e.VALID_URL == TruTVIE._VALID_URL
    assert e.turner_guid_prefix == 'T'


# Generated at 2022-06-26 12:57:06.739220
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize TruTVIE object using url
    TruTVIE(url, {})

    # Test url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url_test = TruTVIE._VALID_URL.match(url)
    assert url_test.groupdict()['series_slug'] == 'the-carbonaro-effect'
    assert url_test.groupdict()['clip_slug'] == 'sunlight-activated-flower'
    assert url_test.groupdict()['id'] is None

    # Test _extract_ngtv_info method
    response = requests.get(url)
    html = response.text

# Generated at 2022-06-26 12:57:07.710564
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Get access to the constructor method
	x = TruTVIE()

# Generated at 2022-06-26 12:57:15.860238
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert(obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    obj._real_extract(url)
    assert(obj.matchedURL==url)
    assert(obj.validURL==True)
    assert(obj.display_id == 'sunlight-activated-flower')

# Generated at 2022-06-26 12:59:02.326875
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-26 12:59:05.200069
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test the constructor of TruTVIE class."""
    ie = TruTVIE()
    assert ie is not None
    assert ie.name == 'trutv'
    assert ie.host == 'trutv.com'

# Generated at 2022-06-26 12:59:05.579701
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:59:06.153546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:59:06.984172
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie is not None

# Generated at 2022-06-26 12:59:07.803982
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None) is not None

# Generated at 2022-06-26 12:59:08.613635
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()

# Generated at 2022-06-26 12:59:10.385654
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:59:13.233980
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE.__init__, TruTVIE.extract()
    assert TruTVIE.__init__ is TurnerBaseIE.__init__
    assert TruTVIE.extract is TurnerBaseIE.extract

# Generated at 2022-06-26 12:59:16.468932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TurnerBaseIE(TurnerBaseIE._VALID_URL)
    b = TruTVIE(TruTVIE._VALID_URL)
    assert a
    assert b