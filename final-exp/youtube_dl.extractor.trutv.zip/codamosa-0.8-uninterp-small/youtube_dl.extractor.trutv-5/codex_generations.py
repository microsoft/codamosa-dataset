

# Generated at 2022-06-26 12:52:01.201514
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()

# Generated at 2022-06-26 12:52:12.323063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()
    assert tru_t_v_i_e_0._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:12.897493
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-26 12:52:14.218899
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)

# Generated at 2022-06-26 12:52:20.881670
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from tests.unit.extractor import assert_equal
    # Constructor of TruTVIE should assign value to _VALID_URL
    assert_equal(TruTVIE._VALID_URL, r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    # Constructor of TruTVIE should assign value to _TESTS
    assert_equal(TruTVIE._TEST['url'], 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:52:21.605261
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:52:23.587602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()


# Generated at 2022-06-26 12:52:24.450550
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:52:32.382074
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().url_result('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE().url_result('https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/episode-2-magician-to-the-stars.html')
    assert TruTVIE().url_result('https://www.trutv.com/shows/truTV-top-funniest/videos/truTV-top-funniest-episodes-13.html')
    assert TruTVIE().url_result('https://www.trutv.com/shows/truTV-top-funniest/episodes/season-2/episode-13.html')

# Generated at 2022-06-26 12:52:33.814574
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert tru_t_v_i_e_0

# Generated at 2022-06-26 12:52:49.344402
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:49.930726
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t is not None

# Generated at 2022-06-26 12:52:59.983520
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    import os
    env_config = {
        'ffmpeg_location': None,
        'ffprobe_location': None,
        'tmp_dir': None,
        'prefer_ffmpeg': True,
        'verbose': False,
        }
    TruTVIE(env_config)
    assert os.path.exists(env_config['tmp_dir'])
    assert os.path.exists(env_config['ffmpeg_location'])
    assert os.path.exists(env_config['ffprobe_location'])
    env_config['tmp_dir'] = '/tmp'
    TruTVIE(env_config)
    env_config['tmp_dir'] = '~/tmp'
    env_config['prefer_ffmpeg'] = False

# Generated at 2022-06-26 12:53:03.353725
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == TruTVIE._VALID_URL
    assert trutv._TEST == TruTVIE._TEST

# Generated at 2022-06-26 12:53:04.034001
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:15.602655
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #print "Testing constructor..."
    ie = TruTVIE()

    #print "Testing object properties..."
    assert ie.ie_key() == 'trutv'
    assert ie.ie_url() == 'http://www.trutv.com/'
    assert ie.video_webpage_url() == 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie.video_webpage_url_with_possible_qs() == 'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie.video_id() == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert ie

# Generated at 2022-06-26 12:53:19.865506
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:53:28.633473
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Create constructor object
    TruTVIE_object = TruTVIE(None)
    # Test URL regex
    new_url = TruTVIE_object._VALID_URL
    assert new_url == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test Test
    TruTVIE_object_test = TruTVIE_object._TEST

# Generated at 2022-06-26 12:53:39.468619
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:39.873459
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:50.836947
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:53.114123
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTV_video = TruTVIE()
    TruTV_video.test()

# Generated at 2022-06-26 12:54:01.771282
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Run test of TruTVIE constructor """
    # Note that this class is not supposed to be instantianated
    # directly, no need to test TruTVIE.__init__ or .suitable
    # Since .extract method is inherited from TurnerBaseIE,
    # no need to test it either.

# Generated at 2022-06-26 12:54:03.409352
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv != None

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-26 12:54:09.604810
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for _VALID_URL
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Test for _TEST

# Generated at 2022-06-26 12:54:15.591774
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    if (trutv != None):
        print("Unit test for TruTVIE passed!\n")
    else:
        print("Unit test for TruTVIE failed!\n")

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-26 12:54:27.831503
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:38.865116
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert obj._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert obj._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-26 12:54:39.749036
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None).test_url(TruTVIE._TEST['url'])

# Generated at 2022-06-26 12:54:50.292761
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    trutv_ie = TruTVIE()

    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:55:11.047946
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:15.123573
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    tru_tv_ie = TruTVIE(url)
    assert tru_tv_ie != None


# Generated at 2022-06-26 12:55:16.675184
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None)._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-26 12:55:17.802292
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'


# Generated at 2022-06-26 12:55:19.308338
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        error = e
    assert not error

# Generated at 2022-06-26 12:55:23.310920
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	#TruTVIE._real_extract(url)
	TruTVIE()._real_extract(url)

# Generated at 2022-06-26 12:55:24.422193
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor_test_for(TruTVIE)

# Generated at 2022-06-26 12:55:27.455482
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-26 12:55:34.936007
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # pylint: disable=protected-access
    url = 'https://www.trutv.com/shows/full-episodes/other/170102-001-001.html'
    assert TruTVIE._VALID_URL == TruTVIE.VALID_URL
    assert TruTVIE._TEST == TruTVIE.TEST
    assert TruTVIE._download_json == TruTVIE.download_json
    assert TruTVIE._extract_ngtv_info == TruTVIE.extract_ngtv_info
    assert TruTVIE._real_extract == TruTVIE.real_extract
    assert TruTVIE(TruTVIE.ie_key())._match_id(url) == '170102-001-001'

# Generated at 2022-06-26 12:55:35.511722
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:22.424885
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    This test might be useful in the future if something goes bad with the TruTVIE class
    """
    ie = TruTVIE()
    ie.download(TruTVIE._TEST['url'])


# Generated at 2022-06-26 12:56:22.849327
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:23.754201
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.working() == True

# Generated at 2022-06-26 12:56:25.610531
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE('test_truTV_IE')

# Generated at 2022-06-26 12:56:26.076970
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:28.149082
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE (trutv.com) IE
    test = TruTVIE()
    assert test.ie_key() == 'trutv'


# Generated at 2022-06-26 12:56:28.658400
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-26 12:56:35.745760
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case 1: A valid clip
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()._real_extract(url)

    # Test case 2: A valid episode
    url = 'https://www.trutv.com/full-episodes/14805/the-carbonaro-effect-ep-22/index.html'
    TruTVIE()._real_extract(url)

    # Test case 3: An invalid URL
    url = 'https://www.trutv.com'
    TruTVIE()._real_extract(url)

# Generated at 2022-06-26 12:56:44.782194
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Tests TruTVIE constructor using a known URL with a video
    trutv_ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Tests that TruTVIE._VALID_URL is set to the expected value
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Tests that TruTVIE._TEST is set to the expected value

# Generated at 2022-06-26 12:56:45.832823
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE("")
    assert obj is not None

# Generated at 2022-06-26 12:58:53.986387
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # The test is based on the test in turner.py
    if (TruTVIE == TurnerBaseIE):
        print("Testing TurnerBaseIE")
        assert TruTVIE._VALID_URL == TurnerBaseIE._VALID_URL
        assert TruTVIE._TEST == TurnerBaseIE._TEST
    else:
        print("Testing TruTVIE")
        assert TruTVIE._VALID_URL != TurnerBaseIE._VALID_URL
        assert TruTVIE._TEST != TurnerBaseIE._TEST
    return "Test passed"


# Generated at 2022-06-26 12:58:54.457430
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-26 12:58:55.458275
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TruTVIE")

# Generated at 2022-06-26 12:58:59.911282
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert re.match("^test_.*", obj.test()) is None

# Generated at 2022-06-26 12:59:06.792365
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:59:09.646196
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): TruTVIE(None)._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:59:10.901875
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE()
    assert isinstance(test_obj, TruTVIE)

# Generated at 2022-06-26 12:59:22.444240
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)
    # Make sure __init__ function runs correctly
    assert isinstance(instance.turner, TurnerBaseIE)
    # Make sure __init__ function runs correctly
    assert isinstance(instance.turner, TruTVIE)
    # Make sure __init__ function runs correctly
    assert isinstance(instance, TurnerBaseIE)
    # Test if this instance work correctly
    assert isinstance(instance._TEST, dict)
    assert 'url' in instance._TEST.keys()
    # Test if this instance work correctly
    assert isinstance(instance._VALID_URL, basestring)
    assert isinstance(instance._TEST, dict)
    assert 'url' in instance._TEST.keys()

# Generated at 2022-06-26 12:59:23.929222
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Constructor of TruTVIE
    assert TruTVIE is not None

# Generated at 2022-06-26 12:59:24.496891
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()