

# Generated at 2022-06-26 12:52:10.195631
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    input_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    input_url_2 = "https://www.trutv.com/full-episodes/335087/carbonaro-effect-episode-1.html"
    tru_t_v_i_e = TruTVIE()

# Generated at 2022-06-26 12:52:10.754995
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-26 12:52:12.071393
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:52:14.084283
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    assert tru_t_v_i_e is not None


# Generated at 2022-06-26 12:52:15.039544
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case_0()

# Generated at 2022-06-26 12:52:16.895228
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert test_case_0()

# Generated at 2022-06-26 12:52:19.372323
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:52:22.814578
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    tru_t_v_i_e_0 = TruTVIE()


# Generated at 2022-06-26 12:52:26.091712
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    assert tru_t_v_i_e is not None


# Generated at 2022-06-26 12:52:29.298599
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Assert that TruTVIE adheres to instance of TurnerBaseIE
    assert issubclass(TruTVIE, TurnerBaseIE)


# Generated at 2022-06-26 12:52:40.529063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass


# Generated at 2022-06-26 12:52:41.706018
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    tru_t_v_i_e.suite()


# Generated at 2022-06-26 12:52:45.345377
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    example_url = TruTVIE._TEST['url']
    assert TruTVIE._VALID_URL == re.match(TruTVIE._VALID_URL, example_url).groups()

# Generated at 2022-06-26 12:52:46.562141
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()



# Generated at 2022-06-26 12:52:49.029590
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()

# Generated at 2022-06-26 12:52:50.992488
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()



# Generated at 2022-06-26 12:52:52.338612
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
     AssertIsNotNone(TruTVIE)

# Generated at 2022-06-26 12:52:57.444163
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test the case where the TruTVIE is initialized with no paramaters
    assert(TruTVIE() is not None)

    # test the case where the TruTVIE is initialized with a URL paramter
    assert(TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is not None)

# Generated at 2022-06-26 12:53:05.243526
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert test_case_0()._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))', 'test failed'
    assert test_case_0().test() == 'test failed', 'test failed'

# Generated at 2022-06-26 12:53:07.175193
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE


# Generated at 2022-06-26 12:53:27.651977
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for _VALID_URL of class TruTVIE
    a = TruTVIE()
    assert a._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test for _TEST of class TruTVIE
    assert a._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Test for _real_extract of class TruTVIE

# Generated at 2022-06-26 12:53:28.676570
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:39.494600
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	print("Testing constructor for class TruTVIE")
	print("-------------------------------------\n")

	print("Testing \"\" as URL")
	try:
		TruTVIE("")
		print("Error in constructor for class TruTVIE")
	except:
		print("Constructor works correctly")
	print("\n")
	
	print("Testing \"https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html\" as URL")
	try:
		TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
		print("Constructor works correctly")
	except:
		print("Error in constructor for class TruTVIE")
	print("\n")
	


# Generated at 2022-06-26 12:53:40.124965
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:41.474042
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .trutv import TruTVIE
    ok_(TruTVIE)

# Generated at 2022-06-26 12:53:42.820147
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass


# Generated at 2022-06-26 12:53:44.792448
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    TruTVIE._download_json()

# Generated at 2022-06-26 12:53:46.379622
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.IE_NAME == 'truTV'

# Generated at 2022-06-26 12:53:58.609981
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_url = TruTVIE.extract_url("https://www.trutv.com/shows/hollywood-hitmen/videos/hollywood-hitmen-on-trutv.html")
    trutv_obj = TruTVIE(trutv_url)
    media_id = trutv_obj._download_json(trutv_obj._VALID_URL, trutv_obj.display_id)["episode"]["mediaId"]
    info = trutv_obj._download_json("https://api.trutv.com/v2/web/ngtv/video/%s" % media_id, media_id)
    assert len(info) == 2
    media_info = info["media"]
    cam_info = info["cam"]
    assert len(media_info) == 2

# Generated at 2022-06-26 12:54:05.612612
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'turner:trutv'
    assert ie.VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie.SHOW_SLUG == 'adultswim'
    assert isinstance(ie, TurnerBaseIE)
    test_pre_process = ie._pre_process('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:54:25.359077
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:37.188825
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-26 12:54:41.918864
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        trutv_ie = TruTVIE()
        assert trutv_ie.name == 'trutv'
        assert TruTVIE.ie_key() == 'trutv'
    except:
        assert False

# Generated at 2022-06-26 12:54:44.081075
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Test scenario for constructor of class TruTVIE
    #result should object 
    #and type of object should be TruTVIE
    TruTVIEobj = TruTVIE()
    if not isinstance(TruTVIEobj, TruTVIE):
        raise AssertionError('TruTVIE Class Constructor not working')


# Generated at 2022-06-26 12:54:45.833478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.SUCCEED

# Generated at 2022-06-26 12:54:47.809291
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:54:57.894540
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test_instance = TruTVIE()
	assert test_instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:59.274973
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    construct = TruTVIE()

# Generated at 2022-06-26 12:55:01.225836
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie


# Generated at 2022-06-26 12:55:02.085179
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:42.364005
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST

# Generated at 2022-06-26 12:55:51.446069
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing URL: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    trutv = TruTVIE()

    assert trutv._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert trutv._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert trutv._TEST['info_dict']['ext'] == 'mp4'
    assert trutv._TEST['info_dict']['title'] == 'Sunlight-Activated Flower'

# Generated at 2022-06-26 12:55:57.616557
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    data_url = 'https://api.trutv.com/v2/web/episode/carbonaro/f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    t = TruTVIE()
    title = t._download_json(data_url)['episode']['title'].strip()
    assert title == 'Sunlight-Activated Flower', "Title is wrong"

# Generated at 2022-06-26 12:55:58.187819
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:01.272832
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE()

    assert test_obj.int_or_none(3) is 3
    assert test_obj.int_or_none("3") is 3
    assert test_obj.int_or_none("Not a number") is None

# Generated at 2022-06-26 12:56:01.818090
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:09.338293
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    url = 'https://www.trutv.com/shows/full-episodes/hotel-impossible/videos/hotel-impossible-s-6-e-6-hotel-impossible.html'
    ie(url)
    url = 'https://www.trutv.com/shows/full-episodes/hotel-impossible/videos/hotel-impossible-s-6-e-6-hotel-impossible.html'
    ie(url)
    print("All unit tests for class TruTVIE passed!")

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-26 12:56:11.298086
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    print (ie)
    assert ie

# Generated at 2022-06-26 12:56:20.139952
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Basic test for constructor
    tru = TruTVIE()
    assert tru.IE_NAME == 'trutv'

    # Test regex
    valid_urls = [
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/349905-the-carbonaro-effect-dust-rabbit-explosion.html'
    ]
    for url in valid_urls:
        assert TruTVIE._VALID_URL.match(url)


# Generated at 2022-06-26 12:56:20.710921
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:14.767349
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:15.454595
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:24.989407
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-26 12:58:26.242637
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:58:28.986781
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE._VALID_URL
    c = TruTVIE(url)
    assert c.url == url

# Generated at 2022-06-26 12:58:32.710952
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
        Unit test for constructor of class TruTVIE
    """

    TruTVIE = TruTVIE()
    assert TruTVIE is not None

# Generated at 2022-06-26 12:58:35.129458
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj != None

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-26 12:58:38.224734
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert isinstance(t, TruTVIE)

# Generated at 2022-06-26 12:58:39.127730
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:40.612917
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()