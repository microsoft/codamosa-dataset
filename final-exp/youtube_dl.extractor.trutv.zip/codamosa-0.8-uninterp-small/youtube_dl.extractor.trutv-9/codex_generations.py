

# Generated at 2022-06-26 12:52:00.028784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # self._downloader = downloader
    # self._download_webpage = webpage_downloade

    test_case_0()

# Generated at 2022-06-26 12:52:11.459400
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    tru_t_v_i_e = TruTVIE()
    assert tru_t_v_i_e.suitable(url) == True
    assert tru_t_v_i_e._TEST['url'] == url
    assert tru_t_v_i_e._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert tru_t_v_i_e._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:52:12.025726
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return True



# Generated at 2022-06-26 12:52:12.585169
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-26 12:52:20.048320
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()
    assert tru_t_v_i_e_0._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:20.865596
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:52:21.403743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert trutvIE.TruTVIE()

# Generated at 2022-06-26 12:52:28.680841
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Get the class name of the initialized instance
    tru_t_v_i_e_0 = TruTVIE()
    print(type(tru_t_v_i_e_0).__name__)

    # Get the class name of the base class
    base_class_name = tru_t_v_i_e_0.__class__.__bases__[0].__name__
    print(base_class_name)

# test_case_0()


# Generated at 2022-06-26 12:52:29.579408
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-26 12:52:33.308261
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        tru_t_v_i_e_ = TruTVIE()
    except Exception as err:
        print(err)
        assert False


# Generated at 2022-06-26 12:52:39.096742
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert False
    assert True


# Generated at 2022-06-26 12:52:40.209301
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE
    obj = TruTVIE()

# Generated at 2022-06-26 12:52:41.058402
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:52:48.682429
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        assert TruTVIE()._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
        print("Success: Constructor of TruTVIE test is pass")
    except AssertionError as e:
        print("Error: Constructor of TruTVIE test is fail")


# Generated at 2022-06-26 12:52:57.053301
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:57.859663
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:52:59.789230
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-26 12:53:02.828208
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:53:03.956492
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("")

# Generated at 2022-06-26 12:53:06.968788
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.ie_key() == "trutv"
    assert ie.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-26 12:53:17.233696
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-26 12:53:19.575615
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    myTest = TruTVIE()

# Generated at 2022-06-26 12:53:23.978465
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.ie_key() == 'TruTV'

# Unit test that checks behaviour of TruTVIE constructor as well as TruTVIE.extract_id method

# Generated at 2022-06-26 12:53:26.214169
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Testing for constructor of class TruTVIE
    """
    obj_TruTVIE = TruTVIE()
    assert isinstance(obj_TruTVIE, TruTVIE)


# Generated at 2022-06-26 12:53:30.401133
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_turner import test_turner_base_ie
    test_turner_base_ie(TruTVIE)
    return



# Generated at 2022-06-26 12:53:31.513068
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:31.843321
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:41.005229
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test Constructor of TruTVIE
    ie = TruTVIE()

    # test with valid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie.suitable(url)

    # test with invalid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/'
    assert not ie.suitable(url)

    # test with invalid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/cottonmouthed.html'
    assert not ie.suitable(url)

    # test with valid url

# Generated at 2022-06-26 12:53:49.629063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE class - constructor
    truTVIE = TruTVIE('www.trutv.com/shows/carbonaro-effect/videos/sunlight-activated-flower.html', 'Test TruTVIE - constructor')
    assert truTVIE.name == 'trutv'
    assert truTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:52.663380
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 12:54:20.068881
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test an url which is a video url
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutv_ie = TruTVIE(url)
    assert trutv_ie._VALID_URL ==  r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:25.128353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # How to test TruTVIE?
    # 1. Write unit test here
    # 2. Create a file 'test_IE_extractors.py'.
    # 3. Put the following sentence 'from . import TruTVIE'
    TruTVIE()

# Generated at 2022-06-26 12:54:31.429961
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    trutv_ie._match_id(trutv_url)
    trutv_ie._download_webpage(trutv_url, None, None, None, None)
    trutv_ie._real_initialize(trutv_url)
    trutv_ie._download_json(
        "https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower", trutv_url)

# Generated at 2022-06-26 12:54:33.961672
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ie = TruTVIE()
	assert ie.__class__.__name__ == TruTVIE.__name__

# Generated at 2022-06-26 12:54:36.093739
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.download(ie._VALID_URL)  # no assert needed

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-26 12:54:39.149737
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:54:46.087087
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test for constructor of class TruTVIE
    """
    from .test import get_testcases
    testcase = get_testcases('TruTVIE')
    #0) Test for TruTVIE constructor with first testcase
    expected_output = "truTV"
    actual_output = testcase[0].ie.name
    assert expected_output == actual_output

    #1) Test for TruTVIE constructor with second testcase
    expected_output = "truTV"
    actual_output = testcase[1].ie.name
    assert expected_output == actual_output

# Generated at 2022-06-26 12:54:53.075868
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an object for testing
    trutv = TruTVIE()


# Generated at 2022-06-26 12:55:05.800127
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:55:08.937033
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE();
    assert isinstance(trutv, TruTVIE)

# Generated at 2022-06-26 12:55:50.882825
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-26 12:55:51.707568
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()

# Generated at 2022-06-26 12:55:52.337904
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:02.304119
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:56:02.840214
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:05.997424
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'


    # Define the TruTVIE class
    TruTVIE = TruTVIE(url, {})
    assert type(TruTVIE) == TruTVIE



# Generated at 2022-06-26 12:56:16.049169
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-26 12:56:19.017951
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert test_case is not None, "Test for constructor of class TruTVIE"

# Generated at 2022-06-26 12:56:20.444927
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test constructor of class TruTVIE."""
    obj = TruTVIE()
    assert obj != None

# Generated at 2022-06-26 12:56:21.858477
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")



# Generated at 2022-06-26 12:58:15.443289
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert ie.IE_DESC == 'Turner Broadcasting unspecified services'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST == ie.TEST



# Generated at 2022-06-26 12:58:17.971478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE().extract(TruTVIE()._TEST['url'])


# Generated at 2022-06-26 12:58:24.706620
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    webpage_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    TruTV_IE = TruTVIE()

    foo_Test_1 = TruTV_IE.suitable(webpage_url)
    foo_Test_2 = TruTV_IE.extract(webpage_url)
    foo_Test_3 = TruTV_IE.get_url(webpage_url)

    assert foo_Test_1 == True
    assert foo_Test_2 != None
    assert foo_Test_3 != None


# Generated at 2022-06-26 12:58:28.361820
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # This test is to make sure that the constructor works, but
    # there are no TruTV videos to test against.
    assert ie

# Generated at 2022-06-26 12:58:29.630387
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:36.450038
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE._VALID_URL
    valid_url = TruTVIE._VALID_URL
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert re.match(valid_url, TruTVIE._TEST['url']).group('series_slug') == 'the-carbonaro-effect'
    assert re.match(valid_url, TruTVIE._TEST['url']).group('clip_slug') == 'sunlight-activated-flower'
    assert re.match(valid_url, TruTVIE._TEST['url']).group('id') is None

# Generated at 2022-06-26 12:58:38.698900
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert isinstance(TruTVIE(),TurnerBaseIE)


# Generated at 2022-06-26 12:58:40.425972
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE."""
    TruTVIE()


# Generated at 2022-06-26 12:58:42.862847
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE constructor"""
    try:
        assert TruTVIE()
    except TypeError:
        assert TruTVIE()

# Generated at 2022-06-26 12:58:46.287061
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    print("TruTVIE object created successfully. This is a unit test")

# test_TruTVIE()