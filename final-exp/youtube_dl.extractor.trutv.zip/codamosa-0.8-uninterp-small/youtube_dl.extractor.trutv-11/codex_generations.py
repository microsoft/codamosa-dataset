

# Generated at 2022-06-26 12:51:59.947247
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case_0()

# Generated at 2022-06-26 12:52:00.796577
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True


# Generated at 2022-06-26 12:52:05.630557
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE();
    assert tru_t_v_i_e_0._VALID_URL
    assert tru_t_v_i_e_0._TEST
    assert tru_t_v_i_e_0._downloader


# Generated at 2022-06-26 12:52:06.543070
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case_0()

# Generated at 2022-06-26 12:52:08.206158
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:52:11.501286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # check if it is an instance of TruTVIE
    tru_t_v_i_e = TruTVIE()
    assert isinstance(tru_t_v_i_e, TruTVIE)


# Generated at 2022-06-26 12:52:12.074583
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-26 12:52:12.990568
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE



# Generated at 2022-06-26 12:52:14.310961
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()


# Generated at 2022-06-26 12:52:15.262335
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case_0()

# Generated at 2022-06-26 12:52:21.095889
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE

# Generated at 2022-06-26 12:52:22.465869
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create instance of class TruTVIE
    trutv_object = TruTVIE('http://cliphunter.com')
    # Assert create object
    assert (isinstance(trutv_object, TruTVIE))

# Generated at 2022-06-26 12:52:25.354169
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.ie_key() == 'truTV'
    assert ie.get_site_info() == {'site_name': 'truTV'}
    assert ie.AUTH_REQUIRED is True
    assert ie.get_page_data() == {}


# Generated at 2022-06-26 12:52:28.778945
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    item = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert item == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-26 12:52:35.707810
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    result = TruTVIE().suitable(url)
    assert result, 'Unit test for constructor of class TruTVIE has failed!'


# Generated at 2022-06-26 12:52:37.538344
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# TBD
	pass


# Generated at 2022-06-26 12:52:48.952789
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TrutvIE = TruTVIE()

    assert TruTVIE._TEST['url'] == url
    assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert TruTVIE._TEST['info_dict']['ext'] == 'mp4'
    assert TruTVIE._TEST['info_dict']['title'] == 'Sunlight-Activated Flower'
    assert TruTVIE._TEST['info_dict']['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert TruTVIE._T

# Generated at 2022-06-26 12:52:49.341324
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-26 12:52:50.838871
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t=TruTVIE()
    t._download_json("https://api.trutv.com/v2/web/episode/the-carbonaro-effect/7133366","")

# Generated at 2022-06-26 12:52:59.522468
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.ie_key() == 'trutv'
    assert trutv_ie.ie_name() == 'TruTV'
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:11.268457
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SUBCLASS == TruTVIE
    assert ie.IE_NAME == 'TruTV'

# Generated at 2022-06-26 12:53:14.048740
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check if the constructor creates object when correct inputs are given
    object_true = TruTVIE({})
    assert object_true
    # Check if the constructor throws exception when it is given empty keyword arguments and empty configuration
    TruTVIE({}, {})

# Generated at 2022-06-26 12:53:15.615550
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    assert(test_TruTVIE)

# Generated at 2022-06-26 12:53:16.694777
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-26 12:53:27.751855
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_object = TruTVIE()
    assert test_object._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:39.190156
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    parms = {
        '_type': 'url',
        'ie_key': 'TruTV',
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'display_id': 'sunlight-activated-flower',
        '_download_video': True,
        'include_ads': True,
        'test': False,
        'video_id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'player_url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    }
    trutv_ie = TruTVIE(**parms)

# Generated at 2022-06-26 12:53:39.598974
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:47.012528
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect").suitable("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html").suitable("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-26 12:53:58.974696
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Successfully initialize a TruTVIE() object
    ie = TruTVIE()
    assert hasattr(ie, '_TEST')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-26 12:53:59.704671
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('cnn')

# Generated at 2022-06-26 12:54:27.638257
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test that TruTVIE is an instance of TurnerBaseIE and that it's
    # created with the right arguments.
    try:
        TruTVIE()
    except TypeError as e:
        if e.args[0] == 'TurnerBaseIE requires exactly one argument':
            print('TruTVIE is an instance of TurnerBaseIE')
            print('TruTVIE is created with the right arguments')
    else:
        print('TruTVIE is not an instance of TurnerBaseIE')
        print('TruTVIE is not created with the right arguments')


# Generated at 2022-06-26 12:54:30.021743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTV = TruTVIE()
	assert type(truTV) == TruTVIE

# Generated at 2022-06-26 12:54:30.832649
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:32.179097
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_instance = TruTVIE()

# Generated at 2022-06-26 12:54:38.927370
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # creating object of class TruTVIE
    obj = TruTVIE()
    assert obj.__class__.__name__ == 'TruTVIE'
    # checking whether instance created is valid
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-26 12:54:39.990695
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        h1 = TruTVIE()
        print(h1)
    except:
        print("error")
    return 0


# Generated at 2022-06-26 12:54:40.780664
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:45.221977
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:49.998627
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        trutv = TruTVIE()
    except Exception as e:
        assert False, "TruTVIE() raised Exception: %s" % e
    assert trutv



# Generated at 2022-06-26 12:54:50.769929
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:37.966222
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Run a unit test for Retriever.
    """
    from .extractors import TruTVIE

    # Travis-CI test machine is not configured for the TruTV Site
    if 'travis' in os.environ:
        return

    # Create a dictionary for the TruTV Site
    testsite = TruTVIE()

    # Create a UnitTester for the TruTV Site
    test_runner = unittest.TextTestRunner(verbosity=2)

    # Create a list of tests
    tests = [
        unittest.TestLoader().loadTestsFromTestCase(testsite.TruTVSiteTest)
    ]

    # Execute the tests.
    # If all goes well, the site will be put in the list of sites supported by youtube-dl

# Generated at 2022-06-26 12:55:39.290227
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-26 12:55:40.542045
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .TruTVIE import TruTVIE
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)


# Generated at 2022-06-26 12:55:49.460877
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test an episode video
    TRUTVIE_EPISODE_TEST = TruTVIE()._TEST

    assert isinstance(TRUTVIE_EPISODE_TEST, dict)
    assert 'url' in TRUTVIE_EPISODE_TEST
    assert TRUTVIE_EPISODE_TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert 'info_dict' in TRUTVIE_EPISODE_TEST
    assert isinstance(TRUTVIE_EPISODE_TEST['info_dict'], dict)
    assert 'id' in TRUTVIE_EPISODE_TEST['info_dict']

# Generated at 2022-06-26 12:55:59.086561
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE.suitable(url)
    assert TruTVIE.IE_NAME == 'trutv:episode'

    url = 'https://www.trutv.com/full-episodes/lplb2g/inside-jokes-season-1-ep-108-tc-electronic/'
    assert TruTVIE.suitable(url)
    assert TruTVIE.IE_NAME == 'trutv:episode'

    url = 'https://www.trutv.com/full-episodes/lplb2g/inside-jokes-season-1-ep-108-tc-electronic/'
    assert TruTVIE.suitable(url)

# Generated at 2022-06-26 12:56:02.528751
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-26 12:56:03.900949
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE = TruTVIE('TruTVIE2')
    assert TruTVIE is not None

# Generated at 2022-06-26 12:56:05.522231
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert False, "An exception happened"

# Generated at 2022-06-26 12:56:08.842977
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test that constructor of class TruTVIE is working
    # without raising any errors
    try:
        TestClass = TruTVIE()
    except:
        raise AssertionError("Possible error in constructor of class TruTVIE")


# Generated at 2022-06-26 12:56:18.581752
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    IE= TruTVIE()

    assert(IE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-26 12:58:17.969948
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ## Testing TruTVIE.__init__
    ie = TruTVIE()
    ie == TruTVIE
    assert ie.ie_key() == 'trutv'
    assert ie.ie_key_id() == 'truTV'
    assert ie.ie_key_name() == 'truTV'
    assert ie.ie_key_description() == 'brings the fun with hilarious original shows.'

    ## Testing TruTVIE.ie_key
    ie = TruTVIE()
    ie == TruTVIE
    assert ie.ie_key() == 'trutv'

    ## Testing TruTVIE.ie_key_id
    ie = TruTVIE()
    ie == TruTVIE
    assert ie.ie_key_id() == 'truTV'

    ## Testing TruTVIE.ie_key_name

# Generated at 2022-06-26 12:58:24.344382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # URL of page containing information about individual video
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Instantiate TruTVIE class
    trutv = TruTVIE()
    # Call method defined in TruTVIE that extracts information about the video corresponding to the input URL
    info = trutv._real_extract(url)
    # Print video title to the screen
    print(info['title'])
    
test_TruTVIE()

# Generated at 2022-06-26 12:58:27.043731
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print(TruTVIE()._TEST)
    print(TruTVIE()._VALID_URL)


# Generated at 2022-06-26 12:58:36.387675
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # These assertions simply check that the TruTVIE instantiation does not
    # throw any errors. They are not intended to be strong tests of the IE
    assert ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-26 12:58:43.801528
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    test_TruTVIE.added_capsule = True


# Generated at 2022-06-26 12:58:54.932822
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-26 12:58:57.214249
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-26 12:58:58.758189
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:59:02.075275
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test top level function
    assert TruTVIE is not None
    # Test TruTVIE class constructor
    assert TruTVIE(None) is not None

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-26 12:59:10.495683
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create TruTVIE object
    TruTVIEObj = TruTVIE()

    # Confirm the value of TruTVIEObj._VALID_URL
    assert TruTVIEObj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Confirm the value of TruTVIEObj._TEST