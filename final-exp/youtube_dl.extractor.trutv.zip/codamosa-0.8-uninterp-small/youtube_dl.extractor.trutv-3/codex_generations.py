

# Generated at 2022-06-26 12:52:00.878360
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() != None


# Generated at 2022-06-26 12:52:12.022781
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("\n Unit Test for constructor of class TruTVIE")
    print("\n The TurnerBaseIE.embed_params is: ")
    print(tru_t_v_i_e_0.embed_params)
    print("\n The TurnerBaseIE.embed_query_key is: ")
    print(tru_t_v_i_e_0.embed_query_key)
    print("\n The TurnerBaseIE.embed_patterns is: ")
    print(tru_t_v_i_e_0.embed_patterns)
    print("\n The TurnerBaseIE.turner_base_path is: ")
    print(tru_t_v_i_e_0.turner_base_path)

# Generated at 2022-06-26 12:52:19.717954
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert getattr(TruTVIE, '_VALID_URL', None) == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:21.952884
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert tru_t_v_i_e_0


# Generated at 2022-06-26 12:52:22.467659
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True


# Generated at 2022-06-26 12:52:31.713897
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE()._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-26 12:52:33.095589
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert test_case_0() == "check ok"

# Generated at 2022-06-26 12:52:34.653789
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE


# Generated at 2022-06-26 12:52:35.946252
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:52:37.743505
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE)


# Generated at 2022-06-26 12:52:54.367936
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Constructor of TruTVIE
    """
    # Test with non standard URL

# Generated at 2022-06-26 12:52:55.774387
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TurnerBaseIE.turner_bucket[0] == TruTVIE

# Generated at 2022-06-26 12:52:56.796721
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    TruTVIE()

# Generated at 2022-06-26 12:53:01.875861
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .. import TruTVIE
    t = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert t._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-26 12:53:11.238935
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert(t.ie_key() ==  'trutv')
    assert(t.ie_key() != 'trutv_key')
    assert(t.name() == 'trutv')
    assert(t.name() != 'TruTV')
    assert(t.description() == 'TruTV')
    assert(t.description() != 'TruTV Description')
    assert(t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-26 12:53:13.494694
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().extract('https://www.trutv.com/shows/the-chris-gethard-show/videos/music-from-the-chris-get-hard-show.html')

# Generated at 2022-06-26 12:53:21.016437
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return

# Generated at 2022-06-26 12:53:21.852483
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:26.144342
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test_download_playlist_formats
    test_url = TruTVIE._TEST.get('url')
    ie = TruTVIE()
    assert TruTVIE._TEST == ie.suitable(test_url)
    assert TruTVIE._VALID_URL == ie._VALID_URL



# Generated at 2022-06-26 12:53:29.675371
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.constructor_name == "TruTVIE"

# Generated at 2022-06-26 12:53:45.512664
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of TruTVIE
    ie = TruTVIE()
    # Get the available options
    options = [o.dest for o in ie._opts]

    # Check the availability of options
    assert 'verbose' in options
    assert 'username' in options
    assert 'password' in options
    assert 'video_password' in options


# Generated at 2022-06-26 12:53:46.496287
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for the constructor of class TruTVIE
    assert TruTVIE

# Generated at 2022-06-26 12:53:50.304862
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE._TEST['url']
    obj = TruTVIE()
    result = obj._real_extract(url)
    print(result)

# Generated at 2022-06-26 12:53:54.470391
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:54:02.338714
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE()
    assert ttvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:05.328304
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.ie_key() == "TruTV"
    assert TruTVIE.ie_key() != "truTV"
    assert TruTVIE.ie_key() == "truTV".title()
    assert TruTVIE.ie_key() != "truTV".upper()
    assert TruTVIE.ie_key() != True

# Generated at 2022-06-26 12:54:12.622166
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .turner import _TEST_TURNER_APIKEY, _TEST_TURNER_SECRET
    assert TruTVIE(
        'http://www.trutv.com/full-episodes/some_series/some_id',
        _TEST_TURNER_APIKEY,
        _TEST_TURNER_SECRET
    )._downloader is not None

# Generated at 2022-06-26 12:54:13.604071
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:16.229633
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST


# Generated at 2022-06-26 12:54:16.925983
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:35.943792
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:54:46.135878
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from unit.test_downloader import FakeYDL
    from unit.helper import FakeDownloader
    ydl = FakeYDL()
    TruTVIE.ie_key = 'truTV'
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(ydl=ydl, downloader=FakeDownloader)._extract_urls(
        {
            'ie_key': 'truTV',
            'url': url,
            'playlist': True,
            'playliststart': 3,
            'playlistend': 4,
            'noplaylist': True,
            'noplaylist_skip_download': True,
        })
    assert TruTVIE.ie_key == 'truTV'

# Generated at 2022-06-26 12:54:50.369466
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	"""Unit test for TruTVIE"""
	truTVIE = TruTVIE()
	assert type(truTVIE).__name__ == "TruTVIE"

# Generated at 2022-06-26 12:54:57.711078
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', "Sunlight-Activated Flower", "A customer is stunned when he sees Michael's sunlight-activated flower.")
    assert TruTVIE('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', "Sunlight-Activated Flower")
    assert TruTVIE('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    assert TruTVIE(None, None, None)


# Generated at 2022-06-26 12:54:59.704997
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x=TruTVIE()

# Generated at 2022-06-26 12:55:01.157355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:55:01.947488
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:02.797050
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-26 12:55:03.690579
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-26 12:55:04.375079
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-26 12:55:52.988241
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import sys
    import unittest
    if sys.version_info.major == 2:
        from HTMLParser import HTMLParser
    else:
        from html.parser import HTMLParser

    html_parser = HTMLParser()
    valid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    invalid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html1'
    valid_video_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    invalid_video_id = '1234567890'

# Generated at 2022-06-26 12:55:53.500538
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:53.994320
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:54.846080
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:55.386615
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-26 12:55:56.575414
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:02.017721
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST.get('url') == TruTVIE._TEST.get('info_dict').get('url')
    assert TruTVIE._TEST.get('info_dict').get('id') == TruTVIE._TEST.get('params').get('id')
    assert TruTVIE._TEST.get('info_dict').get('title') == TruTVIE._TEST['params'].get('title')



# Generated at 2022-06-26 12:56:02.350782
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-26 12:56:02.706882
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:07.920277
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-26 12:57:51.747396
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:57:52.112547
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-26 12:58:04.085897
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE(url)
    
    print("Testing TruTVIE")
    print("Expected first part of title of TruTVIE video: 'Sunlight-Activated'")
    print("Actual first part of title of TruTVIE video: '%s'" % ie.get_title().split(" ")[0])
    if ie.get_title().split(" ")[0] == 'Sunlight-Activated':
        print("Test passed")
    else:
        print("Test failed")
    print("\n")
    
    print("Expected description of TruTVIE video: 'A customer is stunned when he sees Michael\'s sunlight-activated flower.'")

# Generated at 2022-06-26 12:58:08.650051
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE
    t._TEST = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-26 12:58:11.858953
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	print(TruTVIE.__name__)
	assert TruTVIE.__name__ == "TruTVIE"

# Generated at 2022-06-26 12:58:15.313639
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('<a href="https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html">hello</a>')
    # TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:58:24.951216
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:58:26.674688
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().extract(TruTVIE._TEST['url'])

# Generated at 2022-06-26 12:58:27.420845
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:36.509437
# Unit test for constructor of class TruTVIE