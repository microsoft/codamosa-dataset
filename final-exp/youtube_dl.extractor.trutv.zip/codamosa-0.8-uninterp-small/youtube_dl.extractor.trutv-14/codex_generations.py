

# Generated at 2022-06-26 12:52:00.877055
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE


# Generated at 2022-06-26 12:52:02.142332
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #TruTVIE_instance = TruTVIE()
    assert True


# Generated at 2022-06-26 12:52:05.226408
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    tru_t_v_i_e.suite()


# Generated at 2022-06-26 12:52:07.640875
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert test_case_0() == True # In video.pyx

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-26 12:52:09.850868
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._NETRC_MACHINE == 'trutv'


# Generated at 2022-06-26 12:52:16.076825
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()
    tru_t_v_i_e_0._extract_ngtv_info("media_id", {}, {"url": "url", "site_name": "truTV", "auth_required": False})
    tru_t_v_i_e_0._build_url("url")
    tru_t_v_i_e_0._real_extract("url", "or_series_slug", "or_video_id")


# Generated at 2022-06-26 12:52:19.009083
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_tv_ie_0 = TruTVIE()


# Generated at 2022-06-26 12:52:20.366825
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Case 0:
    test_case_0()

# Generated at 2022-06-26 12:52:23.803286
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-26 12:52:27.244145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


if __name__ == '__main__':
    test_case_0()
    test_TruTVIE()


# Generated at 2022-06-26 12:52:34.612872
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    get_test_cases(TruTVIE()._TEST, TruTVIE()._VALID_URL)


# Run test cases for TruTVIE
if __name__ == '__main__':
    test_all(__name__, [TruTVIE])

# Generated at 2022-06-26 12:52:35.911221
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    assert truTV



# Generated at 2022-06-26 12:52:47.498985
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.extract('https://www.trutv.com/shows/hacksaw-ridge/full-episodes/hacksaw-ridge-full-episode.html')
    ie.extract('https://www.trutv.com/shows/hacksaw-ridge/full-episodes/hacksaw-ridge-1287294')
    ie.extract('https://www.trutv.com/shows/hacksaw-ridge/full-episodes/hacksaw-ridge-1287294')

# Generated at 2022-06-26 12:52:48.394172
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This constructor is for testing the class TruTVIE only, which doesn't require internet access
    assert True

# Generated at 2022-06-26 12:52:59.018609
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-26 12:53:00.444351
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:01.904243
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE
    return TruTVIE

# Generated at 2022-06-26 12:53:03.045428
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:05.632352
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-26 12:53:08.498398
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	p = TruTVIE()
	assert p.__class__ == TruTVIE


# Generated at 2022-06-26 12:53:27.423139
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    series_slug = 'the-carbonaro-effect'
    clip_slug = 'sunlight-activated-flower'
    assert tru._VALID_URL == tru.ie._VALID_URL
    assert tru._TEST == tru.ie._TEST
    assert series_slug in tru._VALID_URL == tru.ie._VALID_URL
    assert clip_slug in tru._VALID_URL == tru.ie._VALID_URL
    assert clip_slug in tru._TEST == tru.ie._TEST


# Generated at 2022-06-26 12:53:39.040655
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-26 12:53:44.724296
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:46.033491
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test = TruTVIE(TurnerBaseIE)
	assert isinstance(test, TruTVIE)


# Generated at 2022-06-26 12:53:56.909467
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE(
        show_title='The Carbonaro Effect',
        media_id='f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        video_id='103437')
    assert ie.url == 'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower'
    assert ie.media_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert ie.video_id == '103437'

# Generated at 2022-06-26 12:53:57.650447
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:00.439955
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ie = TruTVIE()
	print(ie.test())

test_TruTVIE()

# Generated at 2022-06-26 12:54:08.764879
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiate class
    tt = TruTVIE()
    assert tt.extractor_key == 'TruTV'
    assert tt.IE_NAME == 'trutv'
    assert tt.ie_key == 'TruTV'
    assert tt._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:10.101858
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    output = TruTVIE()

# Generated at 2022-06-26 12:54:17.028157
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	try:
		assert TruTVIE
	except:
		print("class TruTVIE hasn't been defined!")
		assert False

	truTV_IE = TruTVIE()

	try:
		assert truTV_IE
	except:
		print("class TruTVIE's constructor hasn't been defined!")
		assert False

	print("The TruTVIE class has been defined correctly")
	assert True


# Generated at 2022-06-26 12:54:37.012375
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert True

# Generated at 2022-06-26 12:54:45.748797
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    tt = TruTVIE()

    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    tt.working(test_url)
    tt.run()

    assert tt.data['ext'] == 'mp4'
    assert tt.data['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert tt.data['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert tt.data['title'] == 'Sunlight-Activated Flower'

# Generated at 2022-06-26 12:54:48.217212
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE constructor without exception
    TruTVIE()

# Generated at 2022-06-26 12:54:57.994754
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert_equal(ie.IE_NAME, 'trutv:trutv')
    assert_equal(
        ie._VALID_URL,
        r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    )

# Generated at 2022-06-26 12:55:01.156340
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t_ie = TruTVIE()
    print (t_ie)

# Test for _real_extract function in class TruTVIE

# Generated at 2022-06-26 12:55:03.418419
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Create an instance of TruTVIE"""
    trutv = TruTVIE()
    return trutv

# Generated at 2022-06-26 12:55:05.301772
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    TruTVIE(None)

# Generated at 2022-06-26 12:55:13.686971
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    r = TruTVIE('info_dict','url','display_id','path','clip_slug','series_slug','video_id','ex','media_id','data','title','image','thumbnails','thumbnail','image_url','width','height','info','description','timestamp','site_name','publicationDate','seasonNum','episodeNum','showTitle','isAuthRequired')
    assert r.ie_key() == 'TruTV'

# Generated at 2022-06-26 12:55:17.018978
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
        Succeed = True
    except:
        Succeed = False
    assert(Succeed)



# Generated at 2022-06-26 12:55:17.526220
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:58.824676
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:07.813246
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for getting Titles of Episode
    test_object = TruTVIE()

    title = test_object._extract_title('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    assert title == 'Sunlight-Activated Flower'

    # Test for getting Information of Episode

# Generated at 2022-06-26 12:56:11.201807
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv


# Generated at 2022-06-26 12:56:13.611426
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # print(t.work())
    print('test TruTVIE done')
    return t

test_TruTVIE()

# Generated at 2022-06-26 12:56:14.455564
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global TruTVIE
    TruTVIE

# Generated at 2022-06-26 12:56:21.479192
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    from .common import fake_path_test
    from .trutv import TruTVIE
    from .common import InfoExtractor

    for test in fake_path_test.test_cases:
        url = test['url']
        try:
            video_id = TruTVIE._VALID_URL.match(url).group('id')
            assert video_id is not None
            test['info_dict']['id'] = video_id
        except AttributeError:
            pass
        ie = InfoExtractor.ie_key_map['trutv']()
        ie.extract(url)
        assert test['info_dict'] == ie.result

# Generated at 2022-06-26 12:56:22.708696
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/hacking-the-system/videos/diy-fishing-pole.html")

# Generated at 2022-06-26 12:56:30.715523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:56:31.390243
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:32.197830
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-26 12:58:24.827145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:35.576955
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    r = TruTVIE()
    assert r._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-26 12:58:42.403519
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Use class attributes to configure TruTVIE object
    t = TruTVIE()
    # Make sure class attributes are valid
    assert t._URL_FORMAT == TruTVIE._URL_FORMAT
    assert t._VALID_URL == TruTVIE._VALID_URL
    assert t._TEST == TruTVIE._TEST

# Generated at 2022-06-26 12:58:51.877654
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    # pylint: disable=protected-access
    trutv = TruTVIE()
    videos = trutv._download_json(
        'https://api.trutv.com/v2/web/series/clip/ID/', display_id='ID')['info']
    assert int(videos['mediaId']) > 0
    assert len(videos['title']) > 0
    assert videos['isAuthRequired'] == False

# Generated at 2022-06-26 12:59:02.433375
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:59:10.729728
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    assert 'TruTV' in TruTVIE.IE_NAME
    assert 'TruTV' in TruTVIE._VALID_URL
    assert 'www.trutv.com/' in TruTVIE._VALID_URL
    assert 're.match' in TruTVIE._VALID_URL
    assert 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html' in TruTVIE._TEST['url']
    assert 'https://' in TruTVIE._TEST['url']
    assert 'Sunlight-Activated Flower' in TruTVIE._TEST['info_dict']['title']

# Generated at 2022-06-26 12:59:15.269758
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Constructor of class TruTVIE should return an object of class
    TruTVIE
    """
    _TruTVIE = TruTVIE()
    assert isinstance(_TruTVIE, TruTVIE)


# Generated at 2022-06-26 12:59:16.086579
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	trutv = TruTVIE()


# Generated at 2022-06-26 12:59:16.889077
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert isinstance(TruTVIE, TurnerBaseIE)

# Generated at 2022-06-26 12:59:18.554574
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()