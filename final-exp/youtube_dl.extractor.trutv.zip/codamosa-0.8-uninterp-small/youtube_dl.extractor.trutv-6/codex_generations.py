

# Generated at 2022-06-26 12:52:06.544307
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == "https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))"

# Generated at 2022-06-26 12:52:08.779514
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    assert tru_t_v_i_e is not None

# Generated at 2022-06-26 12:52:13.594105
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:14.538767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()



# Generated at 2022-06-26 12:52:15.802107
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test_case_0()
    test_case_1()


# Generated at 2022-06-26 12:52:20.437265
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Errata
    assert_raises_regexp(RegexMatchError, r'.*input string.*', test_case_0) 


# Generated at 2022-06-26 12:52:24.375816
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()
# Test case for TruTVIE.extract. Case #0


# Test cases for TruTVIE.extract

# Generated at 2022-06-26 12:52:31.605218
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.name == 'turner:trutv'
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv._API_URL == 'https://api.trutv.com/v2/web/%s/%s/%s'


# Generated at 2022-06-26 12:52:33.597316
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i = TruTVIE()
    assert true


# Generated at 2022-06-26 12:52:35.138806
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert isinstance(TruTVIE(), TruTVIE)

# Generated at 2022-06-26 12:52:41.717973
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert isinstance(x, TruTVIE)

# Generated at 2022-06-26 12:52:44.466017
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:52:56.301114
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create object of class TruTVIE
    obj = TruTVIE()
    assert obj is not None, "TruTVIE is not None object"
    # Call function of class
    # assert obj.get_api_data(obj._TEST['url']) is not None, "get_api_data gives non-empty response"
    assert len(obj._extract_ngtv_info('id_of_video')) == 8, "Result of _extract_ngtv_info is a dictionary of 8 elements"
    assert len(obj._real_extract(obj._TEST['url'])) == 15, "Result of _real_extract is a dictionary of 15 elements"

# Generated at 2022-06-26 12:53:03.022113
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test the constructor of class TruTVIE
    if TruTVIE()._VALID_URL != 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))':
        raise Exception('Incorrect constructor of TruTVIE')
    # Test the _real_extract() method of class TruTVIE

# Generated at 2022-06-26 12:53:04.678595
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Check for object TruTVIE object creation
    TruTVIE()

# Generated at 2022-06-26 12:53:05.980469
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:12.277503
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ie.suitable('https://www.trutv.com/full-episodes/14688/impractical-jokers-s03e11-i-lost-on-jeopardy.html')
    assert ie.suitable('https://www.trutv.com/full-episodes/14688/impractical-jokers-s03e11-i-lost-on-jeopardy.html','testing')

# Generated at 2022-06-26 12:53:14.048817
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Assert that the constructor can be called without error
    trutv = TruTVIE()


# Generated at 2022-06-26 12:53:20.442530
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .. import TruTVIE
    expected_turner = 'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/all-the-curls?auth_required=false'
    turner_base = TruTVIE._TEST
    actual_turner = TruTVIE._download_json('https://www.trutv.com/shows/the-carbonaro-effect/videos/all-the-curls.html', 'clip_slug')['info']['url']
    assert(expected_turner == actual_turner)
    assert(expected_turner == turner_base['info_dict']['id'])

# Generated at 2022-06-26 12:53:28.772492
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert not TruTVIE()._VALID_URL.match("https://www.trutv.com/shows/the-carbonaro-effect/full-episodes")
    assert not TruTVIE()._VALID_URL.match("https://www.trutv.com/full-episodes")
    assert not TruTVIE()._VALID_URL.match("https://www.fubo.tv/watch/1")

    assert TruTVIE()._VALID_URL.match("https://www.trutv.com/shows/the-carbonaro-effect/46146/videos/sunlight-activated-flower.html")
    assert TruTVIE()._VALID_URL.match("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert TruTVIE

# Generated at 2022-06-26 12:53:40.048350
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv



# Generated at 2022-06-26 12:53:49.219527
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor_args = ["unit-test"]
    t = TruTVIE(*constructor_args)
    assert len(constructor_args) == 1
    assert t._downloader is not None
    assert "unit-test" == t._downloader.params.get("noprogress")
    assert t.name == "turner"
    assert t.description == "Turner Broadcasting System Inc."
    assert t.ie_key() == "Turner"
    assert t.SUCCEEDED == t.TRUE
    assert t.FAILED == t.FALSE
    assert t.TRUE == 1
    assert t.FALSE == 0
    assert t.SHOW_ID_KEY == "ie_key"
    assert t.TURNEREU_API_KEY == "WEB_PROD"

# Generated at 2022-06-26 12:53:59.936031
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE
    # Test with a valid URL
    _TEST = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }
    tv = TruTVIE()

    # Call function _real_extract with valid url

# Generated at 2022-06-26 12:54:00.577073
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:03.843183
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	obj = TurnerBaseIE('mtv_br')
	print(obj.__class__.__name__)
	print(obj.__module__)
	print(obj.base_url)
	assert obj.__class__.__name__ == 'TurnerBaseIE'
	assert obj.__module__ == 'adobepass'

# Generated at 2022-06-26 12:54:04.692003
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:08.083729
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # Test for method _real_extract
    # This test is not useful, because TruTVIE._real_extract depends on
    # TruTVIE._extract_ngtv_info which can't be tested
    # None value as input
    t._real_extract(None)
    # Wrong URL
    t._real_extract("http://wrong.com")

# Generated at 2022-06-26 12:54:09.566337
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:54:16.451699
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.ie_key() == 'truTV'
    assert t.ie_key() in TruTVIE.ie_key()
    assert t.name == 'truTV'
    assert TruTVIE.ie_key() == 'turner'
    assert TruTVIE.ie_key() in t.ie_key()
    assert TruTVIE.name == 'Turner'

# Generated at 2022-06-26 12:54:17.163289
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:35.805903
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    objex = TruTVIE()
    assert isinstance(objex, TruTVIE) is True

# Generated at 2022-06-26 12:54:38.426489
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert(trutvIE.__class__ == TruTVIE)

# Generated at 2022-06-26 12:54:43.276254
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.extract('https://www.trutv.com/full-episodes/12345')

# Generated at 2022-06-26 12:54:44.506809
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

# Generated at 2022-06-26 12:54:45.772438
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE != None

# Generated at 2022-06-26 12:54:46.788626
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:51.095286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    TruTVIE(url)

# Generated at 2022-06-26 12:54:55.592929
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        # Creating object of TurnerBaseIE subclass TruTVIE
        t = TruTVIE()
        print("Type of class TruTVIE is", type(t))
        print("Is object TruTVIE instance of TurnerBaseIE:", isinstance(t, TurnerBaseIE))
    except Exception as e:
        print("Caught exception:", e)


# Generated at 2022-06-26 12:54:56.384951
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:58.354364
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert isinstance(ie, TruTVIE)

# Generated at 2022-06-26 12:55:41.686705
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    print(t)
    # print(dir(t))
    print(t.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
    print(t.suitable('https://www.trutv.com/shows/tacoma-fd/full-episodes.html'))
    print(t.suitable('https://www.trutv.com/shows/greatest-ever/full-episodes/youre-not-going-to-eat-that-are-you-greatest-eating-challenges.html'))


# Generated at 2022-06-26 12:55:43.038370
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    print ("Test for constructor of class TruTVIE: Pass")


# Generated at 2022-06-26 12:55:43.836478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None, None).test()

# Generated at 2022-06-26 12:55:44.411081
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:53.572119
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.AGE_LIMITS == 18
    assert trutv.CC_SUFFIX == 'cc'
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:55:54.071923
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:03.935136
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:56:06.241772
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Create TruTVIE object and check if url is processed.
    """
    trutv = TruTVIE()
    assert trutv



# Generated at 2022-06-26 12:56:11.894097
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttvie = TruTVIE(url)
    assert ttvie._TEST['url'] == url, 'Expected URL {}'.format(url)

# Generated at 2022-06-26 12:56:13.418699
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_test = TruTVIE()
    assert isinstance(trutv_test, TurnerBaseIE)

# Generated at 2022-06-26 12:58:04.893460
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for _VALID_URL
    import re
    # Matches normal clip URLs
    assert TruTVIE._VALID_URL == re.compile(
        r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

    # Test for _TEST

# Generated at 2022-06-26 12:58:05.705407
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:07.781166
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	'''
	Unit test for constructor of class TruTVIE
	'''
	truTVIE = TruTVIE()

# Generated at 2022-06-26 12:58:16.536056
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-26 12:58:18.797582
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable(TruTVIE._TEST["url"])

# Generated at 2022-06-26 12:58:22.952192
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test that TruTVIE constructor is working properly
    try:
        TruTVIE()
    except Exception as exception:
        test_TruTVIE.valid = False
        print(exception)
    else:
        test_TruTVIE.valid = True

# Generated at 2022-06-26 12:58:35.040348
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Basic unit test for TruTVIE
    """
    # Can't use _TEST because it skips the download
    # Test video: https://www.youtube.com/watch?v=Zb5pr5F5YP4
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()

    # Test correct extract
    data = ie._real_extract(test_url)
    assert 'Sunlight-Activated Flower - The Carbonaro Effect' in data['title']
    assert data['description'].startswith('A customer is stunned when he sees Michael\'s sunlight-activated flower.')
    assert 'mp4' in data['formats'][0]['ext']

# Generated at 2022-06-26 12:58:45.551179
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # First, test one of the clip URLs
    test_1 = True

# Generated at 2022-06-26 12:58:54.616046
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from pytube import YouTube
    y = YouTube('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',on_progress_callback=TruTVIE.my_hook)
    y.streams.get_by_itag(22).download()
    # url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # trutv = TruTVIE(url, on_progress_callback=TruTVIE.my_hook)
    # trutv.downloadYouTube()
    # # trutv.download()


# Generated at 2022-06-26 12:58:56.349362
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
