

# Generated at 2022-06-26 12:52:01.797387
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_1 = TruTVIE()
    tru_t_v_i_e_1.suite()

# Generated at 2022-06-26 12:52:02.668543
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-26 12:52:04.672284
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__bases__ == (TurnerBaseIE,)

# Generated at 2022-06-26 12:52:05.583316
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True == True


# Generated at 2022-06-26 12:52:07.935767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:52:09.454998
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case_0()

# Generated at 2022-06-26 12:52:13.780517
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()
    assert tru_t_v_i_e_0._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:14.721766
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-26 12:52:15.958968
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert test_case_0() == None, "TruTVIE()"

# Generated at 2022-06-26 12:52:20.583217
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_tv_i_e = TruTVIE()

    assert tru_tv_i_e is not False, "TruTVIE() test failed."


# Generated at 2022-06-26 12:52:26.581322
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a.IE_NAME == 'truTV'

# Generated at 2022-06-26 12:52:33.318830
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE.constructor with normal url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    trutv.constructor(url)
    assert trutv.url == url


# Generated at 2022-06-26 12:52:37.367109
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    print('Unit test for TruTVIE()')
    print('title', ie.title())
    print('description', ie.description())
    print('url', ie.url())

if __name__ == '__main__':
    test_TruTVIE()

# TruTVIE() ## Unit test

# Generated at 2022-06-26 12:52:38.461376
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:52:40.897384
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(10)
    TruTVIE(None)

# Generated at 2022-06-26 12:52:49.699845
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE(None)
    assert trutv_ie.url_result is None
    assert trutv_ie.host is None
    assert trutv_ie.protocol is None
    assert trutv_ie.video_id is None
    assert trutv_ie.lang is None
    assert trutv_ie.initial_ip is None
    assert trutv_ie.country is None
    assert trutv_ie.geo_verification_headers is None
    assert trutv_ie.geo_bypass is None
    assert trutv_ie.geo_bypass_ip is None
    assert trutv_ie.geo_bypass_ip_auth is None
    assert trutv_ie.geo_bypass_country is None
    assert trut

# Generated at 2022-06-26 12:52:50.096641
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-26 12:52:50.925510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-26 12:53:00.506938
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie_class = TruTVIE()
    assert(ie_class._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-26 12:53:10.311099
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # instantiate TruTVIE
    trutvIE = TruTVIE()

    # assert properties
    assert trutvIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:28.483681
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-26 12:53:29.910466
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:32.182228
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_str = TruTVIE()
    print (vars(test_str))

# Generated at 2022-06-26 12:53:39.190713
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE")
    trutv_ie = TruTVIE()
    trutv_ie._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/the-trans-mountain-of-doom.html")
    trutv_ie._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-26 12:53:44.842673
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test with valid program URL
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test with invalid program URL

# Generated at 2022-06-26 12:53:45.900215
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()


# Generated at 2022-06-26 12:53:46.664657
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:51.123024
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    object = TruTVIE()
    object._real_extract(url)

# Generated at 2022-06-26 12:53:55.216439
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE.suite()
    runner = unittest.TextTestRunner()
    runner.run(test_TruTVIE)

# Generated at 2022-06-26 12:53:58.438724
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    This function tests that the TruTVIE constructor
    can successfully instantiate an instance of the class.

    https://github.com/rg3/youtube-dl/issues/10814
    """
    trutv_ie = TruTVIE(None, {})
    assert type(trutv_ie) == TruTVIE

# Generated at 2022-06-26 12:54:23.017711
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'TruTV'

# Generated at 2022-06-26 12:54:23.836647
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:24.916518
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:25.469201
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:31.099597
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        assert True
    except Exception as e:
        assert False, "Testcase for TruTVIE construct failed. Message: %s"%e.message

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-26 12:54:38.926896
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Example of TruTVIE URL
    trutv_ie = TruTVIE()
    trutv_ie._VALID_URL
    trutv_ie._TEST
    trutv_ie.suitable
    trutv_ie._real_extract
    trutv_ie._real_extract(url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    trutv_ie._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:54:41.316708
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-26 12:54:47.283875
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    klass = TruTVIE
    input_url = "https://www.trutv.com/shows/impractical-jokers/videos/party-foul-compilation.html"
    kwargs = {
    }
    obj = klass(**kwargs)
    output_url = obj._real_extract(input_url)
    assert output_url['id'] == '5dff0d0f-5f5c-470d-8d29-b62c1f7e94df'
    assert output_url['title'] == 'Party Foul Compilation'
    assert output_url['description'] == 'Some of the best party fouls in Jokers history.'
    assert output_url['timestamp'] == 1511670030

# Generated at 2022-06-26 12:54:48.291568
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:54.643211
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case = TruTVIE()
    assert test_case._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-26 12:55:32.225767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:32.764659
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE()

# Generated at 2022-06-26 12:55:35.493195
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1') == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'


# Generated at 2022-06-26 12:55:37.355350
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create instance of class TruTVIE
    trutv_ie = TruTVIE()
    assert isinstance(trutv_ie, TruTVIE)


# Generated at 2022-06-26 12:55:42.822135
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'test-title')
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'test-title', 'test-description')

# Generated at 2022-06-26 12:55:44.322341
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	TruTVIE()._real_extract(url)

# Generated at 2022-06-26 12:55:50.335021
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    assert TruTVIE.__name__ == "TruTVIE"
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:55:52.184257
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing the constructor
    test_obj = TruTVIE()
    assert isinstance(test_obj, TruTVIE)
    return


# Generated at 2022-06-26 12:56:02.136782
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:56:02.472448
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-26 12:57:43.780368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Constructor test for class TruTVIE
    """
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    trutv_ie.extract(url)

# Generated at 2022-06-26 12:57:44.336950
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTV')

# Generated at 2022-06-26 12:57:47.305659
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    ttv._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ttv._download_json('https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower', 'sunlight-activated-flower')

# Generated at 2022-06-26 12:57:52.909398
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	class_ = TruTVIE
	assert hasattr(class_, '_download_json')
	assert hasattr(class_, '_VALID_URL')
	assert hasattr(class_, '_TEST')
	assert hasattr(class_, '_TOKEN_SERVICE_URL')
	assert hasattr(class_, '_BASE_URL')
	assert hasattr(class_, '_real_extract')
	assert hasattr(class_, '_extract_ngtv_info')
	assert hasattr(class_, '_parse_smil_formats')
	assert hasattr(class_, '_extract_ngtv_formats')
	assert hasattr(class_, '_extract_ngtv_f4m_formats')

# Generated at 2022-06-26 12:57:54.046580
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE is type(TruTVIE()))

# Generated at 2022-06-26 12:57:55.516222
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._SUCCESS == 0

# Generated at 2022-06-26 12:57:56.232424
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:57:57.507764
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-26 12:57:58.929077
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

# Generated at 2022-06-26 12:58:07.037615
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 13:01:50.011342
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Construct an object of class TruTVIE
    instance_TruTVIE = TruTVIE()
    # Call TruTVIE's _extract_ngtv_info method to get the NGTV's title
    NGTV_title = instance_TruTVIE._extract_ngtv_info('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', {}, {'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'site_name': 'truTV', 'auth_required': 0}).get('title')
    # Get the title of TruTV
    TruTV_title = 'Sunlight-Activated Flower'
    # Print out the result

# Generated at 2022-06-26 13:01:56.269074
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor
    try:
        TruTVIE()
        assert True
    except AssertionError:
        assert False

    # Extract
    trutv_ie = TruTVIE()