

# Generated at 2022-06-26 12:51:58.705555
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    tru_t_v_i_e.test()
    test_case_0()


# Generated at 2022-06-26 12:52:01.670104
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE.__name__ == "TruTVIE")
    assert(isinstance(tru_t_v_i_e_0, TruTVIE))


# Generated at 2022-06-26 12:52:04.405660
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


import unittest


# Generated at 2022-06-26 12:52:05.316738
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()



# Generated at 2022-06-26 12:52:15.434408
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:17.507535
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-26 12:52:19.730824
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:52:22.025322
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()

# Generated at 2022-06-26 12:52:23.947062
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert_equal(TruTVIE, tru_t_v_i_e_0)

# Generated at 2022-06-26 12:52:24.733086
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-26 12:52:34.788568
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_1 = TruTVIE()


# Generated at 2022-06-26 12:52:43.735353
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .turner import TurnerBaseIE
    # Call function to test current class
    tru_t_v_i_e_0 = TruTVIE()
    # Assert if __init__() of class TruTVIE was called
    assert isinstance(tru_t_v_i_e_0, TurnerBaseIE)

if __name__ == '__main__':
    test_case_0()
    test_TruTVIE()

# Generated at 2022-06-26 12:52:44.295214
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-26 12:52:46.267146
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case #0
    tru_t_v_i_e_0 = TruTVIE()


# Generated at 2022-06-26 12:52:58.225891
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert tru_t_v_i_e_0._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:01.086498
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # AssertionError: expected TruTVIE to be an instance of TruTVIE
    assert instance(TruTVIE(), TruTVIE), "expected TruTVIE to be an instance of TruTVIE"

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 12:53:10.770486
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:14.024474
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()

if __name__ == '__main__':
    test_case_0()
    test_TruTVIE()

# Generated at 2022-06-26 12:53:15.341949
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_1 = TruTVIE()


# Generated at 2022-06-26 12:53:17.091440
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()



# Generated at 2022-06-26 12:53:38.811124
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://tru.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:53:39.202121
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:44.674952
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # test construct JSON request
    assert ie._extract_ngtv_info('media_1', {}, {'auth_required': True})['json'] == '{"mediaId":"media_1","authRequired":true}'
    assert ie._extract_ngtv_info('media_2', {}, {})['json'] == '{"mediaId":"media_2","authRequired":false}'
    # test extract URN
    assert ie._extract_ngtv_info('urn:ngtv:media:c4b49356-cc13-4e46-a2cb-0a0f4aa0028a', {})['media_id'] == 'c4b49356-cc13-4e46-a2cb-0a0f4aa0028a'

# Generated at 2022-06-26 12:53:49.966692
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Check that the constructor of class TruTVIE
    works correctly.
    """
    url = ("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    trutv = TruTVIE()
    info = trutv._real_extract(url)
    assert info['url'] == url
    assert info['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert info['display_id'] == 'sunlight-activated-flower'
    assert info['title'] == 'Sunlight-Activated Flower'
    assert info['site_name'] == 'truTV'
    assert info['timestamp'] == 1449634860

# Generated at 2022-06-26 12:53:51.416230
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()


# Generated at 2022-06-26 12:54:01.121061
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie = TruTVIE()
    ie._real_extract(url)
    # ie.get_formats('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    # ie.download_video('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    # ie.extract_broadcasted_at(ie.extract_url(url))
    # ie.broadcasted_at('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # ie.get_

# Generated at 2022-06-26 12:54:01.862957
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:03.150121
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()

# Generated at 2022-06-26 12:54:06.890452
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	print("test TruTVIE constructor")
	test_url = "https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower"
	test_instance = TruTVIE(test_url)
	test_instance.extract()


# Generated at 2022-06-26 12:54:08.249126
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:54:32.045044
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    obj = TruTVIE(url)
    #print(obj)


# Generated at 2022-06-26 12:54:34.469766
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE class
    TruTVIE_test = TruTVIE()


# Generated at 2022-06-26 12:54:45.501271
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	import sys, os
	sys.path.append(os.path.abspath('..'))
	from youtube_dl.YoutubeDL import YoutubeDL
	import TruTVIE
	
	ytdl_params = {
		'outtmpl': '%(id)s',
		'quiet': True
	}
	TruTVIE = TruTVIE.TruTVIE()
	TruTVIE_result = TruTVIE.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
	assert TruTVIE_result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
	assert TruTVIE_result['ext'] == 'mp4'



# Generated at 2022-06-26 12:54:46.450296
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:49.997351
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create instance of TruTVIE
    trutv_ie = TruTVIE()

    # Check of TruTVIE created correctly
    assert trutv_ie

# Generated at 2022-06-26 12:54:57.027777
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing Video url
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_TruTVIE = TruTVIE()
    test_TruTVIE._real_extract(url)
    url = "https://www.trutv.com/full-episodes/110/the-carbonaro-effect-episode-102/video-clips/sunlight-activated-flower.html"
    test_TruTVIE._real_extract(url)

# Generated at 2022-06-26 12:55:04.797509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check if the video is a valid video
    try:
        assert TruTVIE()._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
        return True
    except:
        return False

# Generated at 2022-06-26 12:55:06.223678
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()

# Generated at 2022-06-26 12:55:13.579784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE


# For development purposes
if __name__ == '__main__':
    from ytdl.utils import print_json
    print_json(TruTVIE()._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))

# Generated at 2022-06-26 12:55:14.985675
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)


# Generated at 2022-06-26 12:55:59.684496
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-26 12:56:00.524562
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV_test_result = TruTVIE()

# Generated at 2022-06-26 12:56:01.534195
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:02.370757
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("TruTVIE")

# Generated at 2022-06-26 12:56:03.428869
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()
    assert type(test) == TruTVIE

# Generated at 2022-06-26 12:56:05.158491
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test whether TruTVIE works
    tt_ie = TruTVIE()
    tt_ie.extract(TruTVIE._TEST['url'])

# Generated at 2022-06-26 12:56:05.737932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:07.292845
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'

# Generated at 2022-06-26 12:56:08.935284
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor should raise an exception if no param is passed
    assert TruTVIE()

# Generated at 2022-06-26 12:56:09.893349
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTVIE = TruTVIE()

# Generated at 2022-06-26 12:58:04.232440
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:58:05.366879
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:15.589492
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:58:17.592771
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.constructor()

# Generated at 2022-06-26 12:58:19.766691
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test if TruTVIE object is initiated
    TruTVIE


# Generated at 2022-06-26 12:58:23.298104
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()

# Generated at 2022-06-26 12:58:35.066709
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    t.ie # pylint: disable=access-member-before-definition
    t.url # pylint: disable=access-member-before-definition
    t.extractor # pylint: disable=access-member-before-definition
    t.downloader # pylint: disable=access-member-before-definition
    t.name # pylint: disable=access-member-before-definition
    t.new_ext # pylint: disable=access-member-before-definition
    t.merge_result_streams # pylint: disable=access-member-before-definition
    t.add_default_extractor # pylint: disable=access-member-before-definition
    t.is_suitable # pylint: disable=access-member-before-definition
    t

# Generated at 2022-06-26 12:58:37.049468
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:39.044907
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()  # NOQA


# Generated at 2022-06-26 12:58:40.464621
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    s = TruTVIE()
