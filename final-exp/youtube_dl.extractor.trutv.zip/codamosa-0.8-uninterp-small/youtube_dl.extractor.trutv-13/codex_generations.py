

# Generated at 2022-06-26 12:51:58.447183
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()


# Generated at 2022-06-26 12:51:59.528068
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() != None, 'TruTVIE not created'

# Generated at 2022-06-26 12:52:00.228641
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-26 12:52:01.336484
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()


# Generated at 2022-06-26 12:52:03.630946
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert tru_t_v_i_e_0


# Generated at 2022-06-26 12:52:13.729017
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()
    # Default parameters for constructor
    assert tru_t_v_i_e_0._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))', 'Default value for _VALID_URL in constructor is wrong.'

# Generated at 2022-06-26 12:52:20.648651
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    series_slug, clip_slug, video_id = TruTVIE._VALID_URL.match(url).groups()
    match = TruTVIE._VALID_URL.match(url)
    series_slug, clip_slug, video_id = match.groups()
    if video_id:
        path = 'episode'
        display_id = video_id
    else:
        path = 'series/clip'
        display_id = clip_slug
    data = True
    video_data = data['episode'] if video_id else data['info']
    media_id = video_data['mediaId']
    title = video_data['title'].strip()


# Generated at 2022-06-26 12:52:22.872535
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()

# Generated at 2022-06-26 12:52:23.723389
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # create instance without params
    tru_t_v_i_e = test_case_0()


# Generated at 2022-06-26 12:52:27.799474
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    with open(os.path.abspath('test/test_data/test_TruTVIE_0.json'), 'rU') as my_file:
        data = my_file.read()
    obj = TruTVIE()

test_TruTVIE()

# Generated at 2022-06-26 12:52:33.581924
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie != None

# Generated at 2022-06-26 12:52:36.015620
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m=TruTVIE()
    print(m._real_extract(TruTVIE._TEST['url']))

# Generated at 2022-06-26 12:52:37.259840
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:52:47.400998
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    url = "https://api.trutv.com/v2/web/series/clip/impractical-jokers/how-much-is-too-much/8"
    data = t._download_json(url, 's03e05')
    media_id = data['info']['mediaId']
    auth_required = data['info']['isAuthRequired']
    info = t._extract_ngtv_info(
        media_id, {}, {})
    assert media_id == info['id']
    assert auth_required == info['auth_required']

# Generated at 2022-06-26 12:52:48.816308
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:52:58.123236
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

    assert('re' in globals())

# Generated at 2022-06-26 12:52:59.695029
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        assert False
    except:
        assert True



# Generated at 2022-06-26 12:53:05.153649
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Defines url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Instantiates TruTVIE
    t = TruTVIE()

    # Checks whether url matches TruTVIE URL
    assert t._VALID_URL == t._match_id(url)

    # Checks whether _extract method of TruTVIE returns expected result
    extracted_info = {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
    }

# Generated at 2022-06-26 12:53:06.571478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-26 12:53:07.908282
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:53:19.293575
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-26 12:53:27.315068
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	test1 = TruTVIE()
	assert(test1._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
	assert(test1._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-26 12:53:39.007251
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:40.382094
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE(url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:53:47.624934
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'truTV'
    assert ie.IE_DESC == 'truTV'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie._API_BASE_URL == 'https://api.trutv.com/v2/'
    assert ie._TURNERT_VERSION == '1.0.0.0'
    assert ie._TURNERT_TENANT_ID == 'trutv'
    assert ie

# Generated at 2022-06-26 12:53:49.067694
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert True

# Generated at 2022-06-26 12:53:52.665453
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-26 12:53:54.700505
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()
    return i


# Generated at 2022-06-26 12:53:55.482663
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-26 12:54:03.146897
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_class = TruTVIE(test_url)
    expected_class = "<class 'youtube_dl.extractor.trutv.TruTVIE'>"
    assert type(test_class).__name__ == expected_class

# Generated at 2022-06-26 12:54:24.090687
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tv = TruTVIE()
    print(tv)
    assert tv != None

# Generated at 2022-06-26 12:54:25.749532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE("teststring") == TruTVIE("teststring")

# Generated at 2022-06-26 12:54:27.724625
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert isinstance(TruTVIE, object)


# Generated at 2022-06-26 12:54:38.832899
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    true_tv = TruTVIE()
    assert true_tv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:46.947272
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')['display_id'] == 'sunlight-activated-flower'

# Generated at 2022-06-26 12:54:49.931265
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-26 12:54:50.955734
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:52.384585
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.test()

# Generated at 2022-06-26 12:54:56.793757
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    
    test_TruTVIE = TruTVIE()
    value = test_TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert value == True
    print('test case for TruTVIE is passed!')

test_TruTVIE()

# Generated at 2022-06-26 12:55:06.852977
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie_TruTVIE = TruTVIE()
    assert ie_TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:55:51.295703
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tester = TruTVIE()
    assert tester.description() == "Turner Broadcasting System Inc. (TBS, TNT, Cartoon Network, Adult Swim, truTV, Turner Classic Movies) sites"
    assert tester.ie_key() == 'TruTV'

# Generated at 2022-06-26 12:55:53.143785
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv is not None, "Failed to instantiate TruTVIE"


# Generated at 2022-06-26 12:55:58.031191
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_extractor = TruTVIE()
    assert trutv_extractor.name == 'trutv'
    assert trutv_extractor.ie_key() == 'trutv'
    assert trutv_extractor.ie_key() in TruTVIE.ie_key()


# Generated at 2022-06-26 12:56:06.586191
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:56:08.737753
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-26 12:56:10.269954
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TurnerBaseIE()
    assert result == TruTVIE


# Generated at 2022-06-26 12:56:13.114306
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Testing constructor of class TurnerBaseIE
    test_obj_TruTVIE = TruTVIE("", {})
    print("Testing constructor of class TruTVIE")
    assert True

# Generated at 2022-06-26 12:56:19.491093
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor of class TruTVIE
    video_url = TruTVIE._TEST['url']
    print('Video URL: ' + video_url)
    video_info = TruTVIE()._real_extract(video_url)
    print('Video info: ' + str(video_info))
    assert(video_info['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-26 12:56:20.107160
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-26 12:56:20.711579
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:23.355467
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not ie.suitable('https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not ie.suitable('https://www.trutv.com/videos/sunlight-activated-flower.html')
    assert not ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower')

# Generated at 2022-06-26 12:58:25.441079
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.IE_NAME == 'TruTV'

# Generated at 2022-06-26 12:58:26.674259
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    if not True:
        TruTVIE()

# Generated at 2022-06-26 12:58:34.621830
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    c = TruTVIE
    assert c.ie_key() == 'trutv'
    assert c.ie_key() + ':' + c.ie_key() == c.valid_url(c.ie_key() + ':' + c.ie_key())
    assert 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html' == c.valid_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:58:45.387503
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-26 12:58:46.361189
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:49.304500
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        return False
    return True

# Generated at 2022-06-26 12:58:51.486045
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a is not None


# Generated at 2022-06-26 12:58:52.082294
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:59:02.793247
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    module_name = 'trtv' # name of the module which uses the TruTVIE class
    certifi = True # import of SSL certificate
    # url of the video to be tested
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # template values for the assertEqual method
    expected = dict()
    expected['test_module_name'] = module_name
    expected['test_expected_certifi'] = certifi
    expected['test_expected_instance'] = 'TruTVIE(certifi=True)'
    expected['test_expected_url'] = url
    expected['test_expected_re'] = 'TruTVIE._VALID_URL'
    expected['test_expected_result'] = True