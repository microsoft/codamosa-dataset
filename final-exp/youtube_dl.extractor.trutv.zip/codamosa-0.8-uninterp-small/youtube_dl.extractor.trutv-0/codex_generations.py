

# Generated at 2022-06-26 12:52:05.141242
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  # Case 1:
  #  No need to test since method _extract_ngtv_info is tested
  #  in the test case for extractor turner.

  # Case 2:
  #  No need to test since method _extract_ngtv_info is tested
  #  in the test case for extractor turner.

  # Case 3:
  #  No need to test since method _extract_ngtv_info is tested
  #  in the test case for extractor turner.
  return 1


# Generated at 2022-06-26 12:52:15.263445
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
  assert TruTVIE()._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
  assert TruTVIE()._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-26 12:52:24.233051
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()
    # assert that _VALID_URL is of type string
    assert isinstance(tru_t_v_i_e_0._VALID_URL, str)
    # assert that _TEST is of type dict
    assert isinstance(tru_t_v_i_e_0._TEST, dict)


# Generated at 2022-06-26 12:52:27.168334
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    tru_t_v_i_e_1 = TruTVIE()
    assert tru_t_v_i_e_1 is not None


# Generated at 2022-06-26 12:52:29.375101
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()

# Generated at 2022-06-26 12:52:31.364565
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_0 = TruTVIE()


# Generated at 2022-06-26 12:52:39.918767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:41.354104
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e_1 = TruTVIE()
    assert tru_t_v_i_e_1._VALID_URL is not None


# Generated at 2022-06-26 12:52:44.544340
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://api.trutv.com/v2/web/series/clip/tru-tv/epic-fail-compilation"
    TruTVIE.test_valid_url(url)


test_case_0()
test_TruTVIE()

# Generated at 2022-06-26 12:52:49.313063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert True


if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(["-v", __file__]))

# Generated at 2022-06-26 12:52:58.193082
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test whether TruTVIE class exist
    assert TruTVIE

    # test TruTVIE constructor
    ie = TruTVIE(TurnerBaseIE._downloader, 'TruTV')

    # test TruTVIE._VALID_URL
    assert ie._VALID_URL

    # test TruTVIE._TEST
    assert ie._TEST

# Generated at 2022-06-26 12:52:59.716269
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'

# Generated at 2022-06-26 12:53:00.657961
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:10.352702
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    expected_url = 'http://api.trutv.com/v3/videos/' + ie._extract_video_id(url) + '.json'
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test for `extract` method of the class
    assert ie.extract(url) == ie._real_

# Generated at 2022-06-26 12:53:11.329515
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:19.522668
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-26 12:53:26.450870
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Test without video slug
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()._real_extract(url)
    #Test with video slug
    url = 'https://www.trutv.com/shows/the_last_ship/videos/s1-e6-59e6b'
    TruTVIE()._real_extract(url)

# Generated at 2022-06-26 12:53:29.535024
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check class constructor
    assert TruTVIE()._VALID_URL
    assert TruTVIE()._TEST

# Generated at 2022-06-26 12:53:33.800644
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-26 12:53:35.123324
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # return true on success, false on failure
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST
    return True

# Generated at 2022-06-26 12:53:45.048965
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE constructor"""
    TruTVIE()

# Generated at 2022-06-26 12:53:48.400523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # In this test, we will test with a TruTV link
    Trutv = TruTVIE()
    assert TruTVIE._TEST['url'] == Trutv._TEST['url']
    assert Trutv.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:53:59.550656
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check the simple cases
    tv = TruTVIE()
    assert(tv.name == "TruTV")
    assert(tv.subtitle == "extract videos from trutv.com")
    assert(tv.url_re == TruTVIE._VALID_URL)

    # Test TruTVIE._real_extract() for a valid URL
    tv1 = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    data = tv1.extract(url)
    assert(data.get('id') == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    assert(data.get('title') == 'Sunlight-Activated Flower')


# Generated at 2022-06-26 12:54:01.072467
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    r = TruTVIE()
    assert isinstance(r, TruTVIE)
    

# Generated at 2022-06-26 12:54:07.079573
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	
	# Create class instance
	testVideo = TruTVIE()

	# Test TruTVIE._VALID_URL
	assert(testVideo._VALID_URL[0] == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-26 12:54:08.656875
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:54:19.146517
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:22.228893
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    log.debug(TruTVIE._VALID_URL)
    log.debug(TruTVIE._TEST)

# Generated at 2022-06-26 12:54:30.502581
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check if TruTVIE is constructed correctly
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:39.135989
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test without an object instantiation
    try:
        truTV = TruTVIE()
    except Exception as e:
        print("Failed without an object instantiation")
    
    # Test with an object instantiation
    try:
        truTV = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
        print("Working with an object instantiation")
    except Exception as e:
        print("Failed with an object instantiation")
    
    print("Test Completed")

'''
if __name__ == "__main__":
    # Unit test for TruTVIE class
    test_TruTVIE()
'''

# Generated at 2022-06-26 12:54:59.136279
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:01.729332
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_main import main

    # TODO: add more test cases
    main(TruTVIE)

# Generated at 2022-06-26 12:55:02.511921
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # unit test of TruTVIE class
    TruTVIE()

# Generated at 2022-06-26 12:55:03.225551
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:12.391401
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Given
	truTVIE = TruTVIE("")

	# Then
	assert truTVIE.display_id is None
	assert truTVIE.media_id is None
	assert truTVIE.player_id is None
	assert truTVIE.site_name is not None
	assert truTVIE.ngtv_params is not None
	assert truTVIE.auth_required is not None
	assert truTVIE.url is None


# Generated at 2022-06-26 12:55:15.319801
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    print(obj)
    print(type(obj._TEST))
    print(re.match(obj._VALID_URL, obj._TEST['url']))

test_TruTVIE()

# Generated at 2022-06-26 12:55:16.902093
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    assert TruTVIE is not None

# Generated at 2022-06-26 12:55:21.497415
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    u = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert(TruTVIE()._real_extract(u)['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

# Generated at 2022-06-26 12:55:22.024987
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:27.298583
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # url of TruTVIE class
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # create TruTVIE object
    trutv_ie = TruTVIE()
    # test method extract
    trutv_ie.extract(url)

# Generated at 2022-06-26 12:56:13.372139
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:56:20.340938
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE constructor, give a vaild url, return TruTVIE object
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    constructor_test(TruTVIE, test_url)

if __name__ == "__main__":
    # Test for TruTVIE constructor, give a vaild url, return TruTVIE object
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    constructor_test(TruTVIE, test_url)

# Generated at 2022-06-26 12:56:26.358578
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test creation of TruTVIE object with default url
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:56:27.105869
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE



# Generated at 2022-06-26 12:56:30.114385
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("\nTesting constructor of class TruTVIE")
    trutv_ie = TruTVIE()

    assert TruTVIE._VALID_URL == trutv_ie._VALID_URL
    assert TruTVIE._TEST == trutv_ie._TEST


# Generated at 2022-06-26 12:56:32.337820
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from datetime import datetime
    from dateutil.tz import tzoffset
    TruTVIE()

test_TruTVIE()

# Generated at 2022-06-26 12:56:33.978768
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "trutv.com"
    obj = TruTVIE(url)
    assert(obj)

# Generated at 2022-06-26 12:56:35.223809
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TODO Add constructor test
    print("TruTVIE Constructor Test")


# Generated at 2022-06-26 12:56:38.727362
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    # Test for method _real_extract()
    assert TruTVIE._real_extract(trutvIE, TruTVIE._TEST['url'])

# Generated at 2022-06-26 12:56:39.454360
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:58:46.395367
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-26 12:58:47.563904
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:53.482463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('TruTV')._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:59:03.983293
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case = TruTVIE()
    assert test_case._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:59:05.620844
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-26 12:59:06.242596
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE != None

# Generated at 2022-06-26 12:59:16.395767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import json
    import unittest
    import sys

    # load test data
    test_data_file = open('test/test_data/test.trutv.com.json', 'r').read()
    test_data = json.loads(test_data_file)
    #print(test_data)

    # set mocks for call results
    # set data for download json
    download_json_file = open('test/test_data/trutv.com.download_json.json', 'r').read()
    download_json_data = json.loads(download_json_file)
    # set data for extract ngtv info
    extract_ngtv_info_file = open('test/test_data/trutv.com.extract_ngtv_info.json', 'r').read()
    extract_ngtv

# Generated at 2022-06-26 12:59:27.182070
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-26 12:59:28.013004
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-26 12:59:37.189327
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Constructor"""
    ie = TruTVIE()
    # make sure the object was initialized properly
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'