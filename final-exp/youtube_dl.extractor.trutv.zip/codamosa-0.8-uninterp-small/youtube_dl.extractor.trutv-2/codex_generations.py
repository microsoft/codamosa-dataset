

# Generated at 2022-06-26 12:52:07.981373
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert hasattr(TruTVIE, '_real_extract')
    assert callable(TruTVIE._real_extract)
    assert hasattr(TruTVIE, '_VALID_URL')
    assert re.search(TruTVIE._VALID_URL, 'https://www.trutv.com/full-episodes/29477/the-carbonaro-effect-episode-8.html')
    assert re.search(TruTVIE._VALID_URL, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-26 12:52:09.499919
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert test_case_0() == None

# Generated at 2022-06-26 12:52:10.752296
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:52:12.071828
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert callable(TruTVIE)


# Generated at 2022-06-26 12:52:15.174366
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import sys, tempfile
    # Create and initialize a test TruTVIE instance
    tru_t_v_i_e = TruTVIE(params={})
    assert tru_t_v_i_e is not None


# Generated at 2022-06-26 12:52:16.114642
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
   pass

# Generated at 2022-06-26 12:52:27.167817
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    series_slug, clip_slug, video_id = re.match(tru_t_v_i_e._VALID_URL, url).groups()
    assert series_slug == 'the-carbonaro-effect'
    assert clip_slug == 'sunlight-activated-flower'
    assert video_id == None


# Generated at 2022-06-26 12:52:28.643835
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE


# Generated at 2022-06-26 12:52:38.655958
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    # Runs real_extract method for TruTVIE
    tru_t_v_i_e._real_extract(url="https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    # Runs real_extract method for TruTVIE
    tru_t_v_i_e._real_extract(url="https://www.trutv.com/shows/the-carbonaro-effect/10167/the-crappy-to-happy-machine.html")
    # Runs real_extract method for TruTVIE

# Generated at 2022-06-26 12:52:47.625372
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # URL of a show on trutv.com
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Instance of class TruTVIE
    tru_t_v_i_e = TruTVIE.TruTVIE()
    # Instance of class TruTVIE created for extractor for trutv.com
    # This method is called when working with an instance of this class as
    # an argument
    tru_t_v_i_e.extract(url)


# Generated at 2022-06-26 12:52:56.256231
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ConstructorTest('TruTVIE', 'TruTVIE.py', TruTVIE, access='public', access_msg='Access is set to public', params=None,
					props=None, read=False, instantiate=False, abstract=False)


# Generated at 2022-06-26 12:52:59.850035
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-26 12:53:05.097996
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie_valid_url = ie._TEST.get('url')
    ie_id = ie._TEST.get('id')
    ie_info_dict = ie._TEST.get('info_dict')
    ie_display_id = ie._TEST.get('display_id')
    ie_ext = ie._TEST.get('ext')
    ie_params = ie._TEST.get('params')
    print(ie_valid_url)
    print(ie_id)
    print(ie_info_dict)
    print(ie_display_id)
    print(ie_ext)
    print(ie_params)
    #N = 5
    #for i in range(N):
    #    print("hello")

# Generated at 2022-06-26 12:53:16.175467
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:53:17.164656
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:27.921264
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-26 12:53:39.277336
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  test_str = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
  test_extractor = TruTVIE()
  test_url = parse_url(test_str)
  test_video_data = test_extractor._real_extract(test_url)

# Generated at 2022-06-26 12:53:39.725086
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:41.280381
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()    
    print(trutvIE)


# Generated at 2022-06-26 12:53:41.696724
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-26 12:53:56.454093
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
        print("Succeeded in creating TruTVIE class instance")
    except:
        print("Failed to create TruTVIE class instance")

# Generated at 2022-06-26 12:54:07.586869
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing constructor of class TruTVIE")
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:54:08.659438
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:17.411452
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Given a TruTVIE
    trutv = TruTVIE()

    # When initialize TruTVIE
    # Then TruTVIE's url is equal to validate url
    assert trutv._VALID_URL == \
            r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-26 12:54:20.260327
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    instance.toString()


# Generated at 2022-06-26 12:54:23.962427
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.ie_key() == 'TruTV'
    assert t.ie_key() in TURNER_IES



# Generated at 2022-06-26 12:54:28.282512
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-26 12:54:30.625821
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-26 12:54:32.516856
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): 
    TruTVIE = TruTVIE()
    a = 1
    assert a == 1

# Generated at 2022-06-26 12:54:35.055249
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    print("Success")

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-26 12:54:59.845826
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    url = 'https://www.trutv.com/shows/titled/videos/sunlight-activated-flower.html'
    TruTVIE._download_webpage(url, '123')

# Generated at 2022-06-26 12:55:00.714261
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:06.157067
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print ("Testing constructor of class TruTVIE")
    # Testing constructor of class TruTVIE
    test_video_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_TruTVIE = TruTVIE()

    # Checking if valid_url is working properly
    assert test_TruTVIE.suitable(test_video_url), "valid_url is not working properly"


# Generated at 2022-06-26 12:55:06.962620
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-26 12:55:12.728349
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    
    # url response
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    
    # testing TruTVIE class
    TruTVIE(url)

# Generated at 2022-06-26 12:55:13.453869
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:13.819186
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:22.305871
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    expected_regex = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert re.match(expected_regex, url) is not None
    assert re.match(instance._VALID_URL, url) is not None


# Generated at 2022-06-26 12:55:23.153387
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:55:24.595320
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

# Generated at 2022-06-26 12:56:13.973781
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    assert trutv._TEST == TruTVIE._TEST
    assert trutv._VALID_URL == TruTVIE._VALID_URL
    assert trutv.IE_NAME == TruTVIE.IE_NAME
    assert trutv.ie_key() == TruTVIE.ie_key()
    assert trutv.suitable(test_url) == TruTVIE.suitable(test_url)
    assert trutv._WORKING == TruTVIE._WORKING

# Generated at 2022-06-26 12:56:14.974653
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-26 12:56:16.794546
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Test that TruTVIE is constructed correctly """
    ttv = TruTVIE()
    assert isinstance(ttv, TruTVIE)


# Generated at 2022-06-26 12:56:19.137587
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check the constructor of this class
    trutv = TruTVIE()
    print('test_TruTVIE | trutv.constructor succeeded')
    return True


# Generated at 2022-06-26 12:56:19.648867
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:20.782090
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TruTVIE must not be imported
    TruTVIE 
    assert True

# Generated at 2022-06-26 12:56:21.165573
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:56:22.414393
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Test TruTVIE constructor """
    object_TruTVIE = TruTVIE(None)
    assert object_TruTVIE is not None

# Generated at 2022-06-26 12:56:25.479958
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # pylint: disable=protected-access
    TruTVIE('tests', 'run_all')
    assert TruTVIE._VALID_URL is not None # make coverage happy
    assert TruTVIE._TEST is not None # make coverage happy
    # pylint: enable=protected-access

# Generated at 2022-06-26 12:56:33.976626
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE()
    assert trutvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:58:28.294757
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().test()

# Generated at 2022-06-26 12:58:31.153642
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    print(TruTVIE)


# Generated at 2022-06-26 12:58:32.254116
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:58:33.028791
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-26 12:58:34.179593
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    return

# Generated at 2022-06-26 12:58:41.740174
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This function checks constructor's functionality
    # and it returns an object if created properly otherwise None
    # First we create a dummy URL as usual
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()._real_extract(url)


# Generated at 2022-06-26 12:58:44.808491
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()
    assert i


# Test cases for TrueTVIE
# Test cases for method _real_extract of class TruTVIE
# Test cases for method _extract_ngtv_info of class TurnerBaseIE
#     def _extract_ngtv_info(self, media_id, info, ngtv_data={}):

# Generated at 2022-06-26 12:58:48.367959
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TruTVIE(InfoExtractor) instantiates an object of the class TruTVIE
    assert TruTVIE(InfoExtractor) is not None

# Generated at 2022-06-26 12:58:51.207299
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test constructor
    TruTVIE()

    # test TruTVIE class
    TruTVIE()

# Generated at 2022-06-26 12:58:52.560287
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__module__ == TruTVIE._module
