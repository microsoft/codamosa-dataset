

# Generated at 2022-06-26 12:51:59.186772
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert (TruTVIE() != None), "Error: Failed to instantiate TruTVIE"


# Generated at 2022-06-26 12:52:01.200803
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Unit test for constructor of class TruTVIE")
    result = TruTVIE()


# Generated at 2022-06-26 12:52:03.111013
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:52:05.393491
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert test_case_0() == None, "Error in test_case_0"

if __name__ == "__main__":
    test_class()

# Generated at 2022-06-26 12:52:15.520097
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', "Incorrect test URL"
    assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', "Incorrect test ID"
    assert TruTVIE._TEST['info_dict']['ext'] == 'mp4', "Incorrect test extension"
    assert TruTVIE._TEST['info_dict']['title'] == 'Sunlight-Activated Flower', "Incorrect test title"

# Generated at 2022-06-26 12:52:19.588262
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    assert tru_t_v_i_e is not None


# Generated at 2022-06-26 12:52:25.599493
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()
    tru_t_v_i_e.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-26 12:52:32.954248
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check if type is correct
    tru_t_v_i_e = TruTVIE()
    assert(type(tru_t_v_i_e) == TruTVIE)
    # Check if class is immutable
    try:
        tru_t_v_i_e._VALID_URL = "Test"
        assert(False)
    except:
        assert(True)


# Generated at 2022-06-26 12:52:45.553419
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().IE_NAME == 'trutv:video'
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:52:47.686259
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_t_v_i_e = TruTVIE()


# Generated at 2022-06-26 12:52:54.397222
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST['info_dict']['title'] == 'Sunlight-Activated Flower'

# Generated at 2022-06-26 12:52:57.100815
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-26 12:52:58.483344
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    d = TruTVIE()

# Generated at 2022-06-26 12:53:01.150426
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    print(trutv)
    print(type(trutv))

# Generated at 2022-06-26 12:53:10.804732
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # Test _VALID_URL

# Generated at 2022-06-26 12:53:13.130483
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor
    extractor = TruTVIE()
    assert(extractor != None)

# Generated at 2022-06-26 12:53:15.750688
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor of class TruTVIE
    trutvIE = TruTVIE()
    assert trutvIE.__class__ == TruTVIE
    return True


# Generated at 2022-06-26 12:53:18.878241
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    conn = TruTVIE()
    assert conn.__class__.__name__ == 'TruTVIE'

# Generated at 2022-06-26 12:53:28.362428
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    path  = 'episode'
    display_id  = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    series_slug = 'the-carbonaro-effect'

# Generated at 2022-06-26 12:53:29.320894
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:39.282294
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:39.725110
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:40.145031
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:53:41.007349
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  try:
    TruTVIE()
  except:
    return False
  return True

# Generated at 2022-06-26 12:53:45.434459
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE()._real_extract('https://www.trutv.com/full-episodes/3437777/hack-my-life-inside-hacks-how-to-hack-a-car-tire-hack.html')
    TruTVIE()._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/3463381/the-carbonaro-effect-season-3-episode-9-blood-in-the-water.html')

# Generated at 2022-06-26 12:53:50.289234
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize class TruTVIE
    trutv_ie = TruTVIE()
    # Some available data
    data = {
        'series_slug': 'a',
        'clip_slug': 'b',
        'id': 'c'
    }
    try:
        # Asserts for the method _real_extract
        assert trutv_ie._real_extract(
            "https://www.trutv.com/shows/a/videos/b") == trutv_ie._real_extract(
            "https://www.trutv.com/shows/a/c")
    except:
        # If asserts failed, return False
        return False
    # If everything work, return True
    return True

# Generated at 2022-06-26 12:53:52.591500
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception:
        return False
    return True

# Generated at 2022-06-26 12:53:53.493158
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-26 12:53:54.322286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:02.279634
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    assert a.suitable('https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    assert a.suitable('https://www.trutv.com/shows/the-carbonaro-effect/16015') == True
    assert a.suitable('https://www.trutv.com/shows/the-carbonaro-effect/16015/') == True
    assert a.suitable('https://www.trutv.com/shows/the-carbonaro-effect/16015/videos/') == False

    #assert a.get_info

# Generated at 2022-06-26 12:54:30.301340
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialization
    truTVIE = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html');

    # Test
    assert truTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))';

# Generated at 2022-06-26 12:54:40.066949
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	def test_TruTVIE_constructor(input_url, expected_series_slug, expected_clip_slug, expected_id):
		unit_test_url = TruTVIE(None, {'url': input_url})
		assert unit_test_url._VALID_URL == TruTVIE._VALID_URL
		assert unit_test_url._TEST == TruTVIE._TEST
		match_result = re.match(TruTVIE._VALID_URL, input_url)
		assert match_result.groups() == (expected_series_slug, expected_clip_slug, expected_id)
		assert unit_test_url._real_extract(input_url)
		print('Test of TruTVIE constructor success')


# Generated at 2022-06-26 12:54:40.447659
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:54:41.566231
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialization of TruTVIE class
    TruTVIE()

# Generated at 2022-06-26 12:54:45.749145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # create test object
    tt = TruTVIE()
    # output the TruTVIE object for test purposes
    print(tt)
    # perform a test
    result = tt.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # check result
    if result == True:
        return True
    else:
        return False

# Generated at 2022-06-26 12:54:57.176531
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Get instance of TruTVIE
    trutv = TruTVIE()

    # Verify if the call above returned a TurnBaseIE with the expected attributes
    assert isinstance(trutv, TruTVIE)
    assert isinstance(trutv, TurnerBaseIE)
    assert hasattr(trutv, '_VALID_URL')
    assert hasattr(trutv, '_TEST')
    assert isinstance(trutv._VALID_URL, type(re.compile('')))
    assert isinstance(trutv._TEST, dict)
    assert len(trutv._TEST) > 0
    assert hasattr(trutv, '_download_json')
    assert hasattr(trutv, '_extract_ngtv_info')

# Generated at 2022-06-26 12:55:06.972000
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tr = TruTVIE()
    assert tr._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert tr._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-26 12:55:17.278698
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:55:21.901293
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html' # url to test
	truTV_obj = TruTVIE()
	result = truTV_obj.suitable(url)
	print(result)
	assert result == True, 'not a TruTV URL'

# Generated at 2022-06-26 12:55:22.472401
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-26 12:56:09.109946
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE._VALID_URL, 'Invalid TruTVIE._VALID_URL'
	assert TruTVIE._TEST, 'Invalid TruTVIE._TEST'

# Generated at 2022-06-26 12:56:10.310018
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() is not None

# Generated at 2022-06-26 12:56:12.803573
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        class_object = TruTVIE
        class_object(x, y)
    except:
        return False
    else:
        return True

# Generated at 2022-06-26 12:56:14.766714
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(_test_files_downloader(), {'test_option': True})._TEST == 'test_value'

# Generated at 2022-06-26 12:56:17.548016
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie is not None
    assert ie.url_re is not None
    assert ie.url_re.match(TruTVIE._TEST['url'])

test_TruTVIE()

# Generated at 2022-06-26 12:56:20.781341
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t == TruTVIE('TruTV')
    assert t == TruTVIE('TruTV')
    assert t.isimple_title == "TruTV"

# Test istance method of class TruTVIE

# Generated at 2022-06-26 12:56:26.626029
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE();
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:56:31.423076
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE instance
    trutv = TruTVIE()

    # Test with URL
    test_withurl = trutv.suitable('http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert test_withurl

    # Test without URL
    test_withouturl = trutv.suitable('')
    assert not test_withouturl


# Generated at 2022-06-26 12:56:33.071951
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == "TruTVIE"


# Generated at 2022-06-26 12:56:40.183466
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print('Testing TruTVIE')
    vid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    print('\tTesting with URL ' + vid_url)
    vid_data = trutv._real_extract(vid_url)
    assert(vid_data['title'] == 'Sunlight-Activated Flower')
    assert(len(vid_data['thumbnails']) == 3)
    assert(len(vid_data['formats']) == 2)
    print('\tPassed')


# Generated at 2022-06-26 12:58:44.363767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()
    assert i._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-26 12:58:46.501543
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract(TruTVIE._TEST['url'])

# Generated at 2022-06-26 12:58:55.589766
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == "trutv:show"
    assert ie.INFO_HASH
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_REQUIRED_PARAMS
    assert ie.BRIGHTCOVE_TOKEN_QUERY
    assert ie.BRIGHTCOVE_TOKEN_SUFFIX
    assert ie.CLIENT_ID
    assert ie.CLIENT_SECRET
    assert ie.MAX_VIDEO_AGE
    assert ie.BRIGHTCOVE_URL_TEMPLATE
    assert ie.BRIGHTCOVE_REQUIRED_PARAMS
    assert ie.BRIGHTCOVE_TOKEN_QUERY
    assert ie.BRIGHTCOVE_TOKEN_SUFFIX
    assert ie

# Generated at 2022-06-26 12:59:06.393579
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_extractor = TruTVIE()
    assert trutv_extractor._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv_extractor._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-26 12:59:06.747894
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:59:14.910592
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Basic unit test to create TruTVIE instance and test if it meets expectation
    """
    import sys
    import os.path
    sys.path.append(os.path.normpath(os.path.join(os.path.dirname(__file__), '..')))
    from ytdl_services.extractor.common import InfoExtractor

    IE_NAME = 'trutv'
    ie = InfoExtractor.get_info_extractor(IE_NAME)()
    expected_ie = TruTVIE
    assert isinstance(ie, expected_ie)

# Generated at 2022-06-26 12:59:21.250527
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): #must be called from user code, not from library code
	assert TruTVIE._TEST['info_dict']['id'] == TruTVIE._TEST['info_dict']['id']
	assert TruTVIE._TEST['info_dict']['title'] == TruTVIE._TEST['info_dict']['title']
	assert TruTVIE._TEST['info_dict']['description'] == TruTVIE._TEST['info_dict']['description']

# Generated at 2022-06-26 12:59:21.927002
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-26 12:59:31.125252
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))', "VALID_URL didn't match"

# Generated at 2022-06-26 12:59:40.551972
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'