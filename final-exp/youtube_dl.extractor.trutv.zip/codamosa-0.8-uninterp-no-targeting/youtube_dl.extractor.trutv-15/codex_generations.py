

# Generated at 2022-06-22 08:29:01.831243
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Basic unit test for TruTVIE.
    """

    from ..jsinterp import JSInterpreter

    interp = JSInterpreter(
        "var a=_getToken('token','http://127.0.0.1','http://127.0.0.1','http://127.0.0.1')")

    assert interp.extract() == '4f4c3d7d31c58465dc5a5e1b3d3f906087c9b428'

# Generated at 2022-06-22 08:29:12.396784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test for constructor of class TruTVIE
    # Without setup
    # Expecting exception since TruTVIE inherits from TurnerBaseIE
    try:
        ttv = TruTVIE()
    except Exception:
        print('TruTVIE() exception passed!')
    else:
        raise AssertionError('TruTVIE() expected an exception to be thrown')
    # With setup, but wrong arguments
    # Expecting error since TruTVIE inherits from TurnerBaseIE
    ttv = TruTVIE()
    ttv.set_up(None, None, **{'password': 'password', 'username': 'username', 'site_name': 'truTV'})
    print(ttv._TEST_AUTH_TOKEN)

# Test extraction of TruTVIE

# Generated at 2022-06-22 08:29:17.181268
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html",{})
    assert("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html" == t.url)
    assert("Sunlight-Activated Flower" == t.title)

# Generated at 2022-06-22 08:29:17.921160
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert isinstance(TruTVIE(), TurnerBaseIE)

# Generated at 2022-06-22 08:29:18.463247
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:22.236425
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    Test = TruTVIE()
    # Test to get videoInfo
    videoInfo = Test._extract_ngtv_info(
        '62b6b0d7-e8b2-4ee9-b0e5-7d5b24b5f1a0')
    assert True


# Generated at 2022-06-22 08:29:32.174782
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    obj = TruTVIE()
    assert obj is not None
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert obj._TEST['url'] == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

# Generated at 2022-06-22 08:29:41.504944
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test for TruTVIE constructor"""

    trutv_urls = [
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',  # video URL
        'https://www.trutv.com/shows/the-carbonaro-effect/272217/the-carbonaro-effect-unbelievable-truth-about-the-election.html',  # episode URL
    ]

    for url in trutv_urls:
        trutvIE = TruTVIE(url)
        assert trutvIE
        return trutvIE


# Generated at 2022-06-22 08:29:45.990684
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE object.
    t = TruTVIE()

    # Check that the TruTVIE object is valid.
    assert TruTVIE._VALID_URL == t._VALID_URL
    assert TruTVIE._TEST == t._TEST

# Generated at 2022-06-22 08:29:47.255141
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()

# Generated at 2022-06-22 08:30:07.498571
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/full-episodes/247/Impractical-Jokers-S05E21.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/247')
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/247')


# Test for function _real_extract

# Generated at 2022-06-22 08:30:08.985880
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check for the TruTVIE class constructor
    assert TruTVIE



# Generated at 2022-06-22 08:30:10.509751
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert isinstance(ie, TruTVIE)

# Generated at 2022-06-22 08:30:11.978452
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE

# Generated at 2022-06-22 08:30:12.643510
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:15.608781
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test construction of TruTVIE
    try:
        TruTVIE()
    except NotImplementedError:
        print('NotImplementedError: TruTVIE()')


# Generated at 2022-06-22 08:30:24.363639
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        # Create instance of TruTVIE
        extractor = TruTVIE()
        assert extractor is not None
    except:
        print('Unit test for TruTVIE constructor failed')
        raise

    try:
        # Test URL
        url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

        # Test download()
        extractor.download(url)
        assert extractor is not None
    except:
        print('Unit test for TruTVIE.download() failed')
        raise
    finally:
        # De-allocate instance of TruTVIE
        extractor = None

# Test TruTVIE

# Generated at 2022-06-22 08:30:25.671761
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert True

# Generated at 2022-06-22 08:30:27.570102
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE()
    assert result

# Generated at 2022-06-22 08:30:39.334323
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.set_downloader(object)
    assert ie.get_downloader() == object
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:51.868358
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # check TruTVIE not raise exception
    TruTVIE()

# Generated at 2022-06-22 08:30:52.701424
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): 
    assert(True)

# Generated at 2022-06-22 08:30:54.089433
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE is not None

# Generated at 2022-06-22 08:30:57.192065
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:30:58.634021
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._VALID_URL
    ie.extract()

# Generated at 2022-06-22 08:31:00.845333
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-22 08:31:01.842150
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:31:02.428382
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:13.521491
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"

# Generated at 2022-06-22 08:31:20.395457
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-22 08:31:47.953759
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url1 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url2 = 'https://www.trutv.com/full-episodes/7434529/the-carbonaro-effect-s02e01-the-carbonaro-effect-s02e01-is-this-the-end.html'
    url3 = 'https://www.trutv.com/full-episodes/7434529'
    trutv = TruTVIE()
    trutv.extract(url1)
    trutv.extract(url2)
    trutv.extract(url3)

# Generated at 2022-06-22 08:31:58.313809
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test with URLs that should not match the regular expression
    assert TruTVIE.suitable('https://www.trutv.com/shows/full-episodes/') is False
    assert TruTVIE.suitable('https://www.trutv.com/shows/full-episodes') is False
    assert TruTVIE.suitable('https://www.trutv.com/full-episodes/') is False
    assert TruTVIE.suitable('https://www.trutv.com/full-episodes') is False
    assert TruTVIE.suitable('https://www.trutv.com/episodes/') is False
    assert TruTVIE.suitable('https://www.trutv.com/episodes') is False

# Generated at 2022-06-22 08:32:01.635732
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-22 08:32:04.527401
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Get class object
    truTVIE = TruTVIE()
    # Check if object is instance of class TruTVIE
    assert isinstance(truTVIE, TruTVIE)

# Generated at 2022-06-22 08:32:05.376131
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-22 08:32:06.300138
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE

# Generated at 2022-06-22 08:32:09.081278
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_json
    #assert False, "Unit test for constructor of class TruTVIE failed!"


# Generated at 2022-06-22 08:32:14.484418
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert t['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-22 08:32:19.140016
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE('http://www.trutv.com/shows/impractical-jokers/videos/murr-vs-sal-tattletales-at-the-park.html')
    except:
        assert False

# Generated at 2022-06-22 08:32:20.582657
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv


# Generated at 2022-06-22 08:32:57.947431
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:01.251954
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")


# Generated at 2022-06-22 08:33:04.171348
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.ie_key() == 'trutv'
    assert TruTVIE.ie_key(url='example.com/index.html') == 'trutv'

# Generated at 2022-06-22 08:33:11.139853
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for _real_extract
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttvIE = TruTVIE(None)
    info = ttvIE._extract_ngtv_info(
        'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', {}, {'site_name': 'truTV'})
    assert info.get('title') == 'Sunlight-Activated Flower'

# Generated at 2022-06-22 08:33:11.695205
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:12.314716
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:15.819532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    print(t)
    return t

if __name__ == "__main__":
    assert callable(test_TruTVIE)

# Generated at 2022-06-22 08:33:16.309187
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-22 08:33:18.548615
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:33:19.454163
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE

# Generated at 2022-06-22 08:34:54.002143
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE()._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:34:58.386963
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._build_ngtv_request_url("media_id") == "https://media.mtvnservices.com/pmt/e1/access/index.html?uri=mgid:arc:episode:trutv.com:media_id"
    assert t._download_ngtv_info("media_id") == {}

# Generated at 2022-06-22 08:34:59.015945
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:10.300752
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    construct_instance = TruTVIE()
    assert construct_instance._download_json(
        'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower',
        'sunlight-activated-flower')['info']['mediaId'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert TruTVIE._download_json('https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower', 'sunlight-activated-flower')['info']['mediaId']

# Generated at 2022-06-22 08:35:20.584456
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv:show:clip'
    assert ie.IE_DESC == 'Turner: truTV: show: clip'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:35:25.987357
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  print ("Testing TruTVIE")
  TruTVIE()._download_webpage(TruTVIE()._TEST['url'], None).encode('utf-8')

# Command line input to test one file
if __name__ == '__main__':
  test_TruTVIE()

# Generated at 2022-06-22 08:35:26.556665
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:27.485467
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-22 08:35:39.244832
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # initialize the object
    obj = TruTVIE()

    # test the _VALID_URL and _TEST
    obj._TEST = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-22 08:35:50.003368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test object creation
    object = TruTVIE('https://www.trutv.com/full-episodes/the-alaskan-bush-people/videos/alaskan-bush-people-episode-712.html')
    # Test properties
    assert(object._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')