

# Generated at 2022-06-22 08:29:02.031158
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # These tests are basic. To make sure that the TruTVIE class is being constructed with the correct
    # values. Also to verify that TruTVIE works properly, we just need to verify that
    # _download_json() and _extract_ngtv_info() work properly. We can do that by testing their
    # functions. Meaning, we do not need to test TruTVIE.

    test_object = TruTVIE()

    # Testing _VALID_URL
    assert test_object._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:05.490448
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  assert(TruTVIE is not None)

if __name__ == '__main__':
  test_TruTVIE()

# Generated at 2022-06-22 08:29:10.800750
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-22 08:29:11.846712
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
   globals()['TruTVIE']()

# Generated at 2022-06-22 08:29:12.436316
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:18.298331
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == "trutv"
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-22 08:29:20.674273
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        print(e)
        assert(False)
    finally:
        print('test passed')


# Generated at 2022-06-22 08:29:21.244202
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:22.567436
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().IE_NAME == "TruTV"

# Generated at 2022-06-22 08:29:23.439706
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-22 08:29:35.903112
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    success = True
    
    trutv = TruTVIE()
    
    assert(trutv is not None), "Failed to create TruTVIE object"
    assert(trutv.name == 'trutv:videomore'), "Failed to create TruTVIE object; wrong name"
    assert(trutv.IE_NAME == 'trutv'), "Failed to create TruTVIE object; wrong IE_NAME"
    
    return success



# Generated at 2022-06-22 08:29:37.303094
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-22 08:29:37.970486
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:39.481984
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract(TruTVIE()._TEST['url'])

# Generated at 2022-06-22 08:29:41.965381
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test that the class is constructed
    test_class_constructed = TruTVIE()
    assert test_class_constructed != None
# end of unit test

# Generated at 2022-06-22 08:29:43.242126
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-22 08:29:43.890494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:55.382778
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__module__ == "__main__"
    assert TruTVIE.__name__ == "TruTVIE"
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:03.397008
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE()
    assert ttvie.get_id() == 'truTV'
    assert ttvie.get_id('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == 'truTV'
    assert ttvie.get_id('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'trutv.com') == 'truTV'



# Generated at 2022-06-22 08:30:13.306773
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE.truTVIE() and TruTVIE.__init__()"""

    class TruTVIE_test(TruTVIE):
        pass

    assert TruTVIE_test.IE_NAME == "TruTV"
    assert TruTVIE_test.IE_DESC == "TruTV"
    assert TruTVIE.VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE.SUBTITLE_LANGS == ['en', 'es', 'pt']

    # for testing TruTVIE._download_webpage()
    instance_TruTVIE = TruTVIE()
    instance_TruTVIE._download_webpage('https://www.trutv.com')

# Generated at 2022-06-22 08:30:32.045451
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # sample url is: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    json_url = "https://api.trutv.com/v2/web/series/clip/" + "the-carbonaro-effect" + "/sunlight-activated-flower"
    print('json_url=', json_url)
    service = TruTVIE()
    data = service._download_json(json_url, 'sunlight-activated-flower')
    # service._download_json(json_url, 'sunlight-activated-flower')
    print('data=', data)


# unit test for TruTVIE._real_extract()

# Generated at 2022-06-22 08:30:39.081933
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_object = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert test_object.url == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert test_object._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:30:40.399985
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie is not None

# Generated at 2022-06-22 08:30:41.853966
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TruTVIE", "1", "2", "3")

# Generated at 2022-06-22 08:30:42.375044
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:48.033124
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_TruTVIE = TruTVIE()
    result = test_TruTVIE._real_extract(url)
    assert result['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert result['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    assert result['title'] == 'Sunlight-Activated Flower'

# Generated at 2022-06-22 08:30:59.140267
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    This unit test is for the TruTVIE class to make sure that the constructor works
    """
    trutv_object = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert(trutv_object._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-22 08:31:01.362665
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print (TruTVIE())

# Generated at 2022-06-22 08:31:01.994437
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:02.973692
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:31:27.991758
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    # check if the URL matches
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:31:32.079962
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Test constructor of class TruTVIE
    '''
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE(url)


# Generated at 2022-06-22 08:31:39.674127
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Tested URL: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    # Tested URL: https://www.trutv.com/full-episodes/47807/the-carbonaro-effect-season-1-ep-1-what-a-revolting-development-this-is.html
    # Tested URL: https://www.trutv.com/full-episodes/48125/the-carbonaro-effect-season-1-ep-8.html
    # Tested URL: https://www.trutv.com/full-episodes/48125/the-carbonaro-effect-season-1-ep-8

    from ..compat import compat_str

    # Creates TruTVIE object
    ie = TruTVIE()

   

# Generated at 2022-06-22 08:31:41.760517
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-22 08:31:42.375459
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:45.249872
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    # Tested results but not recorded here due to frequent changes,
    # see https://github.com/rg3/youtube-dl/blob/master/test/test_TruTVIE.py


# Generated at 2022-06-22 08:31:54.361567
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert(trutv.name == 'trutv')
    assert(trutv.ie_key() == 'trutv')
    assert(trutv._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))')

# Generated at 2022-06-22 08:31:58.915988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.download(TruTVIE._TEST['url'])
    assert ie.get_info(TruTVIE._TEST['url'])['id'] == TruTVIE._TEST['info_dict']['id']

# Generated at 2022-06-22 08:32:10.988445
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activatad-flower.html")
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:32:15.147307
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert TruTVIE._VALID_URL == trutv._VALID_URL
    assert TruTVIE._TEST == trutv._TEST
    assert TruTVIE._TESTS == trutv._TESTS

# Generated at 2022-06-22 08:32:53.535383
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    e = TruTVIE()
    assert e

# Generated at 2022-06-22 08:32:58.924801
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

    assert ie.IE_KEY == 'trutv'
    assert ie.SUCCEEDED_CACHE_POLICY == 'none'
    assert ie.VALID_URL == TruTVIE._VALID_URL
    assert ie.TEST == TruTVIE._TEST
    assert ie.__name__ == 'TruTVIE'
    assert ie.__doc__

# Generated at 2022-06-22 08:33:01.843931
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()
    assert i

# Unit test to check if TruTVIE extractor raise an exception given a wrong URL

# Generated at 2022-06-22 08:33:11.606116
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    params = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }


# Generated at 2022-06-22 08:33:18.000854
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE({}, None)._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:33:26.307784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an object of TruTVIE
    trutv_ie = TruTVIE()

    # Build and return a test result based on the test case data
    return test_result_for_class(trutv_ie)

if __name__ == '__main__':
    # Test the TruTVIE class and build test result
    test_result = test_TruTVIE()
    print(test_result.plain_text())

    # Output the test result
    sys.exit(0 if test_result.wasSuccessful() else 1)

# Generated at 2022-06-22 08:33:30.337367
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE.__init__()
        A unit test.
    """
    # Unit test for constructor of class TruTVIE
    return TruTVIE(TurnerBaseIE._downloader)

# Generated at 2022-06-22 08:33:31.311168
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-22 08:33:35.938424
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # trutv_test = TruTVIE(test_url)
    # trutv_test.extract()
    pass

# Generated at 2022-06-22 08:33:39.786736
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    URL = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

    TruTVIE(URL).test()

# Generated at 2022-06-22 08:35:16.575136
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except TypeError:
        pass

# Generated at 2022-06-22 08:35:18.670269
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'

# Generated at 2022-06-22 08:35:20.079625
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make sure that class TruTVIE can be created
    TruTVIE()

# Generated at 2022-06-22 08:35:25.388470
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    This unit test tests if is able to be instantiated.
    """
    from youtube_dl.extractor.trutv import TruTVIE
    try:
        TruTVIE(None, None)
    except TypeError:
        return False
    return True


# Generated at 2022-06-22 08:35:31.865826
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TEST_URL = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    t = TruTVIE()
    try:
        result = t._real_extract(TEST_URL)
    except Exception as e:
        print(e)
    else:
        print(result)

test_TruTVIE()


# Generated at 2022-06-22 08:35:41.751955
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  #def __init__(self, *args, **kwargs):
  #def _real_extract(self, url):
  #def _extract_ngtv_info(self, media_id, check_auth, info, headers=None):
  info = TruTVIE()._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-22 08:35:51.537144
# Unit test for constructor of class TruTVIE
def test_TruTVIE():   
    ttvie = TruTVIE()
    assert ttvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:36:01.615415
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-22 08:36:10.132570
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import itertools
    url_values = ['https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
                  'https://www.trutv.com/shows/the-carbonaro-effect/videos/magical-time-machine.html',
                  'https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html',
                  'https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/magical-time-machine.html',
                  'https://www.trutv.com/shows/the-carbonaro-effect/09914']

# Generated at 2022-06-22 08:36:11.529066
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert isinstance(t,TruTVIE)