

# Generated at 2022-06-22 08:28:54.172090
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  TruTVIE()

# Generated at 2022-06-22 08:28:55.445867
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert a

# Generated at 2022-06-22 08:28:56.098211
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    assert(True)

# Generated at 2022-06-22 08:28:57.094648
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:28:58.201692
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.test() # For snippet

# Generated at 2022-06-22 08:28:58.769319
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-22 08:29:06.874652
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._extract_ngtv_info("bob", {
        'title': "test title",
        'description': "test description",
        'series': "test series",
        'season_number': 1,
        'episode_number': 2,
        'timestamp': "test timestamp",
        'thumbnails': ["test thumbnail"]}, {
        'url': "test url",
        'site_name': "test site_name",
        'auth_required': True})



# Generated at 2022-06-22 08:29:08.026682
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE


# Generated at 2022-06-22 08:29:15.515817
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing for TruTVIE
    class_ = TruTVIE
    # Invalid URL
    assert class_._match_id('https://www.trutv.com/shows/') is None
    # Valid URL
    assert class_._match_id('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-22 08:29:24.666583
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_object = TruTVIE()
    assert(test_object._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-22 08:29:31.480905
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie is not None

# Generated at 2022-06-22 08:29:37.863123
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test open url for TruTVIE website
    """
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:40.122002
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE(TurnerBaseIE())
    except TypeError:
        assert True

# Generated at 2022-06-22 08:29:52.144112
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tt = TruTVIE()

# Generated at 2022-06-22 08:29:53.217226
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initializing the class object
    TruTVIE()

# Generated at 2022-06-22 08:29:57.904587
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Checks if the class has the correct constructor
    # Might be worth creating a class for all the test cases
    trutv_ie = TruTVIE()
    # Checks if the super class is initialised
    assert trutv_ie.__class__.__bases__[0].__name__ == "TurnerBaseIE"

test_TruTVIE()

# Generated at 2022-06-22 08:29:58.824684
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:59.630229
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:10.445745
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Testing TruTVIE constructor"""
    obj = TruTVIE()
    assert obj.geturl() == 'https://www.trutv.com/'
    assert obj.gettitle() == 'TruTV'
    assert obj.get_site() == 'truTV'
    assert obj.ismedia()
    assert obj.ismobile()
    assert obj.istv()
    assert obj.getformat() == 'mp4'
    assert obj.getquality() == '480p'
    assert obj.getsource() == 'Turner Broadcasting'
    assert obj.getduration() == '00:00'
    assert obj.geturl() == 'https://www.trutv.com/'
    assert obj.getid() == ''
    assert obj.getauth() == 0

# Generated at 2022-06-22 08:30:22.070882
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for TruTVIE"""
    # Assert URL
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Assert test dict

# Generated at 2022-06-22 08:30:39.104280
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Constructor of class TruTVIE
    truTV = TruTVIE()

    #Check variable _VALID_URL
    #It must be formed by a regular expression that contains the scheme,
    # a subdomain and the domain of the website.
    #The path must start with '/shows/' and finish with a '/videos/'
    # that must be followed by either a word or a number
    # and a '.html'. The final extension is optional
    assert(truTV._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

   

# Generated at 2022-06-22 08:30:42.373829
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE = TruTVIE()
    # Download a video for testing
    TruTVIE.download('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:30:44.214369
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-22 08:30:44.703449
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:46.114257
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-22 08:30:54.680303
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:56.639118
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE._TEST

# Generated at 2022-06-22 08:30:58.880191
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Arrange
    ie = TruTVIE()

    # Act
    ie.extract()

    # Assert - No error is raised
    assert True

# Generated at 2022-06-22 08:31:00.696421
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:31:04.553750
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Constructor of TruTVIE")
    turns = TruTVIE()
    if (turns.IE_NAME) == "truTV":
        print("Constructor of FunimationIE successful"),
    else:
        print("Constructor of FunimationIE failed")


# Generated at 2022-06-22 08:31:26.743295
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE.__init__
    trutv = TruTVIE()
    assert(isinstance(trutv, TruTVIE))


# Generated at 2022-06-22 08:31:29.387590
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        assert True
    except:
        assert False, "Unable to create object for class TruTVIE"


# Generated at 2022-06-22 08:31:30.039854
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:31.355449
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE without a valid url."""
    TruTVIE()

# Generated at 2022-06-22 08:31:31.947040
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-22 08:31:40.844726
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutvie = TruTVIE()
    assert(trutvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-22 08:31:49.922259
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # TruTVIE does not have this method, so it is expected to throw an error
    def _real_initialize(self) -> None:
        raise NotImplementedError

    TruTVIE._real_initialize = _real_initialize
    try:
        ttv = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
        assert ttv
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-22 08:31:50.377355
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:51.397758
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj is not None

# Generated at 2022-06-22 08:31:59.823680
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Set up environment
    import os.path
    import sys
    from importlib import reload
    from unittest import TestCase, mock

    fake_key = 'example_key'
    fake_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    fake_video_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

    # Add current dir to path
    current_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(current_dir)

    # Import TruTVIE class
    from . import trutv
    reload(trutv)

    # Test TruTVIE constructor
    ie = tr

# Generated at 2022-06-22 08:32:41.854799
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Ensure that class constructor is called correctly
    """
    TruTVIE()

# Generated at 2022-06-22 08:32:46.134706
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE()
    trutv_ie._extract_url(url)

# Generated at 2022-06-22 08:32:47.335290
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:32:48.296551
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-22 08:32:49.779237
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        return False
    return True

# Generated at 2022-06-22 08:32:55.568775
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # What video to test?
    video_url = 'https://www.trutv.com/shows/tacoma-fd/videos/tacoma-fd-pilot-episode.html'
    # I think this is about the same as making a new instance of TruTVIE and then calling test_video_info
    # But that's too much work
    TruTVIE()._real_extract(video_url)

# Generated at 2022-06-22 08:32:56.931028
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL


# Generated at 2022-06-22 08:33:00.651106
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(test_url)
    #TruTVIE(test_url, True)

# Generated at 2022-06-22 08:33:03.500001
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit tests for the TruTVIE function.
    """
    # Put your unit tests for this function in here
    return True

# Generated at 2022-06-22 08:33:05.930152
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_media_extractor import _test_media_extractor
    _test_media_extractor(TruTVIE)

# Generated at 2022-06-22 08:34:43.896525
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv.ie_key() == 'trutv.com'



# Generated at 2022-06-22 08:34:44.471152
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:34:46.772962
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test for constructor
    TruTVIE()


# Generated at 2022-06-22 08:34:50.067019
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    trutv_ie = TruTVIE("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert trutv_ie

# Generated at 2022-06-22 08:34:59.054196
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE
    from . import TruTVIE
    # Test TruTVIE
    # TODO
    # TurnBaseIE
    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    assert ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    # _real_extract

# Generated at 2022-06-22 08:35:04.859807
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
	truTVIE = TruTVIE()
	assert isinstance(truTVIE, TruTVIE)
	assert isinstance(truTVIE, TurnerBaseIE)


# Generated at 2022-06-22 08:35:06.240025
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .common import try_get
    # Smoke test
    TruTVIE()

# Generated at 2022-06-22 08:35:15.609856
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'truTV'
    assert ie.IE_DESC == 'truTV.com'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:35:18.066060
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE() # create a TurnerBaseIE object


# Generated at 2022-06-22 08:35:18.699727
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()