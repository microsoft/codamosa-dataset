

# Generated at 2022-06-22 08:28:55.061765
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ydl = TruTVIE()

# Generated at 2022-06-22 08:28:56.139818
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-22 08:28:56.712509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:29:08.111158
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    def _test_channel(channel_name, channel_id):
        channel_url = (
            "https://www.trutv.com/shows/%s/videos/beam-me-up-scotty.html" %
            channel_name)
        video_url = "https://www.trutv.com/shows/%s/videos/beam-me-up-scotty.html" % channel_name
        channel_video_id = "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
        channel_clip_slug = "beam-me-up-scotty"
        channel_series_slug = channel_name

# Generated at 2022-06-22 08:29:15.628622
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Given the URL for https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    # An instance of class TruTVIE() should be created
    ie = TruTVIE()
    # Given the URL is recognised by TruTVIE()
    assert ie._extract_url(url)

# Generated at 2022-06-22 08:29:17.429691
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._downloader.params['noplaylist']

# Generated at 2022-06-22 08:29:21.661617
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit tests for constructor
    t = TruTVIE('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    assert(t.video_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

# Generated at 2022-06-22 08:29:22.604521
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor = TruTVIE(None)

# Generated at 2022-06-22 08:29:24.715937
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TurnerBaseIE())._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-22 08:29:27.685940
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    r = TurnerBaseIE()
    my_ie = TruTVIE()
    assert my_ie is not None

# Generated at 2022-06-22 08:29:44.169918
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .turner import TurnerBaseIE
    from ..utils import (
        extract_attributes,
        parse_iso8601,
    )
    from ..compat import compat_etree_fromstring
    import re
    import time

    start = time.time()

    # Object initialization
    trutv = TruTVIE()

    # Test of method _extract_ngtv_info
    ngtv_url = 'http://link.theplatform.com/s/ngtv/TruTv_App_Tablet_Prod/media/guid/2409325215/856964?mbr=true&manifest=m3u'
    display_id = '856964'
    query = {
        'mbr': 'true',
        'manifest': 'm3u',
    }
    video_

# Generated at 2022-06-22 08:29:45.129864
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:51.885442
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE.TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:56.089823
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #    this test is for checking the constructor of class TruTVIE
    
    #   init constructor TruTVIE
    ie = TruTVIE()
    #   checking whether ie is instance of TruTVIE
    assert isinstance(ie, TruTVIE)



# Generated at 2022-06-22 08:29:57.840806
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor = TruTVIE()
    assert constructor is not None



# Generated at 2022-06-22 08:30:00.849813
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE"""
    ie = TruTVIE()
    ie.match(TruTVIE._VALID_URL)


# Generated at 2022-06-22 08:30:03.650489
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:30:06.769337
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE(TurnerBaseIE._downloader)
        assert(True)
    except:
        assert(False)

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-22 08:30:13.312274
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:15.161523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None)._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-22 08:30:27.250149
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:30:27.978184
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:38.923107
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test for case when video_id is a parameter
    valid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # the TruTVIE class instantiated below is a child class of InfoExtractor in youtube_dl/extractor/common.py
    trutv_ie = TruTVIE()
    assert trutv_ie.suitable(valid_url)
    res = trutv_ie.extract(valid_url)
    # check that TruTV API is being called to get the JSON file
    assert res['url'] == 'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower'

# Generated at 2022-06-22 08:30:47.480200
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import os
    import pdb
    try:
        from urllib.request import urlretrieve 
    except ImportError: 
        from urllib import urlretrieve

    def reporthook(blocknum, bs, size):
        print(blocknum * bs, size) # blocknum: 0
        if blocknum * bs >= size:
            pdb.set_trace()

    url = TruTVIE._TEST['url']
    filename_prefix = TruTVIE._TEST['info_dict']['id']
    urllist = []

# Generated at 2022-06-22 08:30:50.598473
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html");

# Generated at 2022-06-22 08:30:52.081211
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create instance of TurnerBaseIE
    trutv = TruTVIE()
    assert(trutv)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:30:58.682917
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:31:00.477660
# Unit test for constructor of class TruTVIE
def test_TruTVIE(): 
    TruTVIE().assert_valid()

# Generated at 2022-06-22 08:31:01.490227
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

# Generated at 2022-06-22 08:31:02.876672
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL

# Generated at 2022-06-22 08:31:22.372237
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:23.079421
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:23.858102
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE("ThuTVIE")

# Generated at 2022-06-22 08:31:26.010532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SUCCESS == True

# Generated at 2022-06-22 08:31:27.535520
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:33.216596
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Method for testing constructor of TruTVIE class """
    # Sample url for test
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Expecting to get new instance of class TruTVIE
    ttvie = TruTVIE()
    assert isinstance(ttvie, TruTVIE)
    ttvie._real_extract(test_url)



# Generated at 2022-06-22 08:31:33.781548
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert True

# Generated at 2022-06-22 08:31:34.865994
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t is not None


# Generated at 2022-06-22 08:31:35.755140
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:40.577938
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    class_ = TruTVIE
    assert class_ == TruTVIE, "%s != TruTVIE" % class_
    assert class_ is not TruTVIE, "%s == TruTVIE" % class_
    assert TruTVIE is TruTVIE, "Testing constructor of class TruTVIE != TruTVIE"
    assert TruTVIE is TruTVIE, "Testing constructor of class TruTVIE != TruTVIE"
    assert TruTVIE is TruTVIE

# Generated at 2022-06-22 08:32:17.580371
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-22 08:32:18.838753
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-22 08:32:21.619217
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == TruTVIE._VALID_URL
    assert ie._TEST == TruTVIE._TEST

# Generated at 2022-06-22 08:32:26.507085
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE
    constructor = TruTVIE
    # video_id parameter is not optional: TruTVIE requires video_id to be present
    # Pass in truthy value as video_id parameter
    truTVIE = constructor(True)
    # Check that instance of TruTVIE has been created
    assert truTVIE is not None


# Generated at 2022-06-22 08:32:27.268632
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:29.075568
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
        """

        :return: void
        """
        TruTVIE()

# Generated at 2022-06-22 08:32:30.168964
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:31.636161
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._downloader.params["forceduration"] == "yes"

# Generated at 2022-06-22 08:32:40.072830
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST['info_dict'] == {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
    }


# Generated at 2022-06-22 08:32:43.113296
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:34:04.638013
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-22 08:34:05.587363
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE != None

# Generated at 2022-06-22 08:34:09.004695
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert(obj is not None)
    assert(obj.turner_id_pattern is not None)
    assert(obj.turner_info_url is not None)
    assert(obj.turner_key_pattern is not None)
    assert(obj.turner_key_url is not None)
    assert(obj.turner_page_pattern is not None)
    assert(obj.turner_page_url is not None)
    assert(obj.turner_program_pattern is not None)
    assert(obj.turner_url_pattern is not None)

# Generated at 2022-06-22 08:34:20.585006
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    IE_CLASS = TruTVIE
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    video_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    series_slug = 'the-carbonaro-effect'
    clip_slug = 'sunlight-activated-flower'
    trutv_ie = IE_CLASS(url)
    assert (trutv_ie.get_id() == video_id)
    assert (trutv_ie.get_series_slug() == series_slug)
    assert (trutv_ie.get_clip_slug() == clip_slug)

# DO NOT SAVE UNIT TESTS

# Generated at 2022-06-22 08:34:21.793699
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:34:23.837572
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-22 08:34:24.642938
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.suite()

# Generated at 2022-06-22 08:34:25.606260
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()



# Generated at 2022-06-22 08:34:27.716513
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    temp_ie=TruTVIE()
    assert isinstance(temp_ie, TruTVIE)


# Generated at 2022-06-22 08:34:32.028753
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    if 1:
        x.init()
    else:
        # Show constructor argument types
        x.init(whatever=None, otherthing=None)


# Generated at 2022-06-22 08:38:09.828123
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test_TruTVIE = TruTVIE()
    # print(test_TruTVIE)
    # print('\n')
    # print('test_TruTVIE has data : ' + str(test_TruTVIE.test()))
    print('This is a constructor for class TruTVIE')

# Generated at 2022-06-22 08:38:11.930550
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:38:12.897726
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST

# Generated at 2022-06-22 08:38:21.423210
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test if the TruTV constructor works correctly
    """
    ttvIE = TruTVIE()
    assert ttvIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert ttvIE.IE_NAME == 'trutv'
    assert ttvIE.IE_DESC == 'TruTV'

# Generated at 2022-06-22 08:38:24.314547
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()
    assert isinstance(truTVIE, TruTVIE)

# Generated at 2022-06-22 08:38:28.587128
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	print('Testing TruTVIE Constructor')
	truTVIE = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
	print('TruTVIE object has been created with url: ' + truTVIE.url)

# test_TruTVIE()

# Generated at 2022-06-22 08:38:36.503002
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE.new('truTV')
    assert t.name == 'truTV'
    assert 'truTV' in t.ie_key()
    assert 'TruTV' in t.ie_key()
    assert t.ie_key() in TruTVIE._ies
    assert t.suitable(TruTVIE._VALID_URL)
    assert not t.suitable('http://example.com')

# Generated at 2022-06-22 08:38:48.044255
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert TruTVIE._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-22 08:38:56.096789
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    videoInfo = TruTVIE('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'Sunlight-Activated Flower')

    assert(videoInfo.video_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    assert(videoInfo.video_url == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert(videoInfo.video_title == 'Sunlight-Activated Flower')
