

# Generated at 2022-06-22 08:28:56.608436
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TruTVIE)

# Test TruTVIE by running the testing code
test_TruTVIE()

# Generated at 2022-06-22 08:29:04.847501
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.ie_key() == 'trutv'
    assert TruTVIE.ie_key() in ie_key()
    assert TruTVIE.ie_key() in ie_key(TruTVIE)
    assert TruTVIE.ie_key() in TRUTVIE
    assert TruTVIE.ie_key() in TRUTVIE.keys()
    assert 'TruTV' in TRUTVIE.values()
    assert 'TruTV' in TRUTVIE.items()

# Generated at 2022-06-22 08:29:06.761666
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert isinstance(x, TruTVIE)

# unit test for TruTVIE._real_extract

# Generated at 2022-06-22 08:29:17.947819
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # pylint: disable=protected-access
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # pylint: disable=no-member
    assert TruTVIE.IE_NAME == 'trutv'
    # pylint: disable=no-member
    assert TruTVIE.IE_DESC == 'truTV Videos'

# Generated at 2022-06-22 08:29:18.503468
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:20.673087
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        data = TruTVIE()
        return data
    except AttributeError:
        return True
    # test_TruTVIE()

# Generated at 2022-06-22 08:29:31.993327
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    # Test for video-id (episode)
    url = 'https://www.trutv.com/shows/greatest-ever/videos/legendary-comebacks.html'
    url_string = url.split("/")
    url_list = url_string[7].split(".")
    trutv_ie = TruTVIE()
    expected_result = [url_list[0], None, url_string[6]]
    actual_result = re.match(trutv_ie._VALID_URL, url).groups()
    assert expected_result == actual_result

    # Test for clip (clip)
    url = 'https://www.trutv.com/shows/greatest-ever/videos/legendary-comebacks.html'

# Generated at 2022-06-22 08:29:37.122612
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    global my_TruTVIE
    global test_url
    test_TruTVIE = TruTVIE()
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    print("test TruTVIE constructed")


# Generated at 2022-06-22 08:29:37.737857
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-22 08:29:41.342597
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing constructor
    trutvIE = TruTVIE()
    assert trutvIE is not None
    # Testing method _real_extract
    trutvIE._real_extract(url)

# Generated at 2022-06-22 08:29:56.470241
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().ie_key() == 'trutv'
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE()._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:29:57.214484
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:00.597131
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.suitable(TruTVIE._TEST['url']) is True


# Generated at 2022-06-22 08:30:02.146184
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    TruTVIE()

# Generated at 2022-06-22 08:30:07.793745
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:15.590424
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:24.988432
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    Test_TruTVIE = TruTVIE()
    import re
    assert Test_TruTVIE._VALID_URL == re.compile(r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-22 08:30:31.807072
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #TruTVIE(TurnerBaseIE(), 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE(TurnerBaseIE(), 'https://www.trutv.com/full-episodes/1429399/the-carbonaro-effect-the-carbonaro-effect-official-trailer--truTV-1.html')

# Generated at 2022-06-22 08:30:43.608386
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTV = TruTVIE()
    assert TruTV._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:44.138352
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:54.304484
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-22 08:30:55.281981
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE == TruTVIE('TruTV')

# Generated at 2022-06-22 08:30:58.055391
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_tv = TruTVIE()

# Generated at 2022-06-22 08:31:08.566051
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-22 08:31:10.106817
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SUCCESS == True

# Generated at 2022-06-22 08:31:15.214002
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # URL of a page that has an embedded video
    url = 'http://www.trutv.com/shows/upload/videos/bad-bunnies.html'
    trutv = TruTVIE()
    assert trutv._VALID_URL == TruTVIE._VALID_URL
    assert trutv.extract(url)

# Generated at 2022-06-22 08:31:22.453386
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().ie_key() == 'TruTV'
    assert TruTVIE.ie_key() == 'TruTV'
    assert TruTVIE().suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE().extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') != None

# Generated at 2022-06-22 08:31:23.555559
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
#TODO

# Generated at 2022-06-22 08:31:32.754221
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    url = "http://www.trutv.com/shows/the-first-48/videos/the-first-48-the-princess-and-the-priest-full-episode.html"
    clip = TruTVIE()._real_extract(url)
    assert clip['title'] == "The Princess and the Priest"
    assert clip['ext'] == "mp4"
    assert clip['id'] == "25a8e8eaa91f941d9a51326c8e1d35d7e55b08e5"
    assert clip['timestamp'] == 1520947800000

# Generated at 2022-06-22 08:31:33.221429
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:57.454569
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    print("Turner Access Token: ", t._access_token)
    t._extract_ngtv_info("f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1", {}, {})

# Generated at 2022-06-22 08:31:59.180289
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'trutv'



# Generated at 2022-06-22 08:32:00.962746
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # check if TruTVIE object is created successfully
    assert TruTVIE() is not None

# Generated at 2022-06-22 08:32:03.018672
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        return False
    else:
        return True

# Generated at 2022-06-22 08:32:06.726239
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception as e:
        print ("Failed to initialize TruTVIE")
        raise e
    else:
        print ("TruTVIE initialization is successful")


# Generated at 2022-06-22 08:32:16.053121
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:32:17.537932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert isinstance(trutv_ie, TruTVIE)

# Generated at 2022-06-22 08:32:18.186568
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:19.662785
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE(None, None)
    assert x

# Generated at 2022-06-22 08:32:20.325281
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:59.432270
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.test()

# Generated at 2022-06-22 08:33:01.538105
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTVIE

    assert TruTVIE.__doc__ != None

# Generated at 2022-06-22 08:33:07.426310
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test 1
    ie_result_1 = TruTVIE()
    assert ie_result_1.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == True
    # Test 2
    ie_result_2 = TruTVIE()
    assert ie_result_2.suitable('not a real url at all') == False

# Generated at 2022-06-22 08:33:08.363352
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:09.248187
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:15.905494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make TruTVIE object
    trutv_ie = TruTVIE()
    print(trutv_ie)
    # unit test for TruTVIE._real_extract()
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # call TruTVIE._real_extract()
    trutv_ie._real_extract(test_url)

# Call test
test_TruTVIE()

# Generated at 2022-06-22 08:33:16.523124
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  assert TruTVIE()

# Generated at 2022-06-22 08:33:20.672988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    cls = TruTVIE()
    assert cls._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:33:32.058447
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTV_test = TruTVIE()

    TruTV_test.ie_key = 'TruTV'
    TruTV_test.host = 'trutv.com'
    TruTV_test.slug = 'trueV'
    TruTV_test.mso_id = '7068'
    TruTV_test.proxy_service = 'hls'
    TruTV_test.session_token_service = 'trutv2'
    TruTV_test.app_name = 'trutv-web'
    TruTV_test.app_version = '2.0.0'

    assert TruTV_test.ie_key == 'TruTV'
    assert TruTV_test.host == 'trutv.com'
    assert TruTV_test.slug == 'trueV'

# Generated at 2022-06-22 08:33:32.936861
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:12.515876
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    trutv_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:35:15.640377
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	truTV = TruTVIE()
	truTV.extract(url)

# Generated at 2022-06-22 08:35:19.642645
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    obj = TruTVIE(url)
    assert obj.url == url

# Generated at 2022-06-22 08:35:20.272792
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:20.881685
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:25.349512
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        print('TruTVIE constructor passed')
    except Exception as e:
        print('Exception in TruTVIE constructor: {}'.format(e))


# Generated at 2022-06-22 08:35:27.352016
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-22 08:35:39.148390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Initialize a TruTVIE instance
    trutv_instance = TruTVIE()

    # Check if instance is correctly initialized
    assert isinstance(trutv_instance, TruTVIE)

    # Check if instance is correctly initialized
    assert trutv_instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:35:40.861944
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:43.341164
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    print(ie._VALID_URL)
    print(ie._TEST)

test_TruTVIE()