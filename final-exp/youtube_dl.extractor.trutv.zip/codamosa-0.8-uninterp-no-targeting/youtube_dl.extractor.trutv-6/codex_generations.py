

# Generated at 2022-06-22 08:28:57.632777
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-22 08:29:00.747332
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TruTVIE)

test_TruTVIE()

# Generated at 2022-06-22 08:29:01.426326
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-22 08:29:02.404841
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:13.761413
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    TEST_CASE_1: This test case tests when the argument for TruTVIE's constructor is a valid URL
    """
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

# Generated at 2022-06-22 08:29:20.584884
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL is not None
    assert trutv._TEST is not None
    assert trutv._TESTS is None
    assert trutv.IE_NAME == 'trutv:trutv'
    assert trutv.ie_key() == 'TruTV'
    assert trutv.IE_DESC == 'truTV'


# Generated at 2022-06-22 08:29:22.228693
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL is not None
    assert TruTVIE._TEST is not None

# Generated at 2022-06-22 08:29:23.698081
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:29:25.217293
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	trutv_ie = TruTVIE();
	trutv_ie.get_author();


# Generated at 2022-06-22 08:29:32.695315
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    testcase = TruTVIE()
    print('test_TruTVIE: ' + testcase._VALID_URL)
    print('test_TruTVIE: ' + testcase._TEST['url'])
    print('test_TruTVIE: ' + testcase._TEST['info_dict']['id'])
    print('test_TruTVIE: ' + testcase._TEST['info_dict']['ext'])
    print('test_TruTVIE: ' + testcase._TEST['info_dict']['title'])
    print('test_TruTVIE: ' + testcase._TEST['info_dict']['description'])
    return


# Generated at 2022-06-22 08:29:38.338973
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test constructor
    TruTVIE()

# Generated at 2022-06-22 08:29:49.468093
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    IE = TruTVIE
    IE = IE({
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    })
    return True

# Generated at 2022-06-22 08:29:58.122593
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    match = TruTVIE._VALID_URL.match(url)
    assert match is not None
    assert match.group('series_slug') == 'the-carbonaro-effect'
    assert match.group('clip_slug') == 'sunlight-activated-flower'
    url = 'https://www.trutv.com/full-episodes/1327/the-carbonaro-effect/videos/the-carbonaro-effect-s2-the-carbonaro-effect-s2-megashark.html'
    match = TruTVIE._VALID_URL.match(url)
    assert match is not None

# Generated at 2022-06-22 08:30:03.916000
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/hack-my-life/full-episodes/6-put-a-ring-on-it/videos/hack-my-life-full-episode--bigfoot-bell.html')
    assert TruTVIE.suitable('https://www.trutv.com/shows/tacoma-fd/full-episodes/pilot/videos/tacoma-fd-full-episode--losing-my-religion.html')

# Generated at 2022-06-22 08:30:15.852029
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-22 08:30:17.465956
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    check_TruTVIE_constructor = TruTVIE(TurnerBaseIE())

# Generated at 2022-06-22 08:30:24.762109
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case 0
    trutv_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_case = TruTVIE._TEST
    result = TruTVIE._real_extract(TruTVIE(), trutv_url)
    assert test_case['url'] == trutv_url
    assert test_case['info_dict']['title'] == result['title']
    assert test_case['info_dict']['id'] == result['id']
    assert test_case['info_dict']['description'] == result['description']

# Generated at 2022-06-22 08:30:25.299442
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:27.569759
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# test_TruTVIE()

# Generated at 2022-06-22 08:30:31.446963
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE(TurnerBaseIE._downloader, 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert isinstance(obj, TruTVIE)

# Generated at 2022-06-22 08:30:42.213442
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:30:42.757036
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:44.255686
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert(trutv != None)


# Generated at 2022-06-22 08:30:45.651988
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    parser = TruTVIE()
    expected = TruTVIE
    assert parser.__class__ == expected


# Generated at 2022-06-22 08:30:49.480408
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-22 08:30:54.576619
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    if not TruTVIE().suitable("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"):
        raise ValueError("Invalid URL.")

# Generated at 2022-06-22 08:30:55.145221
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:57.560396
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    with pytest.raises(TypeError):
        TruTVIE()


# Generated at 2022-06-22 08:31:07.532276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert t.url == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert t.display_id == "sunlight-activated-flower"
    assert t.series_slug == "the-carbonaro-effect"
    assert t.clip_slug == "sunlight-activated-flower"
    assert t.video_id == None

# Generated at 2022-06-22 08:31:08.050205
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:29.853100
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvIE=TruTVIE()
    print("Test TruTVIE: ",ttvIE)


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:31:31.987509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:31:32.543230
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:33.102597
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE

# Generated at 2022-06-22 08:31:35.966359
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    input_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert TruTVIE(input_url)._VALID_URL == TruTVIE._VALID_URL



# Generated at 2022-06-22 08:31:37.536700
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check TruTVIE class is initialized properly 
    assert TruTVIE.__name__ == 'TruTVIE'

# Generated at 2022-06-22 08:31:45.570751
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    info = TruTVIE()._call_api('f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')
    assert info['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert info['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert info['site_name'] == 'truTV'
    assert info['auth_required'] == False

# Generated at 2022-06-22 08:31:46.141702
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:48.324528
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        e = sys.exc_info()[0]
        print(e)
        assert False


# Generated at 2022-06-22 08:31:51.349303
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert TruTVIE.IE_NAME == trutv.ie_key()
    # check for constructor that does not take the parameter 'url'
    assert TruTVIE(url=None) is trutv

# Generated at 2022-06-22 08:32:31.181853
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.valid()
    assert t.suitable(TruTVIE._TEST['url'])


# Generated at 2022-06-22 08:32:35.206872
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    class Test_TruTVIE(unittest.TestCase):
        def test_construction(self):
            TruTVIE()

    unittest.main()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:32:39.259877
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert m.get_valid_url() == "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"


# Generated at 2022-06-22 08:32:41.777731
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	s = TruTVIE()

# Generated at 2022-06-22 08:32:42.261207
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    True

# Generated at 2022-06-22 08:32:42.809077
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:45.652075
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	"""
	TODO: Test if TruTVIE works at all
	"""
	instance = TruTVIE()
	instance.test()

# Generated at 2022-06-22 08:32:47.690244
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        print('Failed to instantiate TruTVIE()')
        raise

# Generated at 2022-06-22 08:32:48.976457
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Instantiate object
    obj = TruTVIE()

# Generated at 2022-06-22 08:32:54.405214
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:34:24.030513
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE
    except NameError:
        assert False, 'Cannot import class TruTVIE'
    else:
        assert True

# Generated at 2022-06-22 08:34:26.033246
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    # TODO: Add test assertions here
    # unit test for TruTVIE._real_extract
    assert callable(getattr(instance, '_real_extract', None))

# Generated at 2022-06-22 08:34:26.832079
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:34:31.096161
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        m = TruTVIE("http://www.trutv.com/full-episodes/how-to-be-a-grown-up/videos/how-to-be-a-g")
        print("TruTVIE Initialized")
    except:
        print("TruTVIE Failed")


# Generated at 2022-06-22 08:34:31.649770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:34:33.152903
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check if instance is correct
    assert isinstance(TruTVIE(), TruTVIE)

# Generated at 2022-06-22 08:34:35.851017
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    print(trutv)

# Generated at 2022-06-22 08:34:36.978842
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:34:41.477354
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instanciate the class
    trutv_ie = TruTVIE()
    trutv_ie._VALID_URL = "test_test_test"

    # assert chack if the value of _VALID_URL is "test_test_test"
    assert trutv_ie._VALID_URL == "test_test_test"

# Generated at 2022-06-22 08:34:43.151142
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing TruTVIE constructor")
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Constructor of class TruTVIE
    test_TruTVIE = TruTVIE(TurnerBaseIE)


# Generated at 2022-06-22 08:38:33.526352
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case : http://www.trutv.com/video/truTV.com/index.html#!/video/full-episodes/impractical-jokers/season-1/episode-1/index.html
    test_case = TruTVIE()
    actual = test_case._extract_ngtv_info(
        '5a7c2d5a0a7dfc917705f4ed', {}, {
            'url': 'http://www.trutv.com/video/truTV.com/index.html#!/video/full-episodes/impractical-jokers/season-1/episode-1/index.html',
            'site_name': 'truTV',
            'auth_required': False
        })

# Generated at 2022-06-22 08:38:34.825998
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:38:46.462494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    url = 'http://www.trutv.com/shows/south-beach-tow/videos/robber-in-tow.html'
    TruTVIE._TEST = {
            'url': url,
            'info_dict': {
                'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
                'ext': 'mp4',
                'title': 'Sunlight-Activated Flower',
                'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
            },
            'params': {
                # m3u8 download
                'skip_download': True,
            },
        }
    ttv._real_extract(url)

# Generated at 2022-06-22 08:38:50.169588
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._download_webpage("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html", "")