

# Generated at 2022-06-22 08:28:54.624547
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Unit test function to extract data from url

# Generated at 2022-06-22 08:29:00.452119
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:11.575746
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:12.510313
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.test()

# Generated at 2022-06-22 08:29:15.781537
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor
    global trutv
    trutv = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')



# Generated at 2022-06-22 08:29:18.050648
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TruTVIE"," trutv.com/ shows /the-carbonaro-effect/videos/ sunlight-activated-flower ")

# Generated at 2022-06-22 08:29:18.992071
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()
    assert m is not None

# Generated at 2022-06-22 08:29:19.622838
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:24.330463
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    vid = TruTVIE()
    assert vid._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:27.657774
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    # Check type of ie
    assert ie.__class__.__name__ == 'TruTVIE'


# Generated at 2022-06-22 08:29:40.117188
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing constuctor of class TruTVIE")
    myTruTVIE = TruTVIE()
    assert(myTruTVIE is not None)


# Generated at 2022-06-22 08:29:52.143860
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    str = 'Sunlight-Activated Flower'
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    display_id = 'http://trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    valid_url = TruTVIE()._VALID_URL
    if re.match(valid_url, url) is None:
        raise ValueError('Invalid TruTVIE URL: %s' % url)

    data = TruTVIE()._real_extract(url)

    assert data['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert data['display_id'] == display_id

# Generated at 2022-06-22 08:29:52.688734
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-22 08:30:01.666658
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case 1
    test_url = "https://www.trutv.com/shows/full-episodes/8e-5f9b9e7e-4854-4c7c-b1b4-4f0624d4a8b4/videos/it-s-a-trap.html"
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:08.563692
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    # https://trutv.id-cloud.net/ngtv/media/f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1
    ie = TruTVIE()
    ie.download('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:30:11.174391
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for parameter 'series_slug'
    TruTVIE(series_slug=None)
    # Test for parameter 'series_slug'
    assert TruTVIE(series_slug=None) and True



# Generated at 2022-06-22 08:30:19.222680
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    downloader = TruTVIE()
    assert downloader._TEST == {
    'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
    'info_dict': {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
    'params': {
        # m3u8 download
        'skip_download': True,
        },
    }


# Generated at 2022-06-22 08:30:25.835408
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Test with a valid url, should not raise any exception
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    #Test with an invalid url, should raise an exception
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/')

# Generated at 2022-06-22 08:30:33.051615
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
	obj = TruTVIE()
	obj.construct(url)

	url = "https://www.trutv.com/full-episodes/1457/The-Carbonaro-Effect-S2-Ep2.html"
	obj = TruTVIE()
	obj.construct(url)

# Generated at 2022-06-22 08:30:34.367534
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()


# Generated at 2022-06-22 08:30:52.528653
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for correct initialization of TruTVIE
    trutvIE = TruTVIE()
    assert trutvIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-22 08:30:59.629437
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# test with non-existent url (because internet connection is unavailable
	assert(not TruTVIE._real_extract(None, "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"))
	# test with existing url
	assert(TruTVIE._real_extract(None, "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"))

# Generated at 2022-06-22 08:31:05.583766
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    This tests to ensure that TruTVIE is set up correctly
    '''
    trutv_ie = TruTVIE()
    assert trutv_ie.name == 'TruTV'
    assert trutv_ie._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-22 08:31:06.998192
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case for TruTVIE as class function
    TruTVIE()

# Generated at 2022-06-22 08:31:11.556163
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check the constructor of TruTVIE
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    trutv._real_extract(url)



# Generated at 2022-06-22 08:31:12.264603
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:12.649777
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:22.155883
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  site = TruTVIE()
  assert site._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:\<a href=\"https://file.org/url/to/file/file.html\">file.org/url/to/file/file.html</a>videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
  return
  

# Generated at 2022-06-22 08:31:22.781473
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert True

# Generated at 2022-06-22 08:31:32.873190
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Class for retrieving data related to Turner's TruTV.
    '''
    # Test creation of object from constructor function
    test_object = TruTVIE("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    # Test that the object has been extract_info method
    assert hasattr(test_object, "extract") # Test that the object has been extract_info method
    # Test that the _download_webpage method is in the object's namespace
    assert hasattr(test_object, "_download_webpage")
    # Test that _VALID_URL is in the object's namespace
    assert hasattr(test_object, "_VALID_URL")
    # Test that _TEST is in the object's namespace

# Generated at 2022-06-22 08:31:53.490997
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('TruTVIE')

# Generated at 2022-06-22 08:31:54.237016
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:55.269657
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:55.879111
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:59.232341
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE()._TEST["url"] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:32:00.494523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:32:12.136375
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test function to confirm TruTVIE is correctly created
    """

    exp_url = "https://api.trutv.com/v2/web/episode/the-carbonaro-effect/59669/f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    exp_info = {"title": "Sunlight-Activated Flower", "description": "A customer is stunned when he sees Michael's sunlight-activated flower."}

    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    actual_TruTVIE = TruTVIE(url)

    assert actual_TruTVIE._TEST["url"] == url

# Generated at 2022-06-22 08:32:17.075517
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor only has a url argument
    ttv_object = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    # Check if url matches valid url
    url_match = TruTVIE._VALID_URL
    assert re.match(url_match,ttv_object._url) is not None


# Generated at 2022-06-22 08:32:22.762723
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    

# Generated at 2022-06-22 08:32:23.768139
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-22 08:33:03.735516
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-22 08:33:12.571213
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE_instance = TruTVIE()
    assert test_TruTVIE_instance._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:33:13.797288
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:17.828641
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test object constructor
    t = TruTVIE()

    # test _extract_urls
    urls = t._extract_urls('', 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
                           'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert urls == [('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'TruTV')]

    # test _real_extract
    info = TruTVIE()._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:33:20.914647
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test case for constructor of class TruTVIE
    """
    trutv_test_object = TruTVIE(TurnerBaseIE())
    assert(trutv_test_object)



# Generated at 2022-06-22 08:33:26.568277
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    ie.extract("https://www.trutv.com/full-episodes/4701309/the-gift-of-snow-december-2014/videos/sunlight-activated-flower.html")

# Generated at 2022-06-22 08:33:28.567134
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test = TruTVIE()

# Generated at 2022-06-22 08:33:29.460203
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:39.469142
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test_TruTVIE is an example of unit test.
    # Unit testing is in a separate file called test_<module_name>.py.
    # See http://www.voidspace.org.uk/python/articles/introduction-to-unittest.shtml#test-cases.
    from unit_test_suite import UnitTestSuite
    UnitTestSuite.addTest(TruTVIE('test_constructor', 'TruTVIE', 'TruTVIE is successfully created.'))
    UnitTestSuite.addTest(TruTVIE('test_can_handle_url', 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html', 'TruTVIE can handle the URL.'))

# Generated at 2022-06-22 08:33:41.725087
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-22 08:35:26.359902
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    trutv_ie = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    series_slug, clip_slug, video_id = re.match(trutv_ie._VALID_URL, trutv_ie._TEST['url']).groups()
    assert series_slug == 'the-carbonaro-effect'
    assert clip_slug == 'sunlight-activated-flower'
    assert not video_id

# Generated at 2022-06-22 08:35:38.091485
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Execution of constructor for class TruTVIE
    t = TruTVIE()
    # Test if class variable _VALID_URL has been initialized
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    # Test if class variable _TEST has been initialized

# Generated at 2022-06-22 08:35:40.363534
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Should be True
    print(True)


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:35:45.689703
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE with a valid url
    valid_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    a = TruTVIE()

    res = a.suitable(valid_url)
    assert res is True



# Generated at 2022-06-22 08:35:48.545575
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:35:50.487542
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:54.903536
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initializes the object
    obj = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    # Tests if the object is properly initialized
    assert obj._VALID_URL is not None
    assert obj._TEST is not None


# Generated at 2022-06-22 08:36:01.622152
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv.url_result('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-22 08:36:02.213029
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE() # Should not fail

# Generated at 2022-06-22 08:36:10.784693
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

    assert(ie.IE_NAME == "trutv")
    assert(ie.IE_DESC == "truTV: TruTV Video")
    assert(ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')