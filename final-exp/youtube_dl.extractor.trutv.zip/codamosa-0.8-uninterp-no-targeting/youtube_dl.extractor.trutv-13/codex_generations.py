

# Generated at 2022-06-22 08:28:56.412433
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.getName() == 'TruTV'

# Generated at 2022-06-22 08:29:00.820582
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE()._real_extract(url)

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-22 08:29:08.463193
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._DOWNLOADER_CLS = type('TestTruTVDownloader', (object,), {})
    ie.http = type('TestTruTVHttp', (object,), {})
    ie.http.request = type('TestTruTVHttpRequest', (object,), {})
    ie._download_webpage_handle = type('TestDownloadWebpageHandle', (object,), {})

    assert ie
    assert ie.http
    assert ie.http.request
    assert ie._download_webpage_handle

# Generated at 2022-06-22 08:29:11.453398
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.go(TruTVIE._TEST['url']) is not False

# Generated at 2022-06-22 08:29:11.962275
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor = TruTVIE

# Generated at 2022-06-22 08:29:13.254125
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-22 08:29:13.831507
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:23.400955
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for the TruTVIE class
    """
    trutv_ie = TruTVIE()

    url_1 = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    url_2 = "https://www.trutv.com/shows/the-carbonaro-effect/videos/0c1d5b5e-2c8d39fb.html"
    url_3 = "https://www.trutv.com/full-episodes/0c1d5b5e-2c8d39fb"

# Generated at 2022-06-22 08:29:25.206916
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/impractical-jokers/videos/tacos-and-flowers.html")

# Generated at 2022-06-22 08:29:25.993266
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:36.014870
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:37.412063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("test constructor")
    TruTVIE()

# Generated at 2022-06-22 08:29:40.130530
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing object constructor of TruTVIE")

    if __name__ == '__main__':
        test_TruTVIE()

# Generated at 2022-06-22 08:29:43.552839
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE()
    test_obj._extract_ngtv_info("", "", "")
    test_obj._real_extract("")

if __name__ == "__main__":
    test_TruTVIE()

# Generated at 2022-06-22 08:29:51.273723
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  url = 'https://www.trutv.com/full-episodes/7b8a2d4d-b0ad-4d4e-80a1-d6924bef9690/episode-7-fake-toad-on-a-stick-laptop-in-a-box-spider-flies-away-with-a-boy.html'
  trutv = TruTVIE()
  trutv.extract(url)
  print('Pass test: TruTVIE')

if __name__ == '__main__':
  test_TruTVIE()

# Generated at 2022-06-22 08:29:58.722065
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_obj = TruTVIE()
    assert test_obj._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:09.727075
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case:
    # 1. Instantiates an instance of TruTVIE
    # 2. Call method _real_extract()
    # 3. Call method _extract_ngtv_info()
    # 4. Call method _extract_ngtv_formats()

    test = TruTVIE()
    test._real_extract(url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    test._extract_ngtv_info(media_id='f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', info={}, video_data={'url': url, 'site_name': 'truTV', 'auth_required': False})
    test._extract_ngtv_formats

# Generated at 2022-06-22 08:30:15.487632
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert not obj.suitable('https://www.bitchute.com/video/rjtD1ZpAP1nv/')

# Generated at 2022-06-22 08:30:20.285935
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/77597/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:30:29.074843
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiation
    ie = TruTVIE()
    ie = TruTVIE("TruTVIE")
    assert ie.IE_NAME == 'TruTV'
    assert ie.ie_key() == 'TruTV'
    assert ie.IE_DESC == 'TruTV videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:48.568976
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE is not None)

# Generated at 2022-06-22 08:30:59.489523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    instance = TruTVIE()
    video_data = instance._real_extract(url)

    assert video_data['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'id is not correct'
    assert video_data['title'] == 'Sunlight-Activated Flower', 'title is not correct'
    assert video_data['series'] == 'The Carbonaro Effect', 'series is not correct'
    assert video_data['series_slug'] == 'the-carbonaro-effect', 'series_slug is not correct'

# Generated at 2022-06-22 08:31:06.148376
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower/video/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:31:06.641452
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:13.665774
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert test_obj._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert test_obj._TEST['info_dict']['id'] ==  'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert test

# Generated at 2022-06-22 08:31:17.177759
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)


# Generated at 2022-06-22 08:31:20.358849
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiate and run
    trutvIE = TruTVIE()
    trutvIE.run([
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ])

# Generated at 2022-06-22 08:31:22.066301
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:23.655318
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test the constructor of TruTVIE
    t=TruTVIE()

# Generated at 2022-06-22 08:31:25.103951
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    a = TruTVIE()
    assert(a != None)

# Generated at 2022-06-22 08:31:50.669749
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__dict__["_VALID_URL"] == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:31:56.857158
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case 1
    print("Test case 1")
    print("Testing constructor of TruTVIE")
    TruTVIE()

    # Test case 2
    print("Test case 2")
    print("Testing extractor TruTVIE by passing valid url")
    TruTVIE().extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')


# Generated at 2022-06-22 08:32:09.239892
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.suitable("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") == 1
    assert ie.suitable("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") == 1
    assert ie.suitable("http://www.trutv.com/full-episodes/the-carbonaro-effect/sunlight-activated-flower.html") == 2
    assert ie.suitable("http://www.trutv.com/full-episodes/the-carbonaro-effect/sunlight-activated-flower.html") == 2

# Generated at 2022-06-22 08:32:16.276580
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.url == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    y = TruTVIE(URL='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert y.url == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:32:16.883324
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:17.532118
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:19.439575
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE', 'TruTV', 'trutv.com').test()

# Generated at 2022-06-22 08:32:25.925486
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:32:26.999913
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().extract(str()).get('id')

# Generated at 2022-06-22 08:32:36.043232
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/full-episodes/12345678/first-timer-videos/sunlight-activated-flower.html"
    trutv = TruTVIE(url)
    assert trutv.authentication_required == True
    assert trutv.site_name == "truTV"
    assert trutv.video_id == "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    assert trutv.title == "Sunlight-Activated Flower"
    assert trutv.url == url

# Generated at 2022-06-22 08:33:17.230721
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:21.330644
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE('https://www.trutv.com/full-episodes/2118')

# Generated at 2022-06-22 08:33:22.590552
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  # Check if the class is constructed well
  assert(TruTVIE() is not None)



# Generated at 2022-06-22 08:33:29.242004
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None)._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:33:30.786407
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:32.446458
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE() is not None

# Generated at 2022-06-22 08:33:38.098320
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tru_tv_ie = TruTVIE()
    assert tru_tv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:33:44.729169
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructorTest = TruTVIE()

    assert constructorTest._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-22 08:33:46.191390
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:33:48.686403
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Tests for TruTVIE
	assert TruTVIE(TruTVIE._downloader).extract(TruTVIE._TEST['url']) == TruTVIE._TEST

# Generated at 2022-06-22 08:35:29.763136
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:31.913817
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TODO: this test is not so important, should be optimized
    TruTVIE()

# Generated at 2022-06-22 08:35:35.150267
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    v = TruTVIE()
    if (v.IE_NAME != 'trutv'):
        print(v.IE_NAME)
    assert v.IE_NAME == 'trutv'


# Generated at 2022-06-22 08:35:46.156838
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor of class TruTVIE, as well as its methods
    test_TruTVIE = TruTVIE()
    
    # Make use of protected fields in unittest
    assert test_TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:35:54.536315
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create test instance of TruTVIE
    test_tru_tv = TruTVIE()

    # Test TruTVIE object
    assert(test_tru_tv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-22 08:35:56.589138
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    s = TruTVIE()
    assert isinstance(s, TruTVIE)


# Generated at 2022-06-22 08:35:59.597900
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()


# Generated at 2022-06-22 08:36:08.854116
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ie.series_slug = 'the-carbonaro-effect'
    ie.clip_slug = 'sunlight-activated-flower'
    ie._VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:36:12.306313
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # truTV show page
    item = TruTVIE()
    assert TruTVIE(item) is not None
    # truTV video page
    item = TruTVIE()
    assert TruTVIE(item) is not None


# Generated at 2022-06-22 08:36:17.660841
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tt = TruTVIE()
    assert tt._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    return 'Unit test for TruTVIE is successful'
