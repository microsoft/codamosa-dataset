

# Generated at 2022-06-22 08:28:55.879428
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create a TruTVIE object here.
    yield TruTVIE()

# Generated at 2022-06-22 08:28:56.388533
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE() is not None

# Generated at 2022-06-22 08:29:01.423910
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/full-episodes/v-m')
    TruTVIE('https://www.trutv.com/shows/full-episodes/v-m')
    TruTVIE('https://www.trutv.com/shows/full-episodes/v-m')

# Generated at 2022-06-22 08:29:02.946337
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .extractor.TruTVIE import TruTVIE

# Generated at 2022-06-22 08:29:13.997497
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Basic test cases for constructor of class TruTVIE
    """
    test_case_1 = TruTVIE()
    assert test_case_1._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:18.033824
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    # verify that class is an instance of TurnerBaseIE
    assert isinstance(trutv, TurnerBaseIE)
    # verify that the class inherits from object (the root object)
    assert issubclass(TruTVIE, object)


# Generated at 2022-06-22 08:29:22.599860
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-22 08:29:30.061606
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tt = TruTVIE()
    assert tt._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert tt._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:29:34.997655
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.name == 'truTV'
    assert ie.ie_key() == 'TurnerBase'
    assert ie.video_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert ie.url == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert ie.params == {'skip_download': True}
    assert 'Sunlight-Activated Flower' in ie._PRINTABLE_KEYS
    assert ie.display_id == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-22 08:29:47.310095
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialization of bound class TruTVIE
    trutvIE = TruTVIE()
    # Verification of class
    assert(trutvIE._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))")

# Generated at 2022-06-22 08:29:53.101482
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTvIE = TruTVIE()

# Generated at 2022-06-22 08:30:01.363806
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Arrange
    expected_series_slug = "the-carbonaro-effect"
    expected_video_id = "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1"
    expected_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    expected_match_group = (
        expected_series_slug,
        None, expected_video_id
    )
    # Act
    match_group_result = re.match(TruTVIE._VALID_URL, expected_url).groups()
    # Assert
    assert match_group_result == expected_match_group

# Generated at 2022-06-22 08:30:04.973535
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.SESSION is not None
    assert ie.HTTP_HEADER is not None
    assert ie.ngtv_url is not None
    assert ie.ngtv_api_key is not None

# Generated at 2022-06-22 08:30:06.012455
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()
    assert i
    return i

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:30:09.391186
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    "Test TruTVIE class constructor"
    # Print a dollar sign
    print(u"\u0024")
    trutv_ie = TruTVIE()

# Generated at 2022-06-22 08:30:15.166036
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This tests if the constructor of class TruTVIE works as expected
    test_ob = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert test_ob._TEST == TruTVIE._TEST

# Generated at 2022-06-22 08:30:18.017037
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    "TruTVIE(self, url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')"

# Generated at 2022-06-22 08:30:28.925244
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    r = TruTVIE()

    assert r._VALID_URL == "https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))"
    assert len(r._TEST['url']) == 106 and type(r._TEST['url']) is str

# Generated at 2022-06-22 08:30:37.773371
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Unit test TruTV constructor
    assert TruTVIE()._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE()._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE()._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert TruTV

# Generated at 2022-06-22 08:30:39.629396
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._downloader.params['noplaylist'] == False


# Generated at 2022-06-22 08:30:58.059321
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test instantiation of TruTVIE
    try:
        TruTVIE()
        assert True
    except:
        assert False
    # Test TruTVIE.ie_key()
    assert TruTVIE.ie_key() == "TruTV"
    # Test TruTVIE._real_extract()
    try:
        TruTVIE._real_extract(TruTVIE(), 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
        assert True
    except:
        assert False


# Generated at 2022-06-22 08:31:09.555415
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    actual_TruTVIE = TruTVIE()
    assert actual_TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:31:13.115426
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        assert False, 'constructor of class TruTVIE raises Exception'
    assert True, 'constructor of class TruTVIE does not raises Exception'


# Generated at 2022-06-22 08:31:22.241665
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    # Note: TruTVIE with real url will do too much network operation
    # So we only create this object
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv_ie = TruTVIE(url)
    assert isinstance(trutv_ie, TruTVIE)

# Generated at 2022-06-22 08:31:32.631439
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(None)._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE(None)._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE(None)._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert TruTVIE

# Generated at 2022-06-22 08:31:35.831585
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL
    assert TruTVIE()._TEST == TruTVIE._TEST

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:31:37.458950
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert isinstance(trutv, TruTVIE)


# Generated at 2022-06-22 08:31:46.666108
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE = TruTVIE()
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:31:47.777138
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        truTV = TruTVIE()
    except:
        assert False

# Generated at 2022-06-22 08:31:48.701401
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    v = TruTVIE()

# Generated at 2022-06-22 08:32:08.445905
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-22 08:32:12.269675
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
  TruTVIE(True, url)

# Generated at 2022-06-22 08:32:21.892966
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-22 08:32:32.022386
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    ttv = TruTVIE()
    #
    # TruTVIE fails when it cannot obtain "mediaId" from a URL
    #
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    path = 'series/clip'
    series_slug = 'the-carbonaro-effect'
    display_id = 'sunlight-activated-flower'
    out_data = {'display_id': display_id, 'url': url, 'path': path, 'series_slug': series_slug}
    assert ttv._real_extract(url) == out_data

# Generated at 2022-06-22 08:32:41.395711
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower-')
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:32:43.198856
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._download_json
    assert ie.SUCCESS == 'success'

# Generated at 2022-06-22 08:32:46.685972
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
  TruTVIE(url)

# Generated at 2022-06-22 08:32:50.627172
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE()
    assert truTVIE.suitable("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    return truTVIE


# Generated at 2022-06-22 08:32:53.925466
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    t._real_extract(url)

# Generated at 2022-06-22 08:32:55.212449
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test for constructor for TruTVIE class
    """
    TruTVIE()

# Generated at 2022-06-22 08:33:37.292023
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:38.929043
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.extract(TruTVIE._TEST['url'])

# Generated at 2022-06-22 08:33:40.458310
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
        return True
    except:
        return False


# Generated at 2022-06-22 08:33:40.928724
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:42.911711
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.set_downloader(None)


# Generated at 2022-06-22 08:33:46.417579
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert isinstance(TruTVIE, type)
    assert issubclass(TruTVIE, TurnerBaseIE)

if __name__ == '__main__':
    test_TruTVIE()
    sys.exit()

# Generated at 2022-06-22 08:33:47.423184
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # creating TruTVIE instance
    TruTVIE()


# Generated at 2022-06-22 08:33:58.972085
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    _TEST = {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

    # Test public class variables

# Generated at 2022-06-22 08:33:59.980809
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTV = TruTVIE()

# Generated at 2022-06-22 08:34:04.130770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This tests that the class is created correctly
    # More of a sanity test than anything
    try:
        tt = TruTVIE()
        print("TruTVIE created properly")
    except:
        print("Could not create TruTVIE")
        raise


# Generated at 2022-06-22 08:35:47.894100
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:35:53.869775
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert 'truTV' == TruTVIE.name
    assert TruTVIE.ie_key() == 'trutv'
    assert TruTVIE.ie_key() in TruTVIE.pptv_adn
    assert True == TruTVIE.pptv_adn[TruTVIE.ie_key()]['matched']

# Generated at 2022-06-22 08:35:55.472919
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie.ie_key() == 'trutv'

# Generated at 2022-06-22 08:36:04.996367
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().name
    assert TruTVIE()._VALID_URL is not None
    assert TruTVIE()._TEST is not None
    assert TruTVIE()._VALID_URL.match("http://www.trutv.com/shows/tacoma-fd/videos/tacoma-fds-new-chief.html") is not None
    assert TruTVIE()._VALID_URL.match("http://www.trutv.com/shows/tacoma-fd/videos/tacoma-fds-new-chief.html").groups()[0] == "tacoma-fd"
    assert TruTVIE()._VALID_URL.match("http://www.trutv.com/shows/tacoma-fd/videos/tacoma-fds-new-chief.html").groups()[1]

# Generated at 2022-06-22 08:36:05.919371
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:36:09.242457
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Pass URL and check if it is valid URL
    TruTVIE('https://www.trutv.com/shows/impractical-jokers/videos/jokers-wild-special-preview-1.html')

# Generated at 2022-06-22 08:36:14.952134
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    assert test_TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:36:25.394187
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create instance of TruTVIE with valid url
    truTV = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # Check if url is valid
    assert truTV._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # Check that url is valid
    truTV.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # Check

# Generated at 2022-06-22 08:36:27.240767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from __main__ import TruTVIE
    ie = TruTVIE()
    ie.login()


# Generated at 2022-06-22 08:36:37.948769
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialization
    instance = TruTVIE()
    print('Unit test for class TruTVIE')

    # Test case1: valid URL
    # Input
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Output
    print('\nTesting for valid URL ...')
    print('Input URL:', url)
    instance._real_extract(url)
    print('Success!')

    # Test case2: invalid URL
    # Input
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower'
    # Output
    print('\nTesting for invalid URL ...')
    print('Input URL:', url)
    instance._real_extract(url)