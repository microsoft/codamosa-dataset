

# Generated at 2022-06-22 08:28:58.297769
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import extractor
    from . import options

    extractor_unit = extractor.gen_extractor(TruTVIE, sys.argv[1])
    extractor_unit.download(
        extractor_unit.suitable(
            options.dummy_verifyconfig(),
            'test_TruTVIE'
        )[0]
    )

# Generated at 2022-06-22 08:29:01.290516
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import trutv
    trutv.TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:29:02.308400
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()

# Generated at 2022-06-22 08:29:06.122792
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    
    # Create a TruTVIE
    trutv = TruTVIE()

    # Check if it is an instance of TruTVIE
    assert isinstance(trutv, TruTVIE)

# Generated at 2022-06-22 08:29:11.212304
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        trutv_video_ie = TruTVIE()
        expected_class_name = 'TruTVIE'
        assert trutv_video_ie.__class__.__name__ == expected_class_name
    except Exception:
        assert False


# Generated at 2022-06-22 08:29:11.798701
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:13.118002
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test the existence of TruTVIE.
    assert TruTVIE

# Generated at 2022-06-22 08:29:14.071659
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check TruTVIE works
    TruTVIE()

# Generated at 2022-06-22 08:29:16.263084
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for the TruTVIE class.
    """
    import TruTV
    TruTV.TruTVIE()

# Generated at 2022-06-22 08:29:25.206800
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj is not None
    # Test TruTVIE.extract_urls()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    urls = TruTVIE.extract_urls(url)
    url = urls[0]
    assert url == 'https://www.trutv.com/full-episodes/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Test TruTVIE._valid_url()
    assert TruTVIE._valid_url(url, TruTVIE._VALID_URL) is True
    # Test TruTVIE._real_extract()
    info_dict = TruTVIE._real_extract(url)
    assert info_

# Generated at 2022-06-22 08:29:31.533005
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-22 08:29:32.173031
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:34.269799
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL is not None
    assert TruTVIE._TEST is not None

# Generated at 2022-06-22 08:29:34.954328
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE

# Generated at 2022-06-22 08:29:36.853191
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #try:
    #    TruTVIE()
    #except:
    #    pass
    assert True

# Generated at 2022-06-22 08:29:49.254210
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import unittest
    site = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    match = site._VALID_URL
    result = re.match(match, url)
    assert result is not None
    url_match = result.groups()
    assert url_match[0] == 'the-carbonaro-effect'
    assert url_match[1] == 'sunlight-activated-flower'
    assert url_match[2] is None
    test = site._download_json('https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower', 'sunlight-activated-flower')
    assert test is not None

# Generated at 2022-06-22 08:29:53.202963
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #Instantiate object
    TruTVIE_object = TruTVIE()
    try:
        #Initialize object
        TruTVIE_object.initialize()
    except Exception as e:
        print('Failed to initialize object TruTVIE!')
        return e

# Generated at 2022-06-22 08:29:53.916010
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-22 08:29:58.708504
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test function to test creation of a instance of class TruTVIE."""
    trutv_ie = TruTVIE()

    assert trutv_ie.IE_NAME == "trutv"
    assert trutv_ie.VALID_URL == TruTVIE._VALID_URL
    assert trutv_ie.url_result == TruTVIE._url_result

# Generated at 2022-06-22 08:30:00.492364
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert(isinstance(ie, TurnerBaseIE))

# Generated at 2022-06-22 08:30:21.689951
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # return True if the constructor of class TruTVIE is ok and False if not
    valid_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_TruTVIE = TruTVIE('', {})
    test_TruTVIE._VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:25.493634
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE.
    """
    ie = TruTVIE()
    ie.download("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-22 08:30:27.223908
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:30:39.127478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:40.440048
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE.__name__ == 'TruTVIE'


# Generated at 2022-06-22 08:30:41.894507
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-22 08:30:42.759170
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()


# Generated at 2022-06-22 08:30:45.757767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    ie = TruTVIE()
    ie.extract(url)
    assert ie.ie_key() == "truTV"

# Generated at 2022-06-22 08:30:51.949799
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t.SUCCESS_CODE == 200
    assert t.TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-22 08:31:00.545639
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # _VALID_URL is a TruTVIE._VALID_URL string.
    # url is url address that is matched to _VALID_URL string.
    TruTVIE._VALID_URL = TruTVIE._VALID_URL
    url = TruTVIE._VALID_URL
    
    # Constructor of class TruTVIE.
    extractor = TruTVIE()

    # Call of method _real_extract()
    extractor._real_extract(url)
    print('Unit test for constructor of class TruTVIE is completed successfully.')

# Generated at 2022-06-22 08:31:25.618890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv'
    assert ie.IE_DESC == 'truTV'

    # Test to check 'info_dict' of TruTVIE.ie
    info_dict_check = {
        'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
        'ext': 'mp4',
        'title': 'Sunlight-Activated Flower',
        'description': "A customer is stunned when he sees Michael's sunlight-activated flower."
    }

    # TruTVIE._extract_ngtv_info method

# Generated at 2022-06-22 08:31:26.172959
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:26.666833
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-22 08:31:29.897165
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert url, 'Failed to recognize the TruTVIE url'

# Generated at 2022-06-22 08:31:39.145999
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # E01S01
    test_object = TruTVIE()
    assert test_object._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))', test_object._VALID_URL

# Generated at 2022-06-22 08:31:47.308682
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:31:49.167759
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check that id numbers are well extracted from URLs.
    assert TruTVIE._TEST['info_dict']['id'] == TruTVIE._real_extract(TruTVIE._TEST['url'])['id']

# Generated at 2022-06-22 08:31:49.925171
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE()

# Generated at 2022-06-22 08:31:54.380027
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    i = TruTVIE()
    assert i.AUTH_REQUIRED == 0
    assert i.BASE_URL == "http://release.theplatform.com/content.select"
    assert type(i.DEFAULT_HEADERS) == dict
    assert i.EMBED_URL == "https://www.trutv.com/player/embed/%s"
    assert i.GEO_COUNTRIES == ['US']
    assert i.IE_NAME == "trutv"
    assert i.JSON_URL == "http://api.trutv.com/2.0/jsonp/%s"
    assert type(i.PARAMS) == dict
    assert i.PAYLOAD == {'form': True}
    assert i.SALT == "s6U4y8Ub29Mk"
    assert i

# Generated at 2022-06-22 08:31:55.367527
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:36.640146
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(TruTVIE._VALID_URL)
    # Class constructor should work as expected
    # TODO: Implement unit test.

# Generated at 2022-06-22 08:32:41.855185
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # GIVEN a TruTVIE class
    # WHEN creating an instance of it
    ie = TruTVIE()
    # THEN the instance should be a TruTVIE object
    assert isinstance(ie, TruTVIE)

# Generated at 2022-06-22 08:32:44.124767
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE(None)
    assert ttv.ie_key() == 'TruTV'
    assert ttv.ie_url() == 'trutv.com'

# Generated at 2022-06-22 08:32:46.982883
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except:
        return False
    return True

# Generated at 2022-06-22 08:32:50.893680
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    T = TruTVIE(url)
    T.test()


# Generated at 2022-06-22 08:32:54.130713
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE(TruTVIE._downloader, TruTVIE._VALID_URL.replace(r'(?P<id>\d+)', ''))
    assert trutv_ie

# Generated at 2022-06-22 08:32:55.716737
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Arrange
    
    # Act
    trutv_ie = TruTVIE()

    # Assert
    assert isinstance(trutv_ie, TruTVIE)

# Generated at 2022-06-22 08:32:58.578596
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie is not None


# Generated at 2022-06-22 08:33:09.963181
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import gen_extractors
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.utils import DateRange

    ie = TruTVIE()
    ie.ie_key = 'TruTV'
    ie.ie_info = lambda *args, **kwargs: {}
    ydl = YoutubeDL({'nooverwrites': True, 'continuedl': False, 'noprogress': True, 'outtmpl': ''})

# Generated at 2022-06-22 08:33:10.768145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor
    TruTVIE()

# Generated at 2022-06-22 08:34:42.891257
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None, None)

# Generated at 2022-06-22 08:34:54.271127
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie._VALID_URL = r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:34:55.980308
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    extractor = TruTVIE()
    assert extractor._AVAILABLE_PROTOCOLS == ['hls']

# Generated at 2022-06-22 08:34:58.644617
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE()
    except Exception:
        assert False, 'Could not initialize class TruTVIE'
    assert True



# Generated at 2022-06-22 08:34:59.734227
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	x = TruTVIE()


# Generated at 2022-06-22 08:35:03.237125
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    print(ie)

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:35:07.700600
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Basic test for TruTVIE constructor
    """
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    Module = TruTVIE
    expected_result = TruTVIE
    actual_result = Module(url)
    assert expected_result == actual_result

# Generated at 2022-06-22 08:35:09.525035
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:35:11.885975
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_case_1 = TruTVIE(TurnerBaseIE._downloader)
    print(test_case_1)


# Generated at 2022-06-22 08:35:19.931076
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    # Test constructor with test URL
    # assert TruTVIE._TEST['url'] == TruTVIE._TEST
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Test constructor with test info dict
    assert TruTVIE._TEST['info_dict'] == {'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'ext': 'mp4', 'title': 'Sunlight-Activated Flower', 'description': "A customer is stunned when he sees Michael's sunlight-activated flower."}

    # Test constructor with test info params
    assert TruTVIE._TEST['params'] == {'skip_download': True}

    # Test