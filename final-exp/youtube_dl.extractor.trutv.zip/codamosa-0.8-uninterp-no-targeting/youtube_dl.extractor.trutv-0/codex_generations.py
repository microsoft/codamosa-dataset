

# Generated at 2022-06-22 08:28:53.723719
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Test TruTVIE constructor """
    TruTVIE()

# Generated at 2022-06-22 08:28:54.627630
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:28:57.740770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    assert x.extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html") is not None

# Generated at 2022-06-22 08:29:04.076212
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    m_url = re.match(TruTVIE._VALID_URL, url)
    series_slug = m_url.group('series_slug')
    clip_slug = m_url.group('clip_slug')
    video_id = m_url.group('id')

    assert(video_id is None)

    trutv = TruTVIE()

# Generated at 2022-06-22 08:29:06.647552
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE(None,True)
    assert (trutv!=None)
    #print (trutv)

# Generated at 2022-06-22 08:29:17.859936
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'
    # Test _extract_video_info
    # video_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'; display_id = 'sunlight-activated-flower'
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    result = ie._real

# Generated at 2022-06-22 08:29:18.764303
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:29:25.207465
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Tests TruTVIE class constructor to ensure attributes set using given parameters. """
    # Given
    mock_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    expected_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

    # When
    trutvIE = TruTVIE(mock_url)

    # Then
    assert expected_url == trutvIE._url

# Generated at 2022-06-22 08:29:28.118990
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import TruTVIE
    expected = '<class \'__main__.TruTVIE\'>'
    actual = TruTVIE()
    assert expected == actual

# Generated at 2022-06-22 08:29:35.954951
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test TruTVIE constructor
    """
    def test_TurnerBaseIE():
        """
        Test TurnerBaseIE constructor
        """
        def test_TurnerBaseIE():
            """
            Test TurnerBaseIE constructor
            """
            from .turner import TurnerBaseIE
            assert TurnerBaseIE('turner') is not None
        test_TurnerBaseIE()
    test_TurnerBaseIE()

    assert TruTVIE('trutv') is not None



# Generated at 2022-06-22 08:29:46.966246
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TurnerBaseIE())._VALID_URL == TruTVIE._VALID_URL

# Generated at 2022-06-22 08:29:48.083435
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)


# Generated at 2022-06-22 08:29:51.319731
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Tested to make sure it can instantiate and it passes a test
    class_ = TruTVIE

    # Test initialization
    TruTVIE(class_._download_json)
    

# Generated at 2022-06-22 08:30:00.739097
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:12.296260
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:20.022435
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert hasattr(TruTVIE, "ie_key")
    assert TruTVIE.ie_key == "truTV"
    assert hasattr(TruTVIE, "name")
    assert TruTVIE.name == "truTV"
    assert hasattr(TruTVIE, "description")
    assert TruTVIE.description == "TV Network"
    assert hasattr(TruTVIE, "test")
    assert hasattr(TruTVIE, "_VALID_URL")
    assert hasattr(TruTVIE, "suitable")
    assert hasattr(TruTVIE, "url_result")
    assert hasattr(TruTVIE, "result_brand")
    assert hasattr(TruTVIE, "result_channel")
    assert hasattr(TruTVIE, "result_type")

# Generated at 2022-06-22 08:30:23.276514
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    t.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:30:24.124297
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-22 08:30:34.136500
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert t._VALID_URL == TruTVIE._VALID_URL
    test = TruTVIE._TEST
    assert url == test['url']
    info_dict = test['info_dict']
    assert info_dict['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert info_dict['ext'] == 'mp4'
    assert info_dict['title'] == 'Sunlight-Activated Flower'
    assert info_dict['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."
    params = test['params']
    assert params

# Generated at 2022-06-22 08:30:39.926120
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutvIE = TruTVIE()
    trutvIE._get_extractor(url)
    # Unit test for function _real_extract of class TruTVIE
    trutvIE._real_extract(url)

# Generated at 2022-06-22 08:30:59.547946
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    expected_url = 'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower'
    expected_ie_name = 'truTV'
    expected_display_id = 'sunlight-activated-flower'
    expected_media_id = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    expected_auth_required = True
    expected_site_name = 'truTV'


    assert ie.url == expected_url
    assert ie.ie_name == expected_ie_name

# Generated at 2022-06-22 08:31:00.140250
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:10.250413
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_obj = TruTVIE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:31:17.417981
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTV = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-22 08:31:21.196322
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable("""
        https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    """)


# Generated at 2022-06-22 08:31:22.825284
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:31:23.297496
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:26.136480
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    Determines whether constructor of TruTVIE returns TruTVIE object.
    '''
    ie = TruTVIE()
    assert ie is not None

# Generated at 2022-06-22 08:31:34.266873
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL({'noplaylist': True})
    d = ydl.extract_info(
        'http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        download=False)
    assert d['id'].strip() == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert d['ext'] == 'mp4'
    assert d['title'] == 'Sunlight-Activated Flower'
    assert d['site_name'] == 'truTV'
    assert d['auth_required'] == True

# Generated at 2022-06-22 08:31:36.983938
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST.get('url') == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:32:01.973279
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    trutv_ie.valid_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    trutv_ie.valid_url('https://www.trutv.com/shows/the-carbonaro-effect/videos/225201-sunlight-activated-flower')

# Generated at 2022-06-22 08:32:09.133682
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_main import main
    from .common import get_testcases
    from .utils import FakeIE

    ie = FakeIE("trutv", title_re=r'(.+?)\s+-')

    tests = get_testcases("trutv")
    del tests[0]
    del tests[0]
    main("trutv", ie, tests=tests, match_title_only=True)


# Generated at 2022-06-22 08:32:14.225273
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TurnerBaseIE("https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower")
	assert TurnerBaseIE("https://api.trutv.com/v2/web/episode/the-carbonaro-effect/5669")

# Generated at 2022-06-22 08:32:20.818196
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for TruTVIE constructor
    """
    # test valid url
    trutv_ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:32:21.975728
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:32:25.057367
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    tr = TruTVIE()
    result = TruTVIE._TEST['info_dict']
    tr_result = tr.extract(TruTVIE._TEST['url'])
    assert result == tr_result

# Generated at 2022-06-22 08:32:25.696483
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:30.012675
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    if __name__ == "__main__":
        testTruTVIE = TruTVIE()
        print('Testing TruTVIE constructor')
        print(testTruTVIE)


# Generated at 2022-06-22 08:32:39.695405
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test cases for TruTVIE"""
    # Valid TruTVIE
    trutv_ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Check if TruTVIE is valid
    assert TruTVIE._is_valid_url(trutv_ie) is True
    clip_slug, series_slug, video_id = trutv_ie._match_id(trutv_ie)
    assert clip_slug == "sunlight-activated-flower"
    assert series_slug == "the-carbonaro-effect"
    assert video_id == None
    # Check if title was parsed correctly

# Generated at 2022-06-22 08:32:46.269272
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .. import TruTVIE
    from .common import InfoExtractor

    def test_IE(IE):
        ie = IE()
        assert ie.ie_key() == 'trutv'
        assert ie.IE_NAME == 'truTV'
        assert ie._VALID_URL == TruTVIE._VALID_URL
        assert isinstance(ie.IE, TruTVIE.IE)

    test_IE(TruTVIE.TruTVIE)

# Generated at 2022-06-22 08:33:36.951556
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test for TruTVIE constructor
    test_case = TruTVIE
    assert test_case._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:33:37.511784
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()

# Generated at 2022-06-22 08:33:41.984890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    myTruTVIE = TruTVIE()
    assert isinstance(myTruTVIE, TruTVIE)
    return myTruTVIE


# Generated at 2022-06-22 08:33:43.481336
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
   # Test for constructor of class TruTVIE
   assert TruTVIE

# Generated at 2022-06-22 08:33:43.998886
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:46.219420
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:33:46.617442
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:47.631478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(TruTVIE._downloader, TruTVIE._VALID_URL)

# Generated at 2022-06-22 08:33:56.281224
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    object = TruTVIE()
    assert object._VALID_URL == 'https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))'

# Generated at 2022-06-22 08:33:56.929602
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:42.348080
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie is not None
    return trutv_ie


# Generated at 2022-06-22 08:35:43.425509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert(ie)

# Generated at 2022-06-22 08:35:44.487399
# Unit test for constructor of class TruTVIE
def test_TruTVIE():  # noqa: F821
    TruTVIE()

# Generated at 2022-06-22 08:35:55.905254
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TruTVIE object with valid url
    trutv_ie = TruTVIE(TruTVIE._VALID_URL)
    # Testing TruTVIE._TEST
    assert TruTVIE._TEST == trutv_ie._TEST
    # Testing TruTVIE._VALID_URL
    assert TruTVIE._VALID_URL == trutv_ie._VALID_URL
    # Testing TruTVIE._extract_ngtv_info
    assert trutv_ie._extract_ngtv_info == TruTVIE._extract_ngtv_info
    # Testing TruTVIE._real_extract
    assert trutv_ie._real_extract == TruTVIE._real_extract

# Generated at 2022-06-22 08:36:07.941694
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    t._VALID_URL = r'Test'
    t._TEST = {
        'url': 'Test',
        'info_dict': {
            'id': '6279c1f7-b3ec-4b56-a8f0-b5f9835e979c',
            'ext': 'mp4',
            'title': 'Test',
            'description': 'My Test',
        },
    }

    assert_equals(t._VALID_URL, r'Test')

# Generated at 2022-06-22 08:36:09.148795
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:36:10.171234
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:36:10.974499
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert isinstance(TruTVIE, TurnerBaseIE)

# Generated at 2022-06-22 08:36:11.511875
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:36:14.855442
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    # extract_info method
    trutvIE.extract_info("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")