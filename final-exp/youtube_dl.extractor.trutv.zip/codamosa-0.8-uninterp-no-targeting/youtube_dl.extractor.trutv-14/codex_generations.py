

# Generated at 2022-06-22 08:29:05.637528
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .conftest import FakeIE
    from .nbc import NBCIE
    FakeIE.register(lambda *args: TruTVIE(*args) if 'truTV' in args[0] else None)

    ie = FakeIE('https://www.trutv.com/shows/harry-lopez/videos/harry-lopez-welcome-to-college.html')
    assert isinstance(ie, TruTVIE)

    ie = FakeIE('https://www.nbc.com/player/embed/RCVR%3D11784%26video%3D3861661%26endclip%3Dtrue')
    assert isinstance(ie, NBCIE)

# Generated at 2022-06-22 08:29:06.503928
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:07.345338
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:29:11.453118
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:29:12.034932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:16.028137
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create instance for TruTVIE class
    test_TruTVIE = TruTVIE()
    # Call the method with url.
    test_TruTVIE._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:29:16.669049
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    TruTVIE()

# Generated at 2022-06-22 08:29:18.342223
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    success = TruTVIE(None)

    #assert(success == None)

    #assert(success == None)

# Generated at 2022-06-22 08:29:20.719042
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .unittest_helper import setUp
    setUp()
    from . import TruTVIE
    t = TruTVIE()
    assert isinstance(t, TruTVIE)

# Generated at 2022-06-22 08:29:23.399251
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert (ie.site_name == 'truTV')

# Generated at 2022-06-22 08:29:39.292209
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE()
    assert '/v2/web' in ttvie._NGTV_VOD_TEMPLATE
    assert '/v2/web' in ttvie._NGTV_FUTURE_TEMPLATE
    assert '/v2/web' in ttvie._NGTV_LIVE_TEMPLATE

# Generated at 2022-06-22 08:29:51.473672
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create the test object
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    test_obj = TruTVIE()

    # Test URL
    assert test_obj._VALID_URL == "https?://(?:www\\.)?trutv\\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\\d+))"

    #Test _real_extract function
    assert test_obj._real_extract(url)

    # Test _download_json function

# Generated at 2022-06-22 08:29:52.685381
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE

# Generated at 2022-06-22 08:29:56.253377
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make sure our constants do not throw exceptions
    TruTVIE.IE_NAME
    TruTVIE._VALID_URL
    # Make sure we can construct an instance of this class
    TruTVIE(None)

# Generated at 2022-06-22 08:29:58.188018
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from . import TruTV
    resp = TruTV.TruTVIE()
    assert isinstance(resp, TruTVIE) == True

# Generated at 2022-06-22 08:30:02.203223
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    Tru = TruTVIE('TruTVIE')
    with pytest.raises(AttributeError):
        Tru.get_hosts()
    with pytest.raises(AttributeError):
        Tru.get_media_token()

# Generated at 2022-06-22 08:30:13.866285
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """TruTVIE
    https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    """
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv.IE_NAME == 'truTV'
    assert trutv.ie_key() == 'trutv'

# Generated at 2022-06-22 08:30:23.316024
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	# Loads JSON file and reads to object 'data'
	data = {}
	TruTVIE = TruTVIE()
	assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	assert TruTVIE._TEST['info_dict'] == {'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1', 'ext': 'mp4', 'title': 'Sunlight-Activated Flower', 'description': "A customer is stunned when he sees Michael's sunlight-activated flower."}
	assert TruTVIE._TEST['params'] == {'skip_download': True}

# Generated at 2022-06-22 08:30:33.610912
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        import urllib.parse as urlparse
    except ImportError:
        import urlparse
    TruTVIE()
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    query = urlparse.urlparse(url).query
    query_dict = urlparse.parse_qs(query)
    m = re.match(TruTVIE._VALID_URL, url)
    groups = m.groups()
    series_slug = groups[0]
    clip_slug = groups[1]
    video_id = groups[2]
    if video_id:
        path = 'episode'
        display_id = video_id
    else:
        path = 'series/clip'
        display_id = clip_sl

# Generated at 2022-06-22 08:30:37.346722
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # from url
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect')

    # from series_id
    TruTVIE('the-carbonaro-effect')


# Generated at 2022-06-22 08:31:06.899962
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'turner:trutv'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:31:08.873762
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Instantiates a TruTVIE object and confirms that it is of the correct type
    extractor = TruTVIE('The Carbonaro Effect')
    assert type(extractor) is TruTVIE

# Generated at 2022-06-22 08:31:14.118272
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """TruTVIE tests"""
    from .test_cases import TruTVTests
    obj_TruTVIE = TruTVIE()
    obj_TruTVIE.test_cases = TruTVTests
    for test in obj_TruTVIE.test_cases:
        obj_TruTVIE.run_test(test)

# Generated at 2022-06-22 08:31:16.993202
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TurnerBaseIE()
    ie2 = TruTVIE()
    assert ie._downloader == ie2._downloader

# Generated at 2022-06-22 08:31:17.617006
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:19.765774
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:31:31.289318
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test a sample URL
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    # Check if constructor raises exceptions given an invalid URL
    assert(TruTVIE._VALID_URL is not re.match(TruTVIE._VALID_URL, test_url))
    # Test constructor and method with a valid URL
    trutv_video = TruTVIE(None)._real_extract(test_url)
    # Check for correct values for some of the parameters
    if trutv_video['id'] != 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1':
        print('id incorrect')

# Generated at 2022-06-22 08:31:37.683398
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test if TruTVIE constructor is implemented correctly
    obj_tvie = TruTVIE()

    # Test TruTVIE constructor parameters
    assert obj_tvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-22 08:31:39.630151
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE({})
    assert type(test_TruTVIE) == TruTVIE

# Generated at 2022-06-22 08:31:41.704552
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:32:21.114609
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()


# Generated at 2022-06-22 08:32:23.064028
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:32:34.787816
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert(issubclass(TruTVIE, TurnerBaseIE))
	assert(TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
	assert(TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:32:36.193716
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv is not None

# Generated at 2022-06-22 08:32:37.122247
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert callable(TruTVIE)

# Generated at 2022-06-22 08:32:40.424914
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_instance = TruTVIE()
    assert trutv_instance != None

# Generated at 2022-06-22 08:32:45.280770
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize TruTVIE instance
    ie = TruTVIE()
    # Check TruTVIE module
    ie.module
    # Check TruTVIE name
    ie.IE_NAME
    # Check TruTVIE description
    ie.IE_DESC
    # Check TruTVIE URL
    ie._VALID_URL
    # Check TruTVIE working instance
    ie.workingInstance

# Generated at 2022-06-22 08:32:46.983015
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie_object = TruTVIE()
    assert ttvie_object is not None

# Generated at 2022-06-22 08:32:48.719985
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Simple test for constructor of class TruTVIE

    """
    TruTVIE()

# Generated at 2022-06-22 08:32:49.366890
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    return TruTVIE()

# Generated at 2022-06-22 08:33:32.862460
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-22 08:33:35.247567
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE.suite()

if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:33:43.519483
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    for url in [
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'https://www.trutv.com/shows/the-last-ship/videos/the-last-ship--101---it-s-not-a-matter-of-if---it-s-a-matter-of-when-.html',
        'https://www.trutv.com/shows/the-last-ship/full-episodes/s03e03-laird-of-the-rings.html',
        'https://www.trutv.com/shows/at-home-with-bob-ross/videos/a-peaceful-stream.html'
    ]:
        assert TruTVIE._VALID_URL.match(url)

# Generated at 2022-06-22 08:33:47.340681
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    print("Testing constructor of class TruTVIE")
    trutv_ie = TruTVIE()
    print("Testing function __init__")
    assert(trutv_ie != None)
    print("Constructor of class TruTVIE works correctly")


# Generated at 2022-06-22 08:33:48.261076
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj is not None

# Generated at 2022-06-22 08:33:49.979731
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_instance=TruTVIE()
    assert test_instance.ie_key() == 'TruTV'

# Generated at 2022-06-22 08:33:50.550782
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-22 08:33:54.148345
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().fetch_info('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:33:56.652643
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    video = TurnerBaseIE()
    video.extract(TruTVIE._TEST['url'])

# Generated at 2022-06-22 08:33:58.216879
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:43.993743
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()

# Generated at 2022-06-22 08:35:49.046796
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv.url_result('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert trutv.url_result('https://www.trutv.com/shows/the-carbonaro-effect/4084/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:35:57.697021
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttv = TruTVIE()
    assert ttv.IE_NAME == 'trutv:v2'
    assert ttv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:36:08.406820
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')
    assert(TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert(TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1')

# Generated at 2022-06-22 08:36:09.349866
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:36:19.089328
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    data = TruTVIE()
    assert(data._VALID_URL) == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:36:30.183672
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:36:41.889145
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:36:42.856856
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:36:46.294769
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert isinstance(obj, TruTVIE)
