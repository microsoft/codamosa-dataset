

# Generated at 2022-06-22 08:28:53.973896
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-22 08:29:06.171625
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'TruTV'
    assert ie.IE_DESC == 'TruTV shows'
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:13.162483
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-22 08:29:14.117727
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constructor_test_for_ie(TruTVIE)

# Generated at 2022-06-22 08:29:14.713139
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:18.381056
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/3880195/episodes.html')

# Generated at 2022-06-22 08:29:27.091339
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	class TestTruTVIE(TruTVIE):
		def _download_json(self, url, display_id, headers=None):
			return {'series': {'mediaId': '1234567890'}}


# Generated at 2022-06-22 08:29:28.334313
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-22 08:29:35.373078
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  assert TruTVIE()._VALID_URL=='https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-22 08:29:37.320711
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

    TruTVIE(None, None)


if __name__ == '__main__':
    test_TruTVIE()

# Generated at 2022-06-22 08:29:52.521337
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == "TruTVIE"
    assert TruTVIE.__module__ == "youtube_dl.extractor.trutv"
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:54.783741
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert 'TruTVIE' in globals()
    assert TruTVIE is not None


# Generated at 2022-06-22 08:30:02.497054
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	ie = TruTVIE()
	assert ie.name == 'TruTV'
	assert TruTVIE.IE_NAME == 'TruTV'
	assert ie.name == TruTVIE.IE_NAME
	assert ie.description == 'TruTV is an American cable and satellite television channel'
	assert ie.valid_url == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:03.175627
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:05.231315
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTV',TruTVIE.__name__)

# Test for method _real_extract of class TruTVIE

# Generated at 2022-06-22 08:30:16.259070
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj.url == None
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:17.056920
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:18.067523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE({})

# Generated at 2022-06-22 08:30:26.308502
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV_ie = TruTVIE()

    assert truTV_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:28.226920
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:30:46.228643
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize TruTVIE
    test = TruTVIE()
    # Test the _VALID_URL
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    match = re.match(TruTVIE._VALID_URL, url)
    assert match.groups() == ('the-carbonaro-effect', 'sunlight-activated-flower', None)
    # Test the real_extract
    # Check if the title match the expected result
    test._real_extract(url) == "Sunlight-Activated Flower"

# Generated at 2022-06-22 08:30:52.217707
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST.keys() == {'url', 'info_dict', 'params'}
    assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST['params']['skip_download'] == True
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:57.459116
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert(TruTVIE.__name__ == "TruTVIE")
    assert(TruTVIE.__doc__ == "")
    ttv_ie = TruTVIE()
    assert(ttv_ie.IE_NAME == "trutv")


# Unit tests for method of class TruTVIE

# Generated at 2022-06-22 08:30:58.108098
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-22 08:31:08.610715
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test for TruTVIE
    trutv_ie = TruTVIE()
    # test for regex expression
    regex = TruTVIE._VALID_URL
    # test for ._download_json
    def my_download_json(*args, **kwargs):
        return {
                'episode': {
                    'mediaId': 'd82368b9ed17ec97e98d87649ecae8d26e17cecb',
                }
            }
    trutv_ie._download_json = my_download_json
    # test for ._extract_ngtv_info
    def my_extract_ngtv_info(*args, **kwargs):
        return {
                'id': 'd82368b9ed17ec97e98d87649ecae8d26e17cecb',
            }
   

# Generated at 2022-06-22 08:31:10.160154
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Unit test for constructor of class TruTVIE"""
    TruTVIE()

# Generated at 2022-06-22 08:31:20.574250
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Function to test constructor of TruTVIE class """
    trutv_ie = TruTVIE()
    assert(trutv_ie.url_result('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
    assert(trutv_ie.url_result('https://www.trutv.com/full-episodes/the-carbonaro-effect/12426/sunlight-activated-flower/videos/sunlight-activated-flower.html?seasonNum=1'))
    assert(trutv_ie.url_result('https://www.trutv.com/full-episodes/the-carbonaro-effect/12426/sunlight-activated-flower/videos/sunlight-activated-flower.html?episodeNum=1'))

# Generated at 2022-06-22 08:31:24.896818
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit tests for TurnerBaseIE class.
    """
    from .test_turner import test_TurnerBaseIE
    test_TurnerBaseIE(TruTVIE, "TruTVIE")

# Generated at 2022-06-22 08:31:26.445932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE.__init__()
    TruTVIE()

# Generated at 2022-06-22 08:31:36.032522
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ttvie = TruTVIE()
    assert ttvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:31:57.448969
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._TEST == TruTVIE._TEST

# Generated at 2022-06-22 08:31:59.232229
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE()
    print(result)


# Generated at 2022-06-22 08:32:07.567545
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

    # Test of _VALID_URL
    match_1 = re.match(ie._VALID_URL, "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    match_2 = re.match(ie._VALID_URL, "https://www.trutv.com/shows/the-carbonaro-effect/1")

    assert(match_1)
    assert(match_2)

# Generated at 2022-06-22 08:32:08.231952
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:11.017616
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert isinstance(t,TruTVIE)


# Generated at 2022-06-22 08:32:12.081553
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:12.664439
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert True

# Generated at 2022-06-22 08:32:17.833622
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__dict__ == TurnerBaseIE.__dict__
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:32:21.115186
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Unit tests for TruTVIE class
# def test_TruTVIE_download():
#     TruTVIE().download(TruTVIE._TEST['url'])

# Generated at 2022-06-22 08:32:26.101127
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	TruTVIE().suitable(url)
	TruTVIE()._real_initialize()
	TruTVIE()._real_extract(url)

# Generated at 2022-06-22 08:33:19.236996
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test if constructor of TruTVIE works as it is expected
    """
    obj = TruTVIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:33:28.922967
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    from .test_helpers import find_testcase
    from .turner import TurnerBaseIE
    from .common import InfoExtractor
    from .youtube import YoutubeIE

    # Test extraction from constructor of class TruTVIE
    with find_testcase(TruTVIE, 'test_TruTVIE', 'test_TruTVIE', 'test_TruTVIE') as testcase:
        class TruTV_InfoExtractor(InfoExtractor):
            def __init__(self):
                super(TruTV_InfoExtractor, self).__init__()
                self.ie = TruTVIE()
        class TruTV_TurnerBaseIE(TurnerBaseIE):
            def __init__(self):
                super(TruTV_TurnerBaseIE, self).__init__()
                self.ie = TruTVIE()
       

# Generated at 2022-06-22 08:33:32.617208
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    test_obj = TruTVIE(test_url)
    print(test_obj)


# Generated at 2022-06-22 08:33:33.301574
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:35.725445
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie_test = TruTVIE()
    print(trutv_ie_test)

# Generated at 2022-06-22 08:33:36.958751
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	obj = TruTVIE()
	print(obj)

# Generated at 2022-06-22 08:33:37.845831
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()


# Generated at 2022-06-22 08:33:40.666197
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Generate an instance of TruTVIE"""
    get_test_TruTVIE = TruTVIE(True)
    assert isinstance(get_test_TruTVIE, TruTVIE)


# Generated at 2022-06-22 08:33:51.380154
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    constr = TruTVIE
    assert constr.ie_key() == "TruTV"
    assert constr.video_id_re == re.compile(r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-22 08:33:54.431327
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    # TODO: Review assertTrue implementation
    # assertTrue(isinstance(instance, TruTVIE))

# Generated at 2022-06-22 08:35:49.946014
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:35:57.891853
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-22 08:35:59.380388
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TurnerBaseIE)


# Generated at 2022-06-22 08:36:00.534338
# Unit test for constructor of class TruTVIE
def test_TruTVIE():  # noqa: N802
    assert TruTVIE(None)

# Generated at 2022-06-22 08:36:04.264343
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE("http://www.trutv.com/videos/carbonaro-effect/sunlight-activated-flower.html")
    assert obj.series_slug == "the-carbonaro-effect"
    assert obj.clip_slug == "sunlight-activated-flower"

# Generated at 2022-06-22 08:36:05.788326
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._downloader is not None

# Generated at 2022-06-22 08:36:07.400400
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    m = TruTVIE()
    assert 'Turner' in m.__repr__()


# Generated at 2022-06-22 08:36:11.334401
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.__name__ == 'TruTVIE'
    
if __name__ == '__main__':
    # Unit test for module trutv
    # Test the constructor of class TruTVIE
    test_TruTVIE()

# Generated at 2022-06-22 08:36:11.920588
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:36:12.543639
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()