

# Generated at 2022-06-22 08:28:55.023434
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-22 08:29:06.832386
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Valid URL
    test_TruTVIE = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') 
    assert test_TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))' 

    # InValid URL
    test_TruTVIE = TruTVIE('') 

# Generated at 2022-06-22 08:29:18.034613
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Checking for wrong class name, should give a type error
    pass
    # checking for passing of invalid number of input parameters
    # TestSource: Internet
    # Testcase 1: trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    # Testcase 2: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    # Testcase 3: http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    # Testcase 4: https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html
    # Testcase 5: trutv.com/shows/the-carbonaro-effect/videos/

# Generated at 2022-06-22 08:29:19.265484
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TruTVIE", "TruTVIE.test")

# Generated at 2022-06-22 08:29:27.905687
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.suitable(
        'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert TruTVIE.suitable(
        'https://www.trutv.com/full-episodes/76490/billions-shorting-the-delta-full-episode.html')
    assert TruTVIE.suitable(
        'https://www.trutv.com/full-episodes/76490')
    assert TruTVIE.suitable(
        'https://www.trutv.com/full-episodes/78486')

# Generated at 2022-06-22 08:29:32.494596
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie
    #assert ie.name == 'TruTV'
    #assert ie.description == 'TruTV.com'
    #assert ie.domain == 'www.trutv.com'

# Generated at 2022-06-22 08:29:38.857983
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE()
    assert trutvIE._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:42.513243
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # GIVEN a TruTVIE constructor
    # WHEN it is called with a TruTV url
    # THEN it should return a TruTVIE object
    assert isinstance(TruTVIE(), TruTVIE)

# Generated at 2022-06-22 08:29:43.143043
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:46.660272
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test TruTVIE constructor.
    t = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    # Test on the url parameter in _download_json
    assert t._download_json.url.endswith('web/series/clip/the-carbonaro-effect/sunlight-activated-flower')

# Generated at 2022-06-22 08:29:54.582666
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Make an object of TruTVIE and check if object is not null
    object = TruTVIE()
    assert object is not None


# Generated at 2022-06-22 08:29:55.195474
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:56.254106
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x =  TruTVIE()

# Generated at 2022-06-22 08:30:03.111672
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert t._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:30:15.104927
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an object for TruTVIE
    test_case_1 = TruTVIE("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert test_case_1._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:24.694690
# Unit test for constructor of class TruTVIE

# Generated at 2022-06-22 08:30:34.771273
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    rtv = TruTVIE()
    assert rtv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:42.607174
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
	assert TruTVIE._TEST['info_dict']['ext'] == 'mp4'
	assert TruTVIE._TEST['info_dict']['title'] == 'Sunlight-Activated Flower'

# Generated at 2022-06-22 08:30:43.425368
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TurnerBaseIE")

# Generated at 2022-06-22 08:30:44.260398
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test functionality of constructor
    TruTVIE()

# Generated at 2022-06-22 08:30:56.689362
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()



# Generated at 2022-06-22 08:31:02.534774
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Constructor argument url should be valid url
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

    # Constructor argument should raise exception if given invalid url
    try:
        TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower')
    except:
        pass


# Generated at 2022-06-22 08:31:13.634575
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test the constructor
    try:
        tru_tvIE = TruTVIE()
    except Exception as e:
        assert(False)

    # Test the empty url
    url = ""
    result = TruTVIE._VALID_URL_RE.match(url)
    assert(result is None)

    # Test the valid url
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    result = TruTVIE._VALID_URL_RE.match(url)
    assert(result is not None)
    assert("the-carbonaro-effect" == result.group("series_slug"))
    assert("sunlight-activated-flower" == result.group("clip_slug"))
    assert(result.group("id") is None)

   

# Generated at 2022-06-22 08:31:21.748284
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST['url'] == TruTVIE._VALID_URL.format(
        series_slug=TruTVIE._TEST['info_dict']['id'].split('.')[2],
        clip_slug=TruTVIE._TEST['info_dict']['id'].split('.')[3],
    )
    assert TruTVIE._TEST['url'] == TruTVIE._VALID_URL.format(
        series_slug='',
        clip_slug='',
        id=TruTVIE._TEST['info_dict']['id'].split('.')[0],
    )

# Generated at 2022-06-22 08:31:31.495013
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
   assert TruTVIE(test_opts={'verbose': True})._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-22 08:31:33.782263
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TypeError if TruTVIE constructor is called with empty argument
    try:
        TruTVIE()
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-22 08:31:38.765577
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    inst = TruTVIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:31:41.437800
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().extract_url("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-22 08:31:42.648596
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test case for creating TruTVIE
    module = TruTVIE()

# Generated at 2022-06-22 08:31:43.917011
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert isinstance(obj, TruTVIE)

# Generated at 2022-06-22 08:32:15.177588
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._TEST == {
        'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html',
        'info_dict': {
            'id': 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1',
            'ext': 'mp4',
            'title': 'Sunlight-Activated Flower',
            'description': "A customer is stunned when he sees Michael's sunlight-activated flower.",
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

# Generated at 2022-06-22 08:32:16.070647
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()


# Generated at 2022-06-22 08:32:16.645407
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:17.462975
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('test')

# Generated at 2022-06-22 08:32:19.369433
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE();
    assert obj is not None, "Object can't be instanciated"

# Generated at 2022-06-22 08:32:31.116760
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an object of class TruTVIE
    obj=TruTVIE()
    # Test TruTVIE class' constructor with valid URL
    try:
        obj._real_extract(obj._TEST['url'])
    except:
        assert False
    # Test TruTVIE class' constructor with invalid URL
    try:
        obj._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/")
    except:
        assert True
    # Test TruTVIE class' constructor with invalid URL
    try:
        obj._real_extract("https://www.trutv.com/shows/the-carbonaro-effect/videos/")
    except:
        assert True
    # Test TruTVIE class' constructor with invalid URL

# Generated at 2022-06-22 08:32:40.733439
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Initialize a class
    trutv = TruTVIE()

    # Check url
    url = "https://www.trutv.com/shows/the-carbonaro-effect/full-episodes/season-1/episode-1/magical-compost.html"
    check = trutv._VALID_URL == "^https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))$"

    # Check test
    test = trutv._TEST

# Generated at 2022-06-22 08:32:45.764851
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for valid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE(url)
    # Test for invalid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/video'
    TruTVIE(url)

# Generated at 2022-06-22 08:32:52.381632
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTVIE = TruTVIE({'IE': 'truTV'}, {'url': 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'})
    assert truTVIE.get_url(truTVIE.url) == 'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower'

# Generated at 2022-06-22 08:32:54.765511
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert "Turner" in TurnerBaseIE.__bases__
    assert "Turner" in TruTVIE.__bases__

# Generated at 2022-06-22 08:33:45.029903
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """Test TruTVIE"""
    # Arrange
    url = "https://www.trutv.com/shows/the-carbonaro-ef"
    # Act
    x = TruTVIE(url)
    # Assert 
    assert x != None, "Test failed: TruTVIE is None"

# Generated at 2022-06-22 08:33:49.867169
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE().extract_info('https://www.trutv.com/full-episodes/1055-monster-in-laws/videos/monster-in-laws-sneak-peek.html')
    TruTVIE().extract_info('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:34:01.359009
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Description:
        Tests to make sure that the TruTVIE constructor works as expected.
    """
    from .common import FakeYDL
    from .common import test_url
    from .common import test_result_data
    from .common import test_expected_data
    from .common import test_expected_result

    # Constructor test
    # The class being tested is the TruTVIE class.
    # The properties being tested are the id, title, and url properties.
    # The constructor will be passed a url and the video_id will be extracted from the url.
    # The expected_data will return a TruTVIE object with the url and video_id.
    # The result_data will be initialized to None and calls the test_url method to
    # perform the extraction.
    # The test_url method will then pass the expected_data

# Generated at 2022-06-22 08:34:08.046270
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    utils_test = __import__('utils')
    global utils
    utils = utils_test

    # Test function with valid url
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"

    extractor = TruTVIE()

    try:
        utils.replace_urlparse_attr(expect_warnings=True)
        extractor._match_id(url)
    finally:
        utils.revert_urlparse_attr()



# Generated at 2022-06-22 08:34:10.594055
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE()

# Generated at 2022-06-22 08:34:16.609383
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()._real_extract(url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    TruTVIE()._real_extract(url='https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:34:20.072137
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Add unit test code here
    ie = TruTVIE()
    ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:34:30.651976
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:34:38.570647
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'http://www.trutv.com/shows/full-episodes/1-800-lawncare/videos/sunlight-activated-flower.html'
    downloaded_obj = TruTVIE()
    trutv_obj = TruTVIE._real_extract(downloaded_obj,url)
    assert trutv_obj['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert trutv_obj['display_id'] == 'sunlight-activated-flower'
    assert trutv_obj['title'] == "Sunlight-Activated Flower"
    assert trutv_obj['description'] == "A customer is stunned when he sees Michael's sunlight-activated flower."

# Generated at 2022-06-22 08:34:40.134149
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(TruTVIE._downloader)


# Generated at 2022-06-22 08:36:43.190110
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:36:51.455312
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

    # Test TruTVIE as an instance of class TruTVIE
    test_TruTVIE = TruTVIE()

    # Test TruTVIE as an instance of class TurnerBaseIE
    test_TurnerBaseIE = TurnerBaseIE()
    print(isinstance(test_TruTVIE, test_TurnerBaseIE))
    assert isinstance(test_TruTVIE, test_TurnerBaseIE)

# Generated at 2022-06-22 08:36:52.681448
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    True

# Generated at 2022-06-22 08:36:57.781021
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    
    # Test with class constructor
    trutv_ie = TruTVIE()
    print(trutv_ie)
    
    # Test with str method
    print(str(trutv_ie))


# Generated at 2022-06-22 08:36:58.996716
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Create an instance of TruTVIE
    TruTVIE()

# Generated at 2022-06-22 08:37:00.896213
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """test for TruTVIE"""
    trutv = TruTVIE()
    print(trutv._VALID_URL)


# Generated at 2022-06-22 08:37:10.129220
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    file_url = "https://api.trutv.com/v2/web/episode/tru-tv/im-sorry/702350"
    data = TruTVIE()._download_json(file_url, video_id="702350")['episode']
    assert data["mediaId"] == "e5d5b1c2f926b9091efd2d0e6ac8e0a318b9923d"
    assert data["title"] == "I’m Sorry"
    TruTVIE()._extract_ngtv_info(data["mediaId"], {}, site_name='truTV')

# Generated at 2022-06-22 08:37:18.406838
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    ie.suitable('https://www.trutv.com/shows/the-curse-of-oak-island/videos/5610-season-1-ep-9-drilling-down.html')
    ie.suitable('https://www.trutv.com/shows/the-curse-of-oak-island/videos/5610')
    ie.suitable('https://www.trutv.com/full-episodes/5610')
    ie.suitable('https://www.trutv.com/full-episodes/1')

# Generated at 2022-06-22 08:37:23.255146
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        url1 = "http://www.trutv.com/full-episodes/9-8-14"
        ie = TruTVIE()
        ie._real_extract(url1)
    except:
        assert False, "Fail to construct TruTVIE"


# Generated at 2022-06-22 08:37:25.288281
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	
	# Test whether class TruTVIE is successfully constructed.
	TruTVIE()._TEST