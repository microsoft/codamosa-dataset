

# Generated at 2022-06-22 08:29:01.972813
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_item = TruTVIE(TurnerBaseIE())
    assert test_item._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert test_item._NETRC_MACHINE == 'trutv'
    assert test_item.IE_NAME == 'trutv'

# Generated at 2022-06-22 08:29:13.187930
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:13.834835
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	assert TruTVIE()

# Generated at 2022-06-22 08:29:17.539445
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_truTVIE = TruTVIE()
    print('Testing TruTVIE:')
    print('    assert reelgoodIE')

# Generated at 2022-06-22 08:29:17.989842
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:21.414519
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Arrange
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    instance = TruTVIE()
    # Act & Assert
    instance._real_extract(url)

# Generated at 2022-06-22 08:29:23.726046
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	trutv_IE = TruTVIE("TruTVIE")
	assert trutv_IE.__class__.__name__ == "TruTVIE"

# Generated at 2022-06-22 08:29:24.453773
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:28.917918
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # we can keep the same API to construct a new object
    trutv = TruTVIE()

    # we can also use class name as constructor
    trutv = globals()["TruTVIE"]()

    # Unit test code, dont care about return value
    trutv

# Generated at 2022-06-22 08:29:34.702706
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    globaal_TruTVIE = TruTVIE()
    # This line is only meant for test without the ball functioning
    # TruTVIE.download = lambda self, url: True
    globaal_TruTVIE.download("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")

# Generated at 2022-06-22 08:29:45.289330
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:29:46.863142
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_class = TruTVIE()

# Generated at 2022-06-22 08:29:48.877706
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Test the constructor of class TruTVIE
    """
    assert TruTVIE



# Generated at 2022-06-22 08:29:51.715063
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test for TruTVIE inheriting from base class TurnerBaseIE
    assert isinstance(TruTVIE(), TurnerBaseIE)

# Generated at 2022-06-22 08:29:55.471230
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
        Unit test for constructor of class TruTVIE
        """
    trutv_ie = TruTVIE()
    trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:29:56.858898
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # implement your unit test here.
    # this is just example.
    assert True

# Generated at 2022-06-22 08:29:57.890193
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:00.850383
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvIE = TruTVIE('abc')
    assert isinstance(trutvIE, TruTVIE)

# test_TruTVIE()

# Generated at 2022-06-22 08:30:02.153117
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    x = TruTVIE()
    print(x)

# Generated at 2022-06-22 08:30:05.690038
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    TruTVIE = TruTVIE()
    result = TruTVIE.extract(url)
    print(result)


# Generated at 2022-06-22 08:30:16.297060
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
     tt = TruTVIE()

# Generated at 2022-06-22 08:30:17.290093
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("TruTVIE")

# Generated at 2022-06-22 08:30:22.062457
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    #print("Unit test for constructor of class TruTVIE")
    #TruTVIE()
    pass

# Generated at 2022-06-22 08:30:24.421141
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE().suitable('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html') is True

# Generated at 2022-06-22 08:30:25.026491
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:25.701736
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-22 08:30:26.765293
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    if False:
        TruTVIE()

# Generated at 2022-06-22 08:30:39.025563
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()

# Generated at 2022-06-22 08:30:44.559735
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert isinstance(t, TurnerBaseIE)
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-22 08:30:49.939532
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-22 08:31:12.367923
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Testing constructor with valid url
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    ttv = TruTVIE(url)
    assert ttv

# Generated at 2022-06-22 08:31:15.214097
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    '''
    This function creates an instance of class TruTVIE
    '''
    IE_object = TruTVIE()
    assert isinstance(IE_object, TruTVIE)

# Generated at 2022-06-22 08:31:15.854481
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:18.090345
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:31:27.065599
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Tests TruTVIE constructor created from TurnerBaseIE (as well as some methods) """
    ie = TruTVIE();

    # Test that Url matches for TruTVIE and
    m = TruTVIE._VALID_URL
    path = "f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1/web/episode"
    series_slug = "the-carbonaro-effect"
    clip_slug = "sunlight-activated-flower"
    video_id = "1696538"
    base_url = "https://media.services.turner.com/tbs/video/services/ngtv/media/"

    # try to extract three different variables
    assert ie._extract_ngtv_info(path, series_slug, clip_slug) == base_url

# Generated at 2022-06-22 08:31:31.185840
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    test_TruTVIE = trutv_ie.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert test_TruTVIE


# Generated at 2022-06-22 08:31:39.220928
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    video_details = TruTVIE()._real_extract(url)
    assert video_details['video_id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    assert video_details['title'] == 'Sunlight-Activated Flower'
    assert video_details['episode_id'] == 'e341698e52d93df96f9ff5cc6ceb0f0d02f6823c'
    assert video_details['series'] == 'Carbonaro Effect'

# Generated at 2022-06-22 08:31:39.939263
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:31:43.402313
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """ Unit test for constructor of class TruTVIE """
    obj = TruTVIE("http://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")
    assert obj.__class__.__name__ == "TruTVIE"

# Generated at 2022-06-22 08:31:46.137008
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert isinstance(t, TruTVIE)

# Generated at 2022-06-22 08:32:26.177901
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie.IE_NAME == 'trutv:trutv'


# Generated at 2022-06-22 08:32:30.013373
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj_TruTVIE = TruTVIE()
    print(obj_TruTVIE)

if __name__ == '__main__': test_TruTVIE()

# Generated at 2022-06-22 08:32:30.633190
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:31.273581
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:32.027340
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-22 08:32:34.621581
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:35.259478
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:35.844474
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:37.443170
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for TruTVIE class
    """
    test = TruTVIE()
    test.suite()

# Generated at 2022-06-22 08:32:46.193419
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of class TruTVIE
    """
    # get data from official website
    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    data = TruTVIE._download_json(TruTVIE._VALID_URL, 'https://api.trutv.com/v2/web/series/clip/the-carbonaro-effect/sunlight-activated-flower')
    print(data)

# Generated at 2022-06-22 08:34:24.825094
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutvie = TruTVIE()
    assert trutvie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:34:34.040932
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    """
        @staticmethod
        def ie_key():
            return 'trutv.com'
    """    
    assert t.ie_key() == 'trutv.com'
    """
        def _real_extract(self, url)
    """
    # test _real_extract function via _VALID_URL
    """
        _VALID_URL = 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    """
    # modify _VALID_URL
    TruTVIE._VALID

# Generated at 2022-06-22 08:34:45.327155
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url1 = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    url2 = 'https://www.trutv.com/full-episodes/19841274/the-carbonaro-effect-sunlight-activated-flower.html'
    assert TruTVIE._VALID_URL.match(url1)
    assert TruTVIE._VALID_URL.match(url2)
    TruTVIE._TEST['url'] = url1
    TruTVIE._TEST['info_dict']['id'] = 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'
    TruTVIE._TEST['info_dict']['title'] = 'Sunlight-Activated Flower'
   

# Generated at 2022-06-22 08:34:56.291155
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # This is a test for the constructor of the TruTVIE class
    assert TruTVIE.__name__ == 'TruTVIE'
    # This is a test for the inheritance of the TruTVIE class
    assert issubclass(TruTVIE,TurnerBaseIE)

    url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    turner_base_ie = TruTVIE(url)

    # This is a test for class variables of the TruTVIE class
    turner_base_ie_cvariables = dir(turner_base_ie)
    assert '_VALID_URL' in turner_base_ie_cvariables
    assert '_TEST' in turner_base_ie_cvariables

# Generated at 2022-06-22 08:34:58.927417
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_constructor = TruTVIE(TurnerBaseIE())
    assert(trutv_constructor != None)


# Generated at 2022-06-22 08:34:59.643318
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:35:10.856701
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:35:11.879357
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Check constructor
    TruTVIE()

# Generated at 2022-06-22 08:35:15.719685
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit test for constructor of TruTVIE class
    """
    # Instantiating TruTVIE class
    trutv_test_instance = TruTVIE()

    # Checking if 'constructor' creates an instance of TruTVIE
    assert isinstance(trutv_test_instance, TruTVIE)

# Generated at 2022-06-22 08:35:19.354613
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    ie.download("https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html")