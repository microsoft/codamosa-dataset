

# Generated at 2022-06-22 08:28:53.931679
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:28:56.139511
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Test constructor of this class
    TruTVIE('TruTVIE',True,False,['www.youtube.com'])

# Generated at 2022-06-22 08:28:58.442523
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE("")._real_initialize()
    TruTVIE("")._real_extract("")
    TruTVIE("")


# Generated at 2022-06-22 08:29:00.375621
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    result = TruTVIE()
    assert(result != None)

# Generated at 2022-06-22 08:29:11.542276
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test1 = TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')
    assert test1._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:29:12.120606
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    pass

# Generated at 2022-06-22 08:29:12.691286
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE

# Generated at 2022-06-22 08:29:14.026363
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TurnerBaseIE.__name__, True)

# Generated at 2022-06-22 08:29:15.415372
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	obj = TruTVIE("extractor")
	print(obj)

# Generated at 2022-06-22 08:29:18.932278
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE._TEST["info_dict"]["description"] is not None
    assert TruTVIE._TEST["info_dict"]["title"] is not None
    assert TruTVIE._TEST["info_dict"]["id"] is not None
    return

# Generated at 2022-06-22 08:29:25.012037
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    """
    Unit Test for TruTVIE class constructor
    """
    import TruTVIE
    assert TruTVIE

# Generated at 2022-06-22 08:29:30.802495
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = TruTVIE._TEST["url"]
    expected_result = TruTVIE._TEST
    assert TruTVIE._VALID_URL == TruTVIE._TEST['url'], "Failed to construct URL of class TruTVIE"
    assert TruTVIE(expected_result)._VALID_URL == TruTVIE._TEST['url'], "Failed to construct TruTVIE class"
    assert TruTVIE(expected_result)._download_webpage(url, None) is not None, "Failed to download webpage of class TruTVIE"
    return url, expected_result

# Test for _real_extract of class TruTVIE

# Generated at 2022-06-22 08:29:32.285757
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('TruTVIE', 'TruTVIE')
    assert 1

# Generated at 2022-06-22 08:29:33.435942
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE(None)

# Generated at 2022-06-22 08:29:35.479776
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE.extract_title({
        'title': 'Extracted title'
    }) == 'Extracted title'

# Generated at 2022-06-22 08:29:42.070494
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    truTV = TruTVIE()
    print("\n=== Testing TruTVIE ===")
    print("TruTVIE info extraction: ", truTV.extract('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'))
    print("TruTVIE info extraction: ", truTV.extract('https://www.trutv.com/full-episodes/279053/'))

# Generated at 2022-06-22 08:29:52.007329
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE()._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:00.016393
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    assert TruTVIE(TurnerBaseIE._downloader)._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert TruTVIE(TurnerBaseIE._downloader)._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:30:10.897363
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_c = TruTVIE()
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:30:15.161696
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()
    TruTVIE()._download_webpage()
    TruTVIE()._download_json()
    TruTVIE()._extract_ngtv_info()


# Generated at 2022-06-22 08:30:27.834215
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_instance = TruTVIE()
    assert trutv_instance._VALID_URL
    assert trutv_instance._TEST
    assert trutv_instance._download_json

# Generated at 2022-06-22 08:30:39.583218
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	trutv = TruTVIE()
	assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
	assert TruTVIE._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	assert TruTVIE._TEST['info_dict']['id'] == 'f16c03beec1e84cd7d1a51f11d8fcc29124cc7f1'

# Generated at 2022-06-22 08:30:40.190804
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-22 08:30:42.332761
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # TruTVIE constructor function test
    return TruTVIE

if __name__ == '__main__':
    TruTVIE()

# Generated at 2022-06-22 08:30:42.877524
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:30:44.056331
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    instance = TruTVIE()
    assert isinstance(instance, TruTVIE)

# Generated at 2022-06-22 08:30:45.163975
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()
    assert test_TruTVIE

# Generated at 2022-06-22 08:30:45.651293
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	TruTVIE()

# Generated at 2022-06-22 08:30:54.141824
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
	truTVInfo = TruTVIE()

	url = 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
	series_slug, clip_slug, video_id = re.match(truTVInfo._VALID_URL, url).groups()

	if video_id:
		path = 'episode'
		display_id = video_id
	else:
		path = 'series/clip'
		display_id = clip_slug

	data = truTVInfo._download_json(
		'https://api.trutv.com/v2/web/%s/%s/%s' % (path, series_slug, display_id),
		display_id)
	video_data = data['episode']

# Generated at 2022-06-22 08:30:57.243486
# Unit test for constructor of class TruTVIE
def test_TruTVIE():

	# Test true scenario
	assert TruTVIE()

	# Test false scenario
	assert TruTVIE() is None


# Generated at 2022-06-22 08:31:17.368553
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Assert if the object is created
    assert(TruTVIE is not None)

# Generated at 2022-06-22 08:31:26.484444
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert(obj._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))')

# Generated at 2022-06-22 08:31:27.313769
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_TruTVIE = TruTVIE()

# Generated at 2022-06-22 08:31:30.341816
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    TruTVIE()._real_extract(url)
# end of test

# Generated at 2022-06-22 08:31:39.400480
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # pylint: disable=protected-access
    assert TruTVIE._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

    # pylint: disable=protected-access
    truTV = TruTVIE._build_ie('truTV')

    assert TruTVIE._TEST.get('url') == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'
    assert TruTVIE._TEST.get('info_dict').get('id')

# Generated at 2022-06-22 08:31:46.914575
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    content_test_url = "https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    assert TruTVIE()._VALID_URL == TruTVIE._VALID_URL, "Test configuration of class TruTVIE is changed"
    assert TruTVIE()._TEST['url'] == content_test_url, "Test url for TruTVIE is changed"

    # Testing TruTVIE.extract
    content_test_truTV_ie = TruTVIE()._real_extract(content_test_url)
    assert TruTVIE()._TEST['info_dict'] == content_test_truTV_ie, "Extract of TruTVIE changed"

# Generated at 2022-06-22 08:31:55.025733
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    if True:
        # test instanciation of class
        video = TruTVIE()

    # test access to protected member (but ok, since it is a test)
    if True:
        assert video._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:32:07.114289
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    params = {}

# Generated at 2022-06-22 08:32:09.308531
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:32:19.549306
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv_ie = TruTVIE()
    assert trutv_ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'
    assert trutv_ie._TEST['url'] == 'https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html'

# Generated at 2022-06-22 08:33:05.134446
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t._VALID_URL == 'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:33:17.357498
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  obj0 = TruTVIE()
  # Test obj0 has the right attributes
  assert obj0.SUCCESS == 0, "SUCCESS should be 0"
  assert obj0.FAILURE == 1, "FAILURE should be 1"
  assert obj0.EXPIRED == 2, "EXPIRED should be 2"

# Generated at 2022-06-22 08:33:19.928231
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        trutvIE = TruTVIE()
        assert True
    except:
        assert False

# Generated at 2022-06-22 08:33:22.540972
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    try:
        TruTVIE({})
    except Exception as e:
        raise AssertionError("Unexpected exception while instantiating TruTVIE: %s" % e)

# Generated at 2022-06-22 08:33:33.783243
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'

# Generated at 2022-06-22 08:33:36.576670
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # test TruTVIE class
    TruTVIE()

#Unit test for method real_extract(url) of class TruTVIE

# Generated at 2022-06-22 08:33:37.073572
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:33:41.933897
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    url="https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html"
    True_TV_clip = TruTVIE()._real_extract(url)
    print(True_TV_clip)

# Generated at 2022-06-22 08:33:48.923230
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    ie = TruTVIE()

    # instance of the class should be created
    assert ie is not None

    # check for valid video
    info = ie._real_extract(ie._TEST['url'])
    assert info is not None

    # check whether required fields are set or not
    assert info['title'] == ie._TEST['info_dict']['title']
    assert info['description'] == ie._TEST['info_dict']['description']
    assert info['id'] == ie._TEST['info_dict']['id']

# Generated at 2022-06-22 08:33:51.712011
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    t = TruTVIE()
    assert t
    assert t.ie_key() == 'TruTV'
    assert t.ie_codec() == 'TruTv'

# Generated at 2022-06-22 08:35:37.068548
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('https://www.trutv.com/shows/the-carbonaro-effect/videos/sunlight-activated-flower.html')

# Generated at 2022-06-22 08:35:38.482918
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Expected result: class TruTVIE is created
    TruTVIE()

# Generated at 2022-06-22 08:35:44.482728
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    trutv = TruTVIE()
    assert trutv._VALID_URL == r'https?://(?:www\.)?trutv\.com/(?:shows|full-episodes)/(?P<series_slug>[0-9A-Za-z-]+)/(?:videos/(?P<clip_slug>[0-9A-Za-z-]+)|(?P<id>\d+))'


# Generated at 2022-06-22 08:35:52.959435
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    test_cases = [True, False]
    for test_case in test_cases:
        trutv_ie = TruTVIE(test_case)
        assert (trutv_ie.suitable(test_case) == test_case)
        assert(trutv_ie.IE_NAME == 'trutv')
        assert(trutv_ie.IE_DESC == 'Turner Broadcasting System: truTV')
        assert(trutv_ie.BRANDING_ID == 'trutv')

# Generated at 2022-06-22 08:35:55.781650
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    # Set up instance of class TruTVIE
    inst = TruTVIE()

    # Ensure that the constructor takes 2 parameters and returns a subclass of the base class
    assert inst.__init__.__code__.co_argcount == 2
    assert issubclass(type(inst), TurnerBaseIE)

# Generated at 2022-06-22 08:35:58.055332
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
  Test = TruTVIE()


# Generated at 2022-06-22 08:35:59.147509
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    obj = TruTVIE()
    assert obj
    return obj.test()

# Generated at 2022-06-22 08:35:59.800542
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:36:00.834211
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE()

# Generated at 2022-06-22 08:36:02.777061
# Unit test for constructor of class TruTVIE
def test_TruTVIE():
    TruTVIE('test')
# Test the function TruTVIE._real_extract()