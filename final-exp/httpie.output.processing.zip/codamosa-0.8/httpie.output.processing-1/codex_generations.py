

# Generated at 2022-06-11 23:58:47.818811
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    ret = Formatting.format_headers
    assert ret('') == ''



# Generated at 2022-06-11 23:58:55.372357
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    fmt = Formatting(['html'])
    content = '''
        {
            "members": [
                {
                    "id": 1,
                    "name": "john",
                    "email": "john@example.com"
                },
                {
                    "id": 2,
                    "name": "doe",
                    "email": "doe@example.com"
                }
            ]
        }
    '''
    mime = 'application/json'
    format_info = fmt.format_body(content, mime)

# Generated at 2022-06-11 23:59:00.539333
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors', 'formatters']
    f = Formatting(groups, env)
    assert_equals(f.enabled_plugins[0].__class__.__name__, 'ColorsFormatter')
    assert_equals(f.enabled_plugins[1].__class__.__name__, 'FormatFormatter')


# Generated at 2022-06-11 23:59:06.486185
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not is_valid_mime("json")
    assert not is_valid_mime("xml")
    assert is_valid_mime("application/json")
    assert is_valid_mime("application/xml")
    assert is_valid_mime("text/html")
    assert not is_valid_mime("")
    assert not is_valid_mime("application/")
    assert not is_valid_mime("application")

# Generated at 2022-06-11 23:59:12.788630
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=["colors"])
    assert f.format_headers("HTTP/1.1 200 OK\nheader1:value1") == "\x1b[37mHTTP/1.1 \x1b[32m200 OK\x1b[39;49;00m\nheader1:\x1b[32mvalue1\x1b[39;49;00m"


# Generated at 2022-06-11 23:59:14.889463
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['Accept', 'Accept-Charset'], debug=True)
    assert f.enabled_plugins == [
        httpie.plugins.formatter.AcceptFormatter(debug=True),
        httpie.plugins.formatter.AcceptCharsetFormatter(debug=True)
    ]

# Generated at 2022-06-11 23:59:23.837349
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    result1 = Formatting(["headers"], options={"headers": ["httpie==3.1.0"]}).format_headers('HTTP/1.1 200 OK\r\nServer: nginx/1.10.3 (Ubuntu)\r\nDate: Fri, 26 May 2017 14:01:13 GMT\r\nContent-Type: application/json\r\nContent-Length: 54\r\nkeep-alive: timeout=60\r\nConnection: keep-alive\r\nVary: Origin,Access-Control-Request-Method,Access-Control-Request-Headers\r\nAccess-Control-Allow-Origin: *\r\n\r\n')

# Generated at 2022-06-11 23:59:28.115210
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
	test_string = 'application/javascript'
	conver = Conversion.get_converter(test_string)
	assert isinstance(conver, ConverterPlugin)
	assert conver.mime == 'application/javascript'



# Generated at 2022-06-11 23:59:35.153129
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie import OutputFile
    from httpie.output.streams import StreamUnicodeIO
    from httpie.output.formatters import Formatter

    groups = ['json', 'colors']
    kwargs = {
        'stream': OutputFile(StreamUnicodeIO()),
        'isatty': True,
        'colors': True,
        'flow_style': False,
        # 'convert_headers': False,
        'pretty': True,
        'verbose': True
    }
    test_formatting = Formatting(groups, **kwargs)
    # test case 1: normal case
    content1 = "{'color':'red black blue', 'color_format':{'color_first':'red black blue'}}"
    mime1 = 'application/json'
    expected_output1_list

# Generated at 2022-06-11 23:59:38.389382
# Unit test for constructor of class Formatting
def test_Formatting():
    print('\nIn test_Formatting():')
    f = Formatting(groups=['colors'])
    assert f  # TODO: what is the use of this test?


# Generated at 2022-06-11 23:59:42.614679
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'], scheme='http', host='example.org')
    print(f.enabled_plugins)

# Generated at 2022-06-11 23:59:49.193952
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt = Formatting(["SyntaxHighlight"])
    assert fmt.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12') == 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12'


# Generated at 2022-06-11 23:59:59.454165
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    result = Formatting(
        groups=["statusline", "headers"],
        env=Environment()
    ).format_headers(
        "\n".join([
            "HTTP/1.1 200 OK",
            "Accept-Ranges: bytes",
            "Allow: GET, HEAD",
            "Connection: close",
            "Content-Type: text/html",
            "Date: Tue, 16 Jun 2020 14:36:19 GMT",
            "Server: Apache/2.4.10 (Debian)",
            "Vary: Accept-Encoding",
            "Content-Length: 1584",
            "",
            "X-hacker: <script>alert('no')</script>"
        ])
    )
    print(result)

# Generated at 2022-06-12 00:00:11.158460
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    response_headers = '''HTTP/1.1 200 OK
    Date: Wed, 21 May 2020 15:46:22 GMT
    Server: Apache/2.4.18 (Ubuntu)
    Last-Modified: Wed, 21 May 2020 15:46:22 GMT
    ETag: "5cde7eae-136"
    Accept-Ranges: bytes
    Content-Length: 310
    Vary: Accept-Encoding,User-Agent
    Content-Type: text/html; charset=UTF-8'''

    formatting = Formatting(groups=['style'])
    headers = formatting.format_headers(response_headers)

# Generated at 2022-06-12 00:00:13.495035
# Unit test for constructor of class Formatting
def test_Formatting():
    # when
    formatting = Formatting(groups=["body", "headers", "debug"])
    # then
    assert isinstance(formatting, Formatting)


# Generated at 2022-06-12 00:00:20.803635
# Unit test for constructor of class Formatting
def test_Formatting():
    if __name__ == '__main__':
        print('Test for constructor of class Formatting')
        env = Environment()
        # Test with no arguments
        try:
            f = Formatting()
        except TypeError as e:
            print(e)
        # Test with argument groups
        try:
            f = Formatting(groups=[])
        except TypeError as e:
            print(e)
        # Test with argument env
        try:
            f = Formatting(env=env)
        except TypeError as e:
            print(e)
        # Test with argument env, groups
        try:
            f = Formatting(groups=[], env=env)
        except TypeError as e:
            print(e)


# Generated at 2022-06-12 00:00:31.324904
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    json_b = '{"firstName": "John", "lastName": "Smith", "age": 25}'
    json_bf = '{\n    "firstName": "John",\n    "lastName": "Smith",\n    "age": 25\n}'
    json_a = '{ \"firstName\": \"John\", \"lastName\": \"Smith\", \"age\": 25 }'
    json_af = '{ \"firstName\": \"John\", \"lastName\": \"Smith\", \"age\": 25 }'
    xml_b = '<note><to>Tove</to><from>Jani</from><heading>Reminder</heading><body>Don\'t forget me this weekend!</body></note>'

# Generated at 2022-06-12 00:00:35.517191
# Unit test for constructor of class Formatting
def test_Formatting():
    xs = Formatting(['json', 'colors'])
    assert xs.enabled_plugins[0].__class__.__name__ == 'JSONFormatter'
    assert xs.enabled_plugins[1].__class__.__name__ == 'ColoredResponseBodyFormatter'


# Generated at 2022-06-12 00:00:44.350490
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import pytest
    print("test_Formatting_format_body()")

    fmt_json = Formatting(['json'])
    fmt_json_indent = Formatting(['json'], indent=2)
    fmt_json_color = Formatting(['json', 'colors'])
    fmt_json_indent_color = Formatting(['json', 'colors'], indent=2)

    txt = "{\n  \"foo\": 1,\n  \"bar\": \"baz\"\n}"
    fmt_json.format_body(txt, "application/json")
    fmt_json_indent.format_body(txt, "application/json")
    fmt_json_color.format_body(txt, "application/json")

# Generated at 2022-06-12 00:00:45.080669
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting([])

# Generated at 2022-06-12 00:00:56.990235
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=['colors'], env=Environment(),
                   color_scheme_style='monokai',
                   color_scheme='monokai')
    print(f.new_style.style_error)
    content = '''HTTP/1.1 200 OK
Content-Type: text/plain; charset=utf-8
Content-Length: 23
Date: Thu, 24 Aug 2017 11:33:42 GMT
Connection: keep-alive
Server: nginx/1.10.3 (Ubuntu)

HelloWorld
'''
    print(f.format_headers(content))



# Generated at 2022-06-12 00:00:58.333498
# Unit test for constructor of class Formatting
def test_Formatting():
    groups=['colors']
    formatters = Formatting(groups=groups)
    assert len(formatters) == 1

# Generated at 2022-06-12 00:01:00.897565
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.gzip = True
    conversion = Formatting(["gzip"], env=env)
    headers = conversion.format_headers("Accept-Encoding: gzip")
    assert headers =="Accept-Encoding: gzip"



# Generated at 2022-06-12 00:01:05.670285
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    Test method Formatting.format_body.
    """
    import json
    # JsonProcessor should be enabled by default.
    # And JsonProcessor.format_body() should be invoked.
    formatting = Formatting(['colors'])
    x = json.dumps({'b': 2, 'a': 1})
    assert formatting.format_body(x, 'application/json') != x

# Generated at 2022-06-12 00:01:16.037230
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    body_json={'msg':'it is a test'}
    body_json_str=json.dumps(body_json, indent=2)
    # test when mime is a invalid mime type
    # format_body should output the unformatted content
    env = Environment(colors=False)
    fmt = Formatting(env=env, groups=['colors'], colors=True, stream=False)
    body_format=fmt.format_body(body_json_str, mime='invalid_mime')
    assert body_format==body_json_str
    # test when mime is a valid mime type
    body_format=fmt.format_body(body_json_str, mime='application/json')
    assert body_format==body_json_str


# Generated at 2022-06-12 00:01:19.108128
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatter = Formatting()
    assert(formatter.format_headers("hello: world\n") == "hello: world\n")


# Generated at 2022-06-12 00:01:21.535509
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_plugin = Conversion.get_converter('text/html')
    assert converter_plugin == None


# Generated at 2022-06-12 00:01:31.229334
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Get the reference to the function `format_body`.
    format_body = Formatting.format_body.__func__

    assert format_body("Hallo", "text/plain") == "Hallo"
    assert format_body("Hallo", "text/plain;charset=utf-8") == "Hallo"
    assert format_body("Hallo", "text/html") == "Hallo"
    assert format_body("Hallo", "application/json") == "Hallo"

    assert format_body("<b>Hallo</b>", "text/html") == "<b>Hallo</b>"

    #Test to see how the function handles invalid MIME
    assert format_body("Hallo", "") == "Hallo"
    assert format_body("Hallo", "text/") == "Hallo"

# Generated at 2022-06-12 00:01:35.875323
# Unit test for constructor of class Formatting
def test_Formatting():
    assert(len(Formatting(["color"]).enabled_plugins) == 1)
    assert(len(Formatting(["color","browser"]).enabled_plugins) == 2)
    assert(len(Formatting().enabled_plugins) == 0)
    assert(len(Formatting(["color","invalid_name"]).enabled_plugins) == 1)


# Generated at 2022-06-12 00:01:36.848841
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter.mime == "application/json"

# Generated at 2022-06-12 00:01:42.482882
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.mime == 'application/json'


# Generated at 2022-06-12 00:01:46.209451
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.__class__.__name__ == 'JSONConverter'
    converter = Conversion.get_converter('application/xml')
    assert converter.__class__.__name__ == 'XMLConverter'

# Generated at 2022-06-12 00:01:48.798896
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    JSON_MIME = "application/json"
    converter = Conversion.get_converter(JSON_MIME)
    assert converter.mime == JSON_MIME


# Generated at 2022-06-12 00:01:52.745595
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter: ConverterPlugin = Conversion.get_converter(mime='application/json')
    assert converter.name == 'json'
    assert converter.mime == 'application/json'
    assert converter.extension == 'json'
    assert converter.to_terminal_formatter_index == 0

# Generated at 2022-06-12 00:01:53.608003
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    pass


# Generated at 2022-06-12 00:01:55.835825
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    Conversion_get_converter_obj = Conversion()
    assert Conversion_get_converter_obj.get_converter("application/xml") is not None

# Generated at 2022-06-12 00:02:05.170798
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test: Return JsonConverterPlugin
    assert(type(Conversion.get_converter('application/json')) == type(JsonConverterPlugin))
    # Test: Return JsonPrettyConverterPlugin
    assert(type(Conversion.get_converter('application/json-pretty')) == type(JsonPrettyConverterPlugin))
    # Test: Return JsonPrettyConverterPlugin
    assert(type(Conversion.get_converter('application/jsonpretty')) == type(JsonPrettyConverterPlugin))
    # Test: Return YamlConverterPlugin
    assert(type(Conversion.get_converter('application/yaml')) == type(YamlConverterPlugin))
    # Test: Return YamlPrettyConverterPlugin

# Generated at 2022-06-12 00:02:14.154437
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class HeadersFormatterPlugin:
        def __init__(self, **kwargs):
            pass
        def format_headers(self, headers: str) -> str:
            return headers.replace("content-type", "Content-Type")
    plugin_manager.get_formatters_grouped = lambda: {
        'headers': [HeadersFormatterPlugin]
    }
    lines = "content-type: something/else\nother-header: whatever".split("\n")
    formatter = Formatting(['headers'])
    lines = [formatter.format_headers(l) for l in lines]
    assert lines == ["Content-Type: something/else", "other-header: whatever"]


# Generated at 2022-06-12 00:02:16.086888
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'),
                      ConverterPlugin)



# Generated at 2022-06-12 00:02:18.683823
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    content = 'testing'
    f = Formatting(['colors'])
    new = f.format_headers(content)
    assert content == new

# Generated at 2022-06-12 00:02:32.889485
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Case no.1: Passed a string that is not a valid MIME type
    # Expected: Original string will not be changed
    # Result: Correct!
    string_not_mime = "TEST"
    group = ['Uppercase', 'JSONPrettyPrint']
    env = Environment()
    formatter = Formatting(groups=group, env=env)
    result = formatter.format_body(string_not_mime, string_not_mime)
    assert string_not_mime == result

    # Case no.2: Passed a string and a valid MIME type
    # Expected: Original string will be changed by plugins
    # Result: Correct!
    string_mime = "TEST"
    group = ['Uppercase', 'JSONPrettyPrint']
    env = Environment()

# Generated at 2022-06-12 00:02:34.483166
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['appjson']
    env = Environment()
    Formatting(groups, env)

# Generated at 2022-06-12 00:02:44.628432
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import json


# Generated at 2022-06-12 00:02:47.011391
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['html', 'colors']
    env = Environment()
    formats = Formatting(groups, env)
    assert formats

# Generated at 2022-06-12 00:02:54.694530
# Unit test for constructor of class Formatting
def test_Formatting():
    test_values = [{'groups': ['colors'], 'env': Environment(),
                    'kwargs': {'colors': ['blue'],
                               'explicit_json': False,
                               'max_json_pp_depth': None,
                               'pprint': True}},
                   {'groups': ['colors'], 'env': Environment(),
                    'kwargs': {'colors': ['blue'],
                               'explicit_json': True,
                               'max_json_pp_depth': None,
                               'pprint': True}}]
    for v in test_values:
        Formatting(**v)

# Generated at 2022-06-12 00:02:56.594015
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    p = Formatting(['auto'])
    print(p.format_body('{"a":"b"}','application/json'))


# Generated at 2022-06-12 00:03:01.071330
# Unit test for constructor of class Formatting
def test_Formatting():
    # TODO: Refactor and integrate environment data into the unit test.
    groups = ['colors']
    env = Environment()
    kwargs = {}
    some_obj = Formatting(groups=groups, env=env, **kwargs)
    assert some_obj
    assert some_obj.enabled_plugins

# Generated at 2022-06-12 00:03:11.001064
# Unit test for constructor of class Formatting
def test_Formatting():
    import sys
    import os
    from httpie.outputhook import OutputHook
    from httpie import __version__
    from httpie.utils import sizeof_fmt
    from httpie.config import DEFAULT_CONFIG_DIR
    from httpie.plugins import BuiltinPlugin


# Generated at 2022-06-12 00:03:12.456716
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors'])
    assert fmt.enabled_plugins

# Generated at 2022-06-12 00:03:21.721341
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    "Test method get_converter of class Conversion"
    print_test_title("test_Conversion_get_converter", "Test method get_converter of class Conversion")
    # create a converter that supports 'json'
    conv = Conversion.get_converter('json')
    # test that the returned converter is not null
    assert conv is not None
    # test that the returned converter is of type ConverterPlugin
    assert isinstance(conv, ConverterPlugin)
    # test that the returned converter supports 'json'
    assert conv.supports('json')
    # test that the returned converter does not support 'text'
    assert not conv.supports('text')
    # create a converter that supports 'application/json'
    conv = Conversion.get_converter('application/json')
    # test that the returned converter is not

# Generated at 2022-06-12 00:03:26.375345
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    f = Formatting(groups, env)
    assert f is not None


# Generated at 2022-06-12 00:03:35.273364
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Create an instance of Formatting
    fmt = Formatting(['colors'])
    # Define the original headers
    headers = 'HTTP/1.1 200 OK\nAccept: */*\nContent-Type: text/html; charset=utf-8\n'
    # Define the expected headers
    expected_headers = '\x1b[1mHTTP/1.1 200 OK\nAccept: */*\nContent-Type: text/html; charset=utf-8\n\x1b[0m'
    # Get the result of formatting headers
    result_headers = fmt.format_headers(headers)

    assert expected_headers == result_headers

# Generated at 2022-06-12 00:03:36.607200
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    formatting = Formatting(["headers", "body"], env=env)

# Generated at 2022-06-12 00:03:39.205647
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/plain') is None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None


# Generated at 2022-06-12 00:03:43.795231
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    fmt = Formatting(groups=[], env=env, indent=2, sort_keys=False,
                     disable_colors=True)
    content = '{"message": "hello"}'
    mime = 'application/json'
    expected = '{\n  "message": "hello"\n}\n'
    assert fmt.format_body(content, mime) == expected

# Generated at 2022-06-12 00:03:51.148785
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print('Testing for method format_headers of class Formatting ... ', end='')
    try:
        f = Formatting(['colors'])
        assert f.format_headers('{"key": "value"}') == '{\x1b[36m"key"\x1b[39m:\x1b[33m "value"\x1b[39m}'
    except:
        print('Fail')
    else:
        print('Pass')


# Generated at 2022-06-12 00:03:59.969392
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Arrange
    class MyConverter(ConverterPlugin):
        @classmethod
        def supports(cls, mime):
            return 'application/x-httpie-unittest' == mime

        def convert_body(self, body, to_mime):
            return body

    class MyConverter2(ConverterPlugin):
        @classmethod
        def supports(cls, mime):
            return 'application/x-httpie-unittest' == mime

        def convert_body(self, body, to_mime):
            return body

    plugin_manager.register_converter_class(MyConverter)
    plugin_manager.register_converter_class(MyConverter2)

    # Act

# Generated at 2022-06-12 00:04:06.772292
# Unit test for constructor of class Formatting
def test_Formatting():
    # Creating an instance of class Formatting
    formatting = Formatting(["color", "colors"], Environment(), style="paraiso-light")
    # Creating an instance of class Converter and finding the "color" plugin
    for enabled_plugin in formatting.enabled_plugins:
        if enabled_plugin.style == "paraiso-light":
            color_plugin = enabled_plugin
    # Check if the plugin is there
    assert color_plugin is not None
    # Check if the plugin is of type ColorFormatter
    assert isinstance(color_plugin, ColorFormatter)


# Generated at 2022-06-12 00:04:10.766857
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import httpie.output.formatters.colors
    env = Environment()
    formatter = Formatting(["colors"], env)
    assert formatter.format_headers("content-type: application/json") == """
HTTP/1.1 200 OK
content-type: application/json
"""

# Generated at 2022-06-12 00:04:17.317535
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.context import Environment
    env = Environment(stdout=True, stdin=True, ignore_stdin=True)
    g = Formatting(groups=['format', 'pretty'], env=env)
    headers = '''HTTP/1.1 200 OK
content-type: application/json'''
    result = g.format_headers(headers)
    print(result)
    assert result == '''HTTP/1.1 200 OK
content-type: application/json'''



# Generated at 2022-06-12 00:04:26.084636
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert (issubclass(type(converter), ConverterPlugin))
    assert (converter.supports("application/json"))
    converter = Conversion.get_converter("application/xml")
    assert (issubclass(type(converter), ConverterPlugin))
    assert (converter.supports("application/xml"))
    converter = Conversion.get_converter("text/html")
    assert (converter is None)


# Generated at 2022-06-12 00:04:35.644711
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Instance of class Formatting
    formatting = Formatting()
    # Case 1:
    # Input:
    # Content: {
    #	"id": 1,
    #	"name": "Leah"
    # }
    # MIME: application/json
    # Output:
    # {
    #    "id": 1,
    #    "name": "Leah"
    # }
    content = '{ "id": 1, "name": "Leah" }'
    mime = 'application/json'
    expected = '{\n    "id": 1,\n    "name": "Leah"\n}'
    assert formatting.format_body(content, mime) == expected

# Generated at 2022-06-12 00:04:41.789084
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    ascii = Conversion.get_converter('text/plain')
    assert ascii.convert('\xe7\x94\xb5') == '电'

    b64 = Conversion.get_converter('text/base64')
    assert b64.convert(b'\xe7\x94\xb5') == '鐢'

    xml = Conversion.get_converter('application/xml')
    assert xml.convert('<a><b>c</b></a>') == '<a>\n  <b>c</b>\n</a>'

# Generated at 2022-06-12 00:04:44.471127
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors', 'colors'])
    print(fmt)

if __name__ == '__main__':
    test_Formatting()

# Generated at 2022-06-12 00:04:45.283564
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    pass

# Generated at 2022-06-12 00:04:56.177137
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import httpie.plugins.builtin

    # Initialize Formatting object
    env1 = Environment()
    env2 = Environment()
    env2.colors.use_colors = False
    env1.colors.use_colors = False
    # There are two possible ways to initialize the Formatting object
    # One with the env reference and one with no env reference
    fmt1 = Formatting(['colors'], env1)
    fmt2 = Formatting(['colors'])
    # History is used to test if the formatting method format_headers works
    # properly, it records the two different results showed in the two terminals
    history = []
    # Test if the method format_headers can handle the status line
    status_line = 'HTTP/1.1 200 OK'

# Generated at 2022-06-12 00:04:58.710767
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_case1 = 'text/csv'
    # more tests to be added
    assert(Conversion.get_converter(test_case1) is not None)


# Generated at 2022-06-12 00:05:04.209836
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = """{"Code":1}"""
    mime = 'application/json'
    # test without json_plugin
    f = Formatting([])
    assert f.format_body(content, mime) == """{"Code":1}"""

    # test with json_plugin
    f = Formatting(['json'])
    assert f.format_body(content, mime) == """{\n    "Code": 1\n}"""

# Generated at 2022-06-12 00:05:07.387476
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # test happy case
    actual = Conversion.get_converter('application/json')
    assert actual.mime == 'application/json'

    # test invalid case
    actual = Conversion.get_converter('abc')
    assert actual is None



# Generated at 2022-06-12 00:05:18.152070
# Unit test for constructor of class Formatting
def test_Formatting():

    env = Environment(stdout=io.StringIO(),
                      colors=False,
                      pretty=False,
                      format=None,
                      print_body_only=False,
                      print_headers_only=False,
                      style='foo')

    # try with bad arguments
    try:
        f = Formatting(['json', 'pretty', 'request', 'response'], env=env, foo='bar')
    except Exception as exc:
        assert str(exc) == 'Bad argument: \'foo\''
    else:
        assert False

    f = Formatting(['json', 'pretty', 'request', 'response'], env=env)
    assert f.enabled_plugins == [JsonFormatter(env=env), PrettyFormatter(env=env), RequestFormatter(env=env),
                                 ResponseFormatter(env=env)]




# Generated at 2022-06-12 00:05:23.212849
# Unit test for constructor of class Formatting
def test_Formatting():
    c = Formatting(["json"])


# Generated at 2022-06-12 00:05:28.723474
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    print(available_plugins)
    print(available_plugins.items())
    print(available_plugins.keys())
    chosen_group = available_plugins['headers']
    print(chosen_group)
    for group in available_plugins.values():
        for cls in group:
            print(cls)

test_Formatting()


# Generated at 2022-06-12 00:05:31.292811
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    res = Conversion.get_converter('application/json')
    assert isinstance(res, ConverterPlugin)
    assert res.mime == 'application/json'

# Generated at 2022-06-12 00:05:38.896912
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in ['pygments']:
        for cls in available_plugins[group]:
            p = cls(env=Environment(colors=True))
            if p.enabled:
                enabled_plugins.append(p)
    headers = '''HTTP/1.1 200 OK
Date: Wed, 08 Jun 2016 15:31:46 GMT
Server: Apache
X-Powered-By: PHP/5.6.22
Content-Length: 11
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html; charset=UTF-8
'''
    headers = Formatting([]).format_headers(headers)

# Generated at 2022-06-12 00:05:47.961275
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie import main
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPHeadersFormattersPlugin

    HTTPHeadersFormattersPlugin.enabled = True
    plugin_manager.load_installed_plugins()


# Generated at 2022-06-12 00:05:54.259574
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # "application/json" and "application/xml" are supported by
    # httpie.plugins.json and httpie.plugins.xml
    converter1 = Conversion.get_converter("application/json")
    converter2 = Conversion.get_converter("application/xml")
    converter3 = Conversion.get_converter("application/unknown")
    assert isinstance(converter1, ConverterPlugin)
    assert isinstance(converter2, ConverterPlugin)
    assert converter3 is None

# Generated at 2022-06-12 00:05:57.413823
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert(Conversion.get_converter("html") is None)
    assert(Conversion.get_converter("test/test") is None)
    assert(Conversion.get_converter("application/json") is not None)

# Generated at 2022-06-12 00:06:01.556097
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt = Formatting(groups=['headers'])
    headers = '''
    HTTP/1.1 200 OK
    Date: Sun, 13 Mar 2016 12:34:56 GMT
    '''
    assert fmt.format_headers(headers) == '\n'.join([
        'HTTP/1.1 200 OK',
        'Date: Sun, 13 Mar 2016 12:34:56 GMT',
        ''
    ])


# Generated at 2022-06-12 00:06:08.077725
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(['colors']).format_headers('HTTP/1.1 200 OK') == '\x1b[37m\x1b[1mHTTP/1.1\x1b[22m\x1b[39m\x1b[32m 200 \x1b[39m\x1b[36mOK\x1b[39m\x1b[0m\n'
    assert Formatting([]).format_headers('HTTP/1.1 200 OK') == 'HTTP/1.1 200 OK\n'


# Generated at 2022-06-12 00:06:09.929301
# Unit test for constructor of class Formatting
def test_Formatting():
    a = Formatting(['format'])
    assert(a.enabled_plugins[0] == 'pygments')    


# Generated at 2022-06-12 00:06:23.780260
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 19 May 2018 03:36:29 GMT\r\nETag: \"d-L4k4sSN4t4-z4fAezXc5p4\"\r\nServer: Google Frontend\r\nContent-Length: 208\r\nCache-Control: private\r\nX-XSS-Protection: 1; mode=block\r\nX-Frame-Options: SAMEORIGIN\r\n\r\n"
    Formatter = Formatting(groups=['colors'], env=env)
    new_header = Formatter.format_headers(headers)

# Generated at 2022-06-12 00:06:29.127325
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    def get_test_get_formatters():
        for p in plugin_manager.get_formatters_grouped()['headers']:
            p.enabled = True
            return p
    assert Formatting(['headers']).format_headers("Teste1\nTeste2\n") == "Teste1\nTeste2\n"


# Generated at 2022-06-12 00:06:31.892516
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    arg = Formatting(groups, env)
    assert arg.enabled_plugins[0].enabled == True

# Generated at 2022-06-12 00:06:36.533012
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['formatting']
    fmt = Formatting(groups, env)
    headers = "Content-Type: application/json\n"
    assert fmt.format_headers(headers) == headers
    content = '{"key1":"value1","key2":"value2"}'
    assert fmt.format_body(content, "application/json") == content

# Generated at 2022-06-12 00:06:43.757260
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class A:
        def __init__(self, env=None, **kwargs):
            self.enabled = True

        def format_headers(self, headers: str) -> str:
            return 'A' + headers + 'A'

    class B:
        def __init__(self, env=None, **kwargs):
            self.enabled = True

        def format_headers(self, headers: str) -> str:
            return 'B' + headers + 'B'

    available_plugins = {'colors': [A, B]}

    original_plugin_manager_get_formatters = plugin_manager.get_formatters_grouped
    plugin_manager.get_formatters_grouped = lambda: available_plugins


# Generated at 2022-06-12 00:06:47.519234
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=["formatters"])
    content = 'Content-Type: application/json\nX-My-Header: first'
    assert f.format_headers(content) == 'Content-Type: application/json\nX-My-Header: first', "Test failed!"


# Generated at 2022-06-12 00:06:54.169691
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    available_plugins = plugin_manager.get_formatters_grouped()
    env = Environment()
    f = Formatting(['colors', 'format'], env, colors=True)
    headers = f.format_headers("HTTP/1.1 200 OK")
    logging.info("headers: %s", headers)
    content_type = 'text/css'
    p = f.enabled_plugins[-1]
    content = p.format_body('body{color:green}', content_type)
    logging.info("content: %s", content)

# Generated at 2022-06-12 00:06:54.793253
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    a = Formatting(groups=['a'])

# Generated at 2022-06-12 00:07:00.790466
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = b'Content-Type: application/json\nstatus: 200'
    formatting = Formatting(groups=['colors', 'sorted'])
    actual = formatting.format_headers(headers)
    expected = b'\x1b[1m\x1b[34mContent-Type:\x1b[39;49;00m application/json\n\x1b[1m\x1b[34mstatus:\x1b[39;49;00m \x1b[32m200\x1b[39;49;00m'
    assert actual == expected


# Generated at 2022-06-12 00:07:11.054825
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.config.output_options.headers.format = "pretty"
    env.config.output_options.body.format = "pretty"
    env.config.output_options.body.minify = False
    env.config.output_options.body.gallery = True
    groups = ["body", "headers"]
    format = Formatting(groups, env)
    assert format.enabled_plugins[0].__class__.__name__ == "PrettyFormatter"
    assert format.enabled_plugins[1].__class__.__name__ == "PrettyFormatter"
    assert format.enabled_plugins[0].minify == False
    assert format.enabled_plugins[0].gallery == True
    assert format.enabled_plugins[1].minify == False
    assert format.enabled_plugins[1].gallery == True

# Generated at 2022-06-12 00:07:23.689610
# Unit test for constructor of class Formatting
def test_Formatting():
    """Test the constructor of Formatting"""
    from httpie.plugins.default import HTTPiePrettyFormatter

    groups = ['pretty']
    env = Environment()
    fmt = Formatting(groups, env=env)
    assert fmt.enabled_plugins[0].__class__ == HTTPiePrettyFormatter


# Generated at 2022-06-12 00:07:27.858100
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class F(Formatting):
        def __init__(self):
            Formatting.__init__(self, [])

    f = F()
    result = f.format_headers('Content-Type: text/html')
    assert result == 'Content-Type: text/html'

# Generated at 2022-06-12 00:07:31.354727
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Prepare data
    mimes = ["application/json", "application/xml"]
    # Run test method
    for mime in mimes:
        converter = Conversion.get_converter(mime)
        assert isinstance(converter, ConverterPlugin)

# Generated at 2022-06-12 00:07:36.035727
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    string_to_test = "-H 'Content-type: application/json'"
    expected_result = [
        "-H 'Content-type: application/json'",
        "-H 'Content-Type: application/json'"]

    header_formatter = Formatting(['headers'])
    assert header_formatter.format_headers(string_to_test) in expected_result


# Generated at 2022-06-12 00:07:45.616530
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import Formatter

    class TestFormatter(Formatter):
        """Format HTTP headers and body for HTTPie."""

        enabled = True

        def format_headers(self, headers):
            return headers.lower()

        def format_body(self, body, mime):
            return body.lower()

    class TestFormatter2(Formatter):
        """Format HTTP headers and body for HTTPie."""

        enabled = True

        def format_headers(self, headers):
            return headers.upper()

        def format_body(self, body, mime):
            return body.upper()

    plugin_manager.register(TestFormatter)
    plugin_manager.register(TestFormatter2)

    groups = ['test']
    f = Formatting(groups)


# Generated at 2022-06-12 00:07:49.405480
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # The case of valid MIME
    assert Conversion.get_converter('application/json') is None
    # The case of wrong MIME
    assert Conversion.get_converter('wrongMime') is None

# Generated at 2022-06-12 00:07:58.343868
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:08:08.598665
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:08:16.408563
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    mime = "application/json"
    content = '{"demo": "demo"}'
    kwargs = {'body_color_scheme' : "solarized"}
    formatting = Formatting(['styles'], **kwargs)
    assert formatting.format_body(content, mime) == '{\x1b[01;31m\x1b[K"demo"\x1b[m\x1b[K:\x1b[01;31m\x1b[K"demo"\x1b[m\x1b[K}'


# Generated at 2022-06-12 00:08:18.783359
# Unit test for constructor of class Formatting
def test_Formatting():
    format_obj = Formatting(["colors"])
    print(format_obj.enabled_plugins)

if __name__ == "__main__":
    test_Formatting()

# Generated at 2022-06-12 00:08:44.010088
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Method format_headers should remove the "Content-Type:" and "Transfer-Encoding: chunked"
    processed_header = Formatting(["Networking"], None).format_headers(b"HTTP/1.1 200 OK\r\nDate: Sun, 24 Jan 2016 00:00:35 GMT\r\nContent-Type: application/json\r\nServer: WSGIServer/0.2 CPython/3.4.3\r\nX-Powered-By: Flask\r\nX-Processed-Time: 0.001146078109741211\r\nContent-Length: 11\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Credentials: true\r\nConnection: keep-alive\r\n\r\n")

    assert processed_header == b