

# Generated at 2022-06-11 23:58:50.901975
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPieJSONFormatter
    from httpie.plugins.builtin import HTTPiePrettyFormatter
    from httpie.plugins.builtin import HTTPieTerminalFormatter
    available_plugins = plugin_manager.get_formatters_grouped()
    groups = ['json', 'pretty', 'terminal']
    formatting = Formatting(groups)
    assert HTTPieJSONFormatter in formatting.enabled_plugins
    assert HTTPiePrettyFormatter in formatting.enabled_plugins
    assert HTTPieTerminalFormatter in formatting.enabled_plugins
    assert len(formatting.enabled_plugins) == 3


# Generated at 2022-06-11 23:58:52.928776
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter('application/json')
    assert(c == ConverterPlugin.__subclasses__()[0](''))


# Generated at 2022-06-11 23:59:03.029886
# Unit test for method format_body of class Formatting

# Generated at 2022-06-11 23:59:08.307054
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['formatters']
    env = Environment()
    enabled_plugins = []
    available_plugins = plugin_manager.get_formatters_grouped()
    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=env)
            if p.enabled:
                enabled_plugins.append(p)
    f = Formatting(groups, env)
    assert enabled_plugins == f.enabled_plugins

# Generated at 2022-06-11 23:59:17.957868
# Unit test for constructor of class Formatting
def test_Formatting():
    environment = Environment()
    environment.colors = {'code':{'text':'blue'},'status': 'red'}
    groups = ['SyntaxHighlight', 'HTTP', 'PrettyPrint']
    formatting = Formatting(groups, environment)

    assert formatting.enabled_plugins[0].name == 'SyntaxHighlight'
    assert formatting.enabled_plugins[1].name == 'HTTP'
    assert formatting.enabled_plugins[2].name == 'PrettyPrint'
    assert formatting.enabled_plugins[0].default_style.get('text') == 'blue'
    assert formatting.enabled_plugins[1].default_style.get('status') == 'red'



# Generated at 2022-06-11 23:59:21.876413
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.config['output.format'] = 'json'
    fmt = Formatting(env=env, groups=['sql', 'colors'])
    assert len(fmt.enabled_plugins) == 1
    assert type(fmt.enabled_plugins[0]).__name__ == 'JSONFormatter'

# Generated at 2022-06-11 23:59:26.731544
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').convert('{"a":1}') == '{' \
                                                                             '"a": 1' \
                                                                             '}'
    assert not Conversion.get_converter('application/xml').convert('{"a":1}') == '{' \
                                                                             '"a": 1' \
                                                                             '}'
if __name__ == '__main__':
    test_Conversion_get_converter()

# Generated at 2022-06-11 23:59:32.496459
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    ff = Formatting(groups=["JSON"])
    headers = '''HTTP/1.1 200 OK
Content-Length: 14
Content-Type: application/javascript

{"status": 200}
'''
    
    expected = '''HTTP/1.1 200 OK
Content-Length: 14
Content-Type: application/javascript

{
    "status": 200
}
'''
    actual = ff.format_headers(headers)
    assert expected == actual
    
    

# Generated at 2022-06-11 23:59:43.007936
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test for method format_headers
    test_headers = 'Content-Type: application/json\r\nContent-Length: 34\r\nDate: Mon, 11 May 2020 06:28:27 GMT\r\n'
    assert Formatting(['colors']).format_headers(test_headers) == '\x1b[37m\x1b[1mContent-Type\x1b[0m: application/json\r\n\x1b[37m\x1b[1mContent-Length\x1b[0m: 34\r\n\x1b[37m\x1b[1mDate\x1b[0m: Mon, 11 May 2020 06:28:27 GMT\r\n\x1b[0m'
    assert Formatting(['colors', 'colors256']).format

# Generated at 2022-06-11 23:59:49.193681
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1, when the mime type is right
    mime = 'application/json'
    assert isinstance(Conversion.get_converter(mime), ConverterPlugin)
    # Test case 2, when the mime type is wrong
    mime = 'text/plain'
    assert Conversion.get_converter(mime) == None


# Generated at 2022-06-11 23:59:52.545379
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    pass


# Generated at 2022-06-11 23:59:58.969404
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not is_valid_mime('')
    assert not is_valid_mime('text')

    assert is_valid_mime('text/plain')
    assert is_valid_mime('application/json')

    assert not Conversion.get_converter('')
    assert not Conversion.get_converter('text')

    assert Conversion.get_converter('text/plain')
    assert Conversion.get_converter('application/json')

# Generated at 2022-06-12 00:00:10.659274
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json

# Generated at 2022-06-12 00:00:17.258304
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.compat import is_bytes, is_py26
    from httpie.output.formatters import raw_formatter
    from httpie.output.formatters.raw import RawFormatter

    env = Environment()
    env.stdout = io.BytesIO()
    f = Formatting(['raw'], env)

    if is_py26:
        assert isinstance(f.format_headers('hello'), unicode)
        assert isinstance(f.format_headers('hello'), unicode)
    else:
        assert isinstance(f.format_headers('hello'), str)
        assert isinstance(f.format_headers('hello'), str)

    assert f.format_headers('hello') == 'hello'

    assert not is_bytes(f.format_headers('hello'))

# Generated at 2022-06-12 00:00:20.313496
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    format = Formatting(['format']).format_body('{"a":10}', 'application/json')
    answer = '{\n    "a": 10\n}\n'
    assert format == answer

# Generated at 2022-06-12 00:00:29.066876
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Arrange
    test_groups = [
        'colors',
        'format',
        'styles',
    ]
    test_kwargs = {
        'color': 'off',
        'style': 'fire'
    }
    test_headers = '''HTTP/1.1 200 OK
Content-Length: 0'''

    expected_headers = '''HTTP/1.1 200 OK
Content-Length: 0'''

    # Act
    test_formatting = Formatting(test_groups, **test_kwargs)
    actual_headers = test_formatting.format_headers(test_headers)

    # Assert
    assert actual_headers == expected_headers


# Generated at 2022-06-12 00:00:36.343767
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    header = ['HTTP/1.1 200 OK', 'Content-Type: application/json', 'Date: Sun, 10 Mar 2019 18:13:54 GMT', 'Server: Apache/2.4.7 (Ubuntu)', 'Vary: Accept-Encoding', 'Transfer-Encoding: chunked', 'Connection: keep-alive', '', '{"test": "test"}']
    print(Formatting(['format'], ['json']).format_body(header[-1], 'application/json'))



# Generated at 2022-06-12 00:00:43.440180
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import pytest
    tb = Formatting(['colors'])
    assert tb.format_headers('HTTP/1.1 404 Not Found\n\n') == '\x1b[1mHTTP/1.1 404 Not Found\x1b[0m\n\n'
    assert tb.format_headers('HTTP/1.1 404 Not Found') == '\x1b[1mHTTP/1.1 404 Not Found\x1b[0m'
    with pytest.warns(UserWarning):
        assert tb.format_headers('HTTP/1.1 200 OK') == 'HTTP/1.1 200 OK'

# Generated at 2022-06-12 00:00:50.722987
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    task = Formatting("colors")
    assert task.format_headers("some") == "some"
    task = Formatting("colors,json")
    assert task.format_headers("some") == "some"
    assert task.format_headers("some/some") == "some/some"
    assert task.format_headers("content-type: some") == "content-type: some"
    assert task.format_headers("content-type: application/json") == (
        "content-type: application/json")



# Generated at 2022-06-12 00:00:59.956657
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from unittest.mock import Mock
    available_plugins = [Mock(), Mock(), Mock()]
    available_plugins[0].enabled = True
    available_plugins[1].enabled = False
    available_plugins[2].enabled = True

    class F:
        def __init__(self):
            self.enabled_plugins = available_plugins

        def format_headers(self, headers: str) -> str:
            for p in self.enabled_plugins:
                headers = p.format_headers(headers)
            return headers

    f = F()
    assert f.format_headers("abc") == "abcabc"
    assert f.format_headers("") == ""



# Generated at 2022-06-12 00:01:13.322142
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    args = (
        "--format=colors --format-options=style=monokai",
        "--print=hb --style=monokai",
        "--style=monokai",
    )
    expected_output1 = """{
    "args": {},
    "data": "",
    "files": {},
    "form": {},
    "headers": {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate",
        "Content-Length": "",
        "Host": "httpbin.org",
        "User-Agent": "HTTPie/0.9.9"
    },
    "json": null,
    "origin": "103.59.147.202",
    "url": "http://httpbin.org/get"
}
"""


# Generated at 2022-06-12 00:01:20.237750
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Given
    env = Environment()
    groups = ['colors']
    kwargs = {}
    headers = """HTTP/1.1 200 OK
Date: Tue, 10 Nov 2020 14:07:54 GMT
Content-Type: text/plain; charset=UTF-8
Transfer-Encoding: chunked
Connection: keep-alive

12
Hello World!
0
"""
    expected = """\x1b[1mHTTP/1.1 \x1b[34;1m200\x1b[39;22m OK\x1b[0m
Date: Tue, 10 Nov 2020 14:07:54 GMT
Content-Type: text/plain; charset=UTF-8
Transfer-Encoding: chunked
Connection: keep-alive

12
Hello World!
0
"""

    # When
    actual = Format

# Generated at 2022-06-12 00:01:25.963970
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    json_headers = '{"host":"localhost:8080","content-type":"application/json","accept":"application/json"}'
    end_headers = 'Content-Type: application/json\nAccept: application/json\nHost: localhost:8080\n'

    formatting = Formatting(['headers'])
    assert formatting.format_headers(json_headers) == end_headers

# Generated at 2022-06-12 00:01:27.358188
# Unit test for constructor of class Formatting
def test_Formatting():
    format = Formatting(["color"])
    print(format.enabled_plugins)

# Generated at 2022-06-12 00:01:36.598047
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from collections import Counter
    from httpie.core import main


# Generated at 2022-06-12 00:01:42.410380
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    format_class = Formatting(groups=[], env=env)
    assert format_class.format_body('abc', 'a/b') == 'abc'
    assert format_class.format_body('abc', '') == 'abc'
    assert format_class.format_body('abc', None) == 'abc'
    assert format_class.format_body('abc', 'a') == 'abc'

# Generated at 2022-06-12 00:01:46.164340
# Unit test for constructor of class Formatting
def test_Formatting():
    format_name = ['format']
    env = Environment()
    kwargs = {}
    p = Formatting(format_name, env, **kwargs)
    assert p.enabled_plugins == []


if __name__ == '__main__':
    test_Formatting()

# Generated at 2022-06-12 00:01:50.550274
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        result = Conversion.get_converter("txt")
        assert result is None
    except Exception as e:
        print("test_Conversion_get_converter has error :" + str(e))


if __name__ == '__main__':
    test_Conversion_get_converter()

# Generated at 2022-06-12 00:02:00.201371
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    '''
    This unit test will test if the method format_body of class Formatting
    works as expected.
    '''
    # create temporary file
    tmpfile = NamedTemporaryFile()
    # define the content of the file
    tmpfile.write(b'{"error_code":0}')
    # close and reopen the file
    tmpfile.seek(0)
    # initialize the environment for formatting
    env = Environment()
    # initialize the formatting to apply a JSON/PrettyJSON formatting
    formatter = Formatting(['JSON', 'PrettyJSON'], env)
    # format the body of the file
    content = formatter.format_body(tmpfile.read(), 'application/json')
    # the formatted content is
    formatted_content = '{\n    "error_code": 0\n}\n'
    # compare the content

# Generated at 2022-06-12 00:02:03.546133
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert(Conversion.get_converter("text/plain") is not None)
    assert(Conversion.get_converter("application/json") is not None)
    assert(Conversion.get_converter("application/xml") is not None)

# Generated at 2022-06-12 00:02:10.242529
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert isinstance(converter, ConverterPlugin)
    converter = Conversion.get_converter('not-a-mime')
    assert not isinstance(converter, ConverterPlugin)



# Generated at 2022-06-12 00:02:13.447543
# Unit test for constructor of class Formatting
def test_Formatting():
    # TODO: Create more comprehensive test for this function
    # Currently we just test if the constructor can be called
    groups = ["json", "colors"]
    env = Environment()
    fmt = Formatting(groups, env=env)
    pass

# Generated at 2022-06-12 00:02:19.770168
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    fmt = Formatting(groups)

    assert fmt.enabled_plugins[0].__class__.__name__ == 'PygmentsFormatter'
    assert fmt.enabled_plugins[0].enabled == True
    assert fmt.enabled_plugins[0].ctx.get_option('style') == 'solarized'
    assert fmt.enabled_plugins[0].ctx.get_option('colors') != None


# Generated at 2022-06-12 00:02:23.510594
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(["headers", "colors"])
    assert f.enabled_plugins[0].__class__.__name__ == 'HeadersFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-12 00:02:29.205102
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print(Conversion.get_converter('application/json')().name)
    assert Conversion.get_converter('application/json')().name == 'json'
    assert Conversion.get_converter('application/json')().mime == 'application/json'



# Generated at 2022-06-12 00:02:38.821848
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Case 1: mime is not in the expected format
    mime = 'application/xml'
    ff = Formatting('format')
    content = ff.format_body('{"key": "value"}', mime)
    print('content', content)
    assert content == '{"key": "value"}'

    # Case 2: mime is valid, but body is not JSON
    mime = 'application/json'
    ff = Formatting('format')
    content = ff.format_body('This is a string', mime)
    print('content', content)
    assert content == 'This is a string'

    # Case 3: mime is valid, and body is JSON
    ff = Formatting('format')
    content = ff.format_body('{"key": "value"}', mime)
    print('content', content)
   

# Generated at 2022-06-12 00:02:41.564766
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    format_body = Formatting(groups=['body']).format_body
    assert format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'
    assert format_body('{"a": 1}', 'application/unknown') == '{"a": 1}'

# Generated at 2022-06-12 00:02:43.582224
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_mime = 'application/json'
    mime = Conversion.get_converter(test_mime)
    print(mime)
    assert mime



# Generated at 2022-06-12 00:02:44.464331
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(["all"])

# Generated at 2022-06-12 00:02:47.550046
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter('application/json')
    assert c.mime == 'application/json'
    assert c.ext == 'json'
    assert c.name == 'json'


# Generated at 2022-06-12 00:02:56.677634
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    content_header_pairs = [('[{"a":1,"b":2}]', "Content-Type: application/json\n"),
                            ('[{"a":1,"b":2}]', "Content-Type: application/json; charset=UTF-8\n")]
    formatting = Formatting(["json"])
    for content, header in content_header_pairs:
        result = formatting.format_body(content, header)
        assert result == "[\n" \
                         "   {\n" \
                         "      \"a\": 1,\n" \
                         "      \"b\": 2\n" \
                         "   }\n" \
                         "]\n"

# Generated at 2022-06-12 00:02:59.470018
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)

# Generated at 2022-06-12 00:03:04.759699
# Unit test for constructor of class Formatting
def test_Formatting():
    instance1 = Formatting(["colors", "colors"])
    instance2 = Formatting(["colors", "format", "colors"])
    assert instance1 is not None and instance2 is not None
    assert instance1.__class__.__name__ == "Formatting"
    assert instance2.__class__.__name__ == "Formatting"


# Generated at 2022-06-12 00:03:12.762447
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import os
    import sys
    import pytest
    from httpie.downloads import get_config_dir, CONFIG_DIR

    @pytest.fixture()
    def restore_environ(monkeypatch):
        def restore():
            monkeypatch.setattr(os.environ, 'HOME', None)
            monkeypatch.setattr(os.environ, 'XDG_CONFIG_HOME', None)
        return restore

    @pytest.fixture()
    def empty_config(response):
        config_home = get_config_dir()
        if not os.path.exists(config_home):
            os.mkdir(config_home)
        (fd, config_file_name) = tempfile.mkstemp(suffix='.json', dir=config_home)
        config_file = os.fdopen

# Generated at 2022-06-12 00:03:14.338767
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert converter is not None

# Generated at 2022-06-12 00:03:18.076649
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    f = Formatting(['colors', 'formatters'])
    assert len(f.enabled_plugins) == len(available_plugins['colors']) + len(available_plugins['formatters'])

# Generated at 2022-06-12 00:03:25.221892
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """Unit test for method format_body of class Formatting."""
    class FakeFormatter:
        def format_body(self, content: str, mime: str) -> str:
            if mime == "test_mime":
                return content
            else:
                return None

    p = Formatting(groups=[])
    fake_formatter = FakeFormatter()
    p.enabled_plugins.append(fake_formatter)
    content = "some text"
    modified_content = p.format_body(content, "test_mime")
    assert content == modified_content


# Generated at 2022-06-12 00:03:35.560248
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_mimes = [
        'text/xml', 'application/json', 'application/xml',
        'application/x-www-form-urlencoded', 'application/octet-stream',
        'application/pdf', 'application/zip'
    ]
    for mime in test_mimes:
        assert (Conversion.get_converter(mime).mime == mime)
    assert (Conversion.get_converter('') == None)
    assert (Conversion.get_converter(' ') == None)
    assert (Conversion.get_converter('/') == None)
    assert (Conversion.get_converter('/text/xml') == None)
    assert (Conversion.get_converter('text/xml/') == None)

# Generated at 2022-06-12 00:03:42.497333
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test 1:
    # Method get_converter should return JSON or HTML converter plugin according to MIME type
    input_mime = 'application/json'
    expected_converter = plugin_manager.get_converters('application/json')[0]
    assert Conversion.get_converter(input_mime) == expected_converter

    input_mime = 'text/html'
    expected_converter = plugin_manager.get_converters('text/html')[0]
    assert Conversion.get_converter(input_mime) == expected_converter

    # Test 2:
    # Method get_converter should return None if MIME type is not available
    input_mime = 'xx/yy'
    assert Conversion.get_converter(input_mime) is None

# Generated at 2022-06-12 00:03:49.163434
# Unit test for constructor of class Formatting
def test_Formatting():
    allowed_groups = [
        'colors', 'colors-light', 'format', 'format-pretty',
        'format-json', 'format-colors'
    ]
    for group in allowed_groups:
        Formatting([group])

    try:
        Formatting(['invalid-group'])
        assert False
    except KeyError:
        assert True

# Generated at 2022-06-12 00:03:51.881405
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting()

# Generated at 2022-06-12 00:04:00.736768
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formater = Formatting(groups=['colors'])
    assert formater.format_body("hello", None) == "hello"
    assert formater.format_body("hello", "application/json") == "hello"
    assert formater.format_body("hello", "application/js") == "hello"
    assert formater.format_body("hello", "applicatio/json") == "hello"
    assert formater.format_body("hello", "applicationn/json") == "hello"
    assert formater.format_body("hello", "invalid/mime") == "hello"
    assert formater.format_body("hello", "application/xml") == "hello"
    assert formater.format_body("hello", "application/json; charset=UTF-8") == "hello"

# Generated at 2022-06-12 00:04:02.412934
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    res = Conversion.get_converter('application/json')
    assert res.dump == json.dumps

# Generated at 2022-06-12 00:04:05.632816
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter(None)
    assert not Conversion.get_converter('file')
    assert not Conversion.get_converter('foo/bar')

    assert Conversion.get_converter('json')



# Generated at 2022-06-12 00:04:13.812066
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Single line, no newline
    assert Formatting([]).format_body("<html>Test</html>", "text/html") == "<html>Test</html>"
    # Multi line, no newline
    assert Formatting([]).format_body("Test\nTest", "text/html") == "Test\nTest"
    # Single line, newline
    assert Formatting([]).format_body("<html>Test</html>\n", "text/html") == "<html>Test</html>\n"
    # Multi line, newline
    assert Formatting([]).format_body("Test\nTest\n", "text/html") == "Test\nTest\n"

# Generated at 2022-06-12 00:04:19.122482
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors', 'format'])
    print('befor calling:', '{"employees": ['
                            '{"firstName": "John", "lastName": "Doe"}]}')
    print('calling:', f.format_body('{"employees": ['
                                    '{"firstName": "John", "lastName": "Doe"}]}', 'application/json'))

# Generated at 2022-06-12 00:04:26.885684
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting([]).format_headers("""HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Date: Mon, 23 Sep 2019 18:00:00 GMT
Transfer-Encoding: chunked

""") == """HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Date: Mon, 23 Sep 2019 18:00:00 GMT
Transfer-Encoding: chunked

"""

# Generated at 2022-06-12 00:04:28.855799
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)


# Generated at 2022-06-12 00:04:31.607606
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting.format_body('[{"ss":"ss"}]', 'application/json') == '[\n    {\n        "ss": "ss"\n    }\n]'

# Generated at 2022-06-12 00:04:34.110374
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converterPlugin = Conversion.get_converter('application/json')
    assert converterPlugin.render_json() == 'json'



# Generated at 2022-06-12 00:04:38.782660
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    valid_json_converter = Conversion.get_converter(mime)
    assert valid_json_converter.type == 'json'

# Generated at 2022-06-12 00:04:48.459187
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins import FormatterPlugin

    class TestFormatterPlugin(FormatterPlugin):
        enabled = True

        def format_body(self, body, mime):
            body[0] = body[0].upper()
            return body

    groups = ['test-group']

    sample_body = 'test body'
    sample_mime = 'text/plain'

    formatting_class = Formatting(groups=groups)
    formatting_class.enabled_plugins.append(TestFormatterPlugin(env=None))

    formatted_body = formatting_class.format_body(sample_body, sample_mime)

    assert formatted_body == sample_body.upper()

# Generated at 2022-06-12 00:04:58.241559
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:05:07.461409
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(['colors']).format_headers('HTTP/1.1 200 OK\nDate: Wed, 26 Dec 2018 08:23:27 GMT\nContent-Type: text/html\nContent-Length: 11\nServer: Microsoft-HTTPAPI/2.0\n\nHello World!\n') == 'HTTP/1.1 200 OK\nDate: Wed, 26 Dec 2018 08:23:27 GMT\nContent-Type: text/html\nContent-Length: 11\nServer: Microsoft-HTTPAPI/2.0\n\nHello World!\n'

# Generated at 2022-06-12 00:05:12.482648
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    f = Conversion.get_converter("application/json")
    assert f.__class__.__name__ == "JSONConverter"
    f = Conversion.get_converter("application/xml")
    assert f.__class__.__name__ == "XMLConverter"


# Generated at 2022-06-12 00:05:17.741649
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    converter = 'json'
    formats = ['colors']
    env = Environment()
    env.stdout_isatty = True
    formatting = Formatting(groups=formats, env=env)
    f = open("test.txt","r")
    content = f.read()
    f.close()
    content = formatting.format_body(content, converter)
    assert content is not None


# Generated at 2022-06-12 00:05:19.752236
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None



# Generated at 2022-06-12 00:05:23.984767
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    json_mime = 'application/json'
    converter = Conversion.get_converter(json_mime)
    assert 'ToJsonConverter' == converter.__class__.__name__
    assert 'application/json' == converter.mime

# Generated at 2022-06-12 00:05:27.767821
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # no need to test, just for make possible execute 100% code coverage
    headers = "HTTP/1.1 200 OK\n"
    Formatting(groups=['colors'], env=Environment()).format_headers(headers)


# Generated at 2022-06-12 00:05:32.685993
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print(Conversion.get_converter('text/plain').supports_mime())
    print(Conversion.get_converter('text/plain').convert('jjjjj'))


if __name__ == '__main__':
    test_Conversion_get_converter()

# Generated at 2022-06-12 00:05:36.928390
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    plugin_manager.get_converters()
    converter = Conversion.get_converter('json')
    assert converter.mime == 'json'



# Generated at 2022-06-12 00:05:46.001540
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors']

# Generated at 2022-06-12 00:05:51.471293
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = [('Content-Type', 'application/json')]
    headers_str = ': '.join(['{}'.format(kv[0]) for kv in headers]) + '\n'
    formatter = Formatting(groups=['format'], headers=headers)
    assert formatter.format_headers(headers_str) == 'Content-Type: application/json\n'


# Generated at 2022-06-12 00:05:55.909816
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.__class__.__name__ == 'JsonConverter'

    converter = Conversion.get_converter('application/x-www-form-urlencoded')
    assert converter.__class__.__name__ == 'FormConverter'



# Generated at 2022-06-12 00:06:02.976113
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    import json

    env = Environment()
    env.stdout = StringIO()
    formatting = Formatting(['pretty'], env)

    # the class HTTPPrettyJSONProcessor is enabled
    assert isinstance(formatting.enabled_plugins[0], HTTPPrettyJSONProcessor)

    # the enabled class has a method `format_body`
    assert hasattr(formatting.enabled_plugins[0], 'format_body')

    # the enabled class has a method `format_headers`
    assert hasattr(formatting.enabled_plugins[0], 'format_headers')

    data = {'name':'John', 'age':30}
    # the enabled class can format a dictionary to a pretty string

# Generated at 2022-06-12 00:06:10.321153
# Unit test for constructor of class Formatting
def test_Formatting():
    def test_format_headers(a, b):
        print(a)
        print(b)
        assert len(a) == len(b)
        return a+b

    class FormattingMock(Formatting):
        def __init__(self, groups, env=Environment(), **kwargs):
            super().__init__(groups, env, **kwargs)
            # Overload format_headers()
            self.format_headers = lambda x: test_format_headers(a, x)

    a = 'test headers'
    b = 'test'
    instance = FormattingMock(['group_test'])
    assert instance.format_headers(b) == a+b



# Generated at 2022-06-12 00:06:13.967870
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter(None)
    assert not Conversion.get_converter('json')

    assert Conversion.get_converter('json').mime_type == 'application/json'
    assert Conversion.get_converter('application/json').mime_type == 'application/json'


# Generated at 2022-06-12 00:06:23.297305
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.formatting import Formatting
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment

    from httpie.plugins import builtin

    env = Environment()
    groups = ['json', 'colors']
    # A plugin is added to plugin_manager to make the unit test pass
    plugin_manager.register(builtin.JSONPrettyfier)

    # Initialization
    formatting = Formatting(groups, env=env)

    # The test cases
    json_str = '{"p": 1, "q": 2}'

# Generated at 2022-06-12 00:06:31.251235
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin import HTTPBinary, HTTPJSON, HTTPTTY

    def assert_converter(mime, converter_class, **kwargs):
        assert isinstance(Conversion.get_converter(mime), converter_class)

    assert_converter('application/json', HTTPJSON, **{})
    assert_converter('application/octet-stream', HTTPBinary, **{})
    assert_converter('application/tty', HTTPTTY, **{})
    


# Generated at 2022-06-12 00:06:36.181866
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class TestFormatter(Formatting):
        def __init__(self, **kwargs):
            Formatting.__init__(self, ["Test"], **kwargs)
        def format_body(self, body, mime):
            return "\\/\\/\\"

    f = TestFormatter()
    assert f.format_body("", "") == "\\/\\/\\"


# Generated at 2022-06-12 00:06:44.710129
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_class = Conversion.get_converter('application/json')
    assert converter_class.mime == 'application/json'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 00:06:46.271386
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("text/html"),
                      ConverterPlugin)


# Generated at 2022-06-12 00:06:51.500768
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test 1
    mime = "text/html"
    assert Conversion.get_converter(mime).get_mime() == mime
    # Test 2
    mime = "application/json"
    assert Conversion.get_converter(mime).get_mime() == mime
    # Test 3
    mime = "text/xml;"
    assert Conversion.get_converter(mime) == None

# Generated at 2022-06-12 00:06:56.636934
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print(Formatting(['application/json'],
                   env=Environment(),
                   json_prefix=None,
                   json_indent=2,
                   json_sort_keys=False,
                   json_compact=False).format_body(
        '{"key1":"value1","key2":"value2"}',
        mime='application/json'))


if __name__ == '__main__':
    test_Formatting_format_body()

# Generated at 2022-06-12 00:07:03.092837
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\nServer: Apache\r\nConnection: close\r\nContent-Length: 19\r\nFoo: bar\r\nContent-Type: text/html\r\n\r\n'
    env = Environment()
    f = Formatting(['colors'], env=env)
    print(f.format_headers(headers))
    headers = 'HTTP/1.1 200 OK\r\nServer: Apache\r\nConnection: close\r\nContent-Length: 19\r\nFoo: bar\r\nContent-Type: text/html\r\n\r\n'
    env = Environment()
    f = Formatting(['colors', 'colors'], env=env)
    print(f.format_headers(headers))
   

# Generated at 2022-06-12 00:07:10.041204
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter1 = Conversion.get_converter('text/html')
    assert (converter1.mime == 'text/html')

    converter2 = Conversion.get_converter('application/json')
    assert (converter2.mime == 'application/json')

    converter3 = Conversion.get_converter('application/xml')
    assert (converter3.mime == 'application/xml')

    converter4 = Conversion.get_converter('plain/text')
    assert (converter4 is None)



# Generated at 2022-06-12 00:07:18.719711
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = {\
        "Content-Type":"application/json",
        "Connection":"Keep-Alive",
        "X-Auth-Token":"e30.HwPggEfJhMgQIq3PqZXLdHZJ9t5zV7_u1lJwV7oVO5Bk-V7fI-LbZ1J0DpXg5zUk",
        "User-Agent":"okhttp/3.10.0",
        "Accept-Encoding":"gzip",
        "Accept":"application/json",
        "Host":"10.2.105.3:8081",
        "X-Real-IP":"10.2.32.73",
        "Content-Length":"20"}
    plugin_manager.load_directory(path="./httpie/plugins")

# Generated at 2022-06-12 00:07:23.465448
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.output.formatters.json import JSONFormatter
    json = '{"testing": "test"}'
    json_pretty = '{\n    "testing": "test"\n}\n'
    formatting = Formatting(['json'], colors=None)
    assert formatting.format_body(json, 'application/json') == json_pretty


# Generated at 2022-06-12 00:07:24.806910
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])

# Generated at 2022-06-12 00:07:30.534667
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        converter = Conversion.get_converter('application/json')
        assert converter, 'ConverterPlugin not found'
    except:
        assert False, 'ConverterPlugin not found'

    try:
        converter = Conversion.get_converter('application/not_found_mime')
        assert not converter, 'ConverterPlugin found'
    except:
        assert False, 'Unexpected error occuried'



# Generated at 2022-06-12 00:07:41.756004
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_input = 'Content-Type: application/json'
    assert Formatting(['color']).format_headers(test_input) == '\x1b[34mContent-Type:\x1b[39;49;00m application/json'
    assert Formatting(['format']).format_headers(test_input) == 'Content-Type: application/json'
    assert Formatting(['color']).format_headers(test_input) != test_input
    assert Formatting(['format']).format_headers(test_input) != test_input



# Generated at 2022-06-12 00:07:52.726962
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # prepare sample data
    test_object = Formatting(groups=['colors'])
    test_headers = 'HTTP/1.1 200 OK\r\nDate: Tue, 20 Mar 2018 13:21:26 GMT\r\nServer: Apache\r\nLast-Modified: Mon, 19 Mar 2018 19:20:01 GMT\r\nETag: "c0-5650e8a3b3c00"\r\nAccept-Ranges: bytes\r\nContent-Length: 192\r\nKeep-Alive: timeout=5, max=100\r\nConnection: Keep-Alive\r\nContent-Type: text/html\r\n'

# Generated at 2022-06-12 00:07:57.451361
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    a = Conversion.get_converter('audio/wav').__class__
    b = Conversion.get_converter('text/html').__class__
    c = Conversion.get_converter('application/json').__class__
    d = Conversion.get_converter('application/jpg').__class__
    assert a == ConverterPlugin
    assert b == ConverterPlugin
    assert c == ConverterPlugin
    assert d == None

# Generated at 2022-06-12 00:07:58.259752
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')

# Generated at 2022-06-12 00:08:08.535564
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    mime = "application/json"
    content = '{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoyNjY5LCJleHAiOjE1OTc3ODg3NzgsImlhdCI6MTU5NzczNTk3OH0.jK0ZgBryXk-hVuQH2xKS7VdOtJ5h7V5z5wy5pZO4g9I"}'
    print(content)
    for p in Formatting(groups=['color']).enabled_plugins:
        print(p.name)
        content = p.format_body(content, mime)
        print(content)


test_Formatting

# Generated at 2022-06-12 00:08:12.833380
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_content = '{"name": "Clemens", "age": "25"}'
    test_mime = 'application/json'
    format_body = Formatting(['json']).format_body(test_content, test_mime)
    assert format_body is not None
    assert format_body != test_content

# Generated at 2022-06-12 00:08:22.033476
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    lst = [
        ['json', '{"a": [1,2,3]}'],
        ['json', '{"a": \n[1,2,3]}'],
        ['json', '{"a": 1, "b": "xxx", "c": "yyy"}'],
        ['xml', '<CATALOG>\n<CD>\n<TITLE>Empire Burlesque</TITLE>\n</CD>\n</CATALOG>'],
        ['xml', '<CATALOG>\n<CD>\n<TITLE>Empire Burlesque</TITLE>\n</CD>\n</CATALOG>']
    ]

# Generated at 2022-06-12 00:08:23.750653
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert (
        isinstance(
            Conversion.get_converter('text/plain'),
            ConverterPlugin)
    )



# Generated at 2022-06-12 00:08:27.995750
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('a/b') is None
    assert Conversion.get_converter('text/plain').mime == 'text/plain'
    assert Conversion.get_converter('text/xml').mime == 'text/xml'
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert Conversion.get_converter('application/hal+json').mime == 'application/json'


# Generated at 2022-06-12 00:08:29.646272
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "text/html"
    converter = Conversion.get_converter(mime)
    assert converter is not None
    assert converter.name == "html"
    assert converter.mime == "text/html"
