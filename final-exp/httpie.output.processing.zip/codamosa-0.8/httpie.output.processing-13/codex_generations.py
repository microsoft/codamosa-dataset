

# Generated at 2022-06-11 23:58:45.011170
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter = Conversion.get_converter(mime=mime)
    assert converter.supports(mime) is True


# Generated at 2022-06-11 23:58:53.446720
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors', 'formatters', 'encoders']
    env = Environment()
    env.colors = True
    env.style = 'sunburst'
    env.format = 'pretty'
    kwargs = {}
    kwargs['env'] = env

    fmt = Formatting(groups, **kwargs)
    h = fmt.format_headers('\r\n'.join(['HTTP/1.1 200 OK', 'Date: Wed, 11 Nov 2018 22:46:01 GMT', 'Content-Length: 7']))

# Generated at 2022-06-11 23:58:56.645279
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "application/json"
    converter = Conversion.get_converter(mime)
    if converter:
        assert converter.supports(mime) == True
    else:
        assert converter == None


# Generated at 2022-06-11 23:59:02.789090
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format = Formatting(['colors'])
    headers = format.format_headers('HTTP/1.1 200 OK\nContent-Type: text/html; charset=utf-8')
    assert headers == '\x1b[32mHTTP/1.1 200 OK\x1b[0m\n\x1b[33mContent-Type: text/html; charset=utf-8\x1b[0m'


# Generated at 2022-06-11 23:59:04.376098
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter

# Generated at 2022-06-11 23:59:07.708983
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    result = Conversion.get_converter('application/json')
    assert result is not None
    result = Conversion.get_converter('application/xml')
    assert result is not None
    result = Conversion.get_converter('application/pdf')
    assert result is None

# Generated at 2022-06-11 23:59:10.907323
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['color', 'format']
    env = Environment()
    formatting_object = Formatting(groups, env=env)
    assert formatting_object.enabled_plugins != []

# Generated at 2022-06-11 23:59:16.838839
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    body = """
    httpie is nice.
    It's a great tool to use.
    """
    mime = "text/html"
    formatting = Formatting(["JSON", "colors"])
    result_body = formatting.format_body(body, mime)
    assert result_body == "    httpie is nice.\n    It's a great tool to use.\n"


# Generated at 2022-06-11 23:59:24.528336
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "application/json"
    converter = Conversion.get_converter(mime)
    assert(converter.supports(mime) is True)
    assert(converter.can_prettify() is True)
    assert(converter.can_prettify() is True)
    mime = "text/plain"
    converter = Conversion.get_converter(mime)
    assert(converter.supports(mime) is False)
    converter = Conversion.get_converter("text/html")
    assert(converter.supports(mime) is False)
    converter.convert(1.0)
    converter.convert(bytes("testing", "utf-8"))

# Generated at 2022-06-11 23:59:31.391846
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    convert = Conversion()
    # test for JSON
    conv_plug = convert.get_converter('application/json')
    assert conv_plug.plugin_name == 'json'
    # test for XML
    conv_plug = convert.get_converter('text/xml')
    assert conv_plug.plugin_name == 'xml'
    # test for unsupported mime type
    conv_plug = convert.get_converter('text/foobar')
    assert conv_plug is None

# Generated at 2022-06-11 23:59:41.153530
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert(Conversion.get_converter('application/json').mime == 'application/json')
    assert(Conversion.get_converter('text/html').mime == 'text/html')
    assert(not Conversion.get_converter('text/plain-text').mime)
    assert(not Conversion.get_converter('text/plain-text/text').mime)
    assert(not Conversion.get_converter('text/plain-text/text/text').mime)

# Generated at 2022-06-11 23:59:42.494490
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(groups=['json', 'colors'])



# Generated at 2022-06-11 23:59:54.155158
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    Test that a JSON body is formatted correctly
    """

    mime = "application/json"
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in ['format_json', 'format_xml']:
        for cls in available_plugins[group]:
            p = cls(env=Environment())
            if p.enabled:
                enabled_plugins.append(p)

    content = '{"company":"Tripp Lite", "address":"1111 W 35th Street","state":"IL","zipcode":"60616"}'

    for p in enabled_plugins:
        if p.supports(mime):
            content = p.format_body(content, mime)


# Generated at 2022-06-11 23:59:59.946728
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # given
    class HeaderTestProcessor(ConverterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers.upper()
    plugin_manager.add(HeaderTestProcessor)
    test_line = 'abc: def'
    expected = 'ABC: DEF'
    groups = ['to-upper']
    # when
    fmt = Formatting(groups)
    result = fmt.format_headers(test_line)
    # then
    assert expected == result

# Generated at 2022-06-12 00:00:11.627156
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class MockPlugin_A:
        def __init__(self):
            self.enabled = True

        def format_headers(self, headers):
            return headers.upper()

    class MockPlugin_B:
        def __init__(self):
            self.enabled = True

        def format_headers(self, headers):
            return headers + ":test"

    class MockPlugin_C:
        def __init__(self):
            self.enabled = False

        def format_headers(self, headers):
            return headers + ":test"


# Generated at 2022-06-12 00:00:17.845836
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.formatters.colors import Formatter

    # Test case:
    # processor = Formatter(), headers = '{"hello":1, "world":2}'
    out = Formatting(groups=["colors"]).format_headers('{"hello":1, "world":2}')
    assert out == '{\x1b[0m\n  \x1b[96m"hello"\x1b[0m\x1b[1m:\x1b[0m \x1b[92m1\x1b[0m,\n  \x1b[96m"world"\x1b[0m\x1b[1m:\x1b[0m \x1b[92m2\x1b[0m\n\x1b[0m}\n'

    # Test case

# Generated at 2022-06-12 00:00:20.234028
# Unit test for constructor of class Formatting
def test_Formatting():
    plugins = Formatting(['formatters']).enabled_plugins
    assert isinstance(plugins, list)
    print("Test Formatting is passed")



# Generated at 2022-06-12 00:00:23.428495
# Unit test for constructor of class Formatting
def test_Formatting():
    """
    Unit test for constructor of class Formatting
    """
    groups = ['colors']
    environment = Environment()
    formatting = Formatting(groups, environment)
    assert formatting.enabled_plugins == []

# Generated at 2022-06-12 00:00:25.942690
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    assert Formatting(groups).enabled_plugins[0].__class__.__name__ == 'ColorsHighlighter'



# Generated at 2022-06-12 00:00:28.654173
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    fmt = Formatting(groups = ['pretty', 'colors'], env = env, colors = True)
    assert len(fmt.enabled_plugins) == 2

# Generated at 2022-06-12 00:00:41.846633
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    groups = ["colors", "formatters"]
    headers = "HTTP/1.1 200 OK\r\n"
    headers += "Content-Type: application/json\r\n"
    headers += "Server: gunicorn/19.9.0\r\n"
    headers += "Date: Thu, 11 Apr 2019 12:52:18 GMT\r\n"
    headers += "Connection: close\r\n"
    headers += "Content-Length: 83\r\n"
    headers += "Via: 1.1 vegur"

    formatting = Formatting(groups, env)
    formatted_headers = formatting.format_headers(headers)

    expected_formatted_headers = ""
    expected_formatted_headers += "HTTP/1.1 200 OK\n"
    expected_formatted_headers

# Generated at 2022-06-12 00:00:44.485355
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert repr(Conversion.get_converter("text/plain")) == repr(Conversion.get_converter("application/json"))


# Generated at 2022-06-12 00:00:49.856579
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    converter = Conversion.get_converter
    formatting = Formatting(groups=['b'], converter=converter)

    assert formatting.format_headers('Content-Type: application/json') == \
    '\u001b[34mContent-Type:\u001b[0m \u001b[36mapplication/json\u001b[0m'


# Generated at 2022-06-12 00:00:58.281643
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test passed
    assert isinstance(Conversion.get_converter('application/json'), str)

    # Test passed
    assert isinstance(Conversion.get_converter('text/html'), str)

    # Test passed
    assert isinstance(Conversion.get_converter('text/plain'), str)

    # Test passed
    assert isinstance(Conversion.get_converter('text/javascript'), str)

    # Test passed
    assert isinstance(Conversion.get_converter('test/test'), str)


# Generated at 2022-06-12 00:01:02.594469
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """
    check:
    - converter class is returned when valid mime is passed as arguement
    - converter class can be passed to function as argument
    - None is returned for invalid mime
    """
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json')('{"a": 1}'), [('a', 1)]
    assert Conversion.get_converter('application/junk') is None



# Generated at 2022-06-12 00:01:03.940780
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=["colors", "format"], env=Environment())
    assert f  # TODO better test


# Generated at 2022-06-12 00:01:05.597451
# Unit test for constructor of class Formatting
def test_Formatting():
    global f
    f = Formatting(['colors'])
    assert f.enabled_plugins != None


# Generated at 2022-06-12 00:01:07.286559
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors', 'format'])


# Generated at 2022-06-12 00:01:15.800271
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.formatters.json import JSONFormatter
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.registry import plugin_manager
    plugin_manager.save_plugin(JSONFormatter)
    plugins = plugin_manager.get_formatters()
    env = Environment()
    formater = Formatting(['json'], env)
    text = formater.format_body(text, mime='application/json')
    assert isinstance(formater, Formatting)
    assert isinstance(text, str)
    plugin_manager.remove_plugin(JSONFormatter)
    assert plugin_manager.get_formatters() == []

    

# Generated at 2022-06-12 00:01:27.648476
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.registry import plugin_manager
    from pygments.formatters import TerminalFormatter
    from pygments.styles import get_style_by_name

    terminal_formatter = TerminalFormatter(
        style=get_style_by_name('colorful')
    )

    assert plugin_manager.register(
        name='highlight',
        class_=HighlightFormatter,
        formatter=terminal_formatter
    )

    groups = ['highlight', 'colors']
    env = Environment()
    highlighting = Formatting(groups=groups, env=env)

    body = '{"foo": "bar"}'
    mime = 'application/json'

    actual_output = highlighting.format_body(
        content=body,
        mime=mime
    )


# Generated at 2022-06-12 00:01:32.847739
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_class  = Conversion.get_converter('application/json')
    assert converter_class.__name__ == 'JSONConverter'


# Generated at 2022-06-12 00:01:43.085622
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:01:52.985794
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    obj = Formatting(groups)
    file = '{"id":1,"name":"httpie","full_name":"jkbrzt/httpie"}'
    mime = 'application/json'
    answer = obj.format_body(file, mime)

# Generated at 2022-06-12 00:02:02.857240
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    input_headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Length: 52\r\n'
        'Connection: keep-alive\r\n'
        'Server: nginx/1.13.9\r\n'
        'Date: Sat, 07 Apr 2018 20:11:43 GMT\r\n'
        'Content-Type: application/json\r\n\r\n'
        '{ "data": [ { "name": "doe", "age": 34, "sex": "male" },\n'
        '{ "name": "jane", "age": 33, "sex": "female" } ] }'
    )

# Generated at 2022-06-12 00:02:08.504610
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    f = Formatting(['colors', 'colors'])
    assert len(f.enabled_plugins) == 1
    f = Formatting(['colors', 'bpp'])
    assert len(f.enabled_plugins) == 2

# Generated at 2022-06-12 00:02:10.684771
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["formatters"]
    env = Environment()
    f = Formatting(groups, env)


# Generated at 2022-06-12 00:02:12.812139
# Unit test for constructor of class Formatting
def test_Formatting():
    print('Test Formatting constructor:')
    fmt = Formatting(['colors'])
    print(fmt.enabled_plugins)


# Generated at 2022-06-12 00:02:16.775929
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    foo = Formatting(['canonical', 'colors'], env)
    assert foo.enabled_plugins[0].__class__.__name__ == 'CanonicalJSON'
    assert foo.enabled_plugins[1].__class__.__name__ == 'ColoredJSON'


# Generated at 2022-06-12 00:02:27.819535
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """Test for method format_headers of class Formatting"""
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import RawBodyOutputPlugin
    from httpie.compat import is_windows

    headers = "Content-Type:application/json; encoding=utf-8"
    print (headers)
    fmt = Formatting(groups=[PrettyOptionsPlugin.group], pretty="all")
    h = fmt.format_headers(headers)
    print (h)

    fmt = Formatting(groups=[RawBodyOutputPlugin.group], pretty="none")
    h = fmt.format_headers(headers)
    print (h)


# Generated at 2022-06-12 00:02:31.649567
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter(None)
    assert not Conversion.get_converter('not-a-valid-mime')
    converter = Conversion.get_converter('application/json')
    assert converter
    assert converter.mime == 'application/json'

# Generated at 2022-06-12 00:02:36.885510
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=["color", "unicode"], json=True)
    assert len(f.enabled_plugins) == 2

# Generated at 2022-06-12 00:02:38.667603
# Unit test for constructor of class Formatting
def test_Formatting():
    assert isinstance(Formatting(groups=['colors']), Formatting)


# Generated at 2022-06-12 00:02:39.994875
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['browser', 'colors']
    format = Formatting(groups)
    assert format is not None

# Generated at 2022-06-12 00:02:42.227735
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(groups=['json', 'pretty'], env=env)
    assert f != None

# Generated at 2022-06-12 00:02:45.775890
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    for group in available_plugins:
        for cls in available_plugins[group]:
            p = cls(env=Environment(), color=False)
            if p.enabled:
                assert group in p.name


# Generated at 2022-06-12 00:02:47.677837
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    print(converter)


# Generated at 2022-06-12 00:02:56.468176
# Unit test for constructor of class Formatting
def test_Formatting():
    #Test no group
    env = Environment()
    formatting = Formatting(groups=[], env=env)
    assert formatting.enabled_plugins==[]
    formatting = Formatting(groups=["groupX"], env=env)
    assert formatting.enabled_plugins==[]
    #Test an existing group
    available_plugins = plugin_manager.get_formatters_grouped()
    assert "colors" in available_plugins.keys()
    formatting = Formatting(groups=[], env=env)
    assert formatting.enabled_plugins == []
    formatting = Formatting(groups=[], env=env)
    assert formatting.enabled_plugins == []
    formatting = Formatting(groups=["colors"], env=env)
    assert len(formatting.enabled_plugins)>0

# Generated at 2022-06-12 00:03:07.341901
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie import ExitStatus
    from httpie.plugins import FormatterPlugin, ColorFormatter
    from httpie.output.streams import stdout_bytes
    from httpie.plugins.registry import plugin_manager
    
    class TestFormatter(FormatterPlugin):
        """Test formatter."""
        name ='testformatter'
        format = 'test'
        validate_colors = False
        sec_headers = ['sec-header']

        def format_headers(self, headers: str) -> str:
            return 'test: {0}'.format(headers)

    # Register new formatter
    plugin_manager.register(TestFormatter)


# Generated at 2022-06-12 00:03:18.383857
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers_string = "HTTP/1.1 200 OK\r\nServer: Apache-Coyote/1.1\r\n\
        Content-Type: application/json;charset=UTF-8\r\nContent-Length: 0\r\nDate: \
        Fri, 09 Aug 2019 11:14:25 GMT\r\n\r\n"
    expected_headers_string = "HTTP/1.1 200 OK\nServer: Apache-Coyote/1.1\n\
        Content-Type: application/json;charset=UTF-8\nContent-Length: 0\nDate: \
        Fri, 09 Aug 2019 11:14:25 GMT\n\n"
    headers = Formatting(["batch"])
    actual_headers_string = headers.format_headers(headers_string)

# Generated at 2022-06-12 00:03:22.944914
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersFormatPlugin
    f1 = Formatting(['headers'],
                    stream=None)
    assert f1.format_headers("") == ""
    f2 = Formatting(['headers'],
                    stream=None)
    assert f2.format_headers("X-Unit-Test: 1") == "X-Unit-Test: 1\n"

# Generated at 2022-06-12 00:03:32.884138
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(env=Environment(), groups=['format'])
    content = f.format_body('{ "testing": {"test_body" : "test" }}', "application/json")
    assert content == '{\n    "testing": {\n        "test_body": "test"\n    }\n}\n'



# Generated at 2022-06-12 00:03:34.799853
# Unit test for constructor of class Formatting
def test_Formatting():
    formatters = Formatting(None, env=Environment(), **{})
    print(formatters.enabled_plugins)

# Generated at 2022-06-12 00:03:36.560135
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors", "browser"]
    format_resp = Formatting(groups)
    assert format_resp != None

# Generated at 2022-06-12 00:03:42.395714
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Unit test for method format_headers of class Formatting
    # Arrange
    s = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; encoding=utf8\r\n\r\n'
    output = 'HTTP/1.1 200 OK\nContent-Type: text/html; encoding=utf8\n\n'
    environment = Environment()
    http_message = Formatting(groups=['colors'], env=environment)
    # Act
    output = http_message.format_headers(s)
    # Assert
    assert output == output

# Generated at 2022-06-12 00:03:43.747205
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None


# Generated at 2022-06-12 00:03:53.439090
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
        # Test 1
        conversion = Formatting(groups = ['colors'])
        mime = 'text/html'
        content = "<!DOCTYPE html>"
        assert conversion.format_body(content, mime) == '\x1b[38;5;244m<!DOCTYPE html>\x1b[0m'

        # Test 2
        conversion = Formatting(groups = ['colors'])
        mime = 'text/html'
        content = '<html>\n<body>\n<p>Test</p>\n</body>\n</html>'

# Generated at 2022-06-12 00:04:02.550335
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting = Formatting(groups=['colors'])
    formatted_headers = formatting.format_headers("""HTTP/1.1 200 OK
Server: nginx
Content-Type: application/json; charset=utf-8
X-Powered-By: Express
Content-Length: 100
Etag: W/"64-eqKjg/x0X9ey/q3cqC0P/iGjK4"
Date: Sun, 16 Sep 2018 18:39:00 GMT
Connection: keep-alive

""")

# Generated at 2022-06-12 00:04:05.804274
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['highlighting', 'json', 'colors']
    TestFormatting = Formatting(groups, encoding='utf8')
    TestFormatting.format_headers("headers")
    TestFormatting.format_body("content", "json")

# Generated at 2022-06-12 00:04:10.154057
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    groups: List[str] = ['colors']
    format_obj = Formatting(groups, env)

    result = format_obj.format_headers(headers="date: Tue, 01 Dec 2020 19:28:39 GMT")
    assert result == "date: Tue, 01 Dec 2020 19:28:39 GMT"



# Generated at 2022-06-12 00:04:14.898471
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    converter = Conversion.get_converter('application/xml')
    assert converter.mime == 'application/xml'
    converter = Conversion.get_converter('application/yaml')
    assert converter.mime == 'application/yaml'


# Generated at 2022-06-12 00:04:21.167558
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter(mime="text/css")
    assert converter.mime == "text/css"

# Generated at 2022-06-12 00:04:22.952312
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter('application/json')
    assert isinstance(c, ConverterPlugin)



# Generated at 2022-06-12 00:04:25.503313
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('image/jpeg')
    if isinstance(converter,ConverterPlugin):
        assert 1 == 1
    else:
        assert 0 == 1

# Generated at 2022-06-12 00:04:36.195448
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.core import DEFAULT_FORMAT_OPTIONS
    # get the headers from the server
    headers = "HTTP/1.1 200 OK\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nServer: Apache\r\nLast-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\nETag: \"34aa387-d-1568eb00\"\r\nAccept-Ranges: bytes\r\nContent-Length: 51\r\nVary: Accept-Encoding\r\nContent-Type: text/plain\r\n\r\n"
    # format the headers
    f = Formatting(DEFAULT_FORMAT_OPTIONS, env=Environment(),
                   pretty=False, colors=False, style=None, headers=None)
    formatted_

# Generated at 2022-06-12 00:04:38.364000
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['a','b','c']
    env = Environment()
    obj1 = Formatting(groups, env)


# Generated at 2022-06-12 00:04:39.314861
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pass


# Generated at 2022-06-12 00:04:50.663256
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = []
    header = "HTTP/1.1 200 OK\nContent-Type: application/json\n\n"
    test = Formatting(groups)
    assert test.format_headers(header) == header
    groups = ['colors']
    header = "HTTP/1.1 200 OK\nContent-Type: application/json\n\n"
    test = Formatting(groups)
    assert test.format_headers(header) == "\x1b[32mHTTP/1.1 200 OK\x1b[39m\n\x1b[32mContent-Type: application/json\x1b[39m\n\n"
    groups = ['format', 'colors']
    header = "HTTP/1.1 200 OK\nContent-Type: application/json\n\n"
    test = Formatting

# Generated at 2022-06-12 00:04:51.876013
# Unit test for constructor of class Formatting
def test_Formatting():
    a = Formatting(groups=["colors"])

# Generated at 2022-06-12 00:04:57.200311
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    env = Environment()
    groups = ['json', 'colors']
    enabled_plugins = []
    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=env, indent=4)
            if p.enabled:
                enabled_plugins.append(p)
    for p in enabled_plugins:
        print(p.name)
        
test_Formatting()

# Generated at 2022-06-12 00:05:01.164349
# Unit test for constructor of class Formatting
def test_Formatting():
    # Case 1: all formatting rules are available
    f = Formatting(["Color"])
    assert len(f.enabled_plugins) == 1

    # Case 2: no formatting rules are available
    f = Formatting(["blah"])
    assert len(f.enabled_plugins) == 0

# Generated at 2022-06-12 00:05:10.560304
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    try:
        formatter = Formatting(groups=['styled'], env=env)
    except Exception as e:
        assert 0
    try:
        formatter.format_headers('test_headers')
    except Exception as e:
        assert 0
    try:
        formatter = Formatting(groups=['test_group'], env=env)
        formatter.format_headers('test_headers')
        assert 0
    except Exception as e:
        assert 1


# Generated at 2022-06-12 00:05:17.283542
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print("\n********* test_Formatting_format_headers() *********")
    headers = '200\r\nContent-Type: application/json\r\n\r\n'
    # formatters = plugin_manager.get_formatters_grouped()
    # fmt = Formatting(['pprint'])
    # print(fmt.format_headers(headers))
    # assert fmt.format_headers(headers) == headers


# Generated at 2022-06-12 00:05:25.364675
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors', 'compact']
    formaters = Formatting(groups)
    mime = 'application/json'
    body = r'''{"menu": {
  "id": "file",
  "value": "File",
  "popup": {
    "menuitem": [
      {"value": "New", "onclick": "CreateNewDoc()"},
      {"value": "Open", "onclick": "OpenDoc()"},
      {"value": "Close", "onclick": "CloseDoc()"}
    ]
  }
}}'''
    assert body == formaters.format_body(body, mime)



# Generated at 2022-06-12 00:05:31.432441
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie import output
    from httpie.compat import is_py2
    from httpie.compat import is_windows

    output.CRLF = '\r\n' if is_windows else '\n'
    output.COLOR_DEPTH = 16 if is_py2 else 256
    output.IS_PYCHARM = False
    output.__init__()

    input_body = ''
    expected_body = ''
    actual_body = Formatting(['colors']).format_body(input_body, 'text/html')

    assert actual_body == expected_body


# Generated at 2022-06-12 00:05:34.655407
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting = Formatting(['colors'])
    test_body = 'httpie'
    assert formatting.format_body(test_body, 'application/json') == test_body



# Generated at 2022-06-12 00:05:36.624014
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html') is None
    assert isinstance(Conversion.get_converter('text/markdown'),
                      ConverterPlugin)

# Generated at 2022-06-12 00:05:38.465201
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting([])
    Formatting(["colors"])
    Formatting(["colors","format"])

# Generated at 2022-06-12 00:05:43.465934
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_available = Conversion.get_converter("application/json")
    converter_not_found = Conversion.get_converter("application/notfound")
    assert converter_available
    assert not converter_not_found
    json_text = "{\"key\": \"value\"}"
    converted_json_text = converter_available.convert(json_text)
    assert converted_json_text["key"] == "value"



# Generated at 2022-06-12 00:05:53.043483
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    Test data is from python-httpie/tests/compat/test_formatters.py
    """
    formatter = Formatting(['color'])
    assert formatter.format_body('<test></test>',
                                 'text/html') == '<test></test>'
    assert formatter.format_body('<test></test>',
                                 'application/xml') == '<test></test>'
    assert formatter.format_body('<test></test>',
                                 'application/json') == '<test></test>'

# Generated at 2022-06-12 00:06:01.416736
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import PrettyOptionsPlugin

    # test 1: default = all
    f = Formatting([])
    formatter = f.enabled_plugins[0]
    assert isinstance(formatter, PrettyOptionsPlugin)

    headers = {
        "User-Agent": "HTTPie/1.0.0",
        "Content-Type": "application/json",
        "Content-Length": "356",
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "keep-alive"
    }


# Generated at 2022-06-12 00:06:13.022420
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not is_valid_mime('/')
    assert not is_valid_mime('/text')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('text/htm l')
    assert is_valid_mime('text/html; charset=utf8')
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/vnd.api+json')
    assert is_valid_mime('application/vnd.api+json; charset=utf-8')
    assert is_valid_mime('application/vnd.api+json; profile=https://www.example.com/schema/v1/user')


# Generated at 2022-06-12 00:06:17.733248
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {
        'colors': {
            'header': 'cyan'
        }
    }
    fmt = Formatting(groups, env)
    assert len(fmt.enabled_plugins) == 1
    fmt = Formatting(groups, env, **kwargs)
    assert len(fmt.enabled_plugins) == 1
    

# Generated at 2022-06-12 00:06:28.322853
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    kwargs = {'request_info': {'headers': {'Content-Type': 'text/html'}}}
    formatting = Formatting(groups=['default'], env=env, **kwargs)
    plugins = formatting.enabled_plugins

    assert len(plugins) == 1
    assert plugins[0].name == 'colors'

    p = plugins[0]
    assert p.format_headers('Content-Type:text/html\r\nContent-Length:5') == '\x1b[32mContent-Type\x1b[39m: text/html\r\n\x1b[32mContent-Length\x1b[39m: 5'
    assert p.format_body('Hello', 'text/html') == 'Hello'

# Generated at 2022-06-12 00:06:35.124480
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=['colors'])
    headers = "HTTP/1.1 200 OK\r\nCache-Control: no-cache\r\n\r\n"
    result = f.format_headers(headers)
    expected = '\x1b[7mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[33mCache-Control: no-cache\x1b[0m\r\n\r\n'
    assert result == expected


# Generated at 2022-06-12 00:06:37.883556
# Unit test for constructor of class Formatting
def test_Formatting():
    groups=["format_json_body", "format_xml_body"]
    a = Formatting(groups, env=Environment(), ** {"timeout": 45})
    print(a.enabled_plugins)


# Generated at 2022-06-12 00:06:47.518446
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test 1: When mime is valid, at least one processor is enabled, input is not "", output should not be ""
    f = Formatting(["httpie"])
    output_body = f.format_body("", "application/json")
    assert output_body != ""

    # Test 2: When mime is valid, at least one processor is enabled, input is "", output should be ""
    output_body = f.format_body("abc", "application/json")
    assert output_body != ""

    # Test 3: When mime is valid, no processor is enabled, input is "", output should be ""
    f = Formatting(["html"])
    output_body = f.format_body("", "application/json")
    assert output_body == ""

    # Test 4: When mime is not valid, input is "",

# Generated at 2022-06-12 00:06:55.377707
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ["headers"]
    kwargs = {}
    env = Environment()
    formatting = Formatting(groups, env, **kwargs)
    test_headers = """HTTP/1.1 200 OK
Date: Tue, 24 Jun 2017 02:51:44 GMT
Server: Apache/2.2.22 (Ubuntu)
X-Powered-By: PHP/5.3.10-1ubuntu3.26
Vary: Accept-Encoding
Content-Encoding: gzip
Content-Length: 1879
Connection: close
Content-Type: text/html

"""

# Generated at 2022-06-12 00:07:00.256169
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    m = Formatting(['colors'], Environment(colors=True))
    c = available_plugins['colors'][0]
    m.enabled_plugins = [c(env=Environment(colors=True))]
    assert m.enabled_plugins[0].enabled == True
    assert m.format_headers("Content-Type: text/plain") == "\x1b[34mContent-Type: text/plain\x1b[0m"


# Generated at 2022-06-12 00:07:03.914607
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    env = Environment()
    groups = []
    for group in groups:
        for cls in available_plugins[group]:
            cls(env=env, **kwargs)



# Generated at 2022-06-12 00:07:08.234933
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    for group in available_plugins.keys():
        print("group:", group)
        formatting = Formatting([group])
        assert formatting.enabled_plugins
        for p in formatting.enabled_plugins:
            print("p:", p, p.enabled)
            assert p.enabled

# Generated at 2022-06-12 00:07:24.871887
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import FormatterPlugin
    class DummyFormatterPlugin(FormatterPlugin):
        group_name = 'dummy'
        can_disable = True
        enabled = True
        def format_headers(self, headers):
            return(headers)
        def format_body(self, content, mime):
            return(content)

    plugin_manager.register(DummyFormatterPlugin)
    try:
        result = Formatting(groups=['dummy'])
        assert(len(result.enabled_plugins)==1)
        assert(result.enabled_plugins[0].group_name=='dummy')
    finally:
        plugin_manager.unregister(DummyFormatterPlugin)

# Generated at 2022-06-12 00:07:27.573038
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)

# Generated at 2022-06-12 00:07:32.894550
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    expected_output = ["utf-8", "json"]
    generated_output = []
    mime = "application/json"
    if is_valid_mime(mime):
        for converter_class in plugin_manager.get_converters():
            if converter_class.supports(mime):
                generated_output.append(converter_class.get_encoding())
                generated_output.append(converter_class.get_extension())
    assert expected_output == generated_output

# Generated at 2022-06-12 00:07:35.905165
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin import JSONConverter
    assert isinstance(Conversion.get_converter('application/json'), JSONConverter)
    assert not Conversion.get_converter('test')

# Generated at 2022-06-12 00:07:40.124888
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """Unit test for method format_headers of class Formatting."""
    formatting = Formatting([], env=Environment())
    headers = formatting.format_headers("Content-Type: text/html\n\n")
    assert(headers == "Content-Type: text/html\n\n")


# Generated at 2022-06-12 00:07:50.894251
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.config["pretty"] = "all"
    formatter = Formatting(groups=["headers", "colors"], env=env)
    #httpbin.org always returns same data for headers endpoint
    test_input = '''HTTP/1.1 200 OK
access-control-allow-credentials: true
access-control-allow-origin: *
content-length: 872
content-type: application/json
date: Mon, 11 Mar 2019 20:23:14 GMT
server: gunicorn/19.9.0
via: 1.1 vegur
'''
    #expected output with colors and pretty formatting

# Generated at 2022-06-12 00:07:52.996597
# Unit test for constructor of class Formatting
def test_Formatting():
    fm = Formatting(groups=['json', 'colors'])
    print (fm.format_headers('{"key": "value"}'))

# Generated at 2022-06-12 00:07:55.284211
# Unit test for constructor of class Formatting
def test_Formatting():
    input = ['format', 'json']
    expected = True
    actual = Formatting(input)
    assert expected == actual

#Unit test for is_valid_mime

# Generated at 2022-06-12 00:08:01.849233
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = []
    groups.append("pretty")
    groups.append("colors")
    env = Environment()
    json_file = open("format_body_test.json", "r")
    json_data = json_file.read()
    json_file.close()
    result = Formatting(groups=groups, env=env).format_body(json_data, 'application/json')
    assert result == "{\n    \"a\": \"b\"\n}\n"

# Generated at 2022-06-12 00:08:09.956071
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    
    headers = """
        HTTP/1.1 200 OK
        Server: nginx/1.14.0 (Ubuntu)
        Date: Sun, 27 May 2018 09:45:37 GMT
        Content-Type: text/html
        Transfer-Encoding: chunked
        Connection: keep-alive
        Last-Modified: Mon, 19 Jan 2015 17:56:29 GMT
        Cache-Control: max-age=0
        Expires: Sun, 27 May 2018 09:45:37 GMT
    """
    formatting = Formatting(['prettifier'])
    print("From Formatting_format_headers()")
    print("----------------------------------------")
    print("\nBefore Formatting: ")
    print("----------------------------------------")
    print(headers)
    print("\n","----------------------------------------")
    formated_headers = formatting.format_

# Generated at 2022-06-12 00:08:37.870977
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    a = 'HTTP/1.1 200 OK\r\n' + 'Date: Fri, 31 Dec 1999 23:59:59 GMT\r\n' + \
        'Content-Type: text/html\r\n' + \
        'Content-Length: 1354\r\n\r\n' + '<html><body>...</body></html>'