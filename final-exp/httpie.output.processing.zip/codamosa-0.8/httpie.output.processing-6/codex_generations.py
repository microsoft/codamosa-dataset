

# Generated at 2022-06-11 23:58:41.975384
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('json')
    assert not Conversion.get_converter('not valid mime')


# Generated at 2022-06-11 23:58:46.960788
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json').supported_mimetypes == ["application/json"]
    assert Conversion.get_converter('application/x-www-form-urlencoded') is None
    assert Conversion.get_converter(None) is None

# Generated at 2022-06-11 23:58:54.864931
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from datetime import datetime
    from httpie.context import Environment
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.registry import plugin_manager as PM
    from httpie.plugins import builtin
    from httpie.structures import CASEDict
    class HeaderPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            headers = super().format_headers(headers)
            return headers + "\n"

    env = Environment()

# Generated at 2022-06-11 23:59:03.619989
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    origin_mime = "application/json"
    assert(is_valid_mime(origin_mime) is True)
    converter = Conversion.get_converter(origin_mime)
    assert(isinstance(converter, ConverterPlugin))
    new_mime = converter.mime
    assert(new_mime == "application/x-javascript")

    origin_mime = "image/png"
    assert(is_valid_mime(origin_mime) is True)
    converter = Conversion.get_converter(origin_mime)
    assert(converter is None)


# Generated at 2022-06-11 23:59:12.240067
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    class ConverterA(ConverterPlugin):
        supported_mime_types = ['application/json', 'text/html']

        def load_from_filename(self, filename):
            pass

        def load_from_file_object(self, file_object):
            pass

        def get_data(self):
            pass

        def pprint(self):
            pass

    class ConverterB(ConverterPlugin):
        supported_mime_types = ['application/xml']

        def load_from_filename(self, filename):
            pass

        def load_from_file_object(self, file_object):
            pass

        def get_data(self):
            pass

        def pprint(self):
            pass

    plugin_manager.register(ConverterA)

# Generated at 2022-06-11 23:59:16.054897
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """
    Testing method get_converter of class Conversion
    """
    assert Conversion.get_converter('image/gif') is not None
    assert Conversion.get_converter('application/pdf') is not None

# Generated at 2022-06-11 23:59:24.847991
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter("")
    assert not Conversion.get_converter("a")
    assert not Conversion.get_converter("a/")
    assert not Conversion.get_converter("/")
    assert not Conversion.get_converter("/a")
    assert not Conversion.get_converter("asd/")
    assert not Conversion.get_converter("/asd")
    assert not Conversion.get_converter("asd/asd\n")
    assert not Conversion.get_converter("asd/asd ")
    assert not Conversion.get_converter("asd/\nasd")
    assert not Conversion.get_converter("\nasd/asd")

# Generated at 2022-06-11 23:59:28.882720
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html').mime == 'text/html'
    assert not Conversion.get_converter('text/something')



# Generated at 2022-06-11 23:59:34.081135
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    headers = '''status: 200

content-encoding: gzip
content-length: 20
content-type: application/json; charset=utf-8

{
    "key": "value"
}
'''
    expected = '''status: 200

content-encoding: gzip
content-length: 20
content-type: application/json; charset=utf-8

{
    "key": "value"
}
'''
    assert expected == f.format_headers(headers)


# Generated at 2022-06-11 23:59:35.671911
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting([])
    assert f.format_headers("") == ""



# Generated at 2022-06-11 23:59:39.754873
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter(None)



# Generated at 2022-06-11 23:59:46.434965
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.compat import urljoin
    from httpie.plugins import JSONFormatter, FormFormatter, HtmlFormatter
    from httpie.plugins.builtin import HTTPPrettyPrinter


# Generated at 2022-06-11 23:59:57.040167
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    default_mime_type = 'application/json'
    mimes_exist = ['application/json', 'text/html']
    mimes_not_exist = ['foo/bar', 'null/null']
    converters_exist = [Conversion.get_converter(i).mime for i in mimes_exist]
    converters_not_exist = [Conversion.get_converter(i).mime for i in mimes_not_exist]
    assert (converters_exist.__len__() == mimes_exist.__len__())
    assert (converters_not_exist.__len__() == mimes_not_exist.__len__())
    assert (converters_exist[0] == default_mime_type)

# Generated at 2022-06-12 00:00:00.169183
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["json"]
    expect = "[\n    {\n        \"id\": 1,\n"
    env = Environment(output_options={"prettify": True})
    content = "{\"id\": 1, \"name\": \"foo\"}"
    fmt = Formatting(groups, env)
    actual = fmt.format_body(content, "application/json")
    assert expect == actual

# Generated at 2022-06-12 00:00:04.930888
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'add_headers': True}
    assert Formatting(groups, env=env, **kwargs).enabled_plugins[0].name == 'Colors'


# Generated at 2022-06-12 00:00:10.785500
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Given
    mime = "application/json"
    content = {1: 5, 2: 4}
    expected_result = '{\n    "1": 5,\n    "2": 4\n}'
    # When
    actual_result = Formatting(["format", "colors"]).format_body(content, mime)
    # Then
    assert expected_result == actual_result

# Generated at 2022-06-12 00:00:13.684785
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(['colors', 'colors'], Environment(), style='solarized').format_headers("HTTP/1.1 200 OK\r\n") == "\x1b[32mHTTP/1.1 200 OK\x1b[0m\r\n"



# Generated at 2022-06-12 00:00:21.414277
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Unit test
    assert Formatting(["base"]).format_body("{}", "application/json") == "{}"
    assert Formatting(["base"]).format_body("", "text/plain") == ""
    assert Formatting(["base"]).format_body("[]", "application/json") == "[]"
    assert Formatting(["base"]).format_body("{}", "application/json; charset=utf-8") == "{}"
    assert Formatting(["base"]).format_body("[]", "application/json; charset=utf-8") == "[]"
    assert Formatting(["base"]).format_body("{}\n", "application/json") == "{}\n"

# Generated at 2022-06-12 00:00:25.472489
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_string = 'application/json'
    converter_test = Conversion.get_converter(test_string)
    assert converter_test.SUPPORTED_MIME in str(converter_test)
    assert converter_test.mime == converter_test.SUPPORTED_MIME


# Generated at 2022-06-12 00:00:36.343176
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print("Testing Formatting.format_body the method...")

    _env = Environment()  # Environment.get_default_env()
    _groups = ['format', 'colors', 'syntax']
    _kwargs = {}
    _enabled_plugins = []

    _available_plugins = plugin_manager.get_formatters_grouped()
    for _group in _groups:
        for _cls in _available_plugins[_group]:
            p = _cls(env=_env, **_kwargs)
            if p.enabled:
                _enabled_plugins.append(p)


# Generated at 2022-06-12 00:00:40.140253
# Unit test for constructor of class Formatting
def test_Formatting():
    # Create an instance of Formatting, no argument
    f = Formatting()
    # Create an instance of Formatting, groups = ['colors']
    f = Formatting(groups=['colors'])

# Generated at 2022-06-12 00:00:42.750487
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print(Conversion.get_converter("application/json"))
    print(Conversion.get_converter("text/html"))

# Generated at 2022-06-12 00:00:44.973471
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')

    assert converter.supports('application/json')

# Generated at 2022-06-12 00:00:53.807952
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSON
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import json
    import ast

    json_plugin = JSON()
    obj = {"name": "Jack", "age": 32, "gender": "Male"}
    json_str = json.dumps(obj, indent=2)
    obj_str_list = []

    # When the json_str is valid JSON, then json_str is formatted indentation.
    formatted_str = "\n".join(json_str.split("\n")[:2])
    f = Formatting(['json'])
    assert f.format_body(json_str, 'application/json') == formatted_str

    # When the formatted_str is not valid JSON, then the string isn't modified.
    assert f.format

# Generated at 2022-06-12 00:01:03.968573
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    form = Formatting(["common"])

# Generated at 2022-06-12 00:01:07.164053
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # 1. Given
    mime = 'application/json'
    # 2. When
    converter = Conversion.get_converter(mime)
    # 3. Then
    assert converter is not None


# Generated at 2022-06-12 00:01:09.881222
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter(mime="text/csv")
    assert converter
    assert converter.mime == "text/csv"


# Generated at 2022-06-12 00:01:18.577919
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    FormattingObj = Formatting(groups=['colors'])
    test_dict = {'Content-Type': 'application/json', 'date': 'Mon, 03 May 2021 09:39:02 GMT',
                 'connection': 'close',
                 'transfer-encoding': 'chunked', 'server': 'nginx/1.14.0 (Ubuntu)', 'x-ratelimit-limit': '1200',
                 'x-ratelimit-remaining': '1195', 'x-ratelimit-reset': '1620047142'}
    formatted_headers = FormattingObj.format_headers(headers=str(test_dict))

# Generated at 2022-06-12 00:01:29.111470
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import httpie.plugins.builtin
    groups = ['Formatters']
    env = Environment()

    fmt = Formatting(groups, env=env)
    data = b'{"name":"matt","age":13,"gender": "male","interests": ["python","go"]}'
    mime = 'application/json'
    content = fmt.format_body(data, mime)
    assert content == data
    data2 = b'{"name":"matt","age":13,"gender": "male","interests": ["python","go"]}'
    mime2 = 'application/javascript'
    content2 = fmt.format_body(data2, mime2)
    assert content2 == data2
    data3 = b'{"name":"matt","age":13,"gender": "male","interests": ["python","go"]}'

# Generated at 2022-06-12 00:01:37.658818
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
	"""
	Testing method format_headers of class Formatting
	:return: assert 'true' if test is successful
	"""
	assert Formatting(['colors']).format_headers('HTTP/1.1 200 OK\r\n') == '\x1b[01;39mHTTP/1.1 \x1b[1;32m200 \x1b[01;39mOK\x1b[39;00m\r\n'
	assert Formatting(['colors']).format_headers('Content-Type: application/json\r\n') == '\x1b[01;39mContent-Type: \x1b[01;34mapplication/json\x1b[39;00m\r\n'


# Generated at 2022-06-12 00:01:42.784207
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('json') is not None



# Generated at 2022-06-12 00:01:44.372321
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None



# Generated at 2022-06-12 00:01:50.655027
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    print(available_plugins)
    print(len(available_plugins))
    env = Environment()
    #print(env)
    kwargs = {"headers": "test,test"}
    format = Formatting(["highlight", "pretty"], env, **kwargs)
    print(format)
    print(format.format_headers("test"))


# Generated at 2022-06-12 00:01:53.129098
# Unit test for constructor of class Formatting
def test_Formatting():
    """Tests that Formatting has the expected behavior."""
    fm = Formatting(['colors', 'syntax_highlight'])
    assert fm.enabled_plugins != []

# Generated at 2022-06-12 00:01:57.100449
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    #Test when the given mime is not valid
    converter = Conversion.get_converter('invalid-mime-type')
    assert converter is None

    #Test when the given mime is valid and there exists a corresponding converter
    converter = Conversion.get_converter('application/json')
    assert converter is not None



# Generated at 2022-06-12 00:02:04.558488
# Unit test for constructor of class Formatting
def test_Formatting():
    """
    Test constructor of class Formatting
    """
    from httpie.plugins.builtin import (
        JSONFormatter,
        PrettyOptionsObject,
        PrettyOptionsPlugin
    )

    pretty_options = PrettyOptionsObject()
    pretty_options.parse({'format': None})
    env = Environment(stdout=io.StringIO(), pretty_options=pretty_options)
    environment = Formatting(groups=['body'], env=env)

    assert JSONFormatter
    assert PrettyOptionsPlugin
    assert environment.enabled_plugins[0].__class__.__name__ == "PrettyOptionsPlugin"

# Generated at 2022-06-12 00:02:14.519363
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.compat import is_windows
    from httpie.core.defaults import (
        DEFAULT_FORMAT,
        DEFAULT_PREFIX,
        DEFAULT_STYLE,
    )
    from httpie.context import Environment
    from httpie.plugins import builtin as plugin

    env = Environment(
        stdin_isatty=True,
        stdout_isatty=True,
        style=DEFAULT_STYLE,
        format=DEFAULT_FORMAT,
        default_options=plugin.DEFAULT_OPTIONS
    )

    # test
    kwargs = {'env': env, 'indent': 2, 'prefix': DEFAULT_PREFIX}
    #test_class = getFormattingClass(groups=['colors'], **kwargs)
    test_class

# Generated at 2022-06-12 00:02:27.649797
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_case_input = '''status: 200 OK
X-Powered-By: Express
Content-Type: text/html; charset=utf-8
Content-Length: 2000
ETag: W/"7d8-52f97cd2e5d5"
Date: Sun, 29 Jul 2018 08:33:23 GMT
Connection: keep-alive'''

    test_case_expected_output = '''HTTP/1.1 200 OK
X-Powered-By: Express
Content-Type: text/html; charset=utf-8
Content-Length: 2000
ETag: W/"7d8-52f97cd2e5d5"
Date: Sun, 29 Jul 2018 08:33:23 GMT
Connection: keep-alive'''

    t = Formatting(groups=['HTTPie'])
    actual_output = t

# Generated at 2022-06-12 00:02:29.853001
# Unit test for constructor of class Formatting
def test_Formatting():
    """
    Test that Formatting constructor runs without crashing.
    """
    groups = ['default']
    kwargs = {}
    Formatting(groups, **kwargs)

# Generated at 2022-06-12 00:02:32.211008
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Given
    mime = 'application/json'
    # When
    converter = Conversion.get_converter(mime)
    # Then
    assert converter.from_mime == 'json'

# Generated at 2022-06-12 00:02:39.838392
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/html'
    expected_converter = 'ConverterPlugin'
    exported_converter = Conversion.get_converter(mime)
    assert type(exported_converter).__name__ == expected_converter

# Generated at 2022-06-12 00:02:42.446316
# Unit test for constructor of class Formatting
def test_Formatting():
    enabled_plugins = Formatting(groups=['colors'])
    assert enabled_plugins.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-12 00:02:44.501155
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting = Formatting(['color', 'colors'])
    print(formatting.format_headers('headers with color: b and red: f;'))



# Generated at 2022-06-12 00:02:51.575522
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """Test case to verify functionality of method format_headers of 
    class Formatting
    """

    input = "key0:   value0  ,key1:value1\n"
    formatter_obj = Formatting(["Formatter-Json","Formatter-Pretty"], enabled=True)
    output = formatter_obj.format_headers(input)
    assert output == "{\n    \"key0\": \"value0\",\n    \"key1\": \"value1\"\n}"


# Generated at 2022-06-12 00:02:54.162013
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors', 'format'], env=Environment())
    assert not fmt.enabled_plugins
    fmt = Formatting(['colors'], env=Environment())
    assert len(fmt.enabled_plugins) == 1

# Generated at 2022-06-12 00:03:04.472620
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import io
    if __name__ == '__main__':
        # When the script starts, the current working directory
        # will be the 'httpie' directory.
        # This is not the case if we run 'python -m unittest test_formatting.py'.
        # We should use __file__ which points to this script instead.
        sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.registry import plugin_manager
    plugin_manager.__init__(extra_dirs=[os.path.dirname(__file__)])

    # Original result

# Generated at 2022-06-12 00:03:07.840382
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert Conversion.get_converter('text/plain') is None

# Generated at 2022-06-12 00:03:11.461475
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['css'])
    b = f.format_body('<a>\n</a>\n', 'application/xhtml+xml')
    assert b == '<a>\n</a>\n'

# Generated at 2022-06-12 00:03:21.113615
# Unit test for constructor of class Formatting
def test_Formatting():

    class FakePlugin:
        enabled = True

        def __init__(self, **kwargs):
            pass

        def format_headers(self, headers):
            return ''

        def format_body(self, content, mime):
            return ''

    class FormattersPluginManagerMock:
        def get_formatters_grouped(self):
            return {
                'colors': [FakePlugin],
                'format': [FakePlugin],
            }

    plugin_manager_mock = FormattersPluginManagerMock()
    base_env = Environment(stdout=None, stderr=None,
                               stdin=None, vars=None)

    formatting = Formatting(['colors', 'format'],
                           env=base_env,
                           pretty=None,
                           colors=None)


# Generated at 2022-06-12 00:03:30.876357
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class TestPlugin1():
        def __init__(self, env=Environment()):
            self.enabled = True
            self.env = env
        def format_headers(self, headers: str) -> str:
            return headers + "\n" + "Headers from plugin 1"

    class TestPlugin2():
        def __init__(self, env=Environment()):
            self.enabled = True
            self.env = env
        def format_headers(self, headers: str) -> str:
            return headers + "\n" + "Headers from plugin 2"

    plugin_manager.register_plugin(TestPlugin1)
    plugin_manager.register_plugin(TestPlugin2)
    headers = "Test headers"

# Generated at 2022-06-12 00:03:41.939418
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_dict = dict()
    test_str = ""
    test_str_format = "HTTP/1.1 200 OK\r\nConnection: keep-alive\r\n\r\n"
    test_dict['Connection'] = 'keep-alive'
    # test_env = Environment()

# Generated at 2022-06-12 00:03:44.399427
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.mime == 'application/json'



# Generated at 2022-06-12 00:03:53.787717
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:03:55.601453
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion().get_converter("application/json") == None

test_Conversion_get_converter()


# Generated at 2022-06-12 00:04:01.783424
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    result = Formatting(groups=['colors']).format_body(content="{\"key\":\"value\"}", mime="application/json")
    assert result == "\x1b[90m{\x1b[39m\x1b[32m\"key\"\x1b[39m\x1b[90m:\x1b[39m\x1b[32m\"value\"\x1b[39m\x1b[90m}\x1b[39m\n"



# Generated at 2022-06-12 00:04:07.138605
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'content-type:application/json\ncontent-length:12\n'
    result = Formatting(['colors']).format_headers(headers)
    assert result == '\033[95mcontent-type\033[0m: \033[94mapplication/json\033[0m\n\033[95mcontent-length\033[0m: \033[94m12\033[0m\n'



# Generated at 2022-06-12 00:04:09.940787
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    my_converter = Conversion.get_converter(mime)
    assert isinstance(my_converter, ConverterPlugin)



# Generated at 2022-06-12 00:04:13.629351
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format', 'unicode']
    # f = Formatting(groups)
    # f.format_headers('h')
    # f.format_body('b', 'm')
    return Formatting(groups)

# Generated at 2022-06-12 00:04:17.414133
# Unit test for constructor of class Formatting
def test_Formatting():
    h = Formatting(groups=['colors'])
    assert len(h.enabled_plugins) == 1
    assert isinstance(h.enabled_plugins[0], ConverterPlugin)


if __name__ == '__main__':
    test_Formatting()

# Generated at 2022-06-12 00:04:22.146935
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(['colors']).format_headers("HTTP/1.1 200 OK\r\nContent-Type:application/json") == '\x1b[90mHTTP/1.1 200 OK\x1b[39m\r\n\x1b[33mContent-Type:\x1b[39m\x1b[36mapplication/json\x1b[39m'


# Generated at 2022-06-12 00:04:34.595923
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '{"hello": "world"}'
    mime = 'application/json'
    groups = ['colors']
    kwargs = {'body_max_line_length': 100}
    result = Formatting(groups, **kwargs).format_body(content, mime)
    assert result == '{\n    "hello": "world"\n}'

# Generated at 2022-06-12 00:04:39.954053
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin import JSONConverter, FormConverter

    # test converter with available input
    assert isinstance(Conversion.get_converter('application/json'), JSONConverter)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), FormConverter)

    # test converter with unavailable input
    assert Conversion.get_converter('application/text') is None

# Generated at 2022-06-12 00:04:40.476931
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert True

# Generated at 2022-06-12 00:04:42.715808
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    fmt = Formatting(["colors"])
    fmt.format_body("hello world", "text/html")


# Generated at 2022-06-12 00:04:49.631825
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['kuler', 'colors']
    available_plugins = plugin_manager.get_formatters_grouped()
    f = Formatting(groups)
    plugins_enabled = f.enabled_plugins
    assert len(available_plugins[groups[0]]) == len(plugins_enabled)
    assert len(available_plugins[groups[1]]) == len(plugins_enabled)


# Generated at 2022-06-12 00:04:59.285442
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import mock

    env = mock.MagicMock()

    plugins_grouped = plugin_manager.get_formatters_grouped()

    formatting = Formatting(
        groups=('json',),
        env=env,
        indent=2,
        sort_keys=True,
    )
    json_plugin = [
        p for p in formatting.enabled_plugins
        if p.__class__ in plugins_grouped['json']
    ][0]

    body = b'{"aa":1,"bb":2}'
    expected_json_body = '{\n  "aa": 1,\n  "bb": 2\n}\n'

    actual_body = formatting.format_body(body, 'application/json')

    assert actual_body == expected_json_body

    # test that the plugged in json converter

# Generated at 2022-06-12 00:05:02.886112
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting.__init__.__qualname__ == "Formatting.__init__"
    assert Formatting.__init__.__doc__ == """A delegate class that invokes the actual processors.""", \
        "Function docstring is not correct."


# Generated at 2022-06-12 00:05:05.092470
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Correct MIME
    assert is_valid_mime('application/hal+json')

    # Incorrect MIME
    assert not is_valid_mime('application/haljson')

# Generated at 2022-06-12 00:05:15.539953
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    output = Formatting(groups=['colors']).format_body('[{"id":1,"date":"2019-06-29T14:11:38","name":"task2"},{"id":2,"date":"2019-06-29T14:11:38","name":"task3"},{"id":3,"date":"2019-06-29T14:11:38","name":"task4"},{"id":4,"date":"2019-06-29T14:11:38","name":"task5"}]', 'application/json')

# Generated at 2022-06-12 00:05:20.988498
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    possible_converter_mime = ['application/json', 'application/javascript', 'application/x-www-form-urlencoded']
    for mime in possible_converter_mime:
        convert = Conversion.get_converter(mime)
        assert(convert.supports(mime))
    assert(Conversion.get_converter(None) is None)
    assert(Conversion.get_converter('') is None)
    assert(Conversion.get_converter('abcd') is None)


# Generated at 2022-06-12 00:05:38.761834
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(
        Conversion.get_converter(mime='application/json'), ConverterPlugin)
    assert not Conversion.get_converter(mime='text/plain')
    assert not Conversion.get_converter(mime='foobar')


# Generated at 2022-06-12 00:05:47.756659
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors', 'formatting']

# Generated at 2022-06-12 00:05:50.958017
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json")
    assert not Conversion.get_converter("application/xml")
    assert MIME_RE.match('application/json')


# Generated at 2022-06-12 00:05:52.097759
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pytest.skip("format_body not implemented")
    pass


# Generated at 2022-06-12 00:05:56.497793
# Unit test for constructor of class Formatting
def test_Formatting():
    fm = Formatting(['colors'], ['HEADERS', 'BODY'])
    assert fm.env == Environment()
    assert fm.enabled_plugins == [colors.ColorsPlugin()]

    nf = Formatting(['colors'])
    assert nf.env == Environment()
    assert nf.enabled_plugins == []

# Generated at 2022-06-12 00:05:57.653315
# Unit test for constructor of class Formatting
def test_Formatting():
    obj = Formatting(['colors'], env=Environment())

# Generated at 2022-06-12 00:05:59.077376
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting()
    res = f.format_headers("Test")
    assert res == "Test"

# Generated at 2022-06-12 00:06:05.515325
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test with a valid MIME type
    mime = "text/plain"
    converter = Conversion.get_converter(mime)
    assert converter.mime == "text/plain"
    assert converter.can_handle_body == True
    assert converter.can_handle_headers == True
    assert converter.enabled == True

    # Test with a invalid MIME type
    mime = "123"
    converter = Conversion.get_converter(mime)
    assert converter == None


# Generated at 2022-06-12 00:06:07.109089
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting('body').format_body('abc', 'abc/abc') == 'abc'


# Generated at 2022-06-12 00:06:11.928049
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment(stdout=sys.stdout)
    formatting = Formatting(groups, env)
    
    #print("formatting.enabled_plugins", formatting.enabled_plugins)
    """
    <httpie.plugins.builtin.colors.ColorsFormatter object at 0x7f69b6c9a128>
    """
    assert(formatting.enabled_plugins[0].__class__.__name__ == "ColorsFormatter")

# Generated at 2022-06-12 00:06:47.272734
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    class Converter(ConverterPlugin):

        def __init__(self, mime):
            pass

        @classmethod
        def supports(cls, mime):
            if mime == 'text/json':
                return True

        def convert_to_json(self, content: str) -> str:
            return content

    mock_Converter = Converter('text/json')
    assert mock_Converter.convert_to_json('{"test": "Test"}') == '{"test": "Test"}'

# Generated at 2022-06-12 00:06:52.932357
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    default_headers = """HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 316
Content-Type: application/json
"""

    custom_headers = """HTTP/1.1 200 OK
Connection: keep-alive
Content-Type: application/json
Content-Length: 316
"""

    headers = custom_headers

    formatting = Formatting(groups=['headers'])
    headers = formatting.format_headers(headers=headers)
    assert headers == default_headers



# Generated at 2022-06-12 00:06:59.088853
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json; charset=utf8') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/plain; charset=utf8') is not None
    assert Conversion.get_converter('nonexistent/media') is None
    assert Conversion.get_converter('application/json; charset=no_registered') is None


# Generated at 2022-06-12 00:07:08.682634
# Unit test for method get_converter of class Conversion

# Generated at 2022-06-12 00:07:15.620478
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Preconditions
    content = "Hallo Welt"
    mime = "text/plain"
    env = Environment(colors=256, stdout_isatty=True, stdin_isatty=True)
    enabled_plugins = []

    # Test
    formatting = Formatting(groups=["test"], env=env, **enabled_plugins)
    result = formatting.format_body(content=content, mime=mime)

    # Test Result
    assert result == content

# Generated at 2022-06-12 00:07:18.378338
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting([]).format_headers("HTTP /1.1 200 OK\nContent-Length: 0") == "HTTP /1.1 200 OK\nContent-Length: 0"



# Generated at 2022-06-12 00:07:20.819936
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    if converter != None:
        assert converter.mime == 'application/json'

# Generated at 2022-06-12 00:07:25.607594
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = {
        "Content-Type": "application/json",
        "Content-Length": "50"
    }
    format_header = Formatting(["BodyPrettyPrint"], env=Environment()).format_headers(headers)
    assert format_header == 'Content-Length: 50\nContent-Type: application/json\n'


# Generated at 2022-06-12 00:07:28.136484
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['formatters']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert(f)

# Generated at 2022-06-12 00:07:34.123886
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '{ "id": "1" }'
    mime = 'application/json'
    # new instance of Formatting Class
    f = Formatting(['colors', 'format'], stream=sys.stdout)
    # invoke format_body method
    formatted_body = f.format_body(content, mime)
    assert formatted_body == '\x1b[94m{\n\x1b[92m\x1b[1m"id"\x1b[0m: \x1b[94m\x1b[1m"1"\x1b[0m\x1b[0m\n}\n\x1b[0m'

# Generated at 2022-06-12 00:08:08.574531
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    instance = Formatting(['Colors'])
    instance.format_headers('key: value\nkey2: value2') == 'key: value\nkey2: value2'

# Generated at 2022-06-12 00:08:11.988593
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(['jmespath'], env)
    assert len(f.enabled_plugins) == 1
    p = f.enabled_plugins[0]
    assert isinstance(p, JMESPathFormat)

# Generated at 2022-06-12 00:08:21.391621
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for valid mime
    # Test for a valid mime
    groups = ['format', 'colors']
    env = Environment()
    env.colors = True
    mime = 'application/dns-message'
    content = 'yOwAw0kAAABAAABAAAAAAAAABoAAAADABkbG0ub3JnAAABAAABAAABAQAAAAABAAABAAABAAAAAQAABAAAAAQAAAQAAAA'
    b64_content = 'yOwAw0kAAABAAABAAAAAAAAABoAAAADABkbG0ub3JnAAABAAABAAABAQAAAAABAAABAAABAAAAAQAABAAAAAQAAAQAAAA'
    # Unit test for one of the plugin that would be used for mime type 'application/dns-message'

# Generated at 2022-06-12 00:08:24.653988
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    formatting = Formatting(['colors', 'format'], env=env)
    # Check if both the plugins are enabled
    assert len(formatting.enabled_plugins) == 2
    env.stdout.close()

# Generated at 2022-06-12 00:08:25.947249
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(groups=['colors'], env=Environment(), json=False)


# Generated at 2022-06-12 00:08:27.698223
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "application/json"
    converter = Conversion.get_converter(mime)
    assert(converter.mime == mime)


# Generated at 2022-06-12 00:08:28.795829
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(['colors']).format_headers("") == ""



# Generated at 2022-06-12 00:08:33.748028
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_string = "Content-Type: application/json\r\n" \
                  "Accept: text/plain"
    test_groups = ["JSON", "Text"]
    f = Formatting(test_groups)
    assert f.format_headers(test_string) == "Content-Type: application/json\r\nAccept: text/plain\r\n"


# Generated at 2022-06-12 00:08:35.371554
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("image/png"), \
        ConverterPlugin)



# Generated at 2022-06-12 00:08:37.756344
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter('application/json')
    assert c is not None
    assert c.mime == 'application/json'

