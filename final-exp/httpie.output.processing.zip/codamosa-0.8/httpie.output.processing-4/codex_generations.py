

# Generated at 2022-06-11 23:58:40.870851
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('not-a-valid-mime-type')



# Generated at 2022-06-11 23:58:45.438285
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
	groups = ['syntax']
	kwargs = {'syntax':'json'}
	f = Formatting(groups, **kwargs)
	assert f.format_body('{"test":1}', 'application/json') == '{\n  "test": 1\n}'
	assert f.format_body('{"test":1}', 'text/html') == None

# Generated at 2022-06-11 23:58:52.111272
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class TestFormatter:
        def format_headers(self, headers: str) -> str:
            return headers + "\n    test"

    class Available_plugins():
        def __init__(self):
            self.enabled_plugins = [TestFormatter()]

    class Available_plugins_grouped():
        test = []

    class Plugin_manager():
        def get_formatters_grouped(self):
            return Available_plugins_grouped()

    plugin_manager = Plugin_manager()
    formatting = Formatting(['test'])
    assert formatting.format_headers("test") == "test\n    test"

# Generated at 2022-06-11 23:58:54.569723
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/html'
    c = Conversion.get_converter(mime)
    assert c.content_type == 'text/html'


# Generated at 2022-06-11 23:59:04.148187
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeaders, HTTPBody
    env = Environment()
    argv = []
    exit_status = ExitStatus.OK
    env.stdout_isatty = False
    env.stdin_isatty = False
    env.is_windows = False
    env.config = None
    f = Formatting(['headers','body'], env=env, argv=argv, exit_status=exit_status)
    assert f.enabled_plugins[0].__class__ == HTTPHeaders
    assert f.enabled_plugins[1].__class__ == HTTPBody
    return f


# Generated at 2022-06-11 23:59:12.492697
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
	#testcase 1
	assert isinstance(Conversion.get_converter('application/jso'), ConverterPlugin) == True
	assert Conversion.get_converter('application/jso').enabled == True
	#testcase 2
	assert isinstance(Conversion.get_converter('application/js'), ConverterPlugin) == True
	assert Conversion.get_converter('application/js').enabled == True
	#testcase 3
	assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin) == True
	assert Conversion.get_converter('application/xml').enabled == True
	#testcase 4
	assert isinstance(Conversion.get_converter('application/jso'), ConverterPlugin) == True
	assert Conversion.get_converter('application/jso').enabled == True

# Generated at 2022-06-11 23:59:21.956614
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Initialize a list of 3 headers
    headers_list = ["HTTP/1.1 404 Not Found", "Date: Wed, 15 Jul 2020 19:22:08 GMT",
                    "Server: Apache"]
    headers_str = '\n'.join(headers_list)
    # Remove the keyword Date
    assert (Formatting(['headers-display']).format_headers(headers_str) ==
            "\n".join([headers_list[0], headers_list[2]]))
    # Initialize a new header list
    headers_list2 = ["HTTP/1.1 200 OK", "Content-Type: text/html;charset=utf-8",
                    "Cache-Control: public, max-age=60"]
    headers_str2 = '\n'.join(headers_list2)
    # Remove the keyword Cache-Control

# Generated at 2022-06-11 23:59:26.827455
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    format_body_test = {"Content-Type": "application/json", 
                        "Content": "{\"Name\":\"Shawn\",\"Gender\":\"Male\", \"Age\":\"25\"}"}
    formatting = Formatting(['colors', 'format'])
    print(formatting.format_body(format_body_test['Content'], format_body_test['Content-Type']))
    assert formatting.format_body(format_body_test['Content'], format_body_test['Content-Type']) != None

# Generated at 2022-06-11 23:59:29.890779
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting()
    fmt.format_headers('Content-Type: application/json')
    fmt.format_body('{"id": "1"}', 'application/json')

# Generated at 2022-06-11 23:59:41.275508
# Unit test for constructor of class Formatting
def test_Formatting():
    class Plugin1:
        @staticmethod
        def format_headers(headers):
            return 'Plugin1:'+headers
    class Plugin2:
        @staticmethod
        def format_headers(headers):
            return 'Plugin2:'+headers
    class Plugin3:
        @staticmethod
        def format_body(content, mime):
            return 'Plugin3:'+content
    class Plugin4:
        @staticmethod
        def format_body(content, mime):
            return 'Plugin4:'+content
    plugin1 = Plugin1()
    plugin2 = Plugin2()
    plugin3 = Plugin3()
    plugin4 = Plugin4()
    plugin_dict = {'group-1' : [plugin1, plugin2], 'group-2' : [plugin3, plugin4]}
    plugin_manager.get_formatters_grouped

# Generated at 2022-06-11 23:59:46.496578
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(["headers",])
    assert Formatting(["headers",]).format_headers("") == ""

# Generated at 2022-06-11 23:59:52.547334
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    h_formatter = Formatting(['colors'])
    headers = h_formatter.format_headers('Content-Type: application/json\r\n')
    assert 'Content-Type: application/json\r\n' == headers
    headers = h_formatter.format_headers('Content-Type: application/json\r\n')
    assert 'Content-Type: application/json\r\n' == headers



# Generated at 2022-06-11 23:59:59.909278
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    env=Environment()
    for group in available_plugins:
        for cls in available_plugins[group]:
            p = cls(env=env)
            if p.enabled:
                enabled_plugins.append(p)
    headers = "HTTP/1.1 200 OK\r\n\r\n"
    for p in enabled_plugins:
        headers = p.format_headers(headers)
    assert headers == "HTTP/1.1 200 OK\n\n"

# Generated at 2022-06-12 00:00:04.134199
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter('invalid/mime')
    assert Conversion.get_converter('json')
    assert Conversion.get_converter('json=one;two')



# Generated at 2022-06-12 00:00:06.067618
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    s = Conversion.get_converter(mime="text/html")
    assert isinstance(s, ConverterPlugin)

# Generated at 2022-06-12 00:00:10.346582
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in ['colors']:
        for cls in available_plugins[group]:
            p = cls(env=Environment())
            if p.enabled:
                enabled_plugins.append(p)
    formatting = Formatting(groups=['colors'])
    assert formatting.enabled_plugins == enabled_plugins



# Generated at 2022-06-12 00:00:12.769489
# Unit test for constructor of class Formatting
def test_Formatting():
    print(Formatting(groups=['colors'], env=Environment(), use_colors=True, style='paraiso-dark'))

if __name__ == '__main__':
    test_Formatting()

# Generated at 2022-06-12 00:00:14.454724
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').__class__.__name__=='JsonConverter'

# Generated at 2022-06-12 00:00:16.268408
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), None)


# Generated at 2022-06-12 00:00:22.968334
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = _format_headers(
        'HTTP/1.1 200 OK\r\n'
        'cache-control: private\r\n'
        'content-type: application/json; charset=utf-8\r\n'
        'server: Microsoft-IIS/8.5\r\n'
        'x-aspnet-version: 4.0.30319\r\n'
        'x-powered-by: ASP.NET\r\n'
        'date: Thu, 22 Dec 2016 09:59:06 GMT\r\n'
        'connection: close\r\n'
        'content-length: 1234\r\n'
        '\r\n',
        ['headers'],
    )

# Generated at 2022-06-12 00:00:29.713698
# Unit test for constructor of class Formatting
def test_Formatting():

    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.context import Environment
    from httpie.compat import is_windows

    headers = 'Accept: */*\r\nAccept-Encoding: gzip, deflate\r\nAuthorization: Basic dGVzdHVzZXI6dGVzdHBhc3N3b3Jk\r\nConnection: keep-alive\r\nContent-Length: 12\r\nContent-Type: application/x-www-form-urlencoded\r\nHost: jsonplaceholder.typicode.com\r\n\r\n'

    p = HTTPHeadersProcessor(env=Environment(colors=256), scheme_color='green', headers_color='red')

    groups = ['headers']
    # groups = ['headers',

# Generated at 2022-06-12 00:00:40.831267
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors", "format"]
    groups2 = ["colors"]
    groups3 = ["format"]
    env = Environment()
    env.config["headers"]["Content-Type"] = "application/json"
    env.stdout_isatty = True

    # testing the constructor with all groups
    f = Formatting(groups=groups, env=env, mime="application/json")
    assert f.enabled_plugins.__len__() == 3, "This should have 3 plugins"

    # testing the constructor with only one group
    f2 = Formatting(groups=groups2, env=env, mime="application/json")
    assert f2.enabled_plugins.__len__() == 1, "This should have 1 plugin"

    # testing the constructor with only one group, the other one

# Generated at 2022-06-12 00:00:46.480582
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/vnd.json") is None
    assert Conversion.get_converter("") is None
    assert Conversion.get_converter("json") is None

# Generated at 2022-06-12 00:00:48.951028
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting("").enabled_plugins == []
    assert Formatting("k").enabled_plugins == []

# Generated at 2022-06-12 00:00:49.955587
# Unit test for constructor of class Formatting
def test_Formatting():
    pass


# Generated at 2022-06-12 00:00:52.245473
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups = ['body'], text ='test')


# Generated at 2022-06-12 00:01:00.041575
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    context = plugin_manager.plugin_context
    context.session = {}
    context.session['config'], context.session['plugins'] = get_config()
    plugins = context.session['plugins']
    plugins['format'] = ['colors']
    env = Environment({}, plugins)
    json_mime = 'application/json'
    json_mime_result = Formatting(groups=['colors'], env=env).format_body('{"a": "b"}', json_mime)
    assert '\x1b[1' in json_mime_result


# Generated at 2022-06-12 00:01:07.467011
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.registry import plugin_manager
    import json
    plugin_manager.register_plugin(JSONFormatterPlugin)

    test_data = {'header': {'name': 'value'}, 'body': 'base64'}
    expected_output = json.dumps(test_data, indent=2)

    formatting_instance = Formatting(['json'])
    json_output = formatting_instance.format_body(json.dumps(test_data), 'application/json')

    assert json_output == expected_output

# Generated at 2022-06-12 00:01:10.233925
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    result = Conversion.get_converter('application/json')
    assert isinstance(result, ConverterPlugin)
    assert result.mime == 'application/json'



# Generated at 2022-06-12 00:01:18.776156
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin import JSONConverter, FormConverter,\
                                        URLEncodedConverter, Converter

    mime = 'application/json'
    assert_equals(Conversion.get_converter(mime), JSONConverter(mime))

    mime = 'application/x-www-form-urlencoded'
    assert_equals(Conversion.get_converter(mime), URLEncodedConverter(mime))

    mime = 'multipart/form-data'
    assert_equals(Conversion.get_converter(mime), FormConverter(mime))

    mime = 'application/x-custom-converter'

# Generated at 2022-06-12 00:01:24.242754
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting = Formatting([])
    assert formatting.enabled_plugins == []
    formatting = Formatting(["colors", "formatters"])
    assert len(formatting.enabled_plugins) == 2


# Generated at 2022-06-12 00:01:29.240567
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env = Environment()
    f = Formatting(groups, env)
    content = 'color'
    mime = "json/color"
    r = f.format_body(content, mime)
    assert(r == 'color')
    mime = "color/color"
    r = f.format_body(content, mime)
    assert(r == 'color')

# Generated at 2022-06-12 00:01:38.515380
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
  class StdoutTextIOWrapper:
    def __init__(self, stdout):
      self.stdout = stdout
    def write(self, msg: str) -> str:
      print(msg, sep='')
      self.stdout.write(msg)
      return msg
  from io import StringIO
  import sys
  buf = StringIO()
  sys.stdout = StdoutTextIOWrapper(sys.__stdout__)

# Generated at 2022-06-12 00:01:49.437051
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Arrange
    content = '{"key": "value"}'
    mime = 'application/json'
    formatting = Formatting(groups=['colors'], env=Environment(),
                            body_max_linewidth=80, pretty=True,
                            format='{/}')
    # Act
    formatted_content = formatting.format_body(content, mime)
    # Assert

# Generated at 2022-06-12 00:01:52.344780
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    try:
        Formatting(groups, env, **kwargs)
    except:
        raise AssertionError


# Generated at 2022-06-12 00:02:02.213467
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    p = Formatting(groups=['format', 'colors'], env=Environment(), styles=True)
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 17
Connection: keep-alive

{"status": "ok"}
'''

# Generated at 2022-06-12 00:02:05.727376
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.output.writers.formatters import PygmentsFormatter
    a = Formatting(['highlight'],is_windows=False, pygments_formatter_cls=PygmentsFormatter)
    assert type(a.format_headers("<b>Hello</b>")) == str


# Generated at 2022-06-12 00:02:10.877893
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment(colors=256)
    # TODO: understand why I have to explicitly claim param groups
    groups = ['color', 'colors', 'pipes']
    fmt = Formatting(groups, env=env, force_colors=True)
    assert len(fmt.enabled_plugins) == 1


# Generated at 2022-06-12 00:02:13.903100
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["format","pretty"]
    env = Environment()
    kwargs = {"pretty": "none", "format": "json"}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == []


# Generated at 2022-06-12 00:02:26.894612
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """Test method `format_headers()` of class `Formatting`."""
    import httpie.cli.formatters
    import httpie.cli.argtypes
    import os
    env = httpie.context.Environment(colors=256,
                                     stdin_isatty=True,
                                     stdout_isatty=False,
                                     is_windows=os.name == 'nt')

# Generated at 2022-06-12 00:02:37.281051
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["JSON", "COLORS"]
    fm = Formatting(groups)
    assert len(fm.enabled_plugins) == 2
    assert isinstance(fm.enabled_plugins[0], ConverterPlugin)
    assert fm.enabled_plugins[0].enabled == True
    assert fm.enabled_plugins[1].enabled == True
    assert isinstance(fm.enabled_plugins[0], ConverterPlugin)

if __name__ == '__main__':
    test_Formatting()

# Generated at 2022-06-12 00:02:41.446919
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'mime/xml'
    assert type(Conversion.get_converter(mime)) == ConverterPlugin
    assert type(Conversion.get_converter('test/test')) == None
    assert type(Conversion.get_converter(None)) == None

# Generated at 2022-06-12 00:02:50.531820
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print('Invoking method get_converter of class Conversion ...')
    print('Case 1: mime = csv')
    mime = 'csv'
    converter_class = Conversion.get_converter(mime)
    assert converter_class.media_type == 'text/csv'
    print('Case 2: mime = json')
    mime = 'json'
    converter_class = Conversion.get_converter(mime)
    assert converter_class.media_type == 'application/json'
    print('Case 3: mime = Wrong-Type')
    mime = 'Wrong-Type'
    converter_class = Conversion.get_converter(mime)
    assert converter_class is None


# Generated at 2022-06-12 00:02:52.582314
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "application/x-www-form-urlencoded"
    assert isinstance(Conversion.get_converter(mime), ConverterPlugin)

# Generated at 2022-06-12 00:02:59.281970
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Set the Environment to the one used by the implemented function
    env = Environment()
    # Create an instance of Formatting with the "colors" group of formatters
    test_formatting = Formatting(groups=[], env=env)
    # Declare an empty string to hold the formatted output
    formatted_output = ""
    # Call method format_headers with an input string as argument
    formatted_output = test_formatting.format_headers("Host: httpie.org")
    # Check the result with the expected output
    assert formatted_output == "Host: httpie.org"

# Generated at 2022-06-12 00:03:06.429708
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    env = Environment(stdout_isatty=True)
    converter: Optional[ConverterPlugin]
    converter = Conversion.get_converter("application/json")
    assert converter != None
    assert converter.mime == "application/json"
    assert converter.content_type_header == "Content-Type: application/json"
    assert converter.content_type_header.encode("iso-8859-1").decode("utf-8") == "Content-Type: application/json"


# Generated at 2022-06-12 00:03:08.341305
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test = Formatting(["BASE"])
    assert test.format_headers("<TYPO") == "&lt;TYPO"



# Generated at 2022-06-12 00:03:13.920996
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=['SyntaxHighlight', 'Highlight'])
    import json
    headers = json.dumps({'httpie': '1.0.3'})
    formatted_headers = f.format_headers(headers)
    assert formatted_headers == '{\n    "httpie": "1.0.3"\n}'


# Generated at 2022-06-12 00:03:20.970119
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors']
    AvailableFormatterPlugins = plugin_manager.get_formatters_grouped()
    headers = """HTTP/1.1 200 OK
Date: Tue, 08 Apr 2014 15:54:56 GMT
Server: Apache
X-Powered-By: PHP/5.4.4-14+deb7u4
Content-Length: 11
Keep-Alive: timeout=5, max=100
Connection: Keep-Alive
Content-Type: text/html

Hello world!"""

    formatter = Formatting(groups)
    headers = formatter.format_headers(headers)
    print(headers)

# Generated at 2022-06-12 00:03:28.849722
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format_headers_ans = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: 6\r\n\r\n'
    format_headers_para = 'HTTP/1.1 200 OK\r\n\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: 6\r\n'
    assert Formatting('headers').format_headers(format_headers_para) == format_headers_ans
    assert Formatting('headers').format_headers(format_headers_ans) == format_headers_ans


# Generated at 2022-06-12 00:03:45.667742
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    '''
    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=env, **kwargs)
            if p.enabled:
                enabled_plugins.append(p)
    '''
    for cls in available_plugins["colors"]:
            p = cls(env=Environment(), **{})
            if p.enabled:
                enabled_plugins.append(p)
    for cls in available_plugins["format"]:
            p = cls(env=Environment(), **{})
            if p.enabled:
                enabled_plugins.append(p)
    p = Formatting(enabled_plugins, Environment())

# Generated at 2022-06-12 00:03:52.039979
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Tester for method format_headers of class Formatting
    f = Formatting(groups=['colors'])
    print(f.format_headers('HTTP/1.1 200 OK\r\nHeader: value'))
    print(f.format_headers('Content-Type: text/html\r\nHeader: value'))
    print(f.format_headers(''))
    print(f.format_headers(None))


# Generated at 2022-06-12 00:04:00.852728
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # test for input html
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in ['colors', 'colors']:
        for cls in available_plugins[group]:
            p = cls()
            if p.enabled:
                enabled_plugins.append(p)
    content = '<!DOCTYPE html>'
    mime = 'text/html'
    assert Formatting.format_body(enabled_plugins, content, mime) == \
        '[39m[49m^[0m<![33m[39mDOCTYPE html>[0m'
    # test for input plain text
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []

# Generated at 2022-06-12 00:04:10.433960
# Unit test for constructor of class Formatting
def test_Formatting():
    str_headers="HTTP/1.1 200 OK\r\n"
    str_headers+="Content-Type: application/json\r\n"
    str_headers+="Date: Fri, 26 Jun 2020 11:26:32 GMT\r\n"
    str_headers+="Transfer-Encoding: chunked\r\n"
    str_headers+="Connection: keep-alive\r\n"
    str_headers+="Access-Control-Allow-Origin: *\r\n"
    str_headers+="Access-Control-Allow-Methods: DELETE, GET, HEAD, OPTIONS, PATCH, POST, PUT\r\n"

# Generated at 2022-06-12 00:04:20.221420
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    env_mime = 'text/html'
    a = Conversion.get_converter(env_mime)
    assert a is not None
    assert a.mime == 'text/html'

    env_mime = 'text/plain'
    a = Conversion.get_converter(env_mime)
    assert a is not None
    assert a.mime == 'text/plain'

    env_mime = 'text/plain+json'
    a = Conversion.get_converter(env_mime)
    assert a is not None
    assert a.mime == 'text/plain+json'

    env_mime = 'text/html+json'
    a = Conversion.get_converter(env_mime)
    assert a is not None

# Generated at 2022-06-12 00:04:28.278702
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPieJSONFormatPlugin
    from httpie.plugins.builtin import HTTPiePrettyFormatPlugin
    from httpie.context import Environment
    from io import StringIO
    env = Environment(colors=True, stdout=StringIO(), stderr=StringIO())
    formatter = Formatting(groups=["pretty", "json"], env=env)
    assert HTTPieJSONFormatPlugin in [p.__class__ for p in formatter.enabled_plugins]
    assert HTTPiePrettyFormatPlugin in [p.__class__ for p in formatter.enabled_plugins]
    assert formatter.enabled_plugins[0].__class__ == HTTPiePrettyFormatPlugin
    assert formatter.enabled_plugins[1].__class__ == HTTPieJSONFormatPlugin

# Generated at 2022-06-12 00:04:38.825509
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test initialize and instance variables
    available_plugins = plugin_manager.get_formatters_grouped()
    formatting = Formatting(['colors'])
    assert formatting.enabled_plugins == []
    for group in ['colors']:
        for cls in available_plugins[group]:
            p = cls()
            if p.enabled:
                formatting.enabled_plugins.append(p)
    assert formatting.enabled_plugins
    # Test format_headers

# Generated at 2022-06-12 00:04:44.472605
# Unit test for constructor of class Formatting
def test_Formatting():
    headers = "abc\ndef\n"
    mime = "text/plain; charset=iso-8859-1"
    content = "abc\n"

    groups = ["colors", "formatters"]
    formatting = Formatting(groups=groups)
    content = formatting.format_body(content, mime)
    headers = formatting.format_headers(headers)
    print(content)
    print(headers)
    pass

# Generated at 2022-06-12 00:04:47.433139
# Unit test for constructor of class Formatting
def test_Formatting():
    d = Formatting(["colors", "formatters"])
    assert d.enabled_plugins


# Generated at 2022-06-12 00:04:52.109977
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(groups = ['colors'], env=env)
    assert len(f.enabled_plugins) == 2
    assert isinstance(f.enabled_plugins[0], PrettyJsonFormatter)
    assert isinstance(f.enabled_plugins[1], PrettyJsonExpandFormatter)

# Generated at 2022-06-12 00:05:07.949202
# Unit test for constructor of class Formatting
def test_Formatting():
    format_str = Formatting(['colors'], env=Environment(), pretty='all', style='solarized')
    assert format_str.enabled_plugins[0].__class__.__name__ == 'Solarized'
    format_str = Formatting(['colors'], env=Environment(), pretty='', style='monokai')
    assert format_str.enabled_plugins[0].__class__.__name__ == 'Monokai'
    format_str = Formatting(['colors'], env=Environment(), pretty='all', style='default')
    assert format_str.enabled_plugins[0].__class__.__name__ == 'Default'


# Generated at 2022-06-12 00:05:18.633309
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # json to json
    assert Conversion.get_converter('application/json').mime == 'application/json'
    # json to jsonl
    assert Conversion.get_converter('application/jsonl').mime == 'application/jsonl'
    # jsonl to json
    assert Conversion.get_converter('application/jsonl').mime == 'application/jsonl'
    # jsonl to jsonl
    assert Conversion.get_converter('application/jsonl').mime == 'application/jsonl'
    # xml to json
    assert Conversion.get_converter('application/xml').mime == 'application/xml'
    # xml to jsonl
    assert Conversion.get_converter('application/xml').mime == 'application/xml'
    # xml to xml
    assert Conversion.get_conver

# Generated at 2022-06-12 00:05:29.040261
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1: 'auto' as only argument
    a = Formatting(['auto'])
    if len(a.enabled_plugins) < 4:
        raise AssertionError

    # Test case 2: 'all' as only argument
    b = Formatting(['all'])
    if len(b.enabled_plugins) < 6:
        raise AssertionError

    # Test case 3: 'pretty' as only argument
    c = Formatting(['pretty'])
    if len(c.enabled_plugins) < 2:
        raise AssertionError    

    # Test case 4: with different arguments
    d = Formatting(['auto', 'pretty'])
    if len(d.enabled_plugins) < 6:
        raise AssertionError

    # Test case 5: with invalid argument

# Generated at 2022-06-12 00:05:33.992324
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'colors']
    env = Environment()
    f = Formatting(groups, env)
    assert f.enabled_plugins is not None, 'fail'
    assert f.enabled_plugins is not None, 'fail'
    assert len(f.enabled_plugins) == 1, 'fail'
    assert f.enabled_plugins[0] is not None, 'fail'


# Generated at 2022-06-12 00:05:35.816603
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("Content-Type: application/json")
    assert converter == None



# Generated at 2022-06-12 00:05:39.452081
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    Test Formatting method format_body
    """
    # test with json format
    formatter = Formatting()
    formatter.format_body('{"John": "12345678"}')
    # test with html format
    formatter.format_body('<html>Hello World</html>', 'text/html')

# Generated at 2022-06-12 00:05:45.561647
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert(Formatting(["fancy_formatter"]).format_body(
        '{"name":"abc"}', "application/json") == "\x1b[36m{\x1b[39;49;00m\x1b[36m\"name\"\x1b[39;49;00m\x1b[01;33m:\x1b[39;49;00m\x1b[32m\"abc\"\x1b[39;49;00m\x1b[36m}\x1b[39;49;00m\n")

# Generated at 2022-06-12 00:05:49.640771
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_class = plugin_manager.get_converters()[0]
    assert isinstance(Conversion.get_converter(converter_class.mimes[0]),
                      converter_class)
    assert Conversion.get_converter('xyz/abcd') is None

# Generated at 2022-06-12 00:05:56.412526
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """ Test get_converter in class Conversion. The test data is taken from plugin json_indent,
    in which the converter supported is application/json.
    The test result is from the function plugin_manager.get_converters() where you can find
    the supported converter. """
    for converter_class in plugin_manager.get_converters():
        if converter_class.supports("application/json"):
            assert converter_class.name == 'json_indent'
            assert converter_class.mime == 'application/json'
            assert converter_class.options.pretty

# Generated at 2022-06-12 00:06:03.228611
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(["snippet"])
    mime = "text/html"
    content = "<!DOCTYPE html>\n<html>\n<head>\n</head>\n<body>\n<img src=\"http://www.example.com/test1.png\" alt=\"image\" >\n\n<img src=\"test2.jpg\" alt=\"image\" >\n\n</body>\n</html>"

# Generated at 2022-06-12 00:06:25.682876
# Unit test for constructor of class Formatting
def test_Formatting():
    class TestFormatting(Formatting):
        def __init__(self, groups: List[str], env=Environment(), **kwargs):
            super().__init__(groups, env, **kwargs)

    test = TestFormatting(['pretty'])
    assert test.enabled_plugins[0].enabled == True

# Generated at 2022-06-12 00:06:27.868592
# Unit test for constructor of class Formatting
def test_Formatting():
    format = Formatting(['Colored', 'Highlight'])
    for p in format.enabled_plugins:
        assert p.enabled == True

# Generated at 2022-06-12 00:06:35.757307
# Unit test for constructor of class Formatting
def test_Formatting():
    # Testing normal case
    fmt = Formatting(['colors'], color=True, style=True)
    assert isinstance(fmt, Formatting)
    # Testing invalid group name
    with pytest.raises(KeyError):
        fmt = Formatting(['invalid_group_name'])
    # Testing non-string arguments
    fmt = Formatting([1], color=1, style=1)
    assert isinstance(fmt, Formatting)
    # Testing extra argument
    fmt = Formatting([1], color=1, style=1, invalid_arg=None)
    assert isinstance(fmt, Formatting)


# Generated at 2022-06-12 00:06:43.309413
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    mime_re = re.compile(r'^[^/]+/[^/]+$')
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in ['colors', 'format']:
        for cls in available_plugins[group]:
            p = cls(env=Environment(), **{'format': 'default'})
            if p.enabled:
                enabled_plugins.append(p)
    def is_valid_mime(mime):
        return mime and mime_re.match(mime)

    def format_headers(headers):
        for p in enabled_plugins:
            headers = p.format_headers(headers)
        return headers

# Generated at 2022-06-12 00:06:46.439285
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """ Testing format_body() of Formatting() class
    """
    fmt = Formatting([])
    result = fmt.format_body('{"k": "v"}', 'application/json')
    assert result == '{"k": "v"}'

# Generated at 2022-06-12 00:06:54.605126
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    # 1
    format_obj = Formatting(['json', 'colors'], style='solarized')
    input_test = json.dumps({'test': '123'})
    expected_test = '{\n    "test": 123\n}'
    actual_test = format_obj.format_headers(input_test)
    assert actual_test == expected_test

    # 2
    format_obj = Formatting(['colors'], style='solarized')
    input_test = '{"test":"123"}'
    expected_test = '{\n    "test": 123\n}'
    actual_test = format_obj.format_headers(input_test)
    assert actual_test == expected_test

    # 3
    format_obj = Formatting(['colors'])

# Generated at 2022-06-12 00:06:57.293649
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ["colors"]
    kwargs = {"style": {"error": "red"}}
    formatting = Formatting(groups=groups, env=env, **kwargs)
    assert formatting

# Generated at 2022-06-12 00:07:03.585735
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert (Conversion.get_converter("application/json") is not None)
    assert (Conversion.get_converter("application/jsonxxx") is None)
    assert (Conversion.get_converter("application/xml") is not None)
    assert (Conversion.get_converter("application/xmlyyy") is None)
    assert (Conversion.get_converter("text/html") is not None)
    assert (Conversion.get_converter("text/htmlzzz") is None)



# Generated at 2022-06-12 00:07:08.240271
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert(is_valid_mime("hello/world") is False)
    assert(is_valid_mime("application/json") is True)
    converter = Conversion.get_converter("application/json")
    assert(converter is not None)
    converter = Conversion.get_converter("hello/world")
    assert(converter is None)


# Generated at 2022-06-12 00:07:15.548120
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.registry import plugin_manager

    class TestPlugin(FormatterPlugin):
        name = "TestPlugin1"

        def format_headers(self, headers: str) -> str:
            return headers + 'TestPlugin'

    plugin_manager.add_plugin(TestPlugin())
    f = Formatting(['builtin'])
    result = f.format_headers('test')
    assert result == 'testTestPlugin'



# Generated at 2022-06-12 00:07:51.565651
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors', 'colors'])

# Generated at 2022-06-12 00:08:00.840574
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from pytest import approx
    from datetime import datetime
    groups = ['format-header']
    env = Environment()
    args = {}
    formatter = Formatting(groups, env, **args)
    headers = """
{
  "status": 200,
  "time": "2018-08-07T04:00:41Z",
  "request": {
    "method": "GET",
    "url": "https://api.mercadolibre.com/users/616577142",
    "body": null
  },
  "body": {
    "id": 616577142
  },
  "error": {}
}
"""
    formatted_headers = formatter.format_headers(headers)
    # Convert string to datetime so we can verify its value
    formatted_headers_json = json.loads

# Generated at 2022-06-12 00:08:09.318025
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    header_item_list = ['Content-Type: application/json', 'Cache-Control: public, max-age=0, must-revalidate',
                        'Vary: X-HTTP-Method-Override, Accept-Encoding',
                        'Connection: keep-alive', 'Transfer-Encoding: chunked', 'Date: Wed, 28 Jun 2017 17:04:13 GMT',
                        'X-Powered-By: Express', 'ETag: W/"e91-E+FCKFodJtb3qW0nDtKgiz9yRk"',
                        'Content-Encoding: gzip']
    groups = ['colors']
    formatting = Formatting(groups)

# Generated at 2022-06-12 00:08:11.376724
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter_class = Conversion.get_converter(mime)
    assert converter_class is not None



# Generated at 2022-06-12 00:08:18.566769
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Check if method get_converter returns the correct converter.
    converter = Conversion.get_converter('image/jpeg')
    assert converter.__class__.__name__ == 'ImageViewer'

    # Check if method get_converter returns none when it receives invalid mime.
    converter = Conversion.get_converter('image/svg')
    assert converter is None

    # Check if method get_converter returns none when it receives empty string.
    converter = Conversion.get_converter('')
    assert converter is None


# Generated at 2022-06-12 00:08:26.321075
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Requesting the url "https://httpbin.org/json" from Wikipedia's URl shortener API.
    # Wikidata URL shortener API documentation: https://www.mediawiki.org/wiki/Wikidata_URL_shortener_API
    f = Formatting(['format'])  # Create an object of class Formatting
    content = 'https://httpbin.org/json'
    mime = 'application/json'
    result = f.format_body(content, mime)  # Invoke format_body method

# Generated at 2022-06-12 00:08:30.286007
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    headers = "{'Content-Type': 'application/json', 'Authorization': 'Basic token'}"
    body = "{ 'customer': 'Acme Co', 'department': 'Electronics' }"
    f = Formatting([])
    assert f.format_body(body, mime="application/json") == "{ 'customer': 'Acme Co', 'department': 'Electronics' }"

# Generated at 2022-06-12 00:08:32.454587
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(["color", "format", "format_options"])
    assert fmt.enabled_plugins



# Generated at 2022-06-12 00:08:34.669849
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("text/xml")
    assert converter.name == "XML"

# Correctness test for method format_headers of class Formatting