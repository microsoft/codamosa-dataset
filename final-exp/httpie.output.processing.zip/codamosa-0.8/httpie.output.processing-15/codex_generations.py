

# Generated at 2022-06-11 23:58:44.815608
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(["pretty"]).format_headers("a:b\n") == "  a: b\n"

# Generated at 2022-06-11 23:58:53.281402
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Simplest case
    f = Formatting(groups=['simple'])
    assert f.format_headers(
        'HTTP/1.1 200 OK\r\n'
        'Content-Length: 12\r\n'
        'Content-type: text/html\r\n'
        '\r\n'
    ) == (
        'HTTP/1.1 200 OK\n'
        'Content-Length: 12\n'
        'Content-type: text/html\n'
        '\n'
    )

    # Case with colons inside values
    f = Formatting(groups=['colon'])

# Generated at 2022-06-11 23:59:03.472829
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    e = Environment()
    e.config["colors"]["style"] = "monokai"
    sut = Formatting(groups=["colors"], env=e)
    result = sut.format_body("""{
      "hello": "world"
    }""", "application/json")
    expected = """\x1b[38;2;255;255;255m{
      \x1b[38;2;0;151;25m"hello"\x1b[38;2;255;255;255m: \x1b[38;2;0;255;0m"world"\x1b[38;2;255;255;255m
    }\x1b[0m"""
    assert result == expected, result

# Generated at 2022-06-11 23:59:09.245798
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    with patch('httpie.formatting.ConverterPlugin') as MockConverterPlugin:
        mock_converter_plugin = MockConverterPlugin()
        mock_converter_plugin.supports.return_value = True
        mock_converter_plugin.return_value = 42

        res = Conversion.get_converter('zip/zap')
        assert res == 42
        mock_converter_plugin.assert_called_with("zip/zap")


# Generated at 2022-06-11 23:59:11.670328
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter('application/json')
    assert c.__class__.__name__ == 'JSONConverter'

# Generated at 2022-06-11 23:59:17.559909
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = b"""Content-Length: 124
Content-Type: application/json; charset=utf-8

"""
    headers = Formatting(['colors']).format_headers(headers)
    assert 'Content-Type: application/json; charset=utf-8' in headers
    assert 'Content-Length: 124' in headers
    assert '\n' in headers
    print(headers)



# Generated at 2022-06-11 23:59:20.875009
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/x-yaml')
    assert type(converter) is ConverterPlugin
    assert converter.mime_type == 'application/x-yaml'



# Generated at 2022-06-11 23:59:23.271434
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("json"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("json"), json.JsonConverter)


# Generated at 2022-06-11 23:59:29.652536
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class FakePlugin(object):
        def __init__(self):
            pass
        def format_body(self, content, mime):
            return content + '_formatted'
    content = '{"a":1, "b":2}'
    p = Formatting(['json'], FakePlugin())

    assert p.format_body(content, 'application/json') == content+'_formatted'

# Generated at 2022-06-11 23:59:41.228329
# Unit test for constructor of class Formatting
def test_Formatting():
    source = 'Content-Type: application/json\r\n' \
             'x-timestamp: 1453677842\r\n' \
             'x-request-id: 27490da6-3abd-45f6-a0a8-b6dc7b9dd9d6\r\n' \
             'Content-Length: 2\r\n' \
             'Via: 1.1 vegur\r\n' \
             'Connection: keep-alive\r\n'
    res = Formatting(["headers"]).format_headers(source)

# Generated at 2022-06-11 23:59:47.569723
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'



# Generated at 2022-06-11 23:59:58.167068
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:00:09.949299
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:00:12.924645
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/x-www-form-urlencoded')
    assert converter is not None

    converter = Conversion.get_converter('application/x-www-form-urlencoded-')
    assert converter is None


# Generated at 2022-06-12 00:00:14.939369
# Unit test for constructor of class Formatting
def test_Formatting():
    """Test for constructor of class Formatting"""
    f = Formatting(["pretty"])
    assert f.enabled_plugins[0].enabled

# Generated at 2022-06-12 00:00:17.982371
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting([], Environment()).enabled_plugins == []
    assert isinstance(Formatting([], Environment()), Formatting)
    assert Formatting(["json"], Environment()).enabled_plugins[0].__class__.__name__ == "JSONPrettyPipe"


# Generated at 2022-06-12 00:00:23.757969
# Unit test for constructor of class Formatting
def test_Formatting():
    class StubFormatting:
        def __init__(self, **kwargs):
            pass
        def enabled(self):
            return True

    class DummyPluginManager:
        def get_formatters_grouped():
            groups = {'foo': [StubFormatting]}
            return groups

    plugin_manager.instance = DummyPluginManager()
    f = Formatting(['foo'])
    assert len(f.enabled_plugins) == 1

# Generated at 2022-06-12 00:00:25.942873
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter("text/csv")
    assert c.mime == "text/csv"


# Generated at 2022-06-12 00:00:37.305507
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONPrettyPrint
    # Test for plugins
    groups = ['sub-group-1', 'sub-group-2']
    new_fmt = Formatting(groups, is_windows=False)
    assert new_fmt.enabled_plugins is not None
    assert len(new_fmt.enabled_plugins) == 2
    assert isinstance(new_fmt.enabled_plugins[0], FormatterPlugin)
    # Test for keyword args
    new_fmt = Formatting(groups, test="kwarg", is_windows=False)
    assert new_fmt.enabled_plugins[0].test == "kwarg"
    # Test for builtin plugins

# Generated at 2022-06-12 00:00:43.347095
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Create the Formatting object
    formatting = Formatting(["highlighting"], style="solarized")

    # Create a dict with a key with a colon in its name
    headers = {
        ":status": "200",
        "content-type": "text/html",
        "host": "localhost:8090"
    }

    # Assert that the format_headers method returns the value of the key :status
    # as key Status
    assert formatting.format_headers(headers) == {"Status": "200", "content-type": "text/html", "host": "localhost:8090"}

# Generated at 2022-06-12 00:00:47.426373
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    fmt = Formatting(['colors'], env)

# Generated at 2022-06-12 00:00:53.023666
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert Conversion.get_converter('text/html')
    assert not Conversion.get_converter('text/plain')
    assert not Conversion.get_converter('text/html/plain')



# Generated at 2022-06-12 00:00:59.657997
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter is not None
    assert converter.__class__.__name__ == "JSONConverter"

    converter = Conversion.get_converter("text/xml")
    assert converter is not None
    assert converter.__class__.__name__ == "XMLConverter"

    converter = Conversion.get_converter("text/html")
    assert converter is None


# Generated at 2022-06-12 00:01:02.852459
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert converter.__class__.__name__ == 'HTMLConverter'


# Unit tests for method format_body of class Formatting

# Generated at 2022-06-12 00:01:08.152012
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''
Host: example.com
Accept: application/json
'''
    formatting = Formatting(['NETRC'])
    assert formatting.format_headers(headers) == headers

    formatting.enabled_plugins[0].enabled = False
    assert formatting.format_headers(headers) == headers

    formatting.enabled_plugins[0].enabled = True
    formatting.enabled_plugins[0].is_netrc_available = False
    assert formatting.format_headers(headers) == headers

# Generated at 2022-06-12 00:01:12.173272
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert(Conversion.get_converter("application/json").mime == "application/json")
    assert(Conversion.get_converter("application/json") is not None)
    assert(Conversion.get_converter("toto/titi") is None)

# Generated at 2022-06-12 00:01:16.680775
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '{"test":1}'
    mime = 'application/json'
    f = Formatting(['colors'])
    assert f.format_body(content, mime) == '{\x1b[92m"test"\x1b[39m: 1\x1b[39m}'
# End of unit test for method format_body of class Formatting

# Generated at 2022-06-12 00:01:19.528796
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("text/json")
    assert Conversion.get_converter("application/json")
    assert Conversion.get_converter("text/xml")

# Generated at 2022-06-12 00:01:21.585989
# Unit test for constructor of class Formatting
def test_Formatting():
    assert(plugin_manager.get_formatters()[0]().enabled)

# Generated at 2022-06-12 00:01:31.295125
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors'], verbose=True,
        headers=True, body=True,
        disable_colors=True)
    assert len(fmt.enabled_plugins) == 1
    assert fmt.enabled_plugins[0].__class__.__name__ == "ColorsFormatter"
    assert fmt.enabled_plugins[0].verbose == True
    assert fmt.enabled_plugins[0].headers == True
    assert fmt.enabled_plugins[0].body == True
    assert fmt.enabled_plugins[0].disable_colors == True
    assert fmt.enabled_plugins[0].env is not None
    # print(fmt.enabled_plugins[0].env.config)
    # print(fmt.enabled_plugins[0].env.stdout)
    # print(fmt.enabled_plugins[0

# Generated at 2022-06-12 00:01:43.506343
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """
    Test for method format_headers of class Formatting.
    """
    test_headers = '''Connection: keep-alive
    Content-Length: 426
    Content-Type: application/json; charset=utf-8
    Date: Sat, 23 Nov 2019 21:30:48 GMT
    Etag: W/"1a8-CpYryN/qN1gOrsx8wvONfqG3cqg"
    Server: nginx/1.10.3 (Ubuntu)
    Strict-Transport-Security: max-age=15552000; includeSubDomains
    Via: 1.1 vegur
    X-Powered-By: Express'''
    headers = Formatting(groups=['colors'], no_colors=False).format_headers(test_headers)

# Generated at 2022-06-12 00:01:45.165148
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert type(Conversion.get_converter("image/png")) == ImageToBase64Converter

# Generated at 2022-06-12 00:01:48.556677
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    results = Conversion.get_converter(mime)
    assert isinstance(results, ConverterPlugin)
    assert results.mime == mime


# Generated at 2022-06-12 00:01:50.272712
# Unit test for constructor of class Formatting
def test_Formatting():
    myFormatting = Formatting({'headers'})
    assert(myFormatting)



# Generated at 2022-06-12 00:01:57.055180
# Unit test for constructor of class Formatting
def test_Formatting():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--format', action='append', dest='formatter_groups',
        default=[], help='Select formatter for --pretty.'
    )
    args, _ = parser.parse_known_args()
    format_group = ['name', 'bundle', 'format', 'colors']
    formatting = Formatting(args.formatter_groups, **{'format_group': format_group})
    assert args.formatter_groups == ['name', 'bundle', 'format', 'colors']



# Generated at 2022-06-12 00:02:05.868978
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.output.formatters.colors import ColorFormatter
    from httpie.output.formatters.format import Formatter
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.pretty import PrettyFormatter
    from httpie.output.formatters.utils import get_valid_json
    from httpie.plugins import ConverterPlugin

    # test if formatters we want to use are enabled
    assert plugin_manager.get_formatters_grouped()['Auto'] == [ColorFormatter, Formatter, JSONFormatter, PrettyFormatter]
    assert plugin_manager.get_converters() == [ConverterPlugin]

    # test if formatters have the right enabled values
    fsm

# Generated at 2022-06-12 00:02:10.585975
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPiePlugin
    plugin = Formatting(groups=['colors'])
    class TestPlugin(HTTPiePlugin):
        def format_body(self, content: str, mime: str) -> str:
            return content

    assert not plugin.enabled_plugins

# Generated at 2022-06-12 00:02:15.990086
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class Test1:
        def __init__(self):
            pass
        def format_body(self):
            return 1

    class Test2:
        def __init__(self):
            pass
        def format_body(self):
            return 2

    test1 = Test1()

    test = Formatting(False, ["test1", "test2"], env=Environment(), test1=test1, test2=test2)

    content = "42"
    mime = "text/html"

    res = test.format_body(content, mime)
    assert res == 2

# Generated at 2022-06-12 00:02:20.485531
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_mime_list = ["text/html", "text/plain"]
    for each in test_mime_list:
        converter = Conversion.get_converter(each)
        assert converter is not None, "Can't find converter of {}".format(each)

# Generated at 2022-06-12 00:02:22.656325
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(groups=[])
    Formatting(groups=[], env=Environment())
    Formatting(groups=[], env=Environment(), output_options={})

# Generated at 2022-06-12 00:02:29.323786
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatter = Formatting([])
    test_content = "test"
    assert (formatter.format_body(test_content, 'text/plain')) == "test"
    assert (formatter.format_body(test_content, 'text/xml')) == "test"

# Generated at 2022-06-12 00:02:32.538129
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html').__class__.__name__ == 'HTMLConverter'
    assert Conversion.get_converter('text/html').__class__.__name__ != 'JSONConverter'

# Generated at 2022-06-12 00:02:35.908294
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    json_converter = Conversion.get_converter("application/json")
    assert str(json_converter) == "<JSONConverter 'application/json'>"


# Generated at 2022-06-12 00:02:45.473282
# Unit test for constructor of class Formatting
def test_Formatting():
    test_headers = """HTTP/1.1 200 OK
Connection: close
Date: Fri, 27 Mar 2020 11:21:40 GMT
Server: Apache/2.4.6 (CentOS)
X-Powered-By: PHP/5.4.16
Content-Length: 25
Content-Type: text/html; charset=UTF-8
X-Powered-By: PleskLin"""
    test_body = "Hello, world!"
    test_mime = "text/html"
    formatting_1 = Formatting(["HeadersInformationalProcessor"])

# Generated at 2022-06-12 00:02:49.486143
# Unit test for constructor of class Formatting
def test_Formatting():
    print('\n### Unit test for Formatting')
    f = Formatting(groups=['colors'])
    print('Length of enabled plugin: {}'.format(len(f.enabled_plugins)))
    # print('Enabled: {}'.format(f.enabled_plugins))

# Generated at 2022-06-12 00:02:51.201841
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)

# Generated at 2022-06-12 00:02:53.430420
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # MIME type is invalid
    assert Conversion.get_converter("abc") is None

    # MIME type is valid
    assert Conversion.get_converter("text/html") is not None



# Generated at 2022-06-12 00:02:57.322713
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # GIVEN: A mime is given
    mime = 'text/plain'

    # WHEN: Converter is get by the method
    converter = Conversion.get_converter(mime)

    # THEN: The type of converter should be ConverterPlugin
    assert isinstance(converter, ConverterPlugin)


# Generated at 2022-06-12 00:03:01.864905
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin import JSONConverter
    converter = Conversion.get_converter('application/json')
    assert isinstance(converter, JSONConverter) is True
    converter = Conversion.get_converter('application/hal+json')
    assert converter is None



# Generated at 2022-06-12 00:03:09.270487
# Unit test for constructor of class Formatting
def test_Formatting():
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nETag: "v1"; rel="tag"\r\n\r\n'
    formatting = Formatting(groups=['colors'], env=Environment(), style='automatic')
    print(formatting.format_headers(headers))

    content = '{"name": "python"}'
    mime = 'application/json'
    print(formatting.format_body(content, mime))

    if __name__ == '__main__':
        test_Formatting()

# Generated at 2022-06-12 00:03:20.759408
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONStreamFormatter
    print('Test for method format_body of class Formatting')
    f = Formatting(['pretty'], colors=False)
    json_plugin = JSONStreamFormatter(
        colors=False,
        indent=2,
        sort_keys=False,
        show_stream=False,
    )
    f.enabled_plugins.append(json_plugin)
    assert f.format_body('[{"a": "b"}]', 'application/json') == \
            '[\n  {\n    "a": "b"\n  }\n]'
    assert f.format_body('["a", 2]', 'application/json') == \
            '[\n  "a",\n  2\n]'



# Generated at 2022-06-12 00:03:22.025288
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # TODO
    pass

# Generated at 2022-06-12 00:03:23.812961
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    x=Formatting(["json"])
    print(x.format_body('{"hello": "world"}', 'application/json'))

# Generated at 2022-06-12 00:03:25.415027
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)

# Generated at 2022-06-12 00:03:32.982356
# Unit test for constructor of class Formatting
def test_Formatting():
    titlecase = Formatting(["titlecase"])
    assert titlecase.format_headers("header-name: header") == "Header-Name: header\n"
    assert titlecase.format_body("Some description", "text/plain") == "\nSome description\n"

    # Case of no processor plugins
    no_processor = Formatting([])
    assert no_processor.format_headers("header-name: header") == "header-name: header\n"
    assert no_processor.format_body("Some description", "text/plain") == "\nSome description\n"

# Generated at 2022-06-12 00:03:37.436007
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Arrange
    groups = ['colors']
    env = Environment()
    # Act
    formatter = Formatting(groups, env)
    content = '{"foo":"bar"}'
    mime = 'application/json'
    result = formatter.format_body(content, mime)
    # Assert
    assert result is not None or ''

# Generated at 2022-06-12 00:03:48.139579
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    groups = ['colors']
    enabled_plugins = []
    for group in groups:
        for cls in available_plugins[group]:
            p = cls()
            if p.enabled:
                enabled_plugins.append(p)
    for p in enabled_plugins:
        print(p.format_headers("HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: 2\r\nETag: W/\"2-Go6bWXA8Wxk9X9QQ+kqCl3qQHn0\"\r\nDate: Thu, 11 Jul 2019 03:24:27 GMT\r\n"))

test_Formatting_format_headers()

# Generated at 2022-06-12 00:03:54.171895
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class formatter:
        def __init__(self, **kwargs):
            pass
        def format_body(self, content: str, mime: str) -> str:
            return f"{content}, {mime}"
    plugins = {
        'json': [formatter]
    }
    mock_manager = Mock(get_formatters_grouped=Mock(return_value=plugins))
    # patch plugin_manager
    with patch('httpie.formatter.plugin_manager', mock_manager):
        fmt = Formatting(groups=['json'])
        ret_value = fmt.format_body(content='test', mime='application/json')
        assert ret_value == 'test, application/json'

# Generated at 2022-06-12 00:03:56.895661
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    ConverterPlugin.mime_synonym['json'] = 'application/json'
    converter = Conversion.get_converter('json')
    assert converter
    assert converter.mime == 'application/json'

# Generated at 2022-06-12 00:03:57.858271
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter(None)

# Generated at 2022-06-12 00:04:02.451994
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = "Content-Type: application/json"
    output = Formatting(groups=['body']).format_headers(headers)
    assert headers == output


# Generated at 2022-06-12 00:04:10.577191
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatters = Formatting(groups=['colors'])
    test_dict_headers = {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Length': '17'
    }
    assert formatters.format_headers(test_dict_headers) == '\x1b[90mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[33mcontent-length\x1b[0m: 17\r\n\x1b[33mcontent-type\x1b[0m: application/json; charset=utf-8\r\n'



# Generated at 2022-06-12 00:04:12.656379
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'image/png'
    response = Conversion.get_converter(mime)
    assert response is not None


# Generated at 2022-06-12 00:04:18.006877
# Unit test for constructor of class Formatting
def test_Formatting():
    p = Formatting(["colors"])
    loadedClasses = [x.__class__ for x in p.enabled_plugins]
    if ColorFormatter not in loadedClasses:
        raise AssertionError("Плагин 'ColorFormatter' загрузился в переменную 'formatters'.")

# Generated at 2022-06-12 00:04:24.933805
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fh = Formatting(["headers"])
    headers = """User-Agent: (PyHTTPie/0.9.2)
Accept-Encoding: gzip, deflate, compress
Host: httpbin.org
Accept: */*
Content-Length: 6
Connection: keep-alive
Cache-Control: no-cache"""
    headers = fh.format_headers(headers)
    assert headers == """User-Agent: (PyHTTPie/0.9.2)
Accept-Encoding: gzip, deflate, compress
Host: httpbin.org
Accept: */*
Content-Length: 6
Connection: keep-alive
Cache-Control: no-cache"""
    return 0



# Generated at 2022-06-12 00:04:26.169074
# Unit test for constructor of class Formatting
def test_Formatting():
    a = Formatting(['colors', 'format'])



# Generated at 2022-06-12 00:04:29.276190
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert converter.get_annotator('html') == '<span class="annotation annotation-danger">$1</span>'



# Generated at 2022-06-12 00:04:34.304855
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    assert Formatting(['ok'], env).enabled_plugins == []
    assert Formatting(['ok', 'colors'], env).enabled_plugins == [
        plugin_manager.get_group('colors')[0](env=env)
    ]
    assert Formatting([], env).enabled_plugins == []

# Generated at 2022-06-12 00:04:40.028030
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formattor = Formatting(['colors'], env=Environment(colors=True))
    origin_headers = '''Content-Type: application/json
Date: Thu, 17 Oct 2019 01:48:47 GMT
Server: WSGIServer/0.2 CPython/3.6.8
X-Frame-Options: SAMEORIGIN
Content-Length: 49

'''
    assert formattor.format_headers(origin_headers) != origin_headers


# Generated at 2022-06-12 00:04:51.784902
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import httpie.formatters.default
    from httpie.context import Environment

    available_plugins = plugin_manager.get_formatters_grouped()
    group = "headers"
    for cls in available_plugins[group]:
        p = cls(env=Environment())
        if p.enabled:
            httpie.formatters.default.Formatting.enabled_plugins.append(p)

# Generated at 2022-06-12 00:05:05.502791
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    json_converter = Conversion.get_converter('application/json')
    assert json_converter.__class__.__name__ == "JsonConverter"
    #assert json_converter.supports_mime == "application/json"
    assert json_converter.target_mime == "application/json"
    assert json_converter.mimes == ("application/json", "application/hal+json")
    csv_converter = Conversion.get_converter('text/csv')
    assert csv_converter.__class__.__name__ == "CsvConverter"
    #assert csv_converter.supports_mime == "text/csv"
    assert csv_converter.target_mime == "text/csv"
    assert c

# Generated at 2022-06-12 00:05:15.975244
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins import FormatterPlugin, FormatterDict
    from httpie.plugins.registry import plugin_manager

    class TestFormatter(FormatterPlugin):
        enabled = True
        name = "f"
        info = "TestFormatter"
        formatters_dict = FormatterDict(name=name)
        media_type = None

        def get_body_format_handler(self, mime):
            return None

        def format_body(self, body, mime):
            return body

        def get_headers_format_handler(self):
            return None

        def format_headers(self, headers):
            return headers

    class TestFormatter2(FormatterPlugin):
        enabled = True
        name = "f2"
        info = "TestFormatter2"
        formatters_dict = FormatterD

# Generated at 2022-06-12 00:05:21.849805
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').__class__.__name__ == "JSON"
    assert Conversion.get_converter('text/html').__class__.__name__ == "HTML"
    assert Conversion.get_converter('text/xml').__class__.__name__ == "XML"
    assert Conversion.get_converter('application/vnd.api+json').__class__.__name__ == "JSON"
    assert Conversion.get_converter('application/vnd.api+xml').__class__.__name__ == "XML"
    assert not Conversion.get_converter('image/jpeg')


# Generated at 2022-06-12 00:05:28.869584
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    test_formatting = Formatting(groups, env=Environment(), **{
        'style': 'solarized',
        'colors': {'body': {'bg': 'red'}},
        'colors.light': False
    })

    # Test all enabled plugins is a list
    assert type(test_formatting.enabled_plugins) is list

    # Test all enabled plugins is not empty
    assert len(test_formatting.enabled_plugins) != 0

# Generated at 2022-06-12 00:05:37.714495
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class EchoFormatting(Formatting):
        def __init__(self, groups: List[str], env=Environment(), **kwargs):
            available_plugins = plugin_manager.get_formatters_grouped()
            self.enabled_plugins = []
            for group in groups:
                for cls in available_plugins[group]:
                    print(cls)
                    p = cls(env=env, **kwargs)
                    print(p, p.enabled)
                    if p.enabled:
                        self.enabled_plugins.append(p)


# Generated at 2022-06-12 00:05:42.427865
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    #Test case1: when input is wrong
    assert Conversion.get_converter('wrong_format') == None

    #Test case2: when input is json
    assert Conversion.get_converter('application/json').supports('application/json')

    #Test case3: when input is xml
    assert Conversion.get_converter('application/xml').supports('application/xml')


# Generated at 2022-06-12 00:05:43.337505
# Unit test for constructor of class Formatting
def test_Formatting():
    p1 = Formatting("")

# Generated at 2022-06-12 00:05:52.922814
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie import ExitStatus
    from httpie.output.formatters.colors import Formatter

    env = Environment()
    env.colors = 256
    from httpie.plugins.builtin.colors import ColoredFormatter
    from httpie.plugins.builtin.format import PlainFormatter
    from httpie.plugins.builtin.format import JSONFormatter

    output_format_list=["json", "colors"]
    groups = [output_format_list]
    formatting_obj = Formatting(groups=groups, env=env)
    formatted_body = formatting_obj.format_body([{"a": "1", "b": "2"}, {"a": "1", "b": "2"}], "application/json")
    print("formatted_body", formatted_body)

# Generated at 2022-06-12 00:06:01.328366
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in ['parse_json', 'format_json']:
        for cls in available_plugins[group]:
            p = cls(env=Environment())
            if p.enabled:
                enabled_plugins.append(p)
    content = '{"accounts":[{"balance":25400,"id":1},{"balance":0,"id":2}]}'
    mime = 'application/json'
    for p in enabled_plugins:
        content = p.format_body(content, mime)

# Generated at 2022-06-12 00:06:04.943216
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    test_case1 = Formatting(groups, env )
    assert type(test_case1) == Formatting
    assert test_case1.enabled_plugins[0].bg == 'black'

# Generated at 2022-06-12 00:06:15.676911
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(groups=['json'], env=Environment())
    assert fmt # fmt is not None



# Generated at 2022-06-12 00:06:18.642915
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors'])
    #fmt.format_headers()
    #fmt.format_body() 

if __name__ == "__main__":
    test_Formatting()

# Generated at 2022-06-12 00:06:21.023557
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)

# Generated at 2022-06-12 00:06:26.776788
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    formatter = Formatting(['colors'], env=env)
    assert len(formatter.enabled_plugins) == 1
    assert formatter.enabled_plugins[0].name == 'Colorized'
    formatter = Formatting(['colors', 'formatters'], env=env)
    assert len(formatter.enabled_plugins) == 2

# Generated at 2022-06-12 00:06:35.527513
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    fmt = Formatting(groups=['colors'])
    body = fmt.format_body('{"a":"b"}', 'application/json')
    exp = '\x1b[1;37m{\x1b[0m\x1b[1;32m\n    \x1b[0m\x1b[1;32m"a"\x1b[0m\x1b[1;33m:\x1b[0m\x1b[0;32m "b"\x1b[0m\x1b[1;32m\n\x1b[0m\x1b[1;37m}\x1b[0m'
    assert body == exp


# Generated at 2022-06-12 00:06:42.239402
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.colors import PygmentsColorsFormatter
    head = HeadersFormatter()
    colorH = PygmentsColorsFormatter()
    colorB = PygmentsColorsFormatter()
    enabled_plugins = [head, colorH, colorB]
    assert available_plugins == {'headers':[HeadersFormatter], 'colors':[PygmentsColorsFormatter]}
    fmt = Formatting(['headers', 'colors'])
    assert fmt.enabled_plugins == enabled_plugins


# Generated at 2022-06-12 00:06:51.906438
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONPathFormatting
    from httpie.plugins.builtin import JSONFormatting
    from httpie.plugins.builtin import XMLFormatting

    json_body = "{\"name\": \"John\", \"surname\": \"Smith\"}"
    xml_body = "<person><name>John</name><surname>Smith</surname></person>"

    # Try to format JSON body
    fmt = Formatting(groups=['json'])
    assert fmt.format_body(json_body, 'application/json') == json.dumps(json.loads(json_body), indent=2)

    # Try to format XML body
    fmt = Formatting(groups=['xml'])

# Generated at 2022-06-12 00:06:53.115792
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("text/plain"), ConverterPlugin)

# Generated at 2022-06-12 00:06:57.039158
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    tmp = []
    for converter_class in plugin_manager.get_converters():
        tmp.append(converter_class.mime_types[0])
    for i in tmp:
        assert is_valid_mime(i) == True
        assert Conversion.get_converter(i) is not None

# Generated at 2022-06-12 00:07:05.287992
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # initialization
    env = Environment()
    env.config['colors'] = False
    env.config['style'] = 'solarized'
    groups = ['headers']
    kwargs = {
        'headers': 'HTTP/2 200\r\nConnection: close\r\nContent-Length: 5\r\n\r\n'
    }

    # execution
    fm = Formatting(groups=groups, env=env, **kwargs)
    headers = fm.format_headers(kwargs['headers'])

    # verification
    assert (
        headers ==
        'HTTP/2 200\r\nConnection: close\r\nContent-Length: 5\r\n\r\n'
    )



# Generated at 2022-06-12 00:07:17.065294
# Unit test for constructor of class Formatting
def test_Formatting():
    # Arrange
    groups = ['colors', 'format', 'syntax']
    env = Environment()
    kwargs = {}

    # Act
    formatting = Formatting(groups, env, kwargs)

    # Assert
    assert formatting != None


# Generated at 2022-06-12 00:07:25.609694
# Unit test for constructor of class Formatting
def test_Formatting():
    # singleton class
    try:
        Formatting()
    except TypeError:
        pass

    # available_plugins -> enabled plugins
    enabled_plugins = Formatting(["HTTPieFormatter"], env=Environment()).enabled_plugins
    print(enabled_plugins)
    print(type(enabled_plugins[0]))
    assert type(enabled_plugins[0]) is plugin_manager.get_formatters_grouped()['HTTPieFormatter'][0]
    assert enabled_plugins[0].__class__ is plugin_manager.get_formatters_grouped()['HTTPieFormatter'][0]



# Generated at 2022-06-12 00:07:31.091722
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    conversion_plugins = []
    for group in available_plugins:
        for cls in available_plugins[group]:
            p = cls(env=Environment(), **{})
            if p.enabled:
                conversion_plugins.append(p)
    groups = ["json"]
    formatting = Formatting(groups)
    assert conversion_plugins == formatting.enabled_plugins

# Generated at 2022-06-12 00:07:40.456714
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env = Environment()
    my_formatting = Formatting(groups, env)
    # Simple test, no coloration
    assert my_formatting.format_body('test', 'text/plain').strip() == 'test'
    # 'default' coloration
    assert my_formatting.format_body('test', 'application/json').strip() == '\x1b[94m"test"\x1b[0m'
    # 'linux' coloration
    env.colors = 'linux'
    my_formatting = Formatting(groups, env)
    assert my_formatting.format_body('test', 'application/json').strip() == '\x1b[0;36m"test"\x1b[0m'

# Generated at 2022-06-12 00:07:42.055400
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].break_before == 1

# Generated at 2022-06-12 00:07:53.043174
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class MockFormatter(object):
        def __init__(self, **_):
            pass
        @staticmethod
        def enabled():
            return True
        @staticmethod
        def format_headers(headers):
            return headers.upper()
        @staticmethod
        def format_body(body, mime):
            return body
    mock_formatters_grouped = {'formatters': [MockFormatter], 'colors': []}
    mock_mock_plugin_manager = type('MockPluginManager', (object,), {
        'get_formatters_grouped': lambda : mock_formatters_grouped,
    })
    def mock_get_plugin_manager():
        return mock_mock_plugin_manager

# Generated at 2022-06-12 00:07:57.952766
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    expected_output = """\
{
    "content": "some content",
    "headers": {
        "Content-Type": "text/plain"
    }
}\
"""
    input_headers = """\
{
    "content": "some content",
    "headers": {
        "Content-Type": "text/plain"
    }
}\
"""
    headers = Formatting('json').format_headers(input_headers)
    assert headers == expected_output

# Generated at 2022-06-12 00:08:08.272703
# Unit test for method format_body of class Formatting

# Generated at 2022-06-12 00:08:14.004922
# Unit test for constructor of class Formatting
def test_Formatting():
    import pytest
    from httpie.plugins.builtin import HTTPHeadersProcessor, HTTPBodyProcessor
    f = Formatting(groups=['headers', 'body'])
    assert len(f.enabled_plugins) == 2
    assert isinstance(f.enabled_plugins[0], HTTPHeadersProcessor) # first plugin is HTTPHeaderProcessor
    assert isinstance(f.enabled_plugins[1], HTTPBodyProcessor)
    

# Generated at 2022-06-12 00:08:16.222400
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('no/mime')
