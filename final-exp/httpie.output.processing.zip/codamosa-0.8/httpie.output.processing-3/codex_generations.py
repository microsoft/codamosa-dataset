

# Generated at 2022-06-11 23:58:51.610700
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from unittest.mock import patch
    from httpie.plugins import FormatterPlugin
    from httpie.context import Environment
    from httpie import ExitStatus
    # Test Enabled
    class PluginTestHeaderFormatter(FormatterPlugin):
        enabled = True
        def format_headers(self, headers: str) -> str:
            return 'headers_formatted_enabled'

    # Test Not Enabled
    class PluginTestHeaderFormatter2(FormatterPlugin):
        enabled = False
        def format_headers(self, headers: str) -> str:
            return 'headers_formatted_not_enabled'


# Generated at 2022-06-11 23:58:56.054119
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    class_ = Conversion.get_converter
    assert class_('application/json').name() == 'JSON'
    assert class_('application/x-www-form-urlencoded').name() == 'Forms'
    assert class_('') is None
    assert class_('text') is None

# Generated at 2022-06-11 23:59:05.149306
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.request_headers = {'Content-Type': 'application/json', 'Accept': '*/*'}
    env.pretty = True
    f = Formatting(['colors'], env=env, colors=True)

    assert f.format_body('{"test": "body"}', 'application/json') == '{\n    "test": "body"\n}'

    assert f.format_headers('HTTP/1.1 200 OK\nServer: nginx/1.4.4') == '\x1b[32mHTTP/1.1 200 OK\x1b[39m\nServer: nginx/1.4.4'

# Generated at 2022-06-11 23:59:08.033448
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("text/html")
    assert(isinstance(converter, ConverterPlugin))

# Generated at 2022-06-11 23:59:14.807205
# Unit test for constructor of class Formatting
def test_Formatting():
    class env:
        def __init__(self):
            self.color = True
    available_plugins = plugin_manager.get_formatters_grouped()
    
    groups = ['color', 'colors', 'verbose']
    test = env()
    assert Formatting(groups, test).enabled_plugins == [available_plugins['color'][0], available_plugins['colors'][0], available_plugins['verbose'][0]]

# Generated at 2022-06-11 23:59:16.383634
# Unit test for constructor of class Formatting
def test_Formatting():
    groups=["colors"]
    Formatting(groups=groups)

# Generated at 2022-06-11 23:59:18.482724
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """Test that it returns None if converter is not found"""
    assert Conversion.get_converter("text/html") is None



# Generated at 2022-06-11 23:59:21.487052
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Valid MIME type
    result = Conversion.get_converter("application/json")
    assert result is not None

    # Invalid MIME type
    result = Conversion.get_converter("json")
    assert result is None


# Generated at 2022-06-11 23:59:31.578979
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json

    data = {
        "access_token": "slZiLl7V5vBw5j5V5IyiziUf0Fv6Au0I",
        "token_type": "Bearer",
        "expires_in": "3600",
        "scope": "li_basicprofile li_fullprofile li_emailaddress",
        "refresh_token": "Gxrq3BtTJm33fo46zt0ZRBo57ZTSlsYQ"
    }
    stringy_json = json.dumps(data)
    print(stringy_json)
    f = Formatting(["headers", "colors"])
    result = f.format_body(stringy_json, "application/json")
    print(result)



# Generated at 2022-06-11 23:59:39.260090
# Unit test for constructor of class Formatting
def test_Formatting():
    """The constructor of Formatting class"""
    f = Formatting(None)
    assert f.enabled_plugins == []
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].get_type() == "colors"
    f = Formatting(['colors', 'format'])
    assert f.enabled_plugins[0].get_type() == "colors"
    assert f.enabled_plugins[1].get_type() == "format"


# Generated at 2022-06-11 23:59:47.630504
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Initializing
    format_list = ['colors']
    groups = Formatting(format_list)
    headers = 'test:test'
    # Executing
    output = groups.format_headers(headers)
    # Testing
    assert output == '\x1b[37mtest\x1b[39m: \x1b[90mtest\x1b[39m'



# Generated at 2022-06-11 23:59:50.238679
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    available_plugins = plugin_manager.get_formatters_grouped()
    formatted = Formatting(['Colors'])
    for group in available_plugins:
        for cls in available_plugins[group]:
            p = cls(env=env, **{})
            if p.enabled:
                assert p in formatted.enabled_plugins


# Generated at 2022-06-11 23:59:51.725405
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("test/test") == None



# Generated at 2022-06-11 23:59:59.570454
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = (
        b'Content-Type: application/json\r\n'
        b'X-Custom-Header: foo\r\n'
        b'X-Custom-Header: bar\r\n'
    )

    fmt = Formatting(['colors'])
    formatted = fmt.format_headers(headers)

    assert formatted == (
        b'Content-Type: ~Gapplication/json~\n'
        b'X-Custom-Header: ~Gfoo~\n'
        b'X-Custom-Header: ~Gbar~\n'
    )



# Generated at 2022-06-12 00:00:11.278572
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    responseHeaders = '''HTTP/1.1 200 OK
Server: nginx
Date: Mon, 19 Nov 2018 11:45:11 GMT
Content-Type: application/json;charset=utf-8
Content-Length: 7
Connection: keep-alive
Vary: Cookie
X-Powered-By: Express
Access-Control-Allow-Origin: *
Etag: W/"7-qKs7oGdgNOtIhK4/x4y2fYFc47E"
Via: 1.1 vegur
'''


# Generated at 2022-06-12 00:00:19.649708
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    t_input = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>'''
    print('Testing method format_headers of class Formatting...')
    f = Formatting(['colors'])
    t_output = f.format_headers(t_input)
    print('Initial input:')
    print(t_input)
    print('Final output:')
    print(t_output)
    print("Testing of method format_headers completed.")

#

# Generated at 2022-06-12 00:00:24.656380
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(groups=['colors'], env=env, encode_charmap={'00': '0'})
    assert f.enabled_plugins[0].name == 'colors'
    assert f.enabled_plugins[0].env == env
    assert f.enabled_plugins[0].charmap == {'00': '0'}

# Generated at 2022-06-12 00:00:27.724385
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=['simple'])
    assert f.format_headers('spam,eggs;chips=bacon') == 'spam: eggs: chips=bacon'



# Generated at 2022-06-12 00:00:29.478106
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting()
    assert f.format_body("Hello", "text/html") == "Hello"

# Generated at 2022-06-12 00:00:37.646017
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_cases = [
        ("application/json", ConverterPlugin),

        ("image/jpeg", None),  # Not supported
        ("image/png", None),   # Not supported
        ("sample/text", None),
        ("", None),
        ("/", None),
        ("/json", None),
        ("json/", None),
    ]

    for tc in test_cases:
        assert Conversion.get_converter(tc[0]).__class__.__name__ == tc[1].__name__



# Generated at 2022-06-12 00:00:43.055223
# Unit test for constructor of class Formatting
def test_Formatting():
    # Given
    groups = ['str_formatter', 'json_formatter']
    # When
    formatting = Formatting(groups)
    # Then
    assert len(formatting.enabled_plugins) == 2


# Generated at 2022-06-12 00:00:49.629310
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.converter.json import JSONConverter
    from httpie.plugins.converter.image import ImageConverter

    assert isinstance(Conversion.get_converter('image/gif'), ImageConverter)
    assert not Conversion.get_converter('dummy/fake')
    assert isinstance(Conversion.get_converter('application/json'), JSONConverter)



# Generated at 2022-06-12 00:00:56.090757
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    expected = [None, 'text/html', 'text/html', None]
    test_list = ['', 'html', 'text/html', 'text']
    i = 0
    while i < len(test_list):
        result = Conversion.get_converter(test_list[i])
        i = i + 1
        assert result == expected[i]

# Generated at 2022-06-12 00:01:00.601812
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    result = is_valid_mime("application/pdf")
    assert result == True

    result = is_valid_mime("application")
    assert result == False

    result = is_valid_mime("application/")
    assert result == False

    result = Conversion.get_converter("application/pdf")
    assert result.__class__.__name__ == "PdfHtmlConverter"


# Generated at 2022-06-12 00:01:08.151730
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_header = ['GET http://httpbin.org/ HTTP/1.1',
                   'Accept-Encoding: gzip, deflate',
                   'Accept: */*',
                   'User-Agent: HTTPie/0.9.9']
    expected_header = ['GET / HTTP/1.1',
                       'Accept-Encoding: gzip, deflate',
                       'Accept: */*',
                       'User-Agent: HTTPie/0.9.9']
    formatter = Formatting(env=Environment(), groups=['HTTPie'])
    assert(formatter.format_headers(test_header) == expected_header)


# Generated at 2022-06-12 00:01:10.184464
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    ret = Conversion.get_converter("application/json")
    assert ret is not None


# Generated at 2022-06-12 00:01:12.828958
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('mime')
    assert converter is not None
    converter = Conversion.get_converter('a/b')
    assert converter is not None

# Generated at 2022-06-12 00:01:18.636374
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    case_1 = {"groups": ["colors"], "env": env}
    case_2 = {"groups": ["colors", "format"], "env": env}
    case_3 = {"groups": ["colors", "format", "prettify"], "env": env}
    cases = [case_1, case_2, case_3]
    for c in cases:
        f = Formatting(**c)
        content = f.format_body("<h1>Hello World</h1>", "text/html")
        assert isinstance(content, str)

# Generated at 2022-06-12 00:01:29.154412
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    body_json = '{"key": "value"}'
    body_xml = '<xml>value</xml>'
    body_txt = 'test value'
    body_html = '<html><head><title>Test</title></head><body><p>Test</p></body></html>'

    # Test for json
    formatter = Formatting('format')
    body = formatter.format_body(body_json, 'application/json')
    assert body == '{\n    "key": "value"\n}'

    # Test for xml
    formatter = Formatting('format')
    body = formatter.format_body(body_xml, 'application/xml')
    assert body == '<xml>value</xml>'

    # Test for html
    formatter = Formatting('format')

# Generated at 2022-06-12 00:01:33.067751
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'formatting']
    env = Environment()
    kwargs = {'colors': 'none'}
    formatter = Formatting(groups, env, **kwargs)

    print(f'formatter.enabled_plugins: {formatter.enabled_plugins}')



# Generated at 2022-06-12 00:01:41.844086
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print("------ Unit test for method format_headers of class Formatting ------")
    data = Formatting(groups=['colors']).format_headers('Content-Type: application/json\nContent-Length: 10\nConnection: close')
    print(data)
    #  ------ Unit test for method format_headers of class Formatting ------
    #  HTTP/1.1 200 OK
    #  Content-Type: application/json
    #  Content-Length: 10
    #  Connection: close


# Generated at 2022-06-12 00:01:52.044440
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    inp = '''HTTP/1.1 200 OK
    Connection: keep-alive
    Content-Encoding: gzip
    Content-Type: text/html; charset=utf-8
    Transfer-Encoding: chunked
    Date: Wed, 13 Aug 2014 20:32:08 GMT
    Server: Apache'''
    out = '''HTTP/1.1 200 OK
 >>> Connection: keep-alive
 >>> Content-Encoding: gzip
 >>> Content-Type: text/html; charset=utf-8
 >>> Transfer-Encoding: chunked
 >>> Date: Wed, 13 Aug 2014 20:32:08 GMT
 >>> Server: Apache'''

# Generated at 2022-06-12 00:01:54.828868
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTMLFormatter
    available_plugins = plugin_manager.get_formatters_grouped()
    for group in available_plugins:
        for cls in available_plugins[group]:
            Formatting(groups=[group])

# Generated at 2022-06-12 00:01:56.877559
# Unit test for constructor of class Formatting
def test_Formatting():
    environment = Environment()
    formatting = Formatting(["url", "body", "headers"], env=environment)
    assert formatting.enabled_plugins == []

# Generated at 2022-06-12 00:01:59.336742
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format', 'syntax']
    f = Formatting(groups)
    assert f.enabled_plugins == []

# Generated at 2022-06-12 00:02:06.807871
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # get_converter() will return None if it does not support the selected
    # MIME
    assert(Conversion.get_converter('application/json') is None)
    assert(Conversion.get_converter('application/wk') is None)
    # get_converter() will return the converter class if it supports the
    # selected MIME
    assert(Conversion.get_converter('application/vnd.api+json') is not None)
    assert(Conversion.get_converter('application/hal+json') is not None)
    assert(Conversion.get_converter('application/vnd.siren+json') is not None)
    assert(Conversion.get_converter('application/vnd.collection+json') is not None)

# Generated at 2022-06-12 00:02:10.292502
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    print(env.__dict__)
    f = Formatting(groups=['format'], env=env)
    print(f.__dict__)


# Generated at 2022-06-12 00:02:16.872887
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("") == None, "Invalid MIME type"
    assert Conversion.get_converter("/") == None, "Invalid MIME type"
    assert Conversion.get_converter("a/b") == None, "Invalid MIME type"
    assert Conversion.get_converter("a/b/c") == None, "Invalid MIME type"
    assert Conversion.get_converter("application/json") != None, "Valid MIME type"
    assert Conversion.get_converter("application/json") == Conversion.get_converter("application/json"), "Equivalent calls"
    assert Conversion.get_converter("application/json") != Conversion.get_converter("application/xml"), "Equivalent calls"
    assert Conversion.get_converter("application/json") != Conversion

# Generated at 2022-06-12 00:02:19.406269
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.media_type == 'application/json'


# Generated at 2022-06-12 00:02:27.736158
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test empty contents
    assert Formatting(groups=['formatters']).format_body(content='', mime='text/plain') == ''

    # Test wrong mime type
    assert Formatting(groups=['formatters']).format_body(content='something', mime='abc/abc') == 'something'

    # Test correct mime type
    assert Formatting(groups=['formatters']).format_body(content='something', mime='text/plain') == 'something'

# Generated at 2022-06-12 00:02:34.101871
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors'])
    assert fmt.enabled_plugins[0].__class__ in plugin_manager.get_formatters_grouped()['colors']
    fmt = Formatting(['bodies'])
    assert fmt.enabled_plugins[0].__class__ in plugin_manager.get_formatters_grouped()['bodies']


# Generated at 2022-06-12 00:02:44.361931
# Unit test for constructor of class Formatting
def test_Formatting():
    """
    Test whether the formatters are enabled based on the arguments passed
    """
    # Test case 1
    test_obj = Formatting(['pretty'])
    assert len(test_obj.enabled_plugins) == 1
    # Test case 2
    test_obj = Formatting(['pretty', 'colors'])
    assert len(test_obj.enabled_plugins) == 2
    # Test case 3
    test_obj = Formatting(['colors', 'pretty'])
    assert len(test_obj.enabled_plugins) == 2
    # Test case 4
    test_obj = Formatting(['colors'])
    assert len(test_obj.enabled_plugins) == 1
    # Test case 5
    test_obj = Formatting(['pretty', 'nonexistent'])

# Generated at 2022-06-12 00:02:49.546202
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    mime = "application/json"
    content = '{"name":"john","age":25}'
    expected_content = '{\n    "name": "john",\n    "age": 25\n}'

    formatting = Formatting([])
    content = formatting.format_body(content, mime)

    assert content == expected_content



# Generated at 2022-06-12 00:02:53.597498
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.__class__.__name__ == 'JSONConverter'
    assert converter.supports('application/json')
    converter = Conversion.get_converter('application/octet-stream')
    assert converter is None

# Generated at 2022-06-12 00:02:57.877389
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Tests for a proper mime type (i.e. text/plain)
    c = Conversion.get_converter('text/plain')
    assert isinstance(c, ConverterPlugin)
    # Tests for a bad mime type (i.e. plain/text)
    c = Conversion.get_converter('plain/text')
    assert c is None

# Generated at 2022-06-12 00:03:06.808818
# Unit test for constructor of class Formatting
def test_Formatting():
    with open('test.txt', 'r') as f:
        # Read data from file
        data = f.read()
        # Formatting
        fmt = Formatting(['format'], color=False, headers=[])
        fmt.format_headers(data)
        fmt.format_body(data, 'application/json')
        fmt.format_body(data, 'application/xml')
        fmt.format_body(data, 'text/html')
        fmt.format_body(data, 'text/plain')
        fmt.format_body(data, 'text/xml')
        fmt.format_body(data, 'image/jpeg')

# Generated at 2022-06-12 00:03:16.518817
# Unit test for constructor of class Formatting
def test_Formatting():
    class testFormatPlugin1:
        def __init__(self, env, **kwargs):
            self.enabled = True
        def format_body(self, content, mime):
            return ''
    class testFormatPlugin2:
        def __init__(self, env, **kwargs):
            self.enabled = True
        def format_headers(self, content):
            return ''
    available_plugins = {'group1': [testFormatPlugin1], 'group2': [testFormatPlugin2]}
    plugin_manager.get_formatters_grouped = lambda: available_plugins
    f = Formatting(['group1', 'group2'])
    assert len(f.enabled_plugins) == 2

# Generated at 2022-06-12 00:03:23.792437
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class FakeConverterPlugin:
        def __init__(self, env, **kwargs):
            self.env = env
            self.mime = 'application/json'

        def to_html(self, content):
            return '<html>'+content+'</html>'

        def to_json(self, content):
            """helper function to convert json string to dict"""
            return json.loads(content)

    available_plugins = {"json": [FakeConverterPlugin]}
    env = Environment()
    f = Formatting(['json'], env, **{'is_terminal': True})
    f.enabled_plugins = []
    for group in ['json']:
        for cls in available_plugins[group]:
            p = cls(env=env, **{'is_terminal': True})


# Generated at 2022-06-12 00:03:34.395893
# Unit test for constructor of class Formatting
def test_Formatting():
    # init with valid parameter
    data = Formatting(['colors', 'format'])
    assert type(data).__name__ == 'Formatting'

    # test with empty headers
    headers = {
        "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.92 Safari/537.36"
    }
    result = data.format_headers(headers)
    assert result == headers

    # test with empty body
    content = ''
    mime = 'text/html'
    result = data.format_body(content, mime)
    assert type(result).__name__ == 'NoneType'

    # test with invalid mime
    content = ''
    mime = ''
    result

# Generated at 2022-06-12 00:03:41.915422
# Unit test for constructor of class Formatting
def test_Formatting():
    g = Formatting(groups=['colors'])
    str_headers = "HTTP/1.1 200 OK\r\n" \
        "Date: Tue, 26 Aug 2014 01:11:01 GMT\r\n" \
        "Content-Type: text/html; charset=utf-8\r\n" \
        "Content-Length: 24\r\n" \
        "Connection: keep-alive\r\n" \
        "Server: httpie.org\r\n" \
        "Set-Cookie: session=00000000000000000000000000000000; Path=/; HttpOnly\r\n"

# Generated at 2022-06-12 00:03:53.488942
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie import ExitStatus
    from httpie.cli import parser, get_response
    from httpie.output.streams import get_output_stream

    args = parser.parse_args([
        '--headers'
    ])
    args.output_options = parser.get_default_output_options()

    exit_status, output_stream = get_output_stream(args, is_terminal=False)
    output_stream.isatty = lambda: False
    if args.output_options.output_file:
        output_stream.encoding = 'utf8'

    response = get_response(args, output_stream)
    if response is None:
        raise SystemExit(ExitStatus.ERROR)
    f = Formatting(groups=['headers'], env=args.env)

# Generated at 2022-06-12 00:04:02.632029
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    string_test_1 = 'HTTP/1.1 200 OK\n' +\
                    'Content-Type: application/json; charset=UTF-8\n' +\
                    'Content-Length: 3\n' +\
                    'Connection: close\n' +\
                    'Date: Thu, 29 Mar 2018 08:51:02 GMT\n' +\
                    'Server: Apache/2.4.18 (Ubuntu)\n' +\
                    '\n' +\
                    '{1}'

# Generated at 2022-06-12 00:04:04.376903
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').mime == 'application/json'



# Generated at 2022-06-12 00:04:13.629465
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)
    headers = "HTTP/1.1 200 OK\r\n"
    headers += "Date: Mon, 27 Jul 2009 12:28:53 GMT\r\n"
    headers += "Server: Apache/2.2.14 (Win32)\r\n"
    headers += "Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\n"
    headers += "Content-Length: 88\r\n"
    headers += "Content-Type: text/html\r\n"
    headers += "Connection: Closed\r\n"
    headers += "\r\n"
    assert formatting.format_headers(headers) == headers


# Generated at 2022-06-12 00:04:22.841800
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test that the correct plugins are enabled
    from httpie.plugins.builtin import FormatterPlugin

    class TestPlugin(FormatterPlugin):
        enabled = True

    p = TestPlugin()
    f = Formatting(['group1'], env=Environment())
    # Add plugin to group1
    plugin_manager.get_formatters_grouped()['group1'].append(p.__class__)
    assert f.enabled_plugins == [p]
    # Reset plugins to original list
    plugin_manager.get_formatters_grouped()['group1'] = \
        plugin_manager.get_formatters_grouped()['group1'][:-1]

    # Test that no plugins are enabled
    plugin_manager.get_formatters_grouped()['group2'][0].enabled = False

# Generated at 2022-06-12 00:04:26.070173
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    s = Formatting('headers,body', headers=True, body=True)
    data = json.dumps({'name': ['test'], 'test': 0})
    mime = 'application/json'
    print(s.format_body(data, mime))

# Generated at 2022-06-12 00:04:36.759883
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors']
    env = Environment()
    fmt = Formatting(groups, env)
    headers = "HTTP/1.1 200 OK\r\nServer: nginx/1.12.1\r\nDate: Tue, 15 Jan 2019 09:03:43 GMT\r\nContent-Type: text/html; charset=UTF-8\r\nTransfer-Encoding: chunked\r\nConnection: keep-alive\r\nVary: Accept-Encoding\r\nContent-Encoding: gzip"
    formatted_headers = fmt.format_headers(headers)

# Generated at 2022-06-12 00:04:40.099619
# Unit test for constructor of class Formatting
def test_Formatting():
    class MockFormatter:
        def __init__(self, **kwargs):
            self.enabled = True

    plugin_manager.set_formatters([MockFormatter])
    assert Formatting(['all']).enabled_plugins
    assert not Formatting(['none']).enabled_plugins

# Generated at 2022-06-12 00:04:51.977354
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        from httpie.plugins.registry import plugin_manager

        plugin_manager.installed_plugins = []
        plugin_manager.discover()
    except:
        pass

    env = Environment()
    format_value = Formatting(groups=['colors'], env=env,
                              body_style='FORMATTED_PRETTY',
                              headers_style='dim',
                              style='dim',
                              body_bg='dark',
                              body_fg='green',
                              error_bg='red',
                              error_fg='black',
                              error_rule='dim',
                              scheme_fg='cyan')


# Generated at 2022-06-12 00:05:01.396271
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime1 = 'application/json'
    mime2 = 'application/xml'
    assert is_valid_mime(mime1) is True
    assert is_valid_mime(mime2) is True
    converter_class = Conversion.get_converter(mime1)
    converter_class2 = Conversion.get_converter(mime2)
    assert converter_class.__class__.__name__ == 'JSONConverterPlugin'
    assert converter_class2.__class__.__name__ == 'XMLConverterPlugin'
    mime1 = 'foo/bar'
    assert is_valid_mime(mime1) is False
    converter_class = Conversion.get_converter(mime1)
    assert converter_class is None



# Generated at 2022-06-12 00:05:05.420930
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_formatting = Formatting(['colors'])
    test_formatting.format_body('test', 'application/json')
    pass

# Generated at 2022-06-12 00:05:07.447925
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert converter.mime == 'text/html'
    converter = Conversion.get_converter('text/css')
    assert converter is None

# Generated at 2022-06-12 00:05:16.016019
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    Arrange: Create a Formatter object.
    Act: Call method format_body of class Formatting on the object.
    Assert: The returned body is a string with \n newlines.
    """
    formatter = Formatting(["json"])
    body = '{"json": "true"}'
    expected_body = '{\n    "json": "true"\n}'
    assert isinstance(formatter.format_body(body, "application/json"), str)
    assert formatter.format_body(body, "application/json") == expected_body



# Generated at 2022-06-12 00:05:16.927261
# Unit test for constructor of class Formatting
def test_Formatting():
	f = Formatting(['json'])


# Generated at 2022-06-12 00:05:27.046453
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # 1. Create an instance Formatting
    formating = Formatting(groups=["pretty"])
    # 2. Create a string of headers
    headers = '''HTTP/1.1 200 OK
Server: nginx/1.14.0
Date: Mon, 11 Feb 2019 11:50:22 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 122
Connection: keep-alive
Access-Control-Allow-Origin: *
Cache-Control: no-cache
Postman-Token: d7b8d70b-f7b0-432d-b1ad-e2f3a9b989c2
X-Powered-By: Express'''
    # 3. Generate the result

# Generated at 2022-06-12 00:05:29.636204
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/pdf'
    assert is_valid_mime(mime)==True

# Generated at 2022-06-12 00:05:34.857940
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    c = Formatting(['colors'])
    test_input = b'Content-Type: application/json\r\n\r\n'
    test_input = c.format_headers(test_input)
    output = b'Content-Type: \x1b[32mapplication/json\x1b[0m\r\n\r\n'
    assert test_input == output

# Generated at 2022-06-12 00:05:40.318546
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import os
    import tempfile
    from httpie.plugins import FormatterPlugin


    class TempFileFormatter(FormatterPlugin):
        """This processor keeps a copy of the request having its headers
        formatted and saved to the temporary file. By default, the file
        will be removed when the processor is deleted.
        """

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.tempf = tempfile.NamedTemporaryFile(delete=False)

        def format_headers(self, headers: str) -> str:
            self.tempf.write(headers.encode())
            self.tempf.close()
            return headers

        def disable(self):
            super().disable()
            os.unlink(self.tempf.name)

    formatter = TempFileFormatter

# Generated at 2022-06-12 00:05:45.143495
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt = Formatting(['colors'])
    headers = {
        'Content-Type': 'application/json',
        'X-Custom': 'value',
    }
    output = fmt.format_headers(headers)
    assert "{\x1b[94m'Content-Type'\x1b[0m: \x1b[94m'application/json'\x1b[0m" in output

# Generated at 2022-06-12 00:05:47.113873
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') == '<class \'httpie.plugins.converter.JSONConverter\'>'

# Generated at 2022-06-12 00:05:54.500170
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    input = '[{"time": "2017-10-21 12:00:00", "temp": 0.1}]'
    mime = "application/json"
    expected = '[\n  {\n    "temp": 0.1, \n    "time": "2017-10-21 12:00:00"\n  }\n]'
    result = Formatting(groups=["pretty"]).format_body(input, mime)
    assert result == expected

# Generated at 2022-06-12 00:05:57.333127
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test for a valid mime-type
    assert is_valid_mime('application/json') == True
    # Test for a invalid mime-type
    assert is_valid_mime('application') == False

# Generated at 2022-06-12 00:05:59.926984
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter1 = Conversion.get_converter("application/json")
    assert type(converter1) == type(ConverterPlugin)
    converter2 = Conversion.get_converter("random")
    assert converter2 == None



# Generated at 2022-06-12 00:06:04.196146
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    formatting = Formatting(groups)
    assert formatting.enabled_plugins == []
    assert formatting.format_headers('HTTP/1.1') == 'HTTP/1.1'
    assert formatting.format_body('test', 'application/json') == 'test'

# Generated at 2022-06-12 00:06:09.208978
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    assert is_valid_mime(mime) == True

    converter1 = Conversion.get_converter(mime)
    assert converter1.mime == mime

    mime = 'text/plain'
    assert is_valid_mime(mime) == True

    converter2 = Conversion.get_converter(mime)
    assert converter2 is None


# Generated at 2022-06-12 00:06:10.412692
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)

# Generated at 2022-06-12 00:06:11.359178
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter("image/jpeg")



# Generated at 2022-06-12 00:06:17.097030
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    environment = Environment()
    environment.config.output_options.format = "pretty"
    f = Formatting(["headers"], env=environment)
    headers = "HTTP/1.0 200 \r\nContent-Type: application/json; charset=utf-8\r\n\r\n"
    header = f.format_headers(headers)
    assert header == "HTTP/1.0 200 \n\nContent-Type: application/json; charset=utf-8\n\n\n"


# Generated at 2022-06-12 00:06:19.808465
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.name == 'json'
    assert converter.mime == 'application/json'


# Generated at 2022-06-12 00:06:29.541410
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=['JSON'], env=Environment())
    print(f.format_body('{"a":1}', 'application/json'))

    f = Formatting(groups=['JSON'], env=Environment())
    print(f.format_body('{"a": {"b": 3}}', 'application/json'))

    f = Formatting(groups=['JSON', 'Pretty'], env=Environment())
    print(f.format_body('{"a": {"b": 3}}', 'application/json'))

    f = Formatting(groups=['Pretty'], env=Environment())
    print(f.format_body('{"a": {"b": 3}}', 'application/json'))


# Generated at 2022-06-12 00:06:34.843846
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded") is not None


# Generated at 2022-06-12 00:06:39.543290
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    groups = ['colors', 'formatting']
    env.colors = True
    env.format = True
    fmt = Formatting(groups, env=env, indent=3)

    assert fmt.format_headers('Content-Type: application/json\r\n') == '\033[37m\033[1mContent-Type\033[21m: application/json'

# Generated at 2022-06-12 00:06:46.689860
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting = Formatting(groups=['colors'])
    formatted_body = formatting.format_body(
        content='''{"a": 1}''',
        mime='application/json')
    assert formatted_body == '''\033[38;5;241m{\033[39m\033[38;5;45m"a"\033[39m\033[38;5;241m: \033[39m\033[38;5;45m1\033[39m\033[38;5;241m}\033[39m'''

# Generated at 2022-06-12 00:06:50.257609
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'stream': 'stream'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == [colors.Colors(**kwargs)]

# Generated at 2022-06-12 00:06:50.754196
# Unit test for constructor of class Formatting
def test_Formatting():
    assert False

# Generated at 2022-06-12 00:06:55.745874
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    input_content = '{"foo": "bar"}'
    input_mime = 'application/json'
    output_content = '*_ \xb1`\x03K\x1e3\x83\xac\x019\x01\xfd'
    groups = ['json']
    formatting = Formatting(groups)
    assert formatting.format_body(input_content,input_mime) == output_content


# Generated at 2022-06-12 00:06:58.902753
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test for a valid mime
    converter = Conversion.get_converter('text/html')
    assert converter is not None

    # Test for an invalid mime
    converter = Conversion.get_converter('text+html')
    assert converter is None


# Generated at 2022-06-12 00:07:03.338834
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('xyz') is None
    assert Conversion.get_converter('abc/xyz') is None

    assert Conversion.get_converter('application/xml').mime == 'application/xml'
    assert Conversion.get_converter('text/html').mime == 'text/html'

# Generated at 2022-06-12 00:07:11.239635
# Unit test for constructor of class Formatting
def test_Formatting():
        assert Formatting(groups=['colors']).enabled_plugins[0].name == "Colors"
        assert Formatting(groups=['colors']).enabled_plugins[0].enabled
        assert Formatting(groups=[]).enabled_plugins == []
        test_env = Environment()
        test_env.color = True
        assert Formatting(groups=['colors'], env=test_env).enabled_plugins[0].enabled
        test_env.color = False
        assert not Formatting(groups=['colors'], env=test_env).enabled_plugins[0].enabled



# Generated at 2022-06-12 00:07:18.816765
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # set valid strings
    groups = ["colors"]
    headers = "HTTP/1.1 200 OK\nContent-Length: 0\nContent-Type: application/json; charset=utf-8\n\n"
    valid_headers = "\n".join([
        "\x1b[90mHTTP/1.1 200 OK \x1b[0m",
        "\x1b[90mContent-Length: 0 \x1b[0m",
        "\x1b[90mContent-Type: application/json; charset=utf-8\x1b[0m",
        ""
    ]) + "\n"

    # test
    assert Formatting(groups=groups).format_headers(headers) == valid_headers



# Generated at 2022-06-12 00:07:29.627965
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not is_valid_mime('sdfsdsdsd')
    assert is_valid_mime('text/plain')
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')

    c = Conversion.get_converter('text/plain')
    assert c.output_mime_type == 'text/plain'

    c = Conversion.get_converter('text/html')
    assert c.output_mime_type == 'text/plain'

    c = Conversion.get_converter('application/json')
    assert c.output_mime_type == 'application/json'


# Generated at 2022-06-12 00:07:33.198590
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'], env=Environment(), scheme='http', host='localhost', port=8080)
    f = Formatting(groups=['colors', 'json'], env=Environment())
    f = Formatting(groups=['json'], env=Environment())
    f = Formatting(groups=[], env=Environment())


# Generated at 2022-06-12 00:07:40.207333
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatter = Formatting(groups=['HTTP'])

    headers_str = '''HTTP/1.1 200 OK
Content-Type: application/json
Date: Mon, 17 Feb 2020 02:03:20 GMT
Connection: close

'''
    expect_str = '''HTTP/1.1 200 OK
Content-Type: application/json
Date:  Mon, 17 Feb 2020 02:03:20 GMT
Connection:  close\n\n'''
    assert formatter.format_headers(headers_str) == expect_str



# Generated at 2022-06-12 00:07:42.882876
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('test/test'), None)
    assert isinstance(Conversion.get_converter('image/jpeg'), ConverterPlugin)


# Generated at 2022-06-12 00:07:45.041045
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.core import DEFAULTS

    formatting = Formatting(['colors'], env=DEFAULTS)
    assert formatting is not None

# Generated at 2022-06-12 00:07:51.559565
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['formatters', 'highlighting']
    env = Environment()
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=env)
            if p.enabled:
                enabled_plugins.append(p)
    assert enabled_plugins is not None

# Generated at 2022-06-12 00:07:53.257243
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion()
    assert c.get_converter('application/json')



# Generated at 2022-06-12 00:07:56.198507
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("html"), ConverterPlugin)
    assert Conversion.get_converter("html") is not None
    assert isinstance(Conversion.get_converter(None), type(None))
    assert Conversion.get_converter(None) is None


# Generated at 2022-06-12 00:07:57.074124
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    return None


# Generated at 2022-06-12 00:08:00.700928
# Unit test for constructor of class Formatting
def test_Formatting():
    print(Formatting(groups=['colors']))
    # output: <httpie.formatting.Formatting object at 0x103eb7908>


# Generated at 2022-06-12 00:08:05.899435
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html') is not None

# Generated at 2022-06-12 00:08:15.223407
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(groups=['colors'], env=env, colors=True, indent=4)
    headers = '''\
HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 5
Content-Type: application/json; charset=utf-8
Date: Wed, 02 Jan 2019 21:32:42 GMT
ETag: W/"5-u220mhjtc7qxnqnsxF7IEFe2tts"
Vary: Accept-Encoding
X-Powered-By: Express'''
    print (f.format_headers(headers))
    content = '''\
{
    "foo": "bar"
}'''
    print(f.format_body(content, 'application/json'))

# Generated at 2022-06-12 00:08:18.421582
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Check if the method is working.
    assert Conversion.get_converter('application/json') == None
    # Check if the method is working.
    assert Conversion.get_converter('application/xml') == None


# Generated at 2022-06-12 00:08:21.640402
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert converter is not None

    converter = Conversion.get_converter('text/xml')
    assert converter is not None

    converter = Conversion.get_converter('application/json')
    assert converter is not None

# Generated at 2022-06-12 00:08:25.307079
# Unit test for constructor of class Formatting
def test_Formatting():
    import httpie.plugins.builtin
    assert Formatting(groups=['colors'], highlight_lines=[3, 4])
    assert Formatting(groups=['colors'], colors='auto')
    assert Formatting(groups=['colors'], colors=True)
    assert Formatting(groups=['colors'], colors=False)
    # colors = 'off' should also work but currently it is not supported
    # assert Formatting(groups=['colors'], colors='off')

    # colors = 256 should also work but currently it is not supported
    # assert Formatting(groups=['colors'], colors=256)

    # colors = 'xxx' is not supported
    with pytest.raises(SystemExit):
        Formatting(groups=['colors'], colors='xxx')
    # colors = dict is not supported
   

# Generated at 2022-06-12 00:08:28.722755
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.environment import Environment
    import builtins
    env = Environment()
    env.config['colors'] = False,
    env.config['style'] = builtins.style = None,
    env.config['print_body_only'] = False
    test = Formatting(['json', 'pretty'], env)
    assert test.enabled_plugins == []

# Generated at 2022-06-12 00:08:31.223251
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        Conversion.get_converter('text/html')
        assert True
    except Exception:
        assert False


# Generated at 2022-06-12 00:08:36.818271
# Unit test for constructor of class Formatting
def test_Formatting():
    groups=["json"]
    env=Environment()
    kwargs={"indent": 4}
    try:
        get_plugin_method = plugin_manager.get_formatters_grouped()
        get_plugin_method["json"] = [JsonFormatter]
        instance = Formatting(groups, env, **kwargs)
        assert instance.enabled_plugins==[JsonFormatter(env, **kwargs)]
    except Exception as e:
        raise e

# Generated at 2022-06-12 00:08:42.914245
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.cli import parser
    from httpie.context import Environment

    env = Environment(stdin=None, stdout=None, stderr=None, vc=None,
                    args=parser.parse_args(["-g", "colors"]),
                    orig_stdout=sys.stdout, orig_stderr=sys.stderr,
                    config=None)

    formatting = Formatting(groups=["colors"], env=env)

    assert len(formatting.enabled_plugins) == 1
    assert formatting.enabled_plugins[0].__class__.__name__ == "Colors"
    assert formatting.enabled_plugins[0].enabled == True
    assert formatting.enabled_plugins[0].get_body_formatting_func()(
        "", "text/plain") == "Colors"