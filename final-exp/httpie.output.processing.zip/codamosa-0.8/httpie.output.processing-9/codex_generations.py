

# Generated at 2022-06-11 23:58:45.636465
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    env=Environment(colors=True)
    fmt = Formatting(['headers', 'colors'], env=env)
    assert fmt.format_headers('foo: bar\r\nbar: foo') == '\x1b[32mfoo: bar\r\n' \
                                                         'bar: foo\x1b[0m'

# Generated at 2022-06-11 23:58:48.717511
# Unit test for constructor of class Formatting
def test_Formatting():
    F = Formatting("json")
    assert F
    assert isinstance(F.enabled_plugins, list)
    assert F.enabled_plugins[0].__class__.__name__ == 'PrettyJsonFormatter'


# Generated at 2022-06-11 23:58:49.864340
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').supports_json()

# Generated at 2022-06-11 23:58:53.000982
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert len(Conversion.get_converter("json").__dict__) == 7
    assert len(Conversion.get_converter("xml").__dict__) == 7
    assert len(Conversion.get_converter("html").__dict__) == 7

# Generated at 2022-06-11 23:58:54.090686
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(['test'],None, **{'test':1})

# Generated at 2022-06-11 23:59:04.376773
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'
        ])
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 92\r\n' \
              'Date: Tue, 24 Jan 2017 07:44:27 GMT\r\n\r\n'
    headers = f.format_headers(headers)
    print(headers)
    assert(headers.find('HTTP/1.1 200 OK') == 0)
    assert(headers.find('Content-Type: application/json') > 0)
    assert(headers.find('Content-Length: 92') > 0)
    assert(headers.find('Date: Tue, 24 Jan 2017 07:44:27 GMT\r\n\r\n'.strip()) > 0)



# Generated at 2022-06-11 23:59:12.611485
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print("\nTesting method format_headers of class Formatting")

    env = Environment()
    test_formatters = Formatting(['colors'], env)
    test_formatters_json = Formatting(['json'], env)
    test_formatters_json_colors = Formatting(['colors', 'json'], env)
    # Normal test case

# Generated at 2022-06-11 23:59:14.605107
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'syntax']
    test = Formatting(groups)
    return test

# Generated at 2022-06-11 23:59:21.921964
# Unit test for constructor of class Formatting
def test_Formatting():
    class Mock:
        def __init__(self, **kwargs):
            return

        def __call__(self, **kwargs):
            self.args = kwargs

        @property
        def enabled(self):
            return True
    groups = ['json']
    env = Environment()
    env.colors = True

    available_plugins = plugin_manager.get_formatters_grouped()
    Mock = Mock(env=env, colors=env.colors)
    available_plugins['json'] = [Mock]
    formatter = Formatting(groups, env)
    assert formatter.enabled_plugins[0] is Mock

# Generated at 2022-06-11 23:59:29.607401
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    basic_headers = """HTTP/1.1 200 OK
Date: Thu, 15 Dec 2016 01:52:09 GMT
Connection: keep-alive
Content-Length: 12
"""

# Generated at 2022-06-11 23:59:36.758389
# Unit test for constructor of class Formatting
def test_Formatting():
    formatter_groups = ['colors']
    env = Environment()
    formatting = Formatting(formatter_groups, env)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'Colorize'
    assert len(formatting.enabled_plugins) == 1



# Generated at 2022-06-11 23:59:41.357070
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ["colors", "formatters"]
    kwargs = {"help_option": False, "headers_option": True, "body_option": False, "stream": sys.stdout}
    test_formatter = Formatting(groups, env, **kwargs)
    assert test_formatter.enabled_plugins


# Generated at 2022-06-11 23:59:47.630064
# Unit test for constructor of class Formatting
def test_Formatting():
    # Requirement
    groups = ['colors', 'colors']
    env = Environment()
    kwargs = {'style': 'default', 'style_sheet': 'monokai.theme'}

    # Action
    f = Formatting(groups, env=env,**kwargs)

    # Assert
    assert f is not None

    # Assert
    assert f.enabled_plugins is not None


# Generated at 2022-06-11 23:59:58.209979
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    env1 = Environment()

    environment_once = {
        "headers": [
            "HTTP/1.1 200 OK",
            "Content-Length: 57",
            "Content-Type: application/json",
            "Date: Thu, 09 May 2019 02:10:34 GMT",
            "Server: BaseHTTP/0.6 Python/3.7.3"
        ],
        "group": ["HTTPHeadersProcessor"],
        "env": env1,
    }
    headers1 = Formatting.get_converter("txt").to_unicode(
        "\n".join(environment_once["headers"])
    )

    processor1 = HTTPHeadersProcessor(env=Environment())
    headers2 = processor1.format

# Generated at 2022-06-12 00:00:04.186131
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment(output_options=dict(format="formatting"))
    formatting = Formatting({'formatting'}, env=env)
    formatting.enabled_plugins[0].format_body = lambda _x, _y: 'Abc'
    out = formatting.format_body('xyz', 'text/html')
    assert out == 'Abc'


# Generated at 2022-06-12 00:00:13.809654
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import pytest
    from httpie.plugins import JSON_ACCEPT
    from httpie.plugins.builtin import Colors
    from httpie.output.formatters.colors import get_lexer

    env = Environment(colors=True,
                      stdout_isatty=True)
    kwargs = {
        'style': Colors.STYLE_MONOKAI,
        'lexer': get_lexer(JSON_ACCEPT, JSON_ACCEPT),
        'colors': Colors(env),
        'format_options': {},
        }
    content = json.dumps({'foo': 'bar'})
    mime = JSON_ACCEPT
    # If process is success,return the content
    # in the form of string

# Generated at 2022-06-12 00:00:15.744910
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format', 'format-pretty']
    env = Environment()
    formatting = Formatting(groups)


# Generated at 2022-06-12 00:00:17.205304
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    result = Formatting().format_headers("")
    assert len(result) == 0



# Generated at 2022-06-12 00:00:21.388545
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatted_body = Formatting(['colors']).format_body(
        "{'status':'ok'}",
        'application/json'
    )

    if '\x1b' not in formatted_body:
        raise Exception('Formatting of body failed: no color codes present.')

# Generated at 2022-06-12 00:00:31.824624
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import re
    formatting_class = Formatting(["headers"])
    formatted_value = formatting_class.format_headers('HTTP/2 200\nContent-Type: text/html; charset=utf-8\nDate: Sun, 06 Jan 2019 06:09:56 GMT\nServer: Python/3.5 aiohttp/3.3.2\nVary: Accept-Encoding\nContent-Length: 40\n\n<html><body>Hello, world!</body></html>\n')

# Generated at 2022-06-12 00:00:37.813525
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_obj = Conversion.get_converter('text/html')
    assert converter_obj.__class__.__name__ == 'HTMLConverter'
    assert converter_obj.mime_type == 'text/html'


# Generated at 2022-06-12 00:00:44.483147
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['default', 'colors'], env=Environment())

    # Test available plugin
    from httpie.plugins.builtin import PrettyColors
    from httpie.formatter import Formatter
    from httpie.plugins.json import JSONPrettyPrinter
    from httpie.plugins.html import HTMLPrettyPrinter
    from httpie.plugins import registry

    l = [PrettyColors, Formatter, JSONPrettyPrinter,
         HTMLPrettyPrinter]
    for i in fmt.enabled_plugins:
        assert i in l
        l.remove(i)

    # Test unknown plugin
    with pytest.raises(registry.PluginRegistryError):
        Formatting(['unknown'], env=Environment())

# Generated at 2022-06-12 00:00:47.096683
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    assert set(available_plugins.keys()) == {'colors', 'format', 'syntax'}

# Generated at 2022-06-12 00:00:51.967878
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('image/jpeg').supports('image/jpeg') == True
    assert Conversion.get_converter('image/jpeg').supports('text/plain') == False


# Generated at 2022-06-12 00:00:55.858929
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers_raw = 'Content-Type: application/json; charset=utf-8\nContent-Length: 18\n\n'
    headers_formatted = Formatting(groups=['colors']).format_headers(headers_raw)
    assert headers_formatted == '\x1b[36mContent-Type: application/json; charset=utf-8\n\x1b[0m' \
                                '\x1b[36mContent-Length: 18\n\x1b[0m\n'



# Generated at 2022-06-12 00:01:01.779629
# Unit test for constructor of class Formatting
def test_Formatting():
    class DummyFormatter:
        def __init__(self):
            self.enabled = True
    plugins = {'foo': [DummyFormatter]}
    available_plugins = type('Dummy', (), {'get_formatters_grouped': lambda self: plugins})()
    plugin_manager.formatters = available_plugins
    formatting = Formatting(['foo'])
    assert len(formatting.enabled_plugins) == 1



# Generated at 2022-06-12 00:01:03.107385
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')



# Generated at 2022-06-12 00:01:05.211523
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors", "formatting"]
    env = Environment()

# Generated at 2022-06-12 00:01:07.665810
# Unit test for constructor of class Formatting
def test_Formatting():
    p = Formatting(groups=['colors'])
    print(p.enabled_plugins)
    assert p.enabled_plugins

# Generated at 2022-06-12 00:01:12.930499
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json

    class JSONFormatter:
        def format_body(self, data, mime):
            return json.dumps(data)

    formatters = [JSONFormatter()]

    f = Formatting(formatters, "application/json")

    data = ['hello', 'world']
    assert f.format_body(data, 'application/json') == json.dumps(data)

# Generated at 2022-06-12 00:01:26.839094
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    Formatting_instance = Formatting("solarized")

# Generated at 2022-06-12 00:01:27.780577
# Unit test for constructor of class Formatting
def test_Formatting():
    F = Formatting([])
    F = Formatting(['colors'])


# Generated at 2022-06-12 00:01:35.302007
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    cases = [
        # input, expected
        [("{}", "{}"),
         ({"a": [1]}, '{"a": [1]}'),
         ({"Content-Type": "application/json"}, 'Content-Type: application/json'),
         ({"Content-Type": "application/json", "application/json": "Content-Type"}, 'Content-Type: application/json\napplication/json: Content-Type')]
    ]

    for input, expected in cases:
        formating = Formatting(["JSON", "Pretty"])
        answer = formating.format_headers(input)
        assert answer == expected



# Generated at 2022-06-12 00:01:45.371265
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()

# Generated at 2022-06-12 00:01:52.565623
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """Test for method get_converter of class Conversion"""

    # test for valid mime
    TEST_TEXT_MIME = 'text/plain'
    result = Conversion.get_converter(TEST_TEXT_MIME)
    assert isinstance(result, ConverterPlugin)

    # test for invalid mime
    TEST_INVALID_MIME = 'invalid/mime'
    result = Conversion.get_converter(TEST_INVALID_MIME)
    assert result is None


# Generated at 2022-06-12 00:01:55.797503
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Arrange
    mime = 'application/json'
    # Act
    converter = Conversion.get_converter(mime)
    # Assert
    assert isinstance(converter, ConverterPlugin)
    assert converter.mime == mime


# Generated at 2022-06-12 00:02:00.933094
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(['colors', 'unicode'], env, colors=True, unicode=True)
    assert f.enabled_plugins[0]._kwargs == {'colors': True}
    assert f.enabled_plugins[1]._kwargs == {'unicode': True}
    assert len(f.enabled_plugins) == 2


# Generated at 2022-06-12 00:02:03.769534
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    mime = converter.mime
    assert mime == 'application/json'

# Integration test for method get_converter of class Conversion

# Generated at 2022-06-12 00:02:13.943682
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['browser'], is_verbose=True)
    # test constructor
    assert f.enabled_plugins[0].__class__.__name__ == 'BrowserFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[2].__class__.__name__ == 'DefaultFormatter'
    # test format_headers
    assert f.format_headers('header1: val1\r\nheader2: val2') == '  header1: val1\n  header2: val2'
    # test format_body
    assert f.format_body('{"test": "val"}', 'application/json') == '<test: val>'


# Generated at 2022-06-12 00:02:18.646029
# Unit test for constructor of class Formatting
def test_Formatting():
    def test_enabled_plugins():
        test_p = Formatting(groups=['colors'], env=Environment(),color_scheme='Sunburst')
        assert 'ANSI256Auto' in str(type(test_p.enabled_plugins[0]))

    test_enabled_plugins()


# Generated at 2022-06-12 00:02:29.363442
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("text/html")
    assert converter.__class__.__name__ == "HTMLConverter"

    converter = Conversion.get_converter("text/json")
    assert converter.__class__.__name__ == "JSONConverter"

    converter = Conversion.get_converter("text/xml")
    assert converter.__class__.__name__ == "XMLConverter"

    converter = Conversion.get_converter("text/css")
    assert converter is None


# Generated at 2022-06-12 00:02:32.580583
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(groups=['formatters', 'colors'])
    assert fmt



if __name__ == '__main__':
    fmt = Formatting(groups=['formatters', 'colors'])
    print(fmt)
    assert fmt

# Generated at 2022-06-12 00:02:34.720571
# Unit test for constructor of class Formatting
def test_Formatting():
    assert plugin_manager is not None
    assert Environment is not None
    Formatting(groups=["colors"])

# Generated at 2022-06-12 00:02:44.761407
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.context import Environment
    from httpie import ExitStatus
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import stream

    from httpie.output.streams import UnsupportedOutputStreamError
    from httpie.output.streams import get_output_stream
    from httpie.output.streams import write_output_stream

    env = Environment(stdout=sys.stdout,
                      stderr=sys.stderr,
                      stdin=sys.stdin,
                      should_stream=True)
    pretty = PrettyOptions()
    json_formatter = JSONFormatter()
    # set json_formatter to be enabled
    json_formatter.enabled = True

    # create a new Formatting
    formatting = Format

# Generated at 2022-06-12 00:02:51.104640
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter('invalid_mime')
    assert type(Conversion.get_converter('application/json')).__name__ == 'JSONConverter'
    assert type(Conversion.get_converter('application/xml')).__name__ == 'XMLConverter'
    assert type(Conversion.get_converter('text/html')).__name__ == 'HTMLConverter'

# Generated at 2022-06-12 00:02:55.849019
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    plain_text = 'The quick brown fox jumps over the lazy dog.'
    assert Formatting(groups=['colors']).format_body(plain_text, 'text/html') == plain_text
    assert Formatting(groups=['colors']).format_body(plain_text, 'text/plain') == plain_text
    assert Formatting(groups=['colors']).format_body(plain_text, 'invalid/mime') == plain_text
    

# Generated at 2022-06-12 00:02:58.180032
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert not Conversion.get_converter('application/json') == ConverterPlugin



# Generated at 2022-06-12 00:03:00.307928
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conv = Conversion().get_converter('application/json')
    assert conv.mime == 'application/json'

# Generated at 2022-06-12 00:03:08.522306
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # 用于调用方法 format_body 的初始化参数
    groups = ['colors']
    env = Environment()
    kwargs = {}

    content = '{"test":"test"}'
    mime = 'application/json'

    formatting = Formatting(groups, env, **kwargs)
    formatted_content = formatting.format_body(content, mime)
    assert formatted_content == '{\x1b[96m"test"\x1b[39;49;00m: \x1b[31m"test"\x1b[39;49;00m}'

# Generated at 2022-06-12 00:03:13.510900
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """Test case for method get_converter of class Conversion"""

    c = Conversion.get_converter('text/html')
    assert isinstance(c, ConverterPlugin)
    c.supported_mime = 'text/html'

    c = Conversion.get_converter('application/json')
    assert c is None


# Generated at 2022-06-12 00:03:17.374013
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert converter.mime == 'text/html'

# Generated at 2022-06-12 00:03:22.795100
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    formatters = Formatting(['formatters'])
    print(formatters.format_body('{"a": "1", "b": "2"}', 'application/json'))
    assert json.loads(formatters.format_body('{"a": "1", "b": "2"}', 'application/json')) == {"a": "1", "b": "2"}
    assert formatters.format_body('{"a": "1", "b": "2"}', 'text/plain') == '{"a": "1", "b": "2"}'


# Generated at 2022-06-12 00:03:24.480108
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print(Formatting.format_headers(Formatting, '{"key":"hello"}'))
    

# Generated at 2022-06-12 00:03:30.634041
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    kwargs1 = {'mime': 'application/json'}
    kwargs2 = {'mime': 'text/html'}
    kwargs3 = {'mime': 'text/plain'}
    assert Conversion.get_converter(**kwargs1) is not None
    assert Conversion.get_converter(**kwargs2) is not None
    assert Conversion.get_converter(**kwargs3) is None



# Generated at 2022-06-12 00:03:32.633200
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/plain').name == 'highlight'
    assert Conv

# Generated at 2022-06-12 00:03:36.035994
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("text/plain") is None
    assert ConverterPlugin in type(Conversion.get_converter("application/json")).__bases__
    assert Conversion.get_converter("json") is None

# Generated at 2022-06-12 00:03:37.639803
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    p = converter('{"test": "test"}')

# Generated at 2022-06-12 00:03:40.208427
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "application/json"
    converter_object = Conversion.get_converter(mime)
    assert isinstance(converter_object, ConverterPlugin)


# Generated at 2022-06-12 00:03:51.034626
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    http_response_headers = b'''HTTP/1.1 200 OK
    Date: Mon, 23 May 2005 22:38:34 GMT
    Content-Type: text/html; charset=UTF-8
    Content-Encoding: UTF-8
    Content-Length: 138
    Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
    Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
    ETag: \"3f80f-1b6-3e1cb03b\"
    Accept-Ranges: bytes
    Connection: close
    '''
    format_headers = Formatting(['colors'], env)

# Generated at 2022-06-12 00:03:52.264630
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])


# Generated at 2022-06-12 00:03:58.393808
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Arrange
    groups = ['colors']

    # Act
    test = Formatting(groups)

    # Assert
    assert '\x1b[1m\x1b[36mHTTP/2.0 200 OK\x1b[0m' == test.format_headers("HTTP/2.0 200 OK")


# Generated at 2022-06-12 00:04:07.894447
# Unit test for constructor of class Formatting
def test_Formatting():
    import sys
    import pytest
    args = []
    args.append('http')
    args.append('--json')
    sys.argv = args
    env = Environment()
    formatting = Formatting(groups=env.formatter_groups, env=env, colors=env.colors,
                            style=env.style, prettify=env.prettify,
                            max_json_depth=env.max_json_depth,
                            search_in_headers=env.search_in_headers,
                            search_in_body=env.search_in_body)
    # Check if enabled_plugins is populated
    plugins = formatting.enabled_plugins
    assert len(plugins) > 0
    # Check if plugins are properly initialized
    for plugin in plugins:
        assert plugin.enabled == True

# Generated at 2022-06-12 00:04:15.204541
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.core import main

    if main.VERSION == "1.0.0":
        # this test will fail for version < 1.0.0
        groups = ["json"]
        formatting = Formatting(groups)
        # check plugins enabled
        assert len(formatting.enabled_plugins) > 0
        # check type of plugin
        assert isinstance(formatting.enabled_plugins[0], ConverterPlugin)
        # check name of plugin
        assert formatting.enabled_plugins[0].name == groups[0]
        # check supported mime of plugin
        assert formatting.enabled_plugins[0].supports("*/*")

# Generated at 2022-06-12 00:04:23.999718
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import unittest
    from unittest import mock

    class MockFormatBodyPlugin(object):
        def __init__(self, env=Environment(), **kwargs):
            self.enabled = True
            
        def format_body(self, input, mime):
            return 'mock_content'
    
    class MockFormatBodyDisabledPlugin(object):
        def __init__(self, env=Environment(), **kwargs):
            self.enabled = False
            
        def format_body(self, input, mime):
            return "mock_content"

    with mock.patch("httpie.context.Environment"):
        f = Formatting(["colors"])
        f_enabled = Formatting(["colors"])
        f_disabled = Formatting(["colors"])
        f_enabled.enabled_plugins

# Generated at 2022-06-12 00:04:34.012952
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    expected = ['{\n    "hello": "world"\n}', '<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <title>Title</title>\n</head>\n<body>\n\n</body>\n</html>']
    actual = []

    for mime in ['application/json', 'text/html']:
        body = '''{ "hello": "world" }'''
        result = Formatting(groups=['colors'], env=Environment(), json=True, pretty=True).format_body(body, mime)
        actual.append(result)

    assert actual == expected, 'The formatting results are not correct.'



# Generated at 2022-06-12 00:04:37.098331
# Unit test for constructor of class Formatting
def test_Formatting():
    test_enabled_plugins = []
    for p in Formatting(['colors', 'formatters']).enabled_plugins:
        test_enabled_plugins.append(p)
    assert test_enabled_plugins


# Generated at 2022-06-12 00:04:39.104418
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter
    assert converter.mime == "application/json"

# Generated at 2022-06-12 00:04:49.631982
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class _Pretty:
        def __init__(self, **kwargs):
            self.enabled = True

        def format_headers(self, data: str) -> str:
            return data + 'test'

    class _Neat:
        def __init__(self, **kwargs):
            self.enabled = True

        def format_headers(self, data: str) -> str:
            return data + 'test2'

    available_plugins = {
        'pretty': [_Pretty, ],
        'neat': [_Neat, ],
    }
    f = Formatting(['pretty', 'neat'], available_plugins=available_plugins)
    assert f.format_headers('raw') == 'rawtesttest2'



# Generated at 2022-06-12 00:04:59.285062
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_content = "{\"id\":\"1\",\"status\":\"success\",\"data\":{\"user_id\":0,\"user_name\":\"wcx\",\"user_sex\":\"male\",\"user_age\":30,\"user_tel\":\"18888888888\",\"user_addr\":\"okok\"}}"
    test_mime = "application/json"
    temp_env = Environment()
    temp_env.colors = False
    temp_env.format = 'json'
    temp_env.output_options = {"pretty"}
    formatter = Formatting(groups=['json'], env=temp_env)

# Generated at 2022-06-12 00:05:08.118704
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    # we need to import the classes here
    # otherwise plug-in manager will not be able to detect them
    # (the time they are imported they are not able to register)
    import httpie.plugins.builtin
    import httpie.plugins.builtin.converters
    import httpie.plugins.builtin.formatter

    assert isinstance(
        Conversion.get_converter('application/json'),
        httpie.plugins.builtin.converters.JSONConverter)
    assert isinstance(
        Conversion.get_converter('application/xml'),
        httpie.plugins.builtin.converters.XMLConverter)
    assert isinstance(
        Conversion.get_converter('text/xml'), httpie.plugins.builtin.converters.XMLConverter)



# Generated at 2022-06-12 00:05:12.946836
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "text/html"
    assert Conversion.get_converter(mime) is not None

# Generated at 2022-06-12 00:05:21.279200
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    json_str = """
{
    "name": "Jim",
    "age": 28,
    "height": 1.86,
    "weight": 78.2,
    "address": [
        "10001",
        "10011"
    ],
    "is_student": true,
    "grades": [
        {
            "name": "Math",
            "score": 98
        },
        {
            "name": "English",
            "score": 98
        }
    ]
}"""

# Generated at 2022-06-12 00:05:28.527172
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0]._name == 'Colors'
    for g in plugin_manager.get_formatters_grouped().keys():
        f = Formatting([g])
        for p in f.enabled_plugins:
            assert p.__class__.__name__ in g
    f = Formatting(['colors', 'colors'])
    assert len(f.enabled_plugins) == 1



# Generated at 2022-06-12 00:05:35.589001
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_formatting = Formatting(["color"])
    content = test_formatting.format_body(b'{"a":1}', "application/json")
    print(content)
    content = test_formatting.format_body(b'{"a":1}', "image/jpeg")
    print(content)
    content = test_formatting.format_body(b'<html><body><h1>abc</h1></body></html>', "text/html")
    print(content)


# Generated at 2022-06-12 00:05:42.617398
# Unit test for constructor of class Formatting
def test_Formatting():
    # Normal case
    groups = ['chrome']
    env = Environment()
    fmt = Formatting(groups=groups, env=env)
    assert fmt.format_headers('header') == 'header'
    assert fmt.format_body('content', 'text/html') == 'content'

    # Invalid arguments
    groups = ['chrome', 'json']
    fmt = Formatting(groups=groups, env=env)
    assert fmt.format_headers('header') == 'header'
    assert fmt.format_body('content', 'text/html') == 'content'
    assert fmt.format_body('content', 'text/plain') == 'content'

# Generated at 2022-06-12 00:05:44.873971
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors"]
    kwargs = {'theme': 'paraiso-dark'}
    env = Environment()
    format = Formatting(groups, env, **kwargs)

# Generated at 2022-06-12 00:05:49.639025
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print('Testing Conversion.get_converter - Case 1 : accept')
    assert(Conversion.get_converter('application/json') is not None)
    print('Testing Conversion.get_converter - Case 2 : reject')
    assert(Conversion.get_converter('application/csv') is None)


# Generated at 2022-06-12 00:05:56.747431
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test available_plugins
    available_plugins = ['FormatTable', 'FormatOneColumn']
    test_instance = Formatting(groups = available_plugins)
    assert test_instance.enabled_plugins == []

    # test headers
    test_instance = Formatting(groups = available_plugins)
    assert test_instance.enabled_plugins == []
    result = test_instance.format_headers('a:b\nc:d')
    assert result == 'a:b\nc:d'


if __name__ == "__main__":
    # test format_headers
    test_Formatting_format_headers()

# Generated at 2022-06-12 00:06:01.959250
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["to_josn", "to_key_value"]
    env = Environment()
    kwargs = {"indent": 4}
    conversion = Formatting(groups, env, **kwargs)
    conversion.format_headers("[test]")
    conversion.format_body("[test]", "text/html")
    conversion.format_body("[test]", "text/xml")
    conversion.format_body("[test]", "text/html")

if __name__ == "__main__":
    test_Formatting()

# Generated at 2022-06-12 00:06:09.728469
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Note that, the following code was written for a similar test for format_body()
    #     print('\nTesting format_body()')
    #     env = Environment()
    #     env.config.format = 'prettyjson'
    #     f = Formatting(['body'], env)
    #     print(f.format_body('{"a": 1}', 'application/json'))

    print('\nTesting format_headers()')
    env = Environment()
    env.config.format = 'prettyheaders'
    f = Formatting(['headers'], env)
    print(f.format_headers(b'a: 1\r\nb: 2\r\nc: 3\r\n\r\n'))

# Generated at 2022-06-12 00:06:13.778484
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
	assert Conversion.get_converter('application/json')

	assert not Conversion.get_converter('application')


# Generated at 2022-06-12 00:06:17.917692
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    headers = 'HTTP/1.1 200 OK\r\nContent-type: content\r\n\r\n'
    assert f.format_headers(headers) == 'HTTP/1.1 200 OK\r\nContent-type: content\r\n\r\n'


# Generated at 2022-06-12 00:06:21.309736
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting = Formatting(['colors'], True)
    assert formatting.format_headers('Content-Type: text/html\r\nAccept: text/html') == 'Content-Type: text/html\r\nAccept: text/html'


# Generated at 2022-06-12 00:06:28.793050
# Unit test for constructor of class Formatting
def test_Formatting():
    assert (plugin_manager.get_formatters_grouped().keys() ==
            {'colors', 'formatters'})
    a = Formatting(groups=['colors'])
    assert (a.enabled_plugins == [])
    b = Formatting(groups=['colors', 'formatters'])
    assert (b.enabled_plugins == [])
    c = Formatting(groups=['colors', 'formatters'], env=Environment())
    assert (c.enabled_plugins == [])


# Generated at 2022-06-12 00:06:34.046189
# Unit test for constructor of class Formatting
def test_Formatting():
    # Case 1: no plugins enabled
    env = Environment()
    f_group_name = ['raw']
    formatting = Formatting(f_group_name, env)
    assert not formatting.enabled_plugins

    # Case 2: some plugins enabled
    f_group_name = ['ugly', 'colors']
    formatting = Formatting(f_group_name, env)
    assert formatting.enabled_plugins


# Generated at 2022-06-12 00:06:37.232236
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    f = Formatting(groups)
    assert f is not None
    assert f.enabled_plugins[0].__class__.__name__ == 'Colors'



# Generated at 2022-06-12 00:06:40.827240
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.supports(mime='application/json')
    assert converter.supports(mime='application/json')
    assert converter.supports(mime='application/json')
    assert not converter.supports(mime='image/png')



# Generated at 2022-06-12 00:06:45.986836
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import httpie.input
    env = Environment()
    env.stdout = httpie.input.FileBytesInput(b'')
    env.stdin = httpie.input.FileBytesInput(b'{"foo": "bar"}')
    return Formatting(['format'], env=env).format_body('{"foo": "bar"}', 'application/json')

# Generated at 2022-06-12 00:06:51.831221
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(env=Environment(), groups=[])
    headers = 'HTTP/1.1 200 OK\r\nContent-Length: 4\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n'
    assert(headers == f.format_headers(headers))
    f.enabled_plugins.append(plugin_manager.get_formatters_grouped()['colors'][0](env=Environment()))
    assert(headers == f.format_headers(headers))

# Generated at 2022-06-12 00:06:58.258711
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    group1 = ['format', 'colors']
    group2 = ['format']
    group3 = ['colors']
    group4 = []
    assert Formatting(group1).format_headers('foo: bar') == '\x1b[37m\x1b[1mfoo:\x1b[0m \x1b[32mbar\x1b[0m'
    assert Formatting(group2).format_headers('foo: bar') == '\x1b[37m\x1b[1mfoo:\x1b[0m bar'
    assert Formatting(group3).format_headers('foo: bar') == 'foo: \x1b[32mbar\x1b[0m'
    assert Formatting(group4).format_headers('foo: bar') == 'foo: bar'


# Unit test

# Generated at 2022-06-12 00:07:06.600246
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert len(f.enabled_plugins) == 1
    f = Formatting(['colors', 'colors'])
    assert len(f.enabled_plugins) == 1
    f = Formatting(['colors', 'colors', 'colors'])
    assert len(f.enabled_plugins) == 1
    f = Formatting(['colors', 'colors', 'colors', 'colors'])
    assert len(f.enabled_plugins) == 1

# Generated at 2022-06-12 00:07:11.555282
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Date: Thu, 13 Jun 2019 11:33:12 GMT
Content-Length: 30

'''

    fmt = Formatting(groups=['colors'], env=Environment())
    print(fmt.format_headers(headers=headers))


# Generated at 2022-06-12 00:07:16.411203
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    g = Formatting(groups=['colors'])
    content = '{"hello": "world"}'
    mime = 'application/json'
    output = g.format_body(content, mime)
    assert(output == '{\x1b[94m"hello"\x1b[39m:\x1b[93m"world"\x1b[39m}')

# Generated at 2022-06-12 00:07:16.907730
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pass

# Generated at 2022-06-12 00:07:27.766751
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    f = Formatting(['colors'])
    mime = 'application/json'
    json_str = '{"key":"value"}'
    s = f.format_body(json_str, mime)
    assert(s.strip() == '\x1b[38;5;246m{\x1b[39m\n    \x1b[38;5;221m"key"\x1b[39m: \x1b[38;5;154m"value"\x1b[39m\n\x1b[38;5;246m}\x1b[39m')
    # Test case 2
    f = Formatting(['format', 'colors'])
    mime = 'text/plain'
    text = 'some text'
    s = f.format_

# Generated at 2022-06-12 00:07:30.657637
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "application/json"

    # get_converter() should return converter for mime
    converter = Conversion.get_converter(mime)
    assert isinstance(converter, ConverterPlugin)

# Generated at 2022-06-12 00:07:40.495705
# Unit test for constructor of class Formatting
def test_Formatting():
    print("Unit test for constructor of class Formatting")
    groups = []
    groups.append("colors")
    env = Environment()
    # Test case 1
    print("Test case 1: ")
    f = Formatting(groups=groups, env=env)
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == "ColorsFormatter"
    assert f.enabled_plugins[0].__class__.__dict__.get('schema') == 'colors'
    assert f.enabled_plugins[0].__class__.__dict__.get('env') == env
    print("passed")
    # Test case 2
    print("Test case 2: ")
    groups.append("format")

# Generated at 2022-06-12 00:07:41.754444
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Normal case
    # Test for unsupported case
    # Test for disabled plugin
    pass

# Generated at 2022-06-12 00:07:45.622715
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    converter = Conversion.get_converter('json')
    assert converter is not None
    converter = Conversion.get_converter('ignored_fake_mime')
    assert converter is None


# Generated at 2022-06-12 00:07:53.663028
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(None)
    assert f.format_headers('a:b') == 'a: b'
    assert f.format_headers('a: b') == 'a: b'
    assert f.format_headers('A: b') == 'A: b'
    assert f.format_headers('A: b') == 'A: b'
    assert f.format_headers('A: B') == 'A: B'
    assert f.format_headers('a: B') == 'a: B'


# Generated at 2022-06-12 00:08:04.462654
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    format_body_content = "{\n  \"data\": \"test content\"\n}"
    format_body_mime = "application/json"
    format_body_args = Formatting(["Colors"])
    assert format_body_args.format_body(format_body_content, format_body_mime) == '{\n  \x1b[34m"data"\x1b[39;49;00m: \x1b[33m"test content"\x1b[39;49;00m\n}'

# Generated at 2022-06-12 00:08:10.122536
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    #Test case 1
    output_Formatting_1 = Formatting(['colors'], input_format='colors').format_body("{\"key\": \"value\"}", 'application/json')
    expectedOutput_Formatting_1 = "\033[1;39m{\033[0m\n    \033[1;32m\"key\"\033[1;39m: " \
                                  "\033[0m\033[1;32m\"value\"\033[0m\n\033[1;39m}\033[0m"
    assert expectedOutput_Formatting_1 == output_Formatting_1

# Generated at 2022-06-12 00:08:19.749307
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert(Formatting([]).format_body("{\"a\":1}", "application/json") == "{\"a\":1}")
    assert(Formatting(["json"]).format_body("{\"a\":1}", "application/json") ==
           '{\n    "a": 1\n}')
    assert(Formatting(["colors"]).format_body("{\"a\":1}", "application/json") ==
           '{\033[0;31m\n    "a"\033[0m\033[0;33m:\033[0m\033[0;32m 1\n\033[0m}')
    # Test when mime type is not valid, formatting will not be applied.

# Generated at 2022-06-12 00:08:27.204589
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    h = Formatting(["format_json", "format_screen"])
    # test case1
    a = h.format_headers("""HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 3

""")
    b = """HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 3

"""
    assert a == b
    # test case2
    a = h.format_headers("""HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 3

{"a":1}""")

# Generated at 2022-06-12 00:08:29.384399
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # arrange
    mime = 'text/plain'
    # action
    converter = Conversion.get_converter(mime)
    # asset
    assert converter is not None


# Generated at 2022-06-12 00:08:39.153856
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    import os
    import sys
    env = Environment('', [], [], netrc=True, auth=(), timeout=None, max_redirects=None,
                      verify=None, proxies=None, allow_redirects=True, stream=False,
                      check_status=False, headers=[], output_file=sys.stdout,
                      download_dir=None, client_cert=None, debug=False,
                      traceback=False, verify_ssl_certs=False, output_options={"stdout": True},
                      compression=False, http2=False)
    groups = ['default', 'identify']
    formatter_class = Formatting(groups, env)