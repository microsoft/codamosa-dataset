

# Generated at 2022-06-11 23:58:45.673377
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1
    mime = 'text/html'
    result = Conversion.get_converter(mime)
    assert result

    # Test case 1
    mime = 'text/plain'
    result = Conversion.get_converter(mime)
    assert result

    # Test case 1
    mime = 'Hello World!'
    result = Conversion.get_converter(mime)
    assert not result

# Generated at 2022-06-11 23:58:54.048014
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import ast

    # test multiple processors are activated
    groups = ['colors', 'format']
    content = '{"a":1}'
    mime = 'application/json'
    f = Formatting(groups)
    new_content = f.format_body(content, mime)
    if isinstance(new_content, bytes):
        new_content = new_content.decode()
    new_content = ast.literal_eval(new_content)
    assert new_content == json.loads(content)

    # test no processor is activated
    groups = []
    content = '{"a":1}'
    mime = 'application/json'
    f = Formatting(groups)
    new_content = f.format_body(content, mime)
    assert new_content == content

    #

# Generated at 2022-06-11 23:59:01.238382
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print('Unit test for method get_converter of class Conversion ... ', end='')

    assert(Conversion.get_converter('application/json') == None)

    assert(Conversion.get_converter('application/json;') != None)
    assert(Conversion.get_converter('application/json;') == None)

    assert(Conversion.get_converter('application/xml;') != None)
    assert(Conversion.get_converter('application/xml;') == None)

    print('done')

# Generated at 2022-06-11 23:59:09.180155
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class test_PrettyJsonPlugin:
        def __init__(self, **kwargs):
            pass
        def format_body(self, content: str, mime: str) -> str:
            return 'Test: {}'.format(content)
    Formatting.enabled_plugins.append(test_PrettyJsonPlugin())

    # Test normal case
    res = Formatting.format_body('{}', 'application/json')
    assert(res == 'Test: {}')

    # Test when we pass invalid mime
    res = Formatting.format_body('{}', 'application')
    assert(res == '{}')

    del Formatting.enabled_plugins[:]

# Generated at 2022-06-11 23:59:19.769563
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.json.formatter import JSONFormatter
    from httpie.plugins.xml.formatter import XMLFormatter
    from httpie.plugins.graphql.formatter import GraphQLFormatter
    from httpie.plugins.urlencoded.formatter import URLEncodedFormatter

    valid_json = '{"key": "value", "key2": "value2"}'
    valid_xml = '<tag1>value</tag1><tag2>value2</tag2>'
    valid_graphql = 'query { author { name }}'

    formatter_classes = [JSONFormatter, XMLFormatter, GraphQLFormatter, URLEncodedFormatter]

    for formatter_class in formatter_classes:
        formatter = formatter_class()

# Generated at 2022-06-11 23:59:21.644800
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    Conversion = Conversion.get_converter('application/json')
    assert(str(Conversion)) == 'JSONConverter'


# Generated at 2022-06-11 23:59:27.074360
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = """HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 0
Content-Type: application/json
Date: Sun, 07 Oct 2018 11:34:13 GMT
Server: TornadoServer/4.5.2
X-Frame-Options: DENY

"""
    f = Formatting(groups=['colors'], colors=True)
    assert headers == f.format_headers(headers)

# Generated at 2022-06-11 23:59:29.285366
# Unit test for constructor of class Formatting
def test_Formatting():
    headers_data = "HTTP/1.1 200 OK"
    formatter = Formatting(["colors"])
    #print(formatter.format_headers(headers_data))

# Generated at 2022-06-11 23:59:41.017100
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    #Test case 1:
    headers = "Content-Type: text/plain; charset=utf-8\n"
    headers += "Connection: Keep-Alive\n"
    headers += "Transfer-Encoding: chunked\n"
    headers += "Server: gunicorn/19.9.0\n"
    headers += "Date: Tue, 15 Oct 2019 08:02:04 GMT\n"
    headers += "X-Frame-Options: DENY\n"
    headers += "Content-Length: 0\n"
    headers += "Via: 1.1 vegur\n"
    headers += "Allow: GET, POST, OPTIONS\n"
    F = Formatting(['colors'], scheme="http")
    headers = F.format_headers(headers)


# Generated at 2022-06-11 23:59:42.503800
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    formatted = Conversion.get_converter("Command")
    if formatted is None:
        print("no match")

# Generated at 2022-06-11 23:59:56.365156
# Unit test for constructor of class Formatting
def test_Formatting():
    from unittest.mock import MagicMock
    env = Environment()
    # First test when a plugin is enabled
    enabled_plugin = MagicMock()
    enabled_plugin.enabled = True
    enabled_plugin.format_body = MagicMock()
    enabled_plugin.format_headers = MagicMock()
    enabled_plugin.format_body.side_effect = lambda x, y: x
    enabled_plugin.format_headers.side_effect = lambda x: x
    disabled_plugin = MagicMock()
    disabled_plugin.enabled = False
    plugin_manager.get_formatters_grouped = lambda: {
        'group': [enabled_plugin, disabled_plugin]
    }
    # Ensure only the enabled plugin gets instantiated
    f = Formatting(['group'], env)

# Generated at 2022-06-11 23:59:57.080156
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(
        ['color'], 
        env=Environment(), **{}
    )


# Generated at 2022-06-11 23:59:58.449922
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert(Conversion.get_converter('application/json').mime() == 'application/json')
    assert(none == Conversion.get_converter('text/html'))


# Generated at 2022-06-11 23:59:59.956204
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'),
                      ConverterPlugin)


# Generated at 2022-06-12 00:00:06.396474
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_cases = [
        {"input": "application/json", "expected": "JSONConverter"},
        {"input": "application/foo",  "expected": None}
    ]
    for test_case in test_cases:
        assert Conversion.get_converter(test_case["input"]).__class__.__name__ == test_case["expected"]

# Generated at 2022-06-12 00:00:14.362199
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import json
    import pprint
    from httpie import ExitStatus
    from httpie.compat import urlopen
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin, plugin_manager
    from httpie.output import streams

    class JSONFormatter(FormatterPlugin):
        """
        Pretty JSON formatting for --print=B and --pretty=format.
        """

        name = 'json'
        media_type = 'application/json'

        def format(self, body, mime, **kwargs):
            try:
                json_obj = json.loads(body)
            except ValueError:
                raise ValueError('Invalid JSON: %s' % body)
            else:
                pretty_json_str = pprint.pformat(json_obj)

# Generated at 2022-06-12 00:00:15.949104
# Unit test for constructor of class Formatting
def test_Formatting():
    tmp = Formatting(['pretty'])
    assert len(tmp.enabled_plugins) == 1

# Generated at 2022-06-12 00:00:20.269049
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """
    Args:
        mime (string): The mime type.

    Returns:
        A converter.
    """
    assert(is_valid_mime("text/html"))
    assert(is_valid_mime("application/json"))
    assert(is_valid_mime("audio/mpeg") == False)
    assert(is_valid_mime("audio/x-mpeg") == False)


# Generated at 2022-06-12 00:00:27.338396
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # test with unknown mime type
    unknown_mime = 'application/xyz'
    assert not Conversion.get_converter(unknown_mime)
    # test with simple mime type
    simple_mime = 'text/plain'
    assert isinstance(Conversion.get_converter(simple_mime), ConverterPlugin)
    # test with a non-trivial mime type
    mime = 'image/png'
    assert isinstance(Conversion.get_converter(mime), ConverterPlugin)

# Generated at 2022-06-12 00:00:28.881167
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting()
    assert f.enabled_plugins == []



# Generated at 2022-06-12 00:00:41.642077
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers_output = Formatting.format_headers("""HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
ETag: "34aa387-d-1568eb00"
Accept-Ranges: bytes
Content-Length: 51
Content-Type: text/plain
X-Pad: avoid browser bug""")


# Generated at 2022-06-12 00:00:52.096988
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    mime = 'application/json'
    input_text = '{"name": "Gaurav"}'
    output_text = '{\n    "name": "Gaurav"\n}'
    assert output_text == Formatting(groups=['colors']).format_body(input_text, mime)
    input_text = '{"name": "Gaurav"}\n'
    output_text = '{\n    "name": "Gaurav"\n}\n'
    assert output_text == Formatting(groups=['colors']).format_body(input_text, mime)
    assert output_text == Formatting(groups=['colors']).format_body(output_text, mime)
    input_text = '[{"name": "Gaurav"}]'

# Generated at 2022-06-12 00:00:54.006834
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors'])
    assert len(fmt.enabled_plugins) == 1
    assert fmt.enabled_plugins[0].__class__.__name__ == 'Formatter'


# Generated at 2022-06-12 00:00:56.332489
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None

# Generated at 2022-06-12 00:00:57.662685
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("text/plain") is None


# Generated at 2022-06-12 00:00:59.486767
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert is_valid_mime(Conversion.get_converter('application/json').mime)
    

# Generated at 2022-06-12 00:01:05.808202
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """
    Tests method format_headers of class Formatting
    :return:
    """

    # Arrange
    headers = "Content-Type: application/javascript Content-Disposition: attachment;filename=example.jpg"

    format_class = Formatting(["format_headers"])

    # Act
    test_headers = format_class.format_headers(headers)

    # Assert
    assert "Content-Type: application/json" in test_headers
    assert "Content-Disposition: attachment;filename=example.jpg" in test_headers


# Generated at 2022-06-12 00:01:09.598106
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins import builtin
    fmt = Formatting(['colors'])
    assert len(fmt.enabled_plugins) == 1
    assert isinstance(fmt.enabled_plugins[0], builtin.Formatter)

# Generated at 2022-06-12 00:01:17.421649
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from .converter import JSONConverter, URLEncodedConverter
    from .converter import MultipartFormDataConverter
    from .converter import MultipartFormDataConverter
    from .converter import MultipartFormDataConverter
    assert type(Conversion.get_converter("application/json")) == JSONConverter
    assert type(Conversion.get_converter("application/x-www-form-urlencoded")) == URLEncodedConverter
    assert type(Conversion.get_converter("multipart/form-data")) == MultipartFormDataConverter
    

# Generated at 2022-06-12 00:01:20.299140
# Unit test for constructor of class Formatting
def test_Formatting():
    # Constructor of class Formatting
    formatter = Formatting(groups=['colors'])
    assert formatter.enabled_plugins[0].__dict__['_colors'] == None


# Generated at 2022-06-12 00:01:24.771301
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print("Testing the get_converter method of class Conversion")
    assert Conversion.get_converter('text/plain').mime == 'text/plain'

# Generated at 2022-06-12 00:01:26.491796
# Unit test for constructor of class Formatting
def test_Formatting():
    env=Environment()
    f=Formatting(["Colors"], env)


# Generated at 2022-06-12 00:01:32.934714
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print('\n')
    the_content = """
    <html>
        <head>
            <title>Testing</title>
        </head>
        <body>
            <a>This is a test</a>
        </body>
    </html>
    """
    the_mime_type = 'text/html'
    f = Formatting(['httpie', 'html'])
    result_fmt = f.format_body(the_content, the_mime_type)
    assert type(result_fmt) is str

# Generated at 2022-06-12 00:01:42.829565
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatter = Formatting("json")
    headers_json = """
HTTP/1.1 200 OK
Content-Length: 103
Content-Type: application/json; charset=utf-8

"""
    headers = {
        'Access-Control-Allow-Credentials': 'true',
        'Access-Control-Allow-Methods': 'GET'
    }
    assert formatter.format_headers(headers_json) == headers_json
    assert formatter.format_headers(headers_json + str(headers)) == '''
HTTP/1.1 200 OK
Content-Length: 103
Content-Type: application/json; charset=utf-8
Access-Control-Allow-Credentials: true
Access-Control-Allow-Methods: GET

'''


# Generated at 2022-06-12 00:01:52.780686
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """Unit test for method format_body of class Formatting"""
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.context import Environment

    env = Environment(stdout_isatty=False)
    grps = ['json']
    fmt = Formatting(grps, env=env)
    json_processor = HTTPPrettyJSONProcessor(env=env)

    def make_call(content, mime):
        return fmt.format_body(content, mime)

    def make_call_2(content, mime):
        return json_processor.format_body(content, mime)

    # test format_body JSON
    content = '{"key1":"value1", "key2": "value2"}'
    mime = "application/json"
    assert make_call(content, mime)

# Generated at 2022-06-12 00:02:00.488563
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    f = Formatting(groups=['headers'], env=env, pretty_options={'colors': False})
    from httpie.compat import str
    from httpie.output.formats import JSONPygmentsHTTPieOutputFormat
    for p in f.enabled_plugins:
        assert(isinstance(p, JSONPygmentsHTTPieOutputFormat))
    assert(f.format_headers(str({'a': 'b', 'c': 'd'})) == 'HTTP/1.1 200 OK\r\nA: b\r\nC: d\r\n\r\n')


# Generated at 2022-06-12 00:02:07.218685
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=["colors"])

# Generated at 2022-06-12 00:02:12.525105
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # arrange
    json_string = '{"id":1,"name":"Ricky Bobby"}'
    f = Formatting(['json'])
    # act
    formatted_headers = f.format_headers(json_string)

    # assert
    assert(formatted_headers == '{\n    "id": 1,\n    "name": "Ricky Bobby"\n}')

# Generated at 2022-06-12 00:02:17.878715
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin import JSONConverter
    assert isinstance(Conversion.get_converter('application/json'), JSONConverter)
    assert isinstance(Conversion.get_converter('application/geo+json'), JSONConverter)
    assert isinstance(Conversion.get_converter('application/json; charset=UTF-8'), JSONConverter)

# Generated at 2022-06-12 00:02:25.305620
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors','format', 'format-session'])
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].__class__.__name__ == 'Formatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'Formatter'
    assert f.enabled_plugins[2].__class__.__name__ == 'Formatter'


# Generated at 2022-06-12 00:02:32.248459
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert not isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)


# Generated at 2022-06-12 00:02:33.729669
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter('json')
    print(c)

# Generated at 2022-06-12 00:02:39.683258
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("json") is not None
    assert Conversion.get_converter("html") is not None
    assert Conversion.get_converter("txt") is not None
    assert Conversion.get_converter("xml") is not None
    assert Conversion.get_converter("yaml") is not None
    assert Conversion.get_converter("unknown") is None
    

# Generated at 2022-06-12 00:02:41.946108
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/xml")
    assert converter.mime == "application/xml"


# Generated at 2022-06-12 00:02:44.037290
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    test_Formatting = Formatting(groups, env)
    assert test_Formatting != None


# Generated at 2022-06-12 00:02:53.995975
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # given
    groups = ['colors']
    env = Environment()
    converters = [
        ConverterPlugin("text/plain", "text/plain", ""),
        ConverterPlugin("text/html", "text/html", "")
    ]
    plugin_manager.register_converters(converters)
    formatting = Formatting(groups, env)

    # when
    result = formatting.format_headers("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n")

    # then

# Generated at 2022-06-12 00:03:02.578207
# Unit test for constructor of class Formatting
def test_Formatting():
    # ------------ Consider the case of group is None ------------
    ff = Formatting([], Environment())
    assert len(ff.enabled_plugins) == 0

    # ------------ Consider the case of group is empty ------------
    ff = Formatting([], Environment())
    assert len(ff.enabled_plugins) == 0

    # ------------ Consider the case of group is not empty ------------
    ff = Formatting(['colors'], Environment())
    assert len(ff.enabled_plugins) == 1
    assert 'colors' in ff.enabled_plugins[0].__class__.__name__
    with pytest.raises(Exception):
        assert 'NoSuchGroup' in ff.enabled_plugins.keys()

# Generated at 2022-06-12 00:03:11.804978
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = """HTTP/1.1 200 OK
Connection: close
Date: Sat, 16 Mar 2019 03:43:49 GMT
Content-Type: application/json; charset=utf-8
ETag: W/"79cbe3d3f335c7f293a17a559d9b615e"
Vary: Origin
X-Powered-By: Express
Content-Length: 43

{"Message":"Hello world!"}"""

    # Test the method with all enabled plugins
    f1 = Formatting(groups=["format", "colorize", "syntax-highlight"], style='paraiso-dark')
    f1.format_headers(headers)

    # Test the method with only format plugin
    f2 = Formatting(groups=["format"], style='paraiso-dark')
    f2.format_headers(headers)

   

# Generated at 2022-06-12 00:03:16.663096
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    class DummyConverter(ConverterPlugin):
        mimes = ['application/json']

        def to_html(self, data):
            return data

    plugin_manager.register(DummyConverter)
    assert Conversion.get_converter(
        'application/json').__class__ == DummyConverter



# Generated at 2022-06-12 00:03:19.979711
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    output = Formatting(['colors'], env=env)
    assert(output.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter')
    assert(output.enabled_plugins[0].enabled == True)


# Generated at 2022-06-12 00:03:28.659927
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text') is None
    assert Conversion.get_converter('') is None
    assert Conversion.get_converter('html') is None
    assert Conversion.get_converter('html/') is None

# Generated at 2022-06-12 00:03:30.070819
# Unit test for constructor of class Formatting
def test_Formatting():
    assert len(Formatting([]).enabled_plugins) == 0



# Generated at 2022-06-12 00:03:37.518231
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_env = Environment(stdout_isatty=False, color=False)
    test_formatting = Formatting(['color'], env=test_env, colors = True)
    test_dict = {"test": "hello world"}
    test_str = '{"test": "hello world"}'
    for p in test_formatting.enabled_plugins:
        test_str = p.format_body(test_str, "application/json")
    assert test_str == '{color.dim "test": color.reset "hello world"}'



# Generated at 2022-06-12 00:03:40.729753
# Unit test for constructor of class Formatting
def test_Formatting():
    import os
    os.environ['HTTPIE_DEBUG'] = '1'
    groups = ['colors']
    env = Environment(colors = True)
    fo = Formatting(groups,env)
    assert isinstance(fo,Formatting)


# Generated at 2022-06-12 00:03:41.264108
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting([])

# Generated at 2022-06-12 00:03:50.824088
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/vnd.api+json')
    assert converter.mime == 'application/vnd.api+json'
    assert converter.__class__.__name__ == 'PrettyJson'
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.__class__.__name__ == 'PrettyJson'
    converter = Conversion.get_converter('text/plain')
    print(converter)
    assert converter == None
    converter = Conversion.get_converter('image/png')
    print(converter)
    assert converter == None

# Generated at 2022-06-12 00:03:54.605798
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors"]
    env = Environment()
    kw = {}
    formatting = Formatting(groups, env, **kw)
    assert len(formatting.enabled_plugins) == 1
    for p in formatting.enabled_plugins:
        assert p.enabled == True
        assert p.env == env


# Generated at 2022-06-12 00:04:03.982603
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = "HTTP/1.1 400 Bad Request\r\nDate: Thu, 08 Aug 2019 06:24:06 GMT\r\nServer: Tengine\r\nContent-Length: 19\r\nConnection: close\r\nContent-Type: application/json; charset=utf-8\r\n\r\n{\n  \"error\": \"Bad Request\"\n}\n"
    env = Environment()
    f = Formatting(["colors", "headers-content-type", "json"], env)
    headers = f.format_headers(headers)
    print(headers)
    f = Formatting(["colors", "headers-content-type"], env)
    headers = f.format_headers(headers)
    print(headers)
    f = Formatting(["headers-content-type"], env)

# Generated at 2022-06-12 00:04:13.628691
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """Unit test for method Formatting.format_headers()"""

    from httpie.core import StrParams

    env = Environment(colors=256, stdin=False, isatty=True,
                      stdin_isatty=False,
                      stdout_isatty=False,
                      output_options=StrParams(
                          verify=False,
                          default_options=False,
                          indent=None,
                          pretty=True,
                          style=None,
                          print_headers=True,
                          headers=None,
                          body=None,
                          form=False,
                          download=False,
                          implicit_content_type=False,
                          follow=False,
                          all=False,
                          history_max_items=30,)
                      )


# Generated at 2022-06-12 00:04:17.758639
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """
    >>> test_Conversion_get_converter()
    True
    """
    if Conversion.get_converter('application/json'):
        return True
    else:
        return False

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 00:04:28.854820
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Unit test for method get_converter of class Conversion
    assert Conversion.get_converter(None) is None



# Generated at 2022-06-12 00:04:33.006312
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # test a valid mime type
    assert Conversion.get_converter('text/json').__class__.__name__ == 'JsonConverter'
    # test an invalid mime type
    assert Conversion.get_converter('invalid') is None



# Generated at 2022-06-12 00:04:41.744997
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Render
    groups = ['obsolete']
    format = Formatting(groups)

    # format_body
    content = 'Line 1\nLine 2\nLine 3\nLine 4\nLine 5\nLine 6\nLine 7\nLine 8'
    mime = 'text/plain'
    expected = 'Line 1\nLine 3\nLine 5\nLine 7\n'
    print(format.format_body(content,mime))
    assert format.format_body(content,mime) == expected

    content = 'Line 1\nLine 2\nLine 3\nLine 4\nLine 5\nLine 6\nLine 7\nLine 8'
    mime = 'obsolete/plain'
    expected = 'Line 1\nLine 3\nLine 5\nLine 7\n'

# Generated at 2022-06-12 00:04:53.420078
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:04:58.681603
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    input_test=b'{"id": "5f5c5e6b-eb6b-43f9-9b9d-6f90e6b867a0", "name": "John", "age": 17}'
    output_test=b'{' + b'\n' + b'    "age": 17,' + b'\n' + b'    "id": "5f5c5e6b-eb6b-43f9-9b9d-6f90e6b867a0",' + b'\n' + b'    "name": "John"' + b'\n' + b'}'
    groups=['json']
    env=Environment()
    kwargs={'sort_keys': True, 'indent': 4}

# Generated at 2022-06-12 00:05:07.810769
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:05:10.039174
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['all', 'colors'], colors=True, indent=4)
    assert len(f.enabled_plugins) == 2

# Generated at 2022-06-12 00:05:15.851395
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Case 1: mime is invalid
    mime = 'text'
    assert Conversion.get_converter(mime) == None

    # Case 2: mime is valid
    mime = 'application/json'
    assert Conversion.get_converter(mime).mimes == "application/json"


# Generated at 2022-06-12 00:05:17.321608
# Unit test for constructor of class Formatting
def test_Formatting():
    for i in range(0, 1000):
        Formatting(groups=["highlight", "colors"])

# Generated at 2022-06-12 00:05:20.995035
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime1 = "application/json"
    cv1 = Conversion.get_converter(mime1)
    assert cv1.name == "json"
    assert cv1.mime == mime1

    mime2 = "text/plain"
    cv2 = Conversion.get_converter(mime2)
    assert cv2 is None

# Generated at 2022-06-12 00:05:35.890010
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.output.formatters.headers import HeadersFormatter
    groups = ['headers']
    formatting_delegate = Formatting(groups)
    headers_formatter = HeadersFormatter('headers')
    if headers_formatter.enabled:
        formatting_delegate.enabled_plugins.append(HeadersFormatter('headers'))
    headers = formatting_delegate.format_headers('header: value')
    assert headers == 'header: value'


# Generated at 2022-06-12 00:05:43.677787
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    b=Conversion.get_converter('application/json')
    assert b == None
    b=Conversion.get_converter('application/json; subtype=something')
    assert b == None
    b=Conversion.get_converter('application/json; subtype=something; subtype2=somethingelse')
    assert b == None
    b=Conversion.get_converter('json')
    assert b == None
    b=Conversion.get_converter('application/x-www-form-urlencoded')
    assert b != None
    b=Conversion.get_converter('x-www-form-urlencoded')
    assert b != None


# Generated at 2022-06-12 00:05:46.280096
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None

# Generated at 2022-06-12 00:05:56.290122
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.formatter import JSONFormatter
    from httpie.formatters.registry import registry
    registry.remove(JSONFormatter)
    from httpie import formatter
    from httpie.cli import get_formatter

    groups = ['JSON', 'colors']
    f = get_formatter(formatter.DEFAULT_FORMAT_OPTIONS, groups)

    data = {'key': 'value'}
    json_data = json.dumps(data)

    raw_data = f.format_headers(json_data)
    assert raw_data == json_data

    converted_data = f.format_body(json_data, mime='application/json')

    assert converted_data == json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False)

# Generated at 2022-06-12 00:05:57.813407
# Unit test for constructor of class Formatting
def test_Formatting():
    g = Formatting(['colors', 'formatters'])
    assert isinstance(g.enabled_plugins, list)

# Generated at 2022-06-12 00:06:03.766882
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print('test_Formatting_format_body')
    import json
    env = Environment()

    headers = '''HTTP/1.1 200 OK
Content-Type: application/json

'''
    body = """
    {
      "id": 1,
      "name": "A green door",
      "price": 12.50,
      "tags": ["home", "green"]
    }
    """
    formatter = Formatting(["format"], env=env)
    result_body = formatter.format_body(body, headers.split('\n')[1].split(': ')[1])
    print(result_body)
    j_body = json.loads(body.strip())
    j_result_body = json.loads(result_body)
    assert j_body == j_result_body

    formatter

# Generated at 2022-06-12 00:06:08.196119
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert(Conversion.get_converter('application/json').mime == 'application/json')
    assert(Conversion.get_converter('text/html').mime == 'text/html')
    assert(Conversion.get_converter('text/json') is None)
    assert(Conversion.get_converter('invalid') is None)


# Generated at 2022-06-12 00:06:09.371232
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("text/*")



# Generated at 2022-06-12 00:06:12.585626
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    json_str = '{"a":1,"b":"c"}'
    groups = ['pretty']
    f = Formatting(groups=groups)
    content = f.format_body(json_str, mime='application/json')
    assert content == '{\n    "a": 1,\n    "b": "c"\n}\n'

# Generated at 2022-06-12 00:06:21.653250
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.registry import plugin_manager
    print(plugin_manager.get_formatters_grouped())

    class TestFormatterPlugin(FormatterPlugin):
        """Test Formatter plugin."""
        name = 't'

    plugin_manager.register(TestFormatterPlugin)
    class TestJSONFormatter(JSONFormatter):
        """Test JSON Formatter plugin."""
        name = 't'
        mime = 'application/json'

    plugin_manager.register(TestJSONFormatter)

    instance = Formatting(env=Environment(pretty=True, style='default'))
    assert instance.enabled_plugins == []

# Generated at 2022-06-12 00:06:39.850387
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:06:46.991568
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # MIME string for testing
    mime = 'image/jpeg'

    # Create class objects
    converter_class_0 = Conversion()

    # Assert the target function
    assert isinstance(converter_class_0.get_converter(mime=mime), ConverterPlugin), \
        'The type of returned value should be ConverterPlugin.'
    assert converter_class_0.get_converter(mime=mime).mime, \
        'The returned mime should be valid.'



# Generated at 2022-06-12 00:06:49.854980
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '[200]'
    groups = ['colors']
    f = Formatting(groups)
    response = '[200]'
    assert f.format_headers(headers) == response


# Generated at 2022-06-12 00:06:51.752316
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    klass = Conversion.get_converter('application/json')
    assert klass is not None
    assert klass.name == 'JSON'



# Generated at 2022-06-12 00:06:54.919337
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("text/html") is not None
    assert Conversion.get_converter("asdf") is None


# Generated at 2022-06-12 00:07:02.171767
# Unit test for constructor of class Formatting
def test_Formatting():
    # test the constructor of class Formatting
    class DummyEnv(Environment):
        def __init__(self):
            self.stdout_isatty = True
            self.is_windows = False
            self.stdin_isatty = True
            self.stdin = io.StringIO()
            self.stdout = io.BytesIO()
            self.stderr = io.BytesIO()
            self.colors = 256
            self.stream = True
            self.headers = True
            self.style = 'FILES'
            self.format = ['parsed']
            self.vars = []
            self.verbose = 0

    dummy_env = DummyEnv()

# Generated at 2022-06-12 00:07:05.769081
# Unit test for constructor of class Formatting
def test_Formatting():
    options = {'options': {}}
    kwargs = {'indent': 2, 'options': options, 'compact': False}
    f = Formatting(['colors'], **kwargs)
    assert(f.enabled_plugins)


# Generated at 2022-06-12 00:07:07.600626
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=('colors', ))
    assert len(f.enabled_plugins) == 1

# Generated at 2022-06-12 00:07:09.966841
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.__class__.__name__ == "JSONConverter"

# Generated at 2022-06-12 00:07:15.143467
# Unit test for constructor of class Formatting
def test_Formatting():
    fp = Formatting(['colors'])
    assert len(fp.enabled_plugins) == 2
    assert fp.enabled_plugins[0].name == 'Pretty'
    fp = Formatting(['colors'], styles=False)
    assert fp.enabled_plugins[0].name == 'Colored'



# Generated at 2022-06-12 00:07:33.300246
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    import io
    import json
    import sys
    import unittest

    # class PreviousStdout:
    #     """Saves previous STDOUT and restores its value after context is closed"""
    #
    #     def __enter__(self):
    #         self.old_stdout = sys.stdout
    #         sys.stdout = io.StringIO()
    #         return self.old_stdout
    #
    #     def __exit__(self, exc_type, exc_val, exc_tb):
    #         sys.stdout = self.old_stdout

    class ConverterPluginTest(ConverterPlugin):
        """
        ConverterPluginTest is a mock class of converter plugin
        """

        @classmethod
        def supports(cls, mime: str) -> bool:
            return mime

# Generated at 2022-06-12 00:07:37.521065
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    f = Formatting(groups=['colors'], env=env)
    h = 'HTTP/2.0 200 OK\r\n' \
        'Access-Control-Allow-Credentials: true\r\n'
    assert h == f.format_headers(h)

# Generated at 2022-06-12 00:07:46.795432
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    fmt = Formatting(["colorize", "format"])
    mime = "application/json"
    content = """{
  "id": 1,
  "name": "A green door",
  "price": 12.5,
  "tags": ["home", "green"]
}"""
    correct_content = """{
  {h1}"id":{h1} 1,
  {h1}"name":{h1} {t}"A green door",
  {h1}"price":{h1} 12.5,
  {h1}"tags":{h1} [
    {t}"home",
    {t}"green"
  ]
}"""
    assert fmt.format_body(content, mime) == correct_content

    # content: "{}"
    content = "{}"
    correct_content = content


# Generated at 2022-06-12 00:07:51.327588
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Arrange
    mime = 'json'
    # Act
    converter = Conversion.get_converter(mime)
    # Assert
    assert converter == None


# Generated at 2022-06-12 00:07:54.807046
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=['json', 'html'])
    assert f.format_body({'obj': True}, 'application/json') == json.dumps({'obj': True})
    assert f.format_body('<html>', 'text/html') == '<html>'

# Generated at 2022-06-12 00:07:56.259982
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    expected = "jpg"
    assert expected == str(Conversion.get_converter("image/jpeg"))

# Generated at 2022-06-12 00:08:00.632356
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    new_Formatting = Formatting(['colors'])
    headers = 'Content-Type: application/json'
    formatted_headers = new_Formatting.format_headers(headers)
    print(formatted_headers)


# Generated at 2022-06-12 00:08:09.258320
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    for tst_mime in ('text/plain','text/html','text/csv', 'text/xml', 
    'application/json', 'application/vnd.api+json', 'application/xml', 
    'application/javascript', 'application/x-javascript', 'application/x-www-form-urlencoded', 
    'application/gzip', 'application/zip'):
        assert is_valid_mime(tst_mime) == True

# Generated at 2022-06-12 00:08:11.331831
# Unit test for constructor of class Formatting
def test_Formatting():
    format_obj = Formatting(groups=["A"], env=Environment())
    assert format_obj.enabled_plugins is not None



# Generated at 2022-06-12 00:08:15.543456
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert converter.mime == mime
    assert converter.type == 'json'
    assert converter.convert({'a':1}) == '''{
    "a": 1
}'''

# Generated at 2022-06-12 00:08:30.009227
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting = Formatting(["formatters_json"])
    body = """
    {"key1": "value1", "key2": "value2", "key3": "value3",
    "key4": "value4", "key5": "value5"}
    """
    test_body = formatting.format_body(body,"application/json")
    assert test_body == body


# Generated at 2022-06-12 00:08:32.738644
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/plain'
    converter = Conversion.get_converter(mime)
    assert converter.content_type == mime


# Generated at 2022-06-12 00:08:37.022165
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    if __name__ == "__main__":
        content = "Hello, world!\n"
        mime = 'text/plain'
        groups = ['colors']
        obj = Formatting(groups)
        assert obj.format_body(content, mime) == "\x1b[39mHello, world!\x1b[39m\n"