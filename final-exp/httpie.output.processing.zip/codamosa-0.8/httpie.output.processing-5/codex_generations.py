

# Generated at 2022-06-11 23:58:48.637061
# Unit test for constructor of class Formatting
def test_Formatting():
    if __name__ != '__main__':
        return
    assert str(Formatting([])) == '<Formatting []>'
    assert str(Formatting(['colors'])) == '<Formatting [colors]>'
    assert str(Formatting(['colors', 'json'])) == '<Formatting [colors, json]>'
    assert str(Formatting(['colors', 'json', 'colors'])) == \
           '<Formatting [colors, json]>'



# Generated at 2022-06-11 23:58:53.848561
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(["Color"])
    print("fmt.enabled_plugins:", fmt.enabled_plugins)
    print("fmt.enabled_plugins[0].enabled:", fmt.enabled_plugins[0].enabled)
    fmt = Formatting(["Color"], show_all=True)
    print("fmt.enabled_plugins:", fmt.enabled_plugins)
    print("fmt.enabled_plugins[0].enabled:", fmt.enabled_plugins[0].enabled)
test_Formatting()

# Generated at 2022-06-11 23:58:56.729511
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.config['format']['colors'] = '1'
    env.config['format'] = False
    formatters = Formatting(['colors'], env)



# Generated at 2022-06-11 23:59:07.182519
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import httpie.plugins
    httpie.plugins.registry.load_builtin_plugins()
    groups = ['colors', 'format']
    env = httpie.context.Environment()
    f = Formatting(groups, env)
    headers = """
    Host: httpbin.org
    User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64
    Accept: */*
    Accept-Language: en-US,en;q=0.5
    Accept-Encoding: gzip, deflate
    Connection: keep-alive
    """

# Generated at 2022-06-11 23:59:08.698314
# Unit test for constructor of class Formatting
def test_Formatting():
    assert isinstance(Formatting([], {}), Formatting)


# Generated at 2022-06-11 23:59:12.068635
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    groups = ["format"]
    body = b"hello"
    mime = "application/json"
    formatting = Formatting(groups, env)
    formatting.format_body(body, mime)

# Generated at 2022-06-11 23:59:12.976083
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(groups=['colors']).enabled_plugins == []



# Generated at 2022-06-11 23:59:19.470556
# Unit test for method format_body of class Formatting

# Generated at 2022-06-11 23:59:22.948423
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    form = Formatting(["json"])
    assert form.format_headers("Json_key: Json_value") == "Json_key: Json_value"
    assert form.format_headers("JSON_key: JSON_value") == "JSON_key: JSON_value"


# Generated at 2022-06-11 23:59:32.914924
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    #Prepare an HTTP response to be tested
    mime = 'application/json'
    #Get the enabled plugins list form the plugin manager
    import httpie.plugins.manager as plugin_manager
    available_plugins = plugin_manager.plugin_manager.get_formatters_grouped()
    env = Environment()
    enabled_plugins = []
    for group in ['pretty']:
        for cls in available_plugins[group]:
            p = cls(env=env)
            if p.enabled:
                enabled_plugins.append(p)
    #Call the method format_headers of the class to test
    format = Formatting(['pretty'], env)
    result = format.format_headers('{\"Authorization\": \"Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ==\"}')

   

# Generated at 2022-06-11 23:59:41.356533
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert not isinstance(Conversion.get_converter('application/csv'), ConverterPlugin)
    assert not isinstance(Conversion.get_converter(''), ConverterPlugin)
    assert not isinstance(Conversion.get_converter('application'), ConverterPlugin)

# Generated at 2022-06-11 23:59:46.112023
# Unit test for constructor of class Formatting
def test_Formatting():
    """Unit test for constructor of class Formatting."""
    test_groups = ['HTTPie', 'ToDo']
    test_mime = 'text/plain'
    test_kwargs = {'env':Environment()}
    assert Formatting(test_groups, **test_kwargs)

test_Formatting()

# Generated at 2022-06-11 23:59:57.137849
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment(colors=256, stdout_isatty=False,
                     styles={})
    formater = Formatting(groups=["colors"], env=env,
                          colors={'status': 'red'})

# Generated at 2022-06-11 23:59:59.395988
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    res = Conversion.get_converter(mime)
    assert res is not None
    assert res.MIME == 'application/json'
    assert res.modifier is None
    assert res.encoding is None



# Generated at 2022-06-12 00:00:04.782014
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    given = "<script>alert('hello')</script>"
    expected = "&lt;script&gt;alert(&apos;hello&apos;)&lt;/script&gt;"
    result = Formatting(["json", "html"]).format_body(given, mime='text/html')
    assert result == expected

# Generated at 2022-06-12 00:00:13.895659
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    s = Formatting()
    assert s.format_headers('Content-Type: application/json') == 'Content-Type: application/json'
    assert s.format_headers('Content-Type: application/json\n') == 'Content-Type: application/json'
    assert s.format_headers('Content-Type: application/json\r\n') == 'Content-Type: application/json'
    assert s.format_headers('Content-Type: application/json\r\n\r\n') == 'Content-Type: application/json\r\n\r\n'
    assert s.format_headers('Content-Type: application/json\r\n\r\n') == 'Content-Type: application/json\r\n\r\n'


# Generated at 2022-06-12 00:00:17.713858
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    data = "Hello, world."
    mime = "text/plain"
    f = Formatting(['format'], env=env)
    s = f.format_body(data, mime)
    assert s == data
    pass

if __name__ == '__main__':
    test_Formatting_format_body()

# Generated at 2022-06-12 00:00:19.416060
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    result = Conversion.get_converter('application/json')
    assert result is not None



# Generated at 2022-06-12 00:00:25.565629
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print(Conversion.get_converter('text/html'))
    print(Conversion.get_converter('application/xml'))
    print(Conversion.get_converter('application/json'))
    print(Conversion.get_converter('application/pdf'))
    print(Conversion.get_converter('text/plain'))
    print(Conversion.get_converter('image/png'))


# Generated at 2022-06-12 00:00:28.003431
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    for group in available_plugins:
        for cls in available_plugins[group]:
            p = cls()
            if p.enabled:
                print("Processor Group: " + group)
                p.format_headers("Date: Sat, 10 Oct 2020 11:05:34 GMT\n")


# Generated at 2022-06-12 00:00:32.429606
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = ''
    groups = ['colors']
    f = Formatting(groups)
    f.format_headers(headers)


# Generated at 2022-06-12 00:00:40.712356
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("text/plain")
    assert(isinstance(converter, ConverterPlugin))
    converter = Conversion.get_converter("text/postscript")  # "text/postscript" is not supported
    assert(converter is None)
    converter = Conversion.get_converter("")  # empty mime type
    assert(converter is None)
    converter = Conversion.get_converter("a/b")
    assert(converter is None)  # "a/b" is not valid mime type but not empty


# Generated at 2022-06-12 00:00:51.697611
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    f = Formatting(['colors'], env=env, scheme='http')
    headers = '''\
HTTP/1.1 200 OK
Server: nginx
Date: Wed, 23 May 2018 14:16:57 GMT
Content-Type: text/html
Content-Length: 144
Last-Modified: Sat, 17 Mar 2018 17:23:48 GMT
Connection: keep-alive
ETag: "5aaafe60-90"
Accept-Ranges: bytes

'''
    out = f.format_headers(headers)
    print(out)  # expected: 'HTTP/1.1 200 OK' colored
    f = Formatting(['colors'], env=env, scheme='http', headers='Server,Date')
    out = f.format_headers(headers)
    print(out)  # expected

# Generated at 2022-06-12 00:00:53.121361
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter

# Generated at 2022-06-12 00:01:03.746935
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class Test:
        """Plugin for testing the method format_headers of class Formatting
        """

        def __init__(self, env=Environment(), **kwargs):
            self.enabled = True

        def format_headers(self, headers: str) -> str:
            return 'test:test' + headers

    test1 = Test()
    test2 = Test()
    test3 = Test()
    test3.enabled = False
    test4 = Test()

    enabled_plugins = [test1, test2, test3, test4]
    assert 'test:testtest:testtest:testtest:test' == enabled_plugins[0].format_headers(
        enabled_plugins[1].format_headers(
            enabled_plugins[2].format_headers(
                enabled_plugins[3].format_headers('test'))))

# Generated at 2022-06-12 00:01:09.987283
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=["MY"])
    assert f.enabled_plugins == []
    f = Formatting(groups=["JSON"])
    assert f.enabled_plugins == []
    f = Formatting(groups=["JSON", "HTML"])
    assert f.enabled_plugins == []
    f = Formatting(groups=["JSON", "HTML", "COLOUR"])
    assert f.enabled_plugins == []


# Generated at 2022-06-12 00:01:18.636383
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.converter.html import HtmlConverter
    from httpie.plugins.converter.image import ImageConverter

    assert isinstance(Conversion.get_converter('text/html'),
                      HtmlConverter)
    assert isinstance(Conversion.get_converter('image/png'),
                      ImageConverter)
    assert isinstance(Conversion.get_converter('image/jpeg'),
                      ImageConverter)
    assert isinstance(Conversion.get_converter('image/webp'),
                      ImageConverter)
    assert isinstance(Conversion.get_converter('image/gif'),
                      ImageConverter)
    assert isinstance(Conversion.get_converter('image/bmp'),
                      ImageConverter)

# Generated at 2022-06-12 00:01:28.467250
# Unit test for constructor of class Formatting
def test_Formatting():
    # create instance of class Formatting
    formatting = Formatting(groups=['httpie', 'curl'], env=Environment())
    assert len(formatting.enabled_plugins) == 0

    # create instance of class Formatting
    formatting = Formatting(groups=['httpie', 'curl'], env=Environment(), style='green')
    assert len(formatting.enabled_plugins) == 2
    assert formatting.enabled_plugins[0].style.name == 'green'

    try:
        # create instance of class Formatting
        Formatting(groups=['httpie', 'curl', 'junk'], env=Environment(), style='green')
    except Exception as error:
        assert str(error) == 'Invalid processor group: junk'



# Generated at 2022-06-12 00:01:30.499939
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting = Formatting(groups=['colors'])
    print(formatting.format_body('[]', 'application/json'))



# Generated at 2022-06-12 00:01:40.144478
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json').supports('application/json')
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/xml').supports('application/xml')
    assert is_valid_mime(Conversion.get_converter('application/json').mime)
    assert is_valid_mime(Conversion.get_converter('application/xml').mime)

    assert Conversion.get_converter('json') is None
    assert Conversion.get_converter('xml') is None
    assert not is_valid_mime(Conversion.get_converter('json'))

# Generated at 2022-06-12 00:01:52.196477
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting()
    assert f.format_body("""  123  """, "text/plain") == "  123  "
    assert f.format_body("""  123  """, "application/json") == "  123  "
    #
    f = Formatting(['json'])
    assert f.format_body("""  123  """, "text/plain") == "  123  "
    assert f.format_body("""  123  """, "application/json") == "  123  "
    #
    f = Formatting(['prettify'])
    assert f.format_body("""  123  """, "text/plain") == "  123  "
    assert f.format_body("""  123  """, "application/json") == "123"
    #
    f = Formatting

# Generated at 2022-06-12 00:01:54.037249
# Unit test for constructor of class Formatting
def test_Formatting():
    a = Formatting(["pretty"], env=Environment())
    assert a.enabled_plugins[0].__class__.__name__ == "PrettyPlugin"

# Generated at 2022-06-12 00:02:03.880776
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # input parameter: headers
    headers = """HTTP/1.1 200 OK
Content-Length: 12
Content-Type: text/html
Date: Sun, 12 Jun 2016 16:46:15 GMT
Server: Apache/2.4.12 (Win64) OpenSSL/1.0.1m PHP/5.6.8
X-Powered-By: PHP/5.6.8

"""
    # expected output:
    expected_headers = """HTTP/1.1 200 OK
Content-Length: 12
Content-Type: text/html
Date: Sun, 12 Jun 2016 16:46:15 GMT
Server: Apache/2.4.12 (Win64) OpenSSL/1.0.1m PHP/5.6.8
X-Powered-By: PHP/5.6.8

"""
    # invoke processing

# Generated at 2022-06-12 00:02:14.085416
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """
    测试 Formatting 类中 format_headers 方法
    :return:
    """
    env = Environment()

# Generated at 2022-06-12 00:02:27.071214
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    Test method format_body of class Formatting.
    """
    class json_converter(ConverterPlugin):
        """
        Test converter plugin.
        """

        @staticmethod
        def supports(mime: str) -> bool:
            """Overrides the method supports in parent class."""
            return mime == "application/json"


        @staticmethod
        def encode(data, mime) -> str:
            """Overrides the method encode in parent class."""
            return ""

        @staticmethod
        def decode(data, mime) -> str:
            """Overrides the method decode in parent class."""
            return ""

    class json_formatter(ConverterPlugin):
        """
        Test formater plugin.
        """


# Generated at 2022-06-12 00:02:28.804209
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["pretty", "colors"]
    Formatting(groups, True)
    Formatting(groups, False)

# Generated at 2022-06-12 00:02:30.993619
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    target_mime_type = "application/json"
    matched_converter = Conversion.get_converter(target_mime_type)
    assert matched_converter.name == "json_converter"

# Generated at 2022-06-12 00:02:37.660757
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    mime_bmp = "image/bmp"
    mime_jpeg = "image/jpeg"
    mime_png = "image/png"

    assert (Conversion.get_converter(mime_bmp).mime == mime_bmp)
    assert (Conversion.get_converter(mime_jpeg).mime == mime_jpeg)
    assert (Conversion.get_converter(mime_png).mime == mime_png)

# Generated at 2022-06-12 00:02:43.501693
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_content = '{"id": 1, "name": "x"}'
    test_mime = 'application/json'
    formatting = Formatting(groups = ['format'])
    #print(formatting)
    result = formatting.format_body(test_content, test_mime)
    #print(result)
    assert result == '{\n    "id": 1,\n    "name": "x"\n}\n'

# Generated at 2022-06-12 00:02:47.193228
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    fmt = Formatting(['colors'])
    print(fmt.format_body('[{"id":1,"name":"John","age":31}]', 'application/json'))


if __name__ == "__main__":
    test_Formatting_format_body()

# Generated at 2022-06-12 00:02:53.469198
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    result = Formatting([]).format_headers('HTTP/1.1 200 OK\nHeader: Value')
    result = result.decode()
    assert(result == 'HTTP/1.1 200 OK\nHeader: Value')


# Generated at 2022-06-12 00:02:56.210917
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    if is_valid_mime('application/json'):
        for converter_class in plugin_manager.get_converters():
            if converter_class.supports('application/json'):
                converter_class('application/json')

# Generated at 2022-06-12 00:03:02.933061
# Unit test for constructor of class Formatting
def test_Formatting():
    # test with no plugins
    f = Formatting(groups=[])
    assert len(f.enabled_plugins) == 0
    # test with all plugins
    f = Formatting(groups=['json', 'xml', 'html'])
    assert len(f.enabled_plugins) == 3
    # test with one invalid plugin
    f = Formatting(groups=['json', 'invalid'])
    assert len(f.enabled_plugins) == 0


# Generated at 2022-06-12 00:03:06.904014
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment(colors=256)
    groups = ["colors"]
    fmt = Formatting(groups, env)
    print(fmt.enabled_plugins)
    assert fmt.enabled_plugins[0].__class__.__name__ == "ColorsFormatter"

# Generated at 2022-06-12 00:03:17.809871
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test for constructor with a list of strings
    list_of_strings = ['nocolor', 'iterable', 'colors']
    format_test = Formatting(list_of_strings)
    new_list = []
    for i in format_test.enabled_plugins:
        new_list.append(i.NAME)
    assert new_list == ['nocolor', 'iterable', 'colors']
    # Test for constructor with a list of integers
    integer_list = [1, 2, 3]
    format_test = Formatting(integer_list)
    new_list = []
    for i in format_test.enabled_plugins:
        new_list.append(i.NAME)
    assert new_list == []
    # Test for constructor with a list of floats

# Generated at 2022-06-12 00:03:20.480488
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin import JSONConverter

    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert isinstance(converter, JSONConverter)



# Generated at 2022-06-12 00:03:25.416397
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from .formatter.json import JSONFormatterPlugin
    f = Formatting(['json'], style='monokai')
    assert f.format_body("""{"name": "snowman", "age": 23}""", 'application/json').strip() == """[json]
{
    "age": 23,
    "name": "snowman"
}
"""

# Generated at 2022-06-12 00:03:35.797587
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test that the headers are formatted correctly
    env = Environment()
    groups = ["colors"]
    headers = "HTTP/1.1 200 OK" \
              "Connection: close" \
              "Server: nginx/1.10.2 (Ubuntu)" \
              "Date: Fri, 16 Oct 2020 18:11:10 GMT" \
              "Content-Type: application/json; charset=utf-8" \
              "Content-Length: 24" \
              "Access-Control-Allow-Origin: *" \
              "Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept" \
              "Access-Control-Allow-Methods: GET, PATCH, PUT, POST, DELETE, OPTIONS" \
              "X-Content-Type-Options: nosniff" \
             

# Generated at 2022-06-12 00:03:42.611606
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_class1 = Formatting(['colors'], color_scheme={'body': 'red'})
    test_class2 = Formatting(['colors'], color_scheme={'body': 'blue'})
    assert test_class1.format_body("body", None) == "\033[31mbody\033[39m"
    assert test_class2.format_body("body", None) == "\033[34mbody\033[39m"
    assert test_class1.format_body("body", 'image/png') == "body"
    assert test_class2.format_body("body", 'image/png') == "body"
    assert test_class1.format_body("body", 'application/json') == "\033[31m\"body\"\033[39m"

# Generated at 2022-06-12 00:03:52.838561
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = [
        'HTTP/1.1 301 Moved Permanently\r\n',
        'Content-Type: text/html; charset=UTF-8\r\n',
        'Cache-Control: no-cache\r\n',
        'Content-length: 0\r\n',
        'Location: https://www.google.com/\r\n'
    ]
    groups = ["colors"]
    env = Environment()
    body_formatting = Formatting(groups, env)

# Generated at 2022-06-12 00:04:05.934867
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    '''
    :return: This method returns a boolean value depending on the test result.

    '''

    # Test case where one of the formatter enabled is cls_dict['Pretty']
    class DummyPlugin:
        def __init__(self, **kwargs):
            self.enabled = True

        def format_headers(self, headers: str) -> str:
            return headers

        def format_body(self, content: str, mime: str) -> str:
            return content

    class DummyPlugin2:
        def __init__(self, env=Environment(), **kwargs):
            self.enabled = True
            self.env = env

        def format_headers(self, headers: str) -> str:
            return headers

        def format_body(self, content: str, mime: str) -> str:
            return

# Generated at 2022-06-12 00:04:14.149280
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['color'])
    print(f.format_body('{"name": "Apple", "color": "Red", "food": "Fruit"}', 'application/json'))
    print(f.format_body('<name>Apple</name><color>Red</color><food>Fruit</food>', 'application/xml'))
    print(f.format_body('<!DOCTYPE html><p>Apple</p>', 'text/html'))
    print(f.format_body('Not to be formatted', 'text/plain'))
    print(f.format_body('Not to be formatted', 'application/octet-stream'))


# Generated at 2022-06-12 00:04:15.401267
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting = Formatting(groups=['colors'])
    assert formatting


# Generated at 2022-06-12 00:04:17.365722
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert isinstance(converter, ConverterPlugin)

# Generated at 2022-06-12 00:04:22.694139
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print("\n\ntest_Formatting_format_body:")
    content = '{"name": "My Name"}'
    mime = 'application/json'
    print(Formatting(groups=['colors'], env=Environment()).format_body(content, mime))
    assert Formatting(groups=['colors'], env=Environment()).format_body(content, mime) == '{\n    "name": "My Name"\n}'


# Generated at 2022-06-12 00:04:32.673506
# Unit test for constructor of class Formatting
def test_Formatting():
    import httpie
    httpie.context.COLOR = False
    httpie.plugins.registry.load_available_plugins()
    env = httpie.context.Environment(colors=False, stdout_isatty=False)
    # Available plugins: ANSI, JSONPointer, JSONQuery, Pretty
    formatting = Formatting(groups=['ANSI', 'JSONPointer', 'JSONQuery', 'Pretty'], env=env)
    assert len(formatting.enabled_plugins) == 1
    assert formatting.enabled_plugins[0].name == "Pretty"

    formatting = Formatting(groups=['Pretty'], env=env)
    assert len(formatting.enabled_plugins) == 1
    assert formatting.enabled_plugins[0].name == "Pretty"


# Generated at 2022-06-12 00:04:41.595438
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    data = {'headers': 'HTTP/1.1 200 OK\r\nServer: nginx/1.0.0\r\nDate: Mon, 01 Jan 2012 00:00:00 GMT\r\nContent-Type: text/html\r\nContent-Length: 4'}
    f = Formatting(groups=['syntax'])
    formated = f.format_headers(data['headers'])
    assert formated == '\033[38;5;244mHTTP/1.1 200 OK\033[39;49m\n' \
                        'Server: nginx/1.0.0\n' \
                        'Date: Mon, 01 Jan 2012 00:00:00 GMT\n' \
                        'Content-Type: text/html\n' \
                        'Content-Length: 4'



# Generated at 2022-06-12 00:04:43.144377
# Unit test for constructor of class Formatting
def test_Formatting():
	formatting = Formatting(['colors'])
	assert True

# Generated at 2022-06-12 00:04:54.473679
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins import builtin
    from httpie.plugins.registry import plugin_manager
    from httpie import exitstatus
    # Available formats, to be selected by the user.
    available_groups = plugin_manager.get_formatters_grouped()
    environments = [Environment(stdin=None, stdout=None, stderr=None,
                                is_windows=(sys.platform == 'win32'),
                                colors=256,
                                verify=True,
                                stream=False,
                                output_options=None,
                                config_dir=None,
                                config_file=None,
                                env=None)]
    print(environments)

# Generated at 2022-06-12 00:04:56.140756
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    formatting = Formatting(env=env)
    assert formatting.format_headers("Content-Type: application/json") == "Content-Type: application/json"



# Generated at 2022-06-12 00:05:04.759496
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)

    assert converter.mime == mime
    assert converter.name == 'json'
    assert converter.title == 'JSON'
    assert converter.supports(mime)
    assert converter.supports_output(mime) is False
    assert converter.can_decode('{"foo": "bar"}') is True

# Generated at 2022-06-12 00:05:07.571731
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.supports('application/json') == True
    assert converter.supports('text/plain') == False


# Generated at 2022-06-12 00:05:08.785286
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(groups=['tests'])

# Generated at 2022-06-12 00:05:19.099802
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import FormatterPlugin
    an_anchor = FormatterPlugin(env=Environment(), attr2='value2')
    an_anchor.anchor = "unit_test_object"

    an_anchor2 = FormatterPlugin(env=Environment(), attr2='value2')
    an_anchor2.anchor = "unit_test_object"

    an_object = Formatting(groups=['A', 'B'], env=Environment(), attr1='value1')
    an_object.enabled_plugins.append(an_anchor)
    an_object.enabled_plugins.append(an_anchor2)

    assert an_anchor.anchor == "unit_test_object"  # Test data passed in

# Generated at 2022-06-12 00:05:21.145188
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert 'application/json' == converter.mimetype


# Generated at 2022-06-12 00:05:24.557792
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/javascript')
    assert converter.mime == 'application/javascript'


# Generated at 2022-06-12 00:05:27.766847
# Unit test for constructor of class Formatting
def test_Formatting():
    groups: List[str] = ['colors']
    env = Environment()
    kwargs = {}
    Formatting(groups, env, **kwargs)
    assert True


# Generated at 2022-06-12 00:05:37.548520
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import httpie.plugins
    import httpie.plugins._formatter_plugins
    import httpie.plugins._formatter_plugins.json

    httpie.plugins._formatter_plugins.json.supported_mime = ['application/json',
                                                             'application/geojson']

    httpie.plugins._formatter_plugins.json.converter = None
    httpie.plugins._formatter_plugins.json.indent = 2
    httpie.plugins._formatter_plugins.json.colors = None


# Generated at 2022-06-12 00:05:40.083039
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_type = "application/json"
    converter = Conversion.get_converter(mime_type)
    assert converter is not None
    assert converter.MIME == mime_type


# Generated at 2022-06-12 00:05:45.235745
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print("\n Start Unit test for method format_headers of class Formatting")
    s = "content-type: application/json\r\n"
    f = Formatting(['colors'])
    print(f.format_headers(s))

    s = "content-type: application/xml\r\n"
    f = Formatting(['colors'])
    print(f.format_headers(s))



# Generated at 2022-06-12 00:05:58.091633
# Unit test for constructor of class Formatting
def test_Formatting():
    print('\nUnit test for constructor of class Formatting')
    # Case 1: MIME type is supported

    env = Environment()
    env.colors = False
    groups = ['colors']
    json_body = '{"args":{},"headers":{"Host":"httpbin.org","User-Agent":"HTTPie/1.0.2","Accept-Encoding":"gzip, deflate","Accept":"application/json, */*","Connection":"keep-alive"},"origin":"1.1.1.1","url":"https://httpbin.org/get"}'
    formatting = Formatting(groups, env, kwargs)

# Generated at 2022-06-12 00:06:03.677208
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    input1 = 'text/html'
    output1 = Conversion.get_converter(input1).mime.get_primary()
    assert output1 == 'text', 'Expected "text", got ' + str(output1)

    input2 = 'text/plain'
    output2 = Conversion.get_converter(input2)
    assert output2 == None, 'Expected "None", got ' + str(output2)

# Generated at 2022-06-12 00:06:12.019502
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-12 00:06:14.157254
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=[])
    assert f.format_body('{"test": "test_content"}', mime='application/json') == '{"test": "test_content"}'

# Generated at 2022-06-12 00:06:23.519793
# Unit test for constructor of class Formatting
def test_Formatting():
    p1 = Formatting(['headers'])
    p2 = Formatting(['headers'], ignore_lines=3)
    p3 = Formatting(['headers', 'json'])
    p4 = Formatting(['headers', 'json'], ignore_lines=3,
                    json_indent=4, json_sort_keys=True)
    p5 = Formatting(['headers', 'json'], ignore_lines=3,
                    json_indent=4, json_sort_keys=False)
    p6 = Formatting(['headers', 'json'], ignore_lines=3,
                    json_indent=2, json_sort_keys=True)
    p7 = Formatting(['headers', 'json'], ignore_lines=3,
                    json_indent=2, json_sort_keys=False)
    p

# Generated at 2022-06-12 00:06:32.576705
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1: Valid mime
    mime = "application/json"
    if is_valid_mime(mime):
        for converter_class in plugin_manager.get_converters():
            if converter_class.supports(mime):
                assert converter_class(mime) is not None
    # Test case 2: Invalid mime
    mime = "applicatio/json"
    if not is_valid_mime(mime):
        for converter_class in plugin_manager.get_converters():
            assert not converter_class.supports(mime)
            assert converter_class(mime) is None

# Generated at 2022-06-12 00:06:34.222614
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    response = Conversion.get_converter('application/json')
    assert response is not None



# Generated at 2022-06-12 00:06:40.220314
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_env = Environment()
    test_env.colors = True
    test_env.stdout_isatty = True
    test_env.is_windows = False
    formatting_obj = Formatting(['colors'],env=test_env)
    assert formatting_obj.format_body('{"status":"OK"}',mime='application/json') == '{\x1b[32m"status"\x1b[39m:\x1b[33m"OK"\x1b[39m}'



# Generated at 2022-06-12 00:06:46.691181
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    expected_output = {'application/json': 'HTTPieJSONppFormatter',
                       'application/xml': 'HTTPieJSONppFormatter',
                       'text/html': 'HTTPieHTMLFormatter',
                       'text/plain': 'HTTPieHTMLFormatter'}

    for mime, expected_output_class in expected_output.items():
        output = Conversion.get_converter(mime).__class__.__name__
        assert output == expected_output_class



# Generated at 2022-06-12 00:06:49.485118
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # create a Formatting instance
    f1 = Formatting(["headers"])
    # create a str variable
    s = ''
    # test
    assert f1.format_headers(s) == s



# Generated at 2022-06-12 00:07:01.053817
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print(Conversion.get_converter("application/json"))
    print(Conversion.get_converter("text/markdown"))
    print(Conversion.get_converter("app/json"))
    print(Conversion.get_converter("text/html"))
    print(Conversion.get_converter("app/html"))
    print(Conversion.get_converter("json"))


# Generated at 2022-06-12 00:07:03.044222
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/plain'
    converter = Conversion.get_converter(mime)
    assert converter.mime == mime

# Generated at 2022-06-12 00:07:08.536975
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert(Conversion.get_converter("text/plain") is not None)
    assert(Conversion.get_converter("application/json") is not None)
    assert(Conversion.get_converter("application/xml") is not None)
    assert(Conversion.get_converter("application/bash") is not None)
    assert(Conversion.get_converter("application/javascript") is not None)

# Generated at 2022-06-12 00:07:13.102565
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test data
    mime = 'application/json'
    converter = Conversion.get_converter(mime)

    # Asserts
    assert 'JsonConverter' == converter.__class__.__name__



# Generated at 2022-06-12 00:07:19.708626
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # given
    pass
#     content = b'{"StatusCode":401,"Message":"Wrong email or password"}'
#     mime = 'application/json'
#     formatting = Formatting(groups=['colors'], env=Environment())
#     # when
#     formatted_content = formatting.format_body(content, mime)
#     # then
#     assert formatted_content == """\
# {
#     "StatusCode": 401,
#     "Message": "Wrong email or password"
# }"""
#
#
# def test_Formatting_format_body_does_not_format_binary_content():
#     # given
#     content = b'\x00\x01\x02\x03\x04\x05\x06\x07'
#     mime = 'application/octet

# Generated at 2022-06-12 00:07:24.754374
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting(["ansi"]).format_body("<html></html>", "text/html") == "@ESC[7m<html></html>@ESC[27m"
    assert Formatting(["ansi"]).format_body("<html></html>", "text/plain") == "<html></html>"



# Generated at 2022-06-12 00:07:30.534859
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    content = 'hello'
    mime = 'text/plain'
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.config = ConfigObject()
    env.config.color = True    
    Formatting(groups, env).format_body(content, mime)
    Formatting(groups, env).format_headers(content)

# Generated at 2022-06-12 00:07:33.267468
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.supports('application/json')
    c = converter.loads('{}')
    assert c is not None

# Generated at 2022-06-12 00:07:36.595638
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '{"key1":"value1", "key2":"value2"}'
    mime = 'application/json'
    formatting = Formatting(['colors'])
    print(formatting.format_body(content, mime))


# Generated at 2022-06-12 00:07:46.222649
# Unit test for constructor of class Formatting
def test_Formatting():
    #Given
    xml_string = """<?xml version="1.0" ?>
        <Root xmlns:h="http://www.w3.org/TR/html4/"
              xmlns:f="https://www.w3schools.com/furniture">

          <h:table>
            <h:tr>
              <h:td>Apples</h:td>
              <h:td>Bananas</h:td>
            </h:tr>
          </h:table>

          <f:table>
            <f:name>African Coffee Table</f:name>
            <f:width>80</f:width>
            <f:length>120</f:length>
          </f:table>

        </Root>
    """

    #When
    f = Formatting(['xml'])

# Generated at 2022-06-12 00:07:57.893122
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('rongmime') is None
    assert Conversion.get_converter('') is None


# Generated at 2022-06-12 00:08:07.026197
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print('\nTesting format_body()...')
    fo = Formatting(['color'])
    print(fo.format_body('<hello>world</hello>', 'xml'))
    fo = Formatting(['solarized'])
    print(fo.format_body('<hello>world</hello>', 'xml'))
    fo = Formatting(['color', 'indent'])
    print(fo.format_body('<hello>world</hello>', 'xml'))
    fo = Formatting(['color', 'indent', 'solarized'])
    print(fo.format_body('<hello>world</hello>', 'xml'))


# Generated at 2022-06-12 00:08:16.866343
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Case that content is not empty, but mime is empty
    a = Formatting(['colors'])
    assert(a.format_body("hello","") == "")
    assert(a.format_body("", "") == "")
    # Case that both content and mime are empty
    a = Formatting(['colors'])
    assert(a.format_body("hello","text/plain") == "\x1b[38;5;241mhello\x1b[0m")
    assert(a.format_body("", "text/plain") == "")
    # Case that both content and mime are not empty
    a = Formatting(['colors'])
    assert(a.format_body("hello","html") == "\x1b[38;5;241mhello\x1b[0m")


# Generated at 2022-06-12 00:08:23.343333
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPieJSONPlugin
    from httpie.plugins.builtin import HTTPiePrettyJSONPlugin
    instance = Formatting(groups=['json'], env=Environment())
    assert (instance.enabled_plugins[0].__class__ == HTTPieJSONPlugin) or \
           (instance.enabled_plugins[0].__class__ == HTTPiePrettyJSONPlugin)
    assert (instance.enabled_plugins[1].__class__ == HTTPieJSONPlugin) or \
           (instance.enabled_plugins[1].__class__ == HTTPiePrettyJSONPlugin)

# Generated at 2022-06-12 00:08:31.345009
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    def test_header(header, expected_head):
        groups = ['colors', 'format']
        formatting = Formatting(groups)
        formatted_headers = formatting.format_headers(header)
        assert formatted_headers == expected_head
    # test small dict
    test_header('{\n  "foo": "bar"\n}\n', '\x1b[32m{\x1b[39m\n  \x1b[32m"foo"\x1b[39m: \x1b[32m"bar"\x1b[39m\n\x1b[32m}\x1b[39m\n')
    # test big dict

# Generated at 2022-06-12 00:08:38.174165
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    input = """HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Content-Length: 19

"""
    output = Formatting(['colors']).format_headers(input)
    assert output == "\x1b[32mHTTP/1.1 200 OK\x1b[39m\n\x1b[37mContent-Type: application/json; charset=utf-8\x1b[39m\n\x1b[37mContent-Length: 19\x1b[39m\n\n"