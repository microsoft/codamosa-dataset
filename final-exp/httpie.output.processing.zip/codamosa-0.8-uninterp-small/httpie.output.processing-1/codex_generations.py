

# Generated at 2022-06-25 18:49:34.122130
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting([], Environment()).format_body('{}', 'application/json') == '{}'


# Generated at 2022-06-25 18:49:36.779759
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting = Formatting(groups=[], env = Environment(), **{})
    assert isinstance(formatting, Formatting)
    assert formatting.enabled_plugins == []


# Generated at 2022-06-25 18:49:38.511818
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    assert conversion_1.get_converter(None) == None


# Generated at 2022-06-25 18:49:41.663720
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting('formatting')

# Generated at 2022-06-25 18:49:43.406564
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    assert conversion_0.get_converter('*/*') is None


# Generated at 2022-06-25 18:49:47.402654
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    conversion_0 = Conversion()
    assert(conversion_0.get_converter(mime) != None)
    mime = 'application/json+json'
    assert(conversion_0.get_converter(mime) == None)


# Generated at 2022-06-25 18:49:54.516689
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["test_group"]
    env = Environment()
    formatting = Formatting(groups, env)
    assert formatting

import httpie.output
from httpie.output.formatters.colors import COLOR_PALETTE_SESSION_LEVEL

from tests.fixtures import (
    COLOR,
    COLOR_RESET,
    JSON_SORTED,
    JSON_SORTED_ITEMS,
    JSON_SORTED_STR,
)

import httpie

from httpie.cli import parse_items
from httpie.output.formatters.colors import get_lexer

from httpie.output.formatters.utils import get_prettifier_for



# Generated at 2022-06-25 18:49:57.629031
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion = Conversion()
    converter = conversion.get_converter(mime='application/json')
    assert(converter.name =='json')



# Generated at 2022-06-25 18:50:06.418378
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    for i in range(0,10):
        if(i==3):
            conversion_0 = Conversion()
            mime = "text/html"
            assert Conversion.get_converter(mime) is None

        # case 0
        elif(i==0):
            conversion_0 = Conversion()
            mime = "application/json"
            assert not Conversion.get_converter(mime) is None

        # case 1
        elif(i==1):
            conversion_0 = Conversion()
            mime = "application/xml"
            assert not Conversion.get_converter(mime) is None

        # case 2
        elif(i==2):
            conversion_0 = Conversion()
            mime = "application/json"
            assert not Conversion.get_converter(mime) is None

# Generated at 2022-06-25 18:50:07.650522
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])


# Generated at 2022-06-25 18:50:13.247822
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    assert conversion_0.get_converter('application/json') is not None
    assert conversion_0.get_converter('application/xml') is not None
    assert conversion_0.get_converter('text/vnd.yaml') is not None


# Generated at 2022-06-25 18:50:15.733722
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_obj = Conversion()
    assert(conversion_obj.get_converter('application/json') is not None)
    assert(conversion_obj.get_converter('application/xml') is None)


# Generated at 2022-06-25 18:50:17.050848
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    Formatting(['Pygments'], PygmentsFormatter.ENV_KEYS,
                style='autumn', color=False, bg='dark')

# Generated at 2022-06-25 18:50:18.712250
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    assert conversion_1.get_converter('text/html') == None


# Generated at 2022-06-25 18:50:21.320310
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    converter_0 = conversion_0.get_converter('text/html')
    converter_1 = conversion_0.get_converter('NoSuchType')



# Generated at 2022-06-25 18:50:32.525917
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment(stdout=BytesIO(), stdin=BytesIO())
    headers = 'HTTP/1.1 200 OK\r\nServer: nginx/1.10.3\r\nDate: Tue, 24 Jul 2018 11:21:16 GMT\r\nContent-Type: application/json\r\nContent-Length: 2\r\nConnection: keep-alive\r\nVary: Accept-Encoding\r\nX-Powered-By: Express\r\nETag: W/"2-L4vLX9eDLsCuI7rHj6b5Q0g"\r\n\r\n{}'
    result = Formatting(['colors'], env).format_headers(headers)

# Generated at 2022-06-25 18:50:38.523688
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = []
    Formatting(groups, env)
    groups = ['format_pretty']
    Formatting(groups, env)
    groups = ['format_pretty', 'format_cconv']
    Formatting(groups, env)
    groups = ['format_pretty', 'format_cconv', 'format_colors']
    Formatting(groups, env)


# Generated at 2022-06-25 18:50:46.983393
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import json
    from httpie.plugins.builtin import JSONFormatter

    test_dict = {'date': 'Thu, 21 Apr 2016 06:21:33 GMT', 'content-type': 'text/plain', 'transfer-encoding': 'chunked'}
    test_str_dict = str(test_dict).replace("'", '"')
    headers_to_format = json.loads(test_str_dict)

    env = Environment()
    formatting_0 = Formatting(['JSON'], env)
    formatted_headers = formatting_0.format_headers(headers = headers_to_format)
    assert formatted_headers == JSONFormatter.to_json(headers_to_format, env)

# Generated at 2022-06-25 18:50:58.125764
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    args = ['pretty']
    headers = b'content-type: application/json\n\n'
    content_type = b'application/json'
    from os import getcwd
    from httpie.plugins import plugin_manager
    from httpie.plugins.registry import plugin_manager as plugin_manager
    from httpie.context import Environment


    # Here we have added one pretty plugins
    plugin_manager.importer.load_dir(dirs=[getcwd() + '/httpie/plugins/pretty'])
    # Instantiating a formatting object
    formatting_obj = Formatting(groups=args)
    # Printing out the list of plugins in the pretty group
    print(plugin_manager.get_formatters_grouped()[args[0]])
    # Printing out the available plugins

# Generated at 2022-06-25 18:51:03.301513
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(groups=['colors'])
    result_0 = formatting_0.format_headers('HTTP/2 200 OK\nText')
    assert result_0 == '\x1b[1m\x1b[32mHTTP/2 200 OK\x1b[39m\x1b[22m\nText'
    

# Generated at 2022-06-25 18:51:08.381284
# Unit test for constructor of class Formatting
def test_Formatting():
    formatter = Formatting(['colors'])
    assert len(formatter.enabled_plugins) == 1
    assert formatter.enabled_plugins[0].__class__.__name__ == 'Colors'

# Unit Testing for format_headers

# Generated at 2022-06-25 18:51:10.979576
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting([], Environment())



# Generated at 2022-06-25 18:51:16.056537
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_case_1 = Formatting()
    print("original headers: [Content-Type: application/json]")
    print("formatted header:", test_case_1.format_headers("Content-Type: application/json"))
    print("expect:", "Content-Type: application/json")


# Generated at 2022-06-25 18:51:26.753328
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pass
    # Need to initialize Formatting class.
    # Need to pass a list of plugin names to be applied
    output = Formatting(['colors', 'format'])
    input = """
    "Public-Key-Pins-Report-Only":
    "{\"report_only\":{\"pins\":[{\"sha256\":\"wHiTeLiSt\",\"max_age\":6325,\"include_subdomains\":true,\"report_uri\":\"https://report-uri.io/\"},{\"sha256\":\"YXNkZg\",\"max_age\":6325,\"include_subdomains\":true,\"report_uri\":\"https://report-uri.io/\"}],\"report_to\":\"https://report-uri.io/\",\"max_age\":6325}}",
    """
    # Input sample from https

# Generated at 2022-06-25 18:51:34.469413
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case: long_option
    env = Environment()
    env.stdout.isatty()
    env.stdout.encoding = 'utf8'
    fmt = Formatting(['colors'], env)

# Generated at 2022-06-25 18:51:38.682091
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(['colors'])
    assert formatting_0.format_headers("Content-Length: 178\r\nContent-Type: text/plain\r\n") == 'Content-Length: 178\nContent-Type: text/plain\n'



# Generated at 2022-06-25 18:51:44.500064
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors', 'unicode']
    formatting = Formatting(groups)
    headers = '''
    HTTP/1.1 200 OK
    Date: Mon, 27 Jul 2009 12:28:53 GMT
    Server: Apache/2.2.14 (Win32)
    Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
    Content-Length: 88
    Content-Type: text/html

    '''
    result = formatting.format_headers(headers)
    print(result)


# Generated at 2022-06-25 18:51:50.113465
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    input_body = "FILE CONTENT"
    input_mime = "text/plain"
    instance = Formatting(groups=[])
    conversion_0 = Conversion.get_converter(input_mime)
    if conversion_0 is None:
        expected_output = input_body
    else:
        expected_output = conversion_0.to_html(input_body)
    actual_output = instance.format_body(input_body, input_mime)
    assert actual_output == expected_output

# Generated at 2022-06-25 18:51:52.793054
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    mime_0 = 'text/html'
    value_0 = conversion_0.get_converter(mime_0)
    assert value_0 is not None


# Generated at 2022-06-25 18:51:57.179730
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """Unit test for method Formatting.format_body."""
    env = Environment()
    try:
        format_body = Formatting().format_body
        assert(format_body("sample content", "text/plain") is not None)
    except Exception as e:
        print(e)
        env.log.error('Assertion error: ', exc_info=True)


# Generated at 2022-06-25 18:52:01.686280
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting()
    formatting_0.format_body(content="", mime="")


# Generated at 2022-06-25 18:52:03.397818
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_obj_0 = Formatting()
    test_obj_0.format_headers("headers")


# Generated at 2022-06-25 18:52:13.743133
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    assert conversion_0.get_converter('application/json') == None
    assert conversion_0.get_converter('application/x-javascript') == None
    assert conversion_0.get_converter('text/javascript') == None
    assert conversion_0.get_converter('text/x-python') == None
    assert conversion_0.get_converter('text/python') == None
    assert conversion_0.get_converter('text/x-shellscript') == None
    assert conversion_0.get_converter('text/shellscript') == None
    assert conversion_0.get_converter('text/x-php') == None
    assert conversion_0.get_converter('text/php') == None
    assert conversion_0.get_conver

# Generated at 2022-06-25 18:52:16.132471
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(['highlighting', 'colors'])
    assert '\x1b[39m' == formatting_0.format_headers("HTTP/2 200\r\n\r\n")

# Generated at 2022-06-25 18:52:16.918406
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    pass


# Generated at 2022-06-25 18:52:18.505630
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = Formatting(groups=['colors']).format_headers("test")
    assert headers == 'test'


# Generated at 2022-06-25 18:52:29.200406
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1: default value of mime is 'application/json'
    db = []
    json_converter = Conversion.get_converter(db)
    assert json_converter.supports('application/json')
    content = '{"id": "123123", "name": "timedog", "age": 1}'
    assert json_converter.convert(content) == {'id': '123123', 'name': 'timedog', 'age': 1}

    # Test case 2: mime is 'application/xml'
    db = []
    xml_converter = Conversion.get_converter('application/xml')
    assert xml_converter.supports('application/xml')

# Generated at 2022-06-25 18:52:30.197268
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting()

# Generated at 2022-06-25 18:52:32.895748
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting = Formatting(['colors'])
    assert formatting.format_headers("Test Header") == "\x1b[1mTest Header\x1b[0m"

# Generated at 2022-06-25 18:52:34.418101
# Unit test for constructor of class Formatting
def test_Formatting():
    test_Formatting_0()
    #test_Formatting_1()

# Positive test case

# Generated at 2022-06-25 18:52:38.520731
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:52:43.153384
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = "HTTP/1.1 200 OK\nDate: Thu, 01 Jan 1970 01:01:01 GMT\nContent-Type: application/json"
    obj_0 = Formatting(['lorem', 'ipsum'])
    str_1 = obj_0.format_headers(str_0)
    return str_1


# Generated at 2022-06-25 18:52:44.474164
# Unit test for constructor of class Formatting
def test_Formatting():
    format_headers = Formatting()
    format_body = Formatting()


# Generated at 2022-06-25 18:52:48.166212
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups_1 = []
    env_1 = Environment()
    formatting_1 = Formatting(groups_1, env_1)
    str_1 = '{}'
    str_2 = 'application/json'
    formatting_1.format_body(str_1, str_2)


# Generated at 2022-06-25 18:52:56.377626
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    Formatting_instance = Formatting()

# Generated at 2022-06-25 18:52:58.764842
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(None)
    optional_1 = conversion_0.get_converter('application/json')


# Generated at 2022-06-25 18:53:08.698047
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = ['HTTP_HEADERS']
    formatting_0 = Formatting(groups_0)
    str_0 = 'HTTP/1.1 200 OK\nContent-Length: 0\nContent-Type: application/json\nConnection: keep-alive\nServer: nginx\n\n'
    str_1 = formatting_0.format_headers(str_0)
    assert str_1 == 'HTTP/1.1 200 OK\nContent-Length: 0\nContent-Type: application/json\nConnection: keep-alive\nServer: nginx\n'


# Generated at 2022-06-25 18:53:15.799370
# Unit test for constructor of class Formatting
def test_Formatting():
    environment_0 = Environment()
    list_0 = []
    formatting_0 = Formatting(list_0, environment_0)
    assert not hasattr(formatting_0, 'str_0')
    assert not hasattr(formatting_0, 'str_1')
    assert not hasattr(formatting_0, 'list_0')


# Generated at 2022-06-25 18:53:18.722972
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:53:21.215722
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:53:30.375397
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['valid']
    env_0 = Environment()
    kwargs_0 = {'auth': '', 'colors': 'true', 'headers': '', 'ignore-stdin': 'True', 'method': 'GET', 'output': '',
                'proxies': '', 'session': '', 'timeout': '', 'url': 'https://api.github.com/',
                'verify': 'True', 'version': 'False','debug':'False','follow':'True','stream':'True','all':'True','history-print':'all','download':'','http':'','body':'','form':'','json':'','filter':'','headers':'','style':'','print':'','pretty':'','download':''}
    # Test case 0

# Generated at 2022-06-25 18:53:33.324563
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = ['str_0']
    formatting_0 = Formatting(groups_0)
    str_0 = 'str_1'
    str_1 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:53:38.693398
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    arg1 = 'headers'
    arg2 = 'host'
    arg3 = 'Accept-Encoding'
    obj1 = Formatting([arg1, arg2, arg3])
    var1 = test_case_0()
    str1 = 'User-Agent: HTTPie/0.9.9'
    str2 = obj1.format_headers(str1)
    assert str2 == str1


# Generated at 2022-06-25 18:53:42.404381
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    expected__converter = plugin_manager.get_converters()[0]
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert expected__converter == optional_0


# Generated at 2022-06-25 18:53:51.857573
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """
    Test: Get a converter for the specified MIME type.

    """

    # Test case 0
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)

    log.info('actual class: {actual}, expected class: {expected}'.format(
        actual=optional_0.__class__,
        expected=ConverterPlugin
    ))
    assert optional_0.__class__ == ConverterPlugin

    log.info('actual content-type: {actual}, expected content-type: {expected}'.format(
        actual=optional_0.content_type,
        expected='application/json'
    ))
    assert optional_0.content_type == 'application/json'


# Generated at 2022-06-25 18:53:56.022219
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['json', 'table', 'colors']
    formatting_0 = Formatting(groups_0)

# Generated at 2022-06-25 18:53:58.252429
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups_0 = []
    formatting_0 = Formatting(groups_0)
    content_0 = 'hello'
    mime_0 = 'application/json'
    str_0 = formatting_0.format_body(content_0, mime_0)


# Generated at 2022-06-25 18:54:02.633715
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import io
    output = io.StringIO()
    data = {'k1':'v1','k2':'v2','k3':'v3'}
    json.dump(data, output)
    str_0 = output.getvalue()
    formatting_0 = Formatting(['colors'])
    str_1 = 'application/json'
    optional_0 = formatting_0.format_body(str_0, str_1)


if __name__ == "__main__":
    test_case_0()
    test_Formatting_format_body()

# Generated at 2022-06-25 18:54:07.498624
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


if __name__ == '__main__':
    test_case_0()
    test_Conversion_get_converter()

# Generated at 2022-06-25 18:54:08.627474
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_Formatting_format_headers_0()


# Generated at 2022-06-25 18:54:12.771452
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application/jason') == False
    assert is_valid_mime('application=jason') == False

# Generated at 2022-06-25 18:54:15.615295
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = ['{', '  "headers": {}', '}']
    formatting_0 = Formatting(['colors'])
    str_0 = formatting_0.format_headers(headers)
    assert str_0 == '{\n  "headers": {}\n}'



# Generated at 2022-06-25 18:54:18.073111
# Unit test for constructor of class Formatting
def test_Formatting():
    from typing import List
    from httpie.context import Environment
    groups: List[str]
    env: Environment
    env = Environment()
    groups = ['pretty']
    formatting_0 = Formatting(groups)


# Generated at 2022-06-25 18:54:21.035868
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert is_valid_mime('application/json') # == True
    assert not is_valid_mime('my-format') # == False


# Generated at 2022-06-25 18:54:25.787040
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'

    # Call to get_converter of class Conversion
    optional_0 = conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:54:28.252967
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(groups = ['colors'])
    str_0 = 'a: b'
    optional_0 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:54:30.583813
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # print("Not yet implemented")
    # pass
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:54:32.912896
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    test_0 = Formatting(list_0)
    if isinstance(test_0, Formatting):
        assert test_0
    else:
        assert False


# Generated at 2022-06-25 18:54:35.094262
# Unit test for constructor of class Formatting
def test_Formatting():
    # initialization
    groups_0 = ['colors', 'colors', 'colors']
    env_0 = Environment()
    kwargs_0 = {}
    formatting_0 = Formatting(groups_0, env_0, **kwargs_0)


# Generated at 2022-06-25 18:54:36.340915
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 18:54:40.991486
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not test_case_0()
    assert not Conversion.get_converter('application/json')
    assert not Conversion.get_converter('text/plain')


# Generated at 2022-06-25 18:54:44.978706
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assertion_case_0 = ('',)
    mime = 'a/b'
    conversion = Conversion()
    val = conversion.get_converter(mime)
    if val is None:
        raise AssertionError(assertion_case_0)


# Generated at 2022-06-25 18:54:49.725618
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Input arguments:
    str_0 = 'application/json'
    formatting_0 = Formatting(str_0)
    str_1 = 'HTTP/1.1 200 OK\nContent-Length: 12'

    # Output arguments:
    str_2 = ''

    # Function call
    str_2 = formatting_0.format_headers(str_1)



# Generated at 2022-06-25 18:54:51.968282
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)

# Generated at 2022-06-25 18:54:57.613389
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(['formatters'])
    str_0 = 'q=0.9; q=0.8; q=0.7; q=0.6; a=0.5; b=0.4; c=0.3; d=0.2; e=0.1;'
    str_1 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:55:01.623092
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins_0 = plugin_manager.get_formatters_grouped()
    groups_0 = []
    env_0 = Environment()
    # groups = groups_0, env = env_0
    formatting_0 = Formatting(groups_0, env=env_0)


# Generated at 2022-06-25 18:55:02.416345
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_case_0()


# Generated at 2022-06-25 18:55:12.723484
# Unit test for constructor of class Formatting
def test_Formatting():
    environment_0 = Environment()
    formatting_0 = Formatting(
        ['colors', 'format', 'visual'],
        env=environment_0,
        default_colors=True,
    )
    formatting_1 = Formatting(
        ['colors', 'format', 'graph', 'highlight', 'style', 'theme', 'visual'],
        env=environment_0,
        default_colors=True,
    )
    formatting_2 = Formatting(
        ['colors', 'format', 'graph', 'highlight', 'style', 'theme', 'visual'],
        env=environment_0,
        default_colors=True,
    )

# Generated at 2022-06-25 18:55:14.336610
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0_0 = 'application/json'
    str_0_1 = 'application/json'
    list_0_0 = [str_0_0, str_0_1]
    formatting_0 = Formatting(list_0_0)


# Generated at 2022-06-25 18:55:25.837913
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    groups = ['colors']
    formatting = Formatting(groups, env)
    str_0 = 'application/json'

# Generated at 2022-06-25 18:55:31.687436
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    assert conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:55:33.047478
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['Contacts']
    formatting_0 = Formatting(groups_0)


# Generated at 2022-06-25 18:55:37.828762
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format_0 = Formatting()
    str_0 = 'application/json'
    str_1 = '{}'
    str_2 = ''
    optional_0 = format_0.format_body(str_1, str_0)
    optional_0 = format_0.format_body(str_2, str_0)


# Generated at 2022-06-25 18:55:44.300882
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.converters import JSONConverter
    conversion = Conversion()
    str = 'application/json'
    c = conversion.get_converter(str)
    assert isinstance(c, JSONConverter)


# Generated at 2022-06-25 18:55:48.706909
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting(['colors', 'colors'])
    str_0 = '{"message": "hello world"}'
    str_1 = 'application/json'
    str_2 = formatting_0.format_body(str_0, str_1)


# Generated at 2022-06-25 18:55:49.557650
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    pass



# Generated at 2022-06-25 18:55:55.589746
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    str_1 = 'verbose/json'
    try:
        optional_1 = conversion_1.get_converter(str_1)
        assert optional_1 == None
    except Exception as e:
        assert type(e) == RuntimeError

    conversion_2 = Conversion()
    str_2 = 'application/json'
    optional_2 = conversion_2.get_converter(str_2)
    assert optional_2 == None


# Generated at 2022-06-25 18:56:03.295107
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    conversion_1 = Conversion.get_converter('application/json')
    formatting_1 = Formatting(['colors'])
    str_1 = {
        'foo': 'bar',
        'baz': ['a', 'b', 'c'],
        'qux': {
            'foo': 'bar',
            'baz': ['a', 'b', 'c']
        }
    }
    str_2 = 'application/json'
    str_3 = formatting_1.format_body(str_1, str_2)
    str_4 = formatting_1.format_body(str_3, str_2)
    assert str_3 == str_4


# Generated at 2022-06-25 18:56:05.167421
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting = Formatting(["body"], env=Environment())
    assert formatting.format_body("text 0", "text/plain") == "text 0"


# Generated at 2022-06-25 18:56:09.193072
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = "headers, body"
    str_1 = 'text/plain'
    list_0 = []
    list_0.append('headers')
    list_0.append('body')
    formatting_0 = Formatting(list_0)
    str_2 = 'foo: bar'
    assert formatting_0.format_headers(str_2) == 'foo: bar\n'
    str_3 = 'baz'
    assert formatting_0.format_body(str_3,str_1) == 'baz'

# Test that python source files have a proper time complexity

# Generated at 2022-06-25 18:56:24.148642
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    conversion_1 = Conversion()
    str_1 = 'application/json'
    optional_3 = conversion_1.get_converter(str_1)

    test_headers_0 = {
        'Content-Length': 'content_length_0'
    }

    dict_0 = test_headers_0
    str_2 = 'json'
    formatting_0 = Formatting(groups=[str_2])
    try:
        # Condition for the "if" branch is true.
        if True:
            headers_0 = formatting_0.format_headers(dict_0)
    except IOError as e_0:
        print(str(e_0))

# Generated at 2022-06-25 18:56:28.236538
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    headers = ""
    content = "dummy-content"
    mime = "dummy-mime"
    formatting_0 = Formatting(["json", "colors"])
    str_0 = formatting_0.format_headers(headers)
    print(str_0)
    str_1 = formatting_0.format_body(content, mime)
    print(str_1)


# Generated at 2022-06-25 18:56:28.978724
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    pass


# Generated at 2022-06-25 18:56:38.551946
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-25 18:56:39.389559
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting() is not None


# Generated at 2022-06-25 18:56:42.803636
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin.converters.json import Converter

    conversion_1 = Conversion()
    assert conversion_1.get_converter('application/json') is Converter

# Generated at 2022-06-25 18:56:44.806840
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert True

# Generated at 2022-06-25 18:56:52.031325
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
  str_0 = 'Content-Type'
  str_1 = 'text/html'
  str_2 = 'text/plain'
  str_3 = 'User-Agent'
  str_4 = 'HTTPie/0.9.2'
  dict_0 = {str_0: str_1, str_3: str_4}
  str_5 = 'headers:  '
  str_6 = 'text/html'
  str_7 = 'User-Agent'
  str_8 = 'HTTPie/0.9.2'
  dict_1 = {str_7: str_8, str_0: str_6}
  str_9 = 'headers:  '
  str_10 = 'text/plain'
  dict_2 = {str_0: str_10}

# Generated at 2022-06-25 18:56:52.944146
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting()


# Generated at 2022-06-25 18:57:00.931077
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_1 = 'json'
    formatting_0 = Formatting(groups=['json'], indent=4)
    str_2 = 'application/json'
    str_3 = '''[\n    {\n        "name": "example 0"\n    }, \n    {\n        "name": "example 1"\n    }\n]'''
    str_4 = '''[\n    {\n        "name": "example 0"\n    }, \n    {\n        "name": "example 1"\n    }\n]'''
    str_5 = '''[\n    {\n        "name": "example 0"\n    }, \n    {\n        "name": "example 1"\n    }\n]'''

# Generated at 2022-06-25 18:57:13.185818
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = []
    formatting_0 = Formatting(groups_0)
    str_0 = 'application/json'
    str_1 = str_0.lower()
    bool_0 = is_valid_mime(str_1)
    str_2 = formatting_0.format_headers(str_1)
    assert str_2 == str_1


# Generated at 2022-06-25 18:57:14.973384
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = list()
    format = Formatting(groups)
    assert(format is not None)


# Generated at 2022-06-25 18:57:25.040631
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Fixture inside a method
    env_0 = Environment()
    env_0.colors = 256
    env_0.style = HTTPieStyle()
    env_0.style_errors = 'solarized'
    env_0.style_sheets = HTTPieStyleSheets()
    env_0.debug = True
    obj_0 = Formatting(
        ['colors', 'format', 'headers', 'utf8', 'json'],
        env=env_0,
        indent=3,
        sort_headers=False,
        format='pretty',
        colors=128)
    str_0 = 'application/json'
    obj_0.format_body('abc', str_0)


# Generated at 2022-06-25 18:57:32.098514
# Unit test for method format_body of class Formatting

# Generated at 2022-06-25 18:57:35.140219
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ["group_0"]
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env=env_0)
    return formatting_0


# Generated at 2022-06-25 18:57:46.311089
# Unit test for constructor of class Formatting
def test_Formatting():
    conversions = [
        (['colors'], {'format': 'colors'}, Environment(stdout_isatty=True)),
        (['colors'], {'format': 'colors'}, Environment(stdout_isatty=False)),
        (['colors', 'colors'], {'format': 'colors,colors'}, Environment(stdout_isatty=True)),
        (['colors', 'colors'], {'format': 'colors,colors'}, Environment(stdout_isatty=False)),
    ]
    for case in conversions:
        try:
            Formatting(case[0], args=case[1], env=case[2])
        except Exception as e:
            print(e)

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 18:57:47.876704
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['formatter']
    formatting_0 = Formatting(groups_0)


# Generated at 2022-06-25 18:57:51.673995
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Init param args
    groups = ['font']
    kwargs = {'font': 'standard'}

    # Init return type
    expected_0 = data.TEXT_RESPONSE_BODY
    # Execute function
    actual_0 = Formatting(groups, **kwargs).format_headers(data.HEADERS)
    assert expected_0 == actual_0


# Generated at 2022-06-25 18:57:53.802453
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:57:55.979032
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:58:12.771618
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = ["fancy"]
    formatting_0 = Formatting(groups_0)

# Generated at 2022-06-25 18:58:14.427364
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = []
    # Test a case where available plugins is empty
    # Test a case where available plugins is not empty
    format = Formatting(groups)



# Generated at 2022-06-25 18:58:15.746504
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['human', 'json', 'colors']
    formatting = Formatting(groups)
    assert type(formatting) == Formatting


# Generated at 2022-06-25 18:58:19.997988
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test cases
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:58:30.200718
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0.__class__.__name__ == 'JSONConverter'
    str_0 = 'application/xml'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0.__class__.__name__ == 'XMLConverter'
    str_0 = 'application/xml'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0.__class__.__name__ == 'XMLConverter'
    str_0 = 'application/xml'
    optional_0 = conversion_0.get_converter(str_0)

# Generated at 2022-06-25 18:58:40.038605
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    formatting_0 = Formatting(["testGroup"])
    str_0 = "HTTP/1.1 200 OK\r\nCache-Control: max-age=120\r\nConnection: keep-alive\r\nContent-Encoding: gzip\r\nContent-Type: application/json\r\nDate: Thu, 09 Jan 2020 15:23:28 GMT\r\nExpires: Thu, 09 Jan 2020 16:23:28 GMT\r\nServer: nginx/1.10.3 (Ubuntu)\r\nTransfer-Encoding: chunked\r\nVary: Accept-Encoding\r\nX-Runtime: 0.023871\r\n\r\n"
    optional_0 = formatting_0.format_headers(str_0)
    if optional_0 is not None:
        str

# Generated at 2022-06-25 18:58:44.860101
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    str_1 = 'application/json'
    conversion_2 = conversion_1.get_converter(str_1)
    # AssertionError
    try:
        assert conversion_2.mime_type == str_1
    except AssertionError:
        print('AssertionError')


# Generated at 2022-06-25 18:58:47.802737
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert not optional_0 is None


# Generated at 2022-06-25 18:58:58.148499
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    groups_1 = []
    groups_1.append('application/json')
    groups_1.append('application/javascript')
    groups_1.append('text/json')
    groups_1.append('text/javascript')
    groups_1.append('text/x-json')
    groups_1.append('text/x-js')
    groups_1.append('text/x-javascript')
    groups_1.append('application/json-rpc')
    groups_2 = []
    groups_2.append('text/x-javascript')
    groups_2.append('application/json')
    groups_2.append('application/jsonrequest')
    groups_2.append('text/javascript')
    groups_2.append('text/json')
    groups_3 = []
    groups_

# Generated at 2022-06-25 18:58:59.919135
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Requires at least one formatter to be enabled.
    # At the moment, this is unsupported by the PluginManager
    pass



# Generated at 2022-06-25 18:59:10.526791
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # The following line will be replaced by the actual test code.
    assert False



# Generated at 2022-06-25 18:59:13.156844
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = []
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env_0)
    str_0 = ''
    str_1 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:59:15.248048
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:59:18.826728
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Create instance of class Conversion
    conversion_0 = Conversion()
    # Create variables for parameters
    str_0 = 'application/json'
    # Invoke method with parameters
    optional_0 = conversion_0.get_converter(str_0)
    # Assert return value
    assert optional_0.__class__.__name__ == 'JSONConverter'



# Generated at 2022-06-25 18:59:19.835622
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # TODO auto-generated
    assert False


# Generated at 2022-06-25 18:59:22.784630
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting()
    str_0 = 'application/json'
    str_1 = 'body'
    str_0 = formatting_0.format_body(str_1, str_0)


# Generated at 2022-06-25 18:59:31.771543
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['colors']
    env_0 = Environment()
    kwargs_0 = {'colors': '123'}
    formatting_0 = Formatting(groups_0, env_0, **kwargs_0)