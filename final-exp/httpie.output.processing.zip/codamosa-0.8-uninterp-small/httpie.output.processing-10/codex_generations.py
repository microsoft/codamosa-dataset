

# Generated at 2022-06-25 18:49:36.934261
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # creating a conversion object
    conversion_obj = Conversion()
    # calling get_converter method and getting the converter object
    converter_obj = conversion_obj.get_converter("application/json")
    # checking if converter object is not None
    assert converter_obj is not None
    # checking if converter object is an instance of ConverterPlugin
    assert isinstance(converter_obj, ConverterPlugin)


# Generated at 2022-06-25 18:49:38.318711
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    conversion_0 = Conversion()
    conversion_0.get_converter("a")

# Generated at 2022-06-25 18:49:39.638451
# Unit test for constructor of class Formatting
def test_Formatting():
    assert callable(Formatting)


# Generated at 2022-06-25 18:49:49.282134
# Unit test for constructor of class Formatting
def test_Formatting():
    print("------------------Unit test for class Formatting------------------")
    # Chain of Responsibility
    formatting = Formatting(['colors', 'format', 'unicode'])
    print(formatting.format_headers("GET / HTTP/1.1\r\n"))
    print(formatting.format_headers("HTTP/1.1 200 OK\r\n"))
    print(formatting.format_headers("HTTP/1.1 201 Created\r\n"))
    print(formatting.format_headers("HTTP/1.1 401 Unauthorized\r\n"))
    print(formatting.format_headers("HTTP/1.1 500 Internal Server Error\r\n"))
    print(formatting.format_headers("HTTP/1.1 404 Not Found\r\n"))

# Generated at 2022-06-25 18:49:58.452930
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    cases = [
        ("Content-Length: 0\r\n", "Content-Length: 0\r\n"),
        ("Content-Length: 0\r\n", "Content-Length: 0\r\n\r\n"),
        ("Content-Length: 0\r\n", "Content-Length: 0\r\n\r\n\r\n"),
        ("Content-Length: 0\r\n\r\n", "Content-Length: 0\r\n\r\n\r\n"),
        ("Content-Length: 0\r\n", "Content-Length: 0\r\n\r\n\r\n\r\n"),
    ]

    for expected, headers in cases:
        fmt = Formatting(groups=["HTTPieFormatter"])
        assert fmt.format_headers(headers)

# Generated at 2022-06-25 18:50:02.564885
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatter = Formatting(['color', 'format'])
    actual = formatter.format_body('{"data": {"name": "name", "id": "id"}}', 'application/json')
    expected = '{\n    "data": {\n        "name": "name", \n        "id": "id"\n    }\n}'
    assert actual == expected

# Generated at 2022-06-25 18:50:04.699060
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    formatting_1 = Formatting([], env=env)
    formatting_2 = Formatting(env=env)


# Generated at 2022-06-25 18:50:05.955818
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors', 'format'])


# Generated at 2022-06-25 18:50:09.725809
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    for key in available_plugins:
        for cls in available_plugins[key]:
            fmt = Formatting(groups=list(available_plugins.keys()))
            assert isinstance(fmt, Formatting)


# Generated at 2022-06-25 18:50:11.234497
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # TODO
    # This method doesn't have any dependency - so it can be tested easily
    pass


# Generated at 2022-06-25 18:50:15.624207
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    int_1 = 4512
    str_1 = 'Headers'
    object_0 = Formatting(int_1)
    str_0 = object_0.format_headers(str_1)


# Generated at 2022-06-25 18:50:17.742412
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    int_0 = 423
    var_0 = Formatting([])
    var_1 = var_0.format_body(int_0, "bogus")


# Generated at 2022-06-25 18:50:19.139147
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_1 = 'text/html'
    var_2 = Conversion.get_converter(var_1)


# Generated at 2022-06-25 18:50:22.432038
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Set up test environment
    obj_0 = Formatting([])
    # Testing method format_headers
    str_0 = '  f  o o'
    str_1 = obj_0.format_headers(str_0)
    assert str_1 == str_0


# Generated at 2022-06-25 18:50:25.561956
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Setup
    var_0 = Formatting(None)

    # Invoke method
    result = var_0.format_headers(None)

    # Expected result



# Generated at 2022-06-25 18:50:31.461371
# Unit test for constructor of class Formatting
def test_Formatting():
    """
    Expected behavior:

    As in `test_case_0`, the constructor will return a new Formatting object.
    """

    header = 'gh'
    body = 'gh'
    var_0 = Formatting(header, body)
    assert isinstance(var_0, Formatting)
    assert isinstance(var_0.enabled_plugins, list)


# Generated at 2022-06-25 18:50:37.399630
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env_0 = Environment()
    int_0 = 3496
    var_0 = Formatting(int_0, env_0)
    var_1 = 'Hello World!'
    var_2 = var_0.format_headers(var_1)


# Generated at 2022-06-25 18:50:40.459508
# Unit test for constructor of class Formatting
def test_Formatting():
    int_0 = 3496
    var_1 = is_valid_mime(int_0)
    str_0 = "test"
    var_2 = Formatting(str_0)


# Generated at 2022-06-25 18:50:42.312857
# Unit test for constructor of class Formatting
def test_Formatting():
    int_0 = 3496
    var_0 = Formatting(int_0)


# Generated at 2022-06-25 18:50:49.800795
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test function arguments
    headers = '{"headers": {"Cache-Control": "no-cache, no-store", "Content-Type": "application/json", "Date": "Tue, 27 Oct 2015 15:50:19 GMT", "Expires": "0", "Pragma": "no-cache", "Server": "nginx/1.4.6 (Ubuntu)", "Transfer-Encoding": "chunked", "Vary": "Accept-Encoding", "X-Content-Type-Options": "nosniff", "X-Frame-Options": "SAMEORIGIN", "X-Powered-By": "Phusion Passenger 4.0.59", "X-XSS-Protection": "1; mode=block"}}'
    groups = ['colors', 'format', 'pretty']
    # Test function execution

# Generated at 2022-06-25 18:50:54.559598
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = 'mime'
    var_1 = Conversion.get_converter(var_0)


# Generated at 2022-06-25 18:51:01.659180
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print("=== test format_body")
    # Initialize the class object
    test_groups = ['colors', 'formatters']
    test_env = Environment()
    test_body = "{\n  \"key\": \"value\"\n}"
    test_mime = "application/json"
    test_object = Formatting(test_groups, env=test_env)
    # Call the method
    test_result = test_object.format_body(test_body, test_mime)
    print(test_result)



# Generated at 2022-06-25 18:51:10.738161
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    format_body = Formatting.format_body
    class_0 = Formatting()
    class_1 = Formatting()
    class_2 = Formatting()
    class_3 = Formatting()
    class_4 = Formatting()
    class_5 = Formatting()
    class_6 = Formatting()
    class_7 = Formatting()
    class_8 = Formatting()
    class_9 = Formatting()
    class_10 = Formatting()
    class_11 = Formatting()
    class_12 = Formatting()
    class_13 = Formatting()
    class_14 = Formatting()
    class_15 = Formatting()
    class_16 = Formatting()
    class_17 = Formatting()
    class_18 = Formatting()
    class_19 = Formatting()
    class_20 = Formatting

# Generated at 2022-06-25 18:51:16.622271
# Unit test for constructor of class Formatting
def test_Formatting():
    int_0 = 3496
    str_0 = "application/json"
    if is_valid_mime(int_0):
        var_0 = Conversion.get_converter(str_0)
        if var_0 is not None:
            str_1 = "application/json"
            obj_0 = Formatting([str_1])


# Generated at 2022-06-25 18:51:18.800164
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    int_0 = 3496
    var_0 = Formatting.format_headers(int_0)


# Generated at 2022-06-25 18:51:21.240180
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["default"]
    env = Environment()
    kwargs = {}
    
    formatter = Formatting(groups, env, **kwargs)


# Generated at 2022-06-25 18:51:22.993926
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    int_0 = 3496
    var_0 = Formatting.format_body(int_0)


# Generated at 2022-06-25 18:51:26.840392
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    var_1 = Formatting(["colors"])
    int_0 = 3496
    var_2 = var_1.format_body(int_0, "html")
    assert var_2 == int_0


# Generated at 2022-06-25 18:51:27.781840
# Unit test for constructor of class Formatting
def test_Formatting():
    pass



# Generated at 2022-06-25 18:51:32.228447
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    var_0 = Formatting(['colors'])
    var_1 = b'\nHTTP/1.1 200 OK\r\nContent-Length: 7\r\nX-Random-Header: foo\r\n\r\nContent\n'
    var_2 = var_0.format_headers(var_1)
    assert var_2 != var_1



# Generated at 2022-06-25 18:51:40.173392
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    s = Formatting()
    assert s.format_headers(True) == True
    assert s.format_headers(False) == False
    assert s.format_headers('test_string') == 'test_string'


# Generated at 2022-06-25 18:51:42.246446
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = list()
    var_0 = Formatting(groups_0)
    headers_0 = ""
    var_1 = var_0.format_headers(headers_0)
    assert type(var_1) is str


# Generated at 2022-06-25 18:51:50.880392
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    var_0 = Formatting([])

# Generated at 2022-06-25 18:51:58.944879
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    int_1 = 1081
    int_2 = 833
    str_0 = 'text/plain'
    str_1 = 'text/plain'
    str_0 = str_0 + str_1
    str_1 = 'text/json'
    str_1 = str_0 + str_1
    str_0 = 'text/html'
    str_0 = str_1 + str_0
    str_1 = 'text/xml'
    str_0 = str_0 + str_1
    str_1 = 'text/html'
    str_0 = str_0 + str_1
    str_1 = 'application/json'
    str_0 = str_0 + str_1
    str_1 = 'application/xml'
    str_0 = str_0 + str_1
    str_1

# Generated at 2022-06-25 18:52:01.393328
# Unit test for constructor of class Formatting
def test_Formatting():
    test_groups = []
    test_env = Environment()

    Formatting(test_groups, env=test_env)

# Generated at 2022-06-25 18:52:05.024183
# Unit test for constructor of class Formatting
def test_Formatting():
    int_0 = 3496
    fmt = Formatting([int_0], [int_0])
    fmt.enabled_plugins.append(int_0)
    fmt.enabled_plugins.pop()
    fmt.format_headers(int_0)


# Generated at 2022-06-25 18:52:08.797233
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    text_input = '''
    {
        "a": "list",
        "of": "words"
    }
    '''
    text_output = '''
    {
        "a": "list",
        "of": "words"
    }
    '''


# Generated at 2022-06-25 18:52:14.575718
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    int_0 = 2191
    int_1 = 3496
    str_0 = 'application/json'
    # Input: int_0 | Input: int_1 | Output: str_0
    print(Conversion.get_converter(int_0))
    # Input: int_0 | Input: int_1 | Output: str_0
    print(Conversion.get_converter(int_1))


# Generated at 2022-06-25 18:52:15.410761
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    obj = Formatting([], Environment())
    obj.format_headers(1) 


# Generated at 2022-06-25 18:52:16.319524
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    int_0 = 3303
    var_0 = is_valid_mime(int_0)


# Generated at 2022-06-25 18:52:27.057340
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    int_0 = 6
    var_0 = Formatting.format_headers(int_0)


# Generated at 2022-06-25 18:52:30.106706
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_1 = 'text/plain'
    var_2 = Conversion.get_converter(var_1)
    var_3 = None
    var_4 = var_2 == var_3


# Generated at 2022-06-25 18:52:33.147539
# Unit test for constructor of class Formatting

# Generated at 2022-06-25 18:52:34.031301
# Unit test for constructor of class Formatting
def test_Formatting():
    test_case_0()


# Generated at 2022-06-25 18:52:37.124987
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    s = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(random.randint(1, 10)))
    f = Formatting(groups=s)
    f.format_headers(s)


# Generated at 2022-06-25 18:52:37.823677
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(["test"])


# Generated at 2022-06-25 18:52:47.446848
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-25 18:52:48.833305
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    int_1 = 3496
    var_1 = Conversion.get_converter(int_1)


# Generated at 2022-06-25 18:52:56.091317
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # create an instance of the class Formatting
    groups = []
    env = Environment()
    formatter = Formatting(groups, env)

    # create a dummy string and format it
    headers = 'Accept: application/json'
    formatter.format_headers(headers)

    # check if the string has been formatted (in some formatter)
    # if it is not formatted, the 2 strings should be equal
    assert headers != formatter.format_headers(headers)


# Generated at 2022-06-25 18:52:58.802166
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    with pytest.raises(Exception):
        var_1 = 'lD9t'
        var_2 = 'qfLa'
        Formatting.format_body(var_1, var_2)


# Generated at 2022-06-25 18:53:18.847491
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["json"]
    var_0 = Formatting(groups=groups)
    print(var_0.enabled_plugins)
#


# Generated at 2022-06-25 18:53:20.201651
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['plain']
    env_0 = Environment()
    obj_0 = Formatting(groups_0, env_0)

# Generated at 2022-06-25 18:53:25.030698
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = "pSVZ^j"
    list_0 = ["R\x7FyG\x2E", "d\x7F+r\x2B"]
    var_0 = Formatting(list_0)
    var_1 = var_0.format_headers(str_0)
    assert isinstance(var_1, str), "%s: %s" % (type(var_1), var_1)


# Generated at 2022-06-25 18:53:27.949254
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'application/json'
    obj_0 = Conversion.get_converter(str_0)
    assert isinstance(obj_0, ConverterPlugin)


# Generated at 2022-06-25 18:53:29.382635
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    int_0 = 3496
    var_0 = Conversion.get_converter(int_0)


# Generated at 2022-06-25 18:53:32.961353
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    var_1 = Formatting(0, Environment(colors=256, stdin_isatty=False, stdout_isatty=False))
    str_1 = "H"
    try:
        str_2 = var_1.format_headers(str_1)
    except:
        raise


# Generated at 2022-06-25 18:53:35.042018
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['highlight']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)


# Generated at 2022-06-25 18:53:36.185055
# Unit test for constructor of class Formatting
def test_Formatting():
    var_0 = Formatting([])


# Generated at 2022-06-25 18:53:45.971682
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Case 1
    # Input
    groups = ["pretty"]
    content = "mime"
    var_2 = Formatting(groups).format_body(content, 1000)

    # Case 2
    # Input
    groups = ["pretty"]
    content = "mime"
    var_2 = Formatting(groups).format_body(content, 1000)

    # Case 3
    # Input
    groups = ["pretty"]
    content = "mime"
    var_2 = Formatting(groups).format_body(content, 1000)

    # Case 4
    # Input
    groups = ["pretty"]
    content = "mime"
    var_2 = Formatting(groups).format_body(content, 1000)


# Generated at 2022-06-25 18:53:47.279561
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/xml') == None


# Generated at 2022-06-25 18:54:25.712715
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    int_a = 3496
    str_b = "10.4"


# Generated at 2022-06-25 18:54:27.250635
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = 3496
    var_1 = Conversion.get_converter(var_0)


# Generated at 2022-06-25 18:54:31.119235
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    env = Environment()
    dummy_plugin = FormatterPlugin(env)
    formatting = Formatting([], env)
    assert formatting.enabled_plugins == []
    formatting = Formatting(['test'], env, dummy=dummy_plugin)
    assert formatting.enabled_plugins == [dummy_plugin]

# Generated at 2022-06-25 18:54:32.528952
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    int_0 = 3496
    var_0 = is_valid_mime(int_0)


# Generated at 2022-06-25 18:54:37.105336
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['HTTPie'], ['json'])
    if not fmt.enabled_plugins[0].name == 'JSON':
        assert False

    fmt = Formatting(['HTTPie'], ['xml'])
    if not fmt.enabled_plugins[0].name == 'XML':
        assert False

    fmt = Formatting(['HTTPie', 'HTTPie'], ['html'])
    if not fmt.enabled_plugins[0].name == 'HTML':
        assert False



# Generated at 2022-06-25 18:54:41.549602
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    int_0 = 3496
    pass_0 = Formatting(int_0)
    str_0 = 'test'
    str_1 = pass_0.format_body(str_0)
    assert str_1 == str_0


# Generated at 2022-06-25 18:54:43.571806
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = Conversion
    var_1 = var_0.get_converter(1)


# Generated at 2022-06-25 18:54:52.416166
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Initialize
    groups = plugin_manager.get_formatters_grouped()
    instance = Formatting(groups=groups)
    # Do unit test

# Generated at 2022-06-25 18:54:55.807729
# Unit test for constructor of class Formatting
def test_Formatting():
    int_0 = -1348
    str_0 = 'kB#ESK'
    int_1 = -2060
    env = Environment()
    var_1 = Formatting(int_0, int_1, env)


# Generated at 2022-06-25 18:54:58.077948
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    int_0 = 3496
    var_0 = is_valid_mime(int_0)


# Generated at 2022-06-25 18:56:19.210370
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    if False:
        class MockPluginsManager:
            def __init__(self):
                self.converters = []
            def get_converters(self):
                return [MockConverterPlugin_0, MockConverterPlugin_1]
        plugin_manager.plugins_manager = MockPluginsManager()
    
        result = Conversion.get_converter(int_0)

        assert result == MockConverterPlugin_0(int_0)



# Generated at 2022-06-25 18:56:26.719967
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Initialization
    groups = [
        '3',
        '1',
        '8',
        '6',
        '11']
    env = Environment()
    formatting = Formatting(groups, env)

    # Invocation
    result = formatting.format_headers(
        'Mon, 11 Mar 2019 22:29:11 GMT'
    )

    # Output check
    assert re.fullmatch(
        r'Mon, 11 \w{3} 2019 [01]\d:[0-5]\d:[0-5]\d GMT',
        result
    ) is not None


# Generated at 2022-06-25 18:56:28.639850
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case #0
    var_0 = Formatting()
    var_1 = var_0.format_headers()


# Generated at 2022-06-25 18:56:30.283598
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    int_0 = ""
    var_0 = Conversion.get_converter(int_0)


# Generated at 2022-06-25 18:56:36.745433
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    conv = Conversion.get_converter('application/json')
    assert conv is not None

    fmt = Formatting(groups=['stdout', 'colors'])
    cnt = '{"http": "ie"}'
    ret = fmt.format_body(cnt, 'application/json')
    assert ret is not None

    fmt = Formatting(groups=['stdout'])
    cnt = '{"http": "ie"}'
    ret = fmt.format_body(cnt, 'application/json')
    assert ret is not None

# Generated at 2022-06-25 18:56:40.453321
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    var_0 = Formatting([])
    str_0 = "a"
    str_1 = "k9l\x7fq"
    var_1 = var_0.format_body(str_0, str_1)
    # var_1: str



# Generated at 2022-06-25 18:56:42.941314
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    int_0 = 3496
    var_0 = Conversion.get_converter(int_0)


# Generated at 2022-06-25 18:56:44.916066
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "Not A MIME Type"
    var_0 = Conversion.get_converter(mime)
    assert var_0 == None


# Generated at 2022-06-25 18:56:47.739279
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    res = Formatting(["JSON"], Environment(), color=True).format_headers('{"a":"b"}')
    assert res == 'JSON\n{\n    "a": "b"\n}\n'


# Generated at 2022-06-25 18:56:52.766805
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # 测试用例
    print("\n==== test_Conversion_get_converter() ====\n")

    print(Conversion.get_converter('text/html'))

    print(Conversion.get_converter('application/json'))

    print(Conversion.get_converter('application/json-rpc'))

    print(Conversion.get_converter('application/x-www-form-urlencoded'))

    int_0 = 3496
    var_0 = is_valid_mime(int_0)
    print(Conversion.get_converter(var_0))

