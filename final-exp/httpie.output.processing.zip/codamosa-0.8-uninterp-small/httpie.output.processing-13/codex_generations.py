

# Generated at 2022-06-25 18:49:33.975746
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    # Test case0, with no plugins
    format_headers_0 = Formatting([], env=Environment()).format_headers("")
    # Test case1, with plugin `NoPlugin`
    format_headers_1 = Formatting(["NoPlugin"], env=Environment()).format_headers("")
    # Test case2, with plugin `NoPlugin`
    format_headers_2 = Formatting(["NoPlugin"], env=Environment()).format_headers("")


# Generated at 2022-06-25 18:49:41.848339
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # 1. init object
    env = Environment()
    formatting_object = Formatting(['color'], env=env)
    # 2. given some content & mime
    content = "this is a string"
    mime = "text/plain"
    # 3. test whether the given mime is of type text/plain
    conversion_mime = Conversion()
    converter = conversion_mime.get_converter(mime)
    assert isinstance(converter, ConverterPlugin)
    # 4. check whether enabled plugins has contained a color formatter
    assert formatting_object.enabled_plugins[0]

# Generated at 2022-06-25 18:49:45.053409
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    mime = "text/html"
    converter_class = conversion_1.get_converter(mime)
    assert(isinstance(converter_class, ConverterPlugin))


# Generated at 2022-06-25 18:49:46.133786
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting(["formatters"])

# Generated at 2022-06-25 18:49:48.169287
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter.media_type == "application/json"


# Generated at 2022-06-25 18:49:55.501314
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    fm = Formatting(groups=['colors'],
                    style="foo",
                    expand=False,
                    theme="bar",
                    colors="baz")

# Generated at 2022-06-25 18:49:59.909368
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(["json", "colors", "format"], ensure_ascii=True, env=Environment())
    assert formatting_0.format_headers('foo: bar\nContent-Type: application/json\n\n') == 'foo: bar\nContent-Type: application/json\n\n'


# Generated at 2022-06-25 18:50:08.873583
# Unit test for constructor of class Formatting
def test_Formatting():
    f1 = Formatting([], Environment())
    f2 = Formatting([], Environment(), max_line_length=40)
    f3 = Formatting(["colors"], Environment(), max_line_length=40)
    f4 = Formatting(["colors", "format"], Environment(), max_line_length=40)
    f5 = Formatting(["colors", "format", "colors"], Environment(), max_line_length=40)
    f6 = Formatting(["colors", "format"], Environment())
    f7 = Formatting(["colors", "format"], Environment(), max_line_length=0)
    f8 = Formatting(["colors", "format"], Environment(), max_line_length=80)
    f9 = Formatting(["colors", "format"], Environment(), max_line_length=81)
   

# Generated at 2022-06-25 18:50:12.353244
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    test_mime = 'text/xml'
    assert conversion_1.get_converter(test_mime)
    test_mime = 'text/not-a-real-thing'
    assert not conversion_1.get_converter(test_mime)

# Generated at 2022-06-25 18:50:14.356576
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    formatting_0 = Formatting()
    headers = formatting_0.format_headers()
    assert headers == config.UNDEFINED


# Generated at 2022-06-25 18:50:23.204680
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test 1
    formatting_0 = Formatting(['colors', 'format'])
    headers = 'h1: v1'
    headers = formatting_0.format_headers(headers)
    assert headers == 'h1: v1'
    # test 2
    formatting_0 = Formatting(['colors'])
    headers = 'h1: v1'
    headers = formatting_0.format_headers(headers)
    assert headers == 'h1: v1'
    # test 3
    formatting_0 = Formatting(['colors'])
    headers = 'h1: v1'
    headers = formatting_0.format_headers(headers)
    assert headers == 'h1: v1'


# Generated at 2022-06-25 18:50:25.552218
# Unit test for constructor of class Formatting
def test_Formatting():
    test_formatting = Formatting(["json", "colors", "format", "format_options"], stream=False, indent=4)


# Generated at 2022-06-25 18:50:27.104367
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting(groups=[])


# Generated at 2022-06-25 18:50:32.741999
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    converter_0 = Formatting([])
    headers = '{"Accept": "*/*", "Accept-Encoding": "gzip, deflate", "Connection": "close", "Host": "httpbin.org", "User-Agent": "HTTPie/0.9.2"}'
    result = converter_0.format_headers(headers)
    assert result is not None



# Generated at 2022-06-25 18:50:43.721402
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test_case_1
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nTransfer-Encoding: chunked\r\n\r\n"
    groups = ["colors", "format", "to3"]
    env = Environment()
    formatting_0 = Formatting(groups, **locals())
    print(formatting_0.format_headers(**locals()))
    # test_case_2
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\nTransfer-Encoding: chunked\r\n\r\n"
    groups = ["colors", "to3", "format"]
    env = Environment()

# Generated at 2022-06-25 18:50:49.089752
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test1 = Formatting("formatters", format="colors")
    assert test1.format_body("{\"hello\":\"world\"}", "application/json") == "\x1b[37m{\x1b[39;49;00m\n    \x1b[32m\"hello\": \"world\"\x1b[39;49;00m\n\x1b[37m}\x1b[39;49;00m\n"
    assert test1.format_body("hello world", "text/plain") == "hello world"


# Generated at 2022-06-25 18:51:00.699962
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_instance = Formatting(['highlight'])
    test_string = ''
    # Expected values vary with env=None, default value
    expected_0 = ''
    # Expected values vary with env=Environment(), default value
    expected_1 = ''
    # Expected values vary with env=Environment(
    #   stdin=None,
    #   stdout=None,
    #   stderr=None,
    #   stdin_isatty=None,
    #   stdout_isatty=None,
    #   stderr_isatty=None,
    #   output_options=None,
    #   options=None,
    # ), default value
    expected_2 = ''
    # Expected values vary with env=Environment(
    #   stdin=<_io.TextIOW

# Generated at 2022-06-25 18:51:06.135333
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['Converter', 'Formatter', 'Highlighter']
    kwargs = {'format': 'pretty', 'colors': None, 'style': None, 'theme': None}
    kwargs = {'format': 'pretty', 'colors': None, 'style': None, 'theme': None}
    test_case_1 = Formatting(groups, **kwargs)


# Generated at 2022-06-25 18:51:09.734011
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors', 'format-headers']
    kwargs = {}
    format_1 = Formatting(groups, env, **kwargs)
    assert format_1.enabled_plugins == []
    assert format_1.enabled_plugins == []


# Generated at 2022-06-25 18:51:21.275031
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-25 18:51:32.758451
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Input arguments
    mime_0 = "a"

    # Invoke method
    conversion_0 = Conversion()
    result_0 = conversion_0.get_converter(mime_0)
    result_1 = conversion_0.get_converter(mime_0)
    result_2 = conversion_0.get_converter(mime_0)
    result_3 = conversion_0.get_converter(mime_0)

    assert isinstance(result_0, ConverterPlugin)
    assert result_1 is result_0
    assert result_2 is not result_0
    assert result_3 is not result_0

    mime_1 = "text/html"

    # Invoke method
    conversion_1 = Conversion()
    result_0 = conversion_1.get_converter

# Generated at 2022-06-25 18:51:35.035515
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion = Conversion()
    assert conversion.get_converter("application/json")


# Generated at 2022-06-25 18:51:38.145465
# Unit test for constructor of class Formatting
def test_Formatting():
    formatter = Formatting(groups=['colors'])
    if formatter is None:
        return False
    else:
        return True



# Generated at 2022-06-25 18:51:41.019765
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    env_0 = Environment()
    conversion_0 = Conversion()
    assert conversion_0.get_converter('text/xml') is None, "If 'mime' is not a valid mime, an assertion error will be raised."


# Generated at 2022-06-25 18:51:43.231404
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting([], env=Environment())
    assert formatting_0.format_headers('Headers') == 'Headers'


# Generated at 2022-06-25 18:51:44.073211
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(groups,env)


# Generated at 2022-06-25 18:51:45.855290
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting.format_headers("k1: v1\r\n") == "k1: v1\r\n"


# Generated at 2022-06-25 18:51:47.296325
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting()
    formatting_0.format_headers(headers="")


# Generated at 2022-06-25 18:51:50.073410
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    try:
        assert conversion_1.get_converter('application/json') == None, "Test failed"
    except Exception as e:
        print(e)


# Generated at 2022-06-25 18:51:58.489111
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.registry import plugin_manager
    
    # Case0: no groups, no extra args
    format_ = Formatting([])
    assert format_.enabled_plugins == []

    available_plugins = plugin_manager.get_formatters_grouped()
    # Case1: no groups, extra args
    format_ = Formatting([], pretty_format=True)
    for group in available_plugins:
        for plugin in available_plugins[group]:
            if plugin.supports().pretty:
                # The plugin will be enabled
                assert plugin in format_.enabled_plugins
                assert format_.enabled_plugins.pop().enabled == True
            else:
                # The plugin will not be enabled
                assert plugin not in format_.enabled_plugins
    
    # Case2: no extra args


# Generated at 2022-06-25 18:52:11.417296
# Unit test for constructor of class Formatting
def test_Formatting():

    print('\n---=== Unit test for Formatting::__init__() ===---')

    assert Formatting(['colors']).enabled_plugins.__len__() == 1
    assert Formatting(['colors']).enabled_plugins[0].plugin_name == 'httpie.plugins.formatter.colors'
    assert Formatting(['colors']).enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert Formatting(['colors']).enabled_plugins[0].format_headers('_headers_') == '\x1b[32mheaders\x1b[0m'
    assert Formatting(['colors']).enabled_plugins[0].format_body('_hello_', 'text/html') == '\x1b[32mhello\x1b[0m'

# Generated at 2022-06-25 18:52:15.206503
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Arrange
    formatting = Formatting(['highlight', 'colors'])
    h = "HTTP/1.1 200 OK\r\nConnection: close\r\n\r\n"

    # Act
    result = formatting.format_headers(h)

    # Assert
    assert result == h

# Generated at 2022-06-25 18:52:21.598626
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print ("Testing format_body...")
    append_dirs = ['plugins']
    env = Environment()
    env.config.append_dirs = append_dirs
    env.config.output_options = ['format=json,format_options=indent=2']
    formaters_grouped = {'colors': [JSONHighlight, JSONIndent, URLEncodeHighlight, URLEncodeIndent], 'format': [JSONIndent, URLEncodeIndent]}
    plugin_manager._get_formatters_grouped = formaters_grouped
    formatting = Formatting(['colors', 'format'], env)

# Generated at 2022-06-25 18:52:29.501193
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 0
    conversion_0 = Conversion()
    mime_0 = "application/json"
    expected_0 = None
    actual_0 = conversion_0.get_converter(mime_0)
    assert actual_0 == expected_0
    # Test case 1
    conversion_1 = Conversion()
    mime_1 = "image/png"
    expected_1 = None
    actual_1 = conversion_1.get_converter(mime_1)
    assert actual_1 == expected_1


# Generated at 2022-06-25 18:52:33.314276
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    Formatting_0 = Formatting(['ugly'], mime='application/json', options={}, stream=sys.stdout)
    Formatting_0.format_body(content='{"title": "foo"}', mime='application/json')


# Generated at 2022-06-25 18:52:42.236952
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    parameters = {
        'groups': ['colors', 'lorem'],
        'env': Environment(),
        'kwargs': {}
    }
    formatting = Formatting(**parameters)
    conversion = Conversion()

    content = 'this is a test'
    mime = 'text/plain'
    maybe_converted_content = conversion.get_converter(mime).convert_to_unicode(content)
    assert formatting.format_body(maybe_converted_content, mime) == maybe_converted_content

    content = 'this is a test'
    mime = 'text/html'
    converted_content = conversion.get_converter(mime).convert_to_unicode(content)
    assert formatting.format_body(converted_content, mime) == converted_content

    content

# Generated at 2022-06-25 18:52:48.167372
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    # Empty string
    format_0 = Formatting(["colors"])
    format_0.format_body("", "text/plain")

    # Valid and invalid string
    format_1 = Formatting(["colors", "colors"])
    format_1.format_body("{", "application/json")

    # A correct json string
    format_2 = Formatting(["colors", "colors"])
    format_2.format_body("{'a':1,'b':2}", "application/json")


# Generated at 2022-06-25 18:52:51.838061
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert(Formatting(groups=[]).format_headers("GET / HTTP/1.1\r\n") == "GET / HTTP/1.1\r\n")


# Generated at 2022-06-25 18:52:54.566175
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(groups=[], env=Environment())
    headers = ""
    assert formatting_0.format_headers(headers) == ""


# Generated at 2022-06-25 18:52:55.421877
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_case_0()

# Generated at 2022-06-25 18:53:10.530527
# Unit test for constructor of class Formatting
def test_Formatting():
    form = Formatting(groups=['colors', 'format'])
    #
    # Unit test for format_body()
    #

# Generated at 2022-06-25 18:53:21.963692
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatter = Formatting(groups=['colors'],
                           colors=True,
                           format='html')
    assert formatter
    mime_type = 'application/json'
    content = '{"name": "John"}'

# Generated at 2022-06-25 18:53:25.112865
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting(['formatting'])
    assert formatting_0.format_body("", "") == ""


# Generated at 2022-06-25 18:53:31.142345
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("docs") == None
    assert Conversion.get_converter("json") == None
    assert Conversion.get_converter("xml") == None
    assert Conversion.get_converter("html") == None
    assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("application/xml"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/html"), ConverterPlugin)


# Generated at 2022-06-25 18:53:32.089259
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting is not None


# Generated at 2022-06-25 18:53:33.050029
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting()


# Generated at 2022-06-25 18:53:42.815386
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.formatting import get_formatter
    formatter = get_formatter('bcolors')
    conversion_0 = Formatting([formatter])
    # To run the unit test, we need to load a saved response body file
    filename = '/home/wli/Documents/httpie/tests/fixtures/response/response-with-non-parseable-content-type-utf8-eof-no-chunked-encoding.bin'
    with open(filename, 'rb') as f:
        content = f.read()
    # We need to specify the mime type of the content
    mime = 'application/octet-stream'
    # We can also specify the level of nesting
    # Normally, we only need to set level to one
    level = 1
    # content = (b'\x00\x01

# Generated at 2022-06-25 18:53:46.997411
# Unit test for constructor of class Formatting
def test_Formatting():
    test_groups = ["colors", "format", "pretty"]
    test_Formatting = Formatting(test_groups, **{'colors': 1})
    assert 'colors' in test_Formatting.enabled_plugins[0].__class__.__name__


# Generated at 2022-06-25 18:53:49.994981
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    mime = 'application/json'

    # invokes method get_converter
    converter = conversion_1.get_converter(mime)

    assert converter is not None



# Generated at 2022-06-25 18:53:51.889852
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = "application/json"
    actual = Conversion.get_converter(mime_0)
    expected = ConverterPlugin
    assert actual == expected


# Generated at 2022-06-25 18:54:01.527219
# Unit test for constructor of class Formatting
def test_Formatting():

    ref_0 = Formatting([], **{})

    test_1 = Formatting(['a'], **{})

    test_2 = Formatting(['b'], **{})

    test_3 = Formatting(['a', 'b'], **{})

    test_4 = Formatting(['a', 'b', 'c'], **{})

    ref_1 = Formatting([], **{})

    ref_2 = Formatting([], **{})

    ref_3 = Formatting([], **{})

    ref_4 = Formatting([], **{})


# Generated at 2022-06-25 18:54:04.257993
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = 2677.6254
    var_0 = is_valid_mime(float_0)


# Generated at 2022-06-25 18:54:06.641665
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = list()
    env = Environment()

# Generated at 2022-06-25 18:54:07.498762
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_case_0()




# Generated at 2022-06-25 18:54:12.663320
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # case0:
    params = {"headers": "abc", "env": "abc"}
    p = Formatting(params)
    var_0 = p.format_body()
    # case1:
    params = {"headers": "abc", "env": "abc"}
    p = Formatting(params)
    var_1 = p.format_body()
    # case2:
    params = {"headers": "abc", "env": "abc"}
    p = Formatting(params)
    var_2 = p.format_body()

# Generated at 2022-06-25 18:54:16.623836
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    n = 1
    groups = ['a']
    env = Environment()
    kwargs = {}
    content = 'a'
    mime = "text/plain"
    obj = Formatting(groups, env, **kwargs)
    for i in range(n):
        res = obj.format_body(content, mime)
        obj.format_body(content, mime)


# Generated at 2022-06-25 18:54:18.210246
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=[])
    h = f.format_headers("")
    assert h == ""
    

# Generated at 2022-06-25 18:54:20.786186
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    float_0 = 2677.6254
    mime_0 = MIME_RE.match(float_0)


# Generated at 2022-06-25 18:54:26.210726
# Unit test for constructor of class Formatting
def test_Formatting():
    # Args for constructor of class Formatting
    groups: List[str] = ["json", "xml", "html", "css", "csv", "tsv", "yaml"]
    kwargs = {}
    env = Environment()
    Formatting(groups, env, **kwargs)


# Generated at 2022-06-25 18:54:34.123780
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import httpie.cli.argtypes
    import tests.utils as utils

    # Test empty input
    with pytest.raises(TypeError) as excinfo:
        Formatting.format_headers()
    assert "format_headers() missing 1 required positional argument: 'headers'" in str(excinfo.value)

    # Test that output matches input with no plugin
    fmt = Formatting([])
    assert fmt.format_headers("") == ""
    assert fmt.format_headers("x") == "x"

    # Test that input and output match
    fmt = Formatting(["colors"])
    assert fmt.format_headers("") == ""

    # Test that output matches input with no plugin
    fmt = Formatting([])
    assert fmt.format_headers("") == ""

    # Test that headers in bold

# Generated at 2022-06-25 18:54:43.735694
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        fu.write_result('\nClass Formatting test fail', 'FAIL')
        raise Exception('\nClass Formatting test fail')
    else:
        fu.write_result('\nClass Formatting test pass', 'PASS')


# Generated at 2022-06-25 18:54:46.855228
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['0']
    env = Environment()
    content = 'string'
    mime = 2677.6254
    Formatting(groups, env, content, mime)


# Generated at 2022-06-25 18:54:50.212653
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['a', 'b', 'c']
    env = Environment()
    kwargs = {'a': 'b', 'c': 'd'}
    obj = Formatting(groups, env, **kwargs)
    assert obj.enabled_plugins == []


# Generated at 2022-06-25 18:54:52.956941
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = 2677.6254
    var_0 = is_valid_mime(float_0)


# Generated at 2022-06-25 18:54:56.511034
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_1 = "application/json"
    for var_2 in plugin_manager.get_converters():
        if var_2.supports(var_1):
            var_3 = var_2(var_1)
            return var_3


# Generated at 2022-06-25 18:55:07.458154
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    float_0 = 2677.6254
    var_1 = is_valid_mime(float_0)
    float_0 = float_0
    float_0 = 2677.6254
    float_1 = float_0
    float_0 = 2677.6254
    float_1 = float_0
    float_1 = float_0
    float_0 = 2677.6254
    float_1 = float_0
    float_1 = float_0
    float_0 = 2677.6254
    float_1 = float_0
    float_1 = float_0
    float_0 = 2677.6254
    float_1 = float_0
    float_1 = float_0
    var_2 = is_valid_mime(float_0)


# Generated at 2022-06-25 18:55:15.668817
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie import ExitStatus
    from utils import http, HTTP_OK

    env = Environment()
    kwargs = {
        'colors': False,
        'zero_in_red': True,
        'max_linelength': 100,
        'reorder_by_cols': True,
        'sort_columns': True,
    }

    r = http('GET', httpbin('/headers'), 'Foo:bar', env)
    assert HTTP_OK in r
    r = Formatting(['json'], env=env, **kwargs).format_body(r, 'application/json')
    result = Formatting(['colors'], env=env, **kwargs).format_body(r, 'application/json')
    assert HTTP_OK in result
    assert ExitStatus.OK == ExitStatus.OK


# Generated at 2022-06-25 18:55:24.906367
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    if is_valid_mime("rgb"):
        var_0 = plugin_manager.get_converters()
        # var_0 = var_0.supports(str("rgb"))
        # var_0 = var_0.supports(ConverterPlugin, "rgb")
        str_0 = str("rgb")
        var_0 = var_0.supports(ConverterPlugin, str_0)
    else:
        var_0 = plugin_manager.get_converters()
        str_0 = str("rgb")
        var_0 = var_0.supports(ConverterPlugin, str_0)


# Generated at 2022-06-25 18:55:34.965510
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = 0.47759712183178037
    float_1 = 0.31511421752102045
    float_2 = 0.8437044097806772

    float_3 = float_1
    float_1 = float_0
    float_0 = float_3

    float_2 = math.sqrt(float_2)
    float_2 = float_2 % float_2
    float_0 = float_1 * float_2
    float_0 = float_1 / float_0

    float_0 = float_0 + float_2
    float_2 = float_1 / float_2
    float_0 = float_2 * float_0
    float_0 = float_0 % float_1

    float_2 = float_0 + float_1

# Generated at 2022-06-25 18:55:36.410222
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = 2677.6254
    var = Conversion.get_converter(float_0)

# Generated at 2022-06-25 18:55:57.022422
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()
    float_19 = float()
    float_20 = float()
    float_21 = float()
    float_22 = float()
    float_23 = float()
    float_24 = float()

# Generated at 2022-06-25 18:56:00.147210
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print("get_converter")
    mime = ''
    expResult = None
    result = Conversion.get_converter(mime)
    print(result)
    #assertEquals(expResult, result)


# Generated at 2022-06-25 18:56:03.925655
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    float_0 = 623.469
    int_0 = 2
    str_0 = 'headers'
    str_1 = ''.join(reversed(str_0))
    var_0 = Formatting([str_0])
    var_1 = var_0.format_headers(str_1)
    assert var_1 == 'sredaeh'


# Generated at 2022-06-25 18:56:05.488011
# Unit test for constructor of class Formatting
def test_Formatting():
    groups0 = ['a', 'b']
    env0 = Environment()
    Formatting(groups = groups0, env = env0)


# Generated at 2022-06-25 18:56:09.609981
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = -2.8421709430404007e-14
    var_0 = is_valid_mime(float_0)
    float_1 = 1.0
    var_1 = is_valid_mime(float_1)
    float_2 = -1.2345
    var_2 = is_valid_mime(float_2)
    float_3 = -1.2345
    var_3 = is_valid_mime(float_3)
    float_4 = 2.8421709430404007e-14
    var_4 = is_valid_mime(float_4)


# Generated at 2022-06-25 18:56:14.221561
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    input_class_0 = Formatting(['colors'], 'headers', False, False)
    input_string_0 = 'HTTP/1.1 200 OK'
    output_string_0 = 'HTTP/1.1 200 OK'
    assert input_class_0.format_headers(
        input_string_0) == output_string_0


# Generated at 2022-06-25 18:56:23.330535
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie import __main__
    from httpie.plugins import FormatterPlugin

    class TestFormatterPlugin(FormatterPlugin):
        def format_body(self, body, mime):
            return body.upper()

    plugin_manager.register(TestFormatterPlugin)
    try:
        args = ["http", "--output-format=json", "http://httpbin.org/headers"]
        __main__.main(args=args)
    finally:
        plugin_manager.unregister(TestFormatterPlugin)

if __name__ == "__main__":
    test_case_0()
    test_Formatting_format_body()

# Generated at 2022-06-25 18:56:31.362531
# Unit test for method format_body of class Formatting

# Generated at 2022-06-25 18:56:40.628678
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    float_0 = 10.0
    str_0 = 'bqLnU'
    float_1 = 6256.0
    float_2 = 42.0
    float_3 = 278.0
    float_4 = 0.0
    float_5 = 1.0
    float_6 = 423.0
    float_7 = 108.0
    float_8 = 4.0
    float_9 = 6.0
    float_10 = 1939.0
    float_11 = 1.0
    float_12 = 429.0
    float_13 = 5.0
    float_14 = 69.0
    float_15 = 2.0
    float_16 = 61741.0
    float_17 = 2.0
    float_18 = 1.0
    float_19 = 549.0
    float

# Generated at 2022-06-25 18:56:43.472528
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = 2677.6254
    var_0 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:57:10.339892
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = 2677.6254
    var_0 = is_valid_mime(float_0)
    var_1 = Conversion.get_converter(var_0)

test_case_0()
test_Conversion_get_converter()

# Generated at 2022-06-25 18:57:11.847324
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # instantiating objects
    fmt = Formatting()
    fmt.format_headers(test_headers)


# Generated at 2022-06-25 18:57:14.317713
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    #TODO: implement unit test
    print("Test: Formatting.format_headers()")
    test_case_0()


# Generated at 2022-06-25 18:57:16.046775
# Unit test for constructor of class Formatting
def test_Formatting():
    var_0 = [1000,1000]
    f = Formatting(var_0)
    


# Generated at 2022-06-25 18:57:26.900946
# Unit test for constructor of class Formatting
def test_Formatting():
    # var_0, var_1, var_2, var_3 and var_4 are
    # in different scope
    var_0 = 1354.5
    var_0 = 3041.6
    var_0 = "foo"
    var_1 = is_valid_mime(var_0)
    var_0 = is_valid_mime(var_0)
    var_2 = list()
    var_2.append(var_0)
    var_2.append(var_1)
    var_2.append(var_0)
    var_0 = False
    var_3 = Environment()
    var_3 = Formatting(var_2, env=var_3)
    var_2 = ""
    var_1 = var_3.format_headers(var_2)
    var_2

# Generated at 2022-06-25 18:57:28.271930
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    float_0 = 2677.6254
    var_0 = Formatting(float_0)
    float_1 = 2677.6254
    var_1 = var_0.format_headers(float_1)


# Generated at 2022-06-25 18:57:29.550660
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = 2677.6254
    var_0 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:57:32.100648
# Unit test for constructor of class Formatting
def test_Formatting():
    print("Testing for Formatting constructor")

    # Positive test case with integer value
    groups = 2
    env = True
    var_0 = Formatting(groups, env)
    if(var_0 == None):
        raise Exception("Constructor is not working properly")




# Generated at 2022-06-25 18:57:35.779223
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    float_0 = 2677.6254
    var_0 = is_valid_mime(float_0)
    var_0 = Formatting(var_0, var_0)
    var_0.format_headers(var_0)


# Generated at 2022-06-25 18:57:42.497435
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_list = []
    float_0 = 2677.6254
    mime = float_0
    var_0 = is_valid_mime(mime)
    if var_0 == True:
        for converter_class in plugin_manager.get_converters():
            pass
    converter_list.append(converter_class)



# Generated at 2022-06-25 18:58:34.207729
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    float_0 = 2677.6254
    var_0 = Formatting((str(float_0),), {}, {'headers': False, 'body': float_0, 'style': str(float_0), 'colors': {'header': {'bg': '#0a0a0a', 'fg': '#ffffff'}, 'body': {'bg': '#0a0a0a', 'fg': '#ffffff'}}}).format_body(str(float_0))


# Generated at 2022-06-25 18:58:36.238161
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    arg_0 = ''
    con = Conversion()
    con.get_converter(arg_0)


# Generated at 2022-06-25 18:58:42.802849
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in available_plugins.keys():
        for cls in available_plugins[group]:
            p = cls()
            if p.enabled:
                enabled_plugins.append(p)
    for p in enabled_plugins:
        p.format_body('abc', 'abc')

# Generated at 2022-06-25 18:58:44.761463
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = 2677.6254
    var_0 = Conversion.get_converter(float_0)



# Generated at 2022-06-25 18:58:47.698273
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        var_0 = Formatting("-F", "--format", env=Environment())
    except Exception:
        raise AssertionError("Formatting constructor threw an exception")


# Generated at 2022-06-25 18:58:48.652965
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    pass # test is not relevant


# Generated at 2022-06-25 18:58:52.089381
# Unit test for constructor of class Formatting
def test_Formatting():
    # Testing case 0:
    print("Testing 'Formatting' class constructor...\n")
    var_0 = Formatting(['formatters'], env=Environment(), **{})
    if var_0 is not None:
        int_0 = var_0.enabled_plugins
        if int_0:
            print("Passed!")
        else:
            print("Failed!")


# Generated at 2022-06-25 18:58:56.152193
# Unit test for constructor of class Formatting
def test_Formatting():
    test_Formatting_0()
    test_Formatting_1()
    test_Formatting_2()
    test_Formatting_3()
    test_Formatting_4()
    test_Formatting_5()


# Generated at 2022-06-25 18:59:06.573217
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test 1
    try:
        str_0 = 3.19349e+208
        result = is_valid_mime(str_0)
        assert not result
    except:
        assert False
    # Test 2
    try:
        float_0 = 5.95202e+307
        result = is_valid_mime(float_0)
        assert result
    except:
        assert False
    # Test 3
    try:
        float_0 = 6.09824e+307
        result = is_valid_mime(float_0)
        assert not result
    except:
        assert False
    # Test 4
    try:
        float_0 = 2.45228e+308
        result = is_valid_mime(float_0)
        assert not result
    except:
        assert False

# Generated at 2022-06-25 18:59:09.592549
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_case_0()

