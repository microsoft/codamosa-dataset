

# Generated at 2022-06-25 18:49:41.440452
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = -329.0
    str_0 = 'application/json'
    list_0 = [str_0]
    list_1 = [float_0]
    float_1 = 848.2
    float_2 = -732.58
    list_2 = [float_2]
    float_3 = -147.7
    int_0 = -735
    int_1 = -689
    tuple_0 = (-930.41, -34.7, -843.6, -489.46)
    float_4 = 749.51
    int_2 = -679
    float_5 = -622.78
    str_1 = 'application/json'
    list_3 = [str_1]
    str_2 = 'application/json'

# Generated at 2022-06-25 18:49:44.667780
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env_0 = Environment()
    groups_0 = ['colors']
    class_0 = Formatting(groups_0, env_0, pretty=True)
    class_0.format_headers('headers')


# Generated at 2022-06-25 18:49:47.939921
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env_0= Environment()
    kwargs_0= {}
    formatting_0 = Formatting([], env=env_0, **kwargs_0)

    # 
    assert not formatting_0.format_headers('')


# Generated at 2022-06-25 18:49:50.992174
# Unit test for constructor of class Formatting
def test_Formatting():
    # check the number of arguments
    env = Environment()
    try:
        Formatting()
        Formatting(env)
        Formatting(env, 10)
    except TypeError:
        return

    assert False


# Generated at 2022-06-25 18:49:54.964266
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = [float_0]
    conversion_0 = Conversion(*list_0)
    float_1 = 32.0
    list_1 = [float_1]
    formatting_0 = Formatting(*list_1)
    try:
        formatting_0.format_body(str_0, str_1)
        assert False
    except TypeError:
        pass
    finally:
        conversion_0.close()


# Generated at 2022-06-25 18:50:01.286228
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = -364.4
    list_0 = [float_0]
    conversion_0 = Conversion(*list_0)
    list_1 = [float_0]
    conversion_1 = Conversion(*list_1)
    float_0 = 2.447173541815841
    list_0 = [float_0]
    conversion_3 = Conversion(*list_0)
    list_0 = [float_0]
    conversion_2 = Conversion(*list_0)


# Generated at 2022-06-25 18:50:07.097545
# Unit test for constructor of class Formatting
def test_Formatting():
    class_0 = Formatting
    method_0 = class_0.__init__
    unicode_0 = u'content'
    list_0 = ['content',  unicode_0]
    class_0 = test_Formatting.Formatting
    list_1 = [class_0]
    class_1 = Environment
    instance_0 = class_1()
    method_0(instance_0, *list_0, **list_1)

test_case_0()
test_Formatting()

# Generated at 2022-06-25 18:50:09.170365
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting([None, '0'], True, [None]*1, Environment(None)) is not None


# Generated at 2022-06-25 18:50:10.403970
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    conversion_0 = Conversion(*list([]))
    return conversion_0


# Generated at 2022-06-25 18:50:10.834775
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert True


# Generated at 2022-06-25 18:50:14.950195
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'qk4m4Ibx|Md'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)

# Generated at 2022-06-25 18:50:22.080475
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'R\x03\xa2\x98\x96\x01\xd3;\xfc\xeb\x8b\x1d\xd1'
    str_1 = 'N.G\x9d]\xb7\xb3\x93-\xaa\xffF'
    conversion_0 = Conversion()
    str_2 = 'K\x98\xd8\x00\xb3\x10\x7fT\x0f\xae\x9f\x92\\\xc2'
    optional_0 = conversion_0.get_converter(str_2)

# Generated at 2022-06-25 18:50:33.499913
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'TKj!h+PX9(|t&L-E[e@$K#W^+A,s}Mq*BT)1Q>'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    optional_0.format_body()
    optional_0 = conversion_0.get_converter(str_0)
    optional_0.format_body()
    optional_0 = conversion_0.get_converter(str_0)
    optional_0.format_body()
    optional_0 = conversion_0.get_converter(str_0)
    optional_0.format_body()
    optional_0 = conversion_0.get_converter(str_0)
    optional_0.format

# Generated at 2022-06-25 18:50:40.567766
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    env_0 = Environment()
    # Test with class Formatting
    formatting_0 = Formatting(groups_0, env_0)
    # Test with class Formatting
    formatting_1 = Formatting(groups_0)
    # Test with class Formatting
    formatting_2 = Formatting(groups_0, env_0)
    assert formatting_0 is not None
    assert formatting_1 is not None
    assert formatting_2 is not None


# Generated at 2022-06-25 18:50:48.901933
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_2 = Conversion()
    str_2 = 'P|b"P[p\x7f42a'
    optional_1 = conversion_2.get_converter(str_2)
    conversion_3 = Conversion()
    str_3 = '$Zn\x7f'
    optional_2 = conversion_3.get_converter(str_3)
    conversion_4 = Conversion()
    str_4 = 'mX?mz\x7f'
    optional_3 = conversion_4.get_converter(str_4)
    conversion_5 = Conversion()
    str_5 = '+?<h\x7f'
    optional_4 = conversion_5.get_converter(str_5)
    conversion_6 = Conversion()

# Generated at 2022-06-25 18:50:51.640493
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = []
    assert Formatting(groups, env) is not None

# Generated at 2022-06-25 18:51:02.295631
# Unit test for constructor of class Formatting
def test_Formatting():
    dummy_plugins = [DummyPlugin(dummy_feature),
                     DummyPlugin(dummy_feature, True),
                     DummyPlugin(dummy_feature),
                     DummyPlugin(other_feature, True),
                     DummyPlugin(dummy_feature, True),
                     DummyPlugin(other_feature)]
    plugin_manager.add(dummy_plugins)
    try:
        formatting = Formatting(['dummy'])
        assert formatting.enabled_plugins == [dummy_plugins[1], dummy_plugins[4]]
        assert formatting.format_headers('foo') == 'foo' # just return the input
        assert formatting.format_body('foo', 'application/json') == 'foo'


    finally:
        plugin_manager.remove(dummy_plugins)

# Generated at 2022-06-25 18:51:04.840859
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    arg_1 = Environment()
    arg_2 = arg_1 = arg_0 = arg = Formatting(groups_0, arg_1)


# Generated at 2022-06-25 18:51:07.205858
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        assert isinstance(Formatting, object)
    except AssertionError as e:
        print("AssertionError raised")


# Generated at 2022-06-25 18:51:13.525601
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    available_plugins_0 = plugin_manager.get_formatters_grouped()
    enabled_plugins_0 = []
    for str_1 in [str_0]:
        for cls_0 in available_plugins_0[str_1]:
            p = cls_0()
            if p.enabled:
                enabled_plugins_0.append(p)
    header = enabled_plugins_0[0].format_headers('HTTP/1.1 200 OK')
    assert 'Content-Type' in header


# Generated at 2022-06-25 18:51:21.229885
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'application/xml'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0.__class__.__name__ == 'JSONConverter'


# Generated at 2022-06-25 18:51:31.096546
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'l}i'
    str_1 = 'g=BA'
    str_2 = 'o-gC'
    str_3 = 'b~|\n'
    list_0 = [str_1, None, str_0]
    list_1 = [None, str_3, str_1]
    formatting_0 = Formatting(list_1, )
    str_4 = 'SX'
    str_5 = 'Y|'
    str_6 = 'b$uUsYHsSPEje7d\n$qR|'
    str_7 = '~L6@1'
    assert formatting_0.format_body(str_1, str_0) == 'g=BA', 'format_body() fails'

# Generated at 2022-06-25 18:51:38.044709
# Unit test for constructor of class Formatting
def test_Formatting():

    groups = ['highlighters', 'json', 'colors']
    env = Environment()
    kwargs = {}
    test = Formatting(groups, env, **kwargs)
    assert test.enabled_plugins

    # Test entry point for plugins
    plugin_manager.get_formatters_grouped()

    # Test entry point for style
    plugin_manager.get_style()

# Test case for class Conversion

# Generated at 2022-06-25 18:51:46.787658
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'application/json'
    str_1 = '"{}"'.format('"')
    str_2 = '"'.format('"')
    str_3 = '{'
    str_4 = '}'
    str_5 = '{}'.format('"')
    str_6 = '{'
    str_7 = '}'
    str_8 = '"{}"'.format('"')
    str_9 = '{'
    str_10 = '}'
    str_11 = '{}'.format('"')
    str_12 = '{'
    str_13 = '}'
    str_14 = '{}'.format('"')
    str_15 = '{'
    str_16 = '}'
    str_17 = '{}'.format('"')

# Generated at 2022-06-25 18:51:49.210437
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'LK0e&L'
    environment_0 = Environment()
    Formatting((str_0,), environment_0)


# Generated at 2022-06-25 18:51:51.225559
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    arg_1 = ""
    conversion_0 = Conversion()
    assert conversion_0.get_converter(arg_1) is not None

# Generated at 2022-06-25 18:51:56.311050
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = 'a1Qgf$6?5U}O5U'
    str_1 = 'lF|d,!y@X>Kj)k'
    str_2 = 'Z*[:~g2K.e'
    available_plugins_0 = plugin_manager.get_formatters_grouped()
    conversion_0 = Formatting([str_0, str_1, str_2], available_plugins_0)

# Generated at 2022-06-25 18:52:05.234308
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    groups_0 = [str_0, str_0]
    str_1 = 'b$uUsYHsSPEje7d\n$qR|'
    formatting_0 = Formatting(groups_0, headers=str_0)
    str_2 = 'b$uUsYHsSPEje7d\n$qR|'
    output_0 = formatting_0.format_headers(str_1)
    assert str_2 == output_0


# Generated at 2022-06-25 18:52:07.809884
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    optional_0 = Formatting(str_0)


# Generated at 2022-06-25 18:52:11.032732
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ["highlighters"]
    try:
        optional_0 = Formatting(groups_0)
    except:
        print('Test Failed')
    else:
        print('Test Passed')


# Generated at 2022-06-25 18:52:21.449443
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = ':aq_MvnM$'
    str_1 = 'C\x1c'
    str_2 = 'application/json'

# Generated at 2022-06-25 18:52:25.495977
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:52:28.582477
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = ''
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 == None


# Generated at 2022-06-25 18:52:31.560174
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)

# Generated at 2022-06-25 18:52:34.721869
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:52:37.411118
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = list()
    formatting_0 = Formatting(groups_0)
    str_0 = 'p#SkSp!jKmY]B'
    str_1 = formatting_0.format_headers(str_0)



# Generated at 2022-06-25 18:52:39.643673
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'text/html'
    str_1 = '&'
    formatting_0 = Formatting([])
    str_2 = formatting_0.format_body(str_1, str_0)


# Generated at 2022-06-25 18:52:42.736936
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'text/html'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:52:46.832538
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    groups = ['headers']
    formatting_0 = Formatting(groups)
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    formatting_0.format_headers(str_0)
    conversion_0 = Conversion()
    conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:52:51.673633
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'application/json'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    if (optional_0.get_converter(str_0) != None):
        optional_0.process_bytes(str_0)

# Generated at 2022-06-25 18:52:59.122731
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    if optional_0 is not None:
        optional_0.get_mime()


# Generated at 2022-06-25 18:53:05.759344
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    str_1 = 'application/xml'
    formatting_0 = Formatting([], Environment())
    value = formatting_0.format_body(str_0, str_1)
    assert value is not None


# Generated at 2022-06-25 18:53:10.366723
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_1 = 'kK0aT:G<0'
    str_2 = 'nf7\"H\"n4jKZ\u0016'
    conversion_1 = Conversion()
    formatting_0 = Formatting(conversion_1.get_converter(str_1))
    try:
        formatting_0.format_headers(str_2)
    except ValueError:
        pass


# Generated at 2022-06-25 18:53:16.538555
# Unit test for constructor of class Formatting
def test_Formatting():
    # NameError
    try:
        Formatting('')
    except NameError:
        print('NameError')
    # AttributeError
    try:
        Formatting(1)
    except AttributeError:
        print('AttributeError')
    # KeyError
    try:
        Formatting('qwer')
    except KeyError:
        print('KeyError')


# Generated at 2022-06-25 18:53:19.500630
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    args = ['application/json']
    expected = 'application/json'
    output = Conversion.get_converter(args[0]).mime
    assert output == expected


# Generated at 2022-06-25 18:53:27.982286
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'application/json'

# Generated at 2022-06-25 18:53:29.418200
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 0
    test_Formatting_format_body_0()



# Generated at 2022-06-25 18:53:34.459798
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = '~*F6U5!d.\nh\n(X}'
    formatting_0 = Formatting([str_0])
    str_1 = '~*F6U5!d.\nh\n(X}'
    str_2 = 'application/json'
    assert formatting_0.format_body(str_1, str_2) == '~*F6U5!d.\nh\n(X}'


# Generated at 2022-06-25 18:53:39.160020
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '@1\n\\<'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)

if __name__ == '__main__':
    test_case_0()
    test_Conversion_get_converter()

# Generated at 2022-06-25 18:53:49.052906
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    available_plugins_0 = formatters = list(plugin_manager.get_formatters())
    env_0 = Environment()
    enabled_plugins_0 = []
    for available_plugins_1 in available_plugins_0:
        p_0 = available_plugins_1(env=env_0)
        if p_0.enabled:
            enabled_plugins_0.append(p_0)
    groups_0 = ['colors']
    kwargs_0 = {}
    formatting_0 = Formatting(groups=groups_0, env=env_0, **kwargs_0)
    content_0 = 'xn\u000e'
    mime_0 = 'j\u0004'
    formatting_0.format_body(content=content_0, mime=mime_0)


# Generated at 2022-06-25 18:53:59.812883
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['Pretty']
    env = Environment()
    kwargs = {}

    formatting_0 = Formatting(groups, env, **kwargs)

    test_Formatting.enabled_plugins = formatting_0.enabled_plugins


# Generated at 2022-06-25 18:54:05.215722
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = 'x-www-form-urlencoded'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(mime_0)
    optional_1 = conversion_0.get_converter(mime_0)
    optional_0.process_body('', mime_0)
    optional_1.process_body('', mime_0)
    optional_0.get_converter(mime_0)
    optional_1.get_converter(mime_0)
    optional_0.process_body('', mime_0)
    optional_1.process_body('', mime_0)


# Generated at 2022-06-25 18:54:06.683526
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    Formatting(groups_0)


# Generated at 2022-06-25 18:54:09.916527
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    if not optional_0:
        assert(False)


# Generated at 2022-06-25 18:54:13.281348
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'wC|+?NQ2l'
    groups_0 = ['group-0', 'group-1']
    str_1 = 'Pr4\nJ6D"+6o<'
    formatting_0 = Formatting(groups_0)
    headers_0 = formatting_0.format_headers(str_1)

# Generated at 2022-06-25 18:54:17.523771
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'unicode', 'format']
    env=Environment()
    kwargs = {'loglevel': 'loglevel', 'headers': 'headers', 'body': 'body', 'style': 'style', 'force_colors': 'force_colors', 'implicit_content_type': 'implicit_content_type'}
    obj = Formatting(groups, env, **kwargs)


# Generated at 2022-06-25 18:54:28.470564
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    string_0 = 'a+`"}}xl 7jZ5 !5f5Y31}QM'
    string_1 = 'X_"cv8'
    string_2 = '"f5bN`*'
    string_3 = 'O/~XB'
    list_0 = [string_0, string_1]
    formatting_0 = Formatting(list_0)
    string_4 = 'f<q3=x'
    string_5 = '|Y#'
    list_1 = [string_4, string_5, string_2]
    formatting_1 = Formatting(list_1)
    string_6 = ' `Mf^M'
    string_7 = 'i~|'
    list_2 = [string_3, string_6, string_7]
    formatting

# Generated at 2022-06-25 18:54:29.885459
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    conversion_0.get_converter(None)


# Generated at 2022-06-25 18:54:32.529888
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for default args
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    formatting_0 = Formatting()
    str_1 = formatting_0.format_body(str_0)


# Generated at 2022-06-25 18:54:34.177420
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    assert conversion_0.get_converter('text/html') is not None
    assert conversion_0.get_converter('application/javascript') is not None


# Generated at 2022-06-25 18:54:45.113395
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = ';ouJE,F*8xqHk'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:54:48.572134
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'N\n{V.p5H~zG$[p'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:54:51.482870
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'r$/|w_f\x7f\\\\\x7f\x7f_mXy'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:54:56.132189
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    kwargs = {'theme': 'default'}
    env = Environment()
    formatting_0 = Formatting(groups, **kwargs)
    assert formatting_0.enabled_plugins
    formatting_1 = Formatting(env=env, **kwargs)
    assert formatting_1.enabled_plugins


# Generated at 2022-06-25 18:55:05.884101
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'UTF-8'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 == None
    conversion_1 = Conversion()
    optional_1 = conversion_1.get_converter(str_0) 
    assert optional_1 == None
    str_1 = 'us-ascii'
    conversion_2 = Conversion()
    optional_2 = conversion_2.get_converter(str_1)
    assert optional_2 == None
    conversion_3 = Conversion()
    optional_3 = conversion_3.get_converter(str_0) 
    assert optional_3 == None


# Generated at 2022-06-25 18:55:10.345448
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = []
    environment_0 = Environment()
    formatting_0 = Formatting(groups_0, environment_0)
    str_0 = 'X\r\r\r\r\r\r\r'
    str_1 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:55:12.177871
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = 'QO~'
    list_0 = [str_0]
    formatting_0 = Formatting(list_0)


# Generated at 2022-06-25 18:55:14.641276
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'Content-Type'
    str_1 = 'application/json'
    groups_0 = ['XML', 'JSON', 'HTML', 'terminal']
    formatting_0 = Formatting(groups_0)
    optional_0 = formatting_0.format_headers(str_0)
    optional_1 = formatting_0.format_headers(str_1)


# Generated at 2022-06-25 18:55:18.925582
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    conversion_0 = Conversion()
    str_0 = 'Aplication/json'
    assert conversion_0.get_converter(str_0) == None


# Generated at 2022-06-25 18:55:22.611282
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    groups_0 = ['pygments', 'colors']
    formatting_0 = Formatting(groups_0, env)
    assert formatting_0.format_body(str_1, str_1) == str_0

# Generated at 2022-06-25 18:55:46.240979
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Instantiate an object of class Formatting
    formatting_0 = Formatting(['colors'])
    # Call method format_body of object formatting_0 with the following parameters
    str_0 = 'b$uUsYHsSPEje7d\\n$qR|'
    str_1 = 'application/json'
    str_0 = formatting_0.format_body(str_0, str_1)


# Generated at 2022-06-25 18:55:53.094717
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print('Test #1')
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    formatting_0 = Formatting([]);
    try:
        formatting_0.format_headers(str_0)
    except Exception as e:
        print('Error:', e)


# Generated at 2022-06-25 18:55:58.991829
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    arg0 = Formatting([])
    arg1 = 'b$uUsYHsSPEje7d\n$qR|'
    str_1 = arg0.format_body(arg1, str_0)


# Generated at 2022-06-25 18:56:06.349633
# Unit test for constructor of class Formatting
def test_Formatting():
    # 1
    groups = ['b$uUsYHsSPEje7d\n$qR|']
    env = 'Environment()'
    Formatting(groups, env)
    # 2
    groups = ['[vE,P4\\O *>0yX?|z\t']
    env = 'Environment()'
    Formatting(groups, env)
    # 3
    groups = ['vdXC)D>ARz8W(<b]U6"']
    env = 'Environment()'
    Formatting(groups, env)
    # 4
    groups = [')nFUm<N`Nd"^n@$]Q*(']
    env = 'Environment()'
    Formatting(groups, env)
    # 5

# Generated at 2022-06-25 18:56:09.169267
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '?N0et+'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:56:13.626621
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '1.1'
    str_1 = 'OK'
    str_2 = 'HTTP'
    str_3 = 'application/json'
    str_4 = '5/5'
    str_5 = 'C\rD\rB\rA'
    str_6 = 'b$uUsYHsSPEje7d\n$qR|'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_6)
    formatting_0 = Formatting([str_0, str_1, str_2, str_3, str_4, str_5])
    headers = formatting_0.format_headers(str_6)


# Generated at 2022-06-25 18:56:17.274901
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(['K'])
    string_0 = ''
    string_1 = formatting_0.format_headers(string_0)
    assert string_1 != ''


# Generated at 2022-06-25 18:56:20.049227
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = ['tbody']
    formatting_0 = Formatting(groups_0)
    assert_equal(formatting_0.format_headers('tbody'), 'tbody')

# Test case 0

# Generated at 2022-06-25 18:56:24.030625
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:56:24.895963
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pass


# Generated at 2022-06-25 18:56:41.629733
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    if True:
        assert True


# Generated at 2022-06-25 18:56:50.355323
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '\na~Y'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    if not optional_0 is None:
        optional_0 = None
    conversion_1 = Conversion()
    optional_1 = conversion_1.get_converter(str_0)
    if not optional_1 is None:
        optional_1 = None
    conversion_2 = Conversion()
    optional_2 = conversion_2.get_converter(str_0)
    if not optional_2 is None:
        optional_2 = None
    conversion_3 = Conversion()
    optional_3 = conversion_3.get_converter(str_0)
    if not optional_3 is None:
        optional_3 = None
    conversion_4 = Conversion()

# Generated at 2022-06-25 18:56:51.082034
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print('')


# Generated at 2022-06-25 18:56:53.177111
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '0V(wp3'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:56:58.136791
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'application/json'
    converter_0 = plugin_manager.get_converters()[2]()
    converter_0.mime = 'application/json'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    assert isinstance(optional_0, type(converter_0))


# Unit tests for methods of class Formatting

# Generated at 2022-06-25 18:57:02.126761
# Unit test for constructor of class Formatting
def test_Formatting():
    arg0 = [u'colors']
    arg1 = Environment()
    arg2 = {u'colors': True}
    # Type error
    #Formatting(arg0, arg1, **arg2)
    Formatting(arg0, **arg2)
    Formatting(arg0)
    Formatting(arg0, **{})
    Formatting(arg0, **{u'colors': False})


# Generated at 2022-06-25 18:57:09.948839
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """Test for method get_converter of class Conversion"""

    conversion_0 = Conversion()
    if True:
        # If a valid MIME type is passed, then the method should return a converter
        str_0 = 'application/json'
        optional_0 = conversion_0.get_converter(str_0)
        assert optional_0.mime == str_0
    if True:
        # If an invalid MIME type is passed, then the method should return none
        str_0 = '*/*'
        optional_0 = conversion_0.get_converter(str_0)
        assert optional_0 is None


# Generated at 2022-06-25 18:57:21.921484
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'application/json'
    str_1 = '{\\n\\"args\\": {},\\n\\"data\\": \\"\",\\n\\"files\\": {},\\n\\"form\\": {},\\n\\"headers\\": {\\n\\"Accept\\": \\"*/*\\",\\n\\"Accept-Encoding\\": \\"gzip, deflate\\",\\n\\"Host\\": \\"httpbin.org\\",\\n\\"User-Agent\\": \\"HTTPie/0.9.8\\"\\n},\\n\\"json\\": null,\\n\\"origin\\": \\"83.164.222.73\\",\\n\\"url\\": \\"https://httpbin.org/get\\"\\n}'
    formatting_0 = Formatting([])
    str_2

# Generated at 2022-06-25 18:57:25.205858
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['pygments']
    env = Environment()
    formatting_0 = Formatting(groups, env)
    assert formatting_0
    assert formatting_0.enabled_plugins

# Generated at 2022-06-25 18:57:32.239607
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Setup
    str_0 = 'j+L2\x7FJ(9B$F;n?\x7F|Y'
    str_1 = '+&%z{pZb5H5}Xx=\t!l'
    str_2 = 'm7{z\t&'
    list_0 = [str_1, str_2]
    str_3 = 'L$E+pB\t#rF/^d_\x7FE%'
    formatting_0 = Formatting(list_0, str_3)
    str_4 = 'p5@\x7Fnxg{*^oVu'
    str_5 = '?'
    str_6 = 'Z?\x7F[xKk)x=m#w$H'
    str_7

# Generated at 2022-06-25 18:58:13.882062
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test 1
    local_final = None
    def check_res(result):
        global local_final 
        local_final = result
    try:
        str_0 = 'b$uUsYHsSPEje7d\n$qR|'
        conversion_0 = Conversion()
        optional_0 = conversion_0.get_converter(str_0)

        check_res(isinstance(optional_0, ConverterPlugin))
    except ValueError:
        check_res(True)



# Generated at 2022-06-25 18:58:15.008676
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print('Start test...')
    from test_formatter import test_case_0
    test_case_0()

# Generated at 2022-06-25 18:58:23.586025
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.context import Environment

    # Test with groups = ['colors', 'formatters']
    groups = ['colors', 'formatters']
    env = Environment()
    kwargs = {}
    formatting_0 = Formatting(groups, env, **kwargs)
    assert formatting_0.enabled_plugins == []

    # Test with groups = ['colors', 'formatters']
    groups = ['colors', 'formatters']
    env = Environment()
    kwargs = {}
    formatting_1 = Formatting(groups, env, **kwargs)
    assert formatting_1.enabled_plugins == []

# Generated at 2022-06-25 18:58:32.513806
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = ']\x1f|\x1b"n\x15l\x13\x16\x1e\x1e\x18\x1a\x19U6\x1b\x15\x12\x10\x1cV}'
    str_1 = 'QuH\x1b'

# Generated at 2022-06-25 18:58:36.370855
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    formatting_0 = Formatting([str_0])
    str_1 = 'S$bY|i\n{zK"d5ZO9NjK$'
    str_2 = 'aPN6U1!k8f'
  

# Generated at 2022-06-25 18:58:46.784999
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = ['yPd{5P', '5bvCZ&']
    env = Environment()
    formatting_0 = Formatting(list_0, env)
    list_1 = ['x.%f.9>', 'eY-fT+T*bG&', '<U@>6', 'QH4h4{Cg']
    formatting_0 = Formatting(list_1, env)
    env = Environment()
    list_2 = ['x.%f.9>', 'eY-fT+T*bG&', '<U@>6', 'QH4h4{Cg']
    formatting_0 = Formatting(list_2, env)

# Generated at 2022-06-25 18:58:53.382885
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'text/html'
    str_1 = '\r\n'
    str_3 = '\r\n'
    str_5 = '\r\n'
    str_7 = 'c'
    str_9 = 'a'
    str_11 = '\r\n'
    str_13 = '\r\n'
    str_15 = 'a'
    str_17 = '\r\n'
    str_19 = '\r\n'
    str_21 = '\r\n'
    str_23 = '\r\n'
    str_25 = '\r\n'
    str_27 = '\r\n'
    str_29 = '\r\n'
    str_31 = '\r\n'

# Generated at 2022-06-25 18:58:58.309665
# Unit test for constructor of class Formatting
def test_Formatting():
    # Try to create an object with valid group name
    groups_0 = ['color']
    formatting_0 = Formatting(groups_0)

    # Try to create an object with invalid group name
    groups_1 = ['invalid_name']
    formatting_1 = Formatting(groups_1)


# Generated at 2022-06-25 18:59:06.241071
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    fmt = Formatting(['highlight'], theme='paraiso-dark')
    mime = 'application/json'
    body = '{"key":"value"}'
    f = fmt.format_body(body, mime)
    expected = """\x1b[94m{\x1b[39m\x1b[92m"key"\x1b[39m\x1b[93m:\x1b[39m\x1b[92m"value"\x1b[39m\x1b[94m}\x1b[39m"""
    assert f == expected

# Generated at 2022-06-25 18:59:11.734627
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'b$uUsYHsSPEje7d\n$qR|'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)

