

# Generated at 2022-06-25 18:49:28.028986
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    float_0 = Formatting([])
    str_0 = ''
    str_1 = float_0.format_headers(str_0)


# Generated at 2022-06-25 18:49:31.702079
# Unit test for constructor of class Formatting
def test_Formatting():
    obj_expect = None
    obj_actual = Formatting(['html', 'colors'])
    obj_return = assertEqual(obj_actual, obj_expect)


# Generated at 2022-06-25 18:49:34.023994
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    obj_0 = Formatting("headers", Environment())
    obj_0.format_body("text/plain", "application/json")


# Generated at 2022-06-25 18:49:36.202439
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = str()
    ConverterPlugin.supports(mime)
    assert Conversion.get_converter(mime)


# Generated at 2022-06-25 18:49:40.183207
# Unit test for constructor of class Formatting
def test_Formatting():
    obj = Formatting(['groups'], Environment())
    # Asserts that the enabled_plugins attribute is a list
    assert isinstance(obj.enabled_plugins, list)
    # Asserts that the enabled_plugins attribute is empty
    assert not obj.enabled_plugins


# Generated at 2022-06-25 18:49:44.887534
# Unit test for constructor of class Formatting
def test_Formatting():
    print('Test for constructor of class Formatting')
    # 1. No exception thrown
    format_test = Formatting(['colors'], env=Environment())
    # 2. Constructor with wrong paramaters
    try:
        format_test = Formatting(['colors, colors'], env=Environment())
    except Exception:
        print("Constructor with wrong paramaters")
    

# Generated at 2022-06-25 18:49:47.073314
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = None
    float_0 = []
    mime = float_0
    float_0 = Formatting(mime)

# Generated at 2022-06-25 18:49:51.141171
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    env = Environment()
    for group in available_plugins:
        for cls in available_plugins[group]:
            p = cls(env=env)
            if p.enabled:
                enabled_plugins.append(p)

# Generated at 2022-06-25 18:49:52.159689
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_case_0()

# Generated at 2022-06-25 18:49:58.935923
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    conversion = Conversion()
    data = {'test_0':'2'}
    float_0 = 'application/json'
    # Create an instance of class Formatting
    formatting = Formatting(groups=[], env=Environment(), **data)
    # Test method format_body
    str_0 = formatting.format_body(conversion, float_0)


# Generated at 2022-06-25 18:50:10.021855
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # fmt: off
    # No Format
    # var_0
    # fmt: on
    var_0 = str()
    var_0 = '*/*'
    # fmt: off
    # No Format
    # var_0
    # fmt: on
    var_0 = '*/*'
    var_0 = 'applic ation/json'
    # fmt: off
    # No Format
    # var_0
    # fmt: on
    var_0 = 'applic ation/json'
    var_0 = 'application/json'
    # fmt: off
    # No Format
    # var_0
    # fmt: on
    var_0 = 'application/json'
    var_0 = 'application/xml'
    # fmt: off
    # No Format
    # var_0
   

# Generated at 2022-06-25 18:50:11.829295
# Unit test for constructor of class Formatting
def test_Formatting():
    var_0 = list()
    var_0.append("tabulate")
    var_1 = Formatting(var_0)


# Generated at 2022-06-25 18:50:13.285432
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = str()
    var_1 = Conversion.get_converter(var_0)


# Generated at 2022-06-25 18:50:14.660354
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = [str()]
    obj = Formatting(groups)
    test_case_0()


# Generated at 2022-06-25 18:50:15.583344
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 18:50:18.280479
# Unit test for constructor of class Formatting
def test_Formatting():
    var_0 = [str()]
    var_1 = Environment()
    Formatting(var_0, var_1)
    try:
        Formatting()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 18:50:21.182898
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = list()
    env = Environment()
    kwargs = dict()
    formatting = Formatting(groups, env=env, **kwargs)

    body = str()
    mime = str()
    result = formatting.format_body(body, mime)
    assert False


# Generated at 2022-06-25 18:50:22.208863
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    var_0 = Formatting(groups=['colors'])

# Generated at 2022-06-25 18:50:25.506888
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = list()
    env = httpie.context.Environment()
    kwargs = dict()
    x = Formatting(groups, env, **kwargs)


# Generated at 2022-06-25 18:50:29.317139
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = 'application/json'
    var_1 = Conversion.get_converter(var_0)
    var_2 = (var_1 is not None)
    assert var_2 == True


# Generated at 2022-06-25 18:50:36.220850
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = None
    env = Environment()
    obj = Formatting(groups, env)
    assert obj.enabled_plugins == []


# Generated at 2022-06-25 18:50:38.398352
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('text/html;charset=UTF-8'),
                      ConverterPlugin)



# Generated at 2022-06-25 18:50:43.143676
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion = Conversion()
    mime = 'application/json'
    result = conversion.get_converter(mime)
    print(result.content_type)
    expected = "application/json"
    assert result.content_type == expected, f"testcase failed: expected: {expected}, actual: {result.content_type}"

# Generated at 2022-06-25 18:50:44.882059
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    float_1 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:50:48.251783
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatters = Formatting(['colors'])
    result = formatters.format_headers('X-Foo: Bar')
    # assert result == '\x1b[37m\x1b[1mX-Foo:\x1b[22m \x1b[36mBar\x1b[39m'



# Generated at 2022-06-25 18:50:50.641638
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:50:53.049974
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:50:55.041948
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # 1. Run
    # 2. Assert
    print('')


# Generated at 2022-06-25 18:50:56.951528
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:50:59.605691
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    fmt = Formatting([], env=env)
    a = fmt.format_body('body', 'mime')
    assert a == 'body'


# Generated at 2022-06-25 18:51:03.457719
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_2 = None
    var_1 = Conversion.get_converter(float_2)


# Generated at 2022-06-25 18:51:09.057694
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    def func1(mime):
        if mime:
            return
        return None
    def func2():
        return []
    def func3():
        return [func1]
    def func4(mime):
        return k
    def func5(mime):
        return func4(mime)
    func1 = func2
    k = func2()
    func2 = func3
    print(Conversion.get_converter(func1))


# Generated at 2022-06-25 18:51:20.136557
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # arrange
    groups = [
        'colors',
    ]
    env = Environment(stdin=io.StringIO(), stdout=io.StringIO(),
            stdin_isatty=False, stdout_isatty=False,
            is_windows=False,
            config=ScriptTestConfiguration(args=['--print-headers'], env=env))

    formatting = Formatting(groups, env=env)
    headers = 'HTTP/1.1 200 OK'

    # act
    actual = formatting.format_headers(headers)

    # assert
    assert actual == '\x1b[94mHTTP/1.1 200 OK\x1b[0m'



# Generated at 2022-06-25 18:51:25.778851
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    float_0 = None
    str_0 = None
    float_1 = None
    obj_0 = Formatting(float_1)
    obj_1 = Conversion.get_converter(float_0)
    if obj_1 != None:
        obj_0.enabled_plugins = [obj_1]
    obj_0.format_body(str_0, float_0)


# Generated at 2022-06-25 18:51:27.905789
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_1 = None
    var_7 = Conversion.get_converter(float_1)
    assert var_7 is None




# Generated at 2022-06-25 18:51:29.864134
# Unit test for constructor of class Formatting
def test_Formatting():
    unit_test_0 = bool()
    var_0 = Formatting(unit_test_0, unit_test_0)


# Generated at 2022-06-25 18:51:33.090644
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """Asserts true if the method Formatting.format_body(str,str) returns appropriate result
    """
    float_0 = None
    var_0 = Formatting(["default", "colors"],
                       Environment()).format_body("foo", float_0)
    assert_equals(var_0, "foo")

# Generated at 2022-06-25 18:51:34.197802
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    pass


# Generated at 2022-06-25 18:51:36.294134
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    obj = Formatting()
    obj.format_body('content', 'mime')


# Generated at 2022-06-25 18:51:38.362815
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conv = Conversion()
    assert conv.get_converter('application/json') == None


# Generated at 2022-06-25 18:51:41.604016
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:51:42.741082
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting


# Generated at 2022-06-25 18:51:44.266716
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:51:46.045964
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_1 = "*/json"
    var_1 = Conversion.get_converter(float_1)


# Generated at 2022-06-25 18:51:48.118876
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    float_0 = None
    var_0 = Formatting(float_0)
    str_0 = ""
    var_0.format_headers(str_0)


# Generated at 2022-06-25 18:51:53.386229
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """

    Checks if the method get_converter return the
    correct value.

    :return: pass or failed.
    """
    conversion = Conversion()
    is_valid_mime_0 = is_valid_mime(None)
    converter_class_0 = "application/json"
    var_0 = conversion.get_converter(converter_class_0)
    assert var_0 is not None


# Generated at 2022-06-25 18:51:57.666612
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    float_1 = 1.0
    float_2 = float_1
    str_1 = "\"text/plain\""
    str_2 = str_1
    # we are passing the float_1 object (recall that Python is call-by-object)
    str_3 = Formatting.format_body(float_2, str_2)


# Generated at 2022-06-25 18:51:58.544890
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_case_1()


# Generated at 2022-06-25 18:52:01.101359
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = None
    list_0 = [float_0]
    var_0 = Formatting(list_0)


# Generated at 2022-06-25 18:52:03.976215
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    tester = Conversion
    var_0 = 'application/json'
    con = tester.get_converter(var_0)
    assert(con.supported_mimes == ["application/json"])



# Generated at 2022-06-25 18:52:10.556584
# Unit test for constructor of class Formatting
def test_Formatting():
    text_0 = None
    float_0 = None
    groups_0 = [text_0, float_0]
    text_1 = Formatting(groups_0)

# Generated at 2022-06-25 18:52:15.432161
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    references: List[Tuple[str, str]] = [
        ('text/csv', 'CsvConverter'),
        ('text/json', 'Json2HtmlConverter'),
        ('text/xml', 'XmlConverter'),
        ('text/xml', 'XmltodictConverter'),
        ('application/pdf', 'PdfConverter'),
    ]

    for (mime, name) in references:
        converter = Conversion.get_converter(mime)
        assert isinstance(converter, ConverterPlugin), 'could not find converter for `{}`'.format(mime)
        assert converter.__class__.__name__ == name, 'found wrong converter for `{}`'.format(mime)



# Generated at 2022-06-25 18:52:16.549129
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = "text/plain"
    var_0 = Formatting(["colors"], formatter=str_0)


# Generated at 2022-06-25 18:52:17.570512
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:52:18.739685
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:52:21.895346
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = None
    converter = Conversion.get_converter(float_0)
    groups_0 = []
    env_0 = Environment()
    var_1 = Formatting(groups_0, env_0)


# Generated at 2022-06-25 18:52:23.666271
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = [str(float_0)]
    var_0 = Formatting(float_0)


# Generated at 2022-06-25 18:52:26.454092
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    sub_converter_0 = Conversion.get_converter('@')


# Generated at 2022-06-25 18:52:36.157854
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test with args: <class 'httpie.plugins.builtin.BasicAuth'>
    assert Conversion.get_converter('foo') is None

    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('image/png')

    # Test with args: <class 'httpie.plugins.builtin.JWTAuth'>
    assert Conversion.get_converter('foo') is None

    # Test with args: <class 'httpie.plugins.json.HTTPieJSONFormatter'>
    assert Conversion.get_converter('foo') is None

    # Test with args: <class 'httpie.plugins.json.JSONStreamFormatter'>
    assert Conversion.get_converter('foo') is None

    # Test with args: <class 'httpie.plugins.pretty.PrettyJSONFormatter

# Generated at 2022-06-25 18:52:42.191290
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        var_89 = Conversion()
        var_90 = var_89.get_converter(None)
        assert var_90.__eq__(None), 'AssertionError: 7'
    except AssertionError as e:
        print('AssertionError: %d' % e.args[0])
    try:
        var_104 = Conversion()
        var_105 = var_104.get_converter('',)
        assert var_105.__eq__(None), 'AssertionError: 9'
    except AssertionError as e:
        print('AssertionError: %d' % e.args[0])

# Generated at 2022-06-25 18:52:48.679107
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    float_0 = None
    var_0 = Formatting(float_0)

# Generated at 2022-06-25 18:52:53.229505
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    float_0 = None
    var_0 = Formatting(float_0)
    float_0 = None
    var_1 = var_0.format_headers(float_0)


# Generated at 2022-06-25 18:52:55.833604
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
   # MIME_RE = re.compile(r'^[^/]+/[^/]+$')
    float_0 = None
    result = MIME_RE.match(float_0)



# Generated at 2022-06-25 18:52:58.583887
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 0
    float_0 = None
    var_0 = Formatting([], env=Environment())
    var_1 = var_0.format_headers(float_0)
    assert var_1 == float_0


# Generated at 2022-06-25 18:53:10.434357
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie import formatters
    from httpie import plugins

    text_0 = ''
    list_0 = ['', '']
    dict_0 = dict()
    dict_0 = dict()
    float_0 = None

    # ON-PREMISE TEST CASES
    float_0 = Formatting(list_0, var_0, text_0, dict_0, dict_0)
    dict_0 = float_0.format_headers(text_0)

    # ON-PREMISE TEST CASES
    formatters.formatters.enabled_plugins.append(HTTPHeadersProcessor)
    dict_0 = float_0.format_body(text_0, text_0)

    #

# Generated at 2022-06-25 18:53:14.589028
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        var_1 = Conversion.get_converter("application/json")
        assert type(var_1) == Conversion
    except Exception:
        assert False


# Generated at 2022-06-25 18:53:16.106135
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    float_0 = None
    var_0 = is_valid_mime(float_0)


# Generated at 2022-06-25 18:53:18.369735
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    float_1 = Conversion.get_converter(float_0)


# Generated at 2022-06-25 18:53:21.534610
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    float_0 = None
    var_0 = is_valid_mime(float_0)
    var_2 = Formatting(float_0)
    var_3 = var_2.format_headers(var_0)


# Generated at 2022-06-25 18:53:27.197415
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # instantiate the Formatting class
    float_0 = None
    var_0 = Formatting(float_0)
    # test method format_body of class Formatting
    float_0 = None
    float_1 = None
    var_0.format_body(float_0, float_1)



# Generated at 2022-06-25 18:53:36.782799
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        assert False
    except AssertionError:
        print(str(e))


# Generated at 2022-06-25 18:53:47.281028
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    float_0 = None
    str_0 = str(float_0)
    float_1 = float(1)
    float_2 = float(2)
    float_3 = float(3)
    float_4 = float(4)
    float_5 = float(5)
    float_6 = float(6)
    str_1 = str(float_6)
    float_7 = float(7)
    float_8 = float(8)
    float_9 = float(9)
    float_10 = float(10)
    float_11 = float(11)
    float_12 = float(12)
    str_2 = str(float_12)
    str_3 = str_2
    str_4 = str(float_2)
    str_5 = str(float_1)
    str_

# Generated at 2022-06-25 18:53:48.934968
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = None
    var_0 = Formatting([float_0])


# Generated at 2022-06-25 18:53:55.533480
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    group = ['bcolors', 'colors', 'format']
    for g in group:
        for cls in available_plugins[g]:
            p = cls(env=Environment())
            if p.enabled:
                enabled_plugins.append(p)

    # todo: maybe need to do something else before testing
    arg_0 = "test"
    # arg_0 should be an instance of str
    # Expected result: <class 'str'>
    assert type(arg_0) == str

    instance_0 = Formatting(['bcolors', 'colors', 'format'], env=Environment())
    # instance_0 should be an instance of Formatting
    # Expected result: <class 'httpie.formatting

# Generated at 2022-06-25 18:53:57.943238
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting is not None
    assert ConverterPlugin is not None


# Generated at 2022-06-25 18:53:59.288107
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = []
    float_1 = None
    var_0 = Formatting(float_0)


# Generated at 2022-06-25 18:54:04.283623
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    pass
    var_2 = list()
    var_1 = 'text/html'
    var_3 = Conversion.get_converter(var_1)
    var_3.from_unicode(var_2)
    var_1 = None
    var_3 = Conversion.get_converter(var_1)
    var_3.from_unicode(var_2)
    var_1 = 'text/html'
    var_3 = Conversion.get_converter(var_1)
    var_3.from_unicode(var_2)


# Generated at 2022-06-25 18:54:07.378532
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    var_0 = Formatting(groups=[], env=Environment())
    var_1 = 'test'
    var_2 = 'text/plain'
    var_0.format_body(var_1, var_2)


# Generated at 2022-06-25 18:54:08.814035
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter is not None, 'method get_converter not implemented'


# Generated at 2022-06-25 18:54:10.174677
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    assert Conversion.get_converter(float_0) == None


# Generated at 2022-06-25 18:54:31.895839
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = None
    dict_0 = { }
    list_0 = [ ]
    str_0 = "test_case_0"
    float_1 = float()
    float_2 = float(float_0)
    float_3 = float(dict_0)
    float_4 = float(list_0)
    float_5 = float(str_0)
    assert test_case_0()
    assert float_0 == float_2
    assert float_0 == float_3
    assert float_0 == float_4
    assert float_1 == float_5



# Generated at 2022-06-25 18:54:36.139085
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_1 = None
    assert Conversion.get_converter(float_1) == None
    float_2 = "unknown"
    assert Conversion.get_converter(float_2) == None
    float_3 = "application/json"
    assert Conversion.get_converter(float_3) == None
    float_4 = "text/html"
    assert Conversion.get_converter(float_4) == None



# Generated at 2022-06-25 18:54:40.371194
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = None
    string_0 = None
    var_0 = Formatting(float_0, string_0)
    exit(0)


# Generated at 2022-06-25 18:54:42.694266
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Input parameters
    float_0 = 'text/html'

    # Call method
    var_0 = Conversion.get_converter(float_0)

# Generated at 2022-06-25 18:54:47.901783
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        arg_0 = 'text/html'
        var_0 = Conversion.get_converter(arg_0)

        assert var_0, "Conversion.get_converter did not return an object."
    except AssertionError:
        raise
    except Exception:
        raise AssertionError("Error running test_Conversion_get_converter.")

# Generated at 2022-06-25 18:54:54.498859
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = None
    format_0 = Formatting(float_0)
    assert isinstance(format_0, Formatting)

# class Formatting_0:
#     def format_body(self, content: str, mime: str):
#         if True:
#             format_0 = Formatting(['colors'])
#             format_0.format_body(content, mime)
#             return
#
# class Formatting_1:
#     def format_body(self, content: str, mime: str):
#         if True:
#             format_0 = Formatting(['colors'])
#             format_0.format_body(content, mime)
#             return
#
# class Formatting_2:
#     def format_body(self, content: str, mime: str

# Generated at 2022-06-25 18:54:56.393532
# Unit test for constructor of class Formatting
def test_Formatting():
    context = None
    mime = None
    float_0 = None
    result = Formatting(context, mime, float_0)
    assert True

# Generated at 2022-06-25 18:54:58.762085
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_1 = None
    var_1 = Conversion.get_converter(float_1)

# Generated at 2022-06-25 18:54:59.581692
# Unit test for constructor of class Formatting
def test_Formatting():
    pass

# Generated at 2022-06-25 18:55:01.535291
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_2 = None
    var_2 = Conversion.get_converter(float_2)
    assert var_2 is None


# Generated at 2022-06-25 18:55:34.881592
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_case_0()


# Generated at 2022-06-25 18:55:40.572470
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    import requests
    # Test case for when mime is not valid
    assert Conversion.get_converter("") is None

    # Test case for when converter is not registered
    assert Conversion.get_converter("application/json") is None

    # Test case for when converter is registered
    try:
        plugin_manager.set_converters(['httpie.tests.formatters.test_ConverterPlugin'])
        plugin_manager.load_converters()
        assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)
    finally:
        plugin_manager.deregister_converters()



# Generated at 2022-06-25 18:55:46.546428
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    Header.print_class_header(1, "Start test case Formatting_format_body")
    test_obj = Formatting(["None"])
    print(test_obj.format_body("b'\\xe3\\x81\\x8f\\xe3\\x82\\x89\\xe3\\x81\\x93\\xe3\\x81\\xae\\xe8\\x8f\\x9c\\xe5\\xae\\x9a'",
                               "None"))

# Generated at 2022-06-25 18:55:50.833714
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = 20.0
    float_1 = 256.0
    float_2 = 64.0
    float_3 = 1.0
    float_4 = 32.0
    int_0 = is_valid_mime(float_0)
    int_1 = is_valid_mime(float_1)
    int_2 = is_valid_mime(float_2)
    int_3 = is_valid_mime(float_3)
    int_4 = is_valid_mime(float_4)


# Generated at 2022-06-25 18:56:01.575539
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    for float_2 in range(63):
        float_0 = float(float_2)
        float_1 = float(float_0)
        float_3 = float(float_1)
        float_0 = float(float_2)
        float_2 = float(float_0)
        float_1 = float(float_2)
        float_0 = float(float_2)
        float_2 = float(float_0)
        float_1 = float(float_2)
        float_3 = float(float_1)
        float_3 = float(float_1)
        float_0 = float(float_2)
        float_1 = float(float_2)
        float_3 = float(float_1)
        float_3 = float(float_1)

# Generated at 2022-06-25 18:56:03.076182
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = Conversion.get_converter(float_0)



# Generated at 2022-06-25 18:56:04.362233
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    var_1 = Formatting.__init__()
    var_2 = Formatting.format_body()


# Generated at 2022-06-25 18:56:08.205975
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.output.formatters.format_helpers import bytes_to_str

    float_0 = None
    bool_0 = bool(float_0)
    int_0 = len(float_0)
    formatter = Formatting(float_0)
    var_2 = formatter.format_headers(float_0)
    var_3 = formatter.format_body(bool_0, int_0)
    var_1 = bytes_to_str(var_2, None)


# Generated at 2022-06-25 18:56:13.438799
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = 49
    int_0 = 49
    float_1 = 49
    int_1 = 49
    float_2 = 49
    int_2 = 49
    float_3 = 49
    int_3 = 49
    float_4 = 49
    int_4 = 49
    float_5 = 49
    int_5 = 49
    float_6 = 49
    int_6 = 49
    float_7 = 49
    int_7 = 49
    float_8 = 49
    int_8 = 49
    float_9 = 49
    int_9 = 49
    float_10 = 49
    int_10 = 49
    float_11 = 49
    int_11 = 49
    float_12 = 49
    int_12 = 49
    float_13 = 49
    int_13 = 49
    float_

# Generated at 2022-06-25 18:56:24.501782
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    import json
    import httpie.plugins
    
    # First we create a new instance of httpie.plugins.registry.plugin_manager
    base = httpie.plugins.registry.plugin_manager
    manager = base()
    
    # Then we create a new instance of httpie.context.Environment and set it to var_0
    var_0 = httpie.context.Environment()
    
    # Finally we assign the list of all converters to var_1 and create an instance of httpie.plugins.ConverterPlugin.
    var_1 = manager.get_converters()
    var_2 = httpie.plugins.ConverterPlugin()
    
    # After those preparations, we can proceed to check the functionality of get_converter
    # We first set var_3 to str "application/json"

# Generated at 2022-06-25 18:57:31.642817
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = Conversion.get_converter(float_0)

# Generated at 2022-06-25 18:57:34.011595
# Unit test for constructor of class Formatting
def test_Formatting():
    float_0 = []
    var_0 = Formatting(float_0)

# Generated at 2022-06-25 18:57:37.938480
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = []
    env = Environment()
    kwargs = {}
    var_1 = Formatting(groups, env, **kwargs)
    assert var_1.enabled_plugins == []


# Generated at 2022-06-25 18:57:41.585760
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    float_0 = None
    var_0 = Formatting(float_0)
    float_1 = None
    var_1 = None
    var_2 = var_0.format_body(float_1, var_1)

# Generated at 2022-06-25 18:57:45.037018
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = 0
    var_0 = is_valid_mime(float_0)
    var_1 = Conversion.get_converter(float_0)

    assert var_0 == False
    assert var_1 == None


# Generated at 2022-06-25 18:57:52.699094
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # unit test for get_converter
    float_0 = None
    str_0 = 'application/json'
    str_1 = 'application/xml'
    str_2 = 'application/json'
    str_3 = 'application/xml'
    str_4 = 'application/xml'
    str_5 = 'application/json'
    str_6 = 'application/xml'
    str_7 = 'application/json'
    str_8 = 'application/xml'
    str_9 = 'application/json'
    str_10 = 'application/xml'
    str_11 = 'application/json'
    str_12 = 'application/xml'
    str_13 = 'application/json'
    str_14 = 'application/xml'
    str_15 = 'application/json'

# Generated at 2022-06-25 18:57:55.863452
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = []
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    # Test that no errors occur when invoking this method.
    formatting.format_headers(str())


# Generated at 2022-06-25 18:58:00.444355
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    float_0 = None
    var_0 = is_valid_mime(float_0)
    float_0 = None
    var_1 = is_valid_mime(float_0)
    var_1 = is_valid_mime(float_0)


# Generated at 2022-06-25 18:58:05.909644
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Sets up the testing requirements
    var_0 = Conversion()
    mime = "application/json"

    # Invokes the method under test
    var_1 = var_0.get_converter(mime)

    # Checks the expected output against the actual output
    assert var_1.supports(mime), "Expected: 'true', Actual: '%s'" % var_1.supports(mime)


# Generated at 2022-06-25 18:58:06.891883
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pass
