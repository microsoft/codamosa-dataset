

# Generated at 2022-06-25 18:49:35.685140
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'r\rI1TBM%@HBZ\x0blB I <'
    conversion_1 = Conversion()
    formatting_0 = Formatting([])
    str_1 = formatting_0.format_body(str_0, str_0)
    str_2 = 'r\rI1TBM%@HBZ\x0blB I <'
    assert str_1 == str_2


# Generated at 2022-06-25 18:49:45.816611
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test with groups: [], env: Environment(), kwargs: {}
    str_0 = 'HBZ\x0blB I <'
    formatting_0 = Formatting([], Environment(), **{})
    # Test with groups: ['colors'], env: Environment(), kwargs: {}
    formatting_1 = Formatting(['colors'], Environment(), **{})
    # Test with groups: ['colors', 'colors'], env: Environment(), kwargs: {}
    formatting_2 = Formatting(['colors', 'colors'], Environment(), **{})
    # Test with groups: ['colors', 'formatters'], env: Environment(), kwargs: {}
    formatting_3 = Formatting(['colors', 'formatters'], Environment(), **{})
    # Test with groups: ['colors', 'formatters

# Generated at 2022-06-25 18:49:53.961539
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    for i in range(100):
        try:
            str_0 = sigar.loadavg_get()
            conversion_0 = Conversion()
            # method result is not used so didn't verify
            conversion_0.get_converter(str_0)
        except:
            pass
    for i in range(100):
        try:
            groups_0 = []
            formatting_0 = Formatting(groups_0, )
            # method result is not used so didn't verify
            formatting_0.format_headers(str_0)
            formatting_0 = Formatting(groups_0, )
            # method result is not used so didn't verify
            formatting_0.format_body(str_0, str_0)
        except:
            pass


# Generated at 2022-06-25 18:50:00.370268
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'r\rI1TBM%@HBZ\x0blB I <'
    groups_0 = ['colors']
    formatting_0 = Formatting(groups=groups_0)
    str_1 = 'sr\rI1TBM%@HBZ\x0blB I <'
    str_2 = formatting_0.format_headers(headers=str_0)
    # assert str_1 == str_2


# Generated at 2022-06-25 18:50:03.151991
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers_0 = 'r\rI1TBM%@HBZ\x0blB I <'
    format_headers_0 = Formatting([]).format_headers(headers_0)


# Generated at 2022-06-25 18:50:07.400999
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    test_case_0_get_converter_0(conversion_0)
    test_case_0_get_converter_1(conversion_0)
    test_case_0_get_converter_2(conversion_0)
    test_case_0_get_converter_3(conversion_0)



# Generated at 2022-06-25 18:50:14.505706
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/plain'
    conversion_0 = Conversion()
    converter = conversion_0.get_converter(mime)
    assert converter
    mime = 'image/gif'
    conversion_1 = Conversion()
    converter = conversion_1.get_converter(mime)
    assert converter == None
    mime = 'text/html'
    conversion_2 = Conversion()
    converter = conversion_2.get_converter(mime)
    assert converter == None
    mime = 'text/plain'
    conversion_3 = Conversion()
    converter = conversion_3.get_converter(mime)
    assert converter


# Generated at 2022-06-25 18:50:21.594095
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-25 18:50:25.464132
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'r\rI1TBM%@HBZ\x0blB I <'
    conversion_0 = Conversion()
    conversion_1 = Conversion.get_converter(str_0)


# Generated at 2022-06-25 18:50:27.342885
# Unit test for constructor of class Formatting
def test_Formatting():
    # No exception, normal execution
    test_Formatting_0 = Formatting([])


# Generated at 2022-06-25 18:50:31.507687
# Unit test for constructor of class Formatting
def test_Formatting():
    # test case 1
    test_case_1 = Formatting(groups=["name"])



# Generated at 2022-06-25 18:50:36.264780
# Unit test for constructor of class Formatting
def test_Formatting():
    format = Formatting(['colors'], env=Environment())
    assert format.enabled_plugins[0].enabled


# Generated at 2022-06-25 18:50:43.500081
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins_0 = plugin_manager.get_formatters_grouped()
    Formatting_0 = Formatting(['formatters'])

    assert Formatting_0.enabled_plugins == []

    Formatting_1 = Formatting(['formatters'], env=Environment())

    assert Formatting_1.enabled_plugins == []

    Formatting_2 = Formatting(['formatters'], env=Environment(), **{'formatters': [{'colors': True}]})

    assert Formatting_2.enabled_plugins == []



# Generated at 2022-06-25 18:50:50.324279
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    mime = "application/json"
    conversion_0 = Conversion.get_converter(mime=mime)
    # Test case 1
    content = "{\n  \"foo\": \"bar\"\n}\n"
    groups = ["colors"]
    kwargs = {"pygments_style": "monokai"}
    formatting_0 = Formatting(groups=groups, env=Environment(), **kwargs)

# Generated at 2022-06-25 18:50:58.380434
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    _env = 'Environment'
    _groups = ['colors']
    _kwargs = {}

    _headers = 'foo: bar\nbar: foo'

    _formatted_headers = Formatting(groups=_groups, env=_env, **_kwargs).format_headers(_headers)

    assert _formatted_headers == '\x1b[34;1mfoo:\x1b[39;22m bar\n\x1b[34;1mbar:\x1b[39;22m foo\n'


# Generated at 2022-06-25 18:51:01.784444
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    conv = Formatting(['colors'])
    output = conv.format_body('{"Testing":"JSON"}', 'application/json')
    assert output == '{\n    "Testing": "JSON"\n}'


# Generated at 2022-06-25 18:51:05.287803
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    assert conversion_0.get_converter('application/json') is not None
    assert isinstance(conversion_0.get_converter('application/json'), ConverterPlugin)


# Generated at 2022-06-25 18:51:06.634059
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting(groups=[])



# Generated at 2022-06-25 18:51:11.450543
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    assert not Conversion.get_converter('') is None
    assert not Conversion.get_converter('123') is None
    assert not Conversion.get_converter('*/*') is None
    assert not Conversion.get_converter('*/json') is None
    assert not Conversion.get_converter('application/*') is None
    assert not Conversion.get_converter('application/json') is None


# Generated at 2022-06-25 18:51:15.669120
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """get_converter(): Test the return value of a converter for a valid MIME type.
    """
    assert is_valid_mime('image/png') is True
    assert Conversion.get_converter('image/png')


# Generated at 2022-06-25 18:51:19.373118
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['TestCase'])
    assert isinstance(f, Formatting)


# Generated at 2022-06-25 18:51:21.440592
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('text/plain') is None

# Generated at 2022-06-25 18:51:31.298503
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class TestClass:
        def test_method(self, headers: str) -> str:
            groups = ["curl"]
            env = Environment()
            kwargs = {}
            p = Formatting(groups, env, **kwargs)
            headers = p.format_headers(headers)
            return headers

# Generated at 2022-06-25 18:51:32.087471
# Unit test for constructor of class Formatting
def test_Formatting():
    formatter = Formatting()


# Generated at 2022-06-25 18:51:37.847622
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting([])
    formatting_1 = Formatting(['default'])
    formatting_2 = Formatting(['default', 'colors'])
    formatting_3 = Formatting(['colors', 'default'])
    formatting_4 = Formatting(['colors'])


# Generated at 2022-06-25 18:51:46.593767
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    conversion_0 = Conversion()
    text = '{"name":"httpie","language":"python"}'
    result_text = '{\n  "language": "python", \n  "name": "httpie"\n}\n'
    assert result_text == format_body(text, 'application/json', conversion_0)

    text = '<!DOCTYPE html>\n' \
           '<html lang="en">\n' \
           '<head>\n' \
           '<title>Test</title>\n' \
           '</head>\n' \
           '<body>\n' \
           '<h1>My header</h1>\n' \
           '<p>Hello World</p>\n' \
           '</body>\n' \
           '</html>'

# Generated at 2022-06-25 18:51:51.498739
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Testing smart_quote for json for the following cases
    conversion_0 = Conversion()
    assert conversion_0.get_converter("json") == None
    conversion_1 = Conversion("json")
    assert conversion_1.get_converter("json") is not None
    conversion_2 = Conversion("application/json")
    assert conversion_2.get_converter("json") is not None


# Generated at 2022-06-25 18:51:52.034022
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting()

# Generated at 2022-06-25 18:51:53.578962
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    assert conversion_0.get_converter('') == None


# Generated at 2022-06-25 18:51:56.669877
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    result = Conversion.get_converter('application/json')
    assert (str(result)) == '<httpie.plugins.converter.JSONConverter object at 0x7fc01cc4f4e0>'


# Generated at 2022-06-25 18:52:08.758693
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print('Unit test for method format_headers of class Formatting')
    print('')
    headers = '''Content-Type: application/json
Cache-Control: no-cache'''
    print(headers)
    print('')
    available_plugins = plugin_manager.get_formatters_grouped()
    groups = ['formatters']
    kwargs = {}
    env = Environment()
    formatting_0 = Formatting(groups, env, **kwargs)
    print(formatting_0.format_headers(headers))
    print('')
    #print(available_plugins)
    #print(groups)
    #print(kwargs)
    #print(env)
    #for group in groups:
    #    for cls in available_plugins[group]:
    #        p = cls(env, **kw

# Generated at 2022-06-25 18:52:11.601940
# Unit test for constructor of class Formatting
def test_Formatting():
    test_env = Environment(output_options=dict(groups=[]))
    test_Formatting = Formatting(groups=[], env=test_env)


# Generated at 2022-06-25 18:52:15.929136
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(['colors']).format_headers('HTTP/1.1 200 OK\nContent-Type: application/json\n\n') == \
        '\x1b[32mHTTP/1.1 200 OK\x1b[0m\n\x1b[32mContent-Type: application/json\x1b[0m\n\n'



# Generated at 2022-06-25 18:52:18.527414
# Unit test for constructor of class Formatting
def test_Formatting():
    p = Formatting(['Convertors', 'HTML'], Environment(),
                   pretty=True, body_style='INDENTED')
    assert p.enabled_plugins[0].name == 'indented'
    assert p.enabled_plugins[1].name == 'colors'
    assert p.enabled_plugins[2].name == 'format'

# Generated at 2022-06-25 18:52:26.065670
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    input_headers = "\nDate: Wed, 28 Feb 2018 13:11:19 GMT\nContent-Type: application/json\nExpires: Sat, 01 Apr 2017 13:11:19 GMT\nVary: Accept-Encoding\n"
    input_body = "{\"TCP\":\"Gets the information of TCP connection.\"}"
    input_mime = "application/json"
    formatter = Formatting(["Pretty"],)
    assert formatter.format_body(input_body, input_mime) == input_body


# Generated at 2022-06-25 18:52:35.777399
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case # 1, a json body with a valid json mime
    class TestCase1:
        env = Environment()
        groups = ['colors']
        json_body = '{"key1": "value1"}'
        mime = 'application/json'
        formatting = Formatting(groups, env)
        formatted_json_body = formatting.format_body(json_body, mime)
        assert json_body != formatted_json_body
        # The json body should have been colored by the colors plugin
        colors_plugin = plugin_manager.get_plugin_instances_by_base_class(ColorsFormatterPlugin)[0]
        colors_plugin.set_theme_style('monokai')
        assert colors_plugin.format_json(json_body) == formatted_json_body

    # Test case # 2, a plain

# Generated at 2022-06-25 18:52:42.017620
# Unit test for method get_converter of class Conversion

# Generated at 2022-06-25 18:52:42.839410
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    pass


# Generated at 2022-06-25 18:52:48.202445
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    e = Environment()
    f = Formatting(groups=['colors'], env=e, colors=True)
    formatted_headers = f.format_headers('header1: header1-value\nheader2: header2-value')
    formatted_body = f.format_body('plain_text_body', 'plain/text')
    assert formatted_body == 'plain_text_body'
    assert formatted_headers == 'header1: header1-value\nheader2: header2-value'

# Generated at 2022-06-25 18:52:58.584037
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case - 1
    def test_case_1(function):
        user_headers = headers_valid
        expected_output = headers_valid
        status = False
        try:
            final_output = function(*user_headers)
            status = True
            try:
                assert final_output == expected_output
            except AssertionError:
                print("The expected output is ", expected_output)
                print("The actual output is ", final_output)
        except Exception as ex:
            print("Something went wrong while executing the function", ex)

        # Calling the test_case_1 function
        test_case_1(Formatting.format_headers)

    # Test case - 2
    def test_case_2(function):
        user_headers = headers_invalid
        status = False

# Generated at 2022-06-25 18:53:05.805574
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = None
    assert Conversion.get_converter(mime_0) is None
    mime_1 = "a"
    assert Conversion.get_converter(mime_1) is None
    mime_2 = ""
    assert Conversion.get_converter(mime_2) is None


# Generated at 2022-06-25 18:53:09.532062
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    mime_0 = 'content-type: text/plain'
    assert (conversion_0.get_converter(mime_0) is None), 'conversion_0.get_converter(mime_0) is not None'


# Generated at 2022-06-25 18:53:15.001843
# Unit test for constructor of class Formatting
def test_Formatting():
    print("Start unit test of constructor")
    try:
        test_case_0()
        print("Passed the first test case")
    except Exception:
        print("Failed the first test case")

    print("End unit test of constructor")


# Generated at 2022-06-25 18:53:16.183320
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_0 = Conversion.get_converter('application/json')



# Generated at 2022-06-25 18:53:25.156574
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    post_data = '{"aa":222, "bb":444}'
    post_data2 = '{"aa":222, "bb":444}'
    post_data3 = '{"aa":222, "bb":444}'

# Generated at 2022-06-25 18:53:29.612327
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = list()
    formatting_0 = Formatting(list_0)
    headers_0 = headers_from_bytes(b'Content-Type: application/json; charset=utf-8\r\nX-Things: Bob, Alice\r\n')
    str_0 = formatting_0.format_headers(headers_0)


# Generated at 2022-06-25 18:53:31.671042
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    intent = None
    headers = 'headers'
    formatting_0 = Formatting(intent)
    formatting_0.format_headers(headers)


# Generated at 2022-06-25 18:53:41.501369
# Unit test for constructor of class Formatting
def test_Formatting():
    all_formatters = ['colors', 'format', 'indent', 'json', 'pretty', 'sorting', 'stream']
    formatting_0 = Formatting(['colors', 'format'])
    assert formatting_0.enabled_plugins[0].enabled is True
    assert formatting_0.enabled_plugins[0].group == 'colors'
    assert formatting_0.enabled_plugins[0].name == 'Colors'
    assert formatting_0.enabled_plugins[0].plugin_type == 'formatter'
    assert formatting_0.enabled_plugins[1].enabled is True
    assert formatting_0.enabled_plugins[1].group == 'format'
    assert formatting_0.enabled_plugins[1].name == 'Format'
    assert formatting_0.enabled_plugins[1].plugin_type == 'formatter'
    assert formatting

# Generated at 2022-06-25 18:53:43.167351
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = 'application/json'
    conversion_0 = Conversion.get_converter(list_0)

# Generated at 2022-06-25 18:53:48.810601
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    try:
        list_0 = None
        formatting_0 = Formatting(list_0)
        formatting_0.format_headers()
        raise Exception("Expected null pointer exception")
    except TypeError as t:
        # TODO: assert proper error message
        # Assert.assertEquals("formatting_0.format_headers()", t.getMessage())
        pass


# Generated at 2022-06-25 18:53:56.414589
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = mime_0 = ""
    conversion_0 = Conversion()
    assert conversion_0.get_converter(mime_0) == None

    mime = mime_1 = "application/json"
    conversion_1 = Conversion()
    assert conversion_1.get_converter(mime_1) == None

    mime = mime_2 = "application/json;charset=abc"
    conversion_2 = Conversion()
    assert conversion_2.get_converter(mime_2) == None

    mime = mime_3 = "application/json;charset=utf-8"
    conversion_3 = Conversion()
    assert conversion_3.get_converter(mime_3) == None


# Generated at 2022-06-25 18:53:58.920040
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    list_0 = None
    formatting_0 = Formatting(list_0, env)
    headers_0 = None
    expected_0 = None
    actual_0 = formatting_0.format_headers(headers_0)


# Generated at 2022-06-25 18:54:05.169572
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    # init a formatter
    formatters = plugin_manager.get_formatters_grouped()
    fmt = formatters['matrix'][0](options={"colors": False})

    class TestConverter:

        @staticmethod
        def to_unicode(data: str) -> str:
            return data

    t_c = TestConverter()

    # input data
    mime = 'application/json'
    content = {'a': '1', 'b': '2', 'c': ['3', '4']}
    output_string = fmt.format_body(content, mime)

    # test output

# Generated at 2022-06-25 18:54:09.143449
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = None
    formatting_0 = Formatting(list_0)
    mime="text/html"
    dt=Conversion.get_converter(mime)
    #dt.format_body("abcd","text/html")


test_case_0()
test_Conversion_get_converter()

# Generated at 2022-06-25 18:54:11.335466
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Assigning the object:
    mime_0 = None
    # Receiving the object:
    converter_0 = Conversion.get_converter(mime_0)
    return converter_0



# Generated at 2022-06-25 18:54:12.986983
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = None
    expected = None
    actual = Conversion().get_converter(mime)
    assert expected == actual


# Generated at 2022-06-25 18:54:21.129212
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = [
        'HTTPie-HAR',
        'HTTPie-0.9.9',
        'HTTPie-HAR-0.0.3'
    ]
    formatting_0 = Formatting(list_0)
    headers_0 = 'HTTP/1.1 200 OK\nServer: nginx/1.4.6 (Ubuntu)\nDate: Thu, 23 Jun 2016 14:32:52 GMT\nContent-Type: application/json; charset=utf-8\nContent-Length: 5\nConnection: keep-alive'
    str_0 = formatting_0.format_headers(headers_0)
    print(str_0)


if __name__ == '__main__':
    test_case_0()
    test_Formatting()

# Generated at 2022-06-25 18:54:26.534356
# Unit test for constructor of class Formatting
def test_Formatting():
    print('Testing constructor of class Formatting')
    try:
        # Test case 1
        list_0 = 'pygments'
        environment_0 = Environment()
        formatting_0 = Formatting(list_0, environment_0)
        assert True
    except:
        assert False


# Generated at 2022-06-25 18:54:31.670368
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    formatting_0 = Formatting()
    formatters_0 = formatting_0.enabled_plugins
    mime_0 = str()
    try:
        output_0 = Conversion.get_converter(mime_0)
        assert output_0 is not None and output_0.mime == mime_0
    except:
        try:
            output_0 = lambda:0
        except:
            output_0 = lambda:0
        assert output_0() == 0


# Generated at 2022-06-25 18:54:38.333711
# Unit test for constructor of class Formatting

# Generated at 2022-06-25 18:54:46.012708
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    mime = 'application/json'
    headers = '{\n"custom-header": "foo"\n}'
    conversion = Conversion()
    converter = conversion.get_converter(mime)
    if converter:
        headers = converter.decode(headers)




# Generated at 2022-06-25 18:54:49.649920
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # TODO: Please add the code here to finish the test
    # You may add as many test methods as you need.
    mime = 'text/html'
    conversion_0 = Conversion.get_converter(mime)
    assert conversion_0 is not None


# Generated at 2022-06-25 18:54:52.827361
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = ['example']
    formatting_0 = Formatting(list_0)
    str_0 = '{#48#}'
    str_1 = formatting_0.format_headers(str_0)
    str_2 = '{#49#}'
    assert str_2 == str_1


# Generated at 2022-06-25 18:54:58.944539
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = ["a", "b", "c"]
    ConverterPlugin_0 = Conversion.get_converter('a/a')
    content_0 = ""
    mime_0 = "a/a"
    formatting_0 = Formatting(list_0)
    assert formatting_0.format_body(content_0, mime_0) == ConverterPlugin_0.format_body(content_0, mime_0)

# Generated at 2022-06-25 18:55:01.496104
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = None
    conversion_0 = Conversion()
    assert_equals(conversion_0.get_converter(mime), None)



# Generated at 2022-06-25 18:55:06.080599
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = None
    try:
        formatting_0 = Formatting(list_0)
    except Exception as e:
        print(e)
        print('TEST FAIL : test_Formatting')
        return

    print('TEST PASS : test_Formatting')


# Generated at 2022-06-25 18:55:09.420251
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = None
    mime_0 = None
    conversion_0 = Conversion()
    str_0 = conversion_0.get_converter(mime_0)


# Generated at 2022-06-25 18:55:12.060770
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = ['UTF-8', 'UTF-16', 'UTF-32']
    format_0 = 'application/json'
    conversion_0 = Conversion.get_converter(format_0)
    assert conversion_0.encoding in list_0


# Generated at 2022-06-25 18:55:13.152579
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    result = Conversion.get_converter("image/jpeg")


# Generated at 2022-06-25 18:55:19.280842
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin import JSONConverter

    list_1 = ['application/json']
    for list_1_item_ in list_1:
        converter_0 = Conversion.get_converter(list_1_item_)
        assert (isinstance(converter_0, JSONConverter))



# Generated at 2022-06-25 18:55:31.367846
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = str()
    classes_0 = []
    plugin_manager_0 = plugin_manager

    def get_converters_0():
        for cls in classes_0:
            yield cls
    plugin_manager_0.get_converters = get_converters_0
    assert Conversion.get_converter(mime_0) is None

# Generated at 2022-06-25 18:55:36.296825
# Unit test for constructor of class Formatting
def test_Formatting():
    list_1 = ['headers', 'body']
    formatting_0 = Formatting(list_1)
    conversion_0 = Conversion.get_converter('image/png')
    print(conversion_0)
    environment_0 = Environment()
    formatting_1 = Formatting(list_1, environment_0)
    assert formatting_0.enabled_plugins == formatting_1.enabled_plugins


# Generated at 2022-06-25 18:55:39.043159
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("video/mp4") != None


# Generated at 2022-06-25 18:55:45.166733
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = None
    formatting_0 = Formatting(list_0)
    content = '{\'general\': \'test\'}'
    mime = 'application/json'
    res = formatting_0.format_body(content, mime)
    assert res == '{\'general\': \'test\'}'


# Generated at 2022-06-25 18:55:47.272191
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = ['test']
    formatting_0 = Formatting(list_0)

# Generated at 2022-06-25 18:55:56.306888
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    formatting_0 = Formatting(list_0)

    content_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    mime_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-25 18:55:59.348648
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        test_case_0()
        print('pass test_Formatting')
    except:
        print('failed test_Formatting')

if __name__ == '__main__':
    test_Formatting()

# Generated at 2022-06-25 18:56:01.683953
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = ["a"]
    formatting_0 = Formatting(list_0)
    str_0 = formatting_0.format_body(str_0, str_0)


# Generated at 2022-06-25 18:56:03.184172
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    formatting_0 = Formatting(list_0)


# Generated at 2022-06-25 18:56:07.187687
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    list = []
    formatting_0 = Formatting(list)
    formatting_0.enabled_plugins.clear()
    for group in list:
        for cls in available_plugins[group]:
            p = cls()
            if p.enabled:
                formatting_0.enabled_plugins.append(p)

    assert len(formatting_0.enabled_plugins) == 0


# Generated at 2022-06-25 18:56:25.471515
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    for i, s in (("application/json", "json"),
                 ("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "xml"),
                 ("application/vnd.ms-word", "xml"),
                 ):
         assert (Conversion.get_converter(s) is not None)

# Generated at 2022-06-25 18:56:30.497072
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    value_0 = 'Content-Type:'
    try:
        value_1 = Formatting.format_headers(value_0)
    except OSError as e:
        if os.name == "nt":
            reason_0 = (errorcode.ENOENT, "No such file or directory")
            assert reason_0 == e.args
        else:
            reason_0 = (errorcode.ENOENT, "No such file or directory")
            assert reason_0 == e.args
    else:
        raise AssertionError("Expected OSError to be thrown")


# Generated at 2022-06-25 18:56:40.042113
# Unit test for constructor of class Formatting

# Generated at 2022-06-25 18:56:43.242034
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter.mime == 'application/json' and converter.preserve_order == False



# Generated at 2022-06-25 18:56:50.845947
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = ['f', 'e', 'A']
    formatting_0 = Formatting(list_0)
    list_1 = ['e']
    formatting_1 = Formatting(list_1)
    int_0 = formatting_0.get_converter(list_1) # None is returned
    int_1 = formatting_1.get_converter(list_0) # None is returned
    list_2 = ['a', '\\', 'b', 'e']
    formatting_2 = Formatting(list_2)
    int_2 = formatting_2.get_converter(list_0) # None is returned
    list_3 = ['c']
    formatting_3 = Formatting(list_3)
    int_3 = formatting_3.get_converter(list_2) # None is returned


# Generated at 2022-06-25 18:56:54.684174
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = ['--format=colors']
    headers_0 = 'a: 1\r\nb: 2\r\n'
    formatting_0 = Formatting(list_0)
    assert(formatting_0.format_headers(headers_0) == '~Ya: ~Y1\r\n~Yb: ~Y2\r\n')



# Generated at 2022-06-25 18:56:57.836940
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = None
    formatting_0 = Formatting(list_0)
    content_0 = None
    mime_0 = None
    formatting_0.format_body(content_0, mime_0)


# Generated at 2022-06-25 18:56:59.671034
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = None
    env = Environment()
    kwargs = {}
    Formatting(list_0, env, **kwargs)


# Generated at 2022-06-25 18:57:01.199479
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = None
    env_0 = None
    formatting_0 = Formatting(list_0,env_0)


# Generated at 2022-06-25 18:57:04.437489
# Unit test for constructor of class Formatting
def test_Formatting():
    list_1 = []
    list_1.append('formatters')
    formatting_1 = Formatting(list_1)
    list_2 = []
    formatting_2 = Formatting(list_2)
    assert formatting_1 != formatting_2



# Generated at 2022-06-25 18:57:39.027569
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = ""
    assert_raises(Exception, Conversion.get_converter, mime)



# Generated at 2022-06-25 18:57:41.268135
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting.format_body("''") is not None
    assert Formatting.format_body("'httpbin'") is not None

# Generated at 2022-06-25 18:57:42.894589
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    var_0 = Conversion.get_converter(mime)

# Generated at 2022-06-25 18:57:46.472935
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = ['x', 'y', 'z']
    formatting_0 = Formatting(list_0)
    str_0 = '{TestClass,TestMethod}'
    str_1 = formatting_0.format_headers(str_0)
    assert str_1 is None


# Generated at 2022-06-25 18:57:48.000406
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = ''
    converter = Conversion.get_converter(mime)
    assert converter == None

# Generated at 2022-06-25 18:57:52.500651
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    available_plugins = plugin_manager.get_formatters_grouped()
    list_0 = []
    for grp in available_plugins:
        for cls in available_plugins[grp]:
            p = cls()
            if p.enabled:
                list_0.append(cls)
    formatting_0 = Formatting(list_0)
    content = ''
    mime = ''
    formatting_0.format_body(content, mime)



# Generated at 2022-06-25 18:58:02.818247
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = None
    formatting_0 = Formatting(list_0)
    str_0 = "application/json"
    converter_plugin_0 = Conversion.get_converter(str_0)
    converter_plugin_0 = None
    str_1 = "text/html"
    converter_plugin_1 = Conversion.get_converter(str_1)
    converter_plugin_1 = None
    str_2 = ""
    converter_plugin_2 = Conversion.get_converter(str_2)
    converter_plugin_2 = None
    str_3 = "application/json"
    converter_plugin_3 = Conversion.get_converter(str_3)
    converter_plugin_3 = None
    str_4 = "text/html"
    converter_plugin_4 = Conversion.get_con

# Generated at 2022-06-25 18:58:08.874888
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = (None,)
    formatting_0 = Formatting(list_0)
    content_type_0 = None
    list_1 = (content_type_0,)
    formatting_1 = Formatting(list_1)
    headers_0 = None
    formatting_1.format_headers(headers_0)
    headers_1 = None
    formatting_0.format_headers(headers_1)
    headers_2 = None
    formatting_1.format_headers(headers_2)


# Generated at 2022-06-25 18:58:11.976941
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = None
    env = Environment()
    formatting_0 = Formatting(list_0, env)
    formatting_1 = Formatting(list_0, env, converter=None)
    formatting_2 = Formatting(list_0, env, converter=None, colors=None)


# Generated at 2022-06-25 18:58:13.455550
# Unit test for constructor of class Formatting
def test_Formatting():
    instances = [Formatting([])]
    for inst in instances:
        assert isinstance(inst, Formatting)


# Generated at 2022-06-25 18:59:23.449396
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting.__init__ is not None


# Generated at 2022-06-25 18:59:26.266877
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    arg_0 = None
    ret = Conversion.get_converter(arg_0)
    assert ret == None
