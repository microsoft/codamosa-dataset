

# Generated at 2022-06-25 18:49:34.025058
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion = Conversion()
    converter = conversion.get_converter("text/plain")
    assert converter.__class__.__name__ == "RawConverter"

# Generated at 2022-06-25 18:49:35.382674
# Unit test for constructor of class Formatting
def test_Formatting():
    test_obj = Formatting(Environment())


# Generated at 2022-06-25 18:49:42.933208
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Assert that there is no converter when mime is not valid
    assert not Conversion.get_converter(mime='Wrong format')
    # Assert that there is no converter when no converter support the mime
    assert not Conversion.get_converter(mime='text/wrong-mime')
    # Assert that there is a converter for the mime
    assert Conversion.get_converter(mime='application/json')
    assert isinstance(Conversion.get_converter(mime='application/json'), ConverterPlugin)



# Generated at 2022-06-25 18:49:46.556980
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting(groups=['yaml', 'json'])
    print(formatting_0.__dict__)
    print(formatting_0.enabled_plugins)

if __name__ == "__main__":
    test_Formatting()

# Generated at 2022-06-25 18:49:49.412841
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    Formatting_format_body_0 = Formatting(['colors'],)
    Formatting_format_body_0.format_body("{\"key\": \"value\"}", "application/json")


# Generated at 2022-06-25 18:49:50.282818
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting = Formatting()
    assert formatting

# Generated at 2022-06-25 18:49:54.030832
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_list = [
        ('application/json', True),
        ('application/xml', True),
        ('text/html', False),
        ('text/plain', False),
        ('no/matching', False)]

    for test in test_list:
        conversion = Conversion.get_converter(test[0])
        assert (conversion is not None) == test[1]

# Generated at 2022-06-25 18:50:00.028538
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    assert conversion_1.get_converter('text/html').mime == 'text/html'
    assert conversion_1.get_converter('text/plain').mime == 'text/plain'
    assert conversion_1.get_converter('text/xml').mime == 'text/xml'
    assert conversion_1.get_converter('text/something').mime is None


# Generated at 2022-06-25 18:50:08.996762
# Unit test for constructor of class Formatting
def test_Formatting():
    class MockPlugin:
        def __init__(self, env=Environment(), **kwargs):
            self.enabled = True

    # Mock the plugin manager registry
    class MockPluginManager:
        def get_formatters_grouped(self) -> List[str]:
            plugins = {
                'group1': [MockPlugin, MockPlugin],
                'group2': [MockPlugin, MockPlugin]
            }
            return plugins

    orig_pm = plugin_manager
    plugin_manager = MockPluginManager()

    # Mock the environment
    class MockEnvironment:
        def __init__(self):
            self.colors = True

    env = MockEnvironment()

    # Create an instance of Formatting and test if all four plugins were added
    formatting = Formatting(['group1', 'group2'], env=env)

# Generated at 2022-06-25 18:50:10.878477
# Unit test for constructor of class Formatting
def test_Formatting():
    format = Formatting(["colors"], Environment(loglevel='q', colors="q"))
    assert format.enabled_plugins == []



# Generated at 2022-06-25 18:50:20.787044
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_str = 'HTTP/1.1 200 OK\n'
    formatting_ins = Formatting(groups=['formatting'], colors=True)
    test_str = formatting_ins.format_headers(test_str)
    expected_str = '\x1b[1mHTTP/1.1\x1b[22m \x1b[92m200\x1b[39m \x1b[32mOK\x1b[39m\n'
    assert test_str == expected_str


import io

# Generated at 2022-06-25 18:50:21.710716
# Unit test for constructor of class Formatting
def test_Formatting():
    g = ['color']
    f = Formatting(g)


# Generated at 2022-06-25 18:50:25.825867
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Case 0: mime is not in str type
    conversion_0 = Conversion()
    try:
        assert not conversion_0.get_converter(123)
    except AttributeError:
        assert True
    # case 1: mime is valid
    assert not conversion_0.get_converter("application/json")
    # case 2: mime is invalid as do not contain '/'
    assert not conversion_0.get_converter("test")
    # case 3: mime is invalid as contain more than 2 parts
    assert not conversion_0.get_converter("test/test/test")


# Generated at 2022-06-25 18:50:30.055031
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting = Formatting(["Body"])
    assert formatting.format_body("{'num':5, 'str':'string'}",'application/json') == '''{
    "num": 5,
    "str": "string"
}'''

# Generated at 2022-06-25 18:50:33.601949
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion = Conversion()
    mime = 'application/json'
    converter = conversion.get_converter(mime)
    assert isinstance(converter, ConverterPlugin)
    assert converter.mime == mime



# Generated at 2022-06-25 18:50:44.550365
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(["color", "format", "indent", "unicode"],
                              env=Environment())

# Generated at 2022-06-25 18:50:47.360827
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print("Function: Conversion.get_converter, Case: Input is a valid mime type")
    conversion_0 = Conversion()
    converter = conversion_0.get_converter("image/png")
    assert converter != None


# Generated at 2022-06-25 18:50:58.805953
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_data = "Hello World"

    # Test case 1: no input
    format_1 = Formatting(groups=[])
    assert format_1.format_body(test_data, None) == test_data
    assert format_1.format_body("", None) == ""

    # Test case 2: unsupported mime
    format_2 = Formatting(groups=["colors"])
    assert format_2.format_body(test_data, None) == test_data
    assert format_2.format_body(test_data, "") == test_data

    # Test case 3: no plugins enabled
    format_3 = Formatting(groups=[])
    assert format_3.format_body(test_data, "text/css") == test_data

# Generated at 2022-06-25 18:51:08.624698
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=["json", "colors"], colors=True)

# Generated at 2022-06-25 18:51:14.036614
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import pytest
    Formatting_0 = Formatting(['colors'], True, True)
    with pytest.raises(ValueError):
        Formatting_0.format_headers('')


# Generated at 2022-06-25 18:51:18.581165
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins



# Generated at 2022-06-25 18:51:20.338657
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting()
    formatting_0.format_body()



# Generated at 2022-06-25 18:51:21.949975
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion()
    assert c.get_converter('application/json') == None


# Generated at 2022-06-25 18:51:24.469719
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Case 0
    conversion_0 = Conversion()
    assert conversion_0.get_converter is None


# Generated at 2022-06-25 18:51:27.558749
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert (Conversion.get_converter("application/yaml")).is_supported
    assert not(Conversion.get_converter("application/XML")).is_supported



# Generated at 2022-06-25 18:51:32.879596
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert conversion_0.get_converter("application/json") == json
    assert conversion_0.get_converter("application/yaml") == yaml
    assert conversion_0.get_converter("application/xml") == xml
    assert conversion_0.get_converter("text/html") == html
    assert conversion_0.get_converter("text/markdown") == markdown
    assert conversion_0.get_converter("text/csv") == csv


# Generated at 2022-06-25 18:51:35.036321
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting([], None)
    formatting_0.format_headers("")


# Generated at 2022-06-25 18:51:36.246953
# Unit test for constructor of class Formatting
def test_Formatting():
    test_Formatting = Formatting()


# Generated at 2022-06-25 18:51:37.949041
# Unit test for constructor of class Formatting
def test_Formatting():
    test = Formatting([], Environment())
    assert test.enabled_plugins == []

# Generated at 2022-06-25 18:51:40.572659
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') != None
    assert Conversion.get_converter('application/xml') != None
    assert Conversion.get_converter('text/html') != None

# Generated at 2022-06-25 18:51:45.608707
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["XML"]
    env = Environment()
    kwargs = {'body': "xml", 'headers': "xml"}
    formatting_0 = Formatting(groups, env, **kwargs)

# Method format_headers of class Formatting

# Generated at 2022-06-25 18:51:54.445345
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "text/plain"
    conversion_1 = Conversion()
    converter_1 = conversion_1.get_converter(mime)
    assert(converter_1.mime == "text/plain")

    mime = "text/html"
    conversion_2 = Conversion()
    converter_2 = conversion_2.get_converter(mime)
    assert(converter_2 == None)

    mime = "application/javascript"
    conversion_3 = Conversion()
    converter_3 = conversion_3.get_converter(mime)
    assert(converter_3.mime == "application/javascript")

    mime = "application/json"
    conversion_4 = Conversion()
    converter_4 = conversion_4.get_converter(mime)

# Generated at 2022-06-25 18:51:58.406708
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
  conversion_0 = Conversion()
  mime_0 = "video/mp4"
  if conversion_0.get_converter(mime_0) == None:
    print ("[-] Conversion.get_converter_0_0 Error")
  else:
    print ("[+] Conversion.get_converter_0_0 Correct")



# Generated at 2022-06-25 18:52:00.127196
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting = Formatting(['colors'], ['colors'])
    assert formatting.enabled_plugins[0].enabled

# Generated at 2022-06-25 18:52:02.850011
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting = Formatting(groups=['a'], env=Environment(), **{})
    assert formatting.enabled_plugins == []



# Generated at 2022-06-25 18:52:06.857758
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)
    assert not isinstance(Conversion.get_converter("application/sql"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/html"), ConverterPlugin)


# Generated at 2022-06-25 18:52:09.369749
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    x = f.format_headers("aaaa")
    assert x == "aaaa"

# Generated at 2022-06-25 18:52:11.278813
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting([])
    assert isinstance(formatting_0, Formatting)


# Generated at 2022-06-25 18:52:19.339000
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    _input_str = 'HTTP/1.1 200 OK\r\ncontent-type:application/json;charset=UTF-8\r\nserver:Jetty(9.2.z-SNAPSHOT)\r\n\r\n'
    _expected_result = 'HTTP/1.1 200 OK\r\ncache-control: no-cache, no-store, max-age=0, must-revalidate\r\ncontent-type: application/json;charset=UTF-8\r\npragma: no-cache\r\nserver: Jetty(9.2.z-SNAPSHOT)\r\n'
    formatting_0 = Formatting(['headers'], {'format': 'colors'})
    result = formatting_0.format_headers(_input_str)
    assert result

# Generated at 2022-06-25 18:52:23.382474
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    mime = 'text/html'
    content = '<h1>This is a header.</h1>'
    formatting = Formatting(['format'], colors='off', indent=0, mime=mime)
    output = formatting.format_body(content, mime)
    print(output)
    assert output == content


# Generated at 2022-06-25 18:52:32.776046
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1:
    # The input MIME string is valid, which should return a converter instance.
    mime = "application/json"
    conversion_1 = Conversion()
    assert conversion_1.get_converter(mime) is not None

    # Test case 2:
    # The input MIME string is not valid, which should return None.
    mime = "application/application/json"
    conversion_2 = Conversion()
    assert conversion_2.get_converter(mime) is None



# Generated at 2022-06-25 18:52:35.989159
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting.format_body("{'courses': [{'courseId': '111'}, {'courseId': '222'}]}", 'application/json') == \
           "{'courses': [{'courseId': '111'}, {'courseId': '222'}]}"

# Generated at 2022-06-25 18:52:37.376278
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert(conversion_0.get_converter("text/xml") == "ConverterPlugin")


# Generated at 2022-06-25 18:52:42.706097
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    fmt = Formatting(groups=['color'])
    body = fmt.format_body("""
{"foo": "bar",
 "baz": "qux"}
    """, mime="application/json")

# Generated at 2022-06-25 18:52:48.066934
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    formatting_0 = Formatting(groups = ['colors', 'format'], env = env)
    content = '{"foo": "bar"}\n'
    mime = 'application/json'
    assert formatting_0.format_body(content, mime) == '{\x1b[94m"foo"\x1b[39m: \x1b[33m"bar"\x1b[39m}\n'


# Generated at 2022-06-25 18:52:51.674988
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion = Conversion()
    converter = conversion.get_converter('application/json')
    assert(converter.supports('application/json') == True)


# Generated at 2022-06-25 18:52:52.640595
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Add test case here
    pass

# Generated at 2022-06-25 18:52:54.877669
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    formatter = Formatting(['colors'], env=env)
    assert formatter.enabled_plugins != None


# Generated at 2022-06-25 18:52:56.054401
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is None


# Generated at 2022-06-25 18:52:59.042897
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json").name == "json"
    assert Conversion.get_converter("application/xml").name == "xml"
    assert Conversion.get_converter("text/html").name == "html"


# Generated at 2022-06-25 18:53:06.814981
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Positive test case of format_body
    format_groups_0 = ['colors']
    formatting_0 = Formatting(format_groups_0)
    str_0 = 'headers'
    str_1 = 'application/json'
    str_2 = formatting_0.format_body(str_0, str_1)
    print(str_2)


# Generated at 2022-06-25 18:53:10.080323
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting()
    str_0 = 'raw'
    str_1 = 'headers'
    str_2 = formatting_0.format_headers(str_0)
    str_3 = formatting_0.format_body(str_1, str_0)

# Generated at 2022-06-25 18:53:17.860661
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = 'application/json'
    str_1 = 'headers'
    list_0 = [str_1]
    formatting_0 = Formatting(list_0)
    str_2 = '{"key_0": "value_0"}'
    str_3 = formatting_0.format_headers(str_2)
    str_4 = formatting_0.format_body(str_0, str_2)


# Generated at 2022-06-25 18:53:22.341672
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test Case 0
    conversion_0 = Conversion()
    groups_0 = list()
    str_0 = 'test'
    groups_0.append(str_0)
    formatting_0 = Formatting(groups_0)
    str_1 = 'key: value'
    str_2 = formatting_0.format_headers(str_1)


# Generated at 2022-06-25 18:53:25.306819
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['colors']
    formatting_0 = Formatting(groups = groups_0)
    str_0 = "Test string"
    str_1 = "Test string"
    str_2 = formatting_0.format_body(content = str_0, mime = str_1)


# Generated at 2022-06-25 18:53:28.196881
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    line2 = 'application/json'
    conversion = Conversion()
    returned_val = conversion.get_converter(line2)
    assert returned_val is not None


# Generated at 2022-06-25 18:53:29.946431
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt = Formatting(groups=['colors'])
    headers = fmt.format_headers('foo: bar')
    print(headers)



# Generated at 2022-06-25 18:53:34.145728
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups_0 = ['AlwaysOn']
    formatting_0 = Formatting(groups_0)
    content_0 = 'This is a body'
    mime_0 = 'text/plain'
    str_0 = formatting_0.format_body(content_0, mime_0)
    assert str_0 == 'This is a body'


# Generated at 2022-06-25 18:53:43.985952
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'text/html'
    str_1 = 'application/json'
    str_2 = 'application/xml'
    str_3 = 'application/javascript'
    str_4 = 'application/x-www-form-urlencoded'
    str_5 = 'text/xml'

    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    optional_1 = conversion_0.get_converter(str_1)
    optional_2 = conversion_0.get_converter(str_2)
    optional_3 = conversion_0.get_converter(str_3)
    optional_4 = conversion_0.get_converter(str_4)

# Generated at 2022-06-25 18:53:50.613035
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    p = Formatting(groups=['colors'], env=env, colors=True, extensions=True)
    str_0 = '{ "hello": "world", "foo": "bar" }'
    str_1 = 'application/json'
    str_2 = p.format_body(str_0, str_1)
    str_3 = '{ "hello": "world", "foo": "bar" }'
    assert str_2 == str_3


# Generated at 2022-06-25 18:53:58.219569
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'my_mime'
    optional_0 = conversion_0.get_converter(str_0)
    test_case_0()


# Generated at 2022-06-25 18:54:00.903699
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = [None]
    env = Environment()
    content = ""
    mime = ""

    obj = Formatting(groups, env)
    func_ret_val_0 = obj.format_body(content, mime)
    assert func_ret_val_0 is None


# Generated at 2022-06-25 18:54:04.120787
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    for i in range(1):
        conversion_0 = Conversion()
        str_0 = 'application/json'
        optional_0 = conversion_0.get_converter(str_0)
        str_1 = 'Accept: application/json\n'
        headers = str_1
        result = optional_0.format_headers(headers)


# Generated at 2022-06-25 18:54:06.901894
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = ''
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 == None


# Generated at 2022-06-25 18:54:09.535802
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    #  unit test for conversion.get_converter
    pass

# Generated at 2022-06-25 18:54:10.899422
# Unit test for constructor of class Formatting
def test_Formatting():
    format_str = 'json'
    formatting_0 = Formatting([format_str])


# Generated at 2022-06-25 18:54:13.134192
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert callable(getattr(Conversion, "get_converter", None))
    # TODO Write better test cases
    conversion = Conversion()
    conversion.get_converter(str)



# Generated at 2022-06-25 18:54:15.384262
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(['colors', 'colors_256'])
    str_0 = 'status: 200 OK'
    str_1 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:54:19.736771
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/xml'
    optional_0 = conversion_0.get_converter(str_0)
    str_1 = 'application/json'
    optional_1 = conversion_0.get_converter(str_1)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 18:54:24.884569
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(['colors'])
    str_0 = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 4\r\n\r\n'
    formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:54:31.975308
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    env_0 = Environment()
    obj_0 = Formatting(
        groups_0,
        env=env_0,
    )
    obj_1 = Formatting(
        groups_0,
    )
    obj_2 = Formatting(
        [],
    )
    assert obj_0.env == env_0
    assert obj_1.env == Environment()
    assert obj_2.env == Environment()

    

# Generated at 2022-06-25 18:54:36.704909
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(['color'])
    str_0 = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    str_1 = formatting_0.format_headers(str_0)
    str_0 = 'HTTP/1.1 200 OK\r\nContent-Type: application/xml\r\n\r\n'
    str_2 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:54:41.456373
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['highlight']
    env = Environment()
    formatting = Formatting(groups, env)
    content = ''
    mime = 'application/json'
    assert formatting.format_body(content, mime) == ''


# Generated at 2022-06-25 18:54:43.489038
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0: list = []
    test_Formatting_0 = Formatting(groups_0)

# Generated at 2022-06-25 18:54:44.611884
# Unit test for constructor of class Formatting
def test_Formatting():
    format_0 = Formatting([])


# Generated at 2022-06-25 18:54:46.342821
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(['colors'], env)


# Generated at 2022-06-25 18:54:51.654550
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = "json"
    formatting_0 = Formatting(groups=[str_0])
    str_1 = "{'key_2': ['value_3', 'value_4', 'value_5'], 'key_6': {'key_7': 'value_8'}, 'key_9': 'value_10'}"
    str_2 = "application/json"
    str_3 = formatting_0.format_body(str_1, str_2)

# Generated at 2022-06-25 18:54:53.890739
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting()
    str_0 = ''
    str_1 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:55:00.848523
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env=env_0)
    headers_0 = ''
    optional_0 = formatting_0.format_headers(headers_0)
    str_0 = 'application/json'
    content_0 = ''
    optional_1 = formatting_0.format_body(content_0, str_0)


if __name__ == '__main__':
    # test_case_0()
    test_Formatting()

# Generated at 2022-06-25 18:55:07.537832
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from random import randint
    from random import seed
    str_0 = 's'
    seed(0)
    num_0 = randint(-50,50)
    str_1 = 'jJbzgQQq'
    for i in range(0, num_0):
        str_0 = str(i) + str_1
    print(str_0)
    print('Expected output: application/json')
    assert str_0 == 'application/json'


# Generated at 2022-06-25 18:55:12.816153
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    groups = ['Css', 'Json', 'UnixTimestamp', 'Pygments']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting


# Generated at 2022-06-25 18:55:16.713943
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert True
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:55:25.939549
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case with zero argument
    available_plugins = plugin_manager.get_formatters_grouped()
    formatting_0 = Formatting([])
    str_1 = 'HTTP/1.1 200 OK\nContent-Type: application/json'
    str_0 = formatting_0.format_headers(str_1)
    assert str_0 == 'HTTP/1.1 200 OK\nContent-Type: application/json'
    # Test case with one argument
    formatting_1 = Formatting(['colors'])
    str_0 = formatting_1.format_headers(str_1)
    assert str_0 == 'HTTP/1.1 200 OK\nContent-Type: application/json'


# Generated at 2022-06-25 18:55:28.436112
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    test_0 = Formatting(groups_0)
    groups_1 = ['']
    test_1 = Formatting(groups_1)


# Generated at 2022-06-25 18:55:31.583345
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].name == 'Colorizer'
    assert f.enabled_plugins[0].enabled

# Generated at 2022-06-25 18:55:34.569541
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Parameters
    converter = Conversion()
    str0 = 'application/json'
    # Response
    response = converter.get_converter(str0)
    assert response



# Generated at 2022-06-25 18:55:38.955799
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    origin_1 = Environment()
    str_0 = 'application/json'
    str_1 = 'application/json'
    obj_0 = Formatting(str_0, env=origin_1, input_mime_type=str_1)
    str_2 = '{"a":1}'
    var_0 = obj_0.format_headers(str_2)


# Generated at 2022-06-25 18:55:43.871404
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = ''
    formatting = Formatting(str_0)
    str_1 = 'Content-Type: application/json'
    str_2 = formatting.format_headers(str_1)


# Generated at 2022-06-25 18:55:48.059747
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting()
    str_0 = 'application/json'
    str_1 = '{}'
    format_body_ret_0 = formatting_0.format_body(str_1, str_0)


# Generated at 2022-06-25 18:55:53.437645
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    conversion_0 = Conversion()
    str_1 = 'application/json'
    optional_0 = conversion_0.get_converter(str_1)

    formatting_0 = Formatting(['formatters'])
    str_0 = '{}'
    str_2 = formatting_0.format_body(str_0, str_1)


# Generated at 2022-06-25 18:56:00.110435
# Unit test for constructor of class Formatting
def test_Formatting():
    header = 'Header'
    group = ['group']
    env = Environment()
    k = {'k': 'v'}
    formatting = Formatting(group, env, k)
    assert formatting.enabled_plugins == []
    assert formatting.format_headers(header) == header
    assert formatting.format_body(header, 'application/json') == header

# Generated at 2022-06-25 18:56:07.103976
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()

    class FakeFormatter:

        def __init__(self, env, headers_preprocessor_name):
            self.headers_preprocessor_name = headers_preprocessor_name

        def enabled(self):
            return True

        def format_headers(self, headers):
            return 'formatted_headers'

    class StubPluginManager:

        def get_formatters_grouped(self):
            return {
                'headers_preprocessors': [FakeFormatter(env, 'headers_preprocessor_name')]
            }

    env.plugin_manager = StubPluginManager()
    formatting_0 = Formatting(['preprocessors'], env)
    str_0 = 'headers'
    str_1 = formatting_0.format_headers(str_0)
    assert 'formatted_headers' == str_1

# Generated at 2022-06-25 18:56:11.327336
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    # create an instance of class Conversion for testing
    conversion_0 = Conversion()

    # test section one: with string type as content type
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)

    # test section two: with string type as content type
    str_1 = 'text/plain'
    optional_1 = conversion_0.get_converter(str_1)


# Generated at 2022-06-25 18:56:12.820052
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test if the function doesn't raise any error
    formatting = Formatting(groups=['colors'])
    formatting.format_body('', 'image/png')

# Generated at 2022-06-25 18:56:23.832007
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting(('chrome', 'ansi'))
    str_0 = 'application/json'
    str_1 = '{\n    "args": {}, \n    "headers": {\n        "Accept": "*/*", \n        "Accept-Encoding": "gzip, deflate", \n        "Connection": "close", \n        "Host": "httpbin.org", \n        "User-Agent": "HTTPie/0.9.9"\n    }, \n    "origin": "1.1.1.1, 123.456.789.012", \n    "url": "https://httpbin.org/get"\n}'
    str_2 = formatting_0.format_body(str_1, str_0)


# Generated at 2022-06-25 18:56:29.245468
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    # Testing argument 'headers' of method 'format_headers'
    # The value of this argument is equal to the value of the previous argument,
    # and the previous argument is not equal to the default value of the corresponding argument,
    # and the previous argument is not equal to None.
    class Injector1:
        def format_headers(self, headers):
            return headers

    f = Formatting(['injector1'], Injector1=Injector1)
    str_0 = 'headers0'
    str_1 = f.format_headers(str_0)



# Generated at 2022-06-25 18:56:33.510804
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = []
    formatting_0 = Formatting(groups_0)
    headers_0 = 'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'
    assert formatting_0.format_headers(headers_0) == headers_0


# Generated at 2022-06-25 18:56:34.523024
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert test_case_0() == None


# Generated at 2022-06-25 18:56:39.282089
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    pytest.assume(optional_0 is None)
    pytest.assume(optional_0 is not None)
    pytest.assume('httpie.plugins.converter.ConverterPlugin object' in str(optional_0))



# Generated at 2022-06-25 18:56:45.469394
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    o = Formatting()
    formatters = plugin_manager.get_formatters_grouped()
    for i, formatter in enumerate(formatters):
        for formatter_cls in formatters[formatter]:
            p = formatter_cls(env=Environment())
            if p.enabled:
                o.enabled_plugins.append(p)
                p.format_headers(header)
                p.format_body(header, mime_type)


# Generated at 2022-06-25 18:56:50.759417
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 is not None
    assert isinstance(optional_0,ConverterPlugin)


# Generated at 2022-06-25 18:56:56.644178
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ["json"]
    str_1 = 'application/json'
    str_2 = '{"foo":"bar"}'
    str_3 = '{\n    "foo": "bar"\n}'
    formatting_0 = Formatting(groups_0)
    str_4 = formatting_0.format_body(str_2, str_1)
    assert str_4 == str_3
    str_5 = '{\n    "foo": "bar"\n}'
    str_6 = '{\n    "foo": "bar"\n}'


# Generated at 2022-06-25 18:56:59.038071
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = [
        'colors'
    ]
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env=env_0)


# Generated at 2022-06-25 18:57:04.438325
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups_0 = ['Test', 'Test']
    formatting_0 = Formatting(groups_0)
    groups_0 = ['Test']
    str_0 = 'Test'
    str_1 = formatting_0.format_body(groups_0, str_0)
    str_0 = 'Test'
    str_2 = formatting_0.format_headers(str_0)
    str_0 = 'Test'
    str_3 = formatting_0.format_body(str_0, str_0)
    pass

# Generated at 2022-06-25 18:57:05.432190
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert 1 == 1


# Generated at 2022-06-25 18:57:10.387438
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    with patch('httpie.output.Conversion') as mock_Conversion:
        mock_Conversion.get_converter.side_effect = Conversion.get_converter
        conversion = mock_Conversion()
        groups = []
        arg_2 = 'application/json'
        str_0 = conversion.get_converter(arg_2)


# Generated at 2022-06-25 18:57:12.405621
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:57:17.313773
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting([])

# Generated at 2022-06-25 18:57:27.977035
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    json_0 = "{\n    \"rows\": {\n        \"count\": 10,\n        \"item\": [\n        {\n            \"name\": \"name2\",\n            \"title\": \"title2\",\n            \"description\": \"description2\"\n        },\n        {\n            \"name\": \"name1\",\n            \"title\": \"title1\",\n            \"description\": \"description1\"\n        }\n        ]\n    }\n}"
    str_0 = 'json'
    formatting_0 = Formatting(['indent'])
    optional_0 = formatting_0.format_body(json_0, str_0)


# Generated at 2022-06-25 18:57:30.793319
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)

    formatting = Formatting()
    str_1 = '{"testing": "1234"}'
    str_0 = formatting.format_headers(str_1)
    assert str_0 == '{"testing": "1234"}'



# Generated at 2022-06-25 18:57:38.721453
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert callable(test_case_0)

# Generated at 2022-06-25 18:57:43.846391
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['colors']
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env_0)
    headers_0 = 'HTTP/1.1 200 OK\r\nAccept: application/json\r\nContent-Type: application/json\r\n\r\n'
    str_0 = formatting_0.format_headers(headers_0)

# Generated at 2022-06-25 18:57:44.624066
# Unit test for constructor of class Formatting
def test_Formatting():
    pass


# Generated at 2022-06-25 18:57:47.210606
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0.mime == str_0


# Generated at 2022-06-25 18:57:47.761122
# Unit test for constructor of class Formatting
def test_Formatting():
    pass

# Generated at 2022-06-25 18:57:50.180633
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['json', 'style']
    formatting_0 = Formatting(groups_0)
    assert isinstance(formatting_0.enabled_plugins, list) == True


# Generated at 2022-06-25 18:57:52.500870
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_1 = ['Colors' , 'Warnings']
    env_1 = Environment()
    kwargs_1 = {}
    formatting_0 = Formatting(groups_1 , env_1 , **kwargs_1)


# Generated at 2022-06-25 18:57:56.046463
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = ''
    str_1 = 'application/json'
    formatting_0 = Formatting([])
    str_2 = formatting_0.format_body(str_0, str_1)
    assert str_2 == str_0



# Generated at 2022-06-25 18:57:57.850419
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    unittest.main()


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 18:57:59.498650
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(None, None)


# Generated at 2022-06-25 18:58:08.805175
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = [
        'colors',
        'colors',
        'colors'
    ]
    formatting_0 = Formatting(groups_0)
    str_0 = 'application/json'
    optional_0 = formatting_0.format_body(str_0, str_0)


# Generated at 2022-06-25 18:58:10.313709
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion = Conversion()
    str = 'application/json'
    assert conversion.get_converter(str)



# Generated at 2022-06-25 18:58:18.464423
# Unit test for constructor of class Formatting
def test_Formatting():

    conversion_0 = Conversion()
    list_0 = ['A', 'B', 'C', 'D', 'E']
    environment_0 = Environment(None, '', 'application/json')
    formatting_0 = Formatting(list_0, environment_0)

    # Test method format_headers
    str_0 = 'abc'
    assert 'abc' == formatting_0.format_headers(str_0)

    str_1 = 'application/json'
    str_2 = 'aGVsbG8gd29ybGQ='
    str_3 = 'a2V5OiB2YWx1ZQo='
    str_4 = 'eyJrZXkiOiJ2YWx1ZSJ9'

# Generated at 2022-06-25 18:58:26.016725
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.compat import urlopen
    from httpie.core import main
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.registry import plugin_manager

    plugin_manager.register(HTTPBasicAuth)
    url = 'http://github.com/jkbrzt/httpie'
    output = urlopen(main(args=[
        '--print', 'Bh', '--headers',
        'GET', url
    ])).read().decode('UTF-8')
    assert 'HTTP/1.1' in output



# Generated at 2022-06-25 18:58:33.308267
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = ['colors']
    formatting_0 = Formatting(groups_0)
    headers = '''HTTP/1.1 200 OK
Date: Wed, 15 Nov 1995 06:25:24 GMT
Content-Type: text/plain
Content-Length: 1354
Last-modified: Fri, 10 Nov 1995 14:23:27 GMT
Server: Apache/2.2.8 (Unix) DAV/2 PHP/5.2.6 with Suhosin-Patch'''
    headers_format = formatting_0.format_headers(headers)
    assert 'HTTP/1.1 200 OK\n' in headers_format
    assert 'Last-modified: Fri, 10 Nov 1995 14:23:27 GMT\n' in headers_format


# Generated at 2022-06-25 18:58:41.231520
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins_0 = plugin_manager.get_formatters_grouped()
    str_0 = 'headers'
    str_1 = 'body'
    groups_0 = [str_0, str_1]
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env=env_0)
    str_2 = 'text/plain'
    str_3 = 'Hello World!'
    str_4 = formatting_0.format_body(str_3, str_2)
    

# Generated at 2022-06-25 18:58:50.312630
# Unit test for constructor of class Formatting
def test_Formatting():

    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    str_1 = 'application/json'
    optional_1 = conversion_0.get_converter(str_1)
    groups_0 = ['JSON', 'debug']
    env = Environment()
    str_2 = 'application/json'
    optional_2 = conversion_0.get_converter(str_2)
    str_3 = 'application/json'
    optional_3 = conversion_0.get_converter(str_3)
    formatting_0 = Formatting(groups_0, env=env)
    formatting_0 = Formatting(groups_0, env=env)
    str_4 = ''
    str_5 = formatting_0

# Generated at 2022-06-25 18:59:00.127975
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    str_1 = 'application/json'
    optional_1 = conversion_1.get_converter(str_1)
    str_2 = 'text/plain'
    optional_2 = conversion_1.get_converter(str_2)
    str_3 = 'text/html'
    optional_3 = conversion_1.get_converter(str_3)
    str_4 = 'application/xml'
    optional_4 = conversion_1.get_converter(str_4)
    str_5 = 'text/markdown'
    optional_5 = conversion_1.get_converter(str_5)



# Generated at 2022-06-25 18:59:02.542959
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    instance_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = instance_0.get_converter(str_0)
    assert(optional_0 is not None)


# Generated at 2022-06-25 18:59:06.153508
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = []
    env = Environment()
    kwargs = {}
    test = Formatting(groups, env, **kwargs)

# Generated at 2022-06-25 18:59:18.892503
# Unit test for constructor of class Formatting

# Generated at 2022-06-25 18:59:22.064170
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = ['format']
    available_plugins_0 = Formatting(groups_0)
    str_0 = '{ "header": "value" }'
    optional_0 = available_plugins_0.format_headers(str_0)


# Generated at 2022-06-25 18:59:25.011204
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'application/json'
    formatting_0 = Formatting([str_0])
    str_1 = 'Content-Type: application/json'
    str_0 = formatting_0.format_headers(str_1)
