

# Generated at 2022-06-25 18:49:34.850298
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    cls = conversion_0.get_converter('application/json')
    assert cls.mime == 'application/json'


# Generated at 2022-06-25 18:49:44.974460
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Case 1
    fm = Formatting(groups=["format-pretty"])
    mime = "application/json"
    content = """{"text": "Hello world!"}"""
    assert fm.format_body(content, mime) == fm.format_body(content, mime)

    # Case 2
    fm = Formatting(groups=["format-pretty"])
    mime = "application/json"
    content = """{"text": "Hello world!"}"""
    assert fm.format_body(content, mime) == fm.format_body(content, "application/json")

    # Case 3
    fm = Formatting(groups=["format-pretty"])
    mime = "application/json"
    content = """{"text": "Hello world!"}"""
    assert fm.format

# Generated at 2022-06-25 18:49:46.040192
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    pass


# Generated at 2022-06-25 18:49:48.508997
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    conversion_1.get_converter("application/json")
    conversion_1.get_converter("application/xml")


# Generated at 2022-06-25 18:49:50.773683
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('application/json') is not None



# Generated at 2022-06-25 18:50:00.688421
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    msg = "Test if formatting is applied to body"

    # Test case 1:
    f = Formatting(['colors'], None, None)
    assert f.format_body('foo', 'text/plain')

    # Test case 2:
    f = Formatting(['colors'], None, None)
    assert f.format_body('foo', 'text/plain')

    # Test case 3:
    f = Formatting(['colors'], None, None)
    assert f.format_body('foo', 'image/png')

    # Test case 4:
    f = Formatting(['colors'], None, None)
    assert f.format_body('foo', 'image/png')


# Generated at 2022-06-25 18:50:02.488227
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors"]
    env = Environment(colors=True)
    fm = Formatting(groups, env)


# Generated at 2022-06-25 18:50:11.510604
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ["indent"]
    kwargs = {"indent": 4}
    new_formatting = Formatting(groups, **kwargs)
    content = "{\n    \"userId\": 1,   \"id\": 1,\n    \"title\": \"delectus aut autem\", \n    \"completed\": false\n}"
    mime = "application/json"
    expected_1 = "{\n    \"userId\": 1,   \"id\": 1,\n    \"title\": \"delectus aut autem\", \n    \"completed\": false\n}"
    expected_2 = "{\n    \"userId\": 1,   \"id\": 1,\n    \"title\": \"delectus aut autem\", \n    \"completed\": false\n}"

# Generated at 2022-06-25 18:50:13.876868
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format_headers_0 = Formatting.format_headers(groups="headers", headers="")
    if (format_headers_0 is None):
        raise RuntimeError("format_headers_0 is None")


# Generated at 2022-06-25 18:50:21.214646
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-25 18:50:26.557224
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # No need to test on this one, both Formatting and Highlighting contains
    # only methods used by output.py, hence there is no need to see what
    # happens in the method itself.
    pass


# Generated at 2022-06-25 18:50:38.182064
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from io import StringIO
    from httpie.core import main_httpie
    from httpie.context import Environment
    from httpie import ExitStatus
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    _env = Environment()
    args_0 = ['httpie', '-f', 'json', 'http://127.0.0.1:7777/']
    args_1 = args_0[2:]
    exit_status, error_msg, env = main_httpie(
        args=args_0[2:],
        stdin=StringIO(u''),
        env=_env
    )
    args_0 = ['httpie', '-f', 'json', 'http://127.0.0.1:7777/']
    args_1 = args_0[2:]
    exit

# Generated at 2022-06-25 18:50:47.526749
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors']
    env = Environment()
    formatter = Formatting(groups, env)
    headers = '''HTTP/1.1 200 OK
Cache-Control: no-cache
Connection: keep-alive
Content-Length: 14
Content-Type: application/json; charset=utf-8
Date: Tue, 15 Jan 2019 18:50:12 GMT
Server: Titan
X-Powered-By: Express
'''

# Generated at 2022-06-25 18:50:50.424908
# Unit test for constructor of class Formatting
def test_Formatting():

    groups = ['printing']
    kwargs = {'table_columns': ['h']}
    formatting_0 = Formatting(groups, **kwargs)

# Generated at 2022-06-25 18:50:56.195910
# Unit test for constructor of class Formatting
def test_Formatting():
    format_headers = 'headers'
    format_body = 'text'
    groups = [format_headers, format_body]
    formatter = Formatting(groups)
    assert (formatter.enabled_plugins != [])

if __name__ == '__main__':
    test_case_0()
    test_Formatting()
    print('Defensive programming test cases are finished.')

# Generated at 2022-06-25 18:51:00.824518
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(groups = ['colors'])
    str_0 = 'HTTP/1.1 200 OK'
    str_1 = formatting_0.format_headers(str_0)
    assert str_1 == '\x1b[1mHTTP/1.1 200 OK\x1b[0m'


# Generated at 2022-06-25 18:51:09.321992
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Check if there are valid inputs
    # Set up argument values
    groups_0 = []
    groups_1 = ['color', 'syntax']
    kwargs = {}
    kwargs = {}
    obj_0 = Formatting(groups_0, **kwargs)
    obj_1 = Formatting(groups_1, **kwargs)
    headers_0 = "test"
    headers_1 = "test"
    str_0 = obj_0.format_headers(headers_0)
    str_1 = obj_1.format_headers(headers_1)
    # Check if there are valid outputs
    assert "test" == str_0
    assert "test" == str_1


# Generated at 2022-06-25 18:51:21.241901
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Environment
    env = Environment()
    env.config['pretty'] = 'all'
    # Formatting
    formatter = Formatting(('pretty',), env=env)
    # Tests
    test_case_0()
    test_case_1()
    # test_case_2(test_case_1)
    # test_case_3(test_case_1)
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7(formatter)
    test_case_8()
    test_case_9(formatter)
    test_case_10()
    test_case_11(formatter)
    test_case_12()
    test_case_13(formatter)
    # test_case_14(formatter)
    #

# Generated at 2022-06-25 18:51:27.366363
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups: List[str] = []
    env: Environment = Environment()
    f_1: Formatting = Formatting(groups, env=env)
    str_1: str = 'headers'
    str_2: str = 'mime'
    str_3: str = f_1.format_headers(str_1)
    str_4: str = f_1.format_body(str_1, str_2)


# Generated at 2022-06-25 18:51:33.984736
# Unit test for constructor of class Formatting
def test_Formatting():
    with open('./tests/output/formatting.output', 'r') as output:
        with open('./tests/input/formatting.input', 'r') as input:
            env = Environment()
            env.stdout = output
            env.stdin = input
            groups = list()
            groups.append("json")
            groups.append("colors")
            groups.append("format")
            groups.append("colors")
            formatting_0 = Formatting(groups, env)
        # output.close()
        # input.close()

if __name__ == "__main__":
    test_case_0()
    test_Formatting()

# Generated at 2022-06-25 18:51:43.713972
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors'], **{'colors': True})
    fmt.format_headers('{"foo": "bar"}')
    fmt = Formatting(['colors'], **{'colors': False})
    fmt.format_headers('{"foo": "bar"}')
    fmt = Formatting(['colors'], **{'colors': True})
    fmt.format_body('{"foo": "bar"}', 'application/json')
    fmt = Formatting(['colors'], **{'colors': False})
    fmt.format_body('{"foo": "bar"}', 'application/json')

# Generated at 2022-06-25 18:51:45.808481
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['Pretty,Colors']
    formatting_0 = Formatting(groups_0)
    assert isinstance(formatting_0, Formatting)


# Generated at 2022-06-25 18:51:48.533105
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 is not None



# Generated at 2022-06-25 18:51:57.355668
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['json', 'pretty']
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env_0)

# Generated at 2022-06-25 18:52:03.306697
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'headers'
    str_1 = 'application/json'
    formatting_0 = Formatting(['headers'], ['headers'])
    str_2 = formatting_0.format_headers(str_0)
    str_3 = formatting_0.format_body(str_0, str_1)


if __name__ == '__main__':
    test_case_0()
    test_Formatting_format_body()

# Generated at 2022-06-25 18:52:11.697149
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = []
    formatting_0 = Formatting(groups=groups_0)
    str_0 = 'Accept: application/json\r\nCache-Control: no-cache\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: 0\r\nHost: httpbin.org\r\nUser-Agent: HTTPie/1.0.2\r\n'
    str_1 = formatting_0.format_headers(str_0)
    # Asserts the correctness of the type output for format_headers
    assert isinstance(str_1, str)


# Generated at 2022-06-25 18:52:13.221501
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optiona

# Generated at 2022-06-25 18:52:20.431446
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Setup
    def func_0(str_0, str_1):
        str_1
        return str_0
    str_0 = 'abc'
    str_1 = 'def'
    groups = [str_0, str_1]
    env = Environment()
    formatting_0 = Formatting(groups, env)
    headers = 'ghi'
    available_plugins = plugin_manager.get_formatters_grouped()
    formatting_0.enabled_plugins = []
    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=env)
            if p.enabled:
                formatting_0.enabled_plugins.append(p)
    # Exercise
    result = formatting_0.format_headers(headers)
    # Verify
    assert result == 'ghi'


# Generated at 2022-06-25 18:52:22.290394
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = ['pprint']
    env = Environment()
    format = Formatting(list_0, env=env)


# Generated at 2022-06-25 18:52:23.742804
# Unit test for constructor of class Formatting
def test_Formatting():
    assert isinstance(Formatting, object)


# Generated at 2022-06-25 18:52:28.877218
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 is not None

# Generated at 2022-06-25 18:52:37.829513
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    var_0 = ["CURL", "COLORS", "INSPECT"]
    var_1 = Environment()
    formatting_0 = Formatting(var_0, var_1)
    str_0 = 'HTTP/1.1 200 OK\r\nServer: nginx/1.14.0 (Ubuntu)\r\nDate: Tue, 12 Feb 2019 19:33:39 GMT\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 18\r\nConnection: keep-alive\r\nE-Tag: W/"12-FIxzJq3FqLo1z5p5NwZ6Uuq6UY8"\r\nX-Powered-By: Express\r\n\r\n'

# Generated at 2022-06-25 18:52:45.215544
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    str_0 = 'pretty'
    curr = Formatting([str_0], env)
    str_1 = 'http://www.example.com/'
    str_2 = 'HTTP/1.1 200 OK\nContent-Type: text/html\nContent-Length: 1354\n\n'
    str_3 = 'HTTP/1.1 200 OK\nContent-Type: text/html\nContent-Length: 1354\n\n'
    returned_str = curr.format_headers(str_2)
    assert str_3 == returned_str


# Generated at 2022-06-25 18:52:48.577532
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    exception_0 = None
    try:
        optional_0 = conversion_0.get_converter("application/json")
    except Exception as e:
        exception_0 = e
    assert exception_0 is None


# Generated at 2022-06-25 18:52:51.576800
# Unit test for constructor of class Formatting
def test_Formatting():
    # Check the name of the group
    formatting_0 = Formatting(['format'])



# Generated at 2022-06-25 18:52:55.421539
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        str_arg = "json"
        bool_arg = True
        env_arg = Environment()
        obj_arg = Formatting([str_arg], env=env_arg, pretty=bool_arg)
    except Exception:
        assert False


# Generated at 2022-06-25 18:52:57.523617
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:53:01.135181
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = ''
    str_1 = ''
    str_2 = 'application/json'

    formatting_0 = Formatting([], Environment())
    str_3 = formatting_0.format_headers(str_0)

    formatting_1 = Formatting([])
    str_4 = formatting_1.format_headers(str_1)
    str_5 = formatting_1.format_headers(str_2)



# Generated at 2022-06-25 18:53:01.736965
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pass

# Generated at 2022-06-25 18:53:03.685207
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Initialize
    groups_0 = []
    optional_0 = Optional
    # End of initialization



# Generated at 2022-06-25 18:53:09.755471
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Init
    mime = 'Json'
    content = 'Some data in JSON format'
    # Call the method
    formatting_0 = Formatting(['Json'], 'application/json')
    str_0 = formatting_0.format_body(content, mime)
    # Check whether there are not any exceptions


# Generated at 2022-06-25 18:53:14.124879
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/xml'
    result = conversion_0.get_converter(str_0)
    assert result == None

# Generated at 2022-06-25 18:53:18.064394
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 is not None
    assert optional_0.mime == str_0


# Generated at 2022-06-25 18:53:26.772741
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Initialize input parameters
    groups = ['Formatters', 'Converters', 'Highlight']

    # Call to method format_body of class Formatting
    # (Initialize a Formatting instance)
    formatting = Formatting(groups)

    # Call to method format_body of the instance formatting
    str_0 = 'application/json'
    str_1 = '{"key": "value"}'
    str_2 = formatting.format_body(str_1, str_0)
    str_3 = 'HTTPie 0.9.9'
    str_4 = 'HTTPie 0.9.9'
    # Call to method format_headers of the instance formatting
    str_5 = 'Accept: application/json\r\n'
    str_6 = formatting.format_headers(str_5)

# Generated at 2022-06-25 18:53:28.503636
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    env_0 = Environment()
    test_case_0 = Formatting(groups_0, env_0)


# Generated at 2022-06-25 18:53:31.485815
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'application/json'
    str_1 = '{"httpie": "HTTPie"}'
    formatting_0 = Formatting([], env=Environment())
    str_2 = formatting_0.format_body(str_1, str_0)


# Generated at 2022-06-25 18:53:34.076363
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 is not None



# Generated at 2022-06-25 18:53:39.797540
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups_0 = ['colors']
    env_0 = Environment()
    arg_0 = 'application/schema+json'
    arg_1 = '{}'
    obj_0 = Formatting(groups_0, env_0)
    str_0 = obj_0.format_body(arg_1, arg_0)
    assert str_0 == '{\n    '



# Generated at 2022-06-25 18:53:42.856455
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatter_0 = Formatting()
    str_0 = '{}'
    str_1 = 'application/json'
    str_2 = formatter_0.format_body(str_0, str_1)


# Generated at 2022-06-25 18:53:47.988949
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    if optional_0:
        converter_0 = optional_0
        if (converter_0.MIME == str_0):
            assert (True)
    else:
        assert (False)


# Generated at 2022-06-25 18:53:53.745181
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = ['colors', 'colors', 'colors']
    formatting_0 = Formatting(groups_0)
    str_0 = 'application/json'
    str_1 = 'application/json'
    str_2 = 'application/json'
    str_3 = formatting_0.format_headers(str_2)
    assert str_3 == 'application/json'


# Generated at 2022-06-25 18:53:57.262662
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors', 'colors']) is not None


# Generated at 2022-06-25 18:53:59.182871
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:54:04.203152
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content_0 = '{"status":{"code":0,"msg":"success"}}'
    str_1 = 'application/json'
    formatting_0 = Formatting(())
    formatting_0.format_body(content_0, str_1)
    groups_0 = []
    kwargs_0 = {}
    formatting_1 = Formatting(groups_0, **kwargs_0)
    formatting_1.format_body(content_0, str_1)
    formatting_2 = Formatting(())
    formatting_2.format_body(content_0, str_1)


# Generated at 2022-06-25 18:54:06.203811
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Input parameters

    # Invoke operation
    obj = Formatting()
    result = obj.format_headers()

    # Output verification


# Generated at 2022-06-25 18:54:09.534299
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Input Parameters:
    mime = 'application/json'

    # Output Parameters:
    expected_result = 'application/json'

    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(mime)
    assert optional_0.mime == expected_result

# Generated at 2022-06-25 18:54:14.096810
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Create an instance of class Formatting
    formatting_0 = Formatting([], env=Environment())
    # Create an instance of class str, and assign it to the variable str_0
    str_0 = 'HTTP/1.1 200 OK'
    # Assign to the variable str_1 the result of calling method format_headers
    # of formatting_0, providing as argument the value of str_0
    str_1 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:54:16.312807
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors', 'format'], env=Environment(), indent=2)
    # print(fmt)
    assert fmt is not None
    assert fmt.enabled_plugins is not None

# Generated at 2022-06-25 18:54:18.827482
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 is not None


# Generated at 2022-06-25 18:54:29.465247
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    env = Environment()
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    if optional_0:
        optional_0.from_unicode(str_0)
    str_1 = 'application/json'
    optional_1 = conversion_0.get_converter(str_1)
    if optional_1:
        optional_1.from_unicode(str_1)
    str_2 = 'application/json'
    optional_2 = conversion_0.get_converter(str_2)
    if optional_2:
        optional_2.from_unicode(str_2)
    str_3 = 'application/json'

# Generated at 2022-06-25 18:54:38.147233
# Unit test for method get_converter of class Conversion

# Generated at 2022-06-25 18:54:41.362838
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 0 with assertEquals

    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:54:51.057158
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # verification
    groups_0 = []
    env_0 = Environment()
    str_0 = 'HTTP/1.1 200 OK'
    formatting_0 = Formatting(groups_0, env=env_0, headers=str_0)
    str_1 = 'HTTP/1.1 200 OK'
    assert not formatting_0.format_body(str_1, str_1)
    # normal case
    groups_1 = []
    env_1 = Environment()
    str_2 = 'HTTP/1.1 200 OK'
    formatting_1 = Formatting(groups_1, env=env_1, headers=str_2)
    str_3 = 'HTTP/1.1 200 OK'
    str_4 = 'application/json'
    assert not formatting_1.format_body(str_3, str_4)

# Generated at 2022-06-25 18:54:53.288858
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['JSONFormatter']
    formatting_0 = Formatting(groups_0)


# Generated at 2022-06-25 18:54:55.633066
# Unit test for constructor of class Formatting
def test_Formatting():
    x = Formatting(['colors', 'formatters'])
    assert(isinstance(x,Formatting))


# Generated at 2022-06-25 18:54:59.291187
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt_0 = Formatting(groups=['Highlighter'])
    str_0 = 'ABC'
    str_1 = fmt_0.format_headers(str_0)
    assert str_1 == str_0


# Generated at 2022-06-25 18:55:02.901215
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors']
    formatting_0 = Formatting(groups)
    str_0 = 'HTTP/1.1 204\r\n\r\n'
    str_1 = formatting_0.format_headers(str_0)
    assert str_1 is not None


# Generated at 2022-06-25 18:55:11.736360
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    str_1 = 'application/json'
    optional_1 = conversion_0.get_converter(str_1)
    conversion_1 = Conversion()
    str_2 = 'application/json'
    optional_2 = conversion_1.get_converter(str_2)
    str_3 = 'application/json'
    optional_3 = conversion_1.get_converter(str_3)
    assert optional_3 is not None


# Generated at 2022-06-25 18:55:13.065112
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    assert isinstance(conversion_0.get_converter(''),
                      ConverterPlugin)


# Generated at 2022-06-25 18:55:24.669960
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    fmt = Formatting(['colors'], None)
    # Example to be tested
    headers = '''HTTP/1.1 200 OK
Server: MochiWeb/1.1 WebMachine/1.10.3 (that head fake, tho)
Date: Wed, 23 Jan 2013 16:01:38 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 25
Last-Modified: Sat, 13 Oct 2012 20:27:12 GMT
Location: http://www.google.com
X-XSS-Protection: 1; mode=block
X-Frame-Options: SAMEORIGIN
Alternate-Protocol: 80:quic,p=0.5
Accept-Ranges: none
Connection: close

'''


# Generated at 2022-06-25 18:55:36.410172
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print("Test 0")
    conversion_0 = Conversion()
    str_0 = "application/json"
    optional_0 = conversion_0.get_converter(str_0)
    print("Test 1")
    conversion_1 = Conversion()
    str_1 = "application/json"
    optional_1 = conversion_1.get_converter(str_1)
    print("Test 2")
    conversion_2 = Conversion()
    str_2 = "application/json"
    optional_2 = conversion_2.get_converter(str_2)
    print("Test 3")
    conversion_3 = Conversion()
    str_3 = "application/json"
    optional_3 = conversion_3.get_converter(str_3)
    print("Test 4")
    conversion_4 = Conversion()


# Generated at 2022-06-25 18:55:39.511789
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # noinspection PyTypeChecker
    formatting_0 = Formatting()
    # noinspection PyTypeChecker
    str_0 = 'application/json'
    # noinspection PyTypeChecker
    str_1 = formatting_0.format_body(str_0, str_0)


# Generated at 2022-06-25 18:55:45.197719
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # setUp()
    str_0 = 'application/json'
    str_1 = 'text/html'
    formatting = Formatting([str_0, str_1])
    str_2 = 'Content-Type: application/json'
    # act
    str_3 = formatting.format_headers(str_2)


# Generated at 2022-06-25 18:55:53.303796
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Environment variable HTTPIE_PREFERRED_STYLE won't be set
    env = Environment()
    env.preferred_style = None
    # Attempt to invoke the constructor of class Formatting
    try:

        obj_0 = Formatting(['headers'], env, a=['val'])
    except Exception:
        obj_0 = None


# Generated at 2022-06-25 18:55:58.672326
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    for group in plugin_manager.get_formatters_grouped():
        formatting_0 = Formatting(groups=[group])
        str_0 = 'test_str'
        start_line_0 = formatting_0.format_headers(str_0)
        print(start_line_0)


# Generated at 2022-06-25 18:56:02.554910
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """
    Method to test the method format_headers of class Formatting.
    """
    # Test case 0
    output_0 = Formatting()
    output_0 = output_0.format_headers('headers')
    if output_0 == 'headers':
        print("passed test case 0")
    else:
        print("failed test case 0")


# Generated at 2022-06-25 18:56:07.551623
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    def test_format_body(instance, v_0, v_1):
        return instance.format_body(v_0, v_1)

    formatting_0 = Formatting(['colors', 'formatters'])
    conversion_0 = Conversion()
    str_0 = 'application/json'
    conversion_1 = conversion_0.get_converter(str_0)
    optional_0 = conversion_1
    if optional_0:
        value = optional_0.to_html(test_Formatting_format_body.str_1)

        test_case_0(value)



# Generated at 2022-06-25 18:56:12.774751
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting([])
    str_0 = 'Content-Type: application/json\r\n'
    str_1 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:56:19.361223
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format_headers_0 = Formatting(['colors'])
    str_0 = 'HTTP/1.1 200 OK\n\n'
    assert format_headers_0.format_headers(str_0) == str_0
    str_0 = 'HTTP/1.1 200 OK\n{%2B5}\n\n'
    assert format_headers_0.format_headers(str_0) == str_0


# Generated at 2022-06-25 18:56:28.506580
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['body']
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env_0)
    str_0 = 'Content-Type'
    str_1 = 'application/json'
    dict_0 = {str_0: str_1}
    str_2 = '{\n    "key": "value",\n    "2": 3.5\n}'
    dict_1 = {str_0: str_1}
    dict_2 = {str_0: str_1}
    str_3 = '{\n    "key": "value",\n    "2": 3.5\n}'
    dict_3 = {str_0: str_1}
    dict_4 = {str_0: str_1}
    

# Generated at 2022-06-25 18:56:34.194277
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups_0 = ['content_type_formatter', 'subtype_formatter']
    obj_0 = Formatting(groups_0)
    str_0 = 'application/json'
    obj_0.format_body('', str_0)


# Generated at 2022-06-25 18:56:36.110204
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = list(['colors', 'colors'])
    result = test_Formatting_environment(groups)


# Generated at 2022-06-25 18:56:40.815925
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    optional_1 = conversion_0.get_converter(str_0)
    print(optional_0.mime)
    print(optional_0.mime)
    assert optional_1 is optional_0



# Generated at 2022-06-25 18:56:43.917088
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:56:44.671101
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert True == True



# Generated at 2022-06-25 18:56:47.174318
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting()
    assert not hasattr(formatting_0, 'env')
    assert hasattr(formatting_0, 'enabled_plugins')


# Generated at 2022-06-25 18:56:49.903897
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups_0 = []
    formatting_0 = Formatting(groups_0)
    str_2 = ''
    str_1 = 'application/json'
    str_0 = formatting_0.format_body(str_1, str_2)


# Generated at 2022-06-25 18:56:53.092410
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test a case without arguments
    g = [""]
    case_0 = Formatting(g)
    case_1 = Formatting([""])

    # Test a case with both arguments
    g = [""]
    env = Environment()
    case_2 = Formatting(g, env)



# Generated at 2022-06-25 18:56:57.762099
# Unit test for constructor of class Formatting
def test_Formatting():
    environments_0 = Environment()
    formatting_0 = Formatting([], environments_0)
    ie_plugins_registry_0 = plugin_manager
    ie_plugins_registry_1 = plugin_manager
    formatting_1 = Formatting(['color'], environments_0, style='solarized')
    ie_plugins_registry_2 = plugin_manager

# Test check for enabled plugins

# Generated at 2022-06-25 18:57:05.608846
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = 'application/json'
    formatting_0 = Formatting(str_0)
    str_1 = 'mock'
    str_2 = 'mock'
    str_3 = 'mock'
    formatting_1 = Formatting(str_1, str_2, str_3)
    str_3 = 'mock'
    str_2 = 'mock'
    str_1 = 'mock'
    formatting_2 = Formatting(str_1, str_2, str_3)
    str_3 = 'mock'
    str_2 = 'mock'
    str_1 = 'mock'
    formatting_3 = Formatting(str_1, str_2, str_3)
    str_3 = 'mock'
    str_2 = 'mock'
    str

# Generated at 2022-06-25 18:57:13.981792
# Unit test for constructor of class Formatting
def test_Formatting():
    # A test to check the class Formatting works correctly
    test_instance = Formatting(groups=['colors'])
    assert isinstance(test_instance, Formatting)

# Generated at 2022-06-25 18:57:16.478932
# Unit test for constructor of class Formatting
def test_Formatting():
    # kwargs = {}
    # env = Environment.Environment()
    # groups = '*'
    # t = Formatting(groups, env, **kwargs)
    pass

# Generated at 2022-06-25 18:57:27.042727
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'application/json'
    str_1 = '{"a": 1}'
    formatting_0 = Formatting(['json'])
    str_2 = formatting_0.format_body(str_1, str_0)
    str_3 = '\x1b[94m{\x1b[39m\n\x1b[94m  \x1b[39m\x1b[92m"a"\x1b[39m\x1b[94m: \x1b[39m\x1b[91m1\x1b[39m\x1b[94m\n\x1b[39m\x1b[94m}\x1b[39m\n'
    assert str_2 == str_3

# Generated at 2022-06-25 18:57:29.646529
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins import registry
    registry.plugin_manager = registry.PluginManager()
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:57:34.803768
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test 0
    groups_0 = ['Colors']
    formatting_0 = Formatting(groups_0)

    str_0 = '{ "name": "John Doe" }'
    str_1 = 'application/json'
    str_2 = formatting_0.format_body(str_0, str_1)

    # Test 1
    groups_1 = ['Colors']
    formatting_1 = Formatting(groups_1)

    str_1 = 'foo'
    str_3 = 'application/json'
    str_4 = formatting_1.format_body(str_1, str_3)

    # Test 2
    groups_2 = ['colors']
    formatting_2 = Formatting(groups_2)

    str_5 = '{ "name": "John Doe" }'

# Generated at 2022-06-25 18:57:38.577654
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['text']
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env_0)


# Generated at 2022-06-25 18:57:45.752961
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test with dummy headers
    example_headers_0 = '''\
HTTP/1.1 301 Moved Permanently
Date: Wed, 25 May 2016 18:28:27 GMT
Transfer-Encoding: chunked
Server: nginx/1.4.6 (Ubuntu)
Location: http://httpbin.org/get
Connection: close
Vary: Accept
'''
    groups_0 = ['colors', 'format']
    formatting_0 = Formatting(groups_0)
    result_0 = formatting_0.format_headers(example_headers_0)
    print(result_0)
    

# Generated at 2022-06-25 18:57:53.199519
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = 'application/json'
    str_1 = 'application/xml'
    available_plugins = plugin_manager.get_formatters_grouped()
    groups = ['json', 'xml']
    formatting_0 = Formatting(groups)
    assert 'formatters' in formatting_0.__dict__, "Field 'formatters' is not present in object."
    headers = 'headers'
    str_2 = formatting_0.format_headers(headers)
    assert str_2 is not None, "format headers did not return an object"
    content = 'body'
    str_3 = formatting_0.format_body(content, str_1)
    assert str_3 is not None, "format body did not return an object"
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter

# Generated at 2022-06-25 18:57:55.483609
# Unit test for constructor of class Formatting
def test_Formatting():
    env_0 = Environment()
    groups_0 = ['json', 'colors']
    Formatting(groups_0, env_0)


# Generated at 2022-06-25 18:57:58.154111
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting([])
    str_0 = '{"json_prop": "json_val"}'
    str_1 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:58:06.890396
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmtr_0 = Formatting(list())
    str_0 = 'Content-Type: application/json\n'
    bool_0 = fmtr_0.format_headers(str_0) == 'Content-Type: application/json\n'
    assert bool_0


# Generated at 2022-06-25 18:58:08.351814
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    fmt_0 = Formatting(groups_0)


# Generated at 2022-06-25 18:58:13.993591
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting()
    str_0 = '''
HTTP/1.1 200 OK
Date: Sat, 22 Aug 2020 11:33:08 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 182
Connection: keep-alive
Server: gunicorn/19.9.0
Access-Control-Allow-Origin: *
Access-Control-Allow-Credentials: true
Vary: Origin

'''
    str_1 = formatting_0.format_headers(str_0)
    assert type(str_1) is str
    assert len(str_1) > 0


# Generated at 2022-06-25 18:58:19.489036
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()

    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert isinstance(optional_0, ConverterPlugin)

    str_1 = 'no/valid/mime'
    optional_1 = conversion_0.get_converter(str_1)
    assert not optional_1


# Generated at 2022-06-25 18:58:22.173098
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    str_1 = 'random/out'
    optional_1 = conversion_1.get_converter(str_1)


# Generated at 2022-06-25 18:58:23.863222
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['test_group_0']
    formatting = Formatting(groups_0)


# Generated at 2022-06-25 18:58:29.596098
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    str_1 = 'application/json'
    optional_1 = conversion_1.get_converter(str_1)
    bool_0 = optional_1.supports(str_1)
    optional_2 = conversion_1.get_converter(str_1)
    str_2 = 'test'
    optional_3 = conversion_1.get_converter(str_2)


# Generated at 2022-06-25 18:58:33.383010
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = None
    env = None
    kwargs = None
    formatting_0 = Formatting(groups, env, kwargs)
    str_0 = 'application/json'
    str_1 = ''
    formatter = formatting_0.format_body(str_0, str_1)
    str_2 = ''
    formatter_headers = formatting_0.format_headers(str_2)


# Generated at 2022-06-25 18:58:35.148690
# Unit test for constructor of class Formatting
def test_Formatting():
    test_1 = Formatting(['colors'])
    test_2 = Formatting(['colors'])


# Generated at 2022-06-25 18:58:44.525512
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'application/json'
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0.supports(str_0) == True
    assert len(optional_0.convert(str_0)) == 2
    conversion_1 = Conversion()
    str_1 = 'application/json'
    optional_1 = conversion_1.get_converter(str_1)
    assert optional_1.supports(str_1) == True
    assert len(optional_1.convert(str_1)) == 2


# Generated at 2022-06-25 18:59:05.136340
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test for case when content is empty and mime is empty
    formatting_0 = Formatting([])
    str_0 = ''
    str_1 = ''
    str_2 = formatting_0.format_body(str_0, str_1)
    # Test for case when content is valid and mime is valid
    formatting_1 = Formatting(['json', 'colors'])
    str_3 = '{"a": "b"}'
    str_4 = 'application/json'
    str_5 = formatting_1.format_body(str_3, str_4)
    # Test for case when content is valid and mime is empty
    formatting_2 = Formatting([])
    str_6 = '{"a": "b"}'
    str_7 = ''

# Generated at 2022-06-25 18:59:12.214517
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()

    conversion_0.get_converter('application/json')
    str_0 = 'application/json'
    str_1 = 'text/html'
    optional_0 = conversion_0.get_converter(str_1)
    assert optional_0 is None


# Generated at 2022-06-25 18:59:19.710448
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(list())
    str_0 = 'GET http://localhost:3000/ HTTP/1.1'
    str_1 = 'User-Agent: HTTPie/1.0.3'
    str_2 = 'Accept-Encoding: gzip, deflate'
    str_3 = 'Accept: */*'
    str_4 = 'Host: localhost:3000'
    str_5 = 'Connection: keep-alive'
    str_6 = 'Content-Type: application/json'
    str_7 = 'Content-Length: 23'
    list_0 = [
      str_0,
      str_1,
      str_2,
      str_3,
      str_4,
      str_5,
      str_6,
      str_7
    ]

# Generated at 2022-06-25 18:59:23.810734
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = []
    env = Environment()
    kwargs = {}
    formatting_0 = Formatting(groups, env, **kwargs)
    optional_0 = '{a}:{b}\r\n'
    headers = optional_0.format(a='Transfer-Encoding',b='chunked')
    formatting_0.format_headers(headers)


# Generated at 2022-06-25 18:59:31.626795
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups=['headers']
    f = Formatting(groups, env=Environment(
            stdin_isatty=False,
            stdout_isatty=False,
            colors=255,
            styles=128,
            print_options=256
        ))
    headers="""HTTP/1.1 200 OK
Content-Length: 38
Content-Type: application/json
Date: Wed, 19 Aug 2020 23:27:08 GMT
Server: Werkzeug/1.0.1 Python/3.8.3

{"hello": "world", "number": 1}
"""
    ret = f.format_headers(headers)
    assert headers == ret
