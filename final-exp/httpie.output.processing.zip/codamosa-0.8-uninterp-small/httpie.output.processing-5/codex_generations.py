

# Generated at 2022-06-25 18:49:28.054133
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting = Formatting([], Environment())



# Generated at 2022-06-25 18:49:32.163616
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_1 = Conversion.get_converter("application/json")
    assert converter_1.supports("application/json")
    converter_2 = Conversion.get_converter("application/any")
    assert converter_2 is None


# Generated at 2022-06-25 18:49:42.693325
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test with no conversion
    formatter = Formatting(['default'])
    assert formatter.format_body("this is a test", "application/json") == "this is a test"
    assert formatter.format_body("this is a test", "text/plain") == "this is a test"
    assert formatter.format_body("this is a test", "text/html") == "this is a test"
    assert formatter.format_body("this is a test", "text/xml") == "this is a test"

    # Test with converting JSON
    formatter = Formatting(['json'])

# Generated at 2022-06-25 18:49:48.519579
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    mime_0 = 'text/html'
    assert conversion_0.get_converter(mime_0) != None
    mime_1 = 'text/html; charset=utf-8'
    assert conversion_0.get_converter(mime_1) != None
    mime_2 = 'text/plain'
    assert conversion_0.get_converter(mime_2) != None


# Generated at 2022-06-25 18:49:55.647291
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # create an instance of class Formatting
    formatting_0 = Formatting(groups = ['colors'])
    # create a sample input
    input = """{"glossary": {"title": "example glossary","GlossDiv": {"title": "S","GlossList": {"GlossEntry": {"ID": "SGML","SortAs": "SGML","GlossTerm": "Standard Generalized Markup Language","Acronym": "SGML","Abbrev": "ISO 8879:1986","GlossDef": {"para": "A meta-markup language, used to create markup languages such as DocBook.","ID": "44","str": "SGML","GlossSeeAlso": ["GML", "XML"]},"GlossSee": "markup"}]}}}"""
    # unit test

# Generated at 2022-06-25 18:49:58.015341
# Unit test for constructor of class Formatting
def test_Formatting():

    formating_0 = Formatting(groups=['group1', 'group2'])
    assert formating_0.enabled_plugins


# Generated at 2022-06-25 18:49:59.270777
# Unit test for constructor of class Formatting
def test_Formatting():
    test = Formatting(groups=None)


# Generated at 2022-06-25 18:50:07.703773
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print("\n### Unit test for Conversion.get_converter()")
    print("### Case 1: mime = 'text/plain'")
    assert isinstance(Conversion.get_converter(mime='text/plain'), ConverterPlugin)

    print("### Case 2: mime = 'application/json'")
    assert isinstance(Conversion.get_converter(mime='application/json'), ConverterPlugin)

    print("### Case 3: mime = ''")
    assert Conversion.get_converter(mime='') is None

    print("### Case 4: mime = 'invalid_mime_string'")
    assert Conversion.get_converter(mime='invalid_mime_string') is None


# Generated at 2022-06-25 18:50:09.812809
# Unit test for constructor of class Formatting
def test_Formatting():
  formatting_0 = Formatting(["colors"])
  assert isinstance(formatting_0, Formatting)


# Generated at 2022-06-25 18:50:11.946503
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting('json', auto_json=False, pretty=True, color=True)
    formatting_0.format_headers('')


# Generated at 2022-06-25 18:50:14.821867
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pass


# Generated at 2022-06-25 18:50:15.586923
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['body'])


# Generated at 2022-06-25 18:50:16.490171
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    obj = Formatting()
    assert obj.format_headers


# Generated at 2022-06-25 18:50:18.314630
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("") == None
    assert Conversion.get_converter("abc") == None



# Generated at 2022-06-25 18:50:20.958322
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    converter_0 = conversion_1.get_converter("text/html")
    if converter_0 is not None:
        assert converter_0.supports("text/html")
    else:
        assert True


# Generated at 2022-06-25 18:50:30.151459
# Unit test for constructor of class Formatting
def test_Formatting():
    class env:
        def __init__(self):
            self.colors = False
            self.config = None
    class p:
        def __init__(self, env=env(), style="foo"):
            self.env = env
            self.style = style
            self.enabled = True
            self.format_headers = "fh"
            self.format_body = "fb"
    formatting_0 = Formatting(groups = ["foo"], env=env())
    assert (formatting_0.enabled_plugins == [p(env=env(), style="foo")])
    assert (formatting_0.enabled_plugins[0].style == "foo")


# Generated at 2022-06-25 18:50:41.336821
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """
    Unit test for method format_headers of class Formatting.

    """
    formatters = Formatting(['colors'])

# Generated at 2022-06-25 18:50:46.303300
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Create a Formatting object
    e = Environment()
    f = Formatting(['color'], env=e)
    # Test format_headers
    assert f.format_headers("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n") == "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n"



# Generated at 2022-06-25 18:50:56.063202
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting([])
    assert formatting_0.format_headers("", "") == ""
    assert formatting_0.format_headers("", "", "") == ""

    env = Environment()
    env.colors = 0
    formatting_1 = Formatting([], env=env)
    assert formatting_1.format_headers("", "") == ""
    assert formatting_1.format_headers("", "", "") == ""

    formatting_2 = Formatting([], env=env, **{})
    assert formatting_2.format_headers("", "") == ""
    assert formatting_2.format_headers("", "", "") == ""


# Generated at 2022-06-25 18:50:57.540002
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting(["colors"])


# Generated at 2022-06-25 18:51:02.656333
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert callable(Conversion.get_converter)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 18:51:06.223405
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    ansi_0 = 'ms4^4PA'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(ansi_0)
    formatting_0 = Formatting()
    formatting_0.format_headers(optional_0)


# Generated at 2022-06-25 18:51:13.384349
# Unit test for constructor of class Formatting

# Generated at 2022-06-25 18:51:14.276623
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_case_0()


# Generated at 2022-06-25 18:51:21.275505
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = 'YwCnN}Z'
    list_0 = ['YwCnN}Z']
    formatting_0 = Formatting(list_0)
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    if optional_0:
        optional_0.convert(str_0)

if __name__ == '__main__':
    # Test Case 0
    test_case_0()

    # Test Formatting constructor
    test_Formatting()

# Generated at 2022-06-25 18:51:28.115398
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'application1'
    str_1 = 'application2'
    str_2 = 'application3'
    list_0 = [str_0, str_1, str_2]
    argument_0 = Formatting(list_0)
    str_3 = 'media type2'
    str_4 = 'media type1'
    str_5 = 'media type3'
    assert str_4 == argument_0.format_body(str_3, str_4)


# Generated at 2022-06-25 18:51:30.374836
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_1 = None
    conversion_1 = Conversion()
    optional_1 = conversion_1.get_converter(str_1)
    assert optional_1 is None

# Generated at 2022-06-25 18:51:35.326448
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    selected_groups = ['colors']
    formatting_obj = Formatting(selected_groups)
    str_0 = 'h1'
    str_1 = 'h2'
    headers_str = '{}:{}\r\n'.format(str_0, str_1)
    formatted_str = formatting_obj.format_headers(headers_str)
    str_2 = 'b'
    str_3 = 'g'
    assert_1 = str_2 in formatted_str
    assert_2 = str_3 in formatted_str
    assert assert_1
    assert assert_2


# Generated at 2022-06-25 18:51:45.050982
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'Tk'
    list_0 = ['c']
    env_0 = Environment()
    formatting_0 = Formatting(list_0, env_0)

# Generated at 2022-06-25 18:51:46.825985
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['Json']
    env = Environment()
    kwargs = {}
    test_0 = Formatting(groups, env, **kwargs)

# Generated at 2022-06-25 18:51:54.568913
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    data = 'z{D_"N'
    conversion = Conversion()
    optional = conversion.get_converter(data)
    if optional:
        optional.convert('mfh~y' if (__name__ == '__main__') else 'jVd]zq', '7Y;,\\{}')


# Generated at 2022-06-25 18:52:04.529748
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = 'Zm9vOmJhcg=='
    byte_0 = bytes(str_0, encoding='utf-8')
    str_1 = 'YmFy'
    list_0 = [str_1, str_1]
    str_2 = 'YmFy'
    str_3 = 'YmFy'
    list_1 = [str_3, str_2]
    str_4 = 'YmFy'
    str_5 = 'YmFy'
    list_2 = [str_5, str_4]
    str_6 = 'YmFy'
    str_7 = 'YmFy'
    list_3 = [str_7, str_6]
    str_8 = 'YmFy'

# Generated at 2022-06-25 18:52:06.957027
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["headers"]
    env = Environment()
    kwargs = [("data", "Test")]
    fmt = Formatting(groups, env, **kwargs)

# Generated at 2022-06-25 18:52:14.459953
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'YwCnN}Z'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    str_1 = 'G@z.~8i'
    conversion_1 = Conversion()
    optional_1 = conversion_1.get_converter(str_1)
    groups_0 = [4]
    formatting_0 = Formatting(groups_0)
    str_2 = '%g/<'
    formatting_0.format_headers(str_2)


# Generated at 2022-06-25 18:52:19.965338
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'YwCnN}Z'
    str_1 = 'Z.,V/w4'
    str_2 = 'PyRb_!}'
    str_3 = 'F3qNR1B'
    formatting_0 = Formatting([str_0, str_1], Environment(colors=True))
    formatting_1 = Formatting([str_2, str_3], Environment(colors=True))
    assert formatting_0.format_headers("text") == "text"
    assert formatting_1.format_headers("text") == "text"


# Generated at 2022-06-25 18:52:22.495383
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting_0 = Formatting(['colors'])
    str_0 = 'YwCnN}Z'
    str_1 = formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:52:33.714296
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups_0 = [
        'a',
        'b',
        'c',
        'd',
        'e',
        'f',
        'g',
        'h',
    ]

# Generated at 2022-06-25 18:52:35.794278
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    #
    #
    str_0 = 'YwCnN}Z'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:52:45.252067
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    t_0 = Formatting(["auto", "colors"], {u'colors': True})
    int_0 = t_0.format_body('jumps over the lazy')
    assert int_0 == 'jumps over the lazy'
    format_body_env_1 = Formatting(["auto", "colors"], {u'colors': True})
    format_body_env_2 = Formatting(["auto", "colors"], {u'colors': True})
    int_1 = format_body_env_1.format_body('jumps over the lazy')
    int_2 = format_body_env_2.format_body('jumps over the lazy')
    assert int_1 == int_2
    format_body_env_3 = Formatting(["auto", "colors"], {u'colors': True})

# Generated at 2022-06-25 18:52:46.234568
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert ConverterPlugin is not None


# Generated at 2022-06-25 18:52:54.368059
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'YwCnN}Z'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    formatting_0 = Formatting([optional_0])
    formatting_0.format_headers()


# Generated at 2022-06-25 18:52:56.496536
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '9//+'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:52:58.584443
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '=ljKtJp'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)

# Generated at 2022-06-25 18:53:02.973803
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'M7-.ksewWb'
    conversion_0 = Conversion()
    conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:53:10.331132
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'cPjKxQ/36?R\x00,\x00\x00'
    str_1 = 'X9{$k5Gx'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    str_2 = 'application/xml'
    fmt_0 = Formatting(['colors'], True, optional_0, str_1, str_0)
    str_3 = fmt_0.format_body(str_2, str_1)



# Generated at 2022-06-25 18:53:15.876749
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    arg_1 = '{"a": "b"}'
    arg_2 = 'application/json'

    # Create the class
    obj_0 = Formatting()

    # Invoke method
    ret_0 = obj_0.format_body(arg_1, arg_2)


# Generated at 2022-06-25 18:53:19.126470
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_1 = 'application'
    conversion_1 = Conversion()
    optional_1 = conversion_1.get_converter(str_1)
    assert optional_1 == 0


# Generated at 2022-06-25 18:53:21.612788
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'y1<T6'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:53:27.806002
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_1 = 'HnIu[7{oGp'
    formatting_0 = Formatting(str_1)
    str_2 = 'f6G.<U'
    str_3 = '9Pj`&'
    str_4 = 'kf.'
    assert str_4 == formatting_0.format_headers(str_2)


# Generated at 2022-06-25 18:53:32.227362
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    environment_0 = Environment()
    str_0 = 'ybt:'
    formatting_0 = Formatting(str_0, environment=environment_0)
    str_1 = 'QJO\r\u0007\r\u0005>|Vf\u0005D\t\f!G'
    assert (formatting_0.format_headers(str_1) is not None)


# Generated at 2022-06-25 18:53:45.844021
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'YwCnN}Z'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    array_0 = ['foo', 'bar']
    formatting_0 = Formatting(array_0)
    optional_1 = formatting_0.format_headers(str_0)
    int_0 = optional_0.hashCode()
    int_1 = formatting_0.hashCode()


# Generated at 2022-06-25 18:53:48.936391
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print("\x1b[32m# 1/1\x1b[0m")
    print(" \x1b[32m✔\x1b[0m Test case 1 (Conversion_get_converter)")

# Generated at 2022-06-25 18:53:52.382090
# Unit test for constructor of class Formatting
def test_Formatting():
    config = Environment()
    config.colors = None
    formatting_0 = Formatting(['Format'], env=config)
    str_0 = Formatting.__init__(['Format'], config, colors='off')
    str_1 = Formatting.__init__(['Format'], config, colors=None)


# Generated at 2022-06-25 18:53:58.983967
# Unit test for constructor of class Formatting
def test_Formatting():
    str_1 = 'YwCnN}Z'
    var_0 = ['text']
    var_1 = Environment()
    formatting = Formatting(var_0, var_1)
    str_2 = 'YwCnN}Z'
    str_3 = formatting.format_body(str_2, str_1)

test_Formatting()

# Generated at 2022-06-25 18:54:00.801455
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'OdO)y'
    conversion_0 = None
    optional_0 = conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:54:05.170208
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    #for group in groups:
    for cls in available_plugins['json']:
        p = cls(env=Environment())
        if p.enabled:
            enabled_plugins.append(p)
    content = '[]'
    mime = 'application/json'
    formatting_1 = Formatting(['json'])
    actual_output = formatting_1.format_body(content, mime)
    expected_output = ''
    assert actual_output == expected_output

# Generated at 2022-06-25 18:54:07.658176
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = '7Vu1}RS'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:54:13.683255
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['ascii_0', 'cli_0', 'colors_0', 'download_0', 'formatters_0', 'json_0', 'table_0', 'theme_0']
    env_0 = Environment()
    kwargs_0 = {}
    formatting_0 = Formatting(groups_0, env=env_0, **kwargs_0)
    str_0 = 'text/plain'
    formatting_0.format_body(str_0)
    str_1 = 'Date: Sat, 27 Mar 2021 10:08:27 GMT'
    formatting_0.format_headers(str_1)


# Generated at 2022-06-25 18:54:16.209254
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print("Test Case 0")
    str_0 = 'YwCnN}Z'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:54:27.014382
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_dict = {}
    conversion_0 = Conversion()
    str_0 = 'Pz9Jb_NI'
    test_dict.update({'callee': 'CQP_Y.+M'})
    conversion_1 = Conversion()
    test_dict.update({'callee': '5A(2QD-^'})
    conversion_2 = Conversion()
    test_dict.update({'callee': '%$wI8W] '})
    conversion_3 = Conversion()
    test_dict.update({'callee': '=h^.@H&}'})
    conversion_4 = Conversion()
    test_dict.update({'callee': 'n1|<*>Z$'})
    conversion_5 = Conversion()

# Generated at 2022-06-25 18:54:45.610431
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'application/json'
    str_1 = '{ "foo": "bar" }'
    list_0 = ['foo', 'bar']
    formatting_0 = Formatting(list_0)
    str_2 = formatting_0.format_body(str_1, str_0)


# Generated at 2022-06-25 18:54:49.332356
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0: List[str] = ["formatted", "JSON", "JSONPretty", "formatted", "JSONPretty", "JSONPretty"]
    formatting_0 = Formatting(groups_0)
    assert isinstance(formatting_0, Formatting)


# Generated at 2022-06-25 18:54:51.852129
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'YwCnN}Z'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0._mime == None


# Generated at 2022-06-25 18:54:58.305141
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'YwCnN}Z'
    str_1 = 'YwCnN}Z'
    str_2 = 'YwCnN}Z'
    formatting_0 = Formatting([str_0, str_1], str_2)
    str_3 = 'YwCnN}Z'
    str_4 = 'YwCnN}Z'
    formatting_0.format_body(str_3, str_4)


# Generated at 2022-06-25 18:54:59.855156
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    pytest_case_0()
    pytest_case_1()


# Generated at 2022-06-25 18:55:07.614300
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'YwCnN}Z'
    str_1 = 'x0f;7h'
    list_0 = ['1c5NJ/', 'XRiGB~', 'YpNkI8']
    formatting_0 = Formatting(list_0)
    external_0 = formatting_0.format_headers(str_0)
    # external_1 should equal to str_1
    external_1 = formatting_0.format_headers(external_0)
    if str_1 == external_1:
        return True
    else:
        return False


# Generated at 2022-06-25 18:55:15.785115
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test 0
    str_0 = 'YwCnN}Z'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    # Test 1
    str_0 = 'i{'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    # Test 2
    str_0 = 'G``'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    # Test 3
    str_0 = 'Z'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    # Test 4
    str_0 = 'G]XH'

# Generated at 2022-06-25 18:55:26.834947
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '<'
    str_1 = 'D'
    str_2 = 'Tu'
    set_0 = set()
    str_3 = 'Et[F'
    str_4 = '_'
    str_5 = 'O'
    str_6 = 'bd3'
    str_7 = 'f'
    str_8 = 'kjGc'
    list_0 = ['b', 'W', '_']
    set_1 = set()
    str_9 = 'I'
    str_10 = '|'
    str_11 = '1'
    str_12 = 'B'
    list_1 = ['o', '5', '^']
    list_2 = ['j', 'x', '&']
    str_13 = 'P'

# Generated at 2022-06-25 18:55:31.380695
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env_0)
    conversion_0 = Conversion()
    str_0 = 'YwCnN}Z'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:55:33.020876
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env_0)

# Generated at 2022-06-25 18:56:06.053779
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = [b'i\x90\x85', b"\x03\xf8\xd9\x1d", b'\x0a1O\x1f']
    formatting_0 = Formatting(groups)


# Generated at 2022-06-25 18:56:08.907686
# Unit test for constructor of class Formatting
def test_Formatting():
    # Default arguments for test
    groups = list()
    kwargs = dict()
    env = Environment()

    # Local variables for test
    var_groups = groups

    # Execution of constructor
    formatting = Formatting(var_groups, env, **kwargs)


# Generated at 2022-06-25 18:56:12.810016
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'i.wA'
    list_0 = []
    list_1 = ['i.wA', 'L', 'I', 'b', 'tR{']
    formatting_0 = Formatting(groups=list_0)
    str_1 = formatting_0.format_headers(headers=str_0)
    assert (str_0 == str_1)
    formatting_1 = Formatting(groups=list_1)
    formatting_1.format_headers(str_0)
    assert (str_1 == str_0)


# Generated at 2022-06-25 18:56:20.361137
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = 'YwCnN}Z'
    list_of_str_0 = ['XvZMIT`fN', 'OoCnpQYy']
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    formatting_0 = Formatting(list_of_str_0)
    formatting_0.format_body(optional_0.to_unicode(), str_0)
    formatting_0.format_headers(optional_0.to_unicode())

# Generated at 2022-06-25 18:56:21.962504
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert False, "Missing test"


# Generated at 2022-06-25 18:56:24.975597
# Unit test for constructor of class Formatting
def test_Formatting():
    groups: List[str] = ['test']
    formatting_0 = Formatting(groups)
    #The test case below is to check the value of variable formatting_0.enabled_plugins.
    assert formatting_0.enabled_plugins == []

# Generated at 2022-06-25 18:56:26.620644
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'YwCnN}Z'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:56:35.897731
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '7?s='
    str_1 = '*2_T'
    str_2 = '^[7'
    str_3 = 'Ar+%'
    str_4 = '.'
    str_5 = 'W8z"'
    str_6 = 'B~l<'
    str_7 = '+'
    str_8 = '.U6)'
    str_9 = 'a5O5'
    str_10 = '#'
    str_11 = ')z)'
    str_12 = 'l%^<'
    str_13 = ':'
    str_14 = '</U('
    str_15 = ',"@}'
    str_16 = '{p'
    str_17 = 'X+S'
    str_18 = 'nkQ2'

# Generated at 2022-06-25 18:56:38.352153
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = '^MPeg[$}g'
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:56:40.815945
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion = Conversion()
    assert_equals(conversion.get_converter('YwCnN}Z'),
                  optional_t(ConverterPlugin))


# Generated at 2022-06-25 18:57:47.261975
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'r/r'
    assert is_valid_mime(str_0)
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:57:51.438919
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'YwCnN}Z'
    conversion_0 = Conversion()
    available_plugins_0 = plugin_manager.get_formatters_grouped()
    formatting_0 = Formatting(available_plugins_0)
    str_1 = formatting_0.format_headers(str_0)
    assert str_1 == 'YwCnN}Z'


# Generated at 2022-06-25 18:57:52.417657
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert_equal(test_case_0(), None)

# Generated at 2022-06-25 18:57:57.813957
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_0 = Formatting(['colors'])
    str_0 = 'G{H}q='
    str_1 = 'AAAA'
    optional_0 = formatting_0.format_body(str_1, str_0)
    optional_1 = formatting_0.format_body(str_1, str_0)
    optional_2 = formatting_0.format_body(str_1, str_0)


# Generated at 2022-06-25 18:58:03.931790
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    conversion_1 = Conversion()
    str_0 = 'YwCnN}Z'
    optional_0 = conversion_0.get_converter(str_0)
    str_1 = 'YwCnN}Z'
    optional_1 = conversion_1.get_converter(str_1)
    assert optional_0 is None
    assert optional_1 is None


# Generated at 2022-06-25 18:58:11.422359
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0, str_1, str_2 = 'X#', '', 'B'
    groups = [str_0]
    env_0 = Environment()
    formatting_0 = Formatting(groups, env=env_0)
    optional_0 = formatting_0.format_headers(str_1)
    assert optional_0 == str_1
    groups = [str_1, str_2]
    env_1 = Environment()
    formatting_1 = Formatting(groups, env=env_1)
    optional_1 = formatting_1.format_headers(str_2)
    assert optional_1 == str_2
    # Replace this call with your implementation
    raise NotImplementedError()


# Generated at 2022-06-25 18:58:13.425799
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'YwCnN}Z'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:58:18.830806
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'YwCnN}Z'
    str_1 = 'YwCnN}Z'
    str_2 = 'text/html'
    str_3 = 'text/html'
    formatting_0 = Formatting([str_0, str_1], mime=str_2, pretty=str_2)
    string_0 = formatting_0.format_headers(str_3)


# Generated at 2022-06-25 18:58:29.003304
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'application/json'
    str_1 = ''
    # Test case 0
    str_2 = Formatting(str_0, str_1).format_headers(str_0)
    # Test case 1
    str_3 = Formatting(str_0, str_1).format_headers(str_0)
    # Test case 2
    str_4 = Formatting(str_0, str_1).format_headers(str_0)
    # Test case 3
    str_5 = Formatting(str_0, str_1).format_headers(str_0)
    # Test case 4
    str_6 = Formatting(str_0, str_1).format_headers(str_0)
    # Test case 5

# Generated at 2022-06-25 18:58:30.617841
# Unit test for constructor of class Formatting
def test_Formatting():

    # 1. Arguments with default values
    format_1 = Formatting([])
