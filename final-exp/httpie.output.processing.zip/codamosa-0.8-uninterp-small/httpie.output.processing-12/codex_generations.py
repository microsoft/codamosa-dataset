

# Generated at 2022-06-25 18:49:28.472816
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        test_case_0()
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 18:49:40.003289
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = '\n]~/P>\\,*~%|lr|U'
    conversion_0 = Conversion()
    available_plugins_0 = plugin_manager.get_formatters_grouped()
    enabled_plugins_0 = []
    for group in str_0:
        for cls in available_plugins_0[group]:
            p = cls()
            if p.enabled:
                enabled_plugins_0.append(p)
    conversion_1 = Conversion()
    available_plugins_1 = plugin_manager.get_formatters_grouped()
    enabled_plugins_1 = []
    for group in str_0:
        for cls in available_plugins_1[group]:
            p = cls()
            if p.enabled:
                enabled_plugins_1.append(p)
    conversion_

# Generated at 2022-06-25 18:49:41.346353
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting([], Environment(), False, False)


# Generated at 2022-06-25 18:49:44.219993
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '\n]~/P>\\,*~%|lr|U'
    conversion_0 = Conversion()
    conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:49:53.112713
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = '\n]~/P>\\,*~%|lr|U'
    list_1: List[str] = ['\n]~/P>\\,*~%|lr|U', '\n]~/P>\\,*~%|lr|U']
    str_1 = '\n]~/P>\\,*~%|lr|U'
    str_2 = '\n]~/P>\\,*~%|lr|U'
    def test_case_0():
        print('\n]~/P>\\,*~%|lr|U')

# Generated at 2022-06-25 18:49:56.682933
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    class_0 = conversion_0.get_converter('*/*')
    assert class_0.mime == '*/*'


# Generated at 2022-06-25 18:50:01.496645
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    fmt = Formatting('body', None, file_name='file_name')
    assert fmt.enabled_plugins == []
    fmt = Formatting('body,colors', None, file_name='file_name')
    assert fmt.enabled_plugins == available_plugins['body'] + available_plugins['colors']


# Generated at 2022-06-25 18:50:05.943622
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Input parameters
    content_0 = 'g0}`_KBdm?m(Q<'
    mime_0 = 'wH+1c'
    # Output parameters
    output_0 = 'ir<~Y2'

    formatting_0 = Formatting()
    output_0 = formatting_0.format_body(content_0, mime_0)



# Generated at 2022-06-25 18:50:14.429303
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-25 18:50:19.059190
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '\n]~/P>\\,*~%|lr|U'
    conversion_0 = Conversion()

    assert conversion_0.get_converter('application/json')
    assert conversion_0.get_converter('message/http')
    assert conversion_0.get_converter('text/html')
    assert conversion_0.get_converter('application/javascript')
    assert conversion_0.get_converter('application/xml')
    assert conversion_0.get_converter('text/html')


# Generated at 2022-06-25 18:50:32.526313
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case
    test_cases = [
        "text/json",
        "text/html",
        "audio/mp3",
        "image/jpg",
        "video/mp4",
        "application/xml",
        "application/json",
        "application/xhtml+xml",
        "application/zip",
        "application/foo",
        "text/",
        "text",
        "foo/bar"
    ]

    # Expected result
    expected_result_0 = {
        "text/json": "application/json"
    }
    expected_result_1 = {
        "text/html": "text/html"
    }
    expected_result_2 = {
        "audio/mp3": "audio/mp3"
    }

# Generated at 2022-06-25 18:50:35.409598
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors', 'syntax-highlight']
    formatter = Formatting(groups, env).__init__()

# Generated at 2022-06-25 18:50:44.071418
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter('application/json')
    assert c is not None
    c = Conversion.get_converter('text/html')
    assert c is not None
    c = Conversion.get_converter('application/xml')
    assert c is not None
    c = Conversion.get_converter('application/graphql')
    assert c is not None
    c = Conversion.get_converter('text/plain')
    assert c is not None
    c = Conversion.get_converter('')
    assert c is None
    c = Conversion.get_converter(None)
    assert c is None


# Generated at 2022-06-25 18:50:50.598184
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    conversion_0 = Conversion()

# Generated at 2022-06-25 18:50:54.263775
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    # The following test is currently causing a crash
    # conversion_0.get_converter(None)
    # do_test_line()


# Generated at 2022-06-25 18:50:57.409125
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    empty_headers = ''
    formatting = Formatting(['color'])
    formatted_headers = formatting.format_headers(empty_headers)
    assert formatted_headers == empty_headers


# Generated at 2022-06-25 18:51:07.523048
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    body = '{"value": "test"}'
    mime = 'application/json'

    formatting_0 = Formatting(groups=['colors'])
    formatting_0.format_body(body, mime)

    formatting_1 = Formatting(groups=['colors', 'syntax'])
    formatting_1.format_body(body, mime)

    formatting_2 = Formatting(groups=['colors', 'syntax'], color=False)
    formatting_2.format_body(body, mime)

    formatting_3 = Formatting(groups=['colors', 'syntax'], syntax=False)
    formatting_3.format_body(body, mime)

    formatting_4 = Formatting(groups=['colors', 'syntax'], color=False, syntax=False)

# Generated at 2022-06-25 18:51:13.929111
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    formatting_0 = Formatting(env=env, groups=['colors'])
    assert formatting_0.format_headers('rel="nofollow"') == 'rel="nofollow"'
    formatting_1 = Formatting(env=env, groups=['colors'])
    assert formatting_1.format_headers('HTTP/1.1 200 OK') == 'HTTP/1.1 200 OK'
    try:
        formatting_2 = Formatting(env=env, groups=['colors'])
        assert formatting_2.format_headers(None) == '\x1b[34;1mHTTP/1.1 200 OK'
    except ValueError:
        pass
    formatting_3 = Formatting(env=env, groups=['colors'])

# Generated at 2022-06-25 18:51:24.240317
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    converter = conversion_0.get_converter("application/json")
    assert converter.__class__.__name__ == "JSONConverter"
    converter = conversion_0.get_converter("application/xml")
    assert converter.__class__.__name__ == "XMLConverter"
    converter = conversion_0.get_converter("application/msgpack")
    assert converter.__class__.__name__ == "MsgPackConverter"
    converter = conversion_0.get_converter("application/yaml")
    assert converter.__class__.__name__ == "YAMLConverter"
    converter = conversion_0.get_converter("application/html")
    assert converter.__class__.__name__ == "HTMLConverter"


# Generated at 2022-06-25 18:51:28.405874
# Unit test for constructor of class Formatting
def test_Formatting():
    formatter_0 = Formatting.get_converter(0)
    formatter_1 = Formatting.get_converter(1)
    formatter_2 = Formatting.get_converter(2)
    formatter_3 = Formatting.get_converter(3)


# Generated at 2022-06-25 18:51:34.092283
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("text/plain"), ConverterPlugin)
    assert not Conversion.get_converter("Wrong Media type")

# Generated at 2022-06-25 18:51:36.149985
# Unit test for constructor of class Formatting
def test_Formatting():
    with pytest.raises(ValueError):
        Formatting(["invalid_group"])



# Generated at 2022-06-25 18:51:37.359247
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    pass


# Generated at 2022-06-25 18:51:40.134624
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_1 = Conversion()
    result_1 = Conversion.get_converter("application/json")
    assert result_1 is not None # Add your test, test_case_0()


# Generated at 2022-06-25 18:51:44.655826
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    # Case 1: headers is empty
    # Expected result: return empty string
    headers = ''
    groups = ['color']
    expected = ''

    fmt = Formatting(groups)
    actual = fmt.format_headers(headers)
    assert actual == expected

    # Case 2: headers is normal
    # Expected result: return formatted string

# Generated at 2022-06-25 18:51:46.436333
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["HTTP10"]
    env = Environment()
    testing_formatting = Formatting(groups, env)


# Generated at 2022-06-25 18:51:50.792746
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    formatting_0 = Formatting(['colors'], env)
    str_arg_0 = formatting_0.format_headers('Content-Type: text/plain')
    str_arg_1 = formatting_0.format_headers('Content-Type: text/plain')
    assert str_arg_0 == str_arg_1


# Generated at 2022-06-25 18:51:58.944735
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    config_0 = {
        'colors': {
            'body': 'white',
            'header': 'white',
            'header.bg': 'blue',
            'header.fg': 'green',
            'httpie': 'white',
            'httpie.bg': 'blue',
            'httpie.fg': 'green',
            'scheme': 'blue',
            'status': 'red'
        }
    }

# Generated at 2022-06-25 18:52:07.107081
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    output_1 = "HTTP/1.1 200 OK\r\n"
    output_2 = "Content-Type: application/json"
    conversion_1 = Conversion()
    formatting_1 = Formatting("HTTPie", groups=["highlight"], pygments=False)
    result_1 = formatting_1.format_headers(output_1)
    print("Result of method format_headers of class Formatting : ",result_1)
    result_2 = formatting_1.format_headers(output_2)
    print("Result of method format_headers of class Formatting : ",result_2)


# Generated at 2022-06-25 18:52:10.711585
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['Python Monokai']

    formatting_0 = Formatting(groups)

    content = '{"message": "Hello World."}'
    mime = 'application/json'

    formatting_0.format_body(content, mime)


# Generated at 2022-06-25 18:52:20.047954
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'F\x06"m\x1a^\x13\x1c'
    str_1 = '_\x0c\'\x18\x1d\x03\x07\r'
    list_0 = [str_0, str_1]
    formatting_0 = Formatting(*list_0)
    str_2 = '10\x97\x1b\x7f\x1d\x0e'
    str_3 = '\x0b\x07<\x1a\x00\x14'
    str_4 = formatting_0.format_body(str_2, str_3)
    assert str_4 == '', 'Expected empty string, got ' + str_4


# Generated at 2022-06-25 18:52:30.791704
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '\t{S)O]Y/'
    str_1 = '\t{S)O]Y/'
    list_0 = []
    formatting_0 = Formatting(*list_0, str_0)
    str_2 = formatting_0.format_headers(str_1)
    str_3 = formatting_0.format_headers(str_2)
    str_4 = formatting_0.format_headers(str_3)
    str_5 = formatting_0.format_headers(str_4)
    str_6 = formatting_0.format_headers(str_5)
    str_7 = formatting_0.format_headers(str_6)
    str_8 = formatting_0.format_headers(str_7)

# Generated at 2022-06-25 18:52:39.153033
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '\t\t\t\t\t\t\t\t\t\t'
    format_headers_0 = Formatting(str_0)
    str_1 = '"v#7\x1c\u0015\x1bII\x1a"'
    int_0 = format_headers_0.format_headers(str_1)
    assert int_0 == 1
    str_2 = '1\x1a\u0016\x12\x19\u001a\x10'
    format_headers_1 = Formatting(str_2)
    str_3 = '\x12l\x10\x15\u0003\x1c\u001f'
    int_1 = format_headers_0.format_headers(str_3)
    assert int_

# Generated at 2022-06-25 18:52:48.605084
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = "$'g3e~%\u0014W\u001c"
    list_0 = []
    formatting_0 = Formatting(list_0, str_0)
    str_1 = "'\u0003g[0\u001f"
    formatting_0.format_headers(str_1)
    str_2 = '!\u0007$\u0004\u0017'
    str_3 = '\u0012\u0015\u0005\u0014\u0016\u0014'
    str_4 = '\u0010\u0017\u0016\u000e\u0012\u0017\u0013\u0013\u0014'
    formatting_0.format_body(str_2, str_3, str_4)


# Generated at 2022-06-25 18:52:56.493469
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    groups = ['pretty']
    str_0 = '\n]~/P>\\,*~%|lr|U'
    env = Environment()
    env.stdout = StringIO()
    f = Formatting(groups, env)
    f.format_headers(str_0)
    f.format_body(str_0, 'application/json')
    assert env.stdout.getvalue() == ''



if __name__ == '__main__':
    test_case_0()
    test_Conversion_get_converter()

# Generated at 2022-06-25 18:52:59.651451
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '\n]~/P>\\,*~%|lr|U'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(str_0)

    assert optional_0 is None


# Generated at 2022-06-25 18:53:06.126034
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    args_list = [
        ['application/json;charset=utf-8'],
        ['application/json'],
        ['application/x-www-form-urlencoded'],
        ['application/xml'],
        ['text/html']
    ]
    for arg in args_list:
        test_case_0(*arg)
    return True



# Generated at 2022-06-25 18:53:09.339929
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Create instances
    groups_0 = ['verbose']
    #env_0 = Environment()
    kwargs_0 = {}
    formatting_0 = Formatting(groups_0, **kwargs_0)
    str_1 = '!\x11\x06\x14\x1e\x1c'
    obj_0 = formatting_0.format_headers(str_1)


# Generated at 2022-06-25 18:53:15.221968
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'v(2?9i|\t|8Nt'
    theme_0 = None
    list_0 = [theme_0]
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:53:16.691597
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # TODO: find a way to test this method without pytest
    pass



# Generated at 2022-06-25 18:53:29.344722
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    data = {'name': 'value', 'Another header': 'Another header value'}
    headers = ''.join('%s: %s\r\n' % (k, v) for k, v in data.items())
    formatting_0 = Formatting(['colors'])
    str_0 = formatting_0.format_headers(headers)
    list_0 = []
    assert str_0 == ''.join('%s: %s\r\n' % (k, v) for k, v in data.items())


# Generated at 2022-06-25 18:53:37.476414
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['json']
    env = Environment()
    formatting_0 = Formatting(groups, env)
    str_0 = '{"date": "Last year", "name": "Luke"}'
    optional_0 = formatting_0.format_body(str_0, 'application/json')
    # The output should be {"date": "Last year", "name": "Luke"}
    print(optional_0)
    str_1 = '{"client": "Win", "server": "Apache"}'
    optional_1 = formatting_0.format_body(str_1, 'application/json')
    # The output should be {"client": "Win", "server": "Apache"}
    print(optional_1)


test_Formatting()

# Generated at 2022-06-25 18:53:41.566589
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_1 = ']~/P>\\,*~%|lr|U'
    list_0 = []
    formatting_0 = Formatting(*list_0)
    str_0 = formatting_0.format_body(str_1, str_1)


# Generated at 2022-06-25 18:53:42.894114
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    assert not Conversion.get_converter(str_0)


# Generated at 2022-06-25 18:53:46.305066
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'javascript'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:53:49.770708
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '\n]~/P>\\,*~%|lr|U'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:53:52.673917
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '<!$7f;Kj&0MOurT`y'
    list_0 = []
    formatting_0 = Formatting(*list_0)
    str_1 = formatting_0.format_headers(str_0)
    assert str_1 is None


# Generated at 2022-06-25 18:53:59.622779
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    string_0 = '&&P|{h9tj|_tT\\v'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(string_0)
    assert optional_0 is not None
    assert isinstance(optional_0, ConverterPlugin)



# Generated at 2022-06-25 18:54:05.564323
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = []
    str_0 = '\n]~/P>\\,*~%|lr|U'
    str_1 = '\n]~/P>\\,*~%|lr|U'
    str_2 = '\n]~/P>\\,*~%|lr|U'
    str_3 = '\n]~/P>\\,*~%|lr|U'
    str_4 = '\n]~/P>\\,*~%|lr|U'
    str_5 = '\n]~/P>\\,*~%|lr|U'
    str_6 = '\n]~/P>\\,*~%|lr|U'
    str_7 = '\n]~/P>\\,*~%|lr|U'


# Generated at 2022-06-25 18:54:11.226686
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env=env_0)
    str_0 = 'M$z,Hn>-j7G8:6=s/6U'
    str_1 = '8q3r{&%/xZvj?P-T8M'
    headers_0 = formatting_0.format_headers(str_0)
    body_0 = formatting_0.format_body(str_1, str_0)
    return

# Generated at 2022-06-25 18:54:30.156785
# Unit test for method format_body of class Formatting

# Generated at 2022-06-25 18:54:33.715123
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '\r1\nC[k0\t}C\t\r\t\r\t'
    list_0 = []
    env = Environment()
    formatting_0 = Formatting(*list_0, env=env)
    formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:54:36.171337
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '\n]~/P>\\,*~%|lr|U'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:54:45.339736
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = [
        'my_header',
        'my_header',
    ]
    kwargs = {}
    formatting_0 = Formatting(list_0, **kwargs)
    try:
        str_0 = '\n]~/P>\\,*~%|lr|U'
        str_1 = formatting_0.format_body(str_0, str_0)
        assert str_1 == '\n]~/P>\\,*~%|lr|U'
    except:
        assert False, 'Exception raised'


# Generated at 2022-06-25 18:54:50.026525
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    formatting_0 = Formatting([], env)
    str_0 = '\n]~/P>\\,*~%|lr|U'
    str_1 = formatting_0.format_body(str_0, str_0)
    assert str_1 == '\n]~/P>\\,*~%|lr|U'


# Generated at 2022-06-25 18:54:55.531610
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '|\\*R]a'
    list_0 = [str_0]
    formatting_0 = Formatting(*list_0)
    encoding_0 = 'latin-1'
    str_1 = 'N\u00d0\ueb64'
    str_2 = '\u00e5\u00ad\u0092\u0099'
    byte_0 = bytes([121, 77, -4])
    int_0 = printf(byte_0, encoding_0)
    int_1 = printf(str_0, encoding_0)
    unicode_0 = unichr(int_1)
    int_2 = ord(unicode_0)
    str_3 = chr(int_2)
    int_3 = parse_int(str_1, 16)
    int

# Generated at 2022-06-25 18:54:58.486983
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = ['group1', 'group2', 'group3']
    env = Environment()
    formatting_0 = Formatting(list_0, env)


# Generated at 2022-06-25 18:54:59.643624
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format_headers(self, headers)



# Generated at 2022-06-25 18:55:06.002897
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '\n]~/P>\\,*~%|lr|U'
    list_0 = []
    groups_0 = Formatting(list_0)
    str_1 = groups_0.format_headers(str_0)
    if str_1 == str_0:
        return 1.0
    else:
        print("\nDifference between " + str_0 + " and " + str_1)
        return 0.0


# Generated at 2022-06-25 18:55:14.708956
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # enum __label__
    U_0: Formatting
    U_1: Formatting
    U_0 = Formatting(['colors'])  # type: Formatting
    U_1 = Formatting(['colors'])  # type: Formatting
    # enum str __label__
    U_3: str
    U_3 = '\n]~/P>\\,*~%|lr|U'
    # enum str __label__
    U_2: str
    U_2 = '\n]~/P>\\,*~%|lr|U'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(U_3)
    str_0 = optional_0.to_json(U_2)
   

# Generated at 2022-06-25 18:55:40.029720
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '\u0016\u000f\u0011\u0015\u0018'
    list_0 = []
    formatting_0 = Formatting(list_0, *[], **{})
    str_1 = formatting_0.format_headers(str_0)
    assert len(str_1) == 5
    assert str_1[0] == '\x16'
    assert str_1[1] == '\x0f'
    assert str_1[2] == '\x11'
    assert str_1[3] == '\x15'
    assert str_1[4] == '\x18'


# Generated at 2022-06-25 18:55:44.976410
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Instance of Formatting
    formatting_0 = Formatting()
    # Test case with failed assertion
    try:
        formatting_0.format_body(None, None)
        # Should throw exception
        print('uthrow')
    except Exception as e:
        print('exception: ', e)


# Generated at 2022-06-25 18:55:50.834023
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups_0 = []
    bool_0 = False
    str_0 = '\n]~/P>\\,*~%|lr|U'
    str_1 = '\n]~/P>\\,*~%|lr|U'
    str_2 = '\n]~/P>\\,*~%|lr|U'
    formatting_0 = Formatting(groups_0, **kwargs0)
    str_3 = formatting_0.format_body(str_0, str_1)
    assert str_3 == str_2


# Generated at 2022-06-25 18:55:56.632617
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    # Create a string
    str_1 = '^2F8xHd5$5Y5'

    # Create a list
    list_0 = []
    for i in range(0, 9):
        list_0.append(i)

    # Create a variable to store an instance of class Conversion
    conversion_0 = Conversion(*list_0)

    # Store the result of a method call of class Conversion
    optional_0 = conversion_0.get_converter(str_1)

    # Check that the result of the method call is not null
    assert optional_0 is not None

# Generated at 2022-06-25 18:55:57.708365
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_case_0()


# Generated at 2022-06-25 18:55:58.754952
# Unit test for constructor of class Formatting
def test_Formatting():
    format_0 = Formatting()


# Generated at 2022-06-25 18:56:05.168779
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Input parameters
    input_variable_0 = mime = '\n]~/P>\\,*~%|lr|U'
    # Output parameters
    output_variable_0 = '\n]~/P>\\,*~%|lr|U'
    # Unit test for class Conversion
    if not is_valid_mime(input_variable_0):
        test_case_0()
    elif is_valid_mime(input_variable_0):
        test_case_1()
    else:
        test_case_2()
    return output_variable_0 == '\n]~/P>\\,*~%|lr|U'


# Generated at 2022-06-25 18:56:07.510568
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups_0 = ['', '', '', '', '', '', '', '', '', '', '', '', '', '']
    str_0 = '~A'
    str_1 = ''
    formatting_0 = Formatting(groups=groups_0)
    str_2 = formatting_0.format_body(str_0, str_1)


# Generated at 2022-06-25 18:56:15.289981
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Valid mime type
    str_0 = 'application/json'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 is not None
    assert optional_0.mime_type == str_0
    assert optional_0.convert('{"test":1}') == '{"test":1}'
    # Valid mime type
    str_0 = 'application/yaml'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(str_0)
    assert optional_0 is not None
    assert optional_0.mime_type == str_0

# Generated at 2022-06-25 18:56:19.438542
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '\n]~/P>\\,*~%|lr|U'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:56:58.241651
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '$*`F[j'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:57:01.167780
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = ['color', 'cli']
    str_0 = '<html></html>'
    formatting_0 = Formatting(*list_0)
    str_1 = formatting_0.format_headers(str_0)
    assert str_1 == '<html></html>'


# Generated at 2022-06-25 18:57:05.468473
# Unit test for constructor of class Formatting
def test_Formatting():
    # check if the constructor of class Formatting works properly

    # test case 1
    list_0 = []
    environment_0 = Environment()
    formatting_0 = Formatting(list_0, environment_0)


    # test case 2
    list_0 = []
    environment_0 = Environment()
    formatting_0 = Formatting(list_0, environment_0)


# Generated at 2022-06-25 18:57:09.987830
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['data', 'json']
    env = Environment()
    formatting = Formatting(groups, env)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'JSONFormatter'
    assert formatting.enabled_plugins[1].__class__.__name__ == 'DataFormatter'


# Generated at 2022-06-25 18:57:13.886250
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    body = '{}'
    mime = 'application/json'
    assert Formatting([]).format_body(body, mime) == '{}'
    assert Formatting(['json']).format_body(body, mime) == body
    assert Formatting(['colors']).format_body(body, mime) == '{\x1b[32m}\x1b[0m'

# Generated at 2022-06-25 18:57:18.084318
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = ['hi', 'hi']
    str_0 = 'body'
    str_1 = 'mime'
    formatting_0 = Formatting(*list_0)
    str_2 = formatting_0.format_body(str_0, str_1)
    assert 'hii' == str_2


# Generated at 2022-06-25 18:57:23.610449
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """Unit test for method get_converter of class Conversion"""
    str_0 = '\n]~/P>\\,*~%|lr|U'
    list_0 = []
    conversion_0 = Conversion(*list_0)
    optional_0 = conversion_0.get_converter(str_0)



# Generated at 2022-06-25 18:57:27.616312
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = []
    conversion_1 = Conversion(*list_0)
    str_0 = '\n]~/P>\\,*~%|lr|U'
    optional_0 = conversion_1.get_converter(str_0)

# Test methods of Formatting

# Generated at 2022-06-25 18:57:28.870220
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format_headers = Formatting()
    assert format_headers.format_headers('headers') == 'headers'


# Generated at 2022-06-25 18:57:34.426838
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_1 = ['headers']
    formatting_0 = Formatting(*list_1)
    # assert isinstance(formatting_0.format_headers('12.0.0.1'), object)
    # assert isinstance(formatting_0.format_headers('12.0.0.1'), object)
    # assert isinstance(formatting_0.format_headers('12.0.0.1'), object)
    # assert isinstance(formatting_0.format_headers('12.0.0.1'), object)
    # assert isinstance(formatting_0.format_headers('12.0.0.1'), object)
    # assert isinstance(formatting_0.format_headers('12.0.0.1'), object)
    # assert isinstance(formatting_0.format_headers('12.0.0.

# Generated at 2022-06-25 18:58:22.059381
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = '%X/chDSh\r*Y:|4L'
    conversion_0 = Conversion()
    optional_1 = conversion_0.get_converter(str_0)
    format_0 = Formatting(['indent', 'colors'], style='paraiso-dark', theme='monokai', colors=8,
                          syntax=optional_1, tab_size=32, line_max_length=27,
                          indent_size=11, sort_headers=False,
                          sort_dict_keys=False, sort_array_items=False)
    content = 'fjh  HUHd ufh d'
    mime = 'dfjksf/jkd'
    str_1 = format_0.format_body(content, mime)

# Generated at 2022-06-25 18:58:24.698654
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'ByL\u001c'
    optional_0 = conversion_0.get_converter(str_0)

# Generated at 2022-06-25 18:58:28.630909
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '%X/chDSh\r*Y:|4L'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)
    Optional_0 = None
    assert optional_0 != Optional_0


# Generated at 2022-06-25 18:58:31.280831
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = ']|2?l0+Z>8'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:58:41.531427
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():


    str_0 = '\r\r'
    str_1 = '\r\r\r'
    str_2 = '\r\r\r\r'
    str_3 = '\r\r\r\r\r'
    str_4 = '\r\r\r\r\r\r'
    str_5 = '\r\r\r\r\r\r\r'
    str_6 = '\r\r\r\r\r\r\r\r'
    str_7 = '\r\r\r\r\r\r\r\r\r'
    str_8 = '\r\r\r\r\r\r\r\r\r\r'

# Generated at 2022-06-25 18:58:44.629798
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '%X/chDSh\r*Y:|4L'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:58:47.589164
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '%X/chDSh\r*Y:|4L'
    conversion_0 = Conversion()
    optional_0 = conversion_0.get_converter(str_0)


# Generated at 2022-06-25 18:58:49.372865
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_1 = ['json']
    env_1 = Environment()
    formatting_0 = Formatting(groups_1, env_1)


# Generated at 2022-06-25 18:58:53.022869
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = ['json']
    Environment_0 = Environment()
    formatting_0 = Formatting(groups_0, Environment_0)
    str_0 = 'e'
    str_1 = 'e'
    str_2 = ' '
    assert_equal(formatting_0.format_headers(str_0), str_1)
    assert_equal(formatting_0.format_body(str_2, str_2), str_2)


# Generated at 2022-06-25 18:58:54.703411
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert "Status" == "Status", "test functionality"
