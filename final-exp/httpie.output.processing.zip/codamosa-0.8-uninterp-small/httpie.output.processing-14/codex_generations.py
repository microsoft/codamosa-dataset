

# Generated at 2022-06-25 18:49:34.569750
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    dict_0 = None
    conversion_0 = Conversion(**dict_0)
    mime_0 = None
    try:
        conversion_0.get_converter(mime_0)
    except Exception:
        pass


# Generated at 2022-06-25 18:49:36.488587
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Arrange
    # Act
    # Assert
    assert (test_case_0()) == None

# Generated at 2022-06-25 18:49:45.274247
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Arrange
    available_plugins = plugin_manager.get_formatters_grouped()
    grouping = ()
    enabled_plugins = []
    env = Environment()
    group = available_plugins[grouping]
    class_obj = group.__class__
    class_obj_0 = class_obj(env=env)
    class_obj_0_0 = class_obj_0.format_body("application/json")
    class_obj_0_0_0 = class_obj_0_0.format_body(class_obj_0_0, "application/json")

    # Act
    result = Formatting(grouping, env)

    # Assert
    assert result is not None


# Generated at 2022-06-25 18:49:47.715177
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = '1^jyx8'
    env_0 = Environment()
    formatting_0 = Formatting(groups_0, env_0)


# Generated at 2022-06-25 18:49:49.783025
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    true	= True
    false	= False

    converter_0 = Conversion.get_converter(**dict_0)



# Generated at 2022-06-25 18:49:52.215099
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'headers'
    str_1 = 'headers'
    assert_true(str_1==Formatting.format_headers(str_0), 'Test #1 failed.')



# Generated at 2022-06-25 18:49:57.170672
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    dict_0 = None
    conversion_0 = Conversion(**dict_0)
    mime = 'test string'
    conversion_0.get_converter(mime)


# Generated at 2022-06-25 18:50:05.990637
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import JSONFilterConverter
    plugin_manager.filter_by_group[JSONFilterConverter.group].append(JSONFilterConverter)
    groups_0 = ['colors']

# Generated at 2022-06-25 18:50:14.469611
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from core.http.Httpie import Httpie
    from core.http.HTTP import Headers
    headers = '''HTTP/1.1 200 OK
    Connection: keep-alive
    Content-Length: 5
    Content-Type: application/json
    Date: Mon, 10 Oct 2016 02:30:44 GMT
    Server: nginx
    X-Content-Type-Options: nosniff
    X-Frame-Options: SAMEORIGIN
    X-XSS-Protection: 1; mode=block

    {"data": 42}'''

    httpie = Httpie.instance()
    # print(httpie.format_body(headers, 'application/json'))
    # print()
    fmt = Formatting(['json'], httpie.env)

# Generated at 2022-06-25 18:50:15.415932
# Unit test for constructor of class Formatting
def test_Formatting():
    assert (Formatting(**[]) == Formatting(**[]))

# Generated at 2022-06-25 18:50:23.124141
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors"]
    dict_0 = {"debug": False, "follow": False, "max_redirects": 10, "output_file": None, "pretty": True, "session": None, "stream": False, "timeout": None, "verify": True, "allow_redirects": True, "verify_ssl": True}
    env = Environment(**dict_0)
    dict_1 = {"disable_colors": False, "format": "colors", "style_table": None}
    formatting_0 = Formatting(groups, env=env, **dict_1)


# Generated at 2022-06-25 18:50:27.137402
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    dict_0 = None
    conversion_0 = Conversion(**dict_0)
    str_0 = "text/html"
    converter_plugin_0 = conversion_0.get_converter(str_0)
    assert converter_plugin_0 == None


# Generated at 2022-06-25 18:50:38.525890
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'text/plain'
    str_1 = 'text/plain'
    str_2 = 'source.txt'
    str_3 = '{\n  "key": "value"\n}'
    str_4 = '{\n  "key": "value"\n}'
    str_5 = __file__
    str_6 = '{\n  "data": "AoCDaA==",\n  "id_name": "b"\n}'
    str_7 = '{\n  "data": "AoCDaA==",\n  "id_name": "b"\n}'
    str_8 = '{\n  "data": "base 64 encoded text",\n  "id_name": "b"\n}'

# Generated at 2022-06-25 18:50:46.419092
# Unit test for constructor of class Formatting
def test_Formatting():
    dict_0 = None
    str_0 = "hi"
    formatting_0 = Formatting(str_0, **dict_0)
    assert Formatting.get_converter(formatting_0, str_0)
    str_0 = "json"
    formatting_0 = Formatting(str_0, **dict_0)
    assert Formatting.get_converter(formatting_0, str_0)
    str_0 = "table"
    formatting_0 = Formatting(str_0, **dict_0)
    assert Formatting.get_converter(formatting_0, str_0)


# Generated at 2022-06-25 18:50:49.467459
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["foo", "bar"]
    env = Environment()
    kwargs = {}
    obj = Formatting(groups, env, **kwargs)
    assert "enabled_plugins" in obj.keys()


# Generated at 2022-06-25 18:50:55.443142
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    dict_0 = {'headers': None, 'method': None, 'stream': None, 'url': None, 'auth': None, 'verify': None, 'timeout': None, 'allow_redirects': None, 'max_redirects': None}
    formatting_0 = Formatting().format_body(**dict_0)


# Generated at 2022-06-25 18:50:56.894345
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting(**test_case_0).format_body();

# Generated at 2022-06-25 18:50:58.380435
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print("Conversion.get_converter")


# Generated at 2022-06-25 18:50:58.945622
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pass



# Generated at 2022-06-25 18:51:01.925899
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    dict_0 = None
    conversion_0 = Conversion(**dict_0)
    mime = 'null'
    assert conversion_0.get_converter(mime) == "null"


# Generated at 2022-06-25 18:51:05.587927
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = ['json', 'colors']
    formatting_0 = Formatting(list_0)


# Generated at 2022-06-25 18:51:07.961152
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = 'text/json'
    obj_0 = Conversion.get_converter(mime_0)
    assert obj_0 is None


# Generated at 2022-06-25 18:51:10.063996
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    env_0 = Environment()
    # test constructor
    assert Formatting(list_0, env=env_0).enabled_plugins == []


# Generated at 2022-06-25 18:51:15.454170
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = 'nifty.txt'
    #assert conversion_0.get_converter(str_0) == None
    str_1 = 'text/html'
    #assert conversion_0.get_converter(str_1) != None


# Generated at 2022-06-25 18:51:18.714812
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    env_0 = Environment()
    formatting_0 = Formatting(list_0, env=env_0)
    assert formatting_0 is not None


# Generated at 2022-06-25 18:51:28.810111
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    expected = "Command line HTTP client, user-friendly curl replacement"
    splitter_1 = SubprocessEnvironment(Environment(['http'], ['GET', 'https://raw.githubusercontent.com/jakubroztocil/httpie/1.0.3/DESCRIPTION'], ['Httpie/0.9.9'], True, {'Accept': '*/*', 'Content-Type': 'text/plain'}, True, None, 80))
    splitter_1.env.argv.extend(['https://raw.githubusercontent.com/jakubroztocil/httpie/1.0.3/DESCRIPTION'])
    splitter_1.env.stdout = io.BytesIO()
    splitter_1.env.stdout_isatty = False
    splitter_1.env.colors = 256


# Generated at 2022-06-25 18:51:34.263678
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = [ ]
    env_0 = Environment()
    bstr_0 = b"http://www.example.com"
    env_0.stdout = io.BytesIO()
    bstr_1 = b"Content-Type"
    list_1 = [ "application/json" ]
    httpie_0 = HTTPie("Json", list_0, env_0, json='Json')
    httpie_0.http("GET", bstr_0)
    output = env_0.stdout.getvalue()
    assert bstr_1 in output

# Generated at 2022-06-25 18:51:36.695285
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = "g-exan"
    assert_equal(Conversion.get_converter(mime_0), None)

# Generated at 2022-06-25 18:51:41.019287
# Unit test for constructor of class Formatting
def test_Formatting():
    ctx = MagicMock()
    ctx.args.formatter = ['colors']
    assert ctx.args.formatter == ['colors']
    formatter = Formatting(ctx.args.formatter,ctx)
    assert formatter.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-25 18:51:49.582767
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_1 = Formatting.format_headers(list_0, list_0)
    assert list.__eq__(list_1, list_0)
    assert (list_1 is list_0)
    assert (list_0 is list_0)
    list_1 = Formatting.format_headers(list_0, list_0)
    assert list.__eq__(list_1, list_0)
    assert (list_1 is list_0)
    assert (list_0 is list_0)
    list_1 = Formatting.format_headers(list_0, list_0)
    assert list.__eq__(list_1, list_0)
    assert (list_1 is list_0)
    assert (list_0 is list_0)

# Generated at 2022-06-25 18:51:59.683948
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = list()
    formatting_0 = Formatting(list_0)
    # Headers: 'HTTP/1.1 200 OK\r\n' +
    #          'Content-Length: 16\r\n' +
    #          'Content-Type: text/plain; charset=utf-8\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Length: 16\r\nContent-Type: text/plain; charset=utf-8\r\n'

    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 18:52:06.492415
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print('Do we need to define a fake ConverterPlugin to make it work?')
    # Test Setup
    str_0 = 'application/json'
    list_0 = []
    formatting_0 = Formatting(list_0)
    str_1 = '{"foo": "value", "bar": "value"}'
    str_2 = formatting_0.format_body(str_1, str_0)

    assert str_1 == str_2

    test_case_0()
    test_Formatting_format_body()

# Generated at 2022-06-25 18:52:10.190824
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    encoding_0 = ''
    mime_0 = 'application/json'
    formatting_0 = Formatting([])
    content_0 = ''
    formatting_0.format_body(content_0, mime_0)


# Generated at 2022-06-25 18:52:14.350553
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = []
    formatting_0 = Formatting(list_0)
    str_0 = formatting_0.format_headers("e")
    assert str_0 == "e"
    str_1 = formatting_0.format_headers("e")
    assert str_1 == "e"


# Generated at 2022-06-25 18:52:17.565575
# Unit test for constructor of class Formatting
def test_Formatting():
    # 1. default case
    list_0 = []
    formatting_0 = Formatting(list_0)
    assert formatting_0 != None

    # 2.
    list_1 = ["formatters_json", "formatters_pretty"]
    formatting_1 = Formatting(list_1)
    assert formatting_1 != None

# Generated at 2022-06-25 18:52:18.740181
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    formatting_0 = Formatting(list_0)


# Generated at 2022-06-25 18:52:21.908428
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = ['a', 'b']
    env = Environment()
    formatting_0 = Formatting(list_0, env)
    assert formatting_0
    assert env == formatting_0.env
    assert formatting_0.enabled_plugins == []

# Generated at 2022-06-25 18:52:27.010112
# Unit test for constructor of class Formatting
def test_Formatting():
    content_0 = "http://httpbin.org/status/418"
    formatting_0 = Formatting(content_0)
    assert Formatting.__init__(formatting_0, content_0)  # __init__(self, groups: List[str], env=Environment(), **kwargs) -> None


# Generated at 2022-06-25 18:52:33.275188
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = []
    str_0 = (string.printable)[0]
    formatting_0 = Formatting(list_0)
    obj_0 = formatting_0.format_body(str_0, str_0)
    # assert obj_0 is None
    # str_1 = str_0.split(str_0)
    # str_1 = str_0.split(str_0)
    assert obj_0 == str_0


# Generated at 2022-06-25 18:52:36.448050
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    env = Environment()
    formatting_0 = Formatting(list_0, env, ascii_output=True)
    assert formatting_0.enabled_plugins is not None
    assert len(formatting_0.enabled_plugins) == 0


# Generated at 2022-06-25 18:52:43.188427
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = []
    formatting_1 = Formatting(list_0)

    string_0 = "asd"
    assert_equal(formatting_1.format_headers(string_0), "asd")



# Generated at 2022-06-25 18:52:44.806731
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    converter_0 = Conversion.get_converter("application/json")
    assert converter_0 is None

# Generated at 2022-06-25 18:52:55.460982
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = [ 'b' ]
    formatting_0 = Formatting(list_0)
    str_0 = "Content-Type: application/json; charset=utf-8\r\nContent-Length: 18\r\nDate: Sun, 20 Mar 2016 13:48:36 GMT\r\nServer: WSGIServer/0.1 Python/2.7.8\r\n\r\n"
    str_1 = formatting_0.format_headers(str_0)
    assert str_1 == " Content-Type: application/json; charset=utf-8\r\n Content-Length: 18\r\n Date: Sun, 20 Mar 2016 13:48:36 GMT\r\n Server: WSGIServer/0.1 Python/2.7.8\r\n\r\n"

#

# Generated at 2022-06-25 18:52:57.250762
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    env = Environment()
    formatting_0 = Formatting(list_0, env)


# Generated at 2022-06-25 18:52:59.244377
# Unit test for constructor of class Formatting
def test_Formatting():
    environment_0 = Environment()
    list_0 = []
    formatting_0 = Formatting(list_0, environment_0, pretty=True)


# Generated at 2022-06-25 18:53:03.685052
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    env_0 = Environment()
    kwargs_0 = {}
    formatting_0 = Formatting(list_0, env_=env_0, **kwargs_0)


# Generated at 2022-06-25 18:53:08.548995
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    list_0 = []
    
    # This is the default value, but just in case
    env.formatter = "default"
    
    formatting_0 = Formatting(list_0, env)
    assert formatting_0 is not None


# Tests for method get_converter in class Formatting

# Generated at 2022-06-25 18:53:13.675381
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = []
    formatting_0 = Formatting(list_0)
    str_0 = formatting_0.format_headers("-s")
    assert str_0 == "-s"


# Generated at 2022-06-25 18:53:14.730451
# Unit test for constructor of class Formatting
def test_Formatting():
    test_case_0()



# Generated at 2022-06-25 18:53:18.693454
# Unit test for constructor of class Formatting
def test_Formatting():
    converters = []
    environment = Environment()
    kwargs = {}
    groups = []
    test = Formatting(groups, environment, **kwargs)
    if test is None:
        raise Exception('Failed to instantiate object of class Formatting')
    return test

# Generated at 2022-06-25 18:53:27.236009
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    conversion_0 = Conversion()
    converter_plugin_0 = conversion_0.get_converter(mime)
    assert converter_plugin_0


# Generated at 2022-06-25 18:53:29.873231
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = []
    formatting_0 = Formatting(list_0)
    string_0 = "Accept: */*"
    string_1 = formatting_0.format_headers(string_0)
    assert string_1 is not None


# Generated at 2022-06-25 18:53:35.041969
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = []
    formatting_0 = Formatting(list_0)
    bytes_0 = b''
    str_0 = "UTF-8"
    str_1 = ""
    str_2 = formatting_0.format_headers(str_1)
    assert str_2 != ""
    assert (str_2 == str_1)

if __name__ == '__main__':
    test_case_0()
    test_Formatting_format_headers()

# Generated at 2022-06-25 18:53:37.230628
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        list_0 = []
        formatting_0 = Formatting(list_0)
    except:
        raise AssertionError()

# Generated at 2022-06-25 18:53:43.091237
# Unit test for constructor of class Formatting
def test_Formatting():
    assert 0 == Formatting([], Environment())._Formatting__enabled_plugins.__len__()
    assert 0 == Formatting([], Environment(), verbose=False)._Formatting__enabled_plugins.__len__()
    assert 0 == Formatting([], Environment(), pretty=None)._Formatting__enabled_plugins.__len__()
    assert 0 == Formatting([], Environment(), colors=None)._Formatting__enabled_plugins.__len__()


# Generated at 2022-06-25 18:53:49.053815
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = []
    formatting_0 = Formatting(list_0)
    content_0 = ';m43$$6'
    mime_0 = 'bundle=31410'
    str_0 = formatting_0.format_body(content_0, mime_0)
    str_1 = formatting_0.format_body(content_0, mime_0)
    assert str_1 == str_1


# Generated at 2022-06-25 18:53:49.958897
# Unit test for constructor of class Formatting
def test_Formatting():
    g = Formatting([""])


# Generated at 2022-06-25 18:53:51.588988
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting(['none'])
    assert isinstance(formatting_0, Formatting)



# Generated at 2022-06-25 18:53:52.332318
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting([]) is not None

# Generated at 2022-06-25 18:53:56.653814
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert True == is_valid_mime("test/test")

# Generated at 2022-06-25 18:54:11.549825
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Case 1
    list_0 = []
    formatting_0 = Formatting(list_0)
    content_0 = '\n'
    mime_0 = '\n'
    result_0 = formatting_0.format_body(content_0, mime_0)
    assert result_0 == '\n'
    # Case 2
    list_0 = []
    formatting_0 = Formatting(list_0)
    content_0 = '\'5F"'
    mime_0 = '\n'
    result_0 = formatting_0.format_body(content_0, mime_0)
    assert result_0 == '\'5F"'
    # Case 3
    list_0 = []
    formatting_0 = Formatting(list_0)
    content_0 = '\n'
    m

# Generated at 2022-06-25 18:54:15.509684
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # case 0 is test case for empty input
    assert isinstance(Conversion.get_converter(""), ConverterPlugin)
    # case 1 is test case for valid input
    assert isinstance(Conversion.get_converter("text/plain"), ConverterPlugin)
    # case 2 is test case for invalid input
    assert isinstance(Conversion.get_converter("text"), ConverterPlugin)

# Generated at 2022-06-25 18:54:18.210418
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_1 = []
    formatting_1 = Formatting(list_1)
    headers_1 = "headers"
    # Call method format_headers of formatting_1
    assert formatting_1.format_headers(headers_1) == "headers"


# Generated at 2022-06-25 18:54:26.736897
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    env = Environment()
    env.stream = True
    formatting_0 = Formatting(list_0, env=env)
    env.stream = True
    env.json_indent = 4
    formatting_0 = Formatting(list_0, env=env)
    env.stream = False
    formatting_0 = Formatting(list_0, env=env)
    env.stream = False
    env.json_indent = 4
    formatting_0 = Formatting(list_0, env=env)

# Generated at 2022-06-25 18:54:28.763538
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    mime_0 = "unicode/string"
    converter_0 = conversion_0.get_converter(mime_0)

# Generated at 2022-06-25 18:54:30.816492
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_1 = []
    formatting_1 = Formatting(list_1)
    assert formatting_1.format_body('', '') != None



# Generated at 2022-06-25 18:54:34.337793
# Unit test for constructor of class Formatting
def test_Formatting():

    # perform positive testing
    # case 0
    # object is created successfully
    assert Formatting([]) is not None

    # perform negative testing
    # case 0
    # inputs are null, exception should be thrown
    try:
        Formatting(None)
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-25 18:54:39.767172
# Unit test for constructor of class Formatting
def test_Formatting():

    # test for bad arg type for groups
    try:
        Formatting('hello')
    except Exception as e:
        pass
    else:
        assert False

    # test for bad arg type for env
    try:
        Formatting([], 'hello')
    except Exception as e:
        pass
    else:
        assert False

    # test for bad arg type for kwargs
    try:
        Formatting([], kwargs='hello')
    except Exception as e:
        pass
    else:
        assert False

    # test for no arg
    try:
        Formatting()
    except Exception as e:
        pass
    else:
        assert False

    # Test for correct return object type
    try:
        Formatting([])
    except Exception as e:
        assert False

# Test case for method format_headers

# Generated at 2022-06-25 18:54:44.566933
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test with argument valid_0
    try:
        list_0 = []
        formatting_0 = Formatting(list_0)
        str_0 = ''
        str_1 = formatting_0.format_headers(str_0)
        assert str_1 == str_0
    except:
        assert False


# Generated at 2022-06-25 18:54:46.727807
# Unit test for constructor of class Formatting
def test_Formatting():
    print('Testing constructor...')
    list_0 = []
    formatting_0 = Formatting(list_0)
    assert formatting_0



# Generated at 2022-06-25 18:54:55.132489
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    string_0 = "string"
    mapping_0 = dict()
    list_0 = []
    assert Formatting(list_0).format_headers(string_0) == string_0


# Generated at 2022-06-25 18:54:56.657151
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/plain'
    assert is_valid_mime(mime)


# Generated at 2022-06-25 18:55:07.614202
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = ['json']
    formatting_0 = Formatting(list_0)
    str_0 = 'Book'
    str_1 = '{"id": 1, "name": "A Tale of Two Cities", "author": "Charles Dickens"}'
    str_2 = 'Authorization: Basic dXNlcjpwYXNzd29yZA=='
    str_3 = '{"Authorization": "Basic dXNlcjpwYXNzd29yZA=="}'
    str_4 = '{"Authorization": "Basic dXNlcjpwYXNzd29yZA==", "Content-Length": "60"}'

# Generated at 2022-06-25 18:55:10.917827
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    # Instantiate an object of class Conversion
    conversion_0 = Conversion()

    # Invoke get_converter()
    conversion_0.get_converter("json")


# Generated at 2022-06-25 18:55:16.945208
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = []
    formatting_0 = Formatting(list_0)
    conversion_0 = Conversion()
    converter_0 = conversion_0.get_converter("")
    assert converter_0

    # test_case_6
    conversion_1 = Conversion()
    converter_1 = conversion_1.get_converter("type/format")
    assert converter_1

    # test_case_7
    conversion_2 = Conversion()
    converter_2 = conversion_2.get_converter("format/type")
    assert converter_2

    # test_case_8
    conversion_3 = Conversion()
    converter_3 = conversion_3.get_converter("type/format")
    assert converter_3

# Generated at 2022-06-25 18:55:27.383286
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = []
    formatting_0 = Formatting(list_0)


# Generated at 2022-06-25 18:55:32.150834
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    header = "Content-Type: application/json"
    content = "test string"
    mime = header.split(": ")[1]
    conv0 = Conversion.get_converter(mime)
    if conv0:
        content = conv0.encode(content)
    else:
        print("Converter for " + mime + " not found")


# Generated at 2022-06-25 18:55:35.622527
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    env_0 = Environment()
    key_0 = str()
    value_0 = object()
    formatting_0 = Formatting(list_0, env_0, key_0=value_0)

# Generated at 2022-06-25 18:55:42.211998
# Unit test for constructor of class Formatting
def test_Formatting():
    # test initializer:
    # header_groups=[]
    # env=Environment()
    # env.stderr=ColoredStream(stderr)
    # env.stdout=ColoredStream(stdout)
    # env.stdin=stdin
    # env.is_windows=(os.name == 'nt')
    # env.is_python2=six.PY2
    # env.is_valid_http_url=is_valid_http_url
    # env.stdout_isatty=stdout_isatty
    env = Environment()
    available_plugins = plugin_manager.get_formatters_grouped()
    groups = []
    enabled_plugins = []
    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=env)


# Generated at 2022-06-25 18:55:43.543094
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter(str) is None


# Generated at 2022-06-25 18:55:59.109951
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = "application/json"
    assert is_valid_mime(str_0) == True
    assert is_valid_mime("") == False
    assert is_valid_mime("asdf") == False
    assert Conversion.get_converter(str_0)



# Generated at 2022-06-25 18:56:01.408445
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/xml'
    conversion = Conversion()
    converter = conversion.get_converter(mime)
    assert converter != None
    assert converter.mime == 'text/xml'


# Generated at 2022-06-25 18:56:04.035555
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        assert Conversion.get_converter("text/html") == None
        assert Conversion.get_converter("application/x-yaml") == None
    except:
        raise AssertionError


# Generated at 2022-06-25 18:56:07.734668
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    formatting_0 = Formatting(list_0)
    assert isinstance(formatting_0, Formatting), 'Constructor is not returning an object of class Formatting'


# Generated at 2022-06-25 18:56:13.887932
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = []
    formatting_0 = Formatting(list_0)
    content_0 = "body"
    mime_0 = "application/json"

    content_1 = formatting_0.format_body(content_0, mime_0)
    assert content_1 == "body", "Expected format_body(content, mime) to be body, but it was %r" % content_1


# Generated at 2022-06-25 18:56:16.909623
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    environments_0 = Environment()
    formatting_0 = Formatting(list_0, environments_0)
    assert formatting_0 is not None


# Generated at 2022-06-25 18:56:18.698398
# Unit test for constructor of class Formatting
def test_Formatting():
    n = Formatting('list_0')
    assert n != None, 'Object not created'



# Generated at 2022-06-25 18:56:22.674090
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert is_valid_mime("text/html")
    assert is_valid_mime("text/x-markdown")
    assert not is_valid_mime("text/")
    assert not is_valid_mime("/html")

# Generated at 2022-06-25 18:56:26.160566
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = []
    formatting_0 = Formatting(list_0)
    headers = 'Server: nginx/1.14.0 (Ubuntu)'
    result = formatting_0.format_headers(headers)
    assert result == 'Server: nginx/1.14.0 (Ubuntu)'


# Generated at 2022-06-25 18:56:35.202411
# Unit test for constructor of class Formatting
def test_Formatting():
    header = "HTTP/1.1 200 OK\nContent-Type: text/html; Charset=ISO-8859-4\nContent-Encoding: gzip\n\n{\"key\"}:{\"value\"}"
    content = "['a', 'b', 'c']"
    formatter_0 = Formatting(['json', 'colors'])
    mime = "application/json"

# Generated at 2022-06-25 18:56:52.628571
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = []
    formatting_0 = Formatting(list_0)
    string_0 = 'g'
    string_1 = 'o'
    string_2 = 'l'
    string_3 = 'a'
    string_4 = 'n'
    string_5 = 'g'
    string_6 = ' '
    string_7 = 'i'
    string_8 = 's'
    string_9 = ' '
    string_10 = 'a'
    string_11 = ' '
    string_12 = 's'
    string_13 = 't'
    string_14 = 'a'
    string_15 = 't'
    string_16 = 'i'
    string_17 = 'c'
    string_18 = ' '
    string_19 = 't'
    string_

# Generated at 2022-06-25 18:56:54.719334
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = []
    formatting_0 = Formatting(list_0)
    assert get_converter('text/html') == None


# Generated at 2022-06-25 18:57:01.433871
# Unit test for constructor of class Formatting
def test_Formatting():
    # Wrong input 1: Input wrong type for groups.
    try:
        Formatting([1, 2, 3], env=Environment())
    except:
        pass

    # Wrong input 2: Input wrong type for groups.
    try:
        Formatting(Environment(), env=Environment())
    except:
        pass

    # Test case 1: Input valid.
    try:
        Formatting(["colors", "colors"], env=Environment())
    except:
        assert False

    # Test case 2: Input valid.
    try:
        Formatting(["colors", "colors", "colors"], env=Environment())
    except:
        assert False


# Generated at 2022-06-25 18:57:03.236313
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = []
    string_0 = 'application/json'
    conversion_0 = Conversion.get_converter(string_0)



# Generated at 2022-06-25 18:57:07.687636
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = []
    environment_0 = Environment()
    formatting_0 = Formatting(list_0, environment_0)
    str_0 = ''
    str_1 = formatting_0.format_headers(str_0)
    str_2 = ''
    str_3 = formatting_0.format_body(str_2, str_1)

# Generated at 2022-06-25 18:57:14.484742
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from unittest.mock import MagicMock
    from unittest.mock import call
    list_0 = []
    formatting_0 = Formatting(list_0)
    headers_0 = "exampleheader"
    # Argument value is within the valid range: True
    assert formatting_0.format_headers(headers_0) == "exampleheader"
    # Argument value is not within the valid range: False
    try:
        assert formatting_0.format_headers(None) == "exampleheader"
    except TypeError:
        pass
    # Argument value is not within the valid range: False
    try:
        assert formatting_0.format_headers(None) == "exampleheader"
    except TypeError:
        pass
    # Argument value is not within the valid range: False

# Generated at 2022-06-25 18:57:21.921372
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = []
    formatting_0 = Formatting(list_0)
    headers_str = '''X-Xss-Protection: 1; mode=block
X-Frame-Options: SAMEORIGIN
X-Content-Type-Options: nosniff
Content-Type: text/html
Content-Length: 739
Strict-Transport-Security: max-age=31536000
'''
    headers_str = formatting_0.format_headers(headers_str)
    print(headers_str)


# Generated at 2022-06-25 18:57:24.884030
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = '*/*'
    assert_equals(is_valid_mime(mime), True)


# Generated at 2022-06-25 18:57:30.673745
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = []
    formatting_0 = Formatting(list_0)
    jtc = [
        "application/json",
        "application/xml",
        "text/html",
        "text/json",
        "text/plain",
        "text/xml",
        "text/yaml",
        "text/yml"
    ]

    for case in jtc:
        inp = '{"1": "1", "2": [2, 3, {"4": 4}]}'
        fmt = formatting_0.format_body(inp, case)

        assert fmt == inp, case



# Generated at 2022-06-25 18:57:31.427010
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    formatting_0 = Formatting([])
    assert formatting_0 is not None



# Generated at 2022-06-25 18:58:02.030973
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = []
    environment_0 = Environment(colors=True, stdin=None, stdin_isatty=False)
    formatting_0 = Formatting(list_0, environment_0)
    headers_str_0 = "Foo: bar\nBaz: bat\n"
    headers_str_1 = formatting_0.format_headers(headers_str_0)
    assert headers_str_1 == "Foo: bar\nBaz: bat\n"


# Generated at 2022-06-25 18:58:05.988726
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = []
    formatting_0 = Formatting(list_0)
    str_0 = 'data:text/plain'
    str_1 = formatting_0.format_body(str_0, 'data:text/plain')
    assert str_1 == 'data:text/plain'



# Generated at 2022-06-25 18:58:10.282278
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
   if True:
       mime: str = '0123456789'
       conversion_0 = Conversion.get_converter(mime)

       assert isinstance(conversion_0, object)
   else:
       mime: str = '0123456789'
       conversion_0 = Conversion.get_converter(mime)

       assert isinstance(conversion_0, object)



# Generated at 2022-06-25 18:58:13.824178
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = ['uglify', 'colors', 'colors', 'colors']
    formatting_0 = Formatting(list_0)
    str_0 = 'Access-Control-Allow-Origin: *\r\n'
    str_1 = formatting_0.format_headers(str_0)
    assert str_1=='Access-Control-Allow-Origin: *'


# Generated at 2022-06-25 18:58:14.947919
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    assert Formatting.format_body(Formatting, 'httpie.ConsoleFormatter', 'application/json')



# Generated at 2022-06-25 18:58:15.567392
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting.format_headers() == None


# Generated at 2022-06-25 18:58:18.189068
# Unit test for constructor of class Formatting
def test_Formatting():
    assert isinstance(Formatting([], None), Formatting)


# Generated at 2022-06-25 18:58:20.842572
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = []
    formatting_0 = Formatting(list_0)
    assert '1' == formatting_0.format_body('1', 'text/html')


# Generated at 2022-06-25 18:58:30.202529
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test with a valid mime - application/json
    converter_0_result = Conversion.get_converter("application/json")
    assert converter_0_result.mime is not None
    
    # Test with a valid mime - application/xml
    converter_1_result = Conversion.get_converter("application/xml")
    assert converter_1_result.mime is not None

    # Test with an invalid mime - application/
    converter_2_result = Conversion.get_converter("application/")
    assert converter_2_result is None

    # Test with an invalid mime - application
    converter_3_result = Conversion.get_converter("application")
    assert converter_3_result is None


# Generated at 2022-06-25 18:58:32.875509
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = []
    formatting_0 = Formatting(list_0)
    file_0 = open(r"C:\Users\Tom\Documents\GitHub\httpie\tests\data\headers_only.json")
    file_0.close()
    formatting_0.format_headers(file_0)

# Generated at 2022-06-25 18:59:24.538404
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting.format_body(Formatting, None, None) == None # TypeError


# Generated at 2022-06-25 18:59:30.290577
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_2 = []
    formatting_2 = Formatting(list_2)

    for mime in ['text/html', 'text/plain', 'application/json']:
        converter_2 = Conversion.get_converter(mime)
        assert_not_equals(list(), converter_2)
        assert_equals(list_2, list())
        assert_not_equals(list_2, converter_2)
