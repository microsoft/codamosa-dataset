

# Generated at 2022-06-25 18:49:27.571913
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = None
    mime = mime
    converter = Conversion.get_converter(mime)
    assert (converter == None)



# Generated at 2022-06-25 18:49:28.434978
# Unit test for constructor of class Formatting
def test_Formatting():
    t = Formatting(['+Append', '-Pygments'])


# Generated at 2022-06-25 18:49:32.949106
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = None
    formatting_0 = Formatting(list_0) 
    headers_0 = None
    headers_ret_0 = formatting_0.format_headers(headers_0)
    return headers_ret_0

# Generated at 2022-06-25 18:49:39.138928
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    arr = ['json', 'colors']
    def_en = 'headers'
    def_mime = 'application/json'
    env = Environment()
    env.stream = StringIO()
    env.config = Config(default_options={'verbose': True})
    env.headers = {'Content-Type': def_mime}
    fmt_0 = Formatting(arr, env)
    fmt_0.format_headers(def_en)


# Generated at 2022-06-25 18:49:48.923242
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = None
    formatting_0 = Formatting(list_0)
    mime_0 = 'application/json'
    content_0 = '{\n\t"foo": "bar"\n}'
    expected_0 = '{\n\t"foo": "bar"\n}'
    actual_0 = formatting_0.format_body(content_0, mime_0)
    assert expected_0 == actual_0

    list_1 = None
    formatting_1 = Formatting(list_1)
    mime_1 = 'ⓓ'
    content_1 = ''
    expected_1 = ''
    actual_1 = formatting_1.format_body(content_1, mime_1)
    assert expected_1 == actual_1

    list_2 = None
    formatting_2 = Format

# Generated at 2022-06-25 18:49:49.555567
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter == 'json'


# Generated at 2022-06-25 18:49:52.290897
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = Conversion()
    str_0 = None
    conversion_0.get_converter(str_0)
    str_1 = "qwerty"
    conversion_0.get_converter(str_1)


# Generated at 2022-06-25 18:49:54.592790
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting.format_body


# Generated at 2022-06-25 18:49:57.681947
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = None
    env_0 = None
    formatting_0 = Formatting(list_0, env_0)
    assert formatting_0 is not None


# Generated at 2022-06-25 18:50:00.557250
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = None
    formatting_0 = Formatting(list_0)
    content_0 = None
    mime_0 = None
    assert formatting_0.format_body(content_0, mime_0) == None


# Generated at 2022-06-25 18:50:06.104105
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_1 = None
    formatting_1 = Formatting(list_1)
    headers = "headers"
    try:
        assert formatting_1.format_headers(headers) == "headers"
    except AssertionError as e:
        print(e)



# Generated at 2022-06-25 18:50:10.182771
# Unit test for constructor of class Formatting
def test_Formatting():
    from nose.tools import raises

    #test constructor, no params
    #test constructor, one or more params
    #test constructor, invalid params
    #test constructor of base class

    #test __init__
    tests = []
    tests.extend(test_case_0())

    for test in tests:
        test()


# Generated at 2022-06-25 18:50:11.985966
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = ["mime"]
    assert isinstance(Conversion.get_converter(list_0), ConverterPlugin)


# Generated at 2022-06-25 18:50:14.886827
# Unit test for constructor of class Formatting
def test_Formatting():
    # string 0
    groups = ['headers', 'HTTPie', 'Unique', 'colors']
    formatting = Formatting(groups)
    expected = ['headers', 'HTTPie', 'Unique', 'colors']
    # verify results
    assert formatting.enabled_plugins == expected


# Generated at 2022-06-25 18:50:16.251253
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = ['0', '1', '2']
    formatting_0 = Formatting(list_0)


# Generated at 2022-06-25 18:50:18.391238
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = None
    conversion_0 = Conversion.get_converter(mime_0)
    assert conversion_0 == None



# Generated at 2022-06-25 18:50:21.728735
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    test_mime = "text/plain"
    test_content = "This is a test"
    case_1 = Formatting(["format"], env=env)
    assert case_1.format_body(test_content, test_mime) == test_content


# Generated at 2022-06-25 18:50:24.696428
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = None
    formatting_0 = Formatting(list_0)
    assert not isinstance(formatting_0, Formatting)


# Generated at 2022-06-25 18:50:25.836158
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting is not None

# Generated at 2022-06-25 18:50:32.789704
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = ['nocolor']
    env_0 = Environment()
    kwargs_0 = {'ugly': True}
    formatting_0 = Formatting(list_0, env_0, **kwargs_0)
    mime_0 = 'application/json'
    string_0 = '{"key":"value"}'
    string_1 = formatting_0.format_body(string_0, mime_0)
    print(string_1)


# Generated at 2022-06-25 18:50:45.004962
# Unit test for constructor of class Formatting
def test_Formatting():

    env = Environment()
    list_1 = ["JSON"]
    formatting_1 = Formatting(list_1)
    assert formatting_1
    assert formatting_1.enabled_plugins
    assert len(formatting_1.enabled_plugins) == 1
    assert formatting_1.enabled_plugins[0].__class__.__name__ == "JSONFormatter"

    formatting_2 = Formatting([])
    assert formatting_2
    assert formatting_2.enabled_plugins
    assert len(formatting_2.enabled_plugins) == 0
    assert formatting_2.enabled_plugins == None

    list_3 = ["JSON", "RESPONSE_CODE"]
    formatting_3 = Formatting(list_3)
    assert formatting_3
    assert formatting_3.enabled_plugins

# Generated at 2022-06-25 18:50:47.322331
# Unit test for constructor of class Formatting
def test_Formatting():
    var_groups = []
    var_env = Environment()
    var_kwargs = {}
    formatting = Formatting(var_groups, var_env, **var_kwargs)


# Generated at 2022-06-25 18:50:50.126861
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_1 = ['1']
    formatting_1 = Formatting(list_1)
    str_1 = formatting_1.format_headers('1')


# Generated at 2022-06-25 18:50:53.857266
# Unit test for constructor of class Formatting
def test_Formatting():
    environment_0 = pytest.Environment()
    list_0 = None
    with pytest.raises(KeyError):
        Formatting(list_0, environment_0)


# Generated at 2022-06-25 18:51:01.577572
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = None
    formatting_0 = Formatting(list_0)
    str_0 = "7"
    str_1 = formatting_0.format_body(str_0, "")
    assert str_1 == "7"
    str_2 = "ls"
    str_3 = formatting_0.format_body(str_2, "")
    assert str_3 == "ls"
    str_4 = "a"
    str_5 = formatting_0.format_body(str_4, "")
    assert str_5 == "a"


# Generated at 2022-06-25 18:51:10.674607
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case with integer value
    args = None
    for i in range(4):
        try:
            x = Formatting(args)
        except:
            print('unexpected exception')

    # Test case with string value
    args = ""
    for i in range(4):
        try:
            x = Formatting(args)
        except:
            print('unexpected exception')

    # Test case with boolean value
    args = True
    for i in range(4):
        try:
            x = Formatting(args)
        except:
            print('unexpected exception')

    # Test case with Valid Data
    args = ["", "", "", ""]
    for i in range(4):
        try:
            x = Formatting(args)
        except:
            print('unexpected exception')

# Unit test

# Generated at 2022-06-25 18:51:21.789850
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    mime = 'text/plain'
    content = ''
    formatting_0 = Formatting([])
    result = formatting_0.format_body(content, mime)
    assert result == content, f'expected:<{content}> but was:<{result}>'
    list_0 = ['highlighting']
    formatting_1 = Formatting(list_0)
    result = formatting_1.format_body(content, mime)
    expected = ''
    assert result == expected, f'expected:<{expected}> but was:<{result}>'
    formatting_2 = Formatting([])
    result = formatting_2.format_body(content, mime)
    expected = ''
    assert result == expected, f'expected:<{expected}> but was:<{result}>'


# Generated at 2022-06-25 18:51:25.272762
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = None
    formatting_0 = Formatting(list_0)
    headers_0 = ""
    headers_0 = formatting_0.format_headers(headers_0)


# Generated at 2022-06-25 18:51:26.382591
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_0 = Formatting("")


# Generated at 2022-06-25 18:51:29.796811
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    MIME_RE_0 = re.compile(r'^[^/]+/[^/]+$')
    mime = "application/json"
    result = is_valid_mime(mime)
    assert(result == True)


# Generated at 2022-06-25 18:51:35.528871
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting = Formatting(['color'], color=None)
    assert formatting is not None


# Generated at 2022-06-25 18:51:37.106476
# Unit test for constructor of class Formatting
def test_Formatting():
  print('Test 1')
  list_0 = None
  formatting_0 = Formatting(list_0)
  list_0 = []
  formatting_0 = Formatting(list_0)
  list_0 = ['highlight']
  formatting_0 = Formatting(list_0)


# Generated at 2022-06-25 18:51:38.994756
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = None
    formatting_0 = Formatting(list_0)



# Generated at 2022-06-25 18:51:47.605749
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = None
    formatting_0 = Formatting(list_0)
    headers = 'HTTP/1.1 200 OK\nConnection: keep-alive\nCache-Control: max-age=300\nContent-Type: application/json\nServer: nginx/1.13.8\nContent-Security-Policy: default-src blabla.com;\nX-Frame-Options: SAMEORIGIN\nStrict-Transport-Security: max-age=31536000\nX-XSS-Protection: 1; mode=block\nX-Content-Type-Options: nosniff\nDate: Fri, 26 Oct 2018 14:41:13 GMT\nContent-Length: 9\nAccept-Ranges: bytes\n\n{"id":9}\n'

# Generated at 2022-06-25 18:51:49.414896
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = None
    formatting_0 = Formatting(list_0)


# Generated at 2022-06-25 18:51:51.789325
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.priority == 1


# Generated at 2022-06-25 18:51:53.989596
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    u_0 = None
    conversion_0 = Conversion()
    converter_1 = conversion_0.get_converter(u_0)


# Generated at 2022-06-25 18:51:56.772734
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = '^[^/]+/[^/]+$'
    result_0 = Conversion.get_converter(mime_0)
    assert result_0 is not None


# Generated at 2022-06-25 18:51:58.504595
# Unit test for constructor of class Formatting
def test_Formatting():
    list_0 = None
    env_0 = Environment()
    formatting_0 = Formatting(list_0, env_0)


# Generated at 2022-06-25 18:52:09.060643
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = None
    formatting_0 = Formatting(list_0)
    str_0 = ""
    str_1 = formatting_0.format_headers(str_0)
    print(str_1)
    str_2 = "Content-Type: application/json; charset=utf-8\r\nDate: Tue, 23 Jan 2018 18:14:23 GMT"
    str_3 = "Content-Type: application/json\r\nDate: Tue, 23 Jan 2018 18:14:23 GMT"
    formatting_0_0 = Formatting([])
    str_4 = formatting_0_0.format_headers(str_2)
    print(str_4)
    str_5 = formatting_0_0.format_headers(str_3)
    print(str_5)


# Generated at 2022-06-25 18:52:25.981847
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    environment = Environment()
    environment.colors = Environment.Colors()
    environment.colors.body = Environment.Color()
    environment.colors.body.__dict__['256'] = True
    environment.color_scheme = '@(163)'
    environment.stream = io.TextIOWrapper(io.BufferIO())
    setattr(environment.stream, '_CHUNK_SIZE', 0)
    setattr(environment.stream, 'buffer', io.BytesIO())
    setattr(environment.stream, 'encoding', 'utf-8')
    setattr(environment.stream, 'errors', None)
    setattr(environment.stream, 'line_buffering', False)
    setattr(environment.stream, 'newlines', None)
    setattr(environment.stream, 'raw', None)
    str_0

# Generated at 2022-06-25 18:52:29.411430
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    val_0 = "application/json"
    val_1 = "Conversion"
    obj_0 = getattr(Conversion, "get_converter")(val_0)
    assert type(obj_0).__name__ == val_1

# Generated at 2022-06-25 18:52:31.154703
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = ''
    assert Conversion.get_converter(mime) is None



# Generated at 2022-06-25 18:52:35.777518
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Case 1
    format_0 = Conversion.get_converter("application/json")
    assert format_0 != None
    
    # Case 2
    format_0 = Conversion.get_converter("xml")
    assert format_0 == None
    
    # Case 3
    format_0 = Conversion.get_converter("")
    assert format_0 == None

# Generated at 2022-06-25 18:52:39.451289
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "mime"
    assert is_valid_mime(mime)
    assert Conversion.get_converter(mime)
    mime = "test"
    assert not is_valid_mime(mime)
    assert not Conversion.get_converter(mime)


# Generated at 2022-06-25 18:52:48.873606
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = "application/json"
    converter_0 = Conversion.get_converter(mime_0)
    assert converter_0 != None

    mime_0 = "application/json"
    converter_0 = Conversion.get_converter(mime_0)
    assert converter_0 != None

    mime_0 = "application/json"
    converter_0 = Conversion.get_converter(mime_0)
    assert converter_0 != None

    mime_0 = "application/json"
    converter_0 = Conversion.get_converter(mime_0)
    assert converter_0 != None

    mime_0 = "text/plain"
    converter_0 = Conversion.get_converter(mime_0)
    assert converter_0 == None

    mime_

# Generated at 2022-06-25 18:52:55.900769
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_plugin_0 = Conversion.get_converter('application/json')
    converter_plugin_1 = Conversion.get_converter('application/json')
    if (converter_plugin_0 is not None and converter_plugin_1 is not None):
        converter_plugin_0.output_encoding = 'UTF-8'
        converter_plugin_0.output_encoding = 'UTF-8'


# Generated at 2022-06-25 18:52:58.324238
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = None
    formatting_0 = Formatting(list_0)
    headers_0 = "a"
    assert formatting_0.format_headers(headers_0) == "a"



# Generated at 2022-06-25 18:53:06.081271
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    list_0 = [""]
    formatting_0 = Formatting(list_0)
    mime_0 = "application/json"
    content_0 = ""
    str_0 = formatting_0.format_body(content_0, mime_0)
    str_1 = formatting_0.format_body(content_0, mime_0)


# Generated at 2022-06-25 18:53:09.329051
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test cases
    # Normal test case.
    # Input string is empty (b'')
    # Input string is empty (b'')
    # Input string is not empty, but headers are not present
    # Input string is not empty, but headers are not present
    # Input string is not empty, headers are present
    # Input string is not empty, headers are present
    assert formatting_0.format_headers(b'') == b''

# Generated at 2022-06-25 18:53:26.483202
# Unit test for constructor of class Formatting
def test_Formatting():

    list_0 = None
    assert isinstance(Formatting(list_0), Formatting) is True



# Generated at 2022-06-25 18:53:29.161328
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_1 = None
    formatting_1 = Formatting(list_1)
    str_2 = ''
    str_3 = formatting_1.format_headers(str_2)
    assert str_3 == ''


# Generated at 2022-06-25 18:53:30.907141
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # verify that the function returns the expected result
    assert(Conversion.get_converter("application/json") == None)


# Generated at 2022-06-25 18:53:40.749788
# Unit test for constructor of class Formatting

# Generated at 2022-06-25 18:53:43.638100
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    list_0 = None
    formatting_0 = Formatting(list_0)
    str_0 = 'application/json'
    conversion_0 = Conversion.get_converter(str_0)
    assert conversion_0 is not None


# Generated at 2022-06-25 18:53:45.751468
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting.format_headers(Formatting)


# Generated at 2022-06-25 18:53:48.033516
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    arg_0 = None
    formatting_0 = Formatting(arg_0)
    arg_1 = ""
    formatting_0.format_headers(arg_1)


# Generated at 2022-06-25 18:53:50.397476
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = "text/css"
    converter_0 = Conversion.get_converter(mime_0)
    assert converter_0 is not None


# Generated at 2022-06-25 18:53:55.996222
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie import assembler
    from httpie.plugins import PrettyPlugin
    from hypothesis import given, example, settings
    from hypothesis.strategies import text

    @given(url=text(), method=text(), body=text(), headers=assembler.headers())
    @settings(max_examples=20, deadline=None)
    @example('/', '/', '/', {})
    def test(url, method, body, headers):
        request = assembler.Request(url, method, body, headers)
        content_type = request.headers['Content-Type']
        converter = Conversion.get_converter(content_type)
        content = request.body if converter is None else converter.encode(request.body)

        pretty_plugin = PrettyPlu

# Generated at 2022-06-25 18:54:02.370252
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.converter import ConverterPlugin
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.config import Config
    from httpie.output.streams import (
        get_output_stream,
        get_response_stream,
        get_error_stream
    )
    from httpie.input import ParseError
    from httpie.core import main as httpie
    from httpie.context import Environment
    from httpie.input import ParseError
    from httpie.config import Config
    from httpie.output.streams import (
        get_output_stream,
        get_response_stream,
        get_error_stream
    )

    ################################################################################
    # Test for Environment for

# Generated at 2022-06-25 18:54:35.539609
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        list_0 = None
        formatting_0 = Formatting(list_0)
    except Exception as inst:
        print(type(inst))
        print(inst.args)
        print(inst)
    else:
        print("No exception! Excellent!")



# Generated at 2022-06-25 18:54:47.680291
# Unit test for constructor of class Formatting
def test_Formatting():
    dict_0 = {}
    dict_0['http_version'] = 303
    dict_0['path'] = 'skit'
    dict_0['protocol'] = 'hTtp'
    dict_0['status'] = 303
    http_request_0 = HttpRequest(dict_0)
    http_request_0.path = 'fS5'
    dict_0['url'] = 'V7M'
    dict_0['http_version'] = 'HTTP/1.1'
    dict_0['data'] = ''
    dict_0['path'] = '.'
    dict_0['status'] = ''
    dict_0['url'] = '>'
    dict_0['data'] = '}'
    dict_0['status'] = '5<'
    dict_0['url'] = 'o'

# Generated at 2022-06-25 18:54:50.402394
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = PluginManager(None).get_formatters_grouped()
    formatting_0 = Formatting(list_0)
    assert_equals(formatting_0.format_headers(None), None)


# Generated at 2022-06-25 18:54:52.232240
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = []
    env = Environment()
    kwargs = {}
    obj = Formatting(groups, env, **kwargs)

    assert obj is not None

# Generated at 2022-06-25 18:54:53.659750
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter(mime='application/json')


# Generated at 2022-06-25 18:55:04.344298
# Unit test for constructor of class Formatting
def test_Formatting():
    print('Case 1: No group is provided')
    # Test case 1
    list_0 = []
    formatting_0 = Formatting(list_0)
    print('Expected: No input')
    print('Actual:', formatting_0)
    print()

    print('Case 2: A group containing an invalid element is provided')
    # Test case 2
    list_1 = ['invalid group']
    formatting_1 = Formatting(list_1)
    print('Expected: No input')
    print('Actual:', formatting_1)
    print()

    print('Case 3: A group containing valid elements is provided')
    # Test case 3
    list_2 = ['headers']
    formatting_2 = Formatting(list_2)
    print('Expected: Formatters')

# Generated at 2022-06-25 18:55:10.189565
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    set_0 = set()
    list_0 = list()
    list_1 = list()
    set_0.add(list_0)
    set_0.add(list_1)
    formatting_0 = Formatting(list(set_0))
    headers_0 = ''
    str_0 = formatting_0.format_headers(headers_0)
    assert str_0 == ''


# Generated at 2022-06-25 18:55:12.757947
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = None
    formatting_0 = Formatting(list_0)
    str_0 = ""
    str_1 = formatting_0.format_headers(str_0)
    assert str_1 is not None



# Generated at 2022-06-25 18:55:18.268571
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    header_path = os.path.join('..','..','..', 'test', '_test_data', 'httpbin', 'headers.json')

    with open(header_path, 'r') as f:
        headers_text = f.read()

    formatting_0 = Formatting(["colors", "format"])

    # Defect #13: No converter available for MIME type:
    mime = 'text/plain'
    formatted_headers = formatting_0.format_headers(headers_text)
    assert formatted_headers == headers_text, "Text/plain not formatted"

    mime = 'application/json'
    formatted_headers = formatting_0.format_headers(headers_text)
    assert formatted_headers != headers_text, "application/json not formatted"

    mime = 'text/html'
    formatted_

# Generated at 2022-06-25 18:55:20.507202
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_plugin_0 = Conversion.get_converter('/')
    assert converter_plugin_0 == None


# Generated at 2022-06-25 18:56:25.853419
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert callable(Conversion.get_converter)
    assert isinstance(Conversion.get_converter("text/plain"), ConverterPlugin)


# Generated at 2022-06-25 18:56:29.160745
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
  # Create an instance of Environment class
  env = Environment()
  # Create an instance of Formatting class
  formatting_0 = Formatting()
  content_0 = "Q2Fm"
  mime_0 = "application/json"
  result_0 = formatting_0.format_body(content_0, mime_0)


# Generated at 2022-06-25 18:56:34.931971
# Unit test for constructor of class Formatting
def test_Formatting():
    list_1 = []
    try:
        formatting_1 = Formatting(list_1)
        assert False, "Expected AssertionError"
    except AssertionError as ae:
        if str(ae) != "groups must not be empty":
            raise ae
    list_2 = []
    converter_2 = Conversion.get_converter("text/html")
    formatting_2 = Formatting(list_2)

# Generated at 2022-06-25 18:56:36.109824
# Unit test for constructor of class Formatting
def test_Formatting():
    with pytest.raises(TypeError):
        Formatting(list_0)

# Generated at 2022-06-25 18:56:40.858915
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('applicarion/json')
    assert converter != None
    assert converter.name == 'json'
    converter = Conversion.get_converter('application/json')
    assert converter != None
    assert converter.name == 'json'
    converter = Conversion.get_converter('application/j')
    assert converter == None


# Generated at 2022-06-25 18:56:44.774431
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    list_0 = ['json', 'color']
    str_0 = 'Access-Control-Allow-Credentials: true'
    formatting_0 = Formatting(list_0)
    assert str_0 == formatting_0.format_headers(str_0)


# Generated at 2022-06-25 18:56:52.004543
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion_0 = None
    conversion_1 = Conversion()
    conversion_2 = Conversion()
    conversion_3 = Conversion()
    conversion_4 = Conversion()
    conversion_5 = Conversion()
    conversion_6 = Conversion()
    conversion_7 = Conversion()
    conversion_8 = Conversion()
    conversion_9 = Conversion()

    conversion_10 = Conversion()
    conversion_11 = Conversion()
    conversion_12 = Conversion()
    conversion_13 = Conversion()
    conversion_14 = Conversion()
    conversion_15 = Conversion()
    conversion_16 = Conversion()
    conversion_17 = Conversion()
    conversion_18 = Conversion()
    conversion_19 = Conversion()

    conversion_20 = Conversion()
    conversion_21 = Conversion()
    conversion_22 = Conversion()
    conversion_23 = Conversion()
    conversion_24 = Conversion()


# Generated at 2022-06-25 18:56:54.789218
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = "4I ->C"
    list_0 = str_0.split()
    list_1 = list_0
    conversion_0 = Conversion()
    converter_plugin_0 = conversion_0.get_converter(list_1)

# Generated at 2022-06-25 18:56:57.948750
# Unit test for constructor of class Formatting
def test_Formatting():
  # Data flow coverage
  list_0 = ['json', 'json', 'json', 'json']
  formatting_0 = Formatting(list_0)
  # Control flow coverage
  if True:
    print('test_Formatting')


# Generated at 2022-06-25 18:57:03.273649
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt = Formatting(['colors'], headers_include_pattern='(?i){}')
    raw = '''HTTP/1.1 200 OK
Server: nginx/1.12.1
Date: Sun, 18 Feb 2018 11:13:28 GMT
Content-Type: application/json
Content-Length: 14
Connection: keep-alive

{"id": 42}'''
    formatted = fmt.format_headers(raw)
    assert formatted == 'HTTP/1.1 200 OK'
    assert fmt.format_headers('') == ''
