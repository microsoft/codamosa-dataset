

# Generated at 2022-06-25 18:49:32.327399
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(['pretty', 'colors'])


# Generated at 2022-06-25 18:49:36.414298
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = ''
    f = Formatting([])
    output = f.format_headers(headers)
    assert output == ''
    headers = ''
    parm_1 = 'application/json'
    output = f.format_body(headers, parm_1)
    assert output == ''

# Generated at 2022-06-25 18:49:41.162391
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_11 = '`nJ2<ww_sq>h2\x0b'
    obj_5 = Formatting([str_11], Environment())
    str_1 = '`nJ2<ww_sq>h2\x0b'
    t17 = obj_5.format_headers(str_1)


# Generated at 2022-06-25 18:49:46.321742
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    obj_0 = Formatting(groups=['json', 'colors'])
    str_0 = 'Content-Type'
    str_1 = 'application/json'
    str_2 = 'Content-Type: application/json'
    str_3 = obj_0.format_headers(str_1)

    assert(str_2 == str_3, 'AssertionError')


# Generated at 2022-06-25 18:49:48.386209
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['group 1', 'group 2']
    test_formatting = Formatting(groups)
    print(test_formatting)


# Generated at 2022-06-25 18:49:50.366344
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    for _ in range(4):
        test_Formatting_format_headers_0()
        test_Formatting_format_headers_1()


# Generated at 2022-06-25 18:49:52.139186
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '_Yf\x1b'
    var_0 = Conversion.get_converter(str_0)


# Generated at 2022-06-25 18:49:55.847946
# Unit test for constructor of class Formatting
def test_Formatting():
    c = Formatting(['all'], style='fancy')
    c.format_headers('h')


# Generated at 2022-06-25 18:50:01.113185
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = '\x03oW\x0b\x0b'
    str_1 = '\x0b\x0b\x0b'
    str_2 = '\x07\x0b\x0b'

    others_0 = Formatting(str_0, str_1)
    tmp_0 = others_0.format_body(str_2, str_2)


# Generated at 2022-06-25 18:50:10.141923
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'XWRsUdN3LsjwY\x0c'
    str_1 = 'ZWlC\x0c'
    str_2 = 'lw{}@\x0c'
    str_3 = '\x0c'
    var_0 = Formatting([str_2.format(str_0), str_2.format(str_1)], env=Environment(),
                    _colors=True, _format=str_3, _theme='solarized')
    str_4 = '<textarea\x20name="message"\x20rows="10"\x20cols="100"></textarea>'
    str_5 = 'application/xhtml+xml'
    var_1 = var_0.format_body(str_4, str_5)

#

# Generated at 2022-06-25 18:50:17.486143
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    in_1 = 'application/xml'
    arg_1 = in_1.encode()
    in_2 = '<?xml version="1.0" encoding="UTF-8"?>'
    arg_2 = in_2.encode()
    in_3 = 'terminal, rainbow'
    in_4 = Environment()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 18:50:18.733354
# Unit test for constructor of class Formatting
def test_Formatting():
    p = Formatting.get_converter('_Yf\x1b')


# Generated at 2022-06-25 18:50:21.055681
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = [
        '5',
        '6',
        '2',
        '1',
    ]
    assert_Formatting(groups)


# Generated at 2022-06-25 18:50:32.214460
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Create object of class Conversion
    obj_0 = Conversion()
    # Create object of class Environment

# Generated at 2022-06-25 18:50:36.286229
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    env = Environment()
    Formatter = Formatting(env=env)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 18:50:38.478293
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = []
    env = Environment()
    myUnitTest = Formatting(groups, env=env, **kwargs)


# Generated at 2022-06-25 18:50:42.868655
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    arg0 = ''
    arg1 = ''
    arg2 = ''
    arg3 = ''

    ret0 = ''
    try:
        format_headers(arg0, arg1, arg2, arg3)
    except Exception as e:
        pass

    assert(ret0 == '')
    return


# Generated at 2022-06-25 18:50:48.873109
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
	str_0 = '_Yf\x1b'
	env_0 = Environment()
	formatting_0 = Formatting(str_0, env_0)
	str_1 = '|\x1a4\x16\x11;\x1a\x1ej\x0e\x0c\x1e\x10)'
	str_2 = ";\x1a\x1ej\x0e\x0c\x1e\x10)"
	test_Formatting_format_headers_0(formatting_0, str_1, str_2)


# Generated at 2022-06-25 18:50:51.091295
# Unit test for constructor of class Formatting
def test_Formatting():
    mime = ''
    env = Environment()


# Generated at 2022-06-25 18:50:52.281341
# Unit test for constructor of class Formatting
def test_Formatting():
    assert callable(Formatting)


# Generated at 2022-06-25 18:50:57.175795
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["HTTP"]
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)



# Generated at 2022-06-25 18:51:01.520429
# Unit test for constructor of class Formatting
def test_Formatting():
    # Call the constructor
    groups_0 = ['test', 'test']
    env_0 = Environment()
    try:
        Formatting(groups_0, env_0)
    except:
        raise AssertionError('Constructor of class `Formatting` call failed.')


# Generated at 2022-06-25 18:51:02.700693
# Unit test for constructor of class Formatting
def test_Formatting():
    test_case_0()


# Generated at 2022-06-25 18:51:11.342815
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    conversion_0 = Conversion()
    classes = plugin_manager.get_formatters_grouped()

# Generated at 2022-06-25 18:51:17.081855
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # 
    for i in range(0, 10):
        str_0 = test_case_0()
        obj_0 = Formatting(groups=[], env=None, **None)
        str_1 = obj_0.format_headers(str_0)
        if len(str_0) > 0:
            print(str_0)



# Generated at 2022-06-25 18:51:20.700623
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["#", "0"]
    env = Environment()
    kwargs = {"env": Environment(), "plugin": test_case_0}
    formatters = Formatting(groups, env, **kwargs)
    assert formatters


# Generated at 2022-06-25 18:51:30.612390
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = '_Yf\x1b'
    str_1 = ''
    str_2 = 'X-Powered-By: PHP/7.0.0RC1\r\nSet-Cookie: PHPSESSID=jj0o6j9mq3qjvqqq7enu1idfu3; path=/\r\nContent-Length: 4338\r\nVary: Accept-Encoding\r\nDate: Wed, 06 Apr 2016 07:31:02 GMT\r\nServer: LiteSpeed\r\nConnection: Keep-Alive\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n'
    str_3 = 'http'
    str_4 = '_Yf\x1b'
    str_5 = 'iterable'

# Generated at 2022-06-25 18:51:31.640426
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    header_0 = ''
    str_0 = ''


# Generated at 2022-06-25 18:51:36.889435
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Parameters for the get_converter method
    arg_mime = 'text/plain'
    
    # Calling the function
    result = Conversion.get_converter(arg_mime)

    # Assertion
    assert result == None



# Generated at 2022-06-25 18:51:39.602689
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    obj = Conversion()
    obj.get_converter = MagicMock(return_value = None)
    assert obj.get_converter() == None



# Generated at 2022-06-25 18:51:45.808271
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # set up
    groups = ['colors']
    fmt = Formatting(groups)
    headers = 'Content-Type: application/json'

    # act
    formatted = fmt.format_headers(headers)

    # assert
    print(formatted)
    assert '\x1b[37m' in formatted


# Generated at 2022-06-25 18:51:51.700292
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        format_list = ['formatters-text']
        fmt = Formatting(format_list)
        headers = 'Content/Type: text/plain'
        content = 'Hello world!'
        headers = fmt.format_headers(headers)
        content = fmt.format_body(content, 'text/plain')
        fmt.format_body(content, 'text/plain')
    except Exception as e:
        print(e)
    print(fmt) # Use for debugging


# Generated at 2022-06-25 18:51:53.907218
# Unit test for constructor of class Formatting
def test_Formatting():
    for y in range(0, 1000):
        groups = ['escape', 'colors', 'styles']
        env = Environment()
        Formatting(groups, env=Environment())


# Generated at 2022-06-25 18:51:56.041497
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert len(Formatting([], environment.Environment(), **{}).format_body('formatting', 'formatting')) == 1


# Generated at 2022-06-25 18:51:59.601189
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['isEsc']
    env = Environment()
    kwargs = {'isEsc': True}
    formatting = Formatting(groups, env, **kwargs)
    assert len(formatting.enabled_plugins) == 1
    assert formatting.enabled_plugins[0].name == 'isEsc'
    assert formatting.enabled_plugins[0].isEsc == True

# Unit tests for format_headers method of class Formatting

# Generated at 2022-06-25 18:52:03.812496
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    for name in ['base', 'colors']:
        env = Environment()
        env.config['colors'] = True
        formatting = Formatting([name], env=env) 
        assert isinstance(formatting.format_headers(""), str)


# Generated at 2022-06-25 18:52:05.232462
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    for i in range(4):
        test_case_0()


# Generated at 2022-06-25 18:52:07.420081
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format_headers_0 = Formatting([], )
    format_headers_0.format_headers(str_0)


# Generated at 2022-06-25 18:52:11.972622
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=['color'])
    assert f.format_headers('X: 1\nY: 2') == '\x1b[94mX\x1b[0m: 1\n\x1b[94mY\x1b[0m: 2'


# Generated at 2022-06-25 18:52:13.782973
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    obj = Conversion()
    mime = None
    return obj.get_converter(mime)


# Generated at 2022-06-25 18:52:17.845324
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = '_Yf\x1b'
    groups = []
    f = Formatting(groups)


# Generated at 2022-06-25 18:52:18.585953
# Unit test for constructor of class Formatting
def test_Formatting():
    pass


# Generated at 2022-06-25 18:52:29.364020
# Unit test for constructor of class Formatting

# Generated at 2022-06-25 18:52:38.205878
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['bcolors']
    env = Environment()
    kwargs = {}
    m = Formatting(groups, env, kwargs)
    headers = "HTTP/1.1 200 OK\r\n\r\n"
    m.format_headers(headers)
    headers = "HTTP/1.1 200 OK\r\nConnection: close\r\n\r\n"
    m.format_headers(headers)
    headers = "GET / HTTP/1.1\r\nHost: example.org\r\nConnection: close\r\n\r\n"
    m.format_headers(headers)
    headers = "GET /test/test HTTP/1.1\r\nHost: example.org\r\nConnection: close\r\n\r\n"
    m.format_headers

# Generated at 2022-06-25 18:52:47.446041
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = list()
    kwargs_0 = dict()
    env_0 = Environment()

    class Foo:
        def __init__(self, **kwargs):
            self.enabled = True
            self.env = kwargs['env']

        def format_headers(self, headers):
            return headers

        def format_body(self, content, mime):
            return content

    class PluginManager:
        def get_formatters_grouped(self):
            return {
                'group_0': [Foo]
            }

    plugin_manager.get_formatters_grouped = PluginManager().get_formatters_grouped

    formatting_0 = Formatting(groups_0, env_0, **kwargs_0)



# Generated at 2022-06-25 18:52:48.879479
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test = Conversion()
    assert test.get_converter(None) == None


# Generated at 2022-06-25 18:52:58.137618
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    env = Environment()
    kwargs = {}
    # Case 0
    groups = ["colors", "format", "json", "theme"]
    formatting = Formatting(groups, env, **kwargs)
    headers = '_Yf\x1b'
    content = '_Yf\x1b'
    res_0 = formatting.format_headers(headers)
    res_1 = formatting.format_body(content, '_Yf\x1b')
    expected_0 = '_Yf\x1b'
    expected_1 = '_Yf\x1b'
    assert res_0 == expected_0
    assert res_1 == expected_1

# Generated at 2022-06-25 18:53:10.368738
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-25 18:53:14.540966
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["c", "d", "e", "f", "g", "h"]
    env = Environment()
    obj_0 = Formatting(groups, env)


# Generated at 2022-06-25 18:53:16.691960
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = '_Yf\x1b'

    # Call the method
    # Conversion.get_converter(mime)




# Generated at 2022-06-25 18:53:23.037933
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '`nJ2<ww_sq>h2\x0b'
    tmp_0 = Formatting([], Environment())
    var_0 = tmp_0.format_headers(str_0)
    return var_0

test_case_0()
test_Formatting_format_headers()

# Generated at 2022-06-25 18:53:24.088299
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')



# Generated at 2022-06-25 18:53:26.925959
# Unit test for constructor of class Formatting
def test_Formatting():
    obj_0 = Formatting(['test'], env=Environment())
    obj_0 = Formatting(['test'], env=Environment(), exe='test')


# Generated at 2022-06-25 18:53:28.925297
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'formatters']
    env = Environment()
    formatting = Formatting(groups, env)


# Generated at 2022-06-25 18:53:29.420759
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting()

# Generated at 2022-06-25 18:53:32.272000
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = Conversion()
    str_0 = 'Bt*f'
    var_1 = is_valid_mime(str_0)
    var_2 = Conversion.get_converter(str_0)


# Generated at 2022-06-25 18:53:34.598355
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        str_0 = '<3f/p#_!G'
        var_0 = Conversion.get_converter(str_0)
    except:
        pass



# Generated at 2022-06-25 18:53:35.659636
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert test_case_0()

# Generated at 2022-06-25 18:53:37.476564
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # TODO: Write a unit test for format_headers of class Formatting
    raise NotImplementedError


# Generated at 2022-06-25 18:53:42.617993
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers_0 = '>\x15<\x07?{x\x06Q\x1dl'
    var_0 = Formatting(groups=['colors'])
    result_0 = var_0.format_headers(headers_0)
    assert result_0 == '>\x15<\x07?{x\x06Q\x1dl'


# Generated at 2022-06-25 18:53:47.600597
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '5(3#{r&rBc%/\x0b'
    var_0 = Conversion.get_converter(str_0)

# Generated at 2022-06-25 18:53:49.247616
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)


# Generated at 2022-06-25 18:53:50.141842
# Unit test for constructor of class Formatting
def test_Formatting():
    assert True


# Generated at 2022-06-25 18:53:59.976931
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''X-XSS-Protection: 1; mode=block
X-Content-Type-Options: nosniff
X-Download-Options: noopen
X-Permitted-Cross-Domain-Policies: none
Referrer-Policy: strict-origin-when-cross-origin
X-Powered-By: ASP.NET
Strict-Transport-Security: max-age=31536000
Cache-Control: private
Date: Sat, 09 May 2020 15:01:27 GMT
Content-Type: text/html; charset=utf-8
Server: Microsoft-IIS/10.0
X-AspNet-Version: 4.0.30319
X-Powered-By: ASP.NET
Content-Length: 7554
'''
    fmt = Formatting(['headers'], styles=True)

# Generated at 2022-06-25 18:54:04.384554
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    for x in range(10): # Number of invocation
        for y in range(100): # Level of recursion
            str_0 = '`nJ2<ww_sq>h2\x0b'
            obj_0 = Formatting(str_0)
            str_0 = '`nJ2<ww_sq>h2\x0b'
            str_0 = '`nJ2<ww_sq>h2\x0b'
            str_1 = obj_0.format_headers(str_0)



# Generated at 2022-06-25 18:54:07.458694
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0: List[str] = [
        'application/json',
    ]
    env_var_0 = Environment()
    formatting_obj_0 = Formatting(groups_0, env_var_0)


# Generated at 2022-06-25 18:54:10.586743
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        groups = [str(),]
        test_Formatting_0 = Formatting(groups, env=Environment(), **kwargs)
        test_Formatting_1 = Formatting(groups, env=Environment(), **kwargs)
    except Exception as e:
        raise e
    else:
        pass


# Generated at 2022-06-25 18:54:12.852087
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_1 = '~gCc:_n,6U'
    var_1 = Formatting(['simple'], {})
    var_1.format_headers(str_1)


# Generated at 2022-06-25 18:54:15.425538
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    obj_0 = Conversion()
    str_0 = 'C,y#]nj2<ww_sq>h2\x0b'
    var_0 = obj_0.get_converter(str_0)


# Generated at 2022-06-25 18:54:21.266943
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['PythonFormatter']
    kwargs = {'style': 'parrot', 'colors': 'no', 'format': 'json'}
    env = Environment()
    env.config['style'] = 'parrot'
    env.colors = 'no'
    env.stdout.isatty = True
    env.stdout.encoding = 'UTF-8'
    env.stdin.encoding = 'UTF-8'
    Formatting(groups, env, **kwargs)

# Generated at 2022-06-25 18:54:26.975697
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Parameters for var_0
    str_0 = 'wPl/Ao#l V'
    result = Conversion.get_converter(str_0)
    assert False  # Test not implemented


# Generated at 2022-06-25 18:54:30.853487
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'], style='solarized')
    print(f.enabled_plugins)
    str_1 = '\x0b'
    mime_1 = 'charset=utf-8'
    var_1 = f.format_body(str_1, mime_1)
    print(var_1)


# Generated at 2022-06-25 18:54:32.565080
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = []
    kwargs = {}
    _formatting = Formatting(groups, **kwargs)


# Generated at 2022-06-25 18:54:35.940184
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = Conversion()

    str_0 = '`nJ2<ww_sq>h2\x0b'
    var_1 = is_valid_mime(str_0)

    if var_1:
        var_2 = var_0.get_converter(str_0)


# Generated at 2022-06-25 18:54:39.340689
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # This method is a stub, but it will not be considered an error
    # if you fail to implement it.
    pass

# Generated at 2022-06-25 18:54:49.410577
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class Dummy:
        def __init__(self):
            self.enabled = True
        def format_headers(self, str1):
            return str1
    class Dummy2:
        def __init__(self):
            self.enabled = False
        def format_headers(self, str1):
            return str1
    dummy = Dummy()
    dummy2 = Dummy2()
    formatting = Formatting(lst1=[], env=Environment())
    input_str = '*'
    expected_str = '*'
    var_0 = formatting.format_headers(input_str)
    assert var_0 == expected_str

    formatting.enabled_plugins.append(dummy)
    var_0 = formatting.format_headers(input_str)
    assert var_0 == expected_str
    formatting.enabled_

# Generated at 2022-06-25 18:54:50.084249
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    var_6 = Formatting(["All"])


# Generated at 2022-06-25 18:55:01.003790
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = '\x1e\x1e\x1e\x1b\x1b\x1e\x1a\x1a\x1b\x1a\x1b\x1e\x1a\n\x1a\x1e\x1e\x1a'
    str_1 = '\x7fI\\\x13\x1c\x01\x11\x02\x12\x01\x14\x07\x10\x01\x0e\x1a\x12\x03\x0f\x0b\x15'
    obj = Formatting(['color'], colors=256)
    function_1 = obj.format_body
    str_2 = function_1(str_0, str_1)
    assert str_

# Generated at 2022-06-25 18:55:11.106067
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = list()
    groups.append('colors')
    groups.append('formatters')
    groups.append('colors')
    groups.append('colors')
    groups.append('colors')
    groups.append('colors')
    groups.append('colors')
    groups.append('colors')
    groups.append('colors')
    groups.append('formatters')
    groups.append('colors')
    groups.append('colors')
    header_0 = 'c\x0f\x07\x1f/a\x1a8u\x0f.\x0f'
    var_0 = Formatting(groups)
    var_1 = var_0.format_headers(header_0)


# Generated at 2022-06-25 18:55:12.523110
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = 'multipart/form-data'
    var_0 = Conversion.get_converter(mime_0)


# Generated at 2022-06-25 18:55:17.618709
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = []
    fmt = Formatting(groups)


# Generated at 2022-06-25 18:55:21.628018
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '`nJ2<ww_sq>h2\x0b'
    var_0 = is_valid_mime(str_0)
    var_1 = Conversion.get_converter(str_0)


# Generated at 2022-06-25 18:55:24.736930
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '\x1b\x1a*Plk^'
    var_0 = is_valid_mime(str_0)
    var_1 = Conversion.get_converter(str_0)

#Unit test for method format_body of class Formatting

# Generated at 2022-06-25 18:55:28.504548
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    fm = Formatting(groups=['colors'], env=Environment())
    body = fm.format_body('{}', 'application/json')
    assert body == '{}'

if __name__ == '__main__':
    test_case_0()
    test_Formatting_format_body()

# Generated at 2022-06-25 18:55:38.405931
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '`nJ2<ww_sq>h2\x0b'
    var_0 = is_valid_mime(str_0)
    str_1 = 'Content-Type: text/plain'
    var_1 = Formatting.get_converter(str_0)
    if var_0:
        if var_1:
            pass
        pass
    else:
        print('Invalid MIME type')

    str_2 = 'Content-Type: text/plain'
    var_2 = str_2.split(':')
    str_3 = 'text/plain'
    var_3 = is_valid_mime(str_3)
    if var_3:
        num_0 = (int(var_2[-1].strip()))
        print(num_0)
   

# Generated at 2022-06-25 18:55:48.383543
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import scenario_0
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins import BuiltinPlugin
    from httpie.plugins import ConverterPlugin
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.colors import ColorsFormatter
    from httpie.output.formatters.colors import ColorsPlugin
    from httpie.output.formatters.colors import SolarizedColors
    from httpie.output.formatters.headers import HeadersFormatter
    from httpie.output.formatters.convert import ConvertPlugin
    from httpie.output.formatters.convert import Converter
    from httpie.output.formatters.colors import SolarizedColors


# Generated at 2022-06-25 18:55:50.782985
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'application/json'
    obj_0 = Conversion.get_converter(str_0)


# Generated at 2022-06-25 18:55:52.666518
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = []
    obj_0 = Formatting(groups)
    assert obj_0



# Generated at 2022-06-25 18:55:57.353670
# Unit test for constructor of class Formatting
def test_Formatting():
    str_0 = ']3<\x0bp$u@H8\x14]F3g'
    try:
        Formatting(str_0)
    except AttributeError:
        pass


# Generated at 2022-06-25 18:55:59.741920
# Unit test for constructor of class Formatting
def test_Formatting():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 18:56:08.003993
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_1 = 'type/type'
    var_1 = Conversion.get_converter(str_1)

    assert isinstance(var_1, ConverterPlugin)
    assert var_1.mime == str_1


# Generated at 2022-06-25 18:56:14.047766
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.cli.argtypes import KeyValueArg
    groups = ['colors']
    print(groups)
    kwargs = {'stream': sys.stdin, 'headers': [KeyValueArg('b', 'c')]}
    print(kwargs)
    env = Environment()
    print(env)
    a = Formatting(groups, env, **kwargs)
    str_1 = a.format_headers('a')
    print(str_1)



# Generated at 2022-06-25 18:56:17.483879
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment(isatty=True, stdout_isatty=True)
    format_writer = Formatting(groups, env=env)


# Generated at 2022-06-25 18:56:27.156832
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    fmt = Formatting(groups)
    content = 'Hello world!'
    mime = 'text/plain'
    result = fmt.format_body(content, mime)

# Generated at 2022-06-25 18:56:34.242610
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = []
    str_0 = '`nJ2<ww_sq>h2\x0b'
    str_1 = '`nJ2<ww_sq>h2\x0b'
    formatting_instance_0 = Formatting(groups, str_0, str_1)
    str_2 = '`nJ2<ww_sq>h2\x0b'
    str_0 = formatting_instance_0.format_headers(str_2)
    assert str_0 == '`nJ2<ww_sq>h2\x0b'


# Generated at 2022-06-25 18:56:38.707164
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    str_0 = 'x-www-form-urlencoded'
    str_1 = '{"foo": "bar"}'
    formatting_0 = Formatting(['pretty', 'colors'], False, False)
    str_2 = formatting_0.format_body(str_1, str_0)
    assert str_2 is not None


# Generated at 2022-06-25 18:56:41.588991
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = '/z-2'
    var_0 = is_valid_mime(mime_0)
    var_1 = Conversion.get_converter(mime_0)


# Generated at 2022-06-25 18:56:50.089978
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    obj = Formatting(groups=['colors', 'colors_256_bg'], env=env)
    payload = '''HTTP/1.1 200 OK
Connection: close
Date: Mon, 19 Jun 2017 17:49:50 GMT
Content-Length: 4
Content-Type: application/json; charset=UTF-8
Server: gunicorn/19.7.1

null'''
    assert obj.format_headers(payload) == '''HTTP/1.1 200 OK
Connection: close
Date: Mon, 19 Jun 2017 17:49:50 GMT
Content-Length: 4
Content-Type: application/json; charset=UTF-8
Server: gunicorn/19.7.1

null'''


# Generated at 2022-06-25 18:56:58.278303
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '`nJ2<ww_sq>h2\x0b'
    str_1 = '`nJ2<ww_sq>h2\x0b'
    str_2 = '`nJ2<ww_sq>h2\x0b'
    str_3 = '`nJ2<ww_sq>h2\x0b'
    str_4 = '`nJ2<ww_sq>h2\x0b'
    str_5 = '`nJ2<ww_sq>h2\x0b'
    str_6 = '`nJ2<ww_sq>h2\x0b'
    str_7 = '`nJ2<ww_sq>h2\x0b'

# Generated at 2022-06-25 18:57:06.262580
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '`nJ2<ww_sq>h2\x0b'
    obj_0 = Conversion.get_converter(str_0)
    str_1 = 'e'
    obj_1 = Conversion.get_converter(str_1)
    str_2 = '`nJ2<ww_sq>h2\x0b'
    obj_2 = Conversion.get_converter(str_2)
    str_3 = 'e'
    obj_3 = Conversion.get_converter(str_3)
    str_4 = '`nJ2<ww_sq>h2\x0b'
    obj_4 = Conversion.get_converter(str_4)
    str_5 = 'e'

# Generated at 2022-06-25 18:57:20.518711
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '`nJ2<ww_sq>h2\x0b'
    var_0 = is_valid_mime(str_0)
    var_1 = Conversion.get_converter(str_0)


# Generated at 2022-06-25 18:57:24.566093
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter(None) == None
    assert Conversion.get_converter('') == None
    assert Conversion.get_converter('application/json') != None



# Generated at 2022-06-25 18:57:26.936630
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = Conversion()
    str_0 = '`nJ2<ww_sq>h2\x0b'
    var_0 = is_valid_mime(str_0)



# Generated at 2022-06-25 18:57:29.978515
# Unit test for constructor of class Formatting
def test_Formatting():
    groups : List[str] = ['Test group']
    env = Environment()

# Generated at 2022-06-25 18:57:33.561047
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    available_plugins = plugin_manager.get_formatters_grouped()
    disable_str = "default"
    # Invoke the function under test
    f = Formatting([disable_str])
    str_0 = 'w{8>\x14\x19\x0c'
    # noinspection SpellCheckingInspection
    result = f.format_body(str_0, "text/html")
    assert result == str_0


# Generated at 2022-06-25 18:57:35.016589
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str1 = 'application/json'
    var_0 = is_valid_mime(str1)



# Generated at 2022-06-25 18:57:40.010116
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    fmt = Formatting(groups=groups, env=env)
    assert fmt.enabled_plugins is not None, "Error in function Formatting.__init__(): Failed to create enabled_plugins"


# Generated at 2022-06-25 18:57:43.395870
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '`nJ2<ww_sq>h2\x0b'
    f = Formatting(['bcolors'])
    assert f.format_headers(headers) == '`nJ2<ww_sq>h2\x0b'

# Generated at 2022-06-25 18:57:44.472016
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = []
    Formatting(groups)


# Generated at 2022-06-25 18:57:52.471730
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Case 0
    str_0 = '`nJ2<ww_sq>h2\x0b'
    var_0 = is_valid_mime(str_0)
    converter = Conversion.get_converter(str_0)
    # Case 1
    str_0 = ''
    var_0 = is_valid_mime(str_0)
    converter = Conversion.get_converter(str_0)
    # Case 2
    str_0 = '4zV&\t\u0014\u000f'
    var_0 = is_valid_mime(str_0)
    converter = Conversion.get_converter(str_0)
    # Case 3
    str_0 = '6\x0b\x16q'
    var_0 = is_valid_mime

# Generated at 2022-06-25 18:58:14.833107
# Unit test for constructor of class Formatting
def test_Formatting():
    var_0 = Formatting(None)


# Generated at 2022-06-25 18:58:18.830829
# Unit test for constructor of class Formatting
def test_Formatting():
    import httpie
    env = httpie.context.Environment()
    groups = ['colors', 'colors_256']
    formatting = Formatting(groups, env=env)
    assert formatting
    assert formatting.enabled_plugins


# Generated at 2022-06-25 18:58:29.004557
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = '`nJ2<ww_sq>h2\x0b'
    var_0 = is_valid_mime(str_0)
    var_1 = set()
    var_2 = list()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_8 = dict()
    var_9 = dict()
    var_10 = dict()
    var_11 = dict()
    var_12 = dict()
    var_13 = dict()
    var_14 = dict()
    var_15 = dict()
    var_16 = dict()
    var_17 = dict()
    var_18 = dict()
    var_19 = dict()
    var_20 = dict()

# Generated at 2022-06-25 18:58:31.218503
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'a/b'
    obj_0 = Conversion.get_converter(str_0)

# unit test for method format_headers of class Formatting

# Generated at 2022-06-25 18:58:41.459962
# Unit test for constructor of class Formatting
def test_Formatting():
    env_0 = Environment(True)
    arg_0 = ['devices', 'networks', 'phonelocators']
    var_0 = Formatting(arg_0, env_0)
    str_0 = 'ev^5"QZ\x0c'
    arg_1 = var_0.format_headers(str_0)
    if not arg_1:
        var_1 = (0, 1)
    else:
        var_1 = (1, 0)
    var_2 = Environment()
    arg_2 = ['devices', 'networks', 'phonelocators']
    var_3 = Formatting(arg_2, var_2)
    str_1 = 'GGWG\nTc%'
    mime = '<LmjZd'
    arg_3 = var_3.format

# Generated at 2022-06-25 18:58:42.412520
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = '1,jW8=vZ'
    var_0 = Conversion.get_converter(str_0)



# Generated at 2022-06-25 18:58:48.297900
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting = Formatting(['colors','auto'])
    converter = Conversion.get_converter('jpg')
    content = 'Test'
    assert formatting.format_body(content, 'json') == 'Test'
    assert formatting.format_body(content, 'jpg') == converter.encode(content)
    assert formatting.format_body(content, 'text/csv') == 'Test'
    assert formatting.format_body(content, 'pdf') == 'Test'


# Generated at 2022-06-25 18:58:51.835020
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'b''V7\r\x0c\x1d'
    var_0 = is_valid_mime(str_0)

    str_1 = 'cx\x1d\x0c\x02\x02'
    output = Conversion.get_converter((str_0 +  str_1))
    assert isinstance(output, list)



# Generated at 2022-06-25 18:58:54.941986
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['A', 'B', 'C']
    env = Environment()
    f = Formatting(groups, env)


# Generated at 2022-06-25 18:59:01.585158
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    kwargs_0 = {'headers': '', 'env': Environment(), 'groups': []}
    test_object_0 = Formatting(**kwargs_0)
    try:
        result_0 = getattr(test_object_0, 'format_headers', )(str_0)
    except Exception as err_0:
        result_0 = err_0
    try:
        assert result_0 == str_0
    except AssertionError as err_1:
        raise AssertionError(err_1)
