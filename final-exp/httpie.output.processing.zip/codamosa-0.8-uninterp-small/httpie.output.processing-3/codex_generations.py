

# Generated at 2022-06-25 18:49:33.191279
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = 'text/plain'
    var_1 = Conversion.get_converter(var_0)


# Generated at 2022-06-25 18:49:39.639399
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    import httpie.plugins.converter
    # Safely call the function under testing
    try:
        Output = Conversion.get_converter(var_entrypoint)
    except Exception as e:
        # Record any unexpected result
        assert False, f'Test failed due to un-expected exception: {e}'
    else:
        # Verify the expected result
        assert Output == mock_result, f'Test failed: expected {mock_result}, but got {Output}'


# Generated at 2022-06-25 18:49:49.241099
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        assert callable(Conversion.get_converter)
    except:
        print("Method 'get_converter' of class 'Conversion' should be callable")
        raise AssertionError
    arg_0 = 'foo'
    try:
        assert isinstance(Conversion.get_converter(arg_0), ConverterPlugin)
    except:
        print("Method 'get_converter' of class 'Conversion' should return a ConverterPlugin instance")
        raise AssertionError
    try:
        assert Conversion.get_converter(arg_0).mime == arg_0
    except:
        print("Method 'get_converter' of class 'Conversion' should return a ConverterPlugin instance with parameterized mime attribute")
        raise AssertionError

# Generated at 2022-06-25 18:49:51.279964
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Parameter headers is of type NoneType
    headers = None
    # Instantiation of class Formatting with parameter groups=['']
    obj_Formatting = Formatting([''])
    # Invoke method
    var_0 = Formatting.format_headers(obj_Formatting, headers)
    assert type(var_0) == unicode
    assert var_0 == headers


# Generated at 2022-06-25 18:49:55.157353
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        Formatting([])
    except Exception:
        assert False
    print('All test cases passed.')


# Generated at 2022-06-25 18:50:01.365465
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'formatters']
    env = Environment()
    formatting = Formatting(groups, env)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'Colors'
    assert formatting.enabled_plugins[1].__class__.__name__ == 'JSONFormatter'
    assert formatting.enabled_plugins[2].__class__.__name__ == 'Pretty'
    assert formatting.enabled_plugins[3].__class__.__name__ == 'TableFormatter'



# Generated at 2022-06-25 18:50:02.537713
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    obj = Conversion()
    obj.get_converter("text/csv")

# Generated at 2022-06-25 18:50:05.671440
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = 'https://google.com'
    var_0 = is_valid_mime(mime_0)
    var_1 = Conversion.get_converter(mime_0)


# Generated at 2022-06-25 18:50:12.986349
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    try:
        var_0 = None
        var_1 = MIME_RE.match(var_0)
        var_3 = is_valid_mime(var_1)
        var_5 = plugin_manager.get_converters()
        var_5 = var_5[0]
        var_5 = var_5(var_1)
        var_5 = var_5.supports(var_1)
        var_6 = Conversion()
        var_6 = var_6.get_converter(var_1)
    except Exception as instance:
        print(instance)
    else:
        print(var_6)


# Generated at 2022-06-25 18:50:16.765342
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    input = 'file 1\nFile 2\nFile 3\n'
    output = Formatting(['colors']).format_body(input, 'text/plain')
    assert output == '\x1b[32mfile 1\x1b[39m\n\x1b[32mFile 2\x1b[39m\n\x1b[32mFile 3\x1b[39m\n'


# Generated at 2022-06-25 18:50:32.243459
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    #function entry, parameter initialization
    groups = []
    env = Environment()
    kwargs = {}
    #count the number of 'installed' plugins
    #count = 0
    #for _class in plugin_manager.get_formatters_grouped():
    #    if _class.installed:
    #        count += 1
    #if count > 0:
    #    groups.append('installed')
    groups.append("colors")
    groups.append("format")
    groups.append("colors")
    fm = Formatting(groups, env, **kwargs)
    r = fm.format_headers("""Content-Type: text/html; charset=utf-8\r\nContent-Length: 127\r\n\r\n""")

# Generated at 2022-06-25 18:50:37.126610
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    params = {'mime': 'text/plain'}
    conversion = Conversion()

    output = conversion.get_converter('text/plain')
    assert output is not None

    output = conversion.get_converter('application/json')
    assert output is not None


# Generated at 2022-06-25 18:50:46.743335
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Positive tests
    assert is_valid_mime('text/plain')
    assert is_valid_mime('image/jpeg')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/octet-stream')
    # Negative tests
    assert not is_valid_mime(None)
    assert not is_valid_mime('')
    assert not is_valid_mime('/')
    assert not is_valid_mime('//')
    assert not is_valid_mime('test')
    assert not is_valid_mime('text')
    assert not is_valid_mime('test/')
    assert not is_valid_mime('test/test')
    assert not is_valid_mime('te/st')
    assert not is_valid_

# Generated at 2022-06-25 18:50:48.561607
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/plain'
    obj = Conversion.get_converter(mime)
    assert obj != None


# Generated at 2022-06-25 18:50:52.189347
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Setup
    mime = 'text/plain'
    # Method call 
    # Return type constraints
    assert isinstance(Conversion.get_converter(mime), ConversionPlugin)

# Generated at 2022-06-25 18:50:52.744680
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_case_0()

# Generated at 2022-06-25 18:50:55.589566
# Unit test for constructor of class Formatting
def test_Formatting():
    groups_0 = []
    env_0 = []
    kwargs_0 = {}
    Formatting(groups_0, env_0, **kwargs_0)


# Generated at 2022-06-25 18:51:05.167362
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env=Environment()
    funcObj = Formatting(['default', 'colors'], env=env)
    funcargs = { 'content':"{'code':'SUCCESS'}", 'mime':'text/plain'}
    real = funcObj.format_body(**funcargs)
    assert_equal(real, '\x1b[39m{\x1b[32m\x1b[39m\x1b[32m\'code\'\x1b[39m\x1b[32m:\x1b[39m\x1b[32m\'SUCCESS\'\x1b[39m\x1b[32m}\x1b[39m\x1b[39m\n')


# Generated at 2022-06-25 18:51:12.773265
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    for _ in range(1000):
        str_0 = '{:n}'.format(random.randint(0, 65535))
        str_1 = '·'
        str_2 = ''
        str_3 = 'cxyuVF'
        str_4 = '2zZ1)'
        str_5 = '{:n}'.format(random.randint(-32768, 32767))
        str_6 = '{:n}'.format(random.randint(-32768, 32767))
        str_7 = 'xvNg~'
        str_8 = '{:n}'.format(random.randint(0, 65535))
        str_9 = '$ý'
        str_10 = 'h'
        str_11 = 'âÝ'

# Generated at 2022-06-25 18:51:14.076466
# Unit test for constructor of class Formatting
def test_Formatting():
    # Loading an existing formatter

    # Loading a converter
    test_case_0()

# Generated at 2022-06-25 18:51:20.336960
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'text/plain'
    assert Conversion.get_converter(str_0) is None


# Generated at 2022-06-25 18:51:21.275556
# Unit test for constructor of class Formatting
def test_Formatting():
    # Case 0
    test_case_0()

# Generated at 2022-06-25 18:51:23.033415
# Unit test for constructor of class Formatting

# Generated at 2022-06-25 18:51:26.077255
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_0 = 'text/plain'
    obj_0 = Conversion.get_converter(str_0)
    assert_true( obj_0 != None )


# Generated at 2022-06-25 18:51:28.770677
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    args = []
    content = str_0
    mime = str_0
    ret = Formatting.format_body(content, mime)
    assert ret == content
    return ret


# Generated at 2022-06-25 18:51:31.626919
# Unit test for constructor of class Formatting
def test_Formatting():
    test_list = ['red', 'green', 'blue']
    env = Environment()
    test_object_0 = Formatting(test_list, env)
    test_object_1 = Formatting(test_list, env)


# Generated at 2022-06-25 18:51:36.501109
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['JSON', 'HTML', 'Colors']
    kwargs = {}
    fmt = Formatting(groups, env, **kwargs)
    assert fmt.enabled_plugins.__len__() == 3



# Generated at 2022-06-25 18:51:38.229295
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    #
    # Impossible case
    #
    pass



# Generated at 2022-06-25 18:51:41.875526
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'text/plain'
    obj_0 = Formatting(['colors'])
    assert obj_0.format_headers(str_0) == 'text/plain'
    assert obj_0.format_headers(str_0) == 'text/plain'


# Generated at 2022-06-25 18:51:46.826566
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    # mime=str_0; content=str_1
    content = '{}'
    groups = ['colors', 'format']
    mime = 'application/json'
    env = Environment()
    mime = 'application/json'

    p = Formatting(groups, env=env, colors=True)
    print(p)
    #output = p.format_body(content, mime)
    #print(output)


# Generated at 2022-06-25 18:51:55.465202
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test with bool input
    bool_0 = False

    # Test with str input
    str_0 = "abc"

    mime = ""
    if (is_valid_mime(mime)):
        converter = Conversion.get_converter(mime)
        # AssertionError: Conversion.get_converter(mime) != None
        print(converter)


# Generated at 2022-06-25 18:51:57.734258
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = Conversion()
    var_1 = 'text/plain'
    obj_0 = var_0.get_converter(var_1)


# Generated at 2022-06-25 18:52:05.277666
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Conversion.get_converter('tf') should not be None
    groups = ['highlight']
    env = Environment(stdout=None)
    kwargs = {'format':'colors', 'colors':None}
    formattingObj = Formatting(groups, env, **kwargs)
    mime = 'tensorflow/tensorboard'
    content = '{\n  "w": [\n    0,\n    0\n  ],\n  "b": 0\n}'
    fmt_body = formattingObj.format_body(content, mime)

# Generated at 2022-06-25 18:52:06.523108
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print("Test case 0...")
    test_case_0()
    print("Done")

# Generated at 2022-06-25 18:52:07.972102
# Unit test for constructor of class Formatting
def test_Formatting():
    var_1 = Formatting(['json', 'colors'])


# Generated at 2022-06-25 18:52:10.047273
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = []
    env = None
    f = Formatting(groups, env)


# Generated at 2022-06-25 18:52:18.608770
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatters_by_group = {
        'colors': ['ANSI', 'Color'],
        'colors-ext': ['ANSI256', 'ANSI', 'Color'],
        'format': ['JSON', 'JSONLines', 'JSONStream'],
        'format-ext': ['JSONStream', 'JSONLines', 'JSON'],
        'syntax': ['HTML', 'Pretty'],
        'syntax-ext': ['Pretty', 'HTML']
    }
    formatters = plugin_manager.get_formatters_grouped()

    # Testing formats
    formats = [
        'colors', 'colors-ext', 'format', 'format-ext', 'syntax', 'syntax-ext'
    ]
    for format in formats:
        for plugin in formatters_by_group[format]:
            assert plugin in format

# Generated at 2022-06-25 18:52:20.742494
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = [str() for _ in range(4 + 1)]
    var_0 = Formatting(groups)


# Generated at 2022-06-25 18:52:25.516633
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    var_0 = [
                    
                    
        ]
    var_1 = Environment()
    var_2 = Formatting(var_0, var_1)
    var_3 = "headers"
    var_4 = var_2.format_headers(var_3)
    pass


# Generated at 2022-06-25 18:52:31.381139
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = 'geometry/basic-polygon'
    var_0 = is_valid_mime(var_0)
    if var_0:
        var_1 = plugin_manager.get_converters()
        for var_3 in var_1:
            if var_3.supports(var_0):
                var_2 = var_3(var_0)
    else:
        var_2 = None
    pass



# Generated at 2022-06-25 18:52:44.615953
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Initialize objects
    #  from httpie.plugins import ConverterPlugin
    groups = ["json", "html"]
    formatting = Formatting(groups, env=Environment())
    headers = "Content-Type: application/json"

    # Assertions
    assert formatting.format_headers(headers) == "Content-Type: application/json"


# Generated at 2022-06-25 18:52:55.303748
# Unit test for constructor of class Formatting
def test_Formatting():
    # variable to hold the available plugins
    available_plugins = None
    # variable to hold the instance of the class Formatting
    obj_0 = None
    # variable to hold the enabled plugins
    enabled_plugins = None
    # variable to hold the Environment object
    env_0 = None
    # variable to hold the group names
    groups = None
    # variable to hold the keyword arguments
    kwargs = None
    # variable to hold the headers
    headers = None
    # variable to hold the status of the headers
    status_0 = None
    # variable to hold the content
    content = None
    # variable to hold the status of the content
    status_1 = None
    # variable to hold the content mime type
    mime = ''
    # variable to hold the status of the mime type
    status_2 = None
    #

# Generated at 2022-06-25 18:52:57.403314
# Unit test for constructor of class Formatting
def test_Formatting():
    # Create a new instance of class Formatting
    obj = Formatting()
    print("The type of Formatting object is %s" % type(obj))


# Generated at 2022-06-25 18:53:00.473862
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers_0 = ['user-agent: /', 'host: localhost', 'accept: json']
    groups_0 = ['headers']
    env_0 = Environment()
    o_0 = Formatting(groups_0, env_0)
    o_1 = o_0.format_headers(headers_0)


# Generated at 2022-06-25 18:53:04.947974
# Unit test for constructor of class Formatting
def test_Formatting():
    bool_0 = False
    list_0 = ['json']
    object_0 = Formatting(list_0)
    str_0 = object_0.format_body(bool_0, bool_0)
    str_1 = object_0.format_headers(bool_0)

# Generated at 2022-06-25 18:53:06.097856
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    bool_0 = bool()
    var_0 = Conversion.get_converter(bool_0)


# Generated at 2022-06-25 18:53:12.349776
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    obj_0 = Formatting(["HTTPie", "Base", "HTTPie"], env=Environment(), format_options={})
    str_0 = "HTTP/1.1 200 OK\r\n"
    str_1 = "Content-Type: application/json\r\n"
    str_2 = "Content-Length: 2\r\n\r\n"
    str_3 = str_0 + str_1 + str_2
    str_4 = obj_0.format_headers(str_3)


# Generated at 2022-06-25 18:53:20.667467
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    
    # Unit test for method format_headers of class Formatting
    def test_Formatting_format_headers():
        from httpie.plugins.builtin import HeadersFormatter
        # Unit test for method format_body of class Formatting
        def test_Formatting_format_body():
            from httpie.plugins.builtin import JSONFormatter
            from httpie.plugins.builtin import PrettyOptions
            from httpie.plugins.builtin import PrettyFormatter

# Generated at 2022-06-25 18:53:23.911586
# Unit test for constructor of class Formatting
def test_Formatting():
    bool_0 = True
    str_0 = '0R<~I-0$'
    var_1 = Formatting(bool_0, str_0)
    bool_0 = False
    str_1 = ''
    var_2 = Formatting(bool_0, str_1)


# Generated at 2022-06-25 18:53:33.054114
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    try:
        bool_0 = True
        bool_1 = False
        var_0 = Formatting(groups=bool_1, env=bool_0)
        bool_2 = bool_1
        bool_3 = bool_1
        str_0 = var_0.format_headers(headers=bool_3)
        str_1 = str_0
        assert str_1 == bool_2
    except:
        assert False


# Generated at 2022-06-25 18:53:55.874726
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['JSON']
    env = Environment()
    env.stdout = None
    env.format = None
    env.pretty = None
    env.print_headers = None
    env.style = None
    env.style_defs = ""
    env.style_file = None
    env.style_enable_file = None
    env.style_enable_stdout = None
    env.style_force_colors = None
    env.colors = None
    env.table = None
    env.table_format = None
    env.download_dir = None
    env.default_options = None
    env.default_options_overwrite = None
    env.default_options_save = None
    env.max_redirects = None
    env.max_threads = None
    env.timeout = None
   

# Generated at 2022-06-25 18:53:58.522797
# Unit test for constructor of class Formatting
def test_Formatting():
    formatter = Formatting(['colors'], )
    assert formatter.enabled_plugins[0].enabled == True


# Generated at 2022-06-25 18:54:00.390676
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    bool_0 = False
    var_0 = is_valid_mime(bool_0)
    var_1 = Conversion.get_converter(bool_0)


# Generated at 2022-06-25 18:54:03.400559
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    # Arrange: create a list of plugins with different names and call format_headers with an empty string
    plugins = [FormattingPlugin1(), FormattingPlugin2()]
    result = Formatting("", plugins).format_headers("")

    # Assert: Check if the result isn't empty, because then headers are formatted
    assert len(result) != 0



# Generated at 2022-06-25 18:54:07.537854
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_1 = Conversion()
    bool_1 = True
    # Test for valid MIME
    var_2 = var_1.get_converter(bool_1)
    # Test for invalid MIME
    var_3 = var_1.get_converter(bool_1)


# Generated at 2022-06-25 18:54:09.814633
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['group']
    env = Environment()
    headers = 'headers'
    formatting = Formatting(groups = groups, env = env)

    formatting.format_headers(headers = headers)



# Generated at 2022-06-25 18:54:11.478126
# Unit test for constructor of class Formatting
def test_Formatting():
    obj = Formatting(groups=["colors", "formatters"], env=Environment(), **{'style': 'fluent'})


# Generated at 2022-06-25 18:54:16.625201
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    text_0 = "text/plain"
    text_1 = "text/html"
    text_2 = "text/css"
    text_3 = "text/javascript"

    if text_0 == "text/plain":
        print("text is plain")
    elif text_1 == "text/html":
        print("text is html")
    elif text_2 == "text/css":
        print("text is css")
    elif text_3 == "text/javascript":
        print("text is javascript")

# Generated at 2022-06-25 18:54:21.630467
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = [("json",), ("json",)]
    env = Environment()
    kwargs = {"colors": 256}
    try:
        var_1 = Formatting(groups, env=env, **kwargs)
        assert isinstance(var_1, Formatting)
    except:
        var_1 = None
    assert isinstance(var_1, Formatting)


# Generated at 2022-06-25 18:54:31.633496
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.registry import plugin_manager

    class TestConverter01(ConverterPlugin):
        name = "test-converter-01"
        mimes = ("application/test",)

        def encode(self, obj, **kwargs):
            pass

        def decode(self, s, **kwargs):
            pass

    class TestConverter02(ConverterPlugin):
        name = "test-converter-02"
        mimes = ("application/test",)

        def encode(self, obj, **kwargs):
            pass

        def decode(self, s, **kwargs):
            pass


    plugin_manager.register(TestConverter01)
    plugin_manager.register(TestConverter02)

    # Test for case '02,04,13'
    var_

# Generated at 2022-06-25 18:54:49.451015
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    str_0 = 'content-type: text/html'
    var_0 = Formatting(str_0)
    print('Expected: content-type: text/html\nActual: %s' % var_0)
    assert var_0 == 'content-type: text/html'


# Generated at 2022-06-25 18:54:59.643865
# Unit test for constructor of class Formatting
def test_Formatting():
    accept_type = "application/json"
    full = False
    style = "colors"
    formatters = ['json', 'colors']
    e = Environment()
    f = Formatting(formatters, env=e, style=style, full=full)
    headers_str = "HTTP/1.1 200 OK\r\nHeader1: Value1\r\nHeader2: Value2"
    headers_str2 = f.format_headers(headers_str)
    print(headers_str2)
    conv = Conversion.get_converter(accept_type)
    content_str = conv.dump({'a': 1, 'b': 2})
    content_str2 = f.format_body(content_str, accept_type)
    print(content_str2)


# Generated at 2022-06-25 18:55:06.226966
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Make instance of environment with arguments from command-line
    env = Environment(colors=None, stdin_isatty=True, stdout_isatty=True,
                               style=None, default_options=[],
                               output_options=['format'])
    # Make instance of Formatting
    formatting = Formatting(['colors', 'format'], env=env)
    # Make instance of Response
    response = Response(b'{"count": 3}', headers={'Content-Type': 'application/json'})
    # Make instance of formatting
    mime = response.headers['Content-Type']
    content = response.raw.data
    res = formatting.format_body(content, mime)
    assert res == b'{\n    "count": 3\n}\n'



# Generated at 2022-06-25 18:55:07.890526
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    p = Formatting(["json"])
    p.format_headers("{}")


# Generated at 2022-06-25 18:55:15.925421
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test for method get_converter of class Conversion
    groups = [
        "colors",
        "colors.headers",
        "colors.body",
    ]
    environment = Environment()
    environment.config['format'] = ['all']
    # formatting = Formatting(groups, env=environment)
    # body_content = '''{\n  "args": {}, \n  "headers": {\n    "Connection": "close", \n    "Content-Length": "13", \n    "Content-Type": "application/json", \n    "Date": "Wed, 15 Jul 2020 22:43:14 GMT", \n    "Host": "httpbin.org", \n    "User-Agent": "python-requests/2.23.0"\n  }, \n  "origin": "x.x.x.

# Generated at 2022-06-25 18:55:21.947743
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    cli_args = HeadersPrettyPlugin
    formatting = Formatting(groups=['headers'], env=env, cli_args=cli_args)
    headers=''
    __tracebackhide__ = True
    assert formatting.format_headers(headers)== ''
    # write your unit test here


# Generated at 2022-06-25 18:55:23.629324
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['color', 'formatter']
    obj = Formatting(groups, env)


# Generated at 2022-06-25 18:55:25.838097
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/html'
    var_0 = Conversion.get_converter(mime)


# Generated at 2022-06-25 18:55:27.199975
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(groups=[])

# Generated at 2022-06-25 18:55:28.286300
# Unit test for constructor of class Formatting
def test_Formatting():
    var_0 = Formatting(['BinaryResponseProcessors'])


# Generated at 2022-06-25 18:55:53.437869
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    case_0 = "*"
    fmt = Conversion()
    var_0 = fmt.get_converter(case_0)
    # var_0 should instance of class ConverterPlugin


# Generated at 2022-06-25 18:55:57.852838
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors"]
    kwargs = {'arg': None, 'style': None}
    env = Environment()
    f = Formatting(groups, env,**kwargs)
    assert f.enabled_plugins


# Generated at 2022-06-25 18:56:01.304272
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    line_0 = 'text/plain'
    data_0 = Conversion.get_converter(line_0)
    if (data_0 != None):
        data_0.to_ValueError()
    else:
        data_0 = line_0
    assert data_0 == line_0


# Generated at 2022-06-25 18:56:03.364664
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    var_0 = "text/json"
    var_1 = Formatting()
    var_2 = var_1.format_body(var_0)


# Generated at 2022-06-25 18:56:06.165411
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Case 0
    test_case_0()



# Generated at 2022-06-25 18:56:08.737998
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["a", "b", "c"]
    env = Environment()
    env.add_parameter({"a": 10})
    f = Formatting(groups, env)
    assert f.enabled_plugins == []


# Generated at 2022-06-25 18:56:09.972019
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert format_headers('headers') == 'headers', 'Assertion failed'


# Generated at 2022-06-25 18:56:11.452465
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    data = "test_data"
    mime = "test_mime"
    assert Formatting.format_body(data, mime) == data


# Generated at 2022-06-25 18:56:13.688646
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    arg0 = ['colors']
    object_0 = Formatting(arg0, env)


# Generated at 2022-06-25 18:56:17.685755
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env=Environment()
    headers=""""""""
    # init Formatting class
    obj=Formatting(groups=[""],env=env)
    res=obj.format_headers(headers)
    assert res == headers


# Generated at 2022-06-25 18:57:01.085129
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    groups = list(available_plugins.keys())
    env = Environment()
    fmt = Formatting(groups, env)


# Generated at 2022-06-25 18:57:02.725472
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_0 = "text/plain"
    obj_0 = Conversion.get_converter(mime_0)


# Generated at 2022-06-25 18:57:06.419660
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    var_0 = Conversion()
    str1 = "fCqMbbqdNqim.NyFQoY.N_EjRK.wGoMbhmfYhJvHdS"
    var_0.get_converter(str1)


# Generated at 2022-06-25 18:57:11.374746
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups_0 = ['indent', 'colors']
    env_0 = Environment()
    content_0 = 'This is a test string'
    mime_0 = 'test_0/test_0'
    formatting_0 = Formatting(groups_0)
    formatting_1 = formatting_0.format_body(content_0, mime_0)


# Generated at 2022-06-25 18:57:19.192325
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt = Formatting(groups=['colors'])
    assert fmt
    headers = """HTTP/1.1 200 OK
Date: Tue, 28 Jul 2015 20:23:03 GMT
Content-Type: application/json
Transfer-Encoding: chunked
Connection: keep-alive
Server: gunicorn/19.3.0
Vary: Accept-Encoding
X-Frame-Options: DENY
Content-Language: en
Strict-Transport-Security: max-age=31536000

"""
    out = fmt.format_headers(headers)
    assert out

# Generated at 2022-06-25 18:57:21.920754
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    case_0 = Formatting(['colors', 'colors'])
    assert case_0.format_headers(str(2)) == str(2)


# Generated at 2022-06-25 18:57:26.464336
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter(('application/json'))
    assert converter is not None
    converter = Conversion.get_converter(('text/xml'))
    assert converter is not None
    converter = Conversion.get_converter(('executable/binary'))
    assert converter is None


# Generated at 2022-06-25 18:57:29.126449
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    var_0 = Formatting(groups = ["auto"])
    var_1 = "Content-Type: text/plain"
    var_2 = var_0.format_headers(headers = var_1)
    assert isinstance(var_2, str)


# Generated at 2022-06-25 18:57:30.907264
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["group0"]
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env=env, **kwargs)


# Generated at 2022-06-25 18:57:33.125073
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    bool_0 = False
    arg_0 = "text/plain"
    class_0 = Conversion
    var_0 = class_0.get_converter(bool_0)
    var_1 = class_0.get_converter(arg_0)


# Generated at 2022-06-25 18:59:10.811129
# Unit test for constructor of class Formatting
def test_Formatting():
    try:
        formatter = Formatting(["Colors", "Formatters"])
        assert True
    except:
        assert False


# Generated at 2022-06-25 18:59:17.015626
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    catch_headers = {'Content-Type': 'text/html; charset=UTF-8', 'Server': 'nginx', 'X-Content-Type-Options': 'nosniff', 'Content-Length': '2195', 'Connection': 'keep-alive', 'X-XSS-Protection': '1; mode=block', 'Date': 'Sat, 11 Nov 2017 17:44:44 GMT', 'X-Frame-Options': 'SAMEORIGIN'}

    formatting = Formatting(groups=['colors', 'headers', 'format'], env=Environment())
    headers = formatting.format_headers(catch_headers)
    print(headers)



# Generated at 2022-06-25 18:59:17.721521
# Unit test for constructor of class Formatting
def test_Formatting():
    var_0 = Formatting()


# Generated at 2022-06-25 18:59:19.219532
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    obj = Conversion()
    mime = ""
    ret = obj.get_converter(mime)
    assert ret is None



# Generated at 2022-06-25 18:59:20.490007
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    bool_0 = False
    test_var_0 = Conversion.get_converter(bool_0)


# Generated at 2022-06-25 18:59:24.022372
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.highlight import ColoredPygmentsHTTPieFormatter
    formatters = [ColoredPygmentsHTTPieFormatter()]
    obj_0 = Formatting([], formatters=formatters)
    var_0 = obj_0.format_body('', 'application/json')
