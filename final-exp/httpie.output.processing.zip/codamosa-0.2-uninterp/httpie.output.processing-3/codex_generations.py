

# Generated at 2022-06-17 20:45:38.849756
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')


# Generated at 2022-06-17 20:45:47.757816
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('application/pdf') is None
    assert Conversion.get_converter('application/vnd.openxmlformats-officedocument.wordprocessingml.document') is None
    assert Conversion.get_converter('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') is None

# Generated at 2022-06-17 20:46:00.863930
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.config = {}
    env.config_dir = None
    env.colors = 256
    env.style = None
    env.download_dir = None
    env.default_options = []
    env.auto_output = False
    env.output_options = []
    env.output_file = None
    env.output_dir = None
    env.output_encoding = 'utf8'
    env.output_in_terminal = True
    env.output_file_add_headers = False
    env.output_file_safe = False
    env.output_stream = None
    env.output_stream_encoding = None
   

# Generated at 2022-06-17 20:46:10.933855
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # test for mime type 'text/html'
    assert Conversion.get_converter('text/html') is not None
    # test for mime type 'text/plain'
    assert Conversion.get_converter('text/plain') is not None
    # test for mime type 'application/json'
    assert Conversion.get_converter('application/json') is not None
    # test for mime type 'application/xml'
    assert Conversion.get_converter('application/xml') is not None
    # test for mime type 'application/x-www-form-urlencoded'
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    # test for mime type 'application/octet-stream'

# Generated at 2022-06-17 20:46:15.974115
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:46:20.955004
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.config['colors'] = True
    env.config['format'] = ['colors']
    f = Formatting(['colors'], env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].env == env
    assert f.enabled_plugins[0].kwargs == {}

# Generated at 2022-06-17 20:46:32.377612
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/xml'
    assert formatting.format_body

# Generated at 2022-06-17 20:46:42.699989
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:46:51.359927
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-yml') is not None

# Generated at 2022-06-17 20:47:02.312383
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])
    assert Formatting(['colors', 'format'])
    assert Formatting(['colors', 'format', 'format_options'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options', 'colors_extras'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options', 'colors_extras', 'colors_extras_options'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options', 'colors_extras', 'colors_extras_options', 'colors_extras_options_options'])

# Generated at 2022-06-17 20:47:15.256473
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "city": "New York"}'
    #   mime = 'application/json'
    # Expected output:
    #   content = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    #

# Generated at 2022-06-17 20:47:25.702036
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name":"John", "age":30, "car":null}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

    # Test 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name":"John", "age":30, "car":null}'
    mime = 'text/plain'

# Generated at 2022-06-17 20:47:36.670797
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodedProcessor

    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.stdin_isatty = True
    env.is_windows = True
    env.colors = 256

    # Test for constructor of class Formatting
    # Test for case 1: groups = ['headers']
    # Expected: enabled_plugins = [HTTPHead

# Generated at 2022-06-17 20:47:41.499100
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1:
    # Input: mime = 'application/json'
    # Expected output: ConverterPlugin
    mime = 'application/json'
    assert isinstance(Conversion.get_converter(mime), ConverterPlugin)

    # Test case 2:
    # Input: mime = 'application/xml'
    # Expected output: ConverterPlugin
    mime = 'application/xml'
    assert isinstance(Conversion.get_converter(mime), ConverterPlugin)

    # Test case 3:
    # Input: mime = 'text/html'
    # Expected output: ConverterPlugin
    mime = 'text/html'
    assert isinstance(Conversion.get_converter(mime), ConverterPlugin)

    # Test case 4:
    # Input: mime

# Generated at 2022-06-17 20:47:51.763035
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
   

# Generated at 2022-06-17 20:48:04.363883
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrint0Processor
    from httpie.plugins.builtin import HTTPPrintProcessor
    from httpie.plugins.builtin import HTTPUnicodeProcessor
    from httpie.plugins.builtin import HTTPXMLProcessor
    from httpie.plugins.builtin import HTTPYAMLProcessor
    from httpie.plugins.builtin import HTTPHtmlProcessor
    from httpie.plugins.builtin import HTTPJsonProcessor
    from httpie.plugins.builtin import HTTPTableProcessor
    from httpie.plugins.builtin import HTTPXmlProcessor
    from httpie.plugins.builtin import HTTPYamlProcessor

# Generated at 2022-06-17 20:48:15.423790
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor, JSONProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    plugin_manager.add_formatters_grouped(
        'test', [HTTPHeadersProcessor, JSONProcessor])
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.config.default_options = []
    env.config.default_options.append('--pretty')
    env.config.default_options.append('all')
    env.config.default_options.append('--print')
    env.config.default_options.append('hb')
    env.config.default_options.append('--headers')
    env.config.default_options.append

# Generated at 2022-06-17 20:48:27.105442
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: '{"name": "John Doe", "age": 42}'
    #   - mime: 'application/json'
    # Expected output:
    #   - '{\n    "name": "John Doe",\n    "age": 42\n}'
    content = '{"name": "John Doe", "age": 42}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John Doe",\n    "age": 42\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   - content: '{"name": "John Doe", "age": 42}'
    #   - mime:

# Generated at 2022-06-17 20:48:34.992584
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/x-yaml'), ConverterPlugin)

# Generated at 2022-06-17 20:48:38.083455
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:48:50.318289
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test for empty headers
    headers = ""
    groups = ["colors"]
    env = Environment()
    f = Formatting(groups, env)
    assert f.format_headers(headers) == ""

    # test for headers with no color

# Generated at 2022-06-17 20:48:53.671499
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:49:03.991264
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"a": "b"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "a": "b"\n}'
    content = '{"a": "b"}'
    mime = 'application/json'
    assert Formatting(['json']).format_body(content, mime) == '{\n    "a": "b"\n}'

    # Test case 2:
    # Input:
    #   content: '{"a": "b"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "a": "b"\n}'
    content = '{"a": "b"}'

# Generated at 2022-06-17 20:49:12.733462
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:49:22.565516
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:49:24.691345
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter.mime == "application/json"


# Generated at 2022-06-17 20:49:31.416924
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n') == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: text/html; charset=utf-8\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:49:42.969355
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:49:54.223022
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
   

# Generated at 2022-06-17 20:50:05.460792
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert Conversion.get_converter('application/json').supports('application/json')
    assert not Conversion.get_converter('application/json').supports('text/html')
    assert not Conversion.get_converter('application/json').supports('application/xml')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8')

# Generated at 2022-06-17 20:50:10.911619
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': 'on'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:50:21.479531
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[36mOK\x1b[39m\r\n\x1b[37mContent-Type: \x1b[33mapplication/json\x1b[39m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    formatting = Formatting(groups)


# Generated at 2022-06-17 20:50:29.729368
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor
    from httpie.plugins.builtin import ZeroColorProcessor
    from httpie.plugins.builtin import ZeroStyleProcessor
    from httpie.plugins.builtin import ZeroThemeProcessor
    from httpie.plugins.builtin import ZeroWidthProcessor
    from httpie.plugins.builtin import ZeroWidthProcessor
    from httpie.plugins.builtin import ZeroWidthProcessor

# Generated at 2022-06-17 20:50:37.956511
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    groups = ['colors']
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    result = formatting.format_headers(headers)
    assert result == '\x1b[36mHTTP/1.1 200 OK\x1b[39m\r\n\x1b[33mContent-Type: application/json\x1b[39m\r\n\r\n'

    # Test case 2
    env = Environment()
    env.stdout = io.StringIO()
    env.std

# Generated at 2022-06-17 20:50:47.550132
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrettyURLEncodedProcessor
    from httpie.plugins.builtin import HTTPPrettyXMLProcessor
    from httpie.plugins.builtin import HTTPPrettyHTMLProcessor
    from httpie.plugins.builtin import HTTPPrettyMarkdownProcessor
    from httpie.plugins.builtin import HTTPPrettyTextProcessor
    from httpie.plugins.builtin import HTTPPrettyImageProcessor
    from httpie.plugins.builtin import HTTPPrettyPNGProcessor
    from httpie.plugins.builtin import HTTPPrettyJPGProcessor
    from httpie.plugins.builtin import HTTPPrettyGIFProcessor
    from httpie.plugins.builtin import HTTPPrettyBMPProcessor

# Generated at 2022-06-17 20:50:50.113456
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == []

# Generated at 2022-06-17 20:50:59.880122
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:51:10.446281
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert formatting.format_headers(headers) == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
   

# Generated at 2022-06-17 20:51:20.815886
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("text/html") is not None
    assert Conversion.get_converter("text/plain") is not None
    assert Conversion.get_converter("text/xml") is not None
    assert Conversion.get_converter("application/json; charset=utf-8") is not None
    assert Conversion.get_converter("application/xml; charset=utf-8") is not None
    assert Conversion.get_converter("text/html; charset=utf-8") is not None
    assert Conversion.get_converter("text/plain; charset=utf-8") is not None
    assert Conversion.get_converter

# Generated at 2022-06-17 20:51:31.192868
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None

# Generated at 2022-06-17 20:51:41.489130
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/text')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('json')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:51:50.153936
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:51:59.354716
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:52:09.548769
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodedProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor

# Generated at 2022-06-17 20:52:16.355949
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import debug
    from httpie.plugins.builtin import trace
    from httpie.plugins.builtin import verbose
    from httpie.plugins.builtin import warnings
    from httpie.plugins.builtin import zero_rtt


# Generated at 2022-06-17 20:52:20.936341
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': True}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[0].colors == True

# Generated at 2022-06-17 20:52:31.402835
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:52:41.125878
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test for empty headers
    headers = ""
    groups = ["colors"]
    formatting = Formatting(groups)
    assert formatting.format_headers(headers) == headers
    # test for headers with no colors
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12\r\n"
    assert formatting.format_headers(headers) == headers
    # test for headers with colors
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12\r\n"
    assert formatting.format_headers(headers) == headers


# Generated at 2022-06-17 20:52:48.578783
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "car": null}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    assert Formatting(['json']).format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

    # Test case 2:
    # Input:
    #   content = '{"name": "John", "age": 30, "

# Generated at 2022-06-17 20:53:01.218586
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/xml'
    assert formatting.format_body

# Generated at 2022-06-17 20:53:13.658900
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('multipart/form-data') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('application/pdf') is not None

# Generated at 2022-06-17 20:53:21.490076
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-yml') is not None
    assert Conversion

# Generated at 2022-06-17 20:53:32.650366
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups = ['colors']
    # Expected output:
    #   headers = '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']

# Generated at 2022-06-17 20:53:42.345354
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    #   groups: ['colors']
    #   env: Environment()
    #   kwargs: {}
    # Expected result:
    #   enabled_plugins: [ColorsFormatter]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert len(formatting.enabled_plugins) == 1
    assert isinstance(formatting.enabled_plugins[0], ColorsFormatter)

    # Test case 2:
    #   groups: ['colors', 'format']
    #   env: Environment()
    #   kwargs: {}
    # Expected result:
    #   enabled_plugins: [ColorsFormatter, FormatFormatter]
    groups = ['colors', 'format']
    env

# Generated at 2022-06-17 20:53:47.854108
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1: mime is valid
    mime = 'application/json'
    assert is_valid_mime(mime)
    converter = Conversion.get_converter(mime)
    assert converter.mime == mime

    # Test case 2: mime is invalid
    mime = 'application'
    assert not is_valid_mime(mime)
    converter = Conversion.get_converter(mime)
    assert converter is None


# Generated at 2022-06-17 20:54:01.418466
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Test for case 1:
    #   Input:
    #       content = '{"name": "httpie"}'
    #       mime = 'application/json'
    #   Expected output:
    #       '{\n    "name": "httpie"\n}'
    content = '{"name": "httpie"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "httpie"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test for case 2:
    #   Input:
    #       content = '{"name": "httpie"}'
    #       mime = 'application/xml'
    #   Expected output:
    #

# Generated at 2022-06-17 20:54:12.471207
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:54:25.557713
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.output.formatters.colors import ColorsFormatter
    from httpie.output.formatters.format import Formatter
    from httpie.output.formatters.json import JSONFormatter
    from httpie.output.formatters.utils import get_valid_json
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import HTTPiePlugin


# Generated at 2022-06-17 20:54:35.990478
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_conver

# Generated at 2022-06-17 20:54:46.433526
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_con

# Generated at 2022-06-17 20:55:02.186709
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.colors = 256
    env.compress_level = 6
    env.max_redirects = 10
    env.timeout = None
    env.headers = {}
    env.verify = True
    env.cert = None
    env.auth = None
    env.proxy = None
    env.allow_redirects = True
    env.follow_redirects = True
    env.download_dir = None
    env.download_filename = None

# Generated at 2022-06-17 20:55:13.256232
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:55:19.199727
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 13\r\n\r\n'
    assert formatting.format_headers(headers) == '\x1b[32mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[33mContent-Type: text/html; charset=utf-8\x1b[0m\r\n\x1b[33mContent-Length: 13\x1b[0m\r\n\r\n'

    # Test case 2

# Generated at 2022-06-17 20:55:29.004001
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:55:36.543614
# Unit test for method format_headers of class Formatting