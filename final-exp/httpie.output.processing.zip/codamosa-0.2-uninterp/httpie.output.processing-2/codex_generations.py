

# Generated at 2022-06-17 20:45:45.637146
# Unit test for constructor of class Formatting

# Generated at 2022-06-17 20:45:51.162886
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Date: Thu, 19 Sep 2019 09:41:24 GMT
Server: nginx/1.14.0 (Ubuntu)
Content-Length: 2
Connection: keep-alive

'''
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)
    headers = formatting.format_headers(headers)
    print(headers)


# Generated at 2022-06-17 20:45:52.833456
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 20:46:04.013924
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert not converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; a=b')
    assert not converter.supports('application/json; charset=utf-8; a=b;')
    assert not converter.supports('application/json; charset=utf-8; a=b; ')
    assert not converter.supports

# Generated at 2022-06-17 20:46:15.174512
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:46:22.785352
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:46:27.591289
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].style == 'solarized'
    assert formatting.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:46:39.414141
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name":"John","age":30,"car":null}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name":"John","age":30,"car":null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    formatting = Formatting(['json'])
    assert formatting.format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content = '{"name":"

# Generated at 2022-06-17 20:46:49.606114
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
Date: Sun, 25 Oct 2020 22:41:51 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Sun, 25 Oct 2020 22:41:51 GMT
ETag: "2a-58d6a3a9f9e80"
Accept-Ranges: bytes
Content-Length: 42
Vary: Accept-Encoding
Content-Type: text/html

<html><body><h1>It works!</h1></body></html>
'''

# Generated at 2022-06-17 20:47:01.599257
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json; charset=utf-8\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: keep-alive\r\n' \
              'Server: gunicorn/19.9.0\r\n' \
              'Date: Sun, 09 Dec 2018 08:46:44 GMT\r\n' \
              '\r\n' \
              '{}'
    result = formatting.format_headers(headers)

# Generated at 2022-06-17 20:47:15.173787
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import SyntaxHighlightFormatter
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import format_options_spec
    from httpie.plugins.builtin import format_options_spec_dict
    from httpie.plugins.builtin import format_options_spec_list
    from httpie.plugins.builtin import format_options_spec_str
    from httpie.plugins.builtin import format_options_spec_tuple
    from httpie.plugins.builtin import format_options_spec_set

# Generated at 2022-06-17 20:47:25.591441
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test case 1
    groups = ['colors']
    env = Environment()
    env.stdout_isatty = True
    env.is_windows = False
    env.colors = {'header': 'blue'}
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    f = Formatting(groups, env)
    assert f.format_headers(headers) == '\x1b[34mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[34mContent-Type: application/json\x1b[0m\r\n\r\n'

    # test case 2
    groups = ['colors']
    env = Environment()
    env.stdout_isatty = True


# Generated at 2022-06-17 20:47:30.092514
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:47:39.264270
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Tue, 10 Sep 2019 10:54:37 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Tue, 10 Sep 2019 10:54:37 GMT
ETag: "2d-58a9a9a1a7c40"
Accept-Ranges: bytes
Content-Length: 45
Content-Type: text/html

<html><body><h1>It works!</h1></body></html>
'''
    groups = ['colors', 'format', 'format-pretty']
    formatting = Formatting(groups)
    result = formatting.format_headers(headers)

# Generated at 2022-06-17 20:47:49.867916
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None

# Generated at 2022-06-17 20:48:02.636588
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups = ['colors']
    # Expected output:
    #   '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']

# Generated at 2022-06-17 20:48:06.157163
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])
    assert Formatting(['colors', 'format'])
    assert Formatting(['colors', 'format', 'format_options'])


# Generated at 2022-06-17 20:48:08.944340
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:48:18.259983
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Server: nginx
Date: Tue, 25 Feb 2020 15:08:27 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 9
Connection: keep-alive
Vary: Accept-Encoding
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
X-Content-Type-Options: nosniff

<!DOCTYPE html>
<html>
<head>
    <title>Hello</title>
</head>
<body>
    <h1>Hello World!</h1>
</body>
</html>'''
    f = Formatting(['colors'])

# Generated at 2022-06-17 20:48:20.884303
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'], env=Environment(), colors=True)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:48:32.806869
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import PythonProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor
    from httpie.plugins.builtin import XMLEncodeProcessor
    from httpie.plugins.builtin import XMLProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import Form

# Generated at 2022-06-17 20:48:41.255690
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/x-yaml'), ConverterPlugin)

# Generated at 2022-06-17 20:48:44.976099
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:48:52.863758
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.colors = 256
    env.config = {}
    env.config_dir = None
    env.config_path = None
    env.debug = False
    env.follow_redirects = True
    env.headers = {}
    env.history = []
    env.ignore_stdin = False
    env.max_redirects = 10
    env.output_file = None
    env.output_options = {}
    env.output_stream = None
    env.output_stream

# Generated at 2022-06-17 20:49:01.450153
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import Pretty

# Generated at 2022-06-17 20:49:10.776521
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import ConverterPlugin
    from httpie.plugins.builtin import BuiltinPlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin

# Generated at 2022-06-17 20:49:18.334783
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:49:24.131398
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/unknown') is None


# Generated at 2022-06-17 20:49:30.365888
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:49:42.743025
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/xml') is not None

# Generated at 2022-06-17 20:49:56.256256
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups = ['colors']
    #   env = Environment()
    #   kwargs = {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[32mOK\x1b[39m\r\n\x1b[37mContent-Type: application/json\x1b[39m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:50:06.702031
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nServer: Apache\r\nLast-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\nETag: "34aa387-d-1568eb00"\r\nAccept-Ranges: bytes\r\nContent-Length: 51\r\nVary: Accept-Encoding\r\nContent-Type: text/plain\r\nX-Pad: avoid browser bug\r\n\r\n'

# Generated at 2022-06-17 20:50:17.115751
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    #   Input:
    #       content: '{"name": "John", "age": 30, "car": null}'
    #       mime: 'application/json'
    #   Expected output:
    #       '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    #   Input:
    #       content: '

# Generated at 2022-06-17 20:50:25.794499
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = "HTTP/1.1 200 OK\r\n" \
              "Content-Type: application/json; charset=utf-8\r\n" \
              "Content-Length: 2\r\n" \
              "Date: Sun, 10 May 2020 14:58:30 GMT\r\n" \
              "Connection: keep-alive\r\n" \
              "\r\n" \
              "{}"
    f = Formatting(groups=['colors'])

# Generated at 2022-06-17 20:50:36.200111
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.colors = 256
    env.style = 'solarized'
    env.headers = {'Content-Type': 'application/json'}
    groups = ['colors']
    kwargs = {'env': env}
    formatting = Formatting(groups, **kwargs)
    headers = 'Content-Type: application/json'
    assert formatting.format_headers(headers) == '\x1b[38;5;244mContent-Type\x1b[39m: \x1b[38;5;33mapplication/json\x1b[39m'

    # Test case 2
    env = Environment()
    env.stdout = io.StringIO()

# Generated at 2022-06-17 20:50:46.399797
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.color = False
    env.colors = {}
    env.compress = False
    env.debug = False
    env.follow = False
    env.headers = []
    env.ignore_stdin = False
    env.max_redirects = 10
    env.output_file = None
    env.output_options = {}
    env.output_stream = None
    env.output_stream_encoding = 'utf8'

# Generated at 2022-06-17 20:50:58.846641
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert not converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; a=b')
    assert not converter.supports('application/json; charset=utf-8; a=b;')

# Generated at 2022-06-17 20:51:09.597280
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_conver

# Generated at 2022-06-17 20:51:15.168442
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].style == 'solarized'


# Generated at 2022-06-17 20:51:23.581011
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    #   Input: groups = ['colors'], env = Environment(), kwargs = {}
    #   Expected output: enabled_plugins = [ColorsFormatter]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert len(f.enabled_plugins) == 1
    assert isinstance(f.enabled_plugins[0], ColorsFormatter)

    # Test case 2:
    #   Input: groups = ['colors', 'format'], env = Environment(), kwargs = {}
    #   Expected output: enabled_plugins = [ColorsFormatter, FormatFormatter]
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}

# Generated at 2022-06-17 20:51:34.502905
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "car": null}'
    #   mime = 'application/json'
    # Expected output:
    #   content = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_content = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_content

    # Test case 2:
    # Input:
    #   content = '{"

# Generated at 2022-06-17 20:51:45.512273
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "car": null}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    formatting = Formatting(['json'])
    assert formatting.format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #  

# Generated at 2022-06-17 20:51:48.701791
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json1')
    assert not Conversion.get_converter('application/xml1')

# Generated at 2022-06-17 20:52:00.165504
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: keep-alive\r\n' \
              'Server: gunicorn/19.9.0\r\n' \
              'Date: Tue, 23 Apr 2019 13:11:57 GMT\r\n' \
              '\r\n' \
              '{}'
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:52:05.368533
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    assert f.format_body('{"a": 1}', 'application/json') == '{\x1b[32m"a"\x1b[39m: \x1b[34m1\x1b[39m}'
    assert f.format_body('{"a": 1}', 'application/xml') == '{"a": 1}'

# Generated at 2022-06-17 20:52:14.041587
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name": "value"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "value"\n}'
    content = '{"name": "value"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "value"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"name": "value"}'
    #   mime: 'application/xml'
    # Expected output:
    #   '{"name": "value"}'
    content = '{"name": "value"}'
    m

# Generated at 2022-06-17 20:52:23.544946
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Date: Mon, 13 May 2019 06:33:10 GMT
Server: Apache/2.4.18 (Ubuntu)
Vary: Accept-Encoding
Content-Length: 5
Connection: close

'''
    groups = ['colors']
    f = Formatting(groups)

# Generated at 2022-06-17 20:52:29.791249
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n') == '\x1b[32mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[33mContent-Type: application/json\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:52:39.589444
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:52:45.645213
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "httpie"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\x1b[32m"name"\x1b[39m: \x1b[33m"httpie"\x1b[39m}'

# Generated at 2022-06-17 20:53:03.284533
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "car": null}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    formatting = Formatting(['json'])
    assert formatting.format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #  

# Generated at 2022-06-17 20:53:12.854103
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert formatting.format_headers(headers) == '\x1b[32mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[33mContent-Type: application/json\x1b[0m\r\n\r\n'
    # Test case 2
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:53:20.882916
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=['colors'])
    assert f.format_body('{"a": 1}', 'application/json') == '{\x1b[32m"a"\x1b[39m: \x1b[34m1\x1b[39m}'
    assert f.format_body('{"a": 1}', 'application/xml') == '{"a": 1}'
    assert f.format_body('{"a": 1}', 'text/html') == '{"a": 1}'
    assert f.format_body('{"a": 1}', 'text/plain') == '{"a": 1}'
    assert f.format_body('{"a": 1}', 'text/xml') == '{"a": 1}'

# Generated at 2022-06-17 20:53:26.544988
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get_converter('text/markdown') is not None
    assert Conversion.get_converter('text/x-markdown')

# Generated at 2022-06-17 20:53:36.213600
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Test for case 1:
    # Input:
    #   content = '{"name":"John","age":30,"car":null}'
    #   mime = 'application/json'
    # Expected output:
    #   content = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name":"John","age":30,"car":null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    formatting = Formatting(groups=['json'])
    assert formatting.format_body(content, mime) == expected_output

    # Test

# Generated at 2022-06-17 20:53:46.102458
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert converter.mime == mime
    assert converter.supports(mime)
    assert converter.supports('application/xml') is False
    assert converter.supports('application/json;charset=utf-8') is False
    assert converter.supports('application/json;charset=utf-8;') is False
    assert converter.supports('application/json;charset=utf-8;q=0.9') is False
    assert converter.supports('application/json;q=0.9') is False
    assert converter.supports('application/json;q=0.9;charset=utf-8') is False

# Generated at 2022-06-17 20:53:50.310121
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': {'header': 'green'}}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].colors['header'] == 'green'

# Generated at 2022-06-17 20:53:56.654250
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': True}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:53:59.605245
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 20:54:02.110820
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:54:23.034785
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'], env=Environment(), colors=True)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:54:27.254021
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:54:37.273314
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].style == 'solarized'

    # Test case 3
    groups = ['colors']
    env = Environment()

# Generated at 2022-06-17 20:54:47.749656
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"id":1,"name":"John Doe"}'
    #   mime = 'application/json'
    # Output:
    #   content = '{\n    "id": 1,\n    "name": "John Doe"\n}'
    content = '{"id":1,"name":"John Doe"}'
    mime = 'application/json'
    groups = ['colors']
    formatting = Formatting(groups)
    content = formatting.format_body(content, mime)
    assert content == '{\n    "id": 1,\n    "name": "John Doe"\n}'

    # Test case 2:
    # Input:
    #   content = '{"id":1,"name":"John Doe"}'
    #   mime = '

# Generated at 2022-06-17 20:55:01.266907
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "httpie", "description": "HTTPie is a command line HTTP client, a user-friendly cURL replacement."}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "httpie",\n    "description": "HTTPie is a command line HTTP client, a user-friendly cURL replacement."\n}'
    content = '{"name": "httpie", "description": "HTTPie is a command line HTTP client, a user-friendly cURL replacement."}'
    mime = 'application/json'

# Generated at 2022-06-17 20:55:12.393300
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: '{"name": "John", "age": 30, "car": null}'
    #   - mime: 'application/json'
    # Expected output:
    #   - '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    actual_output = Formatting(['json']).format_body(content, mime)
    assert actual_output == expected_output

    # Test case 2:
    #

# Generated at 2022-06-17 20:55:18.207438
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('application/yaml')
    assert not Conversion.get_converter('application/html')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('/')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:55:23.607156
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1: mime is valid
    mime = "application/json"
    assert Conversion.get_converter(mime) is not None

    # Test case 2: mime is invalid
    mime = "application/json/json"
    assert Conversion.get_converter(mime) is None


# Generated at 2022-06-17 20:55:32.780876
# Unit test for method format_headers of class Formatting