

# Generated at 2022-06-17 20:45:43.312568
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:45:46.078883
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')


# Generated at 2022-06-17 20:45:59.639162
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name": "John", "age": 30, "city": "New York"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:

# Generated at 2022-06-17 20:46:06.646367
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for JSON
    json_content = '{"name": "John", "age": 30, "city": "New York"}'
    json_mime = 'application/json'
    assert Formatting(['json']).format_body(json_content, json_mime) == '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'

    # Test for XML
    xml_content = '<note><to>Tove</to><from>Jani</from><heading>Reminder</heading><body>Don\'t forget me this weekend!</body></note>'
    xml_mime = 'application/xml'

# Generated at 2022-06-17 20:46:09.464158
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')


# Generated at 2022-06-17 20:46:14.905054
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:46:22.660942
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name":"httpie","version":"0.9.9"}'
    mime = 'application/json'

# Generated at 2022-06-17 20:46:34.171890
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-toml') is not None
    assert Conversion.get_converter('text/x-python') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:46:43.675468
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:46:46.599830
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(['colors'], env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:46:56.852966
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].env.__class__.__name__ == 'Environment'
    assert f.enabled_plugins[0].style == 'solarized'


# Generated at 2022-06-17 20:47:03.980144
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:47:15.130702
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter

# Generated at 2022-06-17 20:47:25.553236
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/json/xml/')
    assert not Conversion.get_converter('application/json/xml/')
    assert not Conversion.get_converter('/application/json')
    assert not Conversion.get_converter('/application/json/')
    assert not Conversion.get_converter('/application/json/xml')

# Generated at 2022-06-17 20:47:36.587539
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:47:43.512317
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 13\r\n\r\n"
    #   groups = ["colors"]
    # Expected output:
    #   headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 13\r\n\r\n"
    #   (no change)
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 13\r\n\r\n"
    groups = ["colors"]
    formatting = Formatting(groups)
    assert formatting.format_headers(headers) == headers

    # Test case 2

# Generated at 2022-06-17 20:47:52.474300
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"a": "b"}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "a": "b"\n}'
    content = '{"a": "b"}'
    mime = 'application/json'
    expected_output = '{\n    "a": "b"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content = '{"a": "b"}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:48:01.083850
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"hello": "world"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "hello": "world"\n}'
    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"hello": "world"}'
    mime = 'application/xml'
    assert formatting.format_body(content, mime) == '{"hello": "world"}'
    # Test case 3
    groups = ['colors']
    env = Environment()

# Generated at 2022-06-17 20:48:12.719195
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:48:18.754480
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'Solarized'
    assert f.enabled_plugins[1].__class__.__name__ == 'JSONFormatter'
    assert f.enabled_plugins[2].__class__.__name__ == 'PrettyFormatter'
    assert f.enabled_plugins[3].__class__.__name__ == 'Colors'


# Generated at 2022-06-17 20:48:31.137046
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PrettyURLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawURLEncodedFormatter
    from httpie.plugins.builtin import HeadersFormatter
    from httpie.plugins.builtin import HeadersPrettyFormatter
    from httpie.plugins.builtin import HeadersURLEncodedFormatter
    from httpie.plugins.builtin import HeadersRawFormatter
    from httpie.plugins.builtin import HeadersJSONFormatter

# Generated at 2022-06-17 20:48:33.074378
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:48:38.868305
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/unknown') is None
    assert Conversion.get_converter('unknown/unknown') is None
    assert Conversion.get_converter('') is None
    assert Conversion.get_converter(None) is None


# Generated at 2022-06-17 20:48:40.866064
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 20:48:50.796676
# Unit test for method format_body of class Formatting

# Generated at 2022-06-17 20:49:00.955104
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor

    # Test case 1
    groups = ['headers']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == [HTTPHeadersProcessor(env=env, **kwargs)]

    # Test case 2
    groups = ['headers', 'body']
    env = Environment()
    kwargs = {}


# Generated at 2022-06-17 20:49:10.244160
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # test for json
    json_str = '{"name": "John", "age": 30, "car": null}'
    json_str_expected = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    json_str_actual = Formatting(['json']).format_body(json_str, 'application/json')
    assert json_str_actual == json_str_expected

    # test for html
    html_str = '<html><head><title>Title</title></head><body><p>Hello, world!</p></body></html>'

# Generated at 2022-06-17 20:49:17.954261
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/javascript'), ConverterPlugin)

# Generated at 2022-06-17 20:49:29.531960
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:49:35.350718
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatter = Formatting(groups, env, **kwargs)
    content = '{"key": "value"}'
    mime = 'application/json'
    assert formatter.format_body(content, mime) == '\x1b[37m{\x1b[39;49;00m\n  \x1b[37m"key"\x1b[39;49;00m\x1b[37m: \x1b[39;49;00m\x1b[37m"value"\x1b[39;49;00m\n\x1b[37m}\x1b[39;49;00m\n'

# Generated at 2022-06-17 20:49:45.556531
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Test case 1:
    #   Input:
    #       content = '{"name":"John"}'
    #       mime = 'application/json'
    #   Expected output:
    #       content = '{\n    "name": "John"\n}'
    content = '{"name":"John"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John"\n}'
    formatting = Formatting(['json'])
    assert formatting.format_body(content, mime) == expected_output

    # Test case 2:
    #   Input:
    #       content = '{"name":"John"}'
    #       mime = 'application/xml'
    #   Expected output:
    #       content

# Generated at 2022-06-17 20:49:53.329106
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n') == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: text/plain\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:50:01.700411
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('image/png') is None
    assert Conversion.get_converter('image/jpeg') is None
    assert Conversion.get_converter('image/gif') is None

# Generated at 2022-06-17 20:50:08.384049
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Given
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    # When
    result = formatting.format_body(content, mime)
    # Then
    assert result == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

# Generated at 2022-06-17 20:50:19.098984
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/tsv') is not None
   

# Generated at 2022-06-17 20:50:27.169339
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('application/yaml')
    assert not Conversion.get_converter('application/text')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/json/text')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('application/json/text/')
    assert not Conversion.get_converter('application/json/text/xml')
    assert not Conversion.get_converter('application/json/text/xml/')

# Generated at 2022-06-17 20:50:31.813124
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1: mime is not valid
    mime = 'text/plain'
    assert Conversion.get_converter(mime) is None

    # Test case 2: mime is valid
    mime = 'text/html'
    assert Conversion.get_converter(mime) is not None


# Generated at 2022-06-17 20:50:35.096275
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == []


# Generated at 2022-06-17 20:50:40.816615
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/javascript'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/javascript'), ConverterPlugin)

# Generated at 2022-06-17 20:50:43.087559
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:50:51.451331
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test for empty groups
    f = Formatting([])
    assert f.enabled_plugins == []

    # Test for non-empty groups
    f = Formatting(['colors'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:50:58.960115
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/markdown') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:51:05.150767
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name":"John","age":30,"car":null}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

# Generated at 2022-06-17 20:51:16.047894
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/html').mime == 'text/html'
    assert Conversion.get_converter('text/html').supports('text/html') is True
    assert Conversion.get_converter('text/html').supports('text/plain') is False
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/plain').mime == 'text/plain'
    assert Conversion.get_converter('text/plain').supports('text/plain') is True
    assert Conversion.get_converter('text/plain').supports('text/html') is False
    assert Conversion.get_converter('application/json') is not None
    assert Conversion

# Generated at 2022-06-17 20:51:23.323614
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_content = '{"a":1,"b":2,"c":3,"d":4,"e":5}'
    test_mime = 'application/json'
    test_groups = ['colors']
    test_kwargs = {}
    test_env = Environment()
    test_formatting = Formatting(test_groups, test_env, **test_kwargs)
    test_result = test_formatting.format_body(test_content, test_mime)
    assert test_result == '{\n    "a": 1,\n    "b": 2,\n    "c": 3,\n    "d": 4,\n    "e": 5\n}'


# Generated at 2022-06-17 20:51:32.529253
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "httpie"}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "httpie"\n}'
    content = '{"name": "httpie"}'
    mime = 'application/json'
    formatting = Formatting(['format'])
    assert formatting.format_body(content, mime) == '{\n    "name": "httpie"\n}'
    # Test case 2:
    # Input:
    #   content = '{"name": "httpie"}'
    #   mime = 'application/xml'
    # Expected output:
    #   '{"name": "httpie"}'

# Generated at 2022-06-17 20:51:35.699924
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'], env=Environment(), **{})
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:51:46.414474
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

    # Test case 2
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[1].__class__.__name__ == 'FormatFormatter'

    # Test case 3
    groups = ['colors', 'format', 'format_options']
    env = Environment()
    kwargs = {}

# Generated at 2022-06-17 20:51:59.781086
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:52:07.684923
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('application/pdf') is None
    assert Conversion.get_converter('application/vnd.openxmlformats-officedocument.wordprocessingml.document') is None
    assert Conversion.get_converter('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') is None

# Generated at 2022-06-17 20:52:24.880723
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:52:33.789466
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    #   Input:
    #       content = '{"name":"John","age":30,"car":null}'
    #       mime = 'application/json'
    #   Expected output:
    #       content = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name":"John","age":30,"car":null}'
    mime = 'application/json'
    expected_content = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    actual_content = Formatting(['json']).format_body(content, mime)
    assert actual_content == expected_content

    # Test case 2:
    #   Input:
   

# Generated at 2022-06-17 20:52:43.503927
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>'''
    groups = ['colors']
    env = Environment()
    env.stdout_isatty = True
    env.stderr_isatty = True
    formatting = Formatting(groups, env)
    result = formatting.format_headers(headers)

# Generated at 2022-06-17 20:52:53.256975
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor
    from httpie.plugins.builtin import XMLExtendedDumper
    from httpie.plugins.builtin import XMLProcessor
    from httpie.plugins.builtin import XMLPrettyProcessor
    from httpie.plugins.builtin import XMLStdDumper
    from httpie.plugins.builtin import XMLStdProcessor
   

# Generated at 2022-06-17 20:52:56.447041
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': 'on'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].colors == 'on'
    assert f.enabled_plugins[0].env == env

# Generated at 2022-06-17 20:53:01.700837
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>
'''
    groups = ['colors']
    f = Formatting(groups)
    headers = f.format_headers(headers)

# Generated at 2022-06-17 20:53:08.581643
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': True}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].colors == True


# Generated at 2022-06-17 20:53:14.571727
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n') == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:53:22.562077
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    #   Input:
    #       groups: ['colors', 'formatters']
    #       env: Environment()
    #       kwargs: {}
    #   Expected output:
    #       enabled_plugins: [<httpie.plugins.colors.ColorsPlugin object at 0x10f8b5c50>,
    #                         <httpie.plugins.format.FormatPlugin object at 0x10f8b5c88>]
    groups = ['colors', 'formatters']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert len(formatting.enabled_plugins) == 2
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsPlugin'

# Generated at 2022-06-17 20:53:27.318360
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test case 1
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Wed, 19 Jun 2019 15:10:41 GMT

{}'''
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)

# Generated at 2022-06-17 20:53:51.046025
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1: input headers is empty
    headers = ''
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.format_headers(headers) == ''

    # Test case 2: input headers is not empty
    headers = 'HTTP/1.1 200 OK\r\n'
    assert formatting.format_headers(headers) == 'HTTP/1.1 200 OK\r\n'



# Generated at 2022-06-17 20:54:02.355194
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import FormProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonProcessor
    from httpie.plugins.builtin import PrettyFormProcessor
    from httpie.plugins.builtin import PrettyHttpHeadersProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor

    # Test case 1:
    #   - headers:
    #       - Content-Type: application/json
    #       - Content-Length: 10
    #   - groups:
    #       - HTTPHeaders
    #       - JSON
    #       - Form
    #       - Pretty
    #   - expected:
    #

# Generated at 2022-06-17 20:54:13.196432
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_converter('text/ssv') is not None
    assert Conversion.get_converter('text/pipes')

# Generated at 2022-06-17 20:54:25.558784
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/tsv') is not None
   

# Generated at 2022-06-17 20:54:35.990560
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.is_windows = False
    env.colors = 256
    env.config = {}
    env.config_dir = None
    env.config_path = None
    env.colors = 256
    env.config = {}
    env.config_dir = None
    env.config_path = None
    env.debug = False
    env.download_dir = None
    env.follow_redirects = True
    env.headers = {}
    env.history = []
    env.http2 = False
    env.ignore_stdin = False
    env.insecure = False
    env.json = False
    env.max_redirects = 10
    env.output_file = None


# Generated at 2022-06-17 20:54:38.064514
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:54:48.326374
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    expected = '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    assert formatting.format_headers(headers) == expected

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}

# Generated at 2022-06-17 20:55:01.301114
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    assert f.format_body('{"a": "b"}', 'application/json') == '{\x1b[32m"a"\x1b[39m: \x1b[32m"b"\x1b[39m}'
    assert f.format_body('{"a": "b"}', 'application/xml') == '{"a": "b"}'
    assert f.format_body('{"a": "b"}', 'text/plain') == '{"a": "b"}'
    assert f.format_body('{"a": "b"}', 'text/html') == '{"a": "b"}'
    assert f.format_body('{"a": "b"}', 'text/css') == '{"a": "b"}'
    assert f.format_body

# Generated at 2022-06-17 20:55:12.433839
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import RawOrStdoutProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroTerminatedProcessor
    from httpie.plugins.builtin import HTTPMessagesProcessor
    from httpie.plugins.builtin import HTTPTracebackProcessor
    from httpie.plugins.builtin import HTTPErrorProcessor
    from httpie.plugins.builtin import HTTPStatsProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor


# Generated at 2022-06-17 20:55:23.312174
# Unit test for method format_headers of class Formatting