

# Generated at 2022-06-17 20:45:44.519770
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=['colors'])
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert f.format_headers(headers) == '\x1b[37mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37mContent-Type: application/json\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:45:53.577651
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])
    assert Formatting(['colors', 'format'])
    assert Formatting(['colors', 'format', 'formatvars'])
    assert Formatting(['colors', 'format', 'formatvars', 'json'])
    assert Formatting(['colors', 'format', 'formatvars', 'json', 'pretty'])
    assert Formatting(['colors', 'format', 'formatvars', 'json', 'pretty', 'table'])
    assert Formatting(['colors', 'format', 'formatvars', 'json', 'pretty', 'table', 'unicode'])
    assert Formatting(['colors', 'format', 'formatvars', 'json', 'pretty', 'table', 'unicode', 'utils'])

# Generated at 2022-06-17 20:46:00.666287
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.colors = 256
    env.compress_level = 0
    env.default_options = {}
    env.follow_redirects = True
    env.max_redirects = 10
    env.max_content_length = 104857600
    env.output_options = {}
    env.output_file = None
    env.output_dir = None
    env.output_encoding = 'utf8'
    env.output_stream = None
    env.output_stream_

# Generated at 2022-06-17 20:46:07.272307
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups = ['colors']
    #   env = Environment()
    #   kwargs = {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    env = Environment()
    kwargs = {}

# Generated at 2022-06-17 20:46:18.524762
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"key": "value"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "key": "value"\n}'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"key": "value"}'
    mime = 'application/xml'
    assert formatting.format_body(content, mime) == '{"key": "value"}'

    # Test case 3
    groups = ['colors']
    env = Environment()

# Generated at 2022-06-17 20:46:24.826886
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1: groups is empty
    groups = []
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == []

    # Test case 2: groups is not empty
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins != []


# Generated at 2022-06-17 20:46:36.114700
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "car": null}'
    #   mime = 'application/json'
    # Output:
    #   content = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    assert Formatting(['json']).format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

    # Test case 2:
    # Input:
    #   content = '{"name": "John", "age": 30, "

# Generated at 2022-06-17 20:46:39.979278
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ["colors"]
    kwargs = {"style": "solarized"}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == "Solarized"

# Generated at 2022-06-17 20:46:43.675283
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:46:45.784383
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:47:00.810037
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/javascript'), ConverterPlugin)

# Generated at 2022-06-17 20:47:05.820178
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for the case that the mime is not valid
    assert Formatting([]).format_body("{}", "") == "{}"
    # Test for the case that the mime is valid
    assert Formatting(["json"]).format_body("{}", "application/json") == "{\n    \n}"

# Generated at 2022-06-17 20:47:15.989872
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSON
    from httpie.plugins.builtin import HTTPPretty
    from httpie.plugins.builtin import HTTPPrettyXML
    from httpie.plugins.builtin import HTTPPrettyHTML
    from httpie.plugins.builtin import HTTPPrettyURLEncoded
    from httpie.plugins.builtin import HTTPPrettyMultipart
    from httpie.plugins.builtin import HTTPPrettyJsonStream
    from httpie.plugins.builtin import HTTPPrettyJsonArray
    from httpie.plugins.builtin import HTTPPrettyJsonLines
    from httpie.plugins.builtin import HTTPPrettyJsonLinesStream
    from httpie.plugins.builtin import HTTPPrettyJsonLinesArray
    from httpie.plugins.builtin import HTTPPrettyJsonLinesLines

# Generated at 2022-06-17 20:47:26.286186
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is None
    assert Conversion.get_converter('text/plain') is None
    assert Conversion.get_converter('text/csv') is None
    assert Conversion.get_converter('text/css') is None
    assert Conversion.get_converter('text/javascript') is None
    assert Conversion.get_converter('application/javascript') is None

# Generated at 2022-06-17 20:47:37.073548
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    # Expected output: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    # Actual output: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)

# Generated at 2022-06-17 20:47:48.896808
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_preferred_output_options
    from httpie.plugins.builtin import get_preferred_output_stream
    from httpie.plugins.builtin import get_preferred_style
    from httpie.plugins.builtin import get_preferred_syntax_style

# Generated at 2022-06-17 20:47:57.650362
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.colors = True
    env.format = 'json'
    env.prettify = True
    env.style = 'solarized'
    env.table = True
    env.theme = 'solarized'
    env.verbose = True
    env.stream = True
    env.download = True
    env.download_insecure = True
    env.download_resume = True
    env.download_session = True
    env.download_verify = True
    env.download_verify_cert = True
    env.download_verify_host = True
    env.download_verify_proxy = True
    env.download_verify_ssl = True
    env.download_verify_status = True
    env.download_verify_timeout = True
    env.download_

# Generated at 2022-06-17 20:48:05.062513
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test for empty headers
    headers = ''
    groups = ['colors']
    f = Formatting(groups)
    assert f.format_headers(headers) == headers

    # test for headers with no color
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json\r\n' \
              'Content-Length: 13\r\n' \
              'Connection: keep-alive\r\n' \
              '\r\n' \
              '{"hello": "world"}'
    groups = ['colors']
    f = Formatting(groups)
    assert f.format_headers(headers) == headers

    # test for headers with color

# Generated at 2022-06-17 20:48:16.005659
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    #   env: Environment()
    #   kwargs: {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[36mOK\x1b[39m\r\n\x1b[37mContent-Type: \x1b[33mapplication/json\x1b[39m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:48:27.404457
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # test case 1:
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "httpie"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\x1b[32m"name"\x1b[39m: \x1b[33m"httpie"\x1b[39m}'

    # test case 2:
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "httpie"}'
    mime = 'application/xml'
    assert formatting.format_body(content, mime)

# Generated at 2022-06-17 20:48:37.148269
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:48:40.459510
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 20:48:43.770439
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test for constructor of class Formatting
    # Test for the case that the groups is empty
    assert Formatting([])
    # Test for the case that the groups is not empty
    assert Formatting(['colors'])


# Generated at 2022-06-17 20:48:52.289885
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is None
    assert Conversion.get_converter('text/plain') is None
    assert Conversion.get_converter('text/css') is None
    assert Conversion.get_converter('image/png') is None
    assert Conversion.get_converter('image/jpeg') is None
    assert Conversion.get_converter('image/gif') is None

# Generated at 2022-06-17 20:48:58.164304
# Unit test for constructor of class Formatting
def test_Formatting():
    # test with no group
    f = Formatting([])
    assert f.enabled_plugins == []
    # test with group
    f = Formatting(['colors'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:49:05.855294
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('/json/')
    assert not Conversion.get_converter('/')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:49:14.443942
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:49:23.864359
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:49:30.199935
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)

# Generated at 2022-06-17 20:49:42.743218
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:49:59.688402
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor

    # Test for method format_headers of class Formatting
    # Case 1:
    #   Input:
    #       groups: ['HTTPHeadersProcessor', 'JSONProcessor', 'PrettyProcessor', 'StreamProcessor', 'SyntaxHighlightProcessor', 'UnicodeProcessor']
    #       headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\

# Generated at 2022-06-17 20:50:10.953612
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:50:21.479587
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroProcessor

    # Test the case that the headers is empty
    headers = ''
    groups = ['headers', 'body']
    env = Environment()
    kwargs = {'pretty_options': PrettyOptions()}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.format_headers(headers) == headers

    # Test the case that the

# Generated at 2022-06-17 20:50:29.729964
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/x-yaml'), ConverterPlugin)

# Generated at 2022-06-17 20:50:37.955472
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion

# Generated at 2022-06-17 20:50:40.531150
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:50:45.012541
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': True}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].enabled == True
    assert formatting.enabled_plugins[0].env == env
    assert formatting.enabled_plugins[0].colors == True

# Generated at 2022-06-17 20:50:53.080425
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''
    headers_formatted = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed'''
    assert Formatting(['headers']).format_headers(headers) == headers_formatted


# Generated at 2022-06-17 20:51:00.683304
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    assert f.format_body('{"a": "b"}', 'application/json') == '{\x1b[94m"a"\x1b[39m: \x1b[94m"b"\x1b[39m}'
    assert f.format_body('{"a": "b"}', 'application/xml') == '{"a": "b"}'
    assert f.format_body('{"a": "b"}', 'application/html') == '{"a": "b"}'
    assert f.format_body('{"a": "b"}', 'application/pdf') == '{"a": "b"}'

# Generated at 2022-06-17 20:51:02.708828
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 20:51:21.050234
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:51:31.328794
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.colors = 256
    env.style = 'solarized'
    env.prettify = True
    env.stream = False
    env.headers = True
    env.verbose = True
    env.debug = True
    env.follow = True
    env.timeout = 10
    env.max_redirects = 10
    env.check_status = True
    env.verify = True
    env.cert = None
    env.download_resume_from = None
    env.download_resume_count = None
    env.download_resume_last_downloaded = None
    env.download_resume_last_downloaded_size = None
    env.download_resume

# Generated at 2022-06-17 20:51:35.460599
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert converter.mime == mime
    assert converter.supports(mime)
    assert converter.supports('application/xml') == False


# Generated at 2022-06-17 20:51:46.213308
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/x-www-form-urlencoded') is not None

# Generated at 2022-06-17 20:51:59.696556
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-toml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None

# Generated at 2022-06-17 20:52:09.716815
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/x-python') is not None

# Generated at 2022-06-17 20:52:14.878072
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:52:24.183221
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:52:26.364219
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert converter.mime == mime

# Generated at 2022-06-17 20:52:30.672113
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': True}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:53:01.091765
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:53:11.809681
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/csv') is not None
    assert Conversion.get_converter('application/vnd.api+json') is not None
    assert Conversion.get_converter('application/vnd.api+xml') is not None
    assert Conversion.get_converter('application/vnd.api+yaml') is not None
    assert Conversion.get_converter('application/vnd.api+csv') is not None
    assert Conversion.get_converter('application/vnd.api+json; charset=utf-8') is not None
    assert Conversion

# Generated at 2022-06-17 20:53:15.360793
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': 'on'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].name == 'Colors'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:53:23.176159
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:53:34.658777
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting(['colors']).format_body('{"a": "b"}', 'application/json') == '{\n    "a": "b"\n}'
    assert Formatting(['colors']).format_body('{"a": "b"}', 'application/xml') == '{\n    "a": "b"\n}'
    assert Formatting(['colors']).format_body('{"a": "b"}', 'application/javascript') == '{\n    "a": "b"\n}'
    assert Formatting(['colors']).format_body('{"a": "b"}', 'text/html') == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:53:44.716118
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Case 1:
    #   Input:
    #       content = "{"a": "b"}"
    #       mime = "application/json"
    #   Expected output:
    #       content = "{\n    "a": "b"\n}"
    content = '{"a": "b"}'
    mime = "application/json"
    expected_content = '{\n    "a": "b"\n}'
    formatting = Formatting(["json"])
    assert formatting.format_body(content, mime) == expected_content

    # Case 2:
    #   Input:
    #       content = "{"a": "b"}"
    #       mime = "application/xml"
    #   Expected output:
    #       content

# Generated at 2022-06-17 20:53:52.811570
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    # Output:
    #   headers: '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    formatting = Formatting(groups)
    headers = formatting.format_headers(headers)

# Generated at 2022-06-17 20:54:02.975531
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert converter.to_html('{"a": 1}') == '<div class="json"><pre>{\n    "a": 1\n}</pre></div>'
    assert converter.to_html('{"a": 1, "b": 2}') == '<div class="json"><pre>{\n    "a": 1,\n    "b": 2\n}</pre></div>'

# Generated at 2022-06-17 20:54:06.445080
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:54:14.875456
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1: no plugin is enabled
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = False
    env.colors = 256
    env.config = {}
    env.config['colors'] = {}
    env.config['colors']['header'] = 'blue'
    env.config['colors']['body'] = 'red'
    env.config['colors']['error'] = 'red'
    env.config['colors']['extras'] = 'green'
    env.config['colors']['debug'] = 'magenta'
    env.config['colors']['info'] = 'cyan'
    env.config['colors']['warn'] = 'yellow'

# Generated at 2022-06-17 20:54:38.585185
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/octet-stream'), ConverterPlugin)

# Generated at 2022-06-17 20:54:48.756884
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Connection: keep-alive
Content-Length: 2

'''
    formatter = Formatting(['colors'])

# Generated at 2022-06-17 20:55:01.418169
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:55:05.169049
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:55:15.019334
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor

# Generated at 2022-06-17 20:55:25.831942
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('application/yaml')
    assert not Conversion.get_converter('application/x-www-form-urlencoded')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8;')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8; boundary=---------------------------7dd22b5b2e08')

# Generated at 2022-06-17 20:55:34.270593
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LENGTH
    from httpie.output.streams import BINARY

# Generated at 2022-06-17 20:55:42.280620
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    test_obj = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json; charset=utf-8\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: keep-alive\r\n' \
              'Server: gunicorn/19.9.0\r\n' \
              'Date: Sun, 23 Dec 2018 12:00:00 GMT\r\n' \
              '\r\n' \
              '{}'