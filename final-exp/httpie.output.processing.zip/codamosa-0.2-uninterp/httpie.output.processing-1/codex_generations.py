

# Generated at 2022-06-17 20:45:42.192120
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors', 'format']
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'FormatFormatter'

# Generated at 2022-06-17 20:45:50.044662
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    class TestFormatterPlugin(FormatterPlugin):
        def format_headers(self, headers: str) -> str:
            return headers
        def format_body(self, content: str, mime: str) -> str:
            return content
    plugin_manager.register(TestFormatterPlugin)
    env = Environment()
    groups = ['test']
    formatting = Formatting(groups, env)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'TestFormatterPlugin'
    assert formatting.enabled_plugins[0].env == env


# Generated at 2022-06-17 20:45:58.027083
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/csv') is not None
    assert Conversion.get_converter('application/vnd.api+json') is not None
    assert Conversion.get_converter('application/vnd.api+xml') is not None
    assert Conversion.get_converter('application/vnd.api+yaml') is not None
    assert Conversion.get_converter('application/vnd.api+yml') is not None

# Generated at 2022-06-17 20:46:00.475952
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:46:07.136304
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor
    from httpie.plugins.builtin import ZeroTerminatedProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import FormatterPlugin

# Generated at 2022-06-17 20:46:18.419730
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor

    # Test case 1:
    #   input:
    #       groups: ['HTTPHeadersProcessor', 'PrettyProcessor', 'JSONProcessor', 'StreamProcessor']
    #       headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   output:
    #       headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   reason:
    #       HTTPHeadersProcess

# Generated at 2022-06-17 20:46:28.712254
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:46:40.059265
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:46:50.337080
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodedProcessor

    # Test for constructor of class Formatting
    # Test for constructor of class Formatting
    # Test for constructor of class Formatting
    # Test for constructor of class Formatting
    # Test for constructor of class Formatting
    # Test for constructor of class Formatting
    # Test for constructor of class Formatting
    # Test for constructor of class Formatting
    # Test for constructor of class Formatting
    # Test for

# Generated at 2022-06-17 20:46:57.413296
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/xml').mime == 'application/xml'


# Generated at 2022-06-17 20:47:01.062623
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')


# Generated at 2022-06-17 20:47:11.413733
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:47:15.988779
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:47:21.267255
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1: mime is not valid
    mime = "text"
    content = "test"
    assert Formatting([]).format_body(content, mime) == content

    # Test case 2: mime is valid
    mime = "text/html"
    content = "test"
    assert Formatting([]).format_body(content, mime) == content

# Generated at 2022-06-17 20:47:29.284047
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:47:36.429049
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test 1
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: text/html; charset=utf-8\r\n' \
              'Content-Length: 13\r\n' \
              'Connection: close\r\n' \
              '\r\n' \
              'Hello, world!'
    groups = ['colors']
    env = Environment()
    env.stdout_isatty = True
    env.stdout_raw = False
    env.is_windows = False
    env.colors = {'header': 'green'}
    formatting = Formatting(groups, env)

# Generated at 2022-06-17 20:47:43.405485
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    #   Input:
    #       groups: ['colors']
    #       env: Environment()
    #       kwargs: {}
    #   Expected output:
    #       enabled_plugins: [<httpie.plugins.builtin.ColorsFormatter object at 0x7f9d3b7a3e10>]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:47:52.426408
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)

# Generated at 2022-06-17 20:48:01.012911
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
    #   groups: ["colors"]
    # Output:
    #   headers: "\x1b[37mHTTP/1.1 \x1b[32m200 \x1b[39mOK\r\n\x1b[37mContent-Type: \x1b[33mapplication/json\r\n\r\n\x1b[39m"
    #   groups: ["colors"]
    groups = ["colors"]
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"

# Generated at 2022-06-17 20:48:05.972916
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': True}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].colors == True


# Generated at 2022-06-17 20:48:17.815046
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:48:21.444942
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].style == 'solarized'

# Generated at 2022-06-17 20:48:31.565728
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:48:35.857595
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:48:41.284064
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:48:51.019887
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:49:01.053113
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/x-www-form-urlencoded')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8;')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8; ')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8; ')

# Generated at 2022-06-17 20:49:10.372920
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 10\r\n\r\n'
    #   groups: ['colors']
    # Output:
    #   headers: '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: text/html\x1b[0m\r\n\x1b[1mContent-Length: 10\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 10\r\n\r\n'

# Generated at 2022-06-17 20:49:14.666315
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors', 'format']
    kwargs = {'colors': True, 'format': 'pretty'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'PrettyFormatter'

# Generated at 2022-06-17 20:49:18.915482
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:49:31.586393
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

'''
    f = Formatting(groups=['colors'])

# Generated at 2022-06-17 20:49:43.078648
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyJsonFormatterPlugin
    from httpie.plugins.builtin import PrettyJsonBodyFilterPlugin
    from httpie.plugins.builtin import PrettyJsonBodyHighlightPlugin
    from httpie.plugins.builtin import PrettyJsonBodyIndentPlugin
    from httpie.plugins.builtin import PrettyJsonBodySortPlugin
    from httpie.plugins.builtin import PrettyJsonBodyStreamPlugin
    from httpie.plugins.builtin import PrettyJsonBodyTruncatePlugin
    from httpie.plugins.builtin import PrettyJsonBodyWidthPlugin
    from httpie.plugins.builtin import PrettyJsonHeaderFilterPlugin
    from httpie.plugins.builtin import PrettyJson

# Generated at 2022-06-17 20:49:54.299952
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test for empty headers
    headers = ""
    groups = ["colors"]
    env = Environment()
    f = Formatting(groups, env)
    assert f.format_headers(headers) == headers

    # test for headers with colors
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
    groups = ["colors"]
    env = Environment()
    f = Formatting(groups, env)
    assert f.format_headers(headers) == "\x1b[37mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37mContent-Type: application/json\x1b[0m\r\n\r\n"

    # test for headers without colors

# Generated at 2022-06-17 20:49:57.392316
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')


# Generated at 2022-06-17 20:49:59.776615
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:50:11.073954
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Date: Mon, 27 Jul 2009 12:28:53 GMT\r\n' \
              'Server: Apache/2.2.14 (Win32)\r\n' \
              'Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\n' \
              'Content-Length: 88\r\n' \
              'Content-Type: text/html\r\n' \
              'Connection: Closed\r\n\r\n'


# Generated at 2022-06-17 20:50:21.555189
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_converter('text/vnd.yaml') is not None


# Generated at 2022-06-17 20:50:29.792542
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import HTMLOptions
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedOptions
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawJSONOptions
    from httpie.plugins.builtin import RawURLEncodedFormatter
    from httpie.plugins.builtin import RawURLEncodedOptions
    from httpie.plugins.builtin import RawHTMLFormatter

# Generated at 2022-06-17 20:50:33.551438
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].style == 'solarized'

# Generated at 2022-06-17 20:50:40.056630
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('application/x-www-form-urlencoded')
    assert Conversion.get_converter('text/html')
    assert not Conversion.get_converter('text/plain')
    assert not Conversion.get_converter('text/plain; charset=utf-8')
    assert not Conversion.get_converter('text/plain; charset=utf-8;')
    assert not Conversion.get_converter('text/plain; charset=utf-8; ')
    assert not Conversion.get_converter('text/plain; charset=utf-8; ')

# Generated at 2022-06-17 20:50:52.321651
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodedProcessor

    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False


# Generated at 2022-06-17 20:50:54.489350
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:51:01.192279
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    # Expected output: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)
    assert formatting.format_headers(headers) == 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

    # Test case 2:
    # Input: headers = 'HTTP/1.1 200 OK\r\n

# Generated at 2022-06-17 20:51:11.054126
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\nContent-Type: application/json\n'
    #   groups = ['colors']
    # Expected output:
    #   headers = '\x1b[1mHTTP/1.1 200 OK\x1b[0m\n\x1b[1mContent-Type: application/json\x1b[0m\n'
    headers = 'HTTP/1.1 200 OK\nContent-Type: application/json\n'
    groups = ['colors']
    expected_headers = '\x1b[1mHTTP/1.1 200 OK\x1b[0m\n\x1b[1mContent-Type: application/json\x1b[0m\n'
    formatting = Format

# Generated at 2022-06-17 20:51:21.315312
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin.write("HTTP/1.1 200 OK\n")
    env.stdin.write("Content-Type: application/json\n")
    env.stdin.write("Content-Length: 2\n")
    env.stdin.write("\n")
    env.stdin.write("{}")
    env.stdin.seek(0)
    formatting = Formatting(["HTTPie"], env=env)
    headers = formatting.format_headers(env.stdin.read())
    assert headers == "HTTP/1.1 200 OK\nContent-Type: application/json\nContent-Length: 2\n\n"


# Generated at 2022-06-17 20:51:27.427220
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    #   env: Environment()
    #   kwargs: {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[32mOK\x1b[39m\r\n\x1b[37mContent-Type: \x1b[34mapplication/json\x1b[39m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:51:37.726996
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert not converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; a=b')
    assert not converter.supports('application/json; charset=utf-8; a=b;')
    assert not converter.supports('application/json; charset=utf-8; a=b; c=d')

# Generated at 2022-06-17 20:51:47.917519
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrint0Processor
    from httpie.plugins.builtin import HTTPPrintProcessor
    from httpie.plugins.builtin import HTTPUnicodeProcessor
    from httpie.plugins.builtin import HTTPUnicodePrettyProcessor
    from httpie.plugins.builtin import HTTPUnicodePrettyJSONProcessor
    from httpie.plugins.builtin import HTTPUnicodePrettyJSONStreamProcessor
    from httpie.plugins.builtin import HTTPUnicodePrettyStreamProcessor
    from httpie.plugins.builtin import HTTPUnicodeStreamProcessor
    from httpie.plugins.builtin import HTTPUnicodeStreamJSONProcessor

# Generated at 2022-06-17 20:52:00.117302
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.colors = 256
    env.style = 'solarized'
    env.headers = {'Content-Type': 'application/json'}
    env.prettify = True
    env.ugly = False
    env.stream = False
    env.follow = False
    env.verify = True
    env.timeout = None
    env.max_redirects = 10
    env.check_status = True
    env.check_headers = True
    env.check_body = True
    env.headers_normalization = True
    env.output_options = {'pretty': True, 'colors': 256, 'style': 'solarized'}

# Generated at 2022-06-17 20:52:10.051053
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:52:23.197471
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:52:32.534966
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/yaml") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded") is not None
    assert Conversion.get_converter("text/html") is not None
    assert Conversion.get_converter("text/plain") is not None
    assert Conversion.get_converter("text/csv") is not None
    assert Conversion.get_converter("text/tab-separated-values") is not None
    assert Conversion.get_converter("text/xml") is not None
    assert Conversion.get_converter("text/yaml") is not None

# Generated at 2022-06-17 20:52:42.748106
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-msgpack') is not None
    assert Conversion.get_converter('application/msgpack') is not None
    assert Conversion.get_converter('application/x-protobuf') is not None
    assert Conversion.get_converter('application/protobuf') is not None
    assert Conversion.get_converter('application/x-bson') is not None
    assert Conversion.get_converter('application/bson') is not None
   

# Generated at 2022-06-17 20:52:47.851984
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.__class__.__name__ == 'JSONConverter'
    converter = Conversion.get_converter('application/xml')
    assert converter.__class__.__name__ == 'XMLConverter'
    converter = Conversion.get_converter('application/x-www-form-urlencoded')
    assert converter.__class__.__name__ == 'FormConverter'
    converter = Conversion.get_converter('text/html')
    assert converter is None


# Generated at 2022-06-17 20:53:01.035325
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
Date: Tue, 21 May 2019 13:51:35 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Tue, 21 May 2019 13:51:35 GMT
ETag: "2d-58a6a7c7b6f40"
Accept-Ranges: bytes
Content-Length: 45
Cache-Control: max-age=0
Expires: Tue, 21 May 2019 13:51:35 GMT
Connection: close
Content-Type: text/html

'''
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    result = formatting.format_headers(headers)

# Generated at 2022-06-17 20:53:08.977630
# Unit test for constructor of class Formatting
def test_Formatting():
    import httpie.plugins.builtin
    from httpie.plugins.registry import plugin_manager
    plugin_manager.load_installed_plugins()
    available_plugins = plugin_manager.get_formatters_grouped()
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__ == httpie.plugins.builtin.ColorsFormatter

# Generated at 2022-06-17 20:53:18.322713
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "car": null}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content = '{"name":

# Generated at 2022-06-17 20:53:25.504586
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.config_dir = './'
    env.config_path = './config.json'
    env.colors = 256
    env.default_options = []
    env.headers = []
    env.ignore_stdin = False
    env.max_redirects = 10
    env.output_options = []
    env.output_options_given = []
    env.output_stream = None
    env.output_stream_encoding = None
    env.output_stream_errors

# Generated at 2022-06-17 20:53:36.000678
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name": "httpie"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "httpie"\n}'
    content = '{"name": "httpie"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "httpie"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"name": "httpie"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "httpie"\n}'
    content

# Generated at 2022-06-17 20:53:46.012427
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:54:03.023036
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/x-www-form-urlencoded')
    assert not Conversion.get_converter('application/x-www-form-urlencoded;charset=UTF-8')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=UTF-8')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=UTF-8')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=UTF-8')

# Generated at 2022-06-17 20:54:13.691911
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('application/json') is not None
   

# Generated at 2022-06-17 20:54:18.717342
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert converter.mime == mime
    assert converter.supports(mime)
    assert converter.convert('{"a": 1}') == '{\n    "a": 1\n}'


# Generated at 2022-06-17 20:54:22.528775
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:54:33.668835
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor

    # Test case 1
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.stdin_isatty = True
    env.is_windows = False
    env.colors = 256
    env.prettifier_enabled = True
    env.prettifier_class = PrettyProcessor
    env.prett

# Generated at 2022-06-17 20:54:44.921726
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/toml') is not None
    assert Conversion.get_converter('application/csv') is not None
    assert Conversion.get_converter('application/vnd.api+json') is not None
    assert Conversion.get_converter('application/vnd.api+xml') is not None
    assert Conversion.get_converter('application/vnd.api+yaml') is not None

# Generated at 2022-06-17 20:54:50.446354
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n') == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: text/html\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:55:01.933149
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "httpie"}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "httpie"\n}'
    content = '{"name": "httpie"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "httpie"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content = '{"name": "httpie"}'
    #   mime = 'application/xml'
    # Expected output:
    #   '{"name": "httpie"}'

# Generated at 2022-06-17 20:55:13.039804
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroProcessor
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import format_options

# Generated at 2022-06-17 20:55:17.809210
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ["colors"]
    kwargs = {"style": "solarized"}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].style == "solarized"
    assert formatting.enabled_plugins[0].env == env
