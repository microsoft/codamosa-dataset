

# Generated at 2022-06-17 20:45:46.078979
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    class TestFormatter(FormatterPlugin):
        def format_headers(self, headers):
            return headers
        def format_body(self, body, mime):
            return body
    env = Environment()
    env.stdout = sys.stdout
    env.stdin = sys.stdin
    env.stderr = sys.stderr
    f = Formatting(['test'], env=env)
    assert f.enabled_plugins[0].__class__ == TestFormatter
    assert f.enabled_plugins[0].env == env
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].format_headers("test") == "test"
    assert f.enabled_plugins[0].format_

# Generated at 2022-06-17 20:45:59.637145
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json; charset=utf-8\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: keep-alive\r\n' \
              'Server: gunicorn/19.9.0\r\n' \
              'Date: Mon, 10 Dec 2018 16:52:59 GMT\r\n' \
              '\r\n' \
              '{}'

# Generated at 2022-06-17 20:46:09.675351
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import XMLProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor

# Generated at 2022-06-17 20:46:13.987567
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:46:22.103858
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatterV2
    from httpie.plugins.builtin import PrettyJsonFormatterV3
    from httpie.plugins.builtin import PrettyJsonFormatterV4
    from httpie.plugins.builtin import PrettyJsonFormatterV5
    from httpie.plugins.builtin import PrettyJsonFormatterV6
    from httpie.plugins.builtin import PrettyJsonFormatterV7
    from httpie.plugins.builtin import PrettyJsonFormatterV8
    from httpie.plugins.builtin import PrettyJsonFormatterV9

# Generated at 2022-06-17 20:46:25.828209
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'formatters']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == []


# Generated at 2022-06-17 20:46:37.525799
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:46:39.922233
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 20:46:46.704744
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test for method format_headers of class Formatting
    # Case 1: headers is empty
    headers = ""
    groups = ["colors"]
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.format_headers(headers) == headers

    # Case 2: headers is not empty
    headers = "HTTP/1.1 200 OK\r\n" \
              "Content-Type: application/json\r\n" \
              "Content-Length: 2\r\n" \
              "Connection: close\r\n" \
              "\r\n" \
              "{}"
    groups = ["colors"]
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.format

# Generated at 2022-06-17 20:47:00.592996
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Server: nginx/1.10.3 (Ubuntu)\r\n' \
              'Date: Thu, 19 Oct 2017 04:39:53 GMT\r\n' \
              'Content-Type: application/json\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: keep-alive\r\n' \
              '\r\n' \
              '{}'
    groups = ['colors']

# Generated at 2022-06-17 20:47:14.880211
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_

# Generated at 2022-06-17 20:47:17.078120
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:47:27.137882
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name":"John"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John"\n}'
    content = '{"name":"John"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"name":"John"}'
    #   mime: 'application/xml'
    # Expected output:
    #   '{"name":"John"}'
    content = '{"name":"John"}'

# Generated at 2022-06-17 20:47:30.232332
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json")
    assert not Conversion.get_converter("application/xml")


# Generated at 2022-06-17 20:47:39.333231
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_converter('text/json') is not None

# Generated at 2022-06-17 20:47:49.905956
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyPrinter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import SyntaxHighlight
    from httpie.plugins.builtin import UnicodePrettyPrinter
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_preferred_encoding
    from httpie.plugins.builtin import get_response_stream
    from httpie.plugins.builtin import get_terminal_width
    from httpie.plugins.builtin import is_json
    from httpie.plugins.builtin import is_pretty
    from httpie.plugins.builtin import is_terminal

# Generated at 2022-06-17 20:48:02.636827
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
Date: Tue, 16 Jun 2020 15:48:58 GMT
Server: Apache
Last-Modified: Tue, 16 Jun 2020 15:48:58 GMT
ETag: "5-5a8c7b8c8f7c0"
Accept-Ranges: bytes
Content-Length: 5
Content-Type: text/html

'''
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    result = formatting.format_headers(headers)

# Generated at 2022-06-17 20:48:05.333362
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:48:12.216747
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n') == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:48:19.868637
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Case 1:
    # Input:
    #   - content: '{"name": "John", "age": 30, "car": null}'
    #   - mime: 'application/json'
    # Expected output:
    #   - '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(groups=['json']).format_body(content, mime) == expected_output

    # Case 2:
    # Input:
    #   - content:

# Generated at 2022-06-17 20:48:34.233806
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:48:41.646414
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('application/pdf') is None
    assert Conversion.get_converter('application/vnd.openxmlformats-officedocument.wordprocessingml.document') is None
    assert Conversion.get_converter('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') is None

# Generated at 2022-06-17 20:48:46.166969
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': True}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:48:59.429993
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:49:07.445560
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    result = formatting.format_headers(headers)
    assert result == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:49:15.827571
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1: no plugins are enabled
    groups = []
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'
    assert formatting.format_headers(headers) == headers

    # Test case 2: one plugin is enabled
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'

# Generated at 2022-06-17 20:49:20.448764
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n'
    assert f.format_headers(headers) == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: text/html; charset=utf-8\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:49:30.822422
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    #   Input: groups = ['colors', 'formatters'], env = Environment(), kwargs = {}
    #   Expected output: enabled_plugins = [ColorsFormatter, JSONFormatter, PrettyFormatter, URLEncodedFormatter]
    groups = ['colors', 'formatters']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == [ColorsFormatter, JSONFormatter, PrettyFormatter, URLEncodedFormatter]

    # Test case 2:
    #   Input: groups = ['colors', 'formatters'], env = Environment(), kwargs = {'style': 'solarized'}
    #   Expected output: enabled_plugins = [ColorsFormatter, JSONFormatter,

# Generated at 2022-06-17 20:49:36.313331
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:49:45.108693
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:49:59.784801
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "httpie", "description": "HTTPie is a command line HTTP client, a user-friendly cURL replacement."}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "description": "HTTPie is a command line HTTP client, a user-friendly cURL replacement.", \n    "name": "httpie"\n}'
    # test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:50:11.073337
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor

    # Test case 1
    # Test for method format_headers of class Formatting
    # Input:
    #   groups = ['HTTPHeadersProcessor', 'JSONProcessor', 'PrettyProcessor', 'StreamProcessor', 'SyntaxHighlightProcessor', 'UnicodeProcessor', 'URLEncodeProcessor']
    #   env =

# Generated at 2022-06-17 20:50:21.516890
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8'), ConverterPlugin)

# Generated at 2022-06-17 20:50:31.209667
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/xml/json')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('/')
    assert not Conversion.get_converter('/json/')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)

# Generated at 2022-06-17 20:50:38.644357
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_

# Generated at 2022-06-17 20:50:47.992351
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PrettyURLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import PrettyHTMLFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import PrettyXMLFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawURLEncodedFormatter
    from httpie.plugins.builtin import RawHTMLFormatter
    from httpie.plugins.builtin import RawXMLFormatter
    from httpie.plugins.builtin import RawForm

# Generated at 2022-06-17 20:50:56.150887
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PrettyURLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import PrettyHTMLFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawURLEncodedFormatter
    from httpie.plugins.builtin import RawHTMLFormatter

    class MockPlugin(FormatterPlugin):
        def format_body(self, body, mime):
            return body + "MockPlugin"


# Generated at 2022-06-17 20:51:05.994857
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPieJSONFormatter
    from httpie.plugins.builtin import HTTPiePrettyFormatter
    from httpie.plugins.builtin import HTTPieTableFormatter
    from httpie.plugins.builtin import HTTPieURLEncodedFormatter
    from httpie.plugins.builtin import HTTPieColorsFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormat

# Generated at 2022-06-17 20:51:08.030902
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:51:18.941891
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"id":1,"name":"A green door","price":12.50,"tags":["home","green"]}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "id": 1,\n    "name": "A green door",\n    "price": 12.5,\n    "tags": [\n        "home",\n        "green"\n    ]\n}'
    content = '{"id":1,"name":"A green door","price":12.50,"tags":["home","green"]}'
    mime = 'application/json'
    groups = ['json']
    formatting = Formatting(groups)

# Generated at 2022-06-17 20:51:34.142043
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None

# Generated at 2022-06-17 20:51:45.175532
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '<html><body><h1>Hello World</h1></body></html>'
    mime = 'text/html'
    assert formatting.format

# Generated at 2022-06-17 20:51:52.429963
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(groups=['colors'])
    assert Formatting(groups=['colors', 'format'])
    assert Formatting(groups=['colors', 'format', 'syntax'])
    assert Formatting(groups=['colors', 'format', 'syntax', 'browser'])
    assert Formatting(groups=['colors', 'format', 'syntax', 'browser', 'highlight'])
    assert Formatting(groups=['colors', 'format', 'syntax', 'browser', 'highlight', 'pager'])
    assert Formatting(groups=['colors', 'format', 'syntax', 'browser', 'highlight', 'pager', 'stream'])

# Generated at 2022-06-17 20:51:57.844649
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:52:07.772377
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
   

# Generated at 2022-06-17 20:52:10.530651
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:52:14.988026
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

'''
    groups = ['colors']
    f = Formatting(groups)
    f.format_headers(headers)


# Generated at 2022-06-17 20:52:24.249843
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
    #   groups = ['colors']
    #   env = Environment()
    #   kwargs = {}
    # Expected output:
    #   headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.format_headers(headers) == headers

    # Test case

# Generated at 2022-06-17 20:52:33.352274
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    # Input: groups = ['colors'], env = Environment(), kwargs = {}
    # Expected output: enabled_plugins = [ColorsFormatter]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == [ColorsFormatter]
    # Test case 2:
    # Input: groups = ['colors', 'format'], env = Environment(), kwargs = {}
    # Expected output: enabled_plugins = [ColorsFormatter, FormatFormatter]
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:52:35.412398
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 20:52:51.797120
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions

# Generated at 2022-06-17 20:52:58.781844
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_conver

# Generated at 2022-06-17 20:53:04.707416
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    # Output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m\x1b[37m OK\r\n\x1b[37mContent-Type: \x1b[33mapplication/json\x1b[39m\r\n\r\n'
    groups = ['colors']
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:53:13.467244
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Date: Wed, 28 Nov 2018 21:43:44 GMT
Server: Apache/2.4.6 (CentOS) OpenSSL/1.0.2k-fips mod_fcgid/2.3.9 PHP/5.4.16
X-Powered-By: PHP/5.4.16
Content-Length: 2
Connection: close

'''
    f = Formatting(groups=['colors'])

# Generated at 2022-06-17 20:53:20.883563
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n' \
              'Content-Length: 12\r\n\r\n'
    formatting = Formatting(['colors'])
    assert formatting.format_headers(headers) == '\x1b[36mHTTP/1.1 200 OK\x1b[39m\r\n' \
                                                 '\x1b[33mContent-Type: text/html; charset=utf-8\x1b[39m\r\n' \
                                                 '\x1b[33mContent-Length: 12\x1b[39m\r\n\r\n'


# Generated at 2022-06-17 20:53:24.656306
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n") == "\x1b[37mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37mContent-Type: application/json\x1b[0m\r\n\r\n"


# Generated at 2022-06-17 20:53:33.064065
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test for constructor of class Formatting
    # Case 1: groups is empty
    groups = []
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == []

    # Case 2: groups is not empty
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins != []


# Generated at 2022-06-17 20:53:42.937111
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert formatting.format_headers(headers) == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    # Test case 2
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:53:45.217712
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:53:50.754768
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1: mime is None
    assert Conversion.get_converter(None) is None

    # Test case 2: mime is not valid
    assert Conversion.get_converter('abc') is None

    # Test case 3: mime is valid but not supported
    assert Conversion.get_converter('text/html') is None

    # Test case 4: mime is valid and supported
    assert Conversion.get_converter('application/json') is not None



# Generated at 2022-06-17 20:54:01.853584
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors", "formatters"]
    env = Environment()
    kwargs = {"style": "solarized"}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == "Colors"
    assert formatting.enabled_plugins[1].__class__.__name__ == "JSONFormatter"

# Generated at 2022-06-17 20:54:12.786310
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:54:20.485278
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'style': 'monokai'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'FormatFormatter'


# Generated at 2022-06-17 20:54:23.586969
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:54:27.468295
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:54:37.436405
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    #   groups: ['colors']
    #   env: Environment()
    #   kwargs: {}
    # Expected result:
    #   enabled_plugins: [ColorsFormatter]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

    # Test case 2:
    #   groups: ['colors', 'format']
    #   env: Environment()
    #   kwargs: {}
    # Expected result:
    #   enabled_plugins: [ColorsFormatter, FormatFormatter]

# Generated at 2022-06-17 20:54:47.877413
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:54:51.706796
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:55:02.274085
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:55:06.202981
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format', 'format-pretty']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins != None


# Generated at 2022-06-17 20:55:22.806323
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:55:31.990238
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name":"John"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\x1b[94m"name"\x1b[39m:\x1b[33m"John"\x1b[39m}'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name":"John"}'
    mime = 'application/xml'
    assert formatting.format_body(content, mime) == '{"name":"John"}'