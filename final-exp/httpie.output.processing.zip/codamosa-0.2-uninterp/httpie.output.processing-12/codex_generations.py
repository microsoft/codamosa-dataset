

# Generated at 2022-06-17 20:45:47.494659
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('text/html') is None
    assert Conversion.get_converter('text/html; charset=utf-8') is None
    assert Conversion.get_converter('text/html; charset=utf-8;') is None
    assert Conversion.get_converter('text/html; charset=utf-8; ') is None
    assert Conversion.get_converter('text/html; charset=utf-8; a=b') is None
    assert Conversion.get_converter('text/html; charset=utf-8; a=b;') is None
    assert Conversion.get_converter('text/html; charset=utf-8; a=b; ') is None

# Generated at 2022-06-17 20:46:00.798985
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:46:04.733040
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(['colors'], env=env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].env == env


# Generated at 2022-06-17 20:46:16.519910
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: '{"name": "John", "age": 30, "car": null}'
    #   - mime: 'application/json'
    # Expected output:
    #   - '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   - content:

# Generated at 2022-06-17 20:46:23.489407
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:46:35.004726
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:46:39.979224
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].env.__class__.__name__ == 'Environment'


# Generated at 2022-06-17 20:46:50.264847
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_

# Generated at 2022-06-17 20:47:01.896333
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    # Input:
    #   content = '{"name":"test","age":20}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "test",\n    "age": 20\n}'
    content = '{"name":"test","age":20}'
    mime = 'application/json'
    expected_output = '{\n    "name": "test",\n    "age": 20\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2
    # Input:
    #   content = '<html><body><h1>Test</h1></body></html>'
    #   mime = 'text/html'
    # Expected

# Generated at 2022-06-17 20:47:09.631490
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:47:15.348470
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroMQProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor

# Generated at 2022-06-17 20:47:25.739275
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:47:36.713053
# Unit test for constructor of class Formatting

# Generated at 2022-06-17 20:47:41.539517
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.colors = 256
    env.config = {}
    env.config_dir = None
    env.default_options = {}
    env.follow_redirects = True
    env.max_redirects = 10
    env.output_options = {}
    env.output_options_specified = False
    env.output_stream = io.StringIO()
    env.output_stream_isatty = False
    env.prefer_ipv6 = False
    env.request_timeout

# Generated at 2022-06-17 20:47:51.789190
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>
'''
    groups = ['colors']
    env = Environment()
    env.config['colors'] = True
    env.config['style'] = 'solarized'
    env.config['format'] = 'colors'
    formatting = Formatting(groups, env)

# Generated at 2022-06-17 20:48:04.363873
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:48:15.421066
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/csv') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:48:20.689509
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].__class__.__module__ == 'httpie.plugins.builtin.colors'


# Generated at 2022-06-17 20:48:30.977690
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:48:40.423125
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_converter('text/vtt') is not None
    assert Conversion

# Generated at 2022-06-17 20:48:51.707023
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('text/html') is None
    assert Conversion.get_converter('text/plain') is None
    assert Conversion.get_converter('text/plain; charset=utf-8') is None
    assert Conversion.get_conver

# Generated at 2022-06-17 20:48:56.008193
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': True}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:48:59.226064
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')


# Generated at 2022-06-17 20:49:02.480579
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:49:09.471983
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Given
    env = Environment()
    groups = ['colors']
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name":"John"}'
    mime = 'application/json'
    # When
    result = formatting.format_body(content, mime)
    # Then
    assert result == '{\x1b[94m"name"\x1b[39;49;00m: \x1b[33m"John"\x1b[39;49;00m}'

# Generated at 2022-06-17 20:49:13.599801
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    assert f.format_body('{"a": 1}', 'application/json') == '{\x1b[32m"a"\x1b[39m: \x1b[34m1\x1b[39m}'

# Generated at 2022-06-17 20:49:18.305072
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n') == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:49:29.824720
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import json
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_prettifier
    from httpie.plugins.builtin import get_syntax_style
    from httpie.plugins.builtin import get_theme
    from httpie.plugins.builtin import get_writer
    from httpie.plugins.builtin import is_json

# Generated at 2022-06-17 20:49:40.496527
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'formatters']
    env = Environment()
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].enabled == True
    assert formatting.enabled_plugins[0].env == env
    assert formatting.enabled_plugins[0].style == 'solarized'
    assert formatting.enabled_plugins[1].enabled == True
    assert formatting.enabled_plugins[1].env == env
    assert formatting.enabled_plugins[1].style == 'solarized'


# Generated at 2022-06-17 20:49:53.330791
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # test for json
    json_str = '{"name":"test","age":18}'
    mime = 'application/json'
    f = Formatting(['colors'])
    assert f.format_body(json_str, mime) == '{\n    "name": "test",\n    "age": 18\n}'

    # test for html
    html_str = '<html><body><h1>test</h1></body></html>'
    mime = 'text/html'
    f = Formatting(['colors'])
    assert f.format_body(html_str, mime) == '<html>\n<body>\n<h1>test</h1>\n</body>\n</html>'

    # test for text
    text_str = 'test'


# Generated at 2022-06-17 20:50:04.022761
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: '{"key": "value"}'
    #   - mime: 'application/json'
    # Expected output:
    #   - '{\n    "key": "value"\n}'
    content = '{"key": "value"}'
    mime = 'application/json'
    expected_output = '{\n    "key": "value"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   - content: '{"key": "value"}'
    #   - mime: 'application/xml'
    # Expected output:
    #   - '{"key": "value"}'

# Generated at 2022-06-17 20:50:13.085726
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:50:22.677015
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=['colors'], env=Environment(), colors=True)
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Fri, 07 Feb 2020 15:41:37 GMT

'''

# Generated at 2022-06-17 20:50:30.908576
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert Conversion.get_converter('application/json').supports('application/json')
    assert not Conversion.get_converter('application/json').supports('text/html')
    assert not Conversion.get_converter('application/json').supports('application/xml')
    assert not Conversion.get_converter('application/json').supports('text/xml')
    assert not Conversion.get_converter('application/json').supports('application/x-www-form-urlencoded')
    assert not Conversion.get_converter('application/json').supports('multipart/form-data')
    assert not Conversion

# Generated at 2022-06-17 20:50:38.497580
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    # Expected output:
    #   '\x1b[90mHTTP/1.1 \x1b[32m200\x1b[39m\x1b[90m OK\r\n'
    #   '\x1b[90mContent-Type: \x1b[33mapplication/json\x1b[39m\x1b[90m\r\n\r\n\x1b[39m'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:50:47.846289
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/json1')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('application/json/1')
    assert not Conversion.get_converter('application/json/1/')
    assert not Conversion.get_converter('application/json/1/2')
    assert not Conversion.get_converter('application/json/1/2/')
    assert not Conversion.get_converter('application/json/1/2/3')
    assert not Conversion.get_converter('application/json/1/2/3/')
    assert not Conversion.get_converter('application/json/1/2/3/4')

# Generated at 2022-06-17 20:50:56.011967
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("application/xml"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/html"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/plain"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/csv"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/tab-separated-values"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/yaml"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/x-yaml"), ConverterPlugin)

# Generated at 2022-06-17 20:51:05.754029
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8;')
    assert not Conversion.get_converter('application/json; charset=utf-8; ')
    assert not Conversion.get_converter('application/json; charset=utf-8; x')
    assert not Conversion.get_converter('application/json; charset=utf-8; x=')
    assert not Conversion.get_converter('application/json; charset=utf-8; x=y')

# Generated at 2022-06-17 20:51:07.786371
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[0].style == 'solarized'


# Generated at 2022-06-17 20:51:12.105082
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'], env=Environment(), force_colors=True)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].env.force_colors == True


# Generated at 2022-06-17 20:51:24.107842
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import XMLExtendedDumper
    from httpie.plugins.builtin import XMLProcessor
    from httpie.plugins.builtin import XMLPrettyProcessor
    from httpie.plugins.builtin import XMLStdDumper
    from httpie.plugins.builtin import XMLStdProcessor
    from httpie.plugins.builtin import XMLSyntaxHighlightProcessor
    from httpie.plugins.builtin import XMLSyntaxHigh

# Generated at 2022-06-17 20:51:28.130912
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'], env=Environment(), force_colors=True)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].force_colors == True


# Generated at 2022-06-17 20:51:34.697603
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None

# Generated at 2022-06-17 20:51:45.633667
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('multipart/form-data'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)

# Generated at 2022-06-17 20:51:55.511290
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/plain; charset=utf-8') is not None
    assert Conversion.get_converter('text/plain; charset=utf-8') is not None

# Generated at 2022-06-17 20:52:06.896967
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import get_config
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    import json
    import os
    import sys
    import tempfile
    import unittest


# Generated at 2022-06-17 20:52:15.094678
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: '{"name": "John", "age": 30, "city": "New York"}'
    #   - mime: 'application/json'
    # Expected output:
    #   - '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    formatting = Formatting(['json'])
    assert formatting.format_body(content, mime) == expected_output

    #

# Generated at 2022-06-17 20:52:19.439841
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:52:26.341441
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 13\r\n\r\n'
    # Expected output: 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 13\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 13\r\n\r\n'
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.format_headers

# Generated at 2022-06-17 20:52:31.288407
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    formatting = Formatting(['colors'])
    assert formatting.format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'

# Generated at 2022-06-17 20:52:45.105138
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyPrinter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import SyntaxHighlight
    from httpie.plugins.builtin import UnicodePrettyPrinter
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_preferred_format
    from httpie.plugins.builtin import get_preferred_style
    from httpie.plugins.builtin import get_style
    from httpie.plugins.builtin import is_json
    from httpie.plugins.builtin import is_pretty
    from httpie.plugins.builtin import is_raw_formatter

# Generated at 2022-06-17 20:52:54.403556
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert not converter.supports('text/plain')
    assert not converter.supports('text/html')
    assert not converter.supports('text/xml')
    assert not converter.supports('text/css')
    assert not converter.supports('text/csv')
    assert not converter.supports('text/javascript')
    assert not converter.supports('text/ecmascript')
    assert not converter.supports('text/typescript')
    assert not converter.supports('text/vbscript')
    assert not converter.supports('text/x-sh')


# Generated at 2022-06-17 20:53:00.018146
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: 12\r\n\r\n'
    expected_headers = '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: text/plain; charset=utf-8\x1b[0m\r\n\x1b[1mContent-Length: 12\x1b[0m\r\n\r\n'
    assert formatting.format_headers(headers) == expected_headers

    #

# Generated at 2022-06-17 20:53:06.130018
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': True}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:53:14.140291
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('application/pdf') is None
    assert Conversion.get_converter('application/octet-stream') is None

# Generated at 2022-06-17 20:53:22.250796
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('text/plain')
    assert not Conversion.get_converter('application/octet-stream')
    assert not Conversion.get_converter('image/jpeg')
    assert not Conversion.get_converter('image/png')
    assert not Conversion.get_converter('image/gif')
    assert not Conversion.get_converter('image/svg+xml')
    assert not Conversion.get_converter('text/css')
    assert not Conversion.get_converter('application/javascript')

# Generated at 2022-06-17 20:53:23.755420
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:53:35.282579
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.color = True
    env.style = 'solarized'

# Generated at 2022-06-17 20:53:46.012101
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion

# Generated at 2022-06-17 20:53:53.679861
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert Conversion.get_converter('application/json').supports('application/json')
    assert not Conversion.get_converter('application/json').supports('application/xml')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8;')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8; ')

# Generated at 2022-06-17 20:54:00.487524
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:54:11.704081
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:54:23.377150
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/xml') is not None

# Generated at 2022-06-17 20:54:26.527433
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:54:36.701162
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test for constructor of class Formatting
    # Case 1: groups is empty
    groups = []
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == []

    # Case 2: groups is not empty
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert len(formatting.enabled_plugins) == 1
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

    # Case 3: groups is not empty
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert len

# Generated at 2022-06-17 20:54:47.199432
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatterV2
    from httpie.plugins.builtin import PrettyJsonFormatterV3
    from httpie.plugins.builtin import PrettyJsonFormatterV4
    from httpie.plugins.builtin import PrettyJsonFormatterV5
    from httpie.plugins.builtin import PrettyJsonFormatterV6
    from httpie.plugins.builtin import PrettyJsonFormatterV7
    from httpie.plugins.builtin import PrettyJsonFormatterV8
    from httpie.plugins.builtin import PrettyJsonFormatterV9
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:55:00.994943
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = "HTTP/1.1 200 OK\r\nDate: Tue, 04 Aug 2020 13:13:13 GMT\r\nServer: Apache/2.4.18 (Ubuntu)\r\nLast-Modified: Mon, 03 Aug 2020 13:13:13 GMT\r\nETag: \"2a-58f7f0f8b5b00\"\r\nAccept-Ranges: bytes\r\nContent-Length: 42\r\nVary: Accept-Encoding\r\nContent-Type: text/html\r\n\r\n<html><body><h1>It works!</h1></body></html>\r\n"
    groups = ["colors"]
    env = Environment()
    kwargs = {}

# Generated at 2022-06-17 20:55:12.032929
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.config = {
        'colors': {
            'header': 'green',
            'body': 'blue',
            'error': 'red',
        }
    }
    env.config_dir = os.path.expanduser('~/.config/httpie')
    env.config_path = os.path.join(env.config_dir, 'config.json')
    env.colors = True
    env.style = 'solarized'
    env.default_options = ['--style', 'solarized']
    env.debug = False
    env.download_dir = os.path.expanduser('~/Downloads')
    env.max_redirects = 10
   

# Generated at 2022-06-17 20:55:22.693105
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8')
    assert not Conversion.get_

# Generated at 2022-06-17 20:55:31.810344
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyPrinter
    from httpie.plugins.builtin import RawOrStdoutProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor