

# Generated at 2022-06-17 20:45:47.426633
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor
    from httpie.plugins.builtin import ZeroMQProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    import json
    import os
    import sys
    import unittest


# Generated at 2022-06-17 20:46:00.764273
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/hal+json') is not None
    assert Conversion.get_converter('application/hal+xml') is not None
    assert Conversion.get_converter('application/hal+yaml') is not None
    assert Conversion.get_converter('application/hal+json') is not None
    assert Conversion.get_converter('application/hal+xml') is not None
    assert Conversion.get_converter('application/hal+yaml') is not None
    assert Conversion.get_converter('application/vnd.collection+json') is not None

# Generated at 2022-06-17 20:46:10.721613
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.config = {}
    env.config_dir = None
    env.colors = 256
    env.max_content_length = None
    env.download_dir = None
    env.default_options = []
    env.default_options_override = False
    env.follow_redirects = True
    env.timeout = None
    env.max_redirects = 10
    env.check_status = True
    env.verify = True
    env.cert = None
    env.cert_key = None
    env.auth = None
    env.proxy = None
    env.debug = False
    env.output_options = {}

# Generated at 2022-06-17 20:46:20.957602
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/javascript'), ConverterPlugin)

# Generated at 2022-06-17 20:46:32.377702
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json")
    assert Conversion.get_converter("application/xml")
    assert Conversion.get_converter("text/html")
    assert Conversion.get_converter("text/plain")
    assert Conversion.get_converter("text/csv")
    assert Conversion.get_converter("text/tab-separated-values")
    assert Conversion.get_converter("text/javascript")
    assert Conversion.get_converter("text/css")
    assert Conversion.get_converter("application/javascript")
    assert Conversion.get_converter("application/x-javascript")
    assert Conversion.get_converter("application/x-www-form-urlencoded")
    assert Conversion.get_converter("application/xhtml+xml")
   

# Generated at 2022-06-17 20:46:39.856937
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/unknown') is None
    assert Conversion.get_converter('unknown/unknown') is None
    assert Conversion.get_converter('') is None
    assert Conversion.get_converter(None) is None


# Generated at 2022-06-17 20:46:50.129203
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PrettyURLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawURLEncodedFormatter
    from httpie.plugins.builtin import HeadersFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import URLEncodedStreamFormatter
    from httpie.plugins.builtin import PrettyJSONStreamFormatter

# Generated at 2022-06-17 20:46:53.440758
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:47:03.061535
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor

    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.config = Config(env=env)
    env.config.default_options = PrettyOptions()
    env.config.default_options.__dict__.update(
        {'style': 'monokai', 'colors': 'true', 'format': 'all'})

    groups = ['headers', 'body']

# Generated at 2022-06-17 20:47:13.743144
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonProcessor
    from httpie.plugins.builtin import PrettyHttpHeadersProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import Pretty

# Generated at 2022-06-17 20:47:20.501546
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'colors': True, 'format': 'pretty'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].enabled == True
    assert formatting.enabled_plugins[1].enabled == True


# Generated at 2022-06-17 20:47:28.839870
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:47:38.437676
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:47:43.896848
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1: mime is not valid
    mime = "text/plain"
    assert Conversion.get_converter(mime) is None

    # Test case 2: mime is valid
    mime = "text/html"
    assert Conversion.get_converter(mime) is not None


# Generated at 2022-06-17 20:47:52.611405
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.colors = 256
    env.compress_level = 6
    env.max_redirects = 10
    env.max_streams = 10
    env.output_options = {}
    env.output_options_specified = False
    env.output_file = None
    env.output_file_specified = False
    env.output_dir = None
    env.output_dir_specified = False
    env.follow_redirects = True
    env.verify = True
   

# Generated at 2022-06-17 20:48:01.137144
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1: mime is valid
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert converter is not None
    assert converter.mime == mime

    # Test case 2: mime is invalid
    mime = 'application/json/'
    converter = Conversion.get_converter(mime)
    assert converter is None

    # Test case 3: mime is None
    mime = None
    converter = Conversion.get_converter(mime)
    assert converter is None

# Generated at 2022-06-17 20:48:12.778436
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:48:20.085295
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import pytest
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrettyPrintProcessor
    from httpie.plugins.builtin import HTTPPrettyStreamProcessor
    from httpie.plugins.builtin import HTTPPrettyURLEncodedProcessor
    from httpie.plugins.builtin import HTTPPrettyXMLProcessor
    from httpie.plugins.builtin import HTTPPrettyYAMLProcessor
    from httpie.plugins.builtin import HTTPPrettyHTMLProcessor
    from httpie.plugins.builtin import HTTPPrettyCSSProcessor
    from httpie.plugins.builtin import HTTPPrettyCSVProcessor
    from httpie.plugins.builtin import HTTPPrettyMarkdownProcessor

# Generated at 2022-06-17 20:48:30.525494
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor
    from httpie.plugins.builtin import HTTPieProcessor

# Generated at 2022-06-17 20:48:39.993144
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.colors = 256
    env.style = 'solarized'
    env.headers = True
    env.prettify = True
    env.stream = False
    env.verbose = False
    env.debug = False
    env.implicit_content_type = None
    env.implicit_content_type_params = {}
    env.follow_redirects = True
    env.max_redirects = 10
    env.timeout = None
    env.check_status = True
    env.verify = True
    env.cert = None
    env.cert_key = None
    env.auth = None
    env.auth_type = None
    env

# Generated at 2022-06-17 20:48:51.277420
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:48:58.203432
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': 'on'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].env == env
    assert f.enabled_plugins[0].colors == 'on'

# Generated at 2022-06-17 20:49:03.536095
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "httpie"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\x1b[32m"name"\x1b[39m: \x1b[33m"httpie"\x1b[39m}'

# Generated at 2022-06-17 20:49:12.337709
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    f = Formatting(['colors'], colors=True)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert f.format_headers(headers) == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'

    # Test case 2
    f = Formatting(['colors'], colors=False)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:49:19.343479
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/markdown') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
   

# Generated at 2022-06-17 20:49:30.484059
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-yml') is not None
    assert Conversion

# Generated at 2022-06-17 20:49:42.782502
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test for empty headers
    headers = ""
    groups = ["colors"]
    env = Environment()
    formatting = Formatting(groups, env)
    formatted_headers = formatting.format_headers(headers)
    assert formatted_headers == headers

    # Test for headers with no colors
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 13\r\n\r\n"
    groups = ["colors"]
    env = Environment()
    formatting = Formatting(groups, env)
    formatted_headers = formatting.format_headers(headers)
    assert formatted_headers == headers

    # Test for headers with colors

# Generated at 2022-06-17 20:49:54.081393
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_converter('text/tab') is not None
    assert Conversion.get_converter('text/x-toml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None

# Generated at 2022-06-17 20:50:02.225757
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/csv') is not None
    assert Conversion.get_converter('application/vnd.api+json') is not None
    assert Conversion.get_converter('application/vnd.api+xml') is not None
    assert Conversion.get_converter('application/vnd.api+yaml') is not None
    assert Conversion.get_converter('application/vnd.api+csv') is not None
    assert Conversion.get_converter('application/vnd.api+json; charset=utf-8') is not None
    assert Conversion

# Generated at 2022-06-17 20:50:06.051336
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:50:20.508697
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:50:22.337690
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:50:30.659654
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tsv')

# Generated at 2022-06-17 20:50:34.339679
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:50:39.086998
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1: no arguments
    # Expected result: enabled_plugins is empty
    f = Formatting([])
    assert f.enabled_plugins == []

    # Test case 2: groups is empty
    # Expected result: enabled_plugins is empty
    f = Formatting([])
    assert f.enabled_plugins == []

    # Test case 3: groups is not empty
    # Expected result: enabled_plugins is not empty
    f = Formatting(['colors'])
    assert f.enabled_plugins != []


# Generated at 2022-06-17 20:50:43.087824
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == [plugin_manager.get_formatters_grouped()['colors'][0](env=env, **kwargs)]

# Generated at 2022-06-17 20:50:51.843451
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter

# Generated at 2022-06-17 20:50:59.260003
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:51:04.518193
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import RawJSONProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodedProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor

# Generated at 2022-06-17 20:51:15.259855
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"hello": "world"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\x1b[32m"hello"\x1b[39m: \x1b[32m"world"\x1b[39m}'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"hello": "world"}'
    mime = 'application/xml'

# Generated at 2022-06-17 20:51:32.026007
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('image/png') is not None
    assert Conversion.get_converter('image/jpeg') is not None

# Generated at 2022-06-17 20:51:43.261003
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Case 1:
    #   Input:
    #       content = '{"name": "John", "age": 30, "car": null}'
    #       mime = 'application/json'
    #   Expected output:
    #       '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output
    # Case 2:
   

# Generated at 2022-06-17 20:51:45.722822
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting(['colors']).format_body('{"a": "b"}', 'application/json') == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:51:55.507236
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor

    # Test case 1
    # Input:
    #   groups: ['HTTPHeadersProcessor', 'JSONProcessor', 'PrettyProcessor', 'StreamProcessor']
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 2\r\n\r\n{}'
    # Expected output:
    #   'HTTP/1.1 200 OK\nContent-Type: application/json\nContent-Length: 2\n\n{\n}'
   

# Generated at 2022-06-17 20:52:00.291392
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:52:10.212323
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:52:13.792611
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:52:23.339429
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:52:32.635675
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.colors = False
    env.format = ['pretty']
    env.prettifiers = ['all']
    env.style = 'all'
    env.stream = False
    env.verbose = False
    env.debug = False
    env.implicit_content_type = 'json'
    env.implicit_content_type_strict = False
    env.default_options = []
    env.config_dir = '~/.config/httpie'
    env.config_path = '~/.config/httpie/config.json'
    env.download_dir = '~/Downloads'
    env.max_redirects = 10
    env.max_content_length = None
    env.timeout = None
    env.headers = []
    env.auth = None

# Generated at 2022-06-17 20:52:42.752088
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None

# Generated at 2022-06-17 20:52:56.244276
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:53:00.141721
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:53:11.302836
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('application/pdf') is None
    assert Conversion.get_converter('application/vnd.openxmlformats-officedocument.wordprocessingml.document') is None

# Generated at 2022-06-17 20:53:13.609030
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:53:19.725473
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format', 'syntax']
    env = Environment()
    kwargs = {'colors': True, 'format': 'pretty', 'syntax': 'pygments'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'PrettyFormatter'
    assert f.enabled_plugins[2].__class__.__name__ == 'PygmentsFormatter'


# Generated at 2022-06-17 20:53:25.861610
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.config = {}
    env.config_dir = None
    env.colors = 256
    env.is_windows = False
    env.stdout_isatty = True
    env.stdin_isatty = True
    env.is_windows = False
    env.config = {}
    env.config_dir = None
    env.colors = 256
    env.is_windows = False
    env.stdout_isatty = True
    env.stdin_isatty = True
    env.is_windows = False
    env.config = {}
    env.config_dir = None
    env.colors = 256
    env

# Generated at 2022-06-17 20:53:36.027786
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case:
    #   Input:
    #       headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #       groups: ['colors']
    #   Expected output:
    #       '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[32mOK\x1b[39m\r\n\x1b[37mContent-Type: application/json\r\n\r\n\x1b[39m'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']

# Generated at 2022-06-17 20:53:39.644829
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(groups=['colors'], env=env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:53:42.853297
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:53:51.362105
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_preferred_encoding
    from httpie.plugins.builtin import get_response_stream
    from httpie.plugins.builtin import get_style
    from httpie.plugins.builtin import get_theme
    from httpie.plugins.builtin import get_terminal_width

# Generated at 2022-06-17 20:54:14.470434
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/yaml") is not None
    assert Conversion.get_converter("application/csv") is not None
    assert Conversion.get_converter("application/vnd.api+json") is not None
    assert Conversion.get_converter("application/vnd.api+xml") is not None
    assert Conversion.get_converter("application/vnd.api+yaml") is not None
    assert Conversion.get_converter("application/vnd.api+csv") is not None
    assert Conversion.get_converter("application/vnd.api+json; charset=utf-8") is not None
    assert Conversion

# Generated at 2022-06-17 20:54:25.798835
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions

# Generated at 2022-06-17 20:54:36.213025
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor

    # Test 1:
    #   - groups: ['headers', 'body']
    #   - env: Environment()
    #   - kwargs: {}
    #   - enabled_plugins: [HTTPHeadersProcessor, JSONProcessor, PrettyProcessor, StreamProcessor, SyntaxHighlightProcessor, UnicodeProcessor, URLEncode

# Generated at 2022-06-17 20:54:46.679047
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1: no plugin enabled
    groups = []
    env = Environment()
    headers = "HTTP/1.1 200 OK\r\n" \
              "Content-Type: application/json\r\n" \
              "Content-Length: 2\r\n" \
              "Connection: close\r\n" \
              "Server: gunicorn/19.9.0\r\n" \
              "Date: Mon, 05 Nov 2018 23:59:59 GMT\r\n" \
              "\r\n" \
              "{}"
    formatting = Formatting(groups, env)
    assert formatting.format_headers(headers) == headers

    # Test case 2: plugin enabled
    groups = ["colors"]
    env = Environment()

# Generated at 2022-06-17 20:55:00.677736
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/x-yaml'), ConverterPlugin)

# Generated at 2022-06-17 20:55:11.754311
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('text/html')
    assert not converter.supports('application/xml')
    assert not converter.supports('text/xml')
    assert not converter.supports('application/x-www-form-urlencoded')
    assert not converter.supports('application/x-www-form-urlencoded; charset=utf-8')
    assert not converter.supports('multipart/form-data')
    assert not converter.supports('multipart/form-data; boundary=---------------------------7e13g1ae0ae0c')
    assert not converter.supports('application/octet-stream')

# Generated at 2022-06-17 20:55:18.378722
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == []

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': 'on'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins != []

    # Test case 3
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': 'off'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == []

    # Test case 4
    groups = ['colors']
    env = Environment()

# Generated at 2022-06-17 20:55:25.213838
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n') == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: text/plain\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:55:28.139670
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:55:32.063067
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(groups=['colors'], env=env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].env == env
