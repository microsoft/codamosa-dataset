

# Generated at 2022-06-17 20:45:41.469600
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:45:50.393582
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])
    assert Formatting(['colors', 'format'])
    assert Formatting(['colors', 'format', 'format_options'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_format'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_format', 'colors_format_options'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_format', 'colors_format_options', 'colors_format_options_format'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_format', 'colors_format_options', 'colors_format_options_format', 'colors_format_options_format_options'])

# Generated at 2022-06-17 20:45:58.291963
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    # Input: groups = ['colors'], env = Environment(), kwargs = {}
    # Expected output: enabled_plugins = [ColorsFormatter]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == [ColorsFormatter]

    # Test case 2:
    # Input: groups = ['colors', 'format'], env = Environment(), kwargs = {}
    # Expected output: enabled_plugins = [ColorsFormatter, FormatFormatter]
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:46:05.672095
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    # Expected output: 'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)
    result = formatting.format_headers(headers)
    assert result == 'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'

    # Test case 2:
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json

# Generated at 2022-06-17 20:46:16.959906
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None


# Generated at 2022-06-17 20:46:23.712248
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:46:35.226184
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test for method format_headers of class Formatting
    # Given
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 12\r\n\r\n'
    # When
    formatted_headers = formatting.format_headers(headers)
    # Then

# Generated at 2022-06-17 20:46:44.348754
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups = ['colors']
    # Output:
    #   headers = '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    formatting = Formatting(groups)
    headers = formatting.format_headers(headers)

# Generated at 2022-06-17 20:46:49.487258
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'colors': True, 'format': 'pretty'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[1].__class__.__name__ == 'PrettyFormatter'

# Generated at 2022-06-17 20:47:01.566287
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded;charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded;charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded;charset=utf-8') is not None

# Generated at 2022-06-17 20:47:15.214882
# Unit test for method format_body of class Formatting

# Generated at 2022-06-17 20:47:25.629726
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:47:36.627818
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('application/yaml')
    assert not Conversion.get_converter('application/html')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('/json/')
    assert not Conversion.get_converter('/json/xml')
    assert not Conversion.get_converter('/json/xml/')
    assert not Conversion.get_converter('/json/xml/yaml')

# Generated at 2022-06-17 20:47:41.882989
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'FormatFormatter'
    assert f.enabled_plugins[0].style == 'solarized'
    assert f.enabled_plugins[1].style == 'solarized'


# Generated at 2022-06-17 20:47:50.207815
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Given
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    mime = 'application/json'
    content = '{"name":"John","age":30,"car":null}'
    # When
    result = formatting.format_body(content, mime)
    # Then
    assert result == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

# Generated at 2022-06-17 20:47:53.845799
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:47:59.753013
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': True}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].colors == True

# Generated at 2022-06-17 20:48:06.883369
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:48:17.352890
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12\r\n\r\n'
    groups = ['colors']
    env = Environment()
    f = Formatting(groups, env)
    assert f.format_headers(headers) == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: text/html; charset=utf-8\x1b[0m\r\n\x1b[37m\x1b[1mContent-Length: 12\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:48:28.489356
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: "abc"
    #   - mime: "text/plain"
    # Expected output: "abc"
    content = "abc"
    mime = "text/plain"
    groups = ["colors"]
    env = Environment()
    formatting = Formatting(groups, env)
    assert formatting.format_body(content, mime) == content

    # Test case 2:
    # Input:
    #   - content: "abc"
    #   - mime: "application/json"
    # Expected output: "abc"
    content = "abc"
    mime = "application/json"
    groups = ["colors"]
    env = Environment()
    formatting = Formatting(groups, env)

# Generated at 2022-06-17 20:48:40.137440
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

'''
    groups = ['colors', 'format']
    env = Environment()
    f = Formatting(groups, env)
    assert f.format_headers(headers) == '''\
HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

'''



# Generated at 2022-06-17 20:48:43.771138
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:48:51.112195
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/octet-stream') is None
    assert Conversion.get_converter('application/') is None
    assert Conversion.get_converter('application') is None
    assert Conversion.get_converter('') is None
    assert Conversion.get_converter(None) is None


# Generated at 2022-06-17 20:49:01.072714
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:49:10.043032
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 9\r\n\r\n"
    groups = ["colors"]
    env = Environment()
    formatting = Formatting(groups, env)
    formatted_headers = formatting.format_headers(headers)
    assert formatted_headers == "\x1b[37mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37mContent-Type: text/html; charset=utf-8\x1b[0m\r\n\x1b[37mContent-Length: 9\x1b[0m\r\n\r\n"


# Generated at 2022-06-17 20:49:13.161325
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].__class__.__module__ == 'httpie.plugins.builtin.colors'

# Generated at 2022-06-17 20:49:16.489675
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 20:49:19.320973
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(['colors'], env=env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].env == env


# Generated at 2022-06-17 20:49:30.444765
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:49:42.746313
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import JSONLinesFormatter
    from httpie.plugins.builtin import JSONLinesStreamFormatter
    from httpie.plugins.builtin import JSONLinesPrettyFormatter
    from httpie.plugins.builtin import JSONLinesPrettyStreamFormatter
    from httpie.plugins.builtin import JSONLinesOptions
    from httpie.plugins.builtin import JSONLinesPrettyOptions
    from httpie.plugins.builtin import JSONStreamOptions
    from httpie.plugins.builtin import JSON

# Generated at 2022-06-17 20:49:56.448017
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    #   Input:
    #       content: '{"name": "John Doe", "age": "30"}'
    #       mime: 'application/json'
    #   Expected output:
    #       '{\n    "name": "John Doe",\n    "age": "30"\n}'
    content = '{"name": "John Doe", "age": "30"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John Doe",\n    "age": "30"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    #   Input:
    #       content: '{"name": "John Doe", "age": "30"}'
   

# Generated at 2022-06-17 20:50:03.540065
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded") is not None
    assert Conversion.get_converter("text/html") is not None
    assert Conversion.get_converter("text/plain") is not None
    assert Conversion.get_converter("text/csv") is not None
    assert Conversion.get_converter("text/tsv") is not None
    assert Conversion.get_converter("text/yaml") is not None
    assert Conversion.get_converter("text/yml") is not None
    assert Conversion.get_converter("text/xml") is not None
    assert Conversion.get_conver

# Generated at 2022-06-17 20:50:08.654774
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/unknown')
    assert not Conversion.get_converter('unknown/unknown')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:50:18.358417
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

{}'''
    f = Formatting(['colors'])
    assert f.format_headers(headers) == '''\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[32mOK\x1b[39m
\x1b[37mContent-Type: \x1b[33mapplication/json\x1b[39m
\x1b[37mContent-Length: \x1b[33m2\x1b[39m

{}'''


# Generated at 2022-06-17 20:50:26.600509
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/x-yaml'), ConverterPlugin)

# Generated at 2022-06-17 20:50:36.592964
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    #   env: Environment()
    #   kwargs: {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    env = Environment()
    kwargs = {}

# Generated at 2022-06-17 20:50:46.701423
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None

# Generated at 2022-06-17 20:50:58.967378
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPieJSONFormatter
    from httpie.plugins.builtin import HTTPiePrettyFormatter
    from httpie.plugins.builtin import HTTPieTableFormatter
    from httpie.plugins.builtin import HTTPieURLEncodedFormatter
    from httpie.plugins.builtin import HTTPiePrettyURLEncodedFormatter
    from httpie.plugins.builtin import HTTPiePrettyJSONFormatter
    from httpie.plugins.builtin import HTTPiePrettyTableFormatter
    from httpie.plugins.builtin import HTTPiePrettyXMLFormatter
    from httpie.plugins.builtin import HTTPieXMLFormatter
    from httpie.plugins.builtin import HTTPiePrettyHTMLFormatter
    from httpie.plugins.builtin import HTTPieHTMLFormatter
   

# Generated at 2022-06-17 20:51:09.596847
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonProcessor
    from httpie.plugins.builtin import PrettyHttpHeadersProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import PrettyHttpBodyProcessor
    from httpie.plugins.builtin import Pretty

# Generated at 2022-06-17 20:51:20.023570
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-yml') is not None
    assert Conversion

# Generated at 2022-06-17 20:51:32.077060
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:51:43.303565
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:51:51.351130
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:51:59.750152
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name": "John", "age": 30, "city": "New York"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:

# Generated at 2022-06-17 20:52:03.788070
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': 'on'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:52:06.470866
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:52:15.322360
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:52:18.497962
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.__class__.__name__ == 'JSONConverter'


# Generated at 2022-06-17 20:52:25.897138
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    # Output:
    #   headers: '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']

# Generated at 2022-06-17 20:52:34.277674
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    env.stdout_isatty = True
    env.colors = 256
    env.style = 'solarized'
    env.headers = {'Content-Type': 'application/json'}
    env.prettify = True
    env.stream = False
    env.verify = True
    env.timeout = 10
    env.max_redirects = 10
    env.follow_redirects = True
    env.output_file = None
    env.output_dir = None
    env.download_filename = None
    env.download_output_dir = None
    env.download_resume = False
    env.download_session = None
    env.download_chunk_size = 1024

# Generated at 2022-06-17 20:52:43.100759
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].env.colors == True


# Generated at 2022-06-17 20:52:51.654028
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('multipart/form-data'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/octet-stream'), ConverterPlugin)


# Generated at 2022-06-17 20:53:02.143926
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>'''
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)
    result = formatting.format_headers(headers)

# Generated at 2022-06-17 20:53:11.919377
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('application/pdf') is None
    assert Conversion.get_converter('application/vnd.ms-excel') is None
    assert Conversion

# Generated at 2022-06-17 20:53:14.079058
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:53:22.182980
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:53:33.260396
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.config = {}
    env.config_dir = ''
    env.colors = 256
    env.default_options = {}
    env.request = None
    env.args = []
    env.output_options = {}
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.stdin_isatty = False
    env.stdout_encoding = 'utf8'
    env.stdin_encoding = 'utf8'
    env.stdin_errors = 'strict'
    env.is_windows = False
    env.is_macos = False

# Generated at 2022-06-17 20:53:43.165307
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: close\r\n' \
              '\r\n' \
              '{}'
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = formatting.format_headers(headers)

# Generated at 2022-06-17 20:53:51.603577
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:53:55.497877
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:54:09.650065
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:54:14.360119
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('application/yaml')
    assert not Conversion.get_converter('application/unknown')
    assert not Conversion.get_converter('unknown/unknown')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:54:25.797039
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert Conversion.get_converter('application/json').supports('application/json')
    assert not Conversion.get_converter('application/json').supports('application/xml')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8;')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8; ')

# Generated at 2022-06-17 20:54:31.058169
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'colors': True, 'format': 'pretty'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[1].enabled == True


# Generated at 2022-06-17 20:54:39.701011
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html').mime == 'text/html'
    assert Conversion.get_converter('text/html').supports('text/html')
    assert not Conversion.get_converter('text/html').supports('text/plain')
    assert not Conversion.get_converter('text/html').supports('text/css')
    assert not Conversion.get_converter('text/html').supports('text/javascript')
    assert not Conversion.get_converter('text/html').supports('application/json')
    assert not Conversion.get_converter('text/html').supports('application/xml')
    assert not Conversion.get_converter('text/html').supports('application/xhtml+xml')

# Generated at 2022-06-17 20:54:42.174801
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:54:50.888188
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert Conversion.get_converter('application/xml').mime == 'application/xml'
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert Conversion.get_converter('text/html').mime == 'text/html'
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert Conversion.get_converter('text/plain').mime == 'text/plain'

# Generated at 2022-06-17 20:55:02.063801
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodedProcessor
    from httpie.plugins.builtin import XMLProcessor
    from httpie.plugins.builtin import HTMLProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyHighlightProcessor
    from httpie.plugins.builtin import HTTPBodyStreamProcessor
    from httpie.plugins.builtin import HTTPBodyStreamHighlightProcessor


# Generated at 2022-06-17 20:55:06.728433
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': True}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:55:15.999431
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('text/html')
    assert Conversion.get_converter('text/plain')
    assert Conversion.get_converter('text/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application/jsonxml')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('application/json/xml/')
    assert not Conversion.get_converter('application/json/xml/text')
    assert not Conversion.get_converter('application/json/xml/text/html')

# Generated at 2022-06-17 20:55:28.904084
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(groups=['colors'])
    assert Formatting(groups=['colors', 'format'])
    assert Formatting(groups=['colors', 'format', 'colors'])
    assert Formatting(groups=['colors', 'colors'])
    assert Formatting(groups=['colors', 'colors', 'colors'])
    assert Formatting(groups=['colors', 'colors', 'colors', 'colors'])
    assert Formatting(groups=['colors', 'colors', 'colors', 'colors', 'colors'])
    assert Formatting(groups=['colors', 'colors', 'colors', 'colors', 'colors', 'colors'])

# Generated at 2022-06-17 20:55:36.488382
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Given
    groups = ['colors']
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    env = Environment()
    formatting = Formatting(groups, env)

    # When
    result = formatting.format_body(content, mime)

    # Then