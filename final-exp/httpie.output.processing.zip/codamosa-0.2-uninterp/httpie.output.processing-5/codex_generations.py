

# Generated at 2022-06-17 20:45:47.463342
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test case 1
    headers = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=utf-8
Content-Length: 13
Connection: keep-alive
Server: gunicorn/19.9.0
Date: Tue, 23 Apr 2019 09:27:18 GMT

'''
    groups = ['colors']
    env = Environment()
    env.stdout_isatty = True
    env.colors = 256
    env.style = 'solarized'
    env.headers = True
    env.stream = False
    env.verbose = False
    env.debug = False
    env.implicit_content_type = None
    env.follow_redirects = True
    env.max_redirects = 10
    env.timeout = None

# Generated at 2022-06-17 20:46:00.764396
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: '{"name": "John", "age": 30, "city": "New York"}'
    #   - mime: 'application/json'
    # Output:
    #   - content: '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_content = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    formatting = Formatting(['json'])
    assert formatting.format_body(content, mime) == expected_content

    #

# Generated at 2022-06-17 20:46:02.306886
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    formatting = Formatting(groups, env)
    assert formatting.enabled_plugins == []

# Generated at 2022-06-17 20:46:05.986122
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors', 'format']
    kwargs = {'colors': True, 'format': 'pretty'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[1].__class__.__name__ == 'PrettyFormatter'

# Generated at 2022-06-17 20:46:17.305559
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name": "John", "age": 30, "car": null}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    actual = Formatting(['json']).format_body(content, mime)
    assert actual == expected

    # Test case 2:
    # Input:
    #   content: '<html

# Generated at 2022-06-17 20:46:23.400849
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"key": "value"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\x1b[94m"key"\x1b[39m: \x1b[93m"value"\x1b[39m}'

# Generated at 2022-06-17 20:46:34.889847
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:46:44.108186
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import Formatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import HTTPieJSONEncoder
    from httpie.plugins.builtin import JSONEncoder
    from httpie.plugins.builtin import JSONStreamWriter
    from httpie.plugins.builtin import JSONLinesStreamWriter
    from httpie.plugins.builtin import JSONLinesPrettyStreamWriter
    from httpie.plugins.builtin import JSONLinesStreamWriter
    from httpie.plugins.builtin import JSONLinesPrettyStreamWriter
    from httpie.plugins.builtin import JSONLinesStreamWriter

# Generated at 2022-06-17 20:46:53.966089
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:47:00.089629
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n') == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: text/plain\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:47:13.151955
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.registry import plugin_manager
    plugin_manager.register(JSONFormatter)
    plugin_manager.register(PrettyOptions)
    json_str = '{"name": "John", "age": 30, "city": "New York"}'
    json_str_pretty = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    json_str_pretty_indent = '{\n        "name": "John",\n        "age": 30,\n        "city": "New York"\n    }'

# Generated at 2022-06-17 20:47:24.310285
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/x-www-form-urlencoded')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8;')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8; ')
    assert not Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8; a=b')

# Generated at 2022-06-17 20:47:36.295184
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/x-yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)

# Generated at 2022-06-17 20:47:41.172688
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPieJSONFormatter
    from httpie.plugins.builtin import HTTPiePrettyFormatter
    from httpie.plugins.builtin import HTTPieColorsFormatter
    from httpie.plugins.builtin import HTTPieSyntaxHighlightFormatter
    from httpie.plugins.builtin import HTTPieFormatTableFormatter
    from httpie.plugins.builtin import HTTPieFormatJSONLinesFormatter
    from httpie.plugins.builtin import HTTPieFormatJSONLinesPPFormatter
    from httpie.plugins.builtin import HTTPieFormatJSONLinesColorsFormatter
    from httpie.plugins.builtin import HTTPieFormatJSONLinesSyntaxHighlightFormatter
    from httpie.plugins.builtin import HTTPieFormatJSONLinesTableFormatter
    from httpie.plugins.builtin import HTTP

# Generated at 2022-06-17 20:47:42.632949
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter.mime == "application/json"


# Generated at 2022-06-17 20:47:52.105603
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None

# Generated at 2022-06-17 20:48:00.789425
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-toml') is not None
    assert Conversion.get_converter('text/x-python') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:48:06.299185
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/x-www-form-urlencoded')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('json')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:48:16.940966
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion

# Generated at 2022-06-17 20:48:21.199808
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:48:32.560909
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/html').supports('text/html')
    assert Conversion.get_converter('text/html').supports('text/plain') is False
    assert Conversion.get_converter('text/html').supports('text/html') is True
    assert Conversion.get_converter('text/html').supports('text/plain') is False
    assert Conversion.get_converter('text/html').supports('text/html') is True
    assert Conversion.get_converter('text/html').supports('text/plain') is False
    assert Conversion.get_converter('text/html').supports('text/html') is True
    assert Conversion.get_converter('text/html').supp

# Generated at 2022-06-17 20:48:41.237209
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    # Expected output: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert Formatting(['colors']).format_headers(headers) == 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

    # Test case 2:
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #

# Generated at 2022-06-17 20:48:50.993365
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    # Expected output: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = []
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.format_headers(headers) == headers

    # Test case 2
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #

# Generated at 2022-06-17 20:49:01.030603
# Unit test for constructor of class Formatting

# Generated at 2022-06-17 20:49:10.334224
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    import json
    import pytest
    import os

    # Test case 1:
    #   - headers:
    #       - Content-Type: application/json
    #       - Content-Length: 2
    #   - groups:
    #

# Generated at 2022-06-17 20:49:12.230672
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:49:19.272837
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups = ['colors']
    #   env = Environment()
    #   kwargs = {}
    # Expected output:
    #   headers = '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Format

# Generated at 2022-06-17 20:49:30.404239
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "city": "New York"}'
    #   mime = 'application/json'
    # Expected output:
    #   content = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_content = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    f = Formatting(['json'])
    assert f.format_body(content, mime) == expected_content

    # Test

# Generated at 2022-06-17 20:49:34.012832
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    assert f.format_body('{"a": "b"}', 'application/json') == '{\n    "a": "b"\n}'



# Generated at 2022-06-17 20:49:44.668434
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
    Content-Type: application/json
    Date: Mon, 27 Jul 2009 12:28:53 GMT
    Server: Apache/2.2.14 (Win32)
    Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
    Content-Length: 88
    Connection: Closed
    '''
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:49:59.950693
# Unit test for constructor of class Formatting

# Generated at 2022-06-17 20:50:09.955217
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    assert f.format_body('{"a": 1}', 'application/json') == '\x1b[37m{\x1b[39;49;00m\n  \x1b[37m"a"\x1b[39;49;00m\x1b[37m: \x1b[39;49;00m\x1b[34m1\x1b[39;49;00m\n\x1b[37m}\x1b[39;49;00m\n'
    assert f.format_body('{"a": 1}', 'application/xml') == '{"a": 1}'

# Generated at 2022-06-17 20:50:15.659419
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    Test the method format_body of class Formatting
    """
    # Test the case that the content is not json
    content = '{"key": "value"}'
    mime = 'text/html'
    formatting = Formatting(['colors'])
    assert formatting.format_body(content, mime) == content

    # Test the case that the content is json
    content = '{"key": "value"}'
    mime = 'application/json'
    formatting = Formatting(['colors'])
    assert formatting.format_body(content, mime) == '{\n    "key": "value"\n}'


# Generated at 2022-06-17 20:50:17.777394
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:50:26.223408
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:50:36.415606
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/plain') is not None

# Generated at 2022-06-17 20:50:46.588543
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_converter('text/vnd.graphviz') is not None

# Generated at 2022-06-17 20:50:58.922505
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/toml') is not None
    assert Conversion.get_converter('application/msgpack') is not None
    assert Conversion.get_converter('application/x-msgpack') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_con

# Generated at 2022-06-17 20:51:09.597008
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"key1": "value1", "key2": "value2"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "key1": "value1",\n    "key2": "value2"\n}'
    content = '{"key1": "value1", "key2": "value2"}'
    mime = 'application/json'
    expected_output = '{\n    "key1": "value1",\n    "key2": "value2"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"key1": "value1

# Generated at 2022-06-17 20:51:14.157548
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(['colors'], env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].env == env
    assert f.enabled_plugins[0].enabled == True

# Generated at 2022-06-17 20:51:27.948925
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    f = Formatting(groups=['colors'], env=env)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert f.format_headers(headers) == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:51:34.553782
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    #   groups = ['colors']
    #   env = Environment()
    #   kwargs = {}
    #   expected = [<httpie.plugins.builtin.Formatter.ColorsFormatter object at 0x7f8e4a4b7f60>]
    groups = ['colors']
    env = Environment()
    kwargs = {}

# Generated at 2022-06-17 20:51:45.513242
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>'''
    f = Formatting(['colors'])

# Generated at 2022-06-17 20:51:52.630071
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.registry import plugin

# Generated at 2022-06-17 20:51:57.472313
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')


# Generated at 2022-06-17 20:52:02.235462
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': 'on'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:52:11.875527
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:52:13.699877
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    f = Formatting(groups, env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].env == env


# Generated at 2022-06-17 20:52:23.268244
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:52:32.601749
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrint0Processor
    from httpie.plugins.builtin import HTTPPrintProcessor
    from httpie.plugins.builtin import HTTPUnicodeProcessor
    from httpie.plugins.builtin import HTTPXMLProcessor
    from httpie.plugins.builtin import HTTPYAMLProcessor
    from httpie.plugins.builtin import HTTPPrettyURLEncodedProcessor
    from httpie.plugins.builtin import HTTPPrettyMultipartProcessor
    from httpie.plugins.builtin import HTTPPrettyStreamProcessor
    from httpie.plugins.builtin import HTTPPrettyBytesProcessor
    from httpie.plugins.builtin import HTTPPrettyRawProcessor

# Generated at 2022-06-17 20:52:49.398120
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.__class__.__name__ == 'JSONConverter'
    converter = Conversion.get_converter('application/xml')
    assert converter.mime == 'application/xml'
    assert converter.__class__.__name__ == 'XMLConverter'
    converter = Conversion.get_converter('application/yaml')
    assert converter.mime == 'application/yaml'
    assert converter.__class__.__name__ == 'YAMLConverter'
    converter = Conversion.get_converter('application/x-www-form-urlencoded')
    assert converter.mime == 'application/x-www-form-urlencoded'
    assert converter.__

# Generated at 2022-06-17 20:53:01.494064
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.color = False
    env.config = {}
    env.config_dir = None
    env.config_path = None
    env.debug = False
    env.follow_redirects = True
    env.headers = {}
    env.history = []
    env.http2 = False
    env.ignore_stdin = False
    env.max_redirects = 10
    env.output_file = None
    env.output_options = {}
    env.output_stream = None

# Generated at 2022-06-17 20:53:11.893942
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/xml') is None
    assert Conversion.get_converter('application/xml') is None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None

# Generated at 2022-06-17 20:53:20.249842
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups = ['colors']
    #   env = Environment()
    #   kwargs = {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200 \x1b[32mOK\x1b[39m\r\n\x1b[37mContent-Type: \x1b[33mapplication/json\x1b[39m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:53:26.165794
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1: mime is not valid
    mime = 'text'
    content = '{"name":"John"}'
    expected_content = '{"name":"John"}'
    assert Formatting([]).format_body(content, mime) == expected_content

    # Test case 2: mime is valid, but no plugins are enabled
    mime = 'application/json'
    content = '{"name":"John"}'
    expected_content = '{"name":"John"}'
    assert Formatting([]).format_body(content, mime) == expected_content

    # Test case 3: mime is valid, and plugins are enabled
    mime = 'application/json'
    content = '{"name":"John"}'
    expected_content = '{\n    "name": "John"\n}'

# Generated at 2022-06-17 20:53:36.081840
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test 1
    groups = ['colors']
    env = Environment()
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[0].style == 'solarized'
    assert formatting.enabled_plugins[0].env == env

    # Test 2
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:53:40.279608
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:53:49.354975
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PrettyURLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import PrettyHTMLFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import PrettyXMLFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawURLEncodedFormatter
    from httpie.plugins.builtin import RawHTMLFormatter
    from httpie.plugins.builtin import RawXMLForm

# Generated at 2022-06-17 20:53:59.892857
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test 1:
    # Test for constructor of class Formatting
    # Test for empty list of groups
    # Expected result:
    #   enabled_plugins is empty
    groups = []
    formatting = Formatting(groups)
    assert formatting.enabled_plugins == []

    # Test 2:
    # Test for constructor of class Formatting
    # Test for non-empty list of groups
    # Expected result:
    #   enabled_plugins is not empty
    groups = ['colors']
    formatting = Formatting(groups)
    assert formatting.enabled_plugins != []



# Generated at 2022-06-17 20:54:06.309374
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors', 'format']
    kwargs = {'colors': True, 'format': 'pretty'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[1].__class__.__name__ == 'PrettyFormatter'

# Generated at 2022-06-17 20:54:30.245387
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions

# Generated at 2022-06-17 20:54:38.695841
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/x-yaml'), ConverterPlugin)

# Generated at 2022-06-17 20:54:42.706596
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:54:51.143181
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1
    mime = 'application/json'
    assert is_valid_mime(mime) == True
    assert Conversion.get_converter(mime).supports(mime) == True
    assert Conversion.get_converter(mime).convert(mime) == 'application/json'

    # Test case 2
    mime = 'application/xml'
    assert is_valid_mime(mime) == True
    assert Conversion.get_converter(mime).supports(mime) == True
    assert Conversion.get_converter(mime).convert(mime) == 'application/xml'

    # Test case 3
    mime = 'application/html'
    assert is_valid_mime(mime) == True

# Generated at 2022-06-17 20:54:56.497473
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].style == 'solarized'

# Generated at 2022-06-17 20:54:57.950059
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')

# Generated at 2022-06-17 20:55:03.405839
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor

    available_plugins = plugin_manager.get_formatters_grouped()
    assert available_plugins == {
        'headers': [HTTPHeadersProcessor],
        'body': [JSONProcessor, PrettyProcessor, SyntaxHighlightProcessor]
    }

    env = Environment()
    env.stdout_isatty = True
    env.colors = 256
    env.style = 'solarized'
    env.format = 'colors'
    env.prettify = True
    env.syntax = True

# Generated at 2022-06-17 20:55:13.833964
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:55:24.807503
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: '{"name": "John", "age": 30, "city": "New York"}'
    #   - mime: 'application/json'
    # Expected output:
    #   - '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
   

# Generated at 2022-06-17 20:55:26.594616
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert converter.mime == 'text/html'
