

# Generated at 2022-06-17 20:45:43.806155
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Thu, 23 May 2019 09:36:20 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Wed, 22 Aug 2012 19:15:56 GMT
ETag: "1d3-4ab6b59249500"
Accept-Ranges: bytes
Content-Length: 467
Vary: Accept-Encoding
Content-Type: text/html

'''
    f = Formatting(['colors'])
    print(f.format_headers(headers))


# Generated at 2022-06-17 20:45:48.405961
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'format': 'json'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'JsonFormatter'

# Generated at 2022-06-17 20:45:56.329382
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: close\r\n' \
              '\r\n' \
              '{}'
    expected = 'HTTP/1.1 200 OK\r\n' \
               'Content-Type: application/json\r\n' \
               'Content-Length: 2\r\n' \
               'Connection: close\r\n' \
               '\r\n'
    f = Formatting(['headers'])
    assert f.format_headers(headers) == expected


# Generated at 2022-06-17 20:46:02.751087
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyURLEncodedProcessor
    from httpie.plugins.builtin import HTTPPrettyXMLProcessor
    from httpie.plugins.builtin import HTTPPrettyMultipartProcessor
    from httpie.plugins.builtin import HTTPPrettyHTMLProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrettyJsonProcessor
    from httpie.plugins.builtin import HTTPPrettyJsonLinesProcessor
    from httpie.plugins.builtin import HTTPPrettyJsonLinesStreamProcessor
    from httpie.plugins.builtin import HTTPPrettyJsonStreamProcessor
    from httpie.plugins.builtin import HTTPPrettyXmlProcessor

# Generated at 2022-06-17 20:46:13.439169
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPPrettyPrinter
    from httpie.plugins.builtin import JSONPrettyPrinter
    from httpie.plugins.builtin import Formatter
    from httpie.plugins.builtin import PrettyPrinter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import SyntaxHighlight
    from httpie.plugins.builtin import UnixTimestamp
    from httpie.plugins.builtin import HTTPieFormatter
    from httpie.plugins.builtin import HTTPiePrettyPrinter
    from httpie.plugins.builtin import HTTPieStreamFormatter
    from httpie.plugins.builtin import HTTPieSyntaxHighlight
    from httpie.plugins.builtin import HTTPieUnixTimestamp
    from httpie.plugins.builtin import HTTPieJSONPrettyPrinter

# Generated at 2022-06-17 20:46:21.785852
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import JSONLinesFormatter
    from httpie.plugins.builtin import JSONLinesPrettyFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import PrettyHTMLFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import PrettyXMLFormatter

    # Test JSONFormatter
    json_formatter = JSONFormatter()
    json_formatter.enabled = True
    json_formatter.env = Environment()
    json_formatter.env.stdout_isatty = True
    json_formatter.env.stdout_is_redirected = False

# Generated at 2022-06-17 20:46:33.970877
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name":"John","age":30,"city":"New York"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name":"John","age":30,"city":"New York"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"

# Generated at 2022-06-17 20:46:38.239392
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:46:45.771599
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "city": "New York"}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:

# Generated at 2022-06-17 20:46:55.412818
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
   

# Generated at 2022-06-17 20:47:08.361218
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)

# Generated at 2022-06-17 20:47:13.102913
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-toml') is not None
    assert Conversion.get_converter('text/x-ini') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:47:24.269217
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test 1
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12\r\n\r\n'
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.format_headers(headers) == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: text/html; charset=utf-8\x1b[0m\r\n\x1b[1mContent-Length: 12\x1b[0m\r\n\r\n'

    # Test 2

# Generated at 2022-06-17 20:47:36.293954
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:47:41.173066
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])
    assert Formatting(['colors', 'format'])
    assert Formatting(['colors', 'format', 'format_json'])
    assert Formatting(['colors', 'format', 'format_json', 'format_html'])
    assert Formatting(['colors', 'format', 'format_json', 'format_html', 'format_xml'])
    assert Formatting(['colors', 'format', 'format_json', 'format_html', 'format_xml', 'format_javascript'])
    assert Formatting(['colors', 'format', 'format_json', 'format_html', 'format_xml', 'format_javascript', 'format_css'])

# Generated at 2022-06-17 20:47:51.513661
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/markdown'), ConverterPlugin)

# Generated at 2022-06-17 20:47:59.631672
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('application/yaml')
    assert not Conversion.get_converter('application/unknown')
    assert not Conversion.get_converter('unknown/unknown')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)

# Generated at 2022-06-17 20:48:06.770023
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    # Input: groups = ['colors'], env = Environment(), kwargs = {}
    # Expected output: enabled_plugins = [colors]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == [colors]

    # Test case 2:
    # Input: groups = ['colors', 'format'], env = Environment(), kwargs = {}
    # Expected output: enabled_plugins = [colors, format]
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == [colors, format]

    # Test case 3

# Generated at 2022-06-17 20:48:12.531384
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    f = Formatting(groups=['colors'], env=env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].env == env
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:48:19.990322
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded; charset=utf-8") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded; charset=utf-8") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded; charset=utf-8") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded; charset=utf-8") is not None
    assert Conversion.get

# Generated at 2022-06-17 20:48:32.019592
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/csv') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=UTF-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:48:41.168681
# Unit test for constructor of class Formatting

# Generated at 2022-06-17 20:48:50.930336
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert converter.mime == mime
    assert converter.supports(mime)
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert not converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')

# Generated at 2022-06-17 20:49:01.030372
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: {"name": "John", "age": 30, "city": "New York"}
    #   mime: application/json
    # Expected output:
    #   content:
    #   {
    #       "name": "John",
    #       "age": 30,
    #       "city": "New York"
    #   }
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_content = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    formatting = Formatting(groups=['json'])
    assert formatting.format_body(content, mime) == expected

# Generated at 2022-06-17 20:49:10.334765
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = False
    env.stdin_isatty = False
    env.colors = 256
    env.config = {}
    env.config_dir = None
    env.config_path = None
    env.config_defaults = {}
    env.config_overrides = {}
    env.config_override_str = None
    env.config_files = []
    env.debug = False
    env.follow_redirects = True
    env.max_redirects = 10
    env.output_file = None
    env.output_options = {}
    env.output_stream = None
    env.output_stream_encoding = None
    env.output_stream_errors = None

# Generated at 2022-06-17 20:49:18.014456
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/vnd.api+json') is not None
    assert Conversion.get_converter('application/vnd.api+xml') is not None
    assert Conversion.get_converter('application/vnd.api+yaml') is not None
    assert Conversion.get_converter('application/vnd.api+json; charset=utf-8') is not None
    assert Conversion.get_converter('application/vnd.api+xml; charset=utf-8') is not None

# Generated at 2022-06-17 20:49:29.581688
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    # Output:
    #   headers: '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    formatting = Formatting(groups)
    headers = formatting.format_headers(headers)

# Generated at 2022-06-17 20:49:32.393131
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].env == Environment()


# Generated at 2022-06-17 20:49:43.672062
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("application/xml"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/html"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/plain"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/csv"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/tab-separated-values"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/yaml"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/x-yaml"), ConverterPlugin)

# Generated at 2022-06-17 20:49:54.837890
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(groups=['colors']).enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert Formatting(groups=['colors', 'format']).enabled_plugins[1].__class__.__name__ == 'FormatFormatter'
    assert Formatting(groups=['colors', 'format', 'format']).enabled_plugins[2].__class__.__name__ == 'FormatFormatter'
    assert Formatting(groups=['colors', 'format', 'colors']).enabled_plugins[2].__class__.__name__ == 'ColorsFormatter'
    assert Formatting(groups=['colors', 'colors']).enabled_plugins[1].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:49:59.102298
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')

# Generated at 2022-06-17 20:50:08.491551
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('image/png') is not None
    assert Conversion.get_converter('image/jpeg') is not None
    assert Conversion.get_converter

# Generated at 2022-06-17 20:50:15.783396
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    #   env: Environment()
    #   kwargs: {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[36mOK\x1b[39m\r\n\x1b[37mContent-Type: \x1b[33mapplication/json\x1b[39m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:50:24.657476
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('application/vnd.yaml') is not None
    assert Conversion.get_converter('application/vnd.yml') is not None
    assert Conversion.get_converter('application/vnd.x-yaml') is not None

# Generated at 2022-06-17 20:50:35.491319
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/vnd.api+json') is not None
    assert Conversion.get_converter('application/vnd.api+xml') is not None
    assert Conversion.get_converter('application/vnd.api+yaml') is not None
    assert Conversion.get_converter('application/vnd.api+yml') is not None
    assert Conversion.get_converter('application/vnd.api+json; charset=utf-8') is not None
   

# Generated at 2022-06-17 20:50:41.004835
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "city": "New York"}'
    #   mime = 'application/json'
    # Expected output:
    #   content = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    assert Formatting(['json']).format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'

    # Test case 2:
    # Input:
    #   content = '

# Generated at 2022-06-17 20:50:50.256630
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: '{"name": "John", "age": 30, "car": null}'
    #   - mime: 'application/json'
    # Expected output:
    #   - '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    actual_output = Formatting(['json']).format_body(content, mime)
    assert expected_output == actual_output

    # Test case 2:
    #

# Generated at 2022-06-17 20:50:57.968749
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersFormattingPlugin
    from httpie.plugins.builtin import JSONFormattingPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin

# Generated at 2022-06-17 20:51:09.177759
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("application/xml"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/html"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/plain"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/csv"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/tab-separated-values"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/yaml"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("text/x-yaml"), ConverterPlugin)

# Generated at 2022-06-17 20:51:19.553359
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None

# Generated at 2022-06-17 20:51:31.542017
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:51:36.911989
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:51:38.848755
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:51:49.086122
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None

# Generated at 2022-06-17 20:51:58.322845
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-yml') is not None
    assert Conversion

# Generated at 2022-06-17 20:52:01.906475
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'], env=Environment(), colors=True)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:52:11.617153
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name":"John","age":30,"cars":["Ford","BMW","Fiat"]}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "cars": [\n        "Ford",\n        "BMW",\n        "Fiat"\n    ]\n}'
    content = '{"name":"John","age":30,"cars":["Ford","BMW","Fiat"]}'
    mime = 'application/json'

# Generated at 2022-06-17 20:52:15.967259
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('text/plain') is None
    assert Conversion.get_converter('text/html') is None
    assert Conversion.get_converter('text/css') is None
    assert Conversion.get_converter('text/javascript') is None
    assert Conversion.get_converter('image/png') is None

# Generated at 2022-06-17 20:52:24.708735
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "car": null}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content = '<html><

# Generated at 2022-06-17 20:52:33.705694
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions

# Generated at 2022-06-17 20:52:47.984518
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion

# Generated at 2022-06-17 20:53:01.092231
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert formatting.format_headers(headers) == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
   

# Generated at 2022-06-17 20:53:11.809716
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert not converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; a=b')
    assert not converter.supports('application/json; charset=utf-8; a=b;')
    assert not converter.supports('application/json; charset=utf-8; a=b; ')
    assert not converter.supports

# Generated at 2022-06-17 20:53:12.891856
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json")
    assert not Conversion.get_converter("application/json1")


# Generated at 2022-06-17 20:53:20.911867
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatterV2
    from httpie.plugins.builtin import PrettyJsonFormatterV3
    from httpie.plugins.builtin import PrettyJsonFormatterV4
    from httpie.plugins.builtin import PrettyJsonFormatterV5
    from httpie.plugins.builtin import PrettyJsonFormatterV6
    from httpie.plugins.builtin import PrettyJsonFormatterV7
    from httpie.plugins.builtin import PrettyJsonFormatterV8
    from httpie.plugins.builtin import PrettyJsonFormatterV9
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:53:26.561569
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:53:36.238534
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:53:46.090100
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor

    # Test for HTTPHeadersProcessor
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: close
Date: Sun, 19 May 2019 13:24:11 GMT
Server: BaseHTTP/0.6 Python/3.7.3

'''
    env = Environment()
    env.stdout = io.StringIO()
    env.std

# Generated at 2022-06-17 20:53:53.702796
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:53:57.037271
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(["colors"])
    assert f.enabled_plugins[0].__class__.__name__ == "ColorsFormatter"

# Generated at 2022-06-17 20:54:11.891268
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/yaml") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded") is not None
    assert Conversion.get_converter("text/html") is not None
    assert Conversion.get_converter("text/plain") is not None
    assert Conversion.get_converter("text/xml") is not None
    assert Conversion.get_converter("text/yaml") is not None
    assert Conversion.get_converter("text/csv") is not None
    assert Conversion.get_converter("text/tsv") is not None
    assert Conversion.get_conver

# Generated at 2022-06-17 20:54:23.544617
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
Date: Wed, 23 Oct 2019 15:36:55 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Wed, 23 Oct 2019 15:36:55 GMT
ETag: "5db0f5f7-5"
Accept-Ranges: bytes
Content-Length: 5
Content-Type: text/html

'''
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)

# Generated at 2022-06-17 20:54:29.139378
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test with empty list of groups
    f = Formatting([])
    assert f.enabled_plugins == []

    # Test with list of groups
    f = Formatting(['colors'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:54:38.059863
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 13\r\n\r\n'
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:54:40.637252
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    assert f.format_body('{"a": 1}', 'application/json') == '{\n    "a": 1\n}'

# Generated at 2022-06-17 20:54:50.093202
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion

# Generated at 2022-06-17 20:55:01.844300
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/xml')
    assert not converter.supports('text/plain')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter

# Generated at 2022-06-17 20:55:09.982256
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n') == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: text/html\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:55:17.281060
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    assert f.format_body('{"a": "b"}', 'application/json') == '{\x1b[94m"a"\x1b[39m: \x1b[94m"b"\x1b[39m}'
    assert f.format_body('{"a": "b"}', 'application/xml') == '{\x1b[94m"a"\x1b[39m: \x1b[94m"b"\x1b[39m}'
    assert f.format_body('{"a": "b"}', 'application/yaml') == '{\x1b[94m"a"\x1b[39m: \x1b[94m"b"\x1b[39m}'
    assert f.format_

# Generated at 2022-06-17 20:55:28.179158
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ