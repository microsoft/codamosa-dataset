

# Generated at 2022-06-17 20:45:45.530294
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('text/html')
    assert Conversion.get_converter('text/plain')
    assert not Conversion.get_converter('text/plain/html')
    assert not Conversion.get_converter('text/plain/')
    assert not Conversion.get_converter('/text/plain')
    assert not Conversion.get_converter('/text/plain/')
    assert not Conversion.get_converter('/')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:45:49.257320
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    formatting = Formatting(groups, env)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[1].__class__.__name__ == 'FormatFormatter'

# Generated at 2022-06-17 20:45:57.831524
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-yml') is not None

# Generated at 2022-06-17 20:45:59.560858
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:46:01.270183
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:46:07.608905
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PrettyURLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import PrettyHTMLFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import PrettyXMLFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawURLEncodedFormatter
    from httpie.plugins.builtin import RawHTMLFormatter
    from httpie.plugins.builtin import RawXMLForm

# Generated at 2022-06-17 20:46:16.476062
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/yaml") is not None
    assert Conversion.get_converter("application/yml") is not None
    assert Conversion.get_converter("application/unknown") is None
    assert Conversion.get_converter("unknown/unknown") is None
    assert Conversion.get_converter("") is None
    assert Conversion.get_converter(None) is None

# Generated at 2022-06-17 20:46:27.873226
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("text/html") is not None
    assert Conversion.get_converter("text/plain") is not None
    assert Conversion.get_converter("text/xml") is not None
    assert Conversion.get_converter("text/yaml") is not None
    assert Conversion.get_converter("text/yml") is not None
    assert Conversion.get_converter("text/csv") is not None
    assert Conversion.get_converter("text/tsv") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded") is not None
    assert Conversion.get_conver

# Generated at 2022-06-17 20:46:39.648030
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[32mOK\x1b[39m\r\n\x1b[37mContent-Type: application/json\r\n\r\n\x1b[39m'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']

# Generated at 2022-06-17 20:46:43.079942
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:46:54.811420
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[32mOK\x1b[39m\r\n\x1b[37mContent-Type: \x1b[33mapplication/json\x1b[39m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']

# Generated at 2022-06-17 20:47:02.682791
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test with a valid mime type
    assert Formatting(['colors']).format_body('{"a": "b"}', 'application/json') == '{\x1b[32m"a"\x1b[39m: \x1b[32m"b"\x1b[39m}'
    # Test with an invalid mime type
    assert Formatting(['colors']).format_body('{"a": "b"}', 'application/json/') == '{"a": "b"}'
    # Test with an empty mime type
    assert Formatting(['colors']).format_body('{"a": "b"}', '') == '{"a": "b"}'

# Generated at 2022-06-17 20:47:13.306364
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodeProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor

# Generated at 2022-06-17 20:47:24.391128
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:47:36.293128
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdin = io.StringIO()
    env.stderr = io.StringIO()
    env.stdout_isatty = False
    env.stdin_isatty = False
    env.stderr_isatty = False
    env.colors = 256
    env.prettify = True
    env.style = None
    env.stream = False
    env.download_filename = None
    env.download_output_directory = None
    env.follow_redirects = True
    env.max_redirects = 10
    env.timeout = None
    env.check_status = True
    env.verify = True
    env.cert = None
    env.headers = None
    env.auth = None
   

# Generated at 2022-06-17 20:47:43.321303
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:47:52.399886
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json') == True
    assert converter.supports('application/xml') == False
    assert converter.supports('text/plain') == False
    assert converter.supports('text/html') == False
    assert converter.supports('text/xml') == False
    assert converter.supports('text/csv') == False
    assert converter.supports('text/yaml') == False
    assert converter.supports('text/javascript') == False
    assert converter.supports('text/css') == False
    assert converter.supports('text/csv') == False
    assert converter.supports('text/csv') == False
    assert converter.supports('text/csv') == False
   

# Generated at 2022-06-17 20:48:04.573235
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: "abc"
    #   - mime: "text/plain"
    # Expected output: "abc"
    content = "abc"
    mime = "text/plain"
    assert Formatting(["colors"]).format_body(content, mime) == "abc"

    # Test case 2:
    # Input:
    #   - content: "abc"
    #   - mime: "text/html"
    # Expected output: "abc"
    content = "abc"
    mime = "text/html"
    assert Formatting(["colors"]).format_body(content, mime) == "abc"

    # Test case 3:
    # Input:
    #   - content: "abc"
    #   - m

# Generated at 2022-06-17 20:48:09.423741
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': True}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:48:18.522680
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.config['colors'] = True
    env.config['format'] = 'colors'
    env.config['style'] = 'solarized'
    env.config['print_bodies'] = True
    env.config['print_headers'] = True
    env.config['print_cookies'] = True
    env.config['print_history'] = True
    env.config['print_options'] = True
    env.config['print_query_params'] = True
    env.config['print_status'] = True
    env.config['print_title'] = True
    env.config['print_trailers'] = True
    env.config['print_version'] = True
    env.config['style_error'] = 'red'
    env.config['style_info'] = 'green'
    env

# Generated at 2022-06-17 20:48:30.694339
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/octet-stream') is None
    assert Conversion.get_converter('application') is None
    assert Conversion.get_converter('application/') is None
    assert Conversion.get_converter('application/json/') is None
    assert Conversion.get_converter('application/json/xml') is None
    assert Conversion.get_converter('application/json/xml/yaml') is None
    assert Conversion.get_conver

# Generated at 2022-06-17 20:48:34.234631
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': 'on'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:48:36.776369
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins != []


# Generated at 2022-06-17 20:48:47.778044
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json")
    assert Conversion.get_converter("application/xml")
    assert not Conversion.get_converter("application/json-patch+json")
    assert not Conversion.get_converter("application/json+patch")
    assert not Conversion.get_converter("application/json-patch")
    assert not Conversion.get_converter("application/json+")
    assert not Conversion.get_converter("application/json-")
    assert not Conversion.get_converter("application/json+json")
    assert not Conversion.get_converter("application/json-json")
    assert not Conversion.get_converter("application/json+json-patch")
    assert not Conversion.get_converter("application/json-json+patch")

# Generated at 2022-06-17 20:49:00.133553
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:49:09.345203
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrint0Processor
    from httpie.plugins.builtin import HTTPPrintProcessor
    from httpie.plugins.builtin import HTTPUnicodeProcessor
    from httpie.plugins.builtin import HTTPXMLProcessor
    from httpie.plugins.builtin import HTTPYAMLProcessor

    # Test for constructor of class Formatting
    # Case 1: groups = ['pretty', 'print0', 'unicode', 'xml', 'yaml']
    # Case 2: groups = ['pretty', 'print', 'unicode', 'xml', 'yaml']
    # Case 3: groups = ['pretty', 'print0', 'unicode', 'xml', 'yaml']


# Generated at 2022-06-17 20:49:19.831499
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/json')

# Generated at 2022-06-17 20:49:23.125845
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:49:32.179338
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(groups=['colors'], env=Environment(), **{})
    assert Formatting(groups=['colors'], env=Environment(), **{'colors': 'on'})
    assert Formatting(groups=['colors'], env=Environment(), **{'colors': 'off'})
    assert Formatting(groups=['colors'], env=Environment(), **{'colors': 'auto'})
    assert Formatting(groups=['colors'], env=Environment(), **{'colors': 'never'})
    assert Formatting(groups=['colors'], env=Environment(), **{'colors': 'always'})
    assert Formatting(groups=['colors'], env=Environment(), **{'colors': 'never'})

# Generated at 2022-06-17 20:49:43.556833
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
   

# Generated at 2022-06-17 20:49:55.239606
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = "HTTP/1.1 200 OK\r\n" \
              "Date: Mon, 27 Jul 2009 12:28:53 GMT\r\n" \
              "Server: Apache/2.2.14 (Win32)\r\n" \
              "Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\n" \
              "Content-Length: 88\r\n" \
              "Content-Type: text/html\r\n" \
              "Connection: Closed\r\n" \
              "\r\n" \
              "Hello World!"
    formatting = Formatting(groups=['colors'])
    assert formatting.format_headers(headers) == headers


# Generated at 2022-06-17 20:50:02.944143
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name": "John", "age": 30, "city": "New York"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    formatting = Formatting(['json'])
    assert formatting.format_body(content, mime) == expected_output

    # Test case 2

# Generated at 2022-06-17 20:50:07.842697
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': True}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].colors == True

# Generated at 2022-06-17 20:50:18.450553
# Unit test for method format_body of class Formatting

# Generated at 2022-06-17 20:50:26.752811
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None

# Generated at 2022-06-17 20:50:36.676739
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:50:46.811153
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n'
    assert f.format_headers(headers) == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: text/plain\x1b[0m\r\n\r\n'
    # Test case 2
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}

# Generated at 2022-06-17 20:50:54.682436
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12\r\n\r\n'
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.format_headers(headers) == '\x1b[37mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37mContent-Type: text/html; charset=utf-8\x1b[0m\r\n\x1b[37mContent-Length: 12\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:51:04.075331
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "test"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "name": "test"\n}'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "test"}'
    mime = 'application/xml'
    assert formatting.format_body(content, mime) == '{"name": "test"}'

    # Test case 3
    groups = ['colors']
    env = Environment()

# Generated at 2022-06-17 20:51:14.886755
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions

# Generated at 2022-06-17 20:51:21.481399
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'colors': 'on'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'FormatFormatter'

# Generated at 2022-06-17 20:51:31.517415
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups = ['colors']
    #   env = Environment()
    #   kwargs = {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    env = Environment()
    kwargs = {}

# Generated at 2022-06-17 20:51:42.991772
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion

# Generated at 2022-06-17 20:51:51.142688
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    # Expected output: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert Formatting(['colors']).format_headers(headers) == headers

    # Test case 2:
    # Input: headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    # Expected output: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n

# Generated at 2022-06-17 20:51:59.674098
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('application/yaml')
    assert Conversion.get_converter('text/html')
    assert Conversion.get_converter('text/markdown')
    assert Conversion.get_converter('text/plain')
    assert Conversion.get_converter('text/csv')
    assert Conversion.get_converter('text/tab-separated-values')
    assert Conversion.get_converter('text/tsv')
    assert Conversion.get_converter('text/vtt')
    assert Conversion.get_converter('text/x-vcard')
    assert Conversion.get_converter('text/x-yaml')

# Generated at 2022-06-17 20:52:09.716480
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None

# Generated at 2022-06-17 20:52:14.897213
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import RawJSONProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodedProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.plugins import ConverterPlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment

# Generated at 2022-06-17 20:52:19.290864
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/yaml") is not None
    assert Conversion.get_converter("application/yml") is not None
    assert Conversion.get_converter("application/vnd.yaml") is not None
    assert Conversion.get_converter("application/vnd.yml") is not None
    assert Conversion.get_converter("application/vnd.httpie.test") is None
    assert Conversion.get_converter("application/vnd.httpie.test.json") is not None
    assert Conversion.get_converter("application/vnd.httpie.test.xml") is not None
    assert Conversion.get_

# Generated at 2022-06-17 20:52:24.570035
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/yaml") is not None
    assert Conversion.get_converter("application/unknown") is None
    assert Conversion.get_converter("unknown/unknown") is None
    assert Conversion.get_converter("") is None
    assert Conversion.get_converter(None) is None


# Generated at 2022-06-17 20:52:30.554136
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"a": 1}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\x1b[32m"a"\x1b[39m: \x1b[34m1\x1b[39m}'

# Generated at 2022-06-17 20:52:44.045079
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert not converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; a=b')
    assert not converter.supports('application/json; charset=utf-8; a=b;')
    assert not converter.supports('application/json; charset=utf-8; a=b; ')
    assert not converter.supports

# Generated at 2022-06-17 20:52:47.134783
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format', 'formatvars']
    env = Environment()
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins


# Generated at 2022-06-17 20:53:00.979099
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import httpie.plugins.builtin.formatters
    from httpie.plugins.builtin.formatters import JSONFormatter
    from httpie.plugins.builtin.formatters import JSONLinesFormatter
    from httpie.plugins.builtin.formatters import URLEncodedFormatter
    from httpie.plugins.builtin.formatters import RawFormatter

    # Test JSONFormatter
    json_formatter = JSONFormatter()
    json_formatter.enabled = True
    json_formatter.env = Environment()
    json_formatter.env.stdout_isatty = True
    json_formatter.env.colors = 256
    json_formatter.env.style = 'monokai'
    json_formatter.env.format = 'colors'
    json_formatter.env.pre

# Generated at 2022-06-17 20:53:11.749618
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    #   env: Environment()
    #   kwargs: {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200 \x1b[32mOK\x1b[39m\r\n\x1b[37mContent-Type: \x1b[33mapplication/json\x1b[39m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:53:20.162445
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:53:22.972878
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'colors': True, 'format': 'pretty'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[1].__class__.__name__ == 'PrettyFormatter'

# Generated at 2022-06-17 20:53:25.494352
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].env == Environment()
    assert f.enabled_plugins[0].kwargs == {}


# Generated at 2022-06-17 20:53:36.000728
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"a": "b"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "a": "b"\n}'

    # test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"a": "b"}'
    mime = 'application/xml'
    assert formatting.format_body(content, mime) == '{"a": "b"}'

    # test case 3
    groups = ['colors']
    env = Environment()

# Generated at 2022-06-17 20:53:39.941703
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:53:49.037768
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:54:03.696647
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:54:13.747694
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[32mOK\x1b[39m\r\n\x1b[37mContent-Type: \x1b[33mapplication/json\x1b[39m\r\n\r\n'
    groups = ['colors']
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:54:20.140079
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors', 'format']
    kwargs = {'colors': True}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'FormatFormatter'

# Generated at 2022-06-17 20:54:26.911072
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)

# Generated at 2022-06-17 20:54:35.557879
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 2\r\n\r\n{}'
    formatting = Formatting(['colors'])
    assert formatting.format_headers(headers) == '\x1b[32mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[33mContent-Type: application/json\x1b[0m\r\n\x1b[33mContent-Length: 2\x1b[0m\r\n\r\n{}'


# Generated at 2022-06-17 20:54:45.831921
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/yaml") is not None
    assert Conversion.get_converter("application/csv") is not None
    assert Conversion.get_converter("application/vnd.api+json") is not None
    assert Conversion.get_converter("application/vnd.api+xml") is not None
    assert Conversion.get_converter("application/vnd.api+yaml") is not None
    assert Conversion.get_converter("application/vnd.api+csv") is not None
    assert Conversion.get_converter("application/vnd.api+json;version=2") is not None
    assert Conversion.get_

# Generated at 2022-06-17 20:54:53.130939
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_conver

# Generated at 2022-06-17 20:54:58.814625
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:55:04.169683
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/x-yaml'), ConverterPlugin)

# Generated at 2022-06-17 20:55:07.925455
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:55:25.609174
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('multipart/form-data') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('application/pdf') is not None
    assert Conversion.get_converter('application/zip') is not None
    assert Conversion.get_converter('image/jpeg') is not None
    assert Conversion

# Generated at 2022-06-17 20:55:34.031733
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    result = formatting.format_headers(headers)
    assert result == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)