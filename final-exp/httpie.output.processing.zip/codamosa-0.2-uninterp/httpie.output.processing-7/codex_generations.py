

# Generated at 2022-06-17 20:45:45.851447
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_

# Generated at 2022-06-17 20:45:57.525940
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('/')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:46:03.714967
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None

# Generated at 2022-06-17 20:46:14.817683
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import URLEncodedProcessor
    from httpie.plugins.builtin import XMLProcessor
    from httpie.plugins.builtin import HTTPieProcessor

    env = Environment()
    env.stdout_isatty = True
    env.stdin_isatty = True
    env.stdin = sys.stdin
    env.stdout = sys.stdout
    env.stderr = sys.stderr



# Generated at 2022-06-17 20:46:16.165164
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors'])
    assert fmt.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert fmt.enabled_plugins[0].enabled == True


# Generated at 2022-06-17 20:46:20.052011
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)

# Generated at 2022-06-17 20:46:31.203458
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    # Input: groups = ['colors'], env = Environment(), kwargs = {}
    # Expected output:
    #   enabled_plugins = [
    #       ColoredStreamFormatter(env=Environment(), colors=None, style=None,
    #                              theme=None, force_colors=False,
    #                              force_style=False, force_theme=False),
    #       ColoredFormatter(env=Environment(), colors=None, style=None,
    #                        theme=None, force_colors=False, force_style=False,
    #                        force_theme=False)
    #   ]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins

# Generated at 2022-06-17 20:46:35.757051
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:46:42.573439
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n') == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: text/html; charset=utf-8\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:46:51.272595
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:47:02.958151
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:47:05.875155
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:47:16.028401
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import json
    import httpie.output.formatters
    import httpie.output.formatters.colors
    import httpie.output.formatters.format
    import httpie.output.formatters.headers
    import httpie.output.formatters.json
    import httpie.output.formatters.pretty
    import httpie.output.formatters.stream
    import httpie.output.formatters.utils
    import httpie.output.formatters.vertical_table
    import httpie.plugins
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.plugins.registry
    import httpie.plugins.unicode
    import httpie.plugins.unicode.__main__
    import httpie.plugins.unicode.unicode
    import httpie.plugins.unicode.unicode

# Generated at 2022-06-17 20:47:23.871534
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:47:30.281655
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': True}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:47:36.768666
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout.isatty = lambda: True
    env.stdout.encoding = 'utf8'
    env.stdin = io.StringIO()
    env.stdin.isatty = lambda: True
    env.stdin.encoding = 'utf8'
    env.stderr = io.StringIO()
    env.stderr.isatty = lambda: True
    env.stderr.encoding = 'utf8'
    env.config = {}
    env.config_dir = None
    env.config_path = None
    env.colors = 256
    env.color_mode = 'auto'
    env.default_options = []
    env.debug = False
    env.follow_redirects = True

# Generated at 2022-06-17 20:47:48.664043
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None

# Generated at 2022-06-17 20:48:02.125761
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(groups=['colors'])
    assert Formatting(groups=['colors'], env=Environment())
    assert Formatting(groups=['colors'], env=Environment(), indent=2)
    assert Formatting(groups=['colors'], indent=2)
    assert Formatting(groups=['colors'], indent=2, env=Environment())
    assert Formatting(groups=['colors'], indent=2, env=Environment())
    assert Formatting(groups=['colors'], indent=2, env=Environment(), indent=2)
    assert Formatting(groups=['colors'], indent=2, indent=2)
    assert Formatting(groups=['colors'], indent=2, indent=2, env=Environment())

# Generated at 2022-06-17 20:48:13.946858
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].env.__class__.__name__ == 'Environment'
    assert f.enabled_plugins[0].style == 'solarized'
    assert f.enabled_plugins[0].colors == '16'
    assert f.enabled_plugins[0].bg == 'dark'
    assert f.enabled_plugins[0].theme == 'solarized'
    assert f.enabled_plugins[0].colors_256 == False
    assert f.enabled_plugins[0].colors_16m == False
    assert f.enabled_plugins[0].colors_16 == True
   

# Generated at 2022-06-17 20:48:19.745776
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].style == 'solarized'


# Generated at 2022-06-17 20:48:31.843627
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:48:41.054476
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name":"John","age":30,"car":null}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name":"John","age":30,"car":null}'
    mime = 'application/xml'
    assert formatting.format_body(content, mime)

# Generated at 2022-06-17 20:48:50.898602
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name":"John"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John"\n}'
    content = '{"name":"John"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"name":"John"}'
    #   mime: 'application/xml'
    # Expected output:
    #   '{"name":"John"}'
    content = '{"name":"John"}'

# Generated at 2022-06-17 20:49:01.004972
# Unit test for method format_body of class Formatting

# Generated at 2022-06-17 20:49:03.308282
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter.mime == "application/json"


# Generated at 2022-06-17 20:49:12.141706
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:49:19.225204
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/x-yaml'), ConverterPlugin)

# Generated at 2022-06-17 20:49:30.363067
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:49:42.852763
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # input:
    #   headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups: ['colors']
    # output:
    #   headers: '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)

# Generated at 2022-06-17 20:49:54.127976
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import FormatterPlugin

# Generated at 2022-06-17 20:50:06.549633
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test 1: No groups
    f = Formatting([])
    assert f.enabled_plugins == []

    # Test 2: One group
    f = Formatting(['colors'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

    # Test 3: Two groups
    f = Formatting(['colors', 'format'])
    assert len(f.enabled_plugins) == 2
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'FormatFormatter'

    # Test 4: Invalid group
    f = Formatting(['colors', 'invalid'])

# Generated at 2022-06-17 20:50:11.543543
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[0].style == 'solarized'


# Generated at 2022-06-17 20:50:21.668752
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "httpie"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "name": "httpie"\n}'

    # test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "httpie"}'
    mime = 'application/xml'
    assert formatting.format_body(content, mime) == '{"name": "httpie"}'

    # test case 3
    groups = ['colors']
   

# Generated at 2022-06-17 20:50:28.659104
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': 'on'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].colors == 'on'
    assert f.enabled_plugins[0].env == env


# Generated at 2022-06-17 20:50:32.592305
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('text/html')
    assert Conversion.get_converter('text/plain')
    assert not Conversion.get_converter('text/plain/json')

# Generated at 2022-06-17 20:50:37.107929
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:50:47.364850
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:50:55.518516
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: "{\n  \"name\": \"John\",\n  \"age\": 30,\n  \"car\": null\n}"
    #   mime: "application/json"
    # Expected output:
    #   "{\n  \"name\": \"John\",\n  \"age\": 30,\n  \"car\": null\n}"
    content = "{\n  \"name\": \"John\",\n  \"age\": 30,\n  \"car\": null\n}"
    mime = "application/json"
    expected_output = "{\n  \"name\": \"John\",\n  \"age\": 30,\n  \"car\": null\n}"
    assert Formatting([]).format_body(content, mime) == expected_output

    # Test case 2

# Generated at 2022-06-17 20:51:01.962256
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

{}
'''
    groups = ['colors']
    formatting = Formatting(groups)
    assert formatting.format_headers(headers) == '''\x1b[1mHTTP/1.1 200 OK\x1b[0m
\x1b[1mContent-Type: application/json\x1b[0m
\x1b[1mContent-Length: 2\x1b[0m

{}
'''
    # Test case 2
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

{}
'''
    groups = ['colors', 'format']

# Generated at 2022-06-17 20:51:08.544916
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
    #   groups: ["colors"]
    #   env: Environment()
    #   kwargs: {}
    # Expected output:
    #   headers: "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
    groups = ["colors"]
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.format_headers(headers) == headers

    # Test case

# Generated at 2022-06-17 20:51:21.053832
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:51:27.610318
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    groups = ['colors']
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[0].style == 'solarized'


# Generated at 2022-06-17 20:51:34.214982
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name":"John","age":30,"car":null}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name":"John","age":30,"car":null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    formatting = Formatting(['json'])
    assert formatting.format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content = '{"name":"

# Generated at 2022-06-17 20:51:45.218487
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])
    assert Formatting(['colors', 'format'])
    assert Formatting(['colors', 'format', 'format_options'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options', 'colors_extras'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options', 'colors_extras', 'colors_16m'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options', 'colors_extras', 'colors_16m', 'colors_256'])

# Generated at 2022-06-17 20:51:52.456305
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrintHtmlProcessor
    from httpie.plugins.builtin import HTTPPrintJsonProcessor
    from httpie.plugins.builtin import HTTPPrintXmlProcessor
    from httpie.plugins.builtin import HTTPPrintHeadersProcessor
    from httpie.plugins.builtin import HTTPPrintBinaryProcessor
    from httpie.plugins.builtin import HTTPPrintBodyProcessor
    from httpie.plugins.builtin import HTTPPrintRawProcessor
    from httpie.plugins.builtin import HTTPPrintStreamProcessor
    from httpie.plugins.builtin import HTTPPrintStreamProcessor
    from httpie.plugins.builtin import HTTPPrintStreamProcessor

# Generated at 2022-06-17 20:52:01.294452
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    #   Input: groups = ['colors'], env = Environment(), kwargs = {}
    #   Expected output: enabled_plugins = [ColorsFormatter]
    f = Formatting(groups=['colors'], env=Environment(), kwargs={})
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

    # Test case 2:
    #   Input: groups = ['colors', 'format'], env = Environment(), kwargs = {}
    #   Expected output: enabled_plugins = [ColorsFormatter, FormatFormatter]
    f = Formatting(groups=['colors', 'format'], env=Environment(), kwargs={})

# Generated at 2022-06-17 20:52:08.262563
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting(['colors']).format_body("{'a':'b'}", 'application/json') == '\x1b[37m{\x1b[39;49;00m\n  \x1b[33m"a"\x1b[39;49;00m\x1b[37m:\x1b[39;49;00m \x1b[33m"b"\x1b[39;49;00m\n\x1b[37m}\x1b[39;49;00m\n'

# Generated at 2022-06-17 20:52:12.131000
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'colors': True, 'format': 'pretty'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].enabled == True
    assert formatting.enabled_plugins[1].enabled == True

# Generated at 2022-06-17 20:52:22.523499
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>
'''
    groups = ['colors']
    formatting = Formatting(groups)

# Generated at 2022-06-17 20:52:32.015440
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>'''
    groups = ['colors']
    env = Environment()
    env.config['colors'] = {'header': 'green'}
    f = Formatting(groups, env=env)
    result = f.format_headers(headers)

# Generated at 2022-06-17 20:52:47.096432
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_

# Generated at 2022-06-17 20:53:00.976401
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert formatting.format_headers(headers) == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:53:11.749934
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json; charset=utf-8\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: close\r\n' \
              'Server: gunicorn/19.9.0\r\n' \
              'Date: Tue, 05 Mar 2019 12:35:49 GMT\r\n' \
              '\r\n' \
              '{}'

# Generated at 2022-06-17 20:53:20.162166
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/toml') is not None
    assert Conversion.get_converter('application/msgpack') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:53:23.285214
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1: mime is not valid
    mime = "text"
    content = "hello world"
    formatting = Formatting(["colors"])
    assert formatting.format_body(content, mime) == content

    # Test case 2: mime is valid
    mime = "text/html"
    content = "hello world"
    formatting = Formatting(["colors"])
    assert formatting.format_body(content, mime) == content

# Generated at 2022-06-17 20:53:34.760249
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import JSONStreamOptions
    from httpie.plugins.builtin import Formatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import StreamOptions
    from httpie.plugins.builtin import KeyValueFormatter
    from httpie.plugins.builtin import KeyValueOptions
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import HTMLOptions
    from httpie.plugins.builtin import URLEncodedFormatter

# Generated at 2022-06-17 20:53:46.012213
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import HTTPPrettyOptionsPlugin
    from httpie.plugins.builtin import JSONOptionsPlugin
    from httpie.plugins.builtin import JSONLinesOptionsPlugin
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import JSONLinesProcessor
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import JSONProcessor

# Generated at 2022-06-17 20:53:53.679147
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>'''
    groups = ['colors']
    env = Environment()
    env.colors = True
    env.headers = True
    env.stream = False
    env.verbose = False
    env.style = 'solarized'
    env.style_force = True
    env.format = 'colors'
    env.output_options = {}
    env

# Generated at 2022-06-17 20:54:00.209581
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Given
    groups = ["colors"]
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = "test"
    mime = "application/json"

    # When
    result = formatting.format_body(content, mime)

    # Then
    assert result == "test"

# Generated at 2022-06-17 20:54:11.438931
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)
    assert Conversion.get_converter("application/json").mime == "application/json"
    assert not Conversion.get_converter("application/json").supports("application/xml")
    assert not Conversion.get_converter("application/json").supports("application/json")
    assert not Conversion.get_converter("application/json").supports("application/json; charset=utf-8")
    assert not Conversion.get_converter("application/json").supports("application/json; charset=utf-8;")
    assert not Conversion.get_converter("application/json").supports("application/json; charset=utf-8; ")

# Generated at 2022-06-17 20:54:20.340640
# Unit test for constructor of class Formatting
def test_Formatting():
    # test for constructor of class Formatting
    groups = ["colors"]
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == "ColorsFormatter"


# Generated at 2022-06-17 20:54:26.737905
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n') == '\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[1mContent-Type: text/plain\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:54:36.871387
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name": "John", "age": 30, "car": null}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"name":

# Generated at 2022-06-17 20:54:47.336663
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get_converter

# Generated at 2022-06-17 20:55:01.065594
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/xml'
    assert formatting.format_body

# Generated at 2022-06-17 20:55:12.153460
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 13\r\n\r\n'

# Generated at 2022-06-17 20:55:15.110948
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=['colors'])
    assert f.format_body('{"a": "b"}', 'application/json') == '{\n    "a": "b"\n}'


# Generated at 2022-06-17 20:55:25.953447
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json-patch+json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8;')
    assert not Conversion.get_converter('application/json; charset=utf-8; ')
    assert not Conversion.get_converter('application/json; charset=utf-8; a=b')
    assert not Conversion.get_converter('application/json; charset=utf-8; a=b;')
    assert not Conversion.get_converter

# Generated at 2022-06-17 20:55:34.370016
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPieJSONFormatter
    from httpie.plugins.builtin import HTTPiePrettyFormatter
    from httpie.plugins.builtin import HTTPieTableFormatter
    from httpie.plugins.builtin import HTTPieURLEncodedFormatter
    from httpie.plugins.builtin import HTTPieColorsFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormatControlFormatter
    from httpie.plugins.builtin import HTTPieFormat