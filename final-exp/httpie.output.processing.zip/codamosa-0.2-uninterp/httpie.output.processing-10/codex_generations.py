

# Generated at 2022-06-17 20:45:44.994228
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Thu, 05 Apr 2018 14:49:26 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Thu, 05 Apr 2018 14:49:26 GMT
ETag: "1d3-56a6a8a8f0e80"
Accept-Ranges: bytes
Content-Length: 467
Vary: Accept-Encoding
Content-Type: text/html

'''
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)
    headers = formatting.format_headers(headers)

# Generated at 2022-06-17 20:45:53.951388
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter.mime == "application/json"
    assert converter.supports("application/json")
    assert not converter.supports("application/xml")
    assert not converter.supports("application/json;charset=utf-8")
    assert not converter.supports("application/json;charset=utf-8;")
    assert not converter.supports("application/json;charset=utf-8;q=0.8")
    assert not converter.supports("application/json;q=0.8")
    assert not converter.supports("application/json;q=0.8;charset=utf-8")
    assert not converter.supports("application/json;q=0.8;charset=utf-8;")
   

# Generated at 2022-06-17 20:46:01.002652
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/css') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:46:03.832889
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:46:14.950090
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdin = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.colors = 256
    env.config_dir = None
    env.config_path = None
    env.config = None
    env.config_dir_path = None
    env.config_paths = None
    env.default_options = None
    env.output_options = None
    env.output_options_specified = None
    env.output_options_default = None
    env.output_options_env = None
    env.output_options_config = None

# Generated at 2022-06-17 20:46:18.075857
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:46:28.002771
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/x-yaml'), ConverterPlugin)

# Generated at 2022-06-17 20:46:39.773065
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert formatting.format_headers(headers) == '\033[36mHTTP/1.1 200 OK\033[0m\r\n\033[37mContent-Type: application/json\033[0m\r\n\r\n'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:46:46.632320
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
   

# Generated at 2022-06-17 20:47:00.558954
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion

# Generated at 2022-06-17 20:47:13.307556
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/tsv') is not None
   

# Generated at 2022-06-17 20:47:16.068509
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:47:21.765646
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format', 'formatvars']
    env = Environment()
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].enabled == True
    assert formatting.enabled_plugins[1].enabled == True
    assert formatting.enabled_plugins[2].enabled == True


# Generated at 2022-06-17 20:47:30.231506
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Case 1:
    #   Input:
    #       content = '{"name":"test"}'
    #       mime = 'application/json'
    #   Expected:
    #       content = '{\n    "name": "test"\n}'
    content = '{"name":"test"}'
    mime = 'application/json'
    formatting = Formatting(['json'])
    assert formatting.format_body(content, mime) == '{\n    "name": "test"\n}'

    # Case 2:
    #   Input:
    #       content = '{"name":"test"}'
    #       mime = 'application/json'
    #   Expected:
    #       content = '{\n    "name": "test"\n

# Generated at 2022-06-17 20:47:35.168325
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].style == 'solarized'

# Generated at 2022-06-17 20:47:42.603242
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter

    # Test JSONFormatter
    json_formatter = JSONFormatter(PrettyOptions(indent=2, sort_keys=True))
    json_formatter.enabled = True
    json_formatter.env = Environment()
    json_formatter.env.stdout_isatty = True
    json_formatter.env.stdin_isatty = True
    json_formatter.env.is_windows = False
    json_formatter.env.colors = 256
    json_formatter.env.prettifier_enabled = True
    json_formatter.env.prettifier_cls = PrettyFormatter
    json_formatter.env.pre

# Generated at 2022-06-17 20:47:51.209985
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1:
    #   groups = ['colors']
    #   env = Environment()
    #   kwargs = {}
    # Expected result:
    #   enabled_plugins = [ColorsFormatter]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert len(formatting.enabled_plugins) == 1
    assert isinstance(formatting.enabled_plugins[0], ColorsFormatter)

    # Test case 2:
    #   groups = ['colors', 'format']
    #   env = Environment()
    #   kwargs = {}
    # Expected result:
    #   enabled_plugins = [ColorsFormatter, FormatFormatter]
    groups = ['colors', 'format']
    env

# Generated at 2022-06-17 20:48:04.021982
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:48:10.056267
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    #   Input:
    #       headers: 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #       groups: ['colors']
    #   Expected output:
    #       '\x1b[37mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37mContent-Type: application/json\x1b[0m\r\n\r\n'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    groups = ['colors']

# Generated at 2022-06-17 20:48:12.903174
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    formatting = Formatting(['colors'], env=env)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:48:26.657420
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting(['colors']).format_body('{"a": "b"}', 'application/json') == '{\n    "a": "b"\n}'
    assert Formatting(['colors']).format_body('{"a": "b"}', 'application/xml') == '<a>b</a>'
    assert Formatting(['colors']).format_body('{"a": "b"}', 'application/yaml') == 'a: b'
    assert Formatting(['colors']).format_body('{"a": "b"}', 'application/html') == '<html><body><pre>{\n    "a": "b"\n}</pre></body></html>'

# Generated at 2022-06-17 20:48:34.746533
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name":"John","age":30,"car":null}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name":"John","age":30,"car":null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['format']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"name":"John","age":30,"

# Generated at 2022-06-17 20:48:41.913505
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = '''HTTP/1.1 200 OK
    Content-Type: application/json
    Content-Length: 2
    Connection: close
    Server: gunicorn/19.9.0
    Date: Wed, 13 Mar 2019 14:12:21 GMT
    '''
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    result = formatting.format_headers(headers)

# Generated at 2022-06-17 20:48:51.385392
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_prettifier
    from httpie.plugins.builtin import get_response_processor
    from httpie.plugins.builtin import get_unicode_processor
    from httpie.plugins.builtin import get_validator
    from httpie.plugins.builtin import get_writer
    from httpie.plugins.builtin import validate_options
    from httpie.plugins.builtin import validate_prettifier_options

# Generated at 2022-06-17 20:49:01.265639
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: text/html; charset=utf-8\r\n' \
              'Content-Length: 12\r\n' \
              'Connection: close\r\n' \
              '\r\n' \
              'hello world!'
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)

# Generated at 2022-06-17 20:49:10.563579
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrint0Processor
    from httpie.plugins.builtin import HTTPPrintProcessor
    from httpie.plugins.builtin import HTTPPrintHeadersProcessor
    from httpie.plugins.builtin import HTTPPrintBodyProcessor
    from httpie.plugins.builtin import HTTPPrintBodyOnlyProcessor
    from httpie.plugins.builtin import HTTPPrintHeadersOnlyProcessor
    from httpie.plugins.builtin import HTTPPrintHexProcessor
    from httpie.plugins.builtin import HTTPPrintBinaryProcessor
    from httpie.plugins.builtin import HTTPPrint0Processor
    from httpie.plugins.builtin import HTTPPrint0Processor

# Generated at 2022-06-17 20:49:14.254787
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].style == 'solarized'
    assert f.enabled_plugins[0].env == env


# Generated at 2022-06-17 20:49:17.614640
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:49:23.508911
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1: mime is not valid
    mime = 'text'
    assert Conversion.get_converter(mime) is None

    # Test case 2: mime is valid
    mime = 'text/plain'
    assert Conversion.get_converter(mime) is not None


# Generated at 2022-06-17 20:49:32.453556
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"key": "value"}'
    #   mime = 'application/json'
    # Expected output:
    #   content = '{\n    "key": "value"\n}'
    content = '{"key": "value"}'
    mime = 'application/json'
    formatting = Formatting(groups=['colors'])
    assert formatting.format_body(content, mime) == '{\n    "key": "value"\n}'

    # Test case 2:
    # Input:
    #   content = '{"key": "value"}'
    #   mime = 'application/json'
    # Expected output:
    #   content = '{\n    "key": "value"\n}'

# Generated at 2022-06-17 20:49:44.911303
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test for empty headers
    headers = ''
    groups = ['colors']
    f = Formatting(groups)
    assert f.format_headers(headers) == headers

    # Test for headers with no colors
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'
    groups = ['colors']
    f = Formatting(groups)
    assert f.format_headers(headers) == headers

    # Test for headers with colors
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n'
    groups = ['colors']
    f = Formatting(groups)
    assert f.format_headers(headers) == headers

    # Test for headers with colors

# Generated at 2022-06-17 20:49:51.725464
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n') == '\x1b[32mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[33mContent-Type: text/plain\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:50:00.638229
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_

# Generated at 2022-06-17 20:50:10.060706
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name": "John", "age": 30, "car": null}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"name":

# Generated at 2022-06-17 20:50:21.155878
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"hello": "world"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '\x1b[37m{\x1b[39;49;00m\n' \
                                                   '    \x1b[37m"hello"\x1b[39;49;00m\x1b[37m:\x1b[39;49;00m \x1b[37m"world"\x1b[39;49;00m\n' \
                                                   '\x1b[37m}\x1b[39;49;00m\n'
   

# Generated at 2022-06-17 20:50:29.463506
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1:
    mime = 'application/json'
    assert is_valid_mime(mime)
    converter = Conversion.get_converter(mime)
    assert converter is not None
    assert converter.mime == mime

    # Test case 2:
    mime = 'application/json; charset=utf-8'
    assert is_valid_mime(mime)
    converter = Conversion.get_converter(mime)
    assert converter is not None
    assert converter.mime == mime

    # Test case 3:
    mime = 'application/json; charset=utf-8;'
    assert is_valid_mime(mime)
    converter = Conversion.get_converter(mime)
    assert converter is not None
    assert converter.mime == m

# Generated at 2022-06-17 20:50:37.883266
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Test case 1:
    # Input:
    #   - content: "{\n    \"name\": \"John\",\n    \"age\": 30,\n    \"car\": null\n}"
    #   - mime: "application/json"
    # Expected output:
    #   - "{\n    \"name\": \"John\",\n    \"age\": 30,\n    \"car\": null\n}"
    # Observed output:
    #   - "{\n    \"name\": \"John\",\n    \"age\": 30,\n    \"car\": null\n}"
    content = "{\n    \"name\": \"John\",\n    \"age\": 30,\n    \"car\": null\n}"
    mime = "application/json"
    expected_output

# Generated at 2022-06-17 20:50:47.511552
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('application/pdf') is None
    assert Conversion.get_converter('application/') is None
    assert Conversion.get_converter('application') is None
    assert Conversion.get_converter('application/json/') is None
    assert Conversion.get_converter('application/json/xml') is None

# Generated at 2022-06-17 20:50:55.691494
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = sys.stdout
    env.stdin = sys.stdin
    env.stderr = sys.stderr
    env.config = {}
    env.config_dir = os.path.expanduser('~/.config/httpie')
    env.colors = 256
    env.is_windows = False
    env.stdout_isatty = True
    env.stdin_isatty = True
    env.stderr_isatty = True
    env.debug = False
    env.auto_json = False
    env.default_options = []
    env.config_path = os.path.expanduser('~/.config/httpie/config.json')
    env.download_dir = os.path.expanduser('~/Downloads')
   

# Generated at 2022-06-17 20:51:02.082832
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert not Conversion.get_converter('application/json').supports('application/xml')
    assert not Conversion.get_converter('application/json').supports('application/json')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8;')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8; ')

# Generated at 2022-06-17 20:51:17.232836
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name": "John", "age": 30, "car": null}'
    #   mime = 'application/json'
    # Expected output:
    #   content = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    result = Formatting(['format']).format_body(content, mime)
    assert result == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

    # Test case 2:
    # Input:
    #   content = '{"name": "John

# Generated at 2022-06-17 20:51:25.421954
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatterPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyPlugin
    from httpie.plugins.builtin import SyntaxHighlightPlugin
    from httpie.plugins.builtin import UnicodePlugin
    from httpie.plugins.builtin import URLEncodeFormatterPlugin
    from httpie.plugins.builtin import XMLFormatterPlugin

    # Test for JSONFormatterPlugin
    json_formatter_plugin = JSONFormatterPlugin(env=Environment())
    json_formatter_plugin.enabled = True
    json_formatter_plugin.options = PrettyOptionsPlugin(env=Environment())
    json_formatter_plugin.options.enabled = True
    json_formatter_plugin.options.indent = 2

# Generated at 2022-06-17 20:51:32.981842
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/toml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/markdown') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None

# Generated at 2022-06-17 20:51:41.385237
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('/')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:51:50.086735
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_

# Generated at 2022-06-17 20:52:00.612573
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: '{"name": "John Doe", "age": "20"}'
    #   - mime: 'application/json'
    # Expected output:
    #   - '{\n    "name": "John Doe",\n    "age": "20"\n}'
    content = '{"name": "John Doe", "age": "20"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John Doe",\n    "age": "20"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   - content: '{"name": "John Doe", "age": "20"}'


# Generated at 2022-06-17 20:52:04.254394
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:52:13.287869
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins.builtin import JSONOptions
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyFormatter
    from httpie.plugins.builtin import FormatterPlugin

# Generated at 2022-06-17 20:52:22.976148
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n'
    assert formatting.format_headers(headers) == '\x1b[32mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[33mContent-Type: text/plain\x1b[0m\r\n'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:52:32.399478
# Unit test for method format_body of class Formatting

# Generated at 2022-06-17 20:52:47.606288
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Given
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    # When
    result = formatting.format_body(content, mime)
    # Then
    assert result == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

# Generated at 2022-06-17 20:53:01.007066
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PrettyURLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import PrettyXMLFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import PrettyHTMLFormatter
    from httpie.plugins.builtin import CSVFormatter
    from httpie.plugins.builtin import PrettyCSVFormatter
    from httpie.plugins.builtin import ImageFormatter
    from httpie.plugins.builtin import PrettyImageFormatter
    from httpie.plugins.builtin import JavaScriptFormatter

# Generated at 2022-06-17 20:53:11.791301
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.colors = False
    env.stream = sys.stdout
    env.stdout_isatty = False
    env.is_windows = False
    env.config = {}
    env.config_dir = None
    env.config_path = None
    env.config_profile = None
    env.config_profiles = None
    env.config_defaults = None
    env.config_overrides = None
    env.config_search_paths = None
    env.config_loaded = False
    env.config_loaded_path = None
    env.config_loaded_profile = None
    env.config_loaded_profiles = None
    env.config_loaded_defaults = None
    env.config_loaded_overrides = None
    env.config_loaded_search_

# Generated at 2022-06-17 20:53:20.190728
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor

    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()

    # Test case 1:
    #   Input:
    #       groups = ['headers']
    #       headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   Expected output:
    #       HTTP/1.1 200 OK
    #       Content-

# Generated at 2022-06-17 20:53:24.993567
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-yml') is not None
    assert Conversion

# Generated at 2022-06-17 20:53:35.766172
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert not converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')

# Generated at 2022-06-17 20:53:45.972172
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Sun, 26 May 2019 02:29:47 GMT
Server: Apache/2.4.18 (Ubuntu)
Last-Modified: Tue, 07 May 2019 11:49:41 GMT
ETag: "2d-58f6b1c8a6f80"
Accept-Ranges: bytes
Content-Length: 45
Content-Type: text/html

'''
    groups = ['colors']
    env = Environment()
    env.stdout_isatty = True
    env.colors = 256
    env.style = 'solarized'
    env.headers = True
    env.stream = False
    env.verbose = False
    env.debug = False
    env.implicit_content_type = None
    env.implicit_content_type_

# Generated at 2022-06-17 20:53:53.694928
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups = ['colors']
    #   env = Environment()
    #   kwargs = {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m\x1b[37m OK\r\n\x1b[37mContent-Type: \x1b[33mapplication/json\x1b[39m\r\n\r\n\x1b[39m'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:54:03.214090
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    assert formatting.format_headers(headers) == '\x1b[90mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[90mContent-Type: application/json\x1b[0m\r\n\r\n'

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:54:13.719886
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   - content: {"name": "John", "age": 30, "city": "New York"}
    #   - mime: application/json
    # Expected output:
    #   - content: {
    #       "name": "John",
    #       "age": 30,
    #       "city": "New York"
    #   }
    content = '{"name": "John", "age": 30, "city": "New York"}'
    mime = 'application/json'
    expected_content = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    formatting = Formatting(['json'])
    assert formatting.format_body(content, mime) == expected_content



# Generated at 2022-06-17 20:54:38.609637
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:54:48.757903
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test 1:
    #   - groups: ['colors']
    #   - env: Environment()
    #   - kwargs: {}
    # Expected:
    #   - enabled_plugins: [<httpie.plugins.builtin.Formatter.ColorsFormatter object at 0x7f9c7e8e8b70>]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:55:01.416613
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.config['format'] = 'json'
    env.config['colors'] = 'on'
    env.config['style'] = 'solarized'
    env.config['print_body_only'] = True
    env.config['print_headers'] = True
    env.config['print_body'] = True
    env.config['print_cookies'] = True
    env.config['print_status'] = True
    env.config['print_method'] = True
    env.config['print_url'] = True
    env.config['print_elapsed'] = True
    env.config['print_size'] = True
    env.config['print_headers_only'] = True
    env.config['print_body_only'] = True
    env.config['print_cookies_only'] = True

# Generated at 2022-06-17 20:55:12.550782
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''
    assert f.format_headers(headers) == '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

    # Test case 2
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2

'''

# Generated at 2022-06-17 20:55:23.457540
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>'''
    groups = ['colors']
    env = Environment()
    formatter = Formatting(groups, env)

# Generated at 2022-06-17 20:55:26.557132
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    f = Formatting(groups, env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:55:34.812803
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/toml') is not None
    assert Conversion.get_converter('application/csv') is not None
    assert Conversion.get_converter('application/vnd.api+json') is not None
    assert Conversion.get_converter('application/vnd.api+xml') is not None
    assert Conversion.get_converter('application/vnd.api+yaml') is not None