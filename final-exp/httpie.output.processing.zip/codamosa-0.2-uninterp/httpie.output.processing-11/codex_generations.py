

# Generated at 2022-06-17 20:45:48.960970
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:45:53.243327
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=['colors'])
    assert f.format_body('{"a": "b"}', 'application/json') == '{\x1b[34m"a"\x1b[39;49;00m: \x1b[34m"b"\x1b[39;49;00m}'

# Generated at 2022-06-17 20:45:55.504625
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:46:02.065402
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/javascript') is not None
    assert Conversion.get_converter('text/css') is not None

# Generated at 2022-06-17 20:46:05.985571
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"key":"value"}'
    mime = 'application/json'
    assert formatting.format_body(content, mime) == '{\x1b[94m"key"\x1b[39m:\x1b[33m"value"\x1b[39m}'

# Generated at 2022-06-17 20:46:08.697488
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins != []


# Generated at 2022-06-17 20:46:16.476304
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test for constructor of class Formatting
    # Test for the case that groups is empty
    groups = []
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == []
    # Test for the case that groups is not empty
    groups = ['colors']
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins != []


# Generated at 2022-06-17 20:46:22.471090
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])
    assert Formatting(['colors', 'format'])
    assert Formatting(['colors', 'format', 'formatvars'])
    assert Formatting(['colors', 'format', 'formatvars', 'json'])
    assert Formatting(['colors', 'format', 'formatvars', 'json', 'pretty'])
    assert Formatting(['colors', 'format', 'formatvars', 'json', 'pretty', 'table'])
    assert Formatting(['colors', 'format', 'formatvars', 'json', 'pretty', 'table', 'unicode'])


# Generated at 2022-06-17 20:46:34.080536
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("application/yaml") is not None
    assert Conversion.get_converter("application/x-www-form-urlencoded") is not None
    assert Conversion.get_converter("text/html") is not None
    assert Conversion.get_converter("text/plain") is not None
    assert Conversion.get_converter("text/csv") is not None
    assert Conversion.get_converter("text/tab-separated-values") is not None
    assert Conversion.get_converter("text/xml") is not None
    assert Conversion.get_converter("text/yaml") is not None

# Generated at 2022-06-17 20:46:43.538269
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>'''
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)

# Generated at 2022-06-17 20:46:54.827905
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:46:59.625493
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:47:00.424948
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')

# Generated at 2022-06-17 20:47:05.261803
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': 'on'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:47:15.586791
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
   

# Generated at 2022-06-17 20:47:25.950426
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert not converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')

# Generated at 2022-06-17 20:47:36.871725
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import httpie.plugins.builtin.formatters.json
    import httpie.plugins.builtin.formatters.colors
    import httpie.plugins.builtin.formatters.format
    import httpie.plugins.builtin.formatters.pretty
    import httpie.plugins.builtin.formatters.format
    import httpie.plugins.builtin.formatters.format
    import httpie.plugins.builtin.formatters.format
    import httpie.plugins.builtin.formatters.format
    import httpie.plugins.builtin.formatters.format
    import httpie.plugins.builtin.formatters.format
    import httpie.plugins.builtin.formatters.format
    import httpie.plugins.builtin.formatters.format
    import httpie.plugins.builtin.formatters.format

# Generated at 2022-06-17 20:47:48.781642
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import os
    import sys
    import unittest
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import JSONLinesFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import PrettyJSONLinesFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import RawJSONLinesFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedLinesFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import XMLLinesFormatter
    from httpie.plugins.builtin import PrettyXMLLinesFormatter

# Generated at 2022-06-17 20:48:02.174039
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:48:13.989152
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yml') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion.get_conver

# Generated at 2022-06-17 20:48:21.100299
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:48:31.293686
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: 'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'
    #   groups: ['colors']
    # Output:
    #   '\x1b[36mHTTP/1.1 200 OK\x1b[0m\n\x1b[33mContent-Type: application/json\x1b[0m\n\n'
    headers = 'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'
    groups = ['colors']
    formatting = Formatting(groups)

# Generated at 2022-06-17 20:48:40.718242
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: text/html; charset=utf-8\r\n' \
              'Content-Length: 12\r\n' \
              'Connection: keep-alive\r\n' \
              'Server: gunicorn/19.9.0\r\n' \
              'Date: Sun, 22 Sep 2019 07:15:26 GMT\r\n' \
              '\r\n' \
              'Hello World!'
    groups = ['colors']
    env = Environment()
    env.colors = True
    env.style = 'solarized'
    env.stream = False
    env.headers = True
    env.body = True
    env.pretty = True
    env.print_

# Generated at 2022-06-17 20:48:47.197341
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test for valid mime
    assert Conversion.get_converter('application/json')
    # Test for invalid mime
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('json')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:48:59.929544
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:49:09.089406
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor

    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
    groups = ["HTTPHeadersProcessor", "JSONProcessor", "PrettyProcessor", "StreamProcessor", "SyntaxHighlightProcessor", "UnicodeProcessor"]
    env = Environment()
    kwargs = {"options": PrettyOptions()}
    formatting = Formatting

# Generated at 2022-06-17 20:49:17.033085
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.colors = 256
    env.style = 'solarized'
    env.headers = {'Content-Type': 'application/json'}
    env.prettify = True
    env.ugly = False
    env.stream = False
    env.download = False
    env.download_insecure = False
    env.verify = True
    env.verify_all = False
    env.auth = None
    env.auth_type = None
    env.timeout = None
    env.max_redirects = None
    env.follow_redirects = True
    env.headers_file = None
    env.body_file = None
    env.output_file = None
   

# Generated at 2022-06-17 20:49:28.582019
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None

# Generated at 2022-06-17 20:49:35.400536
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyURLEncodedProcessor
    from httpie.plugins.builtin import HTTPPrettyXMLProcessor
    from httpie.plugins.builtin import HTTPPrettyMultipartProcessor
    from httpie.plugins.builtin import HTTPPrettyHtmlProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrettyJsonProcessor
    from httpie.plugins.builtin import HTTPPrettyXmlProcessor
    from httpie.plugins.builtin import HTTPPrettyUrlencodedProcessor
    from httpie.plugins.builtin import HTTPPrettyMultipartProcessor
    from httpie.plugins.builtin import HTTPPrettyHtmlProcessor

# Generated at 2022-06-17 20:49:44.987151
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/markdown') is not None
    assert Conversion.get_converter('text/x-rst') is not None
   

# Generated at 2022-06-17 20:49:59.897689
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)

# Generated at 2022-06-17 20:50:05.658275
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'colors': 'on'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].colors == 'on'


# Generated at 2022-06-17 20:50:08.369339
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'


# Generated at 2022-06-17 20:50:15.710642
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import format_options
    from httpie.plugins.builtin import get_config
    from httpie.plugins.builtin import get_response_processor
    from httpie.plugins.builtin import get_style
    from httpie.plugins.builtin import get_theme
    from httpie.plugins.builtin import get_writer

# Generated at 2022-06-17 20:50:24.621376
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json") is not None
    assert Conversion.get_converter("application/xml") is not None
    assert Conversion.get_converter("text/html") is not None
    assert Conversion.get_converter("text/plain") is not None
    assert Conversion.get_converter("text/xml") is not None
    assert Conversion.get_converter("text/yaml") is not None
    assert Conversion.get_converter("text/yml") is not None
    assert Conversion.get_converter("text/csv") is not None
    assert Conversion.get_converter("text/tsv") is not None
    assert Conversion.get_converter("text/markdown") is not None

# Generated at 2022-06-17 20:50:35.422333
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_

# Generated at 2022-06-17 20:50:40.974075
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-ndjson'), ConverterPlugin)

# Generated at 2022-06-17 20:50:43.978180
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == []


# Generated at 2022-06-17 20:50:52.528755
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor
    from httpie.plugins.builtin import HTTPBodyProcessor

# Generated at 2022-06-17 20:50:59.793505
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: text/html; charset=utf-8\r\n' \
              'Content-Length: 12\r\n' \
              'Connection: keep-alive\r\n' \
              '\r\n' \
              'Hello World!'
    groups = ['colors']
    formatting = Formatting(groups)

# Generated at 2022-06-17 20:51:20.856495
# Unit test for method format_body of class Formatting

# Generated at 2022-06-17 20:51:31.193523
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/json1')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('application/json/1')
    assert not Conversion.get_converter('application/json1/1')
    assert not Conversion.get_converter('application/json/1/')
    assert not Conversion.get_converter('application/json1/1/')
    assert not Conversion.get_converter('application/json/1/1')
    assert not Conversion.get_converter('application/json1/1/1')
    assert not Conversion.get_converter('application/json/1/1/')

# Generated at 2022-06-17 20:51:42.664040
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/csv') is not None
    assert Conversion.get_converter('application/vnd.api+json') is not None
    assert Conversion.get_converter('application/vnd.api+xml') is not None
    assert Conversion.get_converter('application/vnd.api+yaml') is not None
    assert Conversion.get_converter('application/vnd.api+csv') is not None
    assert Conversion.get_converter('application/vnd.api+json') is not None

# Generated at 2022-06-17 20:51:50.541687
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyPrinter
    from httpie.plugins.builtin import PythonFormatter
    from httpie.plugins.builtin import RawJSONFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import ImageFormatter
    from httpie.plugins.builtin import JavaScriptFormatter
    from httpie.plugins.builtin import JSONLinesFormatter
    from httpie.plugins.builtin import JSONLinesPrettyFormatter

# Generated at 2022-06-17 20:51:54.951547
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.context import Environment
    env = Environment()
    f = Formatting(['colors'], env=env)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:52:06.561856
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/xml') is not None

# Generated at 2022-06-17 20:52:14.900657
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: close\r\n' \
              '\r\n' \
              '{}'
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups, env)
    formatted_headers = formatting.format_headers(headers)

# Generated at 2022-06-17 20:52:16.058144
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors"]
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == "ColorsFormatter"

# Generated at 2022-06-17 20:52:24.735741
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:52:29.284765
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/unknown') is None


# Generated at 2022-06-17 20:52:47.230681
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is None
    assert Conversion.get_converter('text/plain') is None
    assert Conversion.get_converter('text/xml') is None
    assert Conversion.get_converter('text/yaml') is None
    assert Conversion.get_converter('text/x-www-form-urlencoded') is None
    assert Conversion.get_converter('application/json; charset=utf-8') is not None

# Generated at 2022-06-17 20:52:52.325908
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:53:02.357129
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:53:11.946483
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('text/plain')
    assert not converter.supports('application/xml')
    assert not converter.supports('application/json+xml')
    assert not converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; ')

# Generated at 2022-06-17 20:53:20.278654
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/html'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/tab-separated-values'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/x-www-form-urlencoded'), ConverterPlugin)

# Generated at 2022-06-17 20:53:24.723214
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('text/yaml') is not None

# Generated at 2022-06-17 20:53:35.589364
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])
    assert Formatting(['colors', 'format'])
    assert Formatting(['colors', 'format', 'format_json'])
    assert Formatting(['colors', 'format', 'format_json', 'format_xml'])
    assert Formatting(['colors', 'format', 'format_json', 'format_xml', 'format_html'])
    assert Formatting(['colors', 'format', 'format_json', 'format_xml', 'format_html', 'format_javascript'])
    assert Formatting(['colors', 'format', 'format_json', 'format_xml', 'format_html', 'format_javascript', 'format_css'])

# Generated at 2022-06-17 20:53:40.018074
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': True}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:53:42.103743
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:53:51.009967
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor

    # Test case 1

# Generated at 2022-06-17 20:54:02.432993
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:54:06.210652
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/unknown')

# Generated at 2022-06-17 20:54:14.754896
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n"
    #   groups: ['colors']
    # Expected output:
    #   headers: "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n"
    groups = ['colors']
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n"
    expected_headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n"
    formatting = Formatting(groups)
    assert formatting.format_headers(headers) == expected_headers

    # Test case

# Generated at 2022-06-17 20:54:19.657064
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'style': 'solarized'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].style == 'solarized'
    assert f.enabled_plugins[0].env == env

# Generated at 2022-06-17 20:54:30.664690
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json; charset=utf-8') is not None
    assert Conversion.get_converter('application/json; charset=utf-8;') is not None
    assert Conversion.get_converter('application/json; charset=utf-8; ') is not None
    assert Conversion.get_converter('application/json; charset=utf-8; a=b') is not None
    assert Conversion.get_converter('application/json; charset=utf-8; a=b;') is not None
    assert Conversion.get_converter('application/json; charset=utf-8; a=b; ') is not None

# Generated at 2022-06-17 20:54:36.102140
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test for constructor of class Formatting
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': True}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[0].colors == True
    assert formatting.enabled_plugins[0].env == env


# Generated at 2022-06-17 20:54:46.535339
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('application/octet-stream') is not None
    assert Conversion.get_converter('application/pdf') is not None

# Generated at 2022-06-17 20:54:59.744723
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('application/')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('application/json/')
    assert not Conversion.get_converter('/json/')
    assert not Conversion.get_converter('/')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:55:03.706276
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-17 20:55:13.971609
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/json-patch+json')
    assert not Conversion.get_converter('application/json-patch+json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json; charset=utf-8; version=1')
    assert not Conversion.get_converter('application/json; version=1')
    assert not Conversion.get_converter('application/json; version=1; charset=utf-8')
    assert not Conversion.get_converter('application/json; version=1; charset=utf-8;')

# Generated at 2022-06-17 20:55:25.290776
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = {'colors': 'on'}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].env == env
    assert f.enabled_plugins[0].colors == 'on'


# Generated at 2022-06-17 20:55:33.733066
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Case 1:
    #   Input:
    #       content: '{"name": "John", "age": 30, "car": null}'
    #       mime: 'application/json'
    #   Expected output:
    #       '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Case 2:
   

# Generated at 2022-06-17 20:55:41.778870
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin_isatty = False
    env.stdout_isatty = False
    env.stderr_isatty = False
    env.colors = 256
    env.config_dir = None
    env.config_path = None
    env.config = None
    env.default_options = None
    env.config_defaults = None
    env.config_overrides = None
    env.config_files = None
    env.config_dirs = None
    env.colors = 256
    env.color_mode = 'auto'
    env.style = None
    env.style_overrides = None
