

# Generated at 2022-06-17 20:45:46.320379
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter

# Generated at 2022-06-17 20:45:59.736630
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
ETag: "3f80f-1b6-3e1cb03b"
Content-Type: text/html; charset=UTF-8
Content-Length: 131
Accept-Ranges: bytes
Connection: close

<html>
<head>
  <title>An Example Page</title>
</head>
<body>
  Hello World, this is a very simple HTML document.
</body>
</html>'''
    f = Formatting(['colors'])

# Generated at 2022-06-17 20:46:06.696727
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded; charset=utf-8') is not None

# Generated at 2022-06-17 20:46:18.033599
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/tsv') is not None
    assert Conversion

# Generated at 2022-06-17 20:46:27.961511
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert Conversion.get_converter('application/json').supports('application/json')
    assert not Conversion.get_converter('application/json').supports('application/xml')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8;')
    assert not Conversion.get_converter('application/json').supports('application/json; charset=utf-8; ')

# Generated at 2022-06-17 20:46:39.731475
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/tsv') is not None
   

# Generated at 2022-06-17 20:46:44.104451
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'], env=Environment())
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[0].env.__class__.__name__ == 'Environment'


# Generated at 2022-06-17 20:46:53.964053
# Unit test for constructor of class Formatting
def test_Formatting():
    # test for empty groups
    f = Formatting([])
    assert f.enabled_plugins == []

    # test for non-empty groups
    f = Formatting(['colors'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

    # test for non-empty groups
    f = Formatting(['colors', 'colors'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

    # test for non-empty groups
    f = Formatting(['colors', 'format'])
    assert len(f.enabled_plugins) == 2
    assert f.enabled_plugins[0].__class__.__

# Generated at 2022-06-17 20:47:03.234248
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/json; charset=utf-8'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/json; charset=utf-8;'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/json; charset=utf-8; '), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/json; charset=utf-8; a=b'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/json; charset=utf-8; a=b;'), ConverterPlugin)

# Generated at 2022-06-17 20:47:13.907495
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test case 1: groups is empty
    groups = []
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == []

    # Test case 2: groups is not empty
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

    # Test case 3: groups is not empty, but the group is not supported
    groups = ['colors', 'not_supported']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)

# Generated at 2022-06-17 20:47:22.336815
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-17 20:47:27.351180
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test with valid arguments
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == []

    # Test with invalid arguments
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins == []

# Generated at 2022-06-17 20:47:37.828943
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:47:49.349930
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:47:54.392277
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    assert f.format_body('{"a": "b"}', 'application/json') == '{\n    "a": "b"\n}'

# Generated at 2022-06-17 20:48:05.782712
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
   

# Generated at 2022-06-17 20:48:16.502530
# Unit test for method format_body of class Formatting

# Generated at 2022-06-17 20:48:27.992754
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is None
    assert Conversion.get_converter('text/plain') is None
    assert Conversion.get_converter('text/css') is None
    assert Conversion.get_converter('image/png') is None
    assert Conversion.get_converter('image/jpeg') is None
    assert Conversion.get_converter('image/gif') is None

# Generated at 2022-06-17 20:48:35.452166
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 2
Connection: keep-alive
Date: Thu, 30 Apr 2020 09:15:28 GMT
Server: nginx/1.14.0 (Ubuntu)

{}'''
    groups = ['colors']
    formatting = Formatting(groups)
    formatted_headers = formatting.format_headers(headers)

# Generated at 2022-06-17 20:48:37.292020
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-17 20:48:49.840895
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonStreamFormatter
    from httpie.plugins.builtin import RawJsonFormatter
    from httpie.plugins.builtin import RawJsonStreamFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedStreamFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import XMLStreamFormatter
    from httpie.plugins.builtin import HTMLFormatter
    from httpie.plugins.builtin import HTMLStreamFormatter
    from httpie.plugins.builtin import CSVForm

# Generated at 2022-06-17 20:49:00.692304
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name": "httpie"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "httpie"\n}'
    content = '{"name": "httpie"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "httpie"\n}'
    output = Formatting(['json']).format_body(content, mime)
    assert output == expected_output

    # Test case 2:
    # Input:
    #   content: '{"name": "httpie"}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "httpie"\n

# Generated at 2022-06-17 20:49:09.924841
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonStreamFormatter
    from httpie.plugins.builtin import PrettyStreamFormatter
    from httpie.plugins.builtin import RawJsonFormatter
    from httpie.plugins.builtin import RawOrPrettyJsonFormatter
    from httpie.plugins.builtin import RawStreamFormatter
    from httpie.plugins.builtin import StreamFormatter
    from httpie.plugins.builtin import URLEncodedFormatter
    from httpie.plugins.builtin import URLEncodedStreamFormatter
    from httpie.plugins.builtin import XMLFormatter
    from httpie.plugins.builtin import XMLStreamFormatter

# Generated at 2022-06-17 20:49:17.701234
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:49:29.157981
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name":"John","age":30,"car":null}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name":"John","age":30,"car":null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    formatting = Formatting(groups=['json'])
    assert formatting.format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content = '<

# Generated at 2022-06-17 20:49:33.099561
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'colors': 'on'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert formatting.enabled_plugins[1].__class__.__name__ == 'FormatFormatter'


# Generated at 2022-06-17 20:49:44.141921
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors'])
    assert Formatting(['colors', 'format'])
    assert Formatting(['colors', 'format', 'format_options'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options', 'colors_extras'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options', 'colors_extras', 'colors_16m'])
    assert Formatting(['colors', 'format', 'format_options', 'colors_options', 'colors_extras', 'colors_16m', 'colors_256'])

# Generated at 2022-06-17 20:49:55.239172
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.stdout = io.StringIO()
    env.stdin = io.StringIO()
    env.stdin.write("""HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed

<html>
<body>
<h1>Hello, World!</h1>
</body>
</html>""")
    env.stdin.seek(0)
    formatting = Formatting(groups=['colors'], env=env)
    result = formatting.format_headers(env.stdin.read())

# Generated at 2022-06-17 20:50:02.810362
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n') == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[37m\x1b[1mContent-Type: application/json\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:50:08.738474
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n') == '\x1b[36mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[33mContent-Type: text/html\x1b[0m\r\n\r\n'


# Generated at 2022-06-17 20:50:21.631394
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test for constructor of class Formatting
    # Case 1:
    #   Input:
        #   groups = ['colors']
        #   env = Environment()
        #   kwargs = {}
    #   Expected output:
        #   enabled_plugins = [ColorsFormatter]
    groups = ['colors']
    env = Environment()
    kwargs = {}
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins == [ColorsFormatter]

    # Case 2:
    #   Input:
        #   groups = ['colors', 'format']
        #   env = Environment()
        #   kwargs = {}
    #   Expected output:
        #   enabled_plugins = [ColorsFormatter, FormatFormatter]

# Generated at 2022-06-17 20:50:32.394765
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrintHtmlProcessor
    from httpie.plugins.builtin import HTTPPrintJsonProcessor
    from httpie.plugins.builtin import HTTPPrintProcessor
    from httpie.plugins.builtin import HTTPPrintXmlProcessor
    from httpie.plugins.builtin import HTTPPrintYamlProcessor
    from httpie.plugins.builtin import HTTPPrintXmlProcessor
    from httpie.plugins.builtin import HTTPPrintYamlProcessor
    from httpie.plugins.builtin import HTTPPrintXmlProcessor
    from httpie.plugins.builtin import HTTPPrintYamlProcessor
    from httpie.plugins.builtin import HTTPPrintXmlProcessor


# Generated at 2022-06-17 20:50:38.928980
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'])
    assert f.format_headers("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 13\r\n\r\n") == "\x1b[37mHTTP/1.1 \x1b[32m200 \x1b[36mOK\x1b[0m\r\n\x1b[37mContent-Type: \x1b[36mtext/html; charset=utf-8\x1b[0m\r\n\x1b[37mContent-Length: \x1b[36m13\x1b[0m\r\n\r\n"


# Generated at 2022-06-17 20:50:48.181088
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')
    assert not converter.supports('application/json; charset=utf-8')
    assert not converter.supports('application/json; charset=utf-8;')
    assert not converter.supports('application/json; charset=utf-8; ')
    assert not converter.supports('application/json; charset=utf-8; a=b')
    assert not converter.supports('application/json; charset=utf-8; a=b;')
    assert not converter.supports('application/json; charset=utf-8; a=b; ')
    assert not converter.supports

# Generated at 2022-06-17 20:50:56.288314
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor
    from httpie.plugins.builtin import HTTPPrettyProcessor
    from httpie.plugins.builtin import HTTPPrettyURLEncodedProcessor
    from httpie.plugins.builtin import HTTPPrettyXMLProcessor
    from httpie.plugins.builtin import HTTPPrettyHTMLProcessor
    from httpie.plugins.builtin import HTTPPrettyMarkdownProcessor
    from httpie.plugins.builtin import HTTPPrettyPandocProcessor
    from httpie.plugins.builtin import HTTPPrettyHighlightProcessor
    from httpie.plugins.builtin import HTTPPrettyCSSProcessor
    from httpie.plugins.builtin import HTTPPrettyJSProcessor
    from httpie.plugins.builtin import HTTPPrettyTextProcessor
    from httpie.plugins.builtin import HTTPPrettyGraphQLProcessor


# Generated at 2022-06-17 20:51:06.202008
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:51:09.476950
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors"]
    env = Environment()
    f = Formatting(groups, env)
    assert f.enabled_plugins[0].__class__.__name__ == "ColorsFormatter"

# Generated at 2022-06-17 20:51:11.102481
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')

# Generated at 2022-06-17 20:51:21.352710
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-17 20:51:31.455381
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None

# Generated at 2022-06-17 20:51:46.941282
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content = '{"name":"John", "age":30, "city":"New York"}'
    #   mime = 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    content = '{"name":"John", "age":30, "city":"New York"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "city": "New York"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #  

# Generated at 2022-06-17 20:51:59.940024
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'
    #   groups = ['colors']
    #   env = Environment()
    #   kwargs = {}
    # Expected output:
    #   '\x1b[37mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[32mOK\x1b[39m\r\n\x1b[37mContent-Type: application/json\r\n\r\n\x1b[39m'
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n'

# Generated at 2022-06-17 20:52:09.929830
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1:
    # Input:
    #   headers: "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12\r\n\r\n"
    #   groups: ["colors"]
    # Expected output:
    #   headers: "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12\r\n\r\n"
    headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 12\r\n\r\n"
    groups = ["colors"]
    formatting = Formatting(groups)
    assert formatting.format

# Generated at 2022-06-17 20:52:20.936589
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json; charset=utf-8\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: keep-alive\r\n' \
              'Server: gunicorn/19.9.0\r\n' \
              'Date: Mon, 22 Jul 2019 05:33:49 GMT\r\n' \
              '\r\n' \
              '{}'

# Generated at 2022-06-17 20:52:31.401331
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: application/json\r\n' \
              'Content-Length: 2\r\n' \
              'Connection: keep-alive\r\n' \
              'Server: gunicorn/19.9.0\r\n' \
              'Date: Sun, 24 Mar 2019 09:54:41 GMT\r\n' \
              '\r\n' \
              '{}'
    headers = formatting.format_headers(headers)

# Generated at 2022-06-17 20:52:41.612627
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name": "John", "age": 30, "car": null}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name": "John", "age": 30, "car": null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"name":

# Generated at 2022-06-17 20:52:47.548777
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test with no plugins
    f = Formatting([])
    assert f.enabled_plugins == []

    # Test with one plugin
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

    # Test with two plugins
    f = Formatting(['colors', 'format'])
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'FormatFormatter'


# Generated at 2022-06-17 20:53:01.006264
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
    from httpie.plugins.builtin import PrettyOptionsPlugin
   

# Generated at 2022-06-17 20:53:11.783168
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJsonFormatter
    from httpie.plugins.builtin import PrettyJ

# Generated at 2022-06-17 20:53:18.254052
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test for method format_body of class Formatting
    # Given
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    content = '{"foo": "bar"}'
    mime = 'application/json'
    # When
    result = formatting.format_body(content, mime)
    # Then
    assert result == '{\x1b[94m"foo"\x1b[39m: \x1b[94m"bar"\x1b[39m}'

# Generated at 2022-06-17 20:53:37.310502
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('text/yaml') is not None
    assert Conversion.get_converter('text/x-yaml') is not None
    assert Conversion.get_converter('text/x-toml') is not None
    assert Conversion.get_converter('text/x-python') is not None
    assert Conversion.get

# Generated at 2022-06-17 20:53:43.978815
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1: mime is not valid
    mime = "text/plain"
    content = "Hello world"
    assert Formatting([]).format_body(content, mime) == content

    # Test case 2: mime is valid
    mime = "application/json"
    content = '{"name":"John", "age":30, "car":null}'
    assert Formatting(["json"]).format_body(content, mime) == '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'

# Generated at 2022-06-17 20:53:52.218815
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import StreamProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor
    from httpie.plugins.builtin import ZeroRTTProcessor
    from httpie.plugins.builtin import get_config
    from httpie.plugins.builtin import get_response_processor
    from httpie.plugins.builtin import get_style_defaults
    from httpie.plugins.builtin import get_style
    from httpie.plugins.builtin import get_theme

# Generated at 2022-06-17 20:54:02.775727
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1:
    # Input:
    #   content: '{"name":"John","age":30,"car":null}'
    #   mime: 'application/json'
    # Expected output:
    #   '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    content = '{"name":"John","age":30,"car":null}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   content: '{"name":"John","age":30,"

# Generated at 2022-06-17 20:54:13.491624
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import UnicodeProcessor

    # Test 1
    groups = ['headers']
    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'
    env.colors = 256
    env.style = 'solarized'
    env.format = 'colors'
    env.prettify = True
    env.syntax = 'auto'
    env.stream = False

# Generated at 2022-06-17 20:54:25.557995
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.config['format'] = 'json'
    env.config['pretty'] = True
    env.config['colors'] = True
    env.config['style'] = 'solarized'
    env.config['formatters'] = ['colors', 'colors_256', 'colors_16m']
    env.config['formatters_styles'] = ['solarized', 'monokai']
    env.config['prettifiers'] = ['json', 'xml']
    env.config['prettifiers_styles'] = ['solarized', 'monokai']
    env.config['print_body_only'] = True
    env.config['print_headers'] = True
    env.config['print_method'] = True
    env.config['print_status'] = True

# Generated at 2022-06-17 20:54:35.990307
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    Test the method format_body of class Formatting
    """
    # Test case 1:
    # Input:
    #   - content: '{"name": "John Doe"}'
    #   - mime: 'application/json'
    # Expected output:
    #   - '{\n    "name": "John Doe"\n}'
    content = '{"name": "John Doe"}'
    mime = 'application/json'
    expected_output = '{\n    "name": "John Doe"\n}'
    assert Formatting(['json']).format_body(content, mime) == expected_output

    # Test case 2:
    # Input:
    #   - content: '{"name": "John Doe"}'
    #   - mime: 'application/json'
    # Expected output

# Generated at 2022-06-17 20:54:46.425850
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONProcessor
    from httpie.plugins.builtin import PrettyOptions
    from httpie.plugins.builtin import PrettyProcessor
    from httpie.plugins.builtin import SyntaxHighlightProcessor
    from httpie.plugins.builtin import XMLProcessor

    env = Environment()
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()

    # Test case 1:
    #   groups = ['headers']
    #   kwargs = {}
    #   expected_enabled_plugins = [HTTPHeadersProcessor]
    groups = ['headers']
    kwargs = {}
    expected_enabled_plugins = [HTTPHeadersProcessor]

# Generated at 2022-06-17 20:54:49.225205
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    kwargs = {'style': 'solarized'}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins[0].style == 'solarized'

# Generated at 2022-06-17 20:55:01.555071
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('application/xml')
    assert not Conversion.get_converter('application/json+xml')
    assert not Conversion.get_converter('application/json/xml')
    assert not Conversion.get_converter('application/json+xml/xml')
    assert not Conversion.get_converter('application/json+xml/xml/xml')
    assert not Conversion.get_converter('application/json+xml/xml/xml/xml')
    assert not Conversion.get_converter('application/json+xml/xml/xml/xml/xml')
    assert not Conversion.get_converter('application/json+xml/xml/xml/xml/xml/xml')

# Generated at 2022-06-17 20:55:27.076429
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/yaml') is not None
    assert Conversion.get_converter('application/x-www-form-urlencoded') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('text/plain') is not None
    assert Conversion.get_converter('text/csv') is not None
    assert Conversion.get_converter('text/tab-separated-values') is not None
    assert Conversion.get_converter('application/octet-stream') is not None

# Generated at 2022-06-17 20:55:32.100155
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/xml')
    assert Conversion.get_converter('application/yaml')
    assert not Conversion.get_converter('application/text')
    assert not Conversion.get_converter('application')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)
