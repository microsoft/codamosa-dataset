

# Generated at 2022-06-21 14:13:36.862279
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '{ "name": "John", "age": 30, "car": null }'
    expected_output = '{\n    "name": "John",\n    "age": 30,\n    "car": null\n}'
    output = Formatting(["formatters"]).format_body(content, "application/json")
    assert output == expected_output


# Generated at 2022-06-21 14:13:46.670239
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    
    # Environment of class Formatting
    env = Environment()
    env.stdout = open(os.devnull, 'wb')
    env.stderr = open(os.devnull, 'wb')

    # -f jl test cases
    fmt = Formatting(['jl'], env, colors=0)
    assert fmt.format_body('{"x":1}', 'application/json') == '{x: 1}', '-f jl application/json'
    assert fmt.format_body('{"x":1}', 'text/json') == '{x: 1}', '-f jl text/json'
    assert fmt.format_body('{"x":1}', 'application/javascript') == '{x: 1}', '-f jl application/javascript'

# Generated at 2022-06-21 14:13:58.073534
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    
    class MyFormatterPlugin(FormatterPlugin, Environment):
        """Formatter plugin for MyFormatterPlugin testing."""
        def __init__(self, env=None):
            FormatterPlugin.__init__(self)
            Environment.__init__(self)
            self.env = env or Environment()
            self.env.stdout = self.env.stdout_isatty
            
        def format_headers(self, headers):
            return 'my_formatter_plugin_header'

        def format_body(self, body, mime):
            return 'my_formatter_plugin_body'

    # Unit test for existing environment
    existing_env = Environment()
    existing_env.stdout = existing_env.stdout_is

# Generated at 2022-06-21 14:14:02.759879
# Unit test for constructor of class Conversion
def test_Conversion():
    try:
        Conversion.get_converter('text/plain')
    except TypeError:
        print('Invalid arguments!')
    try:
        Conversion.get_converter('text/html')
    except TypeError:
        print('Invalid arguments!')


# Generated at 2022-06-21 14:14:04.609079
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # The method format_headers of class Formatting can be tested with the following unit test in the future
    return


# Generated at 2022-06-21 14:14:08.057693
# Unit test for constructor of class Conversion
def test_Conversion():
	assert Conversion.get_converter('text/plain')


# Unit tests for constructor of class Formatting
#def test_Formatting():
    #formatted = Formatting(['pretty'])
    #assert formatted.headers == b'TESTE'

# Generated at 2022-06-21 14:14:19.596012
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    environment = Environment(colors=False)
    test1 = Formatting(groups=['jd'], env=environment)
    assert str(test1.enabled_plugins[0]) == 'jd'
    assert test1.format_headers('{\n    a:b\n    }') == '{\n    a: b\n    }'
    test2 = Formatting(groups=['jd', 'json'], env=environment)
    assert str(test2.enabled_plugins[1]) == 'json'
    assert test2.format_headers('{\n    a: b\n    }') == '{\n  "a": "b"\n}'
    test3 = Formatting(groups=['jd', 'json', 'html'], env=environment)

# Generated at 2022-06-21 14:14:28.503796
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting = Formatting(["highlighting"])

    # Test for valid MIME
    content_1 = formatting.format_body("{\"status\": \"OK\"}", "application/json")
    assert content_1 == "\x1b[37m\x1b[44m{\x1b[39m\x1b[49m\n    \x1b[33m\"status\"\x1b[39m\x1b[49m\x1b[32m: \x1b[39m\x1b[49m\x1b[32m\"OK\"\x1b[39m\x1b[49m\n\x1b[37m\x1b[44m}\x1b[39m\x1b[49m\n"

    # Test for invalid MIME
    content_2

# Generated at 2022-06-21 14:14:39.796068
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # For testing the output of this method, please refer to the unit test case of method format_headers.
    body = '''{"firstName": "John","lastName": "Smith","isAlive": true,"age": 27,"address": {"streetAddress": "21 2nd Street","city": "New York","state": "NY","postalCode": "10021-3100"},"phoneNumbers": [{"type": "home","number": "212 555-1234"},{"type": "office","number": "646 555-4567"},{"type": "mobile","number": "123 456-7890"}],"children": [],"spouse": null}'''
    mime_type = 'application/json'
    frmt = Formatting(groups=['colors', 'format'], env=Environment(colors=False))

# Generated at 2022-06-21 14:14:41.660790
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert converter



# Generated at 2022-06-21 14:14:47.348842
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('abc')
    assert not is_valid_mime('abc/')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application/')

# Generated at 2022-06-21 14:14:53.512627
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['headers'])


# Generated at 2022-06-21 14:15:02.121994
# Unit test for function is_valid_mime
def test_is_valid_mime():
    tests = {
        'True, valid mime': (True, 'text/plain'),
        'True, valid mime with charset': (True, 'text/plain; charset=utf8'),
        'False, missing first slash': (False, 'textplain'),
        'False, missing second slash': (False, 'text/plain/extra'),
        'False, empty string': (False, ''),
    }
    for test_name, expected_result_tuple in tests.items():
        expected_result, test_mime = expected_result_tuple
        result = is_valid_mime(test_mime)
        assert result == expected_result, test_name

# Generated at 2022-06-21 14:15:10.146057
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test case 1
    class test_Plugin(object):
        def __init__(self, env=Environment(), **kwargs):
            pass
        def format_body(self, content):
            return content
    format_mock = test_Plugin()
    content = "testing"
    mime = "testing"
    ab = Formatting(['testing'])
    ab.enabled_plugins.append(format_mock)
    assert ab.format_body(content, mime) == "testing"

    # Test case 2
    content = "testing"
    mime = "testing1"
    assert ab.format_body(content, mime) == "testing"

    # Test case 3
    content = "testing"
    mime = ""
    assert ab.format_body(content, mime) == "testing"

test

# Generated at 2022-06-21 14:15:15.267311
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime("")
    assert not is_valid_mime("a")
    assert not is_valid_mime("a/")
    assert not is_valid_mime("/a")
    assert not is_valid_mime("/")
    assert is_valid_mime("a/a")
    assert is_valid_mime("application/json")


# Generated at 2022-06-21 14:15:16.338958
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    if converter is not None:
        assert "JSON" in converter.name

# Generated at 2022-06-21 14:15:18.880282
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['json']
    env = Environment()
    f = Formatting(groups, env, style='foo')
    assert len(f.enabled_plugins) == 1


# Generated at 2022-06-21 14:15:23.597680
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime(None)
    assert not is_valid_mime('')
    assert not is_valid_mime('/')
    assert not is_valid_mime('//')
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/html')

# Generated at 2022-06-21 14:15:28.691464
# Unit test for function is_valid_mime
def test_is_valid_mime():
    """Test is_valid_mime() function."""
    assert is_valid_mime('text/plain')
    assert is_valid_mime('text/plain; charset=utf-8')

    assert not is_valid_mime('textplain')
    assert not is_valid_mime('text')
    assert not is_valid_mime('plain')
    assert not is_valid_mime(None)

# Generated at 2022-06-21 14:15:32.372179
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    csv = Conversion.get_converter("text/csv")
    assert csv is not None
    assert type(csv).__name__ == "CSVConverter"

    jpeg = Conversion.get_converter("image/jpeg")
    assert jpeg is not None
    assert type(jpeg).__name__ == "ImageConverter"

# Generated at 2022-06-21 14:15:46.819394
# Unit test for constructor of class Conversion
def test_Conversion():
    import httpie.plugins
    from httpie.plugins import ConverterPlugin

    class Dummy(ConverterPlugin):
        supported_mime_types = ["tv/dummy"]

        def encode_file(self, path):
            pass

        def decode_body(self, body):
            pass

    class Dummy2(ConverterPlugin):
        supported_mime_types = ["tv/dummy2"]

        def encode_file(self, path):
            pass

        def decode_body(self, body):
            pass

    httpie.plugins.plugin_manager = httpie.plugins.PluginManager()
    httpie.plugins.plugin_manager._plugins = [Dummy, Dummy2]

    converter = Conversion.get_converter("tv/dummy")
    assert converter is not None

    converter = Conversion.get_

# Generated at 2022-06-21 14:15:52.128546
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('jso') is None
    assert isinstance(
        Conversion.get_converter('application/json'),
        ConverterPlugin
    )
    assert isinstance(
        Conversion.get_converter('application/jq'),
        ConverterPlugin
    )
    assert Conversion.get_converter('application/jq-other') is None



# Generated at 2022-06-21 14:16:02.803411
# Unit test for constructor of class Formatting
def test_Formatting():

    env = Environment()
    env.config.output_options.prettify = True
    env.config.output_options.colors = 0
    env.config.output_options.format = 'Pretty'

    ff = Formatting(env=env)

    return ff



# class Formatting:
#     """A delegate class that invokes the actual processors."""
#
#     def __init__(self, groups: List[str], **kwargs):
#         """
#         :param groups: names of processor groups to be applied
#         :param kwargs: additional keyword arguments for processors
#
#         """
#         available_plugins = plugin_manager.get_formatters_grouped()
#         self.enabled_plugins = []
#         for group in groups:
#             for cls in available_plugins[group]:
#

# Generated at 2022-06-21 14:16:13.963693
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not is_valid_mime('')
    assert not is_valid_mime('xxx')
    assert not is_valid_mime('xxx/')
    assert not is_valid_mime('/yyy')
    assert not is_valid_mime('xxx/yyy/zzz')
    assert is_valid_mime('text/html')

    conv = Conversion.get_converter('')
    assert conv is None

    conv = Conversion.get_converter('xxx')
    assert conv is None

    conv = Conversion.get_converter('xxx/')
    assert conv is None

    conv = Conversion.get_converter('/yyy')
    assert conv is None

    conv = Conversion.get_converter('xxx/yyy/zzz')
    assert conv is None

    conv

# Generated at 2022-06-21 14:16:20.030336
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-21 14:16:27.847829
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    plugin_manager.load_installed_plugins()
    formatting=Formatting(['pretty'],colors=True)
    json.dumps({"a": [1, 2, 3]}, indent=2)
    assert formatting.format_body('{"a": [1, 2, 3]}', 'application/json') == '{\n  "a": [\n    1,\n    2,\n    3\n  ]\n}\n'
    assert formatting.format_body('<p>hello</p>', 'application/xml') == '<p>hello</p>\n'

# Generated at 2022-06-21 14:16:32.555925
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    testFormatting = Formatting([])
    bad_mime = 'toto/titi'
    assert not is_valid_mime(bad_mime)
    assert testFormatting.format_body('{"test":1}', bad_mime) == '{\n    "test": 1\n}'
    assert testFormatting.format_body('{"test":1}', 'application/json') == '{\'test\': 1}'




# Generated at 2022-06-21 14:16:35.805756
# Unit test for constructor of class Conversion
def test_Conversion():
    # Arrange
    mime = 'application/json'

    # Act
    converter = Conversion.get_converter(mime)

    # Assert
    assert converter != None


# Generated at 2022-06-21 14:16:37.723539
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting = Formatting([])
    assert type(formatting) == Formatting


# Generated at 2022-06-21 14:16:41.511919
# Unit test for constructor of class Conversion
def test_Conversion():
    # mime matches the regex
    assert(Conversion.get_converter("application/json") is not None)
    # mime does not match the regex
    assert(Conversion.get_converter("image/svg") is None)

# Generated at 2022-06-21 14:16:48.293466
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('text')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('/html')

# Generated at 2022-06-21 14:16:49.215925
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting_obj = Formatting(["colors"])
    content = formatting_obj.format_body("b'body'", "application/json")
    print(content)


# Generated at 2022-06-21 14:16:55.711900
# Unit test for function is_valid_mime
def test_is_valid_mime():
    c = Formatting([])
    cases = [
        ('json', True), ('application/json', True), ('application/json;charset=utf-8', True),
        ('', False), ('json;charset=utf-8', False), ('text', False), ('text/', False), ('foo/bar', True)
    ]
    for case, expected in cases:
        assert c.is_valid_mime(case) == expected, case


if __name__ == '__main__':
    test_is_valid_mime()

# Generated at 2022-06-21 14:16:57.866474
# Unit test for constructor of class Formatting
def test_Formatting():
    print("Testing Formatting...")
    converter = Formatting(["raw"])
    assert converter is not None
    print("...done!")


# Generated at 2022-06-21 14:17:01.101392
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '{"items":[{"id":1},{"id":2}]}'
    mime = 'application/json'
    formatting = Formatting(groups = ['parsed'])
    processing_result = formatting.format_body(content, mime)
    print(processing_result)
# test_Formatting_format_body()


# Generated at 2022-06-21 14:17:04.449461
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['json', 'colors']
    f = Formatting(groups)
    assert len(f.enabled_plugins) == 2
    for p in f.enabled_plugins:
        assert p.enabled

# Generated at 2022-06-21 14:17:10.168374
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    t1 = Formatting(['colors'])
    assert t1.format_body("<body><h1>400 Bad Request</h1>\n<p>Your browser sent a request that this server could not understand.</p>\n</body>\n","text/html") == "\x1b[31m400 Bad Request\x1b[39m\n\x1b[35mYour browser sent a request that this server could not understand.\x1b[39m\n"

# Generated at 2022-06-21 14:17:17.227085
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor

    headers = "Content-Type: application/zip\r\nConnection: close"
    expected_headers = "Connection: close\r\nContent-Type: application/zip"

    formatting = Formatting(groups=['HTTPHeadersProcessor'], prefs={"sort_headers": True}, env=Environment())
    #  sort_headers=True

    assert formatting.format_headers(headers) == expected_headers



# Generated at 2022-06-21 14:17:18.950178
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter("application/json")
    assert converter is not None

# Generated at 2022-06-21 14:17:27.297044
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in ['colors']:
        for cls in available_plugins[group]:
            p = cls(env=Environment(), **{})
            if p.enabled:
                enabled_plugins.append(p)
    for p in enabled_plugins:
        content = p.format_body('<title>TestCase</title>', 'text/html')
        assert 'Title' in content


# Generated at 2022-06-21 14:17:34.087674
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    with open('../test_data/one_correct_request.json', 'r') as f:
        content = f.read()
    f = Formatting(['colors'])
    print(f.format_body(content, 'application/json'))



# Generated at 2022-06-21 14:17:43.218568
# Unit test for constructor of class Conversion
def test_Conversion():
    # content = '<h1>Hello World!</h1>'
    # mime = 'text/html'
    assert is_valid_mime('text/html') is True
    assert is_valid_mime('application/json') is True
    assert is_valid_mime('application/hal+json') is True
    assert is_valid_mime('application/yaml') is True
    assert is_valid_mime('text/xml') is True
    assert is_valid_mime('image/svg+xml') is True
    assert is_valid_mime('foo/bar') is False
    assert is_valid_mime('foo/') is False
    assert is_valid_mime('foo') is False
    assert is_valid_mime('/') is False

# Generated at 2022-06-21 14:17:44.904869
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').__class__.__name__ == 'JSONConverter'

# Generated at 2022-06-21 14:17:46.110925
# Unit test for constructor of class Conversion
def test_Conversion():
    comp = Conversion()
    assert isinstance(comp, Conversion)

# Generated at 2022-06-21 14:17:55.949522
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Testing an empty string as headers
    f = Formatting(groups=['colors'])
    result1 = f.format_headers("")
    expected1 = ""
    assert result1 == expected1

    # Testing a single line of headers
    result2 = f.format_headers("Test headers")
    expected2 = "\x1b[1mTest headers\x1b[0m"
    assert result2 == expected2

    # Testing multiple lines of headers
    f = Formatting(groups=['colors', 'format'])
    result3 = f.format_headers("First-Headers\nSecond-Headers")
    expected3 = "\x1b[1m\x1b[34mFirst-Headers\x1b[0m\n\x1b[1mSecond-Headers\x1b[0m"

# Generated at 2022-06-21 14:18:00.476806
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['json']
    env = Environment()
    json_string = "{'name': 'Sara', 'age': '20', 'country': 'US'}"
    f = Formatting(groups,env)
    formatted_json_string = f.format_body(json_string, 'application/json')
    print(formatted_json_string)


# Generated at 2022-06-21 14:18:09.037602
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    output_formatter = Formatting(groups=['colors'], colors=256)
    output_formatter.format_body("""
        {"id": 42,
        "name": "abc",
        "something": 42}
        """, mime="application/json")
    assert output_formatter.format_body("""
        {"id": 42,
        "name": "abc",
        "something": 42}
        """, mime="application/json") == """
        {
          "id": 42,
          "name": "abc",
          "something": 42
        }
        """

# Generated at 2022-06-21 14:18:14.174083
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert(converter!=None)
    assert(type(converter)==plugin_manager.plugins['json'])

    converter = Conversion.get_converter(None)
    assert(converter == None)

    converter = Conversion.get_converter('text/html')
    assert(converter == None)



# Generated at 2022-06-21 14:18:19.070408
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test single line
    result = Formatting(['colors']).format_headers('Content-Type: application/json')
    assert result == '\x1b[37m\x1b[1mContent-Type:\x1b[0m application/json'

    # test multi lines
    result = Formatting(['colors']).format_headers('Content-Type: application/json\ncontent-length: 1024')
    assert result == '\x1b[37m\x1b[1mContent-Type:\x1b[0m application/json\n\x1b[37m\x1b[1mcontent-length:\x1b[0m 1024'


# Generated at 2022-06-21 14:18:29.658678
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'pretty': True}
    formatter = Formatting(groups, env, **kwargs)
    

# Generated at 2022-06-21 14:18:44.530582
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import io
    import sys
    import json
    import unittest
    import json
    import httpie.utils as utils

    class TestFormatting_format_body(unittest.TestCase):
        def test_format_body_pretty(self):
            _stdout = sys.stdout
            sys.stdout = io.StringIO()

            env = Environment(stdout=sys.stdout)

            groups = ['pretty']

            kwargs = {'colors': True, 'verbose': True, 'style': None, 'theme': 'solarized-light'}
            Formatting(groups, env, **kwargs).format_body('{ "test": true }', 'application/json')
            self.assertIsNotNone(sys.stdout.getvalue())
            sys.stdout = _stdout


# Generated at 2022-06-21 14:18:55.038816
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt = Formatting(groups = ['colors'])
    headers = fmt.format_headers("""HTTP/1.1 200 OK
Date: Mon, 27 Jul 2009 12:28:53 GMT
Server: Apache/2.2.14 (Win32)
Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT
Content-Length: 88
Content-Type: text/html
Connection: Closed""")

# Generated at 2022-06-21 14:19:05.347347
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatterPlugin

    class MockConverter(JSONFormatterPlugin):
        """
        This mock converter mocks the format_body method. It only prints the
        content and mime type.
        """
        def format_body(self, content: str, mime: str) -> str:
            return 'mime:{}, content:{}'.format(mime, content)

    content = '{"username": "1111", "password": "1111"}'
    mime = 'application/json'
    # Create a new environment, new_env. Set the "formatter" attribute to True.
    new_env = Environment()
    new_env.stdout_isatty = True
    new_env.formatter = True

    # Mock the class Formatting.

# Generated at 2022-06-21 14:19:09.617944
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    env = Environment()
    # Test the function with wrong mime type
    assert not Conversion.get_converter("abcd/efgh")
    # Test the function with right mime type
    assert isinstance(Conversion.get_converter("application/json"), Conversion.get_converter("application/json").__class__)

# Generated at 2022-06-21 14:19:12.827733
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    for group in available_plugins:
        for cls in available_plugins[group]:
            p = cls()
            if p.enabled:
                print(p.format_headers(headers=""))


# Generated at 2022-06-21 14:19:18.263806
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)
    assert not is_valid_mime('foobar')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('/xmldsig#')
    assert not is_valid_mime('/')
    # Too long
    assert not is_valid_mime('application/applicationapplicationapplicationapplicationapplicationapplication')



# Generated at 2022-06-21 14:19:20.886995
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None, "Converter is not found."


# Generated at 2022-06-21 14:19:27.108565
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Should return original content when mime type is not text/plain
    content = "hello"
    mime = 'image/png'
    result = Formatting(['colors']).format_body(content, mime)
    assert content == result

    # Should return colored content when mime type is text/plain
    mime = 'text/plain'
    result = Formatting(['colors']).format_body(content, mime)
    assert '\033[32m' in result

# Generated at 2022-06-21 14:19:34.875949
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter("application/json") == 'application/json' and type(Conversion.get_converter("application/json").__init__()) == dict
    assert Conversion.get_converter("text/html") == 'text/html' and type(Conversion.get_converter("text/html").__init__()) == dict
    assert Conversion.get_converter("application/xml") == 'application/xml' and type(Conversion.get_converter("application/xml").__init__()) == dict
    assert Conversion.get_converter("text/xml") == 'text/xml' and type(Conversion.get_converter("text/xml").__init__()) == dict

# Generated at 2022-06-21 14:19:37.111602
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting(['colors', 'format']).format_body('text', 'text/plain') == '\x1b[00;38;5;244mtext\x1b[0m'


# Generated at 2022-06-21 14:19:47.759143
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(groups=['colors'], env=Environment(), indent=2)
    assert fmt is not None
    assert fmt.enabled_plugins
    assert fmt.enabled_plugins[0].env
    assert fmt.enabled_plugins[0].indent == 2

# Generated at 2022-06-21 14:19:50.375417
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """Unit test for method format_headers of class Formatting"""
    fm = Formatting(groups=[], env=Environment(), )
    assert fm.format_headers("ABC") == "ABC"

# Generated at 2022-06-21 14:19:56.454245
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime(None)
    assert not is_valid_mime('')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('1 2 3')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/x-www-form-urlencoded')
    assert is_valid_mime('text/plain')

# Generated at 2022-06-21 14:19:57.967428
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/plain')
    assert not is_valid_mime('./plain')

# Generated at 2022-06-21 14:20:07.133585
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion()
    assert Conversion([])
    assert ConverterPlugin()
    assert plugin_manager
    assert Formatting()
    assert Formatting(None)
    assert Environmnet()
    assert ConverterPlugin('some string')
    assert plugin_manager.get_converters()
    assert plugin_manager.get_formatters()
    assert plugin_manager.get_formatters_grouped()
    assert plugin_manager.get_converters(group=None)
    assert plugin_manager.get_formatters(group=None)
    assert plugin_manager.get_formatters_grouped(group=None)
    assert is_valid_mime('some string')


# Generated at 2022-06-21 14:20:15.576001
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie import ExitStatus
    from httpie.context import Environment
    actual = Conversion.get_converter(mime='application/json')
    assert actual is not None
    assert isinstance(actual, ConverterPlugin)
    assert actual.mime == 'application/json'
    assert actual.env is None
    assert actual.extension == '.json'
    assert actual.priority is None
    assert actual.convert_arg('abc') is None
    assert actual.convert_file(file_path=None, data=None, mime=None) == ""
    assert actual.convert_data(data=None, mime=None) == ""
    env = Environment(stdout_isatty=True, stdin_isatty=False)
    actual = Conversion.get_converter(mime='text/plain')

# Generated at 2022-06-21 14:20:18.557135
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_converter = Conversion.get_converter('application/json')
    assert test_converter.supports('application/json')


# Generated at 2022-06-21 14:20:27.506817
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Unit test for method format_body of class Formatting
    
    # Case 1: When content is empty.
    # Expected Result: return content as it is.
    grps = ['colors']
    content = ''
    mime = 'application/json'
    formatter = Formatting(grps)
    result = formatter.format_body(content, mime)
    assert result == content, \
        'test_Formatting_format_body: Failure = Content is empty'
    
    # Case 2: When content is valid (JSON in our case)
    # Expected Result: return content as it is.
    content = '{"name":"John", "age":30, "car":null}'
    mime = 'application/json'
    formatter = Formatting(grps)
    result = formatter.format_body

# Generated at 2022-06-21 14:20:35.358776
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Case: Only solarize plugin is enabled.
    f = Formatting(["solarize"])
    given_headers = """
        HTTP/1.1 200 OK
        Content-Type: text/plain; charset=utf-8
        Server: Werkzeug/0.12.2 Python/3.5.2
        Date: Wed, 07 Mar 2018 22:43:17 GMT
        """

# Generated at 2022-06-21 14:20:46.661072
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    mime = "text/html"
    content = '''<html>
    <head>
    <title>Page</title>
    </head>
    <body>
    <h1>Page</h1>
    <p>Simple page.</p>
    </body>
    </html>'''

# Generated at 2022-06-21 14:21:10.681530
# Unit test for constructor of class Formatting
def test_Formatting():
    test_json = '{"userId": 1, "name": "User1", "email": "user1@mail.com"}'
    test_groups = ["json"]
    test_env = Environment()
    test_env.config.default_options['--pretty'] = 'all'
    test_env.config.default_options['--print'] = 'all'
    test_kwargs = {}
    formatter = Formatting(groups=test_groups, env=test_env, **test_kwargs)
    formatted_result = formatter.format_body(content=test_json, mime="application/json")
    assert formatted_result == '{\n    "name": "User1",\n    "email": "user1@mail.com",\n    "userId": 1\n}\n'


# Generated at 2022-06-21 14:21:19.467470
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.core import main
    from httpie import ExitStatus
    args = ['--debug-http']
    args.extend(['--print=format'])
    args.extend(['GET', 'http://httpbin.org/get'])
    exit_status, http_status, _headers, content, json_ = main(args)
    # exit_status is ExitStatus.OK
    assert exit_status == ExitStatus.OK
    # http_status is 200
    assert http_status == 200
    # content is not empty
    assert len(content) > 0
    # json_ is not empty
    assert json_ is not None and len(json_) > 0
    # OK

# Generated at 2022-06-21 14:21:27.428510
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-21 14:21:34.498235
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    env = Environment(
        isatty=False,
        stdin_isatty=False,
        stdout_isatty=False,
        stdout_bytes_written=0,
        output_options={},
        colors={},
        config={},
        stdin=None,
        stdin_text=None,
        stdout=None,
        output_file=None,
        stdout_is_redirected=True,
    )

    # Test for valid json body
    f = Formatting(
        ["JSON"],
        env=env,
        json_indent=None,
        json_sort_keys=False,
        pygments_style="monokai",
        pygments_lexer="json",
        max_json_depth=None,
    )

# Generated at 2022-06-21 14:21:38.194190
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/plain")
    assert is_valid_mime("application/json")
    assert is_valid_mime("application/javascript")
    assert is_valid_mime("font/woff2")
    assert is_valid_mime("application/vnd.ms-excel")

# Generated at 2022-06-21 14:21:46.445679
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = 'text/xml'
    assert str(Conversion.get_converter(mime)) == 'Xml2FormConverter (text/xml)'
    mime = 'application/xml'
    assert str(Conversion.get_converter(mime)) == 'Xml2FormConverter (application/xml)'
    mime = 'text/json'
    assert str(Conversion.get_converter(mime)) == 'Json2FormConverter (text/json)'
    mime = 'application/json'
    assert str(Conversion.get_converter(mime)) == 'Json2FormConverter (application/json)'
    mime = 'text/html'
    assert Conversion.get_converter(mime) == None
    mime = 'application/html'

# Generated at 2022-06-21 14:21:54.102196
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    a = Formatting(['colors'])
    assert (a.format_headers('HTTP/1.1 200 OK\nServer: httpie\nContent-Type: text/html\nContent-Length: 12\n\n') == 
            '\x1b[37mHTTP/1.1 200 OK\x1b[0m\n\x1b[36mServer: httpie\x1b[0m\n\x1b[33mContent-Type: text/html\x1b[0m\n\x1b[31mContent-Length: 12\x1b[0m\n\n')
    
    

# Generated at 2022-06-21 14:22:03.126121
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime(Conversion.get_converter('image/png'))
    assert is_valid_mime(Conversion.get_converter('text/csv'))
    assert is_valid_mime(Conversion.get_converter('audio/mpeg'))
    assert is_valid_mime(Conversion.get_converter('video/mp4'))

# Generated at 2022-06-21 14:22:06.267584
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter("application/json") == plugin_manager.get_converters()[0]
    assert Conversion.get_converter("image/jpeg") == plugin_manager.get_converters()[1]

# Generated at 2022-06-21 14:22:07.351598
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("text/html") == None

# Generated at 2022-06-21 14:22:53.323598
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors']) is not None, "Constructor of Formatting passed!"


# Generated at 2022-06-21 14:22:57.879794
# Unit test for constructor of class Conversion
def test_Conversion():
    plugin_manager.load_installed_plugins()
    headers = [{'Content-Type': 'text/xml'}]
    mimes = [a['Content-Type'] for a in headers]
    conversion = Conversion.get_converter(mimes[0])
    assert conversion is not None
    assert isinstance(conversion, ConverterPlugin)
    assert conversion.mime == 'text/xml'


# Generated at 2022-06-21 14:23:03.536647
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') is True
    assert is_valid_mime('application/json; charset=utf-8') is True
    assert is_valid_mime('application/') is False
    assert is_valid_mime('') is False
    assert is_valid_mime('application') is False



# Generated at 2022-06-21 14:23:10.245322
# Unit test for constructor of class Conversion
def test_Conversion():
    n1=Conversion.get_converter("image/jpg")
    n2=Conversion.get_converter("application/json")
    n3=Conversion.get_converter("application/pdf")
    n4=Conversion.get_converter("text/html")
    n5=Conversion.get_converter("text/plain")
    assert n1 == None
    assert n2 != None
    assert n3 == None
    assert n4 != None
    assert n5 == None



# Generated at 2022-06-21 14:23:11.868403
# Unit test for constructor of class Conversion
def test_Conversion():
    obj = Conversion("application/json")
    assert isinstance(obj, Conversion)


# Generated at 2022-06-21 14:23:16.177152
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format_class = Formatting(['colors', 'format'])
    test_headers = 'HTTP/1.1 200 OK\r\nContent-Length: 2\r\nContent-Type: text/plain;' \
        'charset=utf-8\r\n\r\nHello'
    print(format_class.format_headers(test_headers))


# Generated at 2022-06-21 14:23:23.885577
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = """HTTP/1.1 200 OK
    Cache-Control: private
    Content-Type: application/json; charset=utf-8
    Vary: Accept

    {"id":1,"name":"Leanne Graham","username":"Bret","email":"Sincere@april.biz","address":{"street":"Kulas Light","suite":"Apt. 556","city":"Gwenborough","zipcode":"92998-3874","geo":{"lat":"-37.3159","lng":"81.1496"}},"phone":"1-770-736-8031 x56442","website":"hildegard.org","company":{"name":"Romaguera-Crona","catchPhrase":"Multi-layered client-server neural-net","bs":"harness real-time e-markets"}}"""

# Generated at 2022-06-21 14:23:26.220793
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    res = Conversion.get_converter('text/html')
    assert res.from_mime == 'text/html'


# Generated at 2022-06-21 14:23:33.534057
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = "Content-Type: applcation/json\n" \
              "X-Auth-Token: token\n"
    sample_env = Environment()
    actual = Formatting(groups=['color'],
                        env=sample_env).format_headers(headers)
    expecting = "\033[1;37mContent-Type: applcation/json\033[0m\n" \
                "\033[1;36mX-Auth-Token: token\033[0m\n"
    assert actual == expecting
