

# Generated at 2022-06-21 14:13:33.773295
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=['colors'])
    assert f.format_headers('date: Mon, 01 Jan 2018 00:00:00 GMT\nhost: httpbin.org') == 'date: Mon, 01 Jan 2018 00:00:00 GMT\nhost: httpbin.org'
    f.format_body('{ "name": "dummy", "type": "json" }', mime='application/json')


# Generated at 2022-06-21 14:13:44.765206
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    s = (
        'HTTP/1.1 200 OK\r\n'
        'Date: Sun, 04 Aug 2013 10:49:50 GMT\r\n'
        'Server: Apache\r\n'
        'Last-Modified: Sun, 04 Aug 2013 03:11:32 GMT\r\n'
        'ETag: "2100bc-1ef-4e66a7c571200"\r\n'
        'Accept-Ranges: bytes\r\n'
        'Content-Length: 497\r\n'
        'Connection: close\r\n'
        'Content-Type: text/html\r\n'
        '\r\n'
        '<html>...</html>'
    )


# Generated at 2022-06-21 14:13:50.798921
# Unit test for constructor of class Conversion
def test_Conversion():
    try:
        c = Conversion.get_converter('text/html')
        if not (c.supported_mime() == 'text/html'):
            raise Exception('Conversion unit test failed. Supported MIME is different from expected')
    except:
        print('Conversion unit test failed. Converter instance was not created')
        raise Exception('Conversion unit test failed. Converter instance was not created')



# Generated at 2022-06-21 14:13:55.359865
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # instantiation
    groups = ['colors', 'formatters']
    env = Environment(colors=256, format='pretty')
    formatter = Formatting(groups, env)

    # actual testing
    assert formatter.format_headers('accept:text/html') == 'accept:text/html'


# Generated at 2022-06-21 14:13:59.777954
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
	"""Test the validity of function get_converter in class Conversion

	Parameters
	----------
	mime: str
	    the mime type of input data, e.g. 'text/plain' represents plain text.
		
	Returns
	-------
	test_result: bool
		test_result==True represents success, test_result==False represents failure
	"""
	test_result = True
	if not Conversion.get_converter('text/plain'):
		test_result = False
	return test_result


# Generated at 2022-06-21 14:14:03.241695
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter.supported_mime_type == "application/json", "Converter MIME type is not supported."

# Generated at 2022-06-21 14:14:06.955915
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    fp = Formatting(["colors"])
    fp_body = fp.format_body(
        "{\n  \"name\": \"test\"\n}",
        "application/json"
    )
    print("\nbody:\n{}".format(fp_body))

# Generated at 2022-06-21 14:14:13.914093
# Unit test for constructor of class Formatting
def test_Formatting():
    import sys
    import os
    sys.path.append(os.getcwd())

    groups = ['colors']
    env = Environment()
    env.colors = False

    assert Formatting(groups, env).enabled_plugins == []

    env.colors = True

    assert len(Formatting(groups, env).enabled_plugins) == 1
    assert Formatting(groups, env).enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-21 14:14:25.262645
# Unit test for constructor of class Conversion
def test_Conversion():
    """ Unit test for method `get_converter` in class `Conversion`."""
    # Generate a fake ConverterPlugin class inherited from httpie.plugins.ConverterPlugin
    class FakeConverter(ConverterPlugin):
        name = "fake"
        description = "fake"

        @classmethod
        def supports(cls, mime):
            return True

        def load(self, content: str) -> bytes:
            return bytes(content, 'utf-8')

    # Generate a fake plugin manager
    class PluginManager():
        @staticmethod
        def get_converters():
            # Generate a list of fake converter plugin
            return [FakeConverter]

    plugin_manager.PluginManager = PluginManager
    conversion = Conversion()

    # If mime is valid

# Generated at 2022-06-21 14:14:35.582402
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('image/jpeg')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)
    assert not is_valid_mime('application/json ')
    assert not is_valid_mime('application html')
    assert not is_valid_mime('/')
    assert not is_valid_mime(' application/xml')
    assert not is_valid_mime('application/xml ')
    assert not is_valid_mime('json')
    assert not is_valid_mime('application/xml/')
    assert not is_valid_mime('text/')

# Generated at 2022-06-21 14:14:39.968409
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """
    Unit test for method get_converter of class Conversion
    :return:
    """
    assert callable(Conversion.get_converter)

# Generated at 2022-06-21 14:14:43.245960
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    import json
    from httpie.plugins.json import JSONStreamConverter
    assert Conversion.get_converter("application/json").__class__ == JSONStreamConverter


# Generated at 2022-06-21 14:14:44.282874
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pass


# Generated at 2022-06-21 14:14:48.463125
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.context import Environment
    from httpie.plugins.formatters.colors import ColorsFormatter
    env = Environment(colors=False, stdout_isatty=False)
    formatting = Formatting(['colors'], env=env)
    assert formatting.enabled_plugins[0].__class__ == ColorsFormatter

# Generated at 2022-06-21 14:14:56.050998
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatter = Formatting(['colors','header'])
    content = formatter.format_headers('HTTP/1.1 200 OK\r\nContent-Type: text/plain')
    expected_content = '\x1b[1mHTTP/1.1\x1b[22m \x1b[92m200\x1b[39m \x1b[1mOK\x1b[22m\nContent-Type: text/plain'
    assert content == expected_content

# Generated at 2022-06-21 14:15:05.660385
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.input import ParseError
    from httpie.plugins.builtin import PrettyOptionsPlugin
    # Test case 1
    headers_tc1 = '''\
HTTP/1.1 200 OK
Date: Fri, 26 Jun 2020 16:42:58 GMT
Content-Type: application/json
Transfer-Encoding: chunked
Connection: keep-alive
Vary: Accept
Allow: GET, HEAD, OPTIONS
X-Pagination-Count: 0
X-RateLimit-Limit: 12000
X-RateLimit-Remaining: 11996
X-RateLimit-Reset: 1593217080

'''
    env_tc1 = Environment(colors=256)
    args_tc1 = PrettyOptionsPlugin(env_tc1).get_parser().parse_args([])

# Generated at 2022-06-21 14:15:12.448786
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    class FakePlugin_0:
        enabled = True
        def __init__(self, env=Environment(), **kwargs):
            self.env = env
        def format_body(self, content: str, mime: str) -> str:
            return content + '- FakePlugin_0'

    class FakePlugin_1:
        enabled = True
        def __init__(self, env=Environment(), **kwargs):
            self.env = env
        def format_body(self, content: str, mime: str) -> str:
            return content + '- FakePlugin_1'

    available_plugins = {
        'group_0': [FakePlugin_0],
        'group_1': [FakePlugin_1],
    }


# Generated at 2022-06-21 14:15:17.572581
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    def no_converter():
        assert Conversion.get_converter("text/plain").mime == "text/plain"
    no_converter()

    def with_converter():
        assert Conversion.get_converter("application/json").mime == "application/json"
    with_converter()

# Generated at 2022-06-21 14:15:23.780432
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Create an instance of class Formatting
    fmt = Formatting('colors')
    # Create a test header with a header name and a header value
    header = 'Content-Type: application/json'
    # Test for format_headers method of class Formatting.
    # Test whether the method adds the color to the header name
    assert fmt.format_headers(header) == '\x1b[38;5;33mContent-Type\x1b[0m: application/json'

# Generated at 2022-06-21 14:15:30.171121
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/problem+json')
    assert not is_valid_mime('application/json ')
    assert not is_valid_mime('application/json ')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('/json')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application json')
    assert not is_valid_mime('application/json/')

# Generated at 2022-06-21 14:15:34.825936
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    try:
        assert Formatting(("pretty",)).format_body("<p>It works</p>", "text/html") == "<p>It works</p>"
    except Exception as e:
        print("Exception: {0}".format(e))

# Generated at 2022-06-21 14:15:38.292901
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    text = 'hi'
    mime = 'text/plain'
    formatting = Formatting(['colors', 'format'], [], False)
    assert formatting.format_body(text, mime) == '\033[96mhi\033[0m'


# Generated at 2022-06-21 14:15:40.791014
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter(mime="text/html")
    assert(isinstance(converter, ConverterPlugin))


# Generated at 2022-06-21 14:15:47.770296
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    fmts = Formatting(groups=['matrix', 'table'], env=env)
    output = fmts.format_body(
        'a,b,c\nd,e,f\ng,h,i\n', 'text/csv')
    expected_output = 'a\tb\tc\nd\te\tf\ng\th\ti\n'
    print(output)
    print(expected_output)
    assert output == expected_output


# Generated at 2022-06-21 14:15:50.641843
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('image/png')
    assert is_valid_mime('text/plain')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application')

# Generated at 2022-06-21 14:15:51.911056
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion()

# Testing for get_converter() of class Conversion

# Generated at 2022-06-21 14:15:53.850645
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    fmt = Formatting(groups=['colors'], env=env, colors='16')
    assert fmt.enabled_plugins

# Generated at 2022-06-21 14:15:59.473890
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting = Formatting(groups=['colors'])
    content = formatting.format_body(content='{\n  "a": 1\n}', mime='application/json')
    print(content)
    assert content == '\x1b[1;39m{\x1b[39;22m\n  \x1b[1;32m"a"\x1b[32;22m\x1b[1;39m:\x1b[39;22m \x1b[1;31m1\x1b[31;22m\n\x1b[1;39m}\x1b[39;22m\n'
    content = formatting.format_body(content='<a href="#">test</a>', mime='text/html')
    print(content)

# Generated at 2022-06-21 14:16:11.389925
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter('application/json')
    assert converter.__class__.__name__ == 'JsonConverter'
    converter = Conversion.get_converter('application/xml')
    assert converter.__class__.__name__ == 'Xml2JsonConverter'
    converter = Conversion.get_converter('text/xml')
    assert converter.__class__.__name__ == 'Xml2JsonConverter'
    converter = Conversion.get_converter('application/xhtml+xml')
    assert converter.__class__.__name__ == 'Xml2JsonConverter'
    converter = Conversion.get_converter('image/svg+xml')
    assert converter.__class__.__name__ == 'Xml2JsonConverter'
   

# Generated at 2022-06-21 14:16:16.386193
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    obj = Formatting("pretty")
    headers = '''\
HTTP/1.1 200 OK
Server: nginx/1.10.3 (Ubuntu)
Date: Thu, 25 May 2017 17:09:27 GMT
Content-Type: application/json
Content-Length: 2
Connection: keep-alive'''
    expected = headers + "\n\n"
    result = obj.format_headers(headers)
    assert result == expected



# Generated at 2022-06-21 14:16:20.754959
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(groups=['colors'])
    assert fmt.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'


# Generated at 2022-06-21 14:16:30.493100
# Unit test for method format_body of class Formatting

# Generated at 2022-06-21 14:16:32.601096
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert(is_valid_mime('application/json'))
    assert(not is_valid_mime('applicationjson'))



# Generated at 2022-06-21 14:16:35.847031
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(groups=["highlighting"],
                     colors=None,
                     style="native",
                     theme=None)
    assert fmt.enabled_plugins[0].name == "highlighting"



# Generated at 2022-06-21 14:16:45.620910
# Unit test for constructor of class Formatting
def test_Formatting():
    with open("test/test_formatting_response.txt", "r", encoding='utf-8') as f:
        expected_out = f.read()
    with open("test/test_formatting_response_with_converter.txt", "r", encoding='utf-8') as f:
        expected_out_with_converter = f.read()
    f = Formatting(groups=['colors', 'format'], env=Environment(), output_stream="")
    out = f.format_body("{\"userId\":1,\"id\":1,\"title\":\"test\",\"completed\":false}", "application/json")
    assert out == expected_out
    with open("test/test_formatting_request.txt", "r", encoding='utf-8') as f:
        expected_out = f.read()

# Generated at 2022-06-21 14:16:52.364226
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
        content = '{ "data": { "date": "20190705", "time": "163052", ' \
                  '"type": "TESTTESTTEST", ' \
                  '"source": "TESTTESTTEST", ' \
                  '"status": "TESTTESTTEST", ' \
                  '"function": "TESTTESTTEST", ' \
                  '"comments": "TESTTESTTEST" ' \
                  '} }'

        mime = 'application/json'
        groups = ['colorize', 'format']
        format_body = Formatting(groups).format_body(content, mime)
        print(format_body)

if __name__ == '__main__':
    test_Formatting_format_body()

# Generated at 2022-06-21 14:16:56.653811
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion.get_converter("application/json")
    assert c is not None
    a = c("{\"a\":2}")
    assert a == {"a":2}
    p = c("{\"a\":1,\"b\":2,\"c\":3}")
    assert p == {"a":1,"b":2,"c":3}

# Generated at 2022-06-21 14:17:02.744990
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # using default values
    formatter = Formatting(groups=['colors'])
    headers_str = "HTTP/1.1 200 OK\r\n" \
                  "Date: Thu, 23 Jul 2020 10:22:26 GMT\r\n" \
                  "Server: Apache/2.4.41 (Ubuntu)\r\n" \
                  "Last-Modified: Sat, 20 Jun 2020 04:57:33 GMT\r\n" \
                  "Accept-Ranges: bytes\r\n" \
                  "Content-Length: 12689\r\n" \
                  "Keep-Alive: timeout=5, max=100\r\n" \
                  "Connection: Keep-Alive\r\n" \
                  "Content-Type: text/html\r\n\r\n"
    expected_headers_

# Generated at 2022-06-21 14:17:11.614848
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting([]).format_headers('{"key": "value", "key2":"value2"}') == '{\n    "key": "value",\n    "key2": "value2"\n}'
    assert Formatting(['colors']).format_headers('{"key": "value", "key2":"value2"}') =='{\n    \x1b[94m"key"\x1b[39;49;00m: \x1b[33m"value"\x1b[39;49;00m,\n    \x1b[94m"key2"\x1b[39;49;00m: \x1b[33m"value2"\x1b[39;49;00m\n}'



# Generated at 2022-06-21 14:17:15.383211
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['json']
    env = Environment()
    kwargs = {'indent': 2}
    fmt = Formatting(groups, env, **kwargs)
    assert fmt.enabled_plugins
    assert fmt.enabled_plugins[0].indent == 2


# Generated at 2022-06-21 14:17:20.563908
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    result = Formatting(groups=["syntax"]).format_body(
        content="""{"a": 1, "b": 2}""", mime="application/json"
    )

    assert result == """"a": 1,
"b": 2"""

# Generated at 2022-06-21 14:17:30.430681
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'Content-Type: text/plain; charset=utf-8\nContent-Length: 4\n'
    formatter = Formatting(groups=['colors'])
    assert formatter.format_headers(headers) == '\x1b[34mContent-Type\x1b[0m: ' \
                                                '\x1b[0mtext/plain; charset=utf-8\x1b[0m\n' \
                                                '\x1b[34mContent-Length\x1b[0m: \x1b[0m4\x1b[0m\n'



# Generated at 2022-06-21 14:17:35.418477
# Unit test for function is_valid_mime
def test_is_valid_mime():
    import pytest
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/xml')
    assert is_valid_mime('application/yaml')
    assert not is_valid_mime('')
    assert not is_valid_mime('foo')
    assert not is_valid_mime('foo/bar/baz')
    with pytest.raises(TypeError):
        is_valid_mime(None)

# Generated at 2022-06-21 14:17:44.232731
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    ConverterPlugin.supports = lambda _, mime: mime == 'application/json'
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    ConverterPlugin.supports = lambda _, mime: mime == 'text/xml'
    converter = Conversion.get_converter('text/xml')
    assert converter is not None
    ConverterPlugin.supports = lambda _, mime: mime == 'text/xml'
    converter = Conversion.get_converter('application/json')
    assert converter is None
    ConverterPlugin.supports = lambda _, mime: mime == 'application/json'
    converter = Conversion.get_converter('text/xml')
    assert converter is None


# Generated at 2022-06-21 14:17:50.327630
# Unit test for constructor of class Conversion
def test_Conversion():
    assert(isinstance(Conversion().get_converter(""), None))
    assert(isinstance(Conversion().get_converter("plain"), None))
    assert(isinstance(Conversion().get_converter("text/plain"), None))
    assert(isinstance(Conversion().get_converter("application/json"), None))
    assert(isinstance(Conversion().get_converter("application/xml"), None))


# Generated at 2022-06-21 14:17:58.470022
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(env=Environment(), groups=["headers"])
    assert (f.format_headers("HTTP/1.1 200 OK") ==
            "\033[37mHTTP/1.1 \033[32m200 \033[39mOK")
    assert (f.format_headers("HTTP/1.1 500 Internal Server Error") ==
            "\033[37mHTTP/1.1 \033[31m500 \033[39mInternal Server Error")
    f = Formatting(env=Environment(), groups=[])
    assert (f.format_headers("HTTP/1.1 200 OK") ==
            "HTTP/1.1 200 OK")
    assert (f.format_headers("HTTP/1.1 500 Internal Server Error") ==
            "HTTP/1.1 500 Internal Server Error")



# Generated at 2022-06-21 14:18:02.817099
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime('application/')
    assert not is_valid_mime('application:')
    assert not is_valid_mime('application')
    assert not is_valid_mime('')

    assert is_valid_mime('application/xml')
    assert is_valid_mime('application/xml-dtd')

# Generated at 2022-06-21 14:18:09.041438
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    c = Formatting(['colors', 'formatting'])
    result = c.format_headers('Content-Type: application/json\nAuthor: Wang')
    expectResult = '\x1b[94mContent-Type\x1b[0m: application/json\n\x1b[93mAuthor\x1b[0m: Wang'
    assert result == expectResult


# Generated at 2022-06-21 14:18:17.448908
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    json = '{ "key": "value" }'
    # Unit test with a valid JSON input
    result = Formatting(['colors']).format_body(json, 'application/json')
    assert(result == '\x1b[94m{\x1b[0m \x1b[94m"key"\x1b[0m: \x1b[94m"value"\x1b[0m \x1b[94m}\x1b[0m')
    # Unit test with an invalid JSON input
    result = Formatting(['colors']).format_body('json_text', 'application/json')
    assert(result == 'json_text')
    # Unit test with an invalid Mime input
    result = Formatting(['colors']).format_body(json, None)

# Generated at 2022-06-21 14:18:19.942737
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin import JSONConverter
    assert isinstance(Conversion.get_converter('application/json'), JSONConverter)

# Generated at 2022-06-21 14:18:24.494900
# Unit test for constructor of class Formatting
def test_Formatting():
    t = Formatting(['colors'])

# Generated at 2022-06-21 14:18:28.857169
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime('text/html') == True
    assert is_valid_mime('text/plain') == True
    assert is_valid_mime('text/weird') == True
    assert is_valid_mime('text') == False
    assert is_valid_mime('txt') == False


# Generated at 2022-06-21 14:18:34.933872
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("image/jpeg") is True
    assert is_valid_mime("image/") is False
    assert is_valid_mime("/jpeg") is False
    assert is_valid_mime("") is False
    assert is_valid_mime(None) is False


# Generated at 2022-06-21 14:18:41.493479
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('text/html; charset=utf-8')
    assert not is_valid_mime('invalid mime')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)
    assert not is_valid_mime('text/')
    assert not is_valid_mime(' /html')
    assert not is_valid_mime('text/html/')

# Generated at 2022-06-21 14:18:50.708923
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    '''The unit test for method format_headers of class Formatting'''
    tmp = Formatting(['colors'])
    assert tmp.format_headers("") == ""
    assert tmp.format_headers("a=b") == "a=b"
    assert tmp.format_headers("a: b") == "a: b"
    assert tmp.format_headers("a: b, c: d") == "a: b, c: d"
    assert tmp.format_headers("a: b, c: d, e: f") == "a: b, c: d, e: f"

# Generated at 2022-06-21 14:18:54.726461
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter

    p = JSONFormatter()
    data = '{"a": 2}'
    mime = 'application/json'
    env = Environment()
    f = Formatting([], env=env)
    formatted = f.format_body(data, mime)
    assert data == formatted

# Generated at 2022-06-21 14:19:04.961147
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter("application/json") == None
    assert Conversion.get_converter("text/html") == None
    assert Conversion.get_converter("text/xml") == None
    assert Conversion.get_converter("text/javascript") == None
    assert Conversion.get_converter("application/x-www-form-urlencoded") == None
    assert Conversion.get_converter("image/gif") == None
    assert Conversion.get_converter("image/jpeg") == None
    assert Conversion.get_converter("image/png") == None
    assert Conversion.get_converter("image/svg+xml") == None
    assert Conversion.get_converter("image/x-icon") == None

# Generated at 2022-06-21 14:19:13.692496
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conf = plugin_manager.get_config_dict()
    plugin_manager.load_plugins(conf)
    env = Environment(stdout=io.BytesIO(), stdin=io.BytesIO())

    mime_type = 'application/json'
    converter = Conversion.get_converter(mime_type)
    assert converter
    if converter:
        print(converter.render_response_body('{"key": "value"}', env))

    mime_type = 'application/xml'
    converter = Conversion.get_converter(mime_type)
    assert converter
    if converter:
        print(converter.render_response_body('<xml><key>value</key></xml>', env))

    mime_type = 'text/geo+polyline'
    converter = Conversion.get_con

# Generated at 2022-06-21 14:19:17.708595
# Unit test for constructor of class Formatting
def test_Formatting():
    """Check for the different formats in the plugins"""
    f = Formatting(["format", "colors"])

    # pylint: disable=unused-variable
    for p in f.enabled_plugins:
        assert p.get_format_options()
        assert p.get_style_options()
        assert p.enabled



# Generated at 2022-06-21 14:19:23.016506
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    kwargs = {}
    groups = ["JSON"]
    formatting = Formatting(groups, env, **kwargs)
    content = '{"key1": "value1", "key2": "value2"}'
    mime = "application/json"
    assert formatting.format_body(content, mime) == content


# Generated at 2022-06-21 14:19:34.630583
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/plain')
    assert is_valid_mime('application/json')
    assert is_valid_mime('image/svg')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)
    assert not is_valid_mime('text/plai')
    assert not is_valid_mime('plain')
    assert not is_valid_mime('/plain')

# Generated at 2022-06-21 14:19:39.723333
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter("application/json")
    assert c.mime == "application/json"
    assert c.supports("application/json")
    assert not c.supports("text/plain")
    assert not c.supports("plain/text")
    assert not c.supports("plain")
    assert not c.supports("")



# Generated at 2022-06-21 14:19:42.604644
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    for group in available_plugins:
        for cls in available_plugins[group]:
            Formatting(group)

# Generated at 2022-06-21 14:19:49.985646
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert(is_valid_mime('text/plain') == True)
    assert(is_valid_mime('text/') == False)
    assert(is_valid_mime('/plain') == False)
    assert(is_valid_mime('/') == False)
    assert(is_valid_mime('') == False)
    assert(is_valid_mime('text/plain/json') == False)
    assert(is_valid_mime('text/plain?key=value') == False)


if __name__ == '__main__':
    test_is_valid_mime()

# Generated at 2022-06-21 14:19:51.975441
# Unit test for constructor of class Formatting
def test_Formatting():
    formatting_obj = Formatting(['colors', 'formatters'], env=Environment())
    assert formatting_obj != None


# Generated at 2022-06-21 14:19:57.147381
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json") is True
    assert is_valid_mime("application/xml") is True
    assert is_valid_mime("text/html") is True
    assert is_valid_mime("") is False
    assert is_valid_mime("application/") is False
    assert is_valid_mime("application/json/") is False

# Generated at 2022-06-21 14:19:57.696500
# Unit test for constructor of class Formatting
def test_Formatting():
    pass

# Generated at 2022-06-21 14:20:05.862876
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(["json"])
    if(f.format_body("{\"referee\":\"mousa\",\"scores\":[{\"player\":\"ahmed\",\"score\":0},{\"player\":\"mousa\",\"score\":2}]}", "json") == "{\"referee\": \"mousa\",\"scores\": [{\"player\": \"ahmed\"},{\"player\": \"mousa\",\"score\": 2}]}"):
        print("Test format_body PASSED")
    else:
        print("Test format_body FAILED")



# Generated at 2022-06-21 14:20:10.016306
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    Formatting_test = Formatting(groups=['beautifier'])
    mime = 'application/json'
    content = '{"test": "this is a test"}'
    content_formatted = Formatting_test.format_body(content=content, mime=mime)
    assert content_formatted == '{\n    "test": "this is a test"\n}\n'

# Generated at 2022-06-21 14:20:17.240943
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import JSON
    from httpie.plugins.builtin import Form
    from httpie.plugins.builtin import Pretty
    from httpie.plugins.builtin import Colors
    from httpie.plugins.builtin import Headers
    f = Formatting(['format'], env=Environment(colors=True, pretty=True, headers=True))
    assert any(isinstance(p, JSON) for p in f.enabled_plugins)
    assert any(isinstance(p, Form) for p in f.enabled_plugins)
    assert any(isinstance(p, Pretty) for p in f.enabled_plugins)
    assert any(isinstance(p, Colors) for p in f.enabled_plugins)
    assert any(isinstance(p, Headers) for p in f.enabled_plugins)

# Unit test

# Generated at 2022-06-21 14:20:32.137020
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    x = Formatting([])
    assert x.format_body("{hello:world}", 'application/json') == "{hello:world}"

# Generated at 2022-06-21 14:20:33.001919
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'colors_256']
    Formatting(groups)

# Generated at 2022-06-21 14:20:36.243344
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers_json = {'Content-Type': 'application/json'
                    , 'Access-Control-Allow-Origin': '*'}
    headers_str = str(headers_json)
    f = Formatting(['headers'])
    headers_new_str = f.format_headers(headers_str)
    assert(headers_new_str == headers_str)


# Generated at 2022-06-21 14:20:42.187065
# Unit test for constructor of class Formatting
def test_Formatting():
    fm = Formatting(groups=['colors'])
    assert len(fm.enabled_plugins) == 2
    assert isinstance(fm.enabled_plugins[0], plugin_manager.get_formatters_grouped()['colors'][0])
    assert isinstance(fm.enabled_plugins[1], plugin_manager.get_formatters_grouped()['colors'][1])

# Generated at 2022-06-21 14:20:52.662314
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case of headers with no indentation
    headers = (
        'HTTP/1.1 200 OK\n'
        'Content-Type: application/json\n'
        'Server: nginx\n'
        'Vary: Origin\n'
        'X-Execution-Time: 0.050\n'
        'Content-Length: 7073\n'
        'Connection: keep-alive\n'
        '\n'
    )
    assert Formatting(groups=[], env=Environment(), **{}).format_headers(headers) == headers

    # Test case of headers with indentation

# Generated at 2022-06-21 14:21:04.282840
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    environment1 = Environment()
    groups1 = ["colors"]
    kwargs1 = {}
    test1 = Formatting(groups1, environment1, **kwargs1)
    assert("\x1b[90mHTTP/1.1 200 OK\x1b[0m" == test1.format_headers("HTTP/1.1 200 OK"))
    assert("\x1b[90mHTTP/1.1 200 O" == test1.format_headers("HTTP/1.1 200 O"))
    assert("HTTP/1.1 200 OK" == test1.format_headers("HTTP/1.1 200 OK", "colors"))

# Generated at 2022-06-21 14:21:06.379533
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_obj = Conversion.get_converter("application/json")
    assert converter_obj.mime == "application/json"

# Generated at 2022-06-21 14:21:10.776717
# Unit test for function is_valid_mime
def test_is_valid_mime():
    """
    type: unit test
    """
    assert is_valid_mime('text/plain')
    assert is_valid_mime('application/json')
    assert not is_valid_mime(None)
    assert not is_valid_mime('')
    assert not is_valid_mime('text/plain/plain')
    assert not is_valid_mime('text')

# Generated at 2022-06-21 14:21:16.678751
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    assert is_valid_mime("text/html")
    assert not is_valid_mime("invalid")
    assert not is_valid_mime("invalid/path")
    assert not is_valid_mime("/invalid")
    assert not is_valid_mime("/")
    assert not is_valid_mime("")
    assert not is_valid_mime(None)

# Generated at 2022-06-21 14:21:20.097086
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    x = f.format_body('hello world', 'text/plain')
    assert x == '\x1b[32mhello world\x1b[39m'

# Generated at 2022-06-21 14:21:51.960272
# Unit test for constructor of class Formatting
def test_Formatting():
    # given
    env = Environment()
    # when
    f = Formatting(['colors'], env)
    #then
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    assert len(f.enabled_plugins) == 1

# Generated at 2022-06-21 14:21:55.020522
# Unit test for function is_valid_mime
def test_is_valid_mime():
    cases = [
        ("text/plain", True),
        ("ABCD/1234", True),
        ("ABCD", False),
    ]
    for c in cases:
        assert is_valid_mime(c[0]) is c[1]

# Generated at 2022-06-21 14:21:59.089416
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPieJSONFormatter
    fmt = Formatting(['JSON'], env=None)
    fmt.enabled_plugins = [HTTPieJSONFormatter()]
    assert fmt.format_body('{"a":"b"}', 'application/json') == '{\n    "a": "b"\n}'

# Generated at 2022-06-21 14:22:08.345331
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    groups = ["IEEE"]
    formatting = Formatting(groups=groups, env=env)
    headers = "POST /api/v1/face/identify/ HTTP/1.1\r\nHost: api.eyekey.com\r\nAccept: */*\r\nContent-Type: multipart/form-data; boundary=--------------------------483039506836786122996604\r\nUser-Agent: HTTPie/0.9.9\r\nContent-Length: 5591\r\n\r\n"
    formatted_headers = formatting.format_headers(headers)

# Generated at 2022-06-21 14:22:14.360459
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    '''
    Test the method format_body of class Formatting.
    '''
    import os
    import stat
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment

    env = Environment()

    testname = "test_Formatting_format_body"
    file_name = "./" + testname + ".json"
    file_obj = open(file_name, 'w')
    file_obj.write("{\"a\":\"b\"}")
    file_obj.close()


# Generated at 2022-06-21 14:22:15.744723
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()
    assert(c != None)

# Generated at 2022-06-21 14:22:16.913398
# Unit test for constructor of class Conversion
def test_Conversion():
    res = Conversion.get_converter('application/json')
    assert res

# Generated at 2022-06-21 14:22:26.223797
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers_raw = """HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 30
Date: Tue, 30 Jun 2020 15:55:28 GMT
Connection: keep-alive
Server: nginx

""".strip()

    groups = [
        'colors',
        'formatting',
        'syntax',
    ]

    formatting = Formatting(groups, env=None)
    headers_formatted = formatting.format_headers(headers_raw)
    assert headers_formatted.strip() == """
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 30
Date: Tue, 30 Jun 2020 15:55:28 GMT
Connection: keep-alive
Server: nginx

""".strip()

# Generated at 2022-06-21 14:22:35.590694
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class JSONPrettyPrintPlugin:
        supported_encodings = ('utf-8',)

        def __init__(self, body, mime, pretty_all=False, indent=2):
            self.body = body
            self.mime = mime
            self.pretty_all = pretty_all
            self.indent = indent

        def enabled(self):
            if self.pretty_all:
                return True
            return self.mime == 'application/json'

        def format_body(self, body, mime):
            if not self.enabled():
                return body
            try:
                return json.dumps(json.loads(body), indent=self.indent)
            except ValueError:
                return body

    class XMLPrettyPrintPlugin:
        supported_encodings = ('utf-8',)


# Generated at 2022-06-21 14:22:39.875633
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html').to_html == True
    assert Conversion.get_converter('application/json').to_json == True
    assert Conversion.get_converter('application/xml').to_xml == True

# Generated at 2022-06-21 14:23:14.102030
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'])
    assert f.enabled_plugins[0].style.enabled_styles == ['color']

# Generated at 2022-06-21 14:23:18.597049
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins import ConverterPlugin
    from httpie.plugins.registry import plugin_manager
    # print(plugin_manager.get_converters())
    for converter_class in plugin_manager.get_converters():
        print(converter_class.mime)
        print(converter_class.supports("application/json"))
        print("")


# Generated at 2022-06-21 14:23:25.413747
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """Formatting: format  headers"""
    fmt = Formatting(groups=['red'], env=Environment(), pretty=True)
    assert fmt.format_headers(headers="a: b") == "a: b"
    fmt = Formatting(groups=['red'], env=Environment(), pretty=True)
    assert fmt.format_headers(headers="") == ""
    fmt = Formatting(groups=['red'], env=Environment(), pretty=True)
    assert fmt.format_headers(headers="a: b\nc: d") == "a: b\nc: d"
    fmt = Formatting(groups=['red'], env=Environment(), pretty=True)
    assert fmt.format_headers(headers=None) is None
    fmt = Formatting(groups=[], env=Environment(), pretty=True)