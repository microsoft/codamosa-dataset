

# Generated at 2022-06-23 19:30:01.689061
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    in_str = 'HTTP/1.1 200 OK\nContent-Type: application/json; charset=utf-8\n' \
             'Content-Length: 20\nConnection: keep-alive\n'
    out_str = 'HTTP/1.1 200 OK\nContent-Type: application/json; charset=utf-8\n' \
             'Content-Length: 20\nConnection: keep-alive\n'
    formatting = Formatting(groups=['headers'])
    assert formatting.format_headers(in_str) == out_str



# Generated at 2022-06-23 19:30:08.222400
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie import __version__
    from httpie.plugins.builtin import JSONConverter
    from httpie.plugins.builtin import BytesJSONConverter
    from httpie.plugins.builtin import HTMLConverter

    expected = JSONConverter
    actual = Conversion.get_converter("application/json")
    assert type(actual) == expected

    expected = BytesJSONConverter
    actual = Conversion.get_converter("application/x-ndjson")
    assert type(actual) == expected

    expected = HTMLConverter
    actual = Conversion.get_converter("text/html")
    assert type(actual) == expected

    actual = Conversion.get_converter("text/x-html")
    assert actual is None

# Generated at 2022-06-23 19:30:19.069170
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # arrange
    input_str = """\
HTTP/1.1 200 OK
Server: nginx/1.10.1
Date: Fri, 17 Aug 2018 13:26:30 GMT
Content-Type: image/jpeg
Content-Length: 10546
Connection: keep-alive

"""
    groups = ['colors']
    env = Environment()
    formatting = Formatting(groups=groups, env=env)
    # act
    output_str: str = formatting.format_headers(input_str)
    # assert

# Generated at 2022-06-23 19:30:29.810922
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt = Formatting(groups=["ANSIColors"], env=Environment(), style="monokai")

# Generated at 2022-06-23 19:30:38.389942
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_data = (
        ({"groups": ["colors", "format", "colors", "format"], "mime": "application/json", "content": "test"}, "test", True),
        ({"groups": ["colors", "format", "colors", "json"], "mime": "application/json", "content": ""}, "test", False)
    )
    for kwargs, result, success in test_data:
        ab = Formatting(**kwargs)
        c = ab.format_body(kwargs["content"], kwargs["mime"])
        # On error print arguments and results
        if c != result:
            print("result  :", c)
            print("expected:", result)
            print("arguments:", kwargs)
        # Check results
        assert c == result

# Generated at 2022-06-23 19:30:45.603741
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    env = Environment()
    formatting = Formatting(groups = ["colors"], env = env)
    for group in formatting.enabled_plugins:
        for cls in available_plugins[group]:
            p = cls(env=env)
            if p.enabled:
                fmt = p.highlight_headers(formatting.format_headers(""))
                assert fmt.jmespath("headers.0.name") != "" and fmt.jmespath("headers.0.value") != ""

# Generated at 2022-06-23 19:30:47.299376
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.builtin import JSONConverter
    assert Conversion.get_converter('application/json').__class__ == JSONConverter

# Generated at 2022-06-23 19:30:53.061624
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/plain')
    assert is_valid_mime('application/json')
    assert is_valid_mime('image/png')

    assert not is_valid_mime('text')
    assert not is_valid_mime('plain')
    assert not is_valid_mime('text/plain/extra')
    assert not is_valid_mime(None)
    assert not is_valid_mime('')

# Generated at 2022-06-23 19:30:55.256984
# Unit test for constructor of class Formatting
def test_Formatting():
    result = Formatting(['colors'])
    assert(result.enabled_plugins[0].name == 'Colors')


# Generated at 2022-06-23 19:31:02.279411
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors', 'formatting'])

# Generated at 2022-06-23 19:31:04.634517
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ["Convert", "Color", "Syntax", "Format", "HTTPie"]
    f = Formatting(groups,env)
    assert f

# Generated at 2022-06-23 19:31:15.065511
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # When argument is an empty string.
    assert not is_valid_mime('')
    assert not Conversion.get_converter('')

    # When argument is None.
    assert not is_valid_mime(None)
    assert not Conversion.get_converter(None)

    # When argument is an invalid mimetype.
    assert not is_valid_mime('invalid')
    assert not Conversion.get_converter('invalid')

    # When argument is a valid mimetype that is not supported by any converter.
    assert is_valid_mime('application/json')
    assert not Conversion.get_converter('application/json')

    # When argument is a valid mimetype that is supported by a converter.
    assert is_valid_mime('text/html')
    assert Conversion.get

# Generated at 2022-06-23 19:31:23.649030
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_cases = {
        'output' : [
            {'text/html': '<!doctype html> <html> <body> <h1>Hello, world!</h1> </body> </html>'},
            {'application/json': '{"key1": "value1", "key2": {"key3": "value3"}}'},
            {'application/xml': '<bookstore><book><title lang="eng">Wicked!</title></book></bookstore>'},
            {'text/plain': 'This is a text file'}
        ]
    }

# Generated at 2022-06-23 19:31:33.360931
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie import plugins

    def run(group, mime = "application/json", content = '{"foo": "bar"}'):
        def enable_plugin(p):
            p.enabled = True
        for c in plugin_manager.get_formatters():
            enable_plugin(c)

        formatting = Formatting(group)
        return formatting.format_body(content, mime)
    # Test under PrettyPrint (Formatting)
    assert run("PrettyPrint") == ('{\n'
                                  '    "foo": "bar"\n'
                                  '}\n')
    # Test under Colors (Formatting)

# Generated at 2022-06-23 19:31:42.261568
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting = Formatting(groups=['colors'], env=Environment(),
                            sort_headers=True,
                            headers_length=10,
                            style='parrot')
    from httpie.compat import is_py26

    if is_py26:
        # We have to ignore the diff due to a different sort order in Python 2.6
        assert_py26_ignore_sort_order = True
    else:
        assert_py26_ignore_sort_order = False


# Generated at 2022-06-23 19:31:48.142959
# Unit test for constructor of class Formatting
def test_Formatting():
    raw_env = {'HTTPIE_CONFIG_DIR': '~/.httpie', 'HTTPIE_TEST_CONFIG_DIR': '~/httpie'}
    print(Environment(**raw_env))
    print(Formatting(["highlight", "colors", "format"], Environment(**raw_env)))
    return 0


if __name__ == "__main__":
    test_Formatting()

# Generated at 2022-06-23 19:31:52.771227
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test get_converter with a valid MIME type
    assert Conversion.get_converter('application/json').convert_json(json.dumps({'Message': 'Hello World'})) == {'Message': 'Hello World'}
    assert Conversion.get_converter('application/json').convert_json(json.dumps({'Message': 'Hello World'})) != 'Hello World'
    # Test get_converter with an invalid MIME type
    assert Conversion.get_converter('invalid') is None

# Generated at 2022-06-23 19:31:58.477523
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('jpg/jpeg')
    assert not is_valid_mime(None)
    assert not is_valid_mime('')
    assert not is_valid_mime('/html')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('/')

# Generated at 2022-06-23 19:32:07.824230
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('type/subtype')
    assert is_valid_mime('type/s')
    assert not is_valid_mime('/')
    assert not is_valid_mime('/subtype')
    assert not is_valid_mime('type/')
    assert not is_valid_mime('type//subtype')
    assert not is_valid_mime('type')
    assert not is_valid_mime('type/subtype/subtype')
    assert not is_valid_mime('type/sub-type')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)
    assert not is_valid_mime('type//subtype')

# Generated at 2022-06-23 19:32:12.455145
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors', 'format']
    env = None
    f = Formatting(groups, env, {"style": "paraiso-dark"})

    mime = "json"
    content = """{"Long":1,"Text":"}"Hello World"}"""
    # Formatting is only applied to json data

# Generated at 2022-06-23 19:32:13.360999
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter('text/csv')
    assert ConverterPlugin('text/csv').plugin_name == 'csv'

# Generated at 2022-06-23 19:32:15.445412
# Unit test for constructor of class Conversion
def test_Conversion():
    assert not Conversion.get_converter('application/xml')
    assert not is_valid_mime('')
    assert is_valid_mime('text/xml')



# Generated at 2022-06-23 19:32:20.795248
# Unit test for function is_valid_mime
def test_is_valid_mime():
    mime_str = "application/json"
    assert is_valid_mime(mime_str) == True
    assert is_valid_mime("applicat/json") == False
    assert is_valid_mime("/json") == False
    assert is_valid_mime("a/b") == True

# Generated at 2022-06-23 19:32:25.336983
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conv1 = Conversion.get_converter("application/json")
    conv2 = Conversion.get_converter("application/xml")
    conv3 = Conversion.get_converter("application/html")
    assert conv1.__class__.__name__ == 'XmlToJson'
    assert conv2 is None
    assert conv3 is None

# Generated at 2022-06-23 19:32:26.808517
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    expected = 'application/json'
    actual = Conversion.get_converter(expected).mime.lower()
    assert actual == expected


# Generated at 2022-06-23 19:32:38.121075
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('*/*')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/vnd.custom+json')
    assert is_valid_mime('text/html')
    assert is_valid_mime('text/plain')
    assert is_valid_mime('application/x-www-form-urlencoded')
    assert is_valid_mime('multipart/form-data')
    assert is_valid_mime('text/html;charset=utf-8')

    assert not is_valid_mime('json')
    assert not is_valid_mime('application')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('application/wrong')

# Generated at 2022-06-23 19:32:45.097318
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    flags = [
        ["html"],
        ["json"],
        ["xml"],
        ["html", "json", "xml"],
        ["html", "json", "xml"],
        ["html", "json", "xml", "png", "jpeg"],
        ["html", "json", "xml", "png", "jpeg"],
        ["html", "json", "xml", "png", "jpeg"],
        ["html", "json", "xml", "png", "jpeg"],
        ["html", "json", "xml", "png", "jpeg"],
    ]


# Generated at 2022-06-23 19:32:45.668595
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()

# Generated at 2022-06-23 19:32:49.040530
# Unit test for function is_valid_mime
def test_is_valid_mime():
    mimes = [None, '', ' ', '/', '//', 'text', 'text/', '/json', 'text//json', 'text/json']
    for mime in mimes:
        is_valid_mime(mime) == MIME_RE.match(mime)

# Generated at 2022-06-23 19:32:50.398772
# Unit test for constructor of class Conversion
def test_Conversion():
    assert callable(Conversion.get_converter)


# Generated at 2022-06-23 19:32:53.074615
# Unit test for constructor of class Conversion
def test_Conversion():
    """
    Unit test for constructor of class Conversion
    """
    mime = 'application/json'
    converter = Conversion().get_converter(mime)
    assert isinstance(converter, ConverterPlugin)



# Generated at 2022-06-23 19:32:57.027768
# Unit test for constructor of class Formatting
def test_Formatting():
    e = Environment()
    f = Formatting(['colors'], env=e)
    print(f.enabled_plugins)
    assert len(f.enabled_plugins) == 1
    print(f.enabled_plugins[0].to_terminal())



# Generated at 2022-06-23 19:33:01.683687
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert 'httpie.plugins.builtin.PrettyJson' == type(Conversion.get_converter('application/json')).__module__ + '.' + type(Conversion.get_converter('application/json')).__name__
    assert None == Conversion.get_converter('application/xml')
    assert None == Conversion.get_converter('abc')


# Generated at 2022-06-23 19:33:08.647833
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime_json = 'application/json'
    mime_html = 'text/html'
    mime_xml = 'application/xml'
    mime_unknown = 'application/unknown'

    converter = Conversion.get_converter(mime_json)
    assert converter.name == 'json'
    converter = Conversion.get_converter(mime_html)
    assert converter.name == 'html'
    converter = Conversion.get_converter(mime_xml)
    assert converter.name == 'xml'
    converter = Conversion.get_converter(mime_unknown)
    assert converter is None



# Generated at 2022-06-23 19:33:10.430704
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('a/b') == None
    assert Conversion.get_converter('application/json') != None
    assert Conversion.get_converter('application/json').process('{}') == '{\n    \n}'



# Generated at 2022-06-23 19:33:14.424848
# Unit test for constructor of class Conversion
def test_Conversion():
    import pytest

    mime = "text/html"
    converter = Conversion.get_converter(mime)
    assert converter.supports(mime)
    with pytest.raises(TypeError):
        assert not converter.supports(converter)



# Generated at 2022-06-23 19:33:20.171392
# Unit test for function is_valid_mime
def test_is_valid_mime():
    def expect(actual, expected):
        assert expected == is_valid_mime(actual)

    expect(None, False)
    expect('', False)
    expect('text/', False)
    expect('/plain', False)
    expect('text/plain/', False)
    expect('text/plain/a', False)
    expect('text/plain', True)

# Generated at 2022-06-23 19:33:31.448369
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import yaml
    fm = Formatting(groups=['formatters', 'highlighters'])

# Generated at 2022-06-23 19:33:40.642260
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors']
    env = Environment()
    env.stdout_isatty = True
    headers = b"HTTP/1.1 200 OK\r\nConnection: close\r\n" \
              b"Server: nginx\r\nDate: Wed, 23 Jan 2019 16:21:12 GMT\r\n" \
              b"Content-Type: application/json; charset=utf-8\r\n" \
              b"Content-Length: 855\r\nAccess-Control-Allow-Origin: *\r\n" \
              b"access-control-allow-credentials: true\r\n\r\n"
    formatting = Formatting(groups, env)
    formatting.format_headers(headers)



# Generated at 2022-06-23 19:33:44.909182
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter('form')
    assert not Conversion.get_converter('application/atom+xml')
    assert not Conversion.get_converter('application/xml')
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('html')
    assert not Conversion.get_converter('text')
    assert not Conversion.get_converter('text/xml')
    assert not Conversion.get_converter('text/html')
    assert not Conversion.get_converter('text/plain')
    assert not Conversion.get_converter('text/css')



# Generated at 2022-06-23 19:33:49.127951
# Unit test for constructor of class Formatting
def test_Formatting():
    # Unit test for constructor of class Formatting
    f = Formatting(["color"])
    assert f.enabled_plugins != []

# Generated at 2022-06-23 19:33:52.388499
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/plain")
    assert is_valid_mime("application/json")
    assert not is_valid_mime("text/plain/fun")
    assert not is_valid_mime("json")
    assert not is_valid_mime("text")

# Generated at 2022-06-23 19:34:03.222563
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = b"""<?xml version="1.0" encoding="UTF-8"?>
<restOperationResult>
   <status>SUCCESS</status>
   <lstFolders>
     <lstFolder>
       <str>/home/johndoe/work</str>
     </lstFolder>
   </lstFolders>
   <lstFolders>
     <lstFolder>
       <str>/home/johndoe/family</str>
     </lstFolder>
   </lstFolders>
   <lstFolders>
     <lstFolder>
       <str>/home/johndoe/private</str>
     </lstFolder>
   </lstFolders>
</restOperationResult>
"""

# Generated at 2022-06-23 19:34:06.545557
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'], ignore=None, style_file=None, styles=None)
    assert f.format_headers("HTTP/1.1 200 OK") == "\x1b[1mHTTP/1.1 200 OK\x1b[0m"


# Generated at 2022-06-23 19:34:07.505998
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion().get_converter('application/json') == None


# Generated at 2022-06-23 19:34:12.670739
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'HTTP/1.1 200 OK\r\nContent-length: 1\r\nContent-Type: text/html\r\n'
    f = Formatting(['colors'])
    f.format_headers(headers)



# Generated at 2022-06-23 19:34:15.475122
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json") is True
    assert is_valid_mime("") is False
    assert is_valid_mime("json") is False

# Generated at 2022-06-23 19:34:19.203899
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert not is_valid_mime('invalid/text/html')
    assert not is_valid_mime('invalid/mime')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:34:22.504210
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert isinstance(converter, ConverterPlugin)
    assert converter.mime == mime

# Generated at 2022-06-23 19:34:32.450876
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    class JsonConverter(ConverterPlugin):

        def supports(self, mime):
            if mime == 'application/json':
                return True

        def convert(self, data):
            return data

    class HtmlConverter(ConverterPlugin):

        def supports(self, mime):
            if mime == 'text/html':
                return True

        def convert(self, data):
            return data


# Generated at 2022-06-23 19:34:38.591384
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime(None)
    assert not is_valid_mime('/')
    assert not is_valid_mime('')
    assert not is_valid_mime('html')
    assert not is_valid_mime('text')
    assert not is_valid_mime('text/')

    assert is_valid_mime('text/html')
    assert is_valid_mime('text/html+xml')

# Generated at 2022-06-23 19:34:41.974293
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion()
    f = c.get_converter('application/json')
    assert f.__class__.__name__ == "JSONConverter"



# Generated at 2022-06-23 19:34:45.350473
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/xml') is not None
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('text/json') is not None

# Generated at 2022-06-23 19:34:48.616871
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('')
    assert not is_valid_mime('bad')
    assert not is_valid_mime('bad/')
    assert not is_valid_mime('/bad')
    assert not is_valid_mime('bad/bad')

# Generated at 2022-06-23 19:34:50.877641
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json") == True
    assert is_valid_mime("application/json/python") == False
    assert is_valid_mime("") == False

# Generated at 2022-06-23 19:34:55.830244
# Unit test for constructor of class Formatting
def test_Formatting():
    class F(Formatting):
        pass
    f = F(groups=['colors'])
    assert hasattr(f, 'enabled_plugins')
    assert isinstance(f.enabled_plugins, list)
    assert len(f.enabled_plugins) == 1
    assert hasattr(f.enabled_plugins[0], 'format_headers')
    assert hasattr(f.enabled_plugins[0], 'format_body')

# Unit tests for Formatting.format_headers

# Generated at 2022-06-23 19:35:03.653853
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatter = Formatting("APPLICATION", Humanize=True)
    assert formatter.format_body("""{
      "appId": "string",
      "id": "string",
      "key": "string",
      "keyId": "string",
      "name": "string",
      "typeId": "string"
    }""", "application/json") == """{
      'appId': 'string',
      'id': 'string',
      'key': 'string',
      'keyId': 'string',
      'name': 'string',
      'typeId': 'string'
    }"""

# Generated at 2022-06-23 19:35:05.830052
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('foo/bar')
    assert is_valid_mime('foo/bar-1')
    assert not is_valid_mime('foo/')
    assert not is_valid_mime('foo')
    assert not is_valid_mime('text')

# Generated at 2022-06-23 19:35:09.384545
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    mime = "application/json"
    content = " {" + "\n" + " \"key1\": \"value1\"" + "\n" + "}"
    groups = ["json"]
    assert Formatting(groups).format_body(content, mime) == "{\n    \"key1\": \"value1\"\n}"



# Generated at 2022-06-23 19:35:13.235889
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('text/html') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('application/csv') is None
    assert Conversion.get_converter('text/') is None
    assert Conversion.get_converter('/json') is None


# Generated at 2022-06-23 19:35:23.400157
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    print(available_plugins)
    print(type(available_plugins))
    print(type(available_plugins.keys()))
    print(available_plugins.keys())
    groups = list(available_plugins.keys())
    print(groups)
    env = Environment()
    print(env)
    f = Formatting(groups, env=env)
    print(f)
    print(f.enabled_plugins)
    print(type(f.enabled_plugins))
    print('----')
    for p in f.enabled_plugins:
        print(p)
        print(type(p))

# Generated at 2022-06-23 19:35:26.519944
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print(f'===test_Conversion_get_converter start===')
    converter = Conversion.get_converter('application/json')
    assert converter
    print(f'===test_Conversion_get_converter end===\n')



# Generated at 2022-06-23 19:35:31.052826
# Unit test for constructor of class Conversion
def test_Conversion():
    # For test
    # import sys
    # sys.path.append(os.path.join(os.path.dirname(__file__), '../../'))
    # print(sys.path)
    print(Conversion.get_converter('application/json').__class__.__name__)



# Generated at 2022-06-23 19:35:35.639981
# Unit test for function is_valid_mime
def test_is_valid_mime():
    print(is_valid_mime('application/json'))
    print(is_valid_mime('application'))
    assert is_valid_mime('application/json') == True, "Result should be True"
    assert is_valid_mime('application') == False, "Result should be False"


# Generated at 2022-06-23 19:35:40.164221
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["nocolor"]
    # env = Environment()
    env = Environment()
    groups = ["nocolor"]
    actual = Formatting(groups, env)
    assert len(actual.enabled_plugins) == 1
    assert actual.enabled_plugins[0].__name__ == 'NoColorFormatter'

    # ensure plugins are loaded
    assert len(plugin_manager.get_formatters_grouped()) > 0



# Generated at 2022-06-23 19:35:43.629653
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors', 'HTTPiePrettyPlugins'])
    assert f != None
    f = Formatting(['colors', 'HTTPiePrettyPlugins', 'utf8'])
    assert f != None

test_Formatting()

# Generated at 2022-06-23 19:35:47.935237
# Unit test for function is_valid_mime
def test_is_valid_mime():
    test_cases = [
        ('text/html', True),
        ('application/json', True),
        ('some/thing', True),
        ('text/', False),
        ('text/ ', False),
        ('/', False),
        ('/ ', False),
        (' ', False),
        ('', False),
        (None, False),
        ('app/', False),
        ('app/l', False),
        ('app/json', True),
    ]
    for mime, expect in test_cases:
        assert is_valid_mime(mime) == expect

# Generated at 2022-06-23 19:35:56.361975
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    env = Environment()
    # plugin_manager.load_directory("/home/pi/httpie/plugins/")
    p = Formatting(groups=["format_body"], env=env)
    content = "hello"
    mime = "application/json"
    content_new = p.format_body(content, mime)
    assert content_new == "heo"
    return content_new


# Generated at 2022-06-23 19:35:59.037927
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/plain'
    assert is_valid_mime(mime)
    assert Conversion.get_converter(mime) is not None



# Generated at 2022-06-23 19:36:05.117669
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert(is_valid_mime("xx/xx"))
    assert(is_valid_mime("text/plain"))
    assert(is_valid_mime("application/json"))
    assert(is_valid_mime("".join(chr(97+i) for i in range(1, 50))))
    assert(not is_valid_mime(""))
    assert(not is_valid_mime("application"))
    assert(not is_valid_mime("plain"))
    assert(not is_valid_mime("::::::::::::"))

# Generated at 2022-06-23 19:36:07.911374
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime('')
    assert not is_valid_mime('application')
    assert is_valid_mime('application/json')

# Generated at 2022-06-23 19:36:11.838273
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime(None)
    assert is_valid_mime('text/html')
    assert not is_valid_mime('text')
    assert not is_valid_mime('html')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('/html')

# Generated at 2022-06-23 19:36:17.075930
# Unit test for constructor of class Conversion
def test_Conversion():
    assert MIME_RE.match('application/json')
    assert MIME_RE.match('application/JSoN')
    assert not MIME_RE.match('json')
    assert not MIME_RE.match('application/json/')


# Generated at 2022-06-23 19:36:26.943603
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/plain') == True
    assert is_valid_mime('text/html') == True
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application/x-www-form-urlencoded') == True
    assert is_valid_mime('image/gif') == True

    assert is_valid_mime('') == False
    assert is_valid_mime('/') == False
    assert is_valid_mime('/json') == False
    assert is_valid_mime('application/') == False
    assert is_valid_mime('application') == False
    assert is_valid_mime('application/json/v1') == False
    assert is_valid_mime('text//plain') == False
    assert is_

# Generated at 2022-06-23 19:36:30.019732
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('a/a')
    assert not is_valid_mime('')
    assert not is_valid_mime('/')
    assert not is_valid_mime('a')

# Generated at 2022-06-23 19:36:36.704056
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatter = Formatting(groups=['all'])
    json_mime = 'application/json'
    text_mime = 'text/plain'

    assert formatter.format_body("{}", json_mime) == b'{\n    \n}\n'
    assert formatter.format_body("json", json_mime) == b'{\n    \n}\n'
    assert formatter.format_body("{}", text_mime) == b'{}'

# Generated at 2022-06-23 19:36:38.278417
# Unit test for constructor of class Conversion
def test_Conversion():
    result = is_valid_mime('application/json')
    assert result is True


# Generated at 2022-06-23 19:36:40.276522
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['highlight', 'colors'], env=Environment(), **{})
    f.enabled_plugins


# Generated at 2022-06-23 19:36:43.186078
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert converter.supports('text/html')
    converter = Conversion.get_converter('application/json')
    assert not converter

# Generated at 2022-06-23 19:36:45.476619
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter()


# TODO(ssd) 2018-10-11: Write a unit test for class Formatting

# Generated at 2022-06-23 19:36:50.569743
# Unit test for function is_valid_mime
def test_is_valid_mime():
    mime = 'abc/def'
    assert is_valid_mime(mime), "%s is not a valid mime." % mime
    mime = 'abc//def'
    assert not is_valid_mime(mime), "%s is a valid mime." % mime
    mime = 'abc/def/ghi'
    assert not is_valid_mime(mime), "%s is a valid mime." % mime

# Generated at 2022-06-23 19:36:52.012965
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=['json', 'html'])
    mime = 'application/json'
    content = '{"hello": "world"}'
    f.format_body(content, mime)

# Generated at 2022-06-23 19:37:01.469866
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').enabled == True
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert Conversion.get_converter('text/json').mime == 'text/json'
    assert Conversion.get_converter('text/html').mime == 'text/html'
    assert Conversion.get_converter('text/html').enabled == False
    assert Conversion.get_converter('application/json').to_json() == '{"mime": "application/json"}'
    assert Conversion.get_converter('application/json').format_body('{"name":"Ming"}', 'application/json') == '{\n    "name": "Ming"\n}'
    assert Conversion.get_converter('text/json').format_

# Generated at 2022-06-23 19:37:08.839715
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # When no plugins are enabled
    formatting = Formatting(groups=[])
    assert formatting.format_headers("") == ""
    assert formatting.format_headers("abcdefg\n") == "abcdefg\n"

    # When only the colors plugin is enabled
    colors_plugin = ColorsPlugin()
    colors_plugin.enabled = True
    formatting = Formatting(groups=[])
    formatting.enabled_plugins.append(colors_plugin)
    assert formatting.format_headers("") == ""
    assert formatting.format_headers("abcdefg\n") == "abcdefg\n"
    assert formatting.format_headers("Content-Type: application/json\n") == \
        colors_plugin.style_keyword("Content-Type: ") + colors_plugin.style_keyword("application/json") + "\n"

    #

# Generated at 2022-06-23 19:37:21.119949
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Create a test message with headers
    msg_str = """Content-Type: text/html; charset=ISO-8859-4
Content-Length: 111

<head>
    <title>Headers</title>
</head>

<body>
    <div>
        <a>My</a>
        <b>first</b>
        <p>web</p>
         <h1>page</h1>
    </div>

</body>
    """
    # formatting headers with all plugins
    formatter = Formatting(['colors', 'colors-light'])
    headers = formatter.format_headers(msg_str).split('\n\n', 1)[0]

    # assert that the headers were actually formatted
    assert headers.count('\n') == 2

# Generated at 2022-06-23 19:37:26.935626
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    h = Formatting(['colors'])
    res = h.format_body('{"test": "body"}', 'application/json')
    print(res)

# # Unit test for method format_body of class Formatting
# def test_Formatting_format_headers():
#     h = Formatting(['colors'])
#     res = h.format_headers('{"test": "body"}')
#     print(res)

# Generated at 2022-06-23 19:37:35.113450
# Unit test for function is_valid_mime
def test_is_valid_mime():
    # valid mime
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/xml')
    assert is_valid_mime('text/html')

    # invalid mime
    assert not is_valid_mime('application')
    assert not is_valid_mime('/json')
    assert not is_valid_mime('application-json')
    assert not is_valid_mime('-json')
    assert not is_valid_mime('json')

# Generated at 2022-06-23 19:37:38.591371
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter(mime="text/html")
    assert converter.__class__.__name__ == 'HtmlToAnsiConverter'

    converter = Conversion.get_converter(mime="application/x-www-form-urlencoded")
    assert converter is None

    converter = Conversion.get_converter(mime=None)
    assert converter is None



# Generated at 2022-06-23 19:37:45.549807
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # test case 1, valid mime
    mime = "text/html"
    expected_result = None
    actual_result = Conversion.get_converter(mime)
    assert actual_result == expected_result

    # test case 2, invalid mime
    mime = "text//html"
    expected_result = None
    actual_result = Conversion.get_converter(mime)
    assert actual_result == expected_result


# Generated at 2022-06-23 19:37:51.268053
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter("test")
    assert Conversion.get_converter("application/json")
    assert Conversion.get_converter("application/xml")
    assert not Conversion.get_converter("test/test")



# Generated at 2022-06-23 19:38:02.162773
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-23 19:38:09.008597
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion()
    assert 0 == len(converter.get_converter('1'))
    assert 0 == len(converter.get_converter(1))
    assert 1 == len(converter.get_converter('json'))
    assert 1 == len(converter.get_converter('csv'))


# Generated at 2022-06-23 19:38:15.679797
# Unit test for function is_valid_mime
def test_is_valid_mime():
    # given
    cases = [
        ["text/html", True],
        ["application/json+fhir", True],
        ["application/json", True],
        ["", False],
        ["text/html,foo/bar", False],
        ["/css", False],
        ["text", False]
    ]

    # then
    for mime, expected in cases:
        print(mime, expected)
        assert is_valid_mime(mime) == expected

# Generated at 2022-06-23 19:38:24.221782
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.stdout = io.StringIO()
    formatting = Formatting(["colors"], env=env)
    red = Formatting(["colors"], env=env)
    headers = formatting.format_headers("""HTTP/1.1 200 OK
Connection: keep-alive
Content-Encoding: gzip
Content-Type: application/json; charset=utf-8
Date: Thu, 26 Sep 2019 12:35:57 GMT
ETag: W/"197-W8iv2mzEpIcTLfvGdoKSYW8mQYhE"
Server: nginx/1.16.1
Transfer-Encoding: chunked
Vary: Accept-Encoding""")

# Generated at 2022-06-23 19:38:26.827946
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['format']
    env = Environment()
    fmt = Formatting(groups, env)
    assert fmt
    assert fmt.enabled_plugins



# Generated at 2022-06-23 19:38:34.893626
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    for group in plugin_manager.formatters.groups:
        for testcase in plugin_manager.formatters.group_instances(group):
            testcase.env = env
            data = '"test header"'
            actual = testcase.format_headers(data)
            if testcase.enabled:
                if testcase.is_json:
                    expected = '{\n    "test header"\n}'
                else:
                    expected = 'test header'
                assert actual == expected
            else:
                assert actual == data


# Generated at 2022-06-23 19:38:41.871445
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
	# Type check is fine
    assert isinstance(Conversion.get_converter('application/josn'), ConverterPlugin)
    # Wrong mime type
    assert not Conversion.get_converter('text')
    # Type check is failed
    # assert type(Conversion.get_converter('application/json')) is ConverterPlugin

# unit test for method is_valid_mime of method is_valid_mime

# Generated at 2022-06-23 19:38:45.384302
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    plugin_manager.get_formatters_grouped = lambda: ('mock', [PluginClass])
    PluginClass.format_headers = lambda x, headers: '{}: {}'.format(x.name, headers)
    assert Formatting(['mock'], name='mock').format_headers('mock: mock') == 'mock: mock'



# Generated at 2022-06-23 19:38:57.182514
# Unit test for function is_valid_mime
def test_is_valid_mime():
    mime = 'application/json'
    assert is_valid_mime(mime)
    mime = 'text/plain'
    assert is_valid_mime(mime)
    mime = 'application/jason'
    assert not is_valid_mime(mime)
    mime = None
    assert not is_valid_mime(mime)
    mime = 'application'
    assert not is_valid_mime(mime)
    mime = ''
    assert not is_valid_mime(mime)
    mime = 'application/json; charset=UTF-8'
    assert not is_valid_mime(mime)
    mime = 'text/plain; charset=UTF-8'
    assert not is_valid_mime(mime)

# Generated at 2022-06-23 19:38:59.330014
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=["colors"])
    assert f.enabled_plugins == []



# Generated at 2022-06-23 19:39:03.490855
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') is True
    assert is_valid_mime('text/html') is True
    assert is_valid_mime('') is False
    assert is_valid_mime('application/json=') is False

# Generated at 2022-06-23 19:39:12.741045
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert Formatting(groups=['colors']).format_body(
        content = "[{\"a\": \"b\"}]", mime = "application/json"
    ) == "\033[94m[\033[39m\033[92m{\033[39m\033[94m\"\033[39m\033[92ma\033[39m\033[94m\"\033[39m\033[92m:\033[39m \033[94m\"\033[39m\033[92mb\033[39m\033[94m\"\033[39m\033[92m}\033[39m\033[94m]\033[39m"

# Generated at 2022-06-23 19:39:13.265630
# Unit test for constructor of class Conversion
def test_Conversion():
    Conversion()



# Generated at 2022-06-23 19:39:16.436572
# Unit test for constructor of class Conversion
def test_Conversion():
    res = Conversion.get_converter(mime='application/json')
    assert res is not None
    assert isinstance(res, ConverterPlugin)
    assert res.mime == 'application/json'


# Generated at 2022-06-23 19:39:22.589001
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    env.colors = None
    env.style = None
    env.stream = None
    # p1 and p2 are two instances of FormatterPlugin
    p1 = plugin_manager.instantiate_plugin('format', 'json', env)
    p2 = plugin_manager.instantiate_plugin('format', 'colors', env)
    # f is an instance of class Formatting
    f = Formatting(groups=['format'], env=env)
    f.enabled_plugins = [p1, p2]
    # test format_body method of f
    t = f.format_body(content='{ "a": "b"}', mime='application/json')
    # expected output is '{\n    "a": "b"\n}\n'

# Generated at 2022-06-23 19:39:25.783740
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter('application/json') == None
    assert Conversion.get_converter('text/plain') == None
    assert Conversion.get_converter('image/png') == None


# Generated at 2022-06-23 19:39:35.878074
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors', 'format'])
    assert f.format_headers("Content-Type: application/json\n") == \
           "Content-Type: text/html; charset=utf-8\n"
    assert f.format_body("""{"json": "dict"}\n""", "application/json") == \
           """<!DOCTYPE html>\n<html>\n<head>\n<meta charset="UTF-8" />\n""" \
           """<title>Response content</title>\n</head>\n<body>\n\n""" \
           """<pre><code>{&#34;json&#34;: &#34;dict&#34;}""" \
           """</code></pre>\n</body>\n</html>\n"""




# Generated at 2022-06-23 19:39:42.400367
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/plain')
    assert not is_valid_mime('')
    assert not is_valid_mime('text')
    assert not is_valid_mime('plain')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('/json')
    assert not is_valid_mime('application/json/')

# Generated at 2022-06-23 19:39:45.247026
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = "HTTP/2 200 \r\ncontent-type: application/json\r\n\r\n"
    assert Formatting(['solarized']).format_headers(headers) == headers
    headers = "HTTP/2 200 \r\ncontent-type: application/json\r\n\r\n"
    assert Formatting(['colors']).format_headers(headers) == headers

# Generated at 2022-06-23 19:39:47.585756
# Unit test for constructor of class Conversion
def test_Conversion():
    assert isinstance(Conversion(), Conversion)
    assert isinstance(Conversion().get_converter("application/json"),
                      ConverterPlugin)


# Generated at 2022-06-23 19:39:51.743761
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(["colors"]).format_headers("Content-Type: text/html") == '\x1b[37m\x1b[1mContent-Type\x1b[22m\x1b[39m: \x1b[33m\x1b[1mtext/html\x1b[22m\x1b[39m\r\n'


# Generated at 2022-06-23 19:39:57.146827
# Unit test for function is_valid_mime
def test_is_valid_mime():
    mimes = [
        "application/json",
        "text/html",
        "multipart/form-data",
        "application/x-www-form-urlencoded"
        ]
    invalid_mimes = [
        "not/a/valid-mime",
        "text/html/extra",
        "application/json+extra",
        "application/a+b+c/d+e+f",
        "\"application/json\"",
        "application/json; charset=utf-8"
        ]
    for mime in mimes:
        assert is_valid_mime(mime) == True
    for mime in invalid_mimes:
        assert is_valid_mime(mime) == False