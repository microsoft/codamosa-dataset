

# Generated at 2022-06-23 19:29:51.159007
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("text/html")
    assert converter.__dict__["mime"] == "text/html"


# Generated at 2022-06-23 19:29:54.421915
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test invalid MIME
    mime = "text/html"
    assert Conversion.get_converter(mime) is None
    mime = "text/html/abc"
    assert Conversion.get_converter(mime) is None


# Generated at 2022-06-23 19:29:57.814825
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'])
    assert f.enabled_plugins
    for p in f.enabled_plugins:
        assert p.enabled
    assert type(f) == Formatting

# Generated at 2022-06-23 19:30:06.301447
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    #case 1
    headers = "HTTP/1.1 200 OK\r\nContent-Type: application/xml\r\nContent-Length: 10\r\n\r\n"
    format_groups = []
    format_kwargs = {}
    env = Environment()
    ref = Formatting(format_groups, env, **format_kwargs)
    result = ref.format_headers(headers)
    assert result == headers

    #case 2
    headers = "Content-Type: application/xml\r\nContent-Length: 10\r\n\r\n"
    format_groups = ["HTTPHeadersProcessor", "colors"]
    format_kwargs = {}
    env = Environment()
    ref = Formatting(format_groups, env, **format_kwargs)

# Generated at 2022-06-23 19:30:13.193326
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Initialize environment
    env = Environment()
    # Initialize formatter
    formatter = Formatting(groups=["format", "syntax-highlight"], env=env,
                           syntax="pygments", 
                           style="autumn")
    # Generate a test input
    input_text_json = b"""
    {
        "name": "John Smith",
        "age": 35,
        "height": 1.80,
        "married": true,
        "profession": "architect",
        "salary": 2800.00,
        "hobbies": [
            "sports",
            "cooking"
        ]
    }
    """
    # Convert json bytes -> string
    input_text_json = input_text_json.decode('utf-8')
    # Invoke method format_body()

# Generated at 2022-06-23 19:30:15.059424
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('image/png'), ConverterPlugin)



# Generated at 2022-06-23 19:30:19.381164
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class P:
        def __init__(self):
            pass
            self.enabled = True
        def format_body(self, body, mime):
            return f"P {mime} {body}"

    f = Formatting([])
    f.enabled_plugins.append(P())
    assert f.format_body("whatever", "whatever") == "P whatever whatever"

# Generated at 2022-06-23 19:30:21.833982
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = 'text/html'
    test_converter = Conversion.get_converter(mime)
    assert isinstance(test_converter, ConverterPlugin)


# Generated at 2022-06-23 19:30:24.705103
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    formatting = Formatting(groups=['colors'], env=env)
    assert formatting.enabled_plugins is not None

# Generated at 2022-06-23 19:30:34.204268
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/vtt')
    assert not is_valid_mime('text')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('JSON')
    assert not is_valid_mime('')
    assert not is_valid_mime('/')
    assert not is_valid_mime('t/h')
    assert not is_valid_mime('/t')
    assert not is_valid_mime('t/')
    assert not is_valid_mime('///')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:30:41.271859
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    header_lines = [
        'HTTP/1.1 200 OK',
        'Status: 200 OK',
        'Server: Apache-Coyote/1.1',
        'Accept-Ranges: bytes',
        'Etag: W/"0-1429324665000"',
        'Last-Modified: Thu, 04 Feb 2016 02:11:05 GMT',
        'Content-Type: application/json',
        'Content-Length: 612',
        'Date: Thu, 04 Feb 2016 02:21:50 GMT',
        '',
        ''
    ]
    headers = '\r\n'.join(header_lines)
    content_type = 'application/json'
    fmt = Formatting(['colors', 'format'], styles=[])
    assert 'color' in fmt.format_headers(headers)

# Generated at 2022-06-23 19:30:49.925443
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter(None)
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter('foo')
    assert not Conversion.get_converter('foo/bar/baz')
    assert not Conversion.get_converter('foo/bar/baz')
    assert not Conversion.get_converter('foo/bar/')
    assert not Conversion.get_converter('/')
    assert not Conversion.get_converter('json')
    assert not Conversion.get_converter('/json')
    assert not Conversion.get_converter('json/')

    assert isinstance(Conversion.get_converter('json'), ConverterPlugin)

# Generated at 2022-06-23 19:30:53.014072
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    converter = ConverterPlugin()
    content = '{"A":"B"}'
    assert Formatting([]).format_body(converter.to_json(content), converter.mime) == converter.to_json(content)

# Generated at 2022-06-23 19:31:01.172912
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print()
    print("format_body unit test.")
    print("Test case 1: valid mime.")
    groups = ["format"]
    env = Environment()
    f = Formatting(groups, env=env)
    mime = "application/json"
    content = '{"name": "Kane", "age": "15", "klass": "Chinese"}'
    formatted = f.format_body(content, mime)
    print("Before formatting: "+content)
    print("After formatting: " + formatted)
    print("Result: " + str(formatted == '{\n    "name": "Kane",\n    "age": "15",\n    "klass": "Chinese"\n}'))
    print()
    print("Test case 2: invalid mime.")
    mime = "invalid"
    content

# Generated at 2022-06-23 19:31:02.463032
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter(None)
    assert c == None

# Generated at 2022-06-23 19:31:06.206073
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime("image/jpeg")
    assert not is_valid_mime("jpeg")
    mime = "image/jpeg"
    assert isinstance(Conversion.get_converter(mime),ConverterPlugin)


# Generated at 2022-06-23 19:31:07.170034
# Unit test for constructor of class Conversion
def test_Conversion():
	assert Conversion.get_converter("application/json")

# Generated at 2022-06-23 19:31:12.099830
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    new_obj = Conversion()
    assert new_obj.get_converter('text/plain') is None
    assert new_obj.get_converter('text/csv') is None
    assert new_obj.get_converter('application/json') is not None
    assert new_obj.get_converter('application/xml') is not None

# Generated at 2022-06-23 19:31:14.572927
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    print(env.colors)
    if env.colors:
        Formatting(['colors'], env)



# Generated at 2022-06-23 19:31:22.774315
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.compat import str

    def _test_method(self):
        pass

    class MockClass:
        enabled = False
        env = None
        format_headers = _test_method
        format_body = _test_method

    assert not Formatting('json').enabled_plugins
    assert not Formatting('json',
                          json=MockClass, j=MockClass,
                          pretty=MockClass).enabled_plugins
    f = Formatting('json,pretty',
                   json=MockClass, j=MockClass,
                   pretty=MockClass)
    assert len(f.enabled_plugins) == 2
    assert f.enabled_plugins[0].env == Environment()

    # groups == ['*'] is a special case enabling all groups

# Generated at 2022-06-23 19:31:25.382954
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None


# Generated at 2022-06-23 19:31:30.065385
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class MockClass(Formatting):
        def __init__(self, groups, env, **kwargs):
            super(MockClass, self).__init__(groups, env, **kwargs)
            self.headers = "some headers"

    obj = MockClass(groups=['colors'], env=Environment(), **{})
    assert obj.format_headers() == "some headers"


# Generated at 2022-06-23 19:31:32.915793
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    kwargs = { 'theme': 'TangoTheme'}
    f = Formatting(groups, env, **kwargs)
    assert f

# Generated at 2022-06-23 19:31:37.855860
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env= Environment()
    env.config.output_options.headers = ['verbose']
    kwargs = {'env':env}
    # The method format_headers should return the same string that it was passed
    groups = ['verbose']
    content = "a"
    output_content = Formatting(groups,**kwargs).format_headers(content)
    assert output_content == content


# Generated at 2022-06-23 19:31:39.484714
# Unit test for constructor of class Conversion
def test_Conversion():
    my_converter = Conversion.get_converter('text/html')
    assert my_converter == None

# Generated at 2022-06-23 19:31:46.646295
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert Conversion.get_converter('application/json').supports('application/json')
    assert Conversion.get_converter('application/xhtml+xml').mime == 'application/xhtml+xml'
    assert Conversion.get_converter('application/xhtml+xml').supports('application/xhtml+xml')
    assert Conversion.get_converter('application/xml').mime == 'application/xml'
    assert Conversion.get_converter('application/xml').supports('application/xml')
    assert Conversion.get_converter('text/css').mime == 'text/css'
    assert Conversion.get_converter('text/css').supports('text/css')
    assert Conversion.get_con

# Generated at 2022-06-23 19:31:49.053854
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.builtin import JSONHeadersProcessor

    http_headers = HTTPHeadersProcessor(True, None)
    http_headers.format_headers("")

    json_headers = JSONHeadersProcessor(True, None)
    json_headers.format_headers("")

    formatting = Formatting(["HTTP Headers", "JSON"])
    formatting.format_headers("")

# Generated at 2022-06-23 19:31:55.256185
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application/js') == False
    assert is_valid_mime('application') == False
    assert is_valid_mime('application/') == False
    assert is_valid_mime('/json') == False

# Generated at 2022-06-23 19:31:57.581176
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter.supports("application/json") == True


# Generated at 2022-06-23 19:32:03.820482
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print("test_Formatting_format_headers")
    p = Formatting(groups=('netstrings', ))
    assert 'f#o#o#b#a#r#' == p.format_headers('"f","o","o","b","a","r"')
    assert '"f","o","o","b","a","r"' == p.format_headers('"f","o","o","b","a","r"')
    p = Formatting(groups=('netstrings', 'colors'))
    assert '"f","o",\033[35m"o"\033[0m,"b","a","r"' == p.format_headers('"f","o","o","b","a","r"')

# Generated at 2022-06-23 19:32:06.487906
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """test_Conversion_get_converter"""
    c = Conversion.get_converter("text/html")
    assert c.__class__.__name__ == "HTMLEncodeProcessor"

# Generated at 2022-06-23 19:32:11.039006
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    groups = plugin_manager.get_available_formatter_groups()
    f = Formatting(groups)
    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=Environment(stdout=StringIO()))
            if p.enabled:
                assert p in f.enabled_plugins

# Generated at 2022-06-23 19:32:17.947543
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONRawFormat
    from httpie.plugins.registry import plugin_manager
    env = Environment()
    converter_class = plugin_manager.get_converters()[0]
    converter = converter_class(mime="text/html")
    assert converter.supports("text/html")
    formatter_class = plugin_manager.get_formatters_grouped()[0][0]
    formatter = formatter_class(env=env)
    assert formatter.enabled

# Generated at 2022-06-23 19:32:19.002532
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    asser

# Generated at 2022-06-23 19:32:24.973616
# Unit test for constructor of class Conversion
def test_Conversion():
    print("\nTesting constructor of class Conversion...")
    groups = ["colors", "format"]
    env = Environment()
    conversion = Conversion(groups, env)
    expected = "httpie.core.Conversion"
    received = str(type(conversion))
    
    print("Expected: " + str(expected))
    print("Received: " + str(received))

    assert expected == received


# Generated at 2022-06-23 19:32:28.545642
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('text/html; charset=utf-8')
    assert not is_valid_mime('text/html;charset=utf-8')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('/html')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:32:31.026252
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'], 'wily')
    assert f.enabled_plugins[0].env.colors == 'wily'

# Generated at 2022-06-23 19:32:34.560758
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Delegate instances
    json_yaml_color = Formatting(['color', 'yaml'])
    json_yaml_color.format_body('{"hello": "world"}', 'application/json')

# Generated at 2022-06-23 19:32:36.824064
# Unit test for constructor of class Conversion
def test_Conversion():
    # init an instance
    conversion = Conversion()
    assert conversion.get_converter('json') is not None


# Generated at 2022-06-23 19:32:42.182373
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter(): #1
    assert Conversion.get_converter(None) is None
    assert Conversion.get_converter('*') is None
    assert Conversion.get_converter('*/*') is None
    assert Conversion.get_converter('qwerty') is None
    assert Conversion.get_converter('application/json') is None
    assert Conversion.get_converter('text/*') is None
    assert Conversion.get_converter('text/html') is None

# Generated at 2022-06-23 19:32:43.419918
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(groups=['colors', 'syntax'])


# Generated at 2022-06-23 19:32:45.713252
# Unit test for constructor of class Conversion
def test_Conversion():
    # Create a conversion object
    conversion = Conversion()

    assert conversion is not None


# Generated at 2022-06-23 19:32:47.404477
# Unit test for constructor of class Conversion
def test_Conversion():
    assert not is_valid_mime('')
    assert not is_valid_mime('/')


# Generated at 2022-06-23 19:32:50.068058
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print("testing Formatting.format_body...")
    f = Formatting(groups=["format_json"])
    content = f.format_body("{\"key\":\"value\"}",
                            mime="application/json")
    assert(content == "{\n  \"key\": \"value\"\n}\n")
    print("passed")

# Generated at 2022-06-23 19:32:53.115713
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime("")
    assert not is_valid_mime("application")
    assert not is_valid_mime("application/")
    assert not is_valid_mime("/json")
    assert is_valid_mime("application/json")
    assert is_valid_mime("text/plain")
    assert is_valid_mime("my-custom-mime/my-custom-submime")



# Generated at 2022-06-23 19:32:57.026966
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = "application/json"
    assert Conversion.get_converter(mime)
    mime = "application/json"
    assert is_valid_mime(mime)
    assert not is_valid_mime("jsn")


# Generated at 2022-06-23 19:33:02.139320
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in ['colors', 'colors_256']:
        for cls in available_plugins[group]:
            p = cls(env=Environment(), color_mode='256')
            if p.enabled:
                enabled_plugins.append(p)
    try:
        instance = Formatting(groups=['colors', 'colors_256'], env=Environment(), color_mode='256')
        assert instance.enabled_plugins == enabled_plugins
    except AssertionError:
        print('Unit test failed!')


# Generated at 2022-06-23 19:33:08.114561
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert(is_valid_mime('application/json'))
    assert(is_valid_mime('application/xml'))
    assert(is_valid_mime('text/plain'))
    assert(is_valid_mime('text/html'))
    assert(not is_valid_mime('json'))
    assert(not is_valid_mime('xml'))
    assert(not is_valid_mime('text'))

# unit test for function Conversion.get_converter

# Generated at 2022-06-23 19:33:09.485299
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    converter = Conversion.get_converter('application/javascript')
    assert converter is None

# Generated at 2022-06-23 19:33:12.629485
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion.get_converter('application/json')
    assert isinstance(c, ConverterPlugin)
    c.convert_to_bytes()

# Generated at 2022-06-23 19:33:14.092723
# Unit test for constructor of class Conversion
def test_Conversion():
    x = Conversion.get_converter('application/json')
    assert x is not None


# Generated at 2022-06-23 19:33:23.629240
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import unittest
    from unittest import mock
    class MockFormatter(object):
        def format_headers(self, headers: str) -> str:
            return headers
    class MockFormatter2(object):
        def __init__(self, env=None, **kwargs):
            self.enabled = True
        def format_headers(self, headers: str) -> str:
            return headers
    # mock the object plugin_manager of httpie.plugins.__init__
    with mock.patch('httpie.plugins.__init__.plugin_manager', autospec=True) as plugin_manager:
        available_plugins = {'General':[MockFormatter, MockFormatter2]}
        plugin_manager.get_formatters_grouped.return_value = available_plugins
        # 1. test_format_headers
        #

# Generated at 2022-06-23 19:33:27.505752
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    rs = Conversion.get_converter('text/plain')
    assert hasattr(rs, 'content_type')
    assert hasattr(rs, 'get_convert')


# Generated at 2022-06-23 19:33:33.863040
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()

    # user specify a wrong group
    env = Environment()
    kwargs = {}
    groups = ['WrongGroup']

    got_error = False
    try:
        f = Formatting(groups, env, **kwargs)
    except KeyError:
        got_error = True
    assert got_error

    # user specify a right group
    groups = ['json']
    f = Formatting(groups, env, **kwargs)
    assert f.enabled_plugins[0].__class__ == available_plugins['json'][0]


# Generated at 2022-06-23 19:33:35.359043
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["format"]
    env = Environment()

    formatting = Formatting(groups, env)
    assert formatting != None


# Generated at 2022-06-23 19:33:43.600113
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'Accept: text/html\nUser-Agent: curl/7.54.0\nAccept-Encoding: gzip, deflate, br\nAccept-Language: en-US,en;q=0.9'
    # this is a list of the headers that is given in the request
    list_headers = headers.split('\n')
    # this is a list of the expected headers that have to be returned
    list_expected_headers = ['Accept: text/html', 'User-Agent: curl/7.54.0', 'Accept-Encoding: gzip, deflate, br',
                             'Accept-Language: en-US,en;q=0.9']
    # Test Formatting class by calling its method format_headers, which returns a string with the formatted headers
    formatter = Formatting()
    output_headers = form

# Generated at 2022-06-23 19:33:51.528829
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('test/test')
    assert not is_valid_mime('')
    assert not is_valid_mime('test')
    assert not is_valid_mime('text')
    assert not is_valid_mime('/')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('/html')
    assert not is_valid_mime('text//html')

# Generated at 2022-06-23 19:33:55.392311
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    h = Formatting(['colors'], auto_formatted_colors=True)
    assert h.format_headers('Content-Type: application/json')
    assert h.format_headers('content-type: application/json')

# Generated at 2022-06-23 19:33:58.508932
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    f = Formatting(groups, env)
    assert f.enabled_plugins[0].name == 'colors'

# Generated at 2022-06-23 19:34:08.002692
# Unit test for method format_body of class Formatting

# Generated at 2022-06-23 19:34:14.663177
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import gzip
    x = {
        "input": gzip.compress(b"hello world"),
        "mime": "application/gzip",
        "output": "hello world\n"
    }
    fmt = Formatting(groups=["decode"], env=None)
    assert fmt.format_body(x["input"], x["mime"]) == x["output"]

# Generated at 2022-06-23 19:34:18.324578
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    assert not is_valid_mime("json")
    assert not is_valid_mime("application/json/")
    assert not is_valid_mime("application/json/a")

# Generated at 2022-06-23 19:34:21.559915
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['colors']
    env=Environment()
    format_body = Formatting(groups, env).format_body('{"name": "test"}', 'application/json')
    print(format_body)

# Generated at 2022-06-23 19:34:25.035348
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "application/json"
    expected_mime = "application/json"
    converter = Conversion.get_converter(mime)
    assert converter.mime == expected_mime

# Generated at 2022-06-23 19:34:32.239386
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """Unit tests for the class Conversion"""
    class test_converter_class(ConverterPlugin):
        def __init__(self, mime):
            pass
        @classmethod
        def supports(cls, mime):
            if mime == 'application/octet-stream':
                return True
            else:
                return False

    plugin_manager.register_converter_class(test_converter_class)
    converter = Conversion.get_converter("application/octet-stream")
    assert isinstance(converter, test_converter_class)



# Generated at 2022-06-23 19:34:38.175567
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = 'application/json'
    assert Conversion.get_converter(mime) is not None
    assert Conversion.get_converter(mime).mime == 'application/json'

    mime = 'application/xml'
    assert Conversion.get_converter(mime) is not None
    assert Conversion.get_converter(mime).mime == 'application/xml'

# Generated at 2022-06-23 19:34:46.630178
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.compat import urlopen
    from httpie.plugins.builtin import JSONFormatter
    url = 'https://api.github.com/repos/jakubroztocil/httpie'
    response = urlopen(url)
    body = response.read().decode('utf8')
    content_type = dict(response.getheaders())['Content-Type']
    assert content_type=='application/json; charset=utf-8'
    json_mime = 'application/json'
    formatter = Formatting(['json'])
    formatted = formatter.format_body(body, json_mime)
    print(formatted)
    #now convert formatted back to json
    extra_args = {
        'indent': 2
    }

# Generated at 2022-06-23 19:34:48.950931
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/plain")
    assert is_valid_mime("application/pdf")
    assert is_valid_mime("a/b")
    assert is_valid_mime("a/b/c") is False
    assert is_valid_mime("") is False

# Generated at 2022-06-23 19:34:51.062258
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['format', 'colors', 'colors']
    f = Formatting(groups)
    assert len(f.enabled_plugins) == 1

# Generated at 2022-06-23 19:34:56.991277
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import pytest

    from httpie.plugins import registry

    class TestFormatterPlugin(BaseFormatterPlugin):
        name = 'test'
        description = 'test'

        def format_body(self, body, mime):
            body = json.loads(body.replace('\'','"'))
            return json.dumps(body, sort_keys=True, indent=2)
          
    def mock_get_formatters():
        return TestFormatterPlugin

    registry.plugin_manager.get_formatters = mock_get_formatters
    registry.plugin_manager.enabled_plugins = None
    registry.load_plugins()

    groups = ["test"]
    kwargs = {}
    formatter = Formatting(groups=groups, **kwargs)
    print(formatter.enabled_plugins[0])
   

# Generated at 2022-06-23 19:35:06.635864
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """
    :return:
    """
    def test_valid_mime():
        """
        :return:
        """
        result = {"pass": 0, "fail": 0}
        data_set = [
            "text/html",
            "text/plain",
            "text/xml",
            "image/jpeg",
            "image/png"
        ]
        for mime in data_set:
            if is_valid_mime(mime):
                result["pass"] += 1
            else:
                result["fail"] += 1
                print("fail: %s" % mime)

        print("test_valid_mime: pass %d, fail %d" % (result["pass"], result["fail"]))


# Generated at 2022-06-23 19:35:09.977718
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.context import Environment
    env = Environment()
    fmt = Formatting(['colors'], env, style="monokai")
    assert fmt.enabled_plugins[0].__class__.__name__ == "ColorsFormatter"
    assert fmt.enabled_plugins[0].options['style'] == 'monokai'


# Generated at 2022-06-23 19:35:12.691866
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html") == True, "text/html is a valid MIME"
    assert is_valid_mime("invalid mime") == False, "invalid mime is not valid"

# Generated at 2022-06-23 19:35:13.780201
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime("text/html") == True



# Generated at 2022-06-23 19:35:16.935516
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print(Formatting(["colors"]).format_headers("""HTTP/1.1 200 OK
Content-Type: text/plain; charset=UTF-8
Connection: close

"""))



# Generated at 2022-06-23 19:35:23.442471
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    Test for method format_body of class Formatting
    :return:
    """
    content = '{"foo":"bar"}'
    mime = 'application/json'
    groups: List[str] = ['all']
    env = Environment()

    p = Formatting(groups, env=env)
    print(p.format_body(content, mime))

# Generated at 2022-06-23 19:35:25.324420
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter(mime="application/json")
    assert c.name == "json"

# Generated at 2022-06-23 19:35:32.133977
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors', 'format'], style='solarized')
    headers = b'Content-Type: text/html'
    assert f.format_headers(headers) == '\x1b[1mContent-Type\x1b[0m: \x1b[33mtext/html\x1b[0m'
    body = b'<html>blabla</html>'
    assert f.format_body(body, 'text/html') == '\n<html>\n blabla\n</html>'

# Generated at 2022-06-23 19:35:34.318426
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_instance = Conversion.get_converter(".txt")
    assert converter_instance is None

# Generated at 2022-06-23 19:35:35.287487
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(groups=['type'])

# Generated at 2022-06-23 19:35:40.278210
# Unit test for constructor of class Formatting
def test_Formatting():
    class DummyFmtPlugin:
        def __init__(self, env=Environment(), **kwargs):
            self.env = env
            self.enabled = False
        def format_headers(self, headers):
            return headers
        def format_body(self, content, mime):
            return content
    class Dummy:
        pass

    original_available_plugins = plugin_manager.get_formatters_grouped
    fmts = [
        ('group1', [DummyFmtPlugin]),
        ('group2', [DummyFmtPlugin]),
        ('group3', [DummyFmtPlugin])
    ]
    plugin_manager.get_formatters_grouped = lambda: Dummy()

# Generated at 2022-06-23 19:35:44.067969
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    res = Conversion.get_converter('application/json')
    res1 = Conversion.get_converter('text/xml')
    res2 = Conversion.get_converter('text')
    res3 = Conversion.get_converter(None)



# Generated at 2022-06-23 19:35:47.734338
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('') is False
    assert is_valid_mime(None) is False
    assert is_valid_mime('foo/bar') is True
    assert is_valid_mime('foo/bar+json') is True
    assert is_valid_mime('foo/bar+json/baz') is False

# Generated at 2022-06-23 19:35:58.788627
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/xml')
    assert is_valid_mime('text/plain')
    assert is_valid_mime('text/html')
    assert is_valid_mime('text/yaml')
    assert is_valid_mime('application/x-www-form-urlencoded')
    assert is_valid_mime('multipart/form-data')
    assert is_valid_mime('binary/octet-stream')
    assert is_valid_mime('text/css')
    assert is_valid_mime('text/javascript')

    assert not is_valid_mime('')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('/js')

# Generated at 2022-06-23 19:35:59.572877
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter('application/json') is not None


# Generated at 2022-06-23 19:36:08.714042
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(["color"])
    headers = (
        'HTTP/1.1 200 OK\r\n'
        'Content-Length: 0\r\n'
        'Set-Cookie: test1=test1; expires=Thu, 01 Jan 1970 00:00:00 GMT\r\n'
        'Set-Cookie: test2=test2; expires=Thu, 01 Jan 1970 00:00:00 GMT\r\n'
        'Set-Cookie: test3=test3; expires=Thu, 01 Jan 1970 00:00:00 GMT\r\n'
        'Set-Cookie: test4=test4; expires=Thu, 01 Jan 1970 00:00:00 GMT\r\n'
        '\r\n'
    ).encode()
    _headers = f.format_headers(headers)


# Generated at 2022-06-23 19:36:11.488906
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter1 = Conversion.get_converter('abc')
    assert converter1 == None
    converter2 = Conversion.get_converter('application/json')
    assert converter2.name == 'json'

# Generated at 2022-06-23 19:36:17.148740
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test case 1: format json response
    # input
    headers_str = '''HTTP/1.1 200 OK
Content-Type: application/json
Server: nginx/1.10.0 (Ubuntu)
Date: Thu, 24 Jul 2018 23:51:06 GMT
Content-Length: 382
Connection: keep-alive

'''
    instance = Formatting(['format'], env=Environment())
    res = instance.format_headers(headers_str)
    expected_res = headers_str
    assert res == expected_res

    # test case 2: format text response
    # input

# Generated at 2022-06-23 19:36:23.259842
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert not is_valid_mime('')
    assert not is_valid_mime('text')
    assert not is_valid_mime('text html')
    assert not is_valid_mime('text\\html')
    assert not is_valid_mime('text/html/plain')
    assert not is_valid_mime('///')

# Generated at 2022-06-23 19:36:26.297090
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('video/mp4')
    assert is_valid_mime('text/plain')
    assert not is_valid_mime('')
    assert not is_valid_mime('mp4')
    assert not is_valid_mime('text')
    assert not is_valid_mime('video/')

# Generated at 2022-06-23 19:36:27.909607
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['color']).enabled_plugins == []



# Generated at 2022-06-23 19:36:35.926700
# Unit test for constructor of class Conversion
def test_Conversion():
    print('Unit test for constructor of class Conversion')
    input_file = open('../test/f_input.txt', 'r')
    while True:
        line = input_file.readline()
        if not line:
            break
        if line[-1] == '\n':
            line = line[:-1]
        mime = line
        print('Testing ', mime)
        obj = Conversion.get_converter(mime)
        if obj is not None:
            file_path = '../test/f_input.txt'
            obj.convert(file_path)


# Generated at 2022-06-23 19:36:38.346333
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("text/html")
    assert converter is not None
    assert converter.mime == "text/html"


# Generated at 2022-06-23 19:36:40.909408
# Unit test for constructor of class Conversion
def test_Conversion():
    assert re.match('<class \'httpie.plugins.converter_greynoise.ConverterGreynoise\'>', str(Conversion.get_converter("application/json")))


# Generated at 2022-06-23 19:36:48.000213
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Create dummy class for testing purpose
    class DummyConverter:
        def __init__(self, mime):
            pass
        def supports(mime):
            return True
    # Test if get_converter methods return the correct dummy class
    result = Conversion.get_converter("text/plain")
    assert result.__class__ == DummyConverter
    # Test if get_converter methods return None when no converter is found
    result = Conversion.get_converter("text/fake")
    assert result == None


# Generated at 2022-06-23 19:36:51.920735
# Unit test for constructor of class Formatting
def test_Formatting():
    # the following call should not raise any exceptions
    Formatting(['redirect', 'headers'])


# Generated at 2022-06-23 19:36:54.261763
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    converter = Formatting(groups)
    vars(converter)
    converter.format_headers("")
    converter.format_body("", "")

# Generated at 2022-06-23 19:36:58.884925
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('/json')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)
    assert is_valid_mime('text/plain; charset=utf-8')


# Generated at 2022-06-23 19:37:03.237308
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = None
    mime = 'application/json'
    if is_valid_mime(mime):
        for converter_class in plugin_manager.get_converters():
            if converter_class.supports(mime):
                converter = converter_class(mime)
        print(converter)


# Generated at 2022-06-23 19:37:04.687514
# Unit test for constructor of class Conversion
def test_Conversion():
    cc = Conversion()
    print("The constructor of class Conversion : \n", cc)


# Generated at 2022-06-23 19:37:10.640240
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['test_plugin']
    env = Environment()
    kwargs = {'test_arg': 'test_val'}
    f = Formatting(groups, env, **kwargs)
    assert f is None

# Tests for the function is_valid_mime

# Generated at 2022-06-23 19:37:16.409003
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    environment = Environment()
    formatter = Formatting(groups=["json"], env=environment, color=True)
    content = '{"key":"value"}'
    mime = "application/json"
    result = formatter.format_body(content, mime)
    print(result)



# Generated at 2022-06-23 19:37:19.379398
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert is_valid_mime("text/plain")
    assert not is_valid_mime("text/plain/")
    assert not is_valid_mime("text")
    assert not is_valid_mime("")


# Generated at 2022-06-23 19:37:26.850316
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Initialize a Formatting object with a specified group
    f = Formatting(groups=['colors'])
    # Initialize a JSONConverter object
    json_converter = plugin_manager.get_converters()[2]('application/json')
    # Initialize a JSONConverter object
    csv_converter = plugin_manager.get_converters()[2]('text/csv')
    # Initialize a JSONConverter object
    xml_converter = plugin_manager.get_converters()[2]('text/xml')
    # Initialize a JSONConverter object
    yaml_converter = plugin_manager.get_converters()[2]('application/yaml')
    # Initialize a JSONConverter object
    form_converter = plugin_manager

# Generated at 2022-06-23 19:37:30.642871
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/javascript')
    assert is_valid_mime('application/hal+json')
    assert is_valid_mime('application/hal+json;utf-8')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application;charset=utf-8')

# Generated at 2022-06-23 19:37:36.361883
# Unit test for constructor of class Formatting
def test_Formatting():
    x = Formatting(groups=['colors'])
    assert x.enabled_plugins == [plugin_manager.get_formatters()['colors']]



# Generated at 2022-06-23 19:37:47.475708
# Unit test for constructor of class Formatting
def test_Formatting():
    # 1, empty list of groups
    group_list = []
    env = Environment()
    f = Formatting(group_list, env)
    assert (f.enabled_plugins == [])
    # 2, no displaying for plain formatter with empty body
    group_list = ['plain']
    env = Environment()
    f = Formatting(group_list, env)
    assert (f.enabled_plugins[0].format_body("", "application/json") == "")
    # 3, no displaying for plain formatter with text body
    group_list = ['plain']
    env = Environment()
    f = Formatting(group_list, env)
    assert (f.enabled_plugins[0].format_body("hello", "text/plain") == "hello")


# Generated at 2022-06-23 19:37:52.894822
# Unit test for constructor of class Formatting
def test_Formatting():
    out1 = Formatting(['colors'], env=Environment(), color=True, style='fancy')
    assert out1.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'
    out2 = Formatting(['colors'], env=Environment(), color=False, style='fancy')
    assert len(out2.enabled_plugins) == 0


# Generated at 2022-06-23 19:37:54.995000
# Unit test for constructor of class Conversion
def test_Conversion():
    print("\nTesting constructor of class Conversion()")
    c = Conversion()
    print(c)
    print("Conversion object created")


# Generated at 2022-06-23 19:37:59.257146
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    if get_converter('application/json').__class__.__name__ == 'JsonConverter':
        print('Conversion.get_converter() tested successfully')
    else:
        print('Conversion.get_converter() test failed')


# Generated at 2022-06-23 19:38:00.581090
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    cv = Conversion.get_converter(mime)
    assert cv is not None



# Generated at 2022-06-23 19:38:11.678146
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.output.base import format_json
    from httpie.output.formatters.colors import Base16Style, Solarized256Style
    from httpie.output.formatters.format import get_valid_json
    import json

    f = Formatting(["format"], output_options={"format": ["json"]})
    a = json.loads(f.format_body(
        '{"a": "b"}', "application/json"))
    b = json.loads(f.format_body(
        '{ "a": "b"}', "application/json"))
    c = json.loads(f.format_body(
        '{"a": "b","c": "d"}', "application/json"))

# Generated at 2022-06-23 19:38:17.128583
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    input = "abc:def\r\nghi:jkl"
    expected_output = "abc:def\r\nghi:jkl"
    groups = ['headers']
    kwargs = {'style': 'default'}
    formatting = Formatting(groups, **kwargs)
    output = formatting.format_headers(input)
    assert expected_output == output


# Generated at 2022-06-23 19:38:18.314336
# Unit test for constructor of class Conversion
def test_Conversion():
    conversion = Conversion('text/plain')
    assert conversion == None

# Generated at 2022-06-23 19:38:28.424833
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # mocha
    f = Formatting(['mocha'])
    h = "HTTP/1.1 200 OK\nContent-Length: 14\n\nHello, World!"
    assert f.format_headers(h) == "Headers:\nHTTP/1.1 200 OK\nContent-Length: 14\n"
    # linux
    f = Formatting(['linux'])
    assert f.format_headers(h) == "HTTP/1.1 200 OK\nContent-Length: 14"
    # solaris
    f = Formatting(['solaris'])
    assert f.format_headers(h) == "HTTP/1.1 200 OK\nContent-Length: 14\n"
    # windows
    f = Formatting(['windows'])

# Generated at 2022-06-23 19:38:33.079026
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/plain')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('')
    assert not is_valid_mime('text/plain/invalid')

# Generated at 2022-06-23 19:38:36.078354
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/xml')
    assert not is_valid_mime('./json')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:38:43.938816
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
  class FormatterPlugin_1:
    def __init__(self, env=Environment(), **kwargs):
      self.env = env
      self.enabled = False

    def format_headers(self, headers: str) -> str:
      return headers.replace('\r\n', '')

    def format_body(self, content: str, mime: str) -> str:
      return content

  class FormatterPlugin_2:
    def __init__(self, env=Environment(), **kwargs):
      self.env = env
      self.enabled = True

    def format_headers(self, headers: str) -> str:
      return headers + "abcd"

    def format_body(self, content: str, mime: str) -> str:
      return content


# Generated at 2022-06-23 19:38:47.363049
# Unit test for constructor of class Formatting
def test_Formatting():
    fm = Formatting([])
    assert fm
    fm = Formatting(["colors"])
    assert fm

# Generated at 2022-06-23 19:38:52.958054
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/json; charset=utf-8'), ConverterPlugin)
    assert not isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)


# Generated at 2022-06-23 19:39:00.342968
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # input string
    headers = "HTTP/1.1 200 OK\r\nDate: Sat, 8 Jul 2017 07:01:00 GMT\r\nServer: Apache/2.2.14 (Win32)\r\nLast-Modified: Sat, 8 Jul 2017 07:01:00 GMT\r\nContent-Length: 88\r\nContent-Type: text/html\r\nConnection: Closed"
    # expected output
    ans = headers
    # unit test
    output = Formatting(["headers"]).format_headers(headers)
    assert output == ans


# Generated at 2022-06-23 19:39:01.595907
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime("application/json")

# Generated at 2022-06-23 19:39:07.255042
# Unit test for constructor of class Conversion
def test_Conversion():
    con = Conversion.get_converter('app/json')
    assert con is not None
    assert is_valid_mime('app/json')
    assert is_valid_mime('app/xml')
    assert not is_valid_mime('app/jsonxml')
    assert not is_valid_mime('app/jason')

# Generated at 2022-06-23 19:39:08.755304
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter(mime='application/json')
    assert converter

# Generated at 2022-06-23 19:39:11.567779
# Unit test for constructor of class Conversion
def test_Conversion():
    assert isinstance(Conversion(), Conversion) # check if object is made
    assert hasattr(Conversion(), "get_converter") # check if it has method get_converter


# Generated at 2022-06-23 19:39:18.827407
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """Unit tests for method format_body of class Formatting."""
    config = dict()
    config["groups"] = ["JSON", "Pretty"]
    config["headers"] = ""
    config["pretty"] = "all"
    config["style"] = "default"


    # TODO: add more tests
    formatting = Formatting(**config)
    pretty_json_str = formatting.format_body(
        """{"yo": {"a": "b"}}""", "application/json")
    assert json.dumps(
        json.loads(pretty_json_str), indent=4, sort_keys=True) == pretty_json_str



# Generated at 2022-06-23 19:39:21.826595
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("json/text")
    assert not is_valid_mime("json/text ")
    assert not is_valid_mime("json/text/")
    assert not is_valid_mime("json//text")

# Generated at 2022-06-23 19:39:23.755874
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    s = Formatting(['colors'])
    assert s.format_body("api.com", "application/json") == "api.com"

# Generated at 2022-06-23 19:39:29.636280
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Create a list of headers, feed into format_headers, return the result
    # If nothing changed, return the same thing
    headers = ['a: b', 'c: d', 'e: f']
    env = Environment()
    fmt = Formatting(groups=['colorized'], env=env, stdin=None)
    assert fmt.format_headers(headers) == headers


# Generated at 2022-06-23 19:39:35.710742
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/json')
    assert not is_valid_mime('json')
    assert not is_valid_mime('')
    assert not is_valid_mime(' ')
    assert not is_valid_mime(None)
    assert not is_valid_mime('a')
    assert not is_valid_mime('/')
    assert not is_valid_mime('/a')
    assert not is_valid_mime('a/')

# Generated at 2022-06-23 19:39:45.895461
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in ['colors']:
        for cls in available_plugins[group]:
            p = cls(env=Environment(), **{})
            if p.enabled:
                enabled_plugins.append(p)

    headers = 'HTTP/1.1 200 OK\r\n'
    headers += 'Content-Type: application/json; charset=UTF-8\r\n'
    headers += 'Transfer-Encoding: chunked\r\n'
    headers += 'Date: Thu, 19 Feb 2015 15:51:19 GMT\r\n'
    headers += '\r\n'
    for p in enabled_plugins:
        headers = p.format_headers(headers)

# Generated at 2022-06-23 19:39:53.285699
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie import __version__
    from httpie.plugins.builtin import FormatterPlugin

    class plugin1(FormatterPlugin):
        def format_body(self, body, mime):
            return "plugin1 " + body

    class plugin2(FormatterPlugin):
        def format_body(self, body, mime):
            return "plugin2 " + body

    class plugin3(FormatterPlugin):
        def format_body(self, body, mime):
            return "plugin3 " + body

    plugin_manager = plugin.PluginManager()
    plugin_manager.register_plugin(plugin1())
    plugin_manager.register_plugin(plugin2())
    plugin_manager.register_plugin(plugin3())
    plugin_manager.load_installed_plugins()
    plugin_manager.enable_plugins(skip_installed=True)