

# Generated at 2022-06-23 19:30:01.636937
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    assert len(available_plugins) > 0

    env = Environment()
    groups = ['body', 'headers']
    formatting = Formatting(groups, env)
    #assert formatting.enabled_plugins is None
    #assert formatting.format_headers('headers') is None
    #assert formatting.format_body("content", "mime") is None

    # Ensure that all formatters in group 'body' are instantiated
    plugins = [p for p in available_plugins['body'] if p(env=env).enabled]
    assert len(formatting.enabled_plugins) == len(plugins)

    # Ensure that no formatters in group 'headers' are instantiated
    for p in available_plugins['headers']:
        assert p not in formatting.enabled_plugins


# Unit test

# Generated at 2022-06-23 19:30:07.214556
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_groups = ['colors']
    test_kwargs = {'colors': 'on'}
    test_body = '{"foo": "bar"}'
    test_mime = 'application/json'
    with open('test_formatting.json') as f:
        expected = f.read().splitlines()
    formatted = Formatting(test_groups, **test_kwargs).format_body(test_body, test_mime)
    formatted = formatted.splitlines()
    assert len(expected) == len(formatted)
    for e, f in zip(expected, formatted):
        assert e == f

# Generated at 2022-06-23 19:30:16.870904
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.compat import str
    
    groups = ['json',]
    env = Environment()
    json_data = '{"a":1,"b":2}'
    mime = 'application/json'

    # Create a Formating object
    formater = Formatting(groups=groups, env=env,)

    # Execute the method
    output = formater.format_body(json_data, mime)

    # Check the output type
    assert isinstance(output, str)
    # Check the output content
    assert '{\n    "a": 1,\n    "b": 2\n}' == output



# Generated at 2022-06-23 19:30:22.920134
# Unit test for constructor of class Conversion
def test_Conversion():
    pass
    # print('Conversion')
    # print(Conversion.get_converter('application/json'))
    # print(Conversion.get_converter('application/xml'))
    # print(Conversion.get_converter('text/csv'))
    # print(Conversion.get_converter('text/html'))
    # print(Conversion.get_converter('text/plain'))
    # print(Conversion.get_converter('text/xml'))
    # print(Conversion.get_converter('none/none'))


# Generated at 2022-06-23 19:30:28.319565
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'c=3\nHttp/1.1 200 OK\nContent-Type: application/json\n'
    expected_headers = 'Content-Type: application/json\n'
    f = Formatting(groups=['highlight'])
    assert f.format_headers(headers) == expected_headers



# Generated at 2022-06-23 19:30:30.046711
# Unit test for constructor of class Conversion
def test_Conversion():
    assert isinstance(Conversion.get_converter("json"), ConverterPlugin)


# Generated at 2022-06-23 19:30:35.952088
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/plain")
    assert is_valid_mime("text/csv")
    assert is_valid_mime("application/json")
    assert is_valid_mime("image/jpeg")
    assert is_valid_mime("application/xml")
    assert not is_valid_mime("text")
    assert not is_valid_mime(" ")
    assert not is_valid_mime("")
    assert not is_valid_mime("application/xlsx")

# Generated at 2022-06-23 19:30:37.884596
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    conversion = Conversion()
    converter = conversion.get_converter(mime)
    assert converter.supports(mime)


# Generated at 2022-06-23 19:30:40.713888
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(groups=["colors"])
    assert "colors" in [p.name for p in fmt.enabled_plugins]

# Generated at 2022-06-23 19:30:47.299163
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/html; charset=utf-8')
    assert is_valid_mime('text/plain')
    assert is_valid_mime('image/png; charset=utf-8')
    assert not is_valid_mime('text')
    assert not is_valid_mime('application')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('/json')
    assert not is_valid_mime('text/json/json')

# Generated at 2022-06-23 19:30:49.475963
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter("application/json")
    assert converter.mime == "application/json"


# Generated at 2022-06-23 19:30:52.066667
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('json') is None


# Generated at 2022-06-23 19:31:00.044270
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/plain") == True
    assert is_valid_mime("text/html") == True
    assert is_valid_mime("application/json") == True
    assert is_valid_mime("application/ld+json") == True
    assert is_valid_mime("application/vnd.api+json") == True
    assert is_valid_mime("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8") == False
    assert is_valid_mime("text/plain;charset=UTF-8") == True
    assert is_valid_mime("dummy_text/plain") == False


# Generated at 2022-06-23 19:31:02.366564
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.config['print_headers'] = True
    groups = ['Headers']
    headers = 'Content-Type: text/html\r\nTransfer-Encoding: chunked\r\n'
    obj = Formatting(groups, env=env)
    obj.format_headers(headers)

# Generated at 2022-06-23 19:31:12.694773
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.core import main
    from httpie.compat import (
        is_windows,
        is_py26,
        py26_version,
        py33_version,
        py34_version,
        py35_version,
        py27_version,
        py32_version,
    )

    args = ["--json", "http://httpbin.org/headers"]

    _, err, exit_status = main(args=args)
    if is_windows and is_py26:
        assert err == "stdout access blocked by raw_input"

# Generated at 2022-06-23 19:31:19.531010
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    #arrange
    content = '{"test": "1234"}'
    mime = 'application/json'
    groups = ['colors']

    #act
    formatter = Formatting(groups)
    res = formatter.format_body(content, mime)

    #assert
    assert(res == '{\n    \033[1m\033[94m"test"\033[39m\033[21m: \033[1m\033[94m"1234"\033[39m\033[21m\n}\n')

# Generated at 2022-06-23 19:31:21.034475
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').supports('application/json')



# Generated at 2022-06-23 19:31:27.870262
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/xml')
    assert is_valid_mime('text/html')
    assert is_valid_mime('text/plain')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)
    assert not is_valid_mime('invalid')

# Generated at 2022-06-23 19:31:33.004096
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter(''), type(None))
    assert isinstance(
        Conversion.get_converter('Not-a-valid-mime-string'.lower()), type(None))
    assert isinstance(Conversion.get_converter('application/json'.lower()),
                      ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/json'.upper()),
                      ConverterPlugin)



# Generated at 2022-06-23 19:31:41.930014
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_Conversion_get_converter_exception_if_none()
    test_Conversion_get_converter_exception_if_mime_format_not_correct()
    test_Conversion_get_converter_exception_if_mime_content_not_correct()
    test_Conversion_get_converter_exception_if_mime_is_correct_but_content_not_exist()
    test_Conversion_get_converter_format_json()
    test_Conversion_get_converter_format_html()
    test_Conversion_get_converter_format_text()
    test_Conversion_get_converter_format_image()
    test_Conversion_get_converter_format_mixed()


# Generated at 2022-06-23 19:31:45.759626
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['formatters-builtin'])
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-23 19:31:47.280143
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    env = Environment()
    assert Formatting(groups, env)

# Generated at 2022-06-23 19:31:51.917165
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    class FakeConverterPlugin(ConverterPlugin):
        name = 'name'
        description = 'desc'
        mime_types = ['mime']

    plugin_manager.register_converters(FakeConverterPlugin)
    assert Conversion.get_converter('mime').name == "name"
    assert Conversion.get_converter('mime').description == "desc"
    assert Conversion.get_converter('mime').mime_types == ['mime']


# Generated at 2022-06-23 19:31:54.570051
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('video/mp4') == True
    assert is_valid_mime('html') == False

# Generated at 2022-06-23 19:31:58.519373
# Unit test for constructor of class Conversion
def test_Conversion():
    # test if get converter will work correctly with valid and invalid mime type
    assert isinstance(Conversion.get_converter("*/*"), ConverterPlugin)
    assert Conversion.get_converter("<invalid type>%") == None


# Generated at 2022-06-23 19:32:06.237122
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.config['output']['formatted'] = True
    class JSONFormatter(object):
        def __init__(self, **kwargs):
            pass
    available_plugins = {
        'default': [
            JSONFormatter,
        ]
    }
    with mock.patch('httpie.plugins.registry.plugin_manager') as plugin_manager:
        plugin_manager.get_formatters_grouped.return_value = available_plugins
        f = Formatting(['default'], env)
        assert len(f.enabled_plugins) == 1

# Generated at 2022-06-23 19:32:07.840655
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt = Formatting(["PlainText"])
    assert fmt.format_headers("has headers") == "has headers"


# Generated at 2022-06-23 19:32:08.512501
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("test/test")
    assert converter is None

# Generated at 2022-06-23 19:32:09.030971
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()

# Generated at 2022-06-23 19:32:16.018732
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = 'This is a test.'
    mime = 'text/html'
    env = Environment()
    formatting = Formatting(['colors'], env=env, style='auto',
                            style_errors='auto', colors='auto',
                            color_scheme='auto')
    assert formatting.format_body(content, mime) == 'This is a test.'

    formatting = Formatting(['colors'], env=env, style='auto',
                            style_errors='auto', colors='always',
                            color_scheme='auto')
    assert formatting.format_body(content, mime) == '\x1b[37mThis \x1b[39mis a test.\x1b[39m'



# Generated at 2022-06-23 19:32:21.764413
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatter = Formatting(['colors'])
    headers = '''HTTP/1.1 200 OK
Date: Mon, 23 May 2005 22:38:34 GMT
Content-Type: text/html; charset=UTF-8
Content-Encoding: UTF-8
Last-Modified: Wed, 08 Jan 2003 23:11:55 GMT
Server: Apache/1.3.3.7 (Unix) (Red-Hat/Linux)
ETag: "3f80f-1b6-3e1cb03b"
Content-Length: 138
Accept-Ranges: bytes
Connection: close

<html>
<head>
  <title>An Example Page</title>
</head>
<body>
  <p>Hello World, this is a very simple HTML document.</p>
</body>
</html>
'''
   

# Generated at 2022-06-23 19:32:26.787329
# Unit test for constructor of class Formatting
def test_Formatting():

    class GenericPlugin:
        def __init__(self):
            self.enabled = True
            self.format_headers = self.format_body = lambda x: x

    class GenericPluginGroup:
        def get_formatters(self): return [GenericPlugin]

    plugin_manager.clear()
    plugin_manager.register(GenericPluginGroup)

    formatter = Formatting(['generic'], Environment())
    assert len(formatter.enabled_plugins) == 1



# Generated at 2022-06-23 19:32:38.521927
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format_text = 'HTTP/1.1 200 OK\r\nAccept: text/plain, */*; q=0.01\r\nAccept-Encoding: gzip, deflate, compress\r\nAccept-Language: en-us\r\nCache-Control: no-cache\r\nConnection: keep-alive\r\nContent-Length: 1\r\nContent-Type: text/plain; charset=utf-8\r\nDate: Sun, 22 Nov 2015 01:57:40 GMT\r\nPragma: no-cache\r\nServer: BaseHTTP/0.6 Python/3.4.3\r\n\r\n'
    formatted_text = Formatting(['colors-session']).format_headers(format_text)

# Generated at 2022-06-23 19:32:42.334306
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/plain').supports('text/plain')
    assert not Conversion.get_converter('text/html').supports('text/plain')
    assert not Conversion.get_converter('text/plain').supports('text/html')
    assert not Conversion.get_converter('text/plain').supports('')

# Generated at 2022-06-23 19:32:48.300294
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting([], Environment())
    assert not fmt.enabled_plugins
    fmt = Formatting(['colors', 'format'], Environment())
    assert len(fmt.enabled_plugins) == 5
    fmt = Formatting(['format'], Environment())
    assert len(fmt.enabled_plugins) == 3
    fmt = Formatting(['colors'], Environment())
    assert len(fmt.enabled_plugins) == 2

# Generated at 2022-06-23 19:32:50.240706
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime='application/json'
    print('MIME type:',mime)
    converter = Conversion.get_converter(mime)
    print('Converter:',converter)

if __name__ == '__main__':
    test_Conversion_get_converter()

# Generated at 2022-06-23 19:32:55.268027
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['JSON']
    env = Environment()
    kwargs = {}
    fmt = Formatting(groups, env, **kwargs)
    
    # For the format_headers function
    headers = 'test'
    assert fmt.format_headers(headers) == 'test'
    headers = 'test1, test2'
    assert fmt.format_headers(headers) == 'test1, test2'

    # For the format_body function
    content = '{"test": "test"}'
    mime = 'application/json'
    assert fmt.format_body(content, mime) == '{\n    "test": "test"\n}'
    mime = 'text/html'
    assert fmt.format_body(content, mime) == '{"test": "test"}'

# Generated at 2022-06-23 19:32:57.326019
# Unit test for constructor of class Formatting
def test_Formatting():
    f1 = Formatting(['pretty'])
    f2 = Formatting(['pretty'])
    assert(f1 == f2)



# Generated at 2022-06-23 19:32:58.945352
# Unit test for constructor of class Conversion
def test_Conversion():
    # Given
    converter = Conversion()
    converter.get_converter('image/png')

# Generated at 2022-06-23 19:33:01.844581
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    assert is_valid_mime("text/plain")
    assert not is_valid_mime("application/json/plain")
    assert not is_valid_mime("application//plain")

# Generated at 2022-06-23 19:33:04.828311
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('') is False
    assert is_valid_mime('a/b') is True
    assert is_valid_mime('application/json') is True
    assert is_valid_mime('application/json;foo=bar') is True



# Generated at 2022-06-23 19:33:13.460421
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatter
    from httpie.plugins.builtin import ColoredJSONFormatter
    from httpie.plugins.builtin import PrettyJSONFormatter
    from httpie.plugins.builtin import JSONStreamFormatter
    from httpie.plugins.builtin import JSONPointer
    import unittest
    import json

    # Test Case 1
    # Test Case 1.1
    # Test Case 1.2
    class Test_format_body1(unittest.TestCase):
        def setUp(self):
            self.e = Environment()
            self.jf = JSONFormatter(env=self.e)
            self.cjf = ColoredJSONFormatter(env=self.e)
            self.pjf = PrettyJSONFormatter(env=self.e)
            self.js

# Generated at 2022-06-23 19:33:22.918553
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print("Testing format_headers method of class Formatting")
    instance = Formatting(groups=['colors'],
                          env=Environment(),
                          style='solarized',
                          styles=True,
                          headers={'Content-Type': 'application/json'})
    # Getting a formatting plugin
    formatting_plugin = instance.enabled_plugins[0]
    # Basic test
    assert formatting_plugin.format_headers("HTTP/1.1 200 OK\nContent-Type: application/json\n\n") == '\x1b[38;5;33mHTTP/1.1 200 OK\x1b[0m\n\x1b[38;5;33mContent-Type: application/json\x1b[0m\n\n'
    # Test the fields not to be highlighted

# Generated at 2022-06-23 19:33:24.180905
# Unit test for constructor of class Conversion
def test_Conversion():
    assert isinstance(Conversion(), Conversion) is True

# Generated at 2022-06-23 19:33:28.058554
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter('image/jpg')
    assert converter is not None
    assert converter.supports('image/jpg')
    assert not converter.supports('image/png')


# Generated at 2022-06-23 19:33:28.911310
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter('application/json')

# Generated at 2022-06-23 19:33:32.581428
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.enabled, f'Converter not enabled'
    assert converter.is_binary, f'Converter is not a binary converter'
    assert converter.supports('application/json'), f'Converter does not support application/json'



# Generated at 2022-06-23 19:33:34.907668
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.prettify('{"foo":1}') == '{\n    "foo": 1\n}'



# Generated at 2022-06-23 19:33:38.215304
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter_class = Conversion.get_converter(mime)
    assert converter_class.mime == mime

    mime = 'application/xml'
    converter_class = Conversion.get_converter(mime)
    assert converter_class.mime == mime

# Generated at 2022-06-23 19:33:40.560608
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/plain")
    assert is_valid_mime("application/json")
    assert not is_valid_mime("text-plain")
    assert not is_valid_mime("text/plain/")

# Generated at 2022-06-23 19:33:41.686079
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("text/html")
    assert converter is None

# Generated at 2022-06-23 19:33:48.068132
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ["colors", "colors_256", "colors_16", "colors_8", "colors_bw"]
    format_obj = Formatting(groups)
    headers = "HTTP/1.1 200 OK\r\nDate: Fri, 06 Apr 2018 06:24:57 GMT\r\nContent-Type: application/json; charset=utf-8\r\nTransfer-Encoding: chunked\r\nServer: Web-Server/1.1\r\nX-Powered-By: PHP/7.1.12"

# Generated at 2022-06-23 19:33:51.772090
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatters = Formatting(['colors'])
    test_headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json'
    new_headers = formatters.format_headers(test_headers)
    assert new_headers != test_headers

# Generated at 2022-06-23 19:34:00.905853
# Unit test for constructor of class Formatting
def test_Formatting():
    # Case 1:
    #Test case for giving empty groups parameter
    groups=[]
    format = Formatting(groups)
    assert format.enabled_plugins == []
    # Case 2:
    # Test case for giving all available processor groups
    groups=["JSON","JSONPath","Python","XML","CSS","HTML","Java","JsonLines","Javascript"]
    format = Formatting(groups)
    assert format.enabled_plugins != []
    # Case 3:
    # Test case for giving only few available processor groups
    groups=["JSON","JSONPath","Python"]
    format = Formatting(groups)
    assert format.enabled_plugins != []


# Generated at 2022-06-23 19:34:02.689758
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html')

    assert not Conversion.get_converter('foo/bar')

# Generated at 2022-06-23 19:34:06.094512
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case when we have a valid mime type
    mime1='application/json'
    converter1=Conversion.get_converter(mime1)
    assert converter1
    # Test case when mime is not valid
    mime2='json'
    converter2=Conversion.get_converter(mime2)
    assert converter2 is None



# Generated at 2022-06-23 19:34:12.997720
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html")
    assert is_valid_mime("text/html; charset=utf8")
    assert is_valid_mime("text/html, text/xml")
    assert not is_valid_mime("")
    assert not is_valid_mime("text/html;")
    assert not is_valid_mime("/html")
    assert not is_valid_mime("text/")

# Generated at 2022-06-23 19:34:15.710005
# Unit test for constructor of class Conversion
def test_Conversion():
    try:
        Conversion().get_converter(None)
    except:
        assert 0
    else:
        assert 1
    try:
        Conversion().get_converter('not_valid_mime')
    except:
        assert 0
    else:
        assert 1

# Generated at 2022-06-23 19:34:21.753951
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(['color'])
    Formatting(['color', 'format'])
    Formatting(['color', 'format'],
               kwargs=dict(style='foo',
                           colors={'status': 'red'}))
    Formatting(['color', 'format'],
               env=Environment(),
               kwargs=dict(style='foo',
                           colors={'status': 'red'}))

# Generated at 2022-06-23 19:34:25.291518
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.formatting import CLI_FORMATTERS
    from httpie.context import Environment
    formatting = Formatting(CLI_FORMATTERS, Environment())
    assert formatting.__class__ == Formatting


# Generated at 2022-06-23 19:34:28.893229
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    result = Conversion.get_converter("application/x-www-form-urlencoded")
    assert result is not None
    assert result.mime == "application/x-www-form-urlencoded"


# Generated at 2022-06-23 19:34:37.479142
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.context import Environment
    from httpie.plugins.builtin import Formatter
    from httpie.plugins.builtin import JSONFormatter
    env = Environment(colors=True)
    f = Formatting(groups=['formatter'], env=env)
    assert isinstance(f.enabled_plugins[0], Formatter)

    f = Formatting(groups=['formatter', 'json'], env=env)
    assert isinstance(f.enabled_plugins[0], Formatter)
    assert isinstance(f.enabled_plugins[1], JSONFormatter)

# Generated at 2022-06-23 19:34:44.228652
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['total_body']
    mime = 'application/json'
    env = Environment()
    content = '[{"a":1,"b":2},{"a":3,"b":4}]'
    plugin = Formatting(groups, env=env,indent=2)
    assert plugin.format_body(content,mime) == '[\n  {\n    "a": 1,\n    "b": 2\n  },\n  {\n    "a": 3,\n    "b": 4\n  }\n]'


# Generated at 2022-06-23 19:34:50.767549
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    format = Formatting(['color'], env, )
    format.format_headers("""Content-Length: 200
Content-Type: application/json""")
    assert format.format_headers("""Content-Length: 200
Content-Type: application/json""") == """Content-Length: 200\x1b[39m
\x1b[1m\x1b[33mContent-Type: \x1b[39m\x1b[1m\x1b[36mapplication/json\x1b[39m"""

# Generated at 2022-06-23 19:34:52.697740
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/plain')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('text')
    assert not is_valid_mime('something/something')

# Generated at 2022-06-23 19:34:57.587873
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert (b"Hello World") == Formatting([]).format_body(b"Hello World", "*/*")
    assert (b"Hello World") == Formatting([],
                                           is_json=True,
                                           is_json_pp=True,
                                           is_json_seq=True,
                                           json_indent="3",
                                           json_sort_keys=True).format_body(
        '[{"n": 1}, {"n": 2}, {"n": 3}]',
        "application/json")
    assert (b"Hello World") == Formatting([], is_debug=True).format_body(b"Hello World", "*/*")
    assert (b"Hello World") == Formatting([]).format_body(b"Hello World", "text/plain")

# Generated at 2022-06-23 19:35:01.209945
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html") is True
    assert is_valid_mime("txt/html") is False
    assert is_valid_mime("text/") is False
    assert is_valid_mime("/html") is False

# Generated at 2022-06-23 19:35:07.433069
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in ['json', 'colors', 'format', 'colors']:
        for cls in available_plugins[group]:
            p = cls(env=Environment(), format='json')
            if p.enabled:
                enabled_plugins.append(p)

    content_input = '{"a": "hello", "b": "123", "c": [{"c1": "world"}, {"c2": "456"}], "d": true}'
    mime = 'application/json; charset=UTF-8'
    for p in enabled_plugins:
        content_input = p.format_body(content_input, mime)

# Generated at 2022-06-23 19:35:10.062906
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text')

    # check if the method returns None for invalid mime
    assert converter is None

    converter = Conversion.get_converter('image/png')
    assert converter is not None



# Generated at 2022-06-23 19:35:13.060264
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert(str(type(Conversion.get_converter("application/json"))) == "<class 'httpie.plugins.builtin.JSONConverter'>")
    assert(Conversion.get_converter("json") is None)


# Generated at 2022-06-23 19:35:18.810078
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('font/woff')
    assert str(converter) == '<httpie.plugins.converters.font.woff.FontWoffToOtfc object at 0x7f06488c52b0>'
    assert converter.mime == 'font/woff'
    assert str(converter.supported(converter.mime)) == 'NoneType'


# Generated at 2022-06-23 19:35:21.649056
# Unit test for constructor of class Conversion
def test_Conversion():
    assert(Conversion.get_converter("text/html") is None)


# Generated at 2022-06-23 19:35:25.692764
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # The situation that no formatter is applied
    groups = []
    f = Formatting(groups)
    origin = "test"
    mime = "text/plain"
    assert origin == f.format_body(origin, mime)

    # The situation that formatter is applied
    groups = ['json']
    f = Formatting(groups)
    origin = '{"key1":"value1","key2":"value2","key3":"value3"}'
    mime = "application/json"
    assert origin != f.format_body(origin, mime)

# Generated at 2022-06-23 19:35:28.087473
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=[], env=Environment())
    assert f.format_headers("foo:bar\n") == "foo:bar\n"



# Generated at 2022-06-23 19:35:38.247453
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    s = Formatting(['colors'], colors=True)
    input = '200 OK'
    expected = '200 OK'
    assert s.format_headers(input) == expected

    input = 'Content-Length: 124'
    expected = 'Content-Length: 124'
    assert s.format_headers(input) == expected

    input = 'Status: 400 Bad Request'
    expected = 'Status: 400 Bad Request'
    assert s.format_headers(input) == expected

    input = 'Content-Type: application/json'
    expected = 'Content-Type: application/json'
    assert s.format_headers(input) == expected

    input = 'X-API-Key: 1234567'
    expected = 'X-API-Key: 1234567'
    assert s.format_headers(input) == expected

#

# Generated at 2022-06-23 19:35:43.223744
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application/xml') == True
    assert is_valid_mime('application.json') == False
    assert is_valid_mime('application') == False


# Generated at 2022-06-23 19:35:46.900302
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    plugins = Formatting(["colors"], env=Environment())
    first_plugin_name = plugins.enabled_plugins[0].name
    # TODO: improve to iterate over plugins by names
    assert first_plugin_name in available_plugins["colors"]

# Generated at 2022-06-23 19:35:48.600286
# Unit test for constructor of class Formatting
def test_Formatting():
    output = [p for p in Formatting([], None).enabled_plugins]
    assert len(output) == 0


# Generated at 2022-06-23 19:35:57.296331
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # env is not necessary, so we initialize it as Environment()
    env = Environment()
    # instance of class Formatting
    f = Formatting(['colors'], env=env)
    print("Test format_body")
    # The following is a JSON
    content = '{"info":"httpie is a CLI, cURL-like tool for humans\n","status":true}'
    mime = 'application/json'
    result = f.format_body(content, mime)
    # The method format_body adds color to the content
    print("Result: " + result)



# Generated at 2022-06-23 19:36:01.401567
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_cases = [
        ("unknown", None),
        ("text/plain", None),
        ("application/json", str)
    ]
    for test_case in test_cases:
        env = Environment()
        assert Conversion.get_converter(test_case[0]) == test_case[1]

# Generated at 2022-06-23 19:36:04.011193
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    fm = Formatting(groups=["colors"], env=env)
    assert fm.enabled_plugins[0].mime_type == "application/json"

# Generated at 2022-06-23 19:36:06.017194
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()
    assert c.get_converter('application/json') is not None


# Generated at 2022-06-23 19:36:07.186915
# Unit test for constructor of class Conversion
def test_Conversion():
   assert Conversion.__init__() != None


# Generated at 2022-06-23 19:36:09.343361
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    actual = Conversion.get_converter('application/json')
    expected = 'application/json'
    assert actual.mime == expected
    
    

# Generated at 2022-06-23 19:36:13.023018
# Unit test for function is_valid_mime
def test_is_valid_mime():
    from unittest import TestCase, main
    class TestIsValidMime(TestCase):
        def test_valid_mime(self):
            self.assertTrue(is_valid_mime('application/json'))

        def test_invalid_mime(self):
            self.assertFalse(is_valid_mime('application'))

    main()

# Generated at 2022-06-23 19:36:19.267214
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # test raw output
    groups = ['JSON']
    env = Environment()
    string = '{"id": 1, "name": "movie"}'
    mime = 'application/json'
    formatting = Formatting(groups, env)
    content = formatting.format_body(string, mime)
    assert content == '{\n', 'output of formatting.format_body is wrong'

# Generated at 2022-06-23 19:36:28.342918
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime("application/javascript") == True
    assert is_valid_mime("application/json") == True
    assert is_valid_mime("application/css") == True
    assert is_valid_mime("application/xml") == True
    assert is_valid_mime("application/x-www-form-urlencoded") == True
    assert is_valid_mime("text/xml") == True
    assert is_valid_mime("text/css") == True
    assert is_valid_mime("text/html") == True
    assert is_valid_mime("text/javascript") == True
    assert is_valid_mime("text/plain") == True
    assert is_valid_mime("text/csv") == False

# Generated at 2022-06-23 19:36:30.723128
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    p = Formatting(env=env)
    print(p)

if __name__=="__main__":
    test_Formatting()

# Generated at 2022-06-23 19:36:35.879188
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion.get_converter("text/plain")
    assert c is None
    c2 = Conversion.get_converter(None)
    assert c2 is None
    c3 = Conversion.get_converter("application/json")
    assert c3 is not None

# Unit tests for constructor of class Formatting

# Generated at 2022-06-23 19:36:37.289237
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print(Conversion.get_converter('application/json'))


# Generated at 2022-06-23 19:36:46.714090
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie import ExitStatus

    exit_status = ExitStatus()

# Generated at 2022-06-23 19:36:52.081831
# Unit test for constructor of class Conversion
def test_Conversion():
    conversion = Conversion.get_converter("application/json")
    assert conversion.mime_type == "application/json"



# Generated at 2022-06-23 19:36:53.718305
# Unit test for constructor of class Conversion
def test_Conversion():
    assert isinstance(Conversion, object)
    assert hasattr(Conversion, '__init__')


# Generated at 2022-06-23 19:36:57.714893
# Unit test for constructor of class Formatting
def test_Formatting():
    data = Formatting(['colors'])
    assert data is not None


# Generated at 2022-06-23 19:37:06.211900
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.core import main
    from httpie.output import BINARY_SUPPRESSED_NOTICE
    result = main(args=[
        '--verbose',
        '--print', 'B',
        '--headers',
        'GET', 'https://httpbin.org/headers'
    ])
    assert result == ExitStatus.OK, result.stderr

# Generated at 2022-06-23 19:37:10.591283
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    a = Formatting(groups = ["name"])
    content = "Content to be formatted"
    mime = "text/plain"
    assert a.format_body(content, mime) == "This is to be formatted"


# Generated at 2022-06-23 19:37:17.148611
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    rst_converter = Conversion.get_converter(mime='text/rst')
    assert rst_converter.mime == 'text/rst'

    md_converter = Conversion.get_converter(mime='text/md')
    assert md_converter is None


# Unit tests for methods of class Formatting

# Generated at 2022-06-23 19:37:21.662397
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors'])
    print (fmt.enabled_plugins[0])
    print (fmt.format_headers('header-name: header-value'))
    print (fmt.format_headers('header-name: header-value'))
    print (fmt.format_headers('header-name: header-value'))


# Generated at 2022-06-23 19:37:28.041570
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "application/json"
    expected = "httpie.plugins.converter.JSONConverter"
    assert type(Conversion.get_converter(mime)).__name__ == expected

    mime = "application/xml"
    expected = "httpie.plugins.converter.JSONConverter"
    assert type(Conversion.get_converter(mime)).__name__ == expected

    mime = "application/unknown"
    assert Conversion.get_converter(mime) is None

# Generated at 2022-06-23 19:37:36.924811
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '{"a": "b"}'
    mime = 'application/json'
    cls = Formatting(['colors'])
    result = cls.format_body(content, mime)
    assert result == '\x1b[38;5;244m{\x1b[39m\x1b[38;5;254m"a"\x1b[39m\x1b[38;5;244m:\x1b[39m\x1b[38;5;250m \x1b[39m\x1b[38;5;201m"b"\x1b[39m\x1b[38;5;244m}\x1b[39m'



# Generated at 2022-06-23 19:37:44.761089
# Unit test for function is_valid_mime
def test_is_valid_mime():
    mime = 'text/plain'
    assert is_valid_mime(mime) == True
    mime = 'text/'
    assert is_valid_mime(mime) == False
    mime = 'text/plain_plus'
    assert is_valid_mime(mime) == False
    mime = ''
    assert is_valid_mime(mime) == False
    mime = None
    assert is_valid_mime(mime) == False

# Generated at 2022-06-23 19:37:56.142828
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import pytest
    # No formatters available
    formatting = Formatting([])
    headers = formatting.format_headers('test')
    assert headers == 'test'

    # Only 'colors' formatter available
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import Colors

    dummy_class = type(
        'DummyFormatter',
        (),
        dict(
            supports=FormatterPlugin.supports,
            enabled=False,
            format_headers=FormatterPlugin.format_headers
        )
    )
    Colors.enabled = True
    system_plugins_dict = plugin_manager.system_plugins.copy()
    plugin_manager._system_plugins = {
        'dummy': dummy_class,
        'colors': Colors
    }

# Generated at 2022-06-23 19:38:03.436566
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert is_valid_mime('text/plain')
    assert is_valid_mime('text/xml+atom')
    assert not is_valid_mime('text')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('text?')

    assert not is_valid_mime(None)
    assert not is_valid_mime('')

    assert Conversion.get_converter('text/plain')
    assert Conversion.get_converter('text/html')
    assert not Conversion.get_converter('text/invalid')

# Generated at 2022-06-23 19:38:05.297302
# Unit test for constructor of class Formatting
def test_Formatting():
    fm = Formatting(["json"], env=Environment())
    assert fm.enabled_plugins

# Generated at 2022-06-23 19:38:16.290487
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-23 19:38:18.684391
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors','format']
    env = {'colors': True, 'format': 'all'}
    assert len(Formatting(groups, env).enabled_plugins) == 2

# Generated at 2022-06-23 19:38:19.201119
# Unit test for constructor of class Formatting
def test_Formatting():
    pass

# Generated at 2022-06-23 19:38:23.219936
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert converter is not None
    assert converter.mime == 'application/json'


if __name__ == "__main__":
    test_Conversion_get_converter()

# Generated at 2022-06-23 19:38:29.392093
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    converter = Conversion()
    formatter = Formatting(["html", "colours"], env=Environment())
    converted = converter.get_converter("application/json")
    formatted = formatter.format_body(converted.encode({"a": "b"}), mime="application/json")
    assert formatted == "<div class='json'>\n<div class='json_key'>\"a\"</div><div class='json_value'>:\"b\"</div>\n</div>\n"

# Generated at 2022-06-23 19:38:35.572919
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter('x-www-form-urlencoded')
    assert converter.supports('application/x-www-form-urlencoded')
    assert not converter.supports('multipart/form-data')
    assert converter.supports('application/x-www-form-urlencoded')
    converter.convert('a=1')


# Generated at 2022-06-23 19:38:38.588133
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_class = plugin_manager.get_converters()[1]
    converter = converter_class('image/jpeg')
    assert converter


# Generated at 2022-06-23 19:38:41.072804
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html') == True
    assert is_valid_mime('html') == False
    assert is_valid_mime('') == False

# Generated at 2022-06-23 19:38:45.832498
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('image/jpeg')
    assert is_valid_mime('application/json')

    assert not is_valid_mime('image/jpeg/')
    assert not is_valid_mime('/image/jpeg')
    assert not is_valid_mime('image/jpeg/example')
    assert not is_valid_mime('image//example')
    assert not is_valid_mime('image/')
    assert not is_valid_mime('/')

# Generated at 2022-06-23 19:38:55.534096
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.models import Headers
    from httpie.output.streams import StdoutStreaReadm
    from httpie.context import Environment

    env = Environment(stream=StdoutStream())
    headers = Headers(env=env, headers=[('header1', 'value1')])

    for group in plugin_manager.get_formatters_grouped():
        formatting = Formatting(groups=[group], env=env)
        print(group)
        print(formatting.format_headers(str(headers)))
        print()


if __name__ == '__main__':
    test_Formatting_format_headers()

# Generated at 2022-06-23 19:38:59.885879
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/plain')
    assert not is_valid_mime('')
    assert not is_valid_mime('/')
    assert not is_valid_mime('/text/plain')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:39:11.350359
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # convert to/from text
    converter = Conversion.get_converter('application/octet-stream')
    assert converter.supports('text/plain')
    assert not converter.supports('image/png')

    # convert to/from JSON
    converter = Conversion.get_converter('application/json')
    assert converter.supports('text/plain')
    assert converter.supports('application/xml')
    assert not converter.supports('application/json')

    # convert to/from JSON
    converter = Conversion.get_converter('application/xml')
    assert converter.supports('text/plain')
    assert converter.supports('application/json')
    assert not converter.supports('application/xml')

    # convert to/from JSON
    converter = Conversion.get_converter('text/html')
   

# Generated at 2022-06-23 19:39:15.803791
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # test case 1:
    assert is_valid_mime('json') is False
    assert isinstance(Conversion.get_converter('json'), type(None))

    # test case 2:
    assert is_valid_mime('application/json') is True
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)

# Generated at 2022-06-23 19:39:16.906886
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()
    assert isinstance(c, Conversion)

# Generated at 2022-06-23 19:39:21.699790
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    # JSON
    Formatting(groups=["MIME"], env=Environment()).format_body(content='{"name":"John Smith","age":33}', mime="application/json")

    # HTML
    Formatting(groups=["MIME"], env=Environment()).format_body(content="<!DOCTYPE html><html><body><h1>My First Heading</h1><p>My first paragraph.</p></body></html>", mime="text/html")

    # Text
    Formatting(groups=["MIME"], env=Environment()).format_body(content="text", mime="text/plain")

# Generated at 2022-06-23 19:39:29.762599
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Case 1: text/plain
    result = Formatting.format_body(content="body", mime="text/plain")
    assert (result == "body"), "failed"
    # Case 2: text/html
    result = Formatting.format_body(content="<html><body><p>body</p></body></html>", mime="text/html")
    assert (result == "<html><body><p>body</p></body></html>"), "failed"
    # Case 3: text/xml
    result = Formatting.format_body(content="<root><a>a</a><b>b</b><root>", mime="text/xml")
    assert (result == "<root><a>a</a><b>b</b><root>"), "failed"
    # Case 4: application/json

# Generated at 2022-06-23 19:39:34.565772
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class txt(ConverterPlugin):
        @staticmethod
        def supports(mime):
            return mime == 'text/plain'

        def __init__(self, mime='text/plain'):
            self.mime = mime
    class json(ConverterPlugin):
        @staticmethod
        def supports(mime):
            return mime == 'application/json'

        def __init__(self, mime='application/json'):
            self.mime = mime

    from httpie.plugins.converters.json import JSONConverter
    from httpie.plugins.converters.xml import XMLConverter
    from httpie.plugins.converters.yaml import YAMLConverter
    from httpie.plugins.converters.html import HTMLConverter

    assert Format

# Generated at 2022-06-23 19:39:44.827416
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print('test Formatting.format_headers()')
    fm = Formatting(['colors'])

# Generated at 2022-06-23 19:39:47.542737
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["colors"]
    keywords = {"nonexist": "123"}
    env = Environment()
    f = Formatting(groups, env, **keywords)
    assert not f.enabled_plugins

# Generated at 2022-06-23 19:39:52.994591
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.config['colors'] = True
    env.config['headers'] = 'always'

    fmt = Formatting(['Colors'], env=env)
    fmt.format_headers('content-type: text/json\nx-color: red')
    assert fmt.format_headers('content-type: text/json\nx-color: red') == '\x1b[33mcontent-type\x1b[39m: text/json\n\x1b[33mx-color\x1b[39m: red'

# Generated at 2022-06-23 19:39:57.079172
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment(
        output_options=AttrDict({
            'format': 'colors',
        })
    )
    fm = Formatting(['format'], env=env)
    r = fm.format_body("""
{'a': 'b'}
""".strip(), 'application/json')
    assert r == """
{
    \x1b[32m"a"\x1b[39m: \x1b[32m"b"\x1b[39m
}
""".strip()