

# Generated at 2022-06-23 19:29:52.433689
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("") == False
    assert is_valid_mime("/") == False
    assert is_valid_mime("application/json") == True
    assert is_valid_mime("application/json/") == False

# Generated at 2022-06-23 19:29:55.827445
# Unit test for constructor of class Conversion
def test_Conversion():
    fmt = Conversion('json, syntax')
    assert(len(fmt.enabled_plugins) > 0)


# Generated at 2022-06-23 19:30:05.126677
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    h = Formatting([], env=Environment())
    assert h.format_headers("""
{
  "k": "v"
}""") == """
{
  "k": "v"
}""", "Formatting.format_headers did not remove anything"
    h = Formatting(["none"], env=Environment())
    assert h.format_headers("""
{
  "k": "v"
}""") == """
{
  "k": "v"
}""", "Formatting.format_headers did not remove anything"
    h = Formatting(["group:all"], env=Environment())
    assert h.format_headers("""
{
  "k": "v"
}""") == """
{
  "k": "v"
}""", "Formatting.format_headers did not remove anything"
   

# Generated at 2022-06-23 19:30:11.083316
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    inputJson = '{ "name" : "jason" }'
    inputXml = '<root>test</root>'
    expectedJson = '{"name": "jason"}'
    expectedXml = '<root>test</root>'

    groups = ['format_pretty']
    actualJson = Formatting(groups).format_body(inputJson, 'application/json')
    actualXml = Formatting(groups).format_body(inputXml, 'application/xml')
    assert expectedJson == actualJson
    assert expectedXml == actualXml

# Generated at 2022-06-23 19:30:20.736917
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import (
        HTTPieJSONFormatter,
        HTTPiePrettyFormatter,
        HTTPieColorsFormatter,
    )
    from httpie.core import plugin_manager
    from httpie.context import Environment
    environment = Environment()
    # Default format is pretty
    environment.preferences.default_options['--format'] = "pretty"
    httpie_formatter_plugins = [
        HTTPieJSONFormatter,
        HTTPiePrettyFormatter,
        HTTPieColorsFormatter,
    ]
    plugin_manager.prepend_formatters(httpie_formatter_plugins=httpie_formatter_plugins)
    test_formatting = Formatting(groups=['builtin'], env=environment)
    env = Environment()

# Generated at 2022-06-23 19:30:26.537035
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_content = '{"Just":"a","test":{"foo":"bar"}}'
    output = Formatting(['format', 'colors', 'colors_auto']).format_body(test_content, "application/json")
    assert output == '{\n    "Just": "a",\n    "test": {\n        "foo": "bar"\n    }\n}'

# Generated at 2022-06-23 19:30:29.192007
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter("text/csv")
    assert converter.supports("text/csv")
    assert converter.can_prettify()


# Generated at 2022-06-23 19:30:35.541789
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test case 1: returns the same headers if no plugins are enabled
    groups = []
    f = Formatting(groups)
    assert f.format_headers("") == ""
    assert f.format_headers("a:b") == "a:b"
    assert f.format_headers("a:b\nc:d") == "a:b\nc:d"
    assert f.format_headers("a:b\nc:d\n\ne:f") == "a:b\nc:d\n\ne:f"



# Generated at 2022-06-23 19:30:43.941856
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.output.streams import stdout
    from httpie.context import Environment
    groups = ['colors', 'format']
    kwargs = {'stream': stdout}
    f = Formatting(groups, env=Environment(), **kwargs)
    f.format_headers('HTTP/1.1 200 OK')
    print('===================')
    f.format_headers('Content-Length: 6')
    print('===================')
    f.format_headers('Server: nginx/1.2.1')
    print('===================')
    f.format_heade

# Generated at 2022-06-23 19:30:47.065834
# Unit test for constructor of class Formatting
def test_Formatting():
    """
    >>> f = Formatting(groups=["formatters"])
    >>> f.enabled_plugins
    >>> f.format_headers("hi")
    'hi'
    >>> f.format_body("hey", "text/html")
    'hey'

    """

# Generated at 2022-06-23 19:30:56.982559
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatter = Formatting([])
    headers = '''HTTP/1.1 200 OK
Content-Type: application/octet-stream
Content-Language: en-US
ETag: W/"c0-X9e9BU6zAm3qUZP6UjpPa6kf1k"
Last-Modified: Wed, 09 Sep 2020 21:15:11 GMT
Content-Length: 131072
Connection: keep-alive
Accept-Ranges: bytes
Server: nginx
Age: 58
Cache-Control: public
Expires: Thu, 10 Sep 2020 11:34:05 GMT
Date: Thu, 10 Sep 2020 11:15:05 GMT

'''
    formatter.format_headers(headers) == headers
    formatter = Formatting(['colors'])

# Generated at 2022-06-23 19:30:57.783881
# Unit test for constructor of class Formatting
def test_Formatting():
    assert NotImplementedError, Formatting()

# Generated at 2022-06-23 19:30:59.672770
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application/json/json')
    assert not is_valid_mime('application')

# Generated at 2022-06-23 19:31:01.705601
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    '''
    Test that make sure that the method format_body works properly
    '''
    formatting=Formatting(groups=[])
    content='<html></html>'
    mime='text/html'
    ans=formattin

# Generated at 2022-06-23 19:31:03.749245
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')
    assert not Conversion.get_converter('not/valid')



# Generated at 2022-06-23 19:31:07.219409
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application/json/') == False
    assert is_valid_mime('/json') == False
    assert is_valid_mime('') == False

# Generated at 2022-06-23 19:31:09.307205
# Unit test for constructor of class Formatting
def test_Formatting():
    formats = Formatting(groups=['format'])
    assert formats.enabled_plugins[0].name == 'format'

# Generated at 2022-06-23 19:31:17.514303
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # import unittest
    # class TestConverter(unittest.TestCase):
    #     def test_Conversion_get_converter(self):
        assert isinstance(Conversion.get_converter("image/jpg"), ConverterPlugin)
        assert not isinstance(Conversion.get_converter("image/jpg"), JsonConverter)
        assert isinstance(Conversion.get_converter("application/json"), JsonConverter)
        assert not isinstance(Conversion.get_converter("application/json"), ConverterPlugin)



# Generated at 2022-06-23 19:31:18.928897
# Unit test for constructor of class Conversion
def test_Conversion():
    conversion = Conversion
    assert isinstance(conversion, type)


# Generated at 2022-06-23 19:31:26.296075
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-23 19:31:27.661053
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter("image/jpeg")
    assert c.__class__.__name__ == "ImageConverter"

# Generated at 2022-06-23 19:31:33.900001
# Unit test for constructor of class Conversion
def test_Conversion():
    print("Unit test for constructor of class Conversion")
    if is_valid_mime('mime'):
        print("Test 1 of 3: failed")
    else:
        print("Test 1 of 3: passed")

    if is_valid_mime('application/json'):
        print("Test 2 of 3: passed")
    else:
        print("Test 2 of 3: failed")

    if is_valid_mime('application/json;charset=UTF-8'):
        print("Test 3 of 3: failed")
    else:
        print("Test 3 of 3: passed")



# Generated at 2022-06-23 19:31:42.769371
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # 1.1. Test formatting of general headers
    assert Formatting([]).format_headers("""HTTP/1.1 200 OK
    Host: 127.0.0.1
    User-Agent: HTTPie/0.9.8
    Connection: keep-alive
    Accept-Encoding: gzip, deflate, compress
    Accept: */*
    Content-Type: text/plain""") == """HTTP/1.1 200 OK
Host: 127.0.0.1
User-Agent: HTTPie/0.9.8
Connection: keep-alive
Accept-Encoding: gzip, deflate, compress
Accept: */*
Content-Type: text/plain"""

    # 1.2. Test formatting of status headers

# Generated at 2022-06-23 19:31:48.781445
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    environments = {"colors": False, "style": None, "format": None, "print_body_only": False}
    plugins = {"colors": False, "style": None, "format": None, "print_body_only": False}

    # Default
    formatter = Formatting(groups=['colors'], env=environments, **plugins)
    assert formatter != None

    # Default
    formatter = Formatting(groups=['colors'], env=environments, **plugins)
    assert formatter.format_headers("") == ""

    # Default
    formatter = Formatting(groups=['colors'], env=environments, **plugins)

# Generated at 2022-06-23 19:31:51.095937
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter('application/json')
    assert not Conversion().get_converter('')

# Generated at 2022-06-23 19:31:56.642730
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.colors = False
    env.stdout_isatty = False
    fmt = Formatting([], env)
    assert fmt.enabled_plugins == []
    fmt = Formatting(groups=["HTTPie"], env=env)
    assert len(fmt.enabled_plugins) == 1

# Generated at 2022-06-23 19:31:59.808334
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("application/json")
    assert converter and converter.mime == "application/json"
    assert converter.supports("application/json")
    assert not converter.supports("application/xml")

    converter = Conversion.get_converter("application/yaml")
    assert converter and converter.mime == "application/yaml"
    assert converter.supports("application/yaml")
    assert not converter.supports("application/xml")

    converter = Conversion.get_converter("application/xml")
    assert not converter


# Generated at 2022-06-23 19:32:06.488049
# Unit test for constructor of class Formatting
def test_Formatting():    
    available_plugins = plugin_manager.get_formatters_grouped()
    groups = ['colors', 'colors']
    formatting = Formatting(groups)
    assert len(formatting.enabled_plugins) == len(groups)
    for cls in available_plugins['colors']:
        p = cls(env=Environment())
        if p.enabled:
            assert p.__class__ in [i.__class__ for i in formatting.enabled_plugins]
    


# Generated at 2022-06-23 19:32:14.366016
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # test normal input
    headers_str = "HTTP/1.1 200 OK\nServer: nginx/1.14.0\nDate: Sat, 10 Aug 2019 21:35:00 GMT\nContent-Type: application/json\nContent-Length: 359\nConnection: keep-alive\nAccess-Control-Allow-Origin: *\nAccess-Control-Allow-Credentials: true\n\n{\"data\":\"hello\"}"

# Generated at 2022-06-23 19:32:24.355372
# Unit test for constructor of class Conversion
def test_Conversion():
    # Test Case 1: mime variable is empty
    mime = ""
    assert Conversion.get_converter(mime) == None

    # Test Case 2: mime variable does not have regular expression
    mime = "abcdefg"
    assert Conversion.get_converter(mime) == None

    # Test Case 3: mime variable is not valid mime
    mime = "application/json"
    assert Conversion.get_converter(mime) != None

    # Test Case 4: mime variable is valid mime
    mime = "text/html"
    assert Conversion.get_converter(mime) != None



# Generated at 2022-06-23 19:32:27.386392
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['colors'],
                   env=Environment(),
                   style='auto',
                   themes=None,
                   theme=None,
                   colors=256,
                   force_colors=False,
                   highlight_lines=None)
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].enabled == True


# Generated at 2022-06-23 19:32:31.651899
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') is True
    assert is_valid_mime('application/json; charset=utf-8') is False
    assert is_valid_mime('') is False
    assert is_valid_mime(None) is False

# Generated at 2022-06-23 19:32:34.461249
# Unit test for constructor of class Conversion
def test_Conversion():
    mime_type = str()
    converter = Conversion.get_converter(mime_type)
    assert converter is None


# Generated at 2022-06-23 19:32:36.730815
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """ Dummy test for sample function."""
    assert True

if __name__ == '__main__':
    test_Formatting_format_headers()

# Generated at 2022-06-23 19:32:40.959426
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatting = Formatting(groups=['colors'])
    assert formatting.format_body(content="abc", mime="text/html") == "abc"
    assert formatting.format_body(content="abc", mime="application/json") == "\x1b[37m\"abc\"\x1b[0m"



# Generated at 2022-06-23 19:32:50.768730
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/yaml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/xml'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/csv'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/json;charset=UTF-8'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/json; charset=UTF-8'), ConverterPlugin)

# Generated at 2022-06-23 19:32:52.704166
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter(None)
    assert not Conversion.get_converter('/')
    assert not Conversion.get_converter('a/b/c')
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)

# Generated at 2022-06-23 19:32:53.962973
# Unit test for constructor of class Conversion
def test_Conversion():
    return 0

# Generated at 2022-06-23 19:33:02.862484
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment(post_data='foo=bar',
                      json=True,
                      form=True)
    formatting = Formatting(groups=['colors'], env=env)


# Generated at 2022-06-23 19:33:05.522088
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Arrange
    mime_type: str = 'application/json'

    # Act
    res = Conversion.get_converter(mime_type)

    # Assert
    assert res is not None

# Generated at 2022-06-23 19:33:14.097423
# Unit test for method format_body of class Formatting

# Generated at 2022-06-23 19:33:15.776110
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter("sas/9.2")
    assert(converter)

# Generated at 2022-06-23 19:33:17.809971
# Unit test for constructor of class Conversion
def test_Conversion():
    from httpie.compat import is_pyco

# Generated at 2022-06-23 19:33:22.880270
# Unit test for constructor of class Conversion
def test_Conversion():
    a = Conversion()
    b = 'a'
    c = a.get_converter(b)
    print(c)
    pass



# Generated at 2022-06-23 19:33:32.581354
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime('')
    assert not is_valid_mime('/')
    assert not is_valid_mime('application/')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/x-amz-json-1.0')

    # Compare the performance of two pattern matching functions
    import timeit
    assert timeit.timeit(stmt="MIME_RE.match('application/json')", setup="import re; MIME_RE = re.compile(r'^[^/]+/[^/]+$')") < \
           timeit.timeit(stmt="is_valid_mime('application/json')", setup="from __main__ import is_valid_mime")

# Generated at 2022-06-23 19:33:38.601068
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class HttpBinOrgPlugin(FormattingPlugin):
        def format_headers(self, headers: str) -> str:
            return '[httpbin.org plugin]\n' + headers
    plugin_manager.register_plugin(HttpBinOrgPlugin)

    env = Environment()
    fmt = Formatting(groups=['httpbin.org'], env=env)
    headers = fmt.format_headers('HTTP/1.1 200 OK\nHost: httpbin.org')
    assert headers == 'HTTP/1.1 200 OK\nHost: httpbin.org'

# Generated at 2022-06-23 19:33:40.925694
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application/javascript')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application.json')

# Generated at 2022-06-23 19:33:43.289526
# Unit test for constructor of class Formatting
def test_Formatting():
    f=Formatting(groups=["colors"],delete=True,headers=[1,2,3])
    assert f.enabled_plugins == []
    f=Formatting(groups=["table"],delete=True,headers=[1,2,3])
    assert f.enabled_plugins == []

# Generated at 2022-06-23 19:33:53.662999
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html').name == 'HTML'
    assert Conversion.get_converter('text/xml').name == 'HTML'
    assert Conversion.get_converter('application/rss+xml').name == 'RSS'
    assert Conversion.get_converter('application/atom+xml').name == 'Atom'
    assert Conversion.get_converter('application/json').name == 'JSON'
    assert Conversion.get_converter('application/geo+json').name == 'JSON'
    assert Conversion.get_converter('application/vnd.geo+json').name == 'JSON'
    assert Conversion.get_converter('application/hal+json').name == 'JSON'

# Generated at 2022-06-23 19:33:58.508944
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()
    #assert c.get_converter("application/json") is not None
    assert isinstance(c.get_converter("application/json"), ConverterPlugin)
    assert c.get_converter("foo/bar") is None

# Generated at 2022-06-23 19:34:03.310640
# Unit test for function is_valid_mime
def test_is_valid_mime():
    mimes = ["application/json", "text/html"]
    for mime in mimes:
        assert is_valid_mime(mime)

    not_mimes = ["application/json/text", ""]
    for not_mime in not_mimes:
        assert not is_valid_mime(not_mime)

# Generated at 2022-06-23 19:34:08.983328
# Unit test for function is_valid_mime
def test_is_valid_mime():
    tests = [
        ('application/json', 'application/json', True),
        ('text/*', 'text/html', True),
        ('text/*', 'image/jpg', False),
        ('text/*', 'text/*', True),
        ('*/json', 'application/json', True),
        ('*/*', 'text/html', True),
        ('foo', 'text/html', False),
    ]

    for key, mime, result in tests:
        assert is_valid_mime(key) == result

# Generated at 2022-06-23 19:34:11.982216
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatter_headers = Formatting(['headers'], colors=True)
    assert(formatter_headers.format_headers('200 OK') == '\x1b[32m200\x1b[39m \x1b[33mOK\x1b[39m')


# Generated at 2022-06-23 19:34:23.002368
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """Unit test for method format_body of class Formatting"""
    # When no plugins are enabled
    JSON_PLUGIN = 'json'
    xml_PLUGIN = 'xml'
    groups = []
    content = '{"a": 123, "b": "hi"}'
    mime = "application/json"
    formatting = Formatting(groups=groups)
    formatted_content = formatting.format_body(content=content, mime=mime)
    assert formatted_content == content

    # When plugin JSON is enabled
    groups = [JSON_PLUGIN]
    formatting = Formatting(groups=groups)
    formatted_content = formatting.format_body(content=content, mime=mime)
    print("formatted_content:")
    print(str(formatted_content))
    assert formatted_content != content



# Generated at 2022-06-23 19:34:31.886660
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
	assert Formatting(['headers']).format_headers("""GET / HTTP/1.1
Accept: text/plain, */*; q=0.01
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length:
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.8""") == """GET / HTTP/1.1
Accept: text/plain, */*; q=0.01
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Length:
Content-Type: application/json
Host: httpbin.org
User-Agent: HTTPie/0.9.8"""


# Generated at 2022-06-23 19:34:40.890400
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('image/jpeg') == True
    assert is_valid_mime('text/plain') == True
    assert is_valid_mime('application/hal+json') == True
    assert is_valid_mime('image/jpeg/test') == False
    assert is_valid_mime('text/plain/test') == False
    assert is_valid_mime('application/hal+json/test') == False
    assert is_valid_mime('test/test') == False
    assert is_valid_mime('test image/jpeg') == False
    assert is_valid_mime('test application/hal+json') == False

# Generated at 2022-06-23 19:34:46.325118
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/plain')
    assert is_valid_mime('text/json')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('text')
    assert not is_valid_mime('plain')
    assert not is_valid_mime('json')
    assert not is_valid_mime('text-text')

# Generated at 2022-06-23 19:34:53.742328
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class HeadersFormatter():
        def __init__(self, env = None, **kwargs):
            self.enabled = True
        def format_headers(self, headers: str) -> str:
            out = ''
            lines = headers.split('\n')
            for line in lines:
                if line:
                    out += '-' + line + '\n'
            return out
    plugin_manager.get_formatters_grouped().setdefault('all', []).append(HeadersFormatter)
    f = Formatting(['all'])
    assert f.format_headers('a: b\nc: d') == '-a: b\n-c: d\n'
    plugin_manager.get_formatters_grouped()['all'].pop()


# Generated at 2022-06-23 19:34:55.704909
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    Formatting(groups=["format"], env=env)



# Generated at 2022-06-23 19:35:01.352400
# Unit test for constructor of class Conversion
def test_Conversion():
    mime=Conversion.get_converter("application/json")
    mime2=Conversion.get_converter("application/xml")
    mime3=Conversion.get_converter("application/html")
    assert mime == "application/json"
    assert mime2 == "application/xml"
    assert mime3 == "application/html"


# Generated at 2022-06-23 19:35:07.548693
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Create Formatting objects
    formatter_plugin1 = Formatting(groups=['composite', 'json', 'colors'])
    formatter_plugin2 = Formatting(groups=['composite', 'json', 'colors'])
    # Test different mime types
    mime1 = 'application/json'
    mime2 = 'application/xml'
    # Prepare content

# Generated at 2022-06-23 19:35:10.062759
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)
    assert Conversion.get_converter("text/html") is None
    assert Conversion.get_converter("foo/bar") is None

# Generated at 2022-06-23 19:35:11.178872
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json')


# Generated at 2022-06-23 19:35:22.672869
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.base import Formatter
    from unittest.mock import Mock

    class DummyFormatter(Formatter):
        def format_headers(self, headers):
            return headers

        def format_body(self, body, mime):
            return body

    class AnotherFormatter(Formatter):
        def format_headers(self, headers):
            return headers

        def format_body(self, body, mime):
            return body

    another_formatter = AnotherFormatter()
    dummy_formatter = DummyFormatter()
    plugin_manager.classes = [DummyFormatter, AnotherFormatter]
    # set the 'plugin_manager.get_formatters_grouped()' to return a predefined value

# Generated at 2022-06-23 19:35:24.533372
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """Test case for method get_converter of class Conversion"""
    converter = Conversion.get_converter("text/plain")
    assert isinstance(converter, ConverterPlugin)


# Generated at 2022-06-23 19:35:26.691403
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not Conversion.get_converter('abc')
    assert not Conversion.get_converter(None)
    assert Conversion.get_converter('json')
    assert Conversion.get_converter('html')
    assert not Conversion.get_converter('htm')

# Generated at 2022-06-23 19:35:30.916915
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('a/b') is True
    assert is_valid_mime(u'a/b') is True
    assert is_valid_mime('a') is False
    assert is_valid_mime('a/') is False
    assert is_valid_mime('/b') is False

# Generated at 2022-06-23 19:35:36.193096
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html")
    assert is_valid_mime("a/b")
    assert not is_valid_mime("text/html/")
    assert not is_valid_mime("text/html/css")
    assert not is_valid_mime("")
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:35:40.058974
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(["colors"]).format_headers("HTTP/1.1 200 OK\r\n") + "\n" == "\x1b[90mHTTP/1.1 \x1b[32m200\x1b[39m \x1b[33mOK\x1b[39m\x1b[39m\r\n"


# Generated at 2022-06-23 19:35:48.845050
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import pytest
    @pytest.mark.parametrize(('text', 'mime', 'expected'), [
            ('{"message": "Hello", "name": "world"}',
             "application/json",
             '{\n    "message": "Hello",\n    "name": "world"\n}\n')
            ])
    def test_json(text, mime, expected):
        #from httpie.plugins import plugin_manager
        #plugin_manager.get_viewers = lambda: (PrettyJsonViewer,)
        formatter = Formatting(groups=["json"], env=Environment(stdout=True))
        assert expected == formatter.format_body(text, mime)


# Generated at 2022-06-23 19:35:51.402279
# Unit test for function is_valid_mime
def test_is_valid_mime():
    tests = [
        ("text/html", True),
        ("", False),
        ("text/html/blabla", False),
        ("text", False)
    ]

    for mime, result in tests:
        assert is_valid_mime(mime) is result

# Generated at 2022-06-23 19:36:02.977170
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class Group1Plugin:
        def format_body(self, content: str, mimetype: str) -> str:
            if mimetype == 'application/json':
                return content.replace(
                    '"h1": "This is title"',
                    '"h1": "This is a new title"'
                )
            return content

    class Group2Plugin:
        def format_body(self, content: str, mimetype: str) -> str:
            if mimetype == 'application/json':
                return content.replace(
                    '"h1": "This is a new title"',
                    '"h1": "This is a newer title"'
                )
            return content

    class PluginManager:
        def __init__(self):
            self.group1_plugins = [Group1Plugin()]

# Generated at 2022-06-23 19:36:05.935395
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.supports('application/json')
    assert not converter.supports('text/html')

# Generated at 2022-06-23 19:36:10.284475
# Unit test for constructor of class Conversion
def test_Conversion():
    # when succeed, return a ConverterPlugin
    c = Conversion.get_converter('application/json')
    assert isinstance(c, ConverterPlugin)

    # when no matched converter, return None
    c = Conversion.get_converter('nope')
    assert c is None

    # when invalid mime, return None
    c = Conversion.get_converter('json')
    assert c is None

# Generated at 2022-06-23 19:36:21.944420
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    source = "The quick brown fox jumps over the lazy dog"
    expected_result = "The quick brown fox jumps over the lazy dog"
    groups = ['highlighting']
    mime = 'text/plain'
    # By default, nothing happens
    result = Formatting(groups).format_body(source, mime)
    assert result == expected_result
    # JSON highlight can be enabled
    result = Formatting(groups, json_indent=0).format_body(
        '{"test": "object"}', 'application/json')
    assert result == "{\n  \"test\": \"object\"\n}"
    result = Formatting(groups, json_indent=2).format_body(
        '{"test": "object"}', 'application/json')
    assert result == "{\n  \"test\": \"object\"\n}"
   

# Generated at 2022-06-23 19:36:25.883876
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(["htmlextras"])
    assert fmt.enabled_plugins[0].name == "HTMLFormat"
    assert fmt.enabled_plugins[0].enabled is True
    assert fmt.enabled_plugins[0].env.config.get("h2c", "suppress404") is False



# Generated at 2022-06-23 19:36:30.723158
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    formatter_classes = available_plugins['body']
    formatting = Formatting(groups=['body'])
    assert len(formatting.enabled_plugins) > 0
    assert formatting.enabled_plugins is not formatter_classes
    assert len(formatting.enabled_plugins) is len(formatter_classes)



# Generated at 2022-06-23 19:36:40.334794
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    print("\nTesting Formatting.format_headers")

    env = Environment()
    env.stdout = sys.stdout
    groups = ['colors']
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)


# Generated at 2022-06-23 19:36:45.874217
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    formatting = Formatting(groups=['colors'], env=env)
    headers = formatting.format_headers('HTTP/1.1 200 OK\nContent-type:application/json\n\n{}')
    assert(headers == '\x1b[37m\x1b[1mHTTP/1.1 200 OK\x1b[0m\x1b[37m\n\x1b[32mContent-type:application/json\x1b[0m\x1b[37m\n\n\x1b[33m{}\x1b[0m\x1b[37m')

# Generated at 2022-06-23 19:36:58.789600
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    from httpie.plugins.builtin import JSONPrettyPrint
    from httpie.plugins.builtin import HeadersUnfold
    from httpie.plugins.builtin import HeadersInExport
    from httpie.plugins.builtin import Header
    test_formatters = [JSONPrettyPrint.EnabledJSONPrettyPrint(),
                       HeadersUnfold.EnabledHeadersUnfold(),
                       HeadersInExport.EnabledHeadersInExport(),
                       Header.EnabledHeader()]

    test_input = 'HTTP/1.1 200 OK\r\nServer: nginx\r\nContent-Type: application/json\r\nContent-Length: 4\r\nConnection: keep-alive\r\n'

# Generated at 2022-06-23 19:37:04.423445
# Unit test for function is_valid_mime
def test_is_valid_mime():
    result = is_valid_mime("application/json")
    assert result == True
    result = is_valid_mime("text/xml")
    assert result == True
    result = is_valid_mime("json")
    assert result == False
    result = is_valid_mime("Application/JSON")
    assert result == False
    result = is_valid_mime("application/")
    assert result == False
    result = is_valid_mime("/json")
    assert result == False



# Generated at 2022-06-23 19:37:11.639934
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.stdout = io.StringIO()
    f = Formatting(groups=['HTTPieFormatter'], env=env, request_headers=None)
    output = f.format_headers("WSGI-HTTPie/1.0.2")
    assert output == "WSGI-HTTPie/1.0.2\n"


# Generated at 2022-06-23 19:37:14.968933
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/plain") == True
    assert is_valid_mime("text/") == False
    assert is_valid_mime("text") == False

# Generated at 2022-06-23 19:37:19.761338
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins import json, html

    converter = Conversion.get_converter('application/json')
    assert issubclass(converter.__class__, json.JSONPathToolConverter)

    converter = Conversion.get_converter('text/html')
    assert issubclass(converter.__class__, html.HTMLPathToolConverter)



# Generated at 2022-06-23 19:37:27.930183
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').__class__.__name__ == 'PrettyJson'
    assert Conversion.get_converter('application/xml').__class__.__name__ == 'PrettyJson'
    assert Conversion.get_converter('text/html').__class__.__name__ == 'PrettyJson'

    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/xml') is not None
    assert Conversion.get_converter('text/html') is not None

# Generated at 2022-06-23 19:37:34.038757
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test get ConverterPlugin class JSON
    assert Conversion.get_converter('application/json').__class__.__name__ == 'JSONConverter'
    assert Conversion.get_converter('application/json').mime == 'application/json'

    # Test get ConverterPlugin class None
    assert Conversion.get_converter('application/js') is None

# Generated at 2022-06-23 19:37:38.414310
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html').mime == 'text/html'
    assert Conversion.get_converter('application/json;charset=UTF-8').mime == 'application/json'
    assert Conversion.get_converter('json') is None



# Generated at 2022-06-23 19:37:44.466743
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    assert is_valid_mime("application/x-www-form-urlencoded")
    assert not is_valid_mime("json")
    assert not is_valid_mime("json ")
    assert not is_valid_mime("")
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:37:49.339479
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    str_mime = 'application/json'
    converter = Conversion.get_converter(str_mime)
    assert converter
    assert converter.supports(str_mime)
    assert converter.get_pretty(str_mime) == 'JSON'
    assert converter.extension(str_mime) == '.json'

    str_mime = 'json'
    converter = Conversion.get_converter(str_mime)
    assert not converter

# Generated at 2022-06-23 19:37:51.267602
# Unit test for constructor of class Conversion
def test_Conversion():
    ConverterPlugin.supports("application/json")
    Conversion.get_converter("application/json")


# Generated at 2022-06-23 19:38:02.162389
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(["color"])
    assert f.format_body("body", "application/json") == "body"
    assert f.format_body("[1,2,3]", "application/json") == "\x1b[38;5;250m[\n    \x1b[38;5;28m1\x1b[38;5;250m,\n    \x1b[38;5;28m2\x1b[38;5;250m,\n    \x1b[38;5;28m3\x1b[38;5;250m\n]\x1b[0m\n"
    assert f.format_body("body", "xml") == "body"

# Generated at 2022-06-23 19:38:11.020914
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins import DataProcessorPlugin
    class SpaceToUnderscoreHeaders(DataProcessorPlugin):
        name = 'space_to_underscore_headers'

        def format_headers(self, headers):
            headers = headers.replace(' ', '_')
            return headers
    plugin_manager.register(SpaceToUnderscoreHeaders)
    result = Formatting(groups=['space_to_underscore_headers']).format_headers('hello world')
    assert result == 'hello_world'
    plugin_manager.unregister(SpaceToUnderscoreHeaders)

# Generated at 2022-06-23 19:38:20.077913
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin.formatters.json import JSONFormatter


# Generated at 2022-06-23 19:38:21.021414
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter("application/json")

# Generated at 2022-06-23 19:38:30.117377
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['theme']
    env = Environment()
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=env, **{})
            if p.enabled:
                enabled_plugins.append(p)


# Generated at 2022-06-23 19:38:31.621048
# Unit test for constructor of class Conversion
def test_Conversion():
    assert isinstance(Conversion.get_converter("text/html"), ConverterPlugin)


# Generated at 2022-06-23 19:38:36.216976
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert converter is not None

    converter = Conversion.get_converter('application/json')
    assert converter is None

    converter = Conversion.get_converter('')
    assert converter is None

    converter = Conversion.get_converter(None)
    assert converter is None

# Generated at 2022-06-23 19:38:45.415621
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # should get a "admin" as admin, but since we do not use the json file
    # in this test, we got a None
    # each test must be run one by one to avoid multiple input
    conversion = Formatting(['colors'])

# Generated at 2022-06-23 19:38:57.223808
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatter = Formatting(['color'], )
    headers = 'HTTP/1.1 201 Created\nConnection: keep-alive\nContent-Length: 6\nContent-Type: application/json; charset=utf-8\nDate: Thu, 26 Oct 2017 05:04:54 GMT\nServer: nginx/1.10.3 (Ubuntu)\nStrict-Transport-Security: max-age=15724800\nX-Frame-Options: SAMEORIGIN\n\n'
    print(formatter.format_headers(headers))
    print('\n')
    formatter = Formatting(['format'], )

# Generated at 2022-06-23 19:39:00.678144
# Unit test for constructor of class Conversion
def test_Conversion():
    converter1 = Conversion.get_converter("application/json")
    assert converter1 is not None
    converter2 = Conversion.get_converter("bla/bla")
    assert converter2 is None


# Generated at 2022-06-23 19:39:03.584104
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter("text/html")
    assert converter.__class__.__name__ == "HTMLConverter"


# Generated at 2022-06-23 19:39:05.087192
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Given
    headers = 'blah blah blah'
    mime = 'application/json'

    # When
    fmt = Formatting(['format'])
    content = fmt.format_body(headers, mime)

    # Then
    assert headers == content

# Generated at 2022-06-23 19:39:08.836162
# Unit test for constructor of class Conversion
def test_Conversion():
    result = Conversion.get_converter('application/json')
    if result == None:
        print('The test for class Conversion is passed.')
    else:
        print('The test for class Conversion is failed.')


# Generated at 2022-06-23 19:39:17.938487
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "text/html"

    class TestPlugin(ConverterPlugin):

        def __init__(self, mime):
            self.mime = mime

        def supports(self, mime: str) -> bool:
            return self.mime == mime

        def encode(self, obj, **kwargs):
            return "encode"

        def decode(self, s, **kwargs):
            return "decode"

    original_filter = plugin_manager.filter
    plugin_manager.filter = lambda cls: cls is TestPlugin


# Generated at 2022-06-23 19:39:25.621206
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    result = Formatting(['headers', 'colors']).format_headers("""HTTP/1.1 200 OK
Server: nginx/1.15.6 (Ubuntu)
Date: Tue, 20 Aug 2019 08:21:54 GMT
Content-Type: application/json; charset=utf-8
Transfer-Encoding: chunked
Connection: keep-alive
X-Powered-By: Express
ETag: W/"2-l5mR7n8ClvbYmqX3zxzGdEA7TI8"
Vary: Accept-Encoding
Cache-Control: private, max-age=0, must-revalidate
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 59

Hello world""")

# Generated at 2022-06-23 19:39:31.018830
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('text/css'), ConverterPlugin)
    assert isinstance(Conversion.get_converter('application/xml'), ConverterPlugin)
    assert Conversion.get_converter('application/png') is None

# Generated at 2022-06-23 19:39:33.020403
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "application/json"
    assert Conversion.get_converter(mime) is not None


# Generated at 2022-06-23 19:39:38.949914
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('') is False
    assert is_valid_mime('/') is False
    assert is_valid_mime('json') is False
    assert is_valid_mime('application/') is False
    assert is_valid_mime('application') is False

    assert is_valid_mime('application/json') is True
    assert is_valid_mime('text/plain') is True
    assert is_valid_mime('application/x-yaml') is True

# Generated at 2022-06-23 19:39:49.092767
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content=b'{"text":"Git"}'
    mime='application/json'
    f=Formatting(['pretty'])
    assert f.format_body(content,mime)=='{\n    "text": "Git"\n}'
    content=b'{"text":"Git"}'
    mime='application/xml'
    assert f.format_body(content,mime)=='{"text":"Git"}'
    content=b'{"text":"Git"}'
    mime='text/plain'
    assert f.format_body(content,mime)=='{"text":"Git"}'
    content=b'{"text":"Git"}'
    mime='application/octet-stream'

# Generated at 2022-06-23 19:39:55.396184
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Test no body
    f = Formatting(["colors"])
    p = f.format_body("", "text/html")

    assert(p == "")

    # Test body
    f = Formatting(["colors"])
    p = f.format_body("<html><title>test title</title></html>", "text/html")

    assert(p == "\x1b[90m<html>\x1b[39m\x1b[90m<title>\x1b[39m\x1b[93mtest title\x1b[39m\x1b[90m</title>\x1b[39m\x1b[90m</html>\x1b[39m\n")