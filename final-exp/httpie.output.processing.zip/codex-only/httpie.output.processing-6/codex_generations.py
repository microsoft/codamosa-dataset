

# Generated at 2022-06-23 19:29:54.226342
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("a/b") is True
    assert is_valid_mime("/") is False
    assert is_valid_mime("/a") is False
    assert is_valid_mime("a/") is False

# Generated at 2022-06-23 19:30:01.524799
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins import ConverterPlugin

    class FakeConverter(ConverterPlugin):

        @classmethod
        def supports(cls, mime):
            return mime.startswith('text/')

        def __init__(self, mime):
            self.mime = mime

        def convert(self, data):
            return data

    mime = 'text/html'
    converter = Conversion.get_converter(mime)
    assert isinstance(converter, FakeConverter)



# Generated at 2022-06-23 19:30:05.156093
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    assert not is_valid_mime("application/json; charset=utf-8")
    assert not is_valid_mime("")
    assert not is_valid_mime(None)
    assert not is_valid_mime("   ")



# Generated at 2022-06-23 19:30:08.469407
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=['colors', 'format','pretty'], env=Environment())
    r = f.format_body(content="{\"hello\":\"world\"}", mime="application/json")
    print(r)

# Generated at 2022-06-23 19:30:12.611397
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    assert not is_valid_mime("something")
    assert not is_valid_mime("something/")
    assert not is_valid_mime("/something")

# Generated at 2022-06-23 19:30:14.903404
# Unit test for constructor of class Conversion
def test_Conversion():
    print("Executing Unit Test for constructor of class Conversion")
    a = Conversion.get_converter("text/html")


# Generated at 2022-06-23 19:30:22.676497
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    data_test = {
        'gzip': '''HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 31
Date: Wed, 26 Aug 2020 00:06:27 GMT
Host: localhost:8000

{"data": "test"}''',
        'headers': '''HTTP/1.1 200 OK
Connection: keep-alive
Content-Length: 31
Date: Wed, 26 Aug 2020 00:06:27 GMT
Host: localhost:8000

{"data": "test"}'''
    }

    for key in data_test:
        groups = [key]
        a = Formatting(groups)
        actual = a.format_headers(data_test[key])

# Generated at 2022-06-23 19:30:29.047709
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    input_json = "[1,2,3]{\"foo\":\"bar\"}"
    output_json = "{\n\t\"foo\": \"bar\"\n}[1, 2, 3]"
    f = Formatting(groups=['format'], table=False)
    result = f.format_body(content=input_json, mime="application/json")
    assert result == output_json

# Generated at 2022-06-23 19:30:36.107610
# Unit test for constructor of class Formatting
def test_Formatting():    
    # test for group not in available_plugins
    with pytest.raises(KeyError): 
        f = Formatting(groups=['one'])

    # test for group in available_plugins
    f = Formatting(groups=['json'])
    assert f.enabled_plugins[0].enabled

    # test for kwargs for processors
    def p(env=None, width=80, **kwargs):
        assert env.is_windows == sys.platform.startswith('win')
        assert width == 81
    f = Formatting(groups=['json', 'binary'], width=81, processors=[p])

# Generated at 2022-06-23 19:30:46.368952
# Unit test for constructor of class Formatting
def test_Formatting():

    def pytest_configure(config):
        config.addinivalue_line("markers", "env(name): mark test to run only on named environment")

    def pytest_runtest_setup(item):
        if "env" in item.keywords and item.config.getoption("--current-env") not in item.keywords:
            pytest.skip("test requires env %s" % item.keywords["env"].args[0])

    @pytest.mark.env("test")
    def test_env(request):
        assert request.config.getoption("--current-env") == "test"

    env = Environment()
    fmt = Formatting(["syntax", "headers"], env=env)
    assert fmt.enabled_plugins[0].env is env

# Generated at 2022-06-23 19:30:48.649292
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('json').supports('/json') is True


# Generated at 2022-06-23 19:30:58.114696
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['colors'], is_windows=True, is_terminal=False)
    assert f.enabled_plugins == []

    f = Formatting(['colors'], is_windows=True, is_terminal=True)
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'WindowsConsoleColors'

    f = Formatting(['colors'], is_windows=False, is_terminal=False)
    assert f.enabled_plugins == []

    f = Formatting(['colors'], is_windows=False, is_terminal=True)
    assert len(f.enabled_plugins) == 1
    assert f.enabled_plugins[0].__class__.__name__ == 'ConsoleColors'

    f = Format

# Generated at 2022-06-23 19:31:00.340906
# Unit test for constructor of class Conversion
def test_Conversion():
    test_mime = 'application/json'
    result = Conversion.get_converter(test_mime)
    assert (result.mime == test_mime)


# Generated at 2022-06-23 19:31:01.891635
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    foo = Formatting(['colors'], env, style='solarized-dark')
    print(foo.enabled_plugins)


# Generated at 2022-06-23 19:31:05.215728
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('json')
    if converter is None:
        print('Method get_converter failed.')
    else:
        print('Method get_converter succeeded.')


# Generated at 2022-06-23 19:31:07.317183
# Unit test for constructor of class Formatting
def test_Formatting():
    groups: List[str] = []
    fmt = Formatting(groups)
    assert len(fmt.enabled_plugins) == 0

# Generated at 2022-06-23 19:31:12.600634
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.config['colors'] = False
    f = Formatting(groups=['headers'], env=env)
    headers = 'HTTP/1.1 200\nContent-Type: application/json\n\n'
    headers_formatted = f.format_headers(headers)
    assert headers == headers_formatted



# Generated at 2022-06-23 19:31:17.611421
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html') is True
    assert is_valid_mime('application/json') is True
    assert is_valid_mime('') is False
    assert is_valid_mime('foo') is False
    assert is_valid_mime('foo/bar') is True
    assert is_valid_mime('foo/bar/baz') is False

# Generated at 2022-06-23 19:31:28.321240
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test = Conversion()
    # should return None if mime is None
    assert test.get_converter(None) is None
    # should return None if mime is not valid
    assert test.get_converter('text') is None
    # should return None if mime is not supported by any converter
    assert test.get_converter('application/foo') is None
    # should return None if mime is supported by only one converter
    assert test.get_converter('application/json') is not None
    # should return None if mime is supported by only one converter
    assert test.get_converter('text/plain') is not None
    # should return None if mime is supported by only one converter
    assert test.get_converter('text/html') is not None



# Generated at 2022-06-23 19:31:32.147805
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    #assert is_valid_mime("json")
    assert is_valid_mime("application") is False


# Generated at 2022-06-23 19:31:34.983219
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('invalid')
    assert not is_valid_mime(' text/html')
    assert not is_valid_mime('text/html ')

# Generated at 2022-06-23 19:31:37.935452
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Case 1: mime is not valid
    assert Conversion.get_converter('') is None

    # Case 2: mime is valid
    assert Conversion.get_converter('text/html') is not None



# Generated at 2022-06-23 19:31:42.979920
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    obj = Formatting(groups=['colors'], env=env, style=env.colors.DEFAULT_STYLE)
    headers = "HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n"
    formatted_headers = obj.format_headers(headers)
    assert formatted_headers == "HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n"

# Generated at 2022-06-23 19:31:48.938488
# Unit test for function is_valid_mime
def test_is_valid_mime():
    mime_true = "text/html"
    mime_false = "text"
    mime_false_2 = "text/html/plain"
    assert is_valid_mime(mime_true)
    assert not is_valid_mime(mime_false)
    assert not is_valid_mime(mime_false_2)




# Generated at 2022-06-23 19:31:58.560818
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/json; charset=UTF-8')
    assert is_valid_mime('application/hal+json')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('application')
    assert not is_valid_mime('json')
    assert not is_valid_mime('/json')
    assert not is_valid_mime('')
    assert not is_valid_mime('/')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:32:07.990742
# Unit test for function is_valid_mime
def test_is_valid_mime():
  assert not is_valid_mime('')
  assert not is_valid_mime('/')
  assert not is_valid_mime('//')
  assert not is_valid_mime('foo')
  assert not is_valid_mime('/foo')
  assert not is_valid_mime('foo/')
  assert not is_valid_mime('/foo/')
  assert is_valid_mime('foo/bar')
  assert is_valid_mime('foo/bar/baz')
  assert is_valid_mime('foo/bar-baz')
  assert is_valid_mime('foo/bar_baz')
  assert is_valid_mime('foo/bar+baz')

# Generated at 2022-06-23 19:32:13.267247
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html")
    assert not is_valid_mime("text/html/")
    assert not is_valid_mime("/text/html")
    assert not is_valid_mime("text/html/json")
    assert not is_valid_mime("text")
    assert not is_valid_mime("/")
    assert not is_valid_mime("")
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:32:15.856749
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()
    assert c is not None
    assert c is not ""
    c = Conversion.get_converter("application/json")
    assert c is not None
    assert c is not ""


# Generated at 2022-06-23 19:32:26.543902
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-23 19:32:29.866805
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter is not None
    assert converter.supports('application/json') is True


# Generated at 2022-06-23 19:32:31.650959
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('image/jpg')
    assert not is_valid_mime('.jpg')

# Generated at 2022-06-23 19:32:39.386419
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert(is_valid_mime("application/json"))
    assert(is_valid_mime("text/html"))
    assert(is_valid_mime("image/jpeg"))
    assert(is_valid_mime("application/javascript"))
    assert(is_valid_mime("audio/mp4"))

    assert(not is_valid_mime("json"))
    assert(not is_valid_mime("application"))
    assert(not is_valid_mime("application/x-www-form-urlencoded"))

# Generated at 2022-06-23 19:32:40.061828
# Unit test for constructor of class Conversion
def test_Conversion():
    a = Conversion
    assert a


# Generated at 2022-06-23 19:32:40.953803
# Unit test for constructor of class Conversion
def test_Conversion():
    r = Conversion()

# Generated at 2022-06-23 19:32:50.728120
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    h = Formatting(groups=['colors'])
    s = '\n'.join(['HTTP/1.1 200 OK',
                   'Content-Type: text/plain; charset=utf-8',
                   'Connection: close',
                   'Date: Sun, 17 Jun 2018 13:27:35 GMT',
                   '',
                   'Regards'])
    s = h.format_headers(s[:-7])  # cut Regards from the end

# Generated at 2022-06-23 19:32:55.916263
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json") == True
    assert is_valid_mime("application/vnd.api+json") == True
    assert is_valid_mime("application/x-www-form-urlencoded; charset=UTF-8") == False
    assert is_valid_mime("") == False
    assert is_valid_mime(None) == False
    assert is_valid_mime("application") == False
    assert is_valid_mime("json") == False
    assert is_valid_mime("+") == False
    assert is_valid_mime("/") == False

# Generated at 2022-06-23 19:33:01.318075
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_json = '{"name":"Bob","age":18}'
    json_format = Formatting(['json'])
    pretty_json = json_format.format_body(test_json, 'application/json')
    print(pretty_json)
    assert pretty_json == '{\n    "name": "Bob",\n    "age": 18\n}\n'
    assert json_format.format_body('', 'text/xml') == ''



# Generated at 2022-06-23 19:33:05.221093
# Unit test for constructor of class Formatting
def test_Formatting():
	f = Formatting(['colors', 'formatters'], colors={"red":"1"})
	assert isinstance(f, Formatting)
	assert f.enabled_plugins[0].colors == {"red":"1"}

# Generated at 2022-06-23 19:33:11.718765
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html;charset=utf8')
    assert isinstance(converter, ConverterPlugin)
    assert converter.supports('text/html;charset=utf8')
    assert not converter.supports('text/html;')
    assert not converter.supports('text/html')
    assert not converter.supports('application/json')
    assert converter.mime == 'text/html'
    assert isinstance(converter.charset, str)
    assert converter.charset == 'utf8'


# Generated at 2022-06-23 19:33:12.526286
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting({'cool'}, Environment())

# Generated at 2022-06-23 19:33:15.406001
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content="""{
    "id":1,
    "name":"abc",
}"""
    formatted_content=Formatting("json").format_body(content,"application/json")
    assert formatted_content=="{\n    \"id\":1,\n    \"name\":\"abc\",\n}"

# Generated at 2022-06-23 19:33:19.053876
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting([])
    assert f.enabled_plugins == []
    f = Formatting(['highlight', 'json'])
    assert f.enabled_plugins != []

# Generated at 2022-06-23 19:33:28.099783
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.cli import raw_format
    groups = ['format', 'colors', 'colors_headers']
    format = Formatting(groups)
    assert format is not None
    assert format.enabled_plugins is not None
    assert len(format.enabled_plugins) == len(groups)
    assert isinstance(format.enabled_plugins[0], raw_format.RawFormatter)
    assert format.enabled_plugins[1].get_lexer_name() == "json"
    assert format.enabled_plugins[2].get_lexer_name() == "http"

# Generated at 2022-06-23 19:33:36.000460
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Setup
    f = Formatting(["colors"])
    content = "success"
    mime = "application/json"

    # Actual test
    actual = f.format_body(content, mime)

    # Verification
    expected = "\x1b[32m\x1b[1m\x1b[37m"+"success"+"\x1b[39m\x1b[22m\x1b[0m"
    assert actual == expected


# Generated at 2022-06-23 19:33:43.836554
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment(is_windows=False)
    fmt = Formatting(['colors'], env)
    mime = "application/json"
    json = '{ "error": "test" }'
    result = fmt.format_body(json, mime)
    assert result == '\x1b[39m\x1b[22m{\x1b[39m \x1b[94m"error"\x1b[39m\x1b[22m: \x1b[39m\x1b[22m\x1b[91m"test"\x1b[39m\x1b[22m \x1b[39m\x1b[22m}\x1b[39m\x1b[22m\n'


# Generated at 2022-06-23 19:33:46.069250
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():

    # set up
    k = 'text/html'
    c_obj = Conversion.get_converter(k)

    # execute
    c_obj.dump(True)

    # test
    assert c_obj.mime == 'text/html'

# Generated at 2022-06-23 19:33:54.985857
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = '''HTTP/1.1 200 OK
    Date: Tue, 18 Dec 2018 15:00:43 GMT
    Server: Apache/2.4.29 (Ubuntu)
    Access-Control-Allow-Origin: *
    Vary: Accept-Encoding
    Last-Modified: Mon, 11 Dec 2017 14:28:26 GMT
    ETag: "5a2e66e2-2fd0"
    Accept-Ranges: bytes
    Content-Length: 12144
    Keep-Alive: timeout=5, max=100
    Connection: Keep-Alive
    Content-Type: text/html
    '''

# Generated at 2022-06-23 19:33:58.508760
# Unit test for function is_valid_mime
def test_is_valid_mime():
	assert is_valid_mime("application/json")
	assert not is_valid_mime("application/")
	assert not is_valid_mime("/json")
	assert not is_valid_mime("application")
	assert not is_valid_mime("json")

# Generated at 2022-06-23 19:34:07.403543
# Unit test for constructor of class Formatting
def test_Formatting():
    # Test constructor of class Formatting
    # Since the initialization of `enabled_plugins` is based on the 
    # constructor of class Environment, I used a mock object to 
    # test the constructor of Formatting
    groups = ['format']
    kwargs = {'pretty': True}
    env = Environment()
    env.colors = True
    env.stream = sys.stdout
    env.format = 'colors'
    formatting = Formatting(groups, env, **kwargs)
    assert formatting.enabled_plugins != []
    # I choose plugin PrettyColors to test
    assert len(formatting.enabled_plugins) == 1
    assert formatting.enabled_plugins[0].__class__.__name__ == 'PrettyColors'

# Generated at 2022-06-23 19:34:13.399465
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    '''
    "Unit test" for format_body method of Formatting class
    '''
    # create an instance of Formatting class
    f = Formatting(groups=['colors'], style='solarized')
    # the method format_body will invoke the method format_body of Highlight.
    # So the content of the method format_body of Highlight is implicitly tested.
    content = '{ "key": "value", "key2": "value2" }'
    mime = 'application/json'
    result = f.format_body(content, mime)

# Generated at 2022-06-23 19:34:15.171214
# Unit test for constructor of class Conversion
def test_Conversion():
    conversion = Conversion()
    assert conversion


if __name__ == '__main__':
    test_Conversion()

# Generated at 2022-06-23 19:34:16.023217
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert is_valid_mime('image/svg+xml') is True

# Generated at 2022-06-23 19:34:27.339593
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import JSONFormatterPlugin, FormattingOptionsPlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.plugins.core import ArgTYPE

    env = Environment()
    plugin_manager.add_plugins([
        FormattingOptionsPlugin,
    ])

    args = ArgTYPE(color=False,
                   pretty=True,
                   print_body=True,
                   print_headers=True,
                   verify=True,
                   verify_hostname=True,
                   output_file=None,
                   stdout_isatty=True,
                   output_options=[])

    # For testing format_body method only, we only load plugin JSONFormatterPlugin
    p = Formatting(groups=["formatting"], env=env, **args)
    # Change enabled_plugins of p
    p.enabled_

# Generated at 2022-06-23 19:34:30.461506
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(['colors']).format_headers('some headers') == '\x1b[38;5;8msome headers\x1b[0m'

# Generated at 2022-06-23 19:34:32.694785
# Unit test for constructor of class Formatting
def test_Formatting():
    for item in plugin_manager.get_formatters():
        print(item)



# Generated at 2022-06-23 19:34:41.719058
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.context import Environment
    from httpie.plugins import FormatterPlugin
    
    class FakePlugin1(FormatterPlugin):
        enabled = True
        name = 'test1'
        def format_headers(self, headers):
            return headers
        def format_body(self, body, mime):
            return body

    class FakePlugin2(FormatterPlugin):
        enabled = False
        name = 'test2'
        
    plugin_manager.register(FakePlugin1)
    plugin_manager.register(FakePlugin2)
    fmt = Formatting(['test']).enabled_plugins
    assert len(fmt) == 1
    assert fmt[0].name == 'test1'



# Generated at 2022-06-23 19:34:46.739936
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert not is_valid_mime('/html')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('/')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)
    assert not is_valid_mime(123)

# Generated at 2022-06-23 19:34:49.106379
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    lines = "KeyA: A\nKeyB: B\n"
    lines_ans = "KeyA: A\r\nKeyB: B\r\n"

    g = Formatting(['headers'])
    assert lines_ans == g.format_headers(lines)


# Generated at 2022-06-23 19:34:52.911599
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html")
    assert is_valid_mime("application/json")
    assert is_valid_mime("text/xml")
    assert is_valid_mime("abcdefghijklmnopqrstuvwxyz")
    assert is_valid_mime("abcd/efg")
    assert not is_valid_mime("")
    assert not is_valid_mime("/html")
    assert not is_valid_mime("text/")

# Generated at 2022-06-23 19:35:03.570396
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Normal Usage
    available_plugins = plugin_manager.get_formatters_grouped()
    env = Environment()
    # env.is_windows = True
    groups = ['color']
    kwargs = {}
    headers = 'HTTP/1.1 200 OK\r\nContent-Type:text/html;charset=utf-8\r\nContent-Length:9\r\n\r\n'
    # enabled_plugins = []
    enabled_plugins = []
    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=env, **kwargs)
            if p.enabled:
                enabled_plugins.append(p)
    for p in enabled_plugins:
        headers = p.format_headers(headers)
    print(headers)
    # Expected

# Generated at 2022-06-23 19:35:11.364880
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import unittest.mock
    from httpie.formatters import JSONFormatter
    from httpie.plugins import converter

    for c in (
        converter.JSONConverter,
        converter.TextConverter,
    ):
        if c.supports('application/json'):
            c.from_string = unittest.mock.Mock()
        if c.supports('text/plain'):
            c.from_string = unittest.mock.Mock()

    saved_from_string = converter.TextConverter.from_string


# Generated at 2022-06-23 19:35:15.107948
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatter = Formatting([""])
    print(formatter.format_body('{\n    "name": "",\n    "id": 1\n}', 'application/json'))

if __name__ == '__main__':
    test_Formatting_format_body()

# Generated at 2022-06-23 19:35:19.197582
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('text')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('/html')


# Generated at 2022-06-23 19:35:24.507185
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/plain')
    assert is_valid_mime('text/plaIn')
    assert is_valid_mime('application/admin')
    assert is_valid_mime('application/vnd.github.v3+json')
    assert is_valid_mime('application/vnd.github')
    assert is_valid_mime('xxxxx/xxxxxxxx')
    assert not is_valid_mime('/json')
    assert not is_valid_mime('json')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('application/json;')
    assert not is_valid_mime('application/json; charset=UTF-8')
    assert not is_valid_m

# Generated at 2022-06-23 19:35:29.660743
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ["formatters"]
    from httpie.context import Environment
    env = Environment()
    # test for default plugins
    formatting = Formatting(groups, env)
    assert formatting.enabled_plugins == []
    # test for custom plugins
    from httpie.plugins.builtin import JSON, JSONStream, Hexdump, ColoredJSON
    custom_plugins = []
    custom_plugins.append(ColoredJSON())
    formatting = Formatting(groups, env, plugins = custom_plugins)
    assert formatting.enabled_plugins == custom_plugins


# Generated at 2022-06-23 19:35:33.302404
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    env.colors = 0
    fmt = Formatting([], env=env)
    assert len(fmt.enabled_plugins) == 0


# Generated at 2022-06-23 19:35:36.848445
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/html')
    assert is_valid_mime('*/*')
    assert not is_valid_mime('invalid')
    assert not is_valid_mime('invalid/type')

# Generated at 2022-06-23 19:35:39.523439
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment(colors=True, encoding='utf8', is_windows=False)
    fmt = Formatting(['colors'], env)
    assert fmt.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter'

# Generated at 2022-06-23 19:35:43.910641
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/html'
    result = Conversion.get_converter(mime)
    assert result.mime == mime

    mime = 'text/xhtml'
    result = Conversion.get_converter(mime)
    assert result is None


# Generated at 2022-06-23 19:35:44.749168
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting([], env=Environment())

# Generated at 2022-06-23 19:35:48.911260
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/plain')
    assert converter is None

    converter = Conversion.get_converter('application/json')
    assert converter.__module__ == 'httpie.plugins.builtin.converters.json'

    converter = Conversion.get_converter('application/xml')
    assert converter.__module__ == 'httpie.plugins.builtin.converters.xml'

# Generated at 2022-06-23 19:35:54.652035
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.context import Environment
    env = Environment()
    env.colors = False
    from httpie.plugins.formatter.colors import PygmentsColors
    from httpie.plugins.formatter.grouped import Headers
    from httpie.plugins.formatter.highlight import Highlight
    headers = b"""HTTP/1.1 200 OK
    Content-Type: text/html; charset=utf-8
    Content-Length: 138
    Server: Werkzeug/0.14.1 Python/3.7.0
    Date: Mon, 14 Jan 2019 20:52:15 GMT

    """
    f = Formatting(groups = ['colors'], env = env)
    h = Headers()
    py = PygmentsColors()
    hl = Highlight()
    headers = hl.format_headers

# Generated at 2022-06-23 19:35:57.891150
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("image/jpeg") == True
    assert is_valid_mime("image") == False
    assert is_valid_mime("image/") == False


# Generated at 2022-06-23 19:36:07.216109
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-23 19:36:11.615139
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['formatting']
    kwargs = {}
    test_env = Environment()
    test_env.config["pretty"] = "all"
    test_class = Formatting(groups, env=test_env, **kwargs)
    test_content = '{"abc": 123}'
    test_mime = 'application/json'
    assert test_class.format_body(test_content, test_mime) == \
        '{\n    "abc": 123\n}'

# Generated at 2022-06-23 19:36:16.692837
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formats = Formatting(['colors'], env=Environment())
    content = '[{"name": "first", "age": 18},\n ' \
          + '{"name": "second", "age": 19}\n]'
    assert formats.format_body(content, 'application/json') == \
        '[\n' \
        '    {\n' \
        '        "age": 18,\n' \
        '        "name": "first"\n' \
        '    },\n' \
        '    {\n' \
        '        "age": 19,\n' \
        '        "name": "second"\n' \
        '    }\n' \
        ']'


# Generated at 2022-06-23 19:36:20.487594
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    testContent = '{"a": 1}'
    mime = 'application/json'
    env = Environment()
    format_headers = Formatting(['format', 'colors'], env=env)
    assert testContent == format_headers.format_body(testContent, mime)

# Generated at 2022-06-23 19:36:27.418034
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/xml')
    assert is_valid_mime('text/xml+xsl')
    assert is_valid_mime('*/*')
    assert not is_valid_mime('json')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application/')
    assert not is_valid_mime(None)
    assert not is_valid_mime('')
    assert not is_valid_mime('/')

# Generated at 2022-06-23 19:36:37.960514
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    # Given

    class ConverterStub(ConverterPlugin):
        # test input
        mime = 'text/plain'

        def __init__(self, mime):
            super().__init__(mime)

        @property
        def content_type(self):
            return ConverterStub.mime

        def convert(self, data: str) -> str:
            return data


    class FormatterStub(FormatterPlugin):
        mime = 'text/plain'

        def __init__(self, **kwargs):
            super().__init__(**kwargs)

        @property
        def content_type(self):
            return FormatterStub.m

# Generated at 2022-06-23 19:36:41.108117
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    input = '{"key" : "value"}'
    mime = 'application/json'
    actual = Formatting([]).format_body(input, mime)
    assert actual == '{\n    "key": "value"\n}'

# Generated at 2022-06-23 19:36:42.939324
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    result = Formatting("JSON", env)
    assert len(result.enabled_plugins) == 1



# Generated at 2022-06-23 19:36:50.229339
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Get HTTPie converter plugin manager
    httpie_plugin_manager = plugin_manager
    # Get all converter plugins
    all_converters = httpie_plugin_manager.get_converters()
    sample_converters = [all_converters[0], all_converters[-1]]
    for converter in sample_converters:
        new_converter = converter('text/plain')
        assert new_converter.mime == 'text/plain'
        new_converter = converter('text/html')
        assert new_converter.mime == 'text/html'

# Generated at 2022-06-23 19:36:52.362472
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json').__class__.__name__ == 'JSONConverter'

# Generated at 2022-06-23 19:36:58.524542
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    
    print("\nTesting method get_converter of class Conversion")

    # Not a valid mime
    assert not is_valid_mime("asdf")

    # Not a valid converter
    assert not Conversion.get_converter("")

    # Valid converter
    c = Conversion.get_converter("text/html")
    assert c
    assert c.mime == "text/html"
    assert c.KEY == "html2text"

    print("Test is successful!")


# Generated at 2022-06-23 19:37:03.620306
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime(None) is False
    assert is_valid_mime('') is False
    assert is_valid_mime('/') is False
    assert is_valid_mime('application/x-www-form-urlencoded') is True
    assert is_valid_mime('application/json') is True
    assert is_valid_mime('application/json; charset=utf-8') is True

# Generated at 2022-06-23 19:37:10.206900
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    this_dict = {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5, 'g': 6, 'h': 7, 'i': 8, 'j': 9, 'k': 10, 'l': 11,
                 'm': 12,
                 'n': 13, 'o': 14, 'p': 15, 'q': 16, 'r': 17, 's': 18, 't': 19, 'u': 20, 'v': 21, 'w': 22, 'x': 23,
                 'y': 24,
                 'z': 25}
    total = 0
    for k, v in this_dict.items():
        print('Key: ', k, 'Value: ', v)
        total += 1
    print('Total: ', total)

# Generated at 2022-06-23 19:37:20.357458
# Unit test for constructor of class Conversion
def test_Conversion():
    assert not is_valid_mime('not valid')
    assert is_valid_mime('text/plain')
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/xml')
    assert is_valid_mime('application/javascript')
    assert is_valid_mime('application/x-www-form-urlencoded')

    converter = Conversion.get_converter('text/plain')
    assert converter is None

    converter = Conversion.get_converter('application/json')
    assert converter

    converter = Conversion.get_converter('application/xml')
    assert converter


# Generated at 2022-06-23 19:37:28.830686
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Test empty headers
    headers = ''
    formatter = Formatting(groups=[])
    assert headers == formatter.format_headers(headers)
    # Test plain text
    headers = 'Content-Type: plain/text'
    assert headers == formatter.format_headers(headers)
    # Test JSON
    headers = '{\n    "header": "value"\n}'
    assert headers == formatter.format_headers(headers)
    # Test XML
    headers = ('<xml>\n'
               '    <header>value</header>\n'
               '</xml>')
    assert headers == formatter.format_headers(headers)


# Generated at 2022-06-23 19:37:31.142047
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = 'text/json'
    converter = Conversion.get_converter(mime)
    assert converter is not None

# Generated at 2022-06-23 19:37:37.429643
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('/json')

import pytest

# Generated at 2022-06-23 19:37:40.015090
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter(mime='application/json')
    assert converter is not None

# Generated at 2022-06-23 19:37:49.508596
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.core import main
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPieOutputPlugin
    env = Environment()
    output = HTTPieOutputPlugin(env=env)
    output.enabled = True
    argv = ['httpie', '--json', '--pretty=all', 'http://httpbin.org/get']
    args = main.parse_args(argv=argv, env=env, output_options_override=True,
                           output_options=output.options)
    groups = args.prettify if args.prettify else ['all']
    formatting = Formatting(groups=groups, env=env)
    print(formatting.enabled_plugins)

if __name__ == '__main__':
    test_Formatting()

# Generated at 2022-06-23 19:37:53.269398
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['colors'], env=Environment())
    assert(fmt.enabled_plugins[0] is not None)

# Generated at 2022-06-23 19:37:56.520486
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatted_headers = Formatting(['colors']).format_headers(b'HTTP/1.1 200 OK\nX-Foo: Bar\n').decode('utf-8')
    print(formatted_headers)



# Generated at 2022-06-23 19:37:58.578283
# Unit test for constructor of class Conversion
def test_Conversion():
    x = Conversion()
    print(x)



# Generated at 2022-06-23 19:38:00.342321
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    formatter = Formatting(groups=['stdout', 'html'], env=env)
    assert formatter.enabled_plugins

# Generated at 2022-06-23 19:38:02.795336
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['colors'],colors=True)
    h1 = f.format_headers('HTTP/1.1 200 OK\r\nAccept: */*\r\n')
    h2 = f.format_headers('HTTP/1.1 200 OK\r\nAccept: */*\r\n')
    assert h1 == h2


# Generated at 2022-06-23 19:38:14.002965
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class FormattingTest:

        def setup_method(self):
            self.groups = []
            self.env = Environment()
            self.formatting = Formatting(self.groups, env=self.env)

        def test_format_body_for_not_HTML_content(self):
            content = '{"test_json_key":"test_json_value"}'
            mime = "application/json"
            expected = '{"test_json_key":"test_json_value"}'
            result = self.formatting.format_body(content, mime)
            assert result == expected

        def test_format_body_for_HTML_content(self):
            content = '<html><head></head><body><h1>test_HTML</h1></body></html>'
            mime = "text/html"
           

# Generated at 2022-06-23 19:38:17.381844
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    x = Formatting(groups=["json"])
    print(x.format_body(""" {
            "status": "OK",
            "message": "Uploaded",
            "code": 200
        }""", "application/json"))


# Generated at 2022-06-23 19:38:27.590893
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Create a httpie env of type Environment
    env = Environment()
    # Enable httpie env
    env.enable('HTTPTEST')
    # Create a formatting object
    f = Formatting(['colors', "headers"], env)
    # An input request
    headers = "Accept-Encoding: identity\nHost: httpbin.org\nUser-Agent: HTTPie/1.0.2\n"
    # Expected output

# Generated at 2022-06-23 19:38:36.078040
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class Formatter:
        def __init__(self, **kwargs):
            self.enabled = True
        def format_body(self, content: str, mime: str) -> str:
            return content + '-formatter_suffix'

    f = Formatting(['group'], **{'env': 'env'})
    f.enabled_plugins = [Formatter(**f.enabled_plugins[0].kwargs)]
    assert f.format_body('content', 'mime') == 'content-formatter_suffix'

# Generated at 2022-06-23 19:38:45.382772
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    e = Environment()
    e.stdout.isatty = lambda: True

    # Only plugins are enabled if requests >= 2.19.0
    # Else, plugins always returns False
    is_enabled = True if requests.__version__ >= '2.19.0' else False

    # Only enable plugins where response.is_redirect = False
    # Else, plugins always returns False
    enable_format_headers = Formatting(['format_headers'], env=e)
    assert (enable_format_headers.enabled_plugins[0].enabled == is_enabled)

    # Only enable plugins where response.is_redirect = True
    # Else, plugins always returns False

# Generated at 2022-06-23 19:38:52.958146
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # Given
    body = '{"id":1,"name":"Joe","age":12}'
    env = Environment()
    # When
    formatting = Formatting(groups=None, env=env, pretty=True)
    formatted_body = formatting.format_body(body,'application/json')
    # Then
    assert formatted_body == '{\n    "age": 12,\n    "id": 1,\n    "name": "Joe"\n}'

# Generated at 2022-06-23 19:38:56.679988
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/plain')
    assert not is_valid_mime('')
    assert not is_valid_mime('text')
    assert not is_valid_mime('plain')

# Generated at 2022-06-23 19:38:58.134699
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').__class__.__name__ == 'JSONConverterPlugin'

# Generated at 2022-06-23 19:39:01.553251
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = 'application/json'
    assert is_valid_mime(mime) == True
    assert Conversion.get_converter(mime).mime_type == mime
    assert Conversion.get_converter(mime).mime_type == mime

# Generated at 2022-06-23 19:39:05.692743
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():

    fmt = Formatting(['colors'], env=Environment())
    content = '{"server": "test"}'
    mime = 'application/json'

    print(fmt.format_body(content, mime))



# Generated at 2022-06-23 19:39:09.880720
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=["colors"], no_styles=True)
    input = "HTTP/1.1 200 OK\r\n\r\n"
    output = "HTTP/1.1 200 OK\n\n"
    assert f.format_headers(input) == output

# Generated at 2022-06-23 19:39:11.899210
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print(Formatting(['']).format_body('{name: "yui", age: "25"}', "application/json"))

# Generated at 2022-06-23 19:39:16.360767
# Unit test for constructor of class Conversion
def test_Conversion():
    # Test the import of Conversion
    from httpie.output.formatters import Conversion
    # Test the initializer of Conversion
    mime = 'application/json'
    assert Conversion.get_converter(mime) is not None
    mime = 'text/html'
    assert Conversion.get_converter(mime) is None


# Generated at 2022-06-23 19:39:17.116499
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    pass


# Generated at 2022-06-23 19:39:18.692270
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    fmt = Formatting(groups=['colors'], env=env)
    assert len(fmt.enabled_plugins) == 1

# Generated at 2022-06-23 19:39:24.962218
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors', 'headers']
    kwargs = {'headers': {}}
    headers = 'HTTP/1.1 200 OK\n' \
              'Content-Length: 11\n' \
              'Content-Type: text/plain\n' \
              'Date: Wed, 01 Apr 2020 02:19:27 GMT\n' \
              'Connection: keep-alive\n' \
              'Server: gunicorn/19.9.0\n' \
              'Via: 1.1 vegur'
    assert headers == Formatting(groups, **kwargs).format_headers(headers)


# Generated at 2022-06-23 19:39:32.855640
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(
        ['json'],
        env=Environment(colors='none'),
        indent=2,
        sort_keys=True,
        compact_encoding=True,
        encoding='utf8')
    content = '[{ "b": 2, "a": 1 }]'
    mime = 'application/json'
    assert f.format_body(content, mime) == '''[
  {
    "a": 1,
    "b": 2
  }
]'''

# Generated at 2022-06-23 19:39:34.736876
# Unit test for constructor of class Conversion
def test_Conversion():
    actual = Conversion.get_converter('application/json')
    expected = None
    assert actual == expected


# Generated at 2022-06-23 19:39:37.531100
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert converter != None
    assert str(converter) == "JSONConverter"


# Generated at 2022-06-23 19:39:47.755593
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(['headers'], env=Environment(),
                   color=True,
                   ssl=True,
                   verify=True,
                   debug=True
                   )
    import re
    reg = re.compile(r'(\r?\n)+')

# Generated at 2022-06-23 19:39:50.347154
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/html')
    assert is_valid_mime('image/jpeg')
    assert not is_valid_mime('application')
    assert not is_valid_mime('json')

# Generated at 2022-06-23 19:39:56.134546
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    Tests method format_body of class Formatting with different cases
    """
    import json
    import httpie.input
    f = Formatting(['colors'])
    body_dict = {
        "code": 0,
        "message": "OK",
        "data": {"1": 1, "2": 2},
        "time": "2019-09-04 15:32:43",
        "IP": "9.3.1.123"
    }
    body = json.dumps(body_dict)
    assert f.format_body(body, "application/json") == json.dumps(
        body_dict, indent=2, sort_keys=True, separators=(',', ': ')
    )