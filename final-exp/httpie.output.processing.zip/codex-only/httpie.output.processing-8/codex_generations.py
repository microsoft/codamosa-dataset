

# Generated at 2022-06-23 19:29:58.372930
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    formatting = Formatting(env=env, prefix='> ')
    assert formatting.enabled_plugins == [plugin_manager.get_default_formatter()]
    formatting = Formatting(['prefix'], env=env)
    assert formatting.enabled_plugins == [plugin_manager.get_default_formatter()]
    formatting = Formatting(['prefix'], env=env, prefix='> ')
    assert formatting.enabled_plugins == [plugin_manager.get_default_formatter()]
    formatting = Formatting(['colors'], env=env)
    assert formatting.enabled_plugins == []
    formatting = Formatting(['prefix', 'colors'], env=env)
    assert formatting.enabled_plugins == [plugin_manager.get_colors_formatter()]



# Generated at 2022-06-23 19:30:02.317061
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application')
    assert not is_valid_mime('/json')
    assert not is_valid_mime('/json/json')
    assert not is_valid_mime('json/json')

# Generated at 2022-06-23 19:30:09.718218
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class Plugin(FormattingPlugin):

        name = 'test'

        def format_body(self, content: str, mime: str) -> str:
            return content[::-1]

    plugin_manager.register_plugin(Plugin)

    conversion = Formatting(['tests'])

    assert conversion.format_body("1234", 'text/plain') == '4321'
    assert conversion.format_body("1234", 'applications/xml') == '1234'

    plugin_manager.unregister_plugin(Plugin)

# Generated at 2022-06-23 19:30:13.940673
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('text/html/reactive')
    assert not is_valid_mime('text/html/')

# Generated at 2022-06-23 19:30:17.825846
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('image/png') == True
    assert is_valid_mime('text') == False
    assert is_valid_mime('text/json') == False
    assert is_valid_mime('') == False



# Generated at 2022-06-23 19:30:20.498500
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'])
    s = "abcd"
    assert f.format_body("abcd", "text/plain") == s
    assert f.format_body("abcd", "text/text") == s

# Generated at 2022-06-23 19:30:26.635237
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    json_str = '{"name":"test(test_Formatting_format_body)","test":true}'
    inline_json_str = '{\"name\":\"test(test_Formatting_format_body)\",\"test\":true}'
    f = Formatting(['format'])
    assert json.loads(json_str) == json.loads(f.format_body(inline_json_str, "application/json"))

# Generated at 2022-06-23 19:30:29.998853
# Unit test for constructor of class Conversion
def test_Conversion():
    mime="application/json"
    assert is_valid_mime(mime)
    f = Conversion.get_converter(mime)
    assert f
    assert f.mime == "application/json"



# Generated at 2022-06-23 19:30:34.953918
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '{"status":"success","data":{"id":1,"name":"Test"}}'
    fmt = Formatting(["json"])
    result = fmt.format_body(content, "application/json")
    assert result == '{\n    "data": {\n        "id": 1,\n        "name": "Test"\n    },\n    "status": "success"\n}'

# Generated at 2022-06-23 19:30:45.130221
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment()
    env.stdout = io.StringIO()

    # import plugins for Formatting
    from httpie.plugins.builtin import HTTPHeaders
    from httpie.plugins.builtin import JSON
    from httpie.plugins.builtin import Pretty
    from httpie.plugins.builtin import PrintColors
    from httpie.plugins.builtin import Format
    
    # headers test (invalid)
    headers = "key: value"
    result_headers = Formatting.format_headers(headers, env=env)
    print(result_headers)
    #assert the result should be unchanged
    assert headers == result_headers

    # headers test (valid)

# Generated at 2022-06-23 19:30:46.639175
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion
    assert c.get_converter('*/*') is None
    ass

# Generated at 2022-06-23 19:30:51.821625
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f=Formatting(['colors'],stream=True,headers='[{"Content-Type": "application/json"}]')
    # assert f.format_headers == '{\n    "Content-Type": "application/json"\n}'
    assert f.format_headers(f.headers) == '{\n    "Content-Type": "application/json"\n}'

# Generated at 2022-06-23 19:30:55.600275
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('text')
    assert not is_valid_mime('')
    assert not is_valid_mime('foobar/')

# Generated at 2022-06-23 19:31:02.111311
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('image/png')
    assert is_valid_mime('image/jpeg')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/xml')
    assert is_valid_mime('application/x-www-form-urlencoded')
    assert is_valid_mime('application/vnd.1.0+json')
    assert not is_valid_mime('/')
    assert not is_valid_mime('/foo')
    assert not is_valid_mime('foo/')
    assert not is_valid_mime('foo/bar')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:31:04.538263
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    formatting = Formatting(groups=['json', 'colors'], env=env)
    assert type(formatting) is Formatting


# Generated at 2022-06-23 19:31:14.216219
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['color'], env=Environment())
    assert f.enabled_plugins[0].__class__.__name__ == 'ColorFormatter'
    f = Formatting(groups=['param'], env=Environment())
    assert f.enabled_plugins[0].__class__.__name__ == 'ParameterFormatter'
    f = Formatting(groups=['param', 'color'], env=Environment())
    assert f.enabled_plugins[0].__class__.__name__ == 'ParameterFormatter'
    assert f.enabled_plugins[1].__class__.__name__ == 'ColorFormatter'
    f = Formatting(groups=[], env=Environment())
    assert len(f.enabled_plugins) == 0

# Generated at 2022-06-23 19:31:18.929238
# Unit test for constructor of class Formatting
def test_Formatting():
    available_plugins = plugin_manager.get_formatters_grouped()
    for group in ['colors']:
        for cls in available_plugins[group]:
                p = cls(None, None)
                if p.enabled:
                    assert p is not None

groups = ['colors']

# Test Formatting.format_headers

# Generated at 2022-06-23 19:31:28.072934
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    """
    Test for method format_headers of class Formatting
    
    """
    env = Environment()
    headers = "Content-Type: text/html; charset=utf-8"
    formatting = Formatting(groups=["b64"], env=env)
    output = formatting.format_headers(headers)
    expected_output = "Q29udGVudC1UeXBlOiB0ZXh0L2h0bWw7IGNoYXJzZXQ9dXRmLTg"
    assert output == expected_output, "Output was not in the expected format"
    print("Pass")


# Generated at 2022-06-23 19:31:35.434540
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/csv')
    assert isinstance(is_valid_mime('abc'), bool)
    assert is_valid_mime('image/jpeg')
    assert is_valid_mime('image/png')
    assert not is_valid_mime('image/png1')
    assert not is_valid_mime('application/jso')
    assert not is_valid_mime('')

# Generated at 2022-06-23 19:31:43.646241
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_1 = Conversion.get_converter('application/json')
    converter_2 = Conversion.get_converter('application/xml')
    converter_3 = Conversion.get_converter('application/msgpack')
    converter_4 = Conversion.get_converter('application/hal+json')
    converter_5 = Conversion.get_converter('application/vnd.collection+json')
    converter_6 = Conversion.get_converter('application/problem+json')
    converter_7 = Conversion.get_converter('application/vnd.siren+json')
    converter_8 = Conversion.get_converter('application/vnd.api+json')

    assert converter_1.name == 'json'
    assert converter_2.name == 'xml'

# Generated at 2022-06-23 19:31:52.447380
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():

    f = Formatting(['colors', 'format'], env=None, colors=True, colors_256=True)
    test_string = "HTTP/1.1 200 OK\r\n\r\n<h1>h1</h1>"

# Generated at 2022-06-23 19:31:55.254082
# Unit test for constructor of class Conversion
def test_Conversion():
    env = Environment()
    fmt = Formatting(['colors'], env=env)
    fmt.format_headers("content-type")

# Generated at 2022-06-23 19:31:59.834809
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('text')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('/html')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:32:09.481093
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins.builtin.tests.test_formatter import str_dict
    from httpie.plugins.builtin.tests.test_formatter import str_list
    from httpie.plugins.builtin.tests import test_formatter
    from httpie.compat import urlparse

    env = test_formatter.Environment(colors=256)
    fm = Formatting(['format'], env=env)
    headers = fm.format_headers(str_dict)
    assert headers == 'Content-Type: text/html; charset=utf-8' + '\r\n' + 'Content-Length: 1234' + '\r\n' + 'Content-Encoding: gzip' + '\r\n' + 'Connection: keep-alive'


# Generated at 2022-06-23 19:32:13.414445
# Unit test for constructor of class Formatting
def test_Formatting():
    x = Formatting(groups=['colors', 'formatters'])
    assert x.enabled_plugins == []
    x = Formatting(groups=['colors'])
    assert x.enabled_plugins != []
    assert x.enabled_plugins[0].__class__.__name__ == 'Win32'

# Test for is_valid_mime

# Generated at 2022-06-23 19:32:18.343241
# Unit test for constructor of class Conversion
def test_Conversion():
    """
    Unit test for get_converter method in class Conversion

    """
    mime = 'application/json'
    c = Conversion.get_converter(mime)
    assert c.name == 'json'
    assert c.type == 'application'
    assert c.subtype == 'json'
    assert c.accept() == 'application/json, */*'
    assert c.accept_encoding() == ''
    assert c.text_content_type() == 'application/json'
    assert c.json_content_type() == 'application/json'
    assert c.best_content_type(['application/json']) == 'application/json'
    assert c.best_content_type(['application/json', 'application/xml']) == 'application/json'

    # Unit test for get_converter

# Generated at 2022-06-23 19:32:19.783306
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('text/json') == True
    assert is_valid_mime('json') == False
    assert is_valid_mime('application/json/') == False

# Generated at 2022-06-23 19:32:22.012516
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=['format', 'joke'])
    mime = 'application/json'
    content = '{"foo": "bar"}'
    formated = f.format_body(content, mime)
    expected = '{"foo": "bar"}'
    assert formated == expected

# Generated at 2022-06-23 19:32:23.220721
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(groups=['colors'])



# Generated at 2022-06-23 19:32:25.045987
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime("application/json")
    assert is_valid_mime("text/html")
    assert not is_valid_mime("html")
    assert not is_valid_mime("")


# Generated at 2022-06-23 19:32:30.294364
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '''{
   "jsonrpc": "2.0",
   "method": "get_blocks",
   "params": ["1.2.439183", "1.2.439181"],
   "id": "31"
}'''
    mime = 'application/json'
    formatting = Formatting(['JSON'])
    print(formatting.format_body(content, mime))



# Generated at 2022-06-23 19:32:40.811854
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application-json') == False
    assert is_valid_mime('application/') == False
    assert is_valid_mime('/json') == False
    assert is_valid_mime('application') == False
    assert is_valid_mime('') == False
    assert is_valid_mime(None) == False
    assert is_valid_mime('application/json; charset=utf-8') == True
    assert is_valid_mime('application/json;charset=utf-8') == True
    assert is_valid_mime(' application/json;charset=utf-8') == False
    assert is_valid_mime('application/json;charset=utf-8 ') == False

# Generated at 2022-06-23 19:32:45.952942
# Unit test for constructor of class Formatting
def test_Formatting():
    """
    test Formatting constructor:
    Formatting.__init__(self, groups: List[str], env=Environment(), **kwargs) -> None
    :return: None
    """
    format = Formatting(['colors'])
    assert 'colors' in format.enabled_plugins
    assert 'format' not in format.enabled_plugins


# Generated at 2022-06-23 19:32:52.933667
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format', 'formatvars']
    env = Environment()
    kwargs = dict(compact=True, prettify=True, style=None, style_default=env.colors.enabled)
    a = Formatting(groups, env, **kwargs)
    assert (a.enabled_plugins[0].__class__.__name__ == 'ColorsFormatter')
    assert (a.enabled_plugins[1].__class__.__name__ == 'FormatFormatter')
    assert (a.enabled_plugins[2].__class__.__name__ == 'FormatVarsFormatter')


# Generated at 2022-06-23 19:32:56.636352
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors', 'format']
    env = Environment()
    kwargs = {'colors_assign_only': False, 'format': "None"}
    formatting = Formatting(groups, env, **kwargs)
    assert formatting

# Generated at 2022-06-23 19:33:05.053849
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-23 19:33:09.623751
# Unit test for constructor of class Conversion
def test_Conversion():
    test_list = [
        (None, None),
        ('application/json', 'json'),
        ('text/html', None),
        ('text/html,application/json', None)
    ]
    for testcase in test_list:
        result = is_valid_mime(testcase[0])
        expected = testcase[1]
        assert result == expected

# Generated at 2022-06-23 19:33:16.766484
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("image/png").__class__.__name__ == "PngConverter"
    assert Conversion.get_converter("text/html").__class__.__name__ == "HtmlConverter"
    assert Conversion.get_converter("application/json").__class__.__name__ == "JsonConverter"
    assert Conversion.get_converter("application/x-www-form-urlencoded").__class__.__name__ == "FormUrlEncodeConverter"
    assert not Conversion.get_converter("application/x-www-form-urlencoded")
    assert not Conversion.get_converter("text/plain")
    assert not Conversion.get_converter("image/jpeg")

# Generated at 2022-06-23 19:33:23.628730
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting = Formatting(groups=['headers'], env=Environment(), format='colors')
    headers = formatting.format_headers("'Host': 'localhost:8081'\n'Content-Length': '2'\n'Accept': '*/*'\n'Content-Type': 'application/json'\n")
    assert headers == "'Host': 'localhost:8081'\n'Content-Length': '\x1b[1;30m2\x1b[0m'\n'Accept': '\x1b[1;30m*/*\x1b[0m'\n'Content-Type': 'application/json'\n"

# Generated at 2022-06-23 19:33:26.027973
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()
    assert c is not None



# Generated at 2022-06-23 19:33:33.807255
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    headers = """HTTP/1.1 200 OK
Connection: close
Content-Length: 14
Content-Type: application/json
Date: Mon, 04 May 2020 16:45:30 GMT
Server: BaseHTTP/0.6 Python/3.7.5

{"a":"b"}"""
    formatting = Formatting(groups=['colors'], style='paraiso-dark')
    assert formatting.format_body(content=headers, mime='application/json') == """HTTP/1.1 200 OK
Connection: close
Content-Length: 14
Content-Type: application/json
Date: Mon, 04 May 2020 16:45:30 GMT
Server: BaseHTTP/0.6 Python/3.7.5


{
    "a": "b"
}
"""

# Generated at 2022-06-23 19:33:41.070665
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    headers_mime = 'headers'
    body_mime = 'application/json'
    json_body = '{"status": "success"}'
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Header1: Value1\r\n' \
              'Header2: Value2\r\n' \
              '\r\n' \
              '{}\r\n' \
              '\r\n'

    # Test Formatting object construction
    f = Formatting(groups)

    # Test empty output
    assert f.format_headers('') == ''
    assert f.format_body('', '') == ''

    # Test non-matching outputs
    assert f.format_headers('headers') == 'headers'

# Generated at 2022-06-23 19:33:43.242436
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """
    Test method get_converter of class Conversion
    """
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)

# Generated at 2022-06-23 19:33:46.212049
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert Conversion.get_converter('application/xml').mime == 'application/xml'
    assert Conversion.get_converter('text/plain').mime == 'text/plain'
    assert Conversion.get_converter('text/html').mime == 'text/html'
    assert not Conversion.get_converter('bad-mime')

# Unit tests for method format_headers of class Formatting

# Generated at 2022-06-23 19:33:54.425052
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_mime="application/json"
    result=Conversion.get_converter(test_mime)
    assert result.mime == test_mime
    assert result.supports(test_mime)
    test_mime="application/json;charset=utf-8"
    result=Conversion.get_converter(test_mime)
    assert result.mime == test_mime
    assert result.supports(test_mime)
    test_mime="application/vnd.api+json;"
    result=Conversion.get_converter(test_mime)
    assert result.mime == test_mime
    assert result.supports(test_mime)

# Generated at 2022-06-23 19:33:56.534737
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter("application/json")
    assert c is not None


# Generated at 2022-06-23 19:34:02.690503
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print("Start test for method format_body of class Formatting")
    groups = ["colors"]
    formatting = Formatting(groups)
    mime = "application/json"
    content = '{"a": 1, "b": true}'
    content = formatting.format_body(content, mime)
    print("content: {}".format(content))
    print("End test for method format_body of class Formatting")



# Generated at 2022-06-23 19:34:03.963954
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()
    assert isinstance(c, Conversion)

# Generated at 2022-06-23 19:34:12.013912
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html")
    assert is_valid_mime("application/json")
    assert is_valid_mime("application/x-www-form-urlencoded")
    assert is_valid_mime("application/vnd.api+json")
    assert is_valid_mime("application/vnd+json")
    assert is_valid_mime("text/vnd+custom")
    assert is_valid_mime("application/vnd.custom+json")
    assert not is_valid_mime("application/vnd.custom")
    assert not is_valid_mime("text/")
    assert not is_valid_mime("/json")
    assert not is_valid_mime("text/html+custom")
    assert not is_valid_mime("")

# Generated at 2022-06-23 19:34:14.111362
# Unit test for constructor of class Conversion
def test_Conversion():
    assert(isinstance(Conversion.get_converter('application/json'), ConverterPlugin))


# Generated at 2022-06-23 19:34:25.293300
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    text = "HTTP/1.1 200 OK\r\n" \
           "Date: Sat, 11 Jan 2020 18:57:16 GMT\r\n" \
           "Server: Apache/2.4.18 (Ubuntu)\r\n" \
           "Content-Length: 508\r\n" \
           "Keep-Alive: timeout=5, max=100\r\n" \
           "Connection: Keep-Alive\r\n" \
           "Content-Type: text/html; charset=iso-8859-1\r\n" \
           "\r\n"
    formatter = Formatting(groups=["colors"])
    result = formatter.format_headers(text)

# Generated at 2022-06-23 19:34:29.318792
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/html')

    assert not is_valid_mime('application/')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application html')

# Generated at 2022-06-23 19:34:32.641763
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.__class__.__name__ == 'JSONConverter'


# Generated at 2022-06-23 19:34:35.539302
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert repr(Conversion.get_converter('application/json')) == '<JsonConverter({\'mime\': \'application/json\'})>'

# Generated at 2022-06-23 19:34:40.622856
# Unit test for constructor of class Formatting
def test_Formatting():
    import os
    import json
    from httpie.plugins import FormatterPlugin, ConverterPlugin

    class JsonFormatter(FormatterPlugin):
        """
        This class serves as a sample formatter plugin to invoke Formatting class when no formatter class is applied
        """
        name = 'json formatter'
        description = 'JSON formatter'
        headers_cls = None
        body_cls = None
        version = '0.0.1'
        pyversion = '3.6'
        author = 'Ting'
        author_email = 'ting.hsieh@sap.com'
        homepage = 'http://leela.ai'
        entrypoint_group = 'httpie.formatter.v0'

        def format_headers(self, headers: str) -> str:
            return headers


# Generated at 2022-06-23 19:34:49.275782
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors', 'format'])
    mime = 'application/json'
    content = '{"name":"tiger","age":3,"weight":38}'
    expect = '{\x1b[32m"name"\x1b[39m:\x1b[34m"tiger"\x1b[39m,' \
             '\x1b[32m"age"\x1b[39m:\x1b[34m3\x1b[39m,' \
             '\x1b[32m"weight"\x1b[39m:\x1b[34m38\x1b[39m}'
    assert f.format_body(content, mime) == expect
# Test End

# Generated at 2022-06-23 19:34:52.911892
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Arrange
    groups = ["format"]
    env = Environment()
    fmt = Formatting([], env)
    data = "file1:file2"
    # Act
    res = fmt.format_headers(data)
    # Assert
    assert(res == 'file1\nfile2')


# Generated at 2022-06-23 19:34:58.742835
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = "application/json"
    result = Conversion.get_converter(mime)
    assert result.name == "json"
    assert result.decode(b'{"test": "test2"}') == {"test": "test2"}
    assert result.encode({"test": "test2"}) == b'{"test": "test2"}'


# Generated at 2022-06-23 19:35:01.583525
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting([])
    assert Formatting(['colors'])
    assert Formatting(['colors', 'format'])
    assert Formatting(['colors', 'format'], env=Environment())

# Generated at 2022-06-23 19:35:09.851382
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie import __version__

    # Test case to validate format_headers method of class Formatting
    # when input parameter headers is empty string
    def test_Formatting(headers):
        # Create instance of class Formatting
        with Environment(
            stdin_isatty=True,
            stdout_isatty=True,
            stdin=io.BytesIO(),
            stdout=io.BytesIO(),
            output_options={"isatty": True},
        ) as env:
            formatting = Formatting(['colors'], env=env)
            # Validate method format_headers of class Formatting
            # Response of method format_headers should be empty
            response = formatting.format_headers(headers)
            print(response)
            assert response == ""

    # Execute method test_Formatting of unit test
    test

# Generated at 2022-06-23 19:35:13.410830
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test with an unknown MIME type
    res = Conversion.get_converter("mymime/myformat")
    assert res is None
    # Test with an existing MIME type
    res = Conversion.get_converter("application/json")
    assert res is not None


# Generated at 2022-06-23 19:35:24.254539
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    a = Formatting(['colors'], env=Environment())
    b = Formatting(['colors'], env=Environment())
    c = Formatting(['colors'], env=Environment())
    assert a.format_body("Hi, there!", "text/plain") == "\x1b[34m\x1b[1mHi, there!\x1b[22m\x1b[39m"
    assert b.format_body("Hi, there!", "application/json") == "\x1b[32m\x1b[1mHi, there!\x1b[22m\x1b[39m"
    assert c.format_body("Hi, there!", "invalid/mime") == "Hi, there!"

# Generated at 2022-06-23 19:35:28.125445
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatter = Formatting(env=Environment(), color=False, default_colors=False)
    assert formatter.format_headers("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nCache-Control: no-cache\r\n\r\n") == "HTTP/1.1 200 OK\nContent-Type: text/html\nCache-Control: no-cache\n\n"

# Generated at 2022-06-23 19:35:35.727532
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    test_list = ['Status: 200\nContent-Type: text/html\n',
                 'Status: 200\nContent-Type: application/json\n']
    result_list = ['Status: 200',
                   'Content-Type: text/html',
                   'Status: 200',
                   'Content-Type: application/json']
    formatter = Formatting(['HTTPHeadersProcessor'])
    for test,result in zip(test_list, result_list):
        assert formatter.format_headers(test) == result


# Generated at 2022-06-23 19:35:37.989292
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application//json') == False
    assert is_valid_mime('application/') == False
    assert is_valid_mime('/json') == False
    assert is_valid_mime('json') == False

# Generated at 2022-06-23 19:35:44.246979
# Unit test for constructor of class Formatting
def test_Formatting():
    # Arrange
    import httpie
    from httpie.plugins.builtin import HTTPPrettyJSONPlugin
    from httpie.plugins.builtin import HTTPPrettyPlugin
    from httpie.plugins.builtin import PrettyJsonPlugin
    plugin_list = [HTTPPrettyJSONPlugin, HTTPPrettyPlugin, PrettyJsonPlugin]
    test_format = Formatting(["JSON"])

# Generated at 2022-06-23 19:35:47.027992
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    json_str = '{"id": "1", "name": "Mark"}'
    groups = ['json']
    env = Environment()
    formatting = Formatting(groups, env)
    content = formatting.format_body(json_str, 'application/json')
    assert content == '{\n    "id": "1",\n    "name": "Mark"\n}'

# Generated at 2022-06-23 19:35:55.556725
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application//json')
    assert not is_valid_mime('applicationjson')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:36:00.502099
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['lorem', 'ipsum']
    assert Formatting(groups, env).enabled_plugins == []
    groups = ['lorem', 'highlight']
    assert Formatting(groups, env).enabled_plugins is not []
    env.stdout_isatty = False
    assert Formatting(groups, env).enabled_plugins == []

# Generated at 2022-06-23 19:36:05.107979
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    json_mock = {"name": "Tania", "role": "Software Developer"}
    json_string_mock = json.dumps(json_mock)
    assert Formatting(["colors"]).format_body(json_string_mock, "application/json") == json_string_mock

# Generated at 2022-06-23 19:36:07.072873
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting([])
    assert f.format_headers('Accept: application/json') == 'Accept: application/json'


# Generated at 2022-06-23 19:36:08.253015
# Unit test for constructor of class Formatting
def test_Formatting():
	Formatting(["activity", "colors"], env=Environment())

# Generated at 2022-06-23 19:36:18.780180
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    class AConverterPlugin(ConverterPlugin):
        def __init__(self, mime):
            super().__init__(mime)
        @classmethod
        def supports(cls, mime):
            return mime in [
                'text/html',
                'text/plain'
            ]
        def convert(self, content):
            return content

    plugin_manager.register_plugin(AConverterPlugin)

    converter = Conversion.get_converter('text/html')
    assert converter is not None
    assert converter.mime == 'text/html'

    converter = Conversion.get_converter('text/plain')
    assert converter is not None
    assert converter.mime == 'text/plain'

# Generated at 2022-06-23 19:36:22.927200
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print(Conversion.get_converter('application/xml'))
    print(Conversion.get_converter('application/json'))
    print(Conversion.get_converter('application/json1'))


# Generated at 2022-06-23 19:36:25.299581
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    unit_test = Formatting(["colors"])
    unit_test_header = "Content-Type: json"
    assert unit_test.format_headers(unit_test_header) == "Content-Type: json"  # no-color


# Generated at 2022-06-23 19:36:28.631181
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json")
    assert not Conversion.get_converter("application")
    assert not Conversion.get_converter("")
    assert not Conversion.get_converter(None)


# Generated at 2022-06-23 19:36:31.327957
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime(mime='text/plain')
    assert not is_valid_mime(mime='text')
    assert not is_valid_mime(mime=None)

# Generated at 2022-06-23 19:36:38.317733
# Unit test for function is_valid_mime
def test_is_valid_mime():
    test_cases = ['a/b', 'a/b/', '', ' ', '/', 'a/b/c', 'a//', '\n', '\na/\n']
    for test_case in test_cases:
        assert is_valid_mime(test_case) == False
    test_cases = ['a/b', 'a/b/c']
    for test_case in test_cases:
        assert is_valid_mime(test_case) == True


# Generated at 2022-06-23 19:36:41.852238
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=['html'])
    a = f.format_body(content='<h1>Hello world!</h1>', mime='text/html')
    b = "<html><body><h1>Hello world!</h1></body></html>"
    assert a == b

# Generated at 2022-06-23 19:36:46.510900
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    obj = Formatting(['colors'])
    assert obj.format_body("{'key_1': 'val_1', 'key_2': 'val_2'}", 'application/json') == '{\n    "key_1": "val_1", \n    "key_2": "val_2"\n}\n'


# Generated at 2022-06-23 19:36:53.772678
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ['syntax', 'colors']
    env = Environment()
    formatting = Formatting(groups, env)
    mime = 'application/json'
    content = '{"date": "2017-01-01", "key": "value"}'

# Generated at 2022-06-23 19:36:58.067733
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert(converter.__class__ == ConverterPlugin)

# Generated at 2022-06-23 19:37:04.320388
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/plain').__class__.__name__ == 'ConverterTextPlain'
    assert Conversion.get_converter('text/html').__class__.__name__ == 'ConverterTextHtml'
    assert Conversion.get_converter('text/csv').__class__.__name__ == 'ConverterTextCsv'
    assert Conversion.get_converter('image/jpeg').__class__.__name__ == 'ConverterImageJpeg'


# Generated at 2022-06-23 19:37:11.312195
# Unit test for constructor of class Conversion
def test_Conversion():
    # test when mime with incorrect string format
    result_1 = Conversion.get_converter(mime='incorrect string format')
    assert result_1 == None

    # test when mime with correct string format
    result_1 = Conversion.get_converter(mime='correct/string')
    assert result_1 != None

# Generated at 2022-06-23 19:37:17.586132
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['formatters']
    available_plugins = plugin_manager.get_formatters_grouped()
    env = Environment()
    kwargs = {}

    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=env, **kwargs)
            if p.enabled:
                enabled_plugins = [p]

    assert len(enabled_plugins) == 1

# Generated at 2022-06-23 19:37:25.445652
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import copy
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPieJSONPlugin, HTTPiePrettyOptionsPlugin
    env = Environment()
    kwargs = {}
    httpie_json = HTTPieJSONPlugin(env=env, **kwargs)
    httpie_pretty = HTTPiePrettyOptionsPlugin(env=env, **kwargs)
    # with httpie_json.plugin_enabled()
    httpie_json.enabled = True
    # with httpie_pretty.plugin_enabled()
    httpie_pretty.enabled = True
    mock_plugins = [httpie_json, httpie_pretty]
    fm = Formatting(groups=[], env=env, **kwargs)
    fm.enabled_plugins = copy.deepcopy(mock_plugins)

# Generated at 2022-06-23 19:37:32.191985
# Unit test for constructor of class Conversion
def test_Conversion():
    assert(is_valid_mime("text/.")==False)#not valid mime
    assert(is_valid_mime("text/html")==True)#valid mime
    converter = Conversion.get_converter("application/json")
    assert(converter.mime == "application/json")
    assert(converter.format_name == "json")


# Generated at 2022-06-23 19:37:38.200634
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = "application/json"
    assert Conversion.get_converter(mime).mime == mime
    assert Conversion.get_converter("application/json; charset=utf-8").mime == mime
    assert not Conversion.get_converter("text/plain")

# Generated at 2022-06-23 19:37:41.872453
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    ret = Conversion.get_converter("application/json")
    assert ret
    ret = Conversion.get_converter("impossible/mime")
    assert ret is None



# Generated at 2022-06-23 19:37:48.773198
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.builtin import JSONFormatterPlugin, HTMLFormatterPlugin
    from httpie.plugins.registry import plugin_manager
    plugin_manager.add_plugin_class(JSONFormatterPlugin)
    plugin_manager.add_plugin_class(HTMLFormatterPlugin)
    formatting = Formatting(['content'])

    # test case 1: Accept: text/html
    headers = 'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{'
    fmt = formatting.format_body(headers, 'application/json')
    assert '<pre>' in fmt

    # test case 2: Accept: application/json

# Generated at 2022-06-23 19:37:53.180275
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('/json')

# Generated at 2022-06-23 19:37:58.251480
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    assert not is_valid_mime("")
    assert not is_valid_mime("application")
    assert not is_valid_mime("/json")
    assert not is_valid_mime("application:json")
    assert not is_valid_mime("application/json/foo")

# Generated at 2022-06-23 19:38:08.783298
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert not is_valid_mime('/')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('text//')
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/vnd.api+json')

    assert Conversion.get_converter('application/json')
    assert Conversion.get_converter('application/vnd.api+json')
    assert not Conversion.get_converter('text/html')

    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert Conversion.get_converter('application/vnd.api+json').mime == 'application/vnd.api+json'

# Generated at 2022-06-23 19:38:19.304008
# Unit test for constructor of class Formatting
def test_Formatting():
    # environment for testing
    env = Environment()
    env.config.color = False
    env.stdout = StringIO()
    env.config.output_options["style"] = "default"
    env.config.output_options["format"] = "last"
    env.config.output_options["implicit_content_type"] = None
    env.config.output_options["nicer"] = True
    env.config.output_options["pretty"] = False
    env.config.output_options["prettify"] = False
    env.config.output_options["print_body"] = "always"
    env.config.output_options["stream"] = False
    env.config.output_options["verify"] = "no"
    env.config.style = env.styles.get('default')
    env.stdin = String

# Generated at 2022-06-23 19:38:22.813159
# Unit test for constructor of class Conversion
def test_Conversion():
    # test when spec is a converter available
    assert Conversion.get_converter('application/json') is not None
    # test when spec is not a converter available
    assert Conversion.get_converter('application/python') is None


# Generated at 2022-06-23 19:38:28.858340
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    assert(Formatting(['format']).format_body("{\"hello\":\"world\"}", "application/json") == "{\"hello\":\"world\"}"
           and Formatting(['format']).format_body("{\"hello\":\"world\"}", "application/xml") == "{\"hello\":\"world\"}"
           and Formatting(['format']).format_body("{\"hello\":\"world\"}", "application/csv") == "{\"hello\":\"world\"}")



# Generated at 2022-06-23 19:38:32.668863
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application/json/testing')
    assert not is_valid_mime('application/JSON')

# Generated at 2022-06-23 19:38:34.457031
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('image/png').mime == 'image/png'


# Generated at 2022-06-23 19:38:42.742619
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # one single none converter
    assert Conversion.get_converter('abc/abc') == None

    # one single converter
    converter = Conversion.get_converter('application/json')

    assert isinstance(converter, ConverterPlugin)
    assert isinstance(converter.mimetype, str)
    assert isinstance(converter.process_body, staticmethod)
    assert isinstance(converter.process_body, staticmethod)
    assert isinstance(converter.process_headers, staticmethod)

    # two converters
    converter = Conversion.get_converter('application/sql')

    assert isinstance(converter, ConverterPlugin)
    assert isinstance(converter.mimetype, str)
    assert isinstance(converter.process_body, staticmethod)
   

# Generated at 2022-06-23 19:38:44.220366
# Unit test for constructor of class Conversion
def test_Conversion():
    assert isinstance(Conversion.get_converter("application/xml"), ConverterPlugin)



# Generated at 2022-06-23 19:38:50.450809
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    Formatting_obj = Formatting(None)
    Formatting_obj.enabled_plugins = list()
    Formatting_obj.enabled_plugins.append(__name__+".py")
    res = Formatting_obj.format_headers("input")
    assert res == "input"


# Generated at 2022-06-23 19:38:52.761135
# Unit test for constructor of class Conversion
def test_Conversion():
    _mime = 'application/json'
    assert isinstance(Conversion.get_converter(_mime), ConverterPlugin)


# Generated at 2022-06-23 19:39:02.878561
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    format_headers_input = 'HTTP/1.1 200\r\nDate: Sun, 28 Aug 2016 16:54:42 GMT\r\nServer: Apache\r\nContent-Length: 271\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n'
    format_headers_output = 'HTTP/1.1 200\r\nDate: Sun, 28 Aug 2016 16:54:42 GMT\r\nServer: Apache\r\nContent-Length: 271\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n'
    assert Formatting(['http', 'preview']).format_headers(format_headers_input) == format_headers_output


# Generated at 2022-06-23 19:39:05.740924
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter_plugin = Conversion.get_converter('application/json')
    assert type(converter_plugin) is ConverterPlugin

# Generated at 2022-06-23 19:39:16.047297
# Unit test for constructor of class Formatting
def test_Formatting():
    """Test Formatting class."""
    json = '{"key":"value"}'
    headers = 'HTTP/1.1 200 OK\r\n' \
              'Content-Type: text/html\r\n' \
              'Date: Mon, 27 Jul 2009 12:28:53 GMT\r\n' \
              'Server: Apache/2.2.14 (Win32)\r\n' \
              'Last-Modified: Wed, 22 Jul 2009 19:15:56 GMT\r\n' \
              'Content-Length: 88\r\n' \
              'Connection: Closed\r\n'
    print(Formatting(groups=['highlight', 'colors'],
        env=Environment(pprint=False)).format_body(json, "application/json"))

# Generated at 2022-06-23 19:39:19.456286
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    grouplist = ['json']
    kwargs = {}
    print('<----------------------------->')
    print(Formatting(grouplist,env=env,**kwargs).format_body('{"hello": "world"}', 'application/json'))
    print('<----------------------------->')

# test_Formatting_format_body()

# Generated at 2022-06-23 19:39:28.892725
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import os
    import httpie
    test_dir = os.path.dirname(os.path.dirname(httpie.__file__))
    output_dir = os.path.join(test_dir, 'tests/output')
    input_dir = os.path.join(test_dir, 'tests/input')
    with open(os.path.join(input_dir, 'current.input'), 'r') as file_input:
        input_data = file_input.read()
        with open(os.path.join(output_dir, 'current.output'), 'r') as file_output:
            expected_data = file_output.read()
            test_case = Formatting(groups = ['colors', 'format'])
            actual_data = test_case.format_body(input_data, 'application/json')

# Generated at 2022-06-23 19:39:32.587068
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application/unknown') == False
    assert is_valid_mime('app/unknown') == False
    assert is_valid_mime('/unknown') == False

# Generated at 2022-06-23 19:39:34.170142
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    conversion = Conversion()
    converter = conversion.get_converter("application/json")
    assert converter is not None

# Generated at 2022-06-23 19:39:36.851587
# Unit test for constructor of class Conversion
def test_Conversion():
    test_input = 'text/plain'
    test_class = Conversion.get_converter(test_input)
    assert test_class.supports('text/plain') == True

# Generated at 2022-06-23 19:39:40.967216
# Unit test for constructor of class Conversion
def test_Conversion():
    # Unit test for "get_converter" of class Conversion
    def test_get_converter():
        assert is_valid_mime("test/test") == True
        assert is_valid_mime(None) == False

    test_get_converter()

test_Conversion()



# Generated at 2022-06-23 19:39:50.461759
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/javascript')
    assert is_valid_mime('application/vnd.api+json')
    assert is_valid_mime('application/postscript')
    assert is_valid_mime('image/png')
    assert is_valid_mime('image/svg+xml')
    assert is_valid_mime('text/plain')
    assert is_valid_mime('text/html')
    assert is_valid_mime('text/css')
    assert is_valid_mime('text/javascript')
    assert is_valid_mime('text/csv')
    assert is_valid_mime('video/mp4')
    assert is_valid_mime('audio/mpeg')
    assert not is_valid_