

# Generated at 2022-06-23 19:30:01.811939
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_env = Environment()
    test_env.colors = False
    test_formatter = Formatting(['format', 'colors'], env=test_env)
    test_formatter.enabled_plugins[0]._print = lambda x: x
    test_format_body = test_formatter.format_body('{"name":"John","age":30,"car":null}', 'application/json')
    assert test_format_body == '{\n  "name": "John", \n  "age": 30, \n  "car": null\n}'
    test_formatter.enabled_plugins[0]._print = lambda x: '\x1b[' + x + 'm'

# Generated at 2022-06-23 19:30:07.103012
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    print(Formatting(['colors']).format_headers('''Content-Type: text/html;  charset=utf-8
Server: nginx/1.12.2
Date: Tue, 06 Mar 2018 06:01:03 GMT
Content-Length: 11173
Connection: keep-alive
Vary: Accept-Encoding
X-Frame-Options: SAMEORIGIN
X-XSS-Protection: 1; mode=block
X-Content-Type-Options: nosniff
Strict-Transport-Security:max-age=15552000'''))


# Generated at 2022-06-23 19:30:08.025151
# Unit test for constructor of class Conversion
def test_Conversion():
    assert isinstance(Conversion(), Conversion)

# Generated at 2022-06-23 19:30:10.786538
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['format_command', 'format_colors'])
    assert isinstance(fmt, Formatting)



# Generated at 2022-06-23 19:30:14.040759
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter('image/jpeg') is not None
    assert Conversion.get_converter('not/valid') == None



# Generated at 2022-06-23 19:30:16.625646
# Unit test for function is_valid_mime
def test_is_valid_mime():
    def test_case(test_input, expected):
        actual = is_valid_mime(test_input)
        assert actual == expected

    test_case('application/json', True)
    test_case('', False)
    test_case('application/', False)
    test_case('/json', False)
    test_case('application', False)
    test_case(None, False)

# Generated at 2022-06-23 19:30:18.382678
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    assert is_valid_mime("foo/bar")
    assert not is_valid_mime("")
    assert not is_valid_mime("a/b/c")
    assert not is_valid_mime("foobar")

# Generated at 2022-06-23 19:30:20.889144
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html")
    assert not is_valid_mime("")
    assert not is_valid_mime("texthtml")
    asser

# Generated at 2022-06-23 19:30:28.757408
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # Test case 1 : Requested MIME type is not supported
    mime = 'application/xml'
    expected = None
    actual = Conversion.get_converter(mime)
    assert actual == expected
    # Test case 1 : Converter is returned for requested MIME type
    mime = 'application/json'
    expected = 'httpie.plugins.converter.JsonConverter'
    actual = Conversion.get_converter(mime)
    assert actual.__class__.__name__ == expected


# Generated at 2022-06-23 19:30:31.385611
# Unit test for constructor of class Conversion
def test_Conversion():
    conversion = Conversion()
    mime = 'application/json'
    assert conversion.get_converter(mime).supports(mime) == True


# Generated at 2022-06-23 19:30:34.078642
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = "HTTP/1.1 200 OK\nConnection: close\nContent-Length: 17\n\n"
    formatting = Formatting(['color'])
    formatting.format_headers(headers)

# Generated at 2022-06-23 19:30:38.274135
# Unit test for constructor of class Conversion
def test_Conversion():
    assert(is_valid_mime('application/json'))
    assert(is_valid_mime('text/html'))
    assert(is_valid_mime('text/plain')   )
    assert(is_valid_mime('image/jpg') == False)
    assert(is_valid_mime('text/html http/1.1') == False)
    assert(is_valid_mime('') == False)


# Generated at 2022-06-23 19:30:45.889017
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    env = Environment()
    response_mime = 'application/json'
    converter = Conversion.get_converter(response_mime)
    assert converter.__class__.__name__ == 'JsonConverter'
    response_mime = 'application/xml'
    converter = Conversion.get_converter(response_mime)
    assert converter.__class__.__name__ == 'XmlConverter'
    response_mime = 'text/plain'
    converter = Conversion.get_converter(response_mime)
    assert converter == None

# Generated at 2022-06-23 19:30:47.597014
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("a","x") == None

# Generated at 2022-06-23 19:30:54.533123
# Unit test for constructor of class Formatting
def test_Formatting():
    # Arrange
    env = Environment()
    groups = ["Test_Processor_1", "Test_Processor_2"]

# Generated at 2022-06-23 19:30:58.439200
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/plain")
    assert not is_valid_mime("")
    assert not is_valid_mime("text/")
    assert not is_valid_mime("text")
    assert not is_valid_mime("text/plain/")
    assert not is_valid_mime("text\plain")

# Generated at 2022-06-23 19:31:08.268212
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/plain')
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/html')
    assert is_valid_mime('image/jpeg')
    assert is_valid_mime('image/svg+xml')
    assert is_valid_mime('*/*')
    assert is_valid_mime('text/*')
    assert is_valid_mime('application/*')
    assert is_valid_mime(' */* ')
    assert is_valid_mime('*/json')
    assert not is_valid_mime('(')
    assert not is_valid_mime('*/')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application/')
    assert not is_valid

# Generated at 2022-06-23 19:31:12.054779
# Unit test for constructor of class Conversion
def test_Conversion():
    # Convert response body with mime type application/xml
    test_convert = Conversion.get_converter("application/xml")
    # Check if the response body is successfully converted
    assert test_convert is not None



# Generated at 2022-06-23 19:31:16.569818
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('application/json') is not None
    assert Conversion.get_converter('application/json').mime == 'application/json'
    assert not Conversion.get_converter('application/xml')


# Generated at 2022-06-23 19:31:18.040861
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(['colors'])
    Formatting(['colors', 'format'])

# Generated at 2022-06-23 19:31:27.531599
# Unit test for constructor of class Formatting
def test_Formatting():
    def get_funcname(func):
        return func.__name__

    groups = ['json', 'pretty', 'colors']
    env = Environment()
    formatting = Formatting(groups, env=env)
    assert formatting is not None
    assert len(formatting.enabled_plugins) == 3
    assert get_funcname(formatting.enabled_plugins[0].format_headers) == 'JSONFormatter.format_headers'
    assert get_funcname(formatting.enabled_plugins[1].format_body) == 'PrettyFormatter.format_body'
    assert get_funcname(formatting.enabled_plugins[2].format_headers) == 'ColorsFormatter.format_headers'

# Generated at 2022-06-23 19:31:35.232154
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    input = '''HTTP/1.1 200 OK
content-type: application/json'''
    env = Environment()
    env.stdout = io.StringIO()
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []

    for group in ['colors', 'format']:
        for cls in available_plugins[group]:
            p = cls(env=env)
            if p.enabled:
                enabled_plugins.append(p)

    # testing method format_headers
    output = '''HTTP/1.1 200 OK
\x1b[37mcontent-type: application/json\x1b[0m'''
    assert output == Formatting(['colors', 'format'], env=env).format_headers(input)


# Generated at 2022-06-23 19:31:39.629599
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('image/png')
    assert is_valid_mime('image/png+json')
    assert not is_valid_mime('image/')
    assert not is_valid_mime('/png')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:31:42.225181
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatter = Formatting(groups=['json'])
    headers = formatter.format_headers('{"header":"value"}')
    assert headers == '{header: value}'


# Generated at 2022-06-23 19:31:51.405327
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    if 'json' in env.formatter_groups:
        assert Formatting(['json']).format_body(json.dumps({'a': 'b'}), 'application/json') == '{\n    "a": "b"\n}\n'
    if 'pretty' in env.formatter_groups:
        assert Formatting(['pretty']).format_body('text', 'text/something') == 'text\n'
    if 'colors' in env.formatter_groups:
        assert Formatting(['colors']).format_body('red;green', 'text/something') == '\x01\x1b[31m\x02red\x1b[0m\x01\x1b[32m\x02;green\x1b[0m\x02'

# Generated at 2022-06-23 19:32:01.647016
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print('Test for method format_body of class Formatting')
    # Test for method format_body of class Formatting
    # Situation 1: with valid mime
    if True:
        groups_s1 = ['colors']
        env_s1 = Environment()
        kwargs_s1 = dict()

        f_s1 = Formatting(groups=groups_s1, env=env_s1, **kwargs_s1)

# Generated at 2022-06-23 19:32:03.622963
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(groups=['colors'])
    assert fmt.enabled_plugins[0].name == 'colors'


# Generated at 2022-06-23 19:32:08.910300
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('html/html')
    assert is_valid_mime('x-foo/x-bar')
    assert not is_valid_mime('/json')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('/')
    assert not is_valid_mime('')

# Generated at 2022-06-23 19:32:11.149037
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("json") is not None
    assert Conversion.get_converter("invalid_mime") is None


# Generated at 2022-06-23 19:32:14.165196
# Unit test for constructor of class Conversion
def test_Conversion():
    converter_class = Conversion.get_converter('text/html')
    assert converter_class is not None
    assert converter_class.supports('text/html') is True
    assert converter_class.can_handle_mime('text/html') is True



# Generated at 2022-06-23 19:32:21.121253
# Unit test for constructor of class Formatting
def test_Formatting():
    assert len(Formatting(["default"]).enabled_plugins) == 1
    assert len(Formatting(["json"]).enabled_plugins) == 1
    assert len(Formatting(["json", "json"]).enabled_plugins) == 1
    assert len(Formatting(["json", "html"]).enabled_plugins) == 2
    assert len(Formatting(["json", "html", "json"]).enabled_plugins) == 2


# Generated at 2022-06-23 19:32:24.390644
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("text/html") is None
    assert Conversion.get_converter("text") is None
    assert Conversion.get_converter("/html") is None


# Generated at 2022-06-23 19:32:29.847050
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    import io
    import httpie.plugins.builtin.converters as converters
    from httpie.cli.parser import parse_form
    from httpie.compat import StringIO

    payload = StringIO(content='{"auth":{"passwordCredentials": {"username": "admin", "password": "123456"}}}')
    headers = parse_form([('Content-Type', 'application/json')])
    data = json.load(payload)
    #print(type(data))
    #print(type(headers))
    output = converters.JSONConverter().convert(data, headers, None)
    print(type(output))

    f = Formatting(groups=[], env=Environment())
    print(f.format_body(content=output, mime='application/json'))



# Generated at 2022-06-23 19:32:34.561050
# Unit test for constructor of class Conversion
def test_Conversion():
    def is_valid_mime(mime):
        return mime and MIME_RE.match(mime)

    assert is_valid_mime("text/html") == True
    assert is_valid_mime("123") == False
    assert is_valid_mime("text text") == False


# Generated at 2022-06-23 19:32:37.367921
# Unit test for function is_valid_mime
def test_is_valid_mime():
    # Valid
    assert is_valid_mime("text/html")
    assert is_valid_mime("text/csv")
    # Invalid
    assert not is_valid_mime("text/")
    assert not is_valid_mime("/csv")
    assert not is_valid_mime("text")
    assert not is_valid_mime("-")
    assert not is_valid_mime("")

# Generated at 2022-06-23 19:32:41.676940
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("image/png") is True
    assert is_valid_mime("text/html") is True
    assert is_valid_mime("") is False
    assert is_valid_mime("image/") is False
    assert is_valid_mime("/png") is False
    assert is_valid_mime("/") is False

# Generated at 2022-06-23 19:32:44.667102
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(['codes'], env=Environment())
    assert f.enabled_plugins[0].__class__.__name__ == 'FormattersCodesPlugin'


# Generated at 2022-06-23 19:32:49.883348
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatted_header_1="HTTP/1.1 200 OK\nHost: 127.0.0.1\nUser-Agent: HTTPie/1.0.3\nConnection: keep-alive\nContent-type: application/json\nAccept: application/json\nContent-Length: 79\n\n"
    formatted_header_2="HTTP/1.1 200 OK\nHost: 127.0.0.1\nUser-Agent: HTTPie/1.0.3\nConnection: keep-alive\nContent-type: application/json\nAccept: application/json\nContent-Length: 79\n\n"
    # The test result is expected to be formatted_header_2
    f=Formatting(groups=["HTTPieFormatter"])

# Generated at 2022-06-23 19:32:53.179695
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime("application/json")
    assert not is_valid_mime("application")
    assert not is_valid_mime("application/")

    c = Conversion.get_converter("application/json")
    assert c.mime == "application/json"


# Generated at 2022-06-23 19:33:01.844227
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html') == True
    assert is_valid_mime('text/plain') == True
    assert is_valid_mime('application/pdf') == True
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application/x-www-form-urlencoded') == True

    assert is_valid_mime('text') == False
    assert is_valid_mime('text/') == False
    assert is_valid_mime('/html') == False
    assert is_valid_mime('text/html/') == False
    assert is_valid_mime('/plain') == False
    assert is_valid_mime('text/plain/') == False

# Generated at 2022-06-23 19:33:03.974352
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()  # Constructor of class Conversion
    assert c != None

# Generated at 2022-06-23 19:33:10.104675
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/vnd.api+json')
    assert is_valid_mime('application/json; charset=utf-8')
    assert not is_valid_mime('application/json;charset=utf-8')
    assert not is_valid_mime('json')
    assert not is_valid_mime('application/')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application/json/json')

# Generated at 2022-06-23 19:33:20.790784
# Unit test for function is_valid_mime
def test_is_valid_mime():
    """Unit test for function is_valid_mime."""
    assert not is_valid_mime('')
    assert not is_valid_mime('/')
    assert not is_valid_mime('/abc')
    assert not is_valid_mime('abc/')
    assert is_valid_mime('abc/def')
    assert is_valid_mime('abc/')
    assert is_valid_mime('abc/ ')
    assert is_valid_mime(' abc/def ')
    assert not is_valid_mime(' abc')
    assert not is_valid_mime(' abc/ ')
    assert not is_valid_mime(' abc/ ')
    assert not is_valid_mime(' abc/ ')

# Generated at 2022-06-23 19:33:28.751240
# Unit test for constructor of class Formatting
def test_Formatting():
    F = Formatting(["colors"])
    # Test1: If a Processor is not enabled in `env`
    assert len(F.enabled_plugins) == 1 # colors plugin is only enabled
    assert F.enabled_plugins[0].name == "colors"
    # Test2: If two or more plugins in a group are both enabled
    env = Environment(formatter_plugins=[{"colors": True}])
    G = Formatting(["colors"], env=env)
    assert len(G.enabled_plugins) == 1

# Generated at 2022-06-23 19:33:39.945806
# Unit test for constructor of class Formatting
def test_Formatting():
    #test case 1
    groups = []
    print ("testcase 1: ")
    env = Environment()
    print (Formatting(groups, env).enabled_plugins)
    assert Formatting(groups, env).enabled_plugins == []
    #test case 2
    groups = ["C"]
    print ("testcase 2: ")
    env = Environment()
    print (Formatting(groups, env).enabled_plugins)
    assert Formatting(groups, env).enabled_plugins == []
    #test case 3
    groups = ["B"]
    print ("testcase 3: ")
    env = Environment()
    print (Formatting(groups, env).enabled_plugins)
    assert Formatting(groups, env).enabled_plugins == []
    #test case 4
    groups = ["A"]
    print ("testcase 4: ")
   

# Generated at 2022-06-23 19:33:46.960491
# Unit test for constructor of class Formatting
def test_Formatting():
    import click
    from httpie.plugins.builtin import HTTPHeadersProcessor, JSONProcessor, HTTPPrettyPrinterProcessor, \
        KeyValueProcessor, FormProcessor
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment

    class HTTPHeadersProcessor2(HTTPHeadersProcessor):
        pass

    class JSONProcessor2(JSONProcessor):
        pass

    class HTTPPrettyPrinterProcessor2(HTTPPrettyPrinterProcessor):
        pass

    class KeyValueProcessor2(KeyValueProcessor):
        pass

    class FormProcessor2(FormProcessor):
        pass

    plugin_manager.register(HTTPHeadersProcessor2)
    plugin_manager.load_installed_plugins()
    plugin_manager.register(JSONProcessor2)
    plugin_manager.load

# Generated at 2022-06-23 19:33:53.315741
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = ["colors"]
    fm = Formatting(groups)
    json_str = '{"key": "value"}'
    assert fm.format_body(json_str, mime="application/json") != json_str
    assert fm.format_body(json_str, mime="application/json") == '{\n   "key": "value"\n}'
    assert fm.format_body(json_str, mime="application/xml") == json_str

# Generated at 2022-06-23 19:34:04.051114
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    class ConverterPlugin1(ConverterPlugin):
        def supports(self, mime):
            return mime == 'text/plain'
        def convert(self, content):
            return 'converted'

    class ConverterPlugin2(ConverterPlugin):
        def supports(self, mime):
            return mime == 'application/json'
        def convert(self, content):
            return 'converted'

    ConverterPlugin1.__name__ = 'ConverterPlugin1'
    ConverterPlugin2.__name__ = 'ConverterPlugin2'
    plugin_manager.get_converters = lambda: [ConverterPlugin1, ConverterPlugin2]
    assert Conversion.get_converter('text/plain').convert('unconverted') == 'converted'

# Generated at 2022-06-23 19:34:08.585683
# Unit test for constructor of class Formatting
def test_Formatting():
    import httpie.plugins
    plugin_manager = httpie.plugins.plugin_manager

    env = Environment()
    formatter = Formatting([], env=env)
    assert formatter.enabled_plugins == []

    formatter = Formatting(['all'], env=env)
    assert formatter.enabled_plugins == plugin_manager.get_formatters_grouped()['all']


# Generated at 2022-06-23 19:34:11.481229
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(['colors'], None)
    import json
    content = json.dumps({"a": 1})
    mime = 'application/json'
    assert f.format_body(content, mime) == '{\n    "a": 1\n}'

# Generated at 2022-06-23 19:34:19.345847
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/x-yaml')
    assert not is_valid_mime('text')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('text//html')
    assert not is_valid_mime('text/ht@ml')
    assert not is_valid_mime('text+html')
    assert not is_valid_mime('text/html/v0')

# Generated at 2022-06-23 19:34:21.753682
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # json to xml conversion
    assert isinstance(Conversion.get_converter('application/xml'),
                      ConverterPlugin)

# Generated at 2022-06-23 19:34:31.996102
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-23 19:34:37.992127
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import HTTPPrettyJSONProcessor

    converter = Conversion.get_converter('application/json')
    content = '[1, 2]'
    response_mime = 'application/json'
    formatted_body = Formatting([], env=Environment()).format_body(content, response_mime)
    assert formatted_body == converter.to_html(content)



# Generated at 2022-06-23 19:34:42.922989
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('a/b') == True
    assert is_valid_mime('a/') == False
    assert is_valid_mime('/a') == False
    assert is_valid_mime('*/*') == True
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application/json;charset=utf-8') == False

# Generated at 2022-06-23 19:34:47.496640
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application/json; charset=utf-8')
    assert is_valid_mime('application/json+fhir')
    assert not is_valid_mime('application/json+fhir; charset=UTF-8')

# Generated at 2022-06-23 19:34:48.391572
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups = ['colors'])


# Generated at 2022-06-23 19:34:54.004014
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.plugins import FormatterPlugin, get_plugin_manager
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment

    class DummyFormatterPlugin(FormatterPlugin):

        def format_headers(self, headers: str) -> str:
            return "\n".join(["key:value"] for i in range(2)) + headers

    plugin_manager.set_formatters([DummyFormatterPlugin], {})
    headers = "foo: bar\nbar: foo"
    assert Formatting(["DummyFormatterPlugin"], Environment()).format_headers(headers) == "key:value\nkey:value" + headers

# Generated at 2022-06-23 19:34:58.133591
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    format_body_test_body = ["{", "'id': 1}"]
    format_body_test_answer = "{'id': 1}"
    assert Formatting(["json"]).format_body(format_body_test_body, "application/json") == format_body_test_answer

# Generated at 2022-06-23 19:35:00.106702
# Unit test for constructor of class Conversion
def test_Conversion():
    data = "application/json"
    assert is_valid_mime(data) == True


# Generated at 2022-06-23 19:35:03.613671
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('text/plain')
    assert is_valid_mime('application/json')
    assert not is_valid_mime('text')
    assert not is_valid_mime('')

# Generated at 2022-06-23 19:35:04.762922
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion.get_converter('json')
    print(c)

# Generated at 2022-06-23 19:35:10.479454
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins import FormatterPlugin

    class DummyFormatter(FormatterPlugin):
        format_mime_types = ["text/plain"]

        def format_body(self, body: str, mime: str) -> str:
            return "{%s}" % body

    assert "Content-Type: text/plain" in client.get("--formatter=json", url).json()['headers']['Content-Type']
    assert "Content-Type: text/plain" in client.get("--formatter=DummyFormatter", url).json()['headers']['Content-Type']

# Generated at 2022-06-23 19:35:12.840405
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('image/svg+xml')
    assert converter.mime == 'image/svg+xml'



# Generated at 2022-06-23 19:35:24.254822
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    instFormatting = Formatting(['format', 'colors'], verbose=True)
    ret = instFormatting.format_body('{ "test": [1, 2, 3] }', 'application/json')

# Generated at 2022-06-23 19:35:25.123861
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(['colors']) is not None

# Generated at 2022-06-23 19:35:35.241311
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter("http"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("httpie"), ConverterPlugin)
    assert isinstance(Conversion.get_converter("gopher"), ConverterPlugin)
    assert not isinstance(Conversion.get_converter(""), ConverterPlugin)
    assert not isinstance(Conversion.get_converter("https"), ConverterPlugin)
    assert not isinstance(Conversion.get_converter("abc"), ConverterPlugin)
    assert not isinstance(Conversion.get_converter("abc/"), ConverterPlugin)
    assert not isinstance(Conversion.get_converter("/def"), ConverterPlugin)
    assert not isinstance(Conversion.get_converter("abc/def"), ConverterPlugin)

# Generated at 2022-06-23 19:35:42.546432
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    groups = []
    env = Environment()
    kwargs = {}
    formatter = Formatting(groups, env, **kwargs)
    mime = "application/json"
    content_not_changed = formatter.format_body(content, mime)
    assert content_not_changed == content
    groups = ["colors", "prettify"]
    formatter = Formatting(groups, env, **kwargs)
    content_changed = formatter.format_body(content, mime)
    assert content_changed != content

if __name__ == "__main__":
    groups = []
    env = Environment()
    kwargs = {}
    formatter = Formatting(groups, env, **kwargs)
    mime = "application/json"

# Generated at 2022-06-23 19:35:46.703241
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    p = Conversion.get_converter("html")
    assert p is not None
    p = Conversion.get_converter("json")
    assert p is not None
    p = Conversion.get_converter("txt")
    assert p is not None
    p = Conversion.get_converter("invalid")
    assert p is None


# Generated at 2022-06-23 19:35:49.792482
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')
    assert converter.mime == 'application/json'
    assert converter.can_convert('application/json')
    assert converter.can_convert('application/json; charset=utf-8')
    assert not converter.can_convert('text/html')

# Generated at 2022-06-23 19:35:52.076842
# Unit test for constructor of class Conversion
def test_Conversion():
    c = 'application/json'
    if converter_class.supports(mime):
        return converter_class(mime)


# Generated at 2022-06-23 19:35:54.863987
# Unit test for constructor of class Formatting
def test_Formatting():
    assert Formatting(groups = ['colors'], env = Environment(), use_colors = True)

# Generated at 2022-06-23 19:36:01.801858
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    request_headers = '''Content-Type: application/json
Authorization: Bearer tGzv3JOkF0XG5Qx2TlKWIA'''
    expected_response_headers = '''Content-Type: application/json
Authorization: Bearer tGzv3JOkF0XG5Qx2TlKWIA'''

    f = Formatting(['headers'])
    response_headers = f.format_headers(request_headers)

    assert expected_response_headers == response_headers



# Generated at 2022-06-23 19:36:06.063405
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert not is_valid_mime('application/json/123')
    assert is_valid_mime('application/json; charset=utf-8')
    assert not is_valid_mime('application/json; charset=utf-8; a=1')

# Generated at 2022-06-23 19:36:12.695323
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import httpie.formatters.json

    from httpie.context import Environment
    from httpie.plugins.registry import plugin_manager

    class MockHeaderFormatter(httpie.formatters.json.JSONFormatter):
        def format_headers(self, headers):
            return "mock headers"

    plugin_manager.clear_formatter_instances()
    plugin_manager.register(MockHeaderFormatter)

    formatting = Formatting(['Alpha', 'Beta'], env=Environment(colors=True))
    header = "header"
    header_formatted = formatting.format_headers(header)
    assert header_formatted == "mock headers"


# Generated at 2022-06-23 19:36:24.417590
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html")
    assert is_valid_mime("application/json")
    assert is_valid_mime("application/vnd.api+json")
    assert not is_valid_mime("")
    assert not is_valid_mime("t")
    assert not is_valid_mime("text")
    assert not is_valid_mime("/")
    assert not is_valid_mime("/html")
    assert not is_valid_mime("text/")
    assert not is_valid_mime("text//")
    assert not is_valid_mime("text/html/")
    assert not is_valid_mime("text/html/xxx")
    assert not is_valid_mime("text/html xxx")

# Generated at 2022-06-23 19:36:25.391081
# Unit test for constructor of class Conversion
def test_Conversion():
    print(Conversion.get_converter("application/p-json"))

# Generated at 2022-06-23 19:36:28.320835
# Unit test for constructor of class Conversion
def test_Conversion():
    converter = Conversion.get_converter("application/json")
    assert converter is not None
    assert converter.supports("application/jsons") == False
    assert converter.supports("json") == False



# Generated at 2022-06-23 19:36:30.366708
# Unit test for constructor of class Formatting
def test_Formatting():
    test_groups = ['bcolors', 'format']
    result = Formatting(groups=test_groups)
    assert result



# Generated at 2022-06-23 19:36:34.735330
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['colors']
    kwargs = {"colors": False}
    format_ = Formatting(groups, **kwargs)
    assert format_.enabled_plugins[0].__class__.__name__ == "ColorsFormatter"
    
    

# Generated at 2022-06-23 19:36:38.273016
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    f = Formatting(groups=['colors'])
    print(f.format_body('{"id": "1"}', mime='application/json'))
    print(f.format_body('{"id": "2"}', mime='text/html'))

# Generated at 2022-06-23 19:36:40.275751
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'application/json'
    assert isinstance(Conversion.get_converter(mime), ConverterPlugin)


# Generated at 2022-06-23 19:36:45.634499
# Unit test for function is_valid_mime
def test_is_valid_mime():
    tests = [
        ('application/json', True),
        ('application/*', True),
        ('application/', False),
        ('application', False),
        ('application/*+json', True),
        ('application/json+*', True),
        ('application/*+*', True),
        ('application/xml', True),
        ('*', False),
        ('*/*', False),
        ('*/*+*', False),
        ('*/xml', False),
    ]
    for case, expected in tests:
        assert is_valid_mime(case) is expected, f'is_valid_mime({case!r})'

# Generated at 2022-06-23 19:36:53.474220
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime(None)
    assert not is_valid_mime('invalid')
    assert not is_valid_mime('invalid/')
    assert not is_valid_mime('/invalid')
    assert not is_valid_mime('/invalid/')
    assert is_valid_mime('application/json')
    assert is_valid_mime('text/html')
    assert is_valid_mime('text/plain')
    assert is_valid_mime('multipart/related')
    assert is_valid_mime('application/x-www-form-urlencoded')
    assert not is_valid_mime(1)
    assert not is_valid_mime([])
    assert not is_valid_mime({})



# Generated at 2022-06-23 19:36:56.243789
# Unit test for constructor of class Conversion
def test_Conversion():
    ret = Conversion.get_converter('text/html')
    assert(ret != None)
    ret = Conversion.get_converter('text/not-here')
    assert(ret == None)

# Generated at 2022-06-23 19:37:00.710349
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # Object of class Formatting
    obj = Formatting(['format_headers'])

    # headers without formatting
    headers = """HTTP/1.1 200 OK
Content-Type: application/json
Date: Fri, 23 Nov 2018 15:01:46 GMT
Content-Length: 13

"""
    obj.format_headers(headers)



# Generated at 2022-06-23 19:37:08.359785
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    class test_cls(ConverterPlugin):
        def __init__(self, env=Environment(), **kwargs):
            super(test_cls, self).__init__(env=env, **kwargs)
            self.content_type = 'application/json'

        def convert_from(self, text, content_type) -> str:
            return json.loads(text)

        def convert_to(self, obj, content_type) -> str:
            if content_type in ['application/json', '*/*']:
                return json.dumps(obj)
            else:
                raise ValueError(
                    'Unsupported content type: %s' % content_type)

        def format_headers(self, headers: str) -> str:
            return headers


# Generated at 2022-06-23 19:37:10.008768
# Unit test for constructor of class Conversion
def test_Conversion():
    x = Conversion()
    assert isinstance(x, Conversion)


# Generated at 2022-06-23 19:37:12.671064
# Unit test for constructor of class Formatting
def test_Formatting():
    print(Formatting(["default"]).enabled_plugins)
    print(Formatting([]).enabled_plugins)
    print(Formatting(["json"]).enabled_plugins)



# Generated at 2022-06-23 19:37:21.514688
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from _pytest.monkeypatch import MonkeyPatch
    mp = MonkeyPatch()

    class TestInput:
        def __init__(self, text):
            self.text = text

    class TestOutput:
        def __init__(self, text):
            self.text = text

    class TestFormatterPlugin:
        def format_headers(self, headers):
            if headers.text == 'test':
                return TestOutput('test-output')
            else:
                return headers

    mp.setattr(plugin_manager, 'get_formatters_grouped', lambda: {'group-test': [TestFormatterPlugin]})
    formatting = Formatting(['group-test'])
    assert formatting.format_headers(TestInput('test')).text == 'test-output'



# Generated at 2022-06-23 19:37:28.000616
# Unit test for function is_valid_mime
def test_is_valid_mime():
    mime = 'text/html'
    assert is_valid_mime(mime) == True

    mime = 'text/html; charset=utf-8'
    assert is_valid_mime(mime) == True

    mime = 't/h'
    assert is_valid_mime(mime) == False

    mime = ''
    assert is_valid_mime(mime) == False

    mime = 'text'
    assert is_valid_mime(mime) == False



# Generated at 2022-06-23 19:37:33.201887
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('text/html; charset=utf-8')
    assert not is_valid_mime('text/html ')
    assert not is_valid_mime('text/html ')
    assert not is_valid_mime('text/html/json')
    assert not is_valid_mime('text')
    assert not is_valid_mime('/html')
    assert not is_valid_mime('')
    assert not is_valid_mime('/')
    assert not is_valid_mime(None)

# Generated at 2022-06-23 19:37:44.354502
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
	html = "HTTP/1.1 200 OK\r\nServer: nginx\r\nDate: Thu, 23 Jan 2020 21:02:15 GMT\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: 527\r\nConnection: keep-alive\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST\r\nAccess-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept\r\nX-Powered-By: Express\r\nETag: W/\"20f-V3qAkmoPn7JQA9d1WtIBFo\"\r\n\r\n"

# Generated at 2022-06-23 19:37:45.361812
# Unit test for constructor of class Formatting
def test_Formatting():
  z = Formatting(['color'])
  assert len(z.enabled_plugins) == 1

# Generated at 2022-06-23 19:37:54.411832
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    input_headers = "HTTP/1.1 200 OK\r\nContent-Length: 7\r\nContent-Type: application/json\r\n\r\n"
    output_headers = "HTTP/1.1 200 OK\r\nContent-Length: 7\r\nContent-Type: application/json\r\n\r\n"
    env = Environment()
    groups = ['Colored']
    kwargs = {}
    f = Formatting(groups=groups, env=env, **kwargs)
    assert f.format_headers(input_headers) == output_headers



# Generated at 2022-06-23 19:38:00.380468
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    from urllib.parse import urlparse


# Generated at 2022-06-23 19:38:04.263888
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_mime = 'application/json'
    assert isinstance(Conversion.get_converter(test_mime), ConverterPlugin) == True
    test_mime = 'application/jsons'
    assert isinstance(Conversion.get_converter(test_mime), ConverterPlugin) == True
    test_mime = 'google/json'
    assert isinstance(Conversion.get_converter(test_mime), ConverterPlugin) == False
    test_mime = 'google.json'
    assert isinstance(Conversion.get_converter(test_mime), ConverterPlugin) == False


# Generated at 2022-06-23 19:38:12.277430
# Unit test for constructor of class Formatting
def test_Formatting():
    headers = 'GET / HTTP/1.1\r\nHost: example.com\r\nAccept-Encoding: gzip, deflate\r\nConnection: keep-alive\r\nUser-Agent: HTTPie/0.9.9\r\nAccept: application/json\r\n\r\n'
    content = '{"message": "Hello, World!"}'
    mime = 'application/json'
    groups = ['json', 'colors']
    fmt = Formatting(groups)
    fmt.format_headers(headers)
    fmt.format_body(content, mime)
    assert True

# Generated at 2022-06-23 19:38:15.034391
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    def fake_format_headers(self, headers):
        return headers

    Formatting.format_headers = fake_format_headers


# Generated at 2022-06-23 19:38:24.906302
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    json_data = r"""{
        "glossary": {
            "title": "example glossary",
            "GlossDiv": {
                "title": "S",
                "GlossList": {
                    "GlossEntry": {
                        "ID": "SGML",
                        "SortAs": "SGML",
                        "GlossTerm": "Standard Generalized Markup Language",
                        "Acronym": "SGML",
                        "Abbrev": "ISO 8879:1986",
                        "GlossDef": {
                            "para": "A meta-markup language, used to create markup languages such as DocBook.",
                            "GlossSeeAlso": ["GML", "XML"]
                        },
                        "GlossSee": "markup"
                    }
                }
            }
        }
    }"""
   

# Generated at 2022-06-23 19:38:32.683055
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-23 19:38:34.154322
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = 'application/json'
    assert is_valid_mime(mime)

# Generated at 2022-06-23 19:38:36.619343
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/plain') is None
    assert isinstance(Conversion.get_converter('application/json'),
                      ConverterPlugin)

# Generated at 2022-06-23 19:38:38.780901
# Unit test for constructor of class Conversion
def test_Conversion():
    converter=Conversion.get_converter('json')
    assert(converter.mime == 'json')


# Generated at 2022-06-23 19:38:40.524473
# Unit test for constructor of class Conversion
def test_Conversion():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('text/plain') == True


# Generated at 2022-06-23 19:38:45.174388
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/json')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/json+json')

    assert not is_valid_mime('')
    assert not is_valid_mime('application')
    assert not is_valid_mime('/text')
    assert not is_valid_mime('/json')

# Generated at 2022-06-23 19:38:47.360295
# Unit test for constructor of class Conversion
def test_Conversion():
    temp=Conversion()
    assert temp is not None


# Generated at 2022-06-23 19:38:55.357743
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    body_string = """
    {
    "name": "Mandy",
    "age": "25"
    }
    """
    code = 0
    arg1 = 'Accept'
    arg2 = 'application/json'
    arg3 = 'json'
    arg4 = body_string
    arg5 = 'pretty'
    result = Formatting.format_body(arg4, arg3, arg1, arg2, arg5)
    if (result == ""):
        code = 1
    print(code)
    return code


# Generated at 2022-06-23 19:38:57.779547
# Unit test for constructor of class Formatting
def test_Formatting():
    fm = Formatting(['colors'])
    assert fm.enabled_plugins[0].__class__.__name__ == 'Color'

# Generated at 2022-06-23 19:39:04.722205
# Unit test for constructor of class Formatting
def test_Formatting():
    """
    Test for:
    function: __init__
    """
    from httpie.context import Environment
    from httpie.plugins.builtin import HTTPHeadersProcessor, HTTPBodyProcessor

    available_plugins = plugin_manager.get_formatters_grouped()
    groups = ['HTTPHeadersProcessor', 'HTTPBodyProcessor']
    env = Environment()
    fp = Formatting(groups, env=env)
    assert type(fp.enabled_plugins[0]) == HTTPHeadersProcessor
    assert type(fp.enabled_plugins[1]) == HTTPBodyProcessor



# Generated at 2022-06-23 19:39:06.512041
# Unit test for constructor of class Formatting
def test_Formatting():
    c = Formatting(groups=["formatters"])
    assert type(c) is Formatting


# Generated at 2022-06-23 19:39:10.978444
# Unit test for constructor of class Conversion
def test_Conversion():
    # Given
    c = Conversion()

    # When
    mime = 'application/json'
    c1 = c.get_converter(mime)
    c2 = c.get_converter('null')

    # Then
    assert c1.mime == mime
    assert c2 is None

# Generated at 2022-06-23 19:39:19.754309
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['highlight', 'colors']
    f = Formatting(groups)
    assert(len(f.enabled_plugins) == 2)
    assert(f.format_headers('key: value') == '\x1b[1mkey:\x1b[22m \x1b[34mvalue\x1b[39m')
    assert(f.format_body('{"key": "value"}', 'application/json') == '\x1b[90m{\x1b[39m\x1b[34m"key"\x1b[39m\x1b[90m:\x1b[39m \x1b[34m"value"\x1b[39m\x1b[90m}\x1b[39m')

# Generated at 2022-06-23 19:39:25.910055
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    '''
    >>> test_Formatting_format_headers()
    '''
    plugins = Formatting(groups=['colors'], env=Environment(),
                         foreground='green',
                         background='black',
                         attrs=['bold'])
    print(plugins.format_headers('HTTP/1.1 200 OK\\nContent-Type: text/html; charset=utf-8\\nServer: nginx\\nContent-Type: application/json\\nAccept:*/*\n'))



# Generated at 2022-06-23 19:39:31.211804
# Unit test for constructor of class Formatting
def test_Formatting():
    with pytest.raises(KeyError) as error:
        Formatting(['foo'])
    assert 'Group foo does not exist' in str(error.value)

    with pytest.raises(Exception) as error:
        Formatting(['default', 'foo'])
    assert 'Group foo does not exist' in str(error.value)

# Generated at 2022-06-23 19:39:32.610249
# Unit test for constructor of class Conversion
def test_Conversion():
    Testing = Conversion.get_converter('application/json')
    assert Testing is not None

# Generated at 2022-06-23 19:39:37.361368
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie import ExitStatus

    environment = Environment()
    environment.stdout = io.StringIO()
    format = Formatting(["colors"])
    content = format.format_body("""[
    {
        "age":20,
        "name":"jack"
    },
    {
        "age":30,
        "name":"bob"
    }
]""", "application/json")
    import json
    print(json.loads(content))

# Generated at 2022-06-23 19:39:42.957796
# Unit test for constructor of class Conversion
def test_Conversion():
    print(Conversion.get_converter('application/json'))
    print(Conversion.get_converter('application/xml'))
    print(Conversion.get_converter('application/x-yaml'))
    print(Conversion.get_converter('application/html'))
    print(Conversion.get_converter('application/xhtml+xml'))


# Generated at 2022-06-23 19:39:48.127712
# Unit test for constructor of class Conversion
def test_Conversion():
    c=Conversion()
    assert c.get_converter("html/text") != None
    assert c.get_converter("html/*") != None
    assert c.get_converter("html/json") != None
    assert c.get_converter("text/html") != None
    assert c.get_converter("text/josn") == None


# Generated at 2022-06-23 19:39:52.419045
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/html; charset=utf-8'
    assert is_valid_mime(mime)
    c = Conversion.get_converter(mime)
    assert c is not None
    assert c.name == 'html'
    mime = 'junk/junk'
    assert is_valid_mime(mime) == False
    c = Conversion.get_converter(mime)
    assert c is None


# Generated at 2022-06-23 19:39:53.971587
# Unit test for function is_valid_mime
def test_is_valid_mime():
    is_valid_mime("")
    assert is_valid_mime("application/json"), "Cannot match application/json"
    assert not is_valid_mime("json"), "Should not match json"

# Generated at 2022-06-23 19:39:58.795963
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # testing this input
    test_input = {
        'headers': '\n'.join([
            'HTTP/1.1 200 OK',
            'Connection: keep-alive',
            'Content-Length: 3',
            'Content-Type: application/json; charset=utf-8',
            'Date: Wed, 08 May 2019 20:56:21 GMT',
            'X-Powered-By: Express'
        ]),
        'env': Environment(),
        'groups': ["color", "format", "format_args"],
        'kwargs': {'stream': False, 'pretty': False, 'ugly': False, 'indent': 4, 'explicit_json': False}
    }
    # setup
    f = Formatting(**test_input)
    # debug - print the headers to console
    # print('\