

# Generated at 2022-06-23 19:29:51.462420
# Unit test for constructor of class Conversion
def test_Conversion():
    input_mime="application/json"
    conversion = Conversion()


# Generated at 2022-06-23 19:29:55.177520
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('text/html')
    assert not Conversion.get_converter('text/nohtml')
    assert not Conversion.get_converter('text')
    assert not Conversion.get_converter('')
    assert not Conversion.get_converter(None)


# Generated at 2022-06-23 19:29:56.510312
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('application/json') is not None

# Generated at 2022-06-23 19:30:05.487957
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins import FormatterPlugin
    from httpie.plugins.registry import plugin_manager
    from httpie.context import Environment
    test_mimes = ['text/plain', 'pretty/json']

    class DummyFormatterPlugin(FormatterPlugin):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._supports = None

        @property
        def supported_mime_types(self) -> List[str]:
            return self._supports

        def format_headers(self, headers):
            return headers

        def format_body(self, body, mime):
            return body

    # Build a dummy formatter plugin for our test
    dummy1 = DummyFormatterPlugin()
    dummy1._supports = test_mimes
   

# Generated at 2022-06-23 19:30:07.902768
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['color', 'colors', 'colours', 'format']
    env = Environment()
    formatting = Formatting(groups, env)
    assert formatting.enabled_plugins == []

# Generated at 2022-06-23 19:30:10.225603
# Unit test for constructor of class Conversion
def test_Conversion():
    assert isinstance(Conversion.get_converter('text/plain'), ConverterPlugin)



# Generated at 2022-06-23 19:30:16.913659
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter("application/json")
    assert c.supports("application/json")
    c = Conversion.get_converter("application/xml")
    assert c.supports("application/xml")
    c = Conversion.get_converter("application/json")
    assert c.supports("application/json")
    c = Conversion.get_converter("application/xml")
    assert c.supports("application/xml")


# Generated at 2022-06-23 19:30:23.894416
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-23 19:30:26.091443
# Unit test for function is_valid_mime
def test_is_valid_mime():
    MIME = 'application/json'
    assert is_valid_mime(MIME) == True


# Generated at 2022-06-23 19:30:35.618241
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class NoopFormatterplugin(FormatterPlugin):
        name = 'noop'
    class OneFormatterplugin(FormatterPlugin):
        name = 'one'
        def format_headers(self, headers: str) -> str:
            return '1'
    class TwoFormatterplugin(FormatterPlugin):
        name = 'two'
        def format_headers(self, headers: str) -> str:
            return '2'+headers
    class ThreeFormatterplugin(FormatterPlugin):
        name = 'three'
        def format_headers(self, headers: str) -> str:
            return headers+'3'

    plugin_manager.register(NoopFormatterplugin)
    plugin_manager.register(OneFormatterplugin)
    plugin_manager.register(TwoFormatterplugin)

# Generated at 2022-06-23 19:30:42.480902
# Unit test for constructor of class Conversion
def test_Conversion():
    from pprint import pprint
    from httpie.plugins import plugin_manager

    # Test the constructor of class Conversion
    converter_list = []
    for mime in ("application/json", "application/xml", "application/json-seq"):
        converter = Conversion.get_converter(mime)
        converter_list.append(converter)

    pprint(plugin_manager.get_converters())


# Generated at 2022-06-23 19:30:44.640646
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter('fake/mime') is None
    assert Conversion.get_converter('application/json') is not None

# Generated at 2022-06-23 19:30:49.608231
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment()
    groups = ['colors']
    obj = Formatting(groups, env)
    available_plugins = plugin_manager.get_formatters_grouped()
    enabled_plugins = []
    for group in groups:
        for cls in available_plugins[group]:
            p = cls(env=env)
            if p.enabled:
                enabled_plugins.append(p)
    assert enabled_plugins == obj.enabled_plugins


# Generated at 2022-06-23 19:30:52.417671
# Unit test for constructor of class Conversion
def test_Conversion():
    print('test for constructor of class Conversion')
    print('')
    # given
    mime = 'application/json'
    # when
    converter = Conversion.get_converter(mime)
    # then
    print(converter)
    print('')


# Generated at 2022-06-23 19:30:55.334939
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/plain")
    assert is_valid_mime("app/json")
    assert is_valid_mime("aplication/json")
    assert not is_valid_mime("application/json")
    assert not is_valid_mime("application/jsonblah")
    assert not is_valid_mime("")
    assert not is_valid_mime(None)

test_is_valid_mime()

# Generated at 2022-06-23 19:30:56.830502
# Unit test for constructor of class Conversion
def test_Conversion():
    json_converter = Conversion.get_converter("application/json")
    print(isinstance(json_converter, ConverterPlugin))


# Generated at 2022-06-23 19:30:59.038160
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("application/json")!=None
    assert Conversion.get_converter("application/json")==plugin_manager.get_converters()
    assert Conversion.get_converter("csv")==None

# Generated at 2022-06-23 19:31:02.820764
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    formatting = Formatting(['colors'])
    headers = formatting.format_headers('HTTP/1.1 200 OK\r\n\r\n')
    assert headers.strip() == '\x1b[36mHTTP/1.1 200 OK\x1b[0m'

# Generated at 2022-06-23 19:31:06.977262
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['all', 'json', 'html']
    env: Environment = Environment()
    env.colors = colors = 'on'
    # env.headers = hdrs = ''

    f = Formatting(groups,env)
    assert f.enabled_plugins # should be non-empty
    assert colors == 'on'

# Generated at 2022-06-23 19:31:17.414561
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    # all test cases use the same JSON string
    json = '{"status":"success","data":1,"errors":null}'
    output_json = Formatting.format_body(json, 'application/json')
    output_json_gh = Formatting.format_body(json, 'application/vnd.github.v3+json')
    output_xml = Formatting.format_body(json, 'application/xml')

    # test all valid mime types
    output_valid = Formatting.format_body(json, 'application/json')
    output_valid = Formatting.format_body(json, 'text/json')
    output_valid = Formatting.format_body(json, 'text/javascript')

    # test invalid mime types
    output_invalid = Formatting.format_body(json, 'invalid')
    output

# Generated at 2022-06-23 19:31:19.160642
# Unit test for constructor of class Formatting
def test_Formatting():
    formatter = Formatting(['colors',])
    print(formatter.enabled_plugins)

# Generated at 2022-06-23 19:31:25.290908
# Unit test for constructor of class Conversion
def test_Conversion():
    #MIME_TYPE = 'application/json'
    #MIME_TYPE_BIN = 'image/png'
    assert isinstance(Conversion.get_converter('application/json'),
                      ConverterPlugin)
    #assert is_valid_mime(MIME_TYPE)
    assert not is_valid_mime('png')


# Generated at 2022-06-23 19:31:29.717474
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html') is True
    assert is_valid_mime('application/json') is True
    assert is_valid_mime('a/b') is True
    assert is_valid_mime('/') is False
    assert is_valid_mime('') is False
    assert is_valid_mime(None) is False

# Generated at 2022-06-23 19:31:33.004376
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.plugins.builtin import HTTPHeadersProcessor
    from httpie.plugins.default import JSONProcessor
    groups = ['headers','json']
    assert Formatting(groups=groups).enabled_plugins == [HTTPHeadersProcessor(), JSONProcessor()]

# Generated at 2022-06-23 19:31:37.936709
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    f = Formatting(groups=["colors"])
    input = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\nTest"
    output = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\nTest"
    assert f.format_headers(headers=input) == output


# Generated at 2022-06-23 19:31:40.708802
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()
    assert type(c) is Conversion


# Generated at 2022-06-23 19:31:41.678381
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    print(Conversion.get_converter("application/json"))
    

# Generated at 2022-06-23 19:31:47.400398
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    assert is_valid_mime("application/json; charset=UTF-8")
    assert is_valid_mime("application/json;charset=UTF-8")
    assert is_valid_mime("image/svg+xml")
    assert not is_valid_mime("foo")
    assert not is_valid_mime("")

# Generated at 2022-06-23 19:31:48.580158
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("text/plain") is None
    assert isinstance(Conversion.get_converter("application/json"), ConverterPlugin)


# Generated at 2022-06-23 19:31:54.184605
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    d = Formatting(groups=['colors'], colors=True)
    headers = '{"foo": "bar"}'
    assert d.format_headers(headers) == '\x1b[34m{\x1b[39;49;00m\n  \x1b[32m"foo"\x1b[39;49;00m\x1b[34m:\x1b[39;49;00m \x1b[33m"bar"\x1b[39;49;00m\n\x1b[34m}\x1b[39;49;00m\n' # noqa
    headers = '{"foo": "bar"}\n'

# Generated at 2022-06-23 19:31:57.084442
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('application/json')

    assert converter is not None

    converter = Conversion.get_converter('json')

    assert converter is None

# Generated at 2022-06-23 19:32:04.110453
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    from httpie.output.formatters.colors import Solarized
    from httpie import ExitStatus

    solarized = Solarized(env=ExitStatus.OK)
    assert solarized.enabled == True

    fmtr = Formatting(groups=['colors'], env=ExitStatus.OK)
    fmtr.enabled_plugins.append(solarized)
    assert fmtr.enabled_plugins[0].supported_platform == True

    headers = '''HTTP/1.1 200 OK
Server: nginx
Date: Sun, 15 Sep 2019 02:43:54 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 20
Connection: keep-alive
Keep-Alive: timeout=30
Content-Language: en-US

'''


# Generated at 2022-06-23 19:32:04.800968
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion();
    assert(c)


# Generated at 2022-06-23 19:32:08.772723
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('') is False
    assert is_valid_mime('\\') is False
    assert is_valid_mime('foo') is False
    assert is_valid_mime('foo/') is False
    assert is_valid_mime('foo/bar') is True

# Generated at 2022-06-23 19:32:11.627287
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    cases = [
        ('application/json', 'json'),
        ('unknown/unknown', None)
    ]

    for mime, _type in cases:
        assert _type == Conversion.get_converter(mime).name

# Generated at 2022-06-23 19:32:14.955234
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime(None)
    assert not is_valid_mime('')
    assert not is_valid_mime('application')
    assert not is_valid_mime('application/')
    assert is_valid_mime('application/json')
    assert is_valid_mime('custom/custom-plus')

# Generated at 2022-06-23 19:32:16.383231
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert Conversion.get_converter("text/html")



# Generated at 2022-06-23 19:32:21.487065
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    headers = 'Content-Type: application/json\r\nContent-Length: 13\r\n'
    result = Formatting(['colors']).format_headers(headers)
    assert result == '\x1b[39m\x1b[1m\x1b[33mContent-Type:\x1b[39m\x1b[22m \x1b[36mapplication/json\x1b[39m\n\x1b[39m\x1b[1m\x1b[33mContent-Length:\x1b[39m\x1b[22m \x1b[36m13\x1b[39m\n'


# Generated at 2022-06-23 19:32:24.151080
# Unit test for constructor of class Formatting
def test_Formatting():
    from . import httpie  # this is actually from httpie module
    env = httpie.context.Environment()
    fmt = Formatting(['Colored', 'JSON'], env)

# Generated at 2022-06-23 19:32:27.834283
# Unit test for constructor of class Conversion
def test_Conversion():
    bad_mime = 'not/valid'
    assert not is_valid_mime(bad_mime)

    good_mime = 'valid/mime'
    assert is_valid_mime(good_mime)

    assert Conversion.get_converter(None) is None

    assert Conversion.get_converter(bad_mime) is None

    assert Conversion.get_converter(good_mime) is not None


# Generated at 2022-06-23 19:32:33.388410
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html")
    assert not is_valid_mime("text")
    assert not is_valid_mime("/")
    assert not is_valid_mime("text/html/")
    assert not is_valid_mime("/html")
    assert not is_valid_mime("")

# Generated at 2022-06-23 19:32:36.870656
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    formatter = Formatting(["colors"])
    mime = "application/json"
    print(formatter.format_body(
        "{\n  \"name\": \"AARON\"\n}", mime))



# Generated at 2022-06-23 19:32:44.364958
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    from httpie.plugins.converter.core import CoreConverterPlugin
    from httpie.plugins.converter.json import JsonConverterPlugin
    from httpie.plugins.converter.jsonl import JsonlConverterPlugin
    from httpie.plugins.converter.form import FormConverterPlugin

    assert Conversion.get_converter("application/json").__class__ == JsonConverterPlugin
    assert Conversion.get_converter("application/jsonl").__class__ == JsonlConverterPlugin
    assert Conversion.get_converter("application/json").__class__ != JsonlConverterPlugin
    assert Conversion.get_converter("not_a_mime").__class__ == CoreConverterPlugin

# Generated at 2022-06-23 19:32:46.095868
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['styles']
    env = Environment()
    result = Formatting(groups)
    assert result


# Generated at 2022-06-23 19:32:49.081271
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("image/png")
    assert is_valid_mime("application/json")
    assert not is_valid_mime("image/")
    assert not is_valid_mime("image/jpeg/png")

# Generated at 2022-06-23 19:32:53.703855
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    converter = Conversion.get_converter('application/json')
    import json
    data = converter.decode('{"x": "y"}')
    assert data['x'] == 'y'
    data = json.dumps(data)
    data = Formatting(["JSON"]).format_body(data, 'application/json')
    assert data == '{\n    "x": "y"\n}'


# Generated at 2022-06-23 19:33:00.063763
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    mime = 'text/html'
    assert MIME_RE.match(mime)
    assert is_valid_mime(mime)
    assert isinstance(Conversion.get_converter(mime), ConverterPlugin)
    comparison_mime = 'texthtml'
    assert not MIME_RE.match(comparison_mime)
    assert not is_valid_mime(comparison_mime)
    assert not Conversion.get_converter(comparison_mime)


# Generated at 2022-06-23 19:33:08.689816
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.plugins.builtin import FormatterOffPlugin
    groups = ['colors']
    env = Environment()
    obj = Formatting(groups, env)
    assert obj.enabled_plugins == [] # No formatter is enabled.
    obj.enabled_plugins.append(FormatterOffPlugin())
    assert obj.enabled_plugins == [] # No formatter is enabled.
    obj.enabled_plugins.append(FormatterOffPlugin(env=env))
    assert obj.enabled_plugins == [] # No formatter is enabled.

    hdr = 'HTTP/1.1 200 OK\r\nContent-Type: application/json'
    assert obj.format_headers(hdr) == hdr
    assert obj.format_body('{"name": "Foo", "age": 18}', 'application/json') == ''
    assert obj.format

# Generated at 2022-06-23 19:33:09.049526
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    pass

# Generated at 2022-06-23 19:33:11.561941
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter('json') is not None
    assert Conversion.get_converter('json') is not None
    assert Conversion.get_converter('text') is None


# Generated at 2022-06-23 19:33:14.168116
# Unit test for constructor of class Formatting
def test_Formatting():
    fmt = Formatting(['formatters_text'])
    assert fmt.enabled_plugins[0].__class__.__name__ == 'JavascriptFormatter'


# Generated at 2022-06-23 19:33:23.686180
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    """
    This is a unit test of method format_body of class Formatting.
    """

    # command: http GET http://httpbin.org/headers
    # output:
    # {
    #   "headers": {
    #     "Accept": "*/*",
    #     "Accept-Encoding": "gzip, deflate",
    #     "Connection": "close",
    #     "Host": "httpbin.org",
    #     "User-Agent": "HTTPie/0.9.4"
    #   }
    # }

    # Given

# Generated at 2022-06-23 19:33:27.848034
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    text = "hello world"
    formatting = Formatting(['format'], colors=True)
    assert formatting.format_body(text, "text/plain") == "\033[1m\033[37mhello world\033[39m\033[0m"

# Generated at 2022-06-23 19:33:29.081718
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(["colors", "formatters"])
    assert f.enabled_plugins


# Generated at 2022-06-23 19:33:34.376355
# Unit test for constructor of class Formatting
def test_Formatting():
    groups = ['bg']
    env=Environment()
    kwargs = {}
    test_Formatting = Formatting(groups, env, **kwargs)
    assert test_Formatting != None



# Generated at 2022-06-23 19:33:42.796610
# Unit test for constructor of class Formatting
def test_Formatting():
    env = {
        'colors': 'true',
        'theme': 'solarized-dark',
        'format' : 'all',
        'style' : 'default',
        'headers' : 'colors',
        'prettify': 'true'
    }

    f = Formatting(['body', 'headers'], env=env)

    assert f.enabled_plugins[0].enabled == True
    assert f.enabled_plugins[0].mime == "application/json"
    assert f.enabled_plugins[0].keyword == "prettify"
    assert f.enabled_plugins[0].env.colors == True
    assert f.enabled_plugins[0].env.theme == "solarized-dark"
    assert f.enabled_plugins[0].env.format == "all"
    assert f.enabled

# Generated at 2022-06-23 19:33:53.192513
# Unit test for method format_body of class Formatting

# Generated at 2022-06-23 19:33:57.507574
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    headers = '{"Content-Type": "application/json"}'
    f = Formatting(['colors'])
    body = f.format_body('{"name": "Brown"}', "application/json")
    assert body is not None
    print(body)


# Generated at 2022-06-23 19:34:01.170676
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json")
    assert not is_valid_mime("a/b")
    assert not is_valid_mime("content-type")
    assert not is_valid_mime("a/b/c")

# Generated at 2022-06-23 19:34:07.723195
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # To assert the content of a function, create an object and call the
    # function
    # Test the function when the object is null
    converter = Conversion.get_converter(None)
    assert converter == None

    # Test the function when the input is not a valid mime type
    converter = Conversion.get_converter('abc')
    assert converter == None

    # Test the function when the input is a valid mime type
    converter = Conversion.get_converter('text/html')
    assert converter.mime == 'text/html'


# Generated at 2022-06-23 19:34:14.769310
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    fmt = Formatting(['colors'])

# Generated at 2022-06-23 19:34:22.702340
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    env = Environment(stdin=None, stdout=None, stderr=None)
    formatters = Formatting(groups=['colors'], env=env)
    headers = formatters.format_headers('HTTP/1.1 200 OK\r\nA:B\r\n\r\n')
    assert headers == '\x1b[36mHTTP/1.1 200 OK\x1b[0m\r\n\x1b[32mA:\x1b[0mB\r\n\r\n'



# Generated at 2022-06-23 19:34:26.764700
# Unit test for constructor of class Formatting
def test_Formatting():
    test_env = Environment()
    test_data = ["compact", "colors"]
    test_obj = Formatting(test_data, env=test_env, pretty=False)
    assert isinstance(test_obj, Formatting)


# Generated at 2022-06-23 19:34:34.421151
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert(is_valid_mime('text/html') == True)
    assert(is_valid_mime('application/json') == True)
    assert(is_valid_mime('application/xml') == True)
    assert(is_valid_mime('application/x-www-form-urlencoded') == True)
    assert(is_valid_mime('application/jsonp') == True)
    assert(is_valid_mime('xml/html') == False)
    assert(is_valid_mime(None) == False)
    assert(is_valid_mime(' ') == False)
    assert(is_valid_mime('/') == False)

# Generated at 2022-06-23 19:34:35.625079
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    c = Conversion.get_converter("application/json")
    assert (c != None)


# Generated at 2022-06-23 19:34:37.247213
# Unit test for constructor of class Conversion
def test_Conversion():
    conversion = Conversion.get_converter('application/json')
    assert conversion
    conversion = Conversion.get_converter('my/json')
    assert not conversion



# Generated at 2022-06-23 19:34:41.653556
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '''
    <div>
        <p>One more thing</p>
    </div>
    <script>
        console.log("Hello world")
    </script>
    '''
    mime = 'text/html'
    o_content = content
    f = Formatting(['html-format'])
    content = f.format_body(content, mime)
    assert content == o_content, 'content should not be modified'

# Generated at 2022-06-23 19:34:50.917908
# Unit test for method format_body of class Formatting

# Generated at 2022-06-23 19:34:55.211694
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    content = '{"text": "good"}'
    mime = "application/json"
    env = Environment()
    groups = ["JSON-Processors"]
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    result = formatting.format_body(content, mime)
    assert(result == "{\n"+3*' '+"\"text\": \"good\"\n}")

# Generated at 2022-06-23 19:35:00.007260
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    class Headers:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    headers = Headers(a=1, b=2, c=3)
    fmt = Formatting(groups=['headers'])
    s = fmt.format_headers(headers)
    print(s)


# Generated at 2022-06-23 19:35:08.661760
# Unit test for constructor of class Formatting
def test_Formatting():
    # Setup
    env = Environment()
    # env = Environment(default_options={"--pretty": "none"})
    env.colors = False
    groups = ["format", "colors"]
    kwargs = {"pygments_style": "monokai", "colors": True}

    # Exercise
    fm = Formatting(groups, env=env, **kwargs)

    # Verify
    # print("enabled_plugins: ", fm.enabled_plugins)
    assert """b'# ============================================\n# foo\n# ============================================\n# ============================================\n# bar\n# ============================================\n'""" == str(fm.format_headers(b'# ============================================\n# foo\n# ============================================\n# ============================================\n# bar\n# ============================================\n'))


# Generated at 2022-06-23 19:35:09.805569
# Unit test for constructor of class Conversion
def test_Conversion():
    conversion = Conversion()
    print(conversion)


# Generated at 2022-06-23 19:35:15.855067
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert is_valid_mime('application/json')
    assert is_valid_mime('application/vnd.api+json')

    assert not is_valid_mime('application/json;charset=utf-8')
    assert not is_valid_mime('<html>')
    assert not is_valid_mime('')
    assert not is_valid_mime(None)


test_is_valid_mime()

# Generated at 2022-06-23 19:35:19.280108
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    with open('test/test.json') as f:
        content = f.read()
    result = Formatting(['colors']).format_body(content, 'application/json')
    print('formated content:\n' + result)


# Generated at 2022-06-23 19:35:21.909727
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    # python has no method overloading, so we skip the new param.
    def get_converter(mime, env=Environment()):
        return Conversion.get_converter(mime)
    assert isinstance(get_converter("text/csv"), ConverterPlugin)
    assert isinstance(get_converter("application/csv"), ConverterPlugin)
    assert get_converter("application/xml") is None

# Generated at 2022-06-23 19:35:22.755825
# Unit test for constructor of class Formatting
def test_Formatting():
    Formatting(['color'])
    Formatting(['color', 'format'])

# Generated at 2022-06-23 19:35:26.974725
# Unit test for function is_valid_mime
def test_is_valid_mime():
    type1 = "text/plain"
    type2 = "application/json"
    type3 = "text/plain/"
    type4 = "/text/plain"
    type5 = ""
    type6 = None
    assert is_valid_mime(type1) == True
    assert is_valid_mime(type2) == True
    assert is_valid_mime(type3) == False
    assert is_valid_mime(type4) == False
    assert is_valid_mime(type5) == False
    assert is_valid_mime(type6) == False

# Generated at 2022-06-23 19:35:31.699612
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)
    assert converter.mime == mime
    assert converter.supports('application/json')
    assert converter.supports('text/x-python')
    assert converter.supports('text/html')
    assert not converter.supports('application/xml')

# Generated at 2022-06-23 19:35:33.847322
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter(mime="application/json")
    assert converter is not None



# Generated at 2022-06-23 19:35:41.812210
# Unit test for constructor of class Formatting
def test_Formatting():
    from httpie.core import main as httpie
    from httpie.plugins import builtin
    from httpie.plugins import ConverterPlugin

    class JsonPrettyConverter(ConverterPlugin):
        def __init__(self, env=Environment(stdout=StringIO())):
            self.env = env

        def convert(self, value: str,
                    encoder: json.JSONEncoder,
                    indent: Optional[int] = None) -> str:
            return json.dumps(value, indent=indent, sort_keys=True)

        @staticmethod
        def supports(mime: str) -> bool:
            return mime in ['application/json']


# Generated at 2022-06-23 19:35:49.826962
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import pytest
    class Formatter_headers(object):
        def __init__(self, env, **kwargs):
            self.env = env
            self.enabled = True

        def format_headers(self, headers: str) -> str:
            return "MONEY MONEY MONEY"

    class Formatter_body(object):
        def __init__(self, env, **kwargs):
            self.env = env
            self.enabled = True

        def format_body(self, content: str, mime: str) -> str:
            return content

    plugin_manager.set_formatters([Formatter_headers, Formatter_body])
    env = Environment(stdin=None, stdin_isatty=False,
                     stdout=None, stdout_isatty=False)

# Generated at 2022-06-23 19:35:52.186287
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = 'application/json'
    converter = Conversion.get_converter(mime)

    assert isinstance(converter, ConverterPlugin)
    assert converter.mime == mime
    assert converter.supports(mime)


# Generated at 2022-06-23 19:35:54.500189
# Unit test for constructor of class Conversion
def test_Conversion():
    conv = Conversion()
    assert conv == None


# Generated at 2022-06-23 19:36:00.407439
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    import json
    json_data = json.dumps({
        'req_name': {
            'sender': 'Alice',
            'receiver': 'Bob',
            'message': 'I love you, Bob'
            }
        })
    example = Formatting(['colors'])
    result = example.format_body(json_data, "application/json")
    print(result)

# test_Formatting_format_body()

# Generated at 2022-06-23 19:36:02.915768
# Unit test for constructor of class Formatting
def test_Formatting():
    f = Formatting(groups=['color'])
    assert f.enabled_plugins != []



# Generated at 2022-06-23 19:36:10.625860
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test_mimes = [
        ('video/webm', 'webm'),
        ('', ''),
        ('abc', ''),
        ('abc/', ''),
        ('abc/def', ''),
        ('text/', ''),
        ('text/abc', 'abc'),
    ]
    for mime, expected_extension in test_mimes:
        converter = Conversion.get_converter(mime)
        if converter:
            actual_extension = converter.extension
        else:
            actual_extension = ''
        assert expected_extension == actual_extension, \
            f'{mime} should be converted to {expected_extension}, not {actual_extension}'



# Generated at 2022-06-23 19:36:13.525941
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime(None) is False
    assert is_valid_mime('application/json') is True
    assert is_valid_mime('application/json; json') is False

# Generated at 2022-06-23 19:36:25.212063
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    def _test_one_round(input_val, output_val):
        assert formatting.format_headers(input_val) == output_val
    env = Environment()
    env.colors = False
    formatting = Formatting(groups=["headers"], env=env)

# Generated at 2022-06-23 19:36:30.678830
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime(mime='application/json')
    assert is_valid_mime(mime='application/j') is False
    assert is_valid_mime(mime='application') is False
    assert is_valid_mime(mime='/json') is False
    assert is_valid_mime(mime='') is False
    assert is_valid_mime(mime=None) is False

# Generated at 2022-06-23 19:36:35.069263
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("text/html")
    assert not is_valid_mime("text")
    assert not is_valid_mime("/html")
    assert not is_valid_mime("text//html")
    assert not is_valid_mime("")

# Generated at 2022-06-23 19:36:37.604122
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/plain')
    assert not is_valid_mime('text/')
    assert not is_valid_mime('text')


# Generated at 2022-06-23 19:36:41.302896
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json')
    assert is_valid_mime('AplicAtion/json')
    assert is_valid_mime('application/json/')
    assert not is_valid_mime('')
    assert is_valid_mime('text/html')

# Generated at 2022-06-23 19:36:43.137854
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter = Conversion.get_converter('text/html')
    assert(isinstance(converter, ConverterPlugin))


# Generated at 2022-06-23 19:36:47.957581
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert not is_valid_mime(None)
    assert not is_valid_mime("")
    assert not is_valid_mime("/")
    assert not is_valid_mime("abc/")
    assert not is_valid_mime("/abc")
    assert is_valid_mime("abc/def")

# Generated at 2022-06-23 19:36:59.511139
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    env = Environment()
    env.config['colors'] = True
    env.config['style'] = 'parrot'
    try:
        from parrotstyle.style import ParrotStyle
    except ImportError:
        ParrotStyle = None
    env.style = ParrotStyle()

    groups = ['colors']
    f = Formatting(groups, env=env, mime='application/json')
    assert f.format_body('{"x": "y"}', 'application/json') == '\x1b[34m{\x1b[39;49;00m\n' \
                                                              '  \x1b[34m"x"\x1b[39;49;00m: \x1b[32m"y"\x1b[39;49;00m\n' \
                                                

# Generated at 2022-06-23 19:37:04.656605
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('application/json') == True
    assert is_valid_mime('application/xml') == True
    assert is_valid_mime('application/any') == True
    assert is_valid_mime('any/xml') == True
    assert is_valid_mime('json') == False
    assert is_valid_mime('application/') == False
    assert is_valid_mime('') == False

# Generated at 2022-06-23 19:37:08.806413
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    assert isinstance(Conversion.get_converter('application/json'), ConverterPlugin)
    assert Conversion.get_converter('text/css').supported_mime == 'text/css'
    assert not Conversion.get_converter('text/css').convert('abc')
    assert Conversion.get_converter('application/json').convert('{"abc":1}')
    assert not Conversion.get_converter('application/json').convert('abc')



# Generated at 2022-06-23 19:37:16.643096
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    test1 = Conversion()
    assert test1.get_converter("text/csv") is not None
    assert test1.get_converter("text/json") is not None
    assert test1.get_converter("text/xml") is not None
    assert test1.get_converter("text/plain") is None
    assert test1.get_converter("text") is None
    assert test1.get_converter("text/") is None
    assert test1.get_converter("/csv") is None
    assert test1.get_converter("text/csv/") is None
    assert test1.get_converter("") is None
    assert test1.get_converter("/") is None
    test1 = conversion.Conversion()
    assert test1.get_

# Generated at 2022-06-23 19:37:21.403022
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = "application/json"
    # Conversion.get_converter(mime)

    test_converter_plugin_object = ConverterPlugin('test')
    # test_converter_plugin_object.supports(mime)

    global plugin_manager
    # plugin_manager.get_converters()



# Generated at 2022-06-23 19:37:30.091801
# Unit test for constructor of class Conversion
def test_Conversion():
    mime = None
    expected_converter = None

    converter = Conversion.get_converter(mime)
    assert converter == expected_converter, 'Test case 1: Converter with not-assigned mime is not correct'

    mime = 'invalid mime'
    expected_converter = None

    converter = Conversion.get_converter(mime)
    assert converter == expected_converter, 'Test case 2: Converter with invalid mime is not correct'

    mime = 'text/html'
    expected_converter = None

    plugin_manager.disable_class(ConverterPlugin)
    converter = Conversion.get_converter(mime)
    assert converter == expected_converter, 'Test case 3: Converter with disabled ConverterPlugin is not correct'

    mime

# Generated at 2022-06-23 19:37:34.646764
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    from httpie.formatters import JSONFormatter, JSONLinesFormatter
    obj = Formatting(["json"])
    assert obj.enabled_plugins == [JSONFormatter, JSONLinesFormatter]
    json_str = '[{"a": "A", "b": "B"}]'
    assert obj.format_body(json_str, "application/json") == json_str
    assert obj.format_body(json_str, "application/jsonl") == json_str
    assert obj.format_body(json_str, "application/json+custom") != json_str

# Generated at 2022-06-23 19:37:35.829537
# Unit test for constructor of class Conversion
def test_Conversion():
    test_converter = Conversion.get_converter("application/json")
    assert test_converter is not None


# Generated at 2022-06-23 19:37:44.200564
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    n1 = Formatting(['pretty'], True)
    n2 = Formatting(['colors'], True)
    n3 = Formatting(['colors'], False)
    n4 = Formatting([], True)
    print(n1.format_body('{"a": "12"}', 'application/json'))
    print(n2.format_body('{"a": "12"}', 'application/json'))
    print(n3.format_body('{"a": "12"}', 'application/json'))
    print(n4.format_body('{"a": "12"}', 'application/json'))



# Generated at 2022-06-23 19:37:54.434802
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import json
    # Create an instance of Formatting
    F = Formatting(groups=["headers"])

    # test case 1
    http_headers = json.dumps({"test":"test"})
    assert F.format_headers(http_headers) == '\nHTTP/1.1 200 OK\nContent-Type: application/json; charset=utf-8\nStatus: 200\n{\n    "test": "test"\n}'

    # test case 2
    http_headers = json.dumps({"test":"test"}, indent=4)
    assert F.format_headers(http_headers) == '\nHTTP/1.1 200 OK\nContent-Type: application/json; charset=utf-8\nStatus: 200\n{\n    "test": "test"\n}'

# Unit test

# Generated at 2022-06-23 19:37:59.505102
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    groups = ['colors']
    env = Environment()
    kwargs = {}
    formatting = Formatting(groups, env, **kwargs)
    headers = 'HTTP/1.1 200 OK\r\nCache-Control: no-cache\r\nDate: Mon, 27 Jul 2009 12:28:53 GMT\r\nExpires: -1\r\n\
    Content-Type: text/html; charset=UTF-8\r\nServer: gws\r\nContent-Length: 0\r\nX-XSS-Protection: 0\r\n\r\n'
    assert headers == formatting.format_headers(headers)

# Generated at 2022-06-23 19:38:00.087448
# Unit test for constructor of class Formatting
def test_Formatting():
    pass

# Generated at 2022-06-23 19:38:04.589186
# Unit test for function is_valid_mime
def test_is_valid_mime():
    def test(mime):
        return mime, is_valid_mime(mime)
    assert test("text/plain") == ("text/plain", True)
    assert test("a/b") == ("a/b", True)
    assert test("") == ("", False)
    assert test("/") == ("/", False)
    assert test("text/") == ("text/", False)
    assert test("/plain") == ("/plain", False)

# Generated at 2022-06-23 19:38:09.268957
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(['colors']).format_headers('content-type: text/html\n') == '\x1b[36mcontent-type\x1b[39m: \x1b[36mtext/html\x1b[39m\n'


# Generated at 2022-06-23 19:38:19.344354
# Unit test for constructor of class Conversion
def test_Conversion():
    assert not is_valid_mime(None)
    assert not is_valid_mime("txt")
    assert not is_valid_mime("text/")
    assert not is_valid_mime("/plain")
    assert not is_valid_mime("text/plain/")
    assert is_valid_mime("text/plain")
    assert is_valid_mime("text/html")
    assert is_valid_mime("application/json")
    assert not is_valid_mime("application/json+xml")
    assert not is_valid_mime("application/json+")
    converter = Conversion.get_converter("application/json")
    assert converter.supports("application/json")
    assert converter.supports("application/json ")
    assert converter.supports(" application/json")
   

# Generated at 2022-06-23 19:38:22.114524
# Unit test for constructor of class Conversion
def test_Conversion():
    try:
        # Function call:
        Conversion.get_converter(mime = "text/plain")
    except Exception:
        assert False
    return



# Generated at 2022-06-23 19:38:31.173845
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    print("test method 'format_body()' of class 'Formatting'")
    print()

    # Input, conversion and expected output
    input_1 = '{"test": {"name": "httpie"}}'
    mime_1 = 'application/json'
    output_1 = '{\n    "test": {\n        "name": "httpie"\n    }\n}\n'

    # Unit test
    print("input: ", input_1)
    print("expected output: ", output_1)
    print("mime: ", mime_1)
    print("output: ", Formatting(['pretty']).format_body(input_1, mime_1))

    print()
    print("test successfull")


if __name__ == '__main__':
    test_Formatting_format_body()

# Generated at 2022-06-23 19:38:40.081597
# Unit test for method format_headers of class Formatting

# Generated at 2022-06-23 19:38:43.323443
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime("application/json") == True
    assert is_valid_mime("/json") == False
    assert is_valid_mime("") == False
    assert is_valid_mime(None) == False


# Generated at 2022-06-23 19:38:51.324875
# Unit test for method format_body of class Formatting
def test_Formatting_format_body():
    test_data = [('<html><h1>hello</h1></html>', 'text/html',
                  '\u001b[1m<html><h1>hello</h1></html>\u001b[0m')]
    for data in test_data:
        body, mime, formatted_body = data
        formatter = Formatting(['format'])
        assert formatter.format_body(body, mime) == formatted_body

# Generated at 2022-06-23 19:38:54.071906
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    """Unit test for method get_converter of class Conversion"""
    assert(Conversion.get_converter("application/json") is not None)

# Generated at 2022-06-23 19:38:56.857346
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime('text/html')
    assert not is_valid_mime('text/html/asd')

# Generated at 2022-06-23 19:39:00.529992
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime(None) == False
    assert is_valid_mime(1) == False
    assert is_valid_mime("application/json") == True
    assert is_valid_mime("application") == False

# Generated at 2022-06-23 19:39:06.037264
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    available_plugins = plugin_manager.get_formatters_grouped()
    env = Environment()
    f = Formatting(['colors'], env)
    for p in f.enabled_plugins:
        if p.enabled:
            p.format_headers("Content-Encoding: gzip\nContent-Type: application/json")


# Generated at 2022-06-23 19:39:10.592525
# Unit test for method get_converter of class Conversion
def test_Conversion_get_converter():
    converter=Conversion.get_converter("application/json")
    assert converter.__class__.__name__ == "JsonConverter"
    converter=Conversion.get_converter("application/xml")
    assert converter.__class__.__name__ == "XmlConverter"

# Generated at 2022-06-23 19:39:19.155169
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    # generate fake headers
    from httpie.core import parse_headers
    from collections import OrderedDict

# Generated at 2022-06-23 19:39:20.066663
# Unit test for constructor of class Conversion
def test_Conversion():
    c = Conversion()



# Generated at 2022-06-23 19:39:22.014466
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    assert Formatting(["pretty"]).format_headers("Content-Length=15") == "Content-Length = 15"



# Generated at 2022-06-23 19:39:23.911817
# Unit test for constructor of class Formatting
def test_Formatting():
    Format_test = Formatting(['color'])
    assert Format_test.enabled_plugins[0].enabled is True


# Generated at 2022-06-23 19:39:27.345517
# Unit test for function is_valid_mime
def test_is_valid_mime():
    # Test case with valid mime type
    assert is_valid_mime("text/csv")

    # Test case with invalid mime type
    assert not is_valid_mime("text")

# Generated at 2022-06-23 19:39:31.555698
# Unit test for function is_valid_mime
def test_is_valid_mime():
    assert is_valid_mime(None) is False
    assert is_valid_mime("halllllllll") is False
    assert is_valid_mime("application/json")
    assert is_valid_mime("application/x-www-form-urlencoded")

# Generated at 2022-06-23 19:39:37.916855
# Unit test for constructor of class Formatting
def test_Formatting():
    env = Environment(colors=True)
    groups = ['colors']
    formatting = Formatting(groups, env)
    assert('JsonProcessor' in str(formatting.enabled_plugins))
    assert('JsonHighlightFormatter' in str(formatting.enabled_plugins))
    assert('PrettyFormatter' in str(formatting.enabled_plugins))
    assert('PrettyJsonHighlightFormatter' in str(formatting.enabled_plugins))
    assert('PrintyFormatter' in str(formatting.enabled_plugins))


# Generated at 2022-06-23 19:39:48.127539
# Unit test for method format_headers of class Formatting
def test_Formatting_format_headers():
    import os
    import sys
    sys.path.append(os.getcwd() + "/../")

# Generated at 2022-06-23 19:39:49.899688
# Unit test for constructor of class Conversion
def test_Conversion():
    assert Conversion.get_converter("text/html") is not None, "Expected valid mime type text/html, got None"