

# Generated at 2022-06-17 22:05:19.042330
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:05:20.724877
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:05:22.596488
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:05:24.134180
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:05:28.706306
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:05:35.597600
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda: 'Сәлем, достық!')() == 'Salem, dostyk!'

# Generated at 2022-06-17 22:05:41.136288
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:05:45.476530
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:05:50.382283
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:05:57.525543
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:06:13.718501
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Привет') == 'Privet'

    @romanize('uk')
    def romanize_uk(text):
        return text

    assert romanize_uk('Привіт') == 'Pryvit'

    @romanize('kk')
    def romanize_kk(text):
        return text

    assert romanize_kk('Сәлем') == 'Sälem'

# Generated at 2022-06-17 22:06:17.849524
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:23.214368
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:06:25.199897
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:06:28.928387
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:33.223154
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:35.122856
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:06:42.268071
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:06:45.896761
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:51.721487
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:07:19.613349
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:07:29.327906
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:07:35.296520
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:07:37.662264
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:40.815066
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:44.641807
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:07:49.069394
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:51.275931
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:07:58.365512
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Привет, мир!') == 'Privet, mir!'

    @romanize('uk')
    def romanize_uk(text):
        return text

    assert romanize_uk('Привіт, світ!') == 'Pryvit, svit!'

    @romanize('kk')
    def romanize_kk(text):
        return text

    assert romanize_kk('Сәлем, дүние!') == 'Sälem, dünie!'

# Generated at 2022-06-17 22:08:02.401159
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:05.135156
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:09.587778
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:09:13.894617
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:17.325394
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:09:22.042713
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:29.567294
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:09:35.524482
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:43.325285
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    from mimesis.builtins import Person

    p = Person('ru')
    assert p.full_name() == 'Александр Сергеевич Пушкин'
    assert p.full_name(romanize=True) == 'Aleksandr Sergeevich Pushkin'

    p = Person('uk')
    assert p.full_name() == 'Олександр Сергійович Пушкін'
    assert p.full_name(romanize=True) == 'Oleksandr Serhiyovych Pushkin'

    p = Person('kk')

# Generated at 2022-06-17 22:09:48.442522
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:09:54.893988
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:11:49.380278
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Привет, мир!') == 'Privet, mir!'

    @romanize('uk')
    def romanize_uk(text):
        return text

    assert romanize_uk('Привіт, світ!') == 'Pryvit, svit!'

    @romanize('kk')
    def romanize_kk(text):
        return text

    assert romanize_kk('Сәлем, дүние!') == 'Sälem, dünie!'

# Generated at 2022-06-17 22:11:58.888534
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:12:04.465684
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    p = Person(Locale.RU)
    assert p.full_name() == 'Василий Иванов'
    assert p.full_name(romanize=True) == 'Vasiliy Ivanov'

# Generated at 2022-06-17 22:12:10.396664
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:12:14.119409
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:12:19.808147
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:12:23.827756
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:12:28.345085
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:12:30.078882
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-17 22:12:33.432889
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:14:17.008593
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanized('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanized('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:14:19.508967
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:14:25.773423
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:14:30.588170
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:14:35.150288
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:14:38.199291
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:14:40.431432
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:14:45.354636
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:14:50.323855
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:14:57.436938
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'