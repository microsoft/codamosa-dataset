

# Generated at 2022-06-17 22:05:17.301615
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:05:24.101497
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:05:29.337161
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'



# Generated at 2022-06-17 22:05:31.211552
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:05:36.289240
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:05:39.178569
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:05:41.201584
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-17 22:05:45.517693
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:05:50.424945
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:05:54.618398
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:06:08.664618
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:10.483786
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-17 22:06:19.786633
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-17 22:06:23.622962
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:27.861220
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:06:33.180806
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир!')() == 'Privet mir!'
    assert romanize('uk')(lambda: 'Привіт світ!')() == 'Pryvit svit!'
    assert romanize('kk')(lambda: 'Сәлем әлем!')() == 'Sälem älem!'

# Generated at 2022-06-17 22:06:36.830586
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:43.757499
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:06:48.950010
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:57.422317
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize()('Привет мир') == 'Privet mir'
    assert romanize()('Привет, мир!') == 'Privet, mir!'
    assert romanize()('Привет, мир! Как дела?') == 'Privet, mir! Kak dela?'
    assert romanize()('Привет, мир! Как дела? Хорошо.') == 'Privet, mir! Kak dela? Horosho.'

# Generated at 2022-06-17 22:07:24.314029
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:07:29.585235
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:07:34.703444
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    from mimesis.builtins import RussianSpecProvider

    russian = RussianSpecProvider()

    @romanize('ru')
    def romanized_text():
        return russian.text()

    assert romanized_text()

# Generated at 2022-06-17 22:07:40.924102
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:07:45.892174
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:07:51.258362
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:58.740786
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:04.843813
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:08:10.085314
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize(locale='ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize(locale='uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'

# Generated at 2022-06-17 22:08:12.151575
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:08:46.704364
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, Мир!') == 'Privet, Mir!'
    assert romanize('uk')('Привіт, Світ!') == 'Pryvit, Svit!'
    assert romanize('kk')('Сәлем, Дүние!') == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:08:49.584032
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:58.766887
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:09:03.586534
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:07.287766
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:09:10.870012
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:09:14.750466
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:09:22.166826
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:09:26.784261
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    p = Person(Locale.RU)
    assert p.full_name() == 'Александр Королев'
    assert p.full_name(romanize=True) == 'Aleksandr Korolev'

# Generated at 2022-06-17 22:09:37.571630
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-17 22:10:24.738430
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:10:30.104476
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:10:34.993806
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:10:38.529977
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:10:44.448394
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:10:52.812754
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'

# Generated at 2022-06-17 22:10:59.847330
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:11:04.651859
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:11:08.323584
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:11:11.553820
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:12:58.167052
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:03.553237
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:13:08.205078
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:17.537430
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_ru():
        return 'Привет, Мир!'

    assert romanize_ru() == 'Privet, Mir!'

    @romanize('uk')
    def romanize_uk():
        return 'Привіт, Світ!'

    assert romanize_uk() == 'Pryvit, Svit!'

    @romanize('kk')
    def romanize_kk():
        return 'Сәлем, Дүние!'

    assert romanize_kk() == 'Sälem, Dünie!'

    @romanize('en')
    def romanize_en():
        return 'Привет, Мир!'


# Generated at 2022-06-17 22:13:20.954438
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:25.664304
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:31.302606
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'



# Generated at 2022-06-17 22:13:34.639202
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:13:36.407868
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-17 22:13:41.805716
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'