

# Generated at 2022-06-17 22:05:26.578428
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:05:33.282434
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:05:38.734476
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:05:43.404321
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:05:48.080970
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:05:52.086344
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:00.823208
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:06:05.718706
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:06:10.951487
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:06:16.510900
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    person = Person(Locale.RUSSIAN)
    address = Address(Locale.RUSSIAN)

    assert person.full_name(romanize=True) == person.full_name()
    assert address.city(romanize=True) == address.city()

# Generated at 2022-06-17 22:06:26.228110
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:31.588862
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:06:35.890687
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:42.902593
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:06:49.755041
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:07:00.322526
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Привет') == 'Privet'

    @romanize('uk')
    def romanize_uk(text):
        return text

    assert romanize_uk('Привіт') == 'Pryvit'

    @romanize('kk')
    def romanize_kk(text):
        return text

    assert romanize_kk('Сәлем') == 'Salem'

# Generated at 2022-06-17 22:07:05.302242
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:09.760341
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:07:14.780535
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:17.838270
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:07:36.559374
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:07:42.291094
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:07:43.810597
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-17 22:07:46.532681
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:52.041111
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:01.130149
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:08:05.173579
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:08.352578
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:14.302508
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:08:18.700698
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:01.628369
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:09:03.998662
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-17 22:09:08.651259
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:12.983452
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:09:16.166272
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_test(text):
        return text

    assert romanize_test('Привет') == 'Privet'
    assert romanize_test('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-17 22:09:21.811401
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:09:27.073479
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:09:32.703707
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:42.684722
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:09:47.852528
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:10:39.125171
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:10:49.825940
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-17 22:10:56.811019
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:11:01.829103
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:11:06.795464
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:11:10.825264
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:11:15.972637
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:11:19.477713
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:11:22.020430
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:11:28.804769
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:14.346584
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:21.207208
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:13:23.236380
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:13:27.524890
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:31.682877
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:13:34.205641
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:39.758119
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:43.994657
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:47.561795
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:54.957995
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    p = Person(Locale.RUSSIAN)
    assert p.full_name() == 'Алексей Иванов'
    assert p.full_name(romanize=True) == 'Aleksey Ivanov'

    p = Person(Locale.UKRAINIAN)
    assert p.full_name() == 'Іван Петров'
    assert p.full_name(romanize=True) == 'Ivan Petrovych'

    p = Person(Locale.KAZAKH)