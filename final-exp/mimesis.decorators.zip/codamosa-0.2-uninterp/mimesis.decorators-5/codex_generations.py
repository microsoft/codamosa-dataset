

# Generated at 2022-06-17 22:05:17.302440
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_text():
        return 'Привет, Мир!'

    assert romanize_text() == 'Privet, Mir!'

# Generated at 2022-06-17 22:05:20.811460
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:05:26.055679
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:05:34.260761
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:05:39.000209
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:05:43.616619
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:05:48.660179
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda: 'сәлем')() == 'salem'

# Generated at 2022-06-17 22:05:55.031235
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:01.124305
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:03.392386
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:06:18.445977
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:22.305753
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:26.412961
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:30.720635
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:32.840968
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-17 22:06:36.664356
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:39.106426
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет мир!')() == 'Privet mir!'

# Generated at 2022-06-17 22:06:43.182341
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_func(text):
        return text

    assert romanize_func('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-17 22:06:48.519119
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:06:52.960734
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:07.988855
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:10.672702
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:07:16.565091
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:20.619995
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:07:26.961562
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:07:31.570843
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:07:37.379520
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:41.600580
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:07:44.118707
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_test(text):
        return text

    assert romanize_test('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-17 22:07:45.629581
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:12.069193
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:08:16.564774
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:08:20.623093
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:25.191626
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:08:32.886589
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:37.472542
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:42.340866
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:45.797700
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:53.054030
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:08:59.694011
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:51.231156
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:09:58.816956
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('ru')(lambda: 'Привет, как дела?')() == 'Privet, kak dela?'
    assert romanize('uk')(lambda: 'Привіт, як справи?')() == 'Pryvit, yak spravy?'

# Generated at 2022-06-17 22:10:03.663919
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:10:09.426480
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Привет') == 'Privet'

    @romanize('uk')
    def romanize_uk(text):
        return text

    assert romanize_uk('Привіт') == 'Pryvit'

    @romanize('kk')
    def romanize_kk(text):
        return text

    assert romanize_kk('Сәлем') == 'Sälem'

# Generated at 2022-06-17 22:10:10.604418
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-17 22:10:17.483527
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привет')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Привет')() == 'Pryvet'

# Generated at 2022-06-17 22:10:25.098893
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_text():
        return 'Привет, Мир!'

    assert rus_text() == 'Privet, Mir!'

    @romanize(locale='uk')
    def ukr_text():
        return 'Привіт, Світ!'

    assert ukr_text() == 'Pryvit, Svit!'

    @romanize(locale='kk')
    def kaz_text():
        return 'Сәлем, Дүние!'

    assert kaz_text() == 'Sälem, Dünie!'

# Generated at 2022-06-17 22:10:29.279592
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:10:33.047514
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:10:36.893777
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:12:25.116550
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Привет, мир!') == 'Privet, mir!'

# Generated at 2022-06-17 22:12:30.873981
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:12:35.053235
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:12:38.034243
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-17 22:12:42.527069
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:12:46.909871
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:12:52.059147
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-17 22:12:58.613316
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:13:05.433633
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

    # Test for backward compatibility
    assert romanized('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-17 22:13:09.881784
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-17 22:14:48.937784
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:14:51.675250
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-17 22:14:59.722193
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    p = Person(Locale.RU)
    assert p.full_name() == 'Сергей Петров'
    assert p.full_name(romanize=True) == 'Sergey Petrov'

# Generated at 2022-06-17 22:15:05.007737
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привет')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Привет')() == 'Pryvet'

# Generated at 2022-06-17 22:15:09.050505
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'