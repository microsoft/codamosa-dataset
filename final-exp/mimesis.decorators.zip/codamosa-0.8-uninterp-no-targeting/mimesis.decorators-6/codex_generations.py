

# Generated at 2022-06-21 15:35:05.126054
# Unit test for function romanize
def test_romanize():
    r = romanize('en')(lambda: 'test')
    assert r() == 'test'



# Generated at 2022-06-21 15:35:07.490623
# Unit test for function romanize
def test_romanize():
    @romanized(locale='ru')
    def rus(x):
        return x

    assert rus('русский') == 'russkiy'

# Generated at 2022-06-21 15:35:13.582045
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-21 15:35:19.633455
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import TextSpecifier

    test = TextSpecifier('ru')
    origin = test.word(quantity=4)
    assert origin == test.romanize()

    test = TextSpecifier('uk')
    origin = test.word(quantity=4)
    assert origin == test.romanize()

    test = TextSpecifier('kk')
    origin = test.word(quantity=4)
    assert origin == test.romanize()

# Generated at 2022-06-21 15:35:21.215520
# Unit test for function romanize
def test_romanize():
    _romanize = romanized("ru")("romanize")
    assert isinstance(_romanize, functools.partial)

# Generated at 2022-06-21 15:35:26.725052
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Новосибирск')() == 'Novosibirsk'
    assert romanize(locale='kk')(lambda: 'Казақстан')() == 'Qazaqstan'
    assert romanize(locale='uk')(lambda: 'Україна')() == 'Ukraïna'

# Generated at 2022-06-21 15:35:37.839843
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Geography
    gen = Geography()
    assert gen.local_province() == 'Ставропольский край'
    assert gen.local_province(romanize=True) == 'Stavropolskij kraj'
    assert gen.local_province(locale='ru', romanize=True) == 'Stavropolskij kraj'
    assert gen.local_province(locale='uk', romanize=True) == 'Ставропольський край'

# Generated at 2022-06-21 15:35:42.224745
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='kk')
    assert romanize(locale='ru')
    assert romanize(locale='uk')
    try:
        assert romanize(locale='ukr')
    except UnsupportedLocale:
        pass
    else:
        assert False

# Generated at 2022-06-21 15:35:49.235377
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import russian
    assert russian.get_romanized_word() == 'Volosatyj'
    assert russian.get_romanized_text() == 'Stroganovskaja'
    assert russian.get_romanized_text() == 'Sto sorok shestyj'

    from mimesis.builtins import ukrainian
    assert ukrainian.get_romanized_word() == 'Bolshoj'
    assert ukrainian.get_romanized_text() == 'Piatnadtsatyj'
    assert ukrainian.get_romanized_text() == 'Zaporozhskyi'

    from mimesis.builtins import kazakh
    assert kazakh.get_romanized_word() == 'Yevropa'


# Generated at 2022-06-21 15:35:53.205801
# Unit test for function romanize
def test_romanize():
    assert romanize()('привет') is not None
    assert romanize('ru')('привет') == 'privet'

    @romanize('ru')
    def test(arg):
        return arg

    assert test('привет') == 'privet'

# Generated at 2022-06-21 15:36:09.534761
# Unit test for function romanize
def test_romanize():
    import mimesis.data.extras as extras

    locale = 'ru'
    assert romanized(locale)(lambda: 'деревенская жизнь')(locale=locale) == \
        'derevenskaja zizn'


# Generated at 2022-06-21 15:36:12.647926
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    from mimesis.builtins import Person

    p = Person('')
    r = p.full_name(romanize=True)
    assert len(r) > 0

# Generated at 2022-06-21 15:36:16.234131
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo(string: str) -> str:
        return string

    assert foo('Привет, мир') == 'Privet, mir'

# Generated at 2022-06-21 15:36:18.920907
# Unit test for function romanize
def test_romanize():
    assert romanize()('Ваш браузер устарел') == 'Vash brauzer ustarel'

# Generated at 2022-06-21 15:36:19.252955
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:36:27.828426
# Unit test for function romanize
def test_romanize():
    def romanize(txt):
        alphabet = {s: s for s in ascii_letters + digits + punctuation}

# Generated at 2022-06-21 15:36:32.091938
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    assert romanized(Language.RU.value)(Address.address)() == '8-я улица Комсомола дом 2'

# Generated at 2022-06-21 15:36:35.090072
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Первая строка.')() == 'Pervaja stroka.'



# Generated at 2022-06-21 15:36:38.173847
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person as P
    person = P('ru')
    result = person.full_name()  # noqa: F841


test_romanize()

# Generated at 2022-06-21 15:36:42.759718
# Unit test for function romanize
def test_romanize():
    # The function romanize is wrapped in the function romanize_deco
    # The function romanize_deco is returned by the function romanize
    # Therefore, we need to call the function romanize twice
    @romanize('ru')
    @romanize()
    def name(local='en'):
        return 'Тест'
    assert name() == 'Test'

# Generated at 2022-06-21 15:36:53.697384
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_test(string: str) -> str:
        return string

    assert romanize_test('республика') == 'respublika'
    assert romanize_test('республика Казахстан') == 'respublika Kazakhstan'

# Generated at 2022-06-21 15:36:57.780616
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize()(lambda: 'Я')() == 'Ya'

    assert romanized()(lambda: 'Я')() == 'Ya'



# Generated at 2022-06-21 15:37:00.793223
# Unit test for function romanize
def test_romanize():
    """Romanize test."""
    t = romanized()
    assert t  # NOQA
    assert t == 'romanize'
    assert t == 'romanize'
    assert t == 'romanize'

# Generated at 2022-06-21 15:37:04.209709
# Unit test for function romanize
def test_romanize():
    expected = 'zavtra vyjde solnce'
    result = romanize('ru')(lambda : 'завтра выйдет солнце')()
    assert expected == result



# Generated at 2022-06-21 15:37:16.466047
# Unit test for function romanize

# Generated at 2022-06-21 15:37:24.195632
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanized('ru')(lambda: 'Спасибо')() == 'Spasibo'
    assert romanized('ru')(lambda: 'Привет, как дела?')() == \
           'Privet, kak dela?'
    assert romanized('uk')(lambda: 'Привіт')() == 'Privit'
    assert romanized('uk')(lambda: 'Шелестов')() == 'Shelestov'
    assert romanized('kk')(lambda: 'Азаттың')() == 'Azattıñ'
    assert romanized('kk')(lambda: 'Алматы')

# Generated at 2022-06-21 15:37:30.174611
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    assert romanized('ru')(lambda: 'Проверка')() == 'Proverka'

    s = lambda x: [i for i in x]
    assert romanized('ru')(s)('Проверка') == ['P', 'r', 'o', 'v',
                                               'e', 'r', 'k', 'a']

# Generated at 2022-06-21 15:37:40.165748
# Unit test for function romanize
def test_romanize():
  from mimesis import Person
  from mimesis.builtins import RussiaSpecProvider

  p = Person('ru')
  assert p.full_name() == 'Марина Романова'
  assert p.full_name(romanize=True) == 'Marina Romanova'
  y = p.full_name(romanize='uk')
  assert y in ('Maryna Romanova', 'Marina Romanova')
  y = p.full_name(romanize='kk')
  assert y in ('Marına Romanova', 'Marına Romanova')

  y = p.full_name(romanize=True, spec=RussiaSpecProvider)
  assert len(y.split()) == 2
  assert y

# Generated at 2022-06-21 15:37:42.486847
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Облако')() == 'Oblako'

# Generated at 2022-06-21 15:37:50.104317
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import TextSpecProvider
    from mimesis.enums import Language

    russian_text = TextSpecProvider(Language.RU)
    print(russian_text.word(romanized=False))

    # You can use the decorator in not-overridden methods in
    # the class and it will work.
    print(russian_text.word(romanized=True))

    # You can also use the function romanized as a decorator
    # to override the method in the class.
    @romanized()
    def _word(self, length: int = None, romanized: bool = True) -> str:
        return self.__word(length)

    # Set the method in the class
    TextSpecProvider.word = _word

# Generated at 2022-06-21 15:38:03.231379
# Unit test for function romanize
def test_romanize():
    test_data = data.ROMANIZATION_DICT['ru']
    for k, v in test_data.items():
        assert romanize('ru')(lambda x: x)(k) == v

# Generated at 2022-06-21 15:38:12.367696
# Unit test for function romanize
def test_romanize():
    try:
        @romanize(locale='ru')
        def roman(cls):
            return 'Сколько бы ни я человеку поверил,' \
                   'он все равно подорвет доверие'

        assert roman('') == 'Skol\'ko by ni ya cheloveku pove-ril,' \
                            'on vsë ravno podorvet doverie'
    except ValueError as e:
        print('ValueError: ' + str(e))


# Generated at 2022-06-21 15:38:16.177224
# Unit test for function romanize
def test_romanize():
    from mimesis import Generic
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    g = Generic('ru')
    p = Person('ru')
    assert g.code.isbn()
    assert p.full_name()
    assert p.username(romanize=True)

    g = Generic(locale=Locale.RU)
    assert g.code.isbn()



# Generated at 2022-06-21 15:38:19.524245
# Unit test for function romanize
def test_romanize():
    """Test romanize()."""

    @romanize('ru')
    def return_ru_text():
        return 'строка'

    assert return_ru_text() == 'stroka'

# Generated at 2022-06-21 15:38:24.636522
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'привет мир')() == 'privet mir'
    assert romanize('kk')(lambda: 'привет мир')() == 'privet mir'

    # Plain text
    assert romanize()('привет мир') == 'privet mir'

# Generated at 2022-06-21 15:38:26.291348
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Как дела?')() == 'Kak dela?'

# Generated at 2022-06-21 15:38:28.226416
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-21 15:38:33.550976
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    @romanize('ru')
    def get_ru_name(self):
        """Get russian name."""
        return 'Влади́мир'

    @romanize('uk')
    def get_ukr_name(self):
        """Get ukr name."""
        return 'Володимир'

    assert get_ru_name() == 'Vladimir'
    assert get_ukr_name() == 'Volodimir'

# Generated at 2022-06-21 15:38:40.441001
# Unit test for function romanize
def test_romanize():
    func = lambda x: x

    @romanized()
    def func_romanized(x):
        return x

    assert func('123qwe') == func_romanized('123qwe')
    assert func('йцук') == func_romanized('йцук')
    assert func('йцук') != func('123qwe')
    assert func('йцук') != func_romanized('123qwe')

# Generated at 2022-06-21 15:38:44.917285
# Unit test for function romanize
def test_romanize():
    import mimesis

    assert mimesis.Person().name() == 'Степан'
    assert mimesis.Person(locale='ru').name() == 'Степан'

    @mimesis.romanize('ru')
    def get_name() -> str:
        return mimesis.Person().name()

    assert get_name() == 'Stepan'

# Generated at 2022-06-21 15:39:12.271855
# Unit test for function romanize
def test_romanize():
    """Test usage of romanize function."""
    assert romanize('ru')(lambda: 'Русский')() == 'Russkiĭ'

# Generated at 2022-06-21 15:39:23.429698
# Unit test for function romanize
def test_romanize():
    assert romanize()('Декоратор для романизации текста.') == 'Dekorator dlya romanizatsii teksta.'
    assert romanize('uk')('Декоратор для романизации текста.') == 'Dekorator dlya romanizatsii teksta.'
    assert romanize('ru')('Декоратор для романизации текста.') == 'Dekorator dlya romanizatsii teksta.'
    assert roman

# Generated at 2022-06-21 15:39:27.901496
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_romanized_value():
        return 'Добро пожаловать в Mimesis'
    result = get_romanized_value()
    assert result == 'Dobro pozhalovat v Mimesis'

# Generated at 2022-06-21 15:39:35.886142
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import LanguageSpecifier
    from mimesis.enums import Language

    lang = Language.EN

    cyr = LanguageSpecifier(lang, romanized=True)
    assert cyr.full_name() == 'Василий Иванович Пупкин'
    assert cyr.full_name(gender=None) == 'Василий Иванович Пупкин'
    assert cyr.full_name(gender='male') == 'Василий Иванович Пупкин'

# Generated at 2022-06-21 15:39:40.706850
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    from mimesis.enums import Gender

    rsp = RussianSpecProvider(gender=Gender.FEMALE)

    name = rsp.name()
    assert type(name) is str

    roman_name = rsp.romanized(name)
    assert type(roman_name) is str
    assert name != roman_name

# Generated at 2022-06-21 15:39:50.878758
# Unit test for function romanize
def test_romanize():
    assert 'письмо' == romanized('ru')('письмо')
    assert 'pismo' == romanized('ru')('письмо')
    assert 'chudodeystvie' == romanized('ru')('чудодействие')
    assert 'Khokhryakov' == romanized('ru')('Хохряков')
    assert 'а' == romanized('uk')('а')
    assert 'a' == romanized('uk')('а')
    assert 'А' == romanized('uk')('А')
    assert 'A' == romanized('uk')('А')
    assert 'ама' == r

# Generated at 2022-06-21 15:40:00.311784
# Unit test for function romanize

# Generated at 2022-06-21 15:40:05.413472
# Unit test for function romanize
def test_romanize():
    # Pipe by its name
    result = romanize('ru')(lambda: 'Привет, мир!')();
    assert result == 'Privet, mir!'

    # Pipe by its pointer
    @romanized('ru')
    def func():
        return 'Привет, мир!'
    result = func()
    assert result == 'Privet, mir!'

# Generated at 2022-06-21 15:40:15.664828
# Unit test for function romanize
def test_romanize():
    def func(*args, **kwargs):
        return 'Каждый охотник желает знать, где Сидит фазан'

    @romanized(locale='ru')
    def romanized_func(*args, **kwargs):
        return 'Каждый охотник желает знать, где Сидит фазан'

    # Pre-defined test set

# Generated at 2022-06-21 15:40:19.269773
# Unit test for function romanize
def test_romanize():
    test_string = 'тест'
    assert romanized(locale='ru')(lambda : test_string) == 'test'

    # locale is not supported
    # assert romanized(locale='be')(lambda : test_string) == 'test'

# Generated at 2022-06-21 15:41:27.144457
# Unit test for function romanize
def test_romanize():
    source = 'Привет мир!'
    assert romanize()(lambda: source)() == 'Privet mir!'

# Generated at 2022-06-21 15:41:34.230786
# Unit test for function romanize
def test_romanize():
    import unittest
    import string
    from mimesis.providers.text import Text

    text = Text('ru')

    class RomanizationTestCase(unittest.TestCase):
        def test_romanize(self):
            romanized_word = text.word().romanize()
            not_romanized_word = text.word()
            self.assertTrue(set(romanized_word) <= set(string.ascii_letters))
            self.assertFalse(set(not_romanized_word) <= set(string.ascii_letters))

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-21 15:41:36.745203
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Привет мир!')() == 'Privet mir!'



# Generated at 2022-06-21 15:41:39.742836
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_cyrillic(text: str) -> str:
        return text

    assert romanize_cyrillic('Привет') == 'Privet'



# Generated at 2022-06-21 15:41:41.713097
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'

# Generated at 2022-06-21 15:41:50.201827
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    text = Text()
    text.PRIMITIVE_ROMANIZATION = False

    russian = text.word(locale='ru')
    kazakh = text.word(locale='kk')
    assert isinstance(russian, str)
    assert isinstance(kazakh, str)
    assert russian.isalpha() is True
    assert kazakh.isalpha() is True

    assert text.romanized(locale='ru') == text.romanize(locale='ru')
    assert text.romanized(locale='kk') == text.romanize(locale='kk')

    text.PRIMITIVE_ROMANIZATION = True
    assert text.romanized(locale='ru') == text.romanize(locale='ru')
    assert text

# Generated at 2022-06-21 15:41:55.882141
# Unit test for function romanize
def test_romanize():
    def romanize_this(text):
        return text

    @romanize('ru')
    def romanize_this(text):
        return text

    @romanize('uk')
    def romanize_this(text):
        return text

    @romanize('kk')
    def romanize_this(text):
        return text

    assert romanize_this('Тест') == 'Test'
    assert romanize_this('Тест Тест') == 'Test Test'
    assert romanize_this('Тест-This-Тест') == 'Test-This-Test'
    assert romanize_this('Зборище') == 'Zborishe'

# Generated at 2022-06-21 15:41:57.258727
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda x: 'привет')() == 'privet'

# Generated at 2022-06-21 15:41:59.927104
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    t = Text('en')

    assert t._romanize_all('Привет, мир!', 'ru') == 'Privet, mir!'

# Generated at 2022-06-21 15:42:09.135399
# Unit test for function romanize
def test_romanize():
    import random
    from mimesis.enums import Gender
    from mimesis.providers.address import Address

    test_cases = [
        (
            'Абырвалг',
            'Abirvalg',
        ),
        (
            'Это просто кусок текста, не переведенный на латиницу',
            'Eto prosto kusok teksta, ne perevedennyi na latinitsu',
        ),
    ]

    for t in test_cases:
        assert romanized()(t[0]) == t[1]

    random_address = Address('ru')

# Generated at 2022-06-21 15:44:06.814849
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    romanize('uk')

# Generated at 2022-06-21 15:44:09.430193
# Unit test for function romanize
def test_romanize():
    """Unit tests for function romanize."""
    r = romanize('ru')(lambda: 'яблоко')
    assert r == 'yabloko'



# Generated at 2022-06-21 15:44:10.707564
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Это')() == 'Eto'

# Generated at 2022-06-21 15:44:15.597537
# Unit test for function romanize
def test_romanize():
    """Test for function romanize()."""
    from mimesis import Generic

    g = Generic('ru')

    g_romanize = g.romanize

    assert g_romanize == romanize()(g.__class__.romanize)

    from mimesis.builtins import Person

    p_romanize = Person('ru').romanize

    assert p_romanize == romanize()(Person('ru').__class__.romanize)

# Generated at 2022-06-21 15:44:18.190560
# Unit test for function romanize
def test_romanize():
    def sample_function():
        return "ЍЍЍЍ"

    romanized_function = romanize(locale="ru")(sample_function)
    assert romanized_function() == "IIII"

# Generated at 2022-06-21 15:44:18.660516
# Unit test for function romanize
def test_romanize():
    return romanize()

# Generated at 2022-06-21 15:44:19.318705
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 15:44:23.950990
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')(lambda: 'Басты бет')() == 'Basty bet'
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanized('uk')(lambda: 'Система')() == 'Sistema'

# Generated at 2022-06-21 15:44:26.764458
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    rsp = RussianSpecProvider()
    result = rsp.romanize()
    assert result == rsp.word()

# Generated at 2022-06-21 15:44:36.649492
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize('kz')
    def romanizer_kaz(n: int = 5) -> str:
        return 'Казакша'*n

    @romanize('ru')
    def romanizer_rus(n: int = 5) -> str:
        return 'Русский'*n

    @romanize('uk')
    def romanizer_ukr(n: int = 5) -> str:
        return 'Українська'*n

    assert romanizer_kaz(3) == 'QazaqşaQazaqşaQazaqşa'
    assert romanizer_rus(3) == 'RusskiiRusskiiRusskii'
    assert r