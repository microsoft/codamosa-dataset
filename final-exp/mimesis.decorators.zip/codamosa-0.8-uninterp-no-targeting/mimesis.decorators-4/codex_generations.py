

# Generated at 2022-06-21 15:35:09.063203
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'Здрасте')() in ['Zdraste', 'Zdrastе', 'Zdrastё']
    assert romanized('ru')(lambda : 'Великолепно')() in ['Velikolepno', 'Vеlikolеpnо']
    assert romanized('ru')(lambda : 'Приветствую')() in ['Privetstvuju', 'Prіvеtstvuju']

# Generated at 2022-06-21 15:35:12.342035
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Привет. Как дела?'
    assert foo() == 'Privet. Kak dela?'

# Generated at 2022-06-21 15:35:14.550492
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Мама мыла раму')() == 'Mama myla ramu'

# Generated at 2022-06-21 15:35:23.262800
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_word(pattern='?????'):
        return pattern

    @romanize(locale='uk')
    def ukr_word(pattern='?????'):
        return pattern

    @romanize(locale='kk')
    def kaz_word(pattern='?????'):
        return pattern

    @romanize(locale='foo')
    def banned_locale(pattern='?????'):
        return pattern


# Generated at 2022-06-21 15:35:32.161428
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    def test():
        return 'ёъыэжюсячшцющ'
    assert test.__name__ == 'test'
    assert test() == 'ёъыэжюсячшцющ'
    assert romanize('ru')(test)() == 'yoʺyeezuzsʹzʹzhʹcʹyuʹshh'

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:35:36.485614
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    ru_gen = RussiaSpecProvider()
    ru_word = ru_gen.word()
    ru_word_romanized = ru_gen.word(romanize=True)

    assert ru_word in ru_word_romanized
    assert ru_word_romanized != ru_word

# Generated at 2022-06-21 15:35:39.784456
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_romanized_custom_name(seed: int = None) -> str:
        return 'Абдулла Бин Салам Аттар'

    result = get_romanized_custom_name()
    assert result == 'Abdulla Bin Salam Atar'

# Generated at 2022-06-21 15:35:41.524431
# Unit test for function romanize
def test_romanize():
    assert(romanize()==romanized)
    assert(romanize('ru') != romanize('uk'))

# Generated at 2022-06-21 15:35:48.916905
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    from mimesis.providers import Address
    from mimesis.data import ROMANIZATION_DICT

    # romanize
    result = romanize(locale='ru')(Address('ru').country)
    assert isinstance(result, str)
    result = romanize(locale='uk')(Address('uk').country)
    assert isinstance(result, str)
    result = romanize(locale='kk')(Address('kk').country)
    assert isinstance(result, str)
    result = romanize(locale='ru')(Person('ru').username)
    assert isinstance(result, str)
    result = romanize(locale='uk')(Person('uk').username)
    assert isinstance(result, str)
    result = roman

# Generated at 2022-06-21 15:35:50.485960
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'гавно')() == 'gavno'

# Generated at 2022-06-21 15:36:00.722699
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def r(text):
        return text

    assert r('Привет, test text: , 51 юникод символ. ') == \
           'Privet, test text: , 51 unicod simvol. '

# Generated at 2022-06-21 15:36:04.254467
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет!')() == 'Privet!'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:36:06.170492
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda : 'привет')() == 'privet'

# Generated at 2022-06-21 15:36:10.600987
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_text():
        return 'Это тестовая строка, арифметическая операция 2 + 2.'

    assert test_text() == (
        'Eto testovaya stroka, arifmeticheskaya operaciya 2 + 2.'
    )

# Generated at 2022-06-21 15:36:16.956557
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda: 'сәлем')() == 'salem'
    assert romanize('kk')(lambda: 'привет')() == 'privet'

# Generated at 2022-06-21 15:36:18.826617
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'Привет')() == 'Privyet'

# Generated at 2022-06-21 15:36:24.899997
# Unit test for function romanize
def test_romanize():
    import random
    from mimesis.providers.internet import Internet
    from mimesis.enums import Languages

    i = Internet()

    # Generate a random locale
    locale = random.choice(Languages.get_available_locales())

    @romanize(locale)
    def get_random_email():
        return i.email()

    assert isinstance(get_random_email(), str)

    # Generate an email with the default locale
    assert isinstance(i.email(), str)

# Generated at 2022-06-21 15:36:28.809796
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def f():
        return 'Тестирование'

    assert f() == 'Testirovanie'



# Generated at 2022-06-21 15:36:31.826010
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def function(string):
        return string

    string = function('строка')
    assert string == 'stroka'

# Generated at 2022-06-21 15:36:34.894728
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo():
        return "Привет"

    expected = 'Privet'
    assert foo() == expected



# Generated at 2022-06-21 15:36:51.333955
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    t = ''
    for locale in data.LANGUAGES:
        d = data.Data(locale)
        t = d.create_string(alphabet=d.alphabet)
        assert t == romanize(locale)(d.create_string)(alphabet=d.alphabet)

# Generated at 2022-06-21 15:36:54.995264
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import SpecialChar
    from mimesis.builtins.text import Text
    text = Text('en')
    text.add_special_chars(SpecialChar.EMOJI)
    romanized_text = text.romanize()
    assert romanized_text != text.emoji()
    assert text.emoji() in romanized_text

# Generated at 2022-06-21 15:36:57.063158
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Михаил')() == 'Mikhail'

# Generated at 2022-06-21 15:37:08.164250
# Unit test for function romanize
def test_romanize():
    """Test function romanize with multiple arguments."""
    from mimesis import Person

    d = Person('ru')
    assert 'русский' in d.full_name()
    assert 'белый' in d.color()
    assert 'терракотовый' in d.color()
    assert 'красный' in d.color()
    assert 'белый' in d.color()
    assert 'русский' in d.color()
    assert 'белый' in d.color()
    assert 'терракотовый' in d.color()
    assert 'красный' in d.color()

# Generated at 2022-06-21 15:37:13.202779
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    p = Person('ru')
    assert p.full_name() == p.full_name.romanize()

    p = Person('uk')
    assert p.full_name() == p.full_name.romanize()

    p = Person('kk')
    assert p.full_name() == p.full_name.romanize()

# Generated at 2022-06-21 15:37:19.856202
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    class RPerson(Person):
        @property
        @romanized()
        def full_name(self):
            return self.full_name()

    assert RPerson().full_name
    assert RPerson(gender=Gender.FEMALE).full_name
    assert RPerson(gender=Gender.MALE).full_name
    assert RPerson(gender=Gender.UNKNOWN).full_name

# Generated at 2022-06-21 15:37:22.151487
# Unit test for function romanize
def test_romanize():
    @romanized(locale='ru')
    def some_func():
        return 'Привет мир!'

    assert some_func() == 'Privet mir!'

# Generated at 2022-06-21 15:37:28.519302
# Unit test for function romanize
def test_romanize():  # pragma: no cover
    """Test for function romanize."""
    @romanize(locale='ru')
    def romanize_ru():
        return 'Привет, Мир!'

    assert romanize_ru() == 'Privet, Mir!'

    @romanized(locale='ru')
    def romanized_ru():
        return 'Привет, Мир!'

    assert romanized_ru() == 'Privet, Mir!'

# Generated at 2022-06-21 15:37:30.029640
# Unit test for function romanize
def test_romanize():
    # todo: implement unit test for romanize
    pass

# Generated at 2022-06-21 15:37:35.453365
# Unit test for function romanize
def test_romanize():
    @romanized('uk')
    def func():
        return 'Методичні вказівки для бойовиків'
    result = func()
    assert result == 'Metodychni vkazivky dlia boiovykiv'
    return result

# Generated at 2022-06-21 15:38:00.707756
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text
    
    text = mimesis.builtins.text.Text(locale='ru')
    romanized_cyrillic = text.romanized_cyrillic()
    assert romanized_cyrillic == text.romanize(text.cyrillic())


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:38:09.795888
# Unit test for function romanize
def test_romanize():
    import unittest

    class RomanizeTestCase(unittest.TestCase):

        def setUp(self):
            self.text = 'Член комиссии экспертизы Калинин'

        def test_as_function(self):
            from mimesis.overrides import romanize

            self.assertEqual(
                'Chlen komissii ekspertizy Kalinin',
                romanize(self.text, locale='ru'),
            )

        def test_as_decorator(self):
            from mimesis.overrides import romanized

            @romanized(locale='ru')
            def test(self):
                return self.text


# Generated at 2022-06-21 15:38:11.650662
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')
    assert romanize('unknown')

# Generated at 2022-06-21 15:38:15.878662
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Привет мир')() == 'Privet mir'
    assert romanize('uk')(lambda : 'Привіт світ')() == 'Pryvit svit'
    assert romanize('kk')(lambda : 'Сәлем Әлем')() == 'Sälem Äleм'

# Generated at 2022-06-21 15:38:19.822937
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_text(text: str = '') -> str:
        return text

    result = romanize_text('До свидания!')
    assert result == 'Do svidaniya!'

# Generated at 2022-06-21 15:38:24.636609
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda:  'Привет!')() == 'Privet!'
    assert romanize(locale='ru')(lambda: 'Спасибо, Дима!')() == 'Spasibo, Dima!'


# Generated at 2022-06-21 15:38:26.943861
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test_romanize_function(text):
        return text
    x = test_romanize_function('й')
    assert x == 'i'

# Generated at 2022-06-21 15:38:29.392582
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Здравствуйте')() == 'Zdravstvuyte'



# Generated at 2022-06-21 15:38:33.333557
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Привет, мир!'), "Hello, world!"
    assert romanize('uk')('Привіт, світ!'), "Pryvit, svit!"
    assert romanize('kk')('Сәлем, дүние!'), "Salem, dunie!"

# Generated at 2022-06-21 15:38:37.704032
# Unit test for function romanize
def test_romanize():
    class Test:
        locale = 'ru'

        @romanize(locale)
        def method(self):
            return 'Вы усё знаете?'

    assert Test().method() == 'Vy usjo znaete?'

# Generated at 2022-06-21 15:39:26.837406
# Unit test for function romanize
def test_romanize():
    @romanize()
    def text():
        return 'Привет мир!'

    assert text() == 'Privet mir!'

# Generated at 2022-06-21 15:39:28.500632
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Ю')() == 'Yu'



# Generated at 2022-06-21 15:39:36.346914
# Unit test for function romanize
def test_romanize():
    def foo(value: str = '') -> str:
        return value

    foo_r = romanize(locale='ru')(foo)
    assert foo_r('Кордоны') == 'Kordony'
    assert foo_r('Россия') == 'Rossiya'
    foo_u = romanize(locale='uk')(foo)
    assert foo_u('Станиця') == 'Stanitsya'
    assert foo_u('Гора') == 'Gora'
    foo_k = romanize(locale='kk')(foo)
    assert foo_k('Республика') == 'Respublika'

# Generated at 2022-06-21 15:39:46.289756
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""

# Generated at 2022-06-21 15:39:55.733221
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanized(locale='ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanized(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanized(locale='uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanized(locale='')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-21 15:39:58.932609
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    romanized_text = romanize(locale='ru')(lambda: 'Привет, Мир!')

    assert romanized_text == 'Privet, Mir!'

# Generated at 2022-06-21 15:40:00.241754
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Сидоров')() == 'Sidorov'

# Generated at 2022-06-21 15:40:07.689322
# Unit test for function romanize
def test_romanize():
    original = 'Привет, как дела?'
    romanized = 'Privet, kak dela?'

    @romanized('ru')
    def _test_romanize_ru():
        return original

    assert _test_romanize_ru() == romanized

    @romanized('uk')
    def _test_romanize_uk():
        return original

    assert _test_romanize_uk() == romanized

    @romanized('kk')
    def _test_romanize_kk():
        return original

    assert _test_romanize_kk() == romanized

# Generated at 2022-06-21 15:40:09.000766
# Unit test for function romanize
def test_romanize():
    assert romanize.__name__ == 'romanize'

# Generated at 2022-06-21 15:40:18.440745
# Unit test for function romanize
def test_romanize():
    test_list = ['привет', 'привет123', '¡¿el-chapuza?']
    locale = 'ru'

    @romanize(locale)
    def get_text(*args, **kwargs):
        return test_list[0]

    assert get_text() == 'privet'

    @romanize(locale)
    def get_text(*args, **kwargs):
        return test_list[1]

    assert get_text() == 'privet123'

    @romanize(locale)
    def get_text(*args, **kwargs):
        return test_list[2]

    assert get_text() == '¡¿el-chapuza?'

# Generated at 2022-06-21 15:42:37.220805
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(str)().isalpha()



# Generated at 2022-06-21 15:42:45.792527
# Unit test for function romanize
def test_romanize():
    """Check function romanize."""
    class Test(object):
        """Test."""

        @romanize(locale="ru")
        def test_string(self):  # noqa: D102
            return 'Привет, Мир!'

        @romanize(locale="uk")
        def test_string_uk(self):  # noqa: D102
            return 'Я не вмію російською!'

        @romanize(locale="kk")
        def test_string_kk(self):  # noqa: D102
            return 'Сәлеметсіз бе!'

    test = Test()
    assert test.test_string() == 'privet, mir!'

# Generated at 2022-06-21 15:42:51.414169
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Всем привет!')() == 'Vsem privet!'
    assert romanize('uk')(lambda x: 'Всім привіт!')() == 'Vsim pryvit!'
    assert romanize('kk')(lambda x: 'Барлықға сәлем!')() == 'Barlıqğa sälem!'

# Generated at 2022-06-21 15:43:01.250678
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import CyrillicSpecProvider

    @romanize('ru')
    def _get_data(self, seed, *args, **kwargs):
        return 'Привет, мир!'

    value = _get_data(CyrillicSpecProvider(), None)
    assert value == 'Privet, mir!'

# Generated at 2022-06-21 15:43:09.727060
# Unit test for function romanize
def test_romanize():
    romanized = romanize('ru')
    romanized = romanized(lambda: 'Привет')

    assert romanized() == 'Privet'

    romanized = romanize('uk')
    romanized = romanized(lambda: 'Привіт')

    assert romanized() == 'Privit'

    romanized = romanize('kk')
    romanized = romanized(lambda: 'Сәлем')

    assert romanized() == 'Salem'

# Generated at 2022-06-21 15:43:15.169315
# Unit test for function romanize
def test_romanize():
    """Check romanization of Cyrillic symbols."""
    # Russian
    rus = 'Russian'
    assert romanize('ru')(rus) == 'Russian'
    assert romanized('ru')(rus) == 'Russian'

    # Ukrainian
    ukr = 'Українська'
    assert romanize('uk')(ukr) == 'Ukrajinska'
    assert romanized('uk')(ukr) == 'Ukrajinska'

    # Kazakh
    kaz = 'Қазақша'
    assert romanize('kk')(kaz) == 'Qazaqsha'
    assert romanized('kk')(kaz) == 'Qazaqsha'

# Generated at 2022-06-21 15:43:24.674945
# Unit test for function romanize
def test_romanize():
    assert ascii_letters == romanized()(ascii_letters)
    assert digits == romanized()(digits)
    assert punctuation == romanized()(punctuation)

    assert 'abc' == romanized()('abc')
    assert '123' == romanized()('123')
    assert '-_' == romanized()('-_')
    assert 'Абв' == romanized(locale='ru')('абв')
    assert 'Абв' == romanized(locale='uk')('абв')
    assert 'Абв' == romanized(locale='zz')('абв')

    assert 'abc123-_' == romanized()('abc123-_')

# Generated at 2022-06-21 15:43:27.736926
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_func():
        return 'Привет, Мир!'

    assert test_func() == 'Privet, Mir!'


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-21 15:43:31.574660
# Unit test for function romanize
def test_romanize():
    from mimesis import Personal
    p = Personal(locale='ru')
    assert p.full_name() == 'Алина Савельева'
    p = p.romanize()
    assert p.full_name() == 'Alina Savelieva'



# Generated at 2022-06-21 15:43:36.567146
# Unit test for function romanize
def test_romanize():
    def dummy_func(locale, text):
        return text

    text = 'Привет, Мир!'

    res = romanize('ru')(dummy_func)
    assert res(locale='ru', text=text) == 'Privet, Mir!'