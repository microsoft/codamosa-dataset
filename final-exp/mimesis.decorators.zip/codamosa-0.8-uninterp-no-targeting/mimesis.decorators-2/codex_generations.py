

# Generated at 2022-06-21 15:34:59.719172
# Unit test for function romanize
def test_romanize():
    assert romanize is romanized

# Generated at 2022-06-21 15:35:07.639229
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    alphabet = data.ROMANIZATION_DICT['ru']

    @romanize('ru')
    def romanize_text(text):
        return text

    assert romanize_text('тест') == 'test'

    # We should keep the common letters
    assert romanize_text('самолет') == 'samolety'

    # Non-cyrillic symbols remain untouched
    assert romanize_text('семья') == 'semya'

    # Check the common letters
    assert romanize_text('река') == 'reka'

    # Check if the common letters override romanization dict
    assert romanize_text('щ') == 'shch'

    # Check the case of empty string

# Generated at 2022-06-21 15:35:14.505650
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    r = RussianSpecProvider()  # type: ignore
    r.add_rules({'И': 'Y', 'Ш': 'Sh'})  # type: ignore

    result = r.romanize()  # type: ignore
    assert 'Y' in result
    assert 'Sh' in result
    assert 'И' not in result
    assert 'Ш' not in result

# Generated at 2022-06-21 15:35:21.106310
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир! Как дела?')() == 'Privet, mir! Kak dela?'
    assert romanize('uk')(lambda: 'Привіт, світ')() == 'Pryvit, svit'
    assert romanize('kk')(lambda: 'Қалай салайсызбы')() == 'Qalay salaysyzy'

# Generated at 2022-06-21 15:35:29.111883
# Unit test for function romanize
def test_romanize():
    assert ('Абракадабра фалыш салазан якир'
            == romanize('ru', 'Абракадабра фалыш салазан якир'))
    assert ('Абракадабра фалыш салазан якир'
            == romanize('uk', 'Абракадабра фалыш салазан якир'))

# Generated at 2022-06-21 15:35:32.813967
# Unit test for function romanize
def test_romanize():
    written = romanize('ru')(lambda x: 'русский вариант')
    assert written == 'russkiy variant'

    written = romanize('kk')(lambda x: 'қазақ тілі')
    assert written == 'qazaq tili'

    written = romanize('uk')(lambda x: 'Українська мова')
    assert written == 'Ukrajinska mova'

# Generated at 2022-06-21 15:35:33.417090
# Unit test for function romanize
def test_romanize():
    assert True

# Generated at 2022-06-21 15:35:35.113578
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Петрович')() == 'Petrovich'

# Generated at 2022-06-21 15:35:39.784439
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('en')(lambda: 'Привет, мир!')() == 'Привет, мир!'
    assert romanize('kk')(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-21 15:35:45.722995
# Unit test for function romanize
def test_romanize():
    # Русский текст -- Russian text
    assert romanize('ru')(str)('Русский текст') == 'Russkiy tekst'

    # арадан - aradan (Kazakh)
    assert romanize('kk')(str)('арадан') == 'aradan'

    # Український текст -- Ukrainian text
    assert romanize('uk')(str)('Український текст') ==\
        'Ukrayinsʹkyĭ tekst'

# Generated at 2022-06-21 15:35:53.614280
# Unit test for function romanize
def test_romanize():
    @romanize(locale="ru")
    def get_text(v):
        return 'Привет,'
    
    assert get_text("t") == 'Privet,'

# Generated at 2022-06-21 15:36:00.738146
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def ru(seed):
        return 'Я прошёл через круги ада'
    assert ru(777) == 'Yá proshól chyeréz krugí áda'

    @romanize(locale='uk')
    def uk(seed):
        return 'Я прошел через круги аду'
    assert uk(777) == 'Yá proshél chyeréz krugí ádu'


# Generated at 2022-06-21 15:36:02.459798
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-21 15:36:03.091127
# Unit test for function romanize
def test_romanize():
    assert True

# Generated at 2022-06-21 15:36:10.886625
# Unit test for function romanize
def test_romanize():
    assert romanized()('привет. Мир!') == "privet. Mir!"
    assert romanized()('Лорем ипсум долор') == "Lorem ipsum dolor"
    assert romanized()('Сакала гарантирует покупателям соблюдение требований') == \
        "Sakala garantiruet pokupatelyam sobliudienie trebovanij"

# Generated at 2022-06-21 15:36:18.920894
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda x: 'привет, это тест')() == 'privet, jeto test'
    assert romanize(locale='uk')(lambda x: 'привіт, це тест')() == 'pryivit, ce test'
    assert romanize(locale='kk')(lambda x: 'сәлем, осы текст')() == 'salem, osy tekst'

# Generated at 2022-06-21 15:36:20.777260
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')().startswith('Privet')

# Generated at 2022-06-21 15:36:31.204951
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.providers.text import Text

    text = Text(seed=27)

    rus_text = text.cyrillic_text(10)
    rus_romanized_text = text.romanized_text(10, locale='ru')

    ukr_text = text.cyrillic_text(10, locale='uk')
    ukr_romanized_text = text.romanized_text(10, locale='uk')

    kk_text = text.cyrillic_text(10, locale='kk')
    kk_romanized_text = text.romanized_text(10, locale='kk')

    with pytest.raises(UnsupportedLocale):
        text.romanized_text(10, locale='unknown_locale')

    assert rus_text != rus_roman

# Generated at 2022-06-21 15:36:35.869652
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test_romanize_deco(locale):
        print(locale)

    try:
        test_romanize_deco('ru')
    except Exception:
        raise AttributeError('Exception must not be thrown')

# Generated at 2022-06-21 15:36:41.079735
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.builtins.ukrainian import UkrainianSpecProvider

    usp = UkrainianSpecProvider()

    assert isinstance(usp._data['name'], dict)
    assert isinstance(usp.name(gender=Gender.FEMALE), str)
    assert isinstance(usp.romanize(usp.name(gender=Gender.FEMALE)), str)

# Generated at 2022-06-21 15:36:57.617648
# Unit test for function romanize
def test_romanize():
    # Latin
    assert romanize('ru')(lambda: 'Transliteration')() == 'Transliteration'
    # Cyrillic
    assert romanize('ru')(lambda: 'Транслитерация')() == 'Transliteraciya'

# Generated at 2022-06-21 15:37:03.816268
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def _get_numbers_of_pi():
        return 'Привет мир'

    assert _get_numbers_of_pi() == 'Privet mir'

    @romanize('ru')
    def _get_numbers_of_pi():
        return 'Привет мир!'

    assert _get_numbers_of_pi() == 'Privet mir!'

# Generated at 2022-06-21 15:37:16.091114
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""

    @romanize(locale='uk')
    def uk_romanize(s: str) -> str:
        return s

    assert uk_romanize('Хто такий Пітер Джексон?') == 'Khto takyĭ Piter Dzhekson?'

    @romanize(locale='kk')
    def kk_romanize(s: str) -> str:
        return s

    assert kk_romanize('Бұл күнделікті дүние') == 'Bul kündelikti dünie'


# Generated at 2022-06-21 15:37:19.496968
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Address
    from mimesis.enums import Gender

    a = Address('ru')
    assert a.full_name(gender=Gender.MALE) == 'Иванов Иван Иванович'

# Generated at 2022-06-21 15:37:22.078289
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanized('ru')(lambda : 'Привет!')() == 'Privet!'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:37:26.501183
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')(lambda: 'салық')() == 'salıq'
    assert romanize('uk')(lambda: 'салық')() == 'salık'
    assert romanize('ru')(lambda: 'салық')() == 'salik'

# Generated at 2022-06-21 15:37:29.577116
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    test_func = romanize(locale=Language.RUSSIAN)
    assert test_func() == 'Иванов'

# Generated at 2022-06-21 15:37:40.362965
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanized('ru')(lambda: 'Я меняю порядок букв')() == \
        'Ya menyayu poryadok bukv'
    assert romanized('ru')(lambda: 'Я меняю порядок букв') != \
        romanized('uk')(lambda: 'Я меняю порядок букв')()
    assert romanized('uk')(lambda: 'Я меняю порядок букв')() == \
        'Ya minyayu poryadok bukv'
    assert r

# Generated at 2022-06-21 15:37:49.083045
# Unit test for function romanize
def test_romanize():
    """Test romanization."""
    import transliterate
    import mimesis.builtins.text

    txt = 'Мяу-мяу'
    transl = transliterate.translit(txt, 'ru')
    assert transl == 'Myau-myau'

    generator = mimesis.builtins.Text()
    result = generator._romanize(txt)
    assert result == 'Myau-myau'

    transl = transliterate.translit(txt, 'uk')
    assert transl == 'Myau-myau'

    generator = mimesis.builtins.Text(locale='uk')
    result = generator._romanize(txt)
    assert result == 'Myau-myau'


# Generated at 2022-06-21 15:38:00.592777
# Unit test for function romanize
def test_romanize():
    from mimesis.enumerations import Language
    from mimesis.enumerations import Locales
    from mimesis.providers.address import Address

    @romanized(locale=Locales.RU)  # noqa
    def foo():
        return 'Я не такой, как все.'

    assert foo() == 'Ya ne takoy, kak vse.'

    @romanized(locale=Locales.UK)
    def bar():
        return 'Я не такий, як інші.'

    assert bar() == 'Ya ne takyy, yak inshi.'


# Generated at 2022-06-21 15:38:31.206108
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize(locale='uk')(lambda: 'Привіт, Мир!')() == 'Pryvit, Myr!'
    assert romanize(locale='kk')(lambda: 'Сәлем, дүние!')() == 'Sälém, dünïe!'

# Generated at 2022-06-21 15:38:41.320733
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'test') == 'test'

    @romanize('ru')
    def func():
        yield 'Главный газеты'
        yield 'продавец'
        yield 'канцелярии'
        yield 'подсказала,'
        yield 'как'
        yield 'быстро'
        yield 'открыть'
        yield 'бизнес'

    romanized_text = func()

# Generated at 2022-06-21 15:38:43.894861
# Unit test for function romanize
def test_romanize():
    import string
    import random

    alphabet = string.ascii_letters + string.digits + ' '

    for k in data.ROMANIZATION_DICT:
        for i in range(10):
            result = ''.join(random.choices(alphabet, k=10))
            expected = ''.join(random.choices(alphabet, k=10))
            assert romanized(locale=k)(lambda: result)() == expected

# Generated at 2022-06-21 15:38:47.735696
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Мимими')() == 'Mimimi'
    assert romanize('ru')(lambda: 'Мимими')() == 'Mimimi'
    assert romanized('ru')(lambda: 'Мимими')() == 'Mimimi'



# Generated at 2022-06-21 15:38:48.664849
# Unit test for function romanize
def test_romanize():
    romanize('ru')(print(1))

# Generated at 2022-06-21 15:38:56.857298
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedLocale

    p = Person('ru')
    p.seed(1)

    assert p.full_name(gender=Gender.FEMALE) == 'Анна Сергеевна Куликова'
    assert p.full_name(gender=Gender.MALE) == 'Антон Николаевич Александров'

    assert p.full_name(gender=Gender.FEMALE, romanize=True) == 'Anna Sergeevna Kulikova'  # noqa: E501

# Generated at 2022-06-21 15:39:06.821268
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person1 = Person('ru')
    assert person1.name(gender=Gender.FEMALE) == 'Любовь'
    assert person1.name(gender=Gender.MALE) == 'Александр'
    assert person1.surname() == 'Иванов'

    person2 = Person('ru', romanize=True)
    assert person2.name(gender=Gender.FEMALE) == 'Lyubov'
    assert person2.name(gender=Gender.MALE) == 'Aleksandr'
    assert person2.surname() == 'Ivanov'

# Generated at 2022-06-21 15:39:08.778549
# Unit test for function romanize
def test_romanize():
    assert romanize()  # noqa: F821; pylint: disable=E0602



# Generated at 2022-06-21 15:39:16.033082
# Unit test for function romanize
def test_romanize():
    # code of language, test result
    # en - hello
    # ru - привет
    # uk - здравствуйте
    # kk - сәлем қоштарғыңыздар
    test_results = {'en': 'hello', 'ru': 'privet', 'uk': 'zdravstvuyte',
                    'kk': 'salem koshtarghynyzdar'}

    for lang, expected in test_results.items():
        assert romanize(lang)(lambda: "hello") == expected, \
            'Failed test for {}'.format(lang)

# Generated at 2022-06-21 15:39:23.048129
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Иванов')() == 'Ivanov'
    assert romanized(locale='uk')(lambda: 'Іванов')() == 'Ivanoў'
    assert romanized(locale='kk')(lambda: 'Иванов')() == 'IVANOV'
    assert romanized(locale='ru')(lambda: 'Иванов,1')() == 'Ivanov,1'

# Generated at 2022-06-21 15:40:11.012724
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('kk')(lambda: 'Қазақ')() == 'Qazaq'
    assert romanized('uk')(lambda: 'Україна')() == 'Ukrayina'

# Generated at 2022-06-21 15:40:14.886567
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanized_text():
        return "Привет, как твои дела?"

    assert romanized_text() == 'Privyet, kak tvoi dela?'

# Generated at 2022-06-21 15:40:16.861935
# Unit test for function romanize
def test_romanize():
    @romanize
    def test_func():
        return 'Привет'
    assert test_func() == 'Privet'

# Generated at 2022-06-21 15:40:21.736247
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda : 'тест')() == "test"
    assert romanize()(lambda : 'тест')() == "test"
    assert romanized()(lambda : 'test')() == "test"
    assert romanize('uk')(lambda : 'тест')() == "test"
    assert romanize('uk')(lambda : 'тест')() == "test"
    assert romanized('uk')(lambda : 'тест')() == "test"

# Generated at 2022-06-21 15:40:24.229580
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'слово')() == 'slovo'

# Generated at 2022-06-21 15:40:28.217096
# Unit test for function romanize
def test_romanize():
    def russian():
        return 'Привет мир!'

    assert romanize()(russian) == 'Privet mir!'

# Generated at 2022-06-21 15:40:31.229085
# Unit test for function romanize
def test_romanize():
    result = ''.join([loc for loc in romanized()(['й', 'ц', 'у',
                                                 'к', 'е', 'н', 'г',
                                                 'ш', 'щ', 'з',
                                                 'х', 'ъ'])])
    assert result == 'ictukehngszh'

# Generated at 2022-06-21 15:40:41.591485
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Seed
    from mimesis.enums import Locale

    locale = Locale.RU
    seed = Seed.create_seed(1234567890)
    generator = Seed(seed=seed)

    # Проверка на исключения
    try:
        generator.text.romanize('ru')
    except UnsupportedLocale:
        assert True
    else:
        assert False

    # Декоратор
    @romanize()
    def romanized_uk():
        return generator.text.word(locale=Locale.UK)

    text = romanized_uk()
    assert text == 'zhak'

    # Декоратор 2
   

# Generated at 2022-06-21 15:40:52.717692
# Unit test for function romanize
def test_romanize():
    # TODO: add many more tests
    assert romanize('ru')(lambda: 'Двигатель')() == 'Dvigatel'
    assert romanize('ru')(lambda: 'Светофор')() == 'Svetofor'
    assert romanize('ru')(lambda: 'Автомобиль')() == 'Avtomobil'
    assert romanize('ru')(lambda: 'Дверь')() == 'Dver'
    assert romanize('uk')(lambda: 'Львів')() == 'Lviv'
    assert romanize('uk')(lambda: 'Київ')() == 'Kyiv'

# Generated at 2022-06-21 15:40:54.441546
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Привет мир')() == 'Privet mir'

# Generated at 2022-06-21 15:43:18.811988
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda _: "Привет всем!")() == "Privet vsem!"

# Generated at 2022-06-21 15:43:27.412027
# Unit test for function romanize
def test_romanize():
    txt = 'абвгдежзийклмновпрстуфхцчшщъыьэюяАБВГДЕЖЗИЙКЛМНОВПРСТУФХЦЧШЩЪЫЬЭЮЯ'
    expected_txt = 'abvgdeezjkilmnovpstufhcchshshschyyeuyaABVGDEEZJKILMNOVPSTUFHCCHSHSCHYEYEUYA'
    assert romanize('ru')(lambda: txt)() == expected_txt


# Generated at 2022-06-21 15:43:31.321715
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    p = Person(Locale.UKRAINIAN)
    assert p.full_name(romanize=True) == romanized(p.full_name)(p.full_name)

# Generated at 2022-06-21 15:43:36.661115
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Transliteration
    from mimesis.enums import Locales
    cyr = Transliteration(Locales.EN)
    assert cyr.romanize() == ''
    assert cyr.romanize(locale='ru') == ''
    assert cyr.romanize(locale='uk') == ''

# Generated at 2022-06-21 15:43:53.365895
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Language
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    # String to romanize:
    # строка "Казакевич Олег Романович"

    person = Person('ru')
    # Creating a string for romanization
    s = ' '.join([person.name(Gender.MALE),
                  person.last_name(Gender.MALE),
                  person.patronymic(Gender.MALE)])
    # Romanizing string 's'
    assert s == 'Олег Казакевич Романович'

# Generated at 2022-06-21 15:43:55.243113
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет мир')() == 'Privet mir'

# Generated at 2022-06-21 15:44:01.446620
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.personal import Personal
    test_locale = 'ru'
    p = Personal(test_locale)
    test_name = p.full_name()
    assert isinstance(test_name, str)
    test_romanize = romanize(test_locale)(lambda: test_name)()
    assert isinstance(test_romanize, str)

# Generated at 2022-06-21 15:44:04.264796
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, Мельбурн') == 'Privet, Mel\'burn'

# Generated at 2022-06-21 15:44:11.025029
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Абракадабра')() == 'Abrakadabra'
    assert romanized('ru')(lambda: 'Боже мой')() == 'Bozhe moj'
    assert romanized('uk')(lambda: 'Боже мій')() == 'Bozhe miy'
    assert romanized('kk')(lambda: 'Боже мой')() == 'Bozhe moj'

# Generated at 2022-06-21 15:44:12.574714
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет!')() == 'Privet!'