

# Generated at 2022-06-21 15:35:02.544362
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def get_russian_text():
        return 'Привет, даун!'

    print(get_russian_text())



# Generated at 2022-06-21 15:35:05.793652
# Unit test for function romanize
def test_romanize():
    def func(locale: str = '') -> str:
        return 'Hello, The World!'

    result = romanize(locale='ru')(func)()
    assert result == 'Hello, The World!'

    # It will not change the function results
    assert func == result



# Generated at 2022-06-21 15:35:09.508501
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def some_string():
        return "Привет, I'm a string"

    assert some_string() == "Privet, I'm a string"

# Generated at 2022-06-21 15:35:19.704605
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import SpecialChar
    from mimesis.enums import CharCategories
    from mimesis.providers.address import Address

    a = Address(locale='ru')

    # Transliterate cyrillic chars
    b = a.street_name()
    assert (b in data.ROMANIZATION_DICT['ru'].values())

    # Letter mappings
    b = a.street_name(special_chars=SpecialChar.CYRILLIC)
    r = a.street_name(special_chars=SpecialChar.CYRILLIC,
                      romanize=True)
    assert (b != data.ROMANIZATION_DICT['ru'])
    assert (b != r)

    # Punctuation
    b = a.postcode()
    r = a

# Generated at 2022-06-21 15:35:22.704483
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    person = Person('ru')

    @romanize('ru')
    def foo() -> str:
        return person.full_name()

    result = foo()

    assert result is not None

# Generated at 2022-06-21 15:35:26.643429
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    @romanize('ru')
    def foo():
        return 'Слухай, що я приголомшу'

    assert foo() == 'Sluchaj, shcho ja prigolomshu'

# Generated at 2022-06-21 15:35:35.113093
# Unit test for function romanize
def test_romanize():
    """Test class Romanization."""
    assert romanize('uk')(lambda: 'Пингвін')() == 'Pivgvin'
    assert romanize('ru')(lambda: 'Пингвин')() == 'Pingvin'
    assert romanize('ru')(lambda: 'Пингвин')() == 'Pingvin'
    assert romanize('kk')(lambda: 'Пингвин')() == 'Pingviñ'

# Generated at 2022-06-21 15:35:40.804640
# Unit test for function romanize
def test_romanize():
    mimesis = data.Mimesis()
    assert mimesis.romanize('Привет мир!') == 'Privet mir!'
    assert mimesis.romanize('я тебя люблю') == 'ya tebya lyublyu'
    assert mimesis.romanize('мама мыла раму') == 'mama myla ramu'
    assert mimesis.romanize('привет мир') == 'privet mir'



# Generated at 2022-06-21 15:35:48.534986
# Unit test for function romanize
def test_romanize():
    assert romanize()('Съешь ещё этих мягких французских булок да выпей') == 'Syesh eshchyo etikh myagkikh frantsuzskikh bulok da vypey'
    assert romanize()('Съешь ещё этих мягких французских булок да выпей') != 'Syesh eshchyo etikh myagkikh frantsuzskikh bulok da vypey '

# Generated at 2022-06-21 15:35:51.489597
# Unit test for function romanize
def test_romanize():
    from mimesis import Generic

    gen = Generic('ru')

    # Checking the function `romanize`.
    # It should convert cyrillic characters to latin.
    assert gen.text.romanized() != gen.text()

# Generated at 2022-06-21 15:36:07.446194
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Localization

    @romanize(locale=Localization.RU)
    def ru_str():
        return 'Найти'

    assert ru_str() == 'Najti'

    @romanize(locale=Localization.UK)
    def uk_str():
        return 'Знайти'

    assert uk_str() == 'Znajty'

    @romanize(locale=Localization.KK)
    def kk_str():
        return 'Издеу'

    assert kk_str() == 'İzdew'

# Generated at 2022-06-21 15:36:09.251052
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет'.upper())() == 'Privet'.upper()



# Generated at 2022-06-21 15:36:17.006931
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import Person

    p = Person(Language.RUSSIAN)
    romanized = p.romanized()
    assert isinstance(romanized, str)

    p = Person(Language.UKRAINIAN)
    romanized = p.romanized()
    assert isinstance(romanized, str)

    p = Person(Language.KAZAKH)
    romanized = p.romanized()
    assert isinstance(romanized, str)

# Generated at 2022-06-21 15:36:20.115260
# Unit test for function romanize
def test_romanize():
    def roman():
        return 'Привет, мир!'

    test = romanize()(roman)
    assert test() == 'Privet, mir!'


test_romanize()

# Generated at 2022-06-21 15:36:30.235523
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_test(test: str) -> str:
        return test

    r = rus_test('Привет')
    assert r == 'Privet'

    @romanize(locale='uk')
    def ukr_test():
        return 'Привіт'

    r = ukr_test()
    assert r == 'Pryvit'

    # Unit test for class Romanizer
    from mimesis.enums import Locale
    from mimesis.builtins import Romanizer

    ru = Romanizer(locale=Locale.RUSSIAN)
    assert ru.cyrillic_to_latin('Привет') == 'Privet'


# Generated at 2022-06-21 15:36:37.600463
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Привет')() == 'Privet'
    assert romanize('uk')(lambda : 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda : 'Сәлем')() == 'Sälem'

    # Check that unsupported locale is failed
    assert romanize('fr')(lambda : 'Bonjour')() == 'Bonjour'

# Generated at 2022-06-21 15:36:39.322904
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-21 15:36:44.229626
# Unit test for function romanize
def test_romanize():
    # Source: https://github.com/lk-geimfari/mimesis/issues/153
    from mimesis.providers import Person

    p = Person('ru')
    gender = {0: 'male', 1: 'female'}

    for i in range(0, 2):
        name = p.full_name(gender=gender[i])
        print(name)


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:36:48.301803
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_text():
        return 'Превед, медвед'

    assert romanize_text() == 'Pryevod, myevyd'

# Generated at 2022-06-21 15:36:52.097326
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_test(test):
        return test

    assert test_test('Привет Маша!') == 'Privet Masha!'

# Generated at 2022-06-21 15:36:59.772122
# Unit test for function romanize
def test_romanize():
    assert romanize('en')
    assert romanize('ru')
    assert romanized('en')
    assert romanized('ru')

# Generated at 2022-06-21 15:37:01.473720
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod(extraglobs={'r': romanize()})

# Generated at 2022-06-21 15:37:11.149887
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.localization import Localization

    person = Person(locale='uk')
    localization = Localization(locale='uk')

    txt = person.full_name(gender=Gender.MALE)
    test_txt = localization.romanization(txt)
    assert romanize('uk')(lambda: txt)() == test_txt

    txt = person.full_name(gender=Gender.FEMALE)
    test_txt = localization.romanization(txt)
    assert romanize('uk')(lambda: txt)() == test_txt

# Generated at 2022-06-21 15:37:17.787009
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import Person

    romanized_text = romanize()(
        lambda: Person(Language.UKRAINIAN).surname(gender=None),
    )()

    assert romanized_text == romanized(
        'ru',
        lambda: Person(Language.RUSSIAN).surname(gender=None),
    )()

# Generated at 2022-06-21 15:37:18.741797
# Unit test for function romanize
def test_romanize():
    """Test romanization."""
    assert callable(romanize)

# Generated at 2022-06-21 15:37:20.985627
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus():
        return 'Грузия'

    assert rus() == 'Gruziya'

# Generated at 2022-06-21 15:37:27.526194
# Unit test for function romanize
def test_romanize():
    def Test(locale, inp, expected):
        @romanize(locale)
        def romanize(inp):
            return inp

        result = romanize(inp)
        assert result == expected

    Test('ru', 'Боже мой!', 'Bože moj!')
    Test('uk', 'Боже мой!', 'Bože moj!')
    Test('kk', 'Боже мой!', 'Bože moj!')

# Generated at 2022-06-21 15:37:38.265995
# Unit test for function romanize
def test_romanize():
    t1 = "Профессиональные мыслители известны своей уравновешенностью."
    r1 = "Professional'nye mysliteli izvestny svoei uravnoveennost'iu."
    assert romanize(locale='ru')(lambda: t1)() == r1

    t2 = "Не знаю, с чем это связано, но как только я выхожу на большую "

# Generated at 2022-06-21 15:37:45.504259
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    @romanize(locale='ru')
    def rus(string):
        return string

    assert rus('Я помню чудное мгновенье') == 'Ya pomnyu chudnoe mgnovenie'
    assert rus('Передо мной явилась ты') == 'Peredo mnoy yavilas ty'

# Generated at 2022-06-21 15:37:48.813349
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_function(locale: str = 'ru'):
        return 'Методы для поддержки поведения'
    assert test_function() == 'Metody dlia podderzhki povedenia'

# Generated at 2022-06-21 15:37:58.584494
# Unit test for function romanize
def test_romanize():
    def romanizator(locale):
        @romanize(locale)
        def foo(arg):
            return arg

    for locale in ['ru', 'uk', 'kk']:
        assert romanizator(locale)

    # raise UnsupportedLocale
    romanizator('abc')

# Generated at 2022-06-21 15:38:00.631518
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')('Всем привет') == 'Vsemp privyet'

# Generated at 2022-06-21 15:38:04.607629
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('помидор')() == 'pomidor'
    assert romanize('uk')('помидор')() == 'pomidor'
    assert romanize('kk')('помидор')() == 'pomidor'



# Generated at 2022-06-21 15:38:08.243173
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.datetime import Datetime

    d = Datetime(Language.RU)

    r = d.date(pattern='dd.mm.yyyy')

    assert r == 'te.st'

# Generated at 2022-06-21 15:38:09.797126
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, мир!').startswith("Privet,")

# Generated at 2022-06-21 15:38:16.777682
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    from mimesis.builtins import RussianSpecProvider
    romanized_ru = functools.partial(romanize, 'ru')
    russian_provider = RussianSpecProvider()

    @romanized_ru
    def return_cyrillic_text():
        return russian_provider.text(quantity=4)

    @romanized_ru
    def return_cyrillic_sentence():
        return russian_provider.sentence(quantity=4)

    assert return_cyrillic_text.__name__ == 'return_cyrillic_text'
    assert return_cyrillic_sentence.__name__ == 'return_cyrillic_sentence'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:38:18.248933
# Unit test for function romanize
def test_romanize():
    assert len(romanize()) == 1

# Generated at 2022-06-21 15:38:21.224715
# Unit test for function romanize
def test_romanize():
    txt = __name__

    @romanize(locale='ru')
    def romanize_ru(text):
        return text

    res = romanize_ru(txt)
    assert res == 'mimesis'

# Generated at 2022-06-21 15:38:24.562379
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    @romanize(locale='uk')
    def foo(s: str) -> str:
        return s

    assert foo('test') == 'test'

# Generated at 2022-06-21 15:38:31.022618
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda x: 'Привет, Мир')() == 'Privet, Mir'
    assert romanized('uk')(lambda x: 'Привіт, Світ')() == 'Pryvit, Svit'
    assert romanized('kk')(lambda x: 'Сайн байқасың, Әлем')() == \
        'Sain baikasyń, Älēm'

# Generated at 2022-06-21 15:38:43.130967
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    @romanize('ru')
    def make_ru_str(size: int = 10) -> str:
        return 'о'.join(['мим'] * size)

    assert make_ru_str(size=10) == 'мимо'.join(['мим'] * 9)
    assert make_ru_str(size=1000) == 'мимо'.join(['мим'] * 999)

# Generated at 2022-06-21 15:38:46.568552
# Unit test for function romanize
def test_romanize():
    # assert romanize('ru')('ПРИВЕТ') == 'Privet'
    assert romanize('ru')(lambda : 'ПРИВЕТ')() == 'Privet'



# Generated at 2022-06-21 15:38:48.002664
# Unit test for function romanize
def test_romanize():
    assert romanized('cyrillic')(lambda x: 'Привет') == 'Privet'

# Generated at 2022-06-21 15:38:51.069797
# Unit test for function romanize
def test_romanize():
    """Function for unit testing for romanize."""
    import doctest
    doctest.testfile('tests/utils/test_decorators.txt')


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:38:55.709754
# Unit test for function romanize
def test_romanize():
    assert 'program' == romanize(locale='ru')('программа')
    assert 'program' == romanize(locale='uk')('програма')
    assert 'program' == romanize(locale='kk')('программа')
    assert 'program' == romanize(locale='ru')('program')

# Generated at 2022-06-21 15:38:58.815226
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет Мир!')() == 'Privet Mir!'
    assert romanized('uk')(lambda: 'Привіт Світ!')() == 'Pryvit Svit!'
    assert romanized('kk')(lambda: 'Сәлем Әлем!')() == 'Salem Álem!'

# Generated at 2022-06-21 15:39:07.934199
# Unit test for function romanize
def test_romanize():
    """Test for function romanized."""
    from mimesis.builtins import Person as Person
    from mimesis.enums import Gender

    person = Person('ru')
    name = person.full_name(gender=Gender.MALE)
    assert name == 'Адвокатъ Путинъ Владимиръ'

    @romanize(locale='ru')
    def romanized_name(*args, **kwargs):
        return person.full_name(gender=Gender.MALE)

    assert romanized_name() == 'Advokat Putin Vladimir'

# Generated at 2022-06-21 15:39:10.947796
# Unit test for function romanize
def test_romanize():
    """Test."""

    @romanize()
    def do_rom():
        """Do something."""
        return 'blah-blah'

    assert do_rom() == 'blah-blah'

# Generated at 2022-06-21 15:39:17.200717
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: "Привет!")() == "Privet!"
    assert romanize('uk')(lambda x: "Привіт!")() == "Pryvit!"
    assert romanize('kk')(lambda x: "Сәлем!")() == "Salem!"



# Generated at 2022-06-21 15:39:27.101871
# Unit test for function romanize
def test_romanize():

    # Default
    assert romanize()
    assert romanize(locale='ru')
    assert romanize(locale='uk')
    assert romanize(locale='kk')

    @romanize(locale="ru")
    def romanize_ru(text: str) -> str:
        return text

    assert romanize_ru("привет как дела") == "privet kak dela"

    @romanize(locale="uk")
    def romanize_uk(text: str) -> str:
        return text

    assert romanize_uk("привiт як справи") == "pryvit yak spravy"


# Generated at 2022-06-21 15:39:34.580538
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize.

    :return: True
    """
    assert romanize()(lambda x: 'строка')() == 'stroka'
    return True



# Generated at 2022-06-21 15:39:38.889724
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Вася')() == 'Vasya'
    assert romanized('kk')(lambda: 'Жаным')() == 'Janım'
    assert romanized('uk')(lambda: 'Олег')() == 'Oleh'

# Generated at 2022-06-21 15:39:41.030671
# Unit test for function romanize
def test_romanize():
    assert romanize('')(lambda: 'Клок раз')() == 'Klok raz'

# Generated at 2022-06-21 15:39:43.017963
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет, мир!') == 'Privet, mir!'



# Generated at 2022-06-21 15:39:47.029166
# Unit test for function romanize
def test_romanize():
    """Test function for romanize."""
    assert romanize('ru')(lambda : "Str")() == "Str"
    assert romanize('uk')(lambda : "Str")() == "Str"
    assert romanize('kk')(lambda : "Str")() == "Str"

# Generated at 2022-06-21 15:39:50.165137
# Unit test for function romanize
def test_romanize():
    test_string = u'Привет мир!'
    assert romanized(locale='ru')(lambda *args, **kwargs: test_string)(
    ) == 'Privet mir!'

# Generated at 2022-06-21 15:39:53.916759
# Unit test for function romanize
def test_romanize():
    assert all(char in ascii_letters + digits + punctuation
               for char in romanized('Я люблю программирование')())

# Generated at 2022-06-21 15:39:55.133577
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('de')

# Generated at 2022-06-21 15:39:58.408693
# Unit test for function romanize
def test_romanize():
    @romanize('kk')
    def kazakh_word(length: int = 10) -> str:
        return 'әңгіме'

    assert kazakh_word() == 'әñğımе'

# Generated at 2022-06-21 15:40:02.136758
# Unit test for function romanize
def test_romanize():
    string = 'Какое сегодня хорошее время позаниматься питоном! 123'
    assert romanized(locale='ru')(lambda: string)() == \
        'Kakoe segodnja khorosheje vremya pozanimatsya pitonom! 123'

# Generated at 2022-06-21 15:40:10.494224
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func():
        return 'Тест'

    assert func() == 'Test'
    assert callable(func)

# Generated at 2022-06-21 15:40:15.397960
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""
    romanize_text = romanize('ru')

    @romanize_text
    def _text(length: int = 10) -> str:
        return "Грибочки моих полей"

    print(_text()) # "Gribochki moikh polei"

# Generated at 2022-06-21 15:40:18.725352
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'ру')() == 'ru'
    assert romanize('uk')(lambda: 'ук')() == 'uk'
    assert romanize('kk')(lambda: 'кк')() == 'kk'

# Generated at 2022-06-21 15:40:27.776564
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.RUSSIAN)
    address = address.postal_code(romanize=True)
    assert isinstance(address, str)
    assert all(i in address for i in ascii_letters + digits + punctuation)
    address = Address(Locale.RUSSIAN)
    address = address.postal_code(romanize=False)
    assert isinstance(address, str)
    assert not any(i in address for i in ascii_letters + digits + punctuation)



# Generated at 2022-06-21 15:40:29.342121
# Unit test for function romanize
def test_romanize():
    assert romanize()('Танкист') == 'Tankist'

# Generated at 2022-06-21 15:40:32.650517
# Unit test for function romanize
def test_romanize():
    import random
    from mimesis.builtins.text import Text

    t = Text(locale='ru')
    random_str = t.pystr(length=10)

    assert t.romanize() != random_str

    assert random_str in t.romanize()

# Generated at 2022-06-21 15:40:39.405836
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda x: 'Привіт')() == 'Privit'
    assert romanize('kk')(lambda x: 'Сәлем')() == 'Sälem'
    assert romanize('aa')(lambda x: 'Привет')() == ''

# Generated at 2022-06-21 15:40:41.742277
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Петров')() == 'Petrov'
    assert romanize()(lambda: 'Карась')() == 'Karas'



# Generated at 2022-06-21 15:40:43.975326
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text

    text = mimesis.builtins.text.Text()
    result = text.romanize()
    assert result

# Generated at 2022-06-21 15:40:54.570423
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian_string(pattern):
        return pattern
    s = russian_string('АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдежзиклмнопрстуфхцчшщъыьэюя')
    assert s == 'ABVGDEGZIKLMNOPRSTUFHTCShSCbYTPEZhEJaBVGDEGZIKLMNOPRSTUFHTCShSCbYTPEZhEIa'

# Generated at 2022-06-21 15:41:08.134769
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test(locale):
        return data.MORSE_CODE_DATA[locale]

    assert test(locale='ru') == '.- -... -.-. -.. . ..-. --. .... .. .--- -.- .-.. -- -. --- .--. --.- .-. ... - ..- ...- .-- -..- -.-- --..'



# Generated at 2022-06-21 15:41:10.335365
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.text import Text
    t = Text('ru')
    word = t.word()
    trans = romanized('uk')(lambda: word)()
    assert isinstance(trans, str)

# Generated at 2022-06-21 15:41:18.169771
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Выгодное предложение: до 36 месяцев без процентов'
                   ) == 'Vygodnoe predlozhenie: do 36 mesyacev bez procentov'

# Generated at 2022-06-21 15:41:20.501970
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Неправильный ввод данных!')() == 'Nepravilnyj vvod dannyh!'

# Generated at 2022-06-21 15:41:21.567912
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()



# Generated at 2022-06-21 15:41:24.716483
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Мама')() == 'Mama'
    assert romanize('uk')(lambda: 'Мама')() == 'Mama'
    assert romanize('kk')(lambda: 'Мама')() == 'Mama'


# Generated at 2022-06-21 15:41:30.304400
# Unit test for function romanize
def test_romanize():
    """Unit-test for romanize function."""
    from mimesis.builtins import Person

    p = Person('ru')
    assert p.full_name() == 'Иван Геннадьевич Сергеев'
    assert p.full_name(romanize=True) == 'Ivan Gennad′evich Sergeev'
    assert p.full_name(romanize=True, locale='kk') == 'Ivan Gennad′evich Sergeev'
    assert p.full_name(romanize=True, locale='uk') == 'Ivan Gennadiïvič Sergeev'
    assert p.full_name() == 'Иван Геннадьевич Сергеев'



# Generated at 2022-06-21 15:41:37.448622
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanized(locale='ru')(lambda: '123 тест')() == '123 test'
    assert romanized(locale='uk')(lambda: '123 тест')() == '123 test'
    assert romanized(locale='kk')(lambda: '123 тест')() == '123 test'

    try:
        romanized(locale='zh-hans')(lambda: 123)()
    except UnsupportedLocale:
        pass
    else:
        assert False

# Generated at 2022-06-21 15:41:39.868651
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def test():
        return 'ывапро'

    assert test() == 'yvapro'

# Generated at 2022-06-21 15:41:43.430951
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    from mimesis import Person
    from mimesis.enums import Gender

    p = Person('ru')
    p.create_person(gender=Gender.MALE)
    assert isinstance(p, Person)

# Generated at 2022-06-21 15:42:06.566103
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize decorator for ru."""
    @romanize('ru')
    def text_ru():
        return 'Привет мир'

    assert text_ru() == 'Привет мир'



# Generated at 2022-06-21 15:42:09.537521
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    # noinspection PyUnusedLocal,PyProtectedMember
    @romanize()
    def test():
        return 'тест'

    assert test() == 'test'

# Generated at 2022-06-21 15:42:13.782153
# Unit test for function romanize
def test_romanize():
    """Test for the romanize decorator."""
    import re
    from mimesis.builtins.text import Text

    t = Text('ru')
    pattern = re.compile(r'[^\w\s]+')

    # Checking that decorator works
    @romanize(locale='ru')
    def romanizer():
        return pattern.sub('', t.text(quantity=10))

    assert len(romanizer()) == 10



# Generated at 2022-06-21 15:42:23.209383
# Unit test for function romanize
def test_romanize():
    import pprint
    from mimesis.enums import Locales
    from mimesis.providers.text import Text

    pp = pprint.PrettyPrinter(indent=2)

    t = Text()

    def test(locale: str):
        data = {
            'alphabet': t.alphabet(locale=locale),
            'word': t.word(locale=locale),
            'words': t.words(locale=locale),
            'sentence': t.sentence(locale=locale),
        }

        pp.pprint(data)

    for locale in Locales:
        if locale.value in data.ROMANIZATION_DICT:
            test(locale.value)

# Generated at 2022-06-21 15:42:28.232062
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()
    assert romanize('ru')(lambda: 'тест') == 'test'
    assert romanize('uk')(lambda: 'тест') == 'test'
    assert romanize('kk')(lambda: 'тест') == 'test'
    assert romanize('un')(lambda: 'тест') == 'тест'

# Generated at 2022-06-21 15:42:30.343235
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def str_func(*args, **kwargs):
        return 'Привет, Мидж'

    assert str_func() == 'Privet, Midzh'

# Generated at 2022-06-21 15:42:32.454308
# Unit test for function romanize
def test_romanize():
    @romanize()
    def generate_russian_name():
        return "Александра  Сергеевна"

    assert generate_russian_name() == "Aleksandra  Sergeevna"



# Generated at 2022-06-21 15:42:34.542652
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    romanized = romanize(locale=locale)

    @romanized()
    def foo():
        return 'билл'

    assert foo() == 'bill'



# Generated at 2022-06-21 15:42:42.845821
# Unit test for function romanize
def test_romanize():

    @romanize(locale='kk')
    def romanize_func(locale: str = '') -> str:
        """Helper function to test romanize decorator."""
        data.COMMON_LETTERS = {
            'a': 'а',
        }
        data.ROMANIZATION_DICT = {
            'kk': {
                'а': 'a',
            },
        }
        return data.COMMON_LETTERS[locale]

    res = romanize_func(locale='kk')
    assert res == 'a', 'Should return romanized text'

# Generated at 2022-06-21 15:42:47.076077
# Unit test for function romanize
def test_romanize():
    print('Test 1. Romanized')
    @romanized()
    def some_method():
        return 'сиди дома'

    assert some_method() == 'sididoma'

    print('Test 2. Romanize uk')
    @romanized('uk')
    def some_method_uk():
        return 'сиди дома'

    assert some_method_uk() == 'sydydoma'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:43:11.191235
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'

    assert romanize('kk')(lambda: 'Сәлем Әлем!')() == 'Sälem Alem!'



# Generated at 2022-06-21 15:43:14.462007
# Unit test for function romanize
def test_romanize():
    def test_data(func, *args, **kwargs):
        return func(*args, **kwargs)

    assert test_data(romanize()(test_data), func=romanize)

# Generated at 2022-06-21 15:43:24.443460
# Unit test for function romanize
def test_romanize():
    """Check for romanization."""
    from mimesis.providers.text import Text

    text = Text('ru')
    assert text.romanize() == 'Kiev'
    assert text.romanize('ru') == 'Kiev'
    assert text.romanize('ua') == 'Kiev'
    assert text.romanize('kk') == 'Qaraqalpaqstan'

    text = Text('ua')
    assert text.romanize('ua') == 'Kiev'
    assert text.romanize('ru') == 'Kiev'
    assert text.romanize('kk') == 'Qaraqalpaqstan'

    text = Text('kk')
    assert text.romanize('kk') == 'Qaraqalpaqstan'
    assert text.romanize('ua') == 'Qaraqalpaqstan'

# Generated at 2022-06-21 15:43:26.908441
# Unit test for function romanize
def test_romanize():
    romanized_text = 'This is romanize test'
    result = romanized('ru')(lambda: romanized_text)()
    assert result == 'This is romanize test'

# Generated at 2022-06-21 15:43:31.080152
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    text = ['Маша', 'Макс' 'Мария', 'Саша', 'Сэнди', 'Сюзанна', 'Костя']
    p = Person()
    for item in text:
        assert (romanize('ru')(lambda: item)() == romanized(Locale.RU)(
            lambda: item)())

# Generated at 2022-06-21 15:43:43.114944
# Unit test for function romanize

# Generated at 2022-06-21 15:43:53.420263
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.enums import Special
    from mimesis.builtins import Address
    from mimesis.builtins import Person
    from mimesis.builtins import Lorem

    new_person = Person(Locale('ru'))

    @romanized(locale='ru')
    def test_romanize_person(person):
        return person.full_name()

    def test_romanize_person_ru(person):
        return person.full_name()

    assert test_romanize_person(new_person) == 'Ли Магдалена'
    assert test_romanize_person_ru(new_person) == 'Ли Магдалена'


# Generated at 2022-06-21 15:43:55.064968
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'привет')() == 'privet'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:44:07.113220
# Unit test for function romanize
def test_romanize():
    print("\nStarting romanize unit test ...")

    # Simple test using real locale
    locale = 'uk'
    @romanize(locale)
    def func1(txt):
        return txt

    res = func1("привіт світ")

    if res != "pryvit svit":
        print("Unit test romanize failed. Got: " + str(res))
    else:
        print("Unit test romanize passed.")

    # A more complicated test
    locale = 'ru'
    @romanize(locale)
    def func2(txt):
        return txt


# Generated at 2022-06-21 15:44:11.857790
# Unit test for function romanize
def test_romanize():
    rus_text = 'Правила Ігрового Простору "Підземелля"'
    romanized_text = romanize(locale='ru')(lambda: rus_text)
    assert romanized_text == 'Pravila Igrovogo Prostradu "Podzemellya"'

# Generated at 2022-06-21 15:44:37.350868
# Unit test for function romanize
def test_romanize():
    def test_func():
        return 'Привет'

    assert 'Privet' == romanize('ru')(test_func)()
    assert 'Привет' == romanize('ru')(test_func)()

# Generated at 2022-06-21 15:44:41.053582
# Unit test for function romanize
def test_romanize():
    def func():
        return 'Привет Мир!'

    romanized_func = romanize('ru')(func)
    assert romanized_func() == 'Privet Mir!'

# Generated at 2022-06-21 15:44:51.231547
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Аннулирование')() == 'Annullirovanie'
    assert romanized(locale='ru')(lambda: 'Отрицание')() == 'Otritsanie'
    assert romanized(locale='ru')(lambda: 'Приход')() == 'Prihod'
    assert romanized(locale='ru')(lambda: 'Списание')() == 'Spisanie'
    assert romanized(locale='ru')(lambda: 'Регистрация')() == 'Registratsiya'

    # Test for English words

# Generated at 2022-06-21 15:44:56.994483
# Unit test for function romanize
def test_romanize():
    test_dict_ru = {
        'Привет, Мир!': 'Privet, Mir!',
        'Привет': 'Privet',
        'Мир': 'Mir',
    }
    test_dict_uk = {
        'Привіт, Світ!': 'Privit, Svit!',
        'Привіт': 'Privit',
        'Світ': 'Svit',
    }