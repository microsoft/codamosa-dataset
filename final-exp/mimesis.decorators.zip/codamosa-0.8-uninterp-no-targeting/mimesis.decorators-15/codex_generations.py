

# Generated at 2022-06-21 15:35:00.117215
# Unit test for function romanize
def test_romanize():
    assert len(romanize(locale='uk')) > 0

# Generated at 2022-06-21 15:35:07.956061
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.builtins import UkrainianSpecProvider
    import uuid

    # disable romanize for all builtin provider
    for v in dir(data):
        if (v.startswith('_') or not isinstance(getattr(data, v), dict) or
                v == 'ROMANIZATION_DICT'):
            continue
        data.ROMANIZATION_DICT[v] = {}

    # enable romanize for uk
    data.ROMANIZATION_DICT['uk'] = data.UK_ROMANIZATION_DICT

    # basic
    @romanize('uk')
    def get_uk_id():
        return str(uuid.uuid4())

    assert len(get_uk_id()) == 36

    # use with built-

# Generated at 2022-06-21 15:35:18.524339
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    from mimesis.builtins import Text
    from mimesis.enums import Gender, Locale
    from mimesis.providers.text import Text as TextProvider

    t = Text()
    t_ru = Text(Locale.RU)
    t.add_provider(TextProvider)

    for i in range(10):
        name = t.personal.full_name(gender=Gender.MALE)
        name_ru = t_ru.personal.full_name(gender=Gender.MALE)
        name_ru_romanized = t.romanize(name_ru, locale='ru')

        assert name != name_ru
        assert name_ru_romanized == name



# Generated at 2022-06-21 15:35:21.172631
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_deco():
        return 'Привет, мир!'

    assert romanize_deco() == 'Privet, mir!'

# Generated at 2022-06-21 15:35:22.472638
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-21 15:35:27.047875
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    rs = RussianSpecProvider()
    assert rs.romanized_text() != ""
    assert rs.romanized_text(400) != ""
    assert rs.romanized_text(10, ' ') != ""
    assert rs.romanized_text(10, ' ', ' ') != ""
    assert rs.romanized_text(400, ' ', ' ', 0) != ""

# Generated at 2022-06-21 15:35:34.846296
# Unit test for function romanize
def test_romanize():
    def foo():
        pass

    foo = romanize()(foo)
    txt = 'Это предложение написано на русском языке'
    expected = 'Eto predlozhenie napisano na russkom yazyke'
    assert foo() == expected
    assert txt.lower() != expected.lower()



# Generated at 2022-06-21 15:35:41.401750
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda : 'Привет, мир!') == 'Privet, mir!'
    assert romanize(locale='uk')(lambda : 'Привіт, світ!') == 'Pryvit, svit!'
    assert romanize(locale='kk')(lambda : 'Сәлем, мир!') == 'Sälem, mir!'

# Generated at 2022-06-21 15:35:45.554132
# Unit test for function romanize
def test_romanize():
    assert romanize('en')('en') == 'en'
    assert romanize('ru')('привет') == 'privet'
    assert romanize('uk')('мир') == 'mir'
    assert romanize('kk')('бала') == 'balа'

# Generated at 2022-06-21 15:35:54.461324
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Привет') == 'Privet'
    assert romanize('ru')('123') == '123'
    assert romanize('ru')('Марсель консервировал такое себе блюдо.') == 'Marsel\' konserviroval takoe sebe blyudo.'
    assert romanize('ru')('Марс. эль-Кон. ровал такое себе блюдо.') == 'Mars. el\'Kon. roval takoe sebe blyudo.'

# Generated at 2022-06-21 15:36:07.068976
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo(v):
        return v

    assert foo == 'bar'

# Generated at 2022-06-21 15:36:07.607718
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-21 15:36:13.363053
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Строка')() == 'Stroka'
    assert romanize('uk')(lambda: 'Рядок')() == 'Ryadok'
    assert romanize('kk')(lambda: 'Жол')() == 'Zhol'



# Generated at 2022-06-21 15:36:19.811818
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Мимими')() == 'Mimimi'
    assert romanize()(lambda: 'Мимими')() == 'Mimimi'
    assert romanize('uk')(lambda: 'Мимими')() == 'Mimimi'
    assert romanize('kk')(lambda: 'Мимими')() == 'Mimimi'

# Generated at 2022-06-21 15:36:28.131906
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender, Specialization, Language
    from mimesis.builtins import RussiaSpecProvider, BelarusSpecProvider
    from mimesis.builtins.base import Person
    from mimesis.builtins.generic import Text

    rus_t = Text(language=Language.RUSSIAN)
    rus_p = Person(locale='ru', gender=Gender.MALE)

    blr_t = Text(language=Language.BELARUSIAN)
    blr_p = Person(locale='be', gender=Gender.MALE)

    assert rus_t.word() == 'прямоугольник'
    assert rus_t.word(locale='ru') == 'прямоугольник'


# Generated at 2022-06-21 15:36:36.995867
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(str)('Абайский район') == 'Abajskij rajon'
    assert romanize(locale='uk')(str)('Абайський район') == 'Abajs\'kyj rajon'
    assert romanize('kk')(str)('Абайский район') == 'Abayskiy rayon'

# Generated at 2022-06-21 15:36:37.916650
# Unit test for function romanize
def test_romanize():
    pass

test_romanize()

# Generated at 2022-06-21 15:36:45.668608
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    p = Person()

    assert p.romanize(data.ROMANIZATION_DICT['ru'], p.full_name(gender='male'))\
        == 'iAleksandr'

    assert p.romanize(data.ROMANIZATION_DICT['uk'], p.full_name(gender='male'))\
        == 'iAnatolii'

    assert p.romanize(data.ROMANIZATION_DICT['uk'], p.name(gender='male'))\
        == 'iAnatolii'

    assert p.romanize(data.ROMANIZATION_DICT['kk'], p.full_name(gender='male'))\
        == 'iAleksandr'


# Generated at 2022-06-21 15:36:53.357723
# Unit test for function romanize
def test_romanize():
    assert data.LOCALES[0] == 'en'
    romanized_locale = romanize(locale='ru')(lambda: data.LOCALES[0])
    assert romanized_locale() == 'ru'
    assert data.LOCALES[0] == 'en'
    assert data.LOCALES[1] == 'es'
    romanized_locale = romanize(locale='uk')(lambda: data.LOCALES[1])
    assert romanized_locale() == 'es'



# Generated at 2022-06-21 15:36:57.325250
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Тестовая строка')() == 'Tekstovaya stroka'

# Generated at 2022-06-21 15:37:18.896979
# Unit test for function romanize
def test_romanize():
    txt = "Не соскучишся ли в таких туманах? Ударил тебя рок, жизнь тебя перебила. Ах, печаль течёт вслед за тобой, дева..."
    assert romanize()(txt) == "Ne soskuschisya li v takih tumahah? Udaril tebya rok, zhizn tebya perebila. Ah, pechal techyet vsled za toboyu, deva..."


# Generated at 2022-06-21 15:37:25.636739
# Unit test for function romanize
def test_romanize():
    # Test for russian locale
    def test_ru():
        @romanize('ru')
        def rus_local(value: str) -> str:
            return value

        return rus_local

    # Test for ukrainian locale
    def test_uk():
        @romanize('uk')
        def ukr_local(value: str) -> str:
            return value

        return ukr_local

    # Test for kazakh locale
    def test_kk():
        @romanize('kk')
        def kaz_local(value: str) -> str:
            return value

        return kaz_local

    rus = test_ru()
    ukr = test_uk()
    kaz = test_kk()


# Generated at 2022-06-21 15:37:36.594672
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_to_eng(string):
        return string.lower()

    assert rus_to_eng('Привет, Мир!') == 'privet, mir!'

    @romanize(locale='uk')
    def ukr_to_eng(string):
        return string.lower()

    assert ukr_to_eng('Привіт, Світе!') == 'pryvit, svite!'

    @romanize(locale='kk')
    def kaz_to_eng(string):
        return string.lower()

    assert kaz_to_eng('Сәлем, Дүние!') == 'salem, dunie!'

# Generated at 2022-06-21 15:37:43.830803
# Unit test for function romanize
def test_romanize():
    def _test(locale, source, expected):
        @romanize(locale)
        def f(s):
            return s

        result = f(source)
        assert result == expected

    _test('uk', 'текст', 'tekst')
    _test('ru', 'проверка', 'proverka')
    _test('kk', 'сөз', 'söz')
    _test('ae', 'текст', 'текст')

# Generated at 2022-06-21 15:37:46.209545
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def f():
        return 'Привет мир!'

    assert f() == 'Privet mir!'

# Generated at 2022-06-21 15:37:52.922163
# Unit test for function romanize
def test_romanize():
    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update(data.ROMANIZATION_DICT['ru'])
    alphabet.update(data.COMMON_LETTERS)
    result = 'Результат'
    txt = ''.join([alphabet[i] for i in result if i in alphabet])
    assert txt == 'Rezul`tat'

# Generated at 2022-06-21 15:37:57.225950
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.builtins import Code

    c = Code('ru')

    @romanize('ru')
    def func():
        return c.code()

    assert func() == c.cyrillic_code()

# Generated at 2022-06-21 15:38:00.712499
# Unit test for function romanize
def test_romanize():
    '''Romanize function test'''
    romanize('ru')(lambda: 'Помни Василия Петровича?')() == \
        'pomni vasiliya petrovicha?'

# Generated at 2022-06-21 15:38:08.796561
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Privet')('ru') == 'Privet'
    assert romanize('uk')(lambda x: 'Боже мій, привіт!')('uk') == \
        'Bože mij, privat!'
    assert romanize('kk')(lambda x: 'Салам, достар!')('kk') == \
        'Salam, dostar!'
    assert romanize('foo')(lambda x: 'bar')('baz') is None
    assert romanize('ru')(lambda x: '')('ru') == ''

# Generated at 2022-06-21 15:38:15.143272
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.schema import Field, Schema
    from mimesis.providers.mathematics import Mathematics

    data_provider = Mathematics(Language.RUSSIAN)
    schema = Schema(field_by_provider={
        Field('integer'): data_provider.integer,
    })

    assert romanize(locale='ru')(schema.create(quantity=1)['integer']) == 'двaдцать два'

    assert romanized(locale='ru')(schema.create(quantity=1)['integer']) == 'двaдцать два'

# Generated at 2022-06-21 15:38:49.832086
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Богуславка')() == 'Boguslavka'
    assert romanize('uk')(lambda: 'Іванків')() == 'Ivankiv'
    assert romanize('kk')(lambda: 'Батайсак')() == 'Bataysaq'
    cyr_text = lambda: 'Народному архітектору України Івану ' \
                    'Олеговичу Присяжнему'

# Generated at 2022-06-21 15:38:53.024434
# Unit test for function romanize
def test_romanize():

    @romanize()
    def romanize_test():
        """Romanize test function."""
        return 'Вася'

    assert romanize_test() == 'Vasya'

# Generated at 2022-06-21 15:38:56.449727
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_ru(string: str) -> str:
        return string

    # Simple test
    assert romanize_ru('Привет') == 'Privet'

    # Multi-word
    assert romanize_ru('Привет, мир!') == 'Privet, mir!'

    # Punctuation
    assert romanize_ru('Вот она, волчица.') == 'Vot ona, volchica.'

    # Cyrillic-latin
    assert romanize_ru('Привет, мир!') == 'Privet, mir!'

    # Cyrillic-cyrillic (common)
    assert r

# Generated at 2022-06-21 15:39:07.009086
# Unit test for function romanize
def test_romanize():
    print("###############################")
    print("Testning romanize")
    print("###############################")
    txt = romanize(locale='ru')
    txt_ru = txt("После стрельбы Лондон сделал паузу,чтобы переосмыслить свое отношение к этому вопросу. Мы будем работать вместе ")
    print(txt_ru)



# Generated at 2022-06-21 15:39:15.788089
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda x: 'привет')('ru') == 'privet'
    assert romanized('kk')(lambda x: 'сәлем')('kk') == 'salem'
    assert romanized('uk')(lambda x: 'привіт')('uk') == 'pryvit'
    assert romanized('ru')(lambda x: 'привет!')('ru') == 'privet!'
    assert romanized('kk')(lambda x: 'сәлем!')('kk') == 'salem!'
    assert romanized('uk')(lambda x: 'привіт!')('uk') == 'pryvit!'

# Generated at 2022-06-21 15:39:25.968576
# Unit test for function romanize
def test_romanize():

    supported_locales = data.ROMANIZATION_DICT.keys()
    unsupported_locales = ['ukr', 'ukrainian', 'rus', 'russian']

    @romanize()
    def my_func():
        return 'Привет! Как дела?'

    assert my_func() == 'Pryvit! Kak dela?'

    for locale in supported_locales:
        @romanize(locale=locale)
        def my_locale_func():
            return 'Привет! Как дела?'

        assert my_locale_func() == 'Pryvit! Kak dela?'


# Generated at 2022-06-21 15:39:33.101795
# Unit test for function romanize
def test_romanize():
    alphabet = {s: s for s in
                ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT['ru'],
        **data.COMMON_LETTERS,
    })

    # Cyrillic string can contain ascii
    # symbols, digits and punctuation.
    txt = 'Улица Гарматная 123а кв.32'
    txt1 = ''.join([alphabet[i] for i in txt if i in alphabet])
    assert txt1 == "Ulitsa Garmatnaya 123a kv.32"



# Generated at 2022-06-21 15:39:39.180887
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет Мир!')() == 'Privet Mir!'
    assert romanize('ru')(lambda: 'Привет Мир!')() == 'Privet Mir!'
    assert romanize('uk')(lambda: 'Привіт Мир!')() == 'Privit Mir!'
    assert romanize('kk')(lambda: 'Салам Дүние!')() == 'Salam Dünie!'

    try:
        romanize('de')(lambda: 'Привет Мир!')(failobj='Kotlin')
    except UnsupportedLocale as err:
        assert str(err) == 'de'
        assert err

# Generated at 2022-06-21 15:39:46.513474
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_text(value):
        return value

    assert romanize_text('Привет') == 'Privet'
    assert romanize_text('Дорама') == 'Dorama'
    assert romanize_text('Прывітаньне') == 'Pryvitan\'ne'
    assert romanize_text('Дарама') == 'Dorama'
    assert romanize_text('Привіт') == 'Privit'

# Generated at 2022-06-21 15:39:56.596980
# Unit test for function romanize
def test_romanize():
    from timeit import timeit
    from mimesis.builtins.text import extract
    from mimesis.enums import Language

    t1 = timeit(
        'extract("a", "b", "c")',
        'from mimesis import extract',
        number=1000,
    )
    print(t1)

    t2 = timeit(
        'extract("a", "b", "c")',
        'from  mimesis.builtins.text import extract',
        number=1000,
    )
    print(t2)

    t3 = timeit(
        'extract("a", "b", "c", locale=Language.RU.value)',
        'from  mimesis.builtins.text import extract',
        number=1000,
    )
    print(t3)

# Generated at 2022-06-21 15:40:53.776358
# Unit test for function romanize
def test_romanize():
    from mimesis import Generic
    from mimesis.enums import Gender

    g = Generic('ru')

    assert g.code.imei().find('-') < 0
    assert g.person.full_name(gender=Gender.MALE)

    # TODO:
    # assert g.person.full_name(gender=Gender.MALE).isalpha()

# Generated at 2022-06-21 15:40:55.848039
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test():
        return "Федор Тютчев"
    assert test() == "Fedor Tjuchev"

# Generated at 2022-06-21 15:40:56.470946
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')

# Generated at 2022-06-21 15:40:57.082407
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')



# Generated at 2022-06-21 15:40:59.664229
# Unit test for function romanize
def test_romanize():
    """The function should return a string transliterated from russian
    to latin."""
    @romanize('ru')
    def mytest(x: int) -> int:
        return x

    assert mytest('Москва') == 'Moskva'

# Generated at 2022-06-21 15:41:10.101748
# Unit test for function romanize
def test_romanize():
    """Test function 'romanize'."""
    @romanized(locale='ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Южно-Сахалинск') == 'Yuzhno-Sakhalinsk'
    assert romanize_ru('Воронеж') == 'Voronezh'
    assert romanize_ru('Уфа') == 'Ufa'
    assert romanize_ru('Волгоград') == 'Volgograd'
    assert romanize_ru('Екатеринбург') == 'Yekaterinburg'

# Generated at 2022-06-21 15:41:20.109746
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda: 'Как приказал босс, и так сделал.')
    assert result == 'Kak prikazal boss, i tak sdelal.'

    result = romanize('uk')(lambda: 'Що запросив бос, що вже і зробив.')
    assert result == 'Shcho zaprosyv boss, shcho vzhe i zrobyv.'


# Generated at 2022-06-21 15:41:23.310898
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo():
        return 'Это тест!'

    assert foo() == 'Eto test!'

    @romanize(locale='uk')
    def foo():
        return 'Это тест!'

    assert foo() == 'Eto test!'



# Generated at 2022-06-21 15:41:24.881337
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет') == 'Privet'

# Generated at 2022-06-21 15:41:34.051987
# Unit test for function romanize
def test_romanize():
    """Test for romanize()."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    ru = RussiaSpecProvider()

    # Test cases for romanize

# Generated at 2022-06-21 15:43:40.006364
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Ариэль')() == 'Ariel'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:43:42.894356
# Unit test for function romanize
def test_romanize():
    text = 'Привет мир!'
    assert 'Privet mir!' == romanize('ru')(lambda: text)()



# Generated at 2022-06-21 15:43:53.366646
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.utils import get_locale
    from mimesis.providers.person import Person

    current_locale = get_locale()

    def romanize_cyrillic(locale):
        p = Person(locale)
        name = p.full_name()

        # Simple check of the original string.
        assert all(s in data.CYRILLIC_LETTERS for s in name)

        # Check of the romanized string.
        romanized_name = p.full_name(romanize=True)
        assert all(s in data.LATIN_LETTERS for s in romanized_name)

    def test_romanize_all_locales():
        """Test romanization of all the supported locales."""

# Generated at 2022-06-21 15:43:55.216146
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет мир')() == 'Privet mir'

# Generated at 2022-06-21 15:43:59.502954
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: '')() == ''

    assert romanize(locale='uk')(lambda: '')() == ''

    assert romanize(locale='kk')(lambda: '')() == ''

# Generated at 2022-06-21 15:44:07.039216
# Unit test for function romanize
def test_romanize():
    from mimesis import Address
    address = Address('en')

    @romanize(locale='en')
    def _test_romanize(place):
        return address.street_name(place=place)

    assert _test_romanize(place='uk') == 'Golovinska'
    assert _test_romanize(place='ru') == 'Prospekt Oktyabrskiy'
    assert _test_romanize(place='ru') != 'українська'

# Generated at 2022-06-21 15:44:14.120966
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    rus_provider = RussiaSpecProvider()
    alphabet = rus_provider._alphabet

    assert romanized('')(alphabet) == 'a, b, v, g, d, e,, zh, z, i, k, l, m,' \
                                      ' n, o, p, r, s, t, u, f, x, ts, ch, ' \
                                      'sh, shch, g, yu, ya'
    assert romanized('')('Привет, Мир') == 'pritivit, mir'

# Generated at 2022-06-21 15:44:22.121824
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""

# Generated at 2022-06-21 15:44:26.875799
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    # pylint: disable=import-outside-toplevel
    from mimesis.providers import DateTime
    dt = DateTime('ru')
    assert dt.timestamp.__doc__ == 'Текущий UNIX-временную метку.'

# Generated at 2022-06-21 15:44:32.547203
# Unit test for function romanize
def test_romanize():

    assert romanize.__name__ == 'romanize'
    assert romanize.__doc__ is not None
    assert callable(romanize)
    assert callable(romanize(locale='ru'))
    assert not callable(romanize(locale='en'))
    assert romanize(locale='fr')(lambda: 'Микеланджело').__name__ == \
        '<lambda>'