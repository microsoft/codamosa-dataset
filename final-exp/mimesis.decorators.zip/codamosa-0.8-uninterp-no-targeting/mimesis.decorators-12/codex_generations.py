

# Generated at 2022-06-21 15:35:02.622588
# Unit test for function romanize
def test_romanize():
    """Check that romanize works as expected."""
    @romanize()
    def romanized_func(rnd):
        return rnd.text()

    assert romanized_func is not None
    assert romanized_func(0) is not None

# Generated at 2022-06-21 15:35:12.636643
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.personal import Personal
    from mimesis.providers.payment import Payment
    from mimesis.providers.telecommunications import Telecommunications

    def test_provider(cls):
        obj = cls('ru')
        methods = [i for i in dir(obj)
                   if not i.startswith('_') and callable(getattr(obj, i))]
        for m in methods:
            try:
                getattr(obj, m)()
            except UnsupportedLocale:
                pass

    test_provider(Address)
    test_provider(Geography)
    test_provider(Personal)
    test_provider(Payment)
    test_prov

# Generated at 2022-06-21 15:35:14.454602
# Unit test for function romanize
def test_romanize():
    @romanize()
    def f():
        return 'куку'

    assert f() == 'kuku'

# Generated at 2022-06-21 15:35:15.446203
# Unit test for function romanize
def test_romanize():
    # Write unit tests for romanize decorator
    pass

# Generated at 2022-06-21 15:35:17.026774
# Unit test for function romanize
def test_romanize():
    pass


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:35:19.158232
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('Компания') == 'Kompania'



# Generated at 2022-06-21 15:35:22.537551
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def _romanize():
        return 'Какой-то текст'

    romanized_text = _romanize()
    assert romanized_text == 'Kakoj-to tekst'

# Generated at 2022-06-21 15:35:25.588951
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test(seed: int = None) -> None:
        return "Привет, Мир!"

    assert test(seed=1) == 'privet, mir!'

# Generated at 2022-06-21 15:35:29.507421
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus(token):
        return token

    assert rus('А') == 'A'
    assert rus('Привет') == 'Privet'

    @romanize('kk')
    def kaz(token):
        return token

    assert kaz('Қ') == 'Q'
    assert kaz('Сәлем') == 'Sälem'

# Generated at 2022-06-21 15:35:32.060171
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('en')

# Generated at 2022-06-21 15:35:44.746655
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    @romanize()
    def dummy_func():
        # Tests not supported locale
        try:
            return 'This is a test from {}'.format('dummy')
        except UnsupportedLocale:
            return 'This is an unsupported locale'

    assert dummy_func() == 'This is an unsupported locale'

    @romanize('kk')
    def dummy_func():
        # Tests string
        return 'This is a test from {}'.format('kk')

    assert dummy_func() == 'This is a test from kk'

# Generated at 2022-06-21 15:35:47.573777
# Unit test for function romanize
def test_romanize():
    res = romanize()(lambda: 'Привет любимая')()
    assert res == 'Privet lyubimaya'



# Generated at 2022-06-21 15:35:56.177287
# Unit test for function romanize
def test_romanize():
    def romanize_text(text: str = '') -> str:
        """Romanize the text."""
        return text

    romanized_text = romanize('ru')(romanize_text)

    assert romanized_text('привет') == 'privet'
    assert romanized_text('Привет') == 'Privet'
    assert romanized_text('привет!') == 'privet!'
    assert romanized_text('Я люблю чипсы!') == 'Ja ljublju chipsi!'
    assert romanized_text('привет.') == 'privet.'

# Generated at 2022-06-21 15:35:59.790512
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def func(a):
        return a


    assert func('привет мир') == 'privet mir'

# Generated at 2022-06-21 15:36:02.029872
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def j():
        return 'Привет'

    assert j() == 'Privet'



# Generated at 2022-06-21 15:36:05.394692
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus():
        return 'Мимесис'

    assert rus() == 'Mimesis'

# Generated at 2022-06-21 15:36:07.244788
# Unit test for function romanize
def test_romanize():
        romanized = romanize(locale='ru')
        assert romanized == 'Romanized'

# Generated at 2022-06-21 15:36:08.436284
# Unit test for function romanize
def test_romanize():
    assert romanize
    assert romanized

test_romanize()

# Generated at 2022-06-21 15:36:13.006581
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""

    @romanize(locale='ru')
    def get_romanized_string():
        return 'Привет, Мир!'

    result = get_romanized_string()
    assert result == 'Privet, Mir!'

# Generated at 2022-06-21 15:36:16.556898
# Unit test for function romanize
def test_romanize():
    string = 'Привет, Python!'
    romanized_string = 'Privet, Python!'
    assert romanize()(lambda: string)() == romanized_string

# Generated at 2022-06-21 15:36:30.497654
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет мир')() == 'privet mir'
    assert romanize('ru')(lambda: 'Привет Мир')() == 'Privet Mir'
    assert romanize('uk')(lambda: 'Привіт Світ')() == 'Pryvit Svit'
    assert romanize('kk')(lambda: 'Сәлем Дүние')() == 'Sälem Dünie'

# Generated at 2022-06-21 15:36:34.848565
# Unit test for function romanize
def test_romanize():
    result1 = romanize(locale='ru')(lambda: 'стол')
    result2 = romanize('kk')(lambda: 'Шәші')
    assert result1 == 'stol'
    assert result2 == 'Shasha'

# Generated at 2022-06-21 15:36:40.833630
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.text import Text

    t = Text("ru")
    assert t._romanize("Привет") == "Privet"

    s = Text("uk")
    assert s._romanize("Привіт") == "Pryvit"

    assert t._romanize("Привет Мир") == "Privet Mir"



# Generated at 2022-06-21 15:36:45.901009
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: "Конфигурация разделяемой памяти"
                          "критического ресурса не соответствует")() == \
        'Konfiguratsiya razdelyaemoy pamyati kriticheskogo resursa ne' \
        ' sootvetstvuet'

# Generated at 2022-06-21 15:36:52.610724
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет Мир')() == 'Privet mir'
    assert romanized('uk')(lambda: 'Привіт Мир')() == 'Pryvit mir'
    assert romanized('kk')(lambda: 'Сәлем Дүние')() == 'Salem Dunie'

# Generated at 2022-06-21 15:36:54.973026
# Unit test for function romanize
def test_romanize():
    assert romanize('en')

# Generated at 2022-06-21 15:36:57.062828
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-21 15:37:03.952381
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет!')() == 'Privet!'
    assert romanized('uk')(lambda: 'Привіт!')() == 'Pryvit!'
    assert romanized('kk')(lambda: 'Сәлем!')() == 'Selm!'
    assert (romanize('')(lambda: 'Привіт, привіт!')() ==
            'Pryvit, pryvit!')

# Generated at 2022-06-21 15:37:13.832872
# Unit test for function romanize
def test_romanize():
    # must not fail
    romanize()(str)('Hello')
    # must raise exception
    try:
        romanize('xx')(str)('Hello')
    except UnsupportedLocale:
        pass
    else:
        assert False

    # must be converted
    assert romanize('ru')(str)('Привет') == 'Privyet'
    assert romanize('uk')(str)('Здоровенькі були') == 'Zdorovenki buli'
    assert romanize('kk')(str)('Сәлем') == 'Salem'

# Generated at 2022-06-21 15:37:18.159827
# Unit test for function romanize
def test_romanize():
    """Test romanize()."""
    @romanize(locale='ru')
    def _test():
        return 'Привет Мир!'

    txt = _test()
    assert txt == 'Privet Mir!'



# Generated at 2022-06-21 15:37:42.641020
# Unit test for function romanize
def test_romanize():
    assert 'Moskva' == romanize('ru')('Москва')
    assert 'Kiev' == romanize('uk')('Київ')
    assert 'Astana' == romanize('kk')('Астана')

test_romanize()

# Generated at 2022-06-21 15:37:48.690336
# Unit test for function romanize
def test_romanize():
    @romanized(locale='ru')
    def r_ru():
        return 'Георгий'

    assert r_ru() == 'Georgiy'

    @romanized(locale='uk')
    def r_uk():
        return 'Микола'

    assert r_uk() == 'Mykola'

    @romanized(locale='kk')
    def r_kk():
        return 'Қазақстан'

    assert r_kk() == 'Qazaqstan'

# Generated at 2022-06-21 15:37:51.386492
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'привет')() == 'privet'

# Generated at 2022-06-21 15:37:59.452016
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanized_str(name):
        return name

    assert romanized_str('Александр') == 'Alexander'

    @romanize('uk')
    def romanized_str(name):
        return name

    assert romanized_str('Петро') == 'Petro'

    @romanize('kk')
    def romanized_str(name):
        return name

    assert romanized_str('Алсу') == 'Alsu'

# Generated at 2022-06-21 15:38:02.873681
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize() function."""
    from mimesis.builtins import CyrillicMixin
    from mimesis.providers.text import Text

    class T(CyrillicMixin, Text):
        pass

    t = T('ru')
    assert t.romanize(t.word())

# Generated at 2022-06-21 15:38:10.822374
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian():
        """Return random russian romanized text."""
        return 'конь'

    assert russian() == 'kon'

    @romanize('uk')
    def ukrainian():
        """Return random ukrainian romanized text."""
        return 'КІШКА'

    assert ukrainian() == 'KISHKA'

    @romanize('kk')
    def kazakh():
        """Return random kazakh romanized text."""
        return 'СҰР'

    assert kazakh() == 'SUR'



# Generated at 2022-06-21 15:38:13.153806
# Unit test for function romanize
def test_romanize():
    print(romanized()(lambda: 'Привет мир!'))
    print(romanize('kk')(lambda: 'Привет мир!'))

# Generated at 2022-06-21 15:38:15.832146
# Unit test for function romanize
def test_romanize():
    import random

    @romanize()
    def data(seed):
        for i in range(random.randint(3, 10)):
            yield random.randint(0, 10)

    assert data(10) == '0' * 10

# Generated at 2022-06-21 15:38:19.449529
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanized(locale='ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-21 15:38:25.913477
# Unit test for function romanize
def test_romanize():
    """Test decorator romanize."""
    # pylint: disable=unused-variable, too-few-public-methods
    class Romanizable:

        @romanized('ru')
        def romanizable(self):
            return 'Топот'

        def no_romanized(self):
            return 'Топот'

    r = Romanizable()
    assert r.romanizable() == 'Topot'
    assert r.no_romanized() == 'Топот'

# Generated at 2022-06-21 15:39:18.117832
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    r = romanize('kk')
    c = r(lambda: 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя')

    assert c == "abwgde'öjzïyklmnoprstwfhtschsch'ï'éûâ"



# Generated at 2022-06-21 15:39:22.060669
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    romanized_string = romanized('ru')

    assert romanized_string(provider=None, func='provider') != \
        romanized_string(provider=None, func='provider')

# Generated at 2022-06-21 15:39:25.347504
# Unit test for function romanize
def test_romanize():
    text = romanize()(lambda: 'Я умею программировать.')()
    assert text == 'Ya umeyu programmirovat\'.'

# Generated at 2022-06-21 15:39:30.075944
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    t = Text(Language.ENGLISH)

    @romanize(locale=Language.RUSSIAN)
    def text_data(mask, **kwargs):
        return t.text(mask, **kwargs)

    assert text_data(mask='{{common}}', min_=10, max_=50)

# Generated at 2022-06-21 15:39:37.780636
# Unit test for function romanize

# Generated at 2022-06-21 15:39:42.063861
# Unit test for function romanize
def test_romanize():
    from mimesis.fields import Text

    locales = ['ru', 'uk', 'kk']
    for locale in locales:
        localizer = Text(locale=locale)
        txt = localizer.romanize(localizer.word())
        assert txt != ''
        assert txt.isalpha()


# Generated at 2022-06-21 15:39:50.797860
# Unit test for function romanize
def test_romanize():
    @romanize('kk')
    def get_random_string():
        return 'Абай дасы - мысықтың ұстазы'

    assert get_random_string() == 'Abaı dasy - mısyqtyń ustazy'

    @romanize('ru')
    def get_random_string():
        return 'Я за Эдуарда Дегтярёва!'

    result = get_random_string()
    assert result == 'Ya za Edyarda Dyegtyaryova!'



# Generated at 2022-06-21 15:39:54.806378
# Unit test for function romanize
def test_romanize():
    test_locale = 'ru'
    test_data = 'Хэй'
    test_romanized_data = 'Hey'
    assert romanize(test_locale)(lambda: test_data)(
    ) == test_romanized_data



# Generated at 2022-06-21 15:39:55.692743
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')



# Generated at 2022-06-21 15:40:02.861885
# Unit test for function romanize
def test_romanize():
    assert romanize()('абвгджзийклмнопрстуфхцчшщэюя') == 'abvgjzijklmnoprstufhccschschcejuja'
    assert romanize()('АБВГДЖЗИЙКЛМНОПРСТУФХЦЧШЩЭЮЯ') == 'ABVGJZIJKLMNOPRSTUFHCCSCHSCHCEJUJA'
    assert romanize()('123456') == '123456'


# Generated at 2022-06-21 15:42:10.167321
# Unit test for function romanize
def test_romanize():
    """Test romanize(locale: str = '') -> Callable."""
    from mimesis.overrides import address
    assert type(address.romanize('ru')) is Callable

# Generated at 2022-06-21 15:42:16.083091
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_letter():
        return 'М'

    result = get_letter()
    assert result == 'M'

    @romanize('uk')
    def get_letter():
        return 'М'

    result = get_letter()
    assert result == 'M'

    @romanize('ru')
    def get_letter():
        return 'М'

    result = get_letter()
    assert result == 'M'

    @romanize('kk')
    def get_letter():
        return 'М'

    result = get_letter()
    assert result == 'M'

# Generated at 2022-06-21 15:42:17.994730
# Unit test for function romanize
def test_romanize():
    def func():
        return "Привет"

    func = romanize(func)
    assert func() == "privet"

# Generated at 2022-06-21 15:42:25.555002
# Unit test for function romanize
def test_romanize():
    assert romanized("ru")("Добрый день") == "Dobryj den'"
    assert romanized("kk")("Сәлем! Эй бұл Мәдениет Әнді") == "Salem! Ey bul Madeniet Ändi"
    assert romanized("uk")("Не хвилюйся, живи; а лише мрій") == "Ne khvilyujsja, zhyvy; a lyshe mrij"

# Generated at 2022-06-21 15:42:32.362315
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    a = Address(Language.RU)
    p = Person(Language.RU)
    address = a.address()
    first_name = p.name(gender=None)
    last_name = p.surname()

    print("Address: ", address)
    print("Address Romanized: ", a.address(romanized=True))
    print("First Name: ", first_name)
    print("First Name Romanized: ", p.name(gender=None, romanized=True))
    print("Last Name: ", last_name)
    print("Last Name Romanized: ", p.surname(romanized=True))



# Generated at 2022-06-21 15:42:41.670936
# Unit test for function romanize

# Generated at 2022-06-21 15:42:43.910805
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Казахстан')() == 'Kazakhstan'



# Generated at 2022-06-21 15:42:45.795200
# Unit test for function romanize
def test_romanize():
    """Test romanization decorator."""
    result = romanize('ru')(lambda: 'привет, мир!')
    assert result == 'privet, mir!'

# Generated at 2022-06-21 15:42:56.168991
# Unit test for function romanize
def test_romanize():
    from mimesis import Address, Person

    en = Person().full_name(locale='en')
    ru = Person().full_name(locale='ru')
    za = Person().full_name(locale='za')
    ru_romanized = Person().full_name(locale='ru_RU')

    assert ru != ru_romanized
    assert ru_romanized == 'Александр Иванов'
    assert ru != ru_romanized
    assert ru == 'Александр Иванов'

    assert en == 'Andrew Higgins'
    assert ru != ru_romanized
    assert ru == 'Александр Иванов'


# Generated at 2022-06-21 15:43:01.250653
# Unit test for function romanize
def test_romanize():
    def test_func():
        return 'Привет, мир!'

    decorated_func = romanize()(test_func)
    assert decorated_func() == 'Privet, mir!'