

# Generated at 2022-06-21 15:35:12.733506
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'hello')() == 'hello'
    assert romanize('ru')(lambda: 'hello')(locale='ru') == 'hello'
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('ru')(lambda: 'привет')(locale='ru') == 'privet'
    assert romanize('kk')(lambda: 'привет')() == 'privet'
    assert romanize('kk')(lambda: 'привет')(locale='kk') == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'pryvit'

# Generated at 2022-06-21 15:35:15.305083
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'йцуке')() == 'jcyuke'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:35:18.140072
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test(russian: str) -> str:
        return russian

    assert test('Иванов') == 'Ivanov'

# Generated at 2022-06-21 15:35:19.390695
# Unit test for function romanize
def test_romanize():
    assert romanize()('тест') == 'test'

# Generated at 2022-06-21 15:35:22.412028
# Unit test for function romanize
def test_romanize():
    def f(x):
        return 'я' * x

    g = romanize('ru')(f)
    assert g(42) == f(42)
    assert g(42) == 'я' * 42
    assert g(0) == ''

# Generated at 2022-06-21 15:35:25.465999
# Unit test for function romanize
def test_romanize():
    def test_func():
        return "Привет, как дела?"

    assert (romanized("ru")(test_func)() == "Privet, kak dela?")



# Generated at 2022-06-21 15:35:28.003470
# Unit test for function romanize
def test_romanize():
    """Romanize function."""
    text = 'Лорем ипсум долор сит амет'
    assert text.lower() == romanize('ru')(text).lower()

# Generated at 2022-06-21 15:35:31.406747
# Unit test for function romanize
def test_romanize():
    """Test for romanize()."""
    assert romanize()
    assert romanized()

# Generated at 2022-06-21 15:35:39.932202
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_generator():
        return 'Буря мглою небо кроет,вихри снежные крутя'
    assert russian_generator() == 'Burya mgloyu nebo kroyet,vikhri snezhnye krutya'

    @romanize(locale='uk')
    def ukrainian_generator():
        return 'Буря мглою небо кроеть,вiхрi снiжнi крутять'

# Generated at 2022-06-21 15:35:46.428788
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize()(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('en')(lambda: 'Bye bye, world!')() == 'Bye bye, world!'

# Generated at 2022-06-21 15:35:54.137859
# Unit test for function romanize
def test_romanize():
    romanized_func = romanize('ru')(lambda: 'привет')
    assert romanized_func() == 'privet'



# Generated at 2022-06-21 15:35:55.851141
# Unit test for function romanize
def test_romanize():
    assert romanized()('Будем работать') == 'Budem rabotat'

# Generated at 2022-06-21 15:36:02.240838
# Unit test for function romanize
def test_romanize():
    import random
    import string
    from mimesis.enums import Locale
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.builtins import Cyrillic, Common

    class PersonKz(Person):
        def __init__(self):
            super().__init__(locale=Locale('kz'), gender=Gender.FEMALE)

        @romanized('kz')
        def get_full_name(self) -> str:
            return super().get_full_name()

    class PersonUa(Person):
        def __init__(self):
            super().__init__(locale=Locale('uk'), gender=Gender.FEMALE)


# Generated at 2022-06-21 15:36:08.827346
# Unit test for function romanize
def test_romanize():
    assert (romanize('ru')(
        lambda: 'Привет мир')()) == 'Privet mir'
    assert (romanize('kk')(
        lambda: 'Сәлем әлем')()) == 'Sälem älem'
    assert (romanize('uk')(
        lambda: 'Привіт світ')()) == 'Pryvit svit'

# Generated at 2022-06-21 15:36:16.557187
# Unit test for function romanize
def test_romanize():
    @romanize(locale='uk')
    def test_romanize_deco(*args, **kwargs):
        return 'абвгґдеєжзиіїйклмнопрстуфхцчшщьюя'

    assert test_romanize_deco() == 'abvhgdjejezhziijyzklimnoprstufxchshshjyujia'

# Generated at 2022-06-21 15:36:18.826487
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Коралл') == 'Koralll'

# Generated at 2022-06-21 15:36:26.152357
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    from .conftest import assert_equal

    assert_equal(
        Address(Locale.UKRAINIAN).address.lower(),
        'проспект академіка проскури тупик 15'.lower(),
    )

    assert_equal(
        Address(Locale.UKRAINIAN).address.lower(romanize='uk'),
        'prospekt akademika pros’kuri tupyk 15'.lower(),
    )

# Generated at 2022-06-21 15:36:27.446464
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'на окно') == 'na okno'



# Generated at 2022-06-21 15:36:30.235194
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: "abc")() == "abc"
    assert romanize("ru")(lambda: "АБВ")() == "ABV"

# Generated at 2022-06-21 15:36:35.089583
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    @romanize(locale=Locale.EN)
    def get_text(provider=Text) -> str:
        return provider.text()

    assert isinstance(get_text(), str)

# Generated at 2022-06-21 15:36:43.724042
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text

    txt = Text('ru')
    assert txt.romanize()

    txt = Text('uk')
    assert txt.romanize()

    txt = Text('kk')
    assert txt.romanize()



# Generated at 2022-06-21 15:36:49.633760
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'абв')() == 'abv'
    assert romanize('uk')(lambda: 'абв')() == 'abv'
    assert romanize('kk')(lambda: 'абв')() == 'abv'

# Generated at 2022-06-21 15:36:53.158275
# Unit test for function romanize
def test_romanize():
    assert all(
        romanize()(lambda: i)() == romanize('')(lambda: i)()
        for i in ('Hello world', 'Привіт світ', 'Привет мир')
    )

# Generated at 2022-06-21 15:37:04.589598
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda *args, **kwargs: 'Петро')() == 'Petro'
    assert romanize()(lambda *args, **kwargs: 'Нічі')() == 'Nichi'
    assert romanize()(lambda *args, **kwargs: 'Володимир')() == 'Volodymyr'
    assert romanize()(lambda *args, **kwargs: 'Світлана')() == 'Svitlana'
    assert romanize()(lambda *args, **kwargs: 'Сергій')() == 'Serhiy'
    assert romanize()(lambda *args, **kwargs: 'Ганна')() == 'Hanna'

# Generated at 2022-06-21 15:37:10.951975
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'



# Generated at 2022-06-21 15:37:14.231256
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Демонстрация моих навыков')() == 'Demonstraciya moih navykov'

# Generated at 2022-06-21 15:37:19.896241
# Unit test for function romanize
def test_romanize():
    #
    @romanize('ru')
    def строка() -> str:
        return 'текст'

    #
    assert строка() == 'tekst'

    try:
        #
        @romanize('fr')
        def error() -> str:
            return 'текст'
    except UnsupportedLocale:
        assert True



# Generated at 2022-06-21 15:37:24.343284
# Unit test for function romanize
def test_romanize():
    import string
    import random

    r = random.Random()
    alphabet = string.ascii_letters + string.digits + string.punctuation
    for i in range(10):
        word = ''.join(r.choice(alphabet) for j in range(50))
        assert romanize('')(lambda: word)() == word

# Generated at 2022-06-21 15:37:33.604758
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'


# Generated at 2022-06-21 15:37:37.050793
# Unit test for function romanize
def test_romanize():
    """Calling romanize()."""
    result = romanize()(lambda: 'Ключевые слова.')
    assert result == 'Klyuchevyie slova.'

# Generated at 2022-06-21 15:37:55.933258
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.misc.misc import Misc
    inst = Misc()
    txt = Text(Language.RUSSIAN)
    assert inst.romanize(txt.word()) == txt.word()
    lower = Text(Language.ENGLISH, lowercase=True)
    assert inst.romanize(lower.word()) == lower.word()

# Generated at 2022-06-21 15:37:58.774059
# Unit test for function romanize
def test_romanize():
    assert romanized(locale="ru")("Привет") == "Privet"
    assert romanized(locale="uk")("Привіт") == "Pryvit"
    assert romanized(locale="kk")("Сәлем") == "Sälem"

# Generated at 2022-06-21 15:38:01.441404
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    rus = RussiaSpecProvider(seed=42)

    assert rus.romanize('Как дела') == 'Kak dela'

# Generated at 2022-06-21 15:38:09.258606
# Unit test for function romanize
def test_romanize():
    # Greek string can contain ascii
    # symbols, digits and punctuation.
    alphabet = {s: s for s in
                ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT['uk'],
        **data.COMMON_LETTERS,
    })

    result = 'aběčděfgžďhťišějžďě1lmňopřčstŕvwxřčňyzž'
    assert ''.join([alphabet[i] for i in result if i in alphabet]) == 'a271m'

# Generated at 2022-06-21 15:38:11.752383
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Проверка')() == 'Provecka'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:38:13.723917
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет, мир')() == \
        'Privet, mir'

# Generated at 2022-06-21 15:38:16.616671
# Unit test for function romanize
def test_romanize():
    def foo(x: str) -> str:
        return x

    foo = romanized('ru')(foo)
    text = foo('Привет мир!')
    assert text == 'Привед мир!'

# Generated at 2022-06-21 15:38:20.764588
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: data.CYRILLIC_ALPHABET)() == 'АБВГДежзийклмнопрстуфхцчшщъыьэюя'

# Generated at 2022-06-21 15:38:23.814753
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def test_func():
        yield 'Форма'

    assert test_func() == 'Forma'

# Generated at 2022-06-21 15:38:31.169945
# Unit test for function romanize
def test_romanize():
    str_ru = 'Привет'
    str_uk = 'Привіт'
    str_kk = 'Сәлем'

    # Without romanize
    assert romanized()(str_ru) == str_ru
    assert romanized()(str_uk) == str_uk
    assert romanized()(str_kk) == str_kk

    # With romanize
    assert romanized('ru')(str_ru) == 'Privet'
    assert romanized('uk')(str_uk) == 'Privit'
    assert romanized('kk')(str_kk) == 'Salem'

# Generated at 2022-06-21 15:38:59.679456
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.providers.base import BaseProvider

    class TestProvider(BaseProvider):

        def simple_method(self):
            return 'Привет'

        @romanize('ru')
        def romanized_method(self):
            return 'Привет'

    t = TestProvider('ru')
    assert t.simple_method() == 'Привет'
    assert t.romanized_method() == 'Privet'

    with pytest.raises(UnsupportedLocale):
        TestProvider('zz')

# Generated at 2022-06-21 15:39:05.800390
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize, just check without errors."""

    romanized = romanize('ru')

    @romanized
    def romanize_test(locale: str) -> str:
        """Romanize test.

        :param locale: Locale code.
        :return: Romanized text.
        """
        return 'Добро пожаловать!'

    print(romanize_test)

# Generated at 2022-06-21 15:39:11.639392
# Unit test for function romanize
def test_romanize():
    assert romanized()('АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'), \
        'ABCDĚFGHIJKLMNOPRSŤUVWXYÝZabcdefghijklmnoprstuvwxyýz'

# Generated at 2022-06-21 15:39:16.854431
# Unit test for function romanize
def test_romanize():
    assert romanize()('test') == 'test'
    assert romanize()('тест') == 'test'
    assert romanize()('тест абырвалг') == 'test abyrvalg'

# Generated at 2022-06-21 15:39:22.215870
# Unit test for function romanize
def test_romanize():
    assert(romanize('ru')(lambda: 'Привет')() == 'Privet')
    assert(romanize('uk')(lambda: 'Привіт')() == 'Privit')
    assert(romanize('kk')(lambda: 'Сәлеметсіз бе')() == 'Salemetsiz be')



# Generated at 2022-06-21 15:39:25.879177
# Unit test for function romanize
def test_romanize():
    import mimesis
    text_generator = mimesis.Personal('ru')
    result = text_generator.full_name()
    assert romanize('ru')(lambda: result)() == \
        'Chudovenko Chudovenko Chudovenkovich'

# Generated at 2022-06-21 15:39:28.248120
# Unit test for function romanize
def test_romanize():
    assert romanized()('Ох, уж эти греки!') == 'Oh, uzh etye grekky!'

# Generated at 2022-06-21 15:39:33.508532
# Unit test for function romanize
def test_romanize():
    locale = 'ru-RU'

    g = data.Data(locale)

    translit = g.person.full_name()
    kyrillic = g.person.full_name(romanize_text=False)
    assert translit == romanize(locale)(g.person.full_name)(
        romanize_text=False
    )
    assert kyrillic == romanize(locale)(g.person.full_name)(
        romanize_text=True
    )

# Generated at 2022-06-21 15:39:35.522084
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    @romanize('ru')
    def test():
        return 'Привет'

    assert test() == 'Privet'

# Generated at 2022-06-21 15:39:40.108042
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def russian_text(seed: int = None) -> str:
        """Generate random russian text."""
        text = ''.join(data.RANDOM_STRINGS_DATA['ru'])
        return text

    result = russian_text()
    assert len(result) > 0

# Generated at 2022-06-21 15:40:30.181796
# Unit test for function romanize
def test_romanize():
    assert data.ROMANIZATION_DICT['ru']['Ж'] == 'Zh'


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-21 15:40:33.675104
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-21 15:40:37.128693
# Unit test for function romanize
def test_romanize():
    """Test for function `romanize`."""
    assert romanize(locale='ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-21 15:40:45.948026
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_text():
        return 'Петя вчера пришёл'.lower()

    assert romanize_text() == 'petia vchera prishol'

    @romanize(locale='ru')
    def romanize_ru():
        return 'Петя вчера пришёл'

    assert romanize_ru() == 'petia vchera prishol'

    @romanize(locale='uk')
    def romanize_uk():
        return 'Петя вчера прийшов'

    assert romanize_uk() == 'petia vchera pryishov'


# Generated at 2022-06-21 15:40:52.680825
# Unit test for function romanize
def test_romanize():
    def _romanize(locale: str = '') -> str:
        """Simple method for romanization."""

        return 'Это тестовая строка локали.'

    romanized_test = romanize('ru')(_romanize)
    assert romanized_test() == 'Eto testovaya stroka lokali.'

# Generated at 2022-06-21 15:40:55.187515
# Unit test for function romanize
def test_romanize():
    @romanize()
    def roman():
        return "Романизированный текст"

    assert roman() == "Romanizirovannyi tekst"

# Generated at 2022-06-21 15:41:00.019824
# Unit test for function romanize
def test_romanize():
    list = 'йцукенгшщзхъфывапролджэячсмитьбю'
    for i in list:
        assert romanized(locale='ru')(i) == data.ROMANIZATION_DICT['ru'][i]


# Generated at 2022-06-21 15:41:06.442618
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda: 'абв')() == 'abv'
    assert romanize('uk')(lambda: 'АБВ')() == 'ABV'
    # For Russian:
    assert romanize()(lambda: 'абв')() == 'abv'
    assert romanize()(lambda: 'АБВ')() == 'ABV'

# Generated at 2022-06-21 15:41:18.175917
# Unit test for function romanize
def test_romanize():
    assert 'tst' == romanize('en')(lambda: 'тст')()

# Generated at 2022-06-21 15:41:20.040604
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def roman_func():
        return 'Россия'

    assert roman_func() == 'Rossiya'



# Generated at 2022-06-21 15:43:31.572400
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test(self):
        return 'Привет, мир!'

    result = test()
    assert result == 'Privet, mir!'



# Generated at 2022-06-21 15:43:40.635915
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Как дела? Что у вас нового? Как дела?') == 'Kak dela? Chto u vas novogo? Kak dela?'
    assert romanize('uk')(lambda: 'Як справи? Що нового?') == 'Yak spravy? Shcho novoho?'


# For backwards compatibility
test_romanized = test_romanize

# Generated at 2022-06-21 15:43:43.556728
# Unit test for function romanize
def test_romanize():
    @romanize(locale='kk')
    def foo():
        return 'моя строка'

    assert foo() == 'moya stroka'

# Generated at 2022-06-21 15:43:46.958823
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text

    t = Text(locale='ru')
    text = t.text()
    assert romanized('ru')(lambda: text)() == t.romanized()

# Generated at 2022-06-21 15:43:53.369251
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    assert isinstance(Person().name(locale='ru-RU', romanize=True), str)



# Generated at 2022-06-21 15:44:04.616068
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT
    from mimesis.data import COMMON_LETTERS
    from mimesis.providers import Person

    person = Person(locale='ru')
    romanization_dict = {**ROMANIZATION_DICT['ru'], **COMMON_LETTERS}
    romanization_dict_unsupported_locale = {
        **ROMANIZATION_DICT['uk'],
        **COMMON_LETTERS
    }
    person_uk = Person(locale='uk')

    assert isinstance(person, Person)
    assert person.full_name() == person.romanize(person.full_name())
    assert person_uk.full_name() == person.romanize(person_uk.full_name())

# Generated at 2022-06-21 15:44:14.161435
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""

    def test_func(string: str) -> str:
        """Test function.

        :param string: Testing string.
        :return: String.
        """
        return string

    assert test_func('Привет, мир') == romanize('ru')(test_func)('Привет, мир')
    assert test_func('Привет, мир') == romanize('uk')(test_func)('Привет, мир')
    assert test_func('Привет, мир') == romanize('kk')(test_func)('Привет, мир')

# Generated at 2022-06-21 15:44:18.043469
# Unit test for function romanize
def test_romanize():
    assert romanized()('Тут должны быть русские буквы') == \
        'Tut dolzhny byt russkie bukvy'

test_romanize()

# Generated at 2022-06-21 15:44:20.011691
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_text():
        return 'Привет, друг!'

    assert test_text() == 'Privet, drug!'

# Generated at 2022-06-21 15:44:21.571283
# Unit test for function romanize
def test_romanize():
    @romanize(locale="ru")
    def russian_word(word):
        return word

    assert russian_word("Привет") == "Privet"

