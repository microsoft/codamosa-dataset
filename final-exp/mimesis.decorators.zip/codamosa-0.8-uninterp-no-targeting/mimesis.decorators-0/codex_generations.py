

# Generated at 2022-06-21 15:35:04.049717
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(str)() == 'привет мир'

# Generated at 2022-06-21 15:35:08.017830
# Unit test for function romanize
def test_romanize():
    assert all(
        list(
            map(
                lambda c: c == c.translate({
                    ord(s): s for s in ascii_letters + digits + punctuation
                }).translate(data.ROMANIZATION_DICT['ru']).translate(
                    data.COMMON_LETTERS),
                data.CyrillicProvider('ru').text(20),
            ))
    )

# Generated at 2022-06-21 15:35:14.405138
# Unit test for function romanize
def test_romanize():
    @romanize()
    def a():
        return 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'

    assert a() == 'abvgdejozijklmnoprstufhcccshsch\'"y\'ejua'

# Generated at 2022-06-21 15:35:17.125058
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    p = RussianSpecProvider()
    assert p.romanize('проверка') == 'proverka'

# Generated at 2022-06-21 15:35:20.640314
# Unit test for function romanize
def test_romanize():
    def sample_function(latin_string):
        return latin_string

    @romanize(locale='ru')
    def sample_function_ru(cyrillic_string):
        return cyrillic_string

    assert sample_function_ru('Привет') == 'Privet'

# Generated at 2022-06-21 15:35:21.173817
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:35:27.937381
# Unit test for function romanize
def test_romanize():
    """Test function romanize"""
    def test_func():
        """Arabic text"""
        return 'مكتوب باستخدام لغة بايثون'

    romanized_func = romanize('ar')(test_func)
    assert romanized_func == 'mktwbastakhdm leghabaythwn'

    non_romanized_func = test_func
    assert non_romanized_func == 'مكتوب باستخدام لغة بايثون'

# Generated at 2022-06-21 15:35:30.925972
# Unit test for function romanize
def test_romanize():
    value = romanize()
    assert callable(value)

# Generated at 2022-06-21 15:35:33.257901
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    txt = romanize('ru')(lambda x: 'Я')
    assert txt == 'Ya'

# Generated at 2022-06-21 15:35:38.243196
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""
    from mimesis import Person
    from .utils import get_random_locale

    locale = get_random_locale()
    person = Person(locale)

    result = person.full_name()
    assert isinstance(result, str)
    romanize_name = romanize(locale)(person.full_name)()
    assert isinstance(romanize_name, str)

# Generated at 2022-06-21 15:35:50.115329
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian(self):
        return 'привет'

    assert russian() == 'privet'

    @romanize(locale='kk')
    def kazakh(self):
        return 'привет'

    assert kazakh() == 'privet'

    @romanize(locale='uk')
    def ukrainian(self):
        return 'привет'

    assert ukrainian() == 'privet'

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:35:58.369469
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda: data.CAPITALS['ru'].__next__())
    assert isinstance(result, str)

    result = romanize('uk')(lambda: data.CAPITALS['uk'].__next__())
    assert isinstance(result, str)

    result = romanize('kk')(lambda: data.CAPITALS['kk'].__next__())
    assert isinstance(result, str)

    result = romanize('ru')(lambda: data.FIRST_NAMES_MALE['ru'].__next__())
    assert isinstance(result, str)

    result = romanize('uk')(lambda: data.FIRST_NAMES_MALE['uk'].__next__())
    assert isinstance(result, str)


# Generated at 2022-06-21 15:36:04.896578
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Code
    code = Code('ru')

    @romanize(locale='ru')
    def get_text(length):
        return code.ascii(length=length)

    txt = get_text(13)
    assert len(txt) == 13
    assert isinstance(txt, str)
    assert txt.islower()

# Generated at 2022-06-21 15:36:13.514465
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def check_romanization(text: str, locale: str = '') -> str:
        return text

    # Russian locale
    assert check_romanization('Привет мир!') == 'Privet mir!'

    # Ukrainian locale
    assert check_romanization('Привіт') == 'Pryvit'

    # Kazakh locale
    assert check_romanization('Жақсы жасау') == 'Jaqsy jasaw'

    # Mixed locale
    assert check_romanization('Привет мир!') == 'Privet mir!'
    assert check_romanization('Привіт') == 'Pryvit'

# Generated at 2022-06-21 15:36:14.916978
# Unit test for function romanize
def test_romanize():
    # should we have unit tests for decorator?
    pass

# Generated at 2022-06-21 15:36:19.639893
# Unit test for function romanize
def test_romanize():
    def cyrillic(locale: str = ''):
        return ''.join([data.CYRILLIC_LETTERS[locale]() for i in range(4)])

    for local in data.ROMANIZATION_DICT:
        assert romanize(local)(cyrillic)(locale=local) and True

# Generated at 2022-06-21 15:36:24.746676
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    @romanize(Locale.RUSSIAN)
    def r():
        return 'Привет, Мимесис!'

    assert r == 'Privet, Mimesis!'

    @romanized(Locale.ENGLISH)
    def r():
        return 'Привет, Мимесис!'

    assert r == 'Privet, Mimesis!'

# Generated at 2022-06-21 15:36:36.812676
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    import re

    @romanize(locale='ru')
    def romanized_text(length: int = 10) -> str:
        """Generate romanized random text.

        :param length: Length of generated text.
        :return: Random romanized text.
        """
        russian = data.CYRILLIC_LETTERS
        return ''.join([russian() for _ in range(length)])

    result = romanized_text()
    cyr_re = re.compile(r'[а-яё]', re.I)
    is_cyrillic = cyr_re.findall(result)
    assert is_cyrillic == [], 'Some cyrillic letters in the text.'

# Generated at 2022-06-21 15:36:41.959037
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")(
        lambda: "Сейчас больше снегопадов и больше кошачьих выездов.")(
    ) == "Seichas bol'she snegopadov i bol'she koshach'ikh vyezdov."

# Generated at 2022-06-21 15:36:42.425607
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:37:00.098602
# Unit test for function romanize
def test_romanize():
    x = romanize('ru')
    assert x(lambda: 'Привет')() == 'Privet'

    x = romanize('uk')
    assert x(lambda: 'Рік')() == 'Rik'

    x = romanize('kk')
    assert x(lambda: 'Әйге')() == 'Ájge'


# Generated at 2022-06-21 15:37:07.325575
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.person import Person

    p = Person('ru')
    assert p.full_name() == 'Дмитрий Черный'
    p = Person('ru')
    assert p.full_name(romanize=True) == 'Dmitriy Chernyy'
    p = Person('uk')
    assert p.full_name(romanize=True) == 'Evgeniya Volyns\'ka'



# Generated at 2022-06-21 15:37:17.535807
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, Мир!') == 'Privet, Mir!'

    assert romanize('ru')('Привет, Мир!') == 'Privet, Mir!'
    assert romanize('uk')('До Невилля перейшли через кам’яний мост.') == \
        'Do Nevellia pereishli cherez kam’ianyi most.'
    assert romanize('kk')('Яратпаймын') == 'Yaratpaymyn'

# Generated at 2022-06-21 15:37:19.856932
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize(locale='ru') is not None
    assert romanized(locale='ru') is not None

# Generated at 2022-06-21 15:37:25.935091
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda x: 'Привет, мир!') == 'Privet, mir!'
    assert romanize()(lambda x: 'Формализм') == 'Formalizm'
    assert romanize()(lambda x: 'Телеком') == 'Telekom'

    assert romanize(locale='ru')(lambda x: 'Пафос') == 'Pafos'
    assert romanize(locale='uk')(lambda x: 'Пафос') == 'Pafos'
    assert romanize(locale='kk')(lambda x: 'Пафос') == 'Pafos'


# Generated at 2022-06-21 15:37:30.227605
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test(self):
        return 'Добро пожаловать в Россию'

    assert test(None) == 'Dobro pozhalovat` v Rossiyu'

# Generated at 2022-06-21 15:37:36.517339
# Unit test for function romanize
def test_romanize():
    assert (romanize('ru')(lambda: 'Анализ синтаксиса')()
            == 'Analiz sintaksisa')
    assert (romanize('en')(lambda: 'Анализ синтаксиса')()
            == 'Анализ синтаксиса')

# Generated at 2022-06-21 15:37:44.105375
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    russian_provider = RussiaSpecProvider

    romanized_txt = russian_provider.romanize(russian_provider.last_name())
    assert romanized_txt == 'Kuznetsov'
    romanized_txt = russian_provider.romanize(russian_provider.name())
    assert romanized_txt == 'Kuznetsov'

    assert russian_provider.romanized(russian_provider.last_name()) == 'Kuznetsov'



# Generated at 2022-06-21 15:37:50.740622
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers import Person

    assert romanize(Locale.UK)(Person(Locale.UK).full_name) == \
        romanize(Locale.UK)(Person(Locale.UK).full_name()), 'Decorator failed'

    assert romanize('ru')(Person('ru').full_name) == \
        romanize('ru')(Person('ru').full_name()), 'Decorator failed'

    assert romanize('uk')(Person('uk').full_name) == \
        romanize('uk')(Person('uk').full_name()), 'Decorator failed'


# Generated at 2022-06-21 15:37:51.388871
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-21 15:38:16.114402
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo():
        return 'Давай поженимся'

    assert foo() == 'Davay pojenimsya'

# Generated at 2022-06-21 15:38:19.020010
# Unit test for function romanize
def test_romanize():
    """Test romanize()"""
    assert romanize(locale='ru')(lambda: 'Мимесис')(), 'Mimesis'

# Generated at 2022-06-21 15:38:25.734934
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Абырвалг')() == 'Abyrvalg'
    assert romanized('uk')(lambda: 'Абвгґдеєжзиіїйклмнопрстуфхцчшщьюя')() == \
           'Abvhgdeiezhizhiiiklmnoprstufkhtschshshchiuia'

# Generated at 2022-06-21 15:38:33.831229
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_data():
        return 'Строка с русским набором текста'
    russian = russian_data()
    assert russian == 'Stroka s russkim naborom teksta'

    @romanize(locale='uk')
    def ukrainian_data():
        return 'Українська строка'
    ukrainian = ukrainian_data()
    assert ukrainian == 'Ukrainianska stroka'


# Generated at 2022-06-21 15:38:38.113372
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Макс") == "Maks"
    assert romanize("uk")("Макс") == "Maks"
    assert romanize("kk")("Макс") == "Maks"

# Generated at 2022-06-21 15:38:43.256349
# Unit test for function romanize
def test_romanize():
    # TODO: Find a way to test with unittests
    from mimesis.providers import Personal
    from mimesis.providers.address import Address

    personal = Personal('ru')
    address = Address('uk')

    # address.full_address()
    # address.full_address(region_short=False)
    # personal.name()
    # personal.surname()
    # personal.technical_name()

# Generated at 2022-06-21 15:38:45.488618
# Unit test for function romanize
def test_romanize():
    def romanize_test_func():
        return 'тест'
    wrapper = romanize('ru')(romanize_test_func)
    assert wrapper() == 'test'

# Generated at 2022-06-21 15:38:50.960593
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Привет, мир!'

    @romanized('ru')
    def bar():
        return 'Привет, мир!'

    @romanized('ru')
    def baz():
        return 'Привет, мир!'

    assert foo() == bar() and foo() == baz()
    assert foo() == 'Privet, mir!'

# Generated at 2022-06-21 15:38:57.019798
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    r = RussianSpecProvider()
    assert r.romanize('а б в г д е ё ж з и й к л м н о п р с т у ф х ц ч ш щ ъ ы ь э ю я') == \
        'a b v g d e yo zh z i y k l m n o p r s t u f kh ts ch sh shch i y e yu ya'

# Generated at 2022-06-21 15:39:00.643273
# Unit test for function romanize
def test_romanize():
    # Arrange
    expected = 'Kara Khoja'

    # Act
    actual = romanize('kk')(lambda: 'Қара хоҗа')

    # Assert
    assert actual == expected

# Generated at 2022-06-21 15:39:50.797435
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='kk')('АБВГҒҒҒ') == 'ABVGGG'
    assert romanize()('ААБАВАГАҒАҒАҒ') == 'AAABAVAGAGAG'

# Generated at 2022-06-21 15:39:53.815045
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test():
        return 'Это декоратор.'

    assert test() == 'Eto dekorator.'

# Generated at 2022-06-21 15:39:56.721891
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'русский')() == 'russkiy'
    assert romanize('ru')(lambda: 'русский')() == 'russkiy'

# Generated at 2022-06-21 15:40:05.478744
# Unit test for function romanize
def test_romanize():
    import unittest

    class TestRomanize(unittest.TestCase):

        def setUp(self) -> None:
            self.valid_data = [{'locale': 'uk', 'text': 'Привіт',
                                'result': 'Pryvit'},
                               {'locale': 'ru', 'text': 'Привет',
                                'result': 'Privet'},
                               {'locale': 'kk', 'text': 'Салам',
                                'result': 'Salam'}
                               ]
            self.invalid_data = [{'locale': 'ruu', 'text': 'Привет'}]


# Generated at 2022-06-21 15:40:08.822949
# Unit test for function romanize
def test_romanize():
    def test_func():
        return "Российская Федерация"
    assert ("Rossiiskaya Federatsiya") == romanize('ru')(test_func)()

# Generated at 2022-06-21 15:40:12.780437
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_test(text):
        return text

    text = 'тестовая строка'
    assert romanize_test(text) == 'testovaya stroka'

# Generated at 2022-06-21 15:40:21.085329
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, мир')(locale='ru') == 'Privet, mir'
    assert romanize()('Привіт, світ')(locale='uk') == 'Pryvit, svit'
    assert romanize()('Сәлем, әлем')(locale='kk') == 'Salem, além'
    assert romanize()('Привет, мир')(locale='foo') == ''
    assert romanized('Привет, мир')(locale='ru') == 'Privet, mir'

# Generated at 2022-06-21 15:40:21.836293
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)

# Generated at 2022-06-21 15:40:23.928436
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : '')() == ''

# Generated at 2022-06-21 15:40:25.212773
# Unit test for function romanize
def test_romanize():
    assert romanize()('Африка') == 'Afrika'

# Generated at 2022-06-21 15:42:50.764440
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    p = Person(locale=Locale.RUSSIAN)
    a = Address(locale=Locale.RUSSIAN)

    assert ''.join(r for r in p.name()).isalnum()
    assert ''.join(r for r in a.city()).isalnum()
    assert ''.join(r for r in a.address()).isalnum()

# Generated at 2022-06-21 15:42:52.906459
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: None)
    assert romanize(locale='uk')(lambda: None)
    assert romanize(locale='kk')(lambda: None)
    assert not romanize(locale='ru_RU')(lambda: None)

# Generated at 2022-06-21 15:43:01.553822
# Unit test for function romanize
def test_romanize():
    data.ROMANIZATION_DICT['kk'] = {'А': '1'}
    data.ROMANIZATION_DICT['kk'] = {'Б': '2'}
    data.ROMANIZATION_DICT['kk'] = {'В': '3'}

    @romanize('kk')
    def test_func(n):
        return n

    assert test_func('АБВ') == '123', 'Тест казахского романизатора'

# Generated at 2022-06-21 15:43:13.026387
# Unit test for function romanize

# Generated at 2022-06-21 15:43:17.495796
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    @romanized()
    def foo():
        return 'Привет, мир!'

    assert foo() == 'Privet, mir!'

# Generated at 2022-06-21 15:43:26.255065
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Съешь ещё этих мягких французских булок, да выпей чаю.')() == 'Sʺeshʹ eshche etikh miagkikh frant͡suzskikh bulok, da vypeĭ chaiu.'

# Generated at 2022-06-21 15:43:31.443473
# Unit test for function romanize
def test_romanize():
    def test_function():
        return 'Привет мир! Это русский текст. Спасибо'

    romanized_func = romanize('ru')(test_function)
    assert romanized_func() == 'Privet mir! Eto russkiy tekst. Spasibo'



# Generated at 2022-06-21 15:43:40.102523
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def r():
        return "АБВГД"
    assert r() == 'абвгд'

    @romanize('uk')
    def u():
        return "АБВГД"
    assert u() == 'абвгд'

    @romanize('kk')
    def k():
        return "АБВГД"
    assert k() == 'абвгд'

# Generated at 2022-06-21 15:43:44.849794
# Unit test for function romanize
def test_romanize():
    # method that must be romanized
    @romanize(locale='ru')
    def romanization():
        return 'Давайте поехали к пляжу!'

    assert 'Davayte poexali k plyazhu!' == romanization()

# Generated at 2022-06-21 15:43:47.619355
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Я так рад')() == 'Ja tak rad'