

# Generated at 2022-06-21 15:35:03.485038
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    @romanize(locale='ru')
    def foo():
        """Fake method."""
        return 'Давай поженимся, пожалуйста.'

    assert foo() == 'Davai pozhenimsya, pozhaluista.'

# Generated at 2022-06-21 15:35:10.033848
# Unit test for function romanize
def test_romanize():
    # pylint: disable=protected-access
    assert romanize('ru')(lambda: 'Фэнфэйл')() == 'Fenfayl'
    assert romanized('ru')(lambda: 'Фэнфэйл')() == 'Fenfayl'
    assert romanize('uk')(lambda: 'Фенфайл')() == 'Fenfayl'
    assert romanize('kk')(lambda: 'Фенфайл')() == 'Fenfayl'
    assert romanize('zz')(lambda: 'Фенфайл')() == 'Фенфайл'

# Generated at 2022-06-21 15:35:15.544401
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo():
        return 'тест'
    assert foo() == 'test'

    @romanize(locale='ru')
    def bar():
        return 'тест'
    assert bar() == 'test'

    @romanize('ru')
    def baz():
        return 'тест'
    assert baz() == 'test'

# Generated at 2022-06-21 15:35:19.379880
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'К ä м \' ћ') == 'K ae м \' ch'
    assert romanize('uk')(lambda: 'Сан Минела') == 'San Minelya'

# Generated at 2022-06-21 15:35:27.120565
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers

    a = Address(Locale.RU)
    m = Misc(Locale.RU)
    n = Numbers(Locale.RU)

    assert a.address() == 'ул.Филиппова, д.6, кв.65'
    assert n.romanized_integer(min_value=3, max_value=5) == 'IV'
    assert m.romanized_url() == 'https://lending.ru/infiniti/'

# Generated at 2022-06-21 15:35:36.651032
# Unit test for function romanize
def test_romanize():
    """Test romanize."""

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('ru')
    name = person.full_name(gender=Gender.MALE)
    assert name == 'Ильдар Филатов'

    @romanize(locale='ru')
    def romanized_name():
        return person.full_name(gender=Gender.MALE)

    assert romanized_name() == 'Ildar Filatov'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:35:45.097734
# Unit test for function romanize
def test_romanize():
    """Test Romanize function"""
    def test_gen(locale, text):
        @romanize(locale)
        def test_func(text):
            return text

        return test_func(text)

    assert test_gen('uk', 'Абитурієнти') == 'Abyturiienty'
    assert test_gen('ru', 'Абитуриенты') == 'Abiturienty'
    assert test_gen('kk', 'Туындағандар') == 'Tuuındaǵandar'

# Generated at 2022-06-21 15:35:48.679983
# Unit test for function romanize
def test_romanize():
    """Romanize the cyrillic script into the latin alphabet."""
    assert romanize('ru')('На берегу пустынных') == \
           'Na beregu pustynnykh'



# Generated at 2022-06-21 15:35:50.236328
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'hello, мир!')() == 'hello, mir!'

# Generated at 2022-06-21 15:35:51.125681
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='uk')

# Generated at 2022-06-21 15:35:58.117206
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:36:01.321400
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo():
        return 'Привет!'

    assert foo() == 'Privet!'

# Generated at 2022-06-21 15:36:05.095092
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет, панда Бамбук')() == 'Privet, pandu Bambuk'

# Generated at 2022-06-21 15:36:07.289953
# Unit test for function romanize
def test_romanize():
    assert romanized('ru', 'Привет, Мир!') == 'Privet, Mir!'



# Generated at 2022-06-21 15:36:10.130804
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    romanize_en = romanize('en')
    assert romanize_en(lambda: 'Hello Я Люблю Тебя')() == 'Hello Ya Lyublyu Tebya'

# Generated at 2022-06-21 15:36:11.114280
# Unit test for function romanize
def test_romanize():
    assert romanize() is romanize

# Generated at 2022-06-21 15:36:14.121658
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def get_roman():
        return 'привет, мир!'

    assert get_roman() == 'privet, mir!'

# Generated at 2022-06-21 15:36:17.363219
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import CyrillicWord

    @romanize('ru')
    def text():
        word = CyrillicWord()
        return word.as_latin()

    assert text()

# Generated at 2022-06-21 15:36:20.468875
# Unit test for function romanize
def test_romanize():
    r = romanize('es')(lambda string: string)
    # this is a test
    assert r('esto es una prueba') == 'esto es una prueba'

# Generated at 2022-06-21 15:36:28.523620
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person
    from mimesis.providers.person.ru import Person as PersonRu

    person = Person()
    person_ru = PersonRu()
    text = Text()

    assert text.romanian_surname() != person.last_name()

    assert text.romanian_name(gender=Gender.FEMALE) \
           != person.first_name(gender=Gender.FEMALE)
    assert text.romanian_name(gender=Gender.MALE) \
           != person.first_name(gender=Gender.MALE)


# Generated at 2022-06-21 15:36:43.414830
# Unit test for function romanize
def test_romanize():
    try:
        assert(romanize(locale='ru')('Проверка')=='proverka')
    except:
        assert(False)
    try:
        assert(romanize(locale='kk')('פּראָבֶרקה')=='proverka')
    except:
        assert(False)
    try:
        assert(romanize(locale='uk')('Проверка')=='proverka')
    except:
        assert(False)
    try:
        assert(romanize(locale='uk')('Проверка')=='proverka')
    except:
        assert(False)

# Generated at 2022-06-21 15:36:54.310851
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text

    txt = mimesis.builtins.text.Text(['en'])
    result = txt.word()
    assert romanize('en')(result) == result

    txt = mimesis.builtins.text.Text(['ru'])
    result = txt.word(is_cyr=True)
    assert romanize('ru')(result) == result

    txt = mimesis.builtins.text.Text(['uk'])
    result = txt.word(is_cyr=True)
    assert romanize('uk')(result) == result

    txt = mimesis.builtins.text.Text(['kk'])
    result = txt.word(is_cyr=True)

# Generated at 2022-06-21 15:36:55.626544
# Unit test for function romanize
def test_romanize():
    def foo():
        return 'привет'

    assert 'privet' == romanize('ru')(foo)()

# Generated at 2022-06-21 15:36:57.861777
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Русский')() == 'Russkii'

# Generated at 2022-06-21 15:36:59.770244
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Тест')() == 'Test'

# Generated at 2022-06-21 15:37:02.295761
# Unit test for function romanize
def test_romanize():
    result = romanize(locale='ru')(lambda: 'Заголовок')()
    assert len(result) > 0
    assert result == 'Zagolovok'

# Generated at 2022-06-21 15:37:08.166120
# Unit test for function romanize
def test_romanize():
    import re
    @romanize(locale='ru')
    def romanized_text():
        return 'Привет, Мимезис!'

    assert re.match(r'Privet, Mimezis!', romanized_text())


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:37:09.642007
# Unit test for function romanize
def test_romanize():
    # Test decorator
    assert romanize()



# Generated at 2022-06-21 15:37:16.774184
# Unit test for function romanize
def test_romanize():
    romanize_f = romanize()
    romanize_f_locale = romanize('uk')
    str = 'Шива'
    romanized_str = romanize_f(lambda x: str)
    romanized_str_locale = romanize_f_locale(lambda x: str)
    assert romanized_str == 'Shiva'
    assert romanized_str_locale == 'Šyva'

# Generated at 2022-06-21 15:37:24.389464
# Unit test for function romanize
def test_romanize():
    obj = data.Person(locale='ru')
    result = obj.full_name()
    txt = ''
    for i in result:
        if i in data.ROMANIZATION_DICT[obj.locale]:
            txt += data.ROMANIZATION_DICT[obj.locale][i]
        elif i in data.COMMON_LETTERS:
            txt += data.COMMON_LETTERS[i]
        elif i in (ascii_letters + digits + punctuation):
            txt += i

    assert result == 'рлитак-роьбак'
    assert txt == 'rlitak-rojbak'

    obj = data.Person(locale='uk')
    result = obj.full_name()
    txt = ''


# Generated at 2022-06-21 15:37:38.696078
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: "Буря могучего волнения")\
        == "Burya moguchego volneniya"

# Generated at 2022-06-21 15:37:46.399187
# Unit test for function romanize
def test_romanize():
    class TestClass:
        def test(self, txt: str) -> str:
            return txt

    c = TestClass()

    romanized_func = romanize('ru')(c.test)
    roman_txt = romanized_func('Лозанна')
    assert roman_txt == 'Lozanna'

    # Test for preserving the common letters
    mixed_txt = romanized_func('Лозанна-Lyon-ロザーヌ')
    assert mixed_txt == 'Lozanna-Lyon-ロザーヌ'

# Generated at 2022-06-21 15:37:49.854279
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Это тестовые данные')() == \
        'Eto testovyie dannyie'

# Generated at 2022-06-21 15:37:50.558713
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:37:59.027574
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert 'pyatya' == romanize('ru')('пять')
    assert 'pyatya' == romanize('uk')('пять')
    assert 'pyatya' == romanize('kk')('пять')

    # No such locale
    try:
        assert 'pyatya' == romanize('kkk')('пять')
    except UnsupportedLocale as e:
        assert 'kkk' == e.args[0]

# Generated at 2022-06-21 15:38:01.312314
# Unit test for function romanize
def test_romanize():
    romanized_text = romanize('ru')(lambda: 'привет')
    assert romanized_text() == 'privet'

    romanized_text = romanize('uk')(lambda: 'привіт')
    assert romanized_text() == 'pryvit'

    romanized_text = romanize('kk')(lambda: 'Сәлем')
    assert romanized_text() == 'Salem'

# Generated at 2022-06-21 15:38:03.424880
# Unit test for function romanize
def test_romanize():
    cyr = u'Я пришел'
    assert romanize()(lambda: cyr)() == 'Ya prishel'

# Generated at 2022-06-21 15:38:06.561651
# Unit test for function romanize
def test_romanize():
    translate = romanize(locale='ru')

    @translate
    def return_hi():
        return 'Привет'

    assert return_hi() == 'Privet'



# Generated at 2022-06-21 15:38:09.597411
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Паша')() == 'Pasha'
    assert romanized(locale='uk')(lambda: 'Катя')() == 'Katya'

# Generated at 2022-06-21 15:38:10.172999
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-21 15:38:45.759997
# Unit test for function romanize
def test_romanize():
    def f(x: str) -> str: return x

    r = romanize('ru')(f)
    assert r('ЙЩЦУКЕН') == 'JSCUKEN'

    r = romanize('ru')(f)
    assert r('ЙЩЦУКЕ₽') == 'JSCUKE₽'

    f = romanize('ru')(f)
    assert f('ЙЩЦУКЕ₽') == 'JSCUKE₽'

    f = romanize('uk')(f)
    assert f('ЙЩЦУКЕ₽') == 'ЙЩЦУКЕ₽'

# Generated at 2022-06-21 15:38:48.812307
# Unit test for function romanize
def test_romanize():
    """Test that romanized text is romanized using the romanize decorator."""
    @romanize()
    def get_name():
        return 'Марина'

    assert get_name() == 'Marina'



# Generated at 2022-06-21 15:38:55.905483
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def get_rom_ru():
        return 'Привет, мир!'

    assert get_rom_ru() == 'Privet, mir!'

    @romanized('uk')
    def get_rom_uk():
        return 'Привіт, світ!'

    assert get_rom_uk() == 'Pryvit, svit!'

    @romanized('kk')
    def get_rom_kk():
        return 'Сәлем, әлем!'

    assert get_rom_kk() == 'Salem, älem!'

# Generated at 2022-06-21 15:38:57.366697
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize():
        return 'Привет'

    assert romanize() == 'Privet'

# Generated at 2022-06-21 15:39:00.682063
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test():
        return 'Русский текст'

    assert test() == 'Russkiy tekst'



# Generated at 2022-06-21 15:39:03.704990
# Unit test for function romanize
def test_romanize():
    assert all(x.islower() for x in romanize()(lambda: 'Слово')())
    assert all(x.islower() for x in romanized('ru')(lambda: 'Слово')())

# Generated at 2022-06-21 15:39:11.443450
# Unit test for function romanize
def test_romanize():
    from mimesis import Generic
    from mimesis.enums import Language
    from mimesis import data

    g = Generic(Language.ENGLISH)

    roman = romanize(g.random.choice(data.LOCALES))

    @roman
    def sentence():
        return g.word.word()

    @roman
    def sentence_with_non_latin_symbols():
        return g.code.hash(length=4)

    for _ in range(15):
        assert sentence()
        assert sentence_with_non_latin_symbols()

# Generated at 2022-06-21 15:39:21.894187
# Unit test for function romanize
def test_romanize():
    """Test the romanization of text."""
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    # WARNING: if you want to test the function, be careful with
    # the romanization of the cyrillic alphabet. From the modern
    # point of view, it is not proper transliteration.
    t = Text(Language.RUSSIAN)
    assert t.romanized(locale='ru') == t.romanize(locale='ru')
    assert t.romanized(locale='uk') == t.romanize(locale='uk')
    assert t.romanized(locale='kk') == t.romanize(locale='kk')

# Generated at 2022-06-21 15:39:26.217516
# Unit test for function romanize
def test_romanize():
    result = romanize()(lambda x: 'Привет, Как дела?')
    assert result == 'Privet, Kak dela?'

    result = romanize()(lambda x: '我是中国人')
    assert result == '我是中国人'

# Generated at 2022-06-21 15:39:29.876976
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    example = "Тестовый словарь русский"
    expected = "Testovyj slovar' russkij"
    assert romanize('ru')(lambda x: example)() == expected

# Generated at 2022-06-21 15:40:21.006093
# Unit test for function romanize
def test_romanize():
    print(romanized(locale='ru')(lambda: 'Съешь еще этих мягких французских булок'))
    print(romanize(locale='uk')(lambda: 'Вийшла паня з Венесуели'))
    print(romanize(locale='kk')(lambda: 'Біз бұл елдердің келетін елдері'))


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:40:30.484152
# Unit test for function romanize
def test_romanize():
  from mimesis.enums import Locale
  from mimesis.builtins.ether import Ether
  from mimesis.builtins.person import Person

  ether = Ether(Locale.UK)
  person = Person(Locale.UK)
  result = ether.full_text().romanized()
  assert result == ether.full_text()
  assert result == ether.full_text().romanized()

  result = person.full_name().romanized()
  assert result == person.full_name()
  assert result == person.full_name().romanized()

# Generated at 2022-06-21 15:40:31.565086
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'hello')() == 'привет'

# Generated at 2022-06-21 15:40:37.011711
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'я')() == 'ya'
    assert romanize('uk')(lambda: 'я')() == 'ya'
    assert romanize('kk')(lambda: 'я')() == 'ya'



# Generated at 2022-06-21 15:40:38.747298
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(_romanize_helper)('Привет') == 'Privet'



# Generated at 2022-06-21 15:40:46.900080
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "Я ем блины")() == "YA YEM BLINY"
    assert romanize('ru')(lambda: "Я ем блины")() == "YA YEM BLINY"
    assert romanize('ru')(lambda: "Впрочем, что бы ни было")() == "VPROKHEM, CHTO BY NI BYLO"
    assert romanize('ru')(lambda: "Черт, что ты видишь?")() == "CHERT, CHTO TY VIDISH'?"

# Generated at 2022-06-21 15:40:55.567925
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'
    assert romanize('kk')(lambda: 'Сәлем, свет!')() == 'Sälem, svet!'

# Generated at 2022-06-21 15:40:59.846435
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Спасибо что выбрали нас!')() == 'Spasibo chto vybrali nas!'
    assert romanize(locale='kk')(lambda: 'Білімді бескерісізді басқару және оқуға арналған')() == \
           'Bilimdi beskerisiz baskaru zheno okugha arnalghan'



# Generated at 2022-06-21 15:41:01.346710
# Unit test for function romanize
def test_romanize():
    assert Romanization().romanize("Киев") == "Kiev"



# Generated at 2022-06-21 15:41:05.258549
# Unit test for function romanize
def test_romanize():
    assert __name__ == 'tests.test_utils.test_decorators'
    assert romanize.__name__ == 'romanize'
    assert romanized.__name__ == 'romanize'

# Generated at 2022-06-21 15:43:28.568644
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    from mimesis.providers import Person

    p = Person(RussianSpecProvider())
    assert p.full_name() == 'Иван Сергеевич Иванов'
    name = p.full_name(romanized=True)
    assert any([i in name for i in ('Ivan', 'Ivanovich', 'Ivanov')]), \
        'Not romanized!'

# Generated at 2022-06-21 15:43:31.192499
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'hello')() == 'привет'

if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-21 15:43:43.252563
# Unit test for function romanize
def test_romanize():
    r = romanize()
    def roman(text):
        return r(lambda text: text)(text)
    assert roman('Привет') == 'Privyet'
    assert roman('Hello') == 'Hello'
    assert roman('Привет') == 'Privyet'
    assert roman('Hello') == 'Hello'
    assert roman('Привет') == 'Privyet'
    assert roman('Hello') == 'Hello'
    assert roman('Привет') == 'Privyet'
    assert roman('Hello') == 'Hello'
    assert roman('Привет') == 'Privyet'
    assert roman('Hello') == 'Hello'

# Generated at 2022-06-21 15:43:53.365377
# Unit test for function romanize
def test_romanize():
    # type: () -> None
    from mimesis.enums import Language

    def do_test(language):  # type: (str) -> None
        # type: (...) -> None
        @romanize(language)
        def roman():
            # type: () -> str
            return 'Тимофей'

        assert roman() == 'Timofey'

    do_test(Language.RUSSIAN)
    do_test(Language.ENGLISH)
    do_test(Language.KAZAKH)

# Generated at 2022-06-21 15:43:56.192103
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    t = Text('en')

    assert t.romanize() == t.romanized()
    assert t.romanize() == t.romanized()
    assert t.romanize('ru') == t.romanized('ru')
    assert t.romanize('ru') == t.romanized('ru')

# Generated at 2022-06-21 15:43:58.774704
# Unit test for function romanize
def test_romanize():
    text = ""
    assert romanize('ru')(text)('ru') == text



# Generated at 2022-06-21 15:43:59.774736
# Unit test for function romanize
def test_romanize():
    """Test romanization."""



# Generated at 2022-06-21 15:44:04.944368
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_func():
        return 'Основы классической музыки СССР'

    assert test_func() == 'Osnovy klassicheskoj muzyki SSSR'



# Generated at 2022-06-21 15:44:07.493894
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def id(self):
        return 'Му'

    result = id(None)
    assert result == 'Mu'

# Generated at 2022-06-21 15:44:16.136738
# Unit test for function romanize
def test_romanize():
    russian_alphabet = data.ROMANIZATION_DICT['ru']
    ukranian_alphabet = data.ROMANIZATION_DICT['uk']
    kazah_alphabet = data.ROMANIZATION_DICT['kk']
    common_alphabet = data.COMMON_LETTERS

    @romanize(locale='ru')
    def rus_romanize(s):
        return s

    @romanize(locale='uk')
    def ukr_romanize(s):
        return s

    @romanize(locale='kk')
    def kaz_romanize(s):
        return s

    assert rus_romanize('привет') == 'privet'