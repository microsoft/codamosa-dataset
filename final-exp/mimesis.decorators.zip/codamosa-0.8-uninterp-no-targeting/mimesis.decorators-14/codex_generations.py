

# Generated at 2022-06-21 15:35:07.920450
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize()('test') == 'test'
    assert romanize('ru')('тест') == 'test'
    assert romanize('ru')('Тест') == 'Test'
    assert romanize('uk')('тест') == 'test'
    assert romanize('uk')('Тест') == 'Test'
    assert romanize('kk')('тест') == 'test'
    assert romanize('kk')('Тест') == 'Test'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:35:19.157577
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def ru():
        return 'Это просто тест романизации'

    assert ru() == "E'to prosto test romanizatsii"

    @romanize('uk')
    def uk():
        return 'Це просто тест романізації'

    assert uk() == "Ce prosto test romanizatsii"

    @romanize('kk')
    def kk():
        return 'Бұл жетекшілік тесті'

    assert kk() == "Bul zhetekşilik testi"

# Generated at 2022-06-21 15:35:22.537318
# Unit test for function romanize
def test_romanize():
    from re import search

    @romanize(locale='ru')
    def get_string():
        return 'Привет!'

    assert search(r'Привет!', get_string()) is None


test_romanize()

# Generated at 2022-06-21 15:35:30.024790
# Unit test for function romanize
def test_romanize():
    """Test romanize"""

# Generated at 2022-06-21 15:35:30.869645
# Unit test for function romanize
def test_romanize():
    result = romanized('ru')
    assert result == 'romanized'

# Generated at 2022-06-21 15:35:35.462137
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def generator():
        return "Любая цифра в строке: 4; символ: '.'"
    assert generator() == "Lyubaya tsifra v stroke: 4; simvol: '.'"



# Generated at 2022-06-21 15:35:39.537591
# Unit test for function romanize
def test_romanize():
    import mimesis
    r = mimesis.Cryptographic()
    assert r.romanize('государственный гимн Российской Федерации') == 'gosudarstvennyy gimn Rossiyskoy Federatsii'



# Generated at 2022-06-21 15:35:40.618405
# Unit test for function romanize
def test_romanize():
    # TODO
    pass

# Generated at 2022-06-21 15:35:44.580443
# Unit test for function romanize
def test_romanize():
    def test(name):
        @romanize('ru')
        def r_name():
            return name()
        return r_name

    # 'str' object not callable
    # -> function should not raise TypeError
    r_name = test('name')
    assert r_name() == 'name'

# Generated at 2022-06-21 15:35:45.088212
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-21 15:35:52.744326
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Address
    a = Address()
    txt = a.country_code(lang='ru')
    assert txt == 'rus'

# Generated at 2022-06-21 15:35:53.724289
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Как дела?') == 'Kak dela?'



# Generated at 2022-06-21 15:35:58.160901
# Unit test for function romanize
def test_romanize():
    func = romanize('ru')
    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT['ru'],
        **data.COMMON_LETTERS,
    })
    assert (func('Алексей') == ''.join([alphabet[i] for i in
                                        'Алексей' if i in alphabet])) == 'Aleksey'
    assert func.__name__ == 'romanize_deco'

# Generated at 2022-06-21 15:36:06.890408
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'ab') == 'ab'
    assert romanize('uk')(lambda: 'ab') == 'ab'
    assert romanize('kk')(lambda: 'ab') == 'ab'
    assert romanize('ru')(lambda: 'Здравствуйте') == 'Zdravstvuyte'
    assert romanize('uk')(lambda: 'hello') == 'hello'
    assert romanize('kk')(lambda: 'hello') == 'hello'

# Generated at 2022-06-21 15:36:12.531902
# Unit test for function romanize
def test_romanize():
    assert is_lang == 'ru'
    res = a.text.title()
    assert res == 'Привет'
    assert is_lang == 'ru'
    res = a.text.title(romanize=True)
    assert res == 'Privet'
    assert is_lang == 'ru'
    res = a.text.title(romanized=True)
    assert res == 'Privet'
    assert is_lang == 'ru'
    res = a.text.sentence(romanized=True)
    assert res == 'Привет'
    assert is_lang == 'ru'
    res = a.text.sentence(romanize=True)
    assert res == 'Privet'
    assert is_lang == 'ru'

# Generated at 2022-06-21 15:36:18.579139
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def dummy_func(b: bool = False) -> str:
        if b:
            return 'Привет, мир!'
        return 'Спокойной ночи!'

    assert dummy_func() == 'Spokoinoi nochi!'
    assert dummy_func(True) == 'Privet, mir!'

# Generated at 2022-06-21 15:36:21.201303
# Unit test for function romanize
def test_romanize():
    """Test romanization"""
    assert romanize()('привет сергей') == 'privyet sergey'

# Generated at 2022-06-21 15:36:22.815386
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize()(lambda *args, **kwargs: 'test'), Callable)

# Generated at 2022-06-21 15:36:26.296381
# Unit test for function romanize
def test_romanize():
    cyrillic_name = 'Антон Павлович Чехов'
    romanized_name = 'Anton Pavlovich Chekhov'
    assert romanized_name == romanize('ru')(lambda: cyrillic_name)()

# Generated at 2022-06-21 15:36:38.034559
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(chr)(1072) == 'а'
    assert romanize('ru')(chr)(1073) == 'б'
    assert romanize('ru')(chr)(8361) == 'ё'

    assert romanize('uk')(chr)(1072) == 'а'
    assert romanize('uk')(chr)(1073) == 'б'
    assert romanize('uk')(chr)(8361) == 'ё'

    assert romanize('kk')(chr)(1072) == 'а'
    assert romanize('kk')(chr)(1073) == 'б'
    assert romanize('kk')(chr)(8361) == 'ё'

# Generated at 2022-06-21 15:36:51.936682
# Unit test for function romanize
def test_romanize():
    """Test for the function "romanize"."""
    assert 'привет мир' == romanize('ru')(lambda: 'privet mir')

# Generated at 2022-06-21 15:36:56.969329
# Unit test for function romanize
def test_romanize():
    assert 'Hello world' == romanize('en')(lambda: 'Привет мир')()
    assert 'Hello world' == romanized('en')(lambda: 'Привет мир')()

# Generated at 2022-06-21 15:37:08.051003
# Unit test for function romanize
def test_romanize():
    def test_fn(word):
        if word == 'русский':
            return 'russkiy'
        if word == 'Русский':
            return 'Russkiy'
        if word == 'Hello':
            return 'Hello'
        if word == 'hello':
            return 'hello'
        if word == 'Привет':
            return 'Privet'
        if word == 'день':
            return 'den'
        if word == 'дней':
            return 'dney'

    assert test_fn('Привет') == 'Privet'
    assert test_fn('привет') == 'privet'
    assert test_fn('день') == 'den'

# Generated at 2022-06-21 15:37:14.479577
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світе!')() == 'Pryvit, svite!'
    assert romanize('kk')(lambda: 'Сәлем, Әлем!')() == 'Sälem, Älem!'

# Generated at 2022-06-21 15:37:23.501433
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')(
        lambda: 'test',
    )() == 'test'
    assert romanize('ru')(
        lambda: 'ру́сский',
    )() == 'russkii'
    assert romanize('uk')(
        lambda: 'Російська корона',
    )() == 'Rosijska korona'

# Generated at 2022-06-21 15:37:34.200389
# Unit test for function romanize
def test_romanize():
    # Transliteration Russian
    @romanize(locale='ru')
    def russian():
        return 'Строка для транслитерации'

    assert russian() == 'StrOKa dlya transliteratsii'

    # Transliteration Ukrainian
    @romanize(locale='uk')
    def ukrainian():
        return 'Строка для транслитерациї'

    assert ukrainian() == 'StrOKa dlya transliteratsii'

    # Transliteration Kazakh

# Generated at 2022-06-21 15:37:36.865966
# Unit test for function romanize
def test_romanize():
    romanized_token = romanize(locale='ru')(lambda : 'привет')
    assert romanized_token() == 'privet'

# Generated at 2022-06-21 15:37:46.833931
# Unit test for function romanize
def test_romanize():
    from mimesis.data import CYRILLIC_ALPHABET

    @romanize()
    def gen_cyrillic_text(func, limit=10, provider=None) -> str:
        return func(limit=limit, characters=CYRILLIC_ALPHABET,
                    provider=provider)

    assert all(c in CYRILLIC_ALPHABET for c in gen_cyrillic_text())
    # Test for ukrainian and kazakh languages.
    # Test for the string with a space at the beginning.
    text = ' стрічка з пробілами'
    assert gen_cyrillic_text(locale='uk').startswith(' strichka')

# Generated at 2022-06-21 15:37:55.933652
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda *args, **kwargs: 'привет')() == 'privet'
    assert romanize('uk')(lambda *args, **kwargs: 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda *args, **kwargs: 'сәлем')() == 'sälem'
    assert romanize('ua')(lambda *args, **kwargs: 'привіт')() == 'pryvit'

# Generated at 2022-06-21 15:37:59.052872
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize()('Привiт') == 'Privyt'
    assert romanize()('Мир Вам!') == 'Mir Vam!'
    assert romanize()('Як справи?') == 'Yak spravy?'



# Generated at 2022-06-21 15:38:31.346943
# Unit test for function romanize
def test_romanize():
    def inner(s: str) -> str:
        return s

    @romanized('ru')
    def outer(s: str) -> str:
        return s

    assert inner('Лорем ипсум долор сит амет') == \
           'Лорем ипсум долор сит амет'
    assert outer('Лорем ипсум долор сит амет') == \
           'Lorem ipsum dolor sit amet'

# Generated at 2022-06-21 15:38:41.452547
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize(locale='uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanize(locale='kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'
    try:
        romanize(locale='en')(lambda: 'Hello, world!')()
    except UnsupportedLocale as e:
        assert str

# Generated at 2022-06-21 15:38:42.929908
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-21 15:38:44.808600
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-21 15:38:47.374189
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')().lower() == 'privet'
    assert romanize('uk')(lambda: 'Привіт')().lower() == 'privit'
    assert romanize('kk')(lambda: 'Сәлем')().lower() == 'salem'

# Generated at 2022-06-21 15:38:51.069519
# Unit test for function romanize
def test_romanize():
    assert 'abc' == romanize()(lambda: 'абв')
    assert 'a b c' == romanize()(lambda: 'а б в')
    assert romanize()(lambda: 'абв') == romanized()(lambda: 'абв')

# Generated at 2022-06-21 15:38:51.719619
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-21 15:38:57.206576
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT[locale],
        **data.COMMON_LETTERS,
    })
    test_data = ''.join(alphabet.keys())
    expected_result = ''.join(alphabet.values())

    @romanize(locale)
    def romanize_test(test_data):
        return test_data
    assert romanize_test(test_data) == expected_result

# Generated at 2022-06-21 15:39:01.208992
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus():
        return 'Да раньше придыхать было.'

    assert rus() == "Da ran'she pridyhat' bylo."

# Generated at 2022-06-21 15:39:04.767471
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Как стать брендом?'

    assert foo() == 'Kak stat\' brendom?'



# Generated at 2022-06-21 15:39:52.374981
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def f():
        return 'Привет'

    assert f() == 'Privet'

# Generated at 2022-06-21 15:39:55.091815
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Я думаю, значит я')() == 'Ja dumaju, znachit ja'

# Generated at 2022-06-21 15:40:00.105572
# Unit test for function romanize
def test_romanize():
    check = romanize('ru')

    @check
    def say_hello() -> str:
        return 'Привет, как дела'

    assert say_hello() == 'Privet, kak dela'

    @check
    def my_name() -> str:
        return 'Александр'

    assert my_name() == 'Aleksandr'



# Generated at 2022-06-21 15:40:02.653613
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_test(txt):
        return txt

    assert romanize_test('Тест') == 'Test'

# Generated at 2022-06-21 15:40:04.686039
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def f():
        return 'Привет'

    assert f() == 'Privet'

# Generated at 2022-06-21 15:40:12.823098
# Unit test for function romanize
def test_romanize():
    def romanize_for_test(locale: str = '') -> Callable:
        @romanize(locale=locale)
        def _romanize_for_test(self):
            return "Мама мыла раму"
    assert romanize_for_test(locale="ru")().strip() == 'Mama myla ramu'
    assert romanize_for_test(locale="uk")().strip() == 'Mama myla ramu'
    assert romanize_for_test(locale="kk")().strip() == 'Mama myla ramu'

# Generated at 2022-06-21 15:40:20.445620
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanized():
        return 'русский язык'

    assert romanized() == 'russkiy yazyk'

    try:
        @romanize(locale='de')
        def romanized():
            return 'не понятно'

        assert romanized() == 'ne poniatno'

        # You should never see this
        assert True == False
    except UnsupportedLocale:
        pass
    else:
        raise RuntimeError('Пример должен вызвать исключение.')

# Generated at 2022-06-21 15:40:30.226953
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import TextCode

    text = TextCode('ru')
    assert text.hashcode() == text.hashcode(romanized='ru')
    assert text.hashcode().replace('.', '#') == \
        text.hashcode(romanized='ru', replace=('.', '#'))
    assert text.hashcode().replace('.', '*') == \
        text.hashcode(romanized='ru', replace=('.', '*'))
    assert text.hashcode(romanized='ru', case='lower') == \
        text.hashcode(lowercase=True, romanized='ru')

# Generated at 2022-06-21 15:40:36.377312
# Unit test for function romanize
def test_romanize():
    txt = 'красивый и лёгкий компонент для генерации данных с русского'
    assert isinstance(romanize(locale='ru')(lambda x: txt)(), str)
    assert romanize(locale='ru')(lambda x: txt)() == 'krasivyj i legkij komponent'\
        ' dlja generacii dannyh s russkogo'


# Generated at 2022-06-21 15:40:45.271471
# Unit test for function romanize
def test_romanize():
    # romanize should work without problems
    @romanize()
    def foo():
        return 'тест'
    assert foo() == 'test'

    @romanize('ru')
    def foo():
        return 'тест'
    assert foo() == 'test'

    @romanize('uk')
    def foo():
        return 'тест'
    assert foo() == 'test'

    @romanize('kk')
    def foo():
        return 'тест'
    assert foo() == 'test'

    # romanize should raise UnsupportedLocale for unknown locales
    @romanize('bar')
    def foo():
        return 'тест'
    try:
        foo()
    except UnsupportedLocale:
        assert True
    else:
        assert False

   

# Generated at 2022-06-21 15:43:15.381721
# Unit test for function romanize
def test_romanize():
    # Test without decorator
    assert 'Hello, world!' == romanize()(lambda: 'Hello, world!')

    # Test with decorator
    @romanize()
    def fake_text():
        return 'Hello, world!'

    assert 'Hello, world!' == fake_text()


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:43:24.910454
# Unit test for function romanize
def test_romanize():
    """Test for ``romanize``."""
    assert romanized(locale='ru')(lambda x: 'Привет, мир!')() == 'Privet, mir!'
    assert romanized(locale='ru')(lambda x: 'Hello, world!')() == 'Hello, world!'
    assert romanized(locale='uk')(lambda x: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanized(locale='uk')(lambda x: 'Привет, мир!')() == 'Privet, mir!'
    assert romanized(locale='kk')(lambda x: 'Сәлем, дүние!')()

# Generated at 2022-06-21 15:43:26.726025
# Unit test for function romanize
def test_romanize():
    assert romanize('ru_RU')('Здравствуйте!') == "Zdravstvuyte!"

# Generated at 2022-06-21 15:43:29.023471
# Unit test for function romanize
def test_romanize():
    assert data.ROMANIZATION_DICT['ru']['Ы'] == 'Y'



# Generated at 2022-06-21 15:43:35.982661
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as P

    p = P(RussianSpecProvider, locale='ru', gender=Gender.MALE)
    assert p.data_class.gender == Gender.MALE
    assert p.name(patronymic=True) == 'Альберт Степанович Балдин'

# Generated at 2022-06-21 15:43:39.894048
# Unit test for function romanize
def test_romanize():
    """Test functionality of Romanize."""
    @romanize('ru')
    def something():
        return "Привет мир"

    assert something() == "Privet mir"

# Generated at 2022-06-21 15:43:44.275452
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanizer(text: str) -> str:
        return text

    assert romanizer('Как дела? Всё хорошо!') == 'Kak dela? Vsyo khorosho!'

# Generated at 2022-06-21 15:43:53.365368
# Unit test for function romanize
def test_romanize():
    """Romanize the cyrillic text."""
    assert romanize()(lambda x: 'Самара')(locale='ru') == 'Samara'
    assert romanize()(lambda x: 'Самара')(locale='uk') == 'Samara'
    assert romanize()(lambda x: 'Самара')(locale='kk') == 'Samara'
    assert romanize()(lambda x: 'Самара')(locale='en') == 'Самара'

# Generated at 2022-06-21 15:43:56.168977
# Unit test for function romanize
def test_romanize():
    assert romanized()("a") == "a"
    assert romanized("ru")("Я") == "Ya"
    assert romanized("kk")("Ө") == "Ö"
    assert romanized("uk")("Я") == "Ya"

# Generated at 2022-06-21 15:44:07.866872
# Unit test for function romanize
def test_romanize():
    def foo(locale: str = '') -> str:
        return locale

    result = foo()
    assert result == '', 'It must return empty string'

    @romanize()
    def foo(locale: str = '') -> str:
        return locale

    result = foo()
    assert result == '', 'It must return empty string'

    @romanize('ru')
    def foo(locale: str = 'ru') -> str:
        return locale

    result = foo()
    assert result == 'ru', 'It must return "ru"'

    @romanize('ru')
    def foo(locale: str = 'uk') -> str:
        return locale

    result = foo()
    assert result == 'uk', 'It must return "uk"'
