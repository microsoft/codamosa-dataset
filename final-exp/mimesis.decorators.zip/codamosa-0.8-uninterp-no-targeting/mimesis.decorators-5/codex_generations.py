

# Generated at 2022-06-21 15:35:07.082864
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    t = Text(Language.UK)
    r = t.word(romanize=True)
    assert len(r) > 0
    assert isinstance(r, str)

# Generated at 2022-06-21 15:35:11.998292
# Unit test for function romanize
def test_romanize():
    """Test for the romanize function."""

    @romanize('ru')
    def test_romanize_ru(exclude_letters=''):
        """Test Cyrillic string."""
        return 'Лол'

    assert test_romanize_ru() == 'Lol'

# Generated at 2022-06-21 15:35:13.823283
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Строка')() == 'Stroka'

# Generated at 2022-06-21 15:35:20.096343
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    person = Person('ru')
    assert person._romanize('Строительство') == 'Stroitelstvo'
    assert person.full_name() == 'Строительство Строительство'
    assert person.full_ext_name() == 'Петров Строительство'

# Generated at 2022-06-21 15:35:21.724875
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Текст')() == 'Tekst'

# Generated at 2022-06-21 15:35:24.137444
# Unit test for function romanize
def test_romanize():
    @romanize
    def f(x):
        return x

    ans = f('привет')
    assert ans == 'privet', 'romanize() failed!'

# Generated at 2022-06-21 15:35:26.516234
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'тест')() == 'test'



# Generated at 2022-06-21 15:35:30.515017
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "Москва Россия")() == 'Moskva Rossiya'



# Generated at 2022-06-21 15:35:34.042113
# Unit test for function romanize
def test_romanize():
    """Romanize is Романизация for ru locale."""
    assert romanize('ru')(str)('Романизация') == 'Romanizatsiya'

# Generated at 2022-06-21 15:35:36.356679
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, как дела?')() == 'Privet, kak dela?'

# Generated at 2022-06-21 15:35:46.358203
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Здравствуйте')() == 'Zdravstvujte'
    assert romanized('uk')(lambda: 'Доброго дня')() == 'Dobroho dnja'
    assert romanized('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-21 15:35:50.658064
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    person = Person()
    assert person.full_name('ru') == person.full_name('ru')
    assert person.full_name('uk') == person.full_name('uk')

    # Check if the function is not supported
    try:
        person.full_name('lv')
    except UnsupportedLocale:
        assert True

# Generated at 2022-06-21 15:35:52.576621
# Unit test for function romanize
def test_romanize():
    text = "Всем привет!"
    assert romanized()(text) == "Vsem privet!"

# Generated at 2022-06-21 15:35:56.069485
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    text = Text(lang=Language.RUSSIAN)

    def test():
        return text.word()

    r = romanize('ru')

    assert test() == r(test)()

# Generated at 2022-06-21 15:36:02.368313
# Unit test for function romanize
def test_romanize():
    from random import random

    class Romanizer:
        @romanize(locale='ru')
        def romanize_ru(self, text: str) -> str:
            return text

        @romanize(locale='uk')
        def romanize_uk(self, text: str) -> str:
            return text

        @romanize(locale='kk')
        def romanize_kk(self, text: str) -> str:
            return text

    r = Romanizer()

# Generated at 2022-06-21 15:36:09.813097
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""

    r = romanize()
    assert callable(r)
    assert romanize.__doc__ is not None
    assert romanize.__doc__ != ''
    r = romanize('ru')
    assert callable(r)

    @r
    def foo():
        return 'Козацький гетьманський уряд'

    assert foo() == 'Kozatskyy hetmanskyy uryad'

# Generated at 2022-06-21 15:36:11.565405
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize('ru')
    assert romanized('ru')

# Generated at 2022-06-21 15:36:18.436300
# Unit test for function romanize
def test_romanize():
    """Test for romanized decorator."""
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    romanized_person = romanize(locale=Locale.RU)
    person = Person(locale=Locale.RU)

    assert 'grigoriy' in romanized_person(person.full_name)
    assert 'nikolaevich' in romanized_person(person.full_name)

# Generated at 2022-06-21 15:36:21.454308
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    text = Text(locale='ru')
    result = text.romanize()

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:36:27.702872
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet

    p = Person('ru')
    i = Internet('ru')
    p.seed(1)
    i.seed(1)
    assert p.full_name(Gender.FEMALE) == 'Варвара Павловна Просвирнина'
    assert i.username == 'СтепановВасилий'

# Generated at 2022-06-21 15:36:42.796084
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def mock(pattern):
        return pattern

    ru = mock('тест')

    assert ru == 'test'
    assert ru != mock('test')

    @romanize(locale='uk')
    def mock(pattern):
        return pattern

    uk = mock('тест')

    assert uk == 'test'
    assert uk != mock('test')

    @romanize(locale='kk')
    def mock(pattern):
        return pattern

    kk = mock('тест')

    assert kk == 'test'
    assert kk != mock('test')

    @romanize(locale='asd')
    def mock(pattern):
        return pattern

    kk = mock('тест')


# Generated at 2022-06-21 15:36:45.228444
# Unit test for function romanize
def test_romanize():
    assert '����' == romanize()(lambda: 'Філіп')

# Generated at 2022-06-21 15:36:45.965017
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:36:47.711280
# Unit test for function romanize
def test_romanize():
    """Test that romanize just pass the text through."""
    pass

# Generated at 2022-06-21 15:36:54.497023
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers import Address

    address = Address(locale=Locale.ENGLISH)
    assert ''.join(address.city(with_state=True).split()) == 'Pinkshire'
    assert address.city(locale=Locale.RUSSIAN, with_state=True).strip().title() == \
        'Moskva'
    assert address.city(locale=Locale.UKRAINIAN, with_state=True).strip().title() == \
        'Kiyv'

# Generated at 2022-06-21 15:36:56.203817
# Unit test for function romanize
def test_romanize():
    assert romanize
    assert romanized

# Generated at 2022-06-21 15:37:01.680948
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    from .numbers import Number

    r = Number(Locale.ENGLISH)
    romanized_text = romanize('ru')(r.integral)
    romanized_text_2 = romanize('uk')(r.integral)
    assert romanized_text.isascii()
    assert romanized_text_2.isascii()

# Generated at 2022-06-21 15:37:03.957975
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')
    assert romanize('us') is None

# Generated at 2022-06-21 15:37:04.908630
# Unit test for function romanize
def test_romanize():
    assert romanize()('привет') == 'privet'

# Generated at 2022-06-21 15:37:08.936475
# Unit test for function romanize
def test_romanize():
    @romanize()
    def info():
        return u'ул. Уолл-стрит, д. 7'

    assert info() == u'ul. Wall-strit, d. 7'



# Generated at 2022-06-21 15:37:17.622926
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    p = Person('ru')
    assert p.romanized.full_name() == p.romanize.full_name()

# Generated at 2022-06-21 15:37:22.958141
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda x: 'привет')()
    assert result == 'privet'

    result = romanize('uk')(lambda x: 'привіт')()
    assert result == 'pryvit'

    result = romanize('kk')(lambda x: 'сәлем')()
    assert result == 'sälem'

# Generated at 2022-06-21 15:37:25.297882
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Тест") == "Test"
    assert romanize("ru")("Тест123") == "Test123"

# Generated at 2022-06-21 15:37:25.870152
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:37:31.002392
# Unit test for function romanize
def test_romanize():
    result = {"romanize": False, "romanized": False}
    for item in result:
        for locale in ('ru', 'uk', 'kk'):
            @eval(item)(locale=locale)
            def test():
                return "Привіт"
            result[item] = test()
            assert result[item] == "Pryvit"

# Generated at 2022-06-21 15:37:38.489453
# Unit test for function romanize
def test_romanize():
    # pylint: disable=unused-variable

    @romanize(locale='ru')
    def get_alpha_ru(self):
        return self._get_chars(self._random.random)

    @romanize(locale='uk')
    def get_alpha_uk(self):
        return self._get_chars(self._random.random)

    @romanize(locale='kk')
    def get_alpha_kk(self):
        return self._get_chars(self._random.random)



# Generated at 2022-06-21 15:37:40.881548
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_ru(cls):
        cls.__doc__ = 'Romanize Russian text'
        return cls

    @romanize_ru
    class Ru(object):
        def __init__(self):
            pass

        def __repr__(self):
            return '<Romanized Russian object>'

    r = Ru()
    assert r.__doc__ == 'Romanize Russian text'
    assert repr(r) == '<Romanized Russian object>'

# Generated at 2022-06-21 15:37:49.387677
# Unit test for function romanize
def test_romanize():
    arr = [
        'Январь',
        'Февраль',
        'Март',
        'Апрель',
        'Май',
        'Июнь',
        'Июль',
        'Август',
        'Сентябрь',
        'Октябрь',
        'Ноябрь',
        'Декабрь',
    ]

# Generated at 2022-06-21 15:38:00.669774
# Unit test for function romanize
def test_romanize():
    import pytest

    @romanize(locale='ru')
    def func(a='Жак Керуак'):
        return a

    assert func() == 'Zhak Keruak'

    @romanize(locale='uk')
    def func(b='Жак Керуак'):
        return b

    assert func() == 'Zhak Keruak'

    @romanize(locale='kk')
    def func(c='Жак Керуак'):
        return c

    assert func() == 'Jak Kerwak'

    with pytest.raises(UnsupportedLocale) as e:
        @romanize(locale='en')
        def func(d='Жак Керуак'):
            return

# Generated at 2022-06-21 15:38:04.956705
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanized)
    assert callable(romanize('ru'))
    assert callable(romanized('ru'))
    assert callable(romanize('uk'))
    assert callable(romanized('uk'))
    assert callable(romanize('kk'))
    assert callable(romanized('kk'))

# Generated at 2022-06-21 15:38:22.491621
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    text = Text('en')
    assert text.romanize('Привет') == 'Privet'
    assert text.romanize('Проверка перевода') == 'Proverka perevoda'

# Generated at 2022-06-21 15:38:25.735030
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    rus = RussianSpecProvider()

    @romanize(locale='ru')
    def romanize_rus(length, tokens):
        return rus.string(length, tokens)

    assert romanize_rus(10, 10)



# Generated at 2022-06-21 15:38:26.449506
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Тест')() == 'Test'

# Generated at 2022-06-21 15:38:34.227630
# Unit test for function romanize
def test_romanize():
    assert ('Вован вихрює вовічка він в вагоні' ==
            romanize()(lambda: 'Вован вихрює вовічка він в вагоні'))
    assert ('Vovan vihryuie vovichka vin v vahoni' ==
            romanize(locale='uk')(lambda: 'Вован вихрює вовічка він в вагоні'))


romanized_test = romanize

# Generated at 2022-06-21 15:38:38.972686
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Аргентина манит негра') == \
        'Argentina manit negra'



# Generated at 2022-06-21 15:38:41.169417
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text

    text = Text('ru')
    text.full_name()

    text = Text('ru')
    text.full_name()

# Generated at 2022-06-21 15:38:46.217246
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text

    @mimesis.romanize(locale='ru')
    def romanize_test(seed):
        data_generator = mimesis.builtins.text.Text(seed=seed)
        return data_generator.russian_string()

    print(romanize_test(seed=1))
    print(romanize_test(seed=2))


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:38:50.642702
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "Привет")() == 'Privet'
    assert romanize('uk')(lambda: 'Добрий день')() == 'Dobryi den'
    assert romanize('kk')(lambda: "Сәлем")() == 'Sälem'

# Generated at 2022-06-21 15:38:54.447120
# Unit test for function romanize
def test_romanize():
    def romanize_func(text: str) -> str:
        return text

    romanized_func = romanize(locale='ru')(romanize_func)

    expected = 'Boris Pasternak'
    result = romanized_func('Борис Пастернак')
    assert result == expected

# Generated at 2022-06-21 15:38:56.730480
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda: 'Привіт, Друзі!')() == 'Pryvit, Druzi!'



# Generated at 2022-06-21 15:39:31.047870
# Unit test for function romanize
def test_romanize():
    """Test for function romanize
    """
    assert "Hello, World!" == romanize("en")(lambda: "Hello, World!")()
    assert "Привіт, світ!" == romanize("ua")(lambda: "Привіт, світ!")()
    assert "Привет, мир!" == romanize("ru")(lambda: "Привет, мир!")()
    assert "Privet, mir!" == romanize("ru")(lambda: "Привет, мир!")()

# Generated at 2022-06-21 15:39:35.109717
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test(a):
        return a

    assert test('Привет') == 'Privet'

    try:
        @romanize('ko')
        def test(a):
            return a
    except UnsupportedLocale:
        assert True

    try:
        @romanize
        def test(a):
            return a
    except UnsupportedLocale:
        assert True

# Generated at 2022-06-21 15:39:38.169271
# Unit test for function romanize
def test_romanize():
    """Tests romanization of Russian texts.

    Тесты русской романизации текста.
    """
    import mimesis.builtins.text as text
    t = text.Text('ru')
    assert t.romanized(romanize='ru')

# Generated at 2022-06-21 15:39:39.462534
# Unit test for function romanize
def test_romanize():
    assert romanize('fr')(lambda: 'ab')() == 'ab'

# Generated at 2022-06-21 15:39:49.802711
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def roman_ru():
        return 'ФЫВА олдж'

    assert roman_ru() == 'FIVA oldzh'

    @romanized('en')
    def roman_en():
        return 'Лондон'

    assert roman_en() == 'London'

    @romanize('uk')
    def roman_uk():
        return 'Лондон'

    assert roman_uk() == 'London'

    @romanize('kk')
    def roman_kk():
        return 'Лондон'

    assert roman_kk() == 'London'


# Generated at 2022-06-21 15:39:53.496907
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda : 'abаc')() == 'abac'
    assert romanize()(lambda : 'yiіїийюя')() == 'yiіїийюя'

# Generated at 2022-06-21 15:40:01.629280
# Unit test for function romanize
def test_romanize():
    import pytest

    def romanize_func(input_str: str = '') -> str:
        return input_str

    Romanized = romanize('ru')(romanize_func)

    result = Romanized(u'ё')
    assert result == 'yo'

    result = Romanized(u'Ё')
    assert result == 'Yo'

    result = Romanized(u'ФЫВА')
    assert result == 'FYVA'

    result = Romanized('Выполняется повторная регистрация приложения')
    assert result == 'Vypolniaetsia povtornaia registratsiia prilozheniia'



# Generated at 2022-06-21 15:40:06.932552
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привет')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-21 15:40:15.084864
# Unit test for function romanize
def test_romanize():
    assert romanized()("Привет, друг") == romanize()("Привет, друг")
    assert not romanized()("Привет, друг") == romanized("ru")("Привет, друг")
    assert romanized("uk")("Привет, друг") == romanized("ru")("Привет, друг")

# Generated at 2022-06-21 15:40:19.030451
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Тест')() == 'Test'
    assert romanized('uk')(lambda: 'Тест')() == 'Test'
    assert romanized('kk')(lambda: 'Тест')() == 'Test'

# Generated at 2022-06-21 15:41:28.725482
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Привет мир!'
    assert foo() == 'Privet mir!'

# Generated at 2022-06-21 15:41:29.487935
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    pass


# Generated at 2022-06-21 15:41:32.245230
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'privet'
    assert romanize('ru')(lambda: 'Привет')() == 'privet'
    assert romanize('uk')(lambda: 'Привет')() == 'privet'
    assert romanize('kk')(lambda: 'Привет')() == 'privet'



# Generated at 2022-06-21 15:41:33.046818
# Unit test for function romanize
def test_romanize():
    print(romanize())

# Generated at 2022-06-21 15:41:35.452113
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Россия')() == 'Rossiya'



# Generated at 2022-06-21 15:41:50.204836
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    text_ru = Text(Locale.RUSSIAN)
    text_uk = Text(Locale.UKRAINIAN)
    text_kk = Text(Locale.KAZAKH)

    assert isinstance(text_ru.romanize('Съешь ещё этих мягких французских булок да выпей чаю!'), str)

# Generated at 2022-06-21 15:41:54.218084
# Unit test for function romanize
def test_romanize():
    test_dict = {
        'ru': 'Здравствуйте.',
        'kk': 'Сәлем дүкендер!',
        'ua': 'Привітання.',

    }
    for locale, phrase in test_dict.items():
        assert romanize(locale)(lambda: phrase)() == phrase



# Generated at 2022-06-21 15:41:58.756392
# Unit test for function romanize
def test_romanize():
    import time
    t=time.time()

    @romanized()
    def foo(*args):
        return 'Привет! Как дела? Это не работает!'

    print(time.time()-t)
    print(foo())

if __name__=='__main__':
    test_romanize()

# Generated at 2022-06-21 15:42:00.824602
# Unit test for function romanize
def test_romanize():
    """Unit test function."""
    def wrapper(*args, **kwargs):
        return 'Привет'

    func = romanize()(wrapper)
    func()

# Generated at 2022-06-21 15:42:02.248227
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-21 15:44:01.917793
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def roman():
        return 'Привет, Мир!'

    assert roman() == 'Privet, Mir!'



# Generated at 2022-06-21 15:44:12.003446
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.misc import Misc
    from mimesis.typing import Seed
    m = Misc('ru')
    seed = Seed(123456789)

    # Custom locale
    assert m.romanize(locale='ru')(seed) == 'vse_ideya_prikhodit_iz_ameriki'
    assert m.romanize(locale='uk')(seed) == 'vse_ideya_prikhodit_iz_ameriki'
    assert m.romanize(locale='kk')(seed) == 'vse_ideya_prikhodit_iz_ameriki'

    # Default locale
    assert m.romanize(seed) == 'vse_ideya_prikhodit_iz_ameriki'

# Generated at 2022-06-21 15:44:16.435018
# Unit test for function romanize
def test_romanize():
    @romanize()
    def text():
        return 'Маша водит Мазду по дорогам Москвы.'

    assert text() == 'Masha vodit Mazdu po dorogam Moskvy.'


if __name__ == '__main__':  # pragma: no cover
    test_romanize()

# Generated at 2022-06-21 15:44:19.797810
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    romanized = romanize('ru')

    @romanized
    def foobar():
        """Constant string."""
        return 'привет'

    assert foobar() == 'privet'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:44:29.077917
# Unit test for function romanize
def test_romanize():  # pylint: disable=missing-function-docstring
    assert romanized('ru')(lambda: 'Привет, мир!')()
    assert romanized('ru')(lambda: 'Привет, мир!')()
    assert romanized('ru')(lambda: 'Привет, мир!')()
    assert romanized('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanized('kk')(lambda: 'Сәлем, дүние!')() == 'Salem, dünie!'
    # Unsupported locale

# Generated at 2022-06-21 15:44:38.380260
# Unit test for function romanize
def test_romanize():
    romanized_str_1 = romanize('uk')(lambda: 'А Б В Г Ґ Д Е Є Ж З И І Ї Й К Л М Н О П Р С Т У Ф Х Ц Ч Ш Щ Ь Ю Я')()
    assert romanized_str_1 == 'A B V H G D E Ye Zh Z Y I Yi Y K L M N O P R S T U F Kh Ts Ch Sh Shch YYu Ya'

# Generated at 2022-06-21 15:44:42.088354
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def name():
        """Name."""
        return 'Иван Кузнецов'

    assert name() == 'Ivan Kuznetsov'

# Generated at 2022-06-21 15:44:44.455891
# Unit test for function romanize
def test_romanize():
    assert romanized('en')(lambda: 'Тест тест')() == 'Test test'



# Generated at 2022-06-21 15:44:51.231370
# Unit test for function romanize
def test_romanize():
    assert romanized('uk')(lambda x: 'Рудольф Мендельсон')() == 'Rudolf Mendelson'
    assert romanized('ru')(lambda x: 'Рудольф Мендельсон')() == 'Rudolf Mendelson'
    assert romanized('kk')(lambda x: 'Рудольф Мендельсон')() == 'Rudolf Mendelson'

# Generated at 2022-06-21 15:44:52.929288
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    @romanize('ru')
    def fake():
        return RussianSpecProvider().noun()

    assert fake() == 'islam'