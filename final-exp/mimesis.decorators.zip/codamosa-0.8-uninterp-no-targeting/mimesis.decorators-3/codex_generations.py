

# Generated at 2022-06-21 15:35:02.019216
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'privet'

# Generated at 2022-06-21 15:35:09.124542
# Unit test for function romanize
def test_romanize():
    """Test that romanize decorator works as expected."""
    @romanize('ru')
    def rus(pattern):
        return pattern

    assert rus('Пошел Вы на хуй!') == 'Poshol Vy na khui!'

    @romanize('uk')
    def ukr(pattern):
        return pattern

    assert ukr('Пошел Вы на хуй!') == 'Poshol Vy na khui!'

    @romanize('kk')
    def kaz(pattern):
        return pattern

    assert kaz('Пошел Вы на хуй!') == 'Poshol Vy na khui!'

# Generated at 2022-06-21 15:35:13.630967
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def text(self):
        return 'Водород высшее образование'

    assert text(None) == 'Vodorod vissheye obrazovaniye'

# Generated at 2022-06-21 15:35:15.260704
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'АБВГДЕЖЗ')() == 'ABVGDEZH'

# Generated at 2022-06-21 15:35:18.523903
# Unit test for function romanize
def test_romanize():
    def dummy():
        return 'Привіт, привіт'

    assert romanize('ru')(dummy)() == 'Privet, privet'

# Generated at 2022-06-21 15:35:21.943414
# Unit test for function romanize
def test_romanize():
    # Transliterate ru -> en
    text = 'Привет мир!'
    assert romanize('ru')(lambda: text)() == 'Privet mir!'


if __name__ == '__main__':
    print(test_romanize())

# Generated at 2022-06-21 15:35:25.017428
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider as RS

    assert hasattr(RS, "rom_first_name")
    assert romanize(locale='ru')(RS._first_name)() == RS.rom_first_name()

# Generated at 2022-06-21 15:35:30.462700
# Unit test for function romanize
def test_romanize():
    test_trans_ru = romanize('ru')(lambda: 'Привет, Мир!')
    test_trans_kk = romanize('kk')(lambda: 'Сәлем, Дүние!')
    test_trans_uk = romanize('uk')(lambda: 'Привіт, Світ!')

    assert test_trans_ru == 'Privet, Mir!'
    assert test_trans_kk == 'Salem, Dunie!'
    assert test_trans_uk == 'Pryvit, Svit!'

# Generated at 2022-06-21 15:35:34.380710
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    from mimesis.enums import Locale

    @romanize(Locale.RU)
    def roman_me():
        return 'Вася'

    assert roman_me() == 'Vasya'

# Generated at 2022-06-21 15:35:41.767366
# Unit test for function romanize

# Generated at 2022-06-21 15:35:52.168892
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('ru')(lambda: 'Привет12')() == 'Privet12'
    assert romanized('ru')(lambda: 'Hello')() == 'Hello'
    assert romanized('ru')(lambda: 'Привет!')() == 'Privet!'

# Generated at 2022-06-21 15:35:58.401478
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_ru():
        return 'привет мир'

    assert test_ru() == 'privet mir'

    @romanize('uk')
    def test_uk():
        return 'привіт світ'

    assert test_uk() == 'pryvit svit'

    @romanize('kk')
    def test_kk():
        return 'Сәлем дүниең'

    assert test_kk() == 'Sälemdwñieg'

# Generated at 2022-06-21 15:36:06.934749
# Unit test for function romanize
def test_romanize():
    """Test romanize."""

    @romanize('ru')
    def test():
        return 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'

    result = 'ABVGDEEJZIJKLMNOPRSTUFHCCHCCHCSCHCS_Y_EYUYA'
    assert result == test()

# Generated at 2022-06-21 15:36:11.202812
# Unit test for function romanize
def test_romanize():
    s = 'Строка'
    assert 'Stroka' == romanized(locale='ru')(lambda: s)()
    assert 'Строка' == romanized(locale='nonexistent')(lambda: s)()

# Generated at 2022-06-21 15:36:13.465329
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    p = Person('ru')
    assert p.full_name()[0:2].isalpha()

# Generated at 2022-06-21 15:36:14.929605
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')


# Generated at 2022-06-21 15:36:17.595346
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo():
        return 'Привет мир!'

    assert foo() == 'Privet mir!'

# Generated at 2022-06-21 15:36:22.511498
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import TextSpec

    text_spec = TextSpec('ru')
    assert text_spec.cyrillic() == 'Ауэюэ'
    assert text_spec.romanized_cyrillic() == 'Aueiue'
    assert text_spec.cyrillic(romanize=True) == 'Aueiue'

# Generated at 2022-06-21 15:36:29.095888
# Unit test for function romanize
def test_romanize():
    romanized_dict = {
        'Артем': 'Artem',
        'Привет, мир!': 'Privet, mir!',
        'Хочу в Швейцарию.': 'Hochu v Shveitsariyu.',
        'Давайте выпьем пива с колой!': 'Davayte vypyem piva s koloy!',
    }
    for key, value in romanized_dict.items():
        assert romanize('ru')(lambda: key)(), value

# Generated at 2022-06-21 15:36:31.614394
# Unit test for function romanize
def test_romanize():
    """Test the function romanize."""
    assert romanize('uk')(lambda: 'тест')() == 'test'



# Generated at 2022-06-21 15:36:42.230510
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    import mimesis.builtins
    s = mimesis.builtins.Text()
    assert s.full_name(locale='ru-RU') == 'Алексей Александров'
    assert s.full_name(locale='uk-UA') == 'Андрій Андрійчук'

# Generated at 2022-06-21 15:36:45.703802
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def txt():
        return 'Привет'

    assert txt() == 'Privet'



# Generated at 2022-06-21 15:36:51.240321
# Unit test for function romanize
def test_romanize():
    func = romanize(locale='ru_RU')

    @func
    def get_test_string():
        return 'Привіт, Місяць!'

    test = get_test_string()
    assert test == 'Pryvit, Mysech!'

# Generated at 2022-06-21 15:36:55.600372
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator
    """
    from mimesis.builtins.numbers import Number
    from random import randint
    n = Number(seed=randint(0, 100000))
    n.romanized()

    from mimesis.builtins.text import Alphanumeric, Text
    a = Alphanumeric(seed=randint(0, 100000))
    a.romanized()

    t = Text(seed=randint(0, 100000))
    t.romanized()

# Generated at 2022-06-21 15:37:01.817387
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'пример')() == 'primer'
    assert romanized('kk')(lambda: 'пример')() == 'primer'
    assert romanized('uk')(lambda: 'пример')() == 'primer'

    assert romanized('en')(lambda: 'пример')() == 'пример'

# Generated at 2022-06-21 15:37:05.442356
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    result = romanize()(str)('Привет, Мир!')
    return result == 'Privet, Mir!'

# Generated at 2022-06-21 15:37:09.018038
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    person = Person('ru')
    fullname = person.full_name()
    assert fullname != person.romanize(fullname), "Cyrillic text doesn't \
    convert to latin."

# Generated at 2022-06-21 15:37:11.246930
# Unit test for function romanize
def test_romanize():
    rmn = romanize('ru')(lambda: 'Привет мир')
    assert 'Privet mir' == rmn

# Generated at 2022-06-21 15:37:21.504930
# Unit test for function romanize
def test_romanize():
    from .enums import Language

    r = romanized(locale=Language.RUSSIA.value)
    assert r.__name__ == 'romanize_deco'
    assert r.__doc__ == romanize.__doc__

    @r
    def foo():
        """Test romanization."""
        return 'Всем привет!'

    assert foo() == 'Vseem privet!'
    assert foo.__name__ == 'foo'
    assert foo.__doc__ == 'Test romanization.'

    foo_example = foo()
    assert isinstance(foo_example, str)

    f = romanized(locale=Language.UKRAINE.value)
    assert f.__name__ == 'romanize_deco'
    assert f.__doc__ == roman

# Generated at 2022-06-21 15:37:31.315560
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    @romanize(locale=Language.EN)
    def text():
        return 'Привіт Світ'

    romanized_text = text()
    assert romanized_text == 'Pryvit Svit'

    @romanize(locale=Language.RU)
    def russian():
        return 'Привет Мир'

    romanized_russian = russian()
    assert romanized_russian == 'Privet Mir'

    @romanize(locale=Language.UK)
    def ukrainian():
        return 'Галисія'

    romanized_ukrainian = ukrainian()

# Generated at 2022-06-21 15:37:39.379929
# Unit test for function romanize
def test_romanize():
    test_ru_func = romanize('ru')(lambda: 'Тест')
    test_ru = 'Test'
    assert test_ru_func() == test_ru


# Generated at 2022-06-21 15:37:41.727611
# Unit test for function romanize
def test_romanize():
    assert ascii_letters in data.ROMANIZATION_DICT['']
    assert digits in data.ROMANIZATION_DICT['']

# Generated at 2022-06-21 15:37:48.113123
# Unit test for function romanize
def test_romanize():
    def foo():
        return "Я люблю тебя!"

    def bar():
        return "Я люблю тебя!"

    romanize_deco = romanize('ru')
    romanize_deco(foo)
    assert foo() == "Ya lyublyu tebya!"

    romanize_deco = romanize('ru')
    romanize_deco(bar)
    assert bar() == "Ya lyublyu tebya!"

# Generated at 2022-06-21 15:37:59.702332
# Unit test for function romanize

# Generated at 2022-06-21 15:38:01.208769
# Unit test for function romanize
def test_romanize():
    assert type(romanize) is type
    assert romanize == romanized
    assert type(romanized) is type

# Generated at 2022-06-21 15:38:08.329357
# Unit test for function romanize
def test_romanize():
    """Romanize test."""
    class DataProvider:

        @romanize()
        def russian(self):
            return "Привет"

        @romanize()
        def kazakh(self):
            return "Сәлем"

        @romanize()
        def ukrainian(self):
            return "Добрий день"

    assert DataProvider().russian() == "Privet"
    assert DataProvider().kazakh() == "Sälem"
    assert DataProvider().ukrainian() == "Dobriy den"

# Generated at 2022-06-21 15:38:12.898805
# Unit test for function romanize
def test_romanize():
    from mimesis import Text
    import re
    txt = Text('ru')
    test_txt = re.compile(r'[А-Яа-яA-Za-z0-9\.,_\-\+\~#\?\!\;:\'"\(\)\[\]\{\}]+')
    assert test_txt.fullmatch(txt.romanize())
    assert test_txt.fullmatch(txt.romanize('uk'))
    assert test_txt.fullmatch(txt.romanize('kk'))
    assert len(txt.romanize()) == len(txt.word())

# Generated at 2022-06-21 15:38:15.180776
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize()
    assert romanize(locale='ru')
    assert romanized()
    assert romanized(locale='ru')

# Generated at 2022-06-21 15:38:17.063363
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Привіт'

    assert foo() == 'pryvit'

# Generated at 2022-06-21 15:38:25.821187
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    def romanized(locale: str = '', **kwargs) -> str:
        return Text(locale).romanized(**kwargs)

    assert romanized(Locale.UKRAINIAN) == romanized('uk')
    assert romanized(Locale.KAZAKH) == romanized('kk')
    assert romanized(Locale.RUSSIAN) == romanized('ru')

    assert romanized() == romanized('ru')
    assert romanized('') == romanized('ru')

# Generated at 2022-06-21 15:38:34.380097
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_word():
        return 'привет'

    assert rus_word() == 'privet'

# Generated at 2022-06-21 15:38:44.772490
# Unit test for function romanize
def test_romanize():
    """Test for romanize"""

# Generated at 2022-06-21 15:38:46.824128
# Unit test for function romanize
def test_romanize():
    @romanize(locale='kk')
    def gen_word(**kwargs):
        return 'Test'

    assert gen_word() == 'Test'

# Generated at 2022-06-21 15:38:47.628836
# Unit test for function romanize
def test_romanize():
    assert romanized == romanize



# Generated at 2022-06-21 15:38:56.083076
# Unit test for function romanize
def test_romanize():
    # Default is `ru`
    assert romanize()(lambda: 'Привет') == 'Privet'
    # Empty strings
    assert romanize('ru')(lambda: '') == ''
    assert romanize('uk')(lambda: '') == ''
    assert romanize('kk')(lambda: '') == ''
    assert romanize('az')(lambda: '') == ''
    # Some cases
    assert romanize('ru')(lambda: 'Яблоко') == 'Yabloko'
    assert romanize('uk')(lambda: 'Яблоко') == 'Yabloko'
    assert romanize('kk')(lambda: 'Яблоко') == 'Yablaqo'

# Generated at 2022-06-21 15:38:58.036800
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Абырвалг')() == 'Abryvalg'

# Generated at 2022-06-21 15:39:05.500740
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Что ты делаешь?')() == 'Chto ty delyaesh?'
    assert romanize('uk')(lambda: 'На сьомий поверх')() == 'Na s\'omiy poverkh'
    assert romanize('kk')(lambda: 'Нәрсәләр')() == 'Nәrsәlәr'

# Generated at 2022-06-21 15:39:06.384540
# Unit test for function romanize
def test_romanize():
    assert romanize is romanized

# Generated at 2022-06-21 15:39:12.884604
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize(locale='ru')(lambda: ''), Callable)
    assert isinstance(romanize(locale='uk')(lambda: ''), Callable)
    assert isinstance(romanize(locale='kk')(lambda: ''), Callable)

    romanize_decorator = romanize(locale='ru')

    @romanize_decorator
    def russian_text():
        return 'Русский язык.'.upper()

    assert russian_text() == 'Russkiy yazyk.'

# Generated at 2022-06-21 15:39:14.577882
# Unit test for function romanize
def test_romanize():
    assert romanize()



# Generated at 2022-06-21 15:39:28.666802
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    person = Person('ru')
    name = person.full_name()
    assert name.isalpha()

    name = person.full_name(romanize=True)
    assert name.isalpha()

# Generated at 2022-06-21 15:39:36.472249
# Unit test for function romanize
def test_romanize():
    """Test the correctness of romanization."""
    from mimesis.providers.cyrilic import CyrillicProvider
    from mimesis.providers.currency import Currency
    from mimesis.providers.person import Person

    assert CyrillicProvider.romanize('Привет') == 'Privet'
    assert CyrillicProvider.romanize('Привет', 'ru') == 'Privet'
    assert CyrillicProvider.romanize('Привет', 'uk') == 'Pryvit'
    assert CyrillicProvider.romanize('Привет', 'kk') == 'Privet'


# Generated at 2022-06-21 15:39:38.483402
# Unit test for function romanize
def test_romanize():
    sample = 'Тестовая строка'
    assert romanized(sample) == 'Testovaya stroka'

# Generated at 2022-06-21 15:39:39.108168
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:39:40.484108
# Unit test for function romanize
def test_romanize():
    # TODO: Fix it, see issue #75
    pass

# Generated at 2022-06-21 15:39:50.678546
# Unit test for function romanize
def test_romanize():
    class Test:
        @romanize(locale='ru')
        def russian(self):
            return 'Дата и время'

        @romanize(locale='uk')
        def ukrainian(self):
            return 'Дата i час'

        @romanize(locale='kk')
        def kazakh(self):
            return 'Уақыт және уақыт'

        @romanize()
        def unknown(self):
            return 'Dəqiqə və vaxt'


# Generated at 2022-06-21 15:39:52.186034
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanized, type(object))

# Generated at 2022-06-21 15:39:56.595448
# Unit test for function romanize
def test_romanize():
    assert romanized('привет') == 'privet'
    assert romanized('привет', locale='uk') == 'pryvit'
    assert romanized('привет', locale='kk') == 'privet'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:40:00.757400
# Unit test for function romanize
def test_romanize():
    assert romanized('ru', 'ЫАВП') == 'YAVP'
    assert romanized('ru', 'ЫаВП') == 'YavP'
    assert romanized('ru', 'ыавп') == 'yavp'
    assert romanized('ru', 'yavp') == 'yavp'

# Generated at 2022-06-21 15:40:06.111537
# Unit test for function romanize
def test_romanize():
    # test romanize
    assert romanize()('привет') == 'privet'
    assert romanize('uk')('привіт') == 'privit'
    assert romanize('kk')('салам') == 'salam'

    # Check error
    try:
        romanize('foobar')
    except UnsupportedLocale:
        assert True
    else:
        assert False

# Generated at 2022-06-21 15:40:36.396403
# Unit test for function romanize
def test_romanize():
    def test_ru(string):
        assert romanized("ru")(lambda: string) == string

    def test_uk(string):
        assert romanized("uk")(lambda: string) == string

    def test_kk(string):
        assert romanized("kk")(lambda: string) == string

    test_ru("Что где когда?")
    test_uk("Волком бы быть, а жить собакою")
    test_kk("Орастан ала келетін зат болса")
    test_ru("Я хочу в Москву")

# Generated at 2022-06-21 15:40:38.408511
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Сірік етемін қаламен') == 'Sirik etemin kalamen'

# Generated at 2022-06-21 15:40:40.206884
# Unit test for function romanize
def test_romanize():
    assert romanize('en')(lambda: 'привет') == 'privet'

# Generated at 2022-06-21 15:40:41.523682
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Котик') == 'Kotik'

# Generated at 2022-06-21 15:40:52.716727
# Unit test for function romanize
def test_romanize():
    assert romanize()('АБВ') == 'ABV'
    assert romanize()('АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ') == 'ABVGDEEJZIJKLMNOPRSTUFHCCHSHS``YY``EZIUZ'
    assert romanize()('АБВГ') == 'ABVG'

# Generated at 2022-06-21 15:40:57.411468
# Unit test for function romanize
def test_romanize():
    # Helper function to check if all cyrillic letter was replaced
    def check(locale, word):
        assert not [i for i in word if i in data.LOCALES[locale]]

    check('en', romanize('en')(lambda: 'Hello')())
    check('ru', romanize('ru')(lambda: 'Привет')())
    check('uk', romanize('uk')(lambda: 'Привіт')())
    check('kk', romanize('kk')(lambda: 'Сәлем')())

# Generated at 2022-06-21 15:41:05.050121
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.text import Text
    from mimesis.utils import random

    rsp = RussiaSpecProvider()
    txt = Text()

    fullname = rsp.full_name(gender=Gender.FEMALE)
    s = ''.join(random.choice(fullname) for _ in range(txt.quantity()))
    assert all([c in ascii_letters for c in romanize('ru')(txt.sentence)(s)])

# Generated at 2022-06-21 15:41:08.382648
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_func():
        return 'Привет, Мир!'

    assert test_func() == 'Privet, Mir!'

# Generated at 2022-06-21 15:41:09.491841
# Unit test for function romanize
def test_romanize():
    result = romanize()(lambda: 'с')()
    assert result == 's'

# Generated at 2022-06-21 15:41:18.169883
# Unit test for function romanize
def test_romanize():
    result = romanize()(lambda: 'Привет Мир')()
    assert 'Privet Mir' == result

# Generated at 2022-06-21 15:42:29.283409
# Unit test for function romanize
def test_romanize():

    @romanize
    def test(locale):
        pass

    assert test(locale='ru') == 'Привет, Мир'

# Generated at 2022-06-21 15:42:31.989891
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    # We use romanize as decorator to check romanization
    @romanize()
    def romanized_text():
        return 'Привет, Мир!'

    result = romanized_text()

    expected = 'Privet, Mir!'
    assert result == expected

# Generated at 2022-06-21 15:42:34.277996
# Unit test for function romanize
def test_romanize():
    """ Test function romanize. """
    assert callable(romanize)

    @romanize(locale='ru')
    def dummy(locale):
        return locale

    assert dummy('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-21 15:42:37.010550
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: "Спасибо")() == "Spasibo"

# Generated at 2022-06-21 15:42:43.333527
# Unit test for function romanize
def test_romanize():
    with patch.object(data, 'ROMANIZATION_DICT',
                      {'ru': {'а': 'a', 'б': 'b'}}), \
         patch.object(data, 'COMMON_LETTERS', {'г': 'g', 'д': 'd'}):
        @romanize(locale='ru')
        def get_cyrillic_text():
            return 'абгд'

        assert get_cyrillic_text() == 'abgd'

# Generated at 2022-06-21 15:42:45.322176
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : '')() == ''
    assert romanize('uk')(lambda : '')() == ''
    assert romanize('kk')(lambda : '')() == ''

# Generated at 2022-06-21 15:42:46.714856
# Unit test for function romanize
def test_romanize():
    assert romanize() == romanize

# Generated at 2022-06-21 15:42:47.298755
# Unit test for function romanize
def test_romanize():
    assert romanize()



# Generated at 2022-06-21 15:42:52.977931
# Unit test for function romanize
def test_romanize():
    def romanize(s):
        special_chars = (u"«»—№", u"<>--N")
        trans = {ord(a): ord(b) for a, b in zip(*special_chars)}
        s = s.translate(trans).lower()
        special_chars = (u"абвгдеёзиклмнопрстуфхцчшщ",
                         u"abvgdeeziklmnoprstufhcchshsh")
        trans = {ord(a): ord(b) for a, b in zip(*special_chars)}
        return s.translate(trans)

    assert romanize("Собака") == "sobaka"
    assert romanize

# Generated at 2022-06-21 15:43:01.250695
# Unit test for function romanize
def test_romanize():
    result = ''.join([
        romanized(locale='ru')(lambda: 'я')(),
        romanized(locale='uk')(lambda: 'и')(),
        romanized(locale='kk')(lambda: 'і')(),
    ])
    assert result == 'ya_i_i'

# Generated at 2022-06-21 15:44:38.145881
# Unit test for function romanize
def test_romanize():
    """Test romanization."""
    assert romanize()(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-21 15:44:41.343185
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Посмотри на часы!')() == \
        'Posmotri na chasy!'

# Generated at 2022-06-21 15:44:44.792890
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize"""
    from mimesis.builtins import Code

    code = Code('ru')

    @romanize('kk')
    def hello():
        return code.code()

    assert hello() == 'HW'

# Generated at 2022-06-21 15:44:48.518892
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_text():
        return "Новый текст"

    result = get_text()
    assert result == 'Novyy tekst'



# Generated at 2022-06-21 15:44:50.455971
# Unit test for function romanize
def test_romanize():
    assert romanize('de')
    try:
        assert romanize('asd')
    except UnsupportedLocale:
        assert True



# Generated at 2022-06-21 15:44:56.407473
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    r = RussiaSpecProvider()

    assert romanize(locale='ru')(r.name)['Иван', 'Кузнецов'] in ['Ivan', 'Kuznetsov']
    assert romanize(locale='uk')(r.name)['Мирослав', 'Петров'] in ['Miroslav', 'Petrov']
    assert romanize(locale='kk')(r.name)['Карателистан', 'Рынай'] in ['Karatelistan', 'Rynay']