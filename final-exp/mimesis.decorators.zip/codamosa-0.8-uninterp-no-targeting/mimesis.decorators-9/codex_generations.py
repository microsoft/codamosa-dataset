

# Generated at 2022-06-21 15:35:06.097975
# Unit test for function romanize
def test_romanize():
    """Test for romanization of the text.

    Supported locales: `ru`, `uk`, `kk`
    """
    from mimesis.providers.person import Person

    locales = ['ru', 'uk', 'kk']
    for locale in locales:
        romanized_text = ''

        person = Person(locale=locale)
        romanized_text += person.full_name()
        romanized_text += person.username()
        romanized_text += person.email()
        romanized_text += person.iban()

        assert romanize(locale)(lambda: romanized_text)()


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:35:12.211303
# Unit test for function romanize
def test_romanize():
    import time
    import random
    import string
    import mimesis

    t_start = time.time()
    for i in range(10000):
        p = mimesis.Person(locale='ru')
        result = p.full_name()
        t1 = time.time()
        t2 = t1 - t_start

        if t2 >= 5:
            return "Romanized function is working too long"

    # to test romanize function I generate russian words and
    # compare it with right answer.
    for i in range(10000):
        length = random.randint(1, 10)
        symbols = string.ascii_letters + string.digits
        word = ''.join(random.choice(symbols) for i in range(length))

# Generated at 2022-06-21 15:35:14.453768
# Unit test for function romanize
def test_romanize():
    romanize()
    romanize(locale='en')
    assert(romanize().__name__ != "romanize")

# Generated at 2022-06-21 15:35:22.949992
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    rus_sp = RussiaSpecProvider

    assert rus_sp().full_name('ru', romanize=True) == \
        rus_sp().full_name('ru')

    assert rus_sp().person('ru', romanize=True) == \
        rus_sp().person('ru')

    assert rus_sp().address('ru', romanize=True) == \
        rus_sp().address('ru')

    assert rus_sp().address_line('ru', romanize=True) == \
        rus_sp().address_line('ru')

    assert rus_sp().country('ru', romanize=True) == \
        rus_sp().country('ru')


# Generated at 2022-06-21 15:35:30.252920
# Unit test for function romanize
def test_romanize():
    txt = 'Фотографии выполнены на персне посвященной открытию Института.'
    print('\n'.join([romanized()(txt), romanized('ru')(txt), romanized('uk')(txt)]))

# Generated at 2022-06-21 15:35:32.644872
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет Мир!')() == 'Privet Mir!'

# Generated at 2022-06-21 15:35:40.701148
# Unit test for function romanize
def test_romanize():
    """Test for functools.romanize."""
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet

    romanize_me = {
        Language.EN: 'Hello, my friend!',
        Language.RU: 'Здравствуй, мой друг!',
        Language.UK: 'Вітаю, мій друг!',
        Language.KZ: 'Сәлеметсіз бе?',
    }


# Generated at 2022-06-21 15:35:43.675307
# Unit test for function romanize
def test_romanize():
    # 'func' should not be renamed
    @romanize(locale='ru')
    def func(a: str):
        return a

    assert func('мама') == 'mama'

# Generated at 2022-06-21 15:35:45.772213
# Unit test for function romanize
def test_romanize():
    # Assert romanize is input
    assert type(romanize) is type(Callable)
    assert romanize.__name__ == 'romanize'


# Generated at 2022-06-21 15:35:49.248497
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Address

    address = Address('ru')
    assert isinstance(address.country(), str)
    assert isinstance(address.country(romanized=True), str)
    assert address.country(romanized=True) != address.country()

# Generated at 2022-06-21 15:35:56.743084
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Some test text') == 'Somэ tэst tэxt'



# Generated at 2022-06-21 15:36:08.672054
# Unit test for function romanize
def test_romanize():
    import string
    import random

    def random_string(length):
        return ''.join(random.choices(string.ascii_letters, k=length))

    @romanize('ru')
    def romanize_ru():
        return random_string(10)

    @romanize('uk')
    def romanize_uk():
        return random_string(10)

    @romanize('kk')
    def romanize_kk():
        return random_string(10)

    try:
        @romanize('xx')
        def romanize_xx():
            return random_string(10)
    except UnsupportedLocale:
        pass

    assert romanize_ru()
    assert romanize_uk()
    assert romanize_kk()

# Generated at 2022-06-21 15:36:10.648337
# Unit test for function romanize
def test_romanize():
    assert len(romanize) > 0
    assert len(romanized) > 0

# Generated at 2022-06-21 15:36:14.517036
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_rus_name():
        return 'Александр'

    name = get_rus_name()
    assert name == 'Aleksandr'



# Generated at 2022-06-21 15:36:21.315063
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    def foo(locale: str = '') -> str:
        return 'я тебя люблю'

    assert romanize('ru')(foo)() == 'ya tebya lyublyu'

    assert romanize('ru')(foo)() == 'ya tebya lyublyu'
    assert romanized('ru')(foo)() == 'ya tebya lyublyu'

# Generated at 2022-06-21 15:36:29.018279
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Я люблю выпить кофе перед работой')().lower() == \
        'ya lyublyu vypit\' kofe' +\
        ' pered rabotoy'

    assert romanize('ru')(
        lambda: 'Оно очень много раз дает мне сил и желания работать')().lower() == \
        'ono ochen\' mnogo raz daet mne sil i zhelaniya rabotat\''


# Generated at 2022-06-21 15:36:40.304871
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers import BaseProvider

    class RomanizeTest(BaseProvider):
        """Romanize test."""

        class Meta:
            """Meta data for the data provider."""

            locale = Locale.UKRAINE

        @romanize(locale=Locale.UKRAINE)
        def foo(self) -> str:
            """Test method."""
            russian_letters = self.random_element(
                list(data.ROMANIZATION_DICT[Locale.RUSSIA]))
            ukrainian_letters = self.random_element(
                list(data.ROMANIZATION_DICT[Locale.UKRAINE]))
            return russian_letters + ukrainian_letters

    rt = RomanizeTest()
    rt

# Generated at 2022-06-21 15:36:46.988328
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    locale = Locale.RU

# Generated at 2022-06-21 15:36:55.440067
# Unit test for function romanize
def test_romanize():
    import mimesis.enums
    from mimesis.builtins import Address, Person
    p = Person('ru')
    a = Address('ru')
    assert all(letter in ascii_letters + digits + punctuation
               for letter in p.full_name())
    assert all(letter in ascii_letters + digits + punctuation
               for letter in a.street_address())
    assert not any(letter in mimesis.enums.CYRILLIC + mimesis.enums.HANGUL
                   for letter in p.full_name())
    assert not any(letter in mimesis.enums.CYRILLIC + mimesis.enums.HANGUL
                   for letter in a.street_address())

# Generated at 2022-06-21 15:36:56.678602
# Unit test for function romanize
def test_romanize():
    pass



# Generated at 2022-06-21 15:37:04.460067
# Unit test for function romanize
def test_romanize():
    alphabet = ascii_letters + digits
    for char in alphabet:
        assert romanize('uk')(char) == char

# Generated at 2022-06-21 15:37:08.849729
# Unit test for function romanize
def test_romanize():
    """Tests for romanize decorator."""
    @romanize('ru')
    def f():
        return "Привет, мир!"

    assert f() == 'Privet, mir!'

# Generated at 2022-06-21 15:37:19.737226
# Unit test for function romanize
def test_romanize():
    from mimesis.data import MORZE_DICT
    from mimesis.enum import Language
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.text import Text
    from mimesis.random import Random

    # Test for `ru`, `uk`, `kk`
    for locale in ('ru', 'uk', 'kk'):
        r = Random(locale)
        lorem = Lorem(r)
        text = Text(r)
        sample1 = lorem.text()
        sample2 = text.morze_code()
        assert romanize(locale)(text.morze_code)(sample2) == (
            ' '.join([MORZE_DICT[i] for i in sample2])
        )

# Generated at 2022-06-21 15:37:25.116320
# Unit test for function romanize
def test_romanize():
    @romanized()
    def romanize_test():
        return 'Ккак съешь ещё этих мягких французских булок, да выпей же чаю.'

    result = romanize_test()
    assert result == 'Kkak syesh yeshchyo  etikh myagkikh frantsuzskikh bulok, da' \
                     ' vypey zhe chayu.'

# Generated at 2022-06-21 15:37:35.918972
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: '123')() == '123'
    assert romanize('ru')(lambda: 'буква')() == 'bukva'
    assert romanize('ru')(lambda: 'Буква')() == 'Bukva'
    assert romanize('ru')(lambda: 'Буква?')() == 'Bukva?'
    assert romanize('ru')(lambda: 'БУКВА')() == 'BUKVA'
    assert romanize('ru')(lambda: 'буква.')() == 'bukva.'

    assert romanize('uk')(lambda: '123')() == '123'

# Generated at 2022-06-21 15:37:46.210557
# Unit test for function romanize
def test_romanize():
    from mimesis import Address

    addr = Address('ru')
    assert addr.address() == 'Санкт-Петербург, ул. Дмитрия Донского, 57'

    addr_ru = Address('ru')
    assert addr_ru.address(romanize=True) == \
        'Sankt-PeterbUrg, ul. Dmitriya Donskogo, 57'

    addr_uk = Address('uk')
    assert addr_uk.address(romanize=True) == \
        'Sankt-PeterbUrg, ul. Dmitriya Donsʹkoho, 57'

    user = Address('kk')

# Generated at 2022-06-21 15:37:56.083060
# Unit test for function romanize
def test_romanize():
    """Test for romanization."""
    import mimesis.builtins
    from mimesis.builtins import Person
    assert mimesis.builtins.Person
    person = Person()
    assert person.full_name() == 'Валентин Тарасов'

    @romanize('ru')
    def get_name():
        return person.full_name()

    assert get_name() == 'Valentin Tarasov'

    @romanized('ru')
    def get_name():
        return person.full_name()

    assert get_name() == 'Valentin Tarasov'

# Generated at 2022-06-21 15:38:02.070176
# Unit test for function romanize
def test_romanize():
    @romanized()
    def romanize_words(cnt: int = 1, word_length: int = 1) -> str:
        words = ' '.join([data.common.word(word_length) for _ in
                          range(cnt)])
        return words

    assert romanize_words() == 'a'
    assert romanize_words(cnt=10, word_length=7) \
        == 'nulla autem vallis quia nulla iusto quia nulla'

# Generated at 2022-06-21 15:38:11.254056
# Unit test for function romanize
def test_romanize():
    assert ascii_letters == 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert digits == '0123456789'
    assert punctuation == '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    alphabet = {s: s for s in ascii_letters + digits + punctuation}

# Generated at 2022-06-21 15:38:13.266621
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Привет!'

    assert foo() == 'Privet!'
    assert foo() == 'Privet!'

# Generated at 2022-06-21 15:38:28.187353
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-21 15:38:31.685321
# Unit test for function romanize
def test_romanize():
    a = romanized()(data.CY_LETTERS)
    a = romanized('ru')(data.CY_LETTERS)
    a = romanized('uk')(data.CY_LETTERS)
    a = romanized('kk')(data.CY_LETTERS)

# Generated at 2022-06-21 15:38:33.957422
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test(string):
        return string


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:38:39.619738
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_text():
        return 'Будь ласка, сказавши, завершити'
    assert rus_text() == 'Bud laska, skazavshi, zavershit'

# Generated at 2022-06-21 15:38:47.199056
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    valid_locale = RussiaSpecProvider().get_language_code()
    invalid_locale = 'xx'
    r_string = 'Привет Мир!'

    @romanize(locale=valid_locale)
    def romanized(string):
        return string

    @romanize(locale=invalid_locale)
    def romanized_with_invalid_locale(string):
        return string

    assert romanized(r_string) == 'Privet Mir!'
    assert romanized_with_invalid_locale(r_string) == 'Privet Mir!'

# Generated at 2022-06-21 15:38:50.884930
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'краткое описание')() == \
        romanized(locale='ru')(lambda: 'краткое описание')()



# Generated at 2022-06-21 15:38:51.399614
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:38:54.829868
# Unit test for function romanize
def test_romanize():
    assert romanized("ru")("Привет") == 'Privet'
    assert romanized("uk")("Привіт") == 'Pryvit'
    assert romanized("kk")("Салам") == 'SALAM'

# Generated at 2022-06-21 15:38:58.228913
# Unit test for function romanize

# Generated at 2022-06-21 15:39:00.565410
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privyet'

# Generated at 2022-06-21 15:39:29.749602
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def get_romanized_text():
        return 'Привет, Мимезис!'

    rt = get_romanized_text()
    assert rt == 'Privet, Mimezis!'



# Generated at 2022-06-21 15:39:33.361803
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-21 15:39:34.453204
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Language
    lang = Langua

# Generated at 2022-06-21 15:39:38.356384
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'абвгд')() == 'abvgda'
    assert romanize('ru')(lambda : 'фхцчшщьъыэюя')() == 'fhccshshjyeya'

# Generated at 2022-06-21 15:39:40.108469
# Unit test for function romanize
def test_romanize():
    print(romanize('ru'))
    assert romanize('ru') == 'Сцитира'

# Generated at 2022-06-21 15:39:50.301813
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    @romanize(locale='ru')
    def romanize_ru(self):
        """Romanized russian words."""
        return self.random.choice(data.RU_WORDS)

    @romanize(locale='uk')
    def romanize_uk(self):
        """Romanized ukrainian words."""
        return self.random.choice(data.UK_WORDS)

    @romanize(locale='kk')
    def romanize_kk(self):
        """Romanized kazakh words."""
        return self.random.choice(data.KK_WORDS)

    @romanize(locale='unknown_locale')
    def romanize_unk(self):
        """Romanized string."""

# Generated at 2022-06-21 15:39:57.854956
# Unit test for function romanize
def test_romanize():
    def romanize_example(txt, locale='ru'):
        @romanize(locale)
        def _romanize_example():
            return txt

        return _romanize_example()

    assert romanize_example('Привет') == 'Privet'
    assert romanize_example('Привет мир', 'uk') == 'Pryvet mir'
    assert romanize_example('Жаным сенсіз', 'kk') == 'Janım sensiz'

# Generated at 2022-06-21 15:39:59.796742
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize(locale='ru')(lambda x: 'Правда')() == 'Pravda'



# Generated at 2022-06-21 15:40:03.346060
# Unit test for function romanize
def test_romanize():
    """Function romanize."""
    r = romanize('ru')
    @r
    def func(self):
        """wrapper with romanize."""
        return self.token_hex()

    result = func(None)
    assert isinstance(result, str)



# Generated at 2022-06-21 15:40:13.748752
# Unit test for function romanize

# Generated at 2022-06-21 15:41:22.027830
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'тест')() == 'test'

# Generated at 2022-06-21 15:41:28.312240
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    result = romanize('ru')(lambda x: 'тест')
    assert result == 'test'

    result = romanize('ru')(lambda x: 'Тест')
    assert result == 'Test'

    result = romanize('ru')(lambda x: 'Тест ещё раз')
    assert result == 'Test yeshchó raz'

    result = romanize('ru')(lambda x: 'Тест ещё раз.')
    assert result == 'Test yeshchó raz.'

    result = romanize('ru')(lambda x: 'Тест 12345.')
    assert result == 'Test 12345.'

    result = roman

# Generated at 2022-06-21 15:41:32.253185
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanized_func():
        return 'Какой замечательный день сегодня!'

    assert romanized_func() == 'Kakoj zamechatelnyj den segodnja!'

# Generated at 2022-06-21 15:41:39.098126
# Unit test for function romanize
def test_romanize():
    """Test case for romanize decorator."""
    assert romanize(locale='ru')(lambda: 'Привет мир')() == 'Privet mir'
    assert romanize(locale='uk')(lambda: 'Привіт світ')() == 'Pryvit svit'
    assert romanize(locale='kk')(lambda: 'Сәлем дүние')() == 'Sälem dünje'

# Generated at 2022-06-21 15:41:43.467759
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привет')() == 'pryvet'
    assert romanize('kk')(lambda: 'привет')() == 'privet'

# Generated at 2022-06-21 15:41:50.201792
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda x: 'Привет, Мир!')(locale='ru') == 'Privet, Mir!'

# Generated at 2022-06-21 15:41:55.889777
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    assert romanize(locale='ru')(lambda: 'Лорем ипсум долор')() == 'Lorem ipsum dolor'
    assert romanize(locale='uk')(lambda: 'Лорем іпсум долор')() == 'Lorem ipsum dolor'
    assert romanize(locale='kk')(lambda: 'Лорем ипсум долор')() == 'Lorem ipsum dolor'

# Generated at 2022-06-21 15:42:04.150044
# Unit test for function romanize
def test_romanize():
    cy = 'День народження Ро́ксоланисерів!'
    assert romanize('')(lambda: ''.join(cy)) ==\
        'Den’ narodzhennia Roksolanaiseriv!'
    assert romanize('uk')(lambda: ''.join(cy)) ==\
        'Denʹ narodzhennia Roksolanaiseriv!'
    assert romanize('kk')(lambda: ''.join(cy)) ==\
        'Dіені́ народження Роксоланаі́сірів!'

# Generated at 2022-06-21 15:42:08.870274
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Тестирование некоторых кириллических символов.')() == \
           'Téstirovanié nékotorýkh kirillícheskikh simvolov.'

# Generated at 2022-06-21 15:42:09.918715
# Unit test for function romanize
def test_romanize():
    assert data.random_romanized() == 'aab'



# Generated at 2022-06-21 15:44:17.831341
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT
    from mimesis.data import COMMON_LETTERS

    def f(locale):
        """Without decorator."""
        alphabet = {s: s for s in ascii_letters + digits + punctuation}
        alphabet.update({**ROMANIZATION_DICT[locale], **COMMON_LETTERS})
        text = 'привет'
        txt = ''.join([alphabet[i] for i in text if i in alphabet])
        return txt

    def g(locale):
        """With decorator."""
        text = 'привет'
        txt = ''.join([alphabet[i] for i in text if i in alphabet])
        return txt

    assert f('ru')

# Generated at 2022-06-21 15:44:20.943019
# Unit test for function romanize
def test_romanize():
    the_string = "Тестовая строка"
    def method_to_be_romanized(self):
        return the_string

    romanized_method = romanize("ru")(method_to_be_romanized)
    assert romanized_method(None) == "Testovaya stroka"

# Generated at 2022-06-21 15:44:23.645600
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text
    t = mimesis.builtins.text.Text('ru')
    assert t._romanize('Привет мир') == 'Privet mir'

# Generated at 2022-06-21 15:44:33.656161
# Unit test for function romanize
def test_romanize():
    string = romanize('ru')(lambda: 'Спасибо' + ' за то, что вы с нами!')()
    assert string == 'Spasibo za to, chto vy s nami!'
    string = romanize('uk')(lambda: 'Завжди' + ' раді бути з вами!')()
    assert string == 'Zavzhdi raditi buti z vamy!'
    string = romanize('kk')(lambda: 'Саламатсыз' + ' боласыз!')()
    assert string == 'Salamatsyz bolasyz!'

# Generated at 2022-06-21 15:44:38.116506
# Unit test for function romanize
def test_romanize():
    def foo():
        return 'Грибы'

    assert romanize('ru')(foo)() == 'Griby'

    assert romanize('uk')(foo)() == 'Hryby'

    assert romanize('kk')(foo)() == 'Ғрибы'

    assert romanize('be')(foo)() == 'Gryбы'

# Generated at 2022-06-21 15:44:47.079295
# Unit test for function romanize
def test_romanize():
    # No locale parameter

    @romanize(locale='ru')
    def func1():
        return 'Привет, Мир!'


    @romanize()
    def func2():
        return 'Привет, Мир!'

    assert func1() == 'Privet, Mir!'
    assert func2() == 'Privet, Mir!'

    # No @romanize decorator

    def func3():
        return 'Привет, Мир!'

    assert func3() == 'Привет, Мир!'

# Generated at 2022-06-21 15:44:47.964671
# Unit test for function romanize
def test_romanize():
    assert 'some text' == romanize('some text')

# Generated at 2022-06-21 15:44:56.017533
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize('ru')(lambda: 'Федор Михайлович Достоевский')() == 'Fedor Mihaylovich Dostoyevsky'
    assert romanize('kk')(lambda: 'Құстарға аса бір түркім')() == 'Qustarga asa bir turkim'
    assert romanize('uk')(lambda: 'Федір Михайлович Достоєвський')() == 'Fedir Mykhaylovych Dostoyevskyi'
