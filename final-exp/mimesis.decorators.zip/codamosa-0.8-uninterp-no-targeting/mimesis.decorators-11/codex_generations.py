

# Generated at 2022-06-21 15:35:03.017582
# Unit test for function romanize
def test_romanize():
    def foo(a):
        return a

    x = 'Привіт'

    f = romanize('uk')(foo)
    assert f(x) == 'Privit'

# Generated at 2022-06-21 15:35:04.417972
# Unit test for function romanize
def test_romanize():
    assert romanize == romanized
    assert romanize == romanize('')



# Generated at 2022-06-21 15:35:11.119545
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize('ru')
    def my_func():
        return 'Просто латинский текст'

    assert my_func() == 'Prosto latinskiy tekst'

    @romanize('uk')
    def my_func():
        return 'Просто латинский текст'

    assert my_func() == 'Prosto latinskiy tekst'

    @romanize('uk')
    def my_func():
        return 'просто латинский текст'

    assert my_func() == 'prosto latinskiy tekst'



# Generated at 2022-06-21 15:35:14.651326
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'тест')() == 'test'
    assert romanize(locale='uk')(lambda: 'До побачення')() == 'Do pobachennya'

# Generated at 2022-06-21 15:35:21.618110
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    rus = RussiaSpecProvider(locale='ru')
    print(rus.romanize(rus.legal_form()))
    print(rus.romanize(rus.title_lord_lady()))
    print(rus.romanize(rus.title_mister()))
    print(rus.romanize(rus.title_misses()))
    print(rus.romanize(rus.title_doctor()))
    print(rus.romanize(rus.title_professor()))
    print(rus.romanize(rus.title_sir()))

# Generated at 2022-06-21 15:35:23.745245
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize()(lambda: 'Южная Корея')() == 'Yuzhnaya Koreya'



# Generated at 2022-06-21 15:35:25.596162
# Unit test for function romanize
def test_romanize():
    print(romanize())
    print(romanize('ru'))

# Generated at 2022-06-21 15:35:32.065933
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize()(
        lambda: 'будешь есть слона?')() == 'budyesh'
    assert romanize('kk')(lambda: 'арман жасайсыз')() == 'arman'

# Generated at 2022-06-21 15:35:33.485754
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text
    t = mimesis.builtins.text.Text()
    assert t.romanized(locale='ru')



# Generated at 2022-06-21 15:35:41.150311
# Unit test for function romanize
def test_romanize():
    import mimesis.enums
    from mimesis.builtins.enums import Gender
    from mimesis.builtins.generic import Human

    r = Human(mimesis.enums.Gender.FEMALE)
    assert r.full_name(locale='uk') == 'Євгенія Дяченко'
    assert r.full_name(locale='ru', gender=Gender.MALE) \
       == 'Александр Тимошенко'
    assert r.full_name(locale='ru', gender=Gender.FEMALE) \
       == 'Катерина Васильева'

# Generated at 2022-06-21 15:35:49.708612
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_func(text: str) -> str:
        return text

    assert test_func('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-21 15:35:58.028719
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет мир!')(1) == 'Privet mir!'
    assert romanize('ru')(lambda x: 'Привет мир!')(1) != 'Привет мир!'
    assert romanize('uk')(lambda x: 'Павло Тичина вітає вас!') \
        (1) == 'Pavlo Tichyna vitaye vas!'

# Generated at 2022-06-21 15:36:09.470556
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.builtins import (
        Person,
        Address,
        Text,
    )

    p = Person('uk')
    a = Address('uk')
    t = Text('uk')


# Generated at 2022-06-21 15:36:12.596921
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanized_string(flag=True):
        return 'с текстом'

    assert romanized_string() == 's tekstom'

# Generated at 2022-06-21 15:36:14.982955
# Unit test for function romanize
def test_romanize():
    romanize_deco = romanize('ru')
    assert romanize_deco

# Generated at 2022-06-21 15:36:18.085149
# Unit test for function romanize
def test_romanize():

    @romanized()
    def dummy_text():
        return 'здравствуйте мир'

    assert dummy_text() == 'zdravstvuyte mir'

# Generated at 2022-06-21 15:36:27.038796
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanized)
    ctx = type('Context', (), {})
    ctx.locale = 'ru'

    @romanize(locale=ctx.locale)
    def _romanize_cyrillic(text: str) -> str:
        return text

    text = 'Привет! Я мега-простой тест!'
    assert _romanize_cyrillic(text) == 'Privet! Ya mega-prostoy test!'

    text = 'Привет! Я мега-простой тест!'

# Generated at 2022-06-21 15:36:33.279252
# Unit test for function romanize
def test_romanize():
    # Вениами́н
    w = 'Вениами́н'
    assert romanize()(w) == 'Veniamin'
    assert romanize('ru')(w) == 'Veniamin'
    assert romanize('uk')(w) == 'Veniamin'
    assert romanize('kk')(w) == 'Veniamin'

# Generated at 2022-06-21 15:36:37.324775
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def locator_name():
        return 'Санкт-Петербург'

    assert locator_name() == 'Sankt-Peterburg'

# Generated at 2022-06-21 15:36:43.591396
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize
    def romanized_text(text: str = '') -> str:
        return text

    assert romanized_text('Привет') == 'Privet'
    assert romanized_text('Привет', locale='ru') == 'Privet'
    assert romanized_text('Привет', locale='en') == 'Privet'
    assert romanized_text('Привет', locale='uk') == 'Pryvit'

# Generated at 2022-06-21 15:36:52.573759
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'привет')() == 'privet'
    assert romanize('uk')(lambda x: 'привіт')() == 'pryvit'

# Generated at 2022-06-21 15:37:04.294583
# Unit test for function romanize
def test_romanize():

	from mimesis.providers.person import Person
	from mimesis.enums import Gender
	from mimesis.builtins.en_US.person import Person as PersonEN
	from mimesis.builtins.ru_RU.person import Person as PersonRU
	from mimesis.builtins.uk_UA.person import Person as PersonUA
	from mimesis.builtins.kk_KZ.person import Person as PersonKZ
	from mimesis.builtins.be_BY.person import Person as PersonBE
	from mimesis.builtins.bg_BG.person import Person as PersonBG
	from mimesis.builtins.mk_MK.person import Person as PersonMK


	# Make function romanized if it is not

	Person.romanized = romanize('')(Person.romanized)



# Generated at 2022-06-21 15:37:07.222638
# Unit test for function romanize
def test_romanize():
    assert romanize == romanized
    assert romanize is not romanized

# Generated at 2022-06-21 15:37:08.854962
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    assert RussianSpecProvider.romanize() is not None

# Generated at 2022-06-21 15:37:12.798114
# Unit test for function romanize
def test_romanize():
    """Testing function romanize.
    """
    romanized_string = romanize(locale='ru')(lambda: 'Тест романизации')
    assert romanized_string() == 'Test romanizacii'

# Generated at 2022-06-21 15:37:14.430529
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Russian')() == 'Russian'

# Generated at 2022-06-21 15:37:20.691017
# Unit test for function romanize
def test_romanize():
    # simple test for romanize
    # romanized_simple = romanize('ru')(lambda s: s.rjust(3, 'а'))
    romanized_simple = romanized('ru')(lambda s: s.rjust(3, 'а'))
    assert romanized_simple() == 'ааа'
    assert romanized_simple(seed=1) == 'ааа'
    assert romanized_simple() == 'ааа'

# Generated at 2022-06-21 15:37:21.540767
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:37:26.595333
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'привет')() == 'privet'
    assert romanize(locale='uk')(lambda: 'привіт')() == 'pryvit'
    assert romanize(locale='kk')(lambda: 'сәлем')() == 'sälem'

# Generated at 2022-06-21 15:37:36.958724
# Unit test for function romanize
def test_romanize():
    """Test function ``romanize``."""
    from mimesis.locales.en import English
    from mimesis.locales.ru import Russian
    from mimesis.locales.uk import Ukrainian
    from mimesis.locales.kk import Kazakh
    eng = English()
    rus = Russian()
    ukr = Ukrainian()
    kaz = Kazakh()
    assert eng.romanize('Test') == 'Test'
    assert eng.romanize('Test', 'en') == 'Test'
    assert rus.romanize('Проверка') == 'Proverka'
    assert ukr.romanize('Тест') == 'Test'
    assert kaz.romanize('Тест') == 'Test'

# Generated at 2022-06-21 15:37:45.975581
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.schema import Field

    f = Field('name.full_name', gender=Gender.MALE)
    f.romanize = True
    name = f.execute()
    assert not any(c.isupper() for c in name)

# Generated at 2022-06-21 15:37:46.810574
# Unit test for function romanize
def test_romanize():
    romanize()

# Generated at 2022-06-21 15:37:49.902199
# Unit test for function romanize
def test_romanize():
    test = romanize('ru')
    assert test(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-21 15:37:51.390850
# Unit test for function romanize
def test_romanize():
    print(romanize()(lambda a: data.COMMON_LETTERS))

# Generated at 2022-06-21 15:38:02.071761
# Unit test for function romanize
def test_romanize():
    import unittest

    class RomanizeTestCase(unittest.TestCase):

        def setUp(self):
            """Set up."""
            self.text = 'Здравствуй мир! Hello World!'

        def tearDown(self):
            """Tear down."""
            del self.text

        @romanize(locale='ru')
        def test_ru(self):
            self.assertEqual(
                self.text,
                'Zdravstvuy mir! Hello World!',
            )

        @romanize(locale='uk')
        def test_uk(self):
            self.assertEqual(
                self.text,
                'Zdravstvuy mir! Hello World!',
            )


# Generated at 2022-06-21 15:38:11.255342
# Unit test for function romanize
def test_romanize():
    # Locale 'ru'
    assert romanized('ru')(lambda x: 'Привет')() == 'Privet'
    # Locale 'uk'
    assert romanized('uk')(lambda x: 'Привіт')() == 'Pryvit'
    # Locale 'kk'
    assert romanized('kk')(lambda x: 'Сәлем')() == 'Sälem'
    # Locale 'default'
    assert romanized()(lambda x: 'Привет')() == 'Privet'
    # Default locale
    import mimesis.enums
    mimesis.enums.DEFAULT_LOCALE = 'ru'
    assert romanized()(lambda x: 'Привет')

# Generated at 2022-06-21 15:38:13.552989
# Unit test for function romanize
def test_romanize():
    # romanize() function doesn't require any argument.
    assert romanize() is not None

# Generated at 2022-06-21 15:38:15.392704
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpeller

    assert RussianSpeller().romanize(locale='ru') == 'Test'

# Generated at 2022-06-21 15:38:19.061415
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def romanize_test():
        return "Привет мир! Как дела?"

    assert True is not False
    assert "Priveт mir! Kak dela?" == romanize_test()

# Generated at 2022-06-21 15:38:24.532962
# Unit test for function romanize
def test_romanize():
    from mimesis.providers import DateTime
    from mimesis.enums import Locale

    dt = DateTime(locale=Locale.RUSSIAN)
    datetime_str = dt.date()

    result = romanize(locale='ru')(datetime_str)

    assert datetime_str == '11.01.1985'
    assert result == '11.01.1985'

# Generated at 2022-06-21 15:38:46.672107
# Unit test for function romanize
def test_romanize():
    # Create an instance
    pt = data.Person()
    # Decorate function
    @romanize('ru')
    def func():
        return pt.full_name(gender="female")
    # Assert
    assert isinstance(func(), str)
    # Assert romanized name
    assert func() in ['Петрова Дарья Никитична', 'Бондарева Елена Алексеевна', 'Петров Артём Игоревич']
    # Call functools.wraps on func
    assert func.__name__ == 'func'
    # Call functools.wraps on wrapper

# Generated at 2022-06-21 15:38:55.116557
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    r = data.Romanization(Language.RUSSIAN)
    assert r.romanize('привет') == 'privet'
    assert r.romanize('Привет') == 'Privet'
    assert r.romanize('привет, мир') == 'privet, mir'

    r = data.Romanization(Language.UKRAINIAN)
    assert r.romanize('привіт') == 'pryvit'
    assert r.romanize('Привіт') == 'Pryvit'

    r = data.Romanization(Language.KAZAKH)
    assert r.romanize('Сәлем') == 'Sälem'

# Generated at 2022-06-21 15:38:56.499599
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Привет')() == 'privet'

# Generated at 2022-06-21 15:38:58.726314
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-21 15:39:01.908280
# Unit test for function romanize
def test_romanize():
    @romanize("ru")
    def foo():
        return "Арсений"

    assert str(foo()) == "Arseniy"



# Generated at 2022-06-21 15:39:05.414236
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo(locale: str = 'ru') -> str:
        return "Шоу Стервы"
    assert foo() == "Show Stervy"

# Generated at 2022-06-21 15:39:07.059632
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Юникод') == 'Yunikod'



# Generated at 2022-06-21 15:39:09.287902
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')().lower() == 'privet, mir!'

# Generated at 2022-06-21 15:39:11.023303
# Unit test for function romanize
def test_romanize():
    assert romanize('nl')(lambda: 'test_test')() == 'test_test'

# Generated at 2022-06-21 15:39:22.417019
# Unit test for function romanize
def test_romanize():
    """Check that romanize works correctly."""
    from mimesis.langs import English

    lang = English()

    def get_word():
        return lang.word()

    @romanized(locale='ru')
    def get_word_ru():
        return lang.word()

    @romanized(locale='uk')
    def get_word_uk():
        return lang.word()

    @romanized(locale='kk')
    def get_word_kk():
        return lang.word()

    from_locale_ru = get_word_ru()
    from_locale_uk = get_word_uk()
    to_locale_kk = get_word_kk()
    to_default_locale = get_word()

    assert from_locale_ru == 'Dzho'

# Generated at 2022-06-21 15:39:45.984268
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(str)('Привет, мир!')('ru') == 'Privet, mir!'


# Generated at 2022-06-21 15:39:49.515443
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person

    person = Person()

    assert person.full_name(gender=Gender.MALE) in person.full_name.__doc__



# Generated at 2022-06-21 15:39:58.348572
# Unit test for function romanize
def test_romanize():
    assert 'Русский алфавит' == romanized('ru')('Русский алфавит')
    assert 'Український алфавіт' == romanized('uk')('Український алфавіт')
    assert 'Қазақша алфавит' == romanized('kk')('Қазақша алфавит')

# Generated at 2022-06-21 15:40:00.537345
# Unit test for function romanize
def test_romanize():
    _romanize = romanize('ru')

    @_romanize
    def test():
        return 'Привет, Мир!'

    assert test() == 'Privet, Mir!'

# Generated at 2022-06-21 15:40:05.918375
# Unit test for function romanize
def test_romanize():
    """Tests for romanize."""
    assert romanize('ru')(lambda: 'Пухлый')() == 'Pukhlyi'
    assert romanize('uk')(lambda: 'Пухлий')() == 'Pukhliy'
    assert romanize('kk')(lambda: 'Майнай')() == 'Mainay'

# Generated at 2022-06-21 15:40:07.560590
# Unit test for function romanize
def test_romanize():
    assert data.Person('ru').full_name == data.Person(
        'ru').romanize().full_name

# Generated at 2022-06-21 15:40:08.428656
# Unit test for function romanize
def test_romanize():
    romanize()

# Generated at 2022-06-21 15:40:10.966812
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет!')() == 'Privet!'

# Generated at 2022-06-21 15:40:18.618998
# Unit test for function romanize
def test_romanize():
    import mimesis.enums as enums

    result = romanize(enums.Language.EN)(lambda: 'Юлия, съешь ещё этих мягких французских булок, да выпей же чаю')()
    assert result == 'Yuliya, syesh eshchyo etikh myagkikh frantsuzskikh bulok, da vypey zhe chayu'

# Generated at 2022-06-21 15:40:19.145336
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-21 15:41:30.905500
# Unit test for function romanize
def test_romanize():
    ''' Check romanize function 
    '''
    assert romanize('ru')(
        lambda: 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЫЪЭЮЯ')(
    ) == 'ABVGDEEZHIZJKLMNOPRSTUFHCCHSHSHCHZHJEEYUYA'

# Generated at 2022-06-21 15:41:40.374710
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    t = Text()

    assert t.romanize('ru')() == ''
    assert t.romanize('ru')('абвгд') == 'abvgdy'
    assert t.romanize('ru')('Привет!') == 'Privet!'
    assert t.romanize('ru')('Привет мир!') == 'Privet mir!'
    assert t.romanize('uk')('Привіт світ!') == 'Pryvit svit!'

# Generated at 2022-06-21 15:41:50.203195
# Unit test for function romanize
def test_romanize():
    """Test for romanization."""
    from mimesis.builtins import BelarusianSpecProvider

    be = BelarusianSpecProvider(romanize=True)
    assert be.full_name() == 'Сяргей Аляксеевіч Гуська'
    assert be.full_name(romanize=False) == 'Сяргей Аляксеевіч Гуська'
    assert be.full_name(gender='female') == 'Ліля Ігнатаўна Моранова'

# Generated at 2022-06-21 15:41:52.659417
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_func():
        return 'Привет, Мир!'
    assert test_func() == 'Privet, Mir!'

# Generated at 2022-06-21 15:41:54.166835
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Всё')() == 'Vsyo'

# Generated at 2022-06-21 15:42:02.353680
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    from mimesis.enums import Gender

    p = Person('uk')
    assert p.full_name_male(gender=Gender.MALE) == 'Сергій Дмитрович Коржов'
    assert p.full_name_male(gender=Gender.MALE, romanize=True) == 'Serhii Dmytrovych Korzhov'

    p = Person('ru')
    assert p.full_name_male(gender=Gender.MALE) == 'Юрий Леонидович Торопов'

# Generated at 2022-06-21 15:42:03.867271
# Unit test for function romanize
def test_romanize():
    romanize('ru')('Привет!')

# Generated at 2022-06-21 15:42:12.189731
# Unit test for function romanize
def test_romanize():
    # Check if script transliterate cyrillic symbols
    romanize_dict = romanize('ru')
    romanize_func = romanize_dict(lambda x: x)
    romanize_result = romanize_func('Привет')
    assert romanize_result == 'Privet'

    # Check if script transliterate cyrillic symbols (ukrainian)
    romanize_dict = romanize('uk')
    romanize_func = romanize_dict(lambda x: x)
    romanize_result = romanize_func('Привіт')
    assert romanize_result == 'Pryvit'

    # Check if script transliterate cyrillic symbols (kazakh)

# Generated at 2022-06-21 15:42:23.218521
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    def romanizer(generated_text):
        return generated_text

    @romanize()
    def romanized_text_ru(generated_text):
        return generated_text

    @romanize(locale='ru')
    def romanized_text_ru_locale(generated_text):
        return generated_text

    cyrillic = data.CYRILLIC_ALPHABET['ru']
    assert cyrillic not in romanizer(cyrillic)
    assert cyrillic not in romanized_text_ru(cyrillic)
    assert cyrillic not in romanized_text_ru_locale(cyrillic)

# Generated at 2022-06-21 15:42:24.851213
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def testfunc():
        return 'тест'

    assert testfunc() == 'test'

# Generated at 2022-06-21 15:44:17.724470
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.person import Person
    p = Person('uk')
    assert p.full_name(' ', False, False, True) == 'Адам Сімкович'
    assert p.full_name(' ', False, False, False) == 'Адам Симкович'

# Generated at 2022-06-21 15:44:21.215045
# Unit test for function romanize
def test_romanize():
    def foo(a='russian'):
        return a
        
    assert 'russian' == foo()
    assert 'russkiy' == foo.__wrapped__('russian')
    assert 'russian' == foo(a='russian')


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:44:26.239530
# Unit test for function romanize
def test_romanize():
    assert romanized() is not None
    assert romanized()('Компьютер') == 'Kompyuter'
    assert romanized('uk')('Компьютер') == 'Komputer'
    assert romanized('kk')('Компьютер') == 'Kompjuter'

# Generated at 2022-06-21 15:44:28.661888
# Unit test for function romanize
def test_romanize():
    assert romanized('Полезная информация')() == 'Poleznaya informaciya'



# Generated at 2022-06-21 15:44:30.026656
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Привет") == "Privet"



# Generated at 2022-06-21 15:44:36.993746
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda: 'Привіт, Світе!')() == 'Pryvit, Svite!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Salem, Dunie!'



# Generated at 2022-06-21 15:44:42.192622
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize('ru')
    def romanizer(text):
        return text
    assert romanizer('Привет') == 'Privet'
    assert romanizer('Добрый день') == 'Dobryj den\' '


# Generated at 2022-06-21 15:44:44.831319
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def r_func():
        return 'Россия'

    assert r_func() == 'Rossiya'

# Generated at 2022-06-21 15:44:45.354431
# Unit test for function romanize
def test_romanize():
    pass



# Generated at 2022-06-21 15:44:49.965662
# Unit test for function romanize
def test_romanize():
    @romanized('uk')
    def test_func(*args):
        return 'компанія Інтернет навколо'.capitalize()
    assert test_func() == 'Kompaniia Internet navkolo'


if __name__ == "__main__":
    test_romanize()