

# Generated at 2022-06-21 15:35:05.010866
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())
    assert callable(romanize)
    assert callable(romanized)



# Generated at 2022-06-21 15:35:06.971380
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Language

    text = Language('ru').word(quantity=10)
    result = Language('ru').romanize(text)
    assert result

# Generated at 2022-06-21 15:35:18.478394
# Unit test for function romanize
def test_romanize():
    s = romanize('ru')(lambda: 'Краткий ответ — да.')()
    assert s == 'Kratkij otvet - da.'

    s = romanize('ru')(lambda: 'Да нет, не кажите так!')()
    assert s == 'Da net, ne kazhite tak!'

    s = romanize('ru')(lambda: 'Когда-нибудь мы снова увидимся.')()
    assert s == 'Kogda-nibud my snova uvidimsya.'


# Generated at 2022-06-21 15:35:21.507366
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text

    t = Text(locale='ru')
    assert t.test_romanize("Привет, Мир!") == 'Privet, Mir!'

# Generated at 2022-06-21 15:35:23.874623
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize('ru')(lambda: 1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1) == 'один'

# Generated at 2022-06-21 15:35:29.020791
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    assert romanize()(lambda: 'Вы') == 'Vy'
    assert romanize(locale='ru')(lambda: 'Вы') == 'Vy'
    assert romanized(locale='ru')(lambda: 'Вы') == 'Vy'
    assert romanize(locale='uk')(lambda: 'ви') == 'vy'
    assert romanize(locale='kk')(lambda: 'хам') == 'kham'

# Generated at 2022-06-21 15:35:38.681479
# Unit test for function romanize
def test_romanize():
    import re
    from mimesis import Person
    p = Person('ru')

    def is_romanized(s: str) -> bool:
        """Check if the string is romanized.

        :param s: String to check.
        :return: True if string is romanized, else False.
        """
        pattern = re.compile(r'[а-яё]')
        return pattern.search(s) is None

    assert is_romanized(p.full_name())

    assert is_romanized(p.name())

    assert is_romanized(p.last_name())

    assert is_romanized(p.patronymic())

    assert is_romanized(p.address())

    assert is_romanized(p.postal_code())

# Generated at 2022-06-21 15:35:43.633348
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Привет')() == "Privet"
    assert romanize('uk')(lambda : 'Привіт')() == "Pryvit"
    assert romanize('kk')(lambda : 'Сәлем')() == "Salem"

# Generated at 2022-06-21 15:35:50.153487
# Unit test for function romanize
def test_romanize():
    local = 'ru'
    from mimesis.enums import Locale

    print(Locale(local))

    from mimesis.providers.internet import Internet
    provider = Internet(local)

    print(provider._random.choice(data.ROMANIZATION_DICT[local].values()))

    # text = provider.username()
    text = provider.domain_name()
    print(text)

    text1 = ''.join([data.ROMANIZATION_DICT[local][i] for i in text])
    print(text1)

    text2 = ''.join([data.ROMANIZATION_DICT[local][i] for i in text if
                     i in data.ROMANIZATION_DICT[local]])
    print(text2)

    locale = local

# Generated at 2022-06-21 15:35:58.401473
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.text import Text

    russian = Text('ru')
    assert russian.romanize('бюро ветеринарной патологии') == \
        'biuro veterinarnoj patologii'

    ukrainian = Text('uk')
    assert ukrainian.romanize('побутові споживчі товари') == \
        'pobutovi spozyvchi tovary'

    kazakh = Text('kk')

# Generated at 2022-06-21 15:36:11.642142
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    import string

    person = Person(locale='ru-RU')
    assert all(
        letter in string.ascii_letters + string.digits
        + string.punctuation + ' '
        for word in person.full_name().split()
        for letter in word
    )
    assert all(
        letter in string.ascii_letters + string.digits
        + string.punctuation + ' '
        for word in person.address().split()
        for letter in word
    )

    person = Person(locale='uk-UA')
    assert all(
        letter in string.ascii_letters + string.digits
        + string.punctuation + ' '
        for word in person.full_name().split()
        for letter in word
    )


# Generated at 2022-06-21 15:36:18.921498
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import Person
    from mimesis.providers.person.ru import Provider as PersonRu
    from mimesis.providers.text import Text

    person = Person().create_person('ru')
    romanized_person = romanize(locale='ru')(PersonRu().create_person)('ru')
    assert person != romanized_person

    assert Text(Language.RUSSIAN.value).romanize() == ''

# Generated at 2022-06-21 15:36:28.047583
# Unit test for function romanize
def test_romanize():
    """Romanize the cyrillic text."""
    romanize = romanize_deco('ru')
    assert romanize('Это тест') == 'Eto test'
    assert romanize('Такое тестирование') == 'Takoe testirovanie'
    assert romanize('Такое тестирование.') == 'Takoe testirovanie.'
    assert romanize('Такое тестирование!') == 'Takoe testirovanie!'

# Generated at 2022-06-21 15:36:29.529317
# Unit test for function romanize
def test_romanize():

    @romanize()
    def romanize_it(some):
        return some

    assert romanize_it('символ') == 'simvol'

# Generated at 2022-06-21 15:36:40.705704
# Unit test for function romanize
def test_romanize():

    assert romanized('ru')(lambda: 'ФЫВАОПЯЧСМИТЬ')() == 'FYVAOPYACHSMIT\''

    assert romanized(locale='ru')(lambda: 'ФЫВАОПЯЧСМИТЬ')() == 'FYVAOPYACHSMIT\''


# Generated at 2022-06-21 15:36:47.196700
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Лорем ипсум долор сит')() == 'Lorem ipsum dolor sit'
    assert romanize('ru')(lambda x: 'Лорем ипсум долор сит')('ru') == 'Lorem ipsum dolor sit'
    assert romanize('uk')(lambda x: 'Лорем ипсум долор сит')('uk') == 'Lorem ipsum dolor sit'

# Generated at 2022-06-21 15:36:51.641955
# Unit test for function romanize
def test_romanize():
    @romanize(locale='en')
    def some_text(value: str) -> str:
        return value
    assert some_text('Привет, мир!') == 'Privet, mir!'

# Generated at 2022-06-21 15:36:57.493791
# Unit test for function romanize
def test_romanize():
    """Unit test for testing romanize."""

    @romanize('ru')
    def test_func(c):
        """Return a string."""
        return 'Привет {}'.format(c)

    assert test_func('мир!') == 'Privet mir!'

# Generated at 2022-06-21 15:37:08.594395
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'privet, mir!'
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'privit, svit!'
    assert romanize('uk')(lambda: 'Привіт, світ!')() == 'privit, svit!'
    assert romanize('kk')(lambda: 'Сәлем, дүние!')() == 'salem, dunie!'

# Generated at 2022-06-21 15:37:19.497169
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    russian_locale = 'ru'
    ukrainian_locale = 'uk'
    kazakh_locale = 'kk'
    cyrillic_text = 'Привет мир!'

    @romanize(russian_locale)
    def foo():
        return cyrillic_text

    @romanize(ukrainian_locale)
    def bar():
        return cyrillic_text

    @romanize(kazakh_locale)
    def baz():
        return cyrillic_text

    with open('tests/test_romanized_ru.txt', 'r') as f:
        assert f.read() == foo()


# Generated at 2022-06-21 15:37:35.509019
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Карабас')() == 'Karabas'
    assert romanize('ru')(lambda: 'Ижевск')() == 'Izhevsk'
    assert romanize('ru')(lambda: 'Панов')() == 'Panov'
    assert romanize('uk')(lambda: 'Дніпро')() == 'Dnipro'
    assert romanize('uk')(lambda: 'Львів')() == 'Lviv'
    assert romanize('kk')(lambda: 'Қазақстан')() == 'Qazaqstan'

# Generated at 2022-06-21 15:37:41.616013
# Unit test for function romanize
def test_romanize():

    @romanize('ru')
    def test_ru():
        return 'тест'

    assert test_ru() == 'test'

    @romanize('uk')
    def test_uk():
        return 'тест'

    assert test_uk() == 'test'

    @romanize('kk')
    def test_kk():
        return 'тест'

    assert test_kk() == 'test'

# Generated at 2022-06-21 15:37:45.196173
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_text(*args, **kwargs):
        return 'Абвгдежзикалмнопрстуфх'

    assert rus_text() == 'AbvgdezhzikaLmnoprstufh'

# Generated at 2022-06-21 15:37:45.701546
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:37:47.458705
# Unit test for function romanize
def test_romanize():
    """Call function romanize to check that script works correctly."""
    pass



# Generated at 2022-06-21 15:37:52.363243
# Unit test for function romanize
def test_romanize():
    @romanize("ru")
    def foo():
        return "Привет, как дела?"
    assert foo() == "Privet, kak dela?"


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-21 15:37:57.086179
# Unit test for function romanize
def test_romanize():
    import mimesis.providers.misc as misc
    @misc.romanize('ru')
    def romanized_text():
        return 'русский язык'
    assert romanized_text() == 'russkiy yazyk'

# Generated at 2022-06-21 15:37:58.044965
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)



# Generated at 2022-06-21 15:38:07.217338
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT
    from mimesis.providers.text import Text
    from mimesis.providers.address import Address

    expected = ['улица Лесная',
                'проспект Мира',
                'улица Шоссейная',
                'улица Горького']
    actual = []
    p = Address(locale='ru')
    p.text = Text(locale='ru')
    # p.text.seed(12345)
    p.rom = romanize('ru')
    p.text.rom = romanize('ru')


# Generated at 2022-06-21 15:38:11.485805
# Unit test for function romanize
def test_romanize():
    cyrillic = 'привет мой друг'
    roman = 'privet moj drug'
    assert romanized(locale='ru')(lambda: cyrillic) == roman, \
        'Romanization failed on {c} to {r}'.format(c=cyrillic, r=roman)

# Generated at 2022-06-21 15:38:20.079097
# Unit test for function romanize
def test_romanize():
    def foo():
        return 'привет'

    foo = romanize()(foo)
    assert foo() == 'privet'

# Generated at 2022-06-21 15:38:23.390734
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rnd_name():
        return 'Артём'

    assert rnd_name() == 'Artem'

# Generated at 2022-06-21 15:38:31.059472
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    table = {
        'ru': 'Privet, mir!',
        'uk': 'Pryvit, svit!',
        'kk': 'Salamat, dünya!',
    }

    def get_text(locale):
        return 'Привет, мир!'

    for locale, text in table.items():
        func = romanize(locale)(get_text)
        assert func(locale) == text

    try:
        func = romanize('zh')(get_text)
        func('zh')
    except UnsupportedLocale as err:
        assert err.args[0] == 'zh'

# Generated at 2022-06-21 15:38:33.197204
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'А')().startswith('A')

# Generated at 2022-06-21 15:38:37.027686
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_func(*args):
        """Test for decorator romanize."""
        return 'тест'

    assert romanize_func() == 'test'



# Generated at 2022-06-21 15:38:39.946765
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'Добро пожаловать!')() == 'Dobro požalovat!'

# Generated at 2022-06-21 15:38:48.586769
# Unit test for function romanize
def test_romanize():
    @romanize()
    def return_text():
        return 'Общественные отношения освобождают принцип действия, '\
            'следовательно, мы можем смело говорить о победе совести.'

    assert return_text() == 'Obshchestvennye otnoshenija osvoboždajut '\
        'printsip dejstvija, sledovatel\'no, my možem smelo govorit\' o '\
       

# Generated at 2022-06-21 15:38:49.070762
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-21 15:38:50.747635
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Слово')() == 'Slovo'

# Generated at 2022-06-21 15:38:55.717484
# Unit test for function romanize
def test_romanize():
    text='фыва'
    
    romanized_text=romanized('ru')(lambda: text)()
    assert romanized_text=='fiva'
    
    romanized_text=romanized('uk')(lambda: text)()
    assert romanized_text=='fyva'

    romanized_text=romanized('kk')(lambda: text)()
    assert romanized_text=='ғыва'


# Generated at 2022-06-21 15:39:16.698523
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'А Б В Г Д Е Ж З И Й К Л М Н О П Р С Т У Ф Х Ц Ч Ш Щ Ъ Ы Ь Э Ю Я')('') == 'A B V G D E Zh Z I Y K L M N O P R S T U F Kh Ts Ch Sh Shch \' Y \' E Yu Ya'

# Generated at 2022-06-21 15:39:25.878813
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider
    assert provider.romanize()('Тонна', 'ru') == 'Tonna'
    assert provider.romanize()('Замовлення', 'ru') == 'Zamovlennia'
    assert provider.romanize()('словник', 'uk') == 'slovnyk'
    assert provider.romanize()('Бақылау', 'kk') == 'Baqulya'
    assert provider.romanize()('Статистика', 'kk') == 'Statystyka'

# Generated at 2022-06-21 15:39:28.584781
# Unit test for function romanize
def test_romanize():
    # noinspection PyUnusedLocal
    @romanize('ru')
    def f(x):
        return 'русский'

    assert f(1) == 'russkii'

# Generated at 2022-06-21 15:39:36.410249
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Привет") == "Privet"
    assert romanize("ru")("Здравствуйте") == "Zdravstvuyte"
    assert romanize("ru")("Пока") == "Poka"
    assert romanize("ru")("Петр") == "Petr"
    assert romanize("ru")("Иван") == "Ivan"
    assert romanize("ru")("Купи слона") == "Kupi slona"
    assert romanize("ru")("Колобок") == "Kolobok"

# Generated at 2022-06-21 15:39:44.642514
# Unit test for function romanize
def test_romanize():
    def func():
        return 'Страны СНГ это Азербайджан, Беларусь, Казахстан, Киргизия, \
            Молдова, Россия, Таджикистан, Туркменистан, Узбекистан и \
            Украина.'

    romanize()(func)()

# Generated at 2022-06-21 15:39:46.860003
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod(verbose=True, extraglobs={
        'translate': romanize('ru'),
    })

# Generated at 2022-06-21 15:39:49.721726
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')
    assert romanize('en') == romanize('')

# Generated at 2022-06-21 15:39:53.768455
# Unit test for function romanize
def test_romanize():
    romanized_func = romanize('ru')(lambda x='': x)
    text = 'привет'
    assert romanized_func(text) == 'privet'

    with raises(UnsupportedLocale):
        romanized_func('hello')

# Generated at 2022-06-21 15:40:00.663907
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian_text(length: int = 8) -> str:
        return ''.join([data.CYRILLIC[i] for i in range(length)])

    assert russian_text() == 'АБВГДЕЖЗ'

    @romanize('uk')
    def ukrainian_text(length: int = 8) -> str:
        return ''.join([data.CYRILLIC[i] for i in range(length)])

    assert ukrainian_text() == 'АБВҐДЕЄЖ'

# Generated at 2022-06-21 15:40:03.617274
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanized_text():
        return 'Это моя строка!'

    assert romanized_text() == 'Eto moja stroka!'

# Generated at 2022-06-21 15:40:32.938677
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_text():
        return 'Я проснулся и понял, что превратился в слона.'

    assert russian_text() == 'YA prosnulsya i ponyal, chto prevratilsya v slona.'

# Generated at 2022-06-21 15:40:42.573362
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.display import Display
    from mimesis.providers.language import Language
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science


# Generated at 2022-06-21 15:40:53.489683
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "Здравствуй, мир!")() == "Zdravstvuy, mir!"
    assert romanize('ru')(lambda: "     Здравствуй!")() == "     Zdravstvuy!"
    assert romanize('kk')(lambda: "Мен казактың танысым")() == "Men kazaktyń tanysym"

# Generated at 2022-06-21 15:40:59.156883
# Unit test for function romanize
def test_romanize():
    # format of the data
    # {'ru-ru': ('Манчестер Юнайтед', 'Манчестер Юнайтед'),
    #  'uk-ua': ('Манчестер Юнайтед', 'Манчестер Юнайтед'),
    #  'kk-kz': ('Манчестер Юнайтед', 'Манчестер Юнайтед'),}
    from mimesis import Generic
    gen = Generic('ru')

# Generated at 2022-06-21 15:41:02.812142
# Unit test for function romanize
def test_romanize():
    romanize_string = romanize('ru')('Привет мир!')
    assert romanize_string == 'Privet mir!'

# Generated at 2022-06-21 15:41:09.025413
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Address
    a = Address()

    assert a._ru.get_address(romanize=True) == 'pr. Volkonskogo, d. 49, ...'
    assert a._uk.get_address(romanize=True) == 'pr. Volkonskogo, b. 49, ...'
    assert a._kk.get_address(romanize=True) == 'pr. Volkonskogo, q. 49, ...'



# Generated at 2022-06-21 15:41:19.122973
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_test(a: str = '', b: str = ''):
        print(a + b)

    @romanized()
    def romanized_test(a: str = '', b: str = ''):
        print(a + b)

    romanize_test('a', 'b')
    romanized_test('a', 'b')
    try:
        romanize_test('a', 'b', 'c')
    except TypeError:
        print('TypeError')
    try:
        romanize_test('a', 'b', b='c')
    except TypeError:
        print('TypeError')
    try:
        romanize_test('a', 'b', a='c')
    except TypeError:
        print('TypeError')

# Generated at 2022-06-21 15:41:25.926321
# Unit test for function romanize
def test_romanize():
    """Test for romanize ."""
    @romanize('ru')
    def func(result):
        return result

    assert func('Я работаю в России') == 'Ya rabotayu v Rossii'
    assert func('') == ''

# Generated at 2022-06-21 15:41:27.177883
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()

# Generated at 2022-06-21 15:41:34.279227
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: "Мир")() == "Mir"
    assert romanize("ru")(lambda: "Мир")() == "Mir"
    assert romanize("uk")(lambda: "Мир")() == "Mir"
    assert romanize("kk")(lambda: "Мир")() == "Mir"

    try:
        assert romanize("en")(lambda: "Мир")() == "Mir"
    except UnsupportedLocale as e:
        assert str(e) == "en is not supported."
    else:
        assert "This should not be a result."

# Generated at 2022-06-21 15:42:46.653586
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-21 15:42:50.583058
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian(text):
        return text

    assert russian('Привет, человек!') == 'Privet, chelovek!'

    # Test for backward compatibility
    @romanized(locale='ru')
    def russian(text):
        return text
    assert russian('Привет, человек!') == 'Privet, chelovek!'



# Generated at 2022-06-21 15:43:01.250673
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Добрый день!') == 'Dobryj denʹ!'

    @romanize(locale='uk')
    def romanize_uk(text):
        return text

    assert romanize_uk('Доброго дня!') == 'Dobroho dnia!'

# Generated at 2022-06-21 15:43:05.076821
# Unit test for function romanize
def test_romanize():
    """Test for the romanize function."""
    assert romanize(locale='ru')(lambda x: 'Например, текст')() == \
           'Naprimer, tekst'

# Generated at 2022-06-21 15:43:09.603710
# Unit test for function romanize
def test_romanize():
    """Function romanize testing"""
    def r_func():
        """romanization function"""
        return 'Мимесис'

    romanized_func = romanize('ru')(r_func)

    assert romanized_func() == 'Mimesis'

# Generated at 2022-06-21 15:43:20.062481
# Unit test for function romanize
def test_romanize():
    import datetime
    from mimesis.builtins import Persona

    @romanize()
    def romanized_name(surname, name):
        return surname + name

    def romanized_dt():
        today = datetime.date.today()
        return f'{today.day}.{today.month}.{today.year}'

    p = Persona()
    print(p.name())

    print(p.full_name())
    print(p.full_name(romanize=True))
    print(romanized_name(p.surname(), p.name()))
    print(romanized_dt())


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:43:27.983860
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Добрый день')() == 'Dobriy den'
    assert romanize()(lambda: 'Добрый день')(locale='ru') == 'Dobriy den'
    assert romanize()(lambda: 'Добрый день')(locale='uk') == 'Dobrij den'
    assert romanize('uk')(lambda: 'Добрый день')() == 'Dobrij den'
    assert romanize(locale='uk')(lambda: 'Добрый день')() == 'Dobrij den'



# Generated at 2022-06-21 15:43:30.069900
# Unit test for function romanize
def test_romanize():
    @romanize
    def get_name():
        return 'United States'

    assert get_name('en') == 'United States'



# Generated at 2022-06-21 15:43:36.134849
# Unit test for function romanize
def test_romanize():
    result = "Иногда не очень понятно, что делает данная функция."
    expected = "Inogda ne ochen' poniatno, chto delaet dannaia funktsiia."
    assert result == expected



# Generated at 2022-06-21 15:43:37.382063
# Unit test for function romanize
def test_romanize():
    assert romanized == romanize

