

# Generated at 2022-06-21 15:35:07.831898
# Unit test for function romanize
def test_romanize():
    def _romanize(i):
        _alphabet = {s: s for s in
                     ascii_letters + digits + punctuation}
        _alphabet.update({
            **data.ROMANIZATION_DICT['ru'],
            **data.COMMON_LETTERS,
        })
        return ''.join([_alphabet[j] for j in i if j in _alphabet])

    # Test for romanize decorator
    @romanize(locale='ru')
    def f():
        return 'Привет, мир!'

    assert ''.join([_romanize(i) for i in 'Привет, мир!']) == 'Privet, mir!'
    assert f() == 'Privet, mir!'

# Generated at 2022-06-21 15:35:19.122147
# Unit test for function romanize
def test_romanize():

    # test for romanized function
    @romanized('ru')
    def russian_text() -> str:
        return 'И так до сих пор'

    @romanized('ru')
    def russian_text_with_punctuation() -> str:
        return 'Еще и танцует. Ты и не спроси - как.'

    @romanized('ru')
    def russian_text_with_ascii() -> str:
        return 'Не то что гугл, а уж python.org.'

    @romanized('uk')
    def ukrainian_text() -> str:
        return

# Generated at 2022-06-21 15:35:26.604519
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет сосед!')() == 'Privet sosed!'
    assert romanized('uk')(lambda: 'Привіт сусіде!')() == 'Pryvit susyde!'
    assert romanized('kk')(lambda: 'Сәлем қосым!')() == 'Seliem qosym!'
    assert romanized('en')(lambda: 'Привет сосед!')() == 'Привет сосед!'

# Generated at 2022-06-21 15:35:37.729381
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import UKSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider

    class Person(BaseProvider):

        def __init__(self):
            super().__init__('ru')
            self.__person = UKSpecProvider(self.locale)

        @romanize('ru')
        def full_name(self, gender: Gender = None) -> str:
            """Get full name.

            :param gender: Gender
            :return: Full name.
            """
            return self.__person.full_name(gender=gender)

    p = Person()
    assert p.full_name('f') == 'Tatjana'
    assert p.full_name(gender=Gender.FEMALE) == p.full_name('f')

# Generated at 2022-06-21 15:35:47.144333
# Unit test for function romanize
def test_romanize():
    import string

    p = string.punctuation

    @romanize(locale='ru')
    def sample():
        return 'Эх эй Александр!'

    assert sample() == 'Эх эй Александр!'

    @romanize(locale='uk')
    def sample():
        return 'Ехо Яна вулиці!'

    assert sample() == 'Eho Yana vulytsi!'

    @romanize(locale='kk')
    def sample():
        return 'Мен келемін'

    assert sample() == 'Men kelemіn'


# Generated at 2022-06-21 15:35:55.794095
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.lorem import Lorem

    # test romanize for Russian
    lorem = Lorem(Language.RUSSIAN)
    lorem.seed(4)
    # create romanized string
    roman_str = lorem.text(20, ext_word_list=None)
    roman_str = ''.join([lorem.character(uppercase=False) for i in range(20)])
    print(roman_str)
    print(lorem.romanize(roman_str))

    numbers = Numbers(Language.RUSSIAN)
    numbers.seed(4)

# Generated at 2022-06-21 15:35:57.804561
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def foo():
        return 'Привет, мир!'

    assert foo() == 'Privet, mir!'

# Generated at 2022-06-21 15:36:09.433719
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.enums import SpecialChar
    from mimesis.providers.personal import Person

    def romanize_test(txt: str, locale: str) -> str:
        """Romanize text.

        :param txt: Text to romanize.
        :param locale: Language of the text.
        :return: Romanized text.
        """
        p = Person(locale)
        return p.romanize(txt)

    text = 'Привет, как дела?'
    assert text == romanize_test(text, Language.RUSSIAN)
    assert text == romanize_test(text, Language.UKRAINIAN)


# Generated at 2022-06-21 15:36:12.933437
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize(locale='ru')(lambda: data.ROMANIZATION_DICT['ru'].keys())() == data.ROMANIZATION_DICT['ru'].values()

# Generated at 2022-06-21 15:36:23.512547
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    from mimesis.enums import Locale
    from mimesis.providers.internet import Internet

    # Test provider without romanize decorator.
    inet = Internet()
    assert inet.domain_name(locale=Locale.UK) == 'mail.kz'

    # Test provider with decorator.
    inet_ru = Internet(locale=Locale.RU)
    assert inet_ru.domain_name() == 'mail.ru'

    # Test other decorators.
    from mimesis.providers.transport import Transport

    t = Transport()
    assert t.vehicle_model() == 'ЗИЛ-131'
    t_ru = Transport(locale=Locale.RU)
    assert t_ru.vehicle_model

# Generated at 2022-06-21 15:36:33.385213
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_str():
        return 'Это русская проверка'

    assert rus_str() == 'Jeto russkaya proverka'

# Generated at 2022-06-21 15:36:38.174141
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import RussianSpecProvider
    sp = RussianSpecProvider(locale=RussianSpecProvider.LOCALE)
    #: Dummy romanization
    assert sp._romanize(sp.random_letter(), RussianSpecProvider.LOCALE) == ''

# Generated at 2022-06-21 15:36:39.134877
# Unit test for function romanize
def test_romanize():
    try:
        romanized('ru')(lambda: 'Привет')()
    except UnsupportedLocale:
        pass

# Generated at 2022-06-21 15:36:45.060889
# Unit test for function romanize
def test_romanize():
    """Testing romanize function."""
    def roman(locale: str = '') -> str:
        @romanize(locale)
        def roman_locale(_locale: str = '') -> str:
            return _locale
        return roman_locale(locale)

    assert roman() == ''
    assert roman(locale='ru') == 'ru'
    assert roman(locale='uk') == 'uk'
    assert roman(locale='kk') == 'kk'

    with pytest.raises(UnsupportedLocale):
        roman(locale='us')

# Generated at 2022-06-21 15:36:47.807055
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize()
    assert romanize('ru')
    assert romanize('uk')

# Generated at 2022-06-21 15:36:56.148465
# Unit test for function romanize
def test_romanize():
    """Function tests romanize decorator."""
    import unittest

    class RomanizeTestCase(unittest.TestCase):
        """Test case for romanize decorator"""

        @romanize('ru')
        def russian(self, _str):
            """Russian language."""
            return _str

        def test_ru_romanize(self):
            """Test romanized ru text."""
            s = self.russian('Легко и приятно пользоваться модулем mimesis.')
            result = 'Legko i prijatno polzovat’sa modulom mimesis.'
            self.assertEqual(s, result)

    unittest.main()

# Generated at 2022-06-21 15:36:57.106832
# Unit test for function romanize
def test_romanize():
    import inspect

    assert inspect.getsource(romanize)

# Generated at 2022-06-21 15:36:59.674187
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test():
        return u'Привет мир!'

    assert test() == 'Privet mir!'

# Generated at 2022-06-21 15:37:04.172737
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    from . import Person

    p = Person(Language.ENGLISH)
    name = p.full_name()

    assert len(name) > 0

    p.set_locale('ru')
    name_ru = p.full_name()

    assert len(name_ru) > 0

# Generated at 2022-06-21 15:37:12.159701
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.personal import Personal

    russian = Personal(locale=Locale.RU)
    house = Address(locale=Locale.RU)
    assert russian.surname() == romanize(Locale.RU)(Personal.surname.__wrapped__)()
    assert house.address() != romanize(Locale.RU)(Address.address.__wrapped__)()

# Generated at 2022-06-21 15:37:25.487605
# Unit test for function romanize
def test_romanize():
    r = data.Address(locale='ru')
    assert romanize(locale='ru')(r.city) == r.city_ascii



# Generated at 2022-06-21 15:37:29.524021
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins
    b = mimesis.builtins.Builtins()
    assert b.cyrillic_letter().romanize() in data.CYRILLIC_ALPHABET
    assert b.person.full_name().romanize('ru')

# Generated at 2022-06-21 15:37:31.618684
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo(x):
        return x

    assert foo('Привет') == 'Privet'

# Generated at 2022-06-21 15:37:33.997486
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-21 15:37:44.399785
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    @romanize()
    def _(s):
        return s

    assert _('Привет мир') == 'Privet mir'
    assert _('Привет мир, а не только привет') == 'Privet mir, a ne tol\'ko privet'
    assert _('Привет мир, Привет мир') == 'Privet mir, Privet mir'

    @romanize('ru')
    def _(s):
        return s

    assert _('Привет мир') == 'Privet mir'

# Generated at 2022-06-21 15:37:49.082650
# Unit test for function romanize
def test_romanize():
    dict_one = {'А': 'A', 'а': 'a'}
    dict_two = {'А': 'A', 'а': 'a', 'я': 'ia'}
    d = {}
    d.update(dict_one)
    d.update(dict_two)
    assert d == {'А': 'A', 'а': 'a', 'я': 'ia'}


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:37:50.862156
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func():
        pass

    func()

# Generated at 2022-06-21 15:37:54.348620
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'кириллица')('лепс') == 'leps'



# Generated at 2022-06-21 15:37:56.334602
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Строка')() == 'Stroka'
    assert romanize(locale='uk')(lambda: 'Строка')() == 'Stroka'
    assert romanize(locale='kk')(lambda: 'Строка')() == 'Stroka'

# Generated at 2022-06-21 15:37:57.997748
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: "Привет!")() == 'privet!'

# Generated at 2022-06-21 15:38:26.717664
# Unit test for function romanize
def test_romanize():
    # Add this test as _test_romanize in __init__.py.
    def some_method(arg):
        return arg + 'абвгдеёжзи'

    def some_method_after_decoration(arg):
        return ''.join([data.ROMANIZATION_DICT['ru'][i]
                        if i in data.ROMANIZATION_DICT['ru']
                        else i for i in arg + 'абвгдеёжзи'])

    def some_method_no_arg(arg):
        return arg + 'абвгдеёжзи'


# Generated at 2022-06-21 15:38:34.451231
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import RussiaSpecProvider

    validate = RussiaSpecProvider()

    assert validate.last_name().lower() == 'смирнов'
    assert validate.romanize_last_name().lower() == 'smirnov'
    assert validate.romanize_last_name('uk').lower() == 'smirnov'
    assert validate.romanize_last_name('kk').lower() == 'smirnov'
    assert validate.romanize_last_name('kk') == 'Smirnov'

    assert validate.romanize_last_name('ru').lower() == 'smirnov'
    assert validate.romanize_last_name('ru') == 'Smirnov'


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-21 15:38:37.953669
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Привет, мир!") == 'Privet, mir!'

# Generated at 2022-06-21 15:38:39.177482
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()

# Generated at 2022-06-21 15:38:42.928707
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')('бык') == 'byk'
    assert romanized(locale='uk')('зохай') == 'zokhai'
    assert romanized(locale='kk')('жазан') == 'jazan'

# Generated at 2022-06-21 15:38:51.850068
# Unit test for function romanize
def test_romanize():
    import unittest

    def romanize_func(text: str) -> str:
        return text

    class RomanizeTest(unittest.TestCase):
        @romanize(locale='ru')
        def test_romanize_func(self, text: str) -> str:
            return romanize_func(text)

        def test_romanize_function(self):
            func = romanize(locale='ru')(romanize_func)
            self.assertEqual(func, romanize_func)

        @romanize(locale='uk')
        def test_romanize_ru(self, text: str) -> str:
            return romanize_func(text)


# Generated at 2022-06-21 15:38:57.672668
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian(seed=None):
        return "Мимими мим"

    assert russian() == 'Mimimi mim'

    @romanize('uk')
    def ukranian(seed=None):
        return "Мімімі мім"

    assert ukranian() == 'Mimimi mim'

    @romanize('kk')
    def kazakh(seed=None):
        return "Мімімі мім"

    assert kazakh() == 'Mimimi mim'

# Generated at 2022-06-21 15:39:08.611793
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    p = Person('ru')
    assert p.full_name(gender=Gender.MALE) == 'Виктор Филатов'
    assert p.full_name(gender=Gender.FEMALE) == 'Ирина Костандовна'
    assert p.surname(gender=Gender.MALE) == 'Тарахов'
    assert p.surname(gender=Gender.FEMALE) == 'Кувалова'
    assert p.username(gender=Gender.MALE) == 'ФилатовВиктор'

# Generated at 2022-06-21 15:39:09.795579
# Unit test for function romanize
def test_romanize():
    assert romanize()('привет') == 'privet'

# Generated at 2022-06-21 15:39:15.843107
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')
    for _ in range(50):
        assert set(p.full_name(gender=Gender.MALE).lower()) \
            - set(p.full_name(gender=Gender.MALE, romanize=True).lower()) == set()
        assert set(p.full_name(gender=Gender.FEMALE).lower()) \
            - set(p.full_name(gender=Gender.FEMALE, romanize=True).lower()) == set()

# Generated at 2022-06-21 15:40:04.889487
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize.
    """
    @romanize(locale='ru')
    def romanized_str():
        """The function that will be decorated.
        """
        return 'Привет'

    assert romanized_str() == 'privet'

# Generated at 2022-06-21 15:40:09.458449
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""
    from mimesis.enums import SpecialChar
    from mimesis.providers.misc import Misc

    misc = Misc()
    misc.set_language('ru')

    assert misc.romanize().startswith(SpecialChar.LETTER)
    assert isinstance(misc.romanize('ru'), str)

# Generated at 2022-06-21 15:40:12.901637
# Unit test for function romanize
def test_romanize():
    func = romanize('ru')(lambda: 'Привет')
    romanized_text = func()
    assert romanized_text == 'Privet'



# Generated at 2022-06-21 15:40:21.135981
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'

    assert romanize()(lambda: 'Привіт, Світ?!')() == 'Pryvit, Svit?!'
    assert romanize('uk')(lambda: 'Привіт, Світ?!')() == 'Pryvit, Svit?!'


# Generated at 2022-06-21 15:40:24.794574
# Unit test for function romanize
def test_romanize():
    romanized_text = romanize('ru')
    @romanized_text
    def get_text():
        return 'Привет, мир!'

    assert get_text() == 'Privet, mir!'

# Generated at 2022-06-21 15:40:29.793796
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    rp = RussianSpecProvider()

    assert rp.romanize('Привет, мир!') == 'Privet, mir!'



# Generated at 2022-06-21 15:40:35.866965
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('ru')(lambda: 'Здравствуйте, друг')() == 'Zdravstvuyte, drug'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('uk')(lambda: 'Супер')() == 'Super'
    assert romanize('kk')(lambda: 'Салам алейкум')() == 'Salam alaĭkum'

# Generated at 2022-06-21 15:40:40.049328
# Unit test for function romanize
def test_romanize():
    """Test function for romanize."""
    from mimesis.text import Text

    @romanize('ru')
    def romanize_ru(word):
        return word

    txt = Text()
    result = romanize_ru(txt.word())
    print(result)


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-21 15:40:50.566645
# Unit test for function romanize
def test_romanize():
    romanized_string = 'Кошка которая умеет мау'
    alphabet = ascii_letters + digits + punctuation
    translit = ''.join([data.ROMANIZATION_DICT['ru'][i] for i in romanized_string if i in data.ROMANIZATION_DICT['ru']])
    assert translit == 'Koshka kotoraya umeyet mau'

# Generated at 2022-06-21 15:40:55.797392
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def romanize_(text) -> str:
        return text

    assert romanize_(
        'На ходу можно сдать зачёт и получить кредитные баллы.') == \
        'Na khodu mozhno sdat\' zachet i poluchit\' kreditnye balli.'

# Generated at 2022-06-21 15:43:24.826633
# Unit test for function romanize
def test_romanize():
    def test_func(num: int) -> str:
        return str(num)

    num = 5
    roman_func = romanize('ru')(test_func)
    assert roman_func(num) == '5'

# Generated at 2022-06-21 15:43:27.264369
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanized)

    @romanized('ru')
    def foo():
        return 'фуу'

    assert foo() == 'fuu'

# Generated at 2022-06-21 15:43:31.611150
# Unit test for function romanize
def test_romanize():
    _list = ['ru', 'uk', 'kk']
    for _locale in _list:
        _text = romanize(_locale)
        res = _text('Привет Мир!')
        msg = 'Failed with locale {}'.format(_locale)
        assert res == 'Privet Mir!', msg

# Generated at 2022-06-21 15:43:43.734262
# Unit test for function romanize
def test_romanize():
    assert romanized('ru') == romanize('ru')
    assert romanized('uk') == romanize('uk')
    assert romanized('kk') == romanize('kk')

    @romanize('ru')
    def russian_string():
        return 'Привет, мир!'

    @romanize('uk')
    def ukrainian_string():
        return 'Вітаю, світ!'

    @romanize('kk')
    def kazakh_string():
        return 'Құралым құтты!'

    assert russian_string() == 'Privet, mir!'
    assert ukrainian_string() == 'Vitayu, svit!'
    assert kazakh

# Generated at 2022-06-21 15:43:53.365430
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'мимимимимимимимимимимимимими')(
    ) == 'mimimimimimimimimimimimimimimimimimimimimimimimimim'



# Generated at 2022-06-21 15:43:55.007578
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Тест на русском')() == 'Test na russkom'

# Generated at 2022-06-21 15:44:01.743221
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address
    address = Address()
    assert address.address() == "Коммунистическая, д. 24, кв. 134"
    address = Address(locale="ru-RU")
    assert address.address() == "Kommunisticheskaya, d. 24, kv. 134"



# Generated at 2022-06-21 15:44:11.842999
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')((lambda: 'Короче, вы не послушаетесь?'))() == \
        'Koroche, vi ne poslušaetes?'
    assert romanize('uk')((lambda: 'В людині саме дитинство є вічністю. '
                                   'Все в нас інше змінюється:'))() == \
        'V liudyni same dytinstvo ie vičnistiu. Vse v nas inshe zmińuietʹsia:'


# Generated at 2022-06-21 15:44:15.057147
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Иван') == 'Ivan'
    assert romanize('kk')('Иван') == 'Ivan'
    assert romanize('uk')('Иван') == 'Ivan'



# Generated at 2022-06-21 15:44:23.094048
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Sälem'
    assert romanize(locale='kk')(lambda: 'Электрондық пошта')() == 'Elektrondyq poşta'
    assert romanize(locale='de')(lambda: 'Привет')() == 'Привет'