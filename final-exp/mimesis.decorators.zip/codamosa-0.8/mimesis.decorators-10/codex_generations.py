

# Generated at 2022-06-12 01:24:56.058018
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanize('ru'))
    assert callable(romanized)
    assert callable(romanized('ru'))

# Generated at 2022-06-12 01:25:00.149541
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    class TestPerson(Person):
        @romanize('ru')
        def full_name(self) -> str:
            return super().full_name()

    assert TestPerson().full_name() == 'Петр Иванов'

# Generated at 2022-06-12 01:25:08.313657
# Unit test for function romanize
def test_romanize():

    @romanized('ru')
    def ru():
        return 'Богдан'

    @romanized('uk')
    def uk():
        return 'Богдан'

    @romanized('be')
    def be():
        return 'Богдан'

    assert ru() == 'Bogdan'
    assert uk() == 'Bohdan'
    assert be() == 'Bohdan'  # Actually it's Bogdan in Belarusian



# Generated at 2022-06-12 01:25:13.790368
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Россия')() == 'Rossiya'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-12 01:25:24.791198
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Комп") == "Komp"
    assert romanize("ru")("Привет, как дела?") == "Privet, kak dela?"
    assert romanize("ru")("Привет, как дела?!") == "Privet, kak dela?!"
    assert romanize("ru")("Сколько стоит билет?") == "Skol'ko stoit bilet?"
    assert romanize("ru")("Когда вылетели в Токио?") == "Kogda vyletelyi v Tokiyo?"
    assert roman

# Generated at 2022-06-12 01:25:27.920879
# Unit test for function romanize
def test_romanize():
    text = "c неба падали платиновые капли. Это был Платон."
    result = romanize('ru')(lambda: text)()
    assert result == 's neba padali platino\'vыe kapli. Ёto bыl Plato\'n.'

# Generated at 2022-06-12 01:25:36.936186
# Unit test for function romanize
def test_romanize():
    # Test romanize decorator with russian locale
    @romanize('ru')
    def roman_ru(text):
        return text
    assert roman_ru('Привет') == 'privet'

    # Test romanize decorator with ukrainian locale
    @romanize('uk')
    def roman_uk(text):
        return text
    assert roman_uk('Привіт') == 'privit'

    # Test romanize decorator with kazakh locale
    @romanize('kk')
    def roman_kk(text):
        return text
    assert roman_kk('Сәлем') == 'salem'

    # Test romanize decorator with wrong locale

# Generated at 2022-06-12 01:25:43.313781
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT
    from mimesis.data import COMMON_LETTERS

    for locale in ROMANIZATION_DICT.keys():
        for key, value in ROMANIZATION_DICT[locale].items():
            assert type(key) is str
            assert type(value) is str

    for key, value in COMMON_LETTERS.items():
        assert type(key) is str
        assert type(value) is str

# Generated at 2022-06-12 01:25:45.969515
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    p = Person('ru')
    r = romanize('ru')(p.full_name)
    assert r

# Generated at 2022-06-12 01:25:49.693438
# Unit test for function romanize
def test_romanize():
    """Test function romanize"""
    @romanize()
    def get_api():
        return 'Привет, Мир!'
    assert get_api() == 'Privet, Mir!'

# Generated at 2022-06-12 01:26:06.376863
# Unit test for function romanize
def test_romanize():
    table_dev_to_rus = {
        'A': 'А',
        'B': 'Б',
        'E': 'Е',
        'H': 'Н',
        'K': 'К',
        'M': 'М',
        'O': 'О',
        'P': 'Р',
        'T': 'Т',
        'X': 'Х',
        'a': 'а',
        'b': 'б',
        'c': 'к',
        'e': 'е',
        'h': 'н',
        'k': 'к',
        'm': 'м',
        'o': 'о',
        'p': 'р',
        't': 'т',
        'x': 'х',
    }

    table_rus_

# Generated at 2022-06-12 01:26:10.097718
# Unit test for function romanize
def test_romanize():
    result = romanize()(lambda: "hello")()
    assert result == 'hello'

    assert romanize('ru')(
        lambda: 'Привет, мир!')().lower() == 'privet, mir!'

# Generated at 2022-06-12 01:26:19.486790
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text.latin
    r = mimesis.builtins.text.latin.LatinText()
    # r = Romanizer("ru")
    # r = Romanizer("uk")
    r = Romanizer("kk")

    result = r.romanize("Привет, мир!")
    assert result == 'Salem, aʺı!'
    result = r.romanize("До свидания, мир!")
    assert result == 'Aı, aʺı!'
    result = r.romanize("Как дела?")
    assert result == 'Qaıda bar?'

# Generated at 2022-06-12 01:26:21.843237
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет мир')() == 'Privet mir'

# Generated at 2022-06-12 01:26:28.941610
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize()(str)('Страна  Земля') == 'Strana  Zemlya'
    assert romanize('uk')(str)('Страна  Земля') == 'Strana  Zemlia'
    assert romanize('kk')(str)('Страна  Земля') == 'Strana  Zeml\'a'

# Generated at 2022-06-12 01:26:32.617117
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text
    from mimesis.utils import text

    txt = Text(Language.RUSSIAN)

    @romanize(locale=Language.RUSSIAN)
    def roman(return_ascii=True):
        return txt.word(return_ascii=return_ascii)

    assert text.romanize(txt.word(return_ascii=True)) == \
        roman()



# Generated at 2022-06-12 01:26:38.644284
# Unit test for function romanize
def test_romanize():
    for i in range(1000):
        assert romanize('uk')('привіт')(), 'privyt'
        assert romanize('ru')('привет')(), 'privet'
        assert romanize('kk')('сәлем')(), 'salem'

# Generated at 2022-06-12 01:26:39.980716
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: None)() == ''

# Generated at 2022-06-12 01:26:47.173601
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""

    from mimesis.builtins import Person, Address

    p = Person('uk')
    assert p._locale == 'uk'
    person = p.full_name(gender='female')
    assert person == p.romanized(person)

    p = Person('ru')
    assert p._locale == 'ru'
    person = p.full_name(gender='female')
    assert person == p.romanized(person)

    a = Address('kk')
    assert a._locale == 'kk'
    place = a.address()
    assert place == a.romanized(place)

    a = Address('ru')
    assert a._locale == 'ru'
    place = a.address()
    assert place == a.romanized(place)

    a = Address('en')

# Generated at 2022-06-12 01:26:50.185123
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda x: 'привет')() == 'privet'
    assert romanize('kk')(lambda x: 'привет')() == 'prıvet'



# Generated at 2022-06-12 01:26:57.420567
# Unit test for function romanize
def test_romanize():
    s = romanize(locale='ru')(lambda *args, **kwargs: ['а', 'б', 'в', 'г'])
    assert s == 'abvg'

# Generated at 2022-06-12 01:26:59.507971
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    text_ru = Text('ru')
    assert text_ru.romanized('Привет, мир!') == 'Privet, mir!'

# Generated at 2022-06-12 01:27:11.367488
# Unit test for function romanize
def test_romanize():
    assert 'тест' == romanized('ru')(lambda: 'тест')()
    assert 'тест' == romanized('uk')(lambda: 'тест')()
    assert 'тест' == romanized('kk')(lambda: 'тест')()

    assert 'test' == romanized('ru')(lambda: 'test')()
    assert 'test' == romanized('uk')(lambda: 'test')()
    assert 'test' == romanized('kk')(lambda: 'test')()

    assert 'тест' == romanized('ru')(lambda: 'тест')()
    assert 'тест' == romanized('uk')(lambda: 'тест')()

# Generated at 2022-06-12 01:27:22.080243
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def ru_word():
        return 'привет'

    assert ru_word() == 'privet'

    @romanized('ru')
    def ru_sentence():
        return 'привет, мир'

    assert ru_sentence() == 'privet, mir'

    @romanized('uk')
    def uk_word():
        return 'тосморе'

    assert uk_word() == 'tosmore'

    @romanized('uk')
    def uk_sentence():
        return 'тосморе, світ'

    assert uk_sentence() == 'tosmore, svit'

# Generated at 2022-06-12 01:27:25.666163
# Unit test for function romanize
def test_romanize():
    romanized_numbers = {
        'ru_RU': (1, 'I'),
        'uk_UA': (1, 'I'),
        'kk_KZ': (1, 'БІР'),
    }

    for locale, number in romanized_numbers.items():
        assert romanize(locale)(number[0]) == number[1]



# Generated at 2022-06-12 01:27:34.651819
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo(x):
        return x

    assert foo('') == ''
    assert foo('Как жизнь?') == 'Kak zhizn?'
    assert foo('Я люблю тебя!') == 'Ya lyublyu tebya!'
    assert foo('Я люблю тебя! 2') == 'Ya lyublyu tebya! 2'
    assert foo('Зима') == 'Zima'
    assert foo('Зима? да!') == 'Zima? da!'

# Generated at 2022-06-12 01:27:40.001717
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: '')() == ''
    assert romanize('uk')(lambda: '')() == ''
    assert romanize('kk')(lambda: '')() == ''
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-12 01:27:43.841210
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test(seed: int = 0) -> str:
        return 'Что-то'

    result = test()
    assert result == 'Chto-to', 'Invalid output.'

# Generated at 2022-06-12 01:27:51.023515
# Unit test for function romanize
def test_romanize():
    test_data = {
        ('ru', 'привет'): 'privet',
        ('uk', 'привiт'): 'pryvit',
        ('kk', 'сәлем'): 'salem',
        ('de', 'привет'): 'привет',
    }
    for k, v in test_data.items():
        @romanize(locale=k[0])
        def r():
            return k[1]
        assert r() == v

# Generated at 2022-06-12 01:27:54.917722
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize('ru')('Привет') == 'Privet'
    assert romanize('kk')('Сәлем') == 'Sälem'
    assert romanize('uk')('Привіт') == 'Pryvit'

# Generated at 2022-06-12 01:28:11.750287
# Unit test for function romanize
def test_romanize():
    class Test:
        @romanize('ru')
        def get_name(self):
            return 'Халк'

        @romanize('ru', 'uk')
        def get_user(self):
            return 'Тони Старк'

    test = Test()
    assert test.get_name() == 'KHalk'
    assert test.get_user() == 'TONI STARK'

# Generated at 2022-06-12 01:28:19.876352
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    func_wrapped = romanize('ru')

    @func_wrapped
    def func(*args, **kwargs):
        return 'Люба, Ах! возбуждай, спокойна не буду'

    assert func(locale=locale) == 'Luba, Ax! vozbuzhaj, spokojna ne budu'


# Generated at 2022-06-12 01:28:27.167968
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_ru(value: str) -> str:
        return value

    r = test_ru('Привет, мир!')
    assert r == 'Privet, mir!'

    @romanize(locale='uk')
    def test_uk(value: str) -> str:
        return value

    r = test_uk('Привіт, світ!')
    assert r == 'Pryvit, svit!'

# Generated at 2022-06-12 01:28:32.355087
# Unit test for function romanize

# Generated at 2022-06-12 01:28:35.477852
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.builtins import Text

    text = Text('ru')
    assert text.romanized(data.ROMANIZATION_DICT[Locale.RU]) == text.romanize()

# Generated at 2022-06-12 01:28:43.143999
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender, Locale
    from mimesis.providers.identifiers import Identifiers
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    def assert_romanize(locale_code, attr, value):
        localizer = lambda x: getattr(x, attr)()
        assert getattr(locale_code, attr.upper()) == value
        assert getattr(Locale(locale_code), attr.upper()) == value
        assert getattr(Address(locale_code), attr)() == value
        assert getattr(Identifiers(locale_code), attr)() == value
        assert getattr(Person(locale_code), attr)(Gender.MALE) == value

# Generated at 2022-06-12 01:28:53.025437
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    from mimesis.builtins import (
        RussianSpecProvider,
        UkrainianSpecProvider,
        KazakhSpecProvider,
    )

    # Test Russian
    rp = RussianSpecProvider('')
    assert rp.romanize('Нормальный') == 'Normal\'nyi'

    # Test Ukrainian
    up = UkrainianSpecProvider('')
    assert up.romanize('Привіт') == 'Pryvit'

    # Test Kazakh
    kp = KazakhSpecProvider('')

# Generated at 2022-06-12 01:29:01.504443
# Unit test for function romanize
def test_romanize():
    def romanize_latin_fun(self):
        return 'english'
    result = romanize_latin_fun('')
    assert result == 'english'

    def romanize_cyrillic_fun(self, locale: str = None):
        return 'кириллический'
    result = romanize_cyrillic_fun('', locale='ru')
    assert result == 'kyrillicheskiy'

    def romanize_cyrillic_fun(self, locale: str = None):
        return 'костя'
    result = romanize_cyrillic_fun('', locale='ru')
    assert result == 'kostya'


# Generated at 2022-06-12 01:29:02.064338
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-12 01:29:08.495392
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator"""
    from mimesis.builtins import RussianSpecProvider

    class TestRu(RussianSpecProvider):

        @romanize()
        def get_pet_name(self) -> str:
            """Get pet name."""
            return ''

    test_ru = TestRu()
    r_name = test_ru.get_pet_name()

    for letter in r_name:
        assert letter in ascii_letters or letter in digits or letter in punctuation

# Generated at 2022-06-12 01:29:26.229283
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    alphabets = 'aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ'
    digits = '0123456789'
    punctuation = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    assert romanize('ru')('Абракадабра') == alphabets
    assert romanize('uk')('Абракадабра') == alphabets
    assert romanize('kk')('Абракадабра') == alphabets


# Generated at 2022-06-12 01:29:28.380903
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Привет") == "Privet"

# Generated at 2022-06-12 01:29:30.540172
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет')() == 'Privet'



# Generated at 2022-06-12 01:29:38.231259
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Журнал «Новый мир»') == 'Zhurnal «Novyi mir»'
    assert romanized(locale='uk')(lambda: 'Журнал «Новий мир»') == 'Zhurnal «Novyi mir»'
    assert romanized(locale='kk')(lambda: 'Журнал «Жаңа дүние»') == 'Zhurnal «Zhana dúnie»'

# Generated at 2022-06-12 01:29:41.396230
# Unit test for function romanize
def test_romanize():
    romanized_text = romanized('ru')(lambda: 'Чебурашка')()
    assert romanized_text == 'Cheburashka'

# Generated at 2022-06-12 01:29:42.684268
# Unit test for function romanize
def test_romanize():
    pass


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:29:51.938761
# Unit test for function romanize
def test_romanize():
    """Unit test for function `romanize`.
    """

    def _test_romanization(func, locale: str = ''):
        """Test for romanization function.
        >>> import mimesis
        >>> t = mimesis.Test()
        >>> test_romanization(t.provider.cryptographic.token, 'ru')
        >>> test_romanization(t.provider.identifier.ssn, 'ru')
        >>> test_romanization(t.provider.user_agent.chrome, 'ru')
        >>> test_romanization(t.provider.user_agent.opera, 'ru')
        """

        @romanize(locale=locale)
        def romanized_func():
            return func()

        result = romanized_func()
        assert isinstance(result, str)

    _test

# Generated at 2022-06-12 01:29:53.584209
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda: 'абвгде')()
    assert result == 'abvgde'

# Generated at 2022-06-12 01:30:01.716064
# Unit test for function romanize
def test_romanize():
    """UnitTests for function romanize."""
    # Unit test for function romanize.
    assert romanize('ru')('Привет мир!') == 'Privet mir!'
    assert romanize('kk')('Алем елесі жойылмайды!') == 'Alem elesi joyılmaıdy!'
    assert romanize('uk')('Як дела?') == 'Yak dela?'

# Generated at 2022-06-12 01:30:04.509186
# Unit test for function romanize
def test_romanize():
    """Test for function romanize"""
    assert romanized(locale="ru")('Привет') == 'Privet'

# Generated at 2022-06-12 01:30:27.800260
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_this():
        return 'привет'

    assert romanize_this == 'privet'

# Generated at 2022-06-12 01:30:30.718165
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_word(pattern='*'):
        return 'Привет, как дела?'

    assert get_word() == 'Privet, kak dela?'

# Generated at 2022-06-12 01:30:33.280145
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Россия')() == 'Rossiya'

# Generated at 2022-06-12 01:30:40.841013
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    p = Person(Locale.ENGLISH)
    assert romanize(Locale.ENGLISH)(p.full_name) == p.full_name

    p = Person(Locale.RUSSIAN)
    assert romanize(Locale.RUSSIAN)(p.full_name) == 'Иванова Елена Викторовна'
    assert romanize(Locale.RUSSIAN)(p.full_name) != 'Ivanova Elena Viktorovna'

    p = Person(Locale.UKRAINIAN)

# Generated at 2022-06-12 01:30:47.626892
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_ru(x):
        return x

    @romanized(locale='ru')
    def romanized_ru(x):
        return x

    assert romanize_ru('Привет') == 'Privet'
    assert romanized_ru('Привет') == 'Privet'



# Generated at 2022-06-12 01:30:49.253839
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize(locale='ru')(lambda: 'ye'), Callable)



# Generated at 2022-06-12 01:30:59.456632
# Unit test for function romanize
def test_romanize():
    """Test romanization."""
    assert romanized()(lambda: 'Господи! Приближается королевский поезд.') == 'Gospodi! Priblizhaetsya korolevskiy poezd.'
    assert romanized(locale='kk')(lambda: 'Достық ағап атаңыз!') == 'Dostyk agap atanyz!'
    assert romanized(locale='uk')(lambda: 'Вітаю вас, як добре вам знайомитись!')

# Generated at 2022-06-12 01:31:03.422793
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    @romanize('ru')
    def test_romanizer(text: str) -> str:
        return text

    result = test_romanizer(text='программирование')
    assert result == 'programmirovanie'

# Generated at 2022-06-12 01:31:09.135422
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text
    text = mimesis.builtins.text.Text(locale='ru')
    rus = u'Привет'
    rom = text.romanize(rus)
    assert rom == 'Privet'

# Generated at 2022-06-12 01:31:13.113667
# Unit test for function romanize
def test_romanize():
    print('Test function romanize.')
    romanized_text = romanize('ru')(lambda: 'Привет мир!')
    assert romanized_text == 'Privet mir!'


try:
    test_romanize()
except AssertionError as e:
    print(str(e))

# Generated at 2022-06-12 01:32:20.555693
# Unit test for function romanize
def test_romanize():
    text = romanize()(lambda x: 'Русский')
    assert text == 'Russkiy'

# Generated at 2022-06-12 01:32:25.282224
# Unit test for function romanize
def test_romanize():
    """Test for romanization."""
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    expected = 'Mikhail Semenovich'
    result = Person(locale=Locale.RU).full_name()
    assert expected == result



# Generated at 2022-06-12 01:32:25.712019
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-12 01:32:28.867134
# Unit test for function romanize
def test_romanize():
    romanize_deco = romanize(locale='ru')
    assert romanize_deco.__name__ == 'wrapper'
    # romanize_deco is a wrapper for romanize function
    assert callable(romanize_deco(lambda: True))
    # so function romanize can be called as well.
    assert callable(romanize_deco(romanize))

# Generated at 2022-06-12 01:32:34.561573
# Unit test for function romanize
def test_romanize():
    assert romanize.__name__ == 'romanize'
    assert romanize.__module__ == 'mimesis.builtins.utils'

    @romanize(locale='ru')
    def test():
        return 'Привет'

    assert test() == 'Privet'

    test_locale = romanize(locale='ru')

    @test_locale
    def test():
        return 'Привет'

    assert test() == 'Privet'



# Generated at 2022-06-12 01:32:40.297458
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    s = RussiaSpecProvider()
    assert s._transliterate('Привет!') == 'Privet!'



# Generated at 2022-06-12 01:32:48.368655
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Бла-бла')() == 'Bla-bla'
    assert romanize('ru')(lambda x: 'бла-бла')() == 'bla-bla'
    assert romanize('ru')(lambda x: 'БЛА-бла')() == 'BLA-bla'
    assert romanize('ru')(lambda x: 'Бла-бла.')() == 'Bla-bla.'
    assert romanize('ru')(lambda x: 'Бла-бла()')() == 'Bla-bla()'

# Generated at 2022-06-12 01:32:51.040231
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo():
        return 'Привет!'

    assert foo() == 'Privet!'



# Generated at 2022-06-12 01:32:58.510578
# Unit test for function romanize
def test_romanize():
    import uuid
    from mimesis.builtins import Address, Person

    address = Address('ru')
    username = Person('ru')

    def get_romanized_text():
        try:
            return romanized('ru')(str)(uuid.uuid4())
        except (KeyError, UnsupportedLocale):
            return romanized('ru')(str)(address.region())

    assert(get_romanized_text())
    assert(romanized('uk')(str)(username.username()) == '__fm__')

# Generated at 2022-06-12 01:33:04.983087
# Unit test for function romanize
def test_romanize():
    @romanize()
    def phony():
        return "Съешь ещё этих мягких французских булок, да выпей чаю."
    assert phony() == "S'esh' eshchyo etikh myagkikh frantsuzskikh bulok, da vypei chayu."