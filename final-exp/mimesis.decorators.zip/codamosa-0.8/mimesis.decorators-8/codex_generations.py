

# Generated at 2022-06-12 01:24:56.328052
# Unit test for function romanize
def test_romanize():
    @romanize('kk')
    def romanize_function():
        return 'Ағылшын, қазақ, орыс тілдері'


    assert romanize_function() == 'Ağılşın, qazaq, orıs tilderı'

# Generated at 2022-06-12 01:25:04.919843
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text

    text = Text(locale='ru')
    text.romanize()
    assert text.romanize("Как дела", locale='ru') == 'Kak dela'
    assert text.romanize("Как дела", locale='uk') == 'Kak dela'
    assert text.romanize("Как дела", locale='kk') == 'Kak dela'


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-12 01:25:07.214220
# Unit test for function romanize
def test_romanize():
    assert romanize

if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-12 01:25:11.672851
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    from mimesis.enums import Provinces
    from mimesis.providers.address import Address
    a = Address('ru')
    assert(a.province(province=Provinces.PRIMORSKIY_KRAY).isalnum())
    assert(a.province(province=Provinces.PRIMORSKIY_KRAY) == 'Приморский край')

# Generated at 2022-06-12 01:25:16.664736
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Снег идет. Плохая погода.') == 'Sneg idet. Plohaya pogoda.'

# Generated at 2022-06-12 01:25:18.277080
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: "Привет")() == 'Privet'

# Generated at 2022-06-12 01:25:18.841286
# Unit test for function romanize
def test_romanize():
    romanize()

# Generated at 2022-06-12 01:25:24.940986
# Unit test for function romanize
def test_romanize():
    assert romanize()('Это кириллица.') == 'Eto kirillitsa.'
    assert romanize()('Это кириллица.') != 'Eto kirillitsa'
    assert romanize()('Это кириллица.') != 'Eto kirillitsa. '

# Generated at 2022-06-12 01:25:31.735430
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from ..random import Random
    rnd = Random(Locale.ENGLISH)
    rus_txt = rnd.text.ascii_string(length=32)
    assert type(rus_txt) == str

    @romanize('ru')
    def rus():
        return rus_txt

    assert rus == 'MfLYzdhYqUqBMILUZKkrgAMcG'



# Generated at 2022-06-12 01:25:35.702251
# Unit test for function romanize
def test_romanize():
    '''
    romanized text should match the expected output

    '''
    r = romanize(locale='ru')
    assert r(lambda: 'Кохання тоже має свої правила') == \
        'Koxannya toje maye svoji pravyla'

# Generated at 2022-06-12 01:25:48.217408
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis import Person
    import re

    @romanize(locale=Language.RUSSIAN)
    def rus_func(p: Person) -> str:
        return p.full_name()

    assert re.match(r'[a-zA-Z.]+ [a-zA-Z]+', rus_func(Person(Language.RUSSIAN)))

    @romanize(locale=Language.UKRAINIAN)
    def ukr_func(p: Person) -> str:
        return p.full_name()

    assert re.match(r'[a-zA-Z.]+ [a-zA-Z]+', ukr_func(Person(Language.UKRAINIAN)))


# Generated at 2022-06-12 01:25:58.750245
# Unit test for function romanize
def test_romanize():
    # Cyrillic
    cyrillic = data.CYRILLIC_ALPHABET
    assert cyrillic == 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'

    # Latin
    latin = data.COMMON_LETTERS
    assert latin == 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz'

    # At this moment it works only for ru, uk, kz
    romanized

# Generated at 2022-06-12 01:26:02.286420
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')
    assert romanized('uk')
    assert romanized('kk')
    try:
        assert romanized('xy')
    except:
        assert True

# Generated at 2022-06-12 01:26:13.453735
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    assert romanize()(lambda: 'Hi, I am Михаил')() == 'Hi, I am Mikhail'
    assert romanize()(lambda: 'Олександр Константинович Стельмах')() == \
        'Oleksandr Konstantinovich Stelmakh'
    assert romanize()(lambda: 'БПЛА МАВР')() == 'BPLAMAVR'
    assert romanize()(lambda: 'ЮЖНЫЙ ФЛОТ')() == 'YUZHNYL FLOT'

# Generated at 2022-06-12 01:26:21.439151
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address

    address = Address(Language.RUSSIAN)
    address.provider.set_locale(Language.RUSSIAN)
    assert 'Pechorskiy pr-t, 5' == address.street_name()

    address.provider.set_locale(Language.UKRAINIAN)
    assert 'Майнова вулиця, 77' == address.street_name()

    address.provider.set_locale(Language.KAZAKH)
    assert 'Д.Канаев даңғысы, 52' == address.street_name()

# Generated at 2022-06-12 01:26:23.201285
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет,')() == 'privet,'

# Generated at 2022-06-12 01:26:26.666228
# Unit test for function romanize
def test_romanize():
    @romanized(locale='ru')
    def test_string() -> str:
        return 'привет'

    assert test_string() == 'privet'

# Generated at 2022-06-12 01:26:29.332862
# Unit test for function romanize
def test_romanize():
    """Romanize the cyrillic text."""
    romanization = romanize('uk')(lambda: 'Привіт!')
    assert romanization == 'Pryvit!'

# Generated at 2022-06-12 01:26:30.769188
# Unit test for function romanize
def test_romanize():
    romanized = romanize('ru')

    @romanized
    def test():
        return 'Привет!'

    assert test() == 'Privet!'

# Generated at 2022-06-12 01:26:42.205818
# Unit test for function romanize
def test_romanize():
    assert ('Парам-пам-пам, Парам-пам-пам, Парам-пам-пам, тут сучка парам-пам, '
            'Парам-пам-пам, Парам-пам-пам, Парам-пам-пам, тут сучка парам-пам.') == romanize('ru')('Парам-пам-пам')

# Generated at 2022-06-12 01:26:54.111982
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('КИРИЛЛИЦА') == 'KIRILLICA'

# Generated at 2022-06-12 01:26:56.448196
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda x: 'Большой Тёмный Лес')() == \
        'Bolshoy Tyomnyy Les'



# Generated at 2022-06-12 01:27:02.717571
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_cyrillic_word():
        """Get cyrillic word."""
        return u'Привет'

    @romanize(locale='uk')
    def get_ukrainian_word():
        """Get ukrainian word."""
        return u'Привіт'

    @romanized(locale='kk')
    def get_kazakh_word():
        """Get kazakh word."""
        return u'Привет'

    russian = get_cyrillic_word()
    assert isinstance(russian, str)
    assert russian == 'Privet'

    ukrainian = get_ukrainian_word()
    assert isinstance(ukrainian, str)

# Generated at 2022-06-12 01:27:08.825998
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import person

    # Check that function romanize can romanize
    # cyrillic text (`ru`, `uk`, `kk`)
    p = person()
    assert all(
        char in ascii_letters + digits + punctuation
        for char in p.full_name()
    )

# Generated at 2022-06-12 01:27:14.904969
# Unit test for function romanize
def test_romanize():
    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({**data.ROMANIZATION_DICT['ru'], **data.COMMON_LETTERS})
    # Cyrillic string can contain ascii
    # symbols, digits and punctuation.
    result = 'Мир.'
    txt = ''.join([alphabet[i] for i in result if i in alphabet])
    assert txt == 'Mir. '

# Generated at 2022-06-12 01:27:26.423433
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Address as Addr
    from mimesis.enums import Gender

    assert Addr('ru').address(gender=Gender.MALE) == \
        'г. Коломна, ул. Ильи Франка, д. 17, кв. 55'
    assert Addr('uk').address(gender=Gender.MALE) == \
        'м. Коломия, вул. Іллі Франка, буд. 17, кв. 55'

# Generated at 2022-06-12 01:27:30.561830
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    text = Text()
    result = text.word(locale=Locale.RUSSIAN)
    assert result != text.romanize(result, locale=Locale.RUSSIAN)



# Generated at 2022-06-12 01:27:38.737457
# Unit test for function romanize
def test_romanize():
    result = romanize()(lambda: 'кот')()
    assert result == 'kot'

    result = romanize(locale='ru')(lambda: 'поезд')()
    assert result == 'pojezd'

    result = romanize(locale='uk')(lambda: 'вікно')()
    assert result == 'vіkno'

    result = romanize(locale='kk')(lambda: 'құпия')()
    assert result == 'qupіya'

    result = romanize(locale='be')(lambda: 'кошка')()
    assert result == 'kashka'

# Generated at 2022-06-12 01:27:49.077462
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis import Personal
    from mimesis import Address

    p = Personal(locale=Locale.ENGLISH)
    a = Address(locale=Locale.ENGLISH)
    p_r = Personal(locale=Locale.RUSSIAN)
    a_r = Address(locale=Locale.RUSSIAN)
    p_u = Personal(locale=Locale.UKRAINIAN)
    a_u = Address(locale=Locale.UKRAINIAN)
    p_k = Personal(locale=Locale.KAZAKH)
    a_k = Address(locale=Locale.KAZAKH)

    assert p.name(gender='male').lower() == p.romanize().name(gender='male').lower

# Generated at 2022-06-12 01:27:56.823047
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Здравствуйте!')() == 'Zdravstvujte!'
    assert romanize('ru')(lambda: 'Вызвать людей, поэт, в жизнь трудную')() == 'Vyzvat ljudej, pojet, v zhizn trudnuju'
    assert romanize('uk')(lambda: 'Літопис Середніх віків')() == 'Litopys Serednikh viki'

# Generated at 2022-06-12 01:28:23.035461
# Unit test for function romanize
def test_romanize():
    """Tests for the function romanize."""
    import mimesis.enums
    assert romanize(locale='en')
    func = romanize(locale='ru')(lambda x: data.ROMANIZATION_DICT['ru'])
    assert func(mimesis.enums.Language) == 'б'



# Generated at 2022-06-12 01:28:26.524442
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Куда делись гамаки?')() == 'Kuda delis' \
                                                                  'ya gamaki?'



# Generated at 2022-06-12 01:28:28.620827
# Unit test for function romanize
def test_romanize():
    """Simple test for romanize."""
    assert romanize('ru')(lambda: 'абвгдеё')() == 'abvgdee'

# Generated at 2022-06-12 01:28:34.665022
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')
    n = p.full_name(gender=Gender.FEMALE)
    assert bool(n.isalpha()), \
        f'{n} is not a string without spaces or numbers'
    assert bool(n.isascii()), f'{n} is not a romanized string'

# Generated at 2022-06-12 01:28:40.978295
# Unit test for function romanize
def test_romanize():

    @romanize(locale='uk')
    def test(a, b):
        return a + b

    a = "Список всіх"
    b = " доживаючих православних"
    result = "Spysok vsikh dozhivaiuchykh pravoslavnykh"
    assert result == test(a, b)



# Generated at 2022-06-12 01:28:46.747406
# Unit test for function romanize
def test_romanize():
    """Test Romanize decorator."""
    from mimesis.builtins.text import Text

    class Foo():

        @romanize(locale='ru')
        def _ru(self):
            """Docstring for romanize()."""
            txt = Text('ru')
            return txt.word(quantity=10)

    assert isinstance(Foo()._ru, str)

# Generated at 2022-06-12 01:28:55.819399
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""

    @romanize(locale='ru')
    def rus(x):
        return ''.join('АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'[:x])

    @romanize(locale='uk')
    def ukr(x):
        return ''.join('АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЮЯ'[:x])


# Generated at 2022-06-12 01:28:57.236602
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет Мир!') == 'Privet Mir!'

# Generated at 2022-06-12 01:29:01.198614
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Слово')() == 'Slovo'
    assert romanized('kk')(lambda: 'Слово')() == 'SLOVO'
    assert romanized('uk')(lambda: 'Слово')() == 'SLOVO'

# Generated at 2022-06-12 01:29:06.407306
# Unit test for function romanize
def test_romanize():
    def func(text: str) -> str:
        return text
    func = romanize(locale='ru')(func)
    assert func('привет, мир!') == 'privet, mir!'
    assert func('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-12 01:29:54.488480
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def generator(*args, **kwargs):
        return args[3]

    assert generator('Иван', 'Иванов', 'Иванович', 'Москва') == 'Moscow'

# Generated at 2022-06-12 01:30:00.490475
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""

    @romanize(locale='ru')
    def test_ru_romanization(*args):
        """Russian romanization in uppercase."""
        return ''.join(args).upper()

    assert test_ru_romanization('Санкт-Петербург') == 'SANKT-PETERBURG'



# Generated at 2022-06-12 01:30:03.936043
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_random_name() -> str:
        return "РУСЛАН"

    assert get_random_name() == 'RUSLAN'



# Generated at 2022-06-12 01:30:07.503956
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def _romanize():
        return 'Привет, друг!'

    assert _romanize() == 'Privet, drug!'



# Generated at 2022-06-12 01:30:18.390309
# Unit test for function romanize
def test_romanize():

    assert romanized(locale='ru')(lambda: 'привет')() == 'privet'
    assert romanized(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanized(locale='uk')(lambda: 'привіт')() == 'privit'
    assert romanized(locale='uk')(lambda: 'Привіт')() == 'Privit'
    assert romanized(locale='kk')(lambda: 'Сәлем')() == 'Sälem'

    assert romanized(locale='ru')(lambda: 'привет!')() == 'privet!'

# Generated at 2022-06-12 01:30:20.994401
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Hello'


# Generated at 2022-06-12 01:30:23.465402
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    pass



# Generated at 2022-06-12 01:30:30.223749
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'В России с 18 июня действуют меры противоэпидемической безопасности')() == 'v rossii s 18 iyunya deystvuyut meri protivoopidemicheskoy bezopasnosti'

# Generated at 2022-06-12 01:30:37.893952
# Unit test for function romanize
def test_romanize():
    assert romanize('abcd')(lambda: 'Привет')() == 'Privet'
    assert romanize('abcd')(lambda: 'Привет')(locale='ru') == 'Privet'
    assert romanized('abcd')(lambda: 'Привет')() == 'Privet'
    assert romanized('abcd')(lambda: 'Привет')(locale='ru') == 'Privet'

# Generated at 2022-06-12 01:30:49.055544
# Unit test for function romanize
def test_romanize():
    # Test on ru locale
    locale = 'ru'

    @romanized(locale)
    def _word():
        return 'Привет Мир, ёю'

    assert _word() == 'Privyet Mir, yo yo'

    # Test on uk locale
    locale = 'uk'

    @romanized(locale)
    def _word():
        return 'Привіт, Світ'

    assert _word() == 'Pryvit, Svit'

    # Test on kz locale
    locale = 'kz'

    @romanized(locale)
    def _word():
        return 'Қазақ тілі'

    assert _word() == 'Qazaq tili'

   

# Generated at 2022-06-12 01:32:46.637028
# Unit test for function romanize
def test_romanize():
    n = 10
    
    from mimesis.providers import Address
    from mimesis.providers.address import Address

    a = Address('kk')
    txt = a.address()
    assert txt != a.romanize(txt)

    if n:
        a = Address('uk')
        txt = a.address()
        assert txt != a.romanize(txt)
    else:
        a = Address('kk')
        txt = a.address()
        assert txt != a.romanize(txt)

# Generated at 2022-06-12 01:32:51.422645
# Unit test for function romanize
def test_romanize():
    romanized_func = romanize('ru')

    @romanized_func
    def ru_test():
        return 'Привет, Кириллица!'

    assert ru_test() == 'Privet, Kirillitsa!'


# Generated at 2022-06-12 01:32:52.534784
# Unit test for function romanize
def test_romanize():
    romanize(locale='ru_RU')

# Generated at 2022-06-12 01:32:58.118394
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_test(txt):
        return txt

    assert callable(romanize_test)
    assert romanize_test('Сингапур') == 'Singapur'
    assert romanize_test('test') == 'test'



# Generated at 2022-06-12 01:33:00.057749
# Unit test for function romanize
def test_romanize():
    @romanize()
    def russian():
        return 'Привет'

    assert russian() == 'Privet'

# Generated at 2022-06-12 01:33:08.926020
# Unit test for function romanize
def test_romanize():
    def _romanize_func(text):
        return text

    assert romanize('ru')(_romanize_func)('Привет') == 'Privet'
    assert romanize('uk')(_romanize_func)('Привіт') == 'Privyt'
    assert romanize('kk')(_romanize_func)('Сәлем') == 'Seliem'
    assert romanize('ru')(_romanize_func)('Привет!') == 'Privet!'

# Generated at 2022-06-12 01:33:11.541874
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize('ru')(lambda: 'Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-12 01:33:14.092302
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def romanized_text() -> str:
        return 'Привет, Мир!'

    assert romanized_text() == 'Privet, Mir!'

# Generated at 2022-06-12 01:33:16.001647
# Unit test for function romanize
def test_romanize():
    @romanize(locale='kk')
    def foo():
        return 'болашақтары'

    assert foo() == 'bolashaktary'

# Generated at 2022-06-12 01:33:17.418795
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(_romanization_test)() == expected

