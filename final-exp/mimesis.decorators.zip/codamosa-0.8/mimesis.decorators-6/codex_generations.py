

# Generated at 2022-06-12 01:24:56.960313
# Unit test for function romanize
def test_romanize():
    # NOTE: We use try/except-blocks because we test
    # functions of different modules with different
    # locales on the same time.
    try:
        from mimesis.builtins import Person

        p = Person('uk')
        assert p.full_name() == 'Вадим Князівський'
        assert p.username() == 'Вадим'

    except (UnsupportedLocale, ImportError):
        pass

# Generated at 2022-06-12 01:25:08.646883
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus_t(str):
        return str

    assert rus_t('Привет, Мир!') == 'Privet, Mir!'

    @romanize('uk')
    def ukr_t(str):
        return str

    assert ukr_t('Привіт, Світ!') == 'Pryvit, Svit!'

    @romanize('kk')
    def kaz_t(str):
        return str

    assert kaz_t('Сәлем, Қазақстан!') == 'Sälem, Qazaqstan!'

    @romanize()
    def no_locale_t(str):
        return str

    assert no_

# Generated at 2022-06-12 01:25:14.406145
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    from .generic import Generic

    # Check romanization
    gen = Generic(Locale.RU)
    assert romanized('ru')(gen.random_element)()

    # Check romanization for unsupported locale
    gen = Generic(Locale('xx'))
    gen.random_element()

# Generated at 2022-06-12 01:25:25.323779
# Unit test for function romanize
def test_romanize(): # pylint: disable=R0914
    @romanized()
    def get_name():
        return 'Александр Михайлович Пушкин'

    assert get_name() == 'Aleksandr Mikhailovich Pushkin'

    @romanized()
    def get_name():
        return 'Alexander von Humboldt'

    assert get_name() == 'Alexander von Humboldt'

    @romanized()
    def get_name():
        return 'Александр фон Гумбольдт'

    assert get_name() == 'Aleksandr fon Gumbolʹdt'


# Generated at 2022-06-12 01:25:32.811530
# Unit test for function romanize
def test_romanize():
    # TODO: Split romanize to two functions:
    # one for romanization, one for auto_locale check.
    def romanize_mock(foo):
        return foo

    mock1 = romanize_mock('foo')
    mock2 = romanize_mock('foo')
    assert mock1 == mock2

    mock3 = romanized('foo')
    assert mock3 == mock2

    mock4 = romanized(auto_locale=True)('foo')
    assert mock4 == mock2

# Generated at 2022-06-12 01:25:34.284870
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-12 01:25:41.968827
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda x: "Привет мир")() == "Privet mir"
    assert romanize(locale='uk')(lambda x: "Привіт світ")() == "Pryvit svit"
    assert romanize(locale='kk')(lambda x: "Hello world")() == "Hello world"
    assert romanize(locale='en')(lambda x: "Hello world")() == "Hello world"

# Generated at 2022-06-12 01:25:44.088256
# Unit test for function romanize
def test_romanize():
    def dummy_func():
        return 'привет'

    x = romanize('ru')(dummy_func)()
    assert x == 'privet'

# Generated at 2022-06-12 01:25:57.000756
# Unit test for function romanize
def test_romanize():
    # locale ru
    @romanize(locale='ru')
    def rus(): return 'строка текста.'
    assert rus() == 'stróka tekstá.'
    
    # locale uk
    @romanize(locale='uk')
    def ukr(): return 'текстове повідомлення.'
    assert ukr() == 'tekstové povídomlénnia.'

    # locale kk
    @romanize(locale='kk')
    def kaz(): return 'бірлік пен текст.'
    assert kaz() == 'birlik pen tekst.'

test_romanize()

# Generated at 2022-06-12 01:26:00.443544
# Unit test for function romanize
def test_romanize():
    roman = romanize(locale='ru')(lambda: 'Привет, Мир!')
    assert roman == 'Privet, Mir!'



# Generated at 2022-06-12 01:26:17.283510
# Unit test for function romanize
def test_romanize():

    import unittest.mock as mock

    @romanize(locale='ru')
    def test_func(word: str) -> str:
        return word

    assert test_func('Здравствуйте') == 'Zdravstvujte'
    assert test_func('Голос') == 'Golos'
    assert test_func('Союз') == 'Soyuz'
    assert test_func('Юлия') == 'Yuliya'
    assert test_func('Юлия Грозная') == 'Yuliya Groznaya'


# Generated at 2022-06-12 01:26:23.155835
# Unit test for function romanize
def test_romanize():
    @romanize(locale='uk')
    def _test_uk():
        return 'а б в ґ г Ґ Д д Е е Є є Ж ж З з И и І і Ї ї Й й К к'

    @romanize(locale='ru')
    def _test_ru():
        return 'а б в г д е ж з и й к л м н о п р с т у ф х ц ч ш щ ъ ы ь э ю я'


# Generated at 2022-06-12 01:26:27.379678
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def cyrillic_text():
        return 'Столетняя война'
    assert cyrillic_text() == 'Stoletnyaya voyna'

# Generated at 2022-06-12 01:26:34.412811
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis import Person

    person = Person(locale=Locale.UKRAINIAN)

    name = person.full_name(gender=None)
    assert isinstance(name, str)

    assert isinstance(person.last_name(gender=None), str)
    assert isinstance(person.first_name(gender=None), str)
    assert isinstance(person.middle_name(gender=None), str)
    assert isinstance(person.name(gender=None), str)
    assert isinstance(person.full_name(gender=None), str)
    assert isinstance(person.father_name(), str)
    assert isinstance(person.students_name(), str)
    assert isinstance(person.employee_name(), str)

# Generated at 2022-06-12 01:26:44.374128
# Unit test for function romanize
def test_romanize():
    """Test romanize()"""
    from mimesis.enums import Language

    @romanize(locale=Language.EN.value)
    def romanize_wrapper(locale: str = '') -> str:
        """Romanize the cyrillic text (English locale)"""
        return 'салом'

    assert romanize_wrapper(locale=Language.RU.value) == 'salom'

    @romanize(locale=Language.UK.value)
    def romanize_wrapper(locale: str = '') -> str:
        """Romanize the cyrillic text (English locale)"""
        return 'салом'

    assert romanize_wrapper(locale=Language.RU.value) == 'salom'


# Generated at 2022-06-12 01:26:53.971801
# Unit test for function romanize
def test_romanize():
    assert romanized()('Мама мыла раму.') == 'Mama myla ramu.'
    assert romanized('ru')('Мама мыла раму.') == 'Mama myla ramu.'
    assert romanized('uk')('Мама мила раму.') == 'Mama mіla ramu.'
    assert romanized('kk')('Мама мыла раму.') == 'Maama myla raamu.'

# Generated at 2022-06-12 01:26:56.571775
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    text = Text()
    text.seed(0)
    # Previously, romanization was applied only to
    # russian, ukrainian and kazakh languages.
    result = text.romanize()
    assert result == 'Zaqwsx'

# Generated at 2022-06-12 01:27:01.718538
# Unit test for function romanize
def test_romanize():
    text = "Почему каждый собьется с нами?"
    assert romanize(locale='kk')(lambda x: text) == 'Pochomu kazhdyi sobeetsya s nami?'
    assert romanize(locale='ru')(lambda x: text) == 'Pochemu kazhdyj sobeetsya s nami?'
    assert romanize(locale='uk')(lambda x: text) == 'Pochemu kazhdyj sobeetsja s nami?'

# Generated at 2022-06-12 01:27:08.975305
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda *e, **f: 'абвгдеёжзийклмнопрстуфхцчшщьыъэюя')(locale='ru') == 'abvgdeezhzijklmnoprstufhzcshschyieyua'

# Generated at 2022-06-12 01:27:11.814718
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    text = Text(Language.EN)
    txt = text.sentence(quantity=10)
    print(txt)

# Generated at 2022-06-12 01:27:19.184456
# Unit test for function romanize
def test_romanize():
    # From romanization_dict.py
    assert 'F', 'f' == romanized('uk')(lambda: 'Ф', 'ф')

# Generated at 2022-06-12 01:27:24.189024
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    p = Person().romanize()
    assert isinstance(p, str)
    assert p == Person().romanized()

    r = Person(locale='ru').romanize()
    assert isinstance(r, str)
    assert r == Person(locale='ru').romanized()

# Generated at 2022-06-12 01:27:25.992120
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    p = Person('ru')
    assert p.name() == p.romanized().name()

# Generated at 2022-06-12 01:27:27.966844
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 123)() == '123'



# Generated at 2022-06-12 01:27:28.459428
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-12 01:27:32.980856
# Unit test for function romanize
def test_romanize():
    @romanized()
    def _():
        return "Привет Мир! как дела? это фейл."
    assert _() == "Privet Mir! kak dela? eto feil."

# Generated at 2022-06-12 01:27:35.553262
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT

    for key, value in ROMANIZATION_DICT['ru'].items():
        assert romanize('ru')(lambda: key)() == value

# Generated at 2022-06-12 01:27:41.237176
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def generate_some_text():
        return 'Привет!'

    assert generate_some_text() == 'Privet!'

    @romanize('uk')
    def generate_some_text():
        return 'Привіт!'

    assert generate_some_text() == 'Pryvit!'

    @romanize('kk')
    def generate_some_text():
        return 'Құрылқыбастармен!'

    assert generate_some_text() == 'Qurylqybas­tar­men!'


test_romanize()

# Generated at 2022-06-12 01:27:47.250705
# Unit test for function romanize
def test_romanize():
    # Arrange
    def test_func(locale: str = 'ru', target: str = 'Привет Свет') -> str:
        return target

    # Act
    result = romanize(locale='ru')(test_func)(target='Привет Мир')
    # Assert
    assert result == 'Privet Mir'

# Generated at 2022-06-12 01:27:52.723233
# Unit test for function romanize
def test_romanize():
    # This test only verifies that the decorator is applied
    # to a method, and not to the entire class.
    from mimesis.builtins.numbers import Numbers
    from mimesis.enums import Localization
    numbers = Numbers(localization=Localization.UKRAINE)

    assert numbers.romanize_number(1234567) == "СіЧМільМільОдНаДовДва"

# Generated at 2022-06-12 01:28:13.744774
# Unit test for function romanize
def test_romanize():
    """Test romanize using romanized decorator.

    :return: None
    """

    @romanize('ru')
    def russian_text() -> str:
        """Generate russian text."""
        return 'Я не человек, я — механизм.'

    assert russian_text() == 'Ya ne chelovek, ya — mehanizm.'

    @romanize('uk')
    def ukrainian_text() -> str:
        """Generate ukrainian text."""
        return 'Я і не людина, я — тварина.'


# Generated at 2022-06-12 01:28:23.610730
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_text() -> str:
        return 'В чащах юга жил бы цитрус? Да, но фальшивый экземпляр!'

    assert rus_text() == \
        'V chashchakh yuga zhil by tsitrus? Da, no falshivyy ' \
        'ekzemplyar!'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:28:33.772519
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')
    assert p.full_name(gender=Gender.FEMALE) == 'Ирина Александровна Фомина'
    assert p._full_name(gender=Gender.FEMALE) == 'Irina Aleksandrovna Fomina'
    assert p.full_name_male() == 'Леонид Александрович Ермаков'
    assert p._full_name_male() == 'Leonid Aleksandrovich Ermakov'

# Generated at 2022-06-12 01:28:39.783693
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_name(locale):
        return 'Иван Ползун'

    expected = 'Ivan Polzun'
    assert get_name('ru') == expected

    # Due to the usage of @functools.wraps,
    # the name of the function should not change.
    assert get_name.__name__ == 'get_name'

# Generated at 2022-06-12 01:28:47.482350
# Unit test for function romanize
def test_romanize():
    """Tests for romanization."""
    romanized_string = 'Модуль романизации текста кириллицы.'
    transliterated_string = 'Modul romanizacii teksta kirillicy.'

    @romanize('ru')
    def romanize_text(text):
        return text

    assert romanize_text(romanized_string) == transliterated_string

# Generated at 2022-06-12 01:28:56.103332
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Русский')() == 'Russkiy'
    assert romanize('uk')(lambda: 'Українська мова')() == 'Ukrainska mova'
    assert romanize('kk')(lambda: 'Қазақша')() == 'Kazaksha'
    assert romanize('ru')(lambda: 'english')()  == 'english'
    assert romanize('ru')(lambda: '123')() == '123'
    assert romanize('ru')(lambda: '123.')() == '123.'
    assert romanize('ru')(lambda: '123...')() == '123...'

# Generated at 2022-06-12 01:29:05.691145
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo(string: str) -> str:
        return string

    assert foo('Александр') == 'Aleksandr'
    assert foo('Відділ маркетингу') == 'Viddіl marketingu'
    assert foo('Реклама') == 'Reklama'
    assert foo('Створення сайтів') == 'Stvorennya sаіtіv'
    assert foo('Обслуговування') == 'Obsluhovuvannya'
    assert foo('Розробка') == 'Rozrobka'

# Generated at 2022-06-12 01:29:09.959574
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    target = 'Всем хай, общество!'
    result = 'Vsem khay, obschestvo!'
    assert(RussianSpecProvider.romanize(target) == result)

# Generated at 2022-06-12 01:29:15.453951
# Unit test for function romanize
def test_romanize():
    backup_locale = data.LOCALE
    data.LOCALE = 'ru_RU'

    @romanize(locale='ru')
    def rus(text):
        return text

    sample = rus('Привет, Мимису!')
    expected_value = 'Privet, Mimusu!'

    assert sample == expected_value

    data.LOCALE = backup_locale

# Generated at 2022-06-12 01:29:19.219438
# Unit test for function romanize
def test_romanize():
    romanized_string = romanized(locale='ru')

    @romanized_string
    def lorem():
        return "Привет! Как дела?"

    assert lorem() == "Privet! Kak dela?"

# Generated at 2022-06-12 01:29:51.728232
# Unit test for function romanize
def test_romanize():
    assert romanize() == romanized


try:
    import numpy as np

    @functools.wraps(np.random.seed)
    def seed(seed=None):
        """Seed the random number generator.

        Seed for RandomState instance used by :mod:`~mimesis`.

        :param seed: Seed for the random number generator.
        :return: None
        """
        np.random.seed(seed)


except ImportError:  # pragma: no cover
    import random

    @functools.wraps(random.seed)
    def seed(seed=None):
        """Seed the random number generator.

        Seed for Random instance used by :mod:`~mimesis`.

        :param seed: Seed for the random number generator.
        :return: None
        """

# Generated at 2022-06-12 01:29:58.976754
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""

    @romanize()
    def foo():
        return "Я люблю тебя, Mimesis!"

    assert foo() == "Ya lyublyu tebya, Mimesis!"



# Generated at 2022-06-12 01:30:06.088862
# Unit test for function romanize
def test_romanize():
    LOCALE = 'ru'
    @romanize(locale=LOCALE)
    def test():
        return ('Привет, страна! Меня зовут Серге́й.')

    r = test()
    assert r == 'Privet, strana! Menya zovut Sergej.'

# Generated at 2022-06-12 01:30:13.238413
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    text = 'Не подлежащее разглашению открытое сведение'
    romanized_text = 'ne podlezhashhee razglashhenie otkrytoe svedenie'
    romanize_text = romanize(locale)(lambda: text)
    assert romanize_text == romanized_text

# Generated at 2022-06-12 01:30:20.951954
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Робот')() == 'Robot'
    assert romanized('ua')(lambda: 'Іще')() == 'Ische'
    assert romanized('kk')(lambda: 'Жасау')() == 'Zhasau'
    assert romanized('kk')(lambda: 'Тест 123')() == 'Test 123'
    assert romanized('kk')(lambda: 'Тест, 123')() == 'Test, 123'

# Generated at 2022-06-12 01:30:26.785663
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привіт')() == 'Pryvit'

    double_romanize = romanize()(romanize())
    assert double_romanize(lambda: 'Привіт') == 'Pryvit'

# Generated at 2022-06-12 01:30:38.207149
# Unit test for function romanize
def test_romanize():
    """Test for decorator romanize."""

    @romanize(locale='ru')
    def rus(seed: int = None) -> str:
        return 'Привет Мир!'

    assert rus(seed=123) == 'Privet Mir!'

    @romanize(locale='uk')
    def ukr(seed: int = None) -> str:
        return 'Добрий день!'

    assert ukr(seed=123) == 'Dobriy den\'!'

    @romanize(locale='kk')
    def kaz(seed: int = None) -> str:
        return 'Сәлем әлем!'

    assert kaz(seed=123) == 'Sälem äleм!'

# Generated at 2022-06-12 01:30:49.134730
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    p = Person('ru')

    ru_name = p.full_name()
    ru_romanized_name = romanize('ru')(p.full_name)()

    assert ru_name != ru_romanized_name

    ru_surname = p.surname()
    ru_romanized_surname = romanize('ru')(p.surname)()

    assert ru_surname != ru_romanized_surname

    ru_patronymic = p.patronymic()
    ru_romanized_patronymic = romanize('ru')(p.patronymic)()

    assert ru_patronymic != ru_romanized_patronymic

# Generated at 2022-06-12 01:30:50.573987
# Unit test for function romanize
def test_romanize():
    assert 'Тест' == romanize(locale='ru')(lambda: 'Test')()

# Generated at 2022-06-12 01:30:52.857896
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(romanize_ru)('Привет') == 'Privet'



# Generated at 2022-06-12 01:31:59.990036
# Unit test for function romanize
def test_romanize():
    """Test if romanize works."""
    assert romanize('uk')(lambda: 'Слово')() == 'Slovo'
    assert romanize('uk')(lambda: 'Слово')() == 'Slovo'
    assert romanize('ru')(lambda: 'Слово')() == 'Slovo'
    assert romanize('ru')(lambda: 'Слово')() == 'Slovo'
    assert romanize('kk')(lambda: 'Слово')() == 'Slovo'
    assert romanize('kk')(lambda: 'Слово')() == 'Slovo'

# Generated at 2022-06-12 01:32:06.471545
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    def x(a: str, b: str) -> None:
        assert a == b

    x('tuesday', romanize()(lambda: 'вторник')(locale='ru'))
    x('a', romanize()(lambda: 'а')(locale='ru'))
    x('elxan', romanize()(lambda: 'әлхан')(locale='kk'))



# Generated at 2022-06-12 01:32:15.198921
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import _data
    from mimesis.providers.text import _data as txt_data
    from mimesis.typing import Seed

    person = Person(locale='ru')
    seed = Seed(42)

    name = person.full_name(gender=Gender.MALE, seed=seed)
    assert name == 'Александр Петрович Трофимов'

    male = person._get_formatted_data('full_name', gender=Gender.MALE, seed=seed)
    female = person._get_formatted_data('full_name', gender=Gender.FEMALE, seed=seed)

# Generated at 2022-06-12 01:32:21.018927
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.random import Random
    from mimesis.providers.text import Text

    txt = Text(Locale.ENGLISH)
    rnd = Random()

    assert rnd.romanize(txt.text()) == txt.text()

# Generated at 2022-06-12 01:32:30.570079
# Unit test for function romanize
def test_romanize():

    # Test using no arguments
    @romanize()
    def foo():
        return 'Привет, Мир!'

    assert isinstance(foo(), str)
    assert foo() == 'Privet, Mir!'

    # Test using locale argument
    @romanize('ru')
    def bar():
        return 'Привет, Мир!'

    assert isinstance(bar(), str)
    assert bar() == 'Privet, Mir!'

    # Test if it works with list
    @romanize()
    def baz():
        return ['Привет, Мир!', 'Мир']

    assert isinstance(baz(), list)
    assert baz() == ['Privet, Mir!', 'Mir']

    # Test with other locale


# Generated at 2022-06-12 01:32:32.665903
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Привет!')() == 'Privet!'

# Generated at 2022-06-12 01:32:40.489150
# Unit test for function romanize
def test_romanize():
    def wrapper(locale: str) -> str:
        @romanize(locale)
        def func() -> str:
            return 'Мама мыла раму!'

        return func()

    assert wrapper('ru') == 'Mama myla ramu!'
    assert wrapper('uk') == 'Mama myla ramu!'
    assert wrapper('kk') == 'Mama myla ramu!'



# Generated at 2022-06-12 01:32:44.405469
# Unit test for function romanize
def test_romanize():
    class TestClass:
        def __init__(self):
            pass

        @romanize(locale='ru')
        def my_func(self):
            return 'привет'

    test = TestClass()
    result = test.my_func()
    assert result == 'privet'

# Generated at 2022-06-12 01:32:46.316284
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-12 01:32:50.507472
# Unit test for function romanize
def test_romanize():
    assert data.LANGUAGES.get('ru') is not None
    assert data.LANGUAGES.get('ua') is not None
    assert data.LANGUAGES.get('uk') is not None



# Generated at 2022-06-12 01:34:40.006515
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет мир!') == 'Privet mir!'