

# Generated at 2022-06-12 01:24:55.792919
# Unit test for function romanize
def test_romanize():
    """Test for the romanize."""
    result = romanize()(lambda: "Привет, мир!")
    assert result == "Privet, mir!"

# Generated at 2022-06-12 01:24:59.072266
# Unit test for function romanize
def test_romanize():
    """Check that romanize decorator works correctly."""
    @romanize('uk')
    def test_fn(param):
        return param

    assert test_fn('Вася') == 'Vasya'



# Generated at 2022-06-12 01:25:06.314391
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Вітаю')() == 'Vitayu'
    assert romanize()(lambda: 'Қалайсың? Как сам?')() == 'Qalaysyn? Kak sam?'

# Generated at 2022-06-12 01:25:07.981683
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-12 01:25:13.390341
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo(bar: str) -> str:
        return bar

    assert foo('Foo Bar Baz') == 'Фоо Бар Баз'
    assert foo('Foo Bar Baz', 'Hello World!') == 'Фоо Бар Баз'

# Generated at 2022-06-12 01:25:16.505621
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func(text):
        return text

    assert func('Привет') == 'Privet'

# Generated at 2022-06-12 01:25:26.814248
# Unit test for function romanize
def test_romanize():
    """Tests for the romanize decorator."""
    from mimesis.builtins import RussianSpecProvider

    @romanize('ru')
    def russian(spec):
        """Test romanization."""
        return RussianSpecProvider(spec).text()

    assert russian('cyrillic') == 'kirillitsa'
    assert russian('человек') == 'chelovek'

    assert russian('Через дорогу бегала кошка.') == \
        'cherez dorogu begala koshka.'

    # test wrong locale exception

# Generated at 2022-06-12 01:25:30.681423
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Привет')() != 'privet'

# Generated at 2022-06-12 01:25:32.438114
# Unit test for function romanize
def test_romanize():
    # test_True
    assert True == True


if __name__ == 'main':
    test_romanize()

# Generated at 2022-06-12 01:25:39.093225
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize()('СЛОВОСОЧЕТАНИЕ') == 'SLOVOSOCHETANIE'
    assert romanize()('словосочетание') == 'slovosochetanie'
    assert romanize()('словосочетание.') == 'slovosochetanie.'
    assert romanize()('словосочетание?') == 'slovosochetanie?'
    assert romanize()('словосочетание!') == 'slovosochetanie!'

# Generated at 2022-06-12 01:25:47.654022
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'Привет', 'ru') != None


# Generated at 2022-06-12 01:25:58.442565
# Unit test for function romanize

# Generated at 2022-06-12 01:26:02.688857
# Unit test for function romanize
def test_romanize():
    romanized = romanize('ru')
    romanized.__class__ = ''.__class__

    assert romanized('яблоко') == 'yabloko'
    assert romanized('апельсин') == 'apelsin'

# Generated at 2022-06-12 01:26:05.890318
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda: 'Привет, мир!')().split(', ')
    assert result == ['privet', 'mir!']



# Generated at 2022-06-12 01:26:08.569537
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_test(text):
        return text

    assert romanize_test('Привет') == 'priviet'

# Generated at 2022-06-12 01:26:19.526393
# Unit test for function romanize

# Generated at 2022-06-12 01:26:22.285052
# Unit test for function romanize
def test_romanize():
    # Expected result
    expected = 'test'
    # Actual result
    actual = ('тест')
    assert romanize('ru')(actual) == expected



# Generated at 2022-06-12 01:26:31.925827
# Unit test for function romanize
def test_romanize():
    my_str = "Dobrý den, jméno je Дмитро Степанович Szőke Ferenc"
    result = romanize('cs')(lambda: my_str)()
    assert result == "Dobry den, jmeno je Dmitro Stepanovich Szoke Ferenc"

    result = romanize('de')(lambda: my_str)()
    assert result == "Dobry den, jmeno je Dmitro Stepanovich Szoke Ferenc"

    result = romanize('ru')(lambda: my_str)()
    assert result == "Dobry den, jmeno je Dmitro Stepanovich Szoke Ferenc"

    result = romanize('uk')(lambda: my_str)()

# Generated at 2022-06-12 01:26:43.337530
# Unit test for function romanize
def test_romanize():
    txt = 'Мова народна, як і наро́д.'
    txt_ru = 'Mova narodna, yak i naród.'
    txt_uk = 'Мова народна, як і нарóд.'
    txt_kk = 'Мәңгілік тіл, қазақ элі.'

    @romanized('ru')
    def text_ru() -> str:
        return txt

    @romanized('uk')
    def text_uk() -> str:
        return txt


# Generated at 2022-06-12 01:26:47.360451
# Unit test for function romanize
def test_romanize():
    import random
    import string
    import pytest

    @romanize(locale='ru')
    def test_func(alphabet: str = string.ascii_letters) -> str:
        return random.choice(alphabet)

    assert callable(test_func)

    # Cyrillic string can contain ascii
    # symbols, digits and punctuation.
    alphabet = string.ascii_letters + string.digits + string.punctuation
    for c in alphabet:
        assert isinstance(test_func(alphabet=c), str)

    # Unsupported locale
    with pytest.raises(UnsupportedLocale):
        @romanize(locale='uk')
        def test_func(alphabet: str = string.ascii_letters) -> str:
            return random.choice(alphabet)

# Generated at 2022-06-12 01:27:02.610017
# Unit test for function romanize
def test_romanize():
    import pytest
    from hypothesis import given, settings
    from hypothesis.strategies import text

    from mimesis.builtins import Person
    from mimesis.enums import Gender

    settings.register_profile('ci', max_examples=50)
    settings.load_profile('ci')

    p = Person()

    # test romanization profile of russia locale
    p.set_locale("ru")

    @given(text(min_size=1, max_size=20, alphabet=p.CYRILLIC_CHARACTERS))
    def test_all_cyrillic_characters(s):
        txt_ru = p._romanize(s)
        for l in txt_ru:
            assert l in p.ALPHABET
        assert len(txt_ru) == len(s)



# Generated at 2022-06-12 01:27:05.815326
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_cyrillic():
        return 'фыва'

    assert get_cyrillic() == 'fyva'



# Generated at 2022-06-12 01:27:17.563413
# Unit test for function romanize
def test_romanize():
    # We assume that we test romanize() with a function curried with
    # type: method, where the function is taken from class AbstractBaseProvider.
    def is_valid_result(result):
        return True if result else False

    # Default locale - ru.
    assert is_valid_result(romanize()(lambda: 'на'))

    # Russian locale.
    assert is_valid_result(romanize('ru')(lambda: 'на'))

    # Ukrainian locale.
    assert is_valid_result(romanize('uk')(lambda: 'і'))

    # Kazakh locale.
    assert is_valid_result(romanize('kk')(lambda: 'а'))

    # Belarusian locale. (Not supported)
    assert not is_valid_result(romanize('be')(lambda: 'а'))

# Generated at 2022-06-12 01:27:21.689727
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russia():
        return "Привет, как дела?"
    assert russia() == 'Privet, kak dela?'

    @romanize(locale='kk')
    def kazakh():
        return 'Сәлем, бірақ ақын ма?'
    assert kazakh() == 'Sälem, biraq aqın ma?'

    @romanized(locale='uk')
    def ukrainian():
        return "Привіт, як справи?"
    assert ukrainian() == 'Pryvit, yak spravy?'

# Generated at 2022-06-12 01:27:25.544203
# Unit test for function romanize
def test_romanize():
    @romanize()
    def cyrylio():
        return 'Строка на кириллице'

    assert cyrylio() == 'Stranka na kirillitse'

# Generated at 2022-06-12 01:27:30.517348
# Unit test for function romanize
def test_romanize():
    func = lambda x : x
    func = romanize()(func)
    assert func('Мама мыла раму') == 'Mama myla ramu'
    func = romanize('ua')(func)
    assert func('Мама мыла раму') == 'Mama myla ramu'


# Generated at 2022-06-12 01:27:33.045613
# Unit test for function romanize
def test_romanize():
    _test_romanize = romanize()(lambda: '')

    assert _test_romanize() == ''

# Generated at 2022-06-12 01:27:40.501917
# Unit test for function romanize
def test_romanize():
    sample_data = {}
    sample_data['ru'] ={
        'Кот в сапогах': 'Kot v sapogakh',
        'Как же это чудо?': 'Kak zhe eto chudo?',
        'Привет! Как дела?': 'Privet! Kak dela?',
        'Благодарю за доброе слово.':
            'Blagodaryu za dobroe slovo.'
    }


# Generated at 2022-06-12 01:27:44.115485
# Unit test for function romanize
def test_romanize():
    romanized_func = romanize('ru')(romanized_func)
    assert romanized_func('кириллица') == 'kirillica'

# Generated at 2022-06-12 01:27:50.893045
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'hello abk')() == 'hello abk'
    assert romanize('ru')(lambda: 'abc')() == 'abc'
    assert romanize('')(lambda: 'abc')() == 'abc'
    assert romanize('ru')(lambda: 'привет abc')() == 'privet abc'
    assert romanize('ru')(lambda: 'привет abc')() == 'privet abc'



# Generated at 2022-06-12 01:28:17.340925
# Unit test for function romanize
def test_romanize():
    r = romanize('en')
    @r
    def func():
        return 'Привет, Mimesis!'
    assert func() == 'Privet, Mimesis!'

# Generated at 2022-06-12 01:28:26.534935
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_text():
        return 'Привет, Манекен!'

    assert get_text() == 'Privet, Maneken!'

    @romanize('uk')
    def get_text():
        return 'Привіт, Манекен!'

    assert get_text() == 'Pryvit, Maneken!'

    @romanize('kk')
    def get_text():
        return 'Сәлем, Манекен!'

    assert get_text() == 'Salem, Maneken!'

# Generated at 2022-06-12 01:28:29.364230
# Unit test for function romanize
def test_romanize():
    romanize_test = romanize('ru')(lambda: 'я романизирую')
    assert romanize_test() == 'ya romaniyuyu'



# Generated at 2022-06-12 01:28:33.772480
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import DateTime

    dt = DateTime()
    a = dt.date(romanize=True)
    assert "." in a

    b = dt.date(romanize=True, locale='uk')
    assert "." in b



# Generated at 2022-06-12 01:28:42.198159
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT
    from mimesis.data import COMMON_LETTERS
    from string import ascii_letters, digits, punctuation
    import mimesis

    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({
        **ROMANIZATION_DICT['ru'],
        **COMMON_LETTERS,
    })

    r = mimesis.Person('ru')
    name = r.full_name()
    result = ''.join([alphabet[i] for i in name if i in alphabet])

    assert name == 'Всеволод Корнеев'
    assert result == 'Vsevolod Korneev'

# Generated at 2022-06-12 01:28:52.525687
# Unit test for function romanize
def test_romanize():
    def romanizer(locale: str = '') -> str:
        """Romanize the cyrillic text.

        Transliterate the cyrillic script into the latin alphabet.

        :param locale: Locale code.
        :return: Romanized text.
        """

        try:
            # Cyrillic string can contain ascii
            # symbols, digits and punctuation.
            alphabet = {s: s for s in
                        ascii_letters + digits + punctuation}
            alphabet.update({
                **data.ROMANIZATION_DICT[locale],
                **data.COMMON_LETTERS,
            })
        except KeyError:
            raise UnsupportedLocale(locale)

        txt = 'Тест привет'

# Generated at 2022-06-12 01:28:55.081573
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    txt = Text(locale='ru')
    assert txt.romanize('Москва') == 'Moskva'


# Generated at 2022-06-12 01:28:57.089319
# Unit test for function romanize
def test_romanize():
    '''Testing romanize function'''
    assert romanize('ru')('привет мир') == 'privet mir'

# Generated at 2022-06-12 01:29:00.941602
# Unit test for function romanize
def test_romanize():
    # Here must raise the UnsupportedLocale
    assert romanize('xx')(lambda: 'mimesis')() == ''
    assert romanize('ru')(lambda: 'mimèsis')() == 'mimèsis'
    assert romanized('ru')(lambda: 'mimèsis')() == 'mimèsis'



# Generated at 2022-06-12 01:29:11.439279
# Unit test for function romanize
def test_romanize():
    """Test romanization."""

    @romanize()
    def romanized_text() -> str:
        return 'Привет'

    assert romanized_text() == 'Privet'

    @romanized
    def another_test() -> str:
        return 'Привет, как дела?'

    assert another_test() == 'Privet, kak dela?'

    @romanize('ru')
    def russian_language() -> str:
        return 'Интернет'

    assert russian_language() == 'Internet'

    @romanize('uk')
    def ukrainian_language() -> str:
        return 'Спасибі'

    assert ukrainian_language

# Generated at 2022-06-12 01:30:09.536068
# Unit test for function romanize
def test_romanize():
    from ..text import Text
    from ..random import Random
    from ..utils import get_locale_from_key

    @romanize('uk')
    def test(number=False):
        return Random().create_string(extended=number)

    assert test()
    assert test(number=True)

    t = Text(get_locale_from_key('uk'))
    assert all(map(lambda x: x.isalpha(), t.romanize(t.word())))
    assert all(map(lambda x: x.isalpha(), t.romanize(t.sentence())))

# Generated at 2022-06-12 01:30:20.783873
# Unit test for function romanize
def test_romanize():
    def test_ru():
        from mimesis.providers.internet import Internet
        assert Internet('ru').hyphenated_ip_address() == 'x.x.x.x'

    def test_uk():
        from mimesis.providers.internet import Internet
        assert Internet('uk').hyphenated_ip_address() == 'x.x.x.x'

    def test_kk():
        from mimesis.providers.internet import Internet
        assert Internet('kk').hyphenated_ip_address() == 'x.x.x.x'

    def test_unsupported():
        from mimesis.providers.internet import Internet
        try:
            Internet('test').hyphenated_ip_address()
        except UnsupportedLocale:
            assert True

    test_ru()
    test_uk()
   

# Generated at 2022-06-12 01:30:29.500149
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'asd')() == 'asd'
    assert romanize('ru')(lambda: 'мама мыла раму')() == 'mama myla ramu'
    assert romanize('uk')(lambda: 'asd')() == 'asd'
    assert romanize('uk')(lambda: 'мама мила раму')() == 'mama myla ramu'
    assert romanize('kk')(lambda: 'asd')() == 'asd'
    assert romanize('kk')(lambda: 'мама мыла раму')() == 'mama myla ramu'

# Generated at 2022-06-12 01:30:37.269793
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    @romanize(locale='ru')
    def roman_func(text):
        """Romanized text."""
        return text

    assert roman_func('Каждый охотник желает знать, где сидит фазан') == 'Kazhdyy ohotnik zhelayet znat, gde sidit fazan'

# Generated at 2022-06-12 01:30:39.921878
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanized(text: str = '') -> str:
        return text
    # romanized()
    assert romanized('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-12 01:30:49.016562
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis import Person

    def test_romanize(fixture):
        @romanize('uk')
        def full_name():
            return fixture.simple.full_name()

        return full_name()

    with pytest.raises(UnsupportedLocale):
        @romanize('no_such_locale')
        def _():
            pass

    assert test_romanize(Person()) == 'Білий Володимир Іванович'

# Generated at 2022-06-12 01:30:55.730821
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    from mimesis.enums import Language
    from mimesis.exceptions import UnsupportedLanguage

    try:
        t = Text(Language.RUSSIAN)
    except UnsupportedLanguage:
        t = Text('ru')

    text = t.word(quantity=5)
    result = romanize('ru')(lambda: text)()

    assert text != result
    assert isinstance(result, str)

# Generated at 2022-06-12 01:30:58.681689
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""

    @romanize()
    def test_func():
        return "привет, как дела?"

    assert test_func() == "privet, kak dela?"

# Generated at 2022-06-12 01:31:09.901713
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins
    bd = mimesis.builtins
    assert bd.Person(locale='kk').full_name()[0] == 'Байтерек'
    assert bd.Person(locale='kk').full_name(romanize=True)[0] == 'Bayterek'
    assert bd.Person(locale='ru').full_name()[0] == 'Алексей'
    assert bd.Person(locale='ru').full_name(romanize=True)[0] == 'Aleksey'
    assert bd.Person(locale='uk').full_name()[0] == 'Василь'

# Generated at 2022-06-12 01:31:10.989929
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert callable(romanize)



# Generated at 2022-06-12 01:33:09.258968
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    en = Locale.EN
    russian = Locale.RU

    from mimesis.providers.datetime import Datetime
    dt = Datetime(en)

    @romanize(en)
    @romanize(russian)
    def foo():
        return dt.timestamp(True)

    assert foo() == dt.timestamp(True)

# Generated at 2022-06-12 01:33:16.283044
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Сложности на этом не заканчиваются.')() == \
        'Slozhnosti na jetom ne zakanchivajutsja.'

    assert romanize(locale='en')(lambda: 'Сложности на этом не заканчиваются.')() == \
        'Сложности на этом не заканчиваются.'

# Generated at 2022-06-12 01:33:21.597354
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Привет')() == 'Privet'
    assert romanize('uk')(lambda : 'Привіт')() == 'Privit'
    assert romanize('kk')(lambda : 'Сәлем')() == 'Salem'
    assert romanize('zh')(lambda : '你好')() == '你好'

# Generated at 2022-06-12 01:33:24.855067
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_random_string():
        return 'Далеко-далеко'
    assert get_random_string() == 'Daleko-daleko'

# Generated at 2022-06-12 01:33:27.132434
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_name(): return 'Иван Иванов'
    assert rus_name() == 'Ivan Ivanov'



# Generated at 2022-06-12 01:33:31.534783
# Unit test for function romanize
def test_romanize():
    from unittest import TestCase
    from mimesis.builtins import Person

    class PersonTestCase(TestCase):

        def setUp(self):
            self.person = Person('ru')

        def test_first_name(self):
            first_name = self.person.romanized.first_name()
            self.assertTrue(first_name)

    PersonTestCase().run()

# Generated at 2022-06-12 01:33:32.923816
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda x: 'тест')() == 'test'



# Generated at 2022-06-12 01:33:38.529225
# Unit test for function romanize
def test_romanize():
    import pytest

    from mimesis.builtins import Text

    t = Text('ru')

    # Simple test
    assert t.romanize(t.word(quantity=3)) == t.romanize(t.word(quantity=3))

    # Wrong locale
    with pytest.raises(UnsupportedLocale):
        t.romanize(t.word(quantity=3), locale='de')

    # Wrong locale
    with pytest.raises(UnsupportedLocale):
        t.romanize(t.word(quantity=3), locale='uk')

# Generated at 2022-06-12 01:33:41.552749
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_func():
        return 'Строка'
    assert 'Stroka' == romanize_func()

# Generated at 2022-06-12 01:33:42.036695
# Unit test for function romanize
def test_romanize():
    pass