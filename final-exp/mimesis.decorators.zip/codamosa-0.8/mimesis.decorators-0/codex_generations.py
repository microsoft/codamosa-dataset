

# Generated at 2022-06-12 01:24:54.475023
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_ru_text():
        return 'привет'

    assert get_ru_text() == 'privet'



# Generated at 2022-06-12 01:25:06.267945
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, Мир!') == 'Privet, Mir!'
    assert romanize('ru')('Привет, Мир!') == 'Privet, Mir!'
    assert romanize('uk')('Привіт, Світ!') == 'Pryvit, Svit!'
    assert romanize('kk')('Сәлем Әлем!') == 'Salem Alem!'

    assert romanized()('Привет, Мир!') == 'Privet, Mir!'
    assert romanized('ru')('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-12 01:25:08.605933
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""
    from mimesis.builtins import RussianSpecProvider

    assert romanized('ru')(RussianSpecProvider.first_name)()



# Generated at 2022-06-12 01:25:20.275571
# Unit test for function romanize
def test_romanize():
    import sys
    if sys.version_info.minor < 8:
        # In Python 3.7 and older, decorators are not compatible with @property
        # decorator. So, use the following trick:
        # https://stackoverflow.com/a/54428750/11346794
        from pytest import skip
        skip('Romanisation does not work in Python 3.7 and older')
    from mimesis.builtins import Person as P
    from mimesis.builtins import Address as A
    from mimesis.builtins import Datetime as D
    from mimesis.builtins import Code as C
    from mimesis.builtins import Text as T
    import warnings

    with warnings.catch_warnings():
        # https://stackoverflow.com/a/40653879/11346794
        warnings

# Generated at 2022-06-12 01:25:23.245840
# Unit test for function romanize
def test_romanize():
    """Unit test for function ``romanize``."""
    assert romanized('ru')(lambda x: 'Корова корове')() == 'Korova korove'

# Generated at 2022-06-12 01:25:25.851800
# Unit test for function romanize
def test_romanize():
    assert "Привет!" == romanized(locale='ru')("Привет!")

# Generated at 2022-06-12 01:25:35.702895
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda *_, **__: 'Привет')() == 'Privet'
    assert romanized('uk')(lambda *_, **__: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda *_, **__: 'Сәлем')() == 'Salem'
    assert romanized('ru')(lambda *_, **__: 'Цукерберг')() == 'Cukerberg'
    assert romanized('uk')(lambda *_, **__: 'Тютюнов')() == 'Tyutynov'

# Generated at 2022-06-12 01:25:43.554024
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    assert romanize()('Мим') == 'Mim'
    assert romanize('uk')('Мим') == 'Mim'
    assert romanize('ru')('Мим') == 'Mim'
    assert romanize('kk')('Мим') == 'Mim'

    try:
        romanize('xx')('Мим')
    except UnsupportedLocale:
        assert True

    try:
        romanize()('МимМ')
    except KeyError:
        assert True

# Generated at 2022-06-12 01:25:47.537314
# Unit test for function romanize
def test_romanize():
    def foo(word: str):
        return word

    assert romanized(locale='ru')(foo)('Привет') == 'Privet'
    assert romanized(locale='uk')(foo)('Привіт') == 'Pryvit'
    assert romanized(locale='kk')(foo)('Сәлем') == 'Salem'

# Generated at 2022-06-12 01:25:51.897026
# Unit test for function romanize
def test_romanize():
    try:
        @romanize('xx')
        def romanize_func():
            return 'Привет мир'

        assert romanize_func() == 'Privet mir'
    except UnsupportedLocale:
        pass

# Generated at 2022-06-12 01:26:06.246845
# Unit test for function romanize
def test_romanize():
    """Test romanize."""

    romanize_dict = {
        'ru': data.ROMANIZATION_DICT['ru'],
        'uk': data.ROMANIZATION_DICT['uk'],
        'kk': data.ROMANIZATION_DICT['kk'],
    }

    for key, value in romanize_dict.items():
        s = ''
        for k, v in value.items():
            s += k

        @romanize(key)
        def generator(_):
            return s

        gen = generator(key)

        assert s != gen
        assert ''.join([value[i] for i in s]) == gen

# Generated at 2022-06-12 01:26:08.569750
# Unit test for function romanize
def test_romanize():
    assert romanized(locale="ru")(lambda: "Привет")() == "privet"

# Generated at 2022-06-12 01:26:13.140814
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    for code in list(Locale):
        text = Text(code)
        assert text.romanize(True) == text.romanize(True)



# Generated at 2022-06-12 01:26:19.933138
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: "мимими")() == 'mimimi'
    assert romanize('uk')(lambda x: "мимими")() == 'mimimi'
    assert romanize('kk')(lambda x: "мимими")() == 'mimimi'
    assert romanize('en')(lambda x: "мимими")() == 'мимими'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:26:28.940777
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.person import Person as OldPerson

    p = Person(locale='ru')
    assert p.full_name(gender=Gender.FEMALE) == romanize(p.full_name(gender=Gender.FEMALE))

    o = OldPerson(locale='ru')
    assert p.full_name(gender=Gender.FEMALE) == romanized(o.full_name)(gender=Gender.FEMALE)


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:26:39.937031
# Unit test for function romanize

# Generated at 2022-06-12 01:26:46.558122
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def text(text=''):
        return text

    # Without locale argument
    try:
        @romanize
        def test():
            return 'test'
    except UnsupportedLocale:
        pass
    else:
        assert False

    # Check that function decorator works correctly
    assert 'spasibo za zakaz' == text('спасибо за заказ')

    # Check that `romanize` decorator works correctly
    assert 'spasibo za zakaz' == romanize(locale='ru')(text)('спасибо за заказ')

# Generated at 2022-06-12 01:26:50.625034
# Unit test for function romanize
def test_romanize():
    """Test behavior of romanize decorator."""
    @romanize(locale='ru')
    def ru_words(seed: int = None) -> str:
        """Ru words."""
        return 'Тест романизации'

    @romanize(locale='uk')
    def uk_words(seed: int = None) -> str:
        """Uk words."""
        return 'Тест романизациї'

    @romanize(locale='kk')
    def kk_words(seed: int = None) -> str:
        """Kk words."""
        return 'Тест романизация'


# Generated at 2022-06-12 01:26:53.827559
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Понедельник')() == 'Ponedelnik'
    assert romanize('uk')(lambda: 'Понеділок')() == 'Ponedilok'



# Generated at 2022-06-12 01:26:55.994346
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    from mimesis.builtins.text import TextSpecifier

    spec = TextSpecifier('ru')
    assert spec.romanize() == 'qwertyuiop'
    assert spec.romanize('uk') == 'qqwertyuiop'

# Generated at 2022-06-12 01:27:05.037152
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Разработка софта')() == 'Razrabotka softa'

# Generated at 2022-06-12 01:27:06.857307
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Тест')() == 'Test'

# Generated at 2022-06-12 01:27:12.580209
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Здравствуй, мир!')() == 'Zdravstvuy, mir!'
    assert romanized('uk')(lambda: 'Здравствуй, мир!')() == 'Zdravstvuy, mir!'

# Generated at 2022-06-12 01:27:19.553923
# Unit test for function romanize
def test_romanize():
    rus = "Каждый охотник желает знать, где сидит фазан."

    @romanize(locale='ru')
    def f():
        return rus

    assert f() == "Kazhdyj ohotnik zhelaet znat', gde sidit fazhan."



# Generated at 2022-06-12 01:27:28.682787
# Unit test for function romanize
def test_romanize():
    from mimesis.utils import read_json

    romanization_dict = read_json('data/romanization.json')
    for k, v in romanization_dict.items():
        for _, d in v.items():
            if not isinstance(d, dict):
                continue

            for locale, dict_v in d.items():
                for key, value in dict_v.items():
                    if not isinstance(value, str):
                        continue

                    def test_func(key: str) -> str:
                        return key

                    result = romanize(locale)(test_func)(key)
                    assert result == value

# Generated at 2022-06-12 01:27:34.496598
# Unit test for function romanize
def test_romanize():
    # No parameter
    @romanize()
    def function():
        return 'Привет, друг!'

    assert function() == 'Privet, drug!'

    # With parameter
    @romanize('ua')
    def function_ua():
        return 'Привіт, друже!'

    assert function_ua() == 'Pryvit, druzhe!'
    return True

# Generated at 2022-06-12 01:27:41.376546
# Unit test for function romanize
def test_romanize():
    assert romanize()('Обидно, но условие не пройдено.') == 'Obydno, no usloviye ne proydeno.'
    assert romanize()('Обидно, но условие не пройдено. Небо пасмурное.') == 'Obydno, no usloviye ne proydeno. Nebo pasmurnoye.'

# Generated at 2022-06-12 01:27:45.236098
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    ru = Person(Locale.RU)

    assert ru.full_name() == 'Иванова Людмила Леонидовна'
    assert ru.full_name(romanize=True) == 'Ivanova Ljudmila Leonidovna'
    assert ru.full_name(romanize='ru') == 'Ivanova Ljudmila Leonidovna'

    uk = Person(Locale.UK)

    assert uk.full_name() == 'Антонова Дарина Геннадіївна'

# Generated at 2022-06-12 01:27:47.935619
# Unit test for function romanize
def test_romanize():
    def x() -> str:
        return 'Мибилити'

    assert romanize('ru')(x)() == 'Mibilíti'



# Generated at 2022-06-12 01:27:55.941923
# Unit test for function romanize
def test_romanize():
    # assert romanized('ru')(lambda: 'Андрей Александров')() == 'Andrey Aleksandrov'
    assert romanize('uk')(lambda: 'Андрій Олександрович')() == 'Andriy Oleksandrovich'
    assert romanize('kk')(lambda: 'Андрей Александров')() == 'Andrey Aleksandrov'
    # assert romanize('en')(lambda: 'Андрей Александров')() == 'Андрей Александров'




# Generated at 2022-06-12 01:28:12.358318
# Unit test for function romanize
def test_romanize():
    # Normal test.
    assert romanized('ru')(lambda: 'привет')() == 'privet'

    # Test for unsupported locale.
    try:
        romanized('en')(lambda: 'привет')()
    except UnsupportedLocale:
        assert True

    # Test for unsupported locale.
    try:
        romanized('pt')(lambda: 'привет')()
    except UnsupportedLocale:
        assert True

    # Test for unsupported locale.
    try:
        romanized('en')(lambda: 'привет')()
    except UnsupportedLocale:
        assert True

    # Test for unsupported locale.

# Generated at 2022-06-12 01:28:15.278640
# Unit test for function romanize
def test_romanize():
    assert romanize == romanized
    assert romanized(locale='ru',)(lambda: 'Привет') == 'Privet'

# Generated at 2022-06-12 01:28:19.585677
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import CyrillicSpecProvider

    text = CyrillicSpecProvider('ru')
    assert text.word() == 'победа'
    assert text.word(romanize=True) == 'pobeda'

# Generated at 2022-06-12 01:28:26.612139
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test():
        return 'Строка.'
    assert test() == 'Stroka.'

    @romanize(locale='uk')
    def test():
        return 'Строка.'
    assert test() == 'Stroka.'

    @romanize(locale='kk')
    def test():
        return 'Строка.'
    assert test() == 'Stroka.'



# Generated at 2022-06-12 01:28:37.481700
# Unit test for function romanize
def test_romanize():
    """Test of romanize"""
    import pytest

    from mimesis.enums import Locale
    from mimesis.enums import Gender

    en = Locale.en
    bg = Locale.bg
    ru = Locale.ru
    uk = Locale.uk
    kk = Locale.kk
    de = Locale.de

    person = data.Person(en)
    person.seed(0)

    assert person.full_name(gender=Gender.FEMALE) == 'Susan Parks'
    assert person.full_name(gender=Gender.MALE) == 'Jeffrey Carter'

    person = data.Person(bg)
    person.seed(0)


# Generated at 2022-06-12 01:28:39.842809
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus_word() -> str:
        return data.CYRILLIC_LETTERS['ru'][0]

    assert rus_word() == 'a'

# Generated at 2022-06-12 01:28:43.676638
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_test(self, locale):
        return self.text.cyrillic()
    assert romanize_test(locale='ru')

# Generated at 2022-06-12 01:28:45.406647
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Строка')() == 'Stroka'



# Generated at 2022-06-12 01:28:48.993290
# Unit test for function romanize
def test_romanize():
    assert romanize()('Всем привет') == 'Vsem privet'
    assert romanize()('Всем привет!'.upper()) == 'Vsem privet!'

# Generated at 2022-06-12 01:28:57.746602
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""

# Generated at 2022-06-12 01:29:15.720865
# Unit test for function romanize
def test_romanize():
    output = romanize(locale='ru')(lambda: 'Компания Ай-Ти')()
    assert output == 'Kompaniia Ai-Ti'

    output = romanize(locale='uk')(lambda: 'Ай-Ти')()
    assert output == 'Ai-Ti'

    output = romanize(locale='kk')(lambda: 'Компания Ай-Ти')()
    assert output == 'Kompaniya Aı-Tı'

# Generated at 2022-06-12 01:29:19.807024
# Unit test for function romanize
def test_romanize():
    """Test for romanize with russian locale."""
    from mimesis.builtins import RussiaSpecProvider

    russian = RussiaSpecProvider()

    @romanize('ru')
    def name():
        """Generate russian name."""
        return russian.name()

    assert name()

# Generated at 2022-06-12 01:29:25.922879
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize decorator."""

    @romanize(locale='ru')
    def romanized_ru(value):
        return value

    assert 'Джей' == romanized_ru('Джей')

    @romanize(locale='uk')
    def romanized_uk(value):
        return value

    assert 'Джей' == romanized_uk('Джей')

    @romanize(locale='kk')
    def romanized_kk(value):
        return value

    assert 'Джей' == romanized_kk('Джей')

# Generated at 2022-06-12 01:29:35.950884
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def cyrillic_to_roman(text: str) -> str:
        return text
    # Russian
    assert cyrillic_to_roman('Здравствуйте!') == 'Zdras\'tvuyte!'
    assert cyrillic_to_roman('Привет!') == 'Privet!'

    @romanize(locale='uk')
    def cyrillic_to_roman(text: str) -> str:
        return text

    # Ukrainian
    assert cyrillic_to_roman('Ласкаво просимо!') == 'Laskavo prosymo!'

# Generated at 2022-06-12 01:29:39.585923
# Unit test for function romanize
def test_romanize():
    """Test romanization of russian words."""
    from mimesis.providers.text import Text
    text_data = Text(locale='ru')
    text_data.romanize(locale='ru')
    assert text_data.romanize(locale='ru')

# Generated at 2022-06-12 01:29:43.396695
# Unit test for function romanize
def test_romanize():
    @romanized()
    def get_name(locale=''):
        return 'Привет мир'
    assert get_name() == 'Privet mir'



# Generated at 2022-06-12 01:29:45.762781
# Unit test for function romanize
def test_romanize():
    @romanize('es')
    def foo(*args, **kwargs):
        return 'foo'

    assert foo() == 'foo'

# Generated at 2022-06-12 01:29:52.831140
# Unit test for function romanize
def test_romanize():
    d = {
        'kk': ('Сүйен алаңыз!', 'Süyen alañız!'),
        'ru': ('Привет, Мир!', 'Privet, Mir!'),
        'uk': ('Здравствуйте, Мир!', 'Zdravstvuyte, Mir!'),
    }

    for k, v in d.items():
        assert romanize(k)(lambda *args, **kwargs: v[0])(None) == v[1]

# Generated at 2022-06-12 01:29:58.980090
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Привет'.upper())() == 'PRIVET'
    assert romanize('kk')(lambda : 'Сәлем'.upper())() == 'SALEM'
    assert romanize('uk')(lambda : 'Вітаю'.upper())() == 'VITAYU'

# Generated at 2022-06-12 01:30:10.922257
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Что тут у нас?')() == 'Chto tut u nas?'
    assert romanize('ru')(lambda: 'Что тут у нас?')() == 'Chto tut u nas?'
    assert romanize('uk')(lambda: 'Шо тут у нас?')() == 'Sho tut u nas?'
    assert romanize('uk')(lambda: 'Шо тут у нас?')() == 'Sho tut u nas?'

# Generated at 2022-06-12 01:30:35.056187
# Unit test for function romanize
def test_romanize():
    # func = romanize('ru')(lambda: 'x')
    # assert func() == 'x'
    pass

# Generated at 2022-06-12 01:30:36.812527
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='en')(lambda: '')() == ''

# Generated at 2022-06-12 01:30:37.957896
# Unit test for function romanize
def test_romanize():
    # TODO: write test for romanize decorator
    pass

# Generated at 2022-06-12 01:30:40.344169
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    def hello():
        return 'Привет!'

    func = romanize(locale)(hello)
    assert func() == 'Privet!'

# Generated at 2022-06-12 01:30:43.017016
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Мамуля')() == 'Mamulya'

# Generated at 2022-06-12 01:30:47.583366
# Unit test for function romanize
def test_romanize():
    assert romanize('cs')(lambda: 'Přeji ti hodně štěstí')() == 'Preji ti hodne stesti'
    assert romanize('en')(lambda: 'hi')() == 'hi'



# Generated at 2022-06-12 01:30:49.865140
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize('ru')(_fake_function_with_side_effects)() == 'функция без побочных эффектов'

# Generated at 2022-06-12 01:31:00.058518
# Unit test for function romanize
def test_romanize():
    res = romanize()(lambda: 'Пример русской фразы на кириллице')
    assert res == 'Primer russkoi frazy na kirillitse'

    res = romanize('ru')(lambda: 'Пример русской фразы на кириллице')
    assert res == 'Primer russkoi frazy na kirillitse'


# Generated at 2022-06-12 01:31:05.769354
# Unit test for function romanize
def test_romanize():
    text = "Служба экспресс-доставки (СЭД)"
    romanized_text = romanize(locale='ru')(lambda: text)
    assert romanized_text() == "Sluzhba ekspress-dostavki (SED)"



# Generated at 2022-06-12 01:31:13.267743
# Unit test for function romanize
def test_romanize():
    """Tests for checking romanization of cyrillic text."""
    from mimesis import Person
    p = Person('ru')

    assert p.full_name() == 'Юлия Брагина'

    @romanize('ru')
    def full_name():
        return p.full_name()

    assert full_name() == 'Yuliya Bragina'

    def full_name():
        return p.full_name()

    assert full_name() == 'Юлия Брагина'

# Generated at 2022-06-12 01:32:24.821483
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'привет')() == 'privet'
    assert romanize(locale='ru')(lambda: 'привет')() == 'privet'
    assert romanize(locale='uk')(lambda: 'привіт')() == 'privit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Sалем'

# Generated at 2022-06-12 01:32:31.443793
# Unit test for function romanize
def test_romanize():
    from datetime import date
    from mimesis.builtins import RussiaSpecProvider

    class Person(RussiaSpecProvider):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.russian = self.__class__('ru')

        @romanize('ru')
        def address(self) -> str:
            return self.russian.address()

    person = Person()
    address = person.address()

    assert isinstance(address, str)
    assert isinstance(person, Person)
    assert isinstance(person.address(), str)

# Generated at 2022-06-12 01:32:42.748515
# Unit test for function romanize
def test_romanize():
    from mimesis.numbers import Integer
    from mimesis.utils import choice

    locales = ('ru', 'uk', 'kk')
    locale = choice(locales)
    max_char_length = choice((2, 3))

    int_ = Integer(locale=locale)
    gen = int_.romanized_string(max_char_length)
    romanized_string = gen()

    assert len(romanized_string) <= max_char_length
    assert romanized_string != int_.string(max_char_length)

    romanized_string = gen(symbols='abcd')
    assert set(romanized_string).issubset(set('abcd'))
    assert len(romanized_string) <= max_char_length



# Generated at 2022-06-12 01:32:45.673486
# Unit test for function romanize
def test_romanize():
    """Unit test for method romanize."""
    assert romanize is romanized
    assert romanize('ru')
    assert romanize('uk')(lambda x: 'тест')() == 'test'

# Generated at 2022-06-12 01:32:49.989737
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def rus_ru():
        return 'ПРИВЕТ'

    @romanized('kk')
    def rus_kk():
        return 'СӨЙЛЕ'

    @romanized('uk')
    def rus_uk():
        return 'ПРИВІТ'

    assert rus_ru() == 'PRIVET'
    assert rus_kk() == 'SÖYLE'
    assert rus_uk() == 'PRIVIT'

# Generated at 2022-06-12 01:32:52.189480
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мимимисис!')() == 'Privet, Mimimisis!'

# Generated at 2022-06-12 01:32:57.679280
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Region

    class TestRomanize(object):
        region = Region.RU

        @romanize(locale=region)
        def romanization(self):
            return 'Кириллица'

    assert TestRomanize().romanization() == 'Kirillitsa'

# Generated at 2022-06-12 01:32:59.726137
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('Привет, Мир!').upper() == 'PRIVET, MIR!'

# Generated at 2022-06-12 01:33:01.113182
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'слово')() == 'slovo'

# Generated at 2022-06-12 01:33:08.803840
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    assert 'Kyiv' == romanize('uk')(lambda: 'Київ')()
    assert 'Almaty' == romanize('kk')(lambda: 'Алматы')()
    assert 'vse vydayushcheesya' == romanize('ru')(lambda: 'все выдающееся')()

