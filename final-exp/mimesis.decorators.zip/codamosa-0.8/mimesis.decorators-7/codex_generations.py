

# Generated at 2022-06-12 01:24:55.966041
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    @romanize('uk')
    def romanize_test(i):
        return i

    assert romanize_test(i='Доброго дня') == 'Dobroho dnia'

# Generated at 2022-06-12 01:25:02.887266
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Это просто текст')() == 'Это просто текст'
    assert romanize('ru')(lambda: 'Это просто тряска')() == 'Это просто trяска'

# Generated at 2022-06-12 01:25:05.111010
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Самолет')() == 'Samolety'



# Generated at 2022-06-12 01:25:08.157581
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    provider = RussiaSpecProvider()
    romanized_string = provider.full_name()
    print(romanized_string)

# Generated at 2022-06-12 01:25:11.680073
# Unit test for function romanize
def test_romanize():
    @romanize()
    def _func():
        return 'Привет мир!'

    result = _func()
    assert result == 'Привет мир!'



# Generated at 2022-06-12 01:25:22.152182
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    r = lambda x: romanize(Language.RU)(lambda: x)  # noqa: E731
    # assert r(1) == 1

    assert r('картошка') == 'kartoshka'
    assert r('українська') == 'ukrainska'
    assert r('Святослав') == 'Svyatoslav'

    assert romanize(Language.UK)(lambda: 'кирилиця') == 'kirilitsya'
    assert romanize(Language.KK)(lambda: 'кирилиця') == 'kirilitsya'

# Generated at 2022-06-12 01:25:32.530415
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text
    t = mimesis.builtins.text.Text()

    txt_ru = t.cyrillic_string(language_code='ru', quantity=10)
    txt_uk = t.cyrillic_string(language_code='uk', quantity=10)
    txt_kk = t.cyrillic_string(language_code='kk', quantity=10)

    assert txt_ru == t.romanize_string(language_code='ru', quantity=10)
    assert txt_uk == t.romanize_string(language_code='uk', quantity=10)
    assert txt_kk == t.romanize_string(language_code='kk', quantity=10)

# Generated at 2022-06-12 01:25:40.243994
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanized_text(size: int = 10) -> str:
        return 'Съешь ещё этих мягких французских булок 123'

    assert romanized_text(size=123) == 'Sesh eshche etikh miagkikh frantsuzskikh bulok 123'



# Generated at 2022-06-12 01:25:43.231691
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.text import Text
    from mimesis.enums import Language
    text = Text(Language.RU)
    assert text.romanize() == text.romanized()

# Generated at 2022-06-12 01:25:49.524646
# Unit test for function romanize
def test_romanize():
    import string

    from mimesis import Person
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.data import COMMON_LETTERS
    from mimesis.data import ROMANIZATION_DICT

    p = Person('uk')
    russian = Person('ru', RussiaSpecProvider)

    assert all([s in russian.name(gender=Gender.MALE)
                for s in string.punctuation])
    assert all([s in russian.surname(gender=Gender.MALE)
                for s in string.punctuation])
    assert all([s in russian.patronymic(gender=Gender.MALE)
                for s in string.punctuation])

    name = p.name(gender=Gender.MALE)
   

# Generated at 2022-06-12 01:26:06.289691
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Джейсон Стэйтем')() == 'Djeison Steithem'
    assert romanize('uk')(lambda: 'Ірина Антоненко-Давидович')() == 'Iryna Antonyenko-Davydivych'
    assert romanize('ru')(lambda: 'Мария Ивановна Кудрявцева-Курылева')() == 'Marija Ivanovna Kudrjavceva-Kuryleva'
    assert romanize('kk')(lambda: 'Астана')() == 'Astana'

# Generated at 2022-06-12 01:26:17.833430
# Unit test for function romanize
def test_romanize():
    """Romanize test."""

# Generated at 2022-06-12 01:26:22.459965
# Unit test for function romanize
def test_romanize():
    test_str = 'Как известно, длинные слова труднее запоминаются.'
    romanized_str = 'Kak izvestno, dlinnye slova trudneye zapominaiutsya.'

    @romanize(locale='ru')
    def romanized_func(text: str) -> str:
        return text

    assert romanized_func(test_str) == romanized_str

# Generated at 2022-06-12 01:26:24.985791
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир')() == 'Привет, мир'

# Generated at 2022-06-12 01:26:29.885998
# Unit test for function romanize
def test_romanize():  # pragma: no cover
    """
    print("Romanize:")

    @romanize('uk')
    def get_ukrainian_word():
        return "Вiтання"

    assert get_ukrainian_word() == 'Vitannya'
    print(get_ukrainian_word())
    """



# Generated at 2022-06-12 01:26:32.956508
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    def translate(ru: str) -> str:
        return ru

    romanize_translate = romanize(locale='ru')(translate)

    assert romanize_translate('тест') == 'test'



# Generated at 2022-06-12 01:26:43.644230
# Unit test for function romanize

# Generated at 2022-06-12 01:26:52.174304
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_ru(locale: str) -> str:
        return locale

    assert romanize_ru.__name__ == 'romanize_ru'

    @romanize(locale='kk')
    def romanize_kk(locale: str) -> str:
        return locale

    assert romanize_kk.__name__ == 'romanize_kk'

    @romanize(locale='uk')
    def romanize_uk(locale: str) -> str:
        return locale

    assert romanize_uk.__name__ == 'romanize_uk'



# Generated at 2022-06-12 01:26:57.431780
# Unit test for function romanize
def test_romanize():
    u"""Юнит-тест для функции romanize()."""
    import sys
    import os
    import unittest
    sys.path.append(os.path.dirname(__file__))
    from test_mimesis import TestMimesis

    suite = unittest.TestLoader().loadTestsFromTestCase(TestMimesis)
    unittest.TextTestRunner(verbosity=2).run(suite)


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-12 01:26:59.628274
# Unit test for function romanize
def test_romanize():
    import random
    random.seed()
    @romanize()
    def foo():
        return random.choice(['Тест', 'тест'])
    assert foo() in ('Test', 'test')

# Generated at 2022-06-12 01:27:10.975612
# Unit test for function romanize
def test_romanize():
    assert romanized()('Мимимимимимимимимимимимимимимимимимимимимимимиц') == \
           'mimimimimimimimimimimimimimimimimimimimimimimimimimimimimimimimimi'

# Generated at 2022-06-12 01:27:17.475311
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    # Create the instance.
    provider = RussiaSpecProvider(gender=Gender.MALE)
    # Get romanized name.
    name = provider.name()
    assert name == 'Aleksey'
    # Get romanized fullname.
    fullname = provider.full_name()
    assert fullname == 'Aleksey'

# Generated at 2022-06-12 01:27:19.873653
# Unit test for function romanize
def test_romanize():
    """Test romanized."""
    assert romanize('ru')(lambda: 'Кембридж')() == 'Kembridzh'

# Generated at 2022-06-12 01:27:24.239926
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    import mimesis
    __name__ = mimesis.__name__
    assert mimesis.__name__ is __name__


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:27:32.095183
# Unit test for function romanize
def test_romanize():
    """Check if romanization is working."""
    from mimesis.builtins import RussianSpecProvider

    r = RussianSpecProvider(locale='uk')


# Generated at 2022-06-12 01:27:39.635466
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    rus = RussiaSpecProvider()
    result = rus.cyrillic_text(10)
    assert romanized(locale='ru')(rus.cyrillic_text)(10) == result
    assert romanized('ru')(rus.cyrillic_text)(10) == result

    result = rus.cyrillic_text(10, tpe='py')
    assert romanized('ru')(rus.cyrillic_text)(10, tpe='py') == result

    result = rus.cyrillic_text(10, tpe='vo')
    assert romanized('ru')(rus.cyrillic_text)(10, tpe='vo') == result

# Generated at 2022-06-12 01:27:40.747660
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: '')() == ''



# Generated at 2022-06-12 01:27:45.794550
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'привет')() == 'privet'
    assert romanize('kk')(lambda x: 'hello')() == 'hello'
    assert romanize('uk')(lambda x: 'привіт')() == 'privit'

# Generated at 2022-06-12 01:27:51.169761
# Unit test for function romanize
def test_romanize():
    assert data.random_romanized_word(locale='ru') == 'Вишукэддо'
    assert data.random_romanized_word(locale='uk') == 'Вишукэддо'
    assert data.random_romanized_word(locale='kk') == 'Вишукэддо'

# Generated at 2022-06-12 01:27:54.813970
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import BelarusianSpecProvider

    be = BelarusianSpecProvider(locale='be_BY')
    be.seed('Mimesis')

    assert be.text(romanize=True) == 'Дзміцер'

# Generated at 2022-06-12 01:28:08.731964
# Unit test for function romanize
def test_romanize():
    x = None
    assert romanize()(x) is None
    test_func_with_non_string_input = romanize()(lambda x: x)
    assert test_func_with_non_string_input(False) is False

    from mimesis.builtins import RussiaSpecProvider
    r = RussiaSpecProvider()

    @romanize('ru')
    def test_func_with_cyrillic_input(cyrillic_text):
        return cyrillic_text

    assert test_func_with_cyrillic_input(r.full_name()) == (
        'Maksim Rovnov')

# Generated at 2022-06-12 01:28:11.789165
# Unit test for function romanize
def test_romanize():
    cyrillic = 'Привет, мир!'
    latin = 'Pryvit, mir!'

    @romanize()
    def cyrillic_text():
        return cyrillic

    assert cyrillic_text() == latin

# Generated at 2022-06-12 01:28:19.090266
# Unit test for function romanize
def test_romanize():
    assert romanize()('Шрифт') == 'Shrift'
    assert romanize('ru')('фаршировать') == 'farshirovatʹ'
    assert romanize('uk')('Версія') == 'Versiia'
    assert romanize('kk')('қарау') == 'qaraw'

# Generated at 2022-06-12 01:28:24.616973
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Справка')() == 'Spravka'
    assert romanize('uk')(lambda x: 'Справка')() == 'Spravka'
    assert romanize('kk')(lambda x: 'Справка')() == 'Spravka'

# Generated at 2022-06-12 01:28:34.464976
# Unit test for function romanize
def test_romanize():
    @romanize
    def get_russian_name():
        return 'Дмитрий'

    @romanize
    def get_russian_surname():
        return 'Костромин'

    @romanize
    def get_russian_patronymic():
        return 'Дмитриевич'

    @romanize
    def get_ukrainian_name():
        return 'Дмитро'

    # assert get_russian_name() == 'Dmitriy'
    assert get_russian_surname() == 'Kostromin'
    assert get_russian_patronymic() == 'Dmitrievich'
    assert get_ukrainian_name() == 'Dmytro'

# Generated at 2022-06-12 01:28:42.811398
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "Привет")() == "Privet"
    assert romanize('ru')(lambda: "Привет, Мир!")() == "Privet, Mir!"
    assert romanize('uk')(lambda: "Привіт")() == "Pryvit"
    assert romanize('uk')(lambda: "Привіт, Світ!")() == "Pryvit, Svit!"
    assert romanize('kk')(lambda: "сәлем дүние")() == "sälem dünie"
    assert romanize('kk')(lambda: "сәлем дүние!")

# Generated at 2022-06-12 01:28:52.867066
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Текст.')() == 'Tekst.'
    assert romanize()(lambda: 'АбвгдежзИйклмноПрстуфхЦчшщЪЫЬЭюя ')() \
           == 'AbvgdIzijklmnprstufhCchschY\'Y\'E`juja '

# Generated at 2022-06-12 01:28:54.806703
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Кириллица')() == 'Kirillica'

# Generated at 2022-06-12 01:29:03.819717
# Unit test for function romanize
def test_romanize():
    assert romanize()('Здравствуйте!') == 'Zdravstvujte!'
    assert romanized()('Здравствуйте!') == 'Zdravstvujte!'
    assert romanized('ru')('Здравствуйте!') == 'Zdravstvujte!'
    assert romanized('uk')('Здравствуйте!') == 'Zdravstvujte!'
    assert romanized('kk')('Здравствуйте!') == 'Zdravstvujte!'

# Generated at 2022-06-12 01:29:14.206331
# Unit test for function romanize
def test_romanize():
    """Function ``romanize`` test."""
    assert (
        romanize(locale='ru')(lambda x: 'кириллица')() == 'kirillica'
    ), 'Ru locale not working.'

    assert (
        romanize(locale='uk')(lambda x: 'абвгдеєжзиіїйклмнопрстуфхцчшщьюя')() == (
           'abvhddeiezhzhyiiyiklmnoprstufkhtschschschyiuia')
    ), 'Uk locale not working.'


# Generated at 2022-06-12 01:29:46.582765
# Unit test for function romanize
def test_romanize():
    import pydoc
    import mimesis.builtins.text

    romanized_text = pydoc.render_doc(mimesis.builtins.text, "Help on module mimesis.builtins.text in mimesis.builtins:", renderer=pydoc.plaintext)
    print(romanized_text)
    if romanized_text.find("Из текста выбрать псевдо-случайную последовательность") == -1:
        raise SystemExit("Not transliterated")

# Generated at 2022-06-12 01:29:51.262861
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo():
        return 'Мухаммад Али Ибн Абу Талиб аль-Османи'

    assert foo() == 'Muhammadi Ali Ibn Abu Talib al-Osmani'



# Generated at 2022-06-12 01:29:52.586687
# Unit test for function romanize
def test_romanize():
    # Cyrillic string should contain latin alphabet
    assert romanize()("МіМесis")

# Generated at 2022-06-12 01:29:59.006409
# Unit test for function romanize
def test_romanize():
    assert romanize()(list)('Текст') == ['T', 'i', 'k', 's', 't']
    assert romanize()(str)('Текст') == 'Tikst'
    assert romanized(locale='ru')(str)('Здравствуй, текст!') == \
        'Zdravstvuj, tekst!'



# Generated at 2022-06-12 01:30:05.172393
# Unit test for function romanize
def test_romanize():
    # Assert that romanized
    # properly handles unsupported locales
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.providers.person import Person

    p = Person('en')
    try:
        p.name(locale='foo')
    except UnsupportedLocale as e:
        assert str(e) == 'foo'

# Generated at 2022-06-12 01:30:09.321852
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == romanize('ru')('привет')


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:30:14.507041
# Unit test for function romanize
def test_romanize():
    """Unit test for ``romanize`` function."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    r = RussiaSpecProvider()
    name = r.person.full_name(gender=Gender.MALE)
    assert romanized()(lambda: name)() == romanize()(lambda: name)()

# Generated at 2022-06-12 01:30:17.134556
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    @romanize(locale=Locale.RUSSIAN)
    def rus():
        return 'Привет Мир!'

    assert rus() == 'Privet Mir!'

# Generated at 2022-06-12 01:30:28.341549
# Unit test for function romanize

# Generated at 2022-06-12 01:30:31.975008
# Unit test for function romanize
def test_romanize():
    romanize_check = romanized('zh')

    @romanize_check
    def test_fuc():
        return 'Привет，世界'

    assert test_fuc == 'Privet，Shijie'

# Generated at 2022-06-12 01:31:21.041458
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    txt = Text(Language.RU)
    assert txt.romanized() == txt.arabic()



# Generated at 2022-06-12 01:31:25.320107
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def get_name():
        return "Грицай Новак"

    assert get_name() == "Gracay Novak"

# Generated at 2022-06-12 01:31:35.724931
# Unit test for function romanize
def test_romanize():
    # Test of romanized function in function
    def romanized_func(string):
        return string

    assert romanized_func('Паша') == 'Паша'
    assert romanized_func('Pasha') == 'Pasha'
    assert romanized_func('Паша Гоголь') == 'Паша Гоголь'
    assert romanized_func('Pasha Gogol') == 'Pasha Gogol'
    # Test of romanized function inside instance method
    class Romanize:
        def romanized_method(self, string):
            return string

        @romanized()
        def decorated_method(self, string):
            return string

    r = Romanize()
    assert r.romanized

# Generated at 2022-06-12 01:31:37.441449
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda:'Джекилл и Хайрд')() == 'Dzhekill i Khayrd'

# Generated at 2022-06-12 01:31:46.939689
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.schema import Field, Schema

    Person = Schema(lang=Language.RUSSIAN)
    person = Person(
        {
            'first_name': Field('name'),
            'last_name': Field('surname'),
        }
    )
    person.first_name, person.last_name

    # Romanized function with default locale
    Person = Schema(lang=Language.UKRAINIAN)
    person = Person(
        {
            'first_name': Field('name', romanize=True),
            'last_name': Field('surname', romanize=True),
        }
    )
    person.first_name, person.last_name

    # Romanized function with locale

# Generated at 2022-06-12 01:31:49.898758
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def random_cyrillic_word():
        return 'ёлка'

    rw = random_cyrillic_word()
    assert rw == 'yolka'

# Generated at 2022-06-12 01:31:59.990215
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def foo(x, y):
        r = x + y
        return r

    r = foo('Привет, мир', '!')
    assert r == 'Privet, mir !'

# Generated at 2022-06-12 01:32:08.827759
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('ru')
    person.create_formatted_name(Gender.MALE)
    assert person.random_name() in person.name
    assert person.get_full_name(Gender.MALE) in \
        person.random_name().split()

    person = Person('uk')
    person.create_formatted_name(Gender.FEMALE)
    assert person.random_name() in person.name
    assert person.get_full_name(Gender.FEMALE) in \
        person.random_name().split()

# Generated at 2022-06-12 01:32:11.807104
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""

    @romanize('ru')
    def romanized_rus(): return 'Снегири'

    assert romanized_rus() == 'Snegiri'

    @romanized
    def romanized_lt(): r

# Generated at 2022-06-12 01:32:14.287134
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person('ru')

    name = person.full_name(gender=Gender.FEMALE)
    assert name == romanize()(name)

# Generated at 2022-06-12 01:33:52.886200
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Text

    t = Text('ru')
    text = t.text()
    romanized_text = romanized('ru')(t.text)()
    assert len(text) == len(romanized_text)

# Generated at 2022-06-12 01:34:00.027245
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Стальной Алхимик')() == 'Stalnoy Alkhimik'
    assert romanize(locale='uk')(lambda: 'Речні сполохи')() == 'Rechni spolohy'
    assert romanize(locale='kk')(lambda: 'Асыл арман')() == 'Asyl arman'

# Generated at 2022-06-12 01:34:03.034669
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'тест')().isalpha()

# Generated at 2022-06-12 01:34:08.218918
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, мир!') == 'Privet, mir!'
    assert romanize('uk')('Привіт, світ!') == 'Pryvit, svit!'
    assert romanize('kk')('Салам, дүние!') == 'Salam, dunye!'

# Generated at 2022-06-12 01:34:11.685093
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text

    tt = Text('ru')
    i = Internet('ru')

    @romanized('ru')
    def foo():
        return "{} {}".format(tt.text(), i.url())

    print(foo())

# Generated at 2022-06-12 01:34:13.689440
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def roman_str():
        return 'тест'

    assert roman_str() == 'test'



# Generated at 2022-06-12 01:34:19.337746
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(str)('') == ''
    assert romanized('ru')(str)('привет') == 'privet'
    assert romanize('uk')(str)('привіт') == 'privit'
    assert romanize('kk')(str)('Сәлем') == 'Salem'

# Generated at 2022-06-12 01:34:22.216869
# Unit test for function romanize
def test_romanize():
    x = romanize(locale='ru')

    @x
    def func(a: str='Привет') -> str:
        return a

    assert func() == 'Privet'

# Generated at 2022-06-12 01:34:24.128115
# Unit test for function romanize
def test_romanize():
    pass

    # def test_romanize():
    #     from mimesis.builtins.text import Text
    #     from mimesis.enums import Language
    #     text = Text(Language.RU)
    #     t = text.romanize()
    #     assert t

# Generated at 2022-06-12 01:34:26.522564
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    assert romanize()('Привет, мир!') == 'Privet, mir!'