

# Generated at 2022-06-12 01:24:54.707448
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(
        lambda: data.CYRILLIC_LETTERS_RU_RU.get_choice()
    )() in data.LATIN_LETTERS_RU_RU

# Generated at 2022-06-12 01:24:56.011233
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('test') == 'test'

# Generated at 2022-06-12 01:25:07.771339
# Unit test for function romanize
def test_romanize():
    from random import sample, randint
    from mimesis.enums import Language
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business

    p = Person('en')
    a = Address('en')
    b = Business('en')

    def get_random_locale():
        return Language(randint(0, 31))

    latin_data = {
        'name': p.full_name(),
        'address': a.address(),
        'company': b.company(),
    }

    locales = {
        Language.RUSSIAN: 'ru',
        Language.UKRAINIAN: 'uk',
        Language.KAZAKH: 'kk',
    }


# Generated at 2022-06-12 01:25:19.445831
# Unit test for function romanize
def test_romanize():
    assert romanize.__name__ == 'romanize'
    assert romanize_deco.__name__ == 'romanize'
    assert wrapper.__name__ == 'romanize'
    assert romanize_deco.__name__ == 'romanize'
    assert romanize_deco.__doc__ == 'Romanize the cyrillic text.\n\n    ' \
                                   'Transliterate the cyrillic script ' \
                                   'into the latin alphabet.\n\n    ' \
                                   '.. note:: At this moment it works ' \
                                   'only for `ru`, `uk`, `kk`.\n\n    ' \
                                   ':param locale: Locale code.\n    ' \
                                   ':return: Romanized text.\n    '
    assert roman

# Generated at 2022-06-12 01:25:23.438236
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('Привет, мир!')().startswith('Privet, mir')
    assert romanized('kk')('Еуропа Одағы')().startswith('Evropa Odagi')

# Generated at 2022-06-12 01:25:26.981234
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo():
        return 'Я очень люблю code'

    assert foo() == 'Ya ochen' ' lublu code'

# Generated at 2022-06-12 01:25:36.294670
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.builtins import RussiaSpecProvider

    class LocaleRussia(RussiaSpecProvider):
        pass

    ru = LocaleRussia('ru')
    ru.seed(42)
    str_1 = ru.full_name(gender='female')

    ru_1 = ru.romanize(locale='ru')
    ru_1.seed(42)
    str_2 = ru_1.full_name(gender='female')

    ru_2 = ru.romanize(locale='uk')
    ru_2.seed(42)
    str_3 = ru_2.full_name(gender='female')

    ru_3 = ru.romanize(locale='kk')
    ru_3.seed(42)
    str_4 = ru_3.full_name(gender='female')

   

# Generated at 2022-06-12 01:25:40.407131
# Unit test for function romanize
def test_romanize():
    from mimesis.mimesis import Mimesis
    m = Mimesis()
    @romanize()
    def romanizer():
        return m.person.full_name()
    assert callable(romanizer)() and isinstance(romanizer(), str)

# Generated at 2022-06-12 01:25:41.721714
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)


# Generated at 2022-06-12 01:25:48.712273
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""

    from mimesis.enums import Gender
    from mimesis.providers.personal import Person

    p = Person('ru')
    result = p.full_name('f')
    assert isinstance(result, str)
    assert result == 'Юлия Крючкова'

    result = p.full_name('f', romanize=True)
    assert isinstance(result, str)
    assert result == 'Yuliya Kryuchkova'

    result = p.full_name('f', locale='de')
    assert isinstance(result, str)
    assert result == 'Johanna Döring'

    # Lowercasing
    result = p.full_name('f', romanize=True).lower()
    assert isinstance

# Generated at 2022-06-12 01:25:59.979669
# Unit test for function romanize
def test_romanize():
    romanized_examples = [
        ('Привет, мир!', 'Privet, mir!'),
        ('Мама мыла раму!', 'Mama myla ramu!'),
        ('Раз, два, три, четыре', 'Raz, dva, tri, chetyre'),
    ]

    for example in romanized_examples:
        assert romanize('ru')(lambda: example[0])(), example[1]

# Generated at 2022-06-12 01:26:10.516766
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Люблю кушать')() == 'Lyublyu kushat'
    assert romanize(locale='ru')(lambda: 'Люблю кушать')() == 'Lyublyu kushat'
    assert romanize()(lambda: 'Люблю кушать')(locale='ru') == 'Lyublyu kushat'

    # Test for exception UnsupportedLocale
    try:
        assert romanize(locale='en')(lambda: 'Люблю кушать')()
    except UnsupportedLocale:
        pass

# Generated at 2022-06-12 01:26:11.683208
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_ru_text():
        return 'Привет Мир!'

    assert get_ru_text() == 'Privet Mir!'

# Generated at 2022-06-12 01:26:17.238694
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Любовь')() == 'Lyubov'
    assert romanize('uk')(lambda: 'Любовь')() == 'Liubov'
    assert romanize('kk')(lambda: 'Любовь')() == 'Lyubov'

# Generated at 2022-06-12 01:26:18.743357
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')
    assert romanized(locale='ru')
    assert romanize

# Generated at 2022-06-12 01:26:27.241511
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize('ru')(lambda: 'Это тестовая строка')() == 'Eto testovaya stroka'
    assert romanize('uk')(lambda: 'Это тестовая строка')() == 'Eto testovaya stroka'
    assert romanize('kk')(lambda: 'Это тестовая строка')() == 'Eto testovaya stroka'

# Generated at 2022-06-12 01:26:28.777488
# Unit test for function romanize
def test_romanize():
    assert romanized.__name__ == 'romanize'
    assert romanized.__doc__ == romanize.__doc__
    assert romanized.__annotations__ == romanize.__annotations__

# Generated at 2022-06-12 01:26:29.372601
# Unit test for function romanize
def test_romanize():
    romanize('ru')

# Generated at 2022-06-12 01:26:34.074057
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    from mimesis.providers import Address

    class MyProvider(RussianSpecProvider):
        @romanize(locale='ru')
        def russian_string(self):
            return super().russian_string()

    mp = MyProvider('ru')
    assert mp.russian_string() is not None
    assert mp.russian_string() is not None

    ap = Address('ru')
    assert ap.region() is not None

    # ToDo  Add checks

# test_romanize()

# Generated at 2022-06-12 01:26:37.121122
# Unit test for function romanize
def test_romanize():
    assert romanize("")("Russian") == "Russian"
    assert romanize("ru")("Russian") == "Russkiy"

test_romanize()

# Generated at 2022-06-12 01:26:50.306565
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus():
        return 'Текст на русском языке'

    assert rus() == 'Tekst na russkom yazyke'

# Generated at 2022-06-12 01:26:52.173275
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda x: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-12 01:26:53.365191
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'привет')() == 'privet'

# Generated at 2022-06-12 01:26:54.981878
# Unit test for function romanize
def test_romanize():
    assert romanize('it')
    assert romanized('ru')
    assert romanized('uk')
    assert romanized('kk')

# Generated at 2022-06-12 01:26:56.338747
# Unit test for function romanize
def test_romanize():
    from .personal import Personal
    r = Personal()

    assert isinstance(r.name(locale='ru-RU', romanize=True), str)

# Generated at 2022-06-12 01:26:58.488159
# Unit test for function romanize
def test_romanize():
    txt = romanized(locale='ru')(lambda: 'Привет! Как дела?')
    assert txt == 'Privet! Kak dela?'

# Generated at 2022-06-12 01:27:01.671219
# Unit test for function romanize
def test_romanize():
    # test without locale
    @romanized()
    def test_romanize():
        return 'тест'

    assert test_romanize() == 'test'

    # test with locale=ru
    @romanized(locale='ru')
    def test_romanize():
        return 'тест'

    assert test_romanize() == 'test'

# Generated at 2022-06-12 01:27:08.926437
# Unit test for function romanize
def test_romanize():
    @romanized('ua')
    def romanize_func(a):
        return a

    assert romanize_func('Київ') == 'Kyiv'

    @romanized('ru')
    def romanize_func_1(a):
        return a

    assert romanize_func_1('Калининград') == 'Kaliningrad'



# Generated at 2022-06-12 01:27:11.767877
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_string():
        return "Привет, Мир!"
    assert russian_string() == 'Privyet, Mir!'


# Generated at 2022-06-12 01:27:17.518699
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    from mimesis.enums import Locale
    from mimesis.providers import Person

    assert romanize(Locale.RU)(Person().full_name)
    assert romanize(Locale.UK)(Person().full_name)
    assert romanize(Locale.KZ)(Person().full_name)



# Generated at 2022-06-12 01:27:38.623755
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-12 01:27:43.201068
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize('ru')(lambda: 'abc')() == 'abc'
    assert romanize('ru')(lambda: 'фыв')() == 'fyv'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:27:43.793569
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-12 01:27:50.127094
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize('uk')('Привіт') == 'Privit'
    assert romanize('ru')('Привет') == 'Privet'
    assert romanize('ru')('Привет 12') == 'Privet 12'
    assert romanize('kk')('Сәлем') == 'Salem'

# Generated at 2022-06-12 01:27:56.934683
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    from mimesis.enums import Locale
    from mimesis.providers.personal import Person
    import pytest

    person = Person('ru')
    full_name = person.full_name()
    a = person._romanize(full_name)
    b = person.romanize(full_name)
    c = person.romanized(full_name)

    assert a == b, 'Romanize is not working correctly.'
    assert a == c, 'Romanized is not working correctly.'
    assert b == c, 'Romanize and Romanized mismatch.'

    # Raise unsupported locale
    with pytest.raises(UnsupportedLocale):
        Person('en', locale=Locale.FRANCE).full_name()

# Generated at 2022-06-12 01:27:59.361608
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'У меня есть овощи')( ) == 'U menya yest' \
                                                         ' ovoshchi'

# Generated at 2022-06-12 01:28:08.994964
# Unit test for function romanize
def test_romanize():
    import time

    startTime = time.time()

    @romanize(locale='ru')
    def test(word: str) -> str:
        """Romanize Russian text.

        :param word: Text to romanize.
        :return: Romanized text.
        """
        return word

    print(test('Строка на русском языке'))

    elapsedTime = time.time() - startTime
    print('TEST: Elapsed time: ' + str(elapsedTime))

# Generated at 2022-06-12 01:28:12.319248
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')('Яблуко') == 'Yabluko'
    assert romanize('ru')('Яблуко') == 'Yabluko'
    assert romanize('kk')('Яблуко') == 'Yabluko'

# Generated at 2022-06-12 01:28:18.160837
# Unit test for function romanize
def test_romanize():
    # TypeError
    assert str(type(romanize())) == "<class 'function'>"

    # Romanize
    @romanize()
    def test(txt):
        return txt

    try:
        @romanized('st')
        def test(txt):
            return txt
    except UnsupportedLocale:
        pass

# Generated at 2022-06-12 01:28:26.363673
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.personal import Person

    en = Person(Locale.ENGLISH)
    ru = Person(Locale.RUSSIAN)

    assert en.full_name() == 'Derek Frost'
    assert ru.full_name() == 'Артем Коваленко'

    assert en.full_name(as_ascii=True) == 'Derek Frost'
    assert ru.full_name(as_ascii=True) == 'Artem Kovalevko'

# Generated at 2022-06-12 01:29:11.342763
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text
    txt = Text(Language.RUSSIAN)
    assert txt.romanized() != txt.text()

# Generated at 2022-06-12 01:29:20.844553
# Unit test for function romanize
def test_romanize():
    def test_romanization_func(locale, result_1, result_2):
        assert romanized(locale)(lambda: result_1)() == result_2

    test_romanization_func('ru', 'Попугай', 'Popugay')
    test_romanization_func('ru', 'Привет мир!', 'Privyet mir!')
    test_romanization_func('uk', 'Росія', 'Rosiya')
    test_romanization_func('uk', 'Доброго ранку', 'Dobroho ranuku')
    test_romanization_func('kk', 'Қызыл Палас', 'Qızıl Palas')
    test_

# Generated at 2022-06-12 01:29:23.572297
# Unit test for function romanize
def test_romanize():
    def foo(x):
        return x

    data = 'Это простой текст.'

    f = romanize('ru')(foo)
    assert f(data) == 'Eto prostoj tekst.'

# Generated at 2022-06-12 01:29:26.805066
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru') is not None
    assert romanize(locale='en') is not None
    assert romanize(locale='kk') is not None
    assert romanize(locale='uk') is not None

# Generated at 2022-06-12 01:29:28.107596
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized

# Generated at 2022-06-12 01:29:29.866621
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_test_string():
        return 'тест'

    assert get_test_string() == 'test'

# Generated at 2022-06-12 01:29:39.134502
# Unit test for function romanize
def test_romanize():
    # Check for valid locales
    for locale in ['ru', 'uk', 'kk']:
        @romanize(locale)
        def valid_locales() -> str:
            return 'Строка, содержащая числа и буквы 11.02.2020'

        assert valid_locales()

    # Check for invalid locales
    @romanize('zz')
    def invalid_locale() -> str:
        return 'Строка, содержащая числа и буквы 11.02.2020'

    assert not invalid_locale()

# Generated at 2022-06-12 01:29:42.519880
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda *args, **kwargs: 'Благодаря')() == 'Blagodarya'



# Generated at 2022-06-12 01:29:43.322527
# Unit test for function romanize
def test_romanize():
    assert data.ROMANIZATION_DICT


# Generated at 2022-06-12 01:29:51.970175
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    def romanize(text):
        alphabet = {}
        alphabet.update(data.ROMANIZATION_DICT['ru'])
        alphabet.update(data.COMMON_LETTERS)

        txt = ''.join([alphabet[i] for i in text if i in alphabet])
        return txt

    p = Person('ru')
    name = p.full_name(gender=Gender.FEMALE)
    r = romanize(name)
    assert r

    name = p.full_name(gender=Gender.MALE)
    r = romanize(name)
    assert r

# Generated at 2022-06-12 01:31:35.051672
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    from mimesis import Person
    from random import randint

    p = Person(locale=locale)
    text = p.full_name()

    import re

    assert re.match(r'[А-Яа-яёЁ]', text) is not None

    romanized_text = romanize(locale=locale)(lambda x: text)()

    from mimesis.builtins import romanize as _romanize
    assert romanized_text == _romanize(text, locale=locale)

# Generated at 2022-06-12 01:31:40.987614
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.geographic import Geographic

    s = Geographic(locale='ru')

    assert s.city() == 'Владивосток'
    assert s.romanize().city() == 'Vladivostok'

    s = Geographic(locale='kk')

    assert s.city() == 'Шымкент'
    assert s.romanize().city() == 'Shymkent'

    s = Geographic(locale='uk')

    assert s.city() == 'Ірпінь'
    assert s.romanize().city() == 'Irpin'

    s = Geographic(locale=Locale.EN)

    assert s.city() == 'Tuscaloosa'
    assert s

# Generated at 2022-06-12 01:31:43.711534
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_address():
        return 'берлин'

    result = get_address()
    assert result == 'berlin'

# Generated at 2022-06-12 01:31:46.347229
# Unit test for function romanize
def test_romanize():
    import pytest
    with pytest.raises(UnsupportedLocale):
        romanize(locale='invalid_locale_code')(lambda: 'abc')

# Generated at 2022-06-12 01:31:49.583749
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет!')() == 'Privet!'
    assert romanize('uk')(lambda: 'Привіт!')() == 'Pryvit!'


# Generated at 2022-06-12 01:31:59.990127
# Unit test for function romanize
def test_romanize():
    result = romanized('ru')(lambda: 'Привет')()
    assert result == 'Privet', 'Wrong result'



# Generated at 2022-06-12 01:32:02.095267
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test():
        return 'строка для теста'

    assert test() == 'stryka dlya testa'

# Generated at 2022-06-12 01:32:12.721398
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_ru_random_text(*args, **kwargs):
        return 'Привет Мир!'

    assert get_ru_random_text() == 'Privet Mir!'

    @romanize()
    def get_uk_random_text(*args, **kwargs):
        return 'Гавайські острови'

    assert get_uk_random_text() == 'Havayski ostrovy'

    @romanize()
    def get_kk_random_text(*args, **kwargs):
        return 'Бұл кітап қазақ тілінде'


# Generated at 2022-06-12 01:32:15.036701
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_txt():
        return "Ой, что это?!"

    assert get_txt() == "Oi, chto eto?!"

# Generated at 2022-06-12 01:32:18.254859
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize(locale='ru')
    assert romanize(locale='uk')