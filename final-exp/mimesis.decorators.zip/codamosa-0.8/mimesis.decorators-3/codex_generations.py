

# Generated at 2022-06-12 01:24:55.392940
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Это русский текст')() == \
        'Eto russkiy tekst'



# Generated at 2022-06-12 01:25:05.425033
# Unit test for function romanize
def test_romanize():
    """
    Тест для преобразования кириллицы в латиницу.
    """
    assert romanize()(lambda x: 'Привет') == 'Privet'
    assert romanize()(lambda x: 'Как дела?') == 'Kak dela?'
    assert romanize('uk')(lambda x: 'Привіт') == 'Pryvit'
    assert romanize('kk')(lambda x: 'Сәлем') == 'Sälem'

# Generated at 2022-06-12 01:25:09.128531
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider as RSP

    assert RSP().last_name() == 'Хабибулин'
    assert RSP().romanize().last_name() == 'Khabyulin'


test_romanize()

# Generated at 2022-06-12 01:25:10.570845
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 01:25:19.943614
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'

    assert romanize(locale='uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'

    assert romanize(locale='kk')(lambda: 'Сау́ле сәлем!')() == 'Saule salem!'

    assert romanize(locale='unknown')(lambda: 'Привет, мир!')() == ''

# Generated at 2022-06-12 01:25:23.542164
# Unit test for function romanize
def test_romanize():
    # Test for romanized function
    from mimesis import Person
    from mimesis.enums import Gender

    p = Person('ru')
    assert p.full_name(gender=Gender.MALE) == p.romanized().full_name(gender=Gender.MALE)
    assert p.full_name(gender=Gender.MALE,
                       middle_initials=True) == p.romanized().full_name(gender=Gender.MALE, middle_initials=True)



# Generated at 2022-06-12 01:25:24.219515
# Unit test for function romanize
def test_romanize():
    assert len(__all__) == 1

# Generated at 2022-06-12 01:25:32.893061
# Unit test for function romanize
def test_romanize():
    """Test the correctness of the transliteration."""
    from mimesis.enums import Language
    from mimesis.builtins import RussianSpecProvider

    txt = 'Дарова Стасик, как дела?!'
    romanized_txt = romanize()(txt)

    assert romanized_txt == 'Darova Stasik, kak dela?!'

    provider = RussianSpecProvider(Language.RU)
    romanized_txt = provider.romanize(txt)

    assert romanized_txt == 'Darova Stasik, kak dela?!'

# Generated at 2022-06-12 01:25:36.910003
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_str(lang='ru'):
        return 'Привет'

    assert test_str(lang='ru') == 'Privet'

# Generated at 2022-06-12 01:25:44.813897
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.person import Person
    from mimesis.typing import Seed

    person = Person(seed=Seed.create(), locale='ru')
    upper_name = person.full_name()
    lower_name = person.full_name(lowercase=True)
    assert 'б' in lower_name
    assert 'б' not in upper_name
    upper_name = romanize(locale='ru')(lambda: upper_name)()
    lower_name = romanize(locale='ru')(lambda: lower_name)()
    assert 'b' in upper_name
    assert 'b' in lower_name

# Generated at 2022-06-12 01:26:01.035199
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    @romanize(locale=Locale.RUSSIA)
    def rus():
        address = Address(Locale.RUSSIA)
        return address.address()

    result = rus()
    assert result is not None

# Generated at 2022-06-12 01:26:06.071993
# Unit test for function romanize
def test_romanize():
    func = romanize('ru')(lambda x: x)
    romanized_func = romanized('ru')(lambda x: x)

    assert func('Кириллица') == 'Kirillitsa'
    assert romanized_func('Кириллица') == 'Kirillitsa'

# Generated at 2022-06-12 01:26:09.119147
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.schema import Field

    f = Field(Locale.RUSSIAN)
    assert f.text(romanize=True)



# Generated at 2022-06-12 01:26:13.404529
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize('ru')('Привет') == 'Privet'
    assert romanize('uk')('Привіт') == 'Pryvit'



# Generated at 2022-06-12 01:26:21.780777
# Unit test for function romanize
def test_romanize():
    from .. import Datetime, Personal, Person, Address, Crypto

    locales = [
        'ru',
        'uk',
        'kk',
    ]

    for locale in locales:
        dt = Datetime(locale)
        p = Personal(locale)
        person = Person(locale)
        address = Address(locale)
        crypto = Crypto(locale)

        assert romanize(locale)(dt)('utcnow') != dt('utcnow')
        assert romanize(locale)(p)('username') != p('username')
        assert romanize(locale)(person)('surname') != person('surname')
        assert romanize(locale)(address)('city') != address('city')

# Generated at 2022-06-12 01:26:22.781845
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')



# Generated at 2022-06-12 01:26:24.889892
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир')() == 'Privet mir'


# Generated at 2022-06-12 01:26:33.665123
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import Person as P
    p = P('ru')

    # Ru
    assert p.romanize() == p.romanize(locale='ru')
    assert p.romanize() == p.romanized()

    # Uk
    assert p.romanize(locale='uk') == p.romanize_uk()
    assert p.romanize(locale='uk') == p.romanized_uk()

    # Kk
    assert p.romanize(locale='kk') == p.romanize_kk()
    assert p.romanize(locale='kk') == p.romanized_kk()

    # Bad locale
    try:
        p.romanize(locale='bad_locale')
    except UnsupportedLocale:
        assert True
   

# Generated at 2022-06-12 01:26:38.446673
# Unit test for function romanize
def test_romanize():
    @romanize()
    def text(length: int = 10, **kwargs):
        alphabet = data.ROMANIZATION_DICT['ru'].keys()
        return ''.join([choice(alphabet) for _ in range(length)])
    assert text(10) == '  '

# Generated at 2022-06-12 01:26:44.179104
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def romanizer(source: str) -> str:
        return source

    text = romanizer('Привет, мир!')
    assert text == 'Privet, mir!'

    @romanized(locale='ru')
    def romanizer(source: str) -> str:
        return source

    text = romanizer('Привет, мир!')
    assert text == 'Privet, mir!'

# Generated at 2022-06-12 01:26:55.326647
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: "Привет") == "Privet"

# Generated at 2022-06-12 01:26:59.622133
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    assert RussiaSpecProvider.get_full_name() == 'Алексей Буров'

    # Test with romanize
    str = RussiaSpecProvider.get_full_name(romanize=True)
    assert str == 'Aleksej Burov'

    # Test with romanized decorator
    @romanized()
    def russian_name():
        return RussiaSpecProvider().get_full_name()

    assert russian_name() == 'Aleksej Burov'

# Generated at 2022-06-12 01:27:03.087215
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus_dec(self):
        return 'Привет, Мир!'

    assert rus_dec('') == 'Privyet, Mir!'

# Generated at 2022-06-12 01:27:12.714035
# Unit test for function romanize
def test_romanize():
    import random
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    seed = Seed.create_seed()
    russian = RussiaSpecProvider(seed=seed)
    name = russian.full_name(gender=Gender.MALE)

    assert name == romanize(locale='ru')(russian.full_name)(gender=Gender.MALE)

    # Work around 3.2
    assert name == russian.full_name(gender=Gender.MALE)
    # Work around 3.4
    assert name == russian.full_name(gender=Gender.MALE)

# Generated at 2022-06-12 01:27:15.656655
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize(locale='ru')
    assert romanize(locale='ua')
    assert romanize(locale='kk')

# Generated at 2022-06-12 01:27:22.640182
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир!')() == 'Privet mir!'
    assert romanize('uk')(lambda: 'Вітаю мир!')() == 'Vitayu myr!'
    assert romanize('kk')(lambda: 'Сәлем дүние!')() == 'Sälem dünie!'

# Generated at 2022-06-12 01:27:24.990491
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    assert romanize('ru')(str)('Россия') == 'Rossiya'

# Generated at 2022-06-12 01:27:25.942381
# Unit test for function romanize
def test_romanize():
    # TODO: Rewrite test
    pass

# Generated at 2022-06-12 01:27:27.886973
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Нет')() == 'Net'



# Generated at 2022-06-12 01:27:28.909122
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')

# Generated at 2022-06-12 01:27:49.818649
# Unit test for function romanize
def test_romanize():
    """Tests for romanize()"""
    from mimesis.enums import Gender

    text = 'Привет, мир!'
    assert text.isalpha() is True
    tmp = text.split()

    assert 'Привет,' in tmp
    assert 'мир!' in tmp

    @romanize()
    def romanized_text_gen(*args, **kwargs):
        return tmp

    texts = romanized_text_gen()
    assert 'Privet,' in texts
    assert 'mir!' in texts

    @romanize('ru')
    def romanized_text_gen_2(*args, **kwargs):
        return tmp

    new_texts = romanized_text_gen_2()
    assert 'Privet,' in new_texts

# Generated at 2022-06-12 01:27:51.883705
# Unit test for function romanize
def test_romanize():
    from mimesis import Generic
    gen = Generic('ru')
    assert gen.code.vat_id() == '7811071735'

# Generated at 2022-06-12 01:27:57.766672
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_name():
        return 'Фёдор'

    assert get_name() == 'Fyodor'

    @romanize('uk')
    def get_name():
        return 'Фёдор'

    assert get_name() == 'Fyodor'

    @romanize('kk')
    def get_name():
        return 'Фёдор'

    assert get_name() == 'Fyodor'



# Generated at 2022-06-12 01:28:06.039678
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'string')() == 'string'
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('ru')(lambda: 'привет мир')() == 'privet mir'
    assert romanize('ru')(lambda: 'юрий')() == 'yuriy'
    assert romanized('ru')(lambda: 'привет')() == 'privet'

# Generated at 2022-06-12 01:28:09.367558
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    p = Person(Locale.ENGLISH)
    assert p.romanize() is not None

# Generated at 2022-06-12 01:28:13.026749
# Unit test for function romanize

# Generated at 2022-06-12 01:28:24.721091
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda : 'test1')(locale='en') == 'test1'
    assert romanize(locale='ru')(lambda : 'привет, как дела?')() == 'privet, kak dela?'
    assert romanized(locale='uk')(lambda : 'привіт, як справи?')() == 'pryvit, yak spravy?'
    assert romanize(locale='kk')(lambda : 'Сәлем, күнің тиіс болды')() == 'Sälem, küniñ tïs boldy'

# Generated at 2022-06-12 01:28:27.090978
# Unit test for function romanize
def test_romanize():
    romanized_text = romanized('ru')(lambda: "привет мир")()
    assert romanized_text == "privet mir"

# Generated at 2022-06-12 01:28:29.992839
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def roman():
        return 'Санкт-Петербург'

    res = roman()
    assert res == 'Sankt-Peterburg'

# Generated at 2022-06-12 01:28:38.957823
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_text():
        return "Привет Мир"

    assert get_text() == 'Privet Mir'

    @romanize('uk')
    def get_text():
        return "Привіт Світ"

    assert get_text() == 'Pryvit Svit'

    @romanize('kk')
    def get_text():
        return "Сәлем Әлем"

    assert get_text() == 'Sälem Älem'

# Generated at 2022-06-12 01:29:03.307564
# Unit test for function romanize
def test_romanize():
    assert romanize('ru') == romanize_ru
    assert romanize('uk') == romanize_uk
    assert romanize('kk') == romanize_kk
    assert romanize('kk') != romanize_uk



# Generated at 2022-06-12 01:29:12.503367
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    from mimesis.schema import Field, Schema

    class PersonWithSchema(Person):
        def my_method(self):
            return "is it works"

    person = PersonWithSchema()
    pw = PersonWithSchema.__dict__
    assert person.my_method() == "is it works"
    assert pw['name'](person, 'sr') is not None

    schema = Schema(
        Field('name', provider=pw['name'], provider_args=['sr'])
    )

    test_data = schema.create()
    assert test_data == {'name': 'Лељан Стефановић'}

# Generated at 2022-06-12 01:29:14.247999
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(romanize('ru')).__name__ == 'wrapper'

# Generated at 2022-06-12 01:29:14.815906
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-12 01:29:16.928559
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda: 'Хелло, Ворлд!')() == 'Hello, World!'

# Generated at 2022-06-12 01:29:24.867852
# Unit test for function romanize

# Generated at 2022-06-12 01:29:26.694802
# Unit test for function romanize
def test_romanize():
    return romanize(locale='ru')(lambda: '')

# Generated at 2022-06-12 01:29:29.633186
# Unit test for function romanize
def test_romanize():
    # From https://github.com/lk-geimfari/mimesis/issues/306
    assert romanized('uk')(lambda: 'Сума')() == 'Sumа'

# Generated at 2022-06-12 01:29:39.521920
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'мова'.upper())() == 'MOVA'
    assert romanize('ru')(lambda: 'мои́ очки'.upper())() == 'MOI ÓčKI'
    assert romanize('ru')(lambda: 'приве́т'.upper())() == 'PRIVÉT'
    assert romanize('kk')(lambda: 'приве́т'.upper())() == 'PRIVÉT'
    assert romanize('uk')(lambda: 'козаке́вич'.upper())() == 'KOZAKÉVIČ'

# Generated at 2022-06-12 01:29:47.179860
# Unit test for function romanize
def test_romanize():
    data.ROMANIZATION_DICT['ru'] = {'Р': 'R', 'О': 'O'}
    @romanize('ru')
    def main(locale: str) -> str:
        return 'Россия'

    assert isinstance(main, Callable)
    assert main('ru') == 'Rossiya'

    try:
        @romanize('zz')
        def main(locale: str) -> str:
            return 'Россия'
        assert False
    except UnsupportedLocale:
        assert True

# Generated at 2022-06-12 01:30:40.457175
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    import random
    from mimesis import Person as P

    p = P('ru')
    assert all([isinstance(p.full_name(), str) for _ in range(0, 10)])
    assert all([isinstance(p.full_name(romanize=True), str) for _ in range(0, 10)])
    assert all([''.join(random.sample(p.full_name(), 6)) in p.full_name(romanize=True)
               for _ in range(0, 10)])
    assert all([''.join(random.sample(p.full_name(romanize=True), 6)) in p.full_name(romanize=True)
               for _ in range(0, 10)])

# Generated at 2022-06-12 01:30:49.439808
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda : 'Санкт-Петербург')() == 'Sankt-Peterburg'
    assert romanized(locale='uk')(lambda : 'Санкт-Петербург')() == 'Sankt-Peterburh'
    assert romanized(locale='kk')(lambda : 'Санкт-Петербург')() == 'Sankt-Peterburh'

# Generated at 2022-06-12 01:30:51.903979
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func():
        return 'Образец'

    assert func() == 'Obrasets'

# Generated at 2022-06-12 01:30:56.148176
# Unit test for function romanize
def test_romanize():
    # Python 3.6 above

    @romanize()
    def foo():
        """Test romanization."""
        return 'Привіт Світе!'

    assert foo() == 'Pryvit Svite!'

# Generated at 2022-06-12 01:31:06.817852
# Unit test for function romanize
def test_romanize():
    """Test function romanize.

    :return: None
    """
    from mimesis.enums import Language
    from mimesis.providers.text import Text
    from mimesis.providers.address import Address
    from mimesis.exceptions import UnsupportedLocale

    t = Text(Language.RU)
    a = Address(Language.RU)
    # t.romanize = romanize(locale=Language.RU.value)
    # a.romanize = romanize(locale=Language.RU.value)

    assert t.romanize('Привет, Мир!') == 'Privet, Mir!'
    assert a.romanize('Пермский край') == 'Permskii krai'

# Generated at 2022-06-12 01:31:15.617919
# Unit test for function romanize
def test_romanize():
    import sys, os
    sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../")
    from mimesis.enums import Locale
    import mimesis.builtins
    lang = mimesis.builtins.RussianSpecProvider(locale=Locale.RUSSIAN)

    @romanize(locale='ru')
    def name():
        return lang.full_name(gender='male')

    result = name()
    if result != 'Владимир Анатольевич Шумилов':
        print("Failed romanize function test")
        return False
    return True

# Generated at 2022-06-12 01:31:25.320109
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda x: "Привет, Мир")() == "Privet, Mir"
    assert romanize(locale='uk')(lambda x: "Вітаю, Світ")() == "Vitayu, Svit"
    assert romanize(locale='kk')(lambda x: "Сәлем, Дүние")() == "Sälem, Dünie"
    try:
        romanize(locale='ep')(lambda x: "")
    except UnsupportedLocale as e:
        assert str(e) == "Locale 'ep' is unsupported"

# Generated at 2022-06-12 01:31:28.428565
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Строка')() == 'Stroka'



# Generated at 2022-06-12 01:31:31.657810
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Я люблю тебя')() == 'Ja ljublju tebja'

# Generated at 2022-06-12 01:31:33.517611
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: None)() == ''
    assert romanize('ru')(lambda: 'Кириллица')().lowe

# Generated at 2022-06-12 01:33:19.154176
# Unit test for function romanize
def test_romanize():
    assert romanized()('Зелёный') == 'Zelënyj'

# Generated at 2022-06-12 01:33:26.879708
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'тест')() == 'test'
    assert romanize('uk')(lambda: 'тест')() == 'test'
    assert romanize('kk')(lambda: 'тест')() == 'test'

    try:
        assert romanize('unknown')(lambda: 'тест')()
    except UnsupportedLocale as err:
        assert isinstance(err, UnsupportedLocale)
        print(err)

    assert romanized('uk')(lambda: 'тест')() == 'test'

# Generated at 2022-06-12 01:33:28.257524
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert len(romanized(locale='ru')(lambda: None)()) > 0

# Generated at 2022-06-12 01:33:32.072669
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda:'Буря')() == 'Bur\'ya'
    assert romanize('uk')(lambda:'Буря')() == 'Bur\'ia'
    assert romanize('kk')(lambda:'Буря')() == 'Bẃrwá'

# Generated at 2022-06-12 01:33:33.618426
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda x: 'КУКУ')() == 'KUKU'

# Generated at 2022-06-12 01:33:37.476133
# Unit test for function romanize
def test_romanize():
    @romanize('kk')
    def return_cyr(x):
        return x

    assert isinstance(return_cyr('тест'), str)

    # Test for unsupported locale.
    with pytest.raises(UnsupportedLocale):
        @romanize('es')
        def return_cyr(x):
            return x



# Generated at 2022-06-12 01:33:40.246358
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'Иван Иванович')() == 'Ivan Ivanovich'
    assert romanized('ru')(lambda : '')() == ''
    assert romanized('ru')(lambda : 'Иван')() == 'Ivan'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:33:49.859048
# Unit test for function romanize

# Generated at 2022-06-12 01:33:52.918351
# Unit test for function romanize
def test_romanize():
    from mimesis.numbers import Numbers

    nums = Numbers('en')

    romanized = romanize('ru')(nums.random_int)
    assert romanized



# Generated at 2022-06-12 01:33:55.923845
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    from mimesis.builtins import RussiaSpecProvider

    rus = RussiaSpecProvider
    for lang in Language:
        assert (rus._romanize(rus.name(), lang) ==
                rus._romanize(rus.name(), lang.value))