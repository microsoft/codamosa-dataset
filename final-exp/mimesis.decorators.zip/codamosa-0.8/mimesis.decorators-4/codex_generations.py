

# Generated at 2022-06-12 01:24:55.658315
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize('ru')('Привет') == 'Privet'
    assert romanized('kk')('Привет') == 'Privet'
    assert romanized('uk')('Привет') == 'Pryvit'

# Generated at 2022-06-12 01:25:07.475937
# Unit test for function romanize
def test_romanize():
    # Locale doesn't exist
    with raises(UnsupportedLocale):
        @romanize('in')
        def return_cyrillic():
            return 'Привет, Мир!'

        assert return_cyrillic == 'in'

    # Locale exists
    @romanize('uk')
    def return_cyrillic(name):
        return 'Привет, {}!'.format(name)

    assert return_cyrillic('Юзер') == 'Pryvit, Yuzyer!'
    assert return_cyrillic('Портал') == 'Pryvit, Portal!'


# Generated at 2022-06-12 01:25:15.433959
# Unit test for function romanize
def test_romanize():
    def func(txt='Hi'):
        return txt

    assert romanize('ru')(func)('Привет') == 'Privet'
    assert romanize('uk')(func)('Привіт') == 'Pryvit'
    assert romanize('kk')(func)('Hi') == 'Hi'
    assert romanize('kk')(func)('Привет') == 'Privet'



# Generated at 2022-06-12 01:25:20.652977
# Unit test for function romanize
def test_romanize():
    from mimesis.data import special_chars

    def romanizable_func(text: str = '') -> str:
        return text

    romanizable = romanize('ru')(romanizable_func)

    for i, char in enumerate(special_chars[:5]):
        result = romanizable(char)
        assert result.isalpha()
        assert len(result) == 1



# Generated at 2022-06-12 01:25:31.953958
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'тест')() == 'test'
    assert romanize('ru')(lambda: 'тест')() == romanized('ru')(lambda: 'тест')()
    assert romanize('ru')(lambda: '123')() == '123'
    assert romanize('ru')(lambda: '1,234')() == '1,234'
    assert romanize('ru')(lambda: '1.234')() == '1.234'
    assert romanize('ru')(lambda: 'т')().islower()
    assert romanize('ru')(lambda: 'Т')().islower()
    assert romanize('ru')(lambda: 'ТЕСТ')().islower()
    assert roman

# Generated at 2022-06-12 01:25:37.114434
# Unit test for function romanize
def test_romanize():
    import pprint
    from mimesis.builtins import Crypto

    class Bar:

        def __init__(self):
            self._crypto = Crypto()

        def foo(self, locale='en'):
            return self._crypto.token()

    @romanize('ru')
    def bar():
        return 'Привет, мир!'

    pprint.pprint(bar())

    bar_object = Bar()
    pprint.pprint(bar_object.foo(locale='ru'))

# Generated at 2022-06-12 01:25:46.212339
# Unit test for function romanize
def test_romanize():
    """Test for romanized()."""
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.misc import Misc

    dt = Datetime(locale='ru')
    m = Misc(locale='ru')

    with open('tests/data/ru_test.txt', mode='r') as f:
        test_data = f.read()

    for line in test_data.split('\n'):
        date_time, misc = line.split(',')
        assert dt.date_time(extended=True, start=2010, end=2020) == date_time
        assert m.slug() == misc
    assert dt.date_time(extended=True, start=2010, end=2020) == '13:23:01'
    assert m.slug()

# Generated at 2022-06-12 01:25:48.983280
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Абсолютно все") == "Absoliutno vse"

# Generated at 2022-06-12 01:25:59.158366
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    rus_address = Address('ru')
    uk_address = Address('uk')
    kz_address = Address('kk')

    rus_person = Person('ru')
    uk_person = Person('uk')
    kz_person = Person('kk')

    assert rus_address.city() != uk_address.city() != kz_address.city()
    assert rus_person.full_name() != \
        uk_person.full_name() != kz_person.full_name()

    rus_address_romanized = Address('ru', romanize='ru')

# Generated at 2022-06-12 01:26:05.268355
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize('kk')(lambda: "Жарық")() == "Zharık"
    assert romanize('ru')(lambda: "Привет")() == "Privet"
    assert romanize('uk')(lambda: "Привіт")() == "Pryvit"

# Generated at 2022-06-12 01:26:13.924727
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    person = Person(Locale.ENGLISH)
    s = person.full_name()

    assert romanize(s) == s

# Generated at 2022-06-12 01:26:19.050119
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanized('kk')(lambda: 'Hello!')() == 'Hello!'
    assert romanized('ru')(lambda: 'Hello!')() == 'Hello!'
    assert romanized('uk')(lambda: 'Hello!')() == 'Hello!'
    assert romanized('zz')(lambda: 'Hello!')() == 'Hello!'

# Generated at 2022-06-12 01:26:29.629226
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.enums import Language

    @romanize(locale=Language.BASHKIR)
    def test_romanize_local_bashkir(self):
        return 'Улы куны апарып студенттер гимназияның һәлакаты торып алды.'


# Generated at 2022-06-12 01:26:41.330107
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_text(seed: int = None):
        """Return a romanized text."""
        generator = data.DataGenerator(seed)
        return generator.text.cyrillic()

# Generated at 2022-06-12 01:26:43.089637
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "Привет")() == 'Privet'

# Generated at 2022-06-12 01:26:50.407193
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo(x):
        return x

    assert foo("Пожалуйста спасибо до свидания, обмене! Щелкните на кнопку.") == \
           "Požalujsta spasibo do svidanija, obmene! Ščelknete na knopku."

# Generated at 2022-06-12 01:26:56.219877
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет Мир!')() == 'Privet Mir!'
    assert romanize(locale='uk')(lambda: 'Привіт Світ!')() == 'Pryvit Svit!'
    assert romanize(locale='kk')(lambda: 'Сәлем Дүние!')() == 'S’alem Dünie!'
    #assert romanize(locale='kz')(lambda: 'Сәлем Дүние!')() == 'S’alem Dünie!'

# Generated at 2022-06-12 01:26:59.443547
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-12 01:27:01.552893
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_romanized_string():
        return 'Господин Пирожков'

    assert get_romanized_string() == 'Gospodin Pirozhkov'

# Generated at 2022-06-12 01:27:13.216813
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text as mimesis_t
    import mimesis.builtins.geo as mimesis_g
    import mimesis.builtins.dates as mimesis_d
    import mimesis.builtins.numbers as mimesis_n
    import mimesis.builtins.address as mimesis_a
    import mimesis.builtins.genders as mimesis_genders
    import mimesis.builtins.person as mimesis_person
    import mimesis.builtins.file as mimesis_files
    import mimesis.builtins.mac as mimesis_mac
    import mimesis.builtins.person as mimesis_person
    import mimesis.builtins.other as mimesis_other


# Generated at 2022-06-12 01:27:24.269025
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Вы можете вернуться'
                          ' к началу этой страницы') == \
        'Vy mozhete vernutsya k nachalu etoy stranicy'

# Generated at 2022-06-12 01:27:30.264441
# Unit test for function romanize
def test_romanize():
    """Test cases for romanize."""
    from mimesis.data import CODES
    from mimesis.builtins.locales import English, Spanish, Ukrainian

    for code in CODES:
        localizer = English(code)
        assert localizer.romanize_language() == 'english'

        localizer = Spanish(code)
        assert localizer.romanize_language() == 'spanish'

        localizer = Ukrainian(code)
        assert localizer.romanize_language() == 'ukrainian'

# Generated at 2022-06-12 01:27:38.772441
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize()(lambda: '')() == ''
    assert romanize()(lambda: 'а')() == 'a'
    assert romanize()(lambda: 'абв')() == 'abv'
    assert romanize(locale='ru')(lambda: 'абв')() == 'abv'
    assert romanize(locale='ru')(lambda: 'АБВ')() == 'ABV'
    assert romanize(locale='ru')(lambda: 'абвгде')() == 'abvgde'
    assert romanize(locale='ru')(lambda: 'Я')() == 'Äá'

# Generated at 2022-06-12 01:27:44.935224
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    assert romanized(locale='ru')(lambda x: 'Абвгд')() == 'AbvgD'
    assert romanized(locale='uk')(lambda x: 'Абвгд')() == 'AbvgD'
    assert romanized(locale='kk')(lambda x: 'Абвгд')() == 'Abvd'

# Generated at 2022-06-12 01:27:48.670009
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    from mimesis.builtins import RussiaSpecProvider

    @romanize()
    def rus(locale=''):
        return RussiaSpecProvider(locale).province()

    assert rus() != RussiaSpecProvider().province()

# Generated at 2022-06-12 01:27:56.524779
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender

    class TestRu:

        from mimesis.builtins import RussiaSpecProvider as Ru

        ru = Ru('ru')

        @romanize('ru')
        def test_romanized(self) -> str:
            return self.ru.full_name(gender=Gender.FEMALE)

    class TestKk:

        from mimesis.builtins import KazakhstanSpecProvider as Kk

        kk = Kk('kk')

        @romanize('kk')
        def test_romanized(self) -> str:
            return self.kk.full_name(gender=Gender.MALE)

    class TestUk:

        from mimesis.builtins import UkraineSpecProvider as Uk

        uk = Uk('uk')


# Generated at 2022-06-12 01:28:05.913220
# Unit test for function romanize
def test_romanize():
    assert romanized('kk')(lambda: 'Сәлем ертәке әлемде келегез')() \
        == 'Salem ertek alenda kelegez'
    assert romanized('ru')(lambda: 'Привет, мир!')() \
        == 'Privet, mir!'
    assert romanized('uk')(lambda: 'Привіт, світ!')() \
        == 'Pryvit, svit!'

# Generated at 2022-06-12 01:28:07.964705
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет, мир!') == 'Privet, mir!'

# Generated at 2022-06-12 01:28:09.366881
# Unit test for function romanize
def test_romanize():
    assert romanize()('ресурс') == 'resurs'

# Generated at 2022-06-12 01:28:10.235370
# Unit test for function romanize
def test_romanize():
    assert 'Привет мир' == romanized(lambda: 'Привет мир')()



# Generated at 2022-06-12 01:28:30.101966
# Unit test for function romanize
def test_romanize():
  from mimesis.builtins.numbers import Number
  from mimesis.enums import RomanizationMode
  n = Number(RomanizationMode.TRANSCRIPTION)
  assert isinstance(n._romanize('Привет'), str)
  assert isinstance(n._romanize(1234), str)
  assert n._romanize('Привет') == 'privet'
  assert not isinstance(n._romanize('Привет'), bytes)
  assert n._romanize('Как дела?') == 'kak dela?'
  assert n._romanize('как дела?') == 'kak dela?'
  assert n._romanize('погода') == 'pogoda'
  assert n

# Generated at 2022-06-12 01:28:34.102191
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Сегодня сильный мороз'


    assert foo() == 'Segodnya silʹnyĭ moroz'

# Generated at 2022-06-12 01:28:37.949424
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus():
        return 'Привет, мир!'

    assert rus() == 'Privet, mir!'

# Generated at 2022-06-12 01:28:43.668311
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize"""
    import pytest
    from mimesis.builtins.numbers import Numbers

    n = Numbers()

    @n.romanize('ru')
    def test_romanize_ru():
        return "привет"

    assert test_romanize_ru() == "privet"

    @n.romanize('uk')
    def test_romanize_uk():
        return "привіт"

    assert test_romanize_uk() == "pryvit"

    with pytest.raises(UnsupportedLocale) as exception:
        @n.romanize('xxx')
        def test_romanize_with_exception():
            return "привет"


# Generated at 2022-06-12 01:28:47.069298
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Привет") == "Privet"
    assert romanize("uk")("Привіт") == "Pryvit"

# Generated at 2022-06-12 01:28:52.135711
# Unit test for function romanize
def test_romanize():
    assert romanize('wrong_locale')(lambda: 'мама')() == 'мама'
    assert romanize('ru')(lambda: 'мама')() == 'mama'
    assert romanize('uk')(lambda: 'мама')() == 'mama'
    assert romanize('kk')(lambda: 'мама')() == 'mama'

# Generated at 2022-06-12 01:28:56.571078
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import (
        UkrainianSpecProvider as uk,
        RussianSpecProvider as ru,
    )

    usr = uk()
    rsr = ru()
    h = usr.hash()
    assert isinstance(h, str)
    h = rsr.hash()
    assert isinstance(h, str)


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:29:06.505896
# Unit test for function romanize
def test_romanize():
    text_ru = 'День проведен'
    text_uk = 'Електроенергія та природні ресурси'
    text_kk = 'Өнімнің анықталуы жөнінде ережелер бойынша дәлелдік қалыптастырмалар'

    assert romanize('ru')(lambda: text_ru) == "Den' proveden"

# Generated at 2022-06-12 01:29:14.857728
# Unit test for function romanize
def test_romanize():
    func = romanize()
    res = func(lambda *args, **kwargs: 'Сегодня в магазин зашли!')(
        *(), **{})
    assert res == 'Segodnya v  magazin zashli!'
    func = romanize(locale='uk')
    rez = func(lambda *args, **kwargs: 'Сіла воздуху не багато з 6 до 10')
    assert rez(**{}) == 'Sila vazduhu ne bagato z 6 do 10'

# Generated at 2022-06-12 01:29:16.631624
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize()
    assert romanized

# Generated at 2022-06-12 01:29:43.867579
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    roman = romanize(locale=Locale.RUSSIAN.value)(lambda: 'Борис Николаевич')
    assert roman() == 'Boris Nikolaevich'

# Generated at 2022-06-12 01:29:47.073016
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda x: 'Привет мир привет, мир!')()
    assert result == 'Privet mir privet, mir!'



# Generated at 2022-06-12 01:29:58.977963
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Привет, мир')('') == 'Privet, mir'
    assert romanize('uk')('Привіт, світ')('') == 'Privit, svit'
    assert romanize('kk')('сәлем, дүние')('') == 'şälemdünie'
    assert romanize('')('Не надо')('ru') == 'Ne nado'
    assert romanize('')('Не надо')('uk') == 'Ne nado'
    assert romanize('')('Не надо')('kk') == 'Nä nado'

# Generated at 2022-06-12 01:30:10.965235
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    _russian = romanize('ru')
    _ukrainian = romanize('uk')
    _kazakh = romanize('kk')

    @_russian
    def dostoevsky():
        return 'Фёдор Миха́йлович Достоевский'

    @_ukrainian
    def kotsiubynsky():
        return 'Микита Коцюбинський'

    @_kazakh
    def abai():
        return 'Құнайғүл Әбай Ғиз'

    assert d

# Generated at 2022-06-12 01:30:16.986192
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    @romanize(locale='ru')
    def russian():
        return 'Съешь ещё этих мягких французских булок.'

    assert russian() == 'Syesh eshche etikh myagkikh frantsuzskikh bulok.'



# Generated at 2022-06-12 01:30:28.340995
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Тест')() == 'Test'
    assert romanize('uk')(lambda: 'Тест')() == 'Test'
    assert romanize('kk')(lambda: 'Тест')() == 'Test'

    # Wrong locale
    try:
        assert romanize('en')(lambda: 'Тест')()
    except UnsupportedLocale:
        pass

    assert romanize('ru')(lambda: 'Здравствуй, серьёзный тест!')() == 'Zdravstvuy, seryoznyy test!'
    assert romanize('ru')(lambda: 'Тест!')() == 'Test!'

# Generated at 2022-06-12 01:30:36.248533
# Unit test for function romanize
def test_romanize():
    import unittest
    from mimesis.providers.person import Person

    class RomanizeTestCase(unittest.TestCase):

        def setUp(self):
            self.person = Person()

        def test_romanize(self):
            for i in range(10):
                self.assertEqual(self.person.romanize('ru'),
                                 self.person.romanized('ru'),
                                 msg=f'{"romanize" != "romanized"}')

    unittest.main(exit=False)

# Generated at 2022-06-12 01:30:39.021028
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    prov = RussiaSpecProvider()
    assert romanize(locale='ru')(prov._full_name,'ru') in prov._full_name('ru')

# Generated at 2022-06-12 01:30:50.291850
# Unit test for function romanize
def test_romanize():
    import random

    class Random:

        def __init__(self, seed=None):
            self.seed = seed

        def seed(self, seed=None):
            random.seed(seed)
            self.seed = seed

    random = Random()

    random.seed(12345)
    print(r'путь в питон • python path ${PYTHONPATH}  ножка ❤')
    print(r'путь в питон • python path ${PYTHONPATH}  ножка ❤')
    print(r'путь в питон • python path ${PYTHONPATH}  ножка ❤'.encode())

# Generated at 2022-06-12 01:30:51.513326
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()

# Generated at 2022-06-12 01:31:50.695729
# Unit test for function romanize
def test_romanize():
    assert romanize()('А роза упала на лапу Азора') == 'A roza upala na lapu Azora'

# Generated at 2022-06-12 01:31:59.989831
# Unit test for function romanize
def test_romanize():
    assert romanized()('Я тебя люблю') == 'Ya tebya liubliu'

# Generated at 2022-06-12 01:32:00.379513
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-12 01:32:01.673367
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'привет')() == "privet"

# Generated at 2022-06-12 01:32:11.457650
# Unit test for function romanize
def test_romanize():
    def some_func() -> str:
        return 'Привет мир'

    another_func = romanize()(some_func)
    assert another_func() == 'Privet mir'

    another_func = romanize('kk')(some_func)
    assert another_func() == 'Pryvet myr'

    another_func = romanize('uk')(some_func)
    assert another_func() == 'Pryvit mir'

    # Try to use unsupported locale
    try:
        another_func = romanize('it')(some_func)
    except UnsupportedLocale:
        assert True
    else:
        assert False

# Generated at 2022-06-12 01:32:15.628871
# Unit test for function romanize
def test_romanize():
    def func(a):
        return a

    func = romanize()(func)

    assert func('Съешь ещё этих мягких французских булок') == \
        'Sesh eshche etikh myagkikh frantsuzskikh bulok'

# Generated at 2022-06-12 01:32:23.757236
# Unit test for function romanize
def test_romanize():
    def test_ru(text):
        assert text == romanize('ru')(lambda: text)()

    def test_kk(text):
        assert text == romanize('kk')(lambda: text)()

    def test_uk(text):
        assert text == romanize('uk')(lambda: text)()

    test_ru('тест')
    test_uk('тест')
    test_kk('тест')

# Generated at 2022-06-12 01:32:26.730732
# Unit test for function romanize
def test_romanize():
    from mimesis.schema import Field
    from mimesis.utils import get_locale
    field = Field('personal', get_locale('ru'))
    assert isinstance(field.romanize(), str)

# Generated at 2022-06-12 01:32:27.393586
# Unit test for function romanize
def test_romanize():
    """."""



# Generated at 2022-06-12 01:32:32.403381
# Unit test for function romanize
def test_romanize():
    """Test Romanize."""

    @romanize('ru')
    def get_name():
        return 'Привет'

    assert get_name() == 'Privet'

    @romanized('ru')
    def get_name():
        return 'Привет'

    assert get_name() == 'Privet'

    @romanize('kk')
    def get_name():
        return 'Естестен басыңызды қалағанда'

    assert get_name() == 'Estephen basynyzy qalagand'

    @romanize('uk')
    def get_name():
        return 'Привіт'


# Generated at 2022-06-12 01:34:16.578640
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_function(locale):
        return 'Привет, мир!'

    assert romanize_function('ru') == 'Privet, mir!'



# Generated at 2022-06-12 01:34:19.910084
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    person = Person('ru')

    assert isinstance(person.romanized, str)
    assert person.romanized
    assert person.romanized == 'Mikhail'

# Generated at 2022-06-12 01:34:25.488937
# Unit test for function romanize
def test_romanize():
    # 'ru' -> 'ru'
    assert romanize('ru')(lambda x: ('тест', 'ва'))() == 'тества'

    # 'uf' -> 'ru'
    assert romanize('uf')(lambda x: ('тест', 'ва'))() == 'тества'

    # 'kk' -> 'kk'
    assert romanize('kk')(lambda x: ('тест', 'ва'))() == 'тества'

    # 'at' -> 'ru'
    assert romanize('at')(lambda x: ('тест', 'ва'))() == 'тества'

    # 'pb' -> 'ru'

# Generated at 2022-06-12 01:34:28.786814
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def foo():
        return 'Тестирование'

    assert foo() == 'Testirovanie'

# Generated at 2022-06-12 01:34:30.484198
# Unit test for function romanize
def test_romanize():
    def func():
        return 'ёй'

    assert romanize('ru')(func)() == 'ej'

# Generated at 2022-06-12 01:34:36.706379
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import UkraineSpecProvider

    uk = UkraineSpecProvider()

    assert uk.address.address.startswith('Kyiv') == True
    assert uk.address.code_ipn == '11223'
    assert uk.address.region.startswith('Kyivska') == True
    assert uk.address.district.startswith('Obolonsky') == True
    assert uk.address.city.startswith('Kyiv') == True
    assert uk.address.street.startswith('Bohdana') == True
    assert uk.address.building_number == '13b'
    assert uk.address.apartment_number == '250'

# Generated at 2022-06-12 01:34:40.419947
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import RussianSpecProvider

    rsp = RussianSpecProvider()

    romanized_text = rsp.full_name(gender='female')
    romanized_text = romanize('ru')(rsp.full_name)(gender='female')
    assert type(romanized_text) == str