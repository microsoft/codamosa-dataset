

# Generated at 2022-06-12 01:25:02.839261
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus():
        return 'абвгдеёж'

    assert rus() == 'abvgdeej'

    @romanize('uk')
    def ukr():
        return 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'

    assert ukr() == 'abvhdejizìklmnoprstufxćčšŝýjuja'

    @romanize('kk')
    def kaz():
        return 'ағылшын тіліндегі қазақстан'

# Generated at 2022-06-12 01:25:06.801369
# Unit test for function romanize
def test_romanize():
    @romanized(locale='ru')
    def get_romanized_text() -> str:
        return 'Привет, друг!'

    assert get_romanized_text() == 'Privet, drug!'

# Generated at 2022-06-12 01:25:07.726235
# Unit test for function romanize
def test_romanize():
    r = romanize()
    assert r

# Generated at 2022-06-12 01:25:19.393837
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian_alphabet() -> str:
        return 'Аа Бб Вв Гг Дд Ее Ёё Жж Зз Ии Йй Кк Лл Мм Нн Оо Пп Рр Сс Тт Уу Фф Хх Цц Чч Шш Щщ Ъъ Ыы Ьь Ээ Юю Яя'


# Generated at 2022-06-12 01:25:21.273394
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize function."""
    assert romanize == romanized
    assert romanize != data.COMMON_LETTERS

# Generated at 2022-06-12 01:25:22.412352
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)

# Generated at 2022-06-12 01:25:31.297213
# Unit test for function romanize
def test_romanize():
    """Tests for romanize function."""
    # No locale
    alph = {string: string for string in string.ascii_letters + string.digits + string.punctuation}
    alph.update({**data.ROMANIZATION_DICT['ru'], **data.COMMON_LETTERS})
    result = ''.join([alph[i] for i in "Пример написания кириллицей." if i in alph])
    assert result == "Primer napisaniya kirillitsey."

# Generated at 2022-06-12 01:25:34.167631
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import WordProvider

    word = WordProvider('ru')
    romanized_word_provider = WordProvider('ru')
    assert word('ru') == romanized_word_provider('ru')

# Generated at 2022-06-12 01:25:40.084118
# Unit test for function romanize
def test_romanize():
    from functools import partial

    def test_locale(locale, text):
        @romanize(locale)
        def foo():
            return text
        assert callable(foo)
        return foo()

    @romanize()
    def foo():
        return 'Международный язык'

    assert callable(foo)
    assert foo() == 'Mejdunarodnyj jazyk'

    assert test_locale('ru', 'Международный язык') == \
        'Mejdunarodnyj jazyk'

# Generated at 2022-06-12 01:25:42.090809
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет') == 'Privet'

# Generated at 2022-06-12 01:25:58.148107
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    test_dict = {
        ('ru', 'Привет мир!'): 'Privet mir!',
        ('uk', 'Привіт світ!'): 'Pryvit svit!',
        ('kk', 'Сәлем дүние!'): 'Sälem dünie!',
        ('ru', 'Привет мир!'): 'Privet mir!',
        ('en', 'Привет мир!'): 'Привет мир!',
    }

# Generated at 2022-06-12 01:26:08.939785
# Unit test for function romanize
def test_romanize():
    alphabet = 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя'
    current_letters = ascii_letters + digits + punctuation

    def get_data(locale, common_letters=True):
        alphabet_raw = {s: s for s in current_letters}

        # Update with common letters

# Generated at 2022-06-12 01:26:17.369712
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Меняйте свою жизнь, и будет впечатление, '
                                'что она меняется с вами.')() == \
        'Menyajte svoju zhizn\', i budet vpechatlenie, chto ona menyaetsya ' \
        's vami.'

# Generated at 2022-06-12 01:26:19.731413
# Unit test for function romanize
def test_romanize():
    # Using keyword arguments
    @romanize(locale='zh')
    def dummy():
        return '我爱你'

    assert dummy() == 'wǒ ài nǐ'

# Generated at 2022-06-12 01:26:24.889935
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя')() == 'abvgdegjzijklmnoprstufhcchshshyjjejuja'

# Generated at 2022-06-12 01:26:33.667295
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def _test_romanize():
        return 'Привет, Мир.'

    assert _test_romanize() == 'Privet, Mir.'

    @romanize(locale='kk')
    def _test_romanize():
        return 'Сәлем, Дүние.'

    assert _test_romanize() == 'Salem, Dunie.'

    @romanize(locale='uk')
    def _test_romanize():
        return 'Привіт, Світ.'

    assert _test_romanize() == 'Pryvit, Svit.'


# Generated at 2022-06-12 01:26:36.680840
# Unit test for function romanize
def test_romanize():
    romanize('ru')(lambda: data.CYRILLIC_LETTERS['ru'])()


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:26:39.807424
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import TextGenerator

    tg = TextGenerator('uk')
    assert tg.romanized('')



# Generated at 2022-06-12 01:26:47.082909
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.lorem import Lorem

    lru = Lorem(Language.RUSSIAN)
    assert lru.text().strip() != lru.romanized().strip()
    assert lru.romanized() == 'ne ponimayu po-russki'
    luk = Lorem(Language.UKRAINIAN)
    assert luk.text().strip() != luk.romanized().strip()
    assert luk.romanized() == 'ne rozumiu po-ukrainski'
    lkk = Lorem(Language.KAZAKH)
    assert lkk.text().strip() != lkk.romanized().strip()
    assert lkk.romanized() == 'ossan qazaqsha bilemin'

# Generated at 2022-06-12 01:26:55.511169
# Unit test for function romanize
def test_romanize():
    import random
    import string
    words = ['Hello', 'привет', 'გამარჯობა']
    caps = {'L': 'l', 'H': 'h'}

    def set_caps(letter: str, up_to: int, down_to: int) -> str:
        if up_to < down_to:
            raise ValueError('up_to must be bigger than down_to')
        num = random.randint(down_to, up_to)
        if num < random.randint(1, 100):
            return letter.upper()
        return letter


# Generated at 2022-06-12 01:27:12.623736
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    from mimesis.enums import Gender

    person = Person()
    person.seed(1234)
    assert person.full_name(gender=Gender.MALE) == 'Болдын Батмондох'

    assert person.full_name(
        gender=Gender.MALE,
        romanize=True,
    ) == 'Boldyn Batmondokh'

# Generated at 2022-06-12 01:27:24.460348
# Unit test for function romanize
def test_romanize():
  assert romanize('ru')(lambda: '')() == ''
  assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
  assert romanize('ru')(lambda: 'Привет, Мир!')().isalpha()
  assert romanize('ru')(lambda: 'Привет, Мир!')().islower()
  assert romanize('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
  assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Salem, Dunie!'
  assert roman

# Generated at 2022-06-12 01:27:27.382078
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    @romanize()
    def foo():
        return "Привет, мир!"

    assert foo() == "Privet, mir!"



# Generated at 2022-06-12 01:27:29.781349
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Авторский Код") == 'Avtorskij Kod'

# Generated at 2022-06-12 01:27:36.593280
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test(locale: str) -> str:
        return 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'

    res = test('ru')
    assert res == 'ABVGDEEJZIJKLMNOPRSTUFHCCHSCHSHYJYEEYUA'

# Generated at 2022-06-12 01:27:46.708552
# Unit test for function romanize
def test_romanize():
    """Test ``romanize``."""
    def test_func() -> str:
        return 'Привет, мир!'

    assert test_func() == 'Привет, мир!'

    @romanize('ru')
    def test_func_ru() -> str:
        return 'Привет, мир!'

    assert test_func_ru() == 'Privet, mir!'

    @romanize('uk')
    def test_func_uk() -> str:
        return 'Привіт, світ!'

    assert test_func_uk() == 'Pryvit, svit!'


# Generated at 2022-06-12 01:27:49.092809
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')
    assert romanize('be')

# Generated at 2022-06-12 01:27:53.072291
# Unit test for function romanize
def test_romanize():
    assert romanize('')(lambda: '')() == ''
    assert romanize('en')(lambda: '')() == ''
    assert romanize('ru')(lambda: '')() == ''
    assert romanize('uk')(lambda: '')() == ''
    assert romanize('kk')(lambda: '')() == ''

# Generated at 2022-06-12 01:27:53.510847
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-12 01:27:57.804614
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Word

    word = Word()

    assert word.word(locale='ru') is not word.word(locale='ru')
    assert isinstance(word.word(locale='ru'), str)
    assert isinstance(word.word(locale='uk'), str)
    assert isinstance(word.word(locale='kk'), str)

# Generated at 2022-06-12 01:28:22.580910
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func():
        return 'Это тестовое предложение'
    assert func() == 'Eto testovoe predlozhenie'

# Generated at 2022-06-12 01:28:26.442641
# Unit test for function romanize
def test_romanize():
    assert ascii_letters + digits + punctuation == romanized(locale='ru')(ascii_letters + digits + punctuation)
    assert romanized(locale='ru')('проверка') == 'proverka'

# Generated at 2022-06-12 01:28:29.499141
# Unit test for function romanize
def test_romanize():
    test_string = "Іванов Іван Іванович"
    edited_test_string = "Ivanov Ivan Ivanovich"
    assert romanize('uk')(test_string) == edited_test_string

# Generated at 2022-06-12 01:28:31.816276
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: "Привет!")() == "Privet!"

# Generated at 2022-06-12 01:28:39.070046
# Unit test for function romanize
def test_romanize():
    rus_text = "Привет, мир!"
    assert rus_text == romanized()(rus_text)

    ukr_text = "Привіт, світ!"
    assert ukr_text == romanized(locale='uk_UA')(ukr_text)

    kaz_text = "Salem, dunia!"
    assert kaz_text == romanized(locale='kk_KZ')(kaz_text)

# Generated at 2022-06-12 01:28:49.077846
# Unit test for function romanize
def test_romanize():
    print(romanize('ru')(lambda test: 'Привет, мир!')(''))
    print(romanize('uk')(lambda test: 'Привіт, світ!')(''))
    print(romanize('kk')(lambda test: 'Сәлем, дүние!')(''))
    print(romanize('es')(lambda test: 'Hola, mundo!')(''))
    try:
        print(romanize('en')(lambda test: 'Hello, world!')(''))
    except UnsupportedLocale:
        print('Unsupported locale')


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-12 01:28:53.956609
# Unit test for function romanize
def test_romanize():
    result = romanize()(lambda: 'Составьте письмо и переведите его на английский язык.')
    assert result == 'Sostav\'te pis\'mo i perevedite ego na angliyskiy yazyk.'

# Generated at 2022-06-12 01:28:57.200983
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    rsp = RussianSpecProvider()
    assert isinstance(rsp.romanize('Привет'), str)
    assert isinstance(rsp.romanize('Привет', locale='ru'), str)
    assert isinstance(rsp.romanize('Привет', locale='uk'), str)
    assert isinstance(rsp.romanize('Привет', locale='kk'), str)
    assert rsp.romanize('Привет') == rsp.romanize('Привет', locale='ru')
    assert rsp.romanize('Привет') == rsp.romanize('Привет', locale='uk')

# Generated at 2022-06-12 01:29:00.744964
# Unit test for function romanize
def test_romanize():
    romanize_text = romanize('ru')(lambda: 'Даже не знаю')

    assert isinstance(romanize_text(), str)
    assert romanize_text() == 'Dazhe ne znayu'



# Generated at 2022-06-12 01:29:01.720088
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 01:29:56.486893
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')
    assert p._romanize('Привет, Мир!').lower() == 'privet, mir!'
    assert p._romanize('Привет, Мир!', 'ru').lower() == 'privet, mir!'
    assert p._romanize('Здравствуй, Мир!', 'ru').lower() == 'zdravstvuî, mir!'
    assert p._romanize('Здвараствуй, Мир!', 'ru').lower() == 'zdvarastvuî, mir!'


# Generated at 2022-06-12 01:29:58.978729
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func():
        return 'Привет, Киев!'
    assert func() == 'Pryvit, Kyiv!'

# Generated at 2022-06-12 01:30:08.575484
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.file import File
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.terminal import Terminal

    providers = [Person, Address, File, Internet, Numbers, Terminal]

    for provider in providers:
        for locale in Locale:
            p = provider(locale=locale)
            assert isinstance(p.full_name(as_string=True), str)



# Generated at 2022-06-12 01:30:13.968557
# Unit test for function romanize
def test_romanize():
    @romanize('uk')
    def roman():
        return 'Привіт, щось таке'

    # Result will be: Pryvit, shchosʹ takye
    assert roman() == 'Pryvit, shchosʹ takye'

# Generated at 2022-06-12 01:30:15.457030
# Unit test for function romanize
def test_romanize():
    romanized('ru')(lambda: 'Привет')

# Generated at 2022-06-12 01:30:22.754137
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address
    from mimesis.providers.language import Language
    address = Address('ru')
    language = Language('ru')
    assert address.city() == 'Ростов-на-Дону'
    assert language.word() == 'пользовательский'

# Generated at 2022-06-12 01:30:27.293066
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'привет')(), 'privet'
    assert romanize(locale='uk')(lambda: 'привіт')(), 'pryvit'
    assert romanized(locale='kk')(lambda: 'Сәлем')(), 'Salem'

# Generated at 2022-06-12 01:30:37.559177
# Unit test for function romanize
def test_romanize():
    assert romanized('русский')(lambda: '')() == 'russkiy'
    assert romanized('ru')(lambda: '')() == 'russkiy'

    assert romanized('український')(lambda: '')() == 'ukrayinsʹkyy'
    assert romanized('uk')(lambda: '')() == 'ukrayinsʹkyy'

    assert romanized('қазақша')(lambda: '')() == 'qazaqşa'
    assert romanized('kk')(lambda: '')() == 'qazaqşa'

# Generated at 2022-06-12 01:30:44.459086
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    p = Person(Locale.ENGLISH)
    name = p.full_name
    assert name == 'Donald W. Smith'

    p = Person(Locale.RUSSIAN)
    name = p.full_name
    assert name == 'Дэниел Верниевич Карамышев'

# Generated at 2022-06-12 01:30:54.481645
# Unit test for function romanize
def test_romanize():
    # test function
    assert romanize(locale='ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize(locale='uk')(lambda: 'Привіт, Світе!')(
    ) == 'Pryvit, Svyte!'
    assert romanize(locale='kk')(lambda: 'Сәлем, Дүние!')() == 'Salem, Dunie!'

    # test decorator
    @romanize(locale='ru')
    def say_hello():
        return 'Привет, Мир!'

    assert say_hello() == 'Privet, Mir!'


# Generated at 2022-06-12 01:32:51.113687
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanized_string(pattern: str = 'a') -> str:
        """Romanize the string."""
        return pattern

    res = romanized_string('привет')
    assert res == 'privet'



# Generated at 2022-06-12 01:33:01.463808
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Шла Саша по шоссе')() == 'Shla Sasha po shosse'
    assert romanized(locale='uk')(lambda: 'Шла Саша по шоссе')() == 'Shla Sasha po shosse'
    assert romanized(locale='kk')(lambda: 'Шла Саша по шоссе')() == 'Shla Sasha po shosse'

# Generated at 2022-06-12 01:33:12.845610
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.enums import Locale
    from mimesis.providers.text import Text
    from mimesis.builtins import RussiaSpecProvider

    provider = Text(RussiaSpecProvider())
    text_test = ['На русском языке', 'Это тест', 'Я могу писать', 
                 'Я могу еще писать', 'Я не могу писать латиницей']


# Generated at 2022-06-12 01:33:16.235940
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    @romanized('ru')
    def test(text: str = '') -> str:
        """Romanize test."""
        return text

    assert test('Привет, Мир!') == 'Privet, Mir!'
    assert test('Привет, Мир!', locale='kk') == 'Privet, Mir!'

# Generated at 2022-06-12 01:33:21.222465
# Unit test for function romanize
def test_romanize():
    def romanized(locale: str = ''):
        def decorator(func):
            return romanize(locale)(func)

        return decorator

    @romanized(locale='ru')
    def test():
        return 'Кот напал на собаку'

    result = test()
    assert result == 'Kot napal na sobaku'

# Generated at 2022-06-12 01:33:24.089136
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')
    assert romanized('kk')
    assert romanized('ru')
    assert romanized('uk')
    assert romanize('en')

# Generated at 2022-06-12 01:33:25.215609
# Unit test for function romanize
def test_romanize():
    assert 'ka4' == romanize('ru')(str)('ка4')

# Generated at 2022-06-12 01:33:31.181134
# Unit test for function romanize
def test_romanize():
    # test with unsupported locale
    try:
        @romanize('en')
        def test():
            return "Привет!"
        test()
    except:
        pass
    else:
        assert False

    # test with supported locale "ru"
    @romanize('ru')
    def test():
        return "Привет!"
    assert test() == "Privet!"

    # test with supported locale "uk"
    @romanize('uk')
    def test():
        return "Привіт!"
    assert test() == "Pryvit!"

    # test with supported locale "kk"
    @romanize('kk')
    def test():
        return "Сәлем!"
    assert test() == "Salem!"

# Generated at 2022-06-12 01:33:34.245971
# Unit test for function romanize
def test_romanize():
    @romanize
    def romanize_func(locale, data_provider):
        return data_provider.text(ext_word_list=data.WORD_LIST[locale])

    result = romanize_func('ru')
    assert result



# Generated at 2022-06-12 01:33:35.649062
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Иванов')() == 'Ivanov'

