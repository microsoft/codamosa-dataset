

# Generated at 2022-06-12 01:25:04.373803
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    locale_ru = Locale.RUSSIAN
    locale_uk = Locale.UKRAINIAN
    locale_kk = Locale.KAZAKH

    @romanized(locale_ru)
    def rus(locale):
        return data.CYRILLIC_SCRIPT[locale]

    @romanized(locale_uk)
    def ukr(locale):
        return data.CYRILLIC_SCRIPT[locale]

    @romanized(locale_kk)
    def kaz(locale):
        return data.CYRILLIC_SCRIPT[locale]

    # I don't know if is that good method of testing it
    # But I think it will be better than nothing
    assert rus(locale_ru)

# Generated at 2022-06-12 01:25:10.800893
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')().startswith('Privet')
    assert romanize(locale='uk')(lambda: 'Привіт')().startswith('Pryvit')
    assert romanize(locale='kk')(lambda: 'Сәлем')().startswith('Sälem')

# Generated at 2022-06-12 01:25:13.242372
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda: 'тест')()
    assert result == 'test'



# Generated at 2022-06-12 01:25:24.317890
# Unit test for function romanize
def test_romanize():
    test_string = "Привет Мир"
    test_string2 = "Hello World"
    test_string3 = "Test"
    romanized_string = romanize("ru")(lambda: test_string)
    romanized_string2 = romanize("ru")(lambda: test_string2)
    romanized_string3 = romanize("ru")(lambda: test_string3)
    if romanized_string != "Privet Mir":
        raise Exception("Romanization of the russian text doesn't work")
    if romanized_string2 != "Hello World":
        raise Exception("Incorrect romanization of the English text")
    if romanized_string3 != "Test":
        raise Exception("Romanization doesn't skip English text")

# Generated at 2022-06-12 01:25:30.334221
# Unit test for function romanize
def test_romanize():
    txt = 'П л а н е т а т а к о н е с п о с о б н а'
    romanized_txt = 'P l a n e t a t a k o n e s p o s o b n a'

    assert romanize('ru')(txt) == romanized_txt



# Generated at 2022-06-12 01:25:33.131754
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    from mimesis.builtins import UkraineSpecProvider

    langs = UkraineSpecProvider
    ukr = langs()

    assert ukr.romanized.first_name()

# Generated at 2022-06-12 01:25:38.141388
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    p = Person('ru')
    assert p.full_name(romanize=True) not in p.full_name(romanize=False)
    assert p.full_name(romanize='ru') not in p.full_name(romanize='uk')

# Generated at 2022-06-12 01:25:46.688157
# Unit test for function romanize
def test_romanize():
    # Russian
    assert romanize()('Привет, мир!') == 'Privet, mir!'
    assert romanize()('Привет, мир!') == 'Privet, mir!'
    assert romanize('ru')('Привет, мир!') == 'Privet, mir!'
    assert romanize('ru')('Привет, мир!') == 'Privet, mir!'
    assert romanize('ru')('Привет, мир!').lower() == 'privet, mir!'

    # Ukrainian

# Generated at 2022-06-12 01:25:50.301718
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Мимесис')() == 'Mimesis'
    assert romanized('ru')(lambda: 'Мимесис')(locale='ru') == 'Mimesis'

# Generated at 2022-06-12 01:25:59.844696
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')('test')(locale='ru') == 'test'
    assert romanize(locale='ru')('Привет')(locale='ru') == 'Privet'
    assert romanize(locale='ru')('Привет')(locale='ru') == 'Privet'
    assert romanize(locale='ru')('Привет')(locale='ru') == 'Privet'
    assert romanize(locale='ua')('Привет')(locale='ua') == 'Pryvit'
    assert romanize(locale='kk')('Привет')(locale='kk') == 'Pryvet'


# Generated at 2022-06-12 01:26:06.655730
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Россия')() == 'Rossiya'

# Generated at 2022-06-12 01:26:18.040262
# Unit test for function romanize
def test_romanize():
    class C(object):
        def __init__(self):
            self.locale = 'ru'

        @romanize(locale='uk')
        def romanize_method(self, string):
            return string

    class D(object):
        @romanize('ru')
        def romanize_method(self, string):
            return string

    class E(object):
        @romanize
        def romanize_method(self, string):
            return string

    c = C()
    d = D()
    e = E()

    result_c = c.romanize_method('Рідна хата, містечко мого дитинства')

# Generated at 2022-06-12 01:26:29.104372
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    assert romanize()(Text().cyr_alphabet) == 'абвгдежзийклмнопрстуфхцшщъыьэюя'
    assert romanize()(Address('ru').full_address) == 'г. Москва, ул. ' \
                                                     'Новослободская, ' \
                                                     'р-н Красносельский, ' \
                

# Generated at 2022-06-12 01:26:30.753774
# Unit test for function romanize
def test_romanize():
    assert romanize()('Тест') == 'Test'
    assert romanize('kk')('Тест') == 'Test'

# Generated at 2022-06-12 01:26:33.117951
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'абвгдежзийклмнопрстуфхцчшщъыьэю')(
    ) == 'abvgdezhzijklmnoprstufhzshshhijieiei'

# Generated at 2022-06-12 01:26:37.072103
# Unit test for function romanize
def test_romanize():
    txt = 'Всем привет, Ребята!'

    @romanize()
    def f():
        return txt

    assert f() == 'Vsem privet, Rebjata!'

# Generated at 2022-06-12 01:26:40.513322
# Unit test for function romanize
def test_romanize():
    txt = romanize('ru')(lambda: 'Стоп! Странные дела')
    assert(txt == 'Stop! Strannie dela')

# Generated at 2022-06-12 01:26:47.945258
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    russian = RussiaSpecProvider()
    for _ in range(10):
        r = russian.person(gender=Gender.FEMALE)
        assert isinstance(r, str)

    russian = RussiaSpecProvider(locale='uk')
    for _ in range(10):
        r = russian.person(gender=Gender.FEMALE)
        assert isinstance(r, str)

# Generated at 2022-06-12 01:26:56.069275
# Unit test for function romanize
def test_romanize():
    def test_text(locale: str = 'ru') -> Callable:
        @romanize(locale=locale)
        def inner_func(text):
            return text

        return inner_func

    t = test_text(locale='ru')
    assert t('съешь ещё этих мягких французских булок, да выпей же чаю') == 'sysh eshyo ehtikh miagkikh frantsuzskikh bulok, da vypey zhe chayu'

    t = test_text(locale='uk')

# Generated at 2022-06-12 01:27:02.475841
# Unit test for function romanize
def test_romanize():
    """Test romanize() function."""
    # Create class with romanize decorator
    @romanized('ru')
    def ru_name(self):
        return 'Иванов Иван Иванович'

    # Create class with romanize decorator
    @romanized('uk')
    def uk_name(self):
        return 'Іванов Іван Іванович'

    # Create class with romanize decorator
    @romanized('kk')
    def kk_name(self):
        return 'Иванов Иван Иванович'

    # Print decorated class
    assert ru_name() == 'Ivanov Ivan Ivanovich'

# Generated at 2022-06-12 01:27:10.435777
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')('привет') == romanized('привет', locale='ru')

# Generated at 2022-06-12 01:27:19.554919
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda *args, **kwargs: 'всем привет')(), 'vsem privet'
    assert romanized()(lambda *args, **kwargs: 'всем привет')(), 'vsem privet'
    assert romanized('uk')(lambda *args, **kwargs: 'добрий день')(), 'dobryj den'
    assert romanized('kk')(lambda *args, **kwargs: 'салам алейкум')(), 'salam alejkum'

# Generated at 2022-06-12 01:27:22.530071
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    text = Text(locale='ru')
    assert text.romanize() == text.capitalize()

# Generated at 2022-06-12 01:27:24.670543
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test():
        return 'Привет'

    assert test() == 'privet'

# Generated at 2022-06-12 01:27:26.985069
# Unit test for function romanize
def test_romanize():
    @romanize('en')
    def test_fn():
        return 'Привет, Мир!'

    assert test_fn() == 'Privet, Mir!'

# Generated at 2022-06-12 01:27:35.664986
# Unit test for function romanize
def test_romanize():

    @romanized('ru')
    def hello_ru() -> str:
        return 'Привет, мир!'

    @romanized('uk')
    def hello_uk() -> str:
        return 'Привіт, світ!'

    @romanized('kk')
    def hello_kk() -> str:
        return 'Сәлем, дүние!'

    assert hello_ru() == 'Privet, mir!'
    assert hello_uk() == 'Pryvit, svit!'
    assert hello_kk() == 'Sälem, dünie!'

# Generated at 2022-06-12 01:27:45.957492
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize(locale='ru')(lambda: 'Юлия')().lower() == 'yuliya'
    assert romanize(locale='ru')(lambda: 'Юлия')().lower() != 'yuliya1'
    assert romanize(locale='ru')(lambda: 'Юлия')().lower() != 'yuliya1!'
    assert romanize(locale='ru')(lambda: 'Юлия')().lower() != 'yuliya1!#'

    assert romanize(locale='uk')(lambda: 'Юлия')() == 'Yuliya'

# Generated at 2022-06-12 01:27:49.318697
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_method(self):
        return self.random.choice(self.get_data('common', 'letters_cyr'))

    assert romanize_method() == 'A'



# Generated at 2022-06-12 01:27:50.591779
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('hello') == 'hello'
    assert romanize('ru')('Привет') == 'Privet'

# Generated at 2022-06-12 01:27:57.526622
# Unit test for function romanize
def test_romanize():
    # Test for romanize function when ru is given
    func = romanize('ru')
    @func
    def get_str():
        return "фыва пролдж"
    assert get_str() == "fyva proldz"
    # Test for romanize function when ru is not given
    func = romanize()
    @func
    def get_str():
        return "фыва пролдж"
    assert get_str() == "fyva proldz"
    # Test for romanize function when given unsupported local
    func = romanize('bd')
    @func
    def get_str():
        return "фыва пролдж"
    assert get_str() == "fyva proldz"

# Generated at 2022-06-12 01:28:05.959290
# Unit test for function romanize
def test_romanize():
    def foo(*args, **kwargs):
        return 'тест'

    bar = romanize('ru')(foo)
    result = bar()
    assert result == 'test'

# Generated at 2022-06-12 01:28:14.472181
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""

    @romanize(locale='ru')
    def romanize_ru_deco(text):
        return text

    @romanize(locale='uk')
    def romanize_uk_deco(text):
        return text

    @romanize(locale='kk')
    def romanize_kk_deco(text):
        return text

    text_ru = 'СЛОЖНОСТИ'
    assert romanize_ru_deco(text_ru) == 'SLOZHNOSTI'

    text_uk = 'АНЛІЙСЬКА'
    assert romanize_uk_deco(text_uk) == 'ANLIISKA'

# Generated at 2022-06-12 01:28:19.497381
# Unit test for function romanize
def test_romanize():
    test_string = 'Привет, как твои дела?'
    assert romanize(locale='ru')(lambda: test_string)() == 'Privet, kak tvoi dela?'

# Generated at 2022-06-12 01:28:23.613420
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus():
        return 'привет мир'

    assert rus() == 'privet mir'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:28:27.052524
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    from mimesis.builtins import RussiaSpecProvider
    person = Person(RussiaSpecProvider)
    assert type(person.surname()).__name__ == 'str'

test_romanize()

# Generated at 2022-06-12 01:28:29.150613
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Олег Карпенко')() == 'Oleg Karpenko'

# Generated at 2022-06-12 01:28:30.063338
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-12 01:28:35.178795
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Кошка')() == 'Koshka'
    assert romanize('kk')(lambda: 'сөз')() == 'söz'
    assert romanize('uk')(lambda: 'Коробка')() == 'Korobka'



# Generated at 2022-06-12 01:28:38.573623
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def g():
        return 'Тестируем'
    
    assert g() == 'Testiruem'

# Generated at 2022-06-12 01:28:44.998126
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Что-то на русском')() == 'Chto-to na russkom'
    assert romanize('kk')(lambda: 'Ағылшынша')() == 'Ağılşınşa'
    assert romanize('uk')(lambda: 'Довгаль')() == 'Dovgal'

# Generated at 2022-06-12 01:28:55.276574
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-12 01:28:56.990216
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'абвгдежз')() == 'abvgdezhz'

# Generated at 2022-06-12 01:28:58.740230
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    assert romanize('ru')(lambda: 'hello world')() == 'hello world'

# Generated at 2022-06-12 01:29:06.545460
# Unit test for function romanize
def test_romanize():
    romanize_ = romanize('ru')

    @romanize_
    def foo(locale='ru'):
        return 'Спасибо!'

    assert foo() == 'Spasibo!'

    @romanize_
    def bar():
        return 'Привет!'

    assert bar() == 'Privet!'

    # Unsupported locale
    @romanize('es')
    def invalid_locale():
        return 'Привет!'

    assert invalid_locale == 'Privet!'

# Generated at 2022-06-12 01:29:10.910594
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize(locale='ru')(lambda: 'Улица Красная д. 1')() == \
        'Ulitsa Krasnaja d. 1'


if __name__ == '__main__':
    print(test_romanize())

# Generated at 2022-06-12 01:29:14.423630
# Unit test for function romanize
def test_romanize():
    assert romanize()('Написать тест как можно скорее.') \
        == 'Napisat test kak mozhna skoree.'

# Generated at 2022-06-12 01:29:22.722587
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    @romanize('ru')
    def romanize_ru(n):
        return n

    text = 'Всем привет'
    assert romanize_ru(text) == 'Vsem privet'

    @romanize('uk')
    def romanize_uk(n):
        return n

    text = 'Привіт'
    assert romanize_uk(text) == 'Pryvit'

    @romanized('kk')
    def romanize_kk(n):
        return n

    text = 'Сәлеметсіз бе'
    assert romanize_kk(text) == 'Salemetsiz be'

# Generated at 2022-06-12 01:29:29.634358
# Unit test for function romanize
def test_romanize():
    from mimesis.schema import Field, Schema
    from mimesis.enums import Gender, Locale
    from mimesis.builtins import RussiaSpecProvider

    class Person(RussiaSpecProvider):
        class Meta:
            locales = [Locale.RU]

        full_name = Field('full_name', gender=Gender.MALE)

    person = Person()
    schema = Schema(schema=person.build())
    data = schema.create(iterations=100)
    assert ' ' in data[0]['full_name']

# Generated at 2022-06-12 01:29:39.486627
# Unit test for function romanize
def test_romanize():
    from pytest import raises

    @romanized(locale='ru')
    def get_romanized_ru():
        return 'Привет, Мир!'

    assert get_romanized_ru() == 'Privet, Mir!'

    @romanized(locale='uk')
    def get_romanized_uk():
        return 'Привіт, Світ!'

    assert get_romanized_uk() == 'Pryvit, Svit!'

    @romanized(locale='kk')
    def get_romanized_kk():
        return 'Сәлем, Дүние!'

    assert get_romanized_kk() == 'Sälem, Dünie!'


# Generated at 2022-06-12 01:29:44.696496
# Unit test for function romanize
def test_romanize():
    assert romanize()('Россия') == 'Rossiya'
    assert romanize()('Прывітанне') == 'Pryvitannie'
    assert romanize()('Вітаю, Харків') == 'Vitayu, Kharkiv'



# Generated at 2022-06-12 01:30:06.786545
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    def test_dec(func):

        @romanize('ru')
        def roman():
            """Romanize."""
            return func()

        assert roman() == func()

    test_dec(lambda: "Привет. Мир. Сегодня хорошая погода.")
    test_dec(lambda: "Привiт. Мир. Сьогодні хороша погода.")
    test_dec(lambda: "Привет. Мир. Сегодня хорошая погода.")

# Generated at 2022-06-12 01:30:08.444581
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Тест')() == 'Test'

# Generated at 2022-06-12 01:30:13.493862
# Unit test for function romanize
def test_romanize():
    """Unit test for func romanize.""".format(__name__)
    result = romanize('ru')

    def func(text):
        return text

    assert result(func)('Какая-то строка') == 'Kakaya-to stroka'

# Generated at 2022-06-12 01:30:16.442550
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_russian_string():
        return 'Привет мир!'

    assert get_russian_string() == 'Privet mir!'

# Generated at 2022-06-12 01:30:19.817398
# Unit test for function romanize
def test_romanize():  # pragma: no cover
    """Test romanize."""
    print(romanize()(lambda: 'Привет, Мир!'))

# Generated at 2022-06-12 01:30:24.228098
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test():
        return 'Привет.'

    txt = test()
    assert txt == 'Privet.'

    # Test for two arguments
    @romanize('uk')
    def test2(arg, arg2):
        return '{} {}'.format(arg, arg2)

    txt = test2('Привіт', 'Світ')
    assert txt == 'Pryvit Svit'

    # Test for environment with non-ascii encoding
    import os
    import locale

    locale_info = locale.getlocale()
    os.environ['LANG'] = 'ru_RU.KOI8-R'

# Generated at 2022-06-12 01:30:27.293068
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'тест')() == 'test'
    assert romanize('uk')(lambda: 'тест')() == 'test'
    assert romanize('kk')(lambda: 'тест')() == 'test'

# Generated at 2022-06-12 01:30:29.684419
# Unit test for function romanize
def test_romanize():
    @romanized
    def get_test(): return 'test'

    assert get_test() == 'test'



# Generated at 2022-06-12 01:30:31.246084
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'локаль') == 'lokal`'

# Generated at 2022-06-12 01:30:35.951097
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_name():
        return 'Привет, Мир!'
    assert get_name() == 'Privet, Mir!'



# Generated at 2022-06-12 01:31:09.060279
# Unit test for function romanize
def test_romanize():
    def roman(locale):
        def trans(st):
            return ''.join(st)

        return romanize(locale)(trans)

    assert roman('ru')('Привет') == 'Privet'
    assert roman('uk')('Привіт') == 'Pryvit'
    assert roman('kk')('Салам') == 'Salam'

    assert romanized('ru')(lambda s: ''.join(s))('Привет') == 'Privet'
    assert romanized('uk')(lambda s: ''.join(s))('Привіт') == 'Pryvit'

# Generated at 2022-06-12 01:31:12.494045
# Unit test for function romanize
def test_romanize():
    assert romanize()(str)('123') == '123'
    assert romanize()(str)('Привет!') == 'Privet!'
    assert romanized()(str)('Привет!') == 'Privet!'

# Generated at 2022-06-12 01:31:15.585342
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    romanized = romanize(Language.UKRAINIAN)
    assert 'Dyakuyu' == romanized(lambda: 'Дякую')

# Generated at 2022-06-12 01:31:19.467031
# Unit test for function romanize
def test_romanize():
    @romanize
    def dummy():
        return 'текст должны быть преобразованы'
    result = dummy()
    assert result == 'tekst dolzhny byt' \
                     ' preobrazovany'

# Generated at 2022-06-12 01:31:25.927395
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'privit'
    assert romanize('kk')(lambda: 'сәлем')() == 'salem'

# Generated at 2022-06-12 01:31:32.978757
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    from mimesis.builtins import RussiaSpecProvider

    rus = RussiaSpecProvider()

    assert rus.word(locale='ru') == 'Пожимал'
    assert rus.word(locale='ru-RU') == 'Вошёл'
    assert rus.word(locale='ru-RU-RU-RU') == 'Одной'

# Generated at 2022-06-12 01:31:36.453065
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru', seed=42)
    rus_male = p.full_name(gender=Gender.MALE)
    assert romanize('ru')(rus_male) == 'Vasiliy Voroncov'

# Generated at 2022-06-12 01:31:39.556990
# Unit test for function romanize
def test_romanize():
    romanize('ru')(lambda: 'Привет, мир!') == 'Privet, mir!'
    romanize('uk')(lambda: 'Все добре?') == 'Vse dobre?'
    romanize('kk')(lambda: 'Привет, мир!') == 'Privet, mir!'

# Generated at 2022-06-12 01:31:47.923829
# Unit test for function romanize
def test_romanize():
    def foo(value):
        return value

    decorator = romanize()
    decorated = decorator(foo)
    assert decorated('абв') == 'abv'
    assert decorated('Абв') == 'Abv'
    assert decorated('АБВ') == 'ABV'
    assert decorated('abc') == 'abc'
    assert decorated('abc абв') == 'abc abv'

    decorator = romanize('uk')
    decorated = decorator(foo)
    assert decorated('абв') == 'abv'
    assert decorated('Абв') == 'Abv'
    assert decorated('АБВ') == 'ABV'
    assert decorated('abc абв') == 'abc abv'

    decorator = romanize

# Generated at 2022-06-12 01:31:59.990402
# Unit test for function romanize
def test_romanize():
    data.ROMANIZATION_DICT['ru']['h'] = 'g'
    # Cyrillic string can contain ascii
    # symbols, digits and punctuation
    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({**data.ROMANIZATION_DICT['ru'], **data.COMMON_LETTERS})
    assert ''.join([alphabet[i] for i in 'государство' if i in alphabet]) == "gosudarstvo"

# Generated at 2022-06-12 01:32:46.742553
# Unit test for function romanize
def test_romanize():
    from mimesis.schema import Field
    from mimesis.enums import Gender

    romanized_text = ''.join([letter for letter in Field('person.name',
                                                         gender=Gender.MALE)])
    assert len(romanized_text) > 0
    assert isinstance(romanized_text, str)


# Generated at 2022-06-12 01:32:58.012007
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    # Check that romanize decorator works correctly

    # Create a function, that generates a russian phrase
    @romanize('ru')
    def russian(self):
        return "Как программировать"

    # Create a function, that generates a ukrainian phrase
    @romanize('uk')
    def ukrainian(self):
        return "Програмування - це круто!"

    # Create a function, that generates a kazakh phrase

# Generated at 2022-06-12 01:32:59.976607
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.text import Text

    text = Text('ru')
    assert text.romanize()

# Generated at 2022-06-12 01:33:11.541350
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    from mimesis.builtins import UkrainianSpecProvider
    from mimesis.builtins import KazakhSpecProvider

    russian = RussianSpecProvider()
    ukrainian = UkrainianSpecProvider()
    kazakh = KazakhSpecProvider()

    # Validate russian
    assert russian.as_latin(russian.last_name()) == \
        russian.as_latin.last_name()
    assert russian.as_latin(russian.first_name()) == \
        russian.as_latin.first_name()
    assert russian.as_latin(russian.middle_name()) == \
        russian.as_latin.middle_name()

# Generated at 2022-06-12 01:33:16.905808
# Unit test for function romanize
def test_romanize():
    assert romanize('nl')(lambda: 'test')() == 'test'
    assert romanize('ru')(lambda: 'Учебник по теории дискретных графов')() == 'Uchebnik po teorii diskretnykh grafov'
    assert romanize('en')(lambda: 'Учебник по теории дискретных графов')() == 'Uchebnik po teorii diskretnykh grafov'

# Generated at 2022-06-12 01:33:19.434268
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize(locale='uk')
    assert romanize(locale='ru')
    assert romanize(locale='kk')
    assert romanize('xx')



# Generated at 2022-06-12 01:33:23.442356
# Unit test for function romanize
def test_romanize():
    string = 'Привет мир!'
    assert romanized('ru')(lambda *args, **kwargs: string)('') == 'Privet mir!'



# Generated at 2022-06-12 01:33:25.218216
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет мир!')() == 'Privet mir!'

# Generated at 2022-06-12 01:33:30.063699
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    text = romanize()(lambda: 'Это не юникод')()
    assert text == 'Eto ne yunikod'

    # Wrong locale code
    fn = romanize('ru')(lambda: 'Привет мир!')
    assert fn() == 'Privet mir!'

    # String contains ASCII letter
    fn = romanize('ru')(lambda: 'Привет, A')
    assert fn() == 'Privet, A'

# Generated at 2022-06-12 01:33:31.598278
# Unit test for function romanize
def test_romanize():
    r = romanized('ru')(lambda: 'Привет')
    assert r() == 'Privet'

