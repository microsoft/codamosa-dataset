

# Generated at 2022-06-12 01:24:56.222852
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def rus(x):
        return x

    assert rus('Абедов') == 'Abidov'

    @romanized('uk')
    def ukr(x):
        return x

    assert ukr('Абедов') == 'Abidov'

    @romanized('kk')
    def kk(x):
        return x

    assert kk('Абедов') == 'Abidov'

    # unsupported locale exception
    try:
        @romanized('invalid_locale')
        def with_invalid_locale(x):
            return x
    except UnsupportedLocale as e:
        assert str(e) == 'Unsupported locale: invalid_locale'
    else:
        raise Assertion

# Generated at 2022-06-12 01:25:01.894061
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    @romanize(locale=Language.RUSSIAN)
    def rus_text(length: int = 10) -> str:
        return 'Привет, Мимесис!'

    assert rus_text(length=10) == 'Privet, Mimesis!'

# Generated at 2022-06-12 01:25:09.152070
# Unit test for function romanize
def test_romanize():
    assert romanize()('привет') == 'privet'
    assert romanize('kk')('привет') == 'privet'
    assert romanize('uk')('привет') == 'pryvit'
    assert romanize('uk')('до зустрічі') == 'do zustrichi'
    assert romanize('uk')('модуль') == 'modul'


# Generated at 2022-06-12 01:25:11.383623
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text
    assert mimesis.builtins.text.Text('ru').romanized()

# Generated at 2022-06-12 01:25:15.315711
# Unit test for function romanize
def test_romanize():
    def foo():
        return 'Привет мир!'
    assert romanized('ru')(foo)() == 'Privet mir!'

# Generated at 2022-06-12 01:25:18.061423
# Unit test for function romanize
def test_romanize():
    # TODO: test with all locales
    assert romanized()(lambda: 'Привет, Мир')() == 'Privet, Mir'

# Generated at 2022-06-12 01:25:21.109332
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'абвгджзтіклмнопрстуфґ')() == 'abvgdejztiklmnoprstufg'

# Generated at 2022-06-12 01:25:32.438137
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет, мир!') == 'Privet, mir!'
    assert romanized('ru')('Привет, мир!') == 'Privet, mir!'
    assert romanized('uk')('Привет, мир!') == 'Pryvit, mir!'
    assert romanized('kk')('Привет, мир!') == 'Pryvit, mir!'
    assert romanized('kk')('Привет, мир!') == 'Pryvit, mir!'


# Generated at 2022-06-12 01:25:36.204385
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_name() -> str:
        """Get russian name."""
        return 'Роман'

    assert get_name() == 'Roman'

# Generated at 2022-06-12 01:25:39.608468
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize('uk')('Привіт') == 'Pryvit'

# Generated at 2022-06-12 01:25:49.820876
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def romanize_test():
        return 'Привет, как дела?'

    assert romanize_test() == 'Privet, kak dela?'



# Generated at 2022-06-12 01:25:59.639386
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize('ru')(lambda x: 'Привет!')() == 'Privet!'
    assert romanize('ru')(lambda x: 'Привет!')() == 'Privet!'
    assert romanize('uk')(lambda x: 'Привіт!')() == 'Pryvit!'
    assert romanize('kk')(lambda x: 'Сәлем!')() == 'Salem!'
    assert romanize('ru')(lambda x: 'Привет!')() == 'Privet!'
    assert romanize('kk')(lambda x: 'Сәлемсен ба?')() == 'Salemsen ba?'

# Generated at 2022-06-12 01:26:10.999375
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russify():
        return 'Съешь ещё этих мягких французских булок из Йошкар-Олы, да выпей алтайского чаю'

    assert russify() == (
        'Seshj eščo etih mjagkih frankuzskih bulok iz Joškar-Oly, '
        'da vypej altajskogo čaju'
    )


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:26:20.568561
# Unit test for function romanize
def test_romanize():
    assert ascii_letters == romanize()(ascii_letters)
    assert digits == romanize()(digits)
    assert punctuation == romanize()(punctuation)
    assert 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ' == romanize()('АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ')

# Generated at 2022-06-12 01:26:27.950795
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanized('uk')(lambda: 'Привіт, Світанок!')() == 'Pryvit, Svitanok!'
    assert romanized('kk')(lambda: 'сәлем, дүние!')() == 'salem, dyne!'

# Generated at 2022-06-12 01:26:33.229980
# Unit test for function romanize
def test_romanize():
    '''
    Tests romanize function
    '''
    assert 'Hello World' == romanized('en')('Hello World')
    assert 'Привет, Мир' == romanized('ru')('Привет, Мир')
    assert 'Привіт, Світ' == romanized('uk')('Привіт, Світ')

# Generated at 2022-06-12 01:26:37.167747
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    russian_provider = RussianSpecProvider()

    assert russian_provider.romanize('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-12 01:26:37.878495
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-12 01:26:39.676453
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-12 01:26:44.183316
# Unit test for function romanize
def test_romanize():
    assert 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.' == romanize('ru')(lambda: 'Лорем ипсум долор сит амет, консектетур адиписцинг элит.')

# Generated at 2022-06-12 01:27:00.341428
# Unit test for function romanize
def test_romanize():
    from mimesis import Person, Datetime, Generic

    locale = 'ru'

    p = Person(locale)
    d = Datetime(locale)
    g = Generic(locale)

    person = p.full_name(gender='male')
    assert person in data.ROMANIZATION_DICT[locale]
    assert romanize(locale) == romanized(locale)

    date = d.date(minimum=2000, maximum=2019)
    assert date in data.ROMANIZATION_DICT[locale]
    assert romanize(locale) == romanized(locale)

    number = g.code(mask='#-#-#')
    assert number in data.ROMANIZATION_DICT[locale]

# Generated at 2022-06-12 01:27:02.198405
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize('') is not None
    assert romanize(locale='ru') is not None

# Generated at 2022-06-12 01:27:07.330479
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender

    from .person import Person

    gender = Gender.MALE
    p = Person('ru')
    name = p.full_name(gender)
    romanized_name = p.full_name(gender, romanize='ru')
    assert romanized_name in name

# Generated at 2022-06-12 01:27:13.631976
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privyet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'
    assert romanize('az')(lambda: 'Salam')() == 'Salam'

# Generated at 2022-06-12 01:27:18.607996
# Unit test for function romanize
def test_romanize():
    # example from https://ru.wikipedia.org/wiki/Русский_алфавит
    assert romanized(locale='ru')(lambda: 'Чистая вода')() == 'Chistaya voda'

# Generated at 2022-06-12 01:27:29.361921
# Unit test for function romanize
def test_romanize():
    assert romanize()('На берегу пустынных волн') == 'Na beregu pustynnix voln'
    assert romanize()('Стоял он, дум великих полн') == 'Stoyal on, dum velikix poln'
    assert romanize()('И вдаль глядел.') == 'I vdal glyadel.'
    assert romanize()('Пред ним широко Река неслася') == 'Pred nim shiroko Reka neslasya'

# Generated at 2022-06-12 01:27:32.100912
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda: 'Привет!')()  # noqa
    assert result == 'Privet!'

# Generated at 2022-06-12 01:27:40.117955
# Unit test for function romanize
def test_romanize():
    assert 'Eto proveryaet funktsiyu perevoda na roman' == romanize('ru')(lambda: 'Это проверяет функцию перевода на роман')(), \
        'romanize fails'
    assert 'Teste funktsiyu perevoda na roman' == romanize('ru')(lambda: 'Тест функцию перевода на роман')(), \
        'romanize fails'

# Generated at 2022-06-12 01:27:46.126052
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='uk')(lambda: 'Русский')() == 'Russkiy'
    assert romanize(locale='ru')(lambda: 'Русский')() == 'Russkiy'
    assert romanize(locale='kk')(lambda: 'Русский')() == 'Russkîy'

# Generated at 2022-06-12 01:27:50.854539
# Unit test for function romanize
def test_romanize():
    from mimesis.providers import Person

    def test_romanized_func(name):
        return name

    romanized_test_func = romanize('ru')(test_romanized_func)

    person = Person('ru')
    name = person.name()

    assert name == romanized_test_func(name)

# Generated at 2022-06-12 01:28:12.930068
# Unit test for function romanize
def test_romanize():
    assert romanized()('hello') == 'hello'

# Generated at 2022-06-12 01:28:13.915159
# Unit test for function romanize
def test_romanize():
    romanize('ru')

# Generated at 2022-06-12 01:28:19.487197
# Unit test for function romanize
def test_romanize():
    # Clone the function and change the default locale
    romanized = romanize('uk')

    @romanized
    def some_func(seed: int = None):
        return data.DataProvider('uk_UA', seed).russian.name()

    assert some_func(123) == 'Ivan Kozlov'

# Generated at 2022-06-12 01:28:21.555578
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'привет')() == 'privet'

# Generated at 2022-06-12 01:28:23.348833
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "привет")() == "privet"

# Generated at 2022-06-12 01:28:27.141487
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Привет мир!') == 'Privet mir!'

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:28:30.209037
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_func(word):
        return word

    result = romanize_func('Привет, мир!')
    assert result == 'Privet, mir!'



# Generated at 2022-06-12 01:28:40.764043
# Unit test for function romanize
def test_romanize():
    """Test Romanize the cyrillic script into the latin alphabet."""
    from mimesis.builtins import Person, Address, Datetime
    import mimesis.builtins as mimesis
    import json

    p = Person('ru')
    a = Address('ru')
    dt = Datetime('uk')
    mr = mimesis.Romanizer('ru')
    mr_g = mr.generator('ru')
    assert isinstance(p, Person)
    assert isinstance(a, Address)
    assert isinstance(dt, Datetime)
    assert isinstance(mr, mimesis.Romanizer)
    assert isinstance(mr_g, mimesis.Romanizer)
    assert p.full_name()
    assert p.name()
    assert a.street_name()
    assert dt

# Generated at 2022-06-12 01:28:47.859232
# Unit test for function romanize
def test_romanize():
    # the result will be the same if romanized decorator is used
    # either on the class level or on the method level
    class Person:
        @romanized()
        def get_full_name(self):
            return 'Беляев Александр Сергеевич'

    person = Person()
    assert person.get_full_name() == 'Belyaev Aleksandr Sergeevich'

# Generated at 2022-06-12 01:28:56.139247
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import PersonProvider

    rus_person = PersonProvider(Language.RUSSIAN)
    ukr_person = PersonProvider(Language.UKRAINIAN)
    kaz_person = PersonProvider(Language.KAZAKH)

    assert rus_person.full_name() == 'Андрей Романов'
    assert ukr_person.full_name() == 'Воронченко Олег'
    assert kaz_person.full_name() == 'Құрманғазы Багдат'



# Generated at 2022-06-12 01:29:17.573631
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='en')(data.common_english_words)() == 'common'

# Generated at 2022-06-12 01:29:20.391625
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda: 'Красная Шапочка')()
    assert result == 'Krasnaya Shapochka'

# Generated at 2022-06-12 01:29:26.926276
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(str)('Привет, а как твои дела? Все нормально?') == 'Privet, a kak tvoi dela? Vse normalno?'
    assert romanize('uk')(str)('Привіт, а як твої справи? Все нормально?') == 'Pryvit, a yak tvoi spravy? Vse normalno?'

# Generated at 2022-06-12 01:29:29.037172
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')

# Generated at 2022-06-12 01:29:32.595212
# Unit test for function romanize
def test_romanize():
    class Test(object):
        @romanize('ru')
        def test(self):
            return 'Тест'
    
    test_object = Test()
    
    assert test_object.test() == 'Test'

# Generated at 2022-06-12 01:29:33.688811
# Unit test for function romanize
def test_romanize():
    # It will be replaced later with real test cases
    assert True

# Generated at 2022-06-12 01:29:39.030114
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('Привет Мир!') == 'Privet Mir!'
    assert romanized('uk')('Привіт Світ!') == 'Pryvit Svit!'
    assert romanized('kk')('Сәлем Дүние!') == 'Sälem Dünie!'

# Generated at 2022-06-12 01:29:48.967502
# Unit test for function romanize
def test_romanize():
    test_locale = 'ru'

    # Create reference data
    rus_string = 'Съешь ещё этих мягких французских булок, да выпей же чаю.'
    ref_string = 'S’esh’ yeshchjo yechikh myagkikh frantsuzskikh bulok, ' \
                 'da vypej zhe chaju.'

    class MockRom(object):

        @staticmethod
        @romanize(test_locale)
        def get_text(*args, **kwargs):
            return rus_string

    assert ref_string == MockRom().get

# Generated at 2022-06-12 01:29:52.312838
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def _get_ru_text() -> str:
        return 'Привет! Как дела?'

    assert _get_ru_text() == 'Privet! Kak dela?'

# Generated at 2022-06-12 01:29:56.294382
# Unit test for function romanize
def test_romanize():
    message = "Error: romanize() failed"
    assert romanize('fake')(lambda: 'Непереведённая')(), message

# Generated at 2022-06-12 01:30:26.409206
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'Это просто тест')() == 'Eto prosto test'
    assert romanized('uk')(lambda : 'Это просто тест')() == 'Eto prosto test'
    assert romanized('kk')(lambda : 'Это просто тест')() == 'Eto prosto test'



# Generated at 2022-06-12 01:30:30.341248
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_mock(i):
        return i

    assert romanize_mock('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-12 01:30:39.965247
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    import mimesis.builtins

    class Pattern(object):

        @romanize('ru')
        def romanized(self):
            """Romanized method."""
            return 'русский'

    p = Pattern()

    russian_text = p.romanized()
    assert russian_text == 'russkiy'
    assert mimesis.builtins.Romanization().romanize('ru', 'русский') == \
        russian_text


# Generated at 2022-06-12 01:30:40.600060
# Unit test for function romanize
def test_romanize():
    return romanize

# Generated at 2022-06-12 01:30:44.998091
# Unit test for function romanize
def test_romanize():
    assert romanize()('Светлана') == 'Svetlana'
    assert romanize()('Светлана') != 'Bаша'

# Generated at 2022-06-12 01:30:49.015471
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()
    assert romanize('ru')
    assert romanized('ru')
    assert romanize('uk')
    assert romanized('uk')
    assert romanize('kk')
    assert romanized('kk')

# Generated at 2022-06-12 01:30:55.022290
# Unit test for function romanize
def test_romanize():
    my_func = lambda x: 'Даруйтесь, молодцы и отличники!'

    @romanize(locale='ru')
    def romanized_func(func: Callable) -> str:
        return func()

    assert romanized_func(my_func) == 'Daruytes\', molodcy i otlichniki!'

# Generated at 2022-06-12 01:31:01.236787
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    @romanize(locale='ru')
    def func():
        return 'Строка для проверки правильности русского романизатора'

    assert callable(func)
    assert func() == 'Str7ka dlya prowerki pravilnosti russkogo romaniatora'

# Generated at 2022-06-12 01:31:02.723801
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'абвгд')() == 'abvgd'

# Generated at 2022-06-12 01:31:06.937935
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""

    @romanize(locale='ru')
    def test():
        return 'Привет'



# Generated at 2022-06-12 01:32:13.514066
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_string(cls):
        return cls.text.title()

    # Cyrillic text will be romanized
    assert test_string('Мимезис')

    # Latin text will not be romanized
    assert test_string('mimesis') == 'mimesis'

# Generated at 2022-06-12 01:32:16.292135
# Unit test for function romanize
def test_romanize():
    @romanize(locale='kk')
    def test(seed: int = 0) -> str:
        return 'Кайда жазылған болсын?'

    assert test() == 'Kaıda jazılğan bolsın?'

# Generated at 2022-06-12 01:32:26.347248
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import EnumEn
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person(locale='uk')
    person.gender = Gender.MALE
    assert person.full_name.isalpha() is False
    assert ('Євген Вадимович' in person.full_name) is True
    assert ('Yeugen Vadymovych' in person.romanized.full_name) is True
    assert person.romanized.full_name.isalpha() is True



# Generated at 2022-06-12 01:32:31.687404
# Unit test for function romanize
def test_romanize():

    @romanize('uk')
    def romanize_string(text: str) -> str:
        return text

    @romanize('uk')
    def romanize_string_with_args(text: str, *args, **kwargs) -> str:
        return text

    @romanize('uk')
    def romanize_string_with_default_args(text: str = 'Привіт') -> str:
        return text

    text = 'Я шукав Надю у тому романі, який раніше її не зацікавлював.'

# Generated at 2022-06-12 01:32:41.214395
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person as P
    from mimesis import Generic as G

    p = P('ru')
    g = G('ru')

    assert p.full_name() == 'Василий Чеченов'
    assert g.address.street_suffix() == 'улица'
    assert g.person.full_name() == 'Василий Чеченов'
    assert g.address.street_suffix() == 'улица'

# Generated at 2022-06-12 01:32:48.725796
# Unit test for function romanize
def test_romanize():
    from tests.data import romanize_data

    @romanize('ru')
    def _ru(text):
        return text

    @romanize('')
    def _empty(text):
        return text

    @romanize('uk')
    def _uk(text):
        return text

    @romanize('kk')
    def _kk(text):
        return text

    assert _ru(romanize_data[0]['cyr']) == romanize_data[0]['lat']
    assert _empty(romanize_data[0]['cyr']) == romanize_data[0]['lat']
    assert _uk(romanize_data[1]['cyr']) == romanize_data[1]['lat']
    assert _kk(romanize_data[2]['cyr'])

# Generated at 2022-06-12 01:32:59.396291
# Unit test for function romanize
def test_romanize():
    # romanized function
    assert romanized('ru')(lambda x: 'Привіт')() == 'Pryvit'
    assert romanized('uk')(lambda x: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda x: 'Привіт')() == 'Pryvit'

    # romanized decorator
    @romanized
    def func(x):
        return 'Привіт'


    assert func() == 'Pryvit'

    @romanized('ru')
    def func_ru(x):
        return 'Привіт'


    assert func_ru() == 'Pryvit'


# Generated at 2022-06-12 01:33:09.269947
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    # This decorator can be used only as wrapper
    @romanize()
    def foo():
        return 'первого места'

    assert foo() == 'pervogo mesta'

    @romanize('ru')
    def russia():
        return 'первого места'

    assert russia() == 'pervogo mesta'

    @romanized('uk')
    def ukraine():
        return 'первого места'

    assert ukraine() == 'pervoho mista'

# Generated at 2022-06-12 01:33:13.365944
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'слово')() == 'slovo'
    assert romanize(locale='uk')(lambda: 'слово')() == 'slovo'
    assert romanize(locale='kk')(lambda: 'слово')() == 'slovo'



# Generated at 2022-06-12 01:33:17.367492
# Unit test for function romanize
def test_romanize():
    pattern = '{}'

    # romanized
    c = romanize(locale='ru')
    assert c(lambda: pattern.format(data.CYRILLIC_LETTERS['ru'])) == 'Аа'

    # romanize
    assert romanize(locale='uk')(lambda: pattern.format(data.CYRILLIC_LETTERS['uk'])) == 'Аа'

    # with error
    try:
        romanize(locale='foobar')
    except UnsupportedLocale:
        pass