

# Generated at 2022-06-12 01:24:53.488419
# Unit test for function romanize
def test_romanize():
    assert 'привет' == romanize(locale='ru')('привет')


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-12 01:24:56.812858
# Unit test for function romanize
def test_romanize():
    try:
        romanize_deco(romanize, 1)
    except ValueError as e:
        print(e)
    except TypeError as e:
        print(e)
    except Exception as e:
        print(e)

# Generated at 2022-06-12 01:25:02.933236
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Как известно, главная задача переводчика')(
    ) == 'Kak izvestno, glavnaya zadacha perevodchika'



# Generated at 2022-06-12 01:25:06.512054
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import Person

    person = Person('ru')
    person.romanize = romanize('ru')

    assert person.romanize.name()

# Generated at 2022-06-12 01:25:15.632947
# Unit test for function romanize
def test_romanize():
    assert romanized()('Садко, пойдем сюда') == 'Sadko, poydom syuda'
    assert romanized()('Съешь ещё этих мягких французских булок, да выпей чаю') == 'Syesh\' eshche etikh miagkikh frantsuzskikh bulok, da vypei chayu'

# Generated at 2022-06-12 01:25:17.590310
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize('ru')
    assert not romanize('kz')



# Generated at 2022-06-12 01:25:25.140667
# Unit test for function romanize
def test_romanize():
    # locale = 'uk'
    # locale = 'ru'
    locale = 'kk'

    @romanized(locale)
    def do_romanize_test():
        # Cyrillic string can contain ascii
        # symbols, digits and punctuation.
        return 'asdfA123!@#$%^&*()_+qwerQWER'

    expected = ascii_letters + digits + punctuation
    result = do_romanize_test()
    assert set(result) == set(expected), \
        "Make sure romanization was applied and string was not changed."

# Generated at 2022-06-12 01:25:27.451356
# Unit test for function romanize
def test_romanize():
    @romanized('kk')
    def foo():
        return 'АҚҚҚ'
    assert foo() == 'Ak'

# Generated at 2022-06-12 01:25:32.524637
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Selém'

# Generated at 2022-06-12 01:25:37.996961
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text
    txt = Text(Language.KAZAKH)
    assert txt.romanized == txt.romanize()
    assert txt.romanized == romanize(locale='kk')(txt.romanize)()

# Generated at 2022-06-12 01:25:44.300567
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: "Куку")() == "Kuku"



# Generated at 2022-06-12 01:25:48.099603
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-12 01:25:58.694895
# Unit test for function romanize
def test_romanize():
    # 1
    assert romanize(locale='ru')(lambda: 'привет') == 'privet'
    assert romanize(locale='ru')(lambda: 'ПРИВЕТ') == 'PRIVET'
    # 2
    assert romanize(locale='uk')(lambda: 'Привіт') == 'Pryvit'
    assert romanize(locale='uk')(lambda: 'привіт') == 'pryvit'
    # 3
    assert romanize(locale='kk') == romanize(locale='kz')
    assert romanize(locale='kk')(lambda: 'сәлем') == 'salem'

# Generated at 2022-06-12 01:26:05.218847
# Unit test for function romanize
def test_romanize():
    def foo(text):
        return text

    result = foo('Привет, Мим!')
    assert result == 'Привет, Мим!'

    @romanize('ru')
    def bar(text):
        return text

    result = bar('Привет, Мим!')
    assert result == 'Privet, Mim!'



# Generated at 2022-06-12 01:26:16.777654
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rusian(self):
        return 'Галицко-Волынская Русь'
    assert rusian(None) == 'Galitsko-Volynskaya Rus'

    @romanize('uk')
    def ukrainian(self):
        return 'Галицько-Волинська Русь'
    assert ukrainian(None) == 'Halytsko-Volynska Rus'

    @romanize('kk')
    def kazakh(self):
        return 'Ғалық-Улы Рус'
    assert kazakh(None) == 'Ğalyq-Uly Rus'

   

# Generated at 2022-06-12 01:26:24.750939
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_data(pattern: str = '') -> str:
        return pattern

    assert romanize_data('Спасибо') == 'Spasibo'
    assert romanize_data('Я пишу для мамы') == 'Ja pisim dla mamy'
    assert romanize_data('Настолка семьи') == 'Nastolka semji'
    assert romanize_data('Дорогие друзья!') == 'Dorogije druzja!'

# Generated at 2022-06-12 01:26:32.620557
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""

    @romanize(locale='ru')
    def romanize_deco(value):
        """Romanize the cyrillic text."""
        return value

    text = romanize_deco('Сталин') == 'Stalin'
    assert text

    @romanize(locale='kk')
    def foo(text):
        """Bar."""
        return text

    text = foo('Бүршіліктің') == 'Burshiliktin'
    assert text


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:26:41.665870
# Unit test for function romanize
def test_romanize():
    """Test for romanize.

    :return:
    """
    @romanize('en')
    def aaa(str_):
        return str_
    assert aaa('sdfsdfsdfsdfsdfs') == 'sdfsdfsdfsdfsdfs'

    @romanize('ru')
    def bbb(str_):
        return str_
    assert bbb('sdfsdfsdfsdfsdfs') == 'sdfsdfsdfsdfsdfs'
    assert bbb('Андрей') == 'Andrey'

# Generated at 2022-06-12 01:26:45.283732
# Unit test for function romanize
def test_romanize():
    text = 'Привет, мир!'
    assert romanize('ru')(lambda: text) == 'Privet, mir!'



# Generated at 2022-06-12 01:26:48.639737
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    r = RussianSpecProvider()
    assert (r.romanize(r.localized_string('Привет мир!'))
            == 'Privet mir!')

# Generated at 2022-06-12 01:27:00.675086
# Unit test for function romanize
def test_romanize():
    class TestRomanize(object):
        def test_romanize(self):
            _romanize = romanize(locale='ru')(lambda: 'Привет')()
            assert _romanize == 'Privet'

        def test_romanize_with_ascii_symbols(self):
            _romanize = romanize(locale='ru')(lambda: 'Hello')()
            assert _romanize == 'Hello'

        def test_romanize_with_digits(self):
            _romanize = romanize(locale='ru')(lambda: '42')()
            assert _romanize == '42'


# Generated at 2022-06-12 01:27:07.226039
# Unit test for function romanize
def test_romanize():
    @romanize('en')
    def romanize_text(text):
        return text

    assert romanize_text('Привет') == 'Privet'

# Generated at 2022-06-12 01:27:18.979212
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person('ru')
    person.seed(42)
    person.gender = Gender.MALE

    fullname = person.full_name(patronymic=True)
    surname = person.surname(patronymic=True)
    assert fullname == 'Иванов Иван Иванович'
    assert surname == 'Иванов'

    # TODO: Update decorator after implementing
    # the whole set of romanization systems.
    assert person.romanized_full_name(patronymic=True) == \
        'Ivanov Ivan Ivanovich'
    assert person.romanized_surname(patronymic=True)

# Generated at 2022-06-12 01:27:24.761706
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Россия')() == 'Rossiya'
    assert romanize('kk')(lambda: 'Казахстан')() == 'Qazaqstan'
    assert romanize('uk')(lambda: 'Україна')() == 'Ukrayina'

# Generated at 2022-06-12 01:27:27.310677
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: "Си") == "S"
    assert romanized()(lambda: "й") == "y"
    assert romanized()(lambda: "И") == "I"

# Generated at 2022-06-12 01:27:34.443929
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def x():
        return 'Россия'

    assert x() == 'Rossiya'

    @romanize(locale='uk')
    def x():
        return 'Україна'

    assert x() == 'Ukrayina'

    @romanize(locale='kk')
    def x():
        return 'Қазақстан'
    print(x())

    assert x() == 'Qazaqstan'

# Generated at 2022-06-12 01:27:35.633358
# Unit test for function romanize
def test_romanize():
    assert romanize is romanized is romanize



# Generated at 2022-06-12 01:27:37.676738
# Unit test for function romanize
def test_romanize():
    # TODO: add real unit tests here
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-12 01:27:40.278657
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def r():
        return 'Большой привет мир'

    assert r() == 'Bolshoy privet mir'

# Generated at 2022-06-12 01:27:44.929010
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func():
        return 'абвг'

    assert func() == 'abvg'

    @romanize(locale='uk')
    def func():
        return 'абвг'

    assert func() == 'abvg'

# Generated at 2022-06-12 01:27:52.294388
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda x: 'Здравствуйте')() == 'Zdravstvuyte'

# Generated at 2022-06-12 01:27:58.149071
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func(self, *args):
        return 'Привет'
    assert func(0) == 'Privet'

    @romanize('uk')
    def func(self, *args):
        return 'Привіт'
    assert func(0) == 'Pryvit'

    @romanize('kk')
    def func(self, *args):
        return 'Сәлем'
    assert func(0) == 'Salem'

# Generated at 2022-06-12 01:28:08.368079
# Unit test for function romanize
def test_romanize():
    """Test function romanize.

    :return: None.
    """
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda: 'Қазақстан')() == 'Qazaqtstan'
    assert romanize()(lambda: 'United States of America')() == 'United States of America'

    func = lambda: 'привет'
    assert romanize('ru')(func)() == 'privet'

# Generated at 2022-06-12 01:28:11.357534
# Unit test for function romanize
def test_romanize():
    def fake_func():
        return 'Привет'
    romanize_func = romanize('ru')(fake_func)
    assert romanize_func() == 'Privet'
    

# Generated at 2022-06-12 01:28:14.061915
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    a = Address(locale=Locale.RUSSIA)
    assert romanize(Locale.RUSSIA)(a._get_formatted_address)()

# Generated at 2022-06-12 01:28:21.122483
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.person import Person
    p = Person('ru')
    assert p.full_name() == 'Дмитрий Антонов'

    @romanize(locale='ru')
    def romanized_name(self):
        return p.full_name()

    assert romanized_name() == 'Dmitriy Antonov'

# Generated at 2022-06-12 01:28:23.741992
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='uk')(lambda: 'Привіт, Світ!') == 'Pryvit, Svit!'

# Generated at 2022-06-12 01:28:33.934989
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'привет')(
    ) == romanize(locale='ru')(lambda: 'привет')()
    assert romanize(
        locale='ru')(lambda: 'привет').__doc__ == 'Romanize the cyrillic text.\n\n    Transliterate the cyrillic script into the latin alphabet.\n\n    .. note:: At this moment it works only for `ru`, `uk`, `kk`.\n\n    :param locale: Locale code.\n    :return: Romanized text.\n    '
    assert romanize(
        locale='ru')(lambda: 'привет').__name__ == '<lambda>'

# Generated at 2022-06-12 01:28:39.360656
# Unit test for function romanize
def test_romanize():
    import random

    @romanize(locale='ru')
    def get_ru_word(length: int = 8) -> str:
        return ''.join(
            random.choice(data.CYRILLIC_ALPHABET) for x in range(length))

    word = get_ru_word()
    assert isinstance(word, str)



# Generated at 2022-06-12 01:28:47.700512
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def romanize_function(text):
        return text

    assert romanize_function('Тест') == 'Test'
    assert romanize_function('що') == 'shcho'

    @romanized('uk')
    def romanize_function(text):
        return text

    assert romanize_function('що') == 'scho'

    @romanized('kk')
    def romanize_function(text):
        return text

    assert romanize_function('що') == 'sho'

# Generated at 2022-06-12 01:28:59.410830
# Unit test for function romanize
def test_romanize():
    """Check romanize function.
    """
    # TODO: Unit test for romanize decorator.



# Generated at 2022-06-12 01:29:09.961471
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет Мир') == 'Privet Mir'
    assert romanize()('ПРИВЕТ МИР') == 'PRIVET MIR'
    assert romanize()('Привет Мир') == 'Privet Mir'
    assert romanize()('Привет, Мир') == 'Privet, Mir'
    assert romanize()('Привет, Мир!') == 'Privet, Mir!'
    assert romanize()('Привет привет') == 'Privet privet'

# Generated at 2022-06-12 01:29:17.066935
# Unit test for function romanize
def test_romanize():
    """Test for romanized."""
    assert romanized()('Привет') == 'Privet'
    assert romanized()('Привіт, світ!') == 'Pryvit, svit!'
    assert romanized('uk')('Привіт, світ!') == 'Pryvit, svit!'
    assert romanized('kk')('Привет') == 'Pryvet'


__all__ += ['romanized']

# Generated at 2022-06-12 01:29:22.236502
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    @romanized('ru')
    def just_text(length: int = 10) -> str:
        """Return random text."""
        return ''.join([chr(d) for d in range(ord('а'), ord('я'))])[:length]

    result = just_text(33)
    assert isinstance(result, str)
    assert len(result) > 10
    assert isinstance(just_text(33), str)

# Generated at 2022-06-12 01:29:25.151688
# Unit test for function romanize
def test_romanize():
    """Example of romanize decorator."""

    @romanize('en')
    def romanized_text():
        return 'Привіт, Мімесіс!'

    assert romanized_text() == 'Pryvit, Mimesis!'

# Generated at 2022-06-12 01:29:31.315179
# Unit test for function romanize
def test_romanize():
    def foo(bar='bar'):
        return bar

    foo = romanize()(foo)
    assert foo() == 'bar'

    foo = romanize(locale='ru')(foo)
    assert foo() == 'bar'

    foo = romanize(locale='uk')(foo)
    assert foo() == 'bar'

    foo = romanize(locale='kk')(foo)
    assert foo() == 'bar'

# Generated at 2022-06-12 01:29:37.101736
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda: 'привет')
    assert result == 'privet'
    result = romanize('uk')(lambda: 'привіт')
    assert result == 'privit'
    result = romanize('kk')(lambda: 'сәлем')
    assert result == 'salem'



# Generated at 2022-06-12 01:29:37.638732
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-12 01:29:47.288865
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: None)() == ''
    assert romanized(locale='kk')(lambda: None)() == ''
    assert romanized(locale='uk')(lambda: None)() == ''
    assert romanized(locale='ru')(lambda: 'тест')() == 'test'
    assert romanized(locale='kk')(lambda: 'тест')() == 'test'
    assert romanized(locale='uk')(lambda: 'тест')() == 'test'
    assert romanized(locale='ru')(lambda: 'тест тест')() == 'test test'

# Generated at 2022-06-12 01:29:48.927735
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Тест')() == 'Test'



# Generated at 2022-06-12 01:30:16.688423
# Unit test for function romanize
def test_romanize():
    import random
    import string
    random_string = ''.join(random.choice(string.ascii_lowercase + ' ' + ''.join(data.CYRILLIC_LETTERS)) for x in range(0, 5))
    romanized_string = romanize()(random_string)
    assert romanized_string == romanized_string

# Generated at 2022-06-12 01:30:28.076134
# Unit test for function romanize
def test_romanize():
    """Testing function romanize."""

    @romanize('ru')
    def rus(*args, **kwargs):
        """Sample russian method."""
        return 'Hello Мир!'

    assert rus() == 'Hello Mir!'

    @romanize('uk')
    def ukr(*args, **kwargs):
        """Sample ukrainian method."""
        return 'Добрий ранок!'

    assert ukr() == 'Dobriy ranok!'

    @romanize('kk')
    def kaz(*args, **kwargs):
        """Sample kazakh method."""
        return 'Салам алейкум!'

    assert kaz() == 'Salam aleykum!'


# Generated at 2022-06-12 01:30:34.952934
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    def _test(locale):
        @romanize(locale)
        def get_string():
            return data.DATA['ru']

        test_string = get_string()
        assert isinstance(test_string, str)
        assert len(test_string) > 0

    for locale in data.ROMANIZATION_DICT:
        _test(locale)



# Generated at 2022-06-12 01:30:38.181599
# Unit test for function romanize
def test_romanize():
    """Tests for romanize."""

    @romanize(locale='ru')
    def foo(x: str) -> str:
        return x

    assert foo('привет') == 'privet'



# Generated at 2022-06-12 01:30:47.583781
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    from mimesis.providers.localization import Localization
    from mimesis.providers.datetime import Datetime

    l = Localization('en')

    @romanize(locale='ru')
    def _get_title():
        return l.custom.title()

    d = Datetime('en')
    assert _get_title() == 'Priklyuchenie Kasatki'

    @romanize(locale='ru')
    def _get_time():
        return d.time()

    assert _get_time() == '12:31:06'



# Generated at 2022-06-12 01:30:50.137093
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import UkraineSpecProvider
    ua = UkraineSpecProvider()
    assert ua.title() == 'Апостол Кисель'

# Generated at 2022-06-12 01:31:00.655306
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    import time
    import random
    from mimesis.builtins import Person, Address

    person = Person()
    address = Address()

    @romanize()
    def romanize_person() -> str:
        return person.full_name()

    @romanize()
    def romanize_address() -> str:
        return address.address()

    @romanize('uk')
    def romanize_person() -> str:
        return person.full_name()

    @romanize('uk')
    def romanize_address() -> str:
        return address.address()

    @romanize('ru')
    def romanize_person() -> str:
        return person.full_name()


# Generated at 2022-06-12 01:31:11.488269
# Unit test for function romanize
def test_romanize():
    """Romanize the cyrillic text.

    Transliterate the cyrillic script into the latin alphabet.

    .. note:: At this moment it works only for `ru`, `uk`, `kk`.

    :param locale: Locale code.
    :return: Romanized text.
    """

    def romanize(locale: str) -> Callable:
        try:
            # Cyrillic string can contain ascii
            # symbols, digits and punctuation.
            alphabet = {s: s for s in
                        ascii_letters + digits + punctuation}
            alphabet.update({
                **data.ROMANIZATION_DICT[locale],
                **data.COMMON_LETTERS,
            })
        except KeyError:
            raise UnsupportedLocale(locale)


# Generated at 2022-06-12 01:31:20.900702
# Unit test for function romanize
def test_romanize():
    @romanize()
    def txt(x):
        return x

    assert txt('Абракадабра') == 'Abrakadabra'
    assert txt('Абракадабра',locale='ru') == 'Abrakadabra'
    assert txt('Абракадабра',locale='uk') == 'Abrakadabra'
    assert txt('Абракадабра',locale='kk') == 'Abrakadabra'
    assert txt('Гидра') == 'Gida'
    assert txt('Гидра',locale='ru') == 'Gida'

# Generated at 2022-06-12 01:31:25.927429
# Unit test for function romanize
def test_romanize():
    """Romanize ru string."""
    @romanize('ru')
    def romanize_ru():
        """Generate something."""
        return 'Привет! Как дела?'

    assert romanize_ru() == 'Privet! Kak dela?'



# Generated at 2022-06-12 01:32:26.761160
# Unit test for function romanize
def test_romanize():
    assert romanized()('Тест для функции романизации') == 'Test dlya funktsii romanizatsii'


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-12 01:32:31.992220
# Unit test for function romanize
def test_romanize():
    # Example how to use romanize in generators
    # Some code is commented, because it is meaningless now.
    # It is only a stub for future.
    #
    # @romanize(locale='ru')
    # def roman_generator(self, *args, **kwargs):
    #     return self._data['text']['company']
    text = 'Тестовый текст'
    # roman_generator(self=None)
    assert romanize(locale='ru')(lambda: text)() == 'Testovyi tekst'
    assert romanize(locale='uk')(lambda: text)() == 'Testovyi tekst'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:32:34.596859
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    from mimesis.builtins import Person
    person = Person('ru')
    assert person.name() == 'Joan'
    assert person.full_name() == 'Joan Freeman'

# Generated at 2022-06-12 01:32:44.005342
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_func(test_text):
        return test_text

    assert test_func('Санкт-Петербург') == 'Sankt-Peterburg'
    assert test_func('Санкт-Петербург') == romanized('ru')('Санкт-Петербург')

# Generated at 2022-06-12 01:32:45.535835
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import TextSpecifier

    text_specs = TextSpecifier('ru')
    assert text_specs.romanized_text(2, 2) == 'Nu jdr'



# Generated at 2022-06-12 01:32:49.295207
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_str(x):
        return 'Pусский'
    assert rus_str(x=1) == 'Russkii'
    assert rus_str(x=1) == 'Russkii'
    try:
        @romanize('XXX')
        def text_str(x):
            return 'Pусский'
    except UnsupportedLocale:
        assert True



# Generated at 2022-06-12 01:32:51.282453
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins
    assert isinstance(mimesis.builtins.Names(locale='ru').last_name(), str)


# Generated at 2022-06-12 01:32:55.077575
# Unit test for function romanize
def test_romanize():
    """Test for function `romanize()`."""
    assert romanize(locale='en')(lambda: 'Алиса любит Кристиана')() == 'Alice lubit Kristiana'

# Generated at 2022-06-12 01:32:58.280574
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')(lambda: 'Привет, Мир!')
    assert result == 'Privyet, Mir!'


# Generated at 2022-06-12 01:33:09.438793
# Unit test for function romanize
def test_romanize():
    """Test that romanize Cyrillic text."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    p = Person('ru')
    assert p.romanized_full_name
    assert len(p.romanized_full_name) > 0

    p = Person('kk')
    assert len(p.romanized_full_name) > 0
    assert len(p.romanized_full_name.split()) == 3

    p = Person('uk')
    assert len(p.romanized_full_name) > 0
    assert len(p.romanized_full_name.split()) == 3

    p = Person('ru')
    assert p.romanized_full_name(gender=Gender.MALE)