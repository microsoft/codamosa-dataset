

# Generated at 2022-06-12 01:25:02.511701
# Unit test for function romanize
def test_romanize():
    def _romanize():
        assert romanize()('АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ') == 'ABCDEFGHIJKLMNOPRSTUFHTSCHSHHIIIEIUIA'


# Generated at 2022-06-12 01:25:06.898538
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: "привет")() == "privet"
    assert romanize('ru')(lambda x: "Дядя Ваня")() == "Dyadya Vanya"



# Generated at 2022-06-12 01:25:18.105244
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import TextSpecification
    txt = TextSpecification(locale='ru')
    assert txt.romanize_text('Привет, как дела?') == 'Privet, kak dela?'
    assert txt.romanize_text('e') == 'e'
    assert txt.romanize_text('Как дела') == 'Kak dela'
    assert txt.romanize_text('Спасибо', 'Не за что') == 'Spasibo Nye za chto'
    assert txt.romanize_text('Привет') == 'Privet'



# Generated at 2022-06-12 01:25:25.323787
# Unit test for function romanize
def test_romanize():
    try:
        import unittest.mock as mock
    except ImportError:  # pragma: no cover
        import mock

    # import time
    @romanize('ru')
    def foo():
        return 'Не спала ночь'

    assert foo() == 'Ne spala noch'

    @romanize('uk')
    def foo():
        return 'Не спала ніч'

    assert foo() == 'Ne spala nich'



# Generated at 2022-06-12 01:25:27.634367
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def hello():
        return "Привет"

    assert hello() == 'Privet'

# Generated at 2022-06-12 01:25:28.222695
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-12 01:25:32.521759
# Unit test for function romanize
def test_romanize():
    """Testing function romanize."""
    from mimesis.builtins import Person

    p = Person('uk')
    orig = p.name()
    x = romanize(locale='uk')(Person._name)('F')
    assert x == orig



# Generated at 2022-06-12 01:25:34.621856
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def foo():
        return 'привет мир!'

    assert foo() == 'privet mir!'


test_romanize()

# Generated at 2022-06-12 01:25:36.360432
# Unit test for function romanize
def test_romanize():
    str = ""
    assert romanize("ru")(str) == ""



# Generated at 2022-06-12 01:25:45.532422
# Unit test for function romanize
def test_romanize():
    def _test_romanize(func):
        for lang in ['ru', 'uk', 'kk']:
            assert func(lang) == 'привет мир'

    func = romanize('ru')(lambda x: 'привет мир')
    _test_romanize(func)

    func = romanize('uk')(lambda x: 'привет мир')
    _test_romanize(func)

    func = romanize('kk')(lambda x: 'привет мир')
    _test_romanize(func)

    func = romanize('st')(lambda x: 'привет мир')

# Generated at 2022-06-12 01:25:56.109256
# Unit test for function romanize
def test_romanize():
    result = romanize()(lambda x: 'Привіт світ! Як справи?')()
    assert result == 'Pryvit svit! Yak spravy?'



# Generated at 2022-06-12 01:26:02.238620
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Россия')().lower() == 'rossiya'
    assert romanize('uk')(lambda: 'Україна')().lower() == 'ukrayina'
    assert romanize('kk')(lambda: 'Қазақстан')().lower() == 'qazaqstan'

# Generated at 2022-06-12 01:26:04.317501
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'



# Generated at 2022-06-12 01:26:05.984668
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'превед')() == 'priyed'

# Generated at 2022-06-12 01:26:07.510457
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize()

# Generated at 2022-06-12 01:26:18.743990
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.localization import LOCALE_EN

    p = Person(LOCALE_EN)
    assert p._romanized(str(p.full_name('ru', Gender.FEMALE))), 'Irina Richardson'
    assert p._romanized(str(p.full_name('uk', Gender.MALE))), 'Леонид Олегович'
    assert p._romanized(str(p.full_name('kk', Gender.FEMALE))), 'Нуржан Мустафаевна'

# Generated at 2022-06-12 01:26:23.366170
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda *x, **kwargs: 'абвгдежзийклмнопрст')() == 'abvgdeezilkmnoppt'
    assert romanize('ru')(lambda *x, **kwargs: 'абвгдежзийклмнопрст')() == 'abvgdeezilkmnoppt'
    assert romanized('ru')(lambda *x, **kwargs: 'абвгдежзийклмнопрст')() == 'abvgdeezilkmnoppt'

# Generated at 2022-06-12 01:26:27.555964
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("бандитский") == "banditskiy"
    assert romanize("bb")("бандитский") == "banditskiy"

# Generated at 2022-06-12 01:26:29.142154
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rd(x):
        return x
    assert callable(rd)

# Generated at 2022-06-12 01:26:32.239088
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    @romanize(locale='ru')
    def _roman_test(phrase: str) -> str:
        return phrase

    assert _roman_test('Привет, мир!') == 'Privet, mir!'



# Generated at 2022-06-12 01:26:45.371777
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None
    assert romanize('ru') is not None



# Generated at 2022-06-12 01:26:51.690217
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda x: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize(locale='uk')(lambda x: 'Привіт, Світе!')() == 'Pryvit, Svite!'
    assert romanize(locale='kk')(lambda x: 'Сәлем Дүние!')() == 'Sälem Dünie!'

# Generated at 2022-06-12 01:26:57.344840
# Unit test for function romanize
def test_romanize():
    def test(func):
        """Decorator for unit test."""
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            data = func(*args, **kwargs)
            # For example:
            #         @romanize('ru')
            #         def test(self):
            #             return 'Привет'
            #
            #         assert test(self) == 'Privet'
            try:
                assert data[0] == data[1]
            except UnsupportedLocale:
                pass

        return wrapper

    return test

# Generated at 2022-06-12 01:27:02.087496
# Unit test for function romanize
def test_romanize():
    """Unittest for romanize"""
    import os

    os.environ['MIMESIS_LOCALE'] = "ru"

    from mimesis import Person
    person = Person()

    assert person.full_name(romanize=False) == person.full_name(romanize=True)
    assert person.full_name(romanize=False) == "Олексій Мартин"

# Generated at 2022-06-12 01:27:13.754037
# Unit test for function romanize

# Generated at 2022-06-12 01:27:25.710255
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize(locale='ru')
    def rus_text(*args, **kwargs):
        return 'Привет, Мир!'

    assert rus_text() == 'Privet, Mir!'

    @romanize(locale='uk')
    def uk_text(*args, **kwargs):
        return 'Привіт, Світ!'

    assert uk_text() == 'Pryvit, Svit!'

    @romanize(locale='kk')
    def kk_text(*args, **kwargs):
        return 'Сәлем, Дүние!'

    assert kk_text() == 'Sälem, Dünie!'

# Generated at 2022-06-12 01:27:28.533590
# Unit test for function romanize
def test_romanize():
    @romanize(locale='kk')
    def test_word():
        return 'hello'

    assert test_word() == 'сәлеметсізбе'

# Generated at 2022-06-12 01:27:37.857738
# Unit test for function romanize
def test_romanize():
    func = lambda x: x

    assert romanize()(func)('Привіт, мій друг') == 'Pryvit, mij druh', 'Привіт, мій друг'
    assert romanize('ru')(func)('Привет, мой друг') == 'Privet, moj drug', 'Привет, мой друг'

# Generated at 2022-06-12 01:27:44.297418
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address

    romanizers = (
        'city',
        'region',
        'postal_code',
        'street_name',
        'street_suffix',
    )

    for lang in Language:
        addr = Address(lang.value)

        for romanizer in romanizers:
            assert romanize(addr.lang.value)(getattr(addr, romanizer))()

# Generated at 2022-06-12 01:27:47.719888
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def roman_func(russian_string):
        return russian_string

    assert roman_func('Николай') == 'Nikolay'



# Generated at 2022-06-12 01:28:10.370611
# Unit test for function romanize
def test_romanize():
    assert romanize() and romanized()



# Generated at 2022-06-12 01:28:16.520351
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet

    a = Address('ru')
    i = Internet('ru')

    english_word = a.word(locale='en')
    assert english_word == i.word(locale='en')

    russian_word = a.word(locale='ru')
    assert russian_word != i.word(locale='ru')
    assert i.word(locale='ru') == russian_word.replace('г', 'g')
    # On the letter `г` which is used in words like `Москва`
    # internet provider transliterate `г` into `g`.
    # Now we need to check that all russian word contains latin letters.

# Generated at 2022-06-12 01:28:25.509633
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanize('tat')(lambda: 'Сәлем')() == 'Sәlem'
    assert romanize('kaz')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-12 01:28:26.774455
# Unit test for function romanize
def test_romanize():
    assert romanized('привет') == 'privet'

# Generated at 2022-06-12 01:28:30.405503
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Мимезис')() == 'Mimezis'
    assert romanize('kk')(lambda: 'Құрылғы')() == 'Qurylğy'
    assert romanize('uk')(lambda: 'Космос')() == 'Kosmos'

# Generated at 2022-06-12 01:28:35.131228
# Unit test for function romanize
def test_romanize():
    romanize_func = romanize(locale='ru')

    @romanize_func
    def romanize_text(*args, **kwargs):
        return 'Привет, мир!'

    assert romanize_text() == 'Privet, mir!'

# Generated at 2022-06-12 01:28:38.208382
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: "Привет, мир!")() == "Privet, mir!"

# Generated at 2022-06-12 01:28:47.395173
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize()(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize()(lambda: 'Hello, world!')() == 'Hello, world!'
    assert romanize()(lambda: 'Hello, world!!')() == 'Hello, world!!'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:28:49.003206
# Unit test for function romanize
def test_romanize():
    r = romanize('ru')(lambda: 'фыва')()
    assert r == 'fiva'

# Generated at 2022-06-12 01:28:52.630438
# Unit test for function romanize
def test_romanize():
    """ Unit test for romanize.
    """
    from mimesis.builtins import Code

    code = Code('ru')
    code.romanize = romanize('ru')(code.romanize)

    code.romanize()
    code.romanize(quantity=2)

# Generated at 2022-06-12 01:29:42.567703
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    import mimesis.builtins.text as text
    gen = text.Text()
    assert gen._romanize('Hello') == 'Hello'
    assert gen._romanize('Привет') == 'Privet'
    assert gen._romanize('Привет World') == 'Privet World'

# Generated at 2022-06-12 01:29:51.835480
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    # Test romanized decorator.
    class TestPerson(Person):
        @romanize()
        def full_name(self, gender: Gender = None) -> str:
            return super().full_name(gender)

    class TestAddress(Address):
        @romanize()
        def city(self) -> str:
            return super().city()

        @romanize()
        def street_name(self):
            return super().street_name()

    tp = TestPerson()
    assert tp.full_name()
    assert tp.full_name(Gender.FEMALE)

    ta = TestAddress()
    assert ta.city()
    assert ta.street_

# Generated at 2022-06-12 01:29:53.211783
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Hello Привет')() == 'Hello Privet'

# Generated at 2022-06-12 01:29:58.976491
# Unit test for function romanize
def test_romanize():
    for i in data.ROMANIZATION_DUK:
        assert data.ROMANIZATION_DUK[i] == romanized('uk')(i)


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:30:07.116577
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, приветы!')() == 'Privyet, privety!'
    assert romanized('uk')(lambda: 'Давай, давайте!')() == 'Davai, davaitye!'
    assert romanized('kk')(lambda: 'Екер, екерлер!')() == 'Yetker, yetkerler!'

# Generated at 2022-06-12 01:30:09.407439
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'абвгдеё') == 'abvgdye'

# Generated at 2022-06-12 01:30:20.648875
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Мимесис')() == 'Mimesis'
    assert romanize('ru')(lambda: 'Шахматы')() == 'Shakhmaty'
    assert romanize('ru')(lambda: 'ШАХМАТЫ')() == 'SHAKHMATY'
    assert romanize('ru')(lambda: 'шахматы')() == 'shakhmaty'
    assert romanize('ru')(lambda: 'Шахматы')() == 'Shakhmaty'
    assert romanize('ru')(lambda: 'Шахматы')() == 'Shakhmaty'

# Generated at 2022-06-12 01:30:28.842171
# Unit test for function romanize
def test_romanize():  # noqa: F811
    from mimesis.builtins import RussianSpecProvider

    romanizer = romanize('ru')(RussianSpecProvider().field)
    assert romanizer() == 'АаБбВвГгҐґДдЕеЄєЄєЖжЗзИиІіІіЇїКкЛлМмНнОоПпРрСсТтУуФфХхЦцЧчШшЩщЬьЮюЯя'

# Generated at 2022-06-12 01:30:30.378767
# Unit test for function romanize
def test_romanize():
    result = "Some romanized text"
    assert romanize()(lambda: result) == result

# Generated at 2022-06-12 01:30:37.763285
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda: 'сәлем')() == 'salem'

    @romanize('kk')
    def kk():
        return "Салем"

    assert kk() == 'Salem'

# Generated at 2022-06-12 01:32:34.814189
# Unit test for function romanize
def test_romanize():
    from mimesis import Datetime

    dt = Datetime()
    result_a = dt.date()
    assert result_a == '04-11-1971'

    @romanize('ru')
    def result_b():
        return '04-11-1971'
    assert result_b() == '04-11-1971'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:32:46.700433
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    # Expected: 'Русский алфавит'
    result = romanize(locale='ru')(lambda: 'Русский алфавит')
    assert result == 'Russkiy alfavit'

    # Expected: 'Український алфавіт'
    result = romanize(locale='uk')(lambda: 'Український алфавіт')
    assert result == 'Ukrainskiy alfavit'

    # Expected: 'Қазақ әліп

# Generated at 2022-06-12 01:32:56.973171
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()
    assert romanize.__name__ == 'romanize'
    assert romanize.__module__ == 'mimesis.builtins.decorators'
    assert romanize.__doc__ == 'Romanize the cyrillic text.\n\n    ' \
                               'Transliterate the cyrillic script into ' \
                               'the latin alphabet.\n\n    .. note:: At ' \
                               'this moment it works only for `ru`, ' \
                               '`uk`, `kk`.\n\n    :param locale: Locale code.\n    :return: Romanized text.\n    '

# Generated at 2022-06-12 01:33:04.934962
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda : 'Россия')() == 'Rossiya'

    assert romanize('ru')(lambda : 'Россия')() == 'Rossiya'
    assert romanize('uk')(lambda : 'Россия')() == 'Rossiya'
    assert romanize('kk')(lambda : 'Россия')() == 'Rossiya'

    message = 'UnsupportedLocale: ja'
    try:
        romanize('ja')(lambda : 'Россия')()
    except Exception as err:
        assert str(err) == message

# Generated at 2022-06-12 01:33:15.129320
# Unit test for function romanize
def test_romanize():
    """Test for romanize_deco is working or not."""
    # String which can be Romanized
    roman_string = "Я знаю, что все это фигня, и мне очень плевать!"
    # String which can't be Romanized
    not_roman_string = '今日は、世界！'

    # Function with romanize decorator and no decorator
    # has (should have) different result
    def roman_func():
        return roman_string

    def not_roman_func():
        return not_roman_string

    assert roman_func() != roman_string

# Generated at 2022-06-12 01:33:21.373341
# Unit test for function romanize
def test_romanize():
    """Tests for romanize func."""
    result = romanize('ru')(lambda: 'привет')
    assert result == 'privet'
    result = romanize('uk')(lambda: 'привіт')
    assert result == 'pryvit'
    result = romanize('kk')(lambda: 'Сәлем')
    assert result == 'Salem'

# Generated at 2022-06-12 01:33:24.634376
# Unit test for function romanize
def test_romanize():
    """
    Test romanize
    """
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-12 01:33:25.108577
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-12 01:33:28.702476
# Unit test for function romanize
def test_romanize():
    # Assert that romanize works
    from mimesis.enums import Locale
    from mimesis import Person

    @romanized(Locale.RU)
    def romanize_ru(person: Person) -> str:
        return person.full_name(gender=None)

    assert romanize_ru(Person(Locale.RU)) == 'Olesya Romashkina'

# Generated at 2022-06-12 01:33:33.007809
# Unit test for function romanize
def test_romanize():
    @romanized()
    def function(txt: str = '') -> str:
        return txt

    default = function('Поднялся туман на реке.')
    assert default == 'Podnjalsja tumãn na reke.'

    rus = function('Поднялся туман на реке.', 'ru')
    assert rus == 'Podnjalsja tumãn na reke.'

    ukr = function('Піднявся туман на ріці.', 'uk')
    assert ukr == 'Pidnjavsja tumãn na ritcï.'
