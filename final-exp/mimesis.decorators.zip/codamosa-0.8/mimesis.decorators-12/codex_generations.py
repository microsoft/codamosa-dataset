

# Generated at 2022-06-12 01:24:54.157592
# Unit test for function romanize
def test_romanize():
    """Text func romanize."""
    @romanize('ru')
    def get_russian_text():
        return 'Привет, Мир!'

    assert get_russian_text() == 'Privet, Mir!'

# Generated at 2022-06-12 01:25:02.103451
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'АБГД')() == 'ABGD'
    assert romanize('uk')(lambda: 'АБГД')() == 'ABHD'
    assert romanize('kk')(lambda: 'АБГД')() == 'ABKDT'
    assert romanize('kk')(lambda: 'АБГД')() == romanized('kk')(lambda: 'АБГД')()

# Generated at 2022-06-12 01:25:02.738965
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-12 01:25:03.749496
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-12 01:25:10.259973
# Unit test for function romanize
def test_romanize():
    import unittest
    IMG1 = 'Черный Кот под луной.jpg'
    IMG2 = 'Черный Кот под луной'
    TEXT = 'За холмами, за долами не бачу синього моря, бачу лише море сонця і вітру.'

# Generated at 2022-06-12 01:25:21.361902
# Unit test for function romanize
def test_romanize():
    err = UnsupportedLocale('ru')
    assert romanize('ru')(lambda: 'Пример')() == 'Primer'
    assert romanize('ru')(lambda: 'Пример')() == romanized('ru')(lambda: 'Пример')()
    assert romanized('ru')(lambda: 'Пример')() == romanized('uk')(lambda: 'Пример')()
    assert romanized('ru')(lambda: 'Пример')() == romanized('kk')(lambda: 'Пример')()

# Generated at 2022-06-12 01:25:22.768496
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("привет") == "privet"

# Generated at 2022-06-12 01:25:25.498264
# Unit test for function romanize
def test_romanize():
    # For function romanize
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-12 01:25:35.420673
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Я')() == 'Ya'
    assert romanize()(lambda: 'Ў')() == 'O'
    assert romanize()(lambda: 'ф')() == 'f'
    assert romanize('uk')(lambda: 'І')() == 'Yi'
    assert romanize('uk')(lambda: 'Ѓ')() == 'G'
    assert romanize('uk')(lambda: 'И')() == 'Y'
    assert romanize('kk')(lambda: 'І')() == 'Ã'
    assert romanize('kk')(lambda: 'і')() == 'ã'


if __name__ == '__main__':
    test_romanize()
    print('Internal Romanize Test Success.')

# Generated at 2022-06-12 01:25:41.077373
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == "Sälem"

# Generated at 2022-06-12 01:25:50.485834
# Unit test for function romanize
def test_romanize():

    @romanize('en')
    def check():
        return 'Салихов Александр Игоревич'

    assert check() == 'Salikhov Aleksandr Igorevich'

# Generated at 2022-06-12 01:25:59.960900
# Unit test for function romanize
def test_romanize():
    def test_function():
        return 'Символ'

    @romanize()
    def test_function_with_deco():
        return 'Символ'

    @romanize(locale='ru')
    def test_function_with_deco_ru():
        return 'Символ'

    @romanize(locale='uk')
    def test_function_with_deco_uk():
        return 'Символ'

    @romanize(locale='kk')
    def test_function_with_deco_kk():
        return 'Символ'

    assert test_function() == 'Символ'
    assert test_function_with_deco() == 'Simvol'
    assert test_function

# Generated at 2022-06-12 01:26:03.994030
# Unit test for function romanize
def test_romanize():
    # Test function
    @romanize(locale='ru')
    def example(words):
        return words

    assert example('абв') == 'abv'
    assert example('абв-абв') == 'abv-abv'



# Generated at 2022-06-12 01:26:15.583619
# Unit test for function romanize

# Generated at 2022-06-12 01:26:18.940388
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    russian = RussiaSpecProvider('ru')
    assert russian.personal.full_name() == 'Андрей Андреевич Державин'

# Generated at 2022-06-12 01:26:23.509444
# Unit test for function romanize
def test_romanize():
    def f(x):
        return x

    func = romanize('ru')(f)
    assert func('*строка*') == '*stroka*'

    # For the function without decorators
    func = f
    assert func('*строка*') == '*строка*'

# Generated at 2022-06-12 01:26:32.861804
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'абвгдеёжзийклмнопрст')() == 'abvgdeejziiklmnoprst'
    assert romanized('uk')(lambda: 'абвгґдеєжзиіїйклмнопрст')() == 'abvghdjejziijkiiklmnoprst'
    assert romanized('kk')(lambda: 'абвгғдеёжзіийкқлмнңоөпрст')() == 'abvgghdyejziijkklmnnoopprst'

# Generated at 2022-06-12 01:26:43.596436
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='en')(lambda: 'Привет')() == 'Priv'
    assert romanize(locale='en')(lambda: 'Hello')() == 'Hello'
    assert romanize(locale='en')(lambda: 'Hello')() == 'Hello'
    assert romanize(locale='en')(lambda: 'Hello')() == 'Hello'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-12 01:26:48.089207
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'приветствую')() == 'privetstvuyu'
    assert romanize('en')(lambda: 'test')() == 'test'



# Generated at 2022-06-12 01:26:48.985445
# Unit test for function romanize
def test_romanize():
    assert romanize('en')

# Generated at 2022-06-12 01:27:03.796876
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    @romanize(locale='ru')
    def _data():
        return 'Здравствуйте, мир!'

    assert _data() == 'Zdravstvuyte, mir!'

    @romanize(locale='uk')
    def _data():
        return 'Доброго дня, світ!'

    assert _data() == 'Dobroho dnia, svit!'

    @romanize(locale='kk')
    def _data():
        return 'сәлем, әлем'

    assert _data() == 'sælem, ælem'

# Generated at 2022-06-12 01:27:13.136345
# Unit test for function romanize
def test_romanize():
    assert callable(romanize(locale='ru'))
    assert callable(romanized(locale='ru'))


if __name__ == '__main__':
    # Unit test
    romanize_deco = romanize(locale='ru')
    romanized_deco = romanized(locale='ru')

    def test_cyrillic_to_latin():
        assert romanize_deco(func=test_cyrillic_to_latin)() == ''
        assert romanized_deco(func=test_cyrillic_to_latin)() == ''

    test_cyrillic_to_latin()

# Generated at 2022-06-12 01:27:22.081823
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_me(text: str) -> str:
        return text


    assert romanize_me('Привет') == 'Privet'
    assert romanize_me('Журнал') == 'Zhurnal'
    assert romanize_me('Здравствуйте') == 'Zdravstvujte'
    assert romanize_me('Православие') == 'Pravoslavie'

# Generated at 2022-06-12 01:27:28.516149
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Лучше целоваться с брюнеткой, чем греться с рыжеволосой')() == \
        'Luchshe tselovat\'sa s brunetkoj, chem gret\'sa s ryzhëvolosoj'



# Generated at 2022-06-12 01:27:30.674022
# Unit test for function romanize
def test_romanize():
    text = romanize()(lambda *args, **kwargs: 'Привіт!')()
    assert text == 'Pryvit!'

# Generated at 2022-06-12 01:27:37.751006
# Unit test for function romanize
def test_romanize():
    from mimesis.schema import Field

    class Romanizer(Field):
        def setup(self, **kwargs):
            self._data = ''.join([
                self.ctx.random.choice(data.COMMON_LETTERS.values())
                for _ in range(self.__seed__)
            ])

        @romanize(locale='en')
        def process(self):
            return self._data

    romanizer = Romanizer(seed=10, ctx=None)
    assert romanizer.process() == 'abcdabcdab'

# Generated at 2022-06-12 01:27:41.361577
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text

    mimesis.builtins.text.random.seed(42)
    mimesis.builtins.text.random.seed(42)
    assert mimesis.builtins.text.Text(locale='ru').romanize() == 'tq'

# Generated at 2022-06-12 01:27:51.773449
# Unit test for function romanize
def test_romanize():
    text = ['Строка', 'Hello', 'Привет']
    assert romanize('ru')(text[0]) == 'Stroka'
    assert romanize('uk')(text[0]) == 'Stroka'
    assert romanize('kk')(text[0]) == 'Stroka'

    assert romanize('ru')(text[1]) == 'Hello'
    assert romanize('uk')(text[1]) == 'Hello'
    assert romanize('kk')(text[1]) == 'Hello'

    assert romanize('ru')(text[2]) == 'Privjet'
    assert romanize('uk')(text[2]) == 'Priviet'
    assert romanize('kk')(text[2]) == 'Privet'

# Generated at 2022-06-12 01:27:58.975151
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    from mimesis.enums import Language
    from mimesis.providers.geography import Geography

    g = Geography(Language.EN)
    text = g.address()

    @romanize('kk')
    def kazakh_function():
        return text

    @romanize('ru')
    def russian_function():
        return text

    assert isinstance(kazakh_function(), str)
    assert isinstance(russian_function(), str)
    assert len(kazakh_function()) == len(text)
    assert len(russian_function()) == len(text)

# Generated at 2022-06-12 01:28:01.311547
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'привет')() == 'privet'



# Generated at 2022-06-12 01:28:25.811959
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def r():
        return 'Привет, как дела?'

    txt = r()
    assert txt == 'Privet, kak dela?'

# Generated at 2022-06-12 01:28:26.760319
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'гривня')() == 'grivnya'

# Generated at 2022-06-12 01:28:28.641215
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-12 01:28:34.384686
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func(n):
        return n
    txt = 'Далеко-далеко за словесными горами'
    romanized = func(txt)
    assert romanized == 'Daleko-daleko za slovesnymi gorami'

# Generated at 2022-06-12 01:28:38.252583
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize('ru')
    def foo():
        return 'Привет, Мир!'
    assert foo() == 'Privet, Mir!'

# Generated at 2022-06-12 01:28:40.007362
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    p = Person('ru')
    assert p.romanize(p.name(gender='male')) == "Aleksey"



# Generated at 2022-06-12 01:28:43.239137
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'привет мир'.upper()) == 'Privet mir'



# Generated at 2022-06-12 01:28:44.451397
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(data.Data('ru').integer)() == '23'

# Generated at 2022-06-12 01:28:54.255490
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    cyrillic_characters = [
        'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й',
        'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф',
        'х', 'ц', 'ч', 'ш', 'щ', 'ъ', 'ы', 'ь', 'э', 'ю', 'я',
    ]

# Generated at 2022-06-12 01:28:56.756419
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='asd')(lambda: 'Say hello') == 'Say hello'

    assert romanize(locale='ru')(lambda: 'Привет') == 'Privet'

# Generated at 2022-06-12 01:29:50.627361
# Unit test for function romanize
def test_romanize():
    assert romanize()('тест') == 'test'
    assert romanize()('ТЕСТ') == 'TEST'
    assert romanize()('тест!') == 'test!'
    assert romanize()('ТЕСТ!') == 'TEST!'
    assert romanize()('тест1') == 'test1'
    assert romanize()('ТЕСТ1') == 'TEST1'

    assert romanize(locale='uk')('тест') == 'test'

    assert romanized()('кто такой') == 'kto takoj'

    assert romanize('ru')('тест') == 'test'

# Generated at 2022-06-12 01:29:59.083592
# Unit test for function romanize
def test_romanize():
    import unittest

    class RomanizeTestCase(unittest.TestCase):

        def setUp(self):
            self.text = 'Персональная информация'

        def test_callable(self):
            @romanize()
            def r_text():
                return self.text

            result = r_text()
            self.assertEqual(
                result,
                'Personalnaya informatsiya'
            )

    suite = unittest.TestLoader().loadTestsFromTestCase(RomanizeTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-12 01:30:03.294992
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def foo():
        return 'Привет, мир!'

    text = foo()
    assert text == 'Privet, mir!'



# Generated at 2022-06-12 01:30:06.131386
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize(locale='zh')(lambda: 'hello'), Callable)


# Generated at 2022-06-12 01:30:10.839987
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""

    @romanize('ru')
    def do_romanize(text):
        return text

    assert do_romanize('я иду домой') == 'ya idu domoy'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:30:19.374727
# Unit test for function romanize
def test_romanize():

    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('ru')(lambda: 'привет')() == 'privet'
    assert romanized('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanized('kk')(lambda: 'Сәлем!')() == 'Salem!'



# Generated at 2022-06-12 01:30:24.285428
# Unit test for function romanize
def test_romanize():
    def f():
        return 'Мимесис'

    @romanize('ru')
    def f1():
        return 'Мимесис'

    assert f1() == 'Mimesis'

# Generated at 2022-06-12 01:30:27.080573
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'йцукен')() == 'ytsuken'
    assert romanize('ru')(lambda x: 'йцукен')() != 'ytsuken '

# Generated at 2022-06-12 01:30:31.007361
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'тест')() == 'test'
    assert romanize('uk')(lambda: 'тест')() == 'test'
    assert romanize('kk')(lambda: 'тест')() == 'test'

# Generated at 2022-06-12 01:30:35.055708
# Unit test for function romanize
def test_romanize():
    text = romanize('ru')(lambda: 'Привет')()
    assert text == 'Privet'

# Generated at 2022-06-12 01:32:28.674292
# Unit test for function romanize
def test_romanize():
    import mimesis.random
    import mimesis.api

    random = mimesis.random.Random()
    API = mimesis.api.API('ru')

    API.romanize = romanize('ru')
    API.romanized = romanized('ru')

    assert API.romanize(random.text()) == API.romanized(random.text())

# Generated at 2022-06-12 01:32:31.104575
# Unit test for function romanize
def test_romanize():
    txt = romanize()(lambda: 'Привет, как дела?')()
    assert txt == 'Privet, kak dela?'

# Generated at 2022-06-12 01:32:33.548159
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def roman(message: str='') -> str:
        return message

    assert roman('Привет!') == 'Privet!'

# Generated at 2022-06-12 01:32:37.029509
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Объектная модель')() == 'Obektnaia model'



# Generated at 2022-06-12 01:32:41.697787
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanized_name():
        return 'Кирилл'

    result = romanized_name()
    assert result == 'Kirill'

# Generated at 2022-06-12 01:32:44.874859
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('На');
    assert romanize('uk')('На');
    assert romanize('kk')('За');
    assert romanize('kk')('ул.Риддера');

# Generated at 2022-06-12 01:32:50.918345
# Unit test for function romanize
def test_romanize():
    if __name__ == "__main__":
        test = romanize("ru")


# Generated at 2022-06-12 01:32:55.664404
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda: 'Україна')() == 'Ukrayina'
    assert romanize('kk')(lambda: 'Қазақстан')() == 'Qazaqstan'
    assert romanize()(lambda: 'Беларусь')() == 'Belarus'

# Generated at 2022-06-12 01:32:58.170385
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "Привет!")().lower() == 'privet!'

# Generated at 2022-06-12 01:32:58.776589
# Unit test for function romanize
def test_romanize():
    pass