

# Generated at 2022-06-12 01:24:55.701522
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'привет'

    assert foo() == 'privet'



# Generated at 2022-06-12 01:25:07.519144
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda x: 'Мимимишечка чебуречка') == 'Mimimishechka cheburechka'
    assert romanize('ru')(lambda x: 'Мимимишечка чебуречка') == 'Mimimishechka cheburechka'
    assert romanize('ru')(lambda x: 'Мiмiмiшечка чебуречка') == 'MiMIMishECHka chebureCHka'

# Generated at 2022-06-12 01:25:11.383429
# Unit test for function romanize
def test_romanize():
    """Test function romanize"""

    @romanize(locale='ru')
    def get_name():
        return 'Иван Алексеевич'

    assert get_name() == 'Ivan Alekseevich'

# Generated at 2022-06-12 01:25:19.392980
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.base import BaseProvider

    class Test_Provider(BaseProvider):
        def __init__(self, locale: str = 'en'):
            super().__init__(locale)

        @romanize('ru')
        def romanize_me(self, *args, **kwargs) -> str:
            return 'Привет'

    p = Test_Provider()
    assert p.romanize_me() == 'Privet'



# Generated at 2022-06-12 01:25:22.151457
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test(random: Callable) -> str:
        return random.text()

    assert test(random=data) is not None
    assert test(random=data) != ''

# Generated at 2022-06-12 01:25:33.172375
# Unit test for function romanize
def test_romanize():
    class Cyrillic:
        @romanize('ru')
        def r_ru(self):
            return 'Привет'

        @romanize('uk')
        def r_uk(self):
            return 'Привіт'

        @romanize('kk')
        def r_kk(self):
            return 'Сәлем'

        @romanize('ru')
        def r_ru_ascii(self):
            return 'Привет' + '!'

        @romanize('uk')
        def r_uk_ascii(self):
            return 'Привіт' + '!'


# Generated at 2022-06-12 01:25:37.749470
# Unit test for function romanize
def test_romanize():
    """Test function romanize"""
    for i in data.ROMANIZATION_DICT.keys():
        assert data.ROMANIZATION_DICT[i]
    assert not data.ROMANIZATION_DICT.get('zz')

# Generated at 2022-06-12 01:25:42.292662
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Cyrillic

    @romanized('uk')
    def say_hello(self) -> str:
        return self.random_element(self.data['greetings'])

    c = Cyrillic()
    result = say_hello(c)
    assert result in c.data['greetings']

# Generated at 2022-06-12 01:25:44.952757
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, сука!')() == 'Privet, suka!'
    assert romanize()(lambda: 'СУКА')() == 'SUKA'

# Generated at 2022-06-12 01:25:49.401674
# Unit test for function romanize
def test_romanize():
    @romanize()
    def name():
        return 'Дмитрий'

    assert name() == 'Dmitrii'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:25:58.008062
# Unit test for function romanize
def test_romanize():
    from mimesis import Personal
    from mimesis.enums import Gender

    p = Personal('ru')
    assert p.full_name(gender=Gender.MALE) == 'Арсений Гришко'

# Generated at 2022-06-12 01:26:08.803549
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('ru')(lambda: 'Привет как дела!')() == 'Privet kak dela!'
    assert romanized('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanized('uk')(lambda: 'Привіт як справи!')() == 'Pryvit yak spravy!'
    assert romanized('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-12 01:26:19.731324
# Unit test for function romanize
def test_romanize():
    assert data.COMMON_LETTERS[' '] == ' '

# Generated at 2022-06-12 01:26:24.890277
# Unit test for function romanize
def test_romanize():
    """Tests for romanize."""
    assert romanized('ru')(lambda: 'игорь') == 'Игорь'
    assert romanized('uk')(lambda: 'Слава') == 'Slava'
    assert romanized('kk')(lambda: 'Ержан') == 'Erjan'

# Generated at 2022-06-12 01:26:26.813168
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()

# Generated at 2022-06-12 01:26:30.796633
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet

    i = Internet('ru')
    text1 = i.username(gender=Gender.MALE)

    t1 = ''.join([data.ROMANIZATION_DICT['ru'][i] for i in text1])
    t2 = i.username(gender=Gender.MALE)

    assert t1 == t2

    with pytest.raises(UnsupportedLocale):
        i = Internet('en')
        i.username(gender=Gender.MALE)

# Generated at 2022-06-12 01:26:33.572366
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def ru():
        return 'АБВГД'

    assert ru() == 'ABVGD'

# Generated at 2022-06-12 01:26:42.082127
# Unit test for function romanize
def test_romanize():
    test_ru = romanize('ru')(lambda: 'Иванов')
    test_uk = romanize('uk')(lambda: 'Іванов')
    test_kk = romanize('kk')(lambda: 'Іванов')

    # Assert for ru
    assert test_ru == 'Ivanov', 'Romanization error.'

    # Assert for uk
    assert test_uk == 'Ivano\'v', 'Romanization error.'

    # Assert for kk
    assert test_kk == 'Ivanov', 'Romanization error.'

# Generated at 2022-06-12 01:26:50.222919
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'ЖЕНЯ')() == 'ZHENYA'
    assert romanized(locale='uk')(lambda: 'ЮЛІЯ')() == 'JULIJA'
    assert romanized(locale='kk')(lambda: 'ЖЕНЯ')() == 'JENJA'
    assert romanized(locale='zz')(lambda: 'ЖЕНЯ')() == 'ЖЕНЯ'


test_romanize()

# Generated at 2022-06-12 01:26:54.650864
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize decorator."""
    @romanize()
    def string():
        return 'Я люблю Мимесис!'

    result = string()
    assert 'ya' in result
    assert 'lu' in result
    assert 'bl' in result


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-12 01:27:16.199089
# Unit test for function romanize
def test_romanize():
    # Test function
    @romanize('ru')
    def test_function():
        return 'Привет мир.'

    # Test method
    class TestRomanizeMethod(object):

        def __init__(self):
            self.name = 'test'

        @romanize('ru')
        def test_method(self):
            return 'Привет, мир.'

    # Test class
    @romanize('ru')
    class TestRomanizeClass(object):

        def __init__(self):
            self.name = 'test'

        def test_method(self):
            return 'Привет мир.'

    assert test_function() == 'Privet mir.'

# Generated at 2022-06-12 01:27:22.353965
# Unit test for function romanize
def test_romanize():
    @romanize(locale='uk')
    def romanize_test(text: str) -> str:
        return text

    txt = 'Привіт, як справи?'
    result = romanize_test(txt)
    expected_result = 'Pryvit, yak spravy?'
    assert result == expected_result

# Generated at 2022-06-12 01:27:30.603441
# Unit test for function romanize
def test_romanize():
    test_str = "Привет, как дела?"
    assert romanized('ru')(lambda: test_str)() == "Privet, kak dela?"
    test_str = "Вітаю, як справи?"
    assert romanized('uk')(lambda: test_str)() == "Vitaiu, iak spravy?"
    test_str = "Сәлем, как саласыз?"
    assert romanized('kk')(lambda: test_str)() == "Sälem, kak salasyz?"

# Generated at 2022-06-12 01:27:34.855464
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    from mimesis import Person

    person = Person()
    romanized_name = person.full_name(locale='ru')
    # Should be romanized
    assert romanized_name == romanized(romanized_name)

# Generated at 2022-06-12 01:27:39.911244
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    t = Text(Language.ENGLISH)

    @romanize(locale='ru')
    def romanized():
        return t.text(length=20)

    assert romanized()
    assert romanized()
    assert romanized()
    assert romanized()
    assert romanized()
    assert romanized()
    assert romanized()
    assert romanized()
    assert romanized()
    assert romanized()

# Generated at 2022-06-12 01:27:47.251337
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize(locale='ru')
    def russian_text():
        """Russian text."""
        return 'Ничего не произойдёт, когда я не сплю'

    # Value from the table
    assert russian_text() == 'Ni4ego ni4e priojdjo, kogda ja ni4e s4p4u'

# Generated at 2022-06-12 01:27:49.198494
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Human

    romanized_name = Human().name()
    assert romanized_name != Human().name()

# Generated at 2022-06-12 01:27:52.614729
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    person = Person()
    assert person.full_name(locale='ru') == 'Андрей Антонов'
    assert person.full_name() == 'Andrey Antonov'

# Generated at 2022-06-12 01:27:57.072323
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.general import General

    generator = General('ru')
    assert generator.romanize(generator.word()) == generator.romanize()
    assert generator.romanize(generator.full_name()) == generator.romanize()
    assert generator.romanize(generator.title()) == generator.romanize()
    assert generator.romanize(generator.ipv4()) == generator.ipv4()
    assert generator.romanize(generator.ipv6()) == generator.ipv6()

# Generated at 2022-06-12 01:27:59.786620
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def foo():
        return 'Ланита'
    assert foo() == 'Lanita'

    @romanized('uk')
    def bar():
        return 'Ланита'
    assert bar() == 'Lanita'

    @romanized('kk')
    def bat():
        return 'Ланита'
    assert bat() == 'Lanita'



# Generated at 2022-06-12 01:28:26.733780
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test(a, b):
        return a * b

    txt = 'Привет, мир!'
    txt = txt.replace(',', '')
    txt = txt.replace('!', '')
    romanized_txt = test(txt, 2)
    assert romanized_txt == 'Privet mir Privet mir'



# Generated at 2022-06-12 01:28:29.806592
# Unit test for function romanize
def test_romanize():
    # Internal function for romanize
    def _test_romanize(func: Callable):
        string = func()
        assert isinstance(string, str)
        assert len(string) > 0

    _test_romanize(romanize)



# Generated at 2022-06-12 01:28:34.182036
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    @romanize()
    def get_text():
        return 'Привіт, світ!'
    assert get_text() == 'Pryvit, svit!'



# Generated at 2022-06-12 01:28:42.043883
# Unit test for function romanize
def test_romanize():
    def test_func(locale: str) -> str:
        return 'Привет, мой друг!'

    decorated_function = romanize(locale='ru')(test_func)
    assert decorated_function('ru') == 'Privet, moy drug!'

    decorated_function = romanize(locale='uk')(test_func)
    assert decorated_function('uk') == 'Pryvit, moy druh!'

    decorated_function = romanize(locale='kk')(test_func)
    assert decorated_function('kk') == 'Привет, мой друг!'

# Generated at 2022-06-12 01:28:44.270716
# Unit test for function romanize
def test_romanize():
    _romanize = romanize('ru')
    assert _romanize
    assert isinstance(_romanize, Callable)

# Generated at 2022-06-12 01:28:47.695944
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Спасибо за помощь!')() == 'Spasibo za pomoshh!'

# Generated at 2022-06-12 01:28:53.650816
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Семён Слепаков')() == 'Semyon SLEPAKOV'
    assert romanize('uk')(lambda: 'Семён Слепаков')() == 'Semen Slepakov'
    assert romanize('kk')(lambda: 'Семён Слепаков')() == 'Semen Slepakov'

# Generated at 2022-06-12 01:28:56.796418
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'

    @romanize('ru')
    def roman_meet():
        return 'привет'

    assert roman_meet() == 'privet'

# Generated at 2022-06-12 01:29:05.300585
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Слово')() == 'Slovo'
    assert romanize(locale='uk')(lambda: 'Слово')() == 'Slovo'
    assert romanize(locale='kk')(lambda: 'Слово')() == 'Slovo'
    assert romanized(locale='ru')(lambda: 'Слово')() == 'Slovo'
    assert romanized(locale='uk')(lambda: 'Слово')() == 'Slovo'
    assert romanized(locale='kk')(lambda: 'Слово')() == 'Slovo'

# Generated at 2022-06-12 01:29:11.438461
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    assert romanized(locale='ru')(lambda: 'пока')().startswith('pok')
    assert romanized(locale='uk')(lambda: 'привіт')().startswith('pryvyt')
    assert romanized(locale='kk')(lambda: 'привет')().startswith('privet')

# Generated at 2022-06-12 01:30:05.131968
# Unit test for function romanize
def test_romanize():
    for locale, text in {
        'ru': data.ROMANIZATION_DICT['ru']['━'],
        'uk': data.ROMANIZATION_DICT['uk']['\xa0'],
        'fr': data.COMMON_LETTERS['é'],
    }.items():
        assert romanize(locale)(text) == text

# Generated at 2022-06-12 01:30:15.837563
# Unit test for function romanize
def test_romanize():
    def romanize(key):
        alph = {s: s for s in ascii_letters + digits + punctuation}
        alph.update({
            **data.ROMANIZATION_DICT[locale],
            **data.COMMON_LETTERS,
        })

        return ''.join([alph[i] for i in key if i in alph])

    locale = 'ru'

    assert romanize('АБВГД') == 'ABVGD'

# Generated at 2022-06-12 01:30:16.978242
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    assert isinstance(romanize('ru'), Callable)

# Generated at 2022-06-12 01:30:22.582593
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    rsp = RussianSpecProvider()

    assert rsp.name().isascii() is False
    assert rsp.name(romanized=True).isascii() is True

# Generated at 2022-06-12 01:30:26.259957
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Всем привет!')() == 'Vsem privet!'
    assert romanized('ru')(lambda: 'Поехали!')() == 'Poehali!'

# Generated at 2022-06-12 01:30:31.270856
# Unit test for function romanize
def test_romanize():
    letters_only = 'abcdefghijklmnopqrstuvwxyz'
    letters_numbers = 'abcdef0123456789'
    letters_numbers_punctuation = 'abcdef0123456789!@#$%^&*()'

    result = ''.join([romanized()(letters_only),
                      romanized()(letters_numbers),
                      romanized()(letters_numbers_punctuation)])

    assert result == 'abcdef0123456789!@#$%^&*()abcdef0123456789abcdef0123456789!@#$%^&*()'


# Generated at 2022-06-12 01:30:37.233493
# Unit test for function romanize
def test_romanize():
    romanize_locale = data.romanized('ru')
    assert romanize_locale('Пан Прусак присадил прусак Петровичу.') == \
        'Pan Prusak prisadil prusak Petrovichu.'

# Generated at 2022-06-12 01:30:39.022316
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def roman():
        return 'Привет!'

    assert roman() == 'Privet!'

# Generated at 2022-06-12 01:30:42.713257
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    rsp = RussiaSpecProvider()

    assert rsp.full_name().lower() == rsp.full_name(romanize='ru').lower()

# Generated at 2022-06-12 01:30:52.162299
# Unit test for function romanize
def test_romanize():
    # test language with romanization
    assert romanized()('Проверка') == 'provjerka'
    assert romanized('en')('Проверка') == 'provjerka'

    # test language without romanization
    assert romanized('zh')('Проверка') == 'Проверка'

    # test with ascii symbols
    assert romanized()('Проверка 123') == 'provjerka 123'

    # test with punctuation
    assert romanized()('Проверка ,') == 'provjerka ,'

# Generated at 2022-06-12 01:32:44.977668
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanized(locale='ru')
    def some_fake_func():
        return data.FAKE_DATA['ru-RU']

    assert some_fake_func()
    assert callable(romanized)

# Generated at 2022-06-12 01:32:50.960025
# Unit test for function romanize
def test_romanize():
    romanize = {
        'ru': 'привет мир',
        'uk': 'привіт світ',
        'kk': 'сәлем дүние',
    }

    rom_dict = data.ROMANIZATION_DICT

    for locale in romanize:
        assert rom_dict[locale]['п'] == romanize[locale][0]
        assert rom_dict[locale]['в'] == romanize[locale][1]
        assert rom_dict[locale]['е'] == romanize[locale][2]
        assert rom_dict[locale]['т'] == romanize[locale][3]

# Generated at 2022-06-12 01:33:00.958905
# Unit test for function romanize
def test_romanize():
    from mimesis.schema import Field
    from mimesis.enums import Gender

    def generator(field_):
        first_name = field_.datetime.datetime(
            pattern='%d.%m.%Y',
            start=1830,
            end=1950)
        patronymic = field_.person.patronymic(
            gender=Gender.MALE,
            func=romanized('ru'))
        last_name = field_.person.surname(
            func=romanized('ru'))
        return '{}, {} {}'.format(last_name, first_name, patronymic)

    field = Field('en')
    gen = field.custom.generator(generator)
    gen()
    assert isinstance(gen(), str)

# Generated at 2022-06-12 01:33:08.275416
# Unit test for function romanize
def test_romanize():
    class Person(object):

        @romanize('ru')
        def get_address(self):
            return 'Санкт-Петербург, улица Сергея Есенина'

    person = Person()
    assert person.get_address() == 'Sankt-Peterburg, ulitsa Sergeya Esenina'

# Generated at 2022-06-12 01:33:15.318030
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет и мир')() == 'Privet i mir'
    assert romanize('uk')(lambda: 'Довгі загороди')() == 'Dovhi zahorody'
    assert romanize('kk')(lambda: 'Жоғары кеңістік')() == 'Jogary keñistik'
    assert romanize('ru')(lambda: 'Привет и мир')() == 'Privet i mir'

# Generated at 2022-06-12 01:33:25.583214
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""
    from string import ascii_letters, digits, punctuation
    from random import choice

    from mimesis import Person
    from mimesis.enums import Gender

    character = ascii_letters + digits + punctuation

    person = Person('ru')
    person.seed(12345)

    for _ in range(10):
        n = person.random.randint(1, 512)
        txt = ''.join([choice(character) for _ in range(n)])
        txt_cyrillic = person.full_name(gender=Gender.MALE)

# Generated at 2022-06-12 01:33:28.421920
# Unit test for function romanize
def test_romanize():
    @romanize()
    def a():
        return 'Первый текст на русском языке'

    assert a('ru') == 'Perviy tekst na russkom yazyke'



# Generated at 2022-06-12 01:33:36.700533
# Unit test for function romanize
def test_romanize():
    import string
    alphabet = string.ascii_letters + string.digits + string.punctuation
    assert len(alphabet) == 62
    assert len(data.ROMANIZATION_DICT['kk']) == 33
    assert len(data.COMMON_LETTERS) == 8
    assert len(data.ROMANIZATION_DICT['kk']) + len(data.COMMON_LETTERS) == 41

    from mimesis.builtins.text import Text
    text = Text('kk')
    # Test romanize on common letters
    for key in data.COMMON_LETTERS:
        text.romanized(key)

    # Test that there no letters from the alphabet
    # then romanize non-Roman letters

# Generated at 2022-06-12 01:33:39.696617
# Unit test for function romanize
def test_romanize():
    """Test romanize romanization."""
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person

    person = Person(locale='ru')
    assert romanized('ru')(person.full_name)(gender=Gender.FEMALE) == \
        "Svetlana Vasilyeva"

# Generated at 2022-06-12 01:33:43.971746
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Cryllic
    cryllic = Cryllic()

    @romanize('ru')
    def romanized_names():
        return cryllic.name()

    result_name = romanized_names()
    assert result_name