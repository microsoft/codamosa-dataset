

# Generated at 2022-06-23 20:47:44.837814
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Пример')().isalpha()

# Generated at 2022-06-23 20:47:52.525106
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_ru(word: str):
        return word
    s = 'Привет мир!'
    assert romanize_ru(s) == 'Privet mir!'

    @romanize('uk')
    def romanize_uk(word: str):
        return word
    s = 'Калевала мир!'
    assert romanize_uk(s) == 'Kalevalala mir!'

    @romanize('kk')
    def romanize_kk(word: str):
        return word
    s = 'Сәлем дүние!'
    assert romanize_kk(s) == 'Sälem dünie!'

# Generated at 2022-06-23 20:47:52.977290
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:47:54.660725
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "тест")() == "test"



# Generated at 2022-06-23 20:48:02.256791
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    @romanize(locale=Language.EN)
    def roman(item):  # pylint: disable=unused-variable
        return item
    assert roman('Privet') == 'Privet'

    @romanize(locale=Language.RU)
    def roman(item):  # pylint: disable=unused-variable
        return item
    assert roman('Привет') == 'Privet'

    @romanize(locale=Language.UK)
    def roman(item):  # pylint: disable=unused-variable
        return item
    assert roman('Привiт') == 'Pryvit'


# Generated at 2022-06-23 20:48:09.066454
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def roman(**kwargs):
        return kwargs['value']  # noqa

    text = roman(value='Hello, World!')
    assert text == 'Hello, World!', f'{text} != "Hello, World!"'
    text = roman(value='Привет, Мир!')
    assert text == 'Privet, Mir!', f'{text} != "Privet, Mir!"'

# Generated at 2022-06-23 20:48:14.604545
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize(locale='ru')
    def russian_word(_) -> str:
        return 'Россия'

    assert russian_word(None) == 'Rossiya'

    @romanize(locale='kk')
    def kazakh_word(_) -> str:
        return 'Қазақстан'

    assert kazakh_word(None) == 'Qazaqstan'

# Generated at 2022-06-23 20:48:19.750493
# Unit test for function romanize
def test_romanize():
    assert (romanize('ru')(lambda: '')() == '')
    assert (romanize('ru')(lambda: 'Супер')() == 'Super')
    assert (romanize('ru')(lambda: 'Супер!')() == 'Super!')
    assert (romanize('ru')(lambda: 'Супер 123.')() == 'Super 123.')

# Generated at 2022-06-23 20:48:21.462150
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""
    def serialize(value):
        return value

    results = serialize(romanized()(serialize))
    assert isinstance(results, str)

# Generated at 2022-06-23 20:48:23.819588
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')(lambda: 'Мария')() == 'Maria'


# Generated at 2022-06-23 20:48:29.680718
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Стол и лежак')() == 'Stol i lezhak'
    assert romanize('uk')(lambda: 'Стол и лежак')() == 'Stol i lezhak'
    assert romanize('kk')(lambda: 'Стол и лежак')() == 'Stol i lezhak'

# Generated at 2022-06-23 20:48:40.917313
# Unit test for function romanize
def test_romanize():
    import unittest
    import mimesis

    class TranslitTests(unittest.TestCase):

        def setUp(self):
            self.person = mimesis.Person('ru')


# Generated at 2022-06-23 20:48:49.913738
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def russian_text(data):
        return data('cyrillic.words(5)')

    assert (
        russian_text == 'Великие Дела Выполняются Малыми'
        ' Усилиями Надолго Перед Вами'
    ), 'Russian text failed'

    @romanized('uk')
    def ukrainian_text(data):
        return data('cyrillic.words(5)')


# Generated at 2022-06-23 20:48:55.688543
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    @romanize(locale='uk')
    def romanized_function(param='тест'):
        return param
    assert romanized_function() == 'test'

    @romanize(locale='ru')
    def romanized_function(param='тест'):
        return param
    assert romanized_function() == 'test'


# Generated at 2022-06-23 20:48:57.175303
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('тест')(locale='ru') == 'test'

# Generated at 2022-06-23 20:48:59.101380
# Unit test for function romanize
def test_romanize():
    assert romanize('kg')
    assert romanize('uk')
    assert romanize('ru')
    assert not romanize('xx')

# Generated at 2022-06-23 20:49:01.322427
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'



# Generated at 2022-06-23 20:49:03.594498
# Unit test for function romanize
def test_romanize():
    @romanize()
    def text():
        return 'Тест'

    assert text() == 'Test'



# Generated at 2022-06-23 20:49:07.650532
# Unit test for function romanize
def test_romanize():
    romanized_text = 'Text for romanization'

    @romanize(locale='ru')
    def russian_text():
        return romanized_text

    assert russian_text() == romanized_text

# Generated at 2022-06-23 20:49:12.188681
# Unit test for function romanize
def test_romanize():
    alphabet = {s: s for s in
                ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT['uk'],
        **data.COMMON_LETTERS,
    })
    result = alphabet.get('т')
    assert 't' == result

# Generated at 2022-06-23 20:49:15.659744
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize()
    def romanize_mock(seed: int = None) -> str:
        return "It's a mock method"

    result = romanize_mock()
    assert result  # do not return empty result
    assert isinstance(result, str)



# Generated at 2022-06-23 20:49:22.322454
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    p = Person('ru')
    assert p.name(romanized=True) == romanize('ru')(p.name())
    assert p.surname(romanized=True) == romanize('ru')(p.surname())
    assert p.full_name(romanized=True) == romanize('ru')(p.full_name())



# Generated at 2022-06-23 20:49:28.526088
# Unit test for function romanize
def test_romanize():
    assert functools.partial(romanize, locale='ru')(lambda x: 'Привет')() == 'Privet'
    assert functools.partial(romanize, locale='uk')(lambda x: 'Привет')() == 'Pryvit'
    assert functools.partial(romanize, locale='kk')(lambda x: 'Привет')() == 'Privet'



# Generated at 2022-06-23 20:49:34.039149
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'Привет!')() == ' Privet! '
    assert romanized('uk')(lambda: 'Привіт!')() == ' Pryvit! '
    assert romanized('ru')(lambda: 'Привет!')() == ' Privet! '
    try:
        assert romanized('ukr')(lambda: 'Привіт!')() == ' Pryvit! '
    except UnsupportedLocale:
        assert True
    try:
        assert romanized('uk')(lambda: 'Привет!')() == ' Pryvit! '
    except UnsupportedLocale:
        assert True

# Generated at 2022-06-23 20:49:44.541873
# Unit test for function romanize
def test_romanize():
    # test for russian language
    rus_locale = 'ru'
    # some russian text
    rus_text = 'Привет, как дела, Мир!'
    # transliterated text
    rus_translit = 'Privet, kak dela, Mir!'
    # test if romanize decorator transliterates the text correctly
    class instance(object):
        @romanize(rus_locale)
        def get_translit(self):
            return rus_text
    # test it
    assert instance().get_translit() == rus_translit

    # ukrainian
    ukr_locale = 'uk'
    # some ukrainian text

# Generated at 2022-06-23 20:49:49.343519
# Unit test for function romanize
def test_romanize():
    z = romanized('ru')(lambda: "Привет")
    assert z() == 'Privet'

    z = romanized('uk')(lambda: "Привіт")
    assert z() == 'Pryvit'

    z = romanized('kk')(lambda: "Сәлем")
    assert z() == 'Salem'

    z = romanized()(lambda: "Привет")
    assert z() == ''

# Generated at 2022-06-23 20:49:51.663550
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize, Callable)
    assert isinstance(romanized, Callable)

# Generated at 2022-06-23 20:49:57.517128
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-23 20:50:01.751017
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()
    assert romanize(locale='ru')
    assert romanized(locale='ru')
    assert romanize(locale='uk')
    assert romanized(locale='uk')
    assert romanize(locale='kk')
    assert romanized(locale='kk')

# Generated at 2022-06-23 20:50:03.204555
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:50:07.898614
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'абвгдеж')() == 'abvgdzezh'
    assert romanize()(lambda: 'AБвГДЕЖ')() == 'ABvGDZEZh'
    assert romanize()(lambda: 'йклмноп')() == 'yklmnop'


# Unit tests for the decorator romanized

# Generated at 2022-06-23 20:50:11.551598
# Unit test for function romanize
def test_romanize():
    string = 'Как тебе такое? 1954'
    assert romanize('ru')(lambda: string)() == 'Kak tebe takoe? 1954'



# Generated at 2022-06-23 20:50:14.453691
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    r = data.Data(locale=Locale.RUSSIAN)
    ru = r.romanize(r.text())
    assert ru

# Generated at 2022-06-23 20:50:18.319934
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test(s):
        return s
    assert test('abc') == 'abc'
    assert test('abc абв') == 'abc abv'
    assert test('абв abv') == 'abv abv'
    assert test('йцук йцук') == 'ictuk ictuk'

# Generated at 2022-06-23 20:50:23.470776
# Unit test for function romanize
def test_romanize():
    """Test for the romanization of the cyrillic text.
    """
    result = romanize()(lambda x: 'Подборка десяти лучших матчей 2019-го года.')
    assert result == 'Podborka desyati luchshikh matchiev 2019-go goda.'

# Generated at 2022-06-23 20:50:28.251220
# Unit test for function romanize
def test_romanize():
    for locale in ['ru', 'uk', 'kk']:
        @romanize(locale=locale)
        def r_text():
            return 'Я люблю становиться сильнее!'


# Generated at 2022-06-23 20:50:28.849841
# Unit test for function romanize
def test_romanize():
    romanize()

# Generated at 2022-06-23 20:50:39.788619
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.enums import Locales

    @romanize(locale=Locales.RU)
    def get_name_ru(self) -> str:
        return 'Иван'

    assert get_name_ru() == 'Ivan'

    @romanize(locale=Locales.UK)
    def get_name_uk(self) -> str:
        return 'Іван'

    assert get_name_uk() == 'Ivan'

    @romanize(locale=Locales.KZ)
    def get_name_kz(self) -> str:
        return "И'ван"

    assert get_name_kz() == 'Ivan'

# Generated at 2022-06-23 20:50:42.791076
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize('ru')
    assert romanize('uk')

    assert romanize('fr')
    assert romanize('de')
    assert romanize('en')

# Generated at 2022-06-23 20:50:48.004321
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda x: 'Александр')() == 'Oleksandr'
    assert romanize('ru')(lambda x: 'Александр')() == 'Aleksandr'
    assert romanize('kk')(lambda x: 'Александр')() == 'Aleksandr'



# Generated at 2022-06-23 20:50:50.797391
# Unit test for function romanize
def test_romanize():
    assert romanized('fake_locale')(lambda: 'йцкнгшщзхъфывапролджэячсмитьбю.')() == '.'

# Generated at 2022-06-23 20:50:55.396814
# Unit test for function romanize
def test_romanize():
    @romanize(locale='uk')
    def test_func(answers, start=0, end=10):
        return [answers[i] for i in range(start, end)]

    assert test_func(data.MALE_FIRST_NAMES, 1, 3) == ['Andriy', 'Bohdan']

# Generated at 2022-06-23 20:50:58.229174
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    assert ascii_letters in romanized('ru')(ascii_letters), "romanize"

# Generated at 2022-06-23 20:51:01.163403
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_name():
        return 'Привет, Мир!'
    assert get_name() == 'Privyet, Mir!'

# Generated at 2022-06-23 20:51:03.085135
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:51:11.361640
# Unit test for function romanize
def test_romanize():
    assert romanize()('абвгдеёжзийклмнопрстуфхцчшщъыьэюя') == 'abvgdeejzijklmnoprstufhzcss_y_eua'
    assert romanize(locale='qq')('абвгдеёжзийклмнопрстуфхцчшщъыьэюя') == 'abvgdeejzijklmnoprstufhzcss_y_eua'



# Generated at 2022-06-23 20:51:16.129630
# Unit test for function romanize
def test_romanize():
    # FIXME:
    # romanized = mimesis.decorators.romanize
    # locale = locale.get_locale()
    # cc = ControlCode(locale)
    # res = cc.code()
    # romanized(res)
    pass

# Generated at 2022-06-23 20:51:21.863239
# Unit test for function romanize
def test_romanize():
    assert romanized()('фишка фишки') == 'fishka fishki'
    assert romanized('uk')('фишка фишки') == 'fiszka fiszki'
    assert romanized('kk')('фишка фишки') == 'fışqa fışqı'

# Generated at 2022-06-23 20:51:27.127398
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider('ru')
    assert isinstance(provider.romanized.full_name(), str)

    from mimesis.builtins import UkraineSpecProvider
    provider = UkraineSpecProvider('uk')
    assert isinstance(provider.romanized.full_name(), str)

    from mimesis.builtins import KazakhstanSpecProvider
    provider = KazakhstanSpecProvider('kk')
    assert isinstance(provider.romanized.full_name(), str)

# Generated at 2022-06-23 20:51:29.776529
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo():
        return 'Мимесис'

    assert foo() == 'Mimyesis'



# Generated at 2022-06-23 20:51:32.360533
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_string(*args, **kwargs):
        return kwargs.get('extra').get('locale')

    result = rus_string(extra={'locale': 'поехали'})
    assert result == 'poehali'

# Generated at 2022-06-23 20:51:35.080387
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'привет')() == 'privet'

# Generated at 2022-06-23 20:51:40.246410
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda : 'Абракадабра') == 'AbrakaDabra'
    assert romanize()(lambda : 'Лёша Мирошниченко')\
        == 'Ljosha Miroshnichenko'
    assert romanize(locale='uk')(lambda : 'Дмитро Розумовський')\
        == 'Dmytro Rozumovsjkyj'

# Generated at 2022-06-23 20:51:50.296447
# Unit test for function romanize

# Generated at 2022-06-23 20:52:01.132590
# Unit test for function romanize
def test_romanize():
    # When romanize is applied for supported locale
    @romanize(locale='ru')
    def ru_word():
        return 'Привет, как дела?'
    assert ru_word() == 'Privet, kak dela?'
    # When romanize is applied for unsupported locale
    @romanize(locale='unknown')
    def ru_word():
        return 'Привет, как дела?'
    # it should raise exception
    try:
        ru_word()
        assert False
    except UnsupportedLocale as exception:
        assert 'unknown' in str(exception)
    # When romanize is applied for locale without deco

# Generated at 2022-06-23 20:52:08.317546
# Unit test for function romanize
def test_romanize():
    a = romanize('ru')(lambda: 'Привет')
    assert a() == 'Privet'
    a = romanize('ru')(lambda: 'Привет мир!')
    assert a() == 'Privet mir!'
    a = romanize('ru')(lambda: 'Привет мир!')
    assert a() == 'Privet mir!'
    a = romanize('uk')(lambda: 'Привіт світ!')
    assert a() == 'Pryvit svit!'
    a = romanize('kk')(lambda: 'Сәлем әлем!')
    assert a() == 'Sälem älem!'

# Generated at 2022-06-23 20:52:11.719659
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet mir!'

# Generated at 2022-06-23 20:52:21.551207
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'А не только красиво, но и глубоко.') == \
        'A ne tolko krasivo, no i gluboko.'
    assert romanize()(lambda: 'А не только красиво, но и глубоко.') == \
        romanized()(lambda: 'А не только красиво, но и глубоко.')

# Generated at 2022-06-23 20:52:26.227168
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-23 20:52:28.977746
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-23 20:52:34.755420
# Unit test for function romanize
def test_romanize():
    def rome(locale, text):
        @romanize(locale=locale)
        def romanizer():
            return text
        return romanizer()
    assert rome('ru', 'Мой дядя самых честных правил') == 'Moy dyadya samykh chestnykh pravil'
    assert rome('uk', 'Мій дядя самих честних правил') == 'Myj dyadja samyx chesnyx pravyl'

# Generated at 2022-06-23 20:52:38.247783
# Unit test for function romanize
def test_romanize():
    romanized_function = romanize('ru')
    @romanized_function
    def russian_text():
        return 'Привет, мир!'

    assert russian_text() == 'Privet, mir!'

# Generated at 2022-06-23 20:52:42.829295
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')("Привет мир!")(locale='ru') == "Privet mir!"
    assert romanize('ru')("Привет мир!")() == "Privet mir!"


# Generated at 2022-06-23 20:52:54.128704
# Unit test for function romanize
def test_romanize():
    # russian
    assert romanize('ru')(lambda self: self)().count('h') == 0
    assert romanize('ru')(lambda self: self)().count('х') == 0
    assert romanize('ru')(lambda self: self)().count('H') == 0
    assert romanize('ru')(lambda self: self)().count('Х') == 0

    assert romanize('uk')(lambda self: self)().count('h') == 0
    assert romanize('uk')(lambda self: self)().count('х') == 0
    assert romanize('uk')(lambda self: self)().count('H') == 0
    assert romanize('uk')(lambda self: self)().count('Х') == 0


# Generated at 2022-06-23 20:52:58.528027
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo(x):
        return x + "Привет мир!"

    r = foo("Йоу май чайз! Йоу май дайз!")
    assert r == "You may chájs! You may daýs!"

# Generated at 2022-06-23 20:53:00.913825
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def g() -> str:
        return 'тест'

    assert g() == 'test'

# Generated at 2022-06-23 20:53:11.356259
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.person import Person
    p = Person('ru')
    assert p.full_name() == 'Поперечный Александр Всеволодович'
    p = Person('uk')
    assert p.full_name() == 'Іванов Андрій Володимирович'
    p = Person('kk')
    assert p.full_name() == 'Айтолкын Байбакты'
    p = Person('ru')
    p.romanize()

# Generated at 2022-06-23 20:53:12.893455
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod()

# Unit test of function romanized

# Generated at 2022-06-23 20:53:15.752213
# Unit test for function romanize
def test_romanize():
    assert romanize()('Эта машина моя, сопливая сучка!') == \
        'Eta mashina moya, soplivaia suchka!'

# Generated at 2022-06-23 20:53:17.808114
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-23 20:53:21.448037
# Unit test for function romanize
def test_romanize():
    def foo():
        return "Привет, Мир!"

    romanized = romanize('ru')(foo)
    assert romanized() == "Privet, Mir!"

# Generated at 2022-06-23 20:53:30.721643
# Unit test for function romanize
def test_romanize():

    import pytest # type: ignore
    from hypothesis import given
    from hypothesis.strategies import text

    @romanized(locale='ru')
    def romanize_ru(txt):
        return txt

    @romanized(locale='uk')
    def romanize_uk(txt):
        return txt

    @romanized(locale='kk')
    def romanize_kk(txt):
        return txt

    @romanized(locale='be')
    def romanize_be(txt):
        return txt

    @given(text())
    def test_ru_str(s):
        romanize_ru(s)

    @given(text())
    def test_uk_str(s):
        romanize_uk(s)


# Generated at 2022-06-23 20:53:32.056974
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:53:34.784297
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize(locale='ru')
    assert romanized(locale='uk')
    assert romanize(locale='test')

# Generated at 2022-06-23 20:53:37.501655
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    txt = romanize()(print)('Привет!')
    assert txt == 'Privet!'



# Generated at 2022-06-23 20:53:39.165302
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'здесь')().isalpha()

# Generated at 2022-06-23 20:53:46.245195
# Unit test for function romanize
def test_romanize():
    result = ''
    for i in ascii_letters + digits + punctuation:
        result += f'{i:<2}'

    result += ' '
    for i in range(1071, 1104):
        result += chr(i)


# Generated at 2022-06-23 20:53:48.619729
# Unit test for function romanize
def test_romanize():

    @romanize('ru')
    def rus_text():
        return 'текст'

    assert rus_text() == 'tekst'

# Generated at 2022-06-23 20:53:50.586302
# Unit test for function romanize
def test_romanize():
    assert(romanize()('Привет') == 'Privet')

# Generated at 2022-06-23 20:53:55.766898
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda x: 'Привет')() == 'Privet'
    assert romanized('uk')(lambda x: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda x: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-23 20:54:02.245923
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Locale

    # v.4.0.0
    # Person data
    p = Person(locale=Locale.RU)
    assert p.full_name(gender=Gender.FEMALE) == 'Наталья Сергеевна Семенова'
    assert p.full_name(romanize=True) == 'Инна Витальевна Беляева'

    # Address data

# Generated at 2022-06-23 20:54:08.456949
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    # For example:

    # @romanize(locale='ru')
    # def romanize_ru():
    #     return self.random_element(data.CYRILLIC_LETTERS)

    romanize_ru = romanize('ru')(lambda: data.CYRILLIC_LETTERS)
    romanize_uk = romanize('uk')(lambda: data.CYRILLIC_LETTERS)
    romanize_kk = romanize('kk')(lambda: data.CYRILLIC_LETTERS)

    assert all(set(romanize_ru()).issubset(ascii_letters) for _ in range(10))

# Generated at 2022-06-23 20:54:10.269064
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'проверка')() == 'provеrka'

# Generated at 2022-06-23 20:54:18.003826
# Unit test for function romanize
def test_romanize():
    assert ('Привіт, світ' == romanize('uk')(
            'Привіт, світ'))
    assert ('Привет, мир' == romanize('ru')(
            'Привет, мир'))
    assert ('Сәлем, дүние' == romanize('kk')(
            'Сәлем, дүние'))

# Generated at 2022-06-23 20:54:23.112623
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Москва')() == 'Moskva'
    assert romanize('uk')(lambda : 'Здравствуйте')().lower() == 'zdravstvuyte'
    assert romanize('kk')(lambda : 'Алматы')() == 'Almaty'

# Generated at 2022-06-23 20:54:33.688052
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo():
        return 'Сегодня был прекрасный день'

    assert foo() == 'Segodnya byl prekrasnyj den`'

    @romanize(locale='uk')
    def foo():
        return 'Сьогодні був прекрасний день'

    assert foo() == 'S`ohodni buv prekrasnij den`'

    @romanize(locale='kk')
    def foo():
        return 'Бүгін жақсы күн болды'


# Generated at 2022-06-23 20:54:39.032931
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "Привет, Петр!")() == "Privet, Petr!"
    assert romanize('uk')(lambda: "Завжди це вийде дорожче")() == "Zavzhdy tse vyiede dorozhche"

# Generated at 2022-06-23 20:54:50.102858
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import Person

    person = Person(Language.RUSSIAN)
    name = person.full_name()

    # Test for Russian
    assert romanize(locale=Language.RUSSIAN)(lambda: name)() == \
        romanized(locale=Language.RUSSIAN)(lambda: name)() == \
        'Artemiy Teplov'

    # Test for Ukrainian
    assert romanize(locale=Language.UKRAINIAN)(lambda: name)() == \
        romanized(locale=Language.UKRAINIAN)(lambda: name)() == \
        'Artemiy Teplov'

    # Test for Kazakh
    assert romanize(locale=Language.KAZAKH)(lambda: name)

# Generated at 2022-06-23 20:54:58.857502
# Unit test for function romanize
def test_romanize():
    """Test for the romanize wrapper."""
    from mimesis.providers.internet import Internet

    rus_text = 'Привет, Мир!'
    ukr_text = 'Привіт, Світ!'
    kaz_text = 'Сәлем, Достар!'
    assert Internet().romanize(rus_text, 'ru') == rus_text
    assert Internet().romanize(ukr_text, 'uk') == ukr_text
    assert Internet().romanize(kaz_text, 'kk') == kaz_text

# Generated at 2022-06-23 20:55:08.515831
# Unit test for function romanize
def test_romanize():
    @romanized()
    def razdwa():
        return 'раздва'
    x = razdwa()
    assert x == 'razdva'
    @romanized('uk')
    def razdwa():
        return 'раздва'
    y =razdwa()
    assert y == 'razdva'
    @romanized('ru')
    def razdwa():
        return 'раздва'
    z = razdwa()
    assert z == 'razdva'
    try:
        @romanized('ru')
        def razdwa():
            return 'раздва'
        a = razdwa()
    except UnsupportedLocale:
        pass

# Generated at 2022-06-23 20:55:11.440609
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus():
        return 'Привет, мир!'

    assert rus() == 'Привет, мир!'

# Generated at 2022-06-23 20:55:13.973202
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_func():
        return 'Я хочу отдохнуть'
    assert 'Ja hochu otdojnit' == test_func()

# Generated at 2022-06-23 20:55:17.456727
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет дорогой друг мой') == 'Privet Dorogoy Drug Moy'
    assert romanize(locale='uk')('Привіт друже') == 'Pryvit druzhe'
    assert romanize(locale='kk')('Салам қайда болады') == 'Salam k̠aida bolady'

# Generated at 2022-06-23 20:55:24.690651
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'новый год 2020') == 'novyj god 2020'
    assert romanize(locale='uk')(lambda: 'Точка не відповідає.') == 'Tochka ne vidpovidaje.'
    assert romanize(locale='kk')(lambda: 'Егер бұл адамдық ҚҰҒЫСТАРҚА аударылса...')\
           == 'Eger bul adamdık QUĞYSTARQA audarılsa...'


# Generated at 2022-06-23 20:55:27.641093
# Unit test for function romanize
def test_romanize():
    assert romanize is not None


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-23 20:55:33.098154
# Unit test for function romanize
def test_romanize():
    # Test for russian
    rus_name = 'Иванов'
    assert romanize('ru')(lambda: rus_name) == 'Ivanov'

    # Test for ukrainian
    ukr_name = 'Іванов'
    assert romanize('uk')(lambda: ukr_name) == 'Ivanov'

    # Test for kazakh
    kaz_name = 'Иванов'
    assert romanize('kk')(lambda: kaz_name) == 'Ivanov'

# Generated at 2022-06-23 20:55:33.711789
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:55:36.592150
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.text import Text
    text = Text('ru')
    text.romanize = romanize('ru')(text.romanize)
    assert text.romanize('привет') == 'privet'

# Generated at 2022-06-23 20:55:40.312765
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus_sentence() -> str:
        """Test romanize."""
        return 'Привет, мир!'

    assert rus_sentence() == 'Privet, mir!'

# Generated at 2022-06-23 20:55:44.299196
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Generic
    gen = Generic('uk')

    res = gen.code.cpr()
    assert res == gen.code.cpr.__wrapped__()



# Generated at 2022-06-23 20:55:51.388962
# Unit test for function romanize
def test_romanize():
    def test(romanized_text_ru, text_ru):
        assert romanize('ru')(lambda: text_ru)() == romanized_text_ru

    test(romanized_text_ru='i vozvrashchais', text_ru='я возвращаюсь')
    test(romanized_text_ru='belarus', text_ru='беларусь')
    test(romanized_text_ru='sudba sudba', text_ru='судьба судьба')
    test(romanized_text_ru='2+2=4?', text_ru='2+2=4?')

# Generated at 2022-06-23 20:55:57.884681
# Unit test for function romanize
def test_romanize():
  romanized_set = romanize('ru')
  assert callable(romanized_set), "romanize_set isn't callable"
  romanized_set = romanize('uk')
  assert callable(romanized_set), "romanize_set isn't callable"
  romanized_set = romanize('kk')
  assert callable(romanized_set), "romanize_set isn't callable"
  with assert_raises(UnsupportedLocale):
    romanize('Wrong locale')

test_romanize()

# Generated at 2022-06-23 20:56:03.165721
# Unit test for function romanize
def test_romanize():
    @romanized(locale='ru')
    def test(locale: str = '') -> str:
        return data.ROMANIZATION_DICT[locale]

    result = test()
    assert result == data.ROMANIZATION_DICT['ru']

# Generated at 2022-06-23 20:56:13.066876
# Unit test for function romanize
def test_romanize():
    from mimesis import Generic, Person
    from mimesis.enums import Gender, Language

    g = Generic('ru')
    p = Person('ru')

    name = p.full_name(gender=Gender.FEMALE)
    assert g._data['cyrillic']['latin'].get('Юлия') == 'Yuliya'
    assert romanize()(g.cyrillic.latin)(name) == 'Yuliya Lyubimova'

    p = Person('uk')
    name = p.full_name(gender=Gender.MALE)
    assert g._data['cyrillic']['latin'].get('Іван') == 'Iv\'an'

# Generated at 2022-06-23 20:56:16.377937
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    from mimesis import Person

    person = Person('ru')

    name = person.name()
    assert all([symbol in name for symbol in ascii_letters])

# Generated at 2022-06-23 20:56:24.423507
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    ru = Person('ru')
    assert ru.full_name() == 'Абдулов Борис Леонидович'
    assert ru.full_name(romanize='ru') == 'Abdulov Boris Leonidovich'

    uk = Person('uk')
    assert uk.full_name() == 'Абраменко Борис Леонідович'
    assert uk.full_name(romanize='uk') == 'Abramenko Boris Leonidovych'

    kk = Person('kk')

# Generated at 2022-06-23 20:56:33.841772
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЬЫЪЭЮЯ')() == 'AbvgdeeZzijklmnoprstufhccSchschYieeaia'

# Generated at 2022-06-23 20:56:41.460529
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('ru')(lambda: 'Ты')() == 'Ty'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('uk')(lambda: 'Ти')() == 'Ty'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'
    assert romanize('kk')(lambda: 'Сен')() == 'Sen'

    # assert romanize('en')(lambda: 'Hello')() == 'Hello'

# Generated at 2022-06-23 20:56:46.887924
# Unit test for function romanize
def test_romanize():
    @romanize('kk')
    def romanized(text: str) -> str:
        return text

    assert romanized('Алтын аққұл балыңдар') == 'Altyn aqqul balyńdar'

# Generated at 2022-06-23 20:56:57.143026
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    rus = RussiaSpecProvider()
    @romanize(locale='ru')
    def my_func():
        return rus.surname()


# Generated at 2022-06-23 20:57:05.551209
# Unit test for function romanize
def test_romanize():
    special_characters = '!@#$%^&*()_+=-{}[]:"|;\'\\<>?,./'

    def test(a):
        return a

    if __name__ == '__main__':
        decorated = romanize('ru')(test)
        rus = 'Привет, друг! Погода отличная, мы идем на пиво.'
        assert decorated(rus) == 'Privet, drug! Pogoda otlichnaya, my idem na pivo.'
        lat = 'Privet, drug! Pogoda otlichnaya, my idem na pivo.'
        assert decorated(lat) == lat

# Generated at 2022-06-23 20:57:10.699418
# Unit test for function romanize
def test_romanize():
    assert romanize()(gen_data=lambda: 'Привет, сколько стоит 10$')() == \
        'Privet, skolko stoit 10$'



# Generated at 2022-06-23 20:57:18.158018
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda x: 'привет')() == 'privet'
    assert romanized('kk')(lambda x: 'привет')() == 'privet'
    assert romanized('uk')(lambda x: 'привет')() == 'privet'
    assert romanized('ru')(lambda x: 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя')() == \
           'abvgdeezhziyklmnoprstufhzszyieua'

# Generated at 2022-06-23 20:57:25.235940
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    from mimesis.builtins import Enum, Datetime
    dt = Datetime(locale='ru')
    cl = Enum(locale='ru')

    assert dt.now().romanize() == dt.now()
    assert cl.enums(cl.CURRENCIES).romanize() == cl.enums(cl.CURRENCIES)

# Generated at 2022-06-23 20:57:33.310696
# Unit test for function romanize
def test_romanize():
    # Test function words of language "uk"
    assert romanized('uk')(lambda: 'текст')() == 'tekst'
    assert romanized('uk')(lambda: 'Текст')() == 'Tekst'
    assert romanized('uk')(lambda: 'Текст, Текст, Текст!')() == 'Tekst, Tekst, Tekst!'
    assert romanized('uk')(lambda: 'Текст, Текст, 1.0')() == 'Tekst, Tekst, 1.0'

# Generated at 2022-06-23 20:57:40.441382
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    p = Person('ru')
    assert p.full_name() != p.full_name(romanize=True)
    assert p.surname() != p.surname(romanize=True)
    assert p.name() != p.name(romanize=True)
    assert p.username() != p.username(romanize=True)
    assert p.email() == p.email(romanize=True)

# Generated at 2022-06-23 20:57:44.237229
# Unit test for function romanize
def test_romanize():
    """Test for function of romanize."""
    from mimesis.builtins import Person

    p = Person('en')
    r = Person('en')

    assert p.full_name() == 'Andrew Carter'
    assert r.full_name() == 'Тест Тестов'