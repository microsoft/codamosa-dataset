

# Generated at 2022-06-23 20:47:45.596891
# Unit test for function romanize
def test_romanize():
    text = 'Россия'
    romanized_text = 'Rossiya'
    assert romanize(locale='ru')(lambda: text)() == romanized_text

# Generated at 2022-06-23 20:47:47.806847
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian_word():
        return "Я"

    assert russian_word() == 'Ya'

# Generated at 2022-06-23 20:47:54.133508
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    import mimesis.enums
    from mimesis.providers.datetime.datetime import Datetime

    pattern = '{id}, {first_name}, {last_name}'

# Generated at 2022-06-23 20:47:56.594318
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    import mimesis
    text = mimesis.Text('ru')
    assert len(text.romanize()) < len(text.word())

# Generated at 2022-06-23 20:48:02.644862
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    from tests.utils import unit_test_romanize_decorator
    assert unit_test_romanize_decorator('ru') == 'bcehkmdx'
    assert unit_test_romanize_decorator('kk') == 'bcehmlyz'
    assert unit_test_romanize_decorator('uk') == 'bcehkmdx'



# Generated at 2022-06-23 20:48:07.825026
# Unit test for function romanize
def test_romanize():
    # The default locale is ru.
    @romanize()
    def foo():
        return 'Как дела?'

    assert foo() == 'Kak dela?'
    # Other locale.
    @romanize('uk')
    def bar():
        return 'Как дела?'

    assert bar() == 'Jak dela?'

# Generated at 2022-06-23 20:48:11.403807
# Unit test for function romanize
def test_romanize():
    result = romanize(locale="ru")
    assert result('Привет, как дела?') == 'Privet, kak dela?'
    assert result('Привет, как дела?') == 'Privet, kak dela?'

# Generated at 2022-06-23 20:48:16.601620
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    result = romanize(locale='ru')(lambda: 'Привет')()
    assert result == 'Privet'

    # Cyrillic string can contain ascii symbols
    result = romanize(locale='ru')(lambda: 'Купи мне бутылку пива')()
    assert result == 'Kupi mne butylku piva'



# Generated at 2022-06-23 20:48:20.102554
# Unit test for function romanize
def test_romanize():
    # "random" is imported for mocking purposes in unit tests
    from mimesis import random

    @random.romanized
    def romanize_text():
        return 'тест'

    assert romanize_text() == 'test'

    romanized_text = random.romanized(lambda: 'тест')
    assert romanized_text == 'test'

# Generated at 2022-06-23 20:48:21.745450
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_data():
        return 'Мимизиз'
    assert get_data() == 'Mimizis'

# Generated at 2022-06-23 20:48:24.517470
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda _: 'Привет Мир!')() == 'Privet Mir!'

# Generated at 2022-06-23 20:48:27.005215
# Unit test for function romanize
def test_romanize():
    @romanized()
    def russian_text():
        return data.RUSSIAN_TEXT

    assert isinstance(russian_text(), str)



# Generated at 2022-06-23 20:48:33.296245
# Unit test for function romanize
def test_romanize():
    assert romanize()('тут') == 'tut'
    assert romanize('uk')('Геологічні відомості') == 'Geologichni vidomosti'
    assert romanize()('Добро пожаловать в Россию') == 'Dobro pozhalovat v Rossiyu'

# Generated at 2022-06-23 20:48:43.203107
# Unit test for function romanize
def test_romanize():
    romanize_ru = romanize('ru')
    romanize_uk = romanize('uk')
    romanize_kk = romanize('kk')

    @romanize_ru
    def r1():
        return 'Привет, Мир!'

    @romanize_uk
    def r2():
        return 'Привіт, Світ!'

    @romanize_kk
    def r3():
        return 'Салам, Дүние!'

    assert r1() == 'Privet, Mir!'
    assert r2() == 'Pryvit, Svit!'
    assert r3() == 'Salam, Dünie!'

# Generated at 2022-06-23 20:48:45.494122
# Unit test for function romanize
def test_romanize():
    assert 'abc' == romanized()('abc')
    assert 'Български' == romanized('bg')('Български')

# Generated at 2022-06-23 20:48:47.406423
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Фамилия') == 'Familiia'

# Generated at 2022-06-23 20:48:52.457670
# Unit test for function romanize
def test_romanize():
    """Test Romanization."""
    try:
        _ = romanize('ukr')
    except UnsupportedLocale:
        assert True

    @romanize(locale='ru')
    def romanize_ru():
        return 'Бразилия'

    assert romanize_ru == 'Braziliya'



# Generated at 2022-06-23 20:48:54.899016
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def _romanize(key: str) -> str:
        return key

    assert _romanize('Тест') == 'Test'



# Generated at 2022-06-23 20:48:57.365911
# Unit test for function romanize
def test_romanize():
    """Test romanized function."""

    @romanized()
    def test_romanize():
        return 'Привет'

    assert test_romanize() == 'Privet'

# Generated at 2022-06-23 20:48:58.927446
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: "Привет!")[0] == 'P'

# Generated at 2022-06-23 20:49:00.786746
# Unit test for function romanize
def test_romanize():
    t = 'стакан'
    func = romanize('ru')
    wrapper = func(lambda: t)
    assert wrapper() == 'stakan'

# Generated at 2022-06-23 20:49:06.841699
# Unit test for function romanize
def test_romanize():
    import unittest
    class TestRomanize(unittest.TestCase):
        def test_romanize_works(self):
            @romanize(locale='ru')
            def test_function():
                return 'Лорем ипсум долор сит амет'
            assert test_function() == 'Lorem ipsum dolor sit amet'

        def test_romanize_raises_error(self):
            with self.assertRaises(UnsupportedLocale):
                @romanize(locale='us')
                def test_function_2():
                    return 'Лорем ипсум долор сит амет'
                assert test_function_2()

# Generated at 2022-06-23 20:49:08.222948
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:49:10.721670
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Надеюсь это работает") == "Nadeyus' eto rabotaet"

# Generated at 2022-06-23 20:49:11.932087
# Unit test for function romanize
def test_romanize():
    assert __all__ == ['romanize']

# Generated at 2022-06-23 20:49:14.854827
# Unit test for function romanize
def test_romanize():
    # Arrange
    text = 'Привіт, Світ!'

    # Act
    result = romanize(locale='uk')(lambda: text)

    # Assert
    assert result == 'Pryvit, Svit!'

# Generated at 2022-06-23 20:49:16.136818
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'привіт')() == 'pryvit'

# Generated at 2022-06-23 20:49:18.090460
# Unit test for function romanize
def test_romanize():
    @romanize(locale='uk')
    def _get_random_ukrainian():
        return 'Тест'

    assert _get_random_ukrainian() == 'Test'

# Generated at 2022-06-23 20:49:20.135300
# Unit test for function romanize
def test_romanize():
    assert romanize(locale = 'ru')(lambda: 'йе')() == 'ye'

# Generated at 2022-06-23 20:49:30.159051
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT

    def foo(number):
        return str(number)

    @romanize(locale='ru')
    def foo_ru(number):
        return str(number)

    @romanize(locale='uk')
    def foo_uk(number):
        return str(number)

    @romanize(locale='kk')
    def foo_kk(number):
        return str(number)

    @romanize(locale='unexistent')
    def foo_unexistent(number):
        return str(number)

    assert foo('1234') == '1234'

    assert foo_ru('1234') == foo('1234')
    assert foo_uk('1234') == foo('1234')

# Generated at 2022-06-23 20:49:38.305450
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'ABCDEF')() == 'ABCDEF'

    @romanize(locale='ru')
    def rus_text():
        return 'Умножение на два'

    assert rus_text() == 'UMNOJENIE NA DVA'

    @romanize(locale='uk')
    def ukr_text():
        return 'Умноження на два'

    assert ukr_text() == 'UMNOZHENNYA NA DVA'

    @romanize(locale='kk')
    def kaz_text():
        return 'Екінші кезең'


# Generated at 2022-06-23 20:49:47.050579
# Unit test for function romanize
def test_romanize():  # noqa: D103
    import pytest
    from mimesis.enums import LoremAlphabet

    @romanize('ru')
    def generate_name() -> str:
        return LoremAlphabet.CYRILLIC_FULL.value[:8]

    assert isinstance(generate_name(), str)
    with pytest.raises(UnsupportedLocale) as exc_info:
        @romanize('qq')
        def generate_name_fail():  # noqa: F841
            return LoremAlphabet.CYRILLIC_FULL.value[:8]

        assert 'qq' in str(exc_info.value)

# Generated at 2022-06-23 20:49:53.953436
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Метод') == 'Metod'
    assert romanize(locale='uk')(lambda: 'Метод') == 'Metod'
    assert romanize(locale='kk')(lambda: 'Метод') == 'Metod'

    assert romanize(locale='ru')(lambda: 'Привіт') == 'Pryvit'
    assert romanize(locale='uk')(lambda: 'Привіт') == 'Privit'
    assert romanize(locale='kk')(lambda: 'Привіт') == 'Privit'


# Generated at 2022-06-23 20:49:57.099683
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    assert Person(locale='en').full_name() != Person(locale='ru').full_name()



# Generated at 2022-06-23 20:50:05.518654
# Unit test for function romanize
def test_romanize():
    """Test romanization."""
    @romanize()
    def foobar():
        return 'Hey!'

    result = foobar()
    assert result == 'Hey!'

    @romanize('ru')
    def foobar():
        return 'Привет мир!'

    result = foobar()
    assert result == 'Privet mir!'

    @romanize('kk')
    def foobar():
        return 'Барлығы жақсы болып табылады'

    result = foobar()
    assert result == 'Barlığı jaqsı bolıp taladı'


# Generated at 2022-06-23 20:50:09.162530
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(
        lambda: 'Говорите ли вы по-английски?')() == 'Govorite li vy po-anglijski?'

# Generated at 2022-06-23 20:50:13.886143
# Unit test for function romanize
def test_romanize():
    """Test romanize method."""
    @romanize()
    def fake():
        return 'fake'
    assert fake() == 'fake'

    @romanize('ru')
    def get_name(capitalize=False):
        return 'Иван'

    assert get_name() == 'Ivan'



# Generated at 2022-06-23 20:50:20.595214
# Unit test for function romanize
def test_romanize():
    ru = ["Новость", "Добро пожаловать"]
    ru_r = ["Novost'", "Dobro pozhalovat'"]
    uk = ["Вітання", "Привіт"]
    uk_r = ["Vitannya", "Pryvit"]
    kk = ["Сәлем", "Казакша"]
    kk_r = ["Sälem", "Kazaksa"]

    for a, b in zip(ru, ru_r):
        assert romanize('ru')(lambda: a)() == b, 'Romanize ru'


# Generated at 2022-06-23 20:50:24.470904
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_text() -> str:
        return 'вася'  # vassia

    assert russian_text() == 'вася'
    assert isinstance(russian_text, str)



# Generated at 2022-06-23 20:50:26.157087
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'текст')() == 'tekst'



# Generated at 2022-06-23 20:50:28.830444
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def _gen_name():
        return 'Иванов'

    assert _gen_name() == 'Ivanov'
    assert not _gen_name() == 'Иванов'

# Generated at 2022-06-23 20:50:40.187186
# Unit test for function romanize
def test_romanize():
    assert data.Gender('ru')._romanize('Александр') == 'Aleksandr'
    assert data.Gender('uk')._romanize('Олександр') == 'Aleksandr'
    assert data.Gender('kk')._romanize('Әліппе') == 'Alippe'

    assert romanize(locale='ru')(data.Gender('ru').female)() \
        == 'Анастасия'
    assert romanize(locale='uk')(data.Gender('uk').female)() \
        == 'Анастасія'

# Generated at 2022-06-23 20:50:48.537369
# Unit test for function romanize
def test_romanize():
    assert romanize()('Коктейль') == 'Kokteil'
    assert romanize('ru')('Коктейль') == 'Kokteil'
    assert romanize('uk')('Коктейль') == 'Kokteil'
    assert romanize('kk')('Коктейль') == 'Kokteil'

    # For backward compatibility
    assert romanized('ru')('Коктейль') == romanize('ru')('Коктейль')

# Generated at 2022-06-23 20:50:57.897258
# Unit test for function romanize
def test_romanize():
    import random
    import string

    from mimesis import Person, Address

    random.seed(0)
    locale = random.choice(['ru', 'uk', 'kk'])
    person = Person(locale)
    record = {
        'name': person.full_name(),
        'phone': person.telephone(),
        'address': Address(locale).address(),
        'country': Address(locale).country_name(),
        'ip': person.ipv4(),
        'passport': person.passport(),
        'email': person.email(),
        'company': person.company(),
        'job': person.job(),
    }


# Generated at 2022-06-23 20:51:08.295755
# Unit test for function romanize
def test_romanize():
    def test_string():
        return 'Эта строка должна быть романизирована.'

    # Support for `ru` locale
    r = romanize('ru')
    r_string = r(test_string)
    assert r_string == 'Eta stroka dolzhna byt romanizirovana.'

    # Support for `kk` locale
    r = romanize('kk')
    r_string = r(test_string)
    assert r_string == 'Бұл жол мәтін мәтінделікті қолдану қажет.'

   

# Generated at 2022-06-23 20:51:12.909010
# Unit test for function romanize
def test_romanize():
    """Test coverage for function romanize."""
    locale = 'ru'
    def _func(): return 'Мимесис'

    _romanized_deco = romanize(locale)(_func)
    assert _romanized_deco() == 'Mimesis'

# Generated at 2022-06-23 20:51:18.728672
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_name(self):
        return 'Иван'

    @romanize(locale='ru')
    def get_surname(self):
        return 'Петров'

    assert get_name(None) == 'Ivan'
    assert get_surname(None) == 'Petrov'



# Generated at 2022-06-23 20:51:19.809247
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def romanize():
        return 'сыр'

    assert romanize() == 'syr'



# Generated at 2022-06-23 20:51:22.672169
# Unit test for function romanize
def test_romanize():
    @romanize('uk')
    def _():
        return '  Тестовий випадок'

    assert _() == 'Testovyi vypadok'

# Generated at 2022-06-23 20:51:28.121134
# Unit test for function romanize
def test_romanize():
    romanize_func = romanize()
    romanize_deco = romanize_func(lambda x: 'Мір вебінарів')
    assert romanize_deco(locale='ru') == 'mir-webinarov'

# Generated at 2022-06-23 20:51:31.117232
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test():
        return 'я люблю африку'

    assert test() == 'ya lyublyu afriku'

# Generated at 2022-06-23 20:51:34.556492
# Unit test for function romanize
def test_romanize():
    def test(locale):
        def romanized_func(self):
            pass

        romanized_func = romanize(locale)(romanized_func)
        romanized_func(None)

    test('ru')
    test('uk')
    test('kk')

# Generated at 2022-06-23 20:51:36.356561
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: "Тестирование")() == "Testirovaniye"

# Generated at 2022-06-23 20:51:41.405867
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def cyryllic_txt():
        return 'Давайте пробуем!'

    assert cyryllic_txt() == 'Davaite probuem!'

# Generated at 2022-06-23 20:51:45.696986
# Unit test for function romanize
def test_romanize():
    romanize('ru') == romanized('ru')
    romanize('uk') == romanized('uk')
    romanize('kk') == romanized('kk')
    romanize('en') == romanized('en')


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:51:46.285758
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:51:50.439533
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def romanize_it(text):
        return text

    assert romanize_it('Привет, мир!') == 'Privet, mir!'



# Generated at 2022-06-23 20:51:52.768774
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'исповедь')() == 'ispoved'

# Generated at 2022-06-23 20:51:57.332060
# Unit test for function romanize
def test_romanize():
    def reverse(s):
        return s[::-1]

    def test():
        return 'Тест'

    assert reverse(romanize(locale='ru')(test)()) == 'ТсеТ'
    assert reverse(romanized(locale='ru')(test)()) == 'ТсеТ'

# Generated at 2022-06-23 20:51:59.175362
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo():
        return 'Это тест'

    bar = foo()
    assert bar == 'Eto test'

# Generated at 2022-06-23 20:52:01.172395
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize() is not None
    assert romanized() is not None

# Generated at 2022-06-23 20:52:07.600577
# Unit test for function romanize
def test_romanize():
    assert romanize('en')(lambda: 'Символы')() == 'Simvoly'
    assert romanize('kk')(lambda: 'Сымбалар')() == 'Symbalar'
    assert romanize('ru')(lambda: 'Символы')() == 'Simvoly'
    assert romanize('uk')(lambda: 'Символи')() == 'Simvoli'
    assert romanize('ru')(lambda: 'Пунктуация,!:-')() == 'Punktuaciya,!:-'



# Generated at 2022-06-23 20:52:17.464950
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: '123') == '123'
    assert romanize()(lambda: 'abc') == 'abc'
    assert romanize()(lambda: 'ABC') == 'ABC'
    assert romanize()(lambda: '123abcABC') == '123abcABC'
    assert romanize('ru')(lambda: 'ПРИВЕТ') == 'PRIVET'
    assert romanize('ru')(lambda: '123ПРИВЕТ') == '123PRIVET'
    assert romanize('uk')(lambda: 'ПРИВІТ') == 'Pryvyt'

# Generated at 2022-06-23 20:52:22.800192
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'



# Generated at 2022-06-23 20:52:25.849438
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test(seed: int, data_provider):
        return data_provider.name(seed)

    assert 'Pazukhin' in test(1, data)

# Generated at 2022-06-23 20:52:31.474907
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    p = Person(Locale.ENGLISH)
    a = Address(Locale.ENGLISH)

    assert p.full_name() == 'Mark Thomas'
    assert p.romanize(locale='uk').full_name() == 'Mark Maksimovich'
    assert p.romanize().full_name() == 'Mark Thomas'
    assert a.state() == 'Massachusetts'
    assert a.romanize(locale='ru').state() == 'Massakhussets'

# Generated at 2022-06-23 20:52:34.503039
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(str)('Здравствуйте') == 'Zdravstvujte'

# Generated at 2022-06-23 20:52:34.896355
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:52:43.755853
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_name():
        return 'Петр'
    assert get_name() == 'Petr'

    @romanize('ru')
    def get_last_name():
        return 'Константинопольский'
    assert get_last_name() == 'Konstantinopolʹskiĭ'

    @romanize('uk')
    def get_name():
        return 'Петро'
    assert get_name() == 'Petro'

    @romanize('uk')
    def get_last_name():
        return 'Константинопольський'

# Generated at 2022-06-23 20:52:47.051725
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanization():
        return 'Светлана'
    assert romanization() == 'Svetlana'

# Generated at 2022-06-23 20:52:56.044735
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет!') == 'Privet!'
    assert romanized()('Привет, Мир!') == 'Privet, Mir!'
    assert romanized()('Здравствуй, Мир!') == 'Zdravstvuý, Mir!'
    assert romanized()('Привет, Мир! Как дела?') == 'Privet, Mir! Kak dela?'
    assert romanized()('Кофе и каша!') == 'Kofe i kasha!'

# Generated at 2022-06-23 20:53:00.603140
# Unit test for function romanize
def test_romanize():
    """For romanization, you need to decide on the locale."""
    from mimesis.builtins import RussianSpecProvider
    provider = RussianSpecProvider()
    ru = RussianSpecProvider()
    assert ru.romanize(provider.word()) == ru.romanize(provider.word(), 'ru')



# Generated at 2022-06-23 20:53:11.190555
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    # pylint: disable=missing-function-docstring
    # pylint: disable=too-few-public-methods

    class TestClass:
        """This is a class for testing romanize."""

        @romanize(locale='ru')
        def generate_name(self) -> str:
            """Generate full name in russian."""
            name = ''
            for i in range(5):
                name += self.get_random_letter()
            return name

        @staticmethod
        def get_random_letter() -> str:
            """Generate random cyrillic letter."""
            from mimesis.providers.person import Person
            return Person('ru').cyrillic_letter()  # pylint: disable=no-method-argument

    test_class

# Generated at 2022-06-23 20:53:19.367122
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Юля')() == 'Yuliya'
    assert romanize('uk')(lambda : 'Юля')() == 'Iuliiia'
    assert romanize('kk')(lambda : 'Юля')() == 'Yuliya'
    assert romanized('ru')(lambda : 'Юля')() == 'Yuliya'
    assert romanized('uk')(lambda : 'Юля')() == 'Iuliiia'
    assert romanized('kk')(lambda : 'Юля')() == 'Yuliya'

# Generated at 2022-06-23 20:53:22.381620
# Unit test for function romanize
def test_romanize():
    @romanized()
    def foo():
        return 'Привет, мир!'
    assert foo() == 'Privet, mir!'

# Generated at 2022-06-23 20:53:23.019594
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:53:26.639749
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет от Мимезис!')() == 'Privet ot Mimesis!'

# Generated at 2022-06-23 20:53:34.689087
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    def get_greeting(l: str = 'ru') -> str:
        @romanize(l)
        def greeting():
            return 'Привет, друг!'
        return greeting()

    assert get_greeting() == 'privet, drug!'
    assert get_greeting(Locale.EN) == 'privet, drug!'
    assert get_greeting(Locale.UK) == 'privet, drug!'
    assert get_greeting(Locale.KK) == 'privet, drug!'

# Generated at 2022-06-23 20:53:38.490548
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_func(text: str) -> str:
        return text

    assert test_func('Новый год наступил!') == 'Novyy god nastupil!'

# Generated at 2022-06-23 20:53:44.778801
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'привет')() \
        == romanize(locale='ru')(lambda: 'привет')()
    assert romanize(locale='uk')(lambda: 'привет')() \
        == romanize(locale='uk')(lambda: 'привет')()
    assert romanize(locale='kk')(lambda: 'привет')() \
        == romanize(locale='kk')(lambda: 'привет')()

# Generated at 2022-06-23 20:53:47.652506
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanized(locale='ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:53:57.655203
# Unit test for function romanize
def test_romanize():
    @romanize(locale='kk')
    def _test_romanize(self):
        return 'Өлқен желімнің өлшемі'

    assert _test_romanize(None) == 'Ölken jelemniñ ölşemi'

    @romanize(locale='uk')
    def _test_romanize2(self):
        return 'Маленький підземний тваринний світ'

    assert _test_romanize2(None) == 'Malenʹkyĭ pizemnyĭ tvarynnyĭ svit'



# Generated at 2022-06-23 20:53:58.695555
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)

# Generated at 2022-06-23 20:54:04.789152
# Unit test for function romanize
def test_romanize():
    romanized_str = romanize(locale='uk')(lambda x: 'Вірна подукція')()
    assert romanized_str == 'Virna poduktsiia', 'Expected: Virna poduktsiia, got: {}'.format(romanized_str)

# Generated at 2022-06-23 20:54:11.648296
# Unit test for function romanize
def test_romanize():
    n = 10
    length = 20
    pattern = data.ROMANIZATION_DICT['ru']

    @romanize('ru')
    def romanize_func(*args, **kwargs):
        """Romanize function."""
        return ''.join(pattern.keys())

    romanized_text = romanize_func(n=n, length=length)
    assert len(romanized_text) == 20
    assert romanized_text == ''.join(pattern.values())

# Generated at 2022-06-23 20:54:15.857463
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address

    address = Address(Language.RUSSIAN)

    result = address.street_name(romanize=True)
    assert any([c in result for c in ascii_letters])

# Generated at 2022-06-23 20:54:16.528652
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:54:23.563293
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Гарри')(0) == 'Garry'
    assert romanize('uk')(lambda: 'Гаррі')(0) == 'Garry'
    assert romanize('kk')(lambda: 'Гарри')(0) == 'Garry'

    # Test for unsupported locale
    try:
        romanize('asd')(lambda: 'Гарри')
    except UnsupportedLocale:
        pass
    else:
        raise AssertionError("Should have raised an exception.")

# Generated at 2022-06-23 20:54:26.555864
# Unit test for function romanize
def test_romanize():
    def string_generator(locale):
        return lambda x: romanized(locale)(lambda: 'Пример предложения.')(x)

    for locale in ['ru', 'uk', 'kk']:
        assert string_generator(locale)(0) == 'Primer predlozheniya.'

# Generated at 2022-06-23 20:54:34.651254
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_id():
        return "ИЮНЬСКИЙ"
    assert russian_id() == 'IJUNSKIJ'

    @romanize(locale='uk')
    def ukrainian_id():
        return "КОМУНІКАЦІЯ"
    assert ukrainian_id() == 'KOMUNIKACIYA'

    @romanize(locale='kk')
    def kazakh_id():
        return "ӨСІМ"
    assert kazakh_id() == 'ÖSIM'



# Generated at 2022-06-23 20:54:42.150320
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    from mimesis.builtins.text import Text

    text = Text()
    rus = text.romanize('Привет, мимими!')
    ukr = text.romanize('Привіт, мимими!')
    kaz = text.romanize('Сәлем, мимими!')
    assert rus == 'Privet, mimimi!'
    assert ukr == 'Pryvit, mimimi!'
    assert kaz == 'Sälem, mimimi!'

# Generated at 2022-06-23 20:54:49.849622
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import (
        BelarusSpecProvider,
        KazakhstanSpecProvider,
        RussiaSpecProvider,
    )

    # Belarus
    be = BelarusSpecProvider()
    assert be.full_name() == be.full_name(romanize=True)

    # Kazakhstan
    kz = KazakhstanSpecProvider()
    assert kz.full_name() == kz.full_name(romanize=True)

    # Russia
    ru = RussiaSpecProvider()
    assert ru.full_name() == ru.full_name(romanize=True)



# Generated at 2022-06-23 20:55:00.120673
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize
    """
    import mimesis.builtins

    class Fake:

        @romanize('uk')
        def method(self):
            return 'Привіт, світ'

    assert Fake().method() == 'Pryvit, svit'
    assert mimesis.builtins.Person(locale='uk').first_name == 'Oleksandr'

    class Fake2:

        @romanize('ru')
        def method(self):
            return 'Привет, мир'

    assert Fake2().method() == 'Privet, mir'
    assert mimesis.builtins.Person().first_name == 'Алексей'



# Generated at 2022-06-23 20:55:02.076930
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Вадим')() == 'Vadim'

# Generated at 2022-06-23 20:55:08.457114
# Unit test for function romanize
def test_romanize():
    # An example with locale en_US.
    assert romanized('en-US')(lambda: 'Привет! Как дела?')() == \
        romanized('en-US')(lambda: 'Privet! Kak dela?')()
    assert romanized('ru')(lambda: 'Privet! Kak dela?')() == \
        romanized('ru')(lambda: 'Привет! Как дела?')()
    assert romanized('uk')(lambda: 'Привет! Как дела?')() == \
        romanized('uk')(lambda: 'Pryvit! Jak dila?')()

# Generated at 2022-06-23 20:55:13.890882
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda: 'лопата')().startswith('lopata')
    assert romanize('ru')(lambda: 'промерзли')().startswith('promerzli')
    assert romanize('kk')(lambda: 'болып табылады')().startswith('bolyp tabylady')

# Generated at 2022-06-23 20:55:16.148326
# Unit test for function romanize
def test_romanize():
    assert callable(romanized)

    # Test that decorator applied
    @romanized()
    def find_word(word):
        return word

    res = find_word('Привет!')
    assert res == 'Privet!'

# Generated at 2022-06-23 20:55:17.774599
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:55:23.503905
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'текст')() == 'tekst'
    assert romanize(locale='uk')(lambda: 'текст')() == 'tekst'
    assert romanize(locale='kk')(lambda: 'текст')() == 'tekst'

# Generated at 2022-06-23 20:55:29.926579
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize.__name__ == 'romanize'
    assert romanize.__doc__ == 'Romanize the cyrillic text.\n\n    Transliterate the cyrillic script into the latin alphabet.\n\n    .. note:: At this moment it works only for `ru`, `uk`, `kk`.\n\n    :param locale: Locale code.\n    :return: Romanized text.\n    '

# Generated at 2022-06-23 20:55:32.070777
# Unit test for function romanize
def test_romanize():
    test_string = u'Привет!'
    test_translated = u'Privet!'
    assert romanize(locale='ru')(lambda : test_string)() == test_translated

# Generated at 2022-06-23 20:55:39.521747
# Unit test for function romanize
def test_romanize():
    import string
    alphabet = string.ascii_letters + string.digits + string.punctuation

    def romanize(x, alphabet):
        romanize_alphabet = {
            **data.ROMANIZATION_DICT['ru'],
            **data.COMMON_LETTERS,
        }
        return ''.join([romanize_alphabet.get(i, i) for i in x if i in alphabet])

    def random_string(alphabet, n=20):
        import random
        return ''.join(random.choice(alphabet) for _ in range(n))

    for _ in range(100):
        assert romanize(random_string(alphabet), alphabet) == \
            romanize(random_string(alphabet), alphabet)

# Generated at 2022-06-23 20:55:42.912326
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_name() -> str:
        # Russian name
        return 'Михаил'
    assert get_name() == 'Mikhail'

# Generated at 2022-06-23 20:55:46.498115
# Unit test for function romanize
def test_romanize():
    romanize_locale = romanize(locale='kk')

    @romanize_locale
    def foo():
        return 'Фильм'

    assert 'Fïlm' == foo()

# Generated at 2022-06-23 20:55:50.154884
# Unit test for function romanize
def test_romanize():
    func = lambda x: x[:8]

    @romanize(locale='ru')
    def f(x):
        return func(x)

    assert f('asfasdfasdfasdf') == 'asfasdfa'

# Generated at 2022-06-23 20:55:54.654146
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'мимими')() == 'mimimi'
    assert romanize('ru')(lambda : 'привет')() == 'privet'
    assert romanize('uk')(lambda : 'ізбране')() == 'izbrane'

# Generated at 2022-06-23 20:55:58.085550
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: "Миша")() == "Misha"
    assert romanized('uk')(lambda: "Миша")() == "Mysha"
    assert romanized('kk')(lambda: "Миша")() == "Mysha"

# Generated at 2022-06-23 20:56:08.025086
# Unit test for function romanize
def test_romanize():

    @romanize('ru')
    def russian_test():
        return "Привет, друг!"

    assert russian_test() == "Privet, drug!"

    @romanize('uk')
    def ukrainian_test():
        return "Привіт, друг!"

    assert ukrainian_test() == "Pryvit, druh!"

    @romanize('kk')
    def kazakh_test():
        return "Сәлем, дос!"

    assert kazakh_test() == "Sälem, dos!"

# Generated at 2022-06-23 20:56:09.797266
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    assert romanize(locale='ru')



# Generated at 2022-06-23 20:56:18.530944
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Ой, это не правильно!')() == 'Oj, eto ne pravilno!'
    assert romanize('uk')(lambda x: 'Ой, це не правильно!')() == 'Oj, ce ne pravylno!'
    assert romanize('kk')(lambda x: 'Ой, это не правильно!')() == 'Oy, eta nede pravylno!'

# Generated at 2022-06-23 20:56:23.400016
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_random_string(length=10, chars=None):
        return 'боже мой, что за погода'

    assert get_random_string() == 'bozhe moi, chto za pogoda'

# Generated at 2022-06-23 20:56:33.735328
# Unit test for function romanize
def test_romanize():
    # romanize('ru')
    assert romanize('ru')(lambda: 'Абвгдеёжзийклмнопрстуфхцчшщъыьэюя')() == \
        'Abvgdeëžzïkľmnoprstufhcçšŝăïběûâ'

    # romanize('uk')

# Generated at 2022-06-23 20:56:40.140920
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""

    @romanize('ru')
    def ru():
        return 'Узбекистан, является путешествиями вдоль национальный парк.'

    ru() == 'Uzbekistan, yavlyayetsya puteshestviya-mi vdol natsionalnyi par-k.'



# Generated at 2022-06-23 20:56:49.492617
# Unit test for function romanize
def test_romanize():
    alph = 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'
    assert romanize()(alph) == 'abvgdeëžzińklmnoprstufhcčšŝƶʺyʹèûâ'
    assert romanized()(alph) == 'abvgdeëžzińklmnoprstufhcčšŝƶʺyʹèûâ'



# Generated at 2022-06-23 20:56:59.339298
# Unit test for function romanize
def test_romanize():
    import string
    import random
    import mimesis.locales as lc

    alphabet = ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~'

    @romanize('ru')
    def roman():
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))

    assert roman()
    assert len(roman()) == 10

    @romanized('ru')
    def roman():
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))

    assert roman()
   

# Generated at 2022-06-23 20:57:02.479369
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'тест') == 'test'
    assert romanized('uk')(lambda: 'тест') == 'test'
    assert romanized('kk')(lambda: 'тест') == 'test'

# Generated at 2022-06-23 20:57:14.409456
# Unit test for function romanize
def test_romanize():
    assert 'а' == romanize(locale='ru')(lambda: 'а')()
    assert 'б' == romanize(locale='ru')(lambda: 'б')()
    assert 'в' == romanize(locale='ru')(lambda: 'в')()
    assert 'г' == romanize(locale='ru')(lambda: 'г')()
    assert 'д' == romanize(locale='ru')(lambda: 'д')()
    assert 'е' == romanize(locale='ru')(lambda: 'е')()
    assert 'ё' == romanize(locale='ru')(lambda: 'ё')()
    assert 'ж' == romanize(locale='ru')(lambda: 'ж')()

# Generated at 2022-06-23 20:57:17.710696
# Unit test for function romanize
def test_romanize():
    """Test if the romanized text are correct."""
    from .enumeration import Enumeration

    en = Enumeration()
    if en.locale == 'ru':
        assert en.romanize('Я русский язык') == 'YA russkij yazyk'



# Generated at 2022-06-23 20:57:20.690762
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test_data():
        return 'яблоко'

    assert test_data() == 'yabloko'

# Generated at 2022-06-23 20:57:25.479424
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'от ста до столетия')().lower() == 'ot s' \
                                                                    'ta do' \
                                                                    ' stoleti' \
                                                                    'a'

# Generated at 2022-06-23 20:57:33.427801
# Unit test for function romanize

# Generated at 2022-06-23 20:57:37.390082
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    from mimesis.enums import Language

    t = Text(Language.RU)
    assert(t.romanize(t.word()) == 'privet')

# Generated at 2022-06-23 20:57:39.958594
# Unit test for function romanize
def test_romanize():
    r = romanize('ru')
    @r
    def rus():
        return 'Привет!'
    assert rus() == 'Privet!'

# Generated at 2022-06-23 20:57:49.606813
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    r = romanize('ru')

    def roman(s):
        return romanize('ru')(lambda: s)()

    assert roman('Тестирование романизации кириллицы') == 'Tesirovanie romanizatsii kirillitsy'
    assert roman('Тестирование романизации кириллицы') == 'Tesirovanie romanizatsii kirillitsy'