

# Generated at 2022-06-23 20:47:47.602412
# Unit test for function romanize
def test_romanize():
    import pprint
    from mimesis.enums import Locale

    expected = 'Privet, kak dela? YA tvoy isklyuchitelnyy drug, kogda mne tuda nado!'
    result = data.Text(Locale.RU).romanize('Privet, как дела? Я твой исключительный друг, когда мне туда надо!')
    assert result == expected

    # Double decorators
    @romanize('ru')
    @romanize('ru')
    def get_text(text: str) -> str:
        return text



# Generated at 2022-06-23 20:47:54.847510
# Unit test for function romanize
def test_romanize():
    text = ['Est doloribus atque.',
            'Довольно тока быстрой проверки падежей на Python.']
    expected = ['Est doloribus atque.', 'Dovolno toka bystroj proverki pad'
                                        'jezov na Python.']

    for i, item in enumerate(text):
        assert romanize()(item) == expected[i]

# Generated at 2022-06-23 20:48:01.508775
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Всем привет!')() == 'Vsem privet!'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-23 20:48:06.649557
# Unit test for function romanize
def test_romanize():
    """Romanize function test."""
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanized(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'

# Generated at 2022-06-23 20:48:13.080814
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    from mimesis.enums import Locale
    t = Text()
    r = t.romanize
    txt_ru = t.word()
    txt_uk = r.word(locale=Locale.UK)
    txt_kk = r.word(locale=Locale.KAZAKH)
    assert isinstance(txt_ru, str)
    assert isinstance(txt_uk, str)
    assert isinstance(txt_kk, str)

# Generated at 2022-06-23 20:48:19.321133
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_fun(s: str = '') -> str:
        return s

    txt = test_fun('КАК ИЗБАВИТЬСЯ ОТ ПАРАЗИТОВ')
    assert txt == 'KAK IZBAVISYA OT PARAZITOV'

# Generated at 2022-06-23 20:48:20.776811
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func():
        return 'тест'

    assert func() == 'test'

# Generated at 2022-06-23 20:48:26.240266
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Съешь ещё этих мягких французских булок')() == 'Sʺesʹ eshche etikh miasʹkikh frantsuzskikh bulok'

# Generated at 2022-06-23 20:48:26.816194
# Unit test for function romanize
def test_romanize():
    assert romanize

# Generated at 2022-06-23 20:48:31.850957
# Unit test for function romanize
def test_romanize():
    # TODO: This test should be moved to another test.
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    ad = Address(Locale.RU)
    ru = ad.full_address()

    @romanize(locale='ru')
    def ru_func():
        return ru

    assert ru == ru_func()

# Generated at 2022-06-23 20:48:34.185380
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(str)('') == ''
    assert romanize('ru')(str)('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-23 20:48:41.890519
# Unit test for function romanize
def test_romanize():
    def foo(text):
        return text

    @romanized('ru')
    def bar(text):
        return text

    assert bar('Давай') == 'Davaj'
    assert bar('Возьми с собой') == 'Voz’mi s soboj'
    assert foo('Сколько будет два плюс два?') == 'Сколько будет два плюс два?'

# Generated at 2022-06-23 20:48:48.741768
# Unit test for function romanize
def test_romanize():
    def romanize_ua(s):
        return romanize('uk')(s)()

    assert romanize_ua('Слово') == 'Slovo'
    assert romanize_ua('Обчислення') == 'Obchyslennya'
    assert romanize_ua('Україна') == 'Ukrayina'
    assert romanize_ua('Ує мені просто свої слова.') == \
           'Uie meni prosto svoyi slova.'
    assert romanize_ua('Харківська') == 'Kharkivska'

# Generated at 2022-06-23 20:48:55.353024
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider()

    # Previous version
    # Test 1
    assert provider.romanized(provider.name(), locale='ru') != ''

    # Test 2
    assert provider.romanized(provider.patronymic(), locale='ru') != ''

    # Test 3
    assert provider.romanized(provider.surname(), locale='ru') != ''

    # Test 4
    assert provider.romanized(provider.address()) == ''

# Generated at 2022-06-23 20:48:58.541427
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize.

    :return: None
    """
    string = 'Всем привет'
    romanized_string = 'Vsem privet'
    assert romanize('ru')(string) == romanized_string

# Generated at 2022-06-23 20:49:01.582839
# Unit test for function romanize
def test_romanize():
    assert romanize()('Как дела?') == 'Kak dela?'
    assert romanize('kk')('Абайтын кенесе') == 'Abaıtın kenesе'

# Generated at 2022-06-23 20:49:12.765600
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime


# Generated at 2022-06-23 20:49:18.722422
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins
    builtins = mimesis.builtins.Builtins()
    assert builtins.person.full_name(locale='ru') == 'Алексей Иванов'
    assert builtins.person.full_name(locale='uk') == 'Іван Іванів'
    assert builtins.person.full_name(locale='kk') == 'Айдар Омаров'

    assert builtins.person.full_name(locale='ru-RU') == 'Алексей Иванов'

# Generated at 2022-06-23 20:49:24.279521
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize('ru')(lambda: 'Собака')() == 'Sobaka'
    assert romanize('uk')(lambda: 'Собака')() == 'Sobaka'
    assert romanize('kk')(lambda: 'Собака')() == 'Sobaka'

# Generated at 2022-06-23 20:49:27.757799
# Unit test for function romanize
def test_romanize():
    assert romanize.__doc__ is not None
    assert romanize.__name__ == 'romanize'
    assert romanize.__annotations__ == {'locale': str, 'return': Callable}



# Generated at 2022-06-23 20:49:30.568056
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def my_string():
        return 'Александр'

    assert my_string() == 'Aleksandr'


# Check if function romanize works with locale {}

# Generated at 2022-06-23 20:49:33.592501
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')('Алтын 29 сәуір 2020 жыл') == 'Altın 29 säwir 2020 jıl'



# Generated at 2022-06-23 20:49:39.847755
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    person = Person('ru')
    address = Address('ru')
    person_ru = Person('uk')

    name = person.full_name(gender=Gender.FEMALE)
    name = address.street_name().title()
    assert romanize('ru')(person.full_name)(gender=Gender.FEMALE) == name
    assert romanize('ru')(address.street_name)().title() == name
    assert romanize('uk')(person_ru.full_name)(
        gender=Gender.FEMALE) == name
    assert romanize('uk')(address.street_name)().title() == name

# Generated at 2022-06-23 20:49:49.777015
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def g():
        return 'Я очень рад, но никак не так рад, как мы радовались.'

    assert g() == 'Я ochen rad, no nikak ne tak rad, kak my radovalis.'

    @romanize('uk')
    def g():
        return 'Я зовсім задоволений, але не як так задоволений, як ми задоволені.'


# Generated at 2022-06-23 20:49:57.731583
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda x: 'Иванов')() == 'Ivanov'
    assert romanized('ru')(lambda x: 'Иванов')() == 'Ivanov'
    assert romanized('uk')(lambda x: 'колесо')() == 'koleso'
    assert romanized('kk')(lambda x: 'тармақша')() == 'tarmaqsha'

# Generated at 2022-06-23 20:49:58.320614
# Unit test for function romanize
def test_romanize():
    assert romanized()

# Generated at 2022-06-23 20:49:59.616093
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'тест') == 'test'

# Generated at 2022-06-23 20:50:03.744535
# Unit test for function romanize
def test_romanize():

    @romanized('ru')
    def test_ru():
        return 'Русский'

    assert test_ru() == 'Russkiy'

    @romanized('uk')
    def test_uk():
        return 'Український'

    assert test_uk() == 'Ukrayinsʹkyy'

    @romanized('kk')
    def test_kk():
        return 'Қазақша'

    assert test_kk() == 'Qazaqşa'

    @romanized
    def test_mix():
        return 'Русский Український Қазақша'


# Generated at 2022-06-23 20:50:07.144662
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    text = Text(Locale.RUSSIAN)
    romanized = text.romanize()
    assert all(char in ascii_letters + digits + punctuation
               for char in romanized)

# Generated at 2022-06-23 20:50:14.845660
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person as P
    p = P()
    person = p.full_name()
    assert p._romanize(person) == p.romanize(person)
    assert p._romanize(person, locale='ru') == p.romanize(person, locale='ru')
    assert p._romanize(person, locale='uk') == p.romanize(person, locale='uk')
    # language that is not in the romanization dictionary
    assert p._romanize(person, locale='en') == p.romanize(person, locale='en')

# Generated at 2022-06-23 20:50:19.655897
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Король')() == 'Korol'
    assert romanized('uk')(lambda: 'Король')() == 'Korol'
    assert romanized('kk')(lambda: 'Король')() == 'Korol'
    assert romanized('ee')(lambda: 'Король')() == 'Король'

# Generated at 2022-06-23 20:50:26.893788
# Unit test for function romanize
def test_romanize():
    @romanize('en')
    def roman_en():
        return 'Й'

    assert roman_en() == 'Y'

    @romanize('ru')
    def roman_ru():
        return 'Эй'

    assert roman_ru() == 'Eĭ'

    @romanize('uk')
    def roman_uk():
        return 'Эй'

    assert roman_uk() == 'Eĭ'

    @romanize('kk')
    def roman_kk():
        return 'Эй'

    assert roman_kk() == 'Eı'

# Generated at 2022-06-23 20:50:29.395506
# Unit test for function romanize
def test_romanize():
    assert romanize()('Бородин Сергей') == 'Borodin Sergei'

# Generated at 2022-06-23 20:50:38.668834
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'

    @romanize(locale='uk')
    def uk_romanize(seed: int = None) -> str:
        return data.Data(seed).romanized_string(
            locale='uk',
            length=15,
            alphabet=(
                ascii_letters + digits + punctuation
            )
        )

    assert uk_romanize() == 'HELLO, MIMESĬS'
    assert uk_romanize(seed=42) == 'HELLO, MIMESĬS'



# Generated at 2022-06-23 20:50:40.506319
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'тест')().startswith('t')

# Generated at 2022-06-23 20:50:49.926657
# Unit test for function romanize
def test_romanize():
    import pytest

    from mimesis.enums import Locale
    from mimesis.builtins.numbers import NumberStrategy
    from mimesis.builtins.text import TextSpecification

    @romanize(locale=Locale.RU)
    def test_cyrillic():
        text = TextSpecification(locale=Locale.RU)
        return text.word()

    @romanize(locale=Locale.EN)
    def test_ascii():
        number = NumberStrategy(locale=Locale.EN)
        return number.numeronym()

    assert isinstance(test_cyrillic(), str)
    assert len(test_cyrillic()) > 0

    assert isinstance(test_cyrillic(), str)
    assert len(test_ascii()) > 0

   

# Generated at 2022-06-23 20:50:52.796423
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanized(locale='kk')(lambda: 'Не паникуйте.')() == 'Ne panikujte.'

# Generated at 2022-06-23 20:50:54.285467
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'hello')() == 'hello'

# Generated at 2022-06-23 20:51:01.810554
# Unit test for function romanize
def test_romanize():
    """Test of romanize decorator with ru locale."""
    @romanize('ru')
    def get_fullname(token: str = ' ') -> str:
        """Get full name with token."""
        return token.join([
            data.PERSON_FULL_NAME['name:ru'].get_token(),
            data.PERSON_FULL_NAME['surname:ru'].get_token(),
        ])

    assert get_fullname() == 'Андрей Иванов'

    @romanize('ru')
    def random_text_generator() -> str:
        """Random text generator."""
        letters = {s: s for s in ascii_letters + punctuation}

# Generated at 2022-06-23 20:51:05.819709
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo():
        return 'Привет, мир!'

    assert foo() == 'Privet, mir!'

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:51:07.999505
# Unit test for function romanize
def test_romanize():
    def foo():
        return 'тест'

    func = romanize('uk')(foo)
    assert func() == 'test'

# Generated at 2022-06-23 20:51:19.475206
# Unit test for function romanize
def test_romanize():
    assert romanize()('Одесса') == 'Odessa'
    assert romanize()('Одесса') == 'Odessa'
    assert romanize('uk')('Одеса') == 'Odesa'
    assert romanize('uk')('пошта') == 'poshta'
    assert romanize('kk')('Пошта') == 'Poşta'
    assert romanize('kk')('Пошта') == 'Poşta'
    assert romanize('ru')('пошта') == 'pochta'
    assert romanize('ru')('пошта') == 'pochta'

# Generated at 2022-06-23 20:51:26.807507
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: "Абвгдежзийклмнопрстуфхцчшщъыьэюя")() == "Abvgdezhzijklmnoprstufxccxssjjyjejuja"

    assert romanized('ru')(lambda: "Абвгдежзийклмнопрстуфхцчшщъыьэюя")() == "Abvgdezhzijklmnoprstufxccxssjjyjejuja"


# Generated at 2022-06-23 20:51:33.092498
# Unit test for function romanize
def test_romanize():
    test = "Святая Святых ёлка, щас ты будешь переведёна в латиницу"
    result = "Svyataya Svyatyh yolka, shcas ty budesh perevedyona v latinitsu"
    assert romanize()(lambda x: test)(test) == result
    assert romanize(locale='ru')(lambda x: test)(test) == result
    assert romanize(locale='uk')(lambda x: test)(test) == result
    assert romanize(locale='kk')(lambda x: test)(test) == result

# Generated at 2022-06-23 20:51:40.317897
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    from mimesis.data import ROMANIZATION_DICT
    from mimesis.data import COMMON_LETTERS

    def greeting(locale='ru'):
        """Greeting."""
        return 'Здравствуйте! Будьте добры, выберите пожалуйста файл.'

    assert greeting(locale='ru') == 'Здравствуйте! Будьте добры, выберите пожалуйста файл.'

# Generated at 2022-06-23 20:51:43.044749
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Что-то по-русски')() == 'Chto-to po-russki'

# Generated at 2022-06-23 20:51:52.651403
# Unit test for function romanize
def test_romanize():
    romanization_dict = data.ROMANIZATION_DICT["ru"]
    for k, v in romanization_dict.items():
        assert romanization_dict[k] == v
    assert romanization_dict["А"] == "A"



# Generated at 2022-06-23 20:51:57.241706
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-23 20:52:01.806528
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address

    address = Address('ru')
    assert address.building_name() in data.BUILDING_NAMES['ru']

    address = Address('en')
    assert address.building_name() in data.BUILDING_NAMES['en']

# Generated at 2022-06-23 20:52:10.339017
# Unit test for function romanize
def test_romanize():
    import pytest

    with pytest.raises(UnsupportedLocale):
        romanize('en')(lambda: "hello")()

    assert (romanize('ru')(lambda: "привет петр")() ==
            "pryviet pietr")

    assert (romanize('uk')(lambda: "привіт петро")() ==
            "pryvit pietro")

    assert (romanize('kk')(lambda: "привет петр")() ==
            "pryviet pietr")

# Generated at 2022-06-23 20:52:19.002785
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    ru = RussiaSpecProvider()
    ru_male = RussiaSpecProvider()
    ru_male.gender = Gender.MALE
    ru_female = RussiaSpecProvider()
    ru_female.gender = Gender.FEMALE
    ru_male_str = ru_male.full_name(gender=Gender.MALE)
    ru_female_str = ru_female.full_name(gender=Gender.FEMALE)
    ru_str = ru.full_name()

    ru_male_str = ru_male.full_name(gender=Gender.MALE)
    ru_female_str = ru_female.full_name(gender=Gender.FEMALE)
    ru_str = ru.full_name()

    ru_male

# Generated at 2022-06-23 20:52:23.227316
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    test_string = 'ВКонтакте'

    @romanize(locale='ru')
    def foo(value):
        """Test function."""
        return value

    assert(foo(test_string) == 'VKontakte')

# Generated at 2022-06-23 20:52:23.811236
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:52:27.354452
# Unit test for function romanize
def test_romanize():
    # Test method with custom locale
    assert romanize(locale='ru')(str)().startswith('\u0440') is True

    # Test method without custom locale
    assert romanize()(str)().startswith('\u0440') is True



# Generated at 2022-06-23 20:52:33.272526
# Unit test for function romanize
def test_romanize():
    alphabet = 'АаБбВвГгДдЕеЁёЖжЗзИиЙйКкЛлМмНнОоПпРрСсТтУуФфХхЦцЧчШшЩщЪъЫыЬьЭэЮюЯя'
    romanization = 'AaBbVvGgDdEeYoYoZhzhZzIiYiyKkLlMmNnOoPpRrSsTtUuFfKhkhTsctsChchShshShsh"yYy\'eEyuIa'

# Generated at 2022-06-23 20:52:36.285610
# Unit test for function romanize
def test_romanize():
    locals()['test_romanize'] = romanize(locale='ru')(test_romanize)
    return 'Тестирование'

# Generated at 2022-06-23 20:52:45.134485
# Unit test for function romanize
def test_romanize():
    import re
    from mimesis.ptools import remove_indents
    from mimesis.builtins import Person
    from mimesis import Generic
    from mimesis.builtins import RussianSpecProvider

    g = Generic(locale='ru')
    p = Person(locale='ru')

    class CustomProvider(RussianSpecProvider):
        @romanized()
        def full_name(self) -> str:
            return super(CustomProvider, self).full_name()+'test'

    cp = CustomProvider()

    assert re.match(r'\w', cp.full_name())

    assert re.match(r'[a-zA-Z]', g.person.full_name())
    assert re.match(r'[a-zA-Z]', p.full_name())



# Generated at 2022-06-23 20:52:47.654897
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def generate_name(locale: str = '') -> str:
        return 'Александр'

    assert generate_name() == 'Aleksandr'

# Generated at 2022-06-23 20:52:48.993303
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_function():
        return 'Текст'

    assert test_function() == 'Tekst'

# Generated at 2022-06-23 20:52:51.256401
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import TextSpecification

    text = TextSpecification('ru')
    assert text.romanize() != ''

# Generated at 2022-06-23 20:52:54.265450
# Unit test for function romanize
def test_romanize():
    # When romanize is called
    text = data.Person('ru').full_name()
    # Then romanized is returned
    assert isinstance(text, str)
    assert text not in data.ROMANIZATION_DICT['ru'].values()

# Generated at 2022-06-23 20:53:02.449131
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(str)('Кокос') == 'Kokos'
    assert romanize('uk')(str)('Кокос') == 'Kokos'
    assert romanize('kk')(str)('Кокос') == 'Kokos'
    assert romanize('ru')(str)('КокосКокос') == 'KokosKokos'
    assert romanize('ru')(str)('КокосKокос') == 'KokosKokos'

# Generated at 2022-06-23 20:53:05.721438
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian():
        return 'Привет, мир!'

    assert russian() == 'Privet, mir!'

# Generated at 2022-06-23 20:53:09.654903
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    person = Person(Language.UK)
    address = Address(Language.UK)
    print(''.join([person.full_name(), ' ', address.address()]))

# Generated at 2022-06-23 20:53:14.000273
# Unit test for function romanize
def test_romanize():
    test = romanize('ru')
    @test
    def romanize_test():
        return "Югославская Народная Республика"

    assert romanize_test() == 'Yugoslavskaya Narodnaya Respublika'

# Generated at 2022-06-23 20:53:22.638360
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    text = 'Добро пожаловать в Россию!'
    romanized_text = 'Dobro pozhalovatʹ v Rossiyu!'

    @romanize(locale='ru')
    def russian_text():
        return text

    russian = RussiaSpecProvider()
    assert russian.address.full_address() == 'г. Санкт-Петербург, ул. Садовая, д. 19, кв. 169'
    assert russian_text() == romanized_text

# Generated at 2022-06-23 20:53:30.693996
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет, Мир!') == 'Privet, Mir!'
    assert romanized('ru')('Привет, Мир!') == 'Privet, Mir!'
    assert romanized(locale='ru')('Привет, Мир!') == 'Privet, Mir!'
    assert romanized('uk')('Привіт, Світ!') == 'Pryvit, Svit!'
    assert romanized('kk')('Сәлем Әлем!') == 'Salem Alem!'

# Generated at 2022-06-23 20:53:36.719524
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Металлическая коробка')() == 'Metallichieskaia korobka'
    assert romanize('ru')(lambda: 'Металлическая коробка')() == 'Metallichieskaia korobka'
    assert romanize('uk')(lambda: 'Металева коробка')() == 'Metaleva korobka'
    assert romanize('kk')(lambda: 'Металдық қабырға')() == 'Metadık qabırğa'

# Generated at 2022-06-23 20:53:38.040175
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda: 'Ж')() in 'Zh'

# Generated at 2022-06-23 20:53:39.296755
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo(x):
        return 'Серік'

    assert foo(1) == 'Serik'

# Generated at 2022-06-23 20:53:44.629249
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def roman():
        return 'Директор должен продолжать работать'

    assert roman() == 'Direktor dolzhen prodolzhat rabotat'

# Generated at 2022-06-23 20:53:50.533908
# Unit test for function romanize
def test_romanize():
    @romanize(locale='RU')
    def rome():
        return data.ROMANIZATION_DICT['ru']

    assert rome() == "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,;:()[]{}-\"'"



# Generated at 2022-06-23 20:53:51.247998
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:53:57.418175
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'мама мыла раму')() == 'mama myla ramu'
    assert romanize('uk')(lambda: 'мама мила раму')() == 'mama mila ramu'
    assert romanize('kk')(lambda: 'мама мыла раму')() == 'ma\'ma mılda ramw'



# Generated at 2022-06-23 20:54:02.752706
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    @romanize(locale=Locale.RU)
    def test():
        return 'Привет, как дела?'

    assert test() == 'Privet, kak dela?'

# Generated at 2022-06-23 20:54:06.287986
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def roman():
        return 'Привет мир!'

    assert roman() == 'Privet mir!'



# Generated at 2022-06-23 20:54:12.282744
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    # Short greetings
    @romanize(locale='ru')
    def say_hello():
        return 'Привет мир'

    @romanize('ru')
    def say_hello_1():
        return 'Привет мир'

    assert say_hello() == say_hello_1() == 'Privet mir'
    assert say_hello.__name__ == 'say_hello'
    assert say_hello.__doc__ == 'Romanize the cyrillic text.'

    @romanize('kk')
    def say_hello_2():
        return 'Сәлем әлем'

    assert say_hello_2() == 'Salem além'


# Generated at 2022-06-23 20:54:22.044702
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    ru = romanized('ru')
    uk = romanized('uk')
    kk = romanized('kk')
    assert ru
    assert uk
    assert kk

    @ru
    def ru_txt():
        """Generate russian text."""
        return 'Съешь ещё этих мягких французских булок'

    @uk
    def uk_txt():
        """Generate ukrainian text."""

# Generated at 2022-06-23 20:54:24.627604
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    @romanize('ru')
    def test(thing):
        return thing
    assert test(thing='йцукен') == 'ytsuken'

# Generated at 2022-06-23 20:54:27.901463
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-23 20:54:29.628350
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    # @TODO: Fix it
    pass

# Generated at 2022-06-23 20:54:32.802463
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('uk')
    assert p.username(Gender.MALE) == 'Тонтова Єлизавета'

# Generated at 2022-06-23 20:54:34.896656
# Unit test for function romanize
def test_romanize():
    # Example of romanize
    assert romanized('ru')(lambda: 'Привет')() == 'Privyet'

# Generated at 2022-06-23 20:54:43.429616
# Unit test for function romanize
def test_romanize():
    import re
    import random
    from mimesis.builtins import Person
    from mimesis.providers.internet import Internet
    from mimesis.providers.date_time import DateTime

    person = Person(locale='ru')
    internet = Internet('ru')
    dt = DateTime('ru')
    # Generate test dataset
    d = [person.full_name() for _ in range(random.randint(10, 30))]
    d += [internet.email(d[random.randint(0, len(d) - 1)]) for _ in range(random.randint(10, 30))]
    d += [dt.datetime().strftime('%d.%m.%Y') for _ in range(random.randint(10, 30))]

# Generated at 2022-06-23 20:54:46.309046
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test_1():
        return 'Привет, мир!'

    assert test_1() == 'Privet, mir!'

# Generated at 2022-06-23 20:54:49.953032
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Я люблю Мимисус')() == 'Ya lublyu Mimus'



# Generated at 2022-06-23 20:54:52.381276
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize()('А') == 'A'


__all__ = ['romanized']

# Generated at 2022-06-23 20:54:54.013759
# Unit test for function romanize
def test_romanize():
  assert romanize()('Привет') == 'privet'

# Generated at 2022-06-23 20:55:03.288426
# Unit test for function romanize
def test_romanize():
    def foo():
        return 'Предоставьте доступ к домену, чтобы продолжить.'

    romanize_foo = romanize('ru')(foo)
    assert romanize_foo() == 'Predostav\'te dostup k domenu, chtoby prodolzhit.'

    romanize_foo = romanize('uk')(foo)
    assert romanize_foo() == 'Predostav\'te dostup do domeni, shchob prodovzhyty.'

    romanize_foo = romanize('kk')(foo)

# Generated at 2022-06-23 20:55:11.956793
# Unit test for function romanize
def test_romanize():
    txt = 'Добрый день, меня зовут Иванов'
    f = romanize('ru')

# Generated at 2022-06-23 20:55:14.670931
# Unit test for function romanize
def test_romanize():
    def romanize_test(test_str):
        romanized = test_str.translate(data.ROMANIZATION_DICT['ru'])
        assert romanize_test(test_str) == romanized

    test_romanize('Тест')

# Generated at 2022-06-23 20:55:18.991779
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize('uk')('Привіт') == 'Pryvit'
    assert romanize('kk')('Сәлем') == 'Salem'

# Generated at 2022-06-23 20:55:25.462320
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    from mimesis.builtins import RussiaSpecProvider

    rsp = RussiaSpecProvider()

    @romanize()
    def foo_ru():
        return rsp.first_name()

    @romanize(locale='ru')
    def foo_ru2():
        return rsp.first_name()

    @romanize('uk')
    def foo_uk():
        return rsp.first_name()

    @romanized()
    def foo_ru3():
        return rsp.first_name()

    @romanized(locale='ru')
    def foo_ru4():
        return rsp.first_name()

    @romanized('uk')
    def foo_uk2():
        return rsp.first_name()


# Generated at 2022-06-23 20:55:28.023554
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def func():
        return 'Привет, Мир!'

    correct = 'Privet, Mir!'
    assert func() == correct



# Generated at 2022-06-23 20:55:34.466538
# Unit test for function romanize
def test_romanize():
    def romanize_func():
        return "Мимесис предоставляет реальные данные в виде фейковых"

    @romanize('ru')
    def romanize_decorator():
        return "Мимесис предоставляет реальные данные в виде фейковых"

    assert romanize_func() == romanize_decorator()

# Generated at 2022-06-23 20:55:35.739282
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-23 20:55:39.297717
# Unit test for function romanize
def test_romanize():
    import mimesis

    pc = mimesis.PersonalComputer(locale='ru')
    hostname = pc.hostname()

    assert isinstance(hostname, str)
    assert hostname != ''
    assert len(hostname) > 0

# Generated at 2022-06-23 20:55:42.258669
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize()('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-23 20:55:50.797509
# Unit test for function romanize
def test_romanize():
    # Create a fake class, which have a `_data` attribute
    class FakeClass:
        _data = data.Data()

    fake_class = FakeClass()

    get_full_name = functools.partial(
        fake_class._data.full_name, gender=None)
    get_full_name_male = functools.partial(
        fake_class._data.full_name, gender='male')
    get_full_name_female = functools.partial(
        fake_class._data.full_name, gender='female')

    romanized_full_name = romanize(locale='ru')(get_full_name)
    romanized_full_name_male = romanize(locale='ru')(get_full_name_male)
    romanized_full_name_

# Generated at 2022-06-23 20:56:00.065763
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='kk')(lambda: 'zhadyk')() == 'жадык'
    assert romanize(locale='ru')(lambda: 'ЗАЯЦ')() == 'zayac'
    assert romanize(locale='uk')(lambda: 'ЗАЯЦ')() == 'zajac'
    assert romanize(locale='ru')(lambda: 'заяц')() == 'zayac'
    assert romanize(locale='uk')(lambda: 'заяц')() == 'zajac'
    assert romanize(locale='ru')(lambda: 'Заяц')() == 'Zajac'

# Generated at 2022-06-23 20:56:06.870179
# Unit test for function romanize
def test_romanize():
    # Single use
    @romanize(locale='ru')
    def func():
        return 'Минск'

    # Universal
    @romanize(locale='ru')
    def func2(word: str, locale='ru'):
        return word

    assert func() == 'Minsk'
    assert func2('Минск', locale='ru') == 'Minsk'

# Generated at 2022-06-23 20:56:09.619533
# Unit test for function romanize
def test_romanize():
    """Tests for romanize decorator."""
    from mimesis.builtins import RussiaSpecProvider

    r = RussiaSpecProvider()
    print(r.full_name(romanize=True))

# Generated at 2022-06-23 20:56:12.837537
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Привет мир'

    assert foo() == 'Privet mir'

# Generated at 2022-06-23 20:56:17.583261
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Фьючерс на золото')() == 'Fyuçers na zoloto'

    # Unit test for function romanized
    assert romanized('uk')(lambda: 'цей')() == 'cej'

# Generated at 2022-06-23 20:56:20.774518
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo(i):
        return i
    assert foo('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-23 20:56:32.222669
# Unit test for function romanize
def test_romanize():
    # Romanized
    @romanize()
    def roman_1(self):
        return self.random.choice(data.CYRILLIC)

    # Romanized
    @romanize()
    def roman_2(self):
        return self.random.choice(data.CYRILLIC)

    # Romanized
    @romanize()
    def roman_3(self):
        return ''.join(
            [self.random.choice(data.CYRILLIC) for _ in range(10)])

    # Romanized
    @romanize()
    def roman_4(self):
        return self.random.choice(data.COMMON_LETTERS)

    # Not romanized

# Generated at 2022-06-23 20:56:40.292385
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import CardinalDirection, Gender, Localization
    from mimesis.locales import EN
    from mimesis.providers.address import Address

    address = Address(EN)
    assert address.street_name() == 'Brantwood Road'

    address.add_provider('cardinal_direction', lambda: CardinalDirection.EAST)
    assert address.street_name() == 'East Brantwood Road'

    address.add_provider('gender', lambda: Gender.FEMALE)
    assert address.street_name() == 'East Brantwood Road'

    address = Address('ru')
    assert address.street_name() == 'Красноармейская улица'


# Generated at 2022-06-23 20:56:43.829195
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Привет, как дела?') == 'Privet, kak dela?'

# Generated at 2022-06-23 20:56:54.071218
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    russian = Person(Language.RU)
    russian_address = Address(Language.RU)
    russian_address.__dict__['postal_code'] = 'Первые пять десятичных цифр кода'
    kazakh = Person(Language.KK)
    ukrainian = Person(Language.UK)
    assert russian(data.ROMANIZATION_DICT['ru']) == russian.romanize()
    assert kazakh(data.ROMANIZATION_DICT['kk']) == kazakh.romanize()
   

# Generated at 2022-06-23 20:56:55.878600
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, мир!') == 'Pryvit, mir!'

# Generated at 2022-06-23 20:57:01.270177
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    @romanized
    def romanize_test(locale: str = ''):
        """Romanize text using the romanize decorator."""
        return u'Привіт всім світом!'


    txt = romanize_test()
    assert txt == 'Pryvit vsyim svitom!'

# Generated at 2022-06-23 20:57:06.083435
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-23 20:57:16.927224
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locales
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    person = Person(Locales.RU)
    addr = Address(Locales.UA)
    # Placeholder for default locale.
    pt = Address()

    assert person.name() == 'Игнат Оксанович Каргин'
    assert addr.city() == 'Фонтанка'

    @romanize('ru')
    def romanized_ru():
        return person.name()

    @romanize('uk')
    def romanized_uk():
        return addr.city()

    @romanize()
    def romanized_pt():
        return pt.city

# Generated at 2022-06-23 20:57:25.137985
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text
    t = mimesis.builtins.text.Text('ru')
    t_r = t.romanize
    assert t.cyrillic_text() == t_r.cyrillic_text()

    import mimesis.builtins.misc
    m = mimesis.builtins.misc.Misc('ru')
    m_r = m.romanize
    assert m.iban() == m_r.iban()

# Generated at 2022-06-23 20:57:33.219541
# Unit test for function romanize
def test_romanize():
    assert romanize_deco('как дела дружище') == 'kak dela drujishe'
    assert romanize_deco('Как дела дружище') == 'Kak dela drujishe'
    assert romanize_deco('Как дела дружище?') == 'Kak dela drujishe?'
    assert romanize_deco('Как дела дружище!') == 'Kak dela drujishe!'

# Generated at 2022-06-23 20:57:43.263802
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    a = Address(locale=Locale.RU)
    assert a.territory() == 'РЕСПУБЛИКА АДЫГЕЯ'

    @romanize()
    def romanized_address():
        a = Address(locale=Locale.RU)
        return a.territory()

    assert romanized_address() == 'RESPUBLIKA ADYGEYA'

    @romanize('uk')
    def romanized_address():
        a = Address(locale=Locale.UK)
        return a.territory()
