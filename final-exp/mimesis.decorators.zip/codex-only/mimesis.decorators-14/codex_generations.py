

# Generated at 2022-06-23 20:47:44.227779
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_alphabet():
        return 'АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'

    assert get_alphabet() == 'ABVGDYEZHIZKLMNOPRSTUFXCЧSHЩЪYЬEЮЯ'



# Generated at 2022-06-23 20:47:52.424059
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'привет')() == 'privet'
    assert romanize('ru')(lambda x: 'привет')() == 'privet'
    assert romanized('ru')(lambda x: 'привет')() == 'privet'

    assert romanize('uk')(lambda x: 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda x: 'сәлем')() == 'salem'
    assert romanize('kk')(lambda x: 'хайрым')() == 'khayrym'

    assert romanize('en')(lambda x: 'hey')() == 'hey'

# Generated at 2022-06-23 20:47:56.009494
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus(x):
        return x


    assert rus('привет') == 'privet'
    assert rus('привет мир!') == 'privet mir!'



# Generated at 2022-06-23 20:48:05.337122
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Здравствуйте')() == 'Zdravstvuyte'
    assert romanize()(lambda: 'Здравия')() == 'Zdraviya'
    assert romanize()(lambda: 'Съешь')() == 'Sesh'
    assert romanize()(lambda: 'Ещё')() == 'Eshche'
    assert romanize()(lambda: 'Шесть')() == 'Shest'
    assert romanize()(lambda: 'Щейф')() == 'Scheyf'

# Generated at 2022-06-23 20:48:13.330709
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def f_ru():
        return 'Привет, мир!'

    @romanize(locale='uk')
    def f_uk():
        return 'Привіт, світ!'

    @romanize(locale='kk')
    def f_kk():
        return 'Сәлем, дүние!'

    assert f_ru() == 'Privet, mir!'
    assert f_uk() == 'Privit, svit!'
    assert f_kk() == 'Salem, dunie!'

# Generated at 2022-06-23 20:48:14.857966
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:48:23.100411
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    # From 'кекс' to 'keks'
    assert romanize()(RussianSpecProvider().provide_text)('кекс') == 'keks'

    # From 'КЕКС' to 'KEKS'
    assert romanize()(RussianSpecProvider().provide_text)('КЕКС') == 'KEKS'

    # From 'Да ну!' to 'Da nu!'
    assert romanize()(RussianSpecProvider().provide_text)('Да ну!') == 'Da nu!'

    # From 'Да ну!' to 'Da nu!'

# Generated at 2022-06-23 20:48:25.876477
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Здравствуй, Мир!')().endswith('Mir!')

# Generated at 2022-06-23 20:48:27.092799
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир!')().lower() == 'privet mir!'

# Generated at 2022-06-23 20:48:33.381891
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_text():
        return 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'

    assert rus_text() == 'ABVGDEEJZIJKLMNOPRSTUFHCCHSHSHTYUEIUIA'

# Generated at 2022-06-23 20:48:43.889882
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('uk')

    assert isinstance(p, Person)

    txt = p.full_name(Gender.FEMALE)
    assert isinstance(txt, str)
    assert txt == 'Катерина Морозова'

    txt = p.full_name(Gender.MALE)
    assert isinstance(txt, str)
    assert txt == 'Іван Антонов'

    @romanize('uk')
    def romanize_test(txt):
        return txt

    txt = romanize_test(p.full_name(Gender.MALE))
    assert isinstance(txt, str)
   

# Generated at 2022-06-23 20:48:49.877398
# Unit test for function romanize
def test_romanize():
    # [ABC]
    # [АБВ]
    assert romanize('ru')(lambda: 'АБВ')() == 'ABV'
    # [ABC]
    # [ЗВТРК]
    assert romanize('ru')(lambda: 'ЗВТРК')() == 'ZVTK'
    # [ABC]
    # [ДЖЫЗФЧ]
    assert romanize('uk')(lambda: 'ДЖЫЗФЧ')() == 'DJYZFCH'
    # [ABC]
    # [Қасық]
    assert romanize('kk')(lambda: 'Қасық')() == 'Qasyq'


# Generated at 2022-06-23 20:48:53.383132
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 0)() == '0'
    assert romanize('ru')(lambda: '123')() == '123'
    assert romanize('ru')(lambda: 'Ефремов')() == 'Yefremov'
    assert romanize('uk')(lambda: 'Бублик')() == 'Bublyk'
    assert romanize('kk')(lambda: 'Құқық')() == 'Qoqyq'

# Generated at 2022-06-23 20:49:02.502885
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def result_ru():
        return 'Съешь же еще этих мягких французских'

    @romanize(locale='uk')
    def result_uk():
        return 'Съешь же еще этих мягких французских'


# Generated at 2022-06-23 20:49:03.546373
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:49:06.189959
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:49:11.615898
# Unit test for function romanize
def test_romanize():
    import mimesis
    z = mimesis.Zulu()
    z.add_provider(data.Romanization(locale='ru'))
    z.add_provider(data.Romanization(locale='uk'))
    z.add_provider(data.Romanization(locale='kk'))
    assert z.person().name(locale='ru')
    assert z.person().name(locale='uk')
    assert z.person().name(locale='kk')

# Generated at 2022-06-23 20:49:18.726113
# Unit test for function romanize
def test_romanize():
    import sys
    import unittest
    from typing import Generator

    @romanize(locale='ru')
    def test_func() -> str:
        return 'Кириллица'

    def romanize_gen() -> Generator[str, None, None]:
        yield romanize(locale='ru')(lambda: 'Кириллица')
        yield romanize(locale='ru')(lambda: 'Кириллица')
        yield romanized(locale='ru')(lambda: 'Кириллица')

    class TestRomanize(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            cls.romanize = romanize


# Generated at 2022-06-23 20:49:21.383160
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Text

    t = Text('ru')
    assert t.romanize() == ''

# Generated at 2022-06-23 20:49:29.865513
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person, Codes
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.providers.address import Address
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.commerce import Commerce
    from mimesis.providers.date import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.food import Food
    from mimesis.providers.internet import Internet
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.person import Person as PersonProvider

# Generated at 2022-06-23 20:49:32.492563
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'

# Generated at 2022-06-23 20:49:34.682286
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def foo():
        return "Функция foo."

    assert foo() == "Funkcija foo."

# Generated at 2022-06-23 20:49:40.599888
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    def romanize_en(txt: str = '') -> str:
        return txt

    def romanize_ru(txt: str = '') -> str:
        return txt.upper()

    def romanize_uk(txt: str = '') -> str:
        return txt.lower()

    romanize_en = romanize(locale=Locale.EN)(romanize_en)
    romanize_ru = romanize(locale=Locale.RU)(romanize_ru)
    romanize_uk = romanize(locale=Locale.UK)(romanize_uk)

    text_ru = Text(Locale.RU)

# Generated at 2022-06-23 20:49:48.881341
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize('ru')(lambda: 'Привет мир')() == 'Privet mir'
    assert romanize('uk')(lambda: 'Привіт світ')() == 'Pryvit svit'
    assert romanized('kk')(lambda: 'Қалайсың? привет')() == 'Qalaïsïñ? privet'

    try:
        romanize('de')(lambda: '')()
    except UnsupportedLocale as e:
        assert str(e) == 'Unsupported locale de'

# Generated at 2022-06-23 20:50:00.472781
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.text import Text

    person = Person(locale=Locale.ENGLISH)
    address = Address(locale=Locale.ENGLISH)

    @romanize('ru')
    def name():
        return person.full_name(gender='male')

    @romanize('uk')
    def address_ru():
        return address.address(use_street_prefix=False)

    @romanized('ru')
    def address_uk():
        return address.address(use_street_prefix=False)

    @romanize('ru')
    def text():
        text = Text(locale='ru')
        return text.text()

# Generated at 2022-06-23 20:50:09.120864
# Unit test for function romanize
def test_romanize():
    # Tests block

    def ru_func():
        return 'Привет'

    result = ru_func()
    assert result == 'Привет'

    def uk_func():
        return 'Привіт'

    assert uk_func() == 'Привіт'


# Generated at 2022-06-23 20:50:11.823196
# Unit test for function romanize
def test_romanize():
    """Test for romanize functionality"""
    result = romanize(locale='ru')(lambda a: 'Зима')
    assert result == 'Zima'

# Generated at 2022-06-23 20:50:20.333954
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Нападениебомбой')() == 'Napadeniebomboj'
    assert romanize('ru')(lambda x: 'Нападениебомбой')() == 'Napadeniebomboj'
    assert romanize('ru')(lambda x: 'АбвгдЕёЖзийклмнОопрстуфхцчшщъыьэюя')() == 'AbvgdeEyoZhziiklmnOoprstufkhtschshsh''y''eiuia'

# Generated at 2022-06-23 20:50:26.467862
# Unit test for function romanize

# Generated at 2022-06-23 20:50:32.585950
# Unit test for function romanize
def test_romanize():
    # test for common interface
    assert romanized(locale='ru')(lambda: 'hello')() == 'hello'
    assert romanized(locale='ru')(lambda: 'привет')() == 'privet'
    assert romanized(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanized(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanized(locale='kk')(lambda: 'сәлем')() == 'salem'
    assert romanized(locale='kk')(lambda: 'Әрекет')() == 'Areket'
    # test for wrong locale

# Generated at 2022-06-23 20:50:34.386902
# Unit test for function romanize
def test_romanize():
    assert romanize is romanized

# Generated at 2022-06-23 20:50:40.552048
# Unit test for function romanize
def test_romanize():
    test_string = 'Пока, Панда белая!'
    r_test_string = romanize()(lambda: test_string)()
    assert r_test_string == 'Poka, Panda belaya!'
    r_test_string = romanize('kk')(lambda: test_string)()
    assert r_test_string == 'Poka, Panda belaıa!'

# Generated at 2022-06-23 20:50:49.962834
# Unit test for function romanize
def test_romanize():
    assert romanize()(
        'Я согласен, что это в некотором роде извращение реальности. '
        'Однако этот мир и есть извращение реальности.',
    ) == (
        'Ya soglasen, chto еto v nekotorom rode izvrashchenie realnosti. '
        'Odnako еtot mir i еst izvrashchenie realnosti.'
    )

# Generated at 2022-06-23 20:50:51.659906
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')

# Generated at 2022-06-23 20:50:52.703059
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')

# Generated at 2022-06-23 20:50:54.716317
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def _get_token():
        return 'ЙЦУКЕН'

    assert _get_token() == 'YCTUKEN'

# Generated at 2022-06-23 20:50:56.852686
# Unit test for function romanize
def test_romanize():
    assert 'Hello' == romanize()('Привіт')

# Generated at 2022-06-23 20:51:07.619997
# Unit test for function romanize
def test_romanize():
    import pandas as pd
    import pandas.util.testing as pdt

    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.basic import Basic
    from mimesis.providers.name import Name
    from mimesis.providers.person import Person
    from mimesis.providers.person.en import Provider as PersonEN
    from mimesis.providers.person.uk import Provider as PersonUK

    address = Address(locale='uk')
    basic = Basic(locale='uk')
    name = Name(locale='uk')
    person = Person(locale='uk')
    person_en = PersonEN()
    person_uk = PersonUK()
    start_date = '1990-01-01'

# Generated at 2022-06-23 20:51:11.097934
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize()
    assert romanize(locale='ru')
    assert romanize(locale='uk')

# Generated at 2022-06-23 20:51:21.681628
# Unit test for function romanize
def test_romanize():
    assert (romanized(locale='ru')(lambda: 'доброе утро')()
            == romanize(locale='ru')(lambda: 'доброе утро')())

    assert romanized(locale='uk')(lambda: 'добрий ранок')() == \
        romanize(locale='uk')(lambda: 'добрий ранок')()

# Generated at 2022-06-23 20:51:25.762891
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize(locale='ru')
    def r(*args, **kwargs):
        return 'Бла бла бла!'

    assert r() == 'Bla bla bla!'

# Generated at 2022-06-23 20:51:27.710714
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize(locale='ru')(lambda: 'roma')() == 'рома'

# Generated at 2022-06-23 20:51:32.140546
# Unit test for function romanize
def test_romanize():
    @romanized(locale='ru')
    def cyrillic_text() -> str:
        return 'Добро пожаловать в наш клуб!'

    assert cyrillic_text() == 'Dobro pozhalovat v nash klub!'

# Generated at 2022-06-23 20:51:39.706756
# Unit test for function romanize
def test_romanize():
    assert romanized('ru', 'Русский') == 'Russkiy'
    assert romanized('ru', 'Миша') == 'Misha'
    assert romanized('ru', 'Маша') == 'Masha'
    assert romanized('ru', 'Олег') == 'Oleg'
    assert romanized('ru', 'Сергей') == 'Sergey'
    assert romanized('ru', 'Саша') == 'Sasha'
    assert romanized('ru', 'Вова') == 'Vova'
    assert romanized('ru', 'Настя') == 'Nastya'

# Generated at 2022-06-23 20:51:45.108389
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""
    # test common_letters
    assert len(data.COMMON_LETTERS) == 19

    # test romanization_dict
    assert 'ru' in data.ROMANIZATION_DICT
    assert 'uk' in data.ROMANIZATION_DICT
    assert 'kk' in data.ROMANIZATION_DICT

    # romanize
    assert romanize()('Hello') == 'Hello'
    assert romanize('uk')('Привіт') == 'Pryvit'
    assert romanize('ru')('Здравствуйте') == 'Zdravstvuyte'
    assert romanize('kk')('Сәлем') == 'Salem'

# Generated at 2022-06-23 20:51:46.197985
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет!')() == 'Privet!'

# Generated at 2022-06-23 20:51:47.887600
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')
    assert romanized(locale='ru')

# Generated at 2022-06-23 20:51:56.056838
# Unit test for function romanize

# Generated at 2022-06-23 20:51:58.464885
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize('ru')(lambda: 'гора')() == 'gora'

# Generated at 2022-06-23 20:52:03.962961
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    p = Person('ru')
    assert p.full_name() == 'Александр Иванов'
    assert p.full_name(romanize='ru') == 'Aleksandr Ivanov'
    assert p.full_name(romanize='ru', gender='female') == 'Larisa Ivanova'

# Generated at 2022-06-23 20:52:09.826354
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_only(size):
        return 'Я люблю плавать на каноэ!'   
    text = russian_only('5')
    assert text == 'Ya lyublyu plavat na kanoe!'

if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-23 20:52:13.945494
# Unit test for function romanize
def test_romanize():
    def test_func():
        return 'Привет, Мир!'

    romanize_test_func = romanize('ru')(test_func)
    assert romanize_test_func() == 'Privet, Mir!'

# Generated at 2022-06-23 20:52:24.584953
# Unit test for function romanize
def test_romanize():
    def ru() -> str:
        return 'Привет мир!'

    ru_rom = romanize('ru')(ru)
    assert ru_rom() == 'Privet mir!'

    def uk() -> str:
        return 'Привіт світ!'

    uk_rom = romanize('uk')(uk)
    assert uk_rom() == 'Pryvit svit!'

    def kz() -> str:
        return 'Сәлем дүние!'

    kz_rom = romanize('kk')(kz)
    assert kz_rom() == 'Sälem dünie!'

# Generated at 2022-06-23 20:52:32.992280
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.builtins import Address

    a = Address('ru')
    assert a.full_address().isalpha() is False
    assert a.street_address().isalpha() is False
    assert a.street_name().isalpha() is False
    assert a.city().isalpha() is False
    assert a.region().isalpha() is True
    assert a.country().isalpha() is True

# Generated at 2022-06-23 20:52:36.019139
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider as rsp

    assert isinstance(rsp.romanized, romanize)
    rsp.romanized()

# Generated at 2022-06-23 20:52:44.472989
# Unit test for function romanize
def test_romanize():
    def old_romanize(string: str) -> str:
        return romanize(locale='ru')(lambda x: string)('')

    assert old_romanize('Привет') == 'Privet'
    assert old_romanize('привет') == 'privet'
    assert old_romanize('говорить') == 'govorit'
    assert old_romanize('речь') == 'rec'
    assert old_romanize('зайцев') == 'zaycev'
    assert old_romanize('через') == 'cherez'
    assert old_romanize('через') == 'cherez'

# Generated at 2022-06-23 20:52:46.548268
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def func(text):
        return text

    assert func('Привет!') == 'Privet!'

# Generated at 2022-06-23 20:52:47.153712
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:52:53.040933
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'привет!')() == 'privet!'
    assert romanize('uk')(lambda x: 'привіт!')() == 'pryvit!'
    assert romanize('kk')(lambda x: 'салам!')() == 'salam!'

# Generated at 2022-06-23 20:52:58.715692
# Unit test for function romanize
def test_romanize():
    """Test for :func:`~mimesis.utils.romanize()`."""
    from mimesis import Address, AddressRu

    @romanize()
    def get_address():
        """Get address."""
        a = Address()
        return a.address('mixed')

    @romanize()
    def get_address_ru():
        """Get address."""
        a = AddressRu()
        return a.address('mixed')

    assert get_address() != ''
    assert get_address_ru() != ''

# Generated at 2022-06-23 20:52:59.879225
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:53:04.126725
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Неизвестное сопротивление')() == 'Neizvestnoyesoprotivleniye'

# Generated at 2022-06-23 20:53:07.554674
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Romanization
    from mimesis.enums import Locales
    from mimesis.providers.address import Address

    address = Address(Locales.ENGLISH)
    assert address.romanize(Romanization.UK)

# Generated at 2022-06-23 20:53:10.277268
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def r(locale=''):
        return 'Привет, Мир!'

    assert r() == 'Privet, Mir!'

# Generated at 2022-06-23 20:53:20.394818
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text

    r = mimesis.builtins.text.Text(locale='ru')
    assert r.word().lower() == r._romanize(r.word()).lower()
    assert r.word(capitalize=True) == r._romanize(r.word())

    r = mimesis.builtins.text.Text(locale='uk')
    assert r.word().lower() == r._romanize(r.word()).lower()
    assert r.word(capitalize=True) == r._romanize(r.word())

    r = mimesis.builtins.text.Text(locale='kk')
    assert r.word().lower() == r._romanize(r.word()).lower()

# Generated at 2022-06-23 20:53:21.861998
# Unit test for function romanize
def test_romanize():
    print(romanize()('Привет, мир!'))

# Generated at 2022-06-23 20:53:28.865742
# Unit test for function romanize
def test_romanize():
    assert('a' == romanize()(str))
    assert('b' == romanized()(str))

# ========================================================================
# >>> from mimesis.enums import Locale
# >>> from mimesis.builtins import EnEn
# >>> num = EnEn()
# >>> num.romanize(Locale.EN)
# 'one'
# >>> num.romanize(Locale.RU)
# 'один'
# >>> num.romanize(Locale.DE)
# Traceback (most recent call last):
#   ...
# UnsupportedLocale: de

# Generated at 2022-06-23 20:53:30.542085
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'тест')() == 'test'



# Generated at 2022-06-23 20:53:35.621151
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Лев Николаевич Толстой')() == 'Lev Nikolaevich Tolstoy'
    assert romanize(locale='ru')(lambda: 'Петр I')() == 'Petrovich'
    assert romanize(locale='ru')(lambda: 'Привет! Как дела?')() == 'Privet! Kak dela?'
    assert romanize('ru')(lambda: 'Лев Николаевич Толстой')() == 'Lev Nikolaevich Tolstoy'



# Generated at 2022-06-23 20:53:37.982974
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-23 20:53:39.244194
# Unit test for function romanize
def test_romanize():
    """Decorator Romanize needs this test."""
    pass

# Generated at 2022-06-23 20:53:41.100802
# Unit test for function romanize
def test_romanize():
    assert romanized() == romanize()
    assert romanize('ru')
    assert romanize('ua')

# Generated at 2022-06-23 20:53:49.174421
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func(locale: str = '') -> str:
        return 'Кроту Та́рас Шевче́нко отльчилося чомусь таким промовам'

    assert func() == \
        'Krotu Taras Shevchenko otl\'chilosia chomus\' takim promovam'

# Generated at 2022-06-23 20:53:58.064640
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    r = RussiaSpecProvider('ru')
    assert romanize()(r.name(gender=Gender.FEMALE)) == r.name(gender=Gender.FEMALE)
    assert romanize('ru')(r.name(gender=Gender.FEMALE)) == r.name(gender=Gender.FEMALE)
    assert romanize('uk')(r.name(gender=Gender.FEMALE)) == r.name(gender=Gender.FEMALE)
    assert romanize('kk')(r.name(gender=Gender.FEMALE)) == r.name(gender=Gender.FEMALE)

# Generated at 2022-06-23 20:53:58.652201
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:54:10.935566
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    import pytest

    from mimesis.builtins.text import Text

    text = Text()
    txt = text.word(locale='ru')
    with pytest.raises(UnsupportedLocale):
        text.word(locale='en')

    # Test for different locales
    romanized_ko = text.romanize('ko')
    romanized_uk = text.romanize('uk')
    romanized_kk = text.romanize('kk')
    result_ko = romanized_ko(txt)
    result_uk = romanized_uk(txt)
    result_kk = romanized_kk(txt)
    assert result_ko != result_uk
    assert result_ko != result_kk
    assert result_uk != result_kk

# Generated at 2022-06-23 20:54:20.974374
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import Person

    ru_person = Person('ru')
    assert ru_person.name() == ru_person._romanize(ru_person.name())

    uk_person = Person('uk')
    assert uk_person.name() == uk_person._romanize(uk_person.name())

    kk_person = Person('kk')
    assert kk_person.name() == kk_person._romanize(kk_person.name())

    # Test romanize decorator with internal function
    ru_romanize = ru_person._romanize('Владимир Путин')
    ru_person._romanize = romanize('ru')(ru_person._romanize)

# Generated at 2022-06-23 20:54:27.902254
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='en')
    assert romanize(locale='ru')
    assert romanize(locale='uk')
    assert romanize(locale='kk')

    import mimesis.builtins.text
    from mimesis.providers.text import Text

    text = Text('uk')
    assert romanize(locale='uk')(text.words)(1, 5)

# Generated at 2022-06-23 20:54:31.239706
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    provider = RussiaSpecProvider()
    for _ in range(100):
        test_1 = provider.name(gender=Gender.FEMALE)
        test_2 = provider.name(gender=Gender.MASCULINE)
        assert ''.join(test_1.split()) != test_2
        assert len(test_1) > 3
        assert len(test_2) > 3

# Generated at 2022-06-23 20:54:35.118430
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo(text):
        return text
    result = foo('мемы')
    assert result == 'memy', "Function 'romanize' failed"

# Generated at 2022-06-23 20:54:36.751049
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет!') == 'Hello!'

# Generated at 2022-06-23 20:54:43.063667
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'Юнит тест для декоратора')().startswith('Yunit')
    assert romanize('uk')(lambda : 'Юніт тест для декоратора')().startswith('Yunit')
    assert romanize('kk')(lambda : 'Юнит тест для декоратора')().startswith('Yunit')

# Generated at 2022-06-23 20:54:43.908548
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:54:45.316162
# Unit test for function romanize
def test_romanize():
    romanize_func = romanize(locale='ru')
    assert romanize_func('текст') == 'tekst'

# Generated at 2022-06-23 20:54:48.468530
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanized(locale='ru')(lambda: 'Привет Мир!')() == 'Privet Mir!'

# Generated at 2022-06-23 20:54:51.275891
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'здравствуй, мир!')() == 'zdravstvuj, mir!'

# Generated at 2022-06-23 20:54:54.791540
# Unit test for function romanize
def test_romanize():
    romanized_text = romanize('ru')(lambda : 'Тест')
    assert romanized_text == 'Test'
    romanized_text = romanize('en')(lambda : 'Тест')
    assert romanized_text == 'Тест'

# Generated at 2022-06-23 20:55:03.846321
# Unit test for function romanize
def test_romanize():
    romanize_eng = romanize('en')

    @romanize_eng
    def test_romanize_en(locale: str = 'en') -> str:
        return data.ROMANIZATION_DICT['en']['З']

    assert test_romanize_en() == 'Z'

    romanize_uk = romanize('uk')

    @romanize_uk
    def test_romanize_uk(locale: str = 'uk') -> str:
        return data.ROMANIZATION_DICT['uk']['З']

    assert test_romanize_uk() == 'Z'

    romanize_kk = romanize('kk')

    @romanize_kk
    def test_romanize_kk(locale: str = 'kk') -> str:
        return data.ROM

# Generated at 2022-06-23 20:55:09.050177
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.enums import Locale

    assert not data.ROMANIZATION_DICT.get(Locale.ENGLISH)

    @romanize(Locale.ENGLISH)
    def test(a: str='') -> str:
        return a

    with pytest.raises(UnsupportedLocale):
        test(a='Привет')

# Generated at 2022-06-23 20:55:13.993690
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    @romanize(locale='ru')
    def foo():
        return 'Башкортостан'

    assert foo() == 'Bashkortostan'

    @romanize(locale='kk')
    def bar(text: str) -> str:
        return text

    assert bar('Башқұрт') == 'Başqort'
    assert bar('Республика') == 'Respyblıka'

# Generated at 2022-06-23 20:55:14.464953
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:55:23.338657
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Тест')() == 'Test'
    assert romanize('ru')(lambda: 'Тест')() == 'Test'
    assert romanize('ru')(lambda: 'Тест')() == 'Test'
    assert romanize('ru')(lambda: 'Тест')() == 'Test'
    assert romanize('kk')(lambda: 'Тест')() == 'Test'
    assert romanize('kk')(lambda: 'Тест')() == 'Test'
    assert romanize('kk')(lambda: 'Тест')() == 'Test'
    assert romanize('kk')(lambda: 'Тест')() == 'Test'

# Generated at 2022-06-23 20:55:29.298955
# Unit test for function romanize
def test_romanize():
    from mimesis import Cryptographic
    from mimesis.builtins.locales import ua

    def foo():
        cr = Cryptographic('uk')
        return cr.token_hex()

    bar = romanize(locale=ua)(foo)
    baz = romanized(locale=ua)(foo)

    assert bar() != baz()
    assert foo() != bar() != baz()

# Generated at 2022-06-23 20:55:38.554386
# Unit test for function romanize
def test_romanize():
    """Romanize the cyrillic text.

    Transliterate the cyrillic script into the latin alphabet.

    .. note:: At this moment it works only for `ru`, `uk`, `kk`.
    """
    assert romanize()('test') == 'test'
    assert romanize('ru')('тест') == 'test'
    assert romanize('uk')('тест') == 'test'
    assert romanize('kk')('тест') == 'test'

# Generated at 2022-06-23 20:55:42.809185
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanized():
        return 'Русский язык, тестирование'
    assert romanized == 'Russkiy yazyk, testirovanie'

# Generated at 2022-06-23 20:55:51.042110
# Unit test for function romanize
def test_romanize():
    """Test suite for romanize decorator."""

    ru = 'Тест проверки романизации кириллицы'
    uk = 'Тест перевірки романізації кирилиці'
    kz = 'Тест тексерудің кириллдікті романизациясымен тексере аласыз'


# Generated at 2022-06-23 20:55:57.471230
# Unit test for function romanize
def test_romanize():
    """Unit test."""
    result = romanize('ru')(lambda: 'Привет, Мир!')
    assert result == 'Privet, Mir!'

    result = romanize('ru')(lambda: 'Привет, Мир!')
    assert result == 'Privet, Mir!'

    result = romanized('ru')(lambda: 'Привет, Мир!')
    assert result == 'Privet, Mir!'

# Generated at 2022-06-23 20:56:04.267351
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: None)() == ''

    @romanize(locale='ru')
    def test_function():
        return 'Аа Бб Вв Гг Ґґ Дд Ее Ёё Єє Жж Зз Ии Іі Її Йй Кк Лл Мм Нн Ңң Оо Пп Рр Сс Тт Уу Үү Фф Хх Цц Чч Шш Щщ Ъъ Ыы Ьь Ээ Юю Яя'

# Generated at 2022-06-23 20:56:07.426815
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Содержимое блока данных')() == 'Soderzhimoe bloka dannyh'

# Generated at 2022-06-23 20:56:08.027228
# Unit test for function romanize
def test_romanize():
    pass



# Generated at 2022-06-23 20:56:12.356356
# Unit test for function romanize
def test_romanize():
    def wrapper():
        return 'Привет, мир!'

    test_func = romanize('ru')(wrapper)
    test_result = test_func()
    assert test_result == 'Privet, mir!'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:56:15.692524
# Unit test for function romanize
def test_romanize():
    """ Unit test for function romanize """
    romanized_str = romanize('ru')(lambda: 'Киев')()
    assert(romanized_str == 'Kyiv')



# Generated at 2022-06-23 20:56:20.332267
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_text(text: str) -> str:
        return text

    assert romanize_text('Привет') == 'Privet'

# Generated at 2022-06-23 20:56:25.026052
# Unit test for function romanize
def test_romanize():
    """Test the work of romanize(s)."""
    assert romanized()('Хитроу') == 'Hitrou'
    assert romanized()('Гораздо') == 'Gorazdo'

# Generated at 2022-06-23 20:56:25.915096
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Википедия')()[0] == 'V'



# Generated at 2022-06-23 20:56:28.677678
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Санкт-Петербург')() == 'Sankt-Peterburg'

# Generated at 2022-06-23 20:56:33.532747
# Unit test for function romanize
def test_romanize():
    def foo():
        return 'Тестовая строка'

    foo_ru = romanize('ru')(foo)
    assert foo_ru() == 'Testovaya stroka'

    foo_uk = romanize('uk')(foo)
    assert foo_uk() == 'Testova stroka'

    foo_kg = romanize('kk')(foo)
    assert foo_kg() == 'Testovaya stroka'

# Generated at 2022-06-23 20:56:35.861996
# Unit test for function romanize
def test_romanize():
    result = romanize('ru')('Россия')
    assert result == 'Rossiya'


# Generated at 2022-06-23 20:56:37.598997
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    romanize('ru')(lambda: '')()

# Generated at 2022-06-23 20:56:43.084796
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    def romanize_func():
        """Test romanize decorator."""
        return 'Привет, мир!'

    assert romanized('ru')(romanize_func)() == 'Privet, mir!'
    assert romanized('uk')(romanize_func)() == 'Pryvit, svit!'
    assert romanized('kk')(romanize_func)() == 'Sabaïdy, ölim!'
    assert romanized()(romanize_func)() == 'Privjet, mir!'

# Generated at 2022-06-23 20:56:51.964254
# Unit test for function romanize
def test_romanize():
    assert 'Объединенные Штаты' == romanize(locale='ru')('Объединенные Штаты Америки')
    assert 'Объединенные Штаты Америки' == romanize(locale='en')('Объединенные Штаты Америки')



# Generated at 2022-06-23 20:56:57.355591
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'абвг')() == 'abvg'
    assert romanized(locale='uk')(lambda: 'абвг')() == 'abvg'
    assert romanized(locale='kk')(lambda: 'абвг')() == 'abvg'



# Generated at 2022-06-23 20:56:58.224980
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:57:05.371870
# Unit test for function romanize
def test_romanize():
    def romanize_uk(s):
        s = s.replace(u'А', 'A')
        s = s.replace(u'а', 'a')
        s = s.replace(u'Б', 'B')
        s = s.replace(u'б', 'b')
        s = s.replace(u'В', 'V')
        s = s.replace(u'в', 'v')
        s = s.replace(u'Г', 'H')
        s = s.replace(u'г', 'h')
        s = s.replace(u'Ґ', 'G')
        s = s.replace(u'ґ', 'g')
        s = s.replace(u'Д', 'D')
        s = s.replace(u'д', 'd')

# Generated at 2022-06-23 20:57:07.374744
# Unit test for function romanize
def test_romanize():
    assert 'Eblfg' == romanize()(lambda: 'Эблфг')

# Generated at 2022-06-23 20:57:17.420563
# Unit test for function romanize
def test_romanize():
    """Romanize the cyrillic text."""
    assert romanize()('мимимимимимимимим') == 'mimimimimimimimimimim'
    assert romanize('uk')('мимимимимимимимим') == 'mimimimimimimimimimim'
    assert romanize('kk')('мимимимимимимимим') == 'mimimimimimimimimimim'
    assert romanize('uk')('Юрий Сергеевич Гагарин') == 'Yuriy Sergeyevich Gagarin'

# Generated at 2022-06-23 20:57:25.917267
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    @romanize(locale='uk')
    def foo():
        return 'Вересень'

    assert foo() == 'Verezen'

    @romanize(locale='ru')
    def bar():
        return 'Сентябрь'

    assert bar() == 'Sentiabr'

    assert RussianSpecProvider._romanize('Январь') == 'Yanvar'

# Generated at 2022-06-23 20:57:30.121299
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda x: 'Привіт')() == 'Privit'
    assert romanize('kk')(lambda x: 'Сәлем')() == 'Salem'


# Generated at 2022-06-23 20:57:34.512271
# Unit test for function romanize
def test_romanize():
    def test_func():
        return 'Привет, мир!'
    romanized_func = romanize('ru')(test_func)
    assert romanized_func() == 'Privet, mir!'

# Generated at 2022-06-23 20:57:37.705335
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Купите корову')() == 'Kupite korovu'

# Generated at 2022-06-23 20:57:44.976772
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Сергей')() == 'Sergey'
    assert romanize(locale='kz')(lambda: 'Сергей')() == 'Sergey'
    assert romanize(locale='kk')(lambda: 'Сергей')() == 'Sergey'
    assert romanize(locale='ua')(lambda: 'Сергей')() == 'Sergey'
    assert romanize(locale='by')(lambda: 'Сергей')() == 'Sergey'