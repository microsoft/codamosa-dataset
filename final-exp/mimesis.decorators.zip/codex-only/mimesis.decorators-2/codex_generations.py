

# Generated at 2022-06-23 20:47:43.365261
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:47:51.585773
# Unit test for function romanize
def test_romanize():

    s = 'Новый ключ выбран пользовательским интерфейсом'

    def romanize_func(s):
        return s

    romanize_func = romanize('ru')(romanize_func)

    assert romanize_func(s) == 'Novyi kliuch vybran polzovatelskim interfeisom'

    romanize_func = romanize('uk')(romanize_func)
    assert romanize_func(s) == 'Novyi kliuch vybran polzovatelskim interfeisom'

# Generated at 2022-06-23 20:47:54.627919
# Unit test for function romanize
def test_romanize():
    """Test romanize."""

    @romanize(locale='ru')
    def _test_method():
        return 'привет'

    assert _test_method() == 'privet'

# Generated at 2022-06-23 20:47:57.804455
# Unit test for function romanize
def test_romanize():
    """Test the function romanize"""

    @romanize(locale='ru')
    def _romanize():
        return 'Привет!'

    assert _romanize() == 'Privet!'

# Generated at 2022-06-23 20:48:03.967949
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    from mimesis.builtins import CyrillicText
    cyrillic_text = CyrillicText(locale='ru')
    assert cyrillic_text.romanize() is not None
    assert cyrillic_text.romanize('ru') is not None
    assert cyrillic_text.romanize('uk') is not None
    assert cyrillic_text.romanize('kk') is not None

# Generated at 2022-06-23 20:48:06.058602
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize()(lambda: 'привет')() == 'privet'

# Generated at 2022-06-23 20:48:06.704807
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-23 20:48:13.457162
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Русский') == 'Russkii'
    assert romanize(locale='uk')(lambda: 'Українська') == 'Ukrainska'
    assert romanize(locale='kk')(lambda: 'Қазақша') == 'Qazaqsha'
    assert romanize(locale='invalid')(lambda: 'test123') == 'test123'

# Generated at 2022-06-23 20:48:22.711615
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def rus_text():
        import random
        return random.choice(['я шариковая ручка',
                              'я карандаш',
                              'я генератор случайных чисел',
                              'я генератор случайных строк'])

    @romanize('uk')
    def ukr_text():
        import random

# Generated at 2022-06-23 20:48:33.012313
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def r(x):
        if x < 5:
            return 'люблю ' * x
        return x

    assert r(8) == 'люблю люблю люблю люблю 8'

    @romanize('uk')
    def r(x):
        if x < 5:
            return 'люблю ' * x
        return x

    assert r(8) == 'люблю люблю люблю люблю 8'


# Generated at 2022-06-23 20:48:37.932336
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Шалаш')() == 'Shalash'
    assert romanize('uk')(lambda: 'Шалаш')() == 'Shalash'
    assert romanize('kk')(lambda: 'Шалаш')() == 'Shalash'

# Generated at 2022-06-23 20:48:42.941599
# Unit test for function romanize
def test_romanize():
    """Test for Romanization."""
    # locale is 'ru', but have no romanization
    assert romanize('ru')(_ru_hello)() == 'Привет'
    # locale is 'uk', it's ok
    assert romanize('uk')(_uk_hello)() == 'Privit'



# Generated at 2022-06-23 20:48:48.903477
# Unit test for function romanize

# Generated at 2022-06-23 20:48:53.353297
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Привет") == "Privet"
    assert romanize("uk")("Привіт") == "Privit"
    assert romanize("kk")("Сәлем") == "Sälem"

# Generated at 2022-06-23 20:48:59.481891
# Unit test for function romanize
def test_romanize():
    def check(func):
        result = func()
        assert result is not None
        assert isinstance(result, str)

    check(romanize('ru')(lambda: 'Привет, Мир!'))
    check(romanize('uk')(lambda: 'Привіт, Світ!'))
    check(romanize('kk')(lambda: 'Сәлем Әлем!'))



# Generated at 2022-06-23 20:49:07.393676
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test():
        return 'Если бы всё так было просто, как ты считаешь, это не было бы интересно.'
    assert test() == 'Esli by vsio tak bylo prosto, kak ty schitaesh\', eto ne bylo by interesno.'



# Generated at 2022-06-23 20:49:09.450190
# Unit test for function romanize
def test_romanize():
    import mimesis
    a = mimesis.Cryptographic()
    assert ''.join([a.token() for i in range(5)]) == a.token(5)

# Generated at 2022-06-23 20:49:17.110133
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('ua')(lambda: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda: 'Сәлем')() == 'Salem'
    assert romanized('ru')(lambda: 'Діма')() == 'Dima'
    assert romanized('ua')(lambda: 'Макс')() == 'Maks'
    assert romanized('kk')(lambda: 'Айна')() == 'Ayna'
    # The next two tests are for backward

# Generated at 2022-06-23 20:49:21.035005
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins
    b = mimesis.builtins.Builtins(locale='ru')
    assert b.romanize('Весь мир') == 'Vesʹ mir'

# Generated at 2022-06-23 20:49:27.845442
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.providers.datetime import Datetime
    dt = Datetime('ru')
    assert dt.time == "11:51:24"
    assert dt.date == "04.07.2019"
    assert dt.date_time == "04.07.2019 11:51:24"
    with pytest.raises(UnsupportedLocale):
        dt2 = Datetime('ee')
        dt2.date_time
    with pytest.raises(UnsupportedLocale):
        dt3 = Datetime('ee')
        dt3.datetime

# Generated at 2022-06-23 20:49:31.216562
# Unit test for function romanize
def test_romanize():
    def func():
        return 'Привет, как дела'

    test_func = romanize(locale='ru')(func)
    assert test_func() == 'Privet, kak dela'



# Generated at 2022-06-23 20:49:35.214959
# Unit test for function romanize
def test_romanize():
    assert 'love' == romanize()(lambda: 'любовь')
    assert 'ljubov' == romanize('ru')(lambda: 'любовь')
    assert 'ljubov' != romanize('uk')(lambda: 'любовь')

# Generated at 2022-06-23 20:49:41.116616
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'привет') == 'privet'
    assert romanize('uk')(lambda : 'привіт') == 'pryvit'
    assert romanize('kk')(lambda : 'батыс') == 'batys'

# Generated at 2022-06-23 20:49:50.645500
# Unit test for function romanize
def test_romanize():
    """Test the function romanize."""
    # Function returns a function
    assert callable(romanize()) is True

    # Decorated function should return correct result
    @romanize()
    def romanized_function(s: str) -> str:
        return s

    assert romanized_function('Привет, Мир!') == 'Privet, Mir!'

    # Decorated function should return correct result
    # with kyrgyz locale code
    @romanize(locale='ky')
    def romanized_function(s: str) -> str:
        return s

    assert romanized_function('Привет, Мир!') == 'Privet, Mir!'

    # If incorrect locale code was used
    # the UnsupportedLocale exception should be raised

# Generated at 2022-06-23 20:49:54.529464
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    @romanize(Language.RUSSIAN)
    def some_func():
        return 'тест'
    assert some_func() == 'test'

# Generated at 2022-06-23 20:50:00.089590
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    rus_alphabet = 'РУССКИЙ АЛФАВИТ'
    rus_alphabet_romanized = romanize(locale)(lambda: rus_alphabet)()
    assert rus_alphabet_romanized == 'RUSSKIY ALFAVIT'



# Generated at 2022-06-23 20:50:08.736614
# Unit test for function romanize
def test_romanize():
    """Docstring."""

    @romanize(locale='ru')
    def rus_string():
        """Docstring."""
        return 'Здравствуйте, мир!'

    assert rus_string() == 'Zdravstvuyte, mir!'

    @romanize(locale='uk')
    def ukr_string():
        """Docstring."""
        return 'Привіт, світ!'

    assert ukr_string() == 'Pryvit, svit!'

    @romanize(locale='kk')
    def kaz_string():
        """Docstring."""
        return 'Сәлем, дүние!'


# Generated at 2022-06-23 20:50:11.823136
# Unit test for function romanize
def test_romanize():
    """Unit tests for romanize."""
    @romanize('ru')
    def to_roman(locale):
        return locale

    assert to_roman('ru') == 'ru'



# Generated at 2022-06-23 20:50:16.417571
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize('uk')('Вітаю') == 'Vitayu'
    assert romanize('kk')('Сәлем тегін') == 'Salem tegin'

# Generated at 2022-06-23 20:50:18.727910
# Unit test for function romanize
def test_romanize():
    @romanize(locale="ru")
    def get_name(self):
        return self._data['personal']['name']['full']
    name = get_name()
    assert isinstance(name, str)

# Generated at 2022-06-23 20:50:20.436200
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize()(lambda: 'Мимесис')() == 'Mimesis'

# Generated at 2022-06-23 20:50:22.207497
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def f(x):
        return x

    assert f('Алексей') == 'Aleksey'



# Generated at 2022-06-23 20:50:30.546356
# Unit test for function romanize
def test_romanize():
    """Test romanize method."""
    text = 'Привет, Мир!'
    assert ''.join([
        'Privet, Mir!'
    ]) == romanize(locale='ru')(lambda: text)()

    assert ''.join([
        'Pryvit, Svit!'
    ]) == romanize(locale='ua')(lambda: text)()

    assert ''.join([
        'Salem, Dünya!'
    ]) == romanize(locale='tr')(lambda: text)()

    assert ''.join([
        'В європі морозно.'
    ]) == romanize(locale='uk')(lambda: text)()


# Generated at 2022-06-23 20:50:34.857547
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import CyrillicLanguage

    txt = CyrillicLanguage(locale='ru').word()
    assert txt != romanize(locale='ru')(txt)



# Generated at 2022-06-23 20:50:40.860584
# Unit test for function romanize
def test_romanize():
	@romanize(locale='ru')
	def test_function(text):
		return text

	print(test_function('Жили-были дед и баба, '
		'была у них кобыла-колобала.'))


if __name__ == '__main__':
	test_romanize()

# Generated at 2022-06-23 20:50:41.807795
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')

# Generated at 2022-06-23 20:50:50.166124
# Unit test for function romanize
def test_romanize():
    import sys
    import warnings
    if sys.version_info[:2] == (3, 8):
        warnings.simplefilter('ignore')
    
    assert romanize()(lambda: 'Алексей Бурцев.')() == 'Aleksej Burcev.'
    assert romanize()(lambda: 'Алексей Бурцев.')() == 'Aleksej Burcev.'
    
    assert romanize('ru')(lambda: 'Алексей Бурцев.')() == 'Aleksej Burcev.'

# Generated at 2022-06-23 20:50:58.423389
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    from mimesis.builtins.numbers import Numbers
    from mimesis.typing import Typed
    from mimesis.providers.internet import Internet

    provider = Internet()
    nums = Typed(Numbers)
    romanized_string = nums.numeric_string(64, lowercase=True, romanized=True)

    assert isinstance(romanized_string, str)

    romanized_string = provider.email(romanized=True)

    assert isinstance(romanized_string, str)

    romanized_string = provider.username(romanized=True)

    assert isinstance(romanized_string, str)

# Generated at 2022-06-23 20:51:08.935069
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Address

    address = Address()
    ru_locale = address.localize('ru')
    ua_locale = address.localize('uk')
    kz_locale = address.localize('kk')

    ru = address.address(locale=ru_locale)
    ua = address.address(locale=ua_locale)
    kz = address.address(locale=kz_locale)
    ru_romanized = address.address(locale=ru_locale, romanize=True)
    ua_romanized = address.address(locale=ua_locale, romanize=True)
    kz_romanized = address.address(locale=kz_locale, romanize=True)

    assert ru != ru_romanized


# Generated at 2022-06-23 20:51:12.292152
# Unit test for function romanize
def test_romanize():
    alphabet = data.ROMANIZATION_DICT['ru']
    test_word = 'Приветствую'
    test_word_rom = ''.join([alphabet[i] for i in test_word if i in alphabet])
    assert test_word_rom == 'Privetstvuyu'


test_romanize()

# Generated at 2022-06-23 20:51:20.888634
# Unit test for function romanize
def test_romanize():
    s = romanized()(lambda: 'Кириллица')
    assert s == 'Kirillitsa'

    s = romanized('kk')(lambda: 'Кириллица')
    assert s == 'Kïrillïtsa'

    s = romanized('ru')(lambda: 'Кириллица')
    assert s == 'Kirillitsa'

    s = romanized('uk')(lambda: 'Кириллица')
    assert s == 'Kïrillïtsa'

# Generated at 2022-06-23 20:51:23.369510
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    @romanize('ru')
    def _test():
        return 'тест'

    assert _test() == 'test'

# Generated at 2022-06-23 20:51:30.622459
# Unit test for function romanize
def test_romanize():
    string = 'привет'
    assert romanize('ru')(lambda: string)() == 'privet'
    assert romanize('uk')(lambda: string)() == 'pryvit'
    assert romanize('kk')(lambda: string)() == 'privet'
    try:
        romanize('de')(lambda: string)()
    except UnsupportedLocale:
        pass
    else:
        assert False

# Generated at 2022-06-23 20:51:34.765323
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    rp = RussianSpecProvider('ru')
    print(rp.romanize('Салам'))
    print(rp.romanize('Украина'))
    print(rp.romanize('Казахстан'))

# Generated at 2022-06-23 20:51:41.621239
# Unit test for function romanize
def test_romanize():
    # The language that is not supported
    locale = 'en'
    with UnsupportedLocale.expected(locale):
        def test_romanize_en(locale='en'):
            @romanize(locale)
            def russian_test():
                return 'Тест'
            return russian_test()
        assert test_romanize_en()

    # The language that is not supported
    locale = 'en'
    with UnsupportedLocale.expected(locale):
        def test_romanize_en(locale='en'):
            @romanized(locale)
            def russian_test():
                return 'Тест'
            return russian_test()
        assert test_romanize_en()

    # The language that is supported

# Generated at 2022-06-23 20:51:44.352595
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    p = Person()
    text = p.name(fullname=False)
    assert romanize()(lambda x: x)(text) == text

# Generated at 2022-06-23 20:51:47.225489
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ja')
    def say_hello(name):
        return 'Hello ' + name

    assert say_hello('ひらがな') == 'Hello ひらがな'

# Generated at 2022-06-23 20:51:48.151091
# Unit test for function romanize
def test_romanize():
    pass  # TODO: Implement

# Generated at 2022-06-23 20:51:51.821776
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    @romanize('ru')
    def russian_name():
        return 'Привет мир'

    assert russian_name() == 'Privet mir'



# Generated at 2022-06-23 20:51:54.599491
# Unit test for function romanize
def test_romanize():
    """Test romanize."""

# Generated at 2022-06-23 20:52:04.284117
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_test():
        return 'привет, друг!'
    assert romanize_test() == 'privet, drug!'

    @romanize('uk')
    def romanize_test():
        return 'привіт, друг!'
    assert romanize_test() == 'pryvit, druh!'

    @romanize('kk')
    def romanize_test():
        return 'сәлем, достар!'
    assert romanize_test() == 'salem, dostar!'


# Generated at 2022-06-23 20:52:13.591423
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, мир') == 'Privet, mir'
    assert romanize('kk')('Сәлем, дүние') == 'Sälem, dünie'
    assert romanize('uk')('Привіт, світ') == 'Pryvit, svit'
    assert romanize('uk')('Любов') == 'Liubov'
    assert romanize('ru')('Любовь') == 'Liubov'
    assert romanize('ru')('Любовь') == 'Liubov'

# Generated at 2022-06-23 20:52:25.023851
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    from mimesis.enums import Locale

    assert romanize()(lambda: 'Вова')() == 'Vova'
    assert romanize(Locale.RU)(lambda: 'Вова')() == 'Vova'
    assert romanize(Locale.RU)(lambda: 'Вова')() == 'Vova'
    assert romanize(Locale.UK)(lambda: 'Коля')() == 'Kolya'
    assert romanize(Locale.KZ)(lambda: 'Коля')() == 'Kolya'
    assert romanize(Locale.RU)(lambda: 'Вова.Артём')() == 'Vova.Artyom'
   

# Generated at 2022-06-23 20:52:25.935774
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru') is not None

# Generated at 2022-06-23 20:52:27.723917
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')
    assert romanize('be')

# Generated at 2022-06-23 20:52:35.758894
# Unit test for function romanize
def test_romanize():
    test_str = 'Далеко-далеко за словесными горами в стране, гласных.'
    test_romanized_str = 'Daleko-daleko za slovesnymy goryamy v strane, glasnykh.'
    assert romanize('ru')(lambda: test_str)() == test_romanized_str

# Generated at 2022-06-23 20:52:44.567843
# Unit test for function romanize
def test_romanize():
    # translate to russian
    from mimesis.builtins import RussiaSpecProvider

    @romanize('ru')
    def hello_world(language):
        return 'Hello, {0}'.format(language)

    r = RussiaSpecProvider()
    assert r.language.name() == hello_world(r.language.name())

    # translate to ukrainian
    from mimesis.builtins import UkraineSpecProvider

    @romanize('uk')
    def hello_world(language):
        return 'Hello, {0}'.format(language)

    r = UkraineSpecProvider()
    assert r.language.name() == hello_world(r.language.name())

    # translate to kazakh
    from mimesis.builtins import KazakhstanSpecProvider


# Generated at 2022-06-23 20:52:51.689654
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins
    import mimesis.enums

    alphabet = mimesis.builtins.Alphabet(
        mimesis.enums.Language.RUSSIAN, mimesis.enums.Locale.RU,
    )

    assert alphabet._romanize('Академический') == 'Akademicheskij'
    assert alphabet.romanize('Академический') == 'Akademicheskiy'
    assert alphabet.romanize('Академический городок') == \
        'Akademicheskiy gorodok'

# Generated at 2022-06-23 20:52:59.496801
# Unit test for function romanize

# Generated at 2022-06-23 20:53:07.739403
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Русский текст')() == 'Russkiy tekst'
    assert romanized('uk')(lambda: 'Український текст')() == 'Ukraїns’kyi tekst'
    assert romanized('kk')(lambda: 'Қазақ тілі')() == 'Qazaq tіlі'

test_romanize()

# Generated at 2022-06-23 20:53:17.266406
# Unit test for function romanize
def test_romanize():
    """Test the representational status of the text after romanization."""
    from mimesis.generic import Generic
    from mimesis.builtins import CyrillicLanguage

    g = Generic('ru')
    cl = CyrillicLanguage('ru')

    assert g.romanize(cl.word()) == cl.word()

    word = 'Небо потянуло синим эхом прошлого, плутало облака.'
    assert g.romanize(word) == word

# Generated at 2022-06-23 20:53:19.784734
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Редиска')() == 'Rediska'



# Generated at 2022-06-23 20:53:27.961172
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    from mimesis.providers.text import Text

    text = Text()
    text.romanize = romanize('ru')

    text_ru = text.ext_latin_text(locale='ru')
    text_italy = text.ext_latin_text(locale='it')
    text_other = text.ext_latin_text(locale='other')

    assert text_ru != text.ext_latin_text()
    assert text_ru != text_italy
    assert text_ru and text_italy not in text_other

# Generated at 2022-06-23 20:53:33.692559
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import CyrillicProvider
    assert romanized()(CyrillicProvider('').ascii)() == ''
    assert romanized()(CyrillicProvider('ru').ascii)() == ''
    assert romanized()(CyrillicProvider('uk').ascii)() == ''
    assert romanized()(CyrillicProvider('kk').ascii)() == ''

# Generated at 2022-06-23 20:53:37.171526
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    @romanize
    def words():
        return 'Привет, как дела?'

    assert words() == 'Privet, kak dela?'

# Generated at 2022-06-23 20:53:45.101251
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanized_text():
        return 'Привет, Мир!'
    assert romanized_text() == 'Privet, Mir!'

    @romanize()
    def romanized_text():
        return 'Привет, Мир!'
    assert romanized_text() == 'Privet, Mir!'

    @romanize('uk')
    def romanized_text():
        return 'Привіт, світе!'
    assert romanized_text() == 'Privit, svite!'

    @romanize('kk')
    def romanized_text():
        return 'Қалыңдар!'

# Generated at 2022-06-23 20:53:54.065163
# Unit test for function romanize
def test_romanize():
    romanize_str = romanize('ru')(lambda: 'РУССКИЙ')
    assert romanize_str() == 'RUSSKIJ'
    romanize_str = romanize('uk')(lambda: 'УКРАЇНСЬКИЙ')
    assert romanize_str() == 'UKRAJINSJKIJ'

    with UnsupportedLocale(locale=''):
        romanize_str = romanize('en')(lambda: '')
        romanize_str()

# Generated at 2022-06-23 20:54:00.038720
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""

    test_string = 'ЮПФХЦЧШЩЪЬЫЁЄЭЮЯ'
    romanized_string = 'YUPFHZHSHTEHYIEIYUIA'
    assert romanize(locale='ru')(lambda x: test_string)(locale='ru') == romanized_string
    assert romanize(locale='uk')(lambda x: test_string)(locale='uk') == romanized_string
    assert romanize(locale='kk')(lambda x: test_string)(locale='kk') == romanized_string

# Generated at 2022-06-23 20:54:01.341995
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(str)('русский язык') == 'russkij yazyk'

# Generated at 2022-06-23 20:54:12.640726
# Unit test for function romanize
def test_romanize():
    '''The test_romanize function tests that the decorator romanize
    works correctly. It uses the real implementation of functions
    like :func:`~mimesis.Personal.full_name` and replaces it with
    a mock function.

    The mock function returns the hardcoded test data.

    This functions tests how romanize decorator helps to return
    right results (non cyrilic) instead of wrong ones(cyrilic).

    .. note:: It is called from the test ``test_romanize`` in
        :mod:`~./test/test_locales.py`.
    '''
    # Importing here to avoid cyclic imports.
    from mimesis.providers.person import Person


# Generated at 2022-06-23 20:54:15.197507
# Unit test for function romanize
def test_romanize():
    text = 'Привет, Мир!'
    assert romanize()(text) == 'Privet, Mir!'

# Generated at 2022-06-23 20:54:23.885449
# Unit test for function romanize

# Generated at 2022-06-23 20:54:33.919959
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет, Мир!')() == 'Privet, mir!'
    assert romanize('ru')(lambda x: 'Привет, Мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda x: 'Привіт, Світе!')() == 'Pryvit, svite!'
    assert romanize('kk')(lambda x: 'Сәлем, Дүние!')() == 'Sälem, dünie!'
    assert romanize('de')(lambda x: 'Hallo, Welt!')() == 'Hallo, Welt!'

# Generated at 2022-06-23 20:54:34.490453
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:54:39.422455
# Unit test for function romanize
def test_romanize():
    func = romanize()
    
    @func
    def romanized_function(string):
        return string

    test_string = "Здравствуйте, мир!"
    romanized_string = "Zdravstvuyte, mir!"
    assert romanized_function(test_string) == romanized_string

# Generated at 2022-06-23 20:54:44.427457
# Unit test for function romanize
def test_romanize():
    """Test ``romanize`` decorator."""

    @romanize(locale='ru')
    def romanize_test(locale='ru'):
        return 'Воронеж'

    assert romanize_test() == 'Voronezh'

# Generated at 2022-06-23 20:54:47.267943
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""

    @romanized()
    def foo():
        return "Привет"

    assert foo() == "Privet"

# Generated at 2022-06-23 20:54:57.003323
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Address
    from mimesis.builtins import Person

    person = Person('ru')
    address = Address('ru')
    person_name = person.full_name()
    address_name = address.address()

    assert romanize()(person_name) == romanized()(person_name)
    assert romanize()(address_name) == romanized()(address_name)
    assert romanize(locale='ru')(person_name) == \
        romanized(locale='ru')(person_name)
    assert romanize(locale='ru')(address_name) == \
        romanized(locale='ru')(address_name)

# Generated at 2022-06-23 20:54:59.567228
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет, Мир!') == 'Privyet, Mir!'



# Generated at 2022-06-23 20:55:09.079067
# Unit test for function romanize
def test_romanize():
    # When I romanize text "абвгдеёжз" from locale "ru"
    txt = romanize(locale='ru')(lambda x: 'абвгдеёжз')

    # Then I see "abvgdeejz"
    assert txt == 'abvgdeejz'

    # When I romanize text "Абвгдеёжз" from locale "ru"
    txt = romanize(locale='ru')(lambda x: 'Абвгдеёжз')

    # Then I see "Abvgdeejz"
    assert txt == 'Abvgdeejz'

    # When I romanize text "Илл

# Generated at 2022-06-23 20:55:16.138740
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.person import Person
    from mimesis.providers.utils import ProviderCode, set_provider

    set_provider('ru')

    ass = Address()
    r = RussiaSpecProvider()
    p = Person()

    assert ass.building_name() == 'Атлант'
    assert ass.state(full=True) == 'Республика Хакасия'
    assert ass.street_prefix() == 'улица'

    assert r.attribution_particle() == 'З.п.'
    assert r.azim

# Generated at 2022-06-23 20:55:20.665416
# Unit test for function romanize
def test_romanize():
    """Test romanize() functionality."""
    def func():
        """Test function."""
        return "Привет мир!".lower()

    @romanize()
    def func1():
        """Test function."""
        return "Привет мир!".lower()


    assert func1() == "privet mir!"
    assert func() != func1()

# Generated at 2022-06-23 20:55:27.903071
# Unit test for function romanize
def test_romanize():
    def func(x):
        return x

    x = 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'
    res = romanize('ru')(func)(x)
    assert res == 'abvgdeezhzijklmnoprstufhzschschyieuyuya'

# Generated at 2022-06-23 20:55:30.653481
# Unit test for function romanize
def test_romanize():
    from mimesis import Personal

    p = Personal('ru')
    assert p.full_name() == 'Валерий Любимов'
    assert p.romanized.full_name('ru') == 'Valeriy Lyubimov'

# Generated at 2022-06-23 20:55:36.051692
# Unit test for function romanize
def test_romanize():
    assert romanize("kk")("Бұл қазақ тілі") == "Bul qazaq tili"
    assert romanize("ru")("Это кириллица") == "Eto kirillitsa"
    assert romanize("uk")("Це кирилиця") == "Tse kirilitsia"

# Generated at 2022-06-23 20:55:37.748448
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Мимезис')() == 'Mimezis'

# Generated at 2022-06-23 20:55:46.498033
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.base import BaseDataProvider

    class MyClass(BaseDataProvider):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        @romanize(Locale.UKRAINIAN)
        def myfunc(self):
            return "Привіт, як справи?"

    myobj = MyClass()
    assert myobj.myfunc() == 'Pryvit, yak spravy?'

# Generated at 2022-06-23 20:55:48.335429
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'абв')() == 'abv'

# Generated at 2022-06-23 20:55:52.705336
# Unit test for function romanize
def test_romanize():
    # Set locale
    locale = 'ru'

    # Set func
    def func():
        return 'кириллица'

    # Apply romanize to func
    func = romanize(locale)(func)

    # Romanized text
    result = func()
    assert 'kirillitsa' == result

# Generated at 2022-06-23 20:55:58.734701
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    @romanize(locale='en')
    def romanized_text(locale, seed):
        """Romanize the text."""
        return 'Ёабвгдеёжзийклмнопрстуфхцчшщъыьэюя'

    assert romanized_text('en', None) == 'YaBbVgDeYoZzIyKlMnOpRstUfKhTsChShShYyY`EhYuYa'



# Generated at 2022-06-23 20:56:09.867207
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    def func_test(locale: str) -> str:
        return 'Привет, давайте романизируем этот текст!'

    romanized_uk = romanized('uk')(func_test)('uk')
    assert romanized_uk == 'Pryvit, davayte romanizuyem etot tekst!'

    romanized_ru = romanized('ru')(func_test)('ru')
    assert romanized_ru == 'Privet, davayte romaniziruem etot tekst!'

    romanized_kk = romanized('kk')(func_test)('kk')

# Generated at 2022-06-23 20:56:10.983939
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:56:17.364190
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def ru_gen():
        return 'тест'

    assert ru_gen() == 'test'

    @romanize('uk')
    def uk_gen():
        return 'тест'

    assert uk_gen() == 'test'

    @romanize('kk')
    def kk_gen():
        return 'тест'

    assert kk_gen() == 'tест'



# Generated at 2022-06-23 20:56:18.234814
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:56:20.935630
# Unit test for function romanize
def test_romanize():
    @romanize()
    def rus(text):
        return text

    assert rus('Привет, мир') == 'Privet, mir'

# Generated at 2022-06-23 20:56:26.578200
# Unit test for function romanize
def test_romanize():
    x = 'Привет, мир!'
    assert ['P', 'r', 'i', 'v', 'e', 't', ',', ' ', 'm', 'i', 'r', '!'] == list(
        romanize('ru')(lambda : x))

# Generated at 2022-06-23 20:56:29.602726
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_text() -> str:
        return 'Александр'

    assert romanize_text() == 'Aleksandr'



# Generated at 2022-06-23 20:56:40.623495
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    locale = 'ru'

    def foo(*args, **kwargs):
        return "Вероятность как две девицы"

    foo_romanized = romanize(locale)(foo)
    assert foo_romanized() == 'Veroyatnostʹ kak dve devicy'

    @romanized(locale)
    def bar(*args, **kwargs):
        return "Вероятность как две девицы"

    assert bar() == 'Veroyatnostʹ kak dve devicy'

    assert romanize('not_exists')(lambda: True)

    assert foo.__name__

# Generated at 2022-06-23 20:56:52.495277
# Unit test for function romanize
def test_romanize():
    # Russian
    @romanize(locale='ru')
    def test_rus(seed: int = None) -> str:
        return 'Я пришёл в классе после перемены'

    # Ukrainian
    @romanize(locale='uk')
    def test_ukr(seed: int = None) -> str:
        return 'Я прийшов у класі після перерви'

    # Kazakh

# Generated at 2022-06-23 20:56:55.655518
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    person = Person('ru')
    assert romanized('ru')(person.name)(sex=person.GENDER.MALE)



# Generated at 2022-06-23 20:56:59.043188
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    result = romanize(locale='ru')(lambda: 'Кириллица')
    assert isinstance(result, str)
    assert result == 'Kirillitsa'

# Generated at 2022-06-23 20:57:04.225239
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda : 'Привет, мир!')() == 'Privet, mir!'
    assert romanized(locale='uk')(lambda : 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanized(locale='kk')(lambda : 'Сәлем, дүние!')() == 'Sälem, dünie!'

# Generated at 2022-06-23 20:57:15.747191
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize()('Прiвет') == 'Privet'
    assert romanize()('Прибию') == 'Pribiyu'
    assert romanize()('стихи') == 'stihi'
    assert romanize()('где') == 'gde'
    assert romanize()('атмосфера') == 'atmosfera'
    assert romanize()('Где живут люди') == 'Gde zhivut lyudi'
    assert romanize()('Слово') == 'Slovo'

# Generated at 2022-06-23 20:57:20.970300
# Unit test for function romanize
def test_romanize():
    def func(text: str) -> str:
        return text

    func = romanize(locale='ru')(func)
    result = func('домашка')
    assert result == 'domashka', 'It should be "domashka".'

# Generated at 2022-06-23 20:57:26.197224
# Unit test for function romanize
def test_romanize():
    a = romanize(locale='ru')(lambda: 'привет дорогой друг, как дела?')()
    b = romanize(locale='uk')(lambda: 'баче мама мене баче')()
    c = romanize(locale='kk')(lambda: 'бұл ең еңінен жақсы')()
    d = romanize(locale='en')(lambda: 'какой глупый')()
    assert a == 'privet dorogoy drug, kak dela?'

# Generated at 2022-06-23 20:57:28.152825
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет мир') == 'Privet mir'



# Generated at 2022-06-23 20:57:30.011475
# Unit test for function romanize
def test_romanize():
    _ = romanized('ru')(lambda: 'Держитесь')
    assert _() == 'Derzitieisie'

# Generated at 2022-06-23 20:57:34.382922
# Unit test for function romanize
def test_romanize():
    """Test romanization."""
    @romanize
    def _(param):
        return 'Тест' + param

    assert _('слово') == 'Testслово'



# Generated at 2022-06-23 20:57:39.959947
# Unit test for function romanize
def test_romanize():
    """Test that romanize works correctly."""
    from mimesis.builtins import RussiaSpecProvider

    r = RussiaSpecProvider()

    assert r.name() == r.romanize(r.name())
    assert r.surname() == r.romanize(r.surname())
    assert r.address() == r.romanize(r.address())

# Generated at 2022-06-23 20:57:49.606490
# Unit test for function romanize
def test_romanize():
    """Tests for romanize."""
    txt = romanize(locale='ru')(lambda: 'Привет, мир!')()
    assert txt == 'Privet, mir!'

    txt = romanize(locale='ru')(lambda: 'Как дела?')()
    assert txt == 'Kak dela?'

    txt = romanize(locale='uk')(lambda: 'Вітаю, світ!')()
    assert txt == 'Vitayu, svit!'

    txt = romanize(locale='uk')(lambda: 'Як справи?')()
    assert txt == 'Yak spravy?'
