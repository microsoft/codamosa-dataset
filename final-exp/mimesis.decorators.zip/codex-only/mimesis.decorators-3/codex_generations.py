

# Generated at 2022-06-23 20:47:40.741537
# Unit test for function romanize
def test_romanize():
    '''Test romanize'''
    pass

# Generated at 2022-06-23 20:47:42.755435
# Unit test for function romanize
def test_romanize():
    assert(romanized(locale='ru')(lambda : 'Привет')() == romanize(locale='ru')(lambda : 'Привет')())


# Generated at 2022-06-23 20:47:49.063279
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_ru(self):
        return self._data['ru']['bio']['full_name']

    assert test_ru(None) == 'Петров Иван Сергеевич'
    assert romanized('ru')(test_ru)(None) == 'Петров Иван Сергеевич'

# Generated at 2022-06-23 20:47:52.437451
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    @romanize('ru')
    def get_cyrillic():
        return 'Россия'

    assert get_cyrillic() == 'Rossiya'


test_romanize()

# Generated at 2022-06-23 20:48:02.568243
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Languages

    uk_data_set = [
        'ЛЯЛЯ',
        'ШЕВЕЛЕННЯ',
        'Лабораторія',
        'Лабораторiя',
        'Лабораторії',
        'Лабораторiї',
        'ЛАБОРАТОРIЇ',
    ]


# Generated at 2022-06-23 20:48:05.359384
# Unit test for function romanize
def test_romanize():
    expected = "sdf6ghj"
    actual = romanize()(lambda x: "сdf6гхj")()
    assert expected == actual

# Generated at 2022-06-23 20:48:14.581034
# Unit test for function romanize
def test_romanize():
    """Test function.

    Test function romanize.
    """
    assert romanized('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanized('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanized('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanized('kk')(lambda: 'Қалайықша, қазақша!')() == \
        'Qalayıqşa, qazaqşa'

# Generated at 2022-06-23 20:48:19.709488
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.identifiers import Identifiers

    def test_locale(locale: str):
        @romanize(locale)
        def name():
            return Identifiers(locale).username()

        assert name()

    test_locale(Locale.RU)
    test_locale(Locale.UK)
    test_locale(Locale.KK)

# Generated at 2022-06-23 20:48:20.933131
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize, Callable)
    assert isinstance(romanized, Callable)



# Generated at 2022-06-23 20:48:24.386383
# Unit test for function romanize
def test_romanize():
    @romanize(locale="ru")
    def get_russian_name():
        return "Галина"

    assert get_russian_name() == "Galina"

# Generated at 2022-06-23 20:48:25.357130
# Unit test for function romanize
def test_romanize():
    assert romanize()  # should not raise an error

# Generated at 2022-06-23 20:48:28.986806
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins
    cyr = mimesis.builtins.Cyrillic('ru')
    result = cyr.word()
    expected = 'тест'
    assert result == expected, 'Expected "%s", but got "%s"' % (expected, result)

# Generated at 2022-06-23 20:48:31.577718
# Unit test for function romanize
def test_romanize():
    assert romaniz(locale="ru")
    assert romaniz(locale="uk")
    assert romaniz(locale="kk")

# Generated at 2022-06-23 20:48:34.590788
# Unit test for function romanize
def test_romanize():
    alp = ascii_letters + digits + punctuation
    for i in alp:
        assert romanize(locale='ru')(lambda: i)(), i

# Generated at 2022-06-23 20:48:37.326560
# Unit test for function romanize
def test_romanize():
    res = romanize(locale='ru')(lambda x: 'Привет, мир!')
    assert res == 'Privet, mir!'

# Generated at 2022-06-23 20:48:46.512812
# Unit test for function romanize

# Generated at 2022-06-23 20:48:56.865972
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир')() == 'Privet mir'
    assert romanize('ru')(lambda: 'Быть или не быть, вот в чём вопрос')() == \
        'Byt' + '\'' + ' ili ne byt\', vot v chem vopros'
    assert romanize('ru')(lambda: 'Плюшевый медведь')() == \
        'Plyushevy' + '\'' + 'j medved\''

# Generated at 2022-06-23 20:48:59.145058
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'Попробуйте позже.')() == 'Poprobuyte pozzhe.'

# Generated at 2022-06-23 20:49:05.591718
# Unit test for function romanize
def test_romanize():
    test_string = 'Сергей Петрович'
    assert romanize(locale='ru')(test_string) == 'Sergej Petrovič'
    test_string = 'Кирилл Денисович'
    assert romanize(locale='ru')(test_string) == 'Kirill Denisovič'
    test_string = 'Юлия Васильевна'
    assert romanize(locale='ru')(test_string) == 'Julija Vasil’evna'
    test_string = 'Игорь Юрьевич'

# Generated at 2022-06-23 20:49:08.095313
# Unit test for function romanize
def test_romanize():
    txt = 'Монета'
    assert romanize('kk')(lambda: txt)() == 'Moneta'

# Generated at 2022-06-23 20:49:13.852922
# Unit test for function romanize
def test_romanize():
    """Romanized test."""
    result = romanize()
    resp = result(lambda: 'привет')
    assert resp == 'privet'

    resp = result(lambda: 'Нет')
    assert resp == 'Net'

    resp = result(lambda: 'ура')
    assert resp == 'ura'

    resp = result(lambda: 'Окей')
    assert resp == 'Okej'

# Generated at 2022-06-23 20:49:18.678368
# Unit test for function romanize
def test_romanize():
    cyrillic = 'Что такое программирование? Это код для компьютера, написанный человеком.'
    latin = 'Chto takoye programmirovaniye? YEto kod dlya kompyutera, napisannyy chelovekom.'

    assert romanized('ru')(lambda: cyrillic) == latin

# Generated at 2022-06-23 20:49:23.533674
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    from mimesis.enums import Locales
    from mimesis.providers.lorem import Lorem

    lorem = Lorem(locale=Locales.EN)
    assert lorem.romanize() == 'DGkMVwpHZQzXDlNfR2IJNlw='

# Generated at 2022-06-23 20:49:26.358923
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize(text):
        return text

    text = romanize('Привет мир!')
    assert text == 'Privet mir!'

# Generated at 2022-06-23 20:49:33.755449
# Unit test for function romanize
def test_romanize():
    """This is a test for romanize()

    Romanize() takes a cyrillic text,
    encodes it in utf-8 and transliterates it.
    :return: transliterated text
    """

    import pytest

    @romanize('ru')
    def romanizer(text):
        return text

    result = romanizer('Привет').encode('UTF-8').decode('utf-8')
    assert result == 'Privet'

    result = romanizer('Привет').encode('UTF-8').decode('utf-8')
    assert result == 'Privet'

    result = romanizer('Андрей').encode('UTF-8').decode('utf-8')
    assert result == 'Andrej'



# Generated at 2022-06-23 20:49:35.780724
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    p = Person('de')

    assert p.full_name() != p.get_full_name()



# Generated at 2022-06-23 20:49:41.776767
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Россия') == 'Rossiya'
    assert romanize('uk')('Світ') == 'Svit'
    assert romanize('kk')('Қазақстан') == 'Qazaqstan'



# Generated at 2022-06-23 20:49:44.036281
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_text():
        return 'Мимезис'

    assert get_text() == 'Mimezis'

# Generated at 2022-06-23 20:49:48.082278
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, Мир!') == 'Privet, Mir!'
    assert romanize('ru')('Привет, Мир!') == 'Privet, Mir!'
    assert romanize('uk')('Привет, Мир!') == 'Pryvit, Mir!'

# Generated at 2022-06-23 20:49:51.558075
# Unit test for function romanize
def test_romanize():
    _romanized = romanized(locale='ru')(lambda: 'Привет')
    assert _romanized() == 'Privet'

# Generated at 2022-06-23 20:49:59.917775
# Unit test for function romanize
def test_romanize():
    """Unit test."""
    def func(l: str) -> str:
        return l

    func_r = romanize('ru')(func)
    func_k = romanize('uk')(func)

    assert func('привет мир!') == func_r('привет мир!')
    assert func_r('привет мир!') == 'privet mir!'
    assert func_k('как дела?') == 'kak dela?'

# Generated at 2022-06-23 20:50:04.089609
# Unit test for function romanize
def test_romanize():
    # Pylint ignores the fact that there is no function with
    # name 'romanize'
    # pylint: disable=undefined-variable

    @romanized(locale='ru')
    def fake_ru_data(pattern=None):
        return 'Привет, мир'

    assert 'Privet, mir' == fake_ru_data()

# Generated at 2022-06-23 20:50:13.243003
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_name():
        return 'Иван'

    assert get_name() == 'Ivan'

    def get_locale():
        return 'uk'

    @romanize(get_locale())
    def get_name():
        return 'Максим'

    assert get_name() == 'Maksym'

    # Wrong locale
    @romanize(locale='wrong_locale')
    def get_name():
        return 'Максим'

    try:
        get_name()
        assert False
    except UnsupportedLocale as e:
        assert e.locale == 'wrong_locale'

    # Russian locale for cyrillic string
    @romanize(locale='ru')
    def get_name():
        return

# Generated at 2022-06-23 20:50:16.686553
# Unit test for function romanize
def test_romanize():
    def test_function(text):
        return text

    romanized_function = romanize('ru')(test_function)
    assert romanized_function('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-23 20:50:17.181664
# Unit test for function romanize
def test_romanize():
    assert 1 == 1

# Generated at 2022-06-23 20:50:19.264259
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир')() == 'Привет мир'

# Generated at 2022-06-23 20:50:28.353478
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')

    old_value = data.ROMANIZATION_DICT.keys()
    data.ROMANIZATION_DICT.pop('ru')
    data.ROMANIZATION_DICT.pop('uk')
    data.ROMANIZATION_DICT.pop('kk')

    with pytest.raises(UnsupportedLocale):
        romanize('ru')
    with pytest.raises(UnsupportedLocale):
        romanize('uk')
    with pytest.raises(UnsupportedLocale):
        romanize('kk')


# Generated at 2022-06-23 20:50:37.094051
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator"""

    @romanize(locale='ru')
    def russian_text():
        return 'Очень длинный текст'

    assert russian_text() == 'Ochen dlinnyj tekst'

    @romanize(locale='uk')
    def ukrainian_text():
        return 'Очень довгий текст'

    assert ukrainian_text() == 'Ochen dovhyj tekst'

# Generated at 2022-06-23 20:50:44.570082
# Unit test for function romanize
def test_romanize():
    """Unit test for the function romanize."""
    assert romanize('en')(lambda x: 'Hello молоко')() == 'Hello moloko'
    assert romanize('ru')(lambda x: 'Hello молоко')() == 'Hello moloko'
    assert romanize('uk')(lambda x: 'Hello молоко')() == 'Hello moloko'
    assert romanize('kk')(lambda x: 'Hello молоко')() == 'Hello moloko'

# Generated at 2022-06-23 20:50:50.240759
# Unit test for function romanize
def test_romanize():
    # Test text.
    text = 'Русский и Український'

    # English alphabet, digits and punctuation.
    eng = ascii_letters + digits + punctuation

    # English version of a text.
    eng_text = 'Russkiy i Ukrainskiy'

    # Assert method.
    assert all([i in eng for i in eng_text])
    assert len(eng_text) == len(text)

# Generated at 2022-06-23 20:50:52.703535
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Мир громко молчит') == 'Mir gromko molchit'

# Generated at 2022-06-23 20:50:54.429986
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanizer():
        return 'привет'

    assert romanizer() == 'privet'

# Generated at 2022-06-23 20:50:55.756276
# Unit test for function romanize
def test_romanize():
    """Unit tests for function romanize."""
    assert romanize()



# Generated at 2022-06-23 20:50:57.482090
# Unit test for function romanize
def test_romanize():
    assert romanize('en')

# Generated at 2022-06-23 20:50:58.697711
# Unit test for function romanize
def test_romanize():
    pass

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:51:03.024977
# Unit test for function romanize
def test_romanize():
    # Transliterate a Cyrillic string.
    romanized_string = 'ljhj,ybr'

    @romanize(locale='ru')
    def foo():
        return romanized_string

    assert foo() == 'привет'



# Generated at 2022-06-23 20:51:12.025236
# Unit test for function romanize
def test_romanize():
    # Тесты для русского языка
    romanized('ru')('привет')()
    romanized('ru')('ru')()
    romanized('ru')('тест')()
    romanized('ru')('при')()
    romanized('ru')('то')()
    # Тесты для украинского языка
    romanized('uk')('привіт')()
    romanized('uk')('тест')()
    romanized('uk')('при')()

# Generated at 2022-06-23 20:51:13.885453
# Unit test for function romanize
def test_romanize():
    assert (romanize('ru')(lambda: 'Привет') == 'Privet')

# Generated at 2022-06-23 20:51:15.812783
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'привет')('') == 'privet'

# Generated at 2022-06-23 20:51:19.664364
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'По оживлённым берегам'
    assert 'Po ojivljonnym beregam' == foo()


# Generated at 2022-06-23 20:51:27.977384
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    from mimesis.builtins import RussianSpecProvider as RU

    ru = RU()
    assert ru._romanize_deco(ru.name)() == ru.name()
    assert ru._romanize_deco(ru.surname)() == ru.surname()
    assert ru._romanize_deco(ru.text)() == ru.text()
    assert ru._romanize_deco(ru.email)() == ru.email()

    from mimesis.builtins import UkrainianSpecProvider as UA

    ua = UA()
    assert ua._romanize_deco(ua.name)() == ua.name()
    assert ua._romanize_deco(ua.surname)() == ua.surname()
    assert ua._romanize_

# Generated at 2022-06-23 20:51:37.183049
# Unit test for function romanize
def test_romanize():
    # English
    assert romanize('en')(lambda: 'Hello')() == 'Hello'

    # Russian
    assert romanize('ru_RU')(lambda: 'привет')() == 'privet'
    assert romanize('ru_RU')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

    # Ukrainian
    assert romanize('uk_UA')(lambda: 'привіт')() == 'pryvit'
    assert romanize('uk_UA')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'

    # Kazakh

# Generated at 2022-06-23 20:51:48.928197
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from textwrap import dedent

    @romanize(locale=Locale.EN)
    def dummy_en():
        return 'Здравствуй, Мир!'

    assert dummy_en() == 'Zdravstvuy, Mir!'

    @romanize(locale=Locale.RU)
    def dummy_ru():
        return 'Здравствуй, Мир!'

    assert dummy_ru() == 'Zdravstvuj, Mir!'

    @romanize(locale=Locale.UK)
    def dummy_uk():
        return 'Здравствуй, Мир!'


# Generated at 2022-06-23 20:51:50.967679
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    p = Person()
    assert p.full_name() != p.romanized.full_name()

# Generated at 2022-06-23 20:52:00.346247
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: "Широкая электрификация южных губерний даст мощный толчок подъёму сельского хозяйства.")() == "Shirokaya elektrifikatsiya yuzhnykh guberniy dast moshchnyj tolchok pod'yomu sel'skogo khozyaystva."

# Generated at 2022-06-23 20:52:04.426342
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    def test_func():
        return 'Действие активировано!'

    test_func = romanize(locale='ru')(test_func)
    assert test_func() == 'Dejstvie aktivirovano!'

# Generated at 2022-06-23 20:52:08.318977
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Salem'

# Generated at 2022-06-23 20:52:12.105354
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def gen_rus_name():
        return 'Алексей'

    assert gen_rus_name() == 'Aleksey'

# Generated at 2022-06-23 20:52:15.149663
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_test(alphabet):
        return alphabet

    result = romanize_test('Как дела')
    assert result == 'Kak dela'

# Generated at 2022-06-23 20:52:25.944919
# Unit test for function romanize
def test_romanize():

    # Tests for Russian letters
    assert romanize('ru')(lambda: 'фыва')() == 'fivа'

    # Tests for Ukrainian letters
    assert romanize('uk')(lambda: 'фыва')() == 'fivа'

    # Tests for Kazakh letters
    assert romanize('kk')(lambda: 'фыва')() == 'fıvɑ'

    # Tests for unsupported locale
    try:
        romanize('zz')(lambda: 'фыва')()
    except UnsupportedLocale as e:
        assert str(e) == 'Unsupported locale: zz'
    else:
        assert False

    # Tests for common letters
    assert romanize('zz')(lambda: 'привет')() == 'privet'

# Generated at 2022-06-23 20:52:27.605452
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    _specs = RussianSpecProvider
    assert romanized()(_specs().person.last_name) == 'Petrov'

# Generated at 2022-06-23 20:52:31.954098
# Unit test for function romanize
def test_romanize():
    txt = 'Александр Сергеевич Пушкин'
    assert romanized(locale='ru')(txt) == 'Aleksandr Sergeevich Pushkin'

# Generated at 2022-06-23 20:52:37.505634
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: data.random_int())(length=4) == '0682'
    assert romanize(locale='uk')(lambda: data.random_int())(length=4) == '8253'
    assert romanize(locale='kk')(lambda: data.random_int())(length=4) == '3574'

# Generated at 2022-06-23 20:52:45.032047
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    from mimesis.builtins import RussiaSpecProvider

    #: :type: Person
    person_athor = Person(locale='ru')
    #: :type: RussiaSpecProvider
    russia_spec = RussiaSpecProvider(locale='ru')
    assert person_athor.full_name() == russia_spec.full_name()

    #: :type: Person
    person_athor = Person(locale='kk')
    #: :type: RussiaSpecProvider
    russia_spec = RussiaSpecProvider(locale='kk')
    assert person_athor.full_name() == russia_spec.full_name()

# Generated at 2022-06-23 20:52:47.806012
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет! Как дела?')(
    ) == 'Privet! Kak dela?'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:52:49.411167
# Unit test for function romanize
def test_romanize():
    pass



# Generated at 2022-06-23 20:52:56.597089
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.text import Text
    from mimesis.providers.other import Other

    lorem = Lorem('ru', True)
    txt = Text('ru', True)
    other = Other('ru', True)

    txt.get_word(3)
    assert isinstance(other.romanize('Русский'), str)
    assert len(txt.get_sentence()) > 0
    assert len(txt.get_text()) > 0
    assert len(lorem.get_paragraph(1)) > 0



# Generated at 2022-06-23 20:52:58.624157
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Строка')() == 'Stroka'



# Generated at 2022-06-23 20:53:08.906083
# Unit test for function romanize
def test_romanize():
    assert 'test' == romanized('en')(lambda: 'test')()
    assert 'test' == romanized('ru')(lambda: 'тест')()
    assert 'test' == romanized('uk')(lambda: 'тест')()
    assert 'test' == romanized('kk')(lambda: 'тест')()
    assert 'test_test' == romanized('ru')(lambda: 'тест_тест')()
    assert 'test_test' == romanized('uk')(lambda: 'тест_тест')()
    assert 'test_test' == romanized('kk')(lambda: 'тест_тест')()

# Generated at 2022-06-23 20:53:17.234001
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    def romanized(locale: str = Language[Language.EN].value,
                  *args, **kwargs):
        func = lambda *i, **k: 'Привет, друг!'
        romanized = romanize(locale)(func)
        return romanized(*args, **kwargs)

    assert romanized(Language[Language.RU].value) == 'Привет, друг!'
    assert romanized(Language[Language.UK].value) == 'Привіт, друг!'
    assert romanized(Language[Language.KK].value) == 'Привет, друг!'

# Generated at 2022-06-23 20:53:20.704374
# Unit test for function romanize
def test_romanize():
    @romanize()
    def roman():
        return "ПриветМир"
    assert roman() == "PrivetMir"

    @romanize()
    def another_roman():
        return "ПриветМир!"
    assert another_roman() == "PrivetMir!"

# Generated at 2022-06-23 20:53:26.044975
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')('Мимимими') == 'Mimimimi'
    assert romanized(locale='uk')('Мимимими') == 'Mymymymy'
    assert romanized(locale='kk')('Мимимими') == 'Mîmymymy'

# Generated at 2022-06-23 20:53:27.669555
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')
    assert romanized(locale='ru')



# Generated at 2022-06-23 20:53:29.546860
# Unit test for function romanize
def test_romanize():
    assert 'Привет' == romanize('ru')(lambda: 'Привет')

# Generated at 2022-06-23 20:53:39.550344
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test_ru(text: str = '') -> str:
        return text or 'привет мир'

    @romanize(locale='uk')
    def test_uk(text: str = '') -> str:
        return text or 'привіт світ'

    @romanize(locale='kk')
    def test_kk(text: str = '') -> str:
        return text or 'қауіпсіз әлем'

    assert test_ru() == 'privet mir'
    assert test_uk() == 'privit svit'
    assert test_kk() == 'kauipsiz alemb'

    # Test for function using custom args
   

# Generated at 2022-06-23 20:53:42.421886
# Unit test for function romanize
def test_romanize():
    @romanize()
    def roman():
        pass
    assert roman() == ''

    @romanize('kk')
    def roman_kk():
        pass
    assert roman_kk() == ''



# Generated at 2022-06-23 20:53:46.176116
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize():
        return "привет!"
    assert romanize() == 'privet!'


if __name__ == '__main__':
    romanized()

# Generated at 2022-06-23 20:53:47.328513
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')

# Generated at 2022-06-23 20:53:52.359174
# Unit test for function romanize
def test_romanize():
    """Romanize the cyrillic text."""
    data_ru = data.Data('ru')
    text = data_ru.personal.username()

    @romanize(locale='ru')
    def romanizer(text):
        return text

    assert text != romanizer(text)

# Generated at 2022-06-23 20:53:57.864787
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Все хорошо')() == 'Vse horosho'
    assert romanize('uk')(lambda: 'Все хорошо')() == 'Vse horosho'
    assert romanize('kk')(lambda: 'Улық ҡаҡтарды')() == 'Ulyq qaqtardy'

# Generated at 2022-06-23 20:54:01.416092
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ua')(lambda: 'Комунікація')() == 'Komunikatsiya'



# Generated at 2022-06-23 20:54:12.282418
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')
    assert p.gender(Gender.MALE) == 'Мужской'
    assert p.gender(Gender.FEMALE) == 'Женский'

    p = Person('uk')
    assert p.gender(Gender.MALE) == 'Чоловіча'
    assert p.gender(Gender.FEMALE) == 'Жіноча'

    p = Person('kk')
    assert p.gender(Gender.MALE) == 'Еркек'
    assert p.gender(Gender.FEMALE) == 'Аял'

# Generated at 2022-06-23 20:54:14.387233
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:54:17.033313
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:54:17.870486
# Unit test for function romanize
def test_romanize():
    assert romanize()  # noqa: F811

# Generated at 2022-06-23 20:54:25.494526
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет! Как дела?') == \
        'Privet! Kak dela?'

    assert romanize('ru')('Привет! Как дела?') == \
        'Privet! Kak dela?'

    assert romanize('uk')('Привет! Как дела?') == \
        'Privit! Jak dela?'

    assert romanize('kk')('Привет! Как дела?') == \
        'Privet! Qa, dela?'

# Generated at 2022-06-23 20:54:34.988473
# Unit test for function romanize
def test_romanize():
    # Should not be romanized
    result = romanize('ru')(lambda: '123')()
    assert result == '123'

    # Should be romanized
    result = romanize('ru')(lambda: 'Привет!')()
    assert result == 'Privet!'

    # Should not be romanized
    result = romanize('uk')(lambda: '123')()
    assert result == '123'

    # Should be romanized
    result = romanize('uk')(lambda: 'Привіт')()
    assert result == 'Pryvit'

    # Should not be romanized
    result = romanize('kk')(lambda: '123')()
    assert result == '123'

    # Should be romanized
    result = r

# Generated at 2022-06-23 20:54:39.202973
# Unit test for function romanize
def test_romanize():
    """Test case for function `romanize`."""
    romanized_func = romanized()(lambda x: x)
    assert romanized_func('Лорем ипсум долор сит') == 'Lorem ipsum dolor sit'

# Generated at 2022-06-23 20:54:47.918002
# Unit test for function romanize
def test_romanize():
    '''
    Проверяет, что мы сможем правильно романизировать русское слово.
    '''
    def rus(to_romanize):
        return romanize('ru')(to_romanize)()
    assert "Privet" == rus("Привет")
    assert "Poka" == rus("Пока")

# Generated at 2022-06-23 20:54:58.856256
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo(locale):
        return data.ROMANIZATION_DICT[locale]


# Generated at 2022-06-23 20:55:02.305960
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_to_eng(text):
        return text

    assert rus_to_eng('Мама мыла раму.') == 'Mama myla ramu.'

# Generated at 2022-06-23 20:55:05.224903
# Unit test for function romanize
def test_romanize():
    assert romanize()('Абвгдеёжзийклмнопрстуфхцчшщъыьэюя')

# Generated at 2022-06-23 20:55:06.544075
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()

# Generated at 2022-06-23 20:55:15.547413
# Unit test for function romanize
def test_romanize():
    from mimesis.datetime import Datetime
    from mimesis.enums import Language
    from mimesis.providers.person import Person
    from mimesis.utils import random_ascii

    p = Person(Language.RU)

    def test_decorator():
        @romanize()
        def get_name():
            return p.full_name()

        n = get_name()

        assert n is not None
        assert n.isalpha()
        assert n == Datetime('ru').romanized_full_date()

    test_decorator()

    dt = Datetime('ru')
    assert dt.romanized_full_date() is not None
    assert dt.romanized_full_date().isalpha()

    r_date = dt.romanized_date()
    r_

# Generated at 2022-06-23 20:55:19.622741
# Unit test for function romanize
def test_romanize():
    import mimesis

    r = mimesis.Personal(mimesis.Localization.RU)
    assert r.romanize(r.full_name()) == 'Dmitrenko Kirill Sergeevich'
    assert r.romanize(r.full_name(), locale='ru') == 'Dmitrenko Kirill Sergeevich'


# Generated at 2022-06-23 20:55:22.992517
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'ПрИвЕт')() == 'Privet'

# Generated at 2022-06-23 20:55:28.482139
# Unit test for function romanize
def test_romanize():
    # Arrange
    expected = 'zdravstvujte'
    actual = ''

    # Act
    @romanize('ru')
    def test_func_ru():
        return 'здравствуйте'

    actual = test_func_ru()

    # Assert
    assert expected == actual

# Generated at 2022-06-23 20:55:32.939126
# Unit test for function romanize
def test_romanize():
    func_romanized = romanize(locale='ru')(lambda: "абвгдеёзиклмнопрстуф")
    assert func_romanized() == 'abvgdezzizklmnoprstuf'



# Generated at 2022-06-23 20:55:35.144711
# Unit test for function romanize
def test_romanize():
    """Test romanize method."""
    import mimesis.data

    print('\nTesting function romanize')
    fake = mimesis.data.Fake('ru')
    assert fake.romanize()[0] == 'M'

# Generated at 2022-06-23 20:55:39.136251
# Unit test for function romanize
def test_romanize():
    assert romanize(locale="ru")(lambda: "Александр")() == "Aleksandr"
    assert romanize(locale="kk")(lambda: "Құрман")() == "Qurman"
    assert romanize(locale="kk")(lambda: "Ліштін")() == "Lishtin"
    assert romanize(locale="uk")(lambda: "Віра")() == "Vira"
    assert romanize(locale="uk")(lambda: "Марія")() == "Mariia"
    assert romanize(locale="uk")(lambda: "Микола")() == "Mykola"

# Generated at 2022-06-23 20:55:46.647557
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address

    address = Address(locale='ru')

    # without localisation
    russian = address.building_number()
    russian_romanized = address.building_number(locale='ru').romanize()
    assert russian_romanized != russian

    # with localisation
    address = Address()
    russian = address.building_number(locale='ru').romanize()
    english = address.building_number()
    assert russian != english

# Generated at 2022-06-23 20:55:50.663292
# Unit test for function romanize
def test_romanize():
    """Test romanizing the cyrillic text."""
    assert romanize('ru')(lambda x: 'Кругом шумели камыши')() == \
        'Krugom shumeli kamyshi'

# Generated at 2022-06-23 20:55:59.957022
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.enums import TimeZone
    from mimesis.providers.address import Address

    adr = Address('ru')

    def romanize(locale: str = '') -> Callable:
        def romanize_deco(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                result = func(*args, **kwargs)
                return result.romanize(locale)

            return wrapper

        return romanize_deco

    @romanize()
    def dummy_func():
        return 'Шапка'

    assert dummy_func() == 'Shapka'
    assert adr.romanize('ru', 'Шапка') == 'Shapka'


# Generated at 2022-06-23 20:56:03.427505
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanized('ru')
    assert romanize('ru') is romanized('ru')

# Generated at 2022-06-23 20:56:05.292998
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'АБВ')() == 'ABB'



# Generated at 2022-06-23 20:56:14.187900
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import Person
    from mimesis.providers.beauty import Beauty

    def get_person():
        return Person('ru').name()

    def get_beauty_ru():
        return Beauty('ru').makeup_shade()

    def get_beauty_en():
        return Beauty('en').makeup_shade()

    assert get_person() == 'Павел Попов'
    assert get_beauty_ru() == 'Коричневый'
    assert get_beauty_en() == 'Brown'

    @romanize(locale=Language.RUSSIAN.value)
    def romanized_get_person():
        return Person('ru').name()

# Generated at 2022-06-23 20:56:19.038764
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.schema import Field
    from mimesis.enums import Languages

    field = Field('ru')
    alphabet = field.alphabet()

    assert alphabet.get_cyrillic_symbol() == '1'
    # assert len(alphabet.get_romanized_text(10)) > 0

# Generated at 2022-06-23 20:56:26.109210
# Unit test for function romanize
def test_romanize():
    test_string = u'Съешь ещё этих мягких французских булок'
    expected = 'Syesh eschyo etikh myagkikh frantsuzskikh bulok'
    assert romanize()(lambda: test_string)()== expected

# Generated at 2022-06-23 20:56:32.777456
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Sälem'
    # More tests are not needed because this functionality
    # works for any language, but for some reason, only
    # `uk` and `ru` are supported in tests.



# Generated at 2022-06-23 20:56:38.832973
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize()(lambda: 'Привет!') == 'Priviet!'
    assert romanize()(lambda: 'Привет!') == 'Priviet!'
    assert romanize()(lambda: 'Привет! Меня зовут Андрей!') \
        == 'Priviet! Menja zovut Andrej!'

# Generated at 2022-06-23 20:56:39.357698
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:56:45.542427
# Unit test for function romanize
def test_romanize():
    """Read the docs for this function."""
    assert romanize(locale='ru')(lambda: 'Стальной как закованный в сталь')() == 'Stalnoy kak zakovannyy v stal'


# Test romanized decorator

# Generated at 2022-06-23 20:56:47.169463
# Unit test for function romanize
def test_romanize():
    _str = 'Привет, как дела?'
    _romanized = romanize('ru')(lambda: _str)()
    assert _romanized == 'Privet, kak dela?'



# Generated at 2022-06-23 20:56:49.494114
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test(a):
        return a

    assert test('Привет') == 'Privet'

# Generated at 2022-06-23 20:56:52.319996
# Unit test for function romanize
def test_romanize():
    text = "Привет, как дела?"
    assert romanize()(lambda: text) == "Privet, kak dela?"

# Generated at 2022-06-23 20:56:54.904800
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'тест')().lower() == 'test'

# Generated at 2022-06-23 20:56:57.235756
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def func(value: str) -> str:
        return value

    assert func('Привет') == 'Privet'

# Generated at 2022-06-23 20:57:02.181592
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import SpecialChars
    from mimesis.builtins import Lorem
    l = Lorem('uk')
    result = l.sentence(special_chars=SpecialChars.ABSENT)
    result_romanized = l.sentence(special_chars=SpecialChars.ABSENT,
                                  romanized=True)
    assert result != result_romanized

# Generated at 2022-06-23 20:57:03.242373
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: '')('') == ''

# Generated at 2022-06-23 20:57:09.852285
# Unit test for function romanize
def test_romanize():
    assert romanized('kk')(lambda: 'Test')() == 'Test'
    assert romanized('ru')(lambda: 'Тест')() == 'Test'
    assert romanized('ru')(lambda: 'Тест с пунктуацией, да?')() == \
        'Test s punktuatsiei, da?'

# Generated at 2022-06-23 20:57:12.963879
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Садовое кольцо')() == 'Sadovoe koltso'

# Generated at 2022-06-23 20:57:15.499741
# Unit test for function romanize
def test_romanize():
    def foo():
        return "Я в Києві"

    foo_ = romanize('uk')(foo)
    assert "Ia v Kijevi" == foo_()



# Generated at 2022-06-23 20:57:18.972226
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет мир!')() == 'Privet mir!'



# Generated at 2022-06-23 20:57:20.034396
# Unit test for function romanize
def test_romanize():
    # TODO
    pass

# Generated at 2022-06-23 20:57:29.029317
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Москва')() == 'Moskva'
    assert romanize('ru')(lambda: 'Москва')(locale='ru') == 'Moskva'
    assert romanize('uk')(lambda: 'Москва')() == 'Moskva'
    assert romanize('uk')(lambda: 'Москва')(locale='uk') == 'Moskva'
    assert romanize('kk')(lambda: 'Москва')() == 'Moskwa'
    asser

# Generated at 2022-06-23 20:57:40.356884
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    roman_en = Text(Language.ENGLISH)
    roman_en.romanize(locale = 'en')
    print(roman_en.word())

    roman_ru = Text(Language.RUSSIAN)
    roman_ru.romanize(locale = 'ru')
    print(roman_ru.word())

    roman_uk = Text(Language.UKRAINIAN)
    roman_uk.romanize(locale = 'uk')
    print(roman_uk.word())

    roman_kk = Text(Language.KAZAKH)
    roman_kk.romanize(locale = 'kk')
    print(roman_kk.word())