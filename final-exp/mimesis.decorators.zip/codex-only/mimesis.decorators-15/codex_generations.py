

# Generated at 2022-06-23 20:47:44.027187
# Unit test for function romanize
def test_romanize():
    """Testing romanized."""
    @romanize(locale='ru')
    def get_text(length: int = 25) -> str:
        return 'Привет, Мир!'

    assert get_text(15) == 'Privet, Mir!'

# Generated at 2022-06-23 20:47:49.305878
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Красота')() == 'Krasota'
    assert romanize('uk')(lambda: 'Ковбученька')() == 'Kovbuchenka'
    assert romanize('kk')(lambda: 'Болашақ')() == 'Bolaşaq'

# Generated at 2022-06-23 20:47:51.585739
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_ru():
        return "Найнаболее ясным различием понятий права и собственности"

    assert (romanize_ru() ==
            "Nainablee yasnym razlichiem poniatii prava i sobstvennosti")

# Generated at 2022-06-23 20:47:55.340957
# Unit test for function romanize
def test_romanize():
    def func(locale: str = '') -> str:
        return data.ROMANIZATION_DICT.get(locale, {}).get('э', 'Not Found')

    decorated = romanize(locale='uk')(func)

    assert decorated('uk') == 'e'

# Generated at 2022-06-23 20:47:57.446725
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Кириллица')() == 'Kirillitsa'

# Generated at 2022-06-23 20:48:06.303427
# Unit test for function romanize
def test_romanize():
    """Tests for romanize."""

    @romanize(locale='ru')
    def russian_word():
        return 'Объектно-ориентированное'

    assert russian_word() == 'Obʺektno-orientirovannoe'

    @romanize(locale='uk')
    def ukrainian_word():
        return 'Антиромантик'

    assert ukrainian_word() == 'Antyromantyk'

    @romanize(locale='kk')
    def kazakh_word():
        return 'Тұқымдық'

    assert kazakh_word() == 'Tuqımdıq'



# Generated at 2022-06-23 20:48:15.542131
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, Мир') == 'Privet, Mir'
    assert romanize()('Привіт, Світ') == 'Pryvit, Svit'
    assert romanize()('Прывітанне, Свет') == 'Pryvitanne, Svet'
    assert romanize(locale='ru')('Добры вечар') == 'Dobri vecher'
    assert romanize(locale='uk')('Добрий вечір') == 'Dobriy vecher'

# Generated at 2022-06-23 20:48:16.176756
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:48:23.239178
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import (
        RussianSpecProvider,
        UkrainianSpecProvider,
        KazakhSpecProvider,
    )

    providers = (
        RussianSpecProvider,
        UkrainianSpecProvider,
        KazakhSpecProvider,
    )

    for provider in providers:
        gen = provider()
        lang = gen.data['code']
        assert gen.romanize_cyrillic(gen.name()) == gen.name(lang)
        assert gen.romanize_cyrillic(gen.surname()) == gen.surname(lang)
        assert gen.romanize_cyrillic(gen.patronymic()) == gen.patronymic(lang)

# Generated at 2022-06-23 20:48:28.455905
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    p = Person('en')
    r = p.full_name()
    assert len(r) != len(p.full_name())
    assert len(r) != len(p.full_name(romanized=True))

    p_ru = Person('ru')
    assert p_ru.full_name(romanized='ru') != p_ru.full_name()

    p_ru = Person('ru')
    name = p_ru.name()
    assert name != p_ru.name(romanized='ru')
    assert len(p_ru.name(romanized='ru')) == \
        len(p_ru.name(romanized='ru').encode())


# Generated at 2022-06-23 20:48:32.244327
# Unit test for function romanize
def test_romanize():
    assert romanized('ru') is not None
    assert romanized('uk') is not None
    assert romanized('kk') is not None

    try:
        romanized('invalid')
    except UnsupportedLocale:
        pass



# Generated at 2022-06-23 20:48:32.863536
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:48:39.344342
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    from mimesis.enums import Locale
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    person = Person(Locale.RU)
    address = Address(Locale.RU)

    # Function romanize
    romanized_person = romanize(Locale.RU)(person.full_name)
    romanized_address = romanize(Locale.RU)(address.address)

    assert romanized_person == 'Vasiliy Petrov'
    assert romanized_address == ('г. Москва,' +
                                 ' ул. Дроздовская, д. 5')



# Generated at 2022-06-23 20:48:44.076703
# Unit test for function romanize
def test_romanize():
    romanize_locale = romanize('ru')

    @romanize_locale
    def romanize_text(text):
        return text

    assert romanize_text("Привет") == "Privet"
    assert romanize_text("При`вет, приветули!") == "Pri`vet, privetuli!"

# Generated at 2022-06-23 20:48:46.729078
# Unit test for function romanize
def test_romanize():
    @romanize()
    def hello_world(name):
        return f'Привет, {name}!'

    assert hello_world('Иван') == 'Privet, Ivan!'

# Generated at 2022-06-23 20:48:54.590400
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    rs = RussianSpecProvider('ru')

    assert rs.romanize(rs.full_name()) == 'Konstantin Pavlovich Chayka'
    assert rs.romanize('Борис Николаевич Ельцин') == 'Boris Nikolaevich Eltsin'
    assert rs.romanize('Игорь Владимирович Ильин') == 'Igor Vladimirovich Iljin'

# Generated at 2022-06-23 20:48:56.709281
# Unit test for function romanize
def test_romanize():
    assert romanized()('русский') == 'russkii'


# Generated at 2022-06-23 20:49:01.786952
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    assert romanize(locale='ru')(lambda: 'Александр')().strip() == 'Aleksandr'
    assert romanize(locale='uk')(lambda: 'Александр')().strip() == 'Oleksandr'
    assert romanize(locale='kk')(lambda: 'Александр')().strip() == 'Aleksandr'

# Generated at 2022-06-23 20:49:06.190295
# Unit test for function romanize
def test_romanize():
    cyrillic_word = 'Тестовый текст'
    latin_word = romanize(locale='ru')(lambda: cyrillic_word)
    
    assert latin_word == 'Testovyi tekst'

# Generated at 2022-06-23 20:49:14.678624
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.locale.ukrainian import UkrainianSpecProvider
    ukr = UkrainianSpecProvider()

    text = ukr.cyrillic_text()
    assert romanized('uk')(ukr.cyrillic_text)(10) == 'Гевальдабарска'
    assert romanized('uk')(ukr.cyrillic_text)(15) == 'Абвгдеєжзиіїйклмнопрстуфхцчшщьюя'

# Generated at 2022-06-23 20:49:15.618141
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)

# Generated at 2022-06-23 20:49:17.138626
# Unit test for function romanize
def test_romanize():
    @romanized()
    def romanizer(value):
        return value
    assert romanizer('привет') == 'privet'

# Generated at 2022-06-23 20:49:18.124389
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:49:21.631323
# Unit test for function romanize
def test_romanize():
    def foo():
        return 'абв123 абв123'

    foo_r = romanize('ru')(foo)
    assert foo_r() == 'abv123 abv123'



# Generated at 2022-06-23 20:49:23.582825
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis import Person
    person = Person('ru')
    assert person.name()

# Generated at 2022-06-23 20:49:28.250811
# Unit test for function romanize
def test_romanize():
    text = 'Привет'

    assert romanize('ru')(lambda: text) == 'Privet'
    assert romanize('uk')(lambda: text) == 'Pryvit'
    assert romanize('kk')(lambda: text) == 'Pryvit'

    with UnsupportedLocale:
        assert romanize('de')(lambda: text) == 'Pryvit'

# Generated at 2022-06-23 20:49:36.004524
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.enums import Language

    from .functional import RomanizedSpecification

    spec = RomanizedSpecification(language=Language.EN, pattern='a')

    # Check the decorations
    assert spec.supplemental.pattern == 'a'
    assert spec.supplemental.pattern == spec.pattern
    assert spec.supplemental.pattern == spec.pattern_for_test

    # Check the romanization
    assert spec.test_romanize('привет') == 'privet'

    # Check the romanization in an unsupported locale
    with pytest.raises(UnsupportedLocale):
        spec.test_romanize('привет', 'af')

# Generated at 2022-06-23 20:49:43.187117
# Unit test for function romanize
def test_romanize():
    char_list, txt_list = 'абвгд', 'abvgд'

    @romanize(locale='ru')
    def romanize_func(cl):
        return cl

    assert romanize_func(char_list) == txt_list

    @romanize(locale='en')
    def romanize_func(cl):
        return cl

    assert romanize_func(char_list) == char_list

# Generated at 2022-06-23 20:49:47.335298
# Unit test for function romanize
def test_romanize():
    @romanized(locale='ru')
    def romanize_function(x):
        return x

    assert romanize_function('Привет!') == 'Priviet!'
    assert romanize_function('Привет, мир!') == 'Priviet, mir!'
    assert romanize_function('Hello, world!') == 'Hello, world!'

# Generated at 2022-06-23 20:49:48.082427
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-23 20:49:56.709627
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import CyrillicSpecProvider

    text = CyrillicSpecProvider().text
    romanized = text._romanized
    assert 'Привет' in text.text(locale='ru')
    assert 'Privet' in text.text(locale='ru')

    assert 'Привет' in romanized.text(locale='ru')
    assert 'Privet' in romanized.text(locale='ru')

# Generated at 2022-06-23 20:50:05.303051
# Unit test for function romanize
def test_romanize():
    import mimesis.enums
    import mimesis.builtins

    class CustomText(mimesis.builtins.Text):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.data = data

        @romanize('ru')
        def romanized_ru(self):
            return self._fake.word()

        @romanize('uk')
        def romanized_uk(self):
            return self._fake.word()

        @romanize('kk')
        def romanized_kk(self):
            return self._fake.word()

    r = CustomText(mimesis.enums.Language.RUSSIAN)
    assert r.romanized_ru() != r.romanized_uk() != r.romanized_kk

# Generated at 2022-06-23 20:50:11.823707
# Unit test for function romanize
def test_romanize():
    assert run_romanize_test(romanize('ru'), 'Привет, мир!') == 'Privet, mir!'
    assert run_romanize_test(romanize('uk'), 'Привіт, світ!') == 'Pryvit, svit!'
    assert run_romanize_test(romanize('kk'), 'Сәлем, дүние!') == 'Sälem, dünie!'



# Generated at 2022-06-23 20:50:13.790436
# Unit test for function romanize
def test_romanize():
    def f():
        pass

    assert romanized(locale='ru')(f)('текст') == 'tekst'

# Generated at 2022-06-23 20:50:15.937272
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test():
        return 'Привет, Мир!'
    assert test() == 'Privet, Mir!'

# Generated at 2022-06-23 20:50:17.607258
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo() -> str:
        return 'тест'

    assert foo() == 'test'

# Generated at 2022-06-23 20:50:20.695329
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_result():
        return 'Функция работает'

    assert get_result() == 'Funktsiya rabotaet'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:50:23.355068
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import TextSpecifier
    text = TextSpecifier('en')
    assert text.romanized(locale='ru') == text.romanized('ru')

# Generated at 2022-06-23 20:50:26.554151
# Unit test for function romanize
def test_romanize():
    @romanize(locale='uk')
    def romanized_f():
        from mimesis.builtins.text import Text
        text = Text('uk')
        return text.word()

    assert romanized_f()

# Generated at 2022-06-23 20:50:31.990035
# Unit test for function romanize
def test_romanize():
    """Tests for romanize"""
    assert romanized(locale='ru')(lambda: 'тест') == 'test'
    assert romanize(locale='uk')(lambda: 'тест') == 'test'
    assert romanize(locale='kk')(lambda: 'тест') == 'test'

# Generated at 2022-06-23 20:50:36.466109
# Unit test for function romanize
def test_romanize():
    # Sample function
    @romanize(locale='ru')
    def romanize_deco(text):
        return text

    res = romanize_deco('Привет')
    assert res == 'Privet'

# Generated at 2022-06-23 20:50:46.047854
# Unit test for function romanize

# Generated at 2022-06-23 20:50:50.391040
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('ru')
    assert len(p.name(gender=Gender.MALE)) > 0

    en = Person()
    assert len(en.name(gender=Gender.MALE)) > 0

    with pytest.raises(UnsupportedLocale):
        Person('xx')

# Generated at 2022-06-23 20:50:52.514539
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет Мир!')() == 'Privet Mir!'

# Generated at 2022-06-23 20:50:56.273126
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def f():
        return 'Модуль генерации данных'

    assert f() == 'Modul` generaczii danny`kh'



# Generated at 2022-06-23 20:50:58.916158
# Unit test for function romanize
def test_romanize():
    result = romanize('uk')(lambda: 'Мінфін')()
    assert result == 'Minfin'

# Generated at 2022-06-23 20:51:09.358068
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    # Examples from Wikipedia
    # https://ru.wikipedia.org/wiki/%D0%A0%D1%83%D1%81%D1%81%D0%BA%D0%B0%D1%8F_%D1%82%D1%80%D0%B0%D0%BD%D1%81%D0%BB%D0%B8%D1%82%D0%B5%D1%80%D0%B0%D1%86%D0%B8%D1%8F_%D0%B2_%D0%BB%D0%B0%D1%82%D0%B8%D0%BD%D0%B8%D1%86%D1%83

    t

# Generated at 2022-06-23 20:51:11.026189
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Доброе утро')().isalpha()



# Generated at 2022-06-23 20:51:12.407871
# Unit test for function romanize
def test_romanize():
    # TODO: Write unit tests for romanize
    pass

# Generated at 2022-06-23 20:51:19.895943
# Unit test for function romanize
def test_romanize():
    @romanize(locale='uk')
    def uk_func(data):
        return data

    assert uk_func('Привіт тебе, друже!') == 'Pryvit tebe, druzhe!'

    @romanize(locale='ru')
    def ru_func(data):
        return data

    assert ru_func('Привет тебе, друг!') == 'Privet tebe, drug!'

# Generated at 2022-06-23 20:51:22.761513
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""

    @romanize('ru')
    def test(string='тест'):
        """."""
        return string

    assert test() == 'test'

# Generated at 2022-06-23 20:51:27.064170
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_string():
        return 'Светлана'

    txt = get_string()
    assert txt == 'Svetlana'

# Generated at 2022-06-23 20:51:36.094154
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    import string
    import random
    import pytest
    from mimesis.extra.transliteration import romanize

    @romanize(locale='ru')
    def romanizer(txt):
        return txt

    def _get_string():
        return ''.join(
            random.choice(string.ascii_letters)
            for _ in range(5)
        )

    @pytest.mark.parametrize('locale', ('ru', 'uk', 'kk'))
    def test_romanizer(locale):
        txt = _get_string()
        assert len(txt) == 5
        assert isinstance(romanizer(locale=locale, txt=txt), str)

    test_romanizer()

# Generated at 2022-06-23 20:51:37.254159
# Unit test for function romanize
def test_romanize():
    assert romanize.__name__ == 'romanize'



# Generated at 2022-06-23 20:51:45.357828
# Unit test for function romanize
def test_romanize():
    # Test function romanize same
    assert romanized(locale='ru')(lambda: 'Правильно')() == 'Pravilno'
    assert romanize(locale='uk')(lambda: 'Правильно')() == 'Pravylno'
    assert romanize(locale='kk')(lambda: 'Правильно')() == 'Pravilno'

# Generated at 2022-06-23 20:51:47.754959
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian(self):
        return 'Лагода'

    assert russian() == 'Lagoda'



# Generated at 2022-06-23 20:51:48.668428
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    pass

# Generated at 2022-06-23 20:51:50.746403
# Unit test for function romanize
def test_romanize():
    @romanize
    def test_func():
        return 'Київ'

    assert test_func() == 'Kiyiv'



# Generated at 2022-06-23 20:51:53.870712
# Unit test for function romanize
def test_romanize():
  assert romanized('ru')('Привет, друг!')('ru') == 'Privet, drug!'



# Generated at 2022-06-23 20:51:58.728680
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'фыва')(), 'fiva'
    assert romanize(locale='uk')(lambda: 'привіт')(), 'pryvit'
    assert romanize(locale='kk')(lambda: 'бүтен')(), 'buten'

# Generated at 2022-06-23 20:52:00.590626
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    assert romanize()

# Generated at 2022-06-23 20:52:08.048719
# Unit test for function romanize
def test_romanize():
    """Testing romanize decorator."""
    import random
    import string


# Generated at 2022-06-23 20:52:11.411181
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Привет, мир')() == 'Privet, mir'

# Generated at 2022-06-23 20:52:16.740099
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda: 'Привіт') == 'Privit'
    assert romanize('ru')(lambda: 'Привет') == 'Privet'
    assert romanize('kk')(lambda: 'Сәлем') == 'Sälem'



# Generated at 2022-06-23 20:52:24.735162
# Unit test for function romanize
def test_romanize():
    def romanize_test(text, locale):
        return text.romanize(locale)

    assert romanize_test('Привет мир!', 'ru') == 'Privet mir!'
    assert romanize_test('Привіт світ!', 'uk') == 'Pryvit svit'
    assert romanize_test('Сәлем үлкен дүние!', 'kk') == 'Sálem úlken dúnie'

# Generated at 2022-06-23 20:52:34.042595
# Unit test for function romanize
def test_romanize():
    assert 'lyublyu' == romanize(locale='ru')(lambda: 'люблю')
    assert 'lovelyublyu' == romanize(locale='ru')(lambda: 'loveлюблю')
    assert 'mi' == romanize(locale='ru')(lambda: 'ми')
    assert 'silver' == romanize(locale='ru')(lambda: 'сильвер')

# Generated at 2022-06-23 20:52:43.186410
# Unit test for function romanize
def test_romanize():
    import re
    import mimesis.localization.en

    class Test:
        @mimesis.romanize(locale='ru')
        def russian_text(self):
            return 'Привет, Мир!'

        @mimesis.romanized(locale='uk')
        def ukrainian_text(self):
            return 'Привіт, Світ!'

        @mimesis.romanize(locale='kk')
        def kazakh_text(self):
            return 'Сәлем, Әуе!'

    test = Test()
    russian_correct = 'Privet, Mir!'
    ukrainian_correct = 'Pryvit, Svit!'

# Generated at 2022-06-23 20:52:45.491271
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: '123АБВ')() == '123ABV'

# Generated at 2022-06-23 20:52:51.401102
# Unit test for function romanize
def test_romanize():
    fake = Fake('ru')

    txt = fake.text(length=20, spaces=False)
    assert txt is not None

    # It is guaranteed that romanize works
    romanized_txt = fake.romanized.text(length=20, spaces=False)
    assert romanized_txt is not None
    assert txt != romanized_txt



# Generated at 2022-06-23 20:52:53.741351
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_test():
        return 'Привет Мир!'

    assert romanize_test() == 'Privet Mir!'

# Generated at 2022-06-23 20:52:58.691101
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    test_locale = Locale.ENGLISH

    @romanize(locale=test_locale)
    def test_func(test_locale):
        p = Person(test_locale)
        return p.full_name()

    result = test_func(test_locale)

    assert isinstance(result, str)
    assert result is not ''

# Generated at 2022-06-23 20:53:00.480847
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_name():
        return 'Константин'

    assert get_name() == 'Konstantin'



# Generated at 2022-06-23 20:53:06.772425
# Unit test for function romanize
def test_romanize():
    """Test the function romanize."""
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    p = Person(locale=Locale.RU)
    assert 'Михаил' in p.full_name()
    assert 'Mikhail' in romanized(locale='ru')(p.full_name)()



# Generated at 2022-06-23 20:53:11.504944
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    import mimesis

    rus = Person('ru')
    ukr = Person('uk')
    kas = Person('kk')

    assert rus.full_name != rus.full_name_romanized
    assert ukr.full_name != ukr.full_name_romanized
    assert kas.full_name != kas.full_name_romanized

# Generated at 2022-06-23 20:53:19.343158
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from collections import defaultdict
    from typing import DefaultDict

    class FakeEnum:
        """Fake enum for unit tests."""

        def __init__(self, locale: str) -> None:
            super().__init__()
            self._locale = locale

    f = FakeEnum(Locale.RU)

    @romanize()
    def func(self, text: str) -> str:
        return text

    result = func(f, 'Это фейковый текст.')
    assert result == 'Eto feikovyi tekst.'

    @romanize(locale=Locale.RU)
    def func(self, text: str) -> str:
        return text


# Generated at 2022-06-23 20:53:24.117110
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""

    def test_func():
        return 'Привет, мир!'

    test_func = romanize('ru')(test_func)

    assert test_func() == 'Privet, mir!'

# Generated at 2022-06-23 20:53:29.566693
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def rus_string():
        return 'Привет! Мир! Как твои дела?'

    assert rus_string() == 'Privet! Mir! Kak tvoi dela?'

# Generated at 2022-06-23 20:53:31.298763
# Unit test for function romanize
def test_romanize():
    assert romanize()("Привет") == "Privet"
    assert romanize("ru")("Привет") == "Privet"

# Generated at 2022-06-23 20:53:41.169952
# Unit test for function romanize
def test_romanize():

    def rus(n: int) -> str:
        return ''.join(data.Language('ru').random_data.get_words(quantity=n))

    assert rus(1) == 'приложение'
    assert rus(2) == 'нетемпературныйпитание'
    assert rus(3) == 'контрапунктурныйсапог'

    def ru_r(n: int) -> str:
        return ''.join(data.Language('ru').random_data.get_words(quantity=n, romanize=True))

    assert ru_r(1) == 'prikljuchenie'
    assert ru

# Generated at 2022-06-23 20:53:47.556106
# Unit test for function romanize
def test_romanize():
    '''
    Test function for romanize decorator.
    '''
    @romanize(locale='ru')
    def russian_text():
        '''Generate russian text.'''
        return 'Дорога дошла до дома.'

    result = russian_text()
    assert result == 'Doroga dosla do doma.'

# Generated at 2022-06-23 20:53:57.874646
# Unit test for function romanize
def test_romanize():
    def test_func(locale: str = '') -> str:
        return 'Привет, как дела?'

    result = romanize(locale='ru')(test_func)
    assert result('ru') == 'Privet, kak dela?'

    result = romanize(locale='kk')(test_func)
    assert result('kk') == 'Pryviet, kak dela?'

    result = romanize(locale='uk')(test_func)
    assert result('uk') == 'Pryvit, jak dela?'

    def test_func_with_js_style() -> str:
        return 'Привет как дела?'


# Generated at 2022-06-23 20:54:03.769711
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_text():
        return 'Хэш-тэги на русском и английском'

    assert get_text() == 'Xeš-tègi na russkom i anglijskom'

# Generated at 2022-06-23 20:54:05.250467
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет мир!')() == 'Privet mir!'

# Generated at 2022-06-23 20:54:07.997476
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, мир!') == 'Privet, mir!'



# Generated at 2022-06-23 20:54:18.475807
# Unit test for function romanize
def test_romanize():
    # romanize(locale='')
    @romanize()
    def romanize_test():
        return 'романизация'
    assert romanize_test() == 'romanizatsiya'

    @romanize()
    def romanize_test():
        return 'РОМАНИЗАЦИЯ'
    assert romanize_test() == 'ROMANIZATSIYA'

    @romanize(locale='ru')
    def romanize_test():
        return 'романизация'
    assert romanize_test() == 'romanizatsiya'


# Generated at 2022-06-23 20:54:24.112360
# Unit test for function romanize
def test_romanize():
    """Test for function Romanize."""
    from mimesis.builtins import Text

    test_text = Text(locale='ru')

    assert test_text.romanize() == 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~ '  # noqa: E501



# Generated at 2022-06-23 20:54:28.953903
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    func = romanize('ru')(lambda: 'Привет, Мир!')
    value = func()
    assert value == 'Privet, Mir!'

# Generated at 2022-06-23 20:54:36.338502
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    known = 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'
    assert known == romanized('ru')(known)

    known = 'Абвгґдєїґеёжзиійклмнопрстуфхцчшщъыьэюя'
    assert known == romanized('uk')(known)


# Generated at 2022-06-23 20:54:39.507958
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import Person

    p = Person(Language.ENGLISH)

    assert romanize('ru')(p.full_name) == p.full_name



# Generated at 2022-06-23 20:54:50.408981
# Unit test for function romanize
def test_romanize():
    romanized_ua = romanize('ua')(lambda: 'Привіт')()
    assert romanized_ua == 'Pryvit'
    romanized_ru = romanize('ru')(lambda: 'Привет')()
    assert romanized_ru == 'Privet'
    romanized_kk = romanize('kk')(lambda: 'Сәлем')()
    assert romanized_kk == 'Salem'
    romanized_kk_with_digits = romanize('kk')(lambda: 'Сәлем қалайсың? 1, 1510')()

# Generated at 2022-06-23 20:54:57.260154
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Тест')() == 'Test'
    assert romanize('ru')(lambda: 'тест')() == 'test'
    assert romanize('ru')(lambda: 'ТЕСТ')() == 'TEST'
    assert romanize('ru')(lambda: 'ТЕСТ.ТЕСТ')() == 'TEST.TEST'



# Generated at 2022-06-23 20:55:02.878759
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    import random
    import string

    @romanize(locale='ru')
    def test():
        data = string.ascii_letters + string.digits + "АБВГДЕЗИЛМНОПРСТУХФЪЫЬ"
        return ''.join(random.choice(data) for i in range(100))

    test()

# Generated at 2022-06-23 20:55:08.725500
# Unit test for function romanize
def test_romanize():
    """Test for romanize in decorator."""
    @romanize(locale='ru')
    def f():
        return 'Привет, Друг.'

    assert f() == 'Privet, Drug.'

    @romanized(locale='uk')
    def g():
        return 'Привіт, Друге.'

    assert g() == 'Pryvit, Druhe.'

# Generated at 2022-06-23 20:55:12.051460
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian(cls):
        return 'по-русски пьяному - нарочно'

    assert russian('random') == 'po-russki pʼyanyomu - naroch-nyo'

# Generated at 2022-06-23 20:55:13.854788
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('Александр') == 'Aleksandr'

# Generated at 2022-06-23 20:55:18.861988
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    from unittest import TestCase

    p = Person('en')
    name = p.full_name()
    t = p.romanized(name)
    assert isinstance(t, str)
    assert len(t) >= 1

    with TestCase.assertRaises(UnsupportedLocale):
        p.romanized(name, 'yo')

# Generated at 2022-06-23 20:55:25.400156
# Unit test for function romanize
def test_romanize():
    def get_romanized_string(text: str = '') -> str:
        """Romanize russian string."""
        return text.lower()

    r = get_romanized_string.__name__
    assert r == 'get_romanized_string'

    r = get_romanized_string.__annotations__
    assert r == {'return': str, 'text': str}

    r = get_romanized_string()
    assert r == ''

    get_romanized_string = romanize()(get_romanized_string)
    r = get_romanized_string()
    assert r == ''

    r = get_romanized_string('Привет, Мир!')
    assert r == 'privet, mir!'


# Generated at 2022-06-23 20:55:28.256260
# Unit test for function romanize
def test_romanize():
    from mimesis.text import Text

    t = Text('ru')
    for i in range(1000):
        a = t._tokenize(t.paragraph())
        b = t.romanized(a)
        assert len(a) == len(b)

# Generated at 2022-06-23 20:55:31.336237
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')('Привіт Світ') == 'Pryvit Svit'

# Generated at 2022-06-23 20:55:35.803881
# Unit test for function romanize
def test_romanize():
    from mimesis.datasets import RU
    from mimesis.providers import Address as AddressRU
    # even though the whole Address provider is marked as romanized
    # it is declared with two separate instances (UK and RU)
    # and the romanize decorator is applied only to RU.
    # The following test ensures that the romanize decorator works properly
    # for AddressRU.
    tr = AddressRU(ru=RU)
    assert tr.city() != tr.city(romanized=True)

# Generated at 2022-06-23 20:55:39.803170
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def bank_account():
        return 'Это тестовый русский текст.'

    assert bank_account() == 'Eto testoviy russkiy text.'

# Generated at 2022-06-23 20:55:42.764447
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, Мир!'.upper()) == \
        'Privet, Mir!'

# Generated at 2022-06-23 20:55:49.342961
# Unit test for function romanize
def test_romanize():
    # Simple test for romanize
    @romanize('ru')
    def rus():
        return 'Сделайте из этого весёлый аттракцион'

    assert rus() == 'Sdelajte iz etogo vesjolyj attrakcion'
    assert rus() != 'Sdelajte iz etogo vesjolyj attrakcion '



# Generated at 2022-06-23 20:55:53.019994
# Unit test for function romanize
def test_romanize():
    assert (romanize('ru')('Как дела?')) == 'Kak dela?'
    assert (romanized('ru')('Как дела?')) == 'Kak dela?'


test_romanize()

# Generated at 2022-06-23 20:55:56.253680
# Unit test for function romanize
def test_romanize():
    """Test for romanization."""
    romanized_text = romanize(locale='ru')(lambda: 'Привет, мир!')
    assert romanized_text() == 'Privet, mir!'

# Generated at 2022-06-23 20:56:02.551140
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'фывапролджэыюяё')() == 'fyvaproldzheyuyaе'
    assert romanize('uk')(lambda: 'фывапролджэыюяё')() == 'fyvaproldzheyuyaё'
    assert romanize('kk')(lambda: 'фывапролджэыюяё')() == 'фывапролджэыюяё'

# Generated at 2022-06-23 20:56:04.707324
# Unit test for function romanize
def test_romanize():
    """Test romanizing the string."""
    assert romanize('it')(str) == 'storia'



# Generated at 2022-06-23 20:56:08.565445
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    @romanize('ru')
    def roman_func():
        return 'Электронная почта'

    assert 'E-Mail' == roman_func()



# Generated at 2022-06-23 20:56:09.830955
# Unit test for function romanize
def test_romanize():
    pass

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:56:20.075449
# Unit test for function romanize
def test_romanize():
    def foo(text):
        return text

    @romanize('ru')
    def bar(text):
        return text

    assert bar('123') == '123'
    assert bar('Класс компонента') == 'Klass komponenta'
    assert foo('Класс компонента') == 'Класс компонента'
    assert romanize('ru')(foo)('Класс компонента') == 'Klass komponenta'
    assert bar('Класс компонента') == 'Klass komponenta'

# Generated at 2022-06-23 20:56:27.405141
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    romanized_func = romanize(locale='ru')
    romanized_func('Не скажет ли ты мне напоследок одно слово?') == 'Ne skazhet li ty mne napolisok odno slovo?'

# Generated at 2022-06-23 20:56:29.856249
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.text import Text
    text = Text('ru')
    assert romanized('ru')(text.word)() == \
           text.romanized_word()

# Generated at 2022-06-23 20:56:33.974153
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo(bar: str = '') -> str:
        return bar


    assert foo(bar='тест') == 'test'

# Generated at 2022-06-23 20:56:42.459211
# Unit test for function romanize
def test_romanize():
    assert romanized()('Королевству морских пещер') == 'Korolevstvu morskikh pescher'

    assert romanize('uk')('Королевству морских пещер') == 'Korolevstvu morskikh pescher'

    assert romanize('kk')('Құрманғазы аумағы құйгасы сапарларын') == 'Qurmanğazy awmağı quığası saparların'


# Generated at 2022-06-23 20:56:53.279214
# Unit test for function romanize
def test_romanize():
    def my_func(x):
        return x


    assert my_func.__name__ == 'my_func'

    @romanized('ru')
    def my_romanized_func(x):
        return x


    assert my_romanized_func.__name__ == 'my_romanized_func'

    @romanized('ru')
    def як_де_ви_маєтеся_панове():
        return 'Як де ви, маєтеся, панове?'


    assert як_де_ви_маєтеся_панове() == 'Yak de vi, mayetiesa, panove?'



# Generated at 2022-06-23 20:56:57.148231
# Unit test for function romanize
def test_romanize():
    """Testing function romanize."""
    r = romanize('ru')

    def random_char(locale='ru'):
        return r(lambda: data.uniform(locale, 'char'))()

    assert random_char() in ascii_letters + digits + punctuation

# Generated at 2022-06-23 20:56:59.128617
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')().upper() == 'PRIVET'

# Generated at 2022-06-23 20:57:05.806943
# Unit test for function romanize
def test_romanize():
    import pytest

    @romanize()
    def test_f():
        return 'Test'

    @romanize()
    def test_f_1():
        return 'Тест'

    @romanize()
    def test_f_2():
        return 'Тест'

    @romanize()
    def test_f_3():
        return 'Тест'

    @romanize()
    def test_f_4():
        return 'Тест'


    assert 'Test' == test_f()
    assert 'Test' == test_f_1()
    assert 'Test' == test_f_2()
    assert 'Test' == test_f_3()
    assert 'Test' == test_f_4()


# Generated at 2022-06-23 20:57:16.734582
# Unit test for function romanize
def test_romanize():

    @romanize('ru')
    def romanize_text(text: str) -> str:
        return text

    assert romanize_text('русский') == 'russkij'
    assert romanize_text('йцукен') == 'jtsuken'

    @romanized('uk')
    def romanize_text(text: str) -> str:
        return text

    assert romanize_text('руський') == 'ruskyj'
    assert romanize_text('йцукен') == 'jtsuken'

    @romanize('kk')
    def romanize_text(text: str) -> str:
        return text


# Generated at 2022-06-23 20:57:27.474752
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Планета Земля')() == 'Planet Zemlya'
    assert romanize('uk')(lambda x: 'Земля Земля')() == 'Zemlya'
    assert romanize('kk')(lambda x: 'Құлқан құлқан')() == 'Kulkan'
    assert romanize('uk')(lambda x: 'Россiя')() == 'Rossiya'
    assert romanize('kk')(lambda x: 'абырвалг')() == 'abyrvalg'

# Generated at 2022-06-23 20:57:29.029029
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Пример')() == 'Primer'

# Generated at 2022-06-23 20:57:32.735891
# Unit test for function romanize
def test_romanize():
    """Test romanize()."""
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    expected = 'My name is Bobby and my age is 43.'
    text = Text(Locale.ENGLISH)

    @romanize()
    def func():
        return text.sentence(end_count=5)

    assert func() == expected

# Generated at 2022-06-23 20:57:37.573447
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    simple_func = romanize('ru')

    # Decorate func
    @simple_func
    def test(user_input):
        return user_input

    assert test('тест') == 'test'



# Generated at 2022-06-23 20:57:40.137788
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""

    @romanize
    def get_name():
        return 'Небо'

    assert get_name() == 'Nebo'

# Generated at 2022-06-23 20:57:44.199639
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    txt = 'Тестирование работы romanize'
    txt = romanize('ru')(txt)
    assert txt == 'Testirovanie raboty romanize'