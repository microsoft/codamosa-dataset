

# Generated at 2022-06-23 20:47:47.668762
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'привет мир')() == 'privet mir'
    assert romanized()(lambda: 'яблоко')() == 'yabloko'
    assert romanized()(lambda: 'йцукен')() == 'ycuken'

# Generated at 2022-06-23 20:47:57.804854
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    @romanize()
    def romanize_test():
        return 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890!@#$%^&*()'

    @romanize('ru')
    def russian_romanize():
        return 'йцукенгшщзхъфывапролджэячсмитьбюё'


# Generated at 2022-06-23 20:48:00.119461
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'


# Generated at 2022-06-23 20:48:00.607140
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:48:03.899672
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def get_cyrillic():
        return 'Привет, Мир!'

    assert get_cyrillic() == 'Privet, Mir!'

# Generated at 2022-06-23 20:48:13.657426
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian_string(pattern):
        return 'Абракадабра фыдвалскоп корректор цифровой ОС процессор'

    @romanize('uk')
    def ukrainian_string(pattern):
        return 'Абракадабра фыдвалскоп корректор цифровой ОС процессор'


# Generated at 2022-06-23 20:48:17.525454
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def data():
        return 'Что? Где? Когда?'
    assert data() == 'Chto? Gde? Kogda?'



# Generated at 2022-06-23 20:48:20.995817
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.transliteration import Transliteration
    t = Transliteration(locale='ru')
    assert t.get_letter() == 'a'

    def test_func():
        return 'Хрен'

    t_func = romanize('ru')(test_func)
    assert t_func() == 'hren'

# Generated at 2022-06-23 20:48:24.386066
# Unit test for function romanize
def test_romanize():
    def dummy_func():
        pass

    result = romanize()(dummy_func)

    assert isinstance(result, Callable)
    assert result.__name__ == 'dummy_func'

# Generated at 2022-06-23 20:48:27.224112
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_func():
        return 'Привет мир!'

    assert test_func() == 'Privet mir!'



# Generated at 2022-06-23 20:48:30.794167
# Unit test for function romanize
def test_romanize():
    assert romanize('locale')(lambda x: 'тест')('data') == 'test'
    assert romanized()(lambda x: 'тест')('data') == 'test'

# Generated at 2022-06-23 20:48:34.941651
# Unit test for function romanize
def test_romanize():
    locale = 'ru'

    @romanize(locale)
    def romanize_dummy(text: str) -> str:
        return text

    assert romanize_dummy('Привет мир') == 'Privet mir'

# Generated at 2022-06-23 20:48:39.814256
# Unit test for function romanize
def test_romanize():
    @romanize('uk')
    def get_text():
        return 'Текст на українській мові'

    original = get_text()
    desired = 'Tekst na ukrayinsʹkij movi'
    assert original == desired

# Generated at 2022-06-23 20:48:41.353814
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize()
    assert romanized()

# Generated at 2022-06-23 20:48:46.944219
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    from mimesis.enums import Gender

    p = Person('ru', seed=42)
    person = p.create(gender=Gender.MALE)
    capital_person = p.create(gender=Gender.MALE, capitalized=True)

    assert romanize('ru')(person) == romanized('ru')(person)
    assert romanize('ru')(capital_person) == romanized('ru')(capital_person)

# Generated at 2022-06-23 20:48:57.138143
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    r = RussianSpecProvider()

    assert r.romanize('Съешь ещё этих мягких французских булок да выпей чаю.') == 'S' \
                                                                                  'esh eshchyo etikh myagkikh frantsuzskikh bulok da vypey chayu.'
    assert r.romanize('Министр') == 'Ministr'
    assert r.romanize('Власть') == 'Vlast'

# Generated at 2022-06-23 20:49:02.396401
# Unit test for function romanize
def test_romanize():
    class A:
        locale = 'ru'

        @romanize(locale)
        def foo(self):
            return 'Привет!'

    assert A().foo() == 'Privet!'
    assert A.foo.__name__ == 'foo'

    class B:
        @romanized()
        def bar(self):
            return 'Привет!'

    assert B().bar() == 'Privet!'
    assert B().bar.__name__ == 'bar'

# Generated at 2022-06-23 20:49:07.601215
# Unit test for function romanize
def test_romanize():
    r = romanize()(lambda: 'Сто копеек получили из них у Татьяны')
    assert r == 'Sto kopeek poluchili iz nikh u Tatʹyany'

# Generated at 2022-06-23 20:49:13.738290
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    from mimesis.enums import Language
    from mimesis.providers.lorem import Lorem

    lorem = Lorem()

    @romanize(Language.RU)
    def romanized_text():
        """Return romanized text."""
        return lorem.text()

    assert romanized_text() is not None
    assert isinstance(romanized_text(), str)



# Generated at 2022-06-23 20:49:16.571899
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    methods = [
        'get_russian_first_name',
        'get_russian_last_name',
    ]

    for item in methods:
        assert romanize(locale='ru')(getattr(data, item))().isalpha()

# Generated at 2022-06-23 20:49:20.239539
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text

    text = Text()
    assert text._romanize('привет!') == 'privet!'



# Generated at 2022-06-23 20:49:24.977008
# Unit test for function romanize
def test_romanize():
    def generator():
        for i in range(10):
            yield 'Пример'

    @romanize(locale='ru')
    def romanized_generator():
        for i in range(10):
            yield 'Пример'

    for i, j in zip(generator(), romanized_generator()):
        assert i in j

# Generated at 2022-06-23 20:49:28.476544
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'Привет')() == 'Privet'
    assert romanized('kk')(lambda: 'Привет')() == 'Privet'


# Generated at 2022-06-23 20:49:30.240615
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'привет')() == 'privet'
    assert romanized(locale='ru')(lambda: 'привет')() == 'privet'

# Generated at 2022-06-23 20:49:38.362178
# Unit test for function romanize
def test_romanize():
    def foo(bar):
        return bar

    r = romanize('ru')(foo)('абвгдеёжзийклмнопрстуфхцчшщъыьэюя'
                         'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ')

# Generated at 2022-06-23 20:49:40.472445
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Максим')() == 'Makxim'

# Generated at 2022-06-23 20:49:50.263615
# Unit test for function romanize
def test_romanize():
    """Test romanization."""
    rus = ['Айсберг', 'аист', 'апрель']
    romanized_rus = ['Ajcyberg', 'ajst', 'aprel']
    ukr = ['що', 'паблік', 'реликвія']
    romanized_ukr = ['sho', 'publik', 'relikviya']
    kaz = ['шығарылған', 'құралын']
    romanized_kaz = ['shyğarylğan', 'quralyn']

    @romanize(locale='ru')
    def rus_romanized(n):
        return n



# Generated at 2022-06-23 20:50:01.664981
# Unit test for function romanize
def test_romanize():
    class rus():
        @romanize()
        def rus(self):
            return 'А БВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'

    class uk():
        @romanize()
        def uk(self):
            return 'А БВГҐДЕЄЖЗИІЇКЛМНОПРСТУФХЦЧШЩЬЮЯ'


# Generated at 2022-06-23 20:50:06.518813
# Unit test for function romanize
def test_romanize():
    print(romanize('ru')(lambda: 'Привет, Мир!'))
    # Praviet, Mir!
    print(romanize('uk')(lambda: 'Привіт, Світ!'))
    # Pryvit, Svit!
    print(romanize('kk')(lambda: 'Сәлем, Дүние!'))
    # Sälem, Dünie!



# Generated at 2022-06-23 20:50:10.770891
# Unit test for function romanize
def test_romanize():
    assert romanize()("Привіт") == "Pryvit"
    assert romanize("en")("Hello") == "Hello"
    assert romanize("kk")("Сәлем") == "Sälem"

# Generated at 2022-06-23 20:50:13.722101
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def func(locale):
        return locale

    result = 'Privet Mir'
    assert func('Привет Мир') == result

# Generated at 2022-06-23 20:50:17.039270
# Unit test for function romanize
def test_romanize():
    # test function
    @romanized()
    def test_romanize(text):
        return text

    # test non-cyrillic
    assert test_romanize('Hello') == 'Hello'
    # test cyrillic
    assert test_romanize('Привет') == 'Privet'

# Generated at 2022-06-23 20:50:19.736376
# Unit test for function romanize
def test_romanize():

    def func(text, frequency=None) -> str:
        return text

    assert romanize('ru')(func)('Привет, Мимоза!') == 'Privet, Mimosa!'

# Generated at 2022-06-23 20:50:24.858677
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Русский')() == 'Russkiy'
    assert romanized(locale='uk')(lambda: 'Русский')() == 'Russkyy'
    assert romanized(locale='kk')(lambda: 'Русский')() == 'Russkjy'

# Generated at 2022-06-23 20:50:27.503584
# Unit test for function romanize
def test_romanize():
    if __name__ == '__main__':
        # test for function romanize
        @romanize()
        def romanized_text():
            return ''

        assert romanized_text() == ''

# Generated at 2022-06-23 20:50:37.092603
# Unit test for function romanize
def test_romanize():
    # This function is used to test the romanize decorator
    def foo(string='Строка для тестирования русского текста'):
        return string

    assert romanize('ru')(foo)() == 'Stroka dlya testirovaniya russkogo teksta'
    assert romanize('kk')(foo)() == 'Строка для тестирования русского текста'

# Generated at 2022-06-23 20:50:47.624320
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda: '123abc')() == '123abc'
    assert romanize('ru')(lambda: '123abc')() == '123abc'
    assert romanize('ru')(lambda:  'АаБбВвГг')() == 'AaBbVvGg'
    assert romanize('uk')(lambda: 'АаБбВвГг')() == 'AaBbVvGg'
    assert romanize('kk')(lambda: 'АаБбВвГг')() == 'AaBbVvGg'

# Generated at 2022-06-23 20:50:52.728926
# Unit test for function romanize
def test_romanize():
    import string

    from mimesis.enums import DatetimeFormat

    from .random import Random

    random_ = Random()

    func = random_.datetime.datetime
    result = func(format=DatetimeFormat.FULL)

    alphabet = {s: s for s in string.ascii_letters + string.digits + string.punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT['ru'],
        **data.COMMON_LETTERS,
    })

    txt = ''.join([alphabet[i] for i in result if i in alphabet])

# Generated at 2022-06-23 20:50:58.420443
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    def test_locale_ru(a: str = '') -> str:
        """Test locale ru."""
        return a

    def test_locale_uk(a: str = '') -> str:
        """Test locale uk."""
        return a

    def test_locale_kk(a: str = '') -> str:
        """Test locale kk."""
        return a

    @romanize('ru')
    def test_ru(a: str = '') -> str:
        """Romanize for ru."""
        return a

    @romanize('uk')
    def test_uk(a: str = '') -> str:
        """Romanize for uk."""
        return a


# Generated at 2022-06-23 20:51:04.164158
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import SpecialChars
    from mimesis.providers.person import Person

    class NewPerson(Person):
        @romanize('ru')
        def full_name_male(self):
            return super().full_name_male()

    person = NewPerson('en')
    result = person.full_name_male()
    assert SpecialChars.ASCII not in result

# Generated at 2022-06-23 20:51:07.965588
# Unit test for function romanize
def test_romanize():
    string = 'Алексей'
    result = ''
    for char in string:
        result += data.ROMANIZATION_DICT['ru'][char]
    assert romanize(locale='ru')(lambda: string)() == result

# Generated at 2022-06-23 20:51:14.953065
# Unit test for function romanize
def test_romanize():
    s = 'Привет'
    assert romanize('ru')(lambda: s)() == 'Privet'
    s = 'Поділля'
    assert romanize('uk')(lambda: s)() == 'Podillia'
    s = 'Жаңа'
    assert romanize('kk')(lambda: s)() == 'Zhana'

# Generated at 2022-06-23 20:51:18.209762
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')
    assert p.romanize(p.full_name(gender=Gender.FEMALE)) == \
            "Marina Aleksandrovna Ivanova"

# Generated at 2022-06-23 20:51:25.003567
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'слово')().startswith('slovo')
    assert romanize('uk')(lambda : 'слово')().startswith('slovo')
    assert romanize('kk')(lambda : 'слово')().startswith('slovo')
    assert romanize('ru')(lambda : 'слово')().endswith('во')
    assert romanize('ru')(lambda : 'помилка')().endswith('ka')

# Generated at 2022-06-23 20:51:27.317000
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    ru = RussiaSpecProvider()

    ru.romanize()



# Generated at 2022-06-23 20:51:33.902936
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    print(romanized(locale='ru')(lambda: 'Съешь ещё этих мягких французских булок из Йошкар-Олы, да выпей же чаю'))
    print(romanized(locale='uk')(lambda: 'Шілдеда «поляки» автобус құру'))

# Generated at 2022-06-23 20:51:38.095114
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    class Test:

        def __init__(self, locale='ru'):
            self.provider = RussianSpecProvider(locale=locale)
            self.russian_test = self.provider.get_quotes()

    test = Test()
    assert test.russian_test != romanized('ru')(test.provider.get_quotes)()

# Generated at 2022-06-23 20:51:42.258644
# Unit test for function romanize
def test_romanize():
    """ Test romanize decorator. """
    @romanized()
    def bar(arg):
        return arg
    assert bar('Привет') == 'Privet'



# Generated at 2022-06-23 20:51:50.209535
# Unit test for function romanize
def test_romanize():
    """Test for romanization."""
    examples = {
        'ru': 'Меня зовут Тима.',
        'en': 'My name is Tima.',
        'uk': 'Мене звати Тіма.',
        'kk': 'Менің атым Тима.',
    }
    for locale in examples:
        text = romanize(locale)(lambda: examples[locale])(locale)
        assert isinstance(text, str)
        assert len(text) > 0



# Generated at 2022-06-23 20:51:53.668611
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def dummy(x):
        return x

    assert dummy('Превед, Медвед') == 'Privet, Medved'

# Generated at 2022-06-23 20:51:54.276228
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:52:04.140466
# Unit test for function romanize
def test_romanize():
    alphabet = {s: s for s in ascii_letters + digits + punctuation}

# Generated at 2022-06-23 20:52:07.193752
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    @romanize(locale='ru')
    def foo():
        return 'Привет Мир!'

    assert foo() == 'Privet Mir!'

# Generated at 2022-06-23 20:52:14.113167
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Selеm'


__all__ += [
    'romanized',
    'test_romanize'
]

# Generated at 2022-06-23 20:52:20.239746
# Unit test for function romanize
def test_romanize():
    data.COMMON_LETTERS.update({'Э': 'É'})
    data.ROMANIZATION_DICT['ru'].update({'Э': 'É'})
    res = romanize()(lambda: 'Эээээээээ')
    assert res() == 'ÉÉÉÉÉÉÉÉ'

# Generated at 2022-06-23 20:52:24.976291
# Unit test for function romanize
def test_romanize():
    data.ROMANIZATION_DICT['RU'] = {
        'а': 'a',
        'б': 'b',
        'в': 'v',
    }
    name = 'вася'
    romanized_name = romanize('RU')(name)
    assert romanized_name == 'vasya'

# Generated at 2022-06-23 20:52:33.040390
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    txt = RussiaSpecProvider().full_name(gender=Gender.FEMALE)
    assert romanized('ru')(lambda x: x)(txt) == \
        'Анна Александровна Танкосян'

# Generated at 2022-06-23 20:52:39.140639
# Unit test for function romanize
def test_romanize():
    def foo(locale):
        return data.ROMANIZATION_DICT[locale]

    assert foo('ru') == data.ROMANIZATION_DICT['ru']
    assert foo('uk') == data.ROMANIZATION_DICT['uk']
    assert foo('kk') == data.ROMANIZATION_DICT['kk']
    assert foo('en') == data.ROMANIZATION_DICT['en']


test_romanize()

# Generated at 2022-06-23 20:52:41.935427
# Unit test for function romanize
def test_romanize():
    def test_func():
        return 'Тест'

    romanized_test_func = romanize('ru')(test_func)

    assert romanized_test_func() == 'Test'

# Generated at 2022-06-23 20:52:49.520107
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Русский')() == 'Russkiy'

    assert romanize(locale='uk')(lambda: 'Українська')() == 'Ukrainska'

    assert romanize(locale='kk')(lambda: 'Қазақ')() == 'Qazaq'

    # Russian cyrillic text with digits and punctuation

# Generated at 2022-06-23 20:52:54.348517
# Unit test for function romanize
def test_romanize():
    d = {
        'ru': 'киса',
        'uk': 'кіса',
        'kk': 'қыса',
    }

    # Add korean to check that it doesn't work
    d['ko'] = '가나다'

    for locale in d:
        assert romanize(locale)(lambda: d[locale])() == 'kisa'

# Generated at 2022-06-23 20:53:00.124786
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    from mimesis.enums import Gender
    from random import random

    t = Text()
    # The first argument to the function Romanize
    # is the locale code
    @romanize('ru')
    def romanize_func(gender: str) -> str:
        return t.name(gender=gender)

    # The second argument to the function Romanize
    # is the Gender type
    res = romanize_func(Gender.FEMALE if random() > 0.5 else Gender.MALE)
    assert ' ' not in res, res

# Generated at 2022-06-23 20:53:07.232553
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    p = Person()
    text = p.full_name()
    roman_text = p.full_name(romanize=True)
    assert (roman_text == p.full_name(locale='ru'))
    # In romanized string there are no cyrillic letters
    assert (len(roman_text.encode('utf-8')) == len(text.encode('utf-8')))

# Generated at 2022-06-23 20:53:15.931512
# Unit test for function romanize
def test_romanize():
    @romanized()
    def roman():
        return 'продажа частных данных'

    assert roman() == 'prodazha chastnykh dannykh'

    @romanized('uk')
    def roman():
        return 'продажа частных данных'

    assert roman() == 'prodazha chastnykh danykh'

    @romanized('kk')
    def roman():
        return 'продажа частных данных'

    assert roman() == 'prodazha chastnyh dannyh'

# Generated at 2022-06-23 20:53:27.026626
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func(arg):
        return arg

    assert func('Привет, Мiр!') == 'Privet, Mir!'
    assert func('Как твои дела?') == 'Kak tvoi dela?'

    @romanize(locale='ru')
    def func(arg):
        return arg

    assert func('Привет, Мир!') == 'Privet, Mir!'
    assert func('Как твои дела?') == 'Kak tvoi dela?'

    @romanize(locale='uk')
    def func(arg):
        return arg


# Generated at 2022-06-23 20:53:37.299390
# Unit test for function romanize
def test_romanize():
    """Unittest for romanize.

    - Test from source.
    - Test from destination.
    - Test from source and destination.
    - Test from destination and source.
    """

    def _rom(source, destination):
        def _roman(text):
            return text

        counter = 0
        for k, v in data.ROMANIZATION_DICT[source].items():
            value = _roman(k)
            if value == v:
                counter += 1
        assert counter == len(data.ROMANIZATION_DICT[source])

        counter = 0
        for k, v in data.ROMANIZATION_DICT[destination].items():
            value = _roman(v)
            if value == k:
                counter += 1

# Generated at 2022-06-23 20:53:40.770424
# Unit test for function romanize
def test_romanize():
    txt = 'Сколько на луне килограммов весит человек?'
    trn = 'Skolko na lune kilogrammov vesit chelovek?'
    def f(locale: str = 'ru') -> Callable:
        return romanize(locale)(lambda x: txt)
    assert f()() == trn
    assert f(locale='uk')() == trn

# Generated at 2022-06-23 20:53:47.872714
# Unit test for function romanize
def test_romanize():
    assert len(functools.partial(romanize('ru'))('Привет, мир!')) == 12
    assert len(functools.partial(romanize('uk'))('Привіт, світ!')) == 12
    assert functools.partial(romanize('kk'))('Сәлем, дүние!') == 'Salem, dunie!'

# Generated at 2022-06-23 20:53:58.064374
# Unit test for function romanize
def test_romanize():
    text = 'Мама мыла раму'
    # convert string to upper case
    upper_text = text.upper()

    # conversion

# Generated at 2022-06-23 20:54:10.279441
# Unit test for function romanize
def test_romanize():
    # From https://py.checkio.org/mission/roman-and-arabic-numerals/solve/
    def arabic_to_roman(decimal_num):
        roman = {'M': 1000, 'CM': 900, 'D': 500, 'CD': 400, 'C': 100, 'XC': 90,
                 'L': 50, 'XL': 40, 'X': 10, 'IX': 9, 'V': 5, 'IV': 4, 'I': 1}
        numeral = ''
        for r in roman.keys():
            number = int(decimal_num / roman[r])
            numeral += number * r
            decimal_num -= number * roman[r]
            if decimal_num <= 0:
                return numeral


# Generated at 2022-06-23 20:54:15.695248
# Unit test for function romanize
def test_romanize():
    def foo():
        return "Мне очень нравится Mimesis."

    assert 'Mne ochen nravitsa Mimesis' == romanize(locale='ru')(foo)()
    assert 'Mne ochen nravitsya Mimesis' == romanized(locale='uk')(foo)()

# Generated at 2022-06-23 20:54:20.585256
# Unit test for function romanize
def test_romanize():
    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT['ru'],
        **data.COMMON_LETTERS,
    })
    result = 'тест'.strip()
    txt = ''.join([alphabet[i] for i in result if i in alphabet])
    assert txt == 'test'

# Generated at 2022-06-23 20:54:27.567220
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    ru_provider = RussiaSpecProvider()
    assert ru_provider.person.full_name(romanize=True)
    assert ru_provider.person.full_name(romanize=True, locale='ru')

    assert ru_provider.region.region(romanize=True)
    assert ru_provider.region.region(romanize=True, locale='ru')
    assert ru_provider.region.region(romanize=True, locale='uk')

    assert ru_provider.personal.religion(romanize=True)
    assert ru_provider.personal.religion(romanize=True, locale='ru')

    assert ru_provider.code.isbn(romanize=True)

# Generated at 2022-06-23 20:54:35.591844
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ')() == 'ABVGDĖŽZIJKLMNOPRSTUFHCŠŜĂÝÌÈÚÂ'

# Generated at 2022-06-23 20:54:40.903678
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_cyrillic_symbols():
        return 'Горбунов Иван Петрович'
    assert get_cyrillic_symbols() == 'Gorbunov Ivan Petrovi4'
    assert get_cyrillic_symbols() != 'Gorbyunov Ivan Petrovi4'

# Generated at 2022-06-23 20:54:49.193089
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет, мир!')().startswith('Privet, mir')
    assert romanize(locale='uk')(lambda: 'Привіт, світ!')().startswith('Pryvit, svit')
    assert romanize(locale='kk')(lambda: 'Сәлем, дүние!')().startswith('Sәlem, dünie')

# Generated at 2022-06-23 20:54:54.063678
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Text

    rus_txt = Text('ru')
    rus_txt.words(4)

    ua_txt = Text('uk')
    ua_txt.words(4)

    kz_txt = Text('kk')
    kz_txt.words(4)



# Generated at 2022-06-23 20:54:56.009761
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:54:57.925412
# Unit test for function romanize
def test_romanize():
    test_function_with_decorator()
    test_class_with_decorator()



# Generated at 2022-06-23 20:55:01.859042
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'python')() == 'python'
    assert romanize('kk')(lambda: 'Пайтон')() == 'Paıton'
    assert romanized('uk')(lambda: 'Пайтон')() == 'Pajton'

# Generated at 2022-06-23 20:55:03.702205
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanized():
        return 'привет'

    assert romanized == 'privet'

# Generated at 2022-06-23 20:55:05.397461
# Unit test for function romanize
def test_romanize():
    assert romanize('ua')(lambda: 'Зірка')() == 'Zirka'

# Generated at 2022-06-23 20:55:07.750040
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda _: 'блаблабла')() == 'blablabla'

# Generated at 2022-06-23 20:55:12.477058
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda x: 'Привіт, Мімесіс!')() == 'Pryvit, Mimesis!'
    assert romanize('ru')(lambda x: 'Привет, Мимесис!')() == 'Privet, Mimesis!'
    assert romanize('kk')(lambda x: 'Сәлем, Мімесіс!')() == 'Sälem, Mimesis!'

# Generated at 2022-06-23 20:55:15.380381
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('кот') == 'kot'
    assert romanize('uk')('кот') == 'kot'
    assert romanize('kk')('кот') == 'kot'


__all__ += ['romanized']

# Generated at 2022-06-23 20:55:21.445596
# Unit test for function romanize
def test_romanize():
    alphabet = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    romanized_alphabet = '0123456789abwdeghijklljmnnoprrsttuvxyzABWDEHHIJKLLLMNOPRRSTTUVXYZ'

    def foo(self):
        return alphabet

    foo = romanize(locale='ru')(foo)
    assert foo(None) == romanized_alphabet

# Generated at 2022-06-23 20:55:22.473921
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    pass

# Generated at 2022-06-23 20:55:25.937123
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize('ru')(lambda: 'АБВГДЕ')() == 'ABVGDE'
    assert romanize('uk')(lambda: 'АБВГДЕЖЗИ')() == 'ABVGDEZHZY'
    assert romanize('kk')(lambda: 'АБВГДЕЖЗИ')() == 'ABVGDEJZY'

# Generated at 2022-06-23 20:55:33.042070
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Process

    assert romanize(locale=Process.UKRAINIAN)(lambda: 'Абрікоса')() == \
        'Abríkosa'
    assert romanize(locale=Process.RUSSIAN)(lambda: 'Абрікоса')() == \
        'Abríkosa'
    assert romanize(locale=Process.KAZAKH)(lambda: 'Абрікоса')() == \
        'Abríkosa'
    assert romanize()(lambda: 'Абрікоса')() == 'Абрікоса'

# Generated at 2022-06-23 20:55:34.376265
# Unit test for function romanize
def test_romanize():
    assert romanize('') == romanize

test_romanize()

# Generated at 2022-06-23 20:55:39.131969
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_text():
        text = "Это кусок русскоязычного текста с цифрами 0987987666."
        return text

    assert romanize_text() == "Eto kusok russkojazychnogo teksta s tsiframi " \
                              "0987987666."



# Generated at 2022-06-23 20:55:41.851451
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian():
        return 'Привет мир!'

    assert russian() == 'Privet mir!'

# Generated at 2022-06-23 20:55:44.172011
# Unit test for function romanize
def test_romanize():
    """Tests for romanize."""
    def test_func(a: str) -> str:
        return f'{a} привет мир'

    result = romanize('ru')(test_func)('Tets')
    assert result == 'Tets privet mir'

# Generated at 2022-06-23 20:55:46.379801
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize()(lambda x: 'привет')() == 'privet'

# Generated at 2022-06-23 20:55:51.095251
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize('ru')(lambda: 'привет мир')() == 'privet mir'
    assert romanize('uk')(lambda: 'Привіт Світ')() == 'Pryvit Svit'

# Generated at 2022-06-23 20:56:00.000157
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    ua = Language.UKRAINIAN
    ru = Language.RUSSIAN
    kk = Language.KAZAKH

    uk = Person(locale=ua)
    ru = Person(locale=ru)
    kz = Datetime(locale=kk)

    assert romanized(locale=ua)(uk.full_name) == uk.full_name()
    assert romanized(locale=ru)(ru.full_name) == ru.full_name()
    assert romanized(locale=kk)(kz.day_of_week) == kz.day_of_week()

# Generated at 2022-06-23 20:56:10.333195
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет'.lower())() == 'privet'
    assert romanize('uk')(lambda: 'Привіт'.lower())() == 'pryvit'
    assert romanize('kk')(lambda: 'Сәлем'.lower())() == 'salem'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sәlem'
    assert romanize('kk')(lambda: 'Лайка')() == 'Lajka'
    assert romanize('ru')(lambda: 'Hello world')() == 'Hello world'

test_romanize()

# Generated at 2022-06-23 20:56:20.147635
# Unit test for function romanize
def test_romanize():
    romanized('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    romanized('uk')(lambda: 'Привіт, Світе!')() == 'Pryvit, Svite!'
    romanized('kk')(lambda: 'Сәлем, Қазақстан!')() == 'Sälem, Qazaqstan!'
    romanized('kk')(lambda: 'Сәлем, Мир!')() == 'Sälem, Mir!'
    romanized('kk')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-23 20:56:22.391147
# Unit test for function romanize
def test_romanize():
    assert not hasattr(romanize, '_mimesis_localize')
    assert not hasattr(romanize, 'localize')



# Generated at 2022-06-23 20:56:26.549780
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    ru = Language.RUSSIAN
    ru_provider = ru.value()
    ru_locale = ru_provider.locale

    assert ru_provider.word() == 'word'
    assert ru_provider.word(romanized=True) == 'vord'
    assert ru_provider.romanize(ru_provider.word()) == 'vord'



# Generated at 2022-06-23 20:56:29.249325
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('Как живут кулики?') == 'Kak zhivut kuliki?'

# Generated at 2022-06-23 20:56:32.554885
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Корова')() == 'Korova'

# Generated at 2022-06-23 20:56:36.115294
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    s = 'Один тест написан'
    result = romanize('ru')(lambda: s)()
    assert result == 'Odin test napisan'

# Generated at 2022-06-23 20:56:38.729588
# Unit test for function romanize
def test_romanize():
    assert 'pYcckC,' == romanize()()


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:56:42.697181
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.text import Text
    t = Text('ru')

    @t.romanize
    def test():
        return t.word()

    assert test() == t.romanize(t.word())



# Generated at 2022-06-23 20:56:53.403589
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import (
        RussianSpeaker,
        UkrainianSpeaker,
        KazakhSpeaker,
    )

    r = RussianSpeaker()
    u = UkrainianSpeaker()
    k = KazakhSpeaker()

    assert r.romanize(r.identifier()) == '7C4BZ1Y8KV'
    assert u.romanize(u.identifier()) == '7C4BZ1Y8KV'
    assert k.romanize(k.identifier()) == '14K3T7BZJ1'

    assert r.romanize(r.full_name()) == 'Jlna Jlnaaplna'
    assert u.romanize(u.full_name()) == 'Jlna Jlnaaplna'

# Generated at 2022-06-23 20:56:59.042367
# Unit test for function romanize
def test_romanize():
    from mimesis import Generic

    class MyGeneric(Generic):
        @romanize('ru')
        def romanized_word(self):
            return self.random_element(data.WORD_LIST)


    # Test for romanized words
    g = MyGeneric('ru')
    assert g.romanized_word() in data.ROMANIZATION_DICT['ru'].values()

# Generated at 2022-06-23 20:57:03.672276
# Unit test for function romanize
def test_romanize():
    # Original
    assert 'Иванов Иван Иванович' == romanized('ru')('Иванов Иван Иванович')
    # Romanized
    assert 'Ivanov Ivan Ivanovich' == romanized('ru')('Иванов Иван Иванович')

# Generated at 2022-06-23 20:57:06.115087
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test_func():
        return 'Здравствуйте, мир!'

    assert test_func() == 'Zdravstvuyte, mir!'

# Generated at 2022-06-23 20:57:16.926897
# Unit test for function romanize
def test_romanize():
    def f():
        return 'Йбґцйфцхї фхлĳбг т бд гд цїзбг'

    assert romanize('ru')(f)() == 'Ibggtsiyfthkhljiibg t bd gd tsizibg'
    assert romanize('uk')(f)() == 'Ibihtstiyfthkhljiibg t bd gd tsizibg'
    assert romanize('kk')(f)() == 'İbggtsiyfthkhljiibg t bd gd tsizibg'

# Generated at 2022-06-23 20:57:19.401975
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет') == 'Privet'

# Generated at 2022-06-23 20:57:21.961984
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Возраст океана') == 'Vozrast ocean'

# Generated at 2022-06-23 20:57:27.002590
# Unit test for function romanize
def test_romanize():
    """Test for romanized decorator."""
    from mimesis.builtins import RussiaSpecProvider

    ru = RussiaSpecProvider()

    @romanized()
    def name():
        """Return romanized name."""
        return ru.full_name()

    assert ru.full_name() != name()

# Generated at 2022-06-23 20:57:28.574369
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')(lambda: 'Абир')() == 'Abir'

# Generated at 2022-06-23 20:57:30.352510
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир')() == 'Privet mir'

# Generated at 2022-06-23 20:57:34.221185
# Unit test for function romanize
def test_romanize():
    assert romanize()('Волкова Анастасия Витальевна') == 'Volkova Anastasiya Vitalievna'
    assert romanized(locale='ru')('Волкова Анастасия Витальевна') == 'Volkova Anastasiya Vitalievna'

# Generated at 2022-06-23 20:57:42.640909
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import Person

    p = Person(Language.ENGLISH)
    result = romanize(locale='ru')(p.full_name)
    assert type(result) == str
    result = romanize(locale='uk')(p.full_name)
    assert type(result) == str
    result = romanize(locale='kk')(p.full_name)
    assert type(result) == str
    try:
        result = romanize(locale='la')(p.full_name)
    except UnsupportedLocale:
        assert True
    else:
        assert False

# Generated at 2022-06-23 20:57:51.558279
# Unit test for function romanize
def test_romanize():
    # Import for coverage
    from mimesis.builtins.common import _CommonSpecifier

    def test_func():
        return 'Привет'

    tmp = _CommonSpecifier()
    assert tmp.hello() == 'Привет'

    # Russian
    tmp.locale = 'ru'
    assert tmp.hello() == 'Привет'

    @romanized('ru')
    def test_func():
        return 'Привет'

    assert test_func() == 'Privet'

    # Ukrainian
    tmp.locale = 'uk'
    assert tmp.hello() == 'Привіт'

    @romanized('uk')
    def test_func():
        return 'Привіт'

   