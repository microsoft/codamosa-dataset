

# Generated at 2022-06-23 20:47:51.587171
# Unit test for function romanize
def test_romanize():
    assert 'Здравствуй, мир!' == romanized('ru')(lambda: 'Здравствуй, мир!')
    assert 'Кізі құмалысы келіп, отбасы болса!' == romanized('kk')(lambda: 'Кізі құмалысы келіп, отбасы болса!')

# Generated at 2022-06-23 20:48:02.043530
# Unit test for function romanize
def test_romanize():
    def _test_romanize(word):
        assert word.ru() == _test_romanize.alphabet[word]


# Generated at 2022-06-23 20:48:06.001278
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def gen_name(seed: int = None) -> str:
        return 'Ярослав'

    assert gen_name() == 'Yaroslav'
    assert gen_name.__name__ == 'gen_name'

# Generated at 2022-06-23 20:48:15.005131
# Unit test for function romanize
def test_romanize():
    """Test romanize"""
    # test_romanize_uk

    def inner_test(test_locale, expected):
        @romanize(test_locale)
        def romanize_data():
            return 'Сигнализація вагону'

        assert romanize_data() == expected

    test_locales = {
        'uk': 'Sig’nalizacija vagónu',
        'ru': 'Signalizacija vagonu',
        'kk': 'Sığnalızacıya vagony'
    }

    for test_locale, expected in test_locales.items():
        inner_test(test_locale, expected)

# Generated at 2022-06-23 20:48:23.213091
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    russian = RussianSpecProvider()
    assert isinstance(russian.romanize(), str)
    assert russian.romanize('Иванов Иван Иванович') == \
           'Ivanov Ivan Ivanovich'

    from mimesis.builtins import UkrainianSpecProvider
    ukrainian = UkrainianSpecProvider()
    assert isinstance(ukrainian.romanize(), str)
    assert ukrainian.romanize('Іванов Іван Іванович') == \
           'Ivanov Ivan Ivanovich'

    from mimesis.builtins import KazakhSpecProvider
    kazakh = KazakhSpecProvider()

# Generated at 2022-06-23 20:48:24.485617
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Здравствуй мир!') == 'Zdravstvui mir!'

# Generated at 2022-06-23 20:48:29.637130
# Unit test for function romanize
def test_romanize():
    input = ["Русский", "Китайский", "Испанский"]
    output = ["Russkiy", "Kitayskiy", "Ispanskiy"]

    for i, text in enumerate(input):
        assert romanize(locale='ru')(text) == output[i]

# Generated at 2022-06-23 20:48:32.433036
# Unit test for function romanize
def test_romanize():
    @romanize()
    def r(x):
        return x

    assert r('привет!!!') == 'privet!!!'

# Generated at 2022-06-23 20:48:40.411242
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    alphabet = {s: s for s in
                ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT['ru'],
        **data.COMMON_LETTERS,
    })
    assert isinstance(alphabet, dict)

    result = 'Привет, мир!'
    txt = ''.join([alphabet[i] for i in result if i in alphabet])
    assert txt == 'Privet, mir!'

# Generated at 2022-06-23 20:48:44.977890
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'привет')() == 'privet'
    assert romanized(locale='uk')(lambda: 'привіт')() == 'pryvit'
    assert romanized(locale='kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-23 20:48:51.270184
# Unit test for function romanize
def test_romanize():
    def romanize_text(*args, **kwargs):
        return 'Джек и бобовница.'

    f = romanize_text
    assert f() == 'Джек и бобовница.'
    assert f.__name__ == 'romanize_text'

    f = romanize(locale='ru')(f)
    assert f() == 'Dzhek i bobovnitsa.'
    assert f.__name__ == 'romanize_text'

# Generated at 2022-06-23 20:48:55.810482
# Unit test for function romanize
def test_romanize():
    """Test romanize"""
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'privit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-23 20:48:58.957307
# Unit test for function romanize
def test_romanize():
    @romanize('uk')
    def test(cyrillic_string: str) -> str:
        return cyrillic_string

    assert test('Добро пожаловать') == 'Dobro pozhalovaty'

# Generated at 2022-06-23 20:49:01.939525
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""
    @romanize('ru')
    def get_city() -> str:
        return 'Москва'

    assert get_city() == 'Moskva'

# Generated at 2022-06-23 20:49:04.322019
# Unit test for function romanize
def test_romanize():
    for lang in data.SUPPORTED_LOCALES:
        assert len(romanize(lang)(lambda: 'абвг')) > 0

# Generated at 2022-06-23 20:49:14.722777
# Unit test for function romanize
def test_romanize():
    assert romanized()('test') == 'test'
    assert romanized()('test123') == 'test123'
    assert romanized()('test, test?') == 'test, test?'
    assert romanized()('Привет') == 'Privet'
    assert romanized('ru')('Привет') == 'Privet'
    assert romanized('uk')('Привет') == 'Pryvit'
    assert romanized('kk')('Привет') == 'Privet'
    assert romanized('ru')('Привет, мир!') == 'Privet, mir!'

# Generated at 2022-06-23 20:49:23.210593
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Specialization
    from mimesis.providers.science import Science

    science = Science('ru')
    assert all(science.specialization.code in Specialization.__members__.values())

    spec = science.specialization.code
    pzkvd = science.pzkvd()

    assert len(pzkvd) > 0
    assert pzkvd in data.PZKVD[spec]
    assert 'СОЦИОЛОГИЯ' in pzkvd

# Generated at 2022-06-23 20:49:27.360442
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('Как дела?') == 'Kak dela?'
    assert romanized('kk')('Как дела?') == 'Qańǵa ĵolа?'
    assert romanized('uk')('Как дела?') == 'Kak dela?'

# Generated at 2022-06-23 20:49:35.524004
# Unit test for function romanize
def test_romanize():
    assert 'Hello, world' == romanize(locale='en')(lambda: 'Hello, world')
    assert 'Привет, мир' == romanize(locale='ru')(lambda: 'Привет, мир')
    assert 'Привет, мир' == romanized(locale='ru')(lambda: 'Привет, мир')

    with UnsupportedLocale('blah'):
        romanize(locale='blah')(lambda: 'blah')

    with UnsupportedLocale('blah'):
        romanized(locale='blah')(lambda: 'blah')

# Generated at 2022-06-23 20:49:36.850819
# Unit test for function romanize
def test_romanize():
    assert romanize()  # Test for decorator
    assert romanized()  # Test for decorator (BC)

# Generated at 2022-06-23 20:49:41.026030
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_text(text, num=1):
        return text * num

    assert romanize_text('Привет, Мир!', num=2) == 'Privet, Mir!' * 2

# Generated at 2022-06-23 20:49:42.806637
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda **kwargs: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:49:46.251225
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test():
        return 'Когда скажут, «пойдём гулять»'

    assert test() == 'Kogda skazhut, «poidyom gulyat'

# Generated at 2022-06-23 20:49:48.948163
# Unit test for function romanize
def test_romanize():
    """Tests that romanize is working."""
    @romanize('ru')
    def test(s: str) -> str:
        return s

    assert test('Я любил') == 'Ya lubil'

# Generated at 2022-06-23 20:49:53.976534
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    person = Person('ru')

    assert person.romanized(quantity=5) == "Таня Максим Антон Костя Аня"



# Generated at 2022-06-23 20:50:03.709226
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_func(source: str) -> str:
        return source

    assert romanize_func('Привет') == 'Privet'
    assert romanize_func('Україна') == 'Ukraina'
    assert romanize_func('Пащёлкин') == 'Pashcholkin'
    assert romanize_func('На поле берёза стояла') == 'Na pole bereza stoyala'

# Generated at 2022-06-23 20:50:06.255578
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.latin import LatinSpecProvider as LSP
    assert isinstance(LSP(Locale.RU).word(), str)

# Generated at 2022-06-23 20:50:08.693785
# Unit test for function romanize
def test_romanize():
    r = romanize()

    @r
    def foo():
        return 'Текст'

    assert foo() == 'Tekst'

# Generated at 2022-06-23 20:50:13.807866
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    rus = RussiaSpecProvider()

    assert rus.romanize('Как вы хотите назвать своего собаку?') == 'Kak vy khotite nazvat svoego sobaku?'

# Generated at 2022-06-23 20:50:18.469949
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Лорем ипсум долор сит амет") == "Lorem ipsum dolor sit amet"
    assert romanized("ru")("Лорем ипсум долор сит амет") == "Lorem ipsum dolor sit amet"

# Generated at 2022-06-23 20:50:18.961188
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:50:26.506947
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def generate_number():
        return '123'

    assert generate_number() == '123'

    @romanize('ru')
    def generate_ru_name():
        return 'Иван'

    assert generate_ru_name() == 'Ivan'

    @romanize('ua')
    def generate_ua_name():
        return 'Петро'

    assert generate_ua_name() == 'Petro'

    @romanize('kk')
    def generate_kk_name():
        return 'Батыр'

    assert generate_kk_name() == 'Batır'

# Generated at 2022-06-23 20:50:32.797927
# Unit test for function romanize
def test_romanize():
    def foo(*args, **kwargs):
        return 'ёжик рыбка бабочка летает'

    bar = romanize(locale='ru')(foo)
    assert bar() == 'yozhik rybka babochka letaet'

    with pytest.raises(UnsupportedLocale):
        romanize(locale='be')(foo)

# Generated at 2022-06-23 20:50:37.699539
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def cyrillic_text() -> str:
        return 'Привет, Мир!'
    assert cyrillic_text() == 'Privet, Mir!'



# Generated at 2022-06-23 20:50:46.011724
# Unit test for function romanize
def test_romanize():
    import mimesis
    from mimesis.builtins import RussiaSpecProvider as rsp
    from mimesis.builtins import RussiaSpecProvider

    person = rsp(mimesis.Generator)
    rst = RussiaSpecProvider.romanize('Колян')
    assert rst == 'Kolyan'
    assert isinstance(rst, str)
    assert person.romanize('Егор') == 'Egor'
    assert person.romanize('Петр') == 'Petr'
    assert person.romanize('Барсук') == 'Barsuk'
    assert isinstance(person.romanize('Барсук'), str)

# Generated at 2022-06-23 20:50:52.729079
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет, мир!')().lower() == 'privet, mir!'
    assert romanize()(lambda: 'Привет, мир!')().lower() == 'privet, mir!'
    assert romanize('ru')(lambda: 'Привет, мир!')().lower() == 'privet, mir!'
    assert romanize('en')(lambda: 'Привет, мир!')().lower() == 'privet, mir!'
    assert romanize('uk')(lambda: 'Привіт, світ!')().lower() == 'pryvit, svit!'

# Generated at 2022-06-23 20:50:56.150659
# Unit test for function romanize
def test_romanize():
    assert romanize()('Работать проще всего с тем, чем раньше не работал.') == ('Rabotat` prosche vsego s tem, chem ran\'she '
                                                                            'ne rabotal.')

# Generated at 2022-06-23 20:50:59.386529
# Unit test for function romanize
def test_romanize():
    @romanize(locale='uk')
    def func(locale: str = 'uk') -> str:
        return locale

    assert func() == 'uk'

# Generated at 2022-06-23 20:51:09.614377
# Unit test for function romanize
def test_romanize():
    print('This is the test for "romanize" decorator')
    import mimesis.builtins.text

    mimesis.builtins.text.Text.get_cyrillic = romanized('ru')(mimesis.builtins.text.Text.get_cyrillic)
    txt = mimesis.builtins.text.Text()
    text = txt.get_cyrillic(words=2)
    print(text)
    assert isinstance(text, str)
    assert ' ' in text
    assert len(text) > 0
    assert ' ' in text

    mimesis.builtins.text.Text.get_cyrillic = romanized('uk')(mimesis.builtins.text.Text.get_cyrillic)

# Generated at 2022-06-23 20:51:20.042868
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import Person, PersonProvider
    from mimesis.providers.internet import Internet
    from mimesis.providers.address import Address
    from mimesis.providers.identifier import ScientificIdProvider

    data.ROMANIZATION_DICT[Language.RUSSIAN]['и'] = 'i'
    data.ROMANIZATION_DICT[Language.RUSSIAN]['я'] = 'ya'

    sp = ScientificIdProvider(Language.RUSSIAN)

    id_str = sp.identifier()
    assert 'и' not in id_str, 'Romanize decorator did not work'
    assert 'я' not in id_str, 'Romanize decorator did not work'


# Generated at 2022-06-23 20:51:23.618076
# Unit test for function romanize
def test_romanize():
    from mimesis import Generic
    g = Generic('ja')
    txt = g.sentence(max_length=20)
    result = g._romanize(txt)
    assert txt != result
    assert isinstance(result, str)
    assert result

# Generated at 2022-06-23 20:51:27.511370
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Кирилический алфавит')() == 'Kirilitseskii alfavit'

# Generated at 2022-06-23 20:51:28.807141
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda _: 'Собака')() == 'Sobaka'

# Generated at 2022-06-23 20:51:31.007378
# Unit test for function romanize
def test_romanize():
    @romanize()
    def rus():
        return 'Всем привет, друзья!'
    assert rus() == 'Vsem privet, druzya!'



# Generated at 2022-06-23 20:51:39.054810
# Unit test for function romanize
def test_romanize():
    def _romanize():
        return 'Привет, мир!'

    new = romanize()(_romanize)
    assert new() == 'Yfpyfxt, мир!'

    from mimesis.builtins.locales import ru

    ru_locale = ru.RuSpecification
    ru_locale.__init__()

# Generated at 2022-06-23 20:51:48.711783
# Unit test for function romanize
def test_romanize():
    import unittest
    from mimesis.builtins import Person
    from mimesis.builtins import Address

    person = Person('ru')
    address = Address('ru')

    text = person.full_name()
    assert len(text) > 0

    # without locale
    text = person.full_name()
    assert len(text) > 0

    # for region
    text = address.region()
    assert len(text) > 0

    # for city
    text = address.city()
    assert len(text) > 0

    # for street_name
    text = address.street_name()
    assert len(text) > 0

    # for address
    text = address.address()
    assert len(text) > 0

# Generated at 2022-06-23 20:51:54.092110
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    provider = RussiaSpecProvider()
    assert provider.person.full_name(postfix=False) == 'Иванов Иван Иванович'
    assert provider.person.full_name(postfix=False, romanize=True) == 'Ivanov Ivan Ivanovich'

# Generated at 2022-06-23 20:52:02.230738
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Работают')('Работают') == 'Rabotayut'
    assert romanize('uk')(lambda: 'Работают')('Работают') == 'Rabotayut'
    assert romanize('kk')(lambda: 'Работают')('Работают') == 'Rabotayut'



# Generated at 2022-06-23 20:52:07.508356
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: x)('Привет!') == 'Privet!'
    assert romanize('uk')(lambda x: x)('Привіт!') == 'Pryvit!'
    assert romanize('kk')(lambda x: x)('Привет!') == 'Privet!'

# Generated at 2022-06-23 20:52:15.412670
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Неотвратимое')() == 'Nеотвратимое'
    assert romanize(locale='kk')(lambda: 'Неотвратимое')() == 'Nеотвратимое'
    assert romanize(locale='uk')(lambda: 'Неотвратимое')() == 'Nеотвратимое'

# Generated at 2022-06-23 20:52:26.186673
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    r = RussiaSpecProvider()

    ###########
    # PASSED
    ###########

    assert r.person.full_name(romanize=True) is not None
    assert r.person.full_name(romanize=True, gender='male') is not None
    assert r.person.full_name(romanize=True, gender='female') is not None
    assert r.person.full_name(romanize=True, gender='binary') is not None

    assert r.person.full_name(romanize=True, gender='male') != r.person.full_name(romanize=True, gender='female')
    assert r.person.full_name(romanize=True, gender='male') != r.person.full_name(romanize=True, gender='binary')

# Generated at 2022-06-23 20:52:28.223957
# Unit test for function romanize
def test_romanize():

    @romanize()
    def romanized_text(token: str = '') -> str:
        return token

    assert romanized_text.__name__ == 'romanized_text'

# Generated at 2022-06-23 20:52:34.041378
# Unit test for function romanize
def test_romanize():
    text1 = "Привет, мир! Как дела?"
    text2 = "Hello, world! How are you?"

    @romanized('ru')
    def romanizer(text):
        return text

    assert romanizer(text1) == text2

# Generated at 2022-06-23 20:52:43.186198
# Unit test for function romanize
def test_romanize():
    assert all([romanize()(c) == c for c in ascii_letters])
    assert romanize()(
        'РђР‘Р’Р“Р”Р•Р–Р—Р’Р“Р”Р•Р–Р—РљРљРњРћРќРџР') == \
        'ABVGDEZIJKLMNOP'

# Generated at 2022-06-23 20:52:48.139130
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test():
        return 'Привет, Как дела? Да всё нормально.'

    assert test() == 'Privet, Kak dela? Da vsyo normal’no.'

# Generated at 2022-06-23 20:52:53.698786
# Unit test for function romanize
def test_romanize():
    import pytest

    @romanize('uk')
    def foo(arg):
        return arg

    with pytest.raises(UnsupportedLocale) as exc:
        # TODO:
        # Exception will be raised because of the
        # DataProvider.__init__() method.
        foo('текст')
    assert 'uk' in str(exc.value)

# Generated at 2022-06-23 20:52:54.807015
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'mimesis')()

# Generated at 2022-06-23 20:53:01.511871
# Unit test for function romanize
def test_romanize():
    def romanize_ru(text):
        return romanize('ru')(lambda: text)()

    def romanize_uk(text):
        return romanize('uk')(lambda: text)()

    def romanize_kk(text):
        return romanize('kk')(lambda: text)()

    # ru

    assert romanize_ru('Привет мир') == 'Privet mir'
    assert romanize_ru('Жирный текст') == 'Zhirniy tekst'
    assert romanize_ru('Пример') == 'Primer'
    assert romanize_ru('строка') == 'stroka'

# Generated at 2022-06-23 20:53:10.899563
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Моско́вский го́сударственный институ́т')() == "Moskóvskij gósudarstvennyj institút"
    assert romanized('uk')(lambda: 'Джерело мудрості')() == "Dzherelo mudrosti"
    assert romanized('kk')(lambda: 'Алтын алма кеңесі')() == "Altyn alma keñesi"

# Generated at 2022-06-23 20:53:15.607864
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    @romanize()
    def ru():
        return 'ЪЫЬЭЮЯ'

    assert ru() == 'Eiieiia'


test_romanize()  # noqa

# Generated at 2022-06-23 20:53:26.699519
# Unit test for function romanize
def test_romanize():
    import os
    import sys
    import unittest

    path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    sys.path.append(path)

    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Format

    class TestRomanize(unittest.TestCase):

        def setUp(self):
            self.locale = 'ru'
            self.ru = RussiaSpecProvider

        def test_romanize(self):
            romanized_methods = [getattr(self.ru, i) for i in dir(self.ru)
                                 if isinstance(getattr(self.ru, i),
                                               romanize)]


# Generated at 2022-06-23 20:53:37.210062
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    @romanize(locale='ru')
    def get_random_words(pattern: str) -> str:
        return pattern

    @romanized(locale='ru')
    def get_random_words_backward(pattern: str) -> str:
        return pattern

    assert get_random_words('А васька слушает') == 'A vaskha slushaiot'
    assert get_random_words('Б б б б б б') == 'B b b b b b'
    assert get_random_words('И и и и и и') == 'I i i i i i'

# Generated at 2022-06-23 20:53:39.302361
# Unit test for function romanize
def test_romanize():
    """Test for the romanize function."""
    romanized_str = 'Khity'

    @romanize(locale='kk')
    def romanize_str() -> str:
        return 'Хіты'

    assert romanized_str == romanize_str()

# Generated at 2022-06-23 20:53:44.638966
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_romanize_text():
        return "Россия – страна в Европе и Азии."

    assert get_romanize_text() == "Rossiya – strana v Evrope i Azii."

# Generated at 2022-06-23 20:53:53.507675
# Unit test for function romanize
def test_romanize():
    # test for romanized()
    assert romanize(locale='ru')
    assert romanize(locale='en')

    # test for romanize()
    assert romanize
    assert romanize(locale='ru')
    assert romanize(locale='en')
    assert romanize(locale='de')
    assert romanize(locale='fr')
    assert romanize(locale='it')
    assert romanize(locale='es')
    assert romanize(locale='pt')
    assert romanize(locale='tr')

# Generated at 2022-06-23 20:54:00.624270
# Unit test for function romanize
def test_romanize():
    assert 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ' == romanize('ru')('АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ')
    assert 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' == romanize('en')('ABCDEFGHIJKLMNOPQRSTUVWXYZ')

# Generated at 2022-06-23 20:54:01.317424
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:54:05.160703
# Unit test for function romanize
def test_romanize():

    def xxx(locale='ru-RU'):
        return 'слово'

    if xxx() != romanized(locale='ru')(xxx)():
        raise AssertionError('Romanization has failed.')

# Generated at 2022-06-23 20:54:16.424919
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import CyrillicLanguage, Language
    from mimesis.enums import Language as Lang


# Generated at 2022-06-23 20:54:22.240529
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import UkrainianSpecProvider
    uk_provider = UkrainianSpecProvider()

    assert uk_provider.romanize('Абвгдеєжзиіїйклмнопрстуфхцчшщьюя') == \
        'Abvgdeiezhziijkylmnoprstufhcshshchjuja'



# Generated at 2022-06-23 20:54:23.672549
# Unit test for function romanize
def test_romanize():
    assert romanized()
    assert romanized(locale='ru')() == 'самый'

# Generated at 2022-06-23 20:54:26.416565
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanized():
        return "Сегодня еду на работу на машине"

    assert romanized() == "Segodnja edu na rabotu na mashine"

# Generated at 2022-06-23 20:54:31.655400
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет мир.')() == 'Privet mir.'
    assert romanize(locale='ru')(lambda: 'Привет мир.')() == 'Privet mir.'
    assert romanize(locale='kk')(lambda: 'Привет мир.')() == 'Privet mir.'
    assert romanize(locale='uk')(lambda: 'Привет мир.')() == 'Pryvit myr.'

    assert romanized()(lambda: 'Привет мир.')() == 'Privet mir.'

# Generated at 2022-06-23 20:54:40.179614
# Unit test for function romanize
def test_romanize():
    import unittest

    class RomanizeTestCase(unittest.TestCase):
        def setUp(self):
            self.locale = 'ru'
            self.pattern = 'Привет, {0}!'

        def test_romanize(self):
            @romanize(self.locale)
            def romanize_func(pattern: str, seed: int) -> str:
                return pattern.format(seed)

            result = romanize_func(self.pattern, 'Мир')
            self.assertEqual(result, 'Privet, Mir!')

    unittest.main()

# Generated at 2022-06-23 20:54:44.789107
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир') == 'Privet mir'
    assert romanize('ru')(lambda: 'Привет, мир') == 'Privet, mir'
    assert romanize('ru')(lambda: 'Привет, мир!') == 'Privet, mir!'
    assert romanize('ru')(lambda: 'Гусар') == 'Gusar'



# Generated at 2022-06-23 20:54:47.538480
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test():
        return 'Привет, мир!'

    assert test() == 'Privet, mir!'

# Generated at 2022-06-23 20:54:58.495986
# Unit test for function romanize
def test_romanize():
    import random
    from string import ascii_letters, digits, punctuation


# Generated at 2022-06-23 20:55:04.600819
# Unit test for function romanize
def test_romanize():
    # English
    assert romanized('en')(lambda: 'Hello')() == 'Hello'

    # Russian
    assert romanized('ru')(lambda: 'привет')() == 'privet'

    # Ukranian
    assert romanized('uk')(lambda: 'привіт')() == 'pryvit'

    # Kazakh
    assert romanized('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-23 20:55:06.584432
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Алексей')() == 'Aleksey'

# Generated at 2022-06-23 20:55:10.349544
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda x: 'Привет')(locale='ru') == 'Priwet'
    assert romanize(locale='uk')(lambda x: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda x: 'Сәлем')() == 'Sälem'



# Generated at 2022-06-23 20:55:12.617530
# Unit test for function romanize
def test_romanize():
    @romanize('uk')
    def test_f(value):
        return value

    assert test_f('Ексземпляр') == 'Ekszempljar'

# Generated at 2022-06-23 20:55:17.639606
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize('ru')(lambda: 'Каждый хочет быть счастливым.')() == \
        'Kazhdyy khochet byt schastlivym.'

# Generated at 2022-06-23 20:55:24.784504
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import UkraineSpecProvider

    rp = RussiaSpecProvider(locale=Locale.RU)
    up = UkraineSpecProvider(locale=Locale.UK)

    @romanize(locale=Locale.RU)
    def get_rus_patronymic():
        return rp.patronymic()

    @romanize(locale=Locale.UK)
    def get_ukr_patronymic():
        return up.patronymic()

    assert isinstance(get_rus_patronymic(), str)
    assert isinstance(get_ukr_patronymic(), str)

# Generated at 2022-06-23 20:55:27.881491
# Unit test for function romanize
def test_romanize():
    r = romanized('ru')
    @r
    def foo():
        return 'Привет, МIЛОЧКА!'
    assert foo() == 'Privet, MILOCHKA!'

# Generated at 2022-06-23 20:55:37.768269
# Unit test for function romanize
def test_romanize():
    import sys
    import random

    if sys.version_info[:2] < (3, 3):  # pragma: no cover
        import mock   # noqa: F401

    @romanize(locale='ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Россия') == 'Rossiya'
    assert romanize_ru('Объединённые Штаты Америки') == 'Obyedinennye Shtaty Ameriki'

    @romanize(locale='uk')
    def romanize_uk(text):
        return text

    assert romanize_uk('Україна') == 'Ukrayina'

# Generated at 2022-06-23 20:55:46.793961
# Unit test for function romanize
def test_romanize():
    romanize_func = romanize()
    assert callable(romanize_func)

    @romanize_func
    def romanize_test():
        return 'Тест'
    # Should return 'Test'
    assert romanize_test() == 'Test'

    # Should raise an error, because there is no
    # romanization for this language.
    with romanized('unsupported'):
        @romanize
        def romanize_test():
            return 'Тест'
    assert romanize_test() == 'Тест'

# Generated at 2022-06-23 20:55:49.208963
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    assert 'Russia' == romanize('ru')(lambda: 'Россия')()

# Generated at 2022-06-23 20:55:55.112875
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanized('uk')(lambda: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanized('kk')(lambda: 'Сәлем, Дүние!')() == 'Säleм, Dünie!'



# Generated at 2022-06-23 20:56:02.916008
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus(cyrillic):
        return cyrillic

    assert rus('Восстановление пароля') == 'Vosstanovlenie parolja'

    @romanize(locale='uk')
    def ukr(cyrillic):
        return cyrillic

    assert ukr('Восстановлення паролю') == 'Vosstanovlennja parolju'

    @romanize(locale='kk')
    def kaz(cyrillic):
        return cyrillic


# Generated at 2022-06-23 20:56:06.776684
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(print)('Привет') == 'Privet'

    @romanize(locale='ru')
    def russian():
        return 'Привет'

    assert russian() == 'Privet'

# Generated at 2022-06-23 20:56:14.772207
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_word():
        return 'тест'
    assert get_word() == 'test'

    @romanize('uk')
    def get_word():
        return 'цицька'
    assert get_word() == 'cic’ka'

    @romanize('kk')
    def get_word():
        return 'барлық'
    assert get_word() == 'barlıq'

    @romanize('be')
    def get_word():
        return 'барлық'
    assert get_word() == 'barlıq'

    with pytest.raises(UnsupportedLocale):
        @romanize('test')
        def get_word():
            return 'test'
        get

# Generated at 2022-06-23 20:56:19.275585
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')().lower() == 'privet'
    assert romanize('uk')(lambda: 'Привіт')().lower() == 'pryvit'
    assert romanize('kk')(lambda: 'Сәлем')().lower() == 'salem'

# Generated at 2022-06-23 20:56:22.620752
# Unit test for function romanize
def test_romanize():
    def test_function():
        s = 'слово'
        return s

    test_function()
    test_function_rom = romanize()(test_function)
    assert test_function_rom() == 'slovo'

# Generated at 2022-06-23 20:56:24.072052
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привіт').lower() == 'pryvit'


# Generated at 2022-06-23 20:56:33.816224
# Unit test for function romanize
def test_romanize():
    def test_ru():
        @romanize('ru')
        def test(x):
            return x

        assert test('Украина') == 'Ukraina'
        assert test('Україна') == 'Ukrajina'
        assert test('Україна Київ Бровари') == 'Ukrajina Kyiv Brovary'
        assert test('Як дивитися серіал Україна має талант') == \
            'Yak divytysja serial Ukraina maie talant'

# Generated at 2022-06-23 20:56:42.380056
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'привет')() == 'privet'
    assert romanize()(lambda: 'привет мир')() == 'privet mir'
    assert romanize()(lambda: 'привет мир!')() == 'privet mir!'
    assert romanize()(lambda: 'привет мир! классно?')() == 'privet mir! klassno?'
    assert romanize()(lambda: 'привет мир! классно? 123')() == 'privet mir! klassno? 123'

# Generated at 2022-06-23 20:56:49.391405
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "Пока!")() == "Poka!"
    assert romanize('kk')(lambda: "Сәлем!")() == "Salem!"
    assert romanize('uk')(lambda: "Вітаю!")() == "Vitayu!"
    assert romanize('ja')(lambda: "Марш")() == "Марш"

# Generated at 2022-06-23 20:56:53.062273
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_text():
        return 'Привет мир'

    assert russian_text() == 'Privet mir'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:56:56.292969
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    r = RussiaSpecProvider()
 
    assert r.romanize(r.full_name()) == 'Ivanova Irina Aleksandrovna'

# Generated at 2022-06-23 20:56:59.635224
# Unit test for function romanize
def test_romanize():
    def romanized_foo():
        return 'Привет, мир!'

    romanized_foo = romanize('ru')(romanized_foo)
    assert romanized_foo() == 'Privet, mir!'

# Generated at 2022-06-23 20:57:01.893708
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('ru')(lambda: 'Прывет')() == 'Privyet'
    assert romanize('uk')(lambda: 'Привет')() == 'Pryvit'
    assert romanize('uk')(lambda: 'Прывет')() == 'Pyvyet'

# Generated at 2022-06-23 20:57:07.214587
# Unit test for function romanize
def test_romanize():
    assert romanized(locale="ru")(lambda: "Привет, Мир!")() == "Privet, Mir!"
    assert (romanized(locale="kk")(
        lambda: "Сөйлеу қажет жерлер салыстыру"))() == "Söileui qajet jerler " \
                                                      "salıstıru"
    assert romanized(locale="uk")(lambda: "Привіт!")() == "Pryvit!"

# Generated at 2022-06-23 20:57:16.262326
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'привет')() == 'privet'
    assert romanized('uk')(lambda: 'привіт')() == 'pryvit'
    assert romanized('kk')(lambda: 'привет')() == 'privet'

    assert romanized('kk')(lambda: 'привет')() == romanized('ru')(
        lambda: 'привет')(
    ) == romanized('uk')(lambda: 'привіт')()

# Generated at 2022-06-23 20:57:18.465803
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-23 20:57:19.579449
# Unit test for function romanize
def test_romanize():
    assert type(romanize) == type(romanize)
    assert type(romanized) == type(romanize)

# Generated at 2022-06-23 20:57:28.701336
# Unit test for function romanize
def test_romanize():
    import unittest

    class TestRomanize(unittest.TestCase):

        def setUp(self):
            self.obj = data.Person('en')

        def test_romanize(self):
            r = self.obj.full_name(romanize=True)
            self.assertIsInstance(r, str)
            self.assertEqual(len(r.split()), 2)

            r = self.obj.full_name(romanize=True, locale='ru')
            self.assertIsInstance(r, str)
            self.assertEqual(len(r.split()), 2)

    unittest.main()

# Generated at 2022-06-23 20:57:35.472844
# Unit test for function romanize
def test_romanize():
    text_cyrillic = "Привет мир, я твой покорный слуга штучного интеллекта"

    @romanize(locale="ru")
    def romanized_ru(value):
        return value

    @romanize(locale="uk")
    def romanized_uk(value):
        return value

    @romanize(locale="kk")
    def romanized_kk(value):
        return value

    rus = romanized_ru(text_cyrillic)
    uk = romanized_uk(text_cyrillic)
    kk = romanized_kk(text_cyrillic)

# Generated at 2022-06-23 20:57:42.810976
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.enums import DefaultEnum
    from mimesis.numbers import NumberGenerator

    assert romanize('')

    @romanize('uk')
    def f(n):
        gen = NumberGenerator()
        return gen.uuid4(DefaultEnum.ALPHANUMERIC, n)

    assert callable(f)

    with pytest.raises(UnsupportedLocale) as e:
        @romanize('foo')
        def f():
            return 'foo'
    assert str(e.value) == 'Locale "foo" is not supported'