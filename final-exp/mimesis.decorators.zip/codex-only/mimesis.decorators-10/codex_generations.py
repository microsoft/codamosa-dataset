

# Generated at 2022-06-23 20:47:46.419998
# Unit test for function romanize
def test_romanize():
    romanize_ru = romanize('ru')
    assert(romanize_ru)
    romanize_uk = romanize('uk')
    assert (romanize_uk)
    romanize_kk = romanize('kk')
    assert (romanize_kk)

# Generated at 2022-06-23 20:47:47.033897
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:47:51.468870
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'фыва'

    assert foo() == 'fыva'

    @romanize()
    def bar():
        return 'фыва'

    assert bar() == 'fыva'

# Generated at 2022-06-23 20:47:54.889705
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    @romanized('ru')
    def rus():
        return "Тестовая строка."

    assert rus() == 'Testovaya stroka.'

# Generated at 2022-06-23 20:48:00.880181
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    def foo(i, locale):
        @romanize(locale)
        def romanize_text(text):
            return text

        return romanize_text('Hello ' + i)

    assert foo('World', 'ru') == 'Gello Vorld'
    assert foo('World', 'uk') == 'Gello Vorld'
    assert foo('World', 'kk') == 'Gello Vorld'

# Generated at 2022-06-23 20:48:04.245561
# Unit test for function romanize
def test_romanize():
    result = romanize('uk')(lambda: 'Здоровенькі були?')()
    assert result == 'Zdoroven\'ki buly?'

# Generated at 2022-06-23 20:48:07.945404
# Unit test for function romanize
def test_romanize():
    @romanize('uk')
    def kk(s):  # and 'kk' will be added here
        return s

    assert kk('Вітаю, світе!') == 'Vitayu, svite!'

# Generated at 2022-06-23 20:48:11.771347
# Unit test for function romanize
def test_romanize():
    romanize_test = romanize('de')(lambda: 'Байхостан')
    assert romanize_test() == 'Baikhostan'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:48:14.641248
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize("ru")(lambda: 'Привет'), str)
    return True

# Generated at 2022-06-23 20:48:17.473450
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address
    addr = Address('ru')
    assert isinstance(addr.address(), str)
    assert isinstance(addr.country(), str)



# Generated at 2022-06-23 20:48:18.038431
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:48:21.652242
# Unit test for function romanize
def test_romanize():
    from mimesis.schema import Field
    from mimesis.enums import Gender

    @romanize(locale='ru')
    def my_func(field: Field) -> str:
        return field('person.full_name', gender=Gender.MALE)

    assert my_func(None) == 'Oleg Dostovalov'

# Generated at 2022-06-23 20:48:24.431910
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет Мир')() == 'privet Mir'



# Generated at 2022-06-23 20:48:33.631158
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет мир!') == "Privet mir!"
    assert romanize('ru')('Привет мир!') == "Privet mir!"
    assert romanize('uk')('Привіт світ!') == "Pryvit svit!"
    assert romanize('kk')('Сәлем әлем!') == "Sälem älem!"

    # Assert error for unsupport locale
    try:
        _ = romanize('zz')('Сәлем әлем!')
    except UnsupportedLocale:
        pass

# Generated at 2022-06-23 20:48:36.428838
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Мама мыла раму.')() == 'Mama myla ramu.'

# Generated at 2022-06-23 20:48:44.824543
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())
    assert called(romanized(locale='ru')(lambda: 'qwerty')) == 'qwerty'
    assert called(romanize(locale='ru')(lambda: 'я писал код')) == 'ya pisal kod'
    assert called(romanized(locale='uk')(lambda: 'погрози')) == 'pohrozy'
    assert called(romanize(locale='kk')(lambda: 'барлық ғимараттар')) == 'barlyq ƣimarattar'

# Generated at 2022-06-23 20:48:50.414199
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_text() -> str:
        return 'Привет, Мир!'

    text = get_text()
    assert text == 'Privyet, Mir!'

# Generated at 2022-06-23 20:48:53.668493
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_romanized():
        return 'луна, луна свети.'

    assert get_romanized() == 'luna, luna sveti.'



# Generated at 2022-06-23 20:49:01.868725
# Unit test for function romanize
def test_romanize():
    def romanize_locale(locale=''):
        @romanize(locale=locale)
        def romanize_func():
            return 'Какая-то строка на русском'
        return romanize_func

    assert romanize_locale(locale='ru')() == 'Kakaya-to stroka na russkom'
    assert romanize_locale(locale='uk')() == 'Kakaya-to stroka na russkom'
    assert romanize_locale(locale='kk')() == 'Kakaya-to stroka na russkom'

# Generated at 2022-06-23 20:49:13.038870
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ')() == 'ABCDEFEOZIJKLMNOPRSTUFXCCHSCHSYYEZIUYA'

# Generated at 2022-06-23 20:49:16.541499
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.lorem import Lorem

    l = Lorem('ru')

    assert ''.join(l.text(10).split(' ')).isalpha()
    assert ''.join(l.words(10)).isalpha()
    assert ''.join(l.sentences(10)).isalpha()
    assert ''.join(l.paragraphs(10)).isalpha()
    assert l.word()

# Generated at 2022-06-23 20:49:24.196293
# Unit test for function romanize
def test_romanize():
    """Test for function romanize"""
    romanized = romanize('ru')
    def test_romanize_deco(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            return result
        return wrapper

    test = test_romanize_deco(romanized('Абырвалг'))
    assert test == 'Abyrvalg'

# Generated at 2022-06-23 20:49:29.001835
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_data():
        return 'Привет, мир!'

    @romanize(locale='ru')
    def get_data_ru():
        return 'Как дела?'

    assert get_data() == 'Privet, mir!'
    assert get_data_ru() == 'Kak dela?'

# Generated at 2022-06-23 20:49:32.569478
# Unit test for function romanize
def test_romanize():
    def romanize_func(text: str) -> str:
        return text

    romanize_deco = romanize('ru')(romanize_func)
    assert romanize_deco('Привет') == 'Privet'

# Generated at 2022-06-23 20:49:37.822009
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    @romanize(Language.EN)
    def foo_bar():
        return 'Функция romanize() преобразовывает текст из кириллицы в латиницу'

    assert foo_bar() == 'Funktsiia romanize() preobrazovyvaet tekst iz kirillitsy v latinitsu'

# Generated at 2022-06-23 20:49:40.004492
# Unit test for function romanize
def test_romanize():
    @romanized()
    def generator(x):
        return x

    assert generator('Привет!') == 'Privet!'

# Generated at 2022-06-23 20:49:43.186359
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    from .. import Text
    text = Text('ru')

    assert text.romanize('Тестовая строка') \
        == 'Testovaya stroka'

# Generated at 2022-06-23 20:49:45.536280
# Unit test for function romanize
def test_romanize():
    try:
        from .abc import String

        @romanize(locale='uk')
        def r():
            return String().ukrainian()

        assert r()
    except ImportError:
        pass

# Generated at 2022-06-23 20:49:53.124705
# Unit test for function romanize
def test_romanize():
    """Romanize the cyrillic text.

    Transliterate the cyrillic script into the latin alphabet.

    .. note:: At this moment it works only for `ru`, `uk`, `kk`.

    :param locale: Locale code.
    :return: Romanized text.
    """


# Generated at 2022-06-23 20:50:02.650918
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.personal import Personal

    personal = Personal('ru')
    assert isinstance(personal.full_name(gender=Gender.FEMALE), str)
    assert isinstance(personal.full_name(gender=Gender.MALE), str)

    personal = Personal('uk')
    assert isinstance(personal.full_name(gender=Gender.FEMALE), str)
    assert isinstance(personal.full_name(gender=Gender.MALE), str)

    personal = Personal('kk')
    assert isinstance(personal.full_name(gender=Gender.FEMALE), str)
    assert isinstance(personal.full_name(gender=Gender.MALE), str)



# Generated at 2022-06-23 20:50:12.395767
# Unit test for function romanize
def test_romanize():
    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT['ru'],
        **data.COMMON_LETTERS,
    })

    text = 'Говорит мне душа: "Я, без умолку, 117 лет,\n'\
        'Просто начал я этот спор о вечности.'
    translation = text.translate(alphabet)


# Generated at 2022-06-23 20:50:12.943487
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:50:14.496583
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:50:20.917077
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins
    text1 = mimesis.builtins.CyrillicWord(locale='ru')()
    text2 = mimesis.builtins.CyrillicWord(locale='uk')()
    text3 = mimesis.builtins.CyrillicWord(locale='kk')()
    text4 = mimesis.builtins.CyrillicWord(locale='en')()
    assert isinstance(text1, str)
    assert isinstance(text2, str)
    assert isinstance(text3, str)
    assert isinstance(text4, str)

# Generated at 2022-06-23 20:50:26.090659
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    alp = ascii_letters + digits + punctuation
    romanization = {
        **data.ROMANIZATION_DICT['ru'],
        **data.COMMON_LETTERS,
    }

    @romanize(locale='ru')
    def _text_generator():
        text = 'Ах да я счастливчик!'
        return text

    for char in _text_generator():
        assert (char in alp or char in romanization)

    assert _text_generator() == 'Ah da ja schastlivchik!'



# Generated at 2022-06-23 20:50:27.933008
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda: 'Будинок')() == 'Budynok'

# Generated at 2022-06-23 20:50:39.266626
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Localization
    from mimesis.providers.person import Person

    p = Person(Localization.ENGLISH)
    assert p.name() == 'Sokrates Berger'

    txt = p.romanize(p.name())
    assert txt == 'Sokrates Berger'

    p = Person(Localization.RUSSIAN)
    assert p.name() == 'Владилен Кузьмин'

    txt = p.romanize(p.name())
    assert txt == 'Vladilen Kuzmin'

    p = Person(Localization.UKRAINIAN)
    assert p.name() == 'Ігнат Журавль'


# Generated at 2022-06-23 20:50:40.687279
# Unit test for function romanize
def test_romanize():
    assert romanize()('Отчим') == 'Otchim'

# Generated at 2022-06-23 20:50:50.068348
# Unit test for function romanize
def test_romanize():
    @romanize(locale='kk')
    def test(self):
        return 'Алтын түрлі біріккендері'

    assert 'Aldyn turlı birikkenderi' == test(True)

    @romanize(locale='ru')
    def test(self):
        return 'Алтын түрлі біріккендері'

    assert 'Alyin turli birikkenderi' == test(True)

    @romanize(locale='uk')
    def test(self):
        return 'Алтын түрлі біріккендері'



# Generated at 2022-06-23 20:50:51.802697
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, Мир!') == 'Privyet, Mir!'

# Generated at 2022-06-23 20:50:55.976877
# Unit test for function romanize
def test_romanize():
    result = {'ru': 'привет', 'kk': 'Сәлем', 'uk': 'Салам'}
    for lc in result.keys():
        assert romanize(lc)(lambda: result[lc])() == 'privet'

# Generated at 2022-06-23 20:50:58.397679
# Unit test for function romanize
def test_romanize():
    fake = Fake('ru')

    txt = fake.romanized.text()
    assert txt

# Generated at 2022-06-23 20:50:58.959452
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:51:01.870921
# Unit test for function romanize
def test_romanize():
    romanized_text = romanized('ru')(lambda: 'Привет, мир!')
    assert romanized_text() == 'Privet, mir!'

# Generated at 2022-06-23 20:51:04.674280
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')().lower() == 'privet'



# Generated at 2022-06-23 20:51:07.221471
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Привет, Мир!'

    assert foo() == 'Privet, Mir!'

# Generated at 2022-06-23 20:51:14.152585
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    @romanized('uk')
    def romanize_uk(text: str) -> str:
        return text

    assert romanize_uk('Тест') == 'Test'

    @romanize('ru')
    def romanize_ru(text: str) -> str:
        return text

    assert romanize_ru('Тест') == 'Test'



# Generated at 2022-06-23 20:51:24.110247
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address
    from mimesis.providers.names import Names

    @romanize('ru')
    def get_ru_name(fullname: bool = False) -> str:
        name = Names('ru')
        if fullname:
            return name.full_name()
        return name.last_name()

    @romanize('uk')
    def get_ukr_name(fullname: bool = False) -> str:
        name = Names('uk')
        if fullname:
            return name.full_name()
        return name.last_name()

    @romanize('kk')
    def get_kk_name(fullname: bool = False) -> str:
        name = Names('kk')
        if fullname:
            return name.full_name()

# Generated at 2022-06-23 20:51:28.694691
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.unit_test import UnitTest

    ut = UnitTest()
    assert ut._romanize_text('Вогню над Берліном') == 'Vognyu nad Berlinom'

# Generated at 2022-06-23 20:51:31.654441
# Unit test for function romanize
def test_romanize():
    def f(r): return r

    g = romanize()(f)
    h = g('Привет, мир!')
    assert h == 'privet, mir!'

# Generated at 2022-06-23 20:51:39.437652
# Unit test for function romanize
def test_romanize():
    alphabet = {s: c for c, s in enumerate(ascii_letters)}

# Generated at 2022-06-23 20:51:49.746629
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    from mimesis.enums import Language
    from mimesis.providers import BaseProvider
    from mimesis.providers.text import Text as TextProvider

    class Romanizer(TextProvider):
        @romanized()
        def romanized_text(self) -> str:
            return self.text(4, 255)

    class Romanian(BaseProvider):
        @romanize(Language.ROMANIAN)
        def romanian_alphabet(self) -> str:
            return self.text(10)

    romanizer = Romanizer(Language.RUSSIAN)
    romanian = Romanian()

    # Russian
    assert romanizer.romanized_text() != romanizer.text(255)

    # Romanian
    assert romanian.romanian_alph

# Generated at 2022-06-23 20:51:55.949939
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    from mimesis.builtins.integers import Integer
    from mimesis.builtins.words import Words

    i = Integer(10, 20)
    words = Words('ru')
    text = words.text(quantity=i.random())

    assert ''.join([words.get_alphabet_item() for _ in range(30)]) != \
        romanize('ru')(lambda: text)()

# Generated at 2022-06-23 20:52:02.108876
# Unit test for function romanize
def test_romanize():
    assert romanize()('Буль-буль') == 'Bulʹ-bulʹ'
    assert romanize(locale='uk')('Буль-буль') == 'Bulʹ-bulʹ'
    assert romanize(locale='kk')('Буль-буль') == 'Bulʹ-bulʹ'

# Generated at 2022-06-23 20:52:07.007267
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет!')() == 'Privet!'
    assert romanize('uk')(lambda: 'Привіт!')() == 'Privit!'
    assert romanize('kk')(lambda: 'Сәлем!')() == 'Salem!'

# Generated at 2022-06-23 20:52:11.260724
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.person import Person
    russian = RussiaSpecProvider()
    person = Person(locale=russian.locale, provider=russian)
    name = person.full_name()
    assert all([i in ascii_letters for i in name])

# Generated at 2022-06-23 20:52:14.293546
# Unit test for function romanize
def test_romanize():
    res = "Mozhno li ne tak?"
    text = u"Можно ли не так?"

    assert romanize("ru")(lambda: text)() == res

# Generated at 2022-06-23 20:52:16.740223
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет!')() == 'Privyet!'

# Generated at 2022-06-23 20:52:22.382366
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')('привет')() == 'privet'
    assert romanize(locale='ru')('привет')() == 'privet'
    assert romanize(locale='ru')('привет')() == 'privet'
    assert romanize(locale='ru')('Привет')() == 'Privet'
    assert romanize(locale='ru')('Строка привет')() == 'Stroka privet'
    assert romanize(locale='ru')('Габриэль')() == 'Gabriel'

# Generated at 2022-06-23 20:52:23.759370
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru') # Noqa: S101

# Generated at 2022-06-23 20:52:29.456646
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedLocale
    ru = RussiaSpecProvider()
    ru_feminine_name = ru.person.name(gender=Gender.FEMALE)
    assert ru_feminine_name != ru.romanize(ru_feminine_name)
    try:
        ru.romanize(ru_feminine_name, locale='de')
    except UnsupportedLocale:
        pass
    else:
        assert False



# Generated at 2022-06-23 20:52:31.960110
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'привет') == 'privet'

# Generated at 2022-06-23 20:52:33.573851
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize('')



# Generated at 2022-06-23 20:52:42.836945
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')
    assert p.full_name(Gender.FEMALE) == 'Александра Бабикова'
    assert (p.full_name(Gender.FEMALE, romanized='ru')
            == 'Aleksandra Babikova')

    p = Person('uk')
    assert p.full_name(Gender.MALE, romanized='uk') == 'Сергій Горбунов'

# Generated at 2022-06-23 20:52:49.603902
# Unit test for function romanize
def test_romanize():
    ''' test romanize function '''
    @romanize(locale='uk')
    def get_random_uk_name():
        return 'Яни Семенович Шевченко'

    romanized_string = get_random_uk_name()
    assert romanized_string == 'Yanı Semenovıh Shevchenko'



# Generated at 2022-06-23 20:52:55.456570
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    import mimesis.enums
    from mimesis.builtins.cyrillic import CyrillicText

    @romanize(mimesis.enums.Language.RUSSIAN)
    def some_function(value: str) -> str:
        return value

    ct = CyrillicText(language=mimesis.enums.Language.RUSSIAN)
    result = ct.text(10)
    assert result != some_function(result)

# Generated at 2022-06-23 20:52:57.485876
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир')() == 'Privet mir'

# Generated at 2022-06-23 20:53:08.862809
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: "АБВГД")() == "ABVGD"
    assert romanized('ru')(lambda: "А Б В Г Д")() == "A B V G D"

    assert romanized('uk')(lambda: "АБВГД")() == "ABVGD"
    assert romanized('uk')(lambda: "А Б В Г Д")() == "A B V G D"

    assert romanized('kk')(lambda: "АБВГД")() == "ABVGD"
    assert romanized('kk')(lambda: "А Б В Г Д")() == "A B V G D"

    # Invalid locale code
   

# Generated at 2022-06-23 20:53:11.131567
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет, мир!')() == \
           'Privet, mir!'

# Generated at 2022-06-23 20:53:17.342979
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.builtins import RussianSpecProvider
    from mimesis.providers.name import Name

    r = RussianSpecProvider(Language.RUSSIAN)
    n = Name(Language.RUSSIAN)

    assert r.romanized(r.full_name()) == n.full_name()
    assert r.romanized(r.patronymic()) == n.patronymic()
    assert r.romanized(r.surname()) == n.surname()
    assert r.romanized(r.first_name()) == n.first_name()

# Generated at 2022-06-23 20:53:24.731296
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import Person
    from mimesis.providers.misc import Misc
    from mimesis.enums import Gender
    p = Person('ru')
    m = Misc('ru')
    assert p.name(Gender.FEMALE) == 'Алла Казакова'
    assert m.romanize(p.name(Gender.MALE)) == 'Vladimir Petrov'

# Generated at 2022-06-23 20:53:28.751570
# Unit test for function romanize
def test_romanize():
    assert romanize()('Форма налогоплательщиков') == 'Forma nalogoplatelshikov'

# Generated at 2022-06-23 20:53:34.025189
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda: 'ғафу етіңіздер')() == 'ğafw etingizder'

# Generated at 2022-06-23 20:53:35.369038
# Unit test for function romanize
def test_romanize():
    assert romanize()('Тест') == 'Test'



# Generated at 2022-06-23 20:53:36.928808
# Unit test for function romanize
def test_romanize():
    assert romanized()('сорре') == 'sorre'

# Generated at 2022-06-23 20:53:37.310667
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:53:39.769852
# Unit test for function romanize
def test_romanize():
    def test_function(locale):
        return 'Привет'

    romanized_test_function = romanize(locale='ru')(test_function)
    assert romanized_test_function('ru') == 'Privet'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:53:45.434142
# Unit test for function romanize
def test_romanize():
    assert romanize
    assert romanize(locale='ru')
    assert romanized
    assert romanized(locale='ru')

    # For backward compatibility
    def dummy():
        return 'test'

    romanized(dummy)
    assert dummy.__name__ == 'dummy'
    assert dummy.__doc__ == 'test'

# Generated at 2022-06-23 20:53:50.902461
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'

# Generated at 2022-06-23 20:53:52.809440
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')

# Generated at 2022-06-23 20:53:58.399023
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет, Мир!') == 'Privet, Mir!'
    assert romanized()('Привіт, Мір!') == 'Pryvit, Mir!'
    assert romanized()('Привет, Мир! Привіт, Мір!') == \
        'Privet, Mir! Pryvit, Mir!'



# Generated at 2022-06-23 20:54:07.394042
# Unit test for function romanize
def test_romanize():
    orig_text = 'в предутреннем тумане полз собака под колеса'
    romanized_text = 'v predutrennem tumane polz sobaka pod kolesa'
    assert romanize()(lambda: orig_text)() == romanized_text
    # The same but with the old name (deprecated)
    assert romanized()(lambda: orig_text)() == romanized_text

# Generated at 2022-06-23 20:54:17.959776
# Unit test for function romanize

# Generated at 2022-06-23 20:54:25.532522
# Unit test for function romanize
def test_romanize():
    # tests for romanized string
    from mimesis import Person

    p = Person('uk')
    p.personal.last_name_male()
    p.personal.last_name_female()
    p.personal.last_name()
    p.personal.full_name()

    p = Person('ru')
    p.personal.last_name_male()
    p.personal.last_name_female()
    p.personal.last_name()
    p.personal.full_name()

    p = Person('kk')
    p.personal.last_name_male()
    p.personal.last_name_female()
    p.personal.last_name()
    p.personal.full_name()

# Generated at 2022-06-23 20:54:32.475218
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize(locale='uk')(lambda: 'як'), Callable)
    assert romanize(locale='uk')(lambda: 'як')() == 'yak'
    assert romanize(locale='uk')(lambda: 'привіт')() == 'pryvit'
    assert romanize(locale='uk')(lambda: 'З чого почати?')() == 'Z choho pochaty?'

# Generated at 2022-06-23 20:54:41.978420
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Вася Петя')() == 'Vasya Pyotya'
    assert romanize('ru')(lambda: 'ЛОМАТЬ ВСЕ')() == 'LOMAT VSE'
    assert romanize('kk')(lambda: 'ЛОМАТЬ ВСЕ')() == 'LOMAT VSE'
    assert romanize('uk')(lambda: 'ЛОМАТЬ ВСЕ')() == 'LOMAT VSE'

# Generated at 2022-06-23 20:54:45.664924
# Unit test for function romanize
def test_romanize():
    func = romanized(locale='ru')(lambda x: "Привет")
    assert func == 'Privet'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:54:51.473775
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def romanizer(text: str) -> str:
        return text

    assert romanizer('Русский') == 'Russkiy'
    assert romanizer('Українська') == 'Ukrayins\'ka'
    assert romanizer('Қазақша') == 'Qazaqşa'

# Generated at 2022-06-23 20:54:55.804892
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanized('ru')(lambda: 'Привет Мир')() == 'Privet Mir'
    assert romanized('uk')(lambda: 'Привіт Світ')() == 'Pryvit Svit'
    assert romanized('kk')(lambda: 'Сәлем Дүние')() == 'Sälem Dünie'

# Generated at 2022-06-23 20:55:04.456710
# Unit test for function romanize
def test_romanize():
    _rus = 'Привет'
    _eng = 'Privet'
    _ukr = 'Привіт'
    _kaz = 'Сәлем'
    _rus_alpha = 'Привет, Как дела?'
    _ukr_alpha = 'Привіт, Як справи?'
    _kaz_alpha = 'Сәлем, Көріңіздер?'

    @romanized('ru')
    def rus():
        return _rus

    assert rus() == _eng

    @romanized('uk')
    def ukr():
        return _ukr


# Generated at 2022-06-23 20:55:10.548785
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian() -> str:
        return 'Хээж бүү хүндэтгэгчдээсээ хамааран бай!'

    assert russian() == 'Hehezh buu khundetgegdeesee khamaaran bai!'


# Generated at 2022-06-23 20:55:17.323142
# Unit test for function romanize
def test_romanize():
    assert romanize('ru_RU')(lambda: 'Сидоров')() == 'Sidorov'
    assert romanize('ru_RU')(lambda: 'Михайлов')() == 'Mikhaĭlov'
    assert romanize('uk_UA')(lambda: 'Василь')() == 'Vasylʹ'
    assert romanize('uk_UA')(lambda: 'Віталій')() == 'Vitalij'
    assert romanize('kk_KZ')(lambda: 'Абай')() == 'Abaj'
    assert romanize('kk_KZ')(lambda: 'Даулет')() == 'Daýlet'

# Generated at 2022-06-23 20:55:21.466620
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_title() -> str:
        return 'Философия духовной личности'  # noqa: W605

    assert russian_title() == 'Filosofia dukhovnoi lichnosti'

# Generated at 2022-06-23 20:55:29.091349
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.builtins import Address

    a = Address(Locale.ENGLISH)
    assert a.state() in data.STATES[Locale.ENGLISH]

    a_ru = Address(Locale.RUSSIAN)
    assert a_ru.state() in data.STATES[Locale.RUSSIAN]
    assert a_ru.romanized_state() in data.STATES[Locale.ENGLISH]

# Generated at 2022-06-23 20:55:38.215346
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanized('ru')('Василий') == 'Vasiliy'
    assert romanized('ru')('Василий1!') == 'Vasiliy1!'
    assert romanized('uk')('Василій') == 'Vasiliy'
    assert romanized('kk')('Жасқан') == 'Zhasqan'
    assert romanized('kk')('Жасқа́н') == 'Zhasqán'
    assert romanized('ru')('Василий0') == 'Vasiliy0'

# Generated at 2022-06-23 20:55:48.941685
# Unit test for function romanize
def test_romanize():
    from hypothesis import strategies as st
    from hypothesis import given

    from . import ui
    from . import ru, uk, kk
    from . import en, de, es, it, fr, pt, nl, sk
    from . import ja, zh
    from . import hy, vi, km, fa

    @given(st.text())
    def test_ru(text):
        assert ru.Address.street_suffix(text) == \
            ru.Address.street_suffix(text)


    @given(st.text())
    def test_uk(text):
        assert uk.Address.street_suffix(text) == \
            uk.Address.street_suffix(text)


    @given(st.text())
    def test_kk(text):
        assert kk.Address.street

# Generated at 2022-06-23 20:55:52.556952
# Unit test for function romanize
def test_romanize():
    """Test romanize function.
    """
    @romanize(locale='ru')
    def roman(value):
        return value

    assert callable(roman)
    assert roman('Привет') == 'Privet'


# Unit tests for decorator romanize

# Generated at 2022-06-23 20:55:55.926796
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""

    @romanize()
    def roman_wrapper():
        return 'Привет, Мир!'

    assert roman_wrapper() == 'Privet, Mir!'

# Generated at 2022-06-23 20:55:58.254655
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text as text_
    assert text_.Text().romanize() != ''
    assert text_.Text(locale='en').romanize() == ''

# Generated at 2022-06-23 20:56:02.782143
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locality
    from mimesis.providers.address import Address
    address = Address(locale=Locality.UKRAINIAN)
    assert address.city() == address.romanized_city()

# Generated at 2022-06-23 20:56:04.898166
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(_romanize_test_func)('Пример') == 'Primer'



# Generated at 2022-06-23 20:56:06.874092
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.words import Word
    word = Word('ru')

    @romanized('ru')
    def romanized(word):
        return word.word()

    assert romanized('он') == 'on'

# Generated at 2022-06-23 20:56:18.047937
# Unit test for function romanize

# Generated at 2022-06-23 20:56:23.398963
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Проверка')().isalpha()
    assert romanized(locale='uk')(lambda: 'Перевірка')().isalpha()
    assert romanized(locale='kk')(lambda: 'Текст')().isalpha()

# Generated at 2022-06-23 20:56:27.101700
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет!')() == 'Privet!'

# Generated at 2022-06-23 20:56:29.687342
# Unit test for function romanize
def test_romanize():
    assert romanize()('Спасибо') == 'Spasibo'

if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-23 20:56:40.657336
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus(cyrillic: str) -> str:
        return cyrillic

    # From:
    # https://en.wikipedia.org/wiki/Transliteration_of_Cyrillic_characters_into_Latin_characters
    example = ('Привет, мир! На берегу безымянного пруда '
               'Стоял он, внимая и слушая далекий звон '
               'Серебряных куполов.')
    assert rus(example)

# Generated at 2022-06-23 20:56:46.235402
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    from mimesis.builtins import RussiaSpecProvider

    r = RussiaSpecProvider('ru')

    @romanize('ru')
    def foo():
        return r.code.ssn()

    assert foo() == '040818135225'

# Generated at 2022-06-23 20:56:50.211965
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'
    assert romanize()(lambda: 'Всем привет')() == 'Vsem privet'

# Generated at 2022-06-23 20:56:52.231015
# Unit test for function romanize
def test_romanize():
    @romanize('en')
    def foo():
        return 'Привет!'

    assert foo() == 'Privet!'



# Generated at 2022-06-23 20:56:59.385590
# Unit test for function romanize
def test_romanize():
    r = romanized()
    assert r('Привет, мир!') == 'Privet, mir!'

    r = romanize(locale='en')
    assert r('Привет, мир!') == 'Privet, mir!'

    try:
        r = romanize(locale='foo')
        r('Привет, мир!')
    except UnsupportedLocale:
        pass

# Generated at 2022-06-23 20:57:03.359117
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    rp = RussianSpecProvider(locale='ru')
    assert rp.romanize('Строка с русским текстом', ' ') == \
           'Stroka s russkim tekstom'



# Generated at 2022-06-23 20:57:06.095078
# Unit test for function romanize
def test_romanize():
    romanize_data = romanize('ru')

    @romanize_data
    def wrapper():
        return 'Привет Мир'

    assert wrapper() == 'Privet Mir'

# Generated at 2022-06-23 20:57:15.712319
# Unit test for function romanize
def test_romanize():
    """Test ``romanize`` function."""
    alphabet = \
        'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЫЭЮЯ'
    alphabet += alphabet.lower() + 'ЬЪ'
    answer = "".join([data.ROMANIZATION_DICT["ru"][i] for i in alphabet])
    answer += 'ЬЪ'
    assert romanize('ru')(lambda: alphabet)() == answer

# Generated at 2022-06-23 20:57:18.972499
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')(lambda: 'Басты бет')() == 'Bastı bet'

# Generated at 2022-06-23 20:57:26.112106
# Unit test for function romanize
def test_romanize():
    # Example tests for romanize
    assert romanize(locale='ru')(lambda: 'Пример')() == 'Primer'
    assert romanize(locale='uk')(lambda: 'Приклад')() == 'Priklad'
    assert romanize(locale='kk')(lambda: 'Дәйек')() == 'Däyek'



# Generated at 2022-06-23 20:57:27.045706
# Unit test for function romanize
def test_romanize():
    assert romanize == romanized

# Generated at 2022-06-23 20:57:28.616088
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Привет") == "Privet"

# Generated at 2022-06-23 20:57:31.286806
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    person = Person('en')
    ru = 'Привет, Мир!'
    expected = 'Privet, Mir!'

    assert person._romanize(ru, 'ru') == expected

# Generated at 2022-06-23 20:57:36.477121
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.geography import Geography

    geo = Geography()
    assert geo.address() == 'Ukraine, Kharkov, Никитин переулок, 3/2, 34'
    romanized_geo = Geography(locale=Geography.RU, romanized=True)
    assert romanized_geo.address() == \
        'Ukraine, Kharkov, Nikitin pereulok, 3/2, 34'

    try:
        Geography(locale='xx', romanized=True)
    except UnsupportedLocale:
        assert True
    else:
        raise UnsupportedLocale

# Generated at 2022-06-23 20:57:40.858882
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func(text: str) -> str:
        return text

    text = 'Привет, как дела?'
    romanized_str = func(text)
    assert romanized_str == 'Privet, kak dela?'



# Generated at 2022-06-23 20:57:49.834967
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    from mimesis.builtins import RussiaSpecProvider

    class RomanizedRussiaSpecProvider(RussiaSpecProvider):
        @romanize('ru')
        def name(self):
            return self.__name

        @romanize('ru')
        def surname(self):
            return super().surname()

        @romanize('ru')
        def initials(self):
            return super().initials()

        @romanize('ru')
        def patronymic(self):
            return super().patronymic()

        @romanize('ru')
        def full_name(self):
            return super().full_name()

        @romanize('ru')
        def address(self, with_street=False, with_building=False,
                    with_apartment=False):
            return super