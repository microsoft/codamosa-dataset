

# Generated at 2022-06-23 20:47:44.841398
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    @romanized('ru')
    def romanize_test():
        return RussianSpecProvider._data['names_male'][0]

    assert romanize_test() == 'Konstantin'

# Generated at 2022-06-23 20:47:47.467260
# Unit test for function romanize
def test_romanize():
    @romanize('uk')
    def get_word(word: str) -> str:
        return word

    assert get_word('Тест') == 'Test'

# Generated at 2022-06-23 20:47:57.761606
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import SpecialChars

    def romanize_func(locale: str = 'ru'):
        from mimesis.builtins.numbers import Numbers
        return Numbers(locale).random(as_string=True)

    @romanize(locale='ru')
    def romanize_func_decorator(locale: str = 'ru'):
        from mimesis.builtins.numbers import Numbers
        return Numbers(locale).random(as_string=True)

    encoded_result = romanize_func()
    decoded_result = romanize_func_decorator()
    assert encoded_result == decoded_result

    result = decoded_result

    # Check length
    assert isinstance(result, str)
    assert len(result) >= 1

    # Check

# Generated at 2022-06-23 20:48:01.459803
# Unit test for function romanize
def test_romanize():
    decorator = romanize()
    function = decorator(lambda: 'Привет, Мир!')
    text = function()
    assert text == 'Privet, Mir!'



# Generated at 2022-06-23 20:48:05.921695
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def ru():
        return 'строка'

    @romanized('uk')
    def uk():
        return 'строка'

    @romanized('kk')
    def kk():
        return 'строка'

    assert ru() == 'stroka'
    assert uk() == 'stroka'
    assert kk() == 'stroq`a'

# Generated at 2022-06-23 20:48:09.763823
# Unit test for function romanize
def test_romanize():
    _romanized = romanize('ru')
    txt = _romanized(lambda: 'Кот поймал рыбку')
    print(txt)
    assert txt == 'Kot pojmal rybku'

# Generated at 2022-06-23 20:48:15.402129
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis import Person
    p_ru = Person(Locale.RU)
    assert p_ru.full_name().lower() == \
        romanized(locale=Locale.RU)(p_ru.full_name).lower()

    # this one is not working at this moment
    try:
        romanized(locale='bla-bla')(p_ru.full_name)
    except UnsupportedLocale:
        pass

# Generated at 2022-06-23 20:48:18.281106
# Unit test for function romanize
def test_romanize():
    @romanize()
    def get_test():
        return "Конец света"
    t = get_test()
    assert t == 'Konets sveta'



# Generated at 2022-06-23 20:48:21.004846
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize('ru')(lambda: "Тест")() == 'Test'
    assert romanize('ru')((lambda: "Тест"))() == 'Test'

# Generated at 2022-06-23 20:48:28.541760
# Unit test for function romanize
def test_romanize():
    """Test Romanize function."""
    import mimesis.defaults
    class A(mimesis.defaults.Fake):
        def b(self, *args, **kwargs):
            return "Hello, мой друг!"
    a = A()
    assert isinstance(a.b, str) and a.b() == 'Hello, мой друг!'
    assert isinstance(a.romanized.b(), str) and \
           a.romanized.b() == 'Hello, moi drug!'



# Generated at 2022-06-23 20:48:35.355801
# Unit test for function romanize
def test_romanize():
    """Test romanize function.
    """
    locs = ['ru', 'uk', 'kk']
    sls = ['слово', 'Слово', 'ЛОБОС', 'кіт']
    res = ['slovo', 'Slovo', 'LOBOS', 'kit']
    for i, sl in enumerate(sls):
        for l in locs:
            r = romanize(l)(lambda: sl)
            assert r == res[i]
    r = romanize('fr')(lambda: 'Nothing')
    assert r == 'Nothing'

# Generated at 2022-06-23 20:48:41.582845
# Unit test for function romanize
def test_romanize():
    @romanize(locale='en')
    def foo(x: str) -> str:
        return x

    @romanize(locale='ru')
    def bar(x: str) -> str:
        return x

    assert foo('123') == '123'
    assert foo('Алгоритмы') == 'Algoritmy'
    assert bar('Алгоритмы') == 'Algoritmy'

# Generated at 2022-06-23 20:48:49.913225
# Unit test for function romanize
def test_romanize():
    """Romanize should romanize the cyrillic words."""
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    class TestRomanize(object):
        """Test romanize decorator."""

        def __init__(self, locale: str = ''):
            """Initialize attributes."""
            self.text = Text(locale=locale)

        @romanized(locale=Locale.RUSSIAN)
        def __romanizer(self):
            """Get romanized text."""
            return self.text.word()

    test_case = TestRomanize(locale=Locale.RUSSIAN)
    assert test_case._TestRomanize__romanizer() != ''

# Generated at 2022-06-23 20:48:50.885985
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()

# Generated at 2022-06-23 20:48:59.719434
# Unit test for function romanize

# Generated at 2022-06-23 20:49:04.222068
# Unit test for function romanize
def test_romanize():
    func = lambda i: i
    romanized_func = romanize('ru')(func)

    assert 'rick' == romanized_func('рик') == romanized(func)()
    assert 'rick y morty' == romanized_func('рик и морти') == romanized(func)()

# Generated at 2022-06-23 20:49:12.230924
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    rsp = RussiaSpecProvider()

    assert rsp.romanize(rsp.city()) == 'moskva'
    assert rsp.romanize(rsp.region()) == 'rossiiskaya-federatsiya'
    assert rsp.romanize(rsp.vehicle_code()) == 'x-999-xx'
    assert rsp.romanize(rsp.personal_code()) == '0000000000'
    assert rsp.romanize(rsp.name()) == 'ivanov-ivan'

# Generated at 2022-06-23 20:49:15.476640
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    from mimesis.builtins import UkrainianSpecProvider

    @romanize('uk')
    def r_text(random) -> str:
        r = UkrainianSpecProvider(random)
        return r.text(quantity=10)

    assert isinstance(r_text(random=None), str)

# Generated at 2022-06-23 20:49:16.378947
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)

# Generated at 2022-06-23 20:49:21.631414
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_cyrillic_text():
        return 'Привет, сука блять!'

    assert get_cyrillic_text() == 'Privet, suka bliat!'

# Generated at 2022-06-23 20:49:27.480253
# Unit test for function romanize
def test_romanize():
    assert romanize()('Как пройти тесты?') == 'Kak projti testy?'

    @romanize(locale='uk')
    def api(self):
        return 'Валіза для продажу найякісніша!'

    assert api(None) == 'Valiza dlia prodazhu naïiakіsnіsha!'

# Generated at 2022-06-23 20:49:28.677347
# Unit test for function romanize
def test_romanize():
    assert True


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:49:31.635776
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    from mimesis import Generic
    from mimesis.localization import get_current_locale

    locales = ['ru', 'uk', 'kk']
    for loc in locales:
        gen = Generic('ru')
        gen._locale.code = loc
        gen.seed(1)
        assert all([x in ascii_letters + digits for x in gen.romanize()])

# Generated at 2022-06-23 20:49:34.063039
# Unit test for function romanize
def test_romanize():
    # TypeError: romanize() missing 1 required positional argument: 'func'
    def test_func():
        pass

    romanize()(test_func)()


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:49:43.435852
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Что-то на русском языке.')() == 'CHto-to na russkom yazyke.'
    assert romanized('uk')(lambda: 'Щось на українській мові.')() == 'SHChos na ukrajinskiy movi.'
    assert romanized('kk')(lambda: "Нешін қазақ тілінде.")() == 'Neshin qazaq tilinde.'

# Generated at 2022-06-23 20:49:45.766235
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.datetime import Datetime

    dt = Datetime(Locale.RU)
    dt.datetime()

# Generated at 2022-06-23 20:49:50.234083
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locales
    from mimesis.random import Random
    from mimesis.providers.person import Person

    p = Person(Locales.UK)
    r = Random()

    result = r.choice(p.full_name() for _ in range(10_000))
    assert len(result) > 0

# Generated at 2022-06-23 20:49:56.350183
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import RussianSpecProvider

    rs = RussianSpecProvider('ru')
    text = rs.personal.full_name()
    romanized_text = romanized('ru')(text)
    assert romanized_text == romanize('ru')(text)

# Generated at 2022-06-23 20:49:59.616624
# Unit test for function romanize
def test_romanize():
    def func(**kwargs):
        @romanize(**kwargs)
        def wrapper(self, **kwargs):
            return self.seed.get_random_byte(100)

        return wrapper

    assert hasattr(func(), '__name__')

# Generated at 2022-06-23 20:50:00.471676
# Unit test for function romanize
def test_romanize():
    try:
        romanize()
    except TypeError:
        pass

# Generated at 2022-06-23 20:50:02.207365
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize(locale="en")
    romanize(locale='es')

# Generated at 2022-06-23 20:50:11.166046
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanized('kk')(lambda: 'Мен сені сәлем деп тіркелдім')() \
        == 'Men seni salem dep tirlidim'
    assert romanized('ru')(lambda: 'Привет!')() == 'Privet!'
    assert romanized('uk')(lambda: 'Привіт!')() == 'Pryvit!'

# Generated at 2022-06-23 20:50:19.694969
# Unit test for function romanize
def test_romanize():
    from unittest import TestCase, mock

    class TestRomanization(TestCase):

        @mock.patch('mimesis.decorators.data')
        def test_romanize(self, mock_data):
            mock_data.ROMANIZATION_DICT = {
                'ru': {'le': 'le', 'hab': 'hab'},
                'uk': {'mo': 'mo', 'hab': 'hab'},
                'kk': {'у': 'u', 'hab': 'hab'}
            }
            mock_data.COMMON_LETTERS = {'hab': 'hab'}

            @romanize('ru')
            def r_text():
                return 'le hab'

            @romanize('uk')
            def r_text2():
                return 'mo hab'


# Generated at 2022-06-23 20:50:21.773276
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def foo():
        return 'Привет, Мир!'

    assert foo() == 'Privet, Mir!'



# Generated at 2022-06-23 20:50:27.145614
# Unit test for function romanize
def test_romanize():
    r = romanize('ru')

    @r
    def bar():
        return "Абвгдежзийклмнопрстуфхцчшщъыьэюя"

    assert bar() == 'Abvgdezhzijklmnoprstufhcchshshchyieiuia'

# Generated at 2022-06-23 20:50:38.206968
# Unit test for function romanize
def test_romanize():
    """Testing decorator romanize."""
    ROMANIZATION = {
        'ru': {'А': 'A', 'а': 'a'},
        'uk': {'А': 'A', 'а': 'a'},
    }

    @romanize(locale='ru')
    def func_ru(locale):
        """Rus function."""
        return data.ROMANIZATION_DICT[locale]

    assert func_ru('ru') == ROMANIZATION['ru']

    @romanize(locale='uk')
    def func_uk(locale):
        """Ukr function."""
        return data.ROMANIZATION_DICT[locale]

    assert func_uk('uk') == ROMANIZATION['uk']

# Generated at 2022-06-23 20:50:41.157586
# Unit test for function romanize
def test_romanize():
    romanized_test = romanize('ru')

    @romanized_test
    def get_test():
        return 'Пример'

    assert get_test() == 'Primer'

# Generated at 2022-06-23 20:50:50.410747
# Unit test for function romanize
def test_romanize():
    from mimesis.schema import Field
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider

    assert isinstance(RomanizationDecorator, Callable)
    assert isinstance(RomanizationDecorator.__call__, Callable)
    func = RomanizationDecorator(str)(lambda: None)

    assert isinstance(func, Callable)
    assert func() is None
    assert func('abc') is None
    assert func(locale='ru') is None
    assert func(locale='uk') is None
    assert func(locale='kk') is None
    assert func(locale='en_GB') is None

    ru = RussiaSpecProvider()
    f = Field('name')
    assert isinstance(f.pattern, str)
    assert ru.gender == Gender.M

# Generated at 2022-06-23 20:50:55.758429
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian():
        return data.CYRILLIC_LETTERS['ru']

    text = russian()

    assert text == 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'

# Generated at 2022-06-23 20:51:06.995713
# Unit test for function romanize
def test_romanize():
    print('Это русский текст.')
    print(romanized('ru')(lambda: 'Это русский текст.')())
    print('\n')
    print('Це український текст.')
    print(romanized('uk')(lambda: 'Це український текст.')())
    print('\n')
    print('Бұл қазақ тілі.')

# Generated at 2022-06-23 20:51:11.798222
# Unit test for function romanize
def test_romanize():
    assert romanize_ru('Мимисус Идеалус Пулпулчулчули.') == \
        'Mimisus Idealus Pulpulchulchuli.'



# Generated at 2022-06-23 20:51:13.888064
# Unit test for function romanize
def test_romanize():
    print(romanized('ru')(lambda: 'Александр'))
    # Alexandr

# Generated at 2022-06-23 20:51:17.057541
# Unit test for function romanize
def test_romanize():
    def func(x):
        return x
    if __name__ == '__main__':
        romanize(None)(func)('Привет, мир!')

# Generated at 2022-06-23 20:51:20.792146
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanized_test_string() -> str:
        return 'Привет, как дела'

    assert romanized_test_string() == 'Privet, kak dela'

# Generated at 2022-06-23 20:51:22.850046
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Enum, Text

    assert romanized('ru')(Text.text)(length=20)

# Generated at 2022-06-23 20:51:28.694786
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'привет')() == 'privet'
    assert romanize('uk')(lambda : 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda : 'сәлем')() == 'salem'

# Generated at 2022-06-23 20:51:32.796775
# Unit test for function romanize
def test_romanize():
    rus = 'Бла-бла-бла'
    txt = 'Bla-bla-bla'
    assert romanize('ru')(lambda: rus) == txt
    assert romanized('ru')(lambda: rus) == txt



# Generated at 2022-06-23 20:51:38.673413
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    roman_data = {
        'ru': 'Россия',
        'uk': 'Україна',
        'kk': 'Қазақстан',
    }
    roman_answer = {
        'ru': 'Rossiya',
        'uk': 'Ukrayina',
        'kk': 'Qazaqstan',
    }
    for locale in roman_data:
        @romanize(locale)
        def roman(text):
            return text

        assert roman(roman_data[locale]) == roman_answer[locale]

    @romanize('ru')
    def roman(text):
        """Roman."""
        return text


# Generated at 2022-06-23 20:51:42.731881
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize('ru')
    def roman():
        return "Привет мир!"

    assert (roman() == "Privet mir!")



# Generated at 2022-06-23 20:51:47.622320
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import Text
    from mimesis.localization import LOCALES

    txt = Text()

    for locale in LOCALES:
        txt.reset_locale(locale)
        romanized_string = txt.romanize(locale)
        assert len(romanized_string) > 0

# Generated at 2022-06-23 20:51:55.898545
# Unit test for function romanize
def test_romanize():
    # This locale is not supported
    try:
        @romanize('not_supported')
        def test(**kwargs):
            return 'тест'

        test()
    except UnsupportedLocale:
        pass

    @romanize()
    def test_ru(**kwargs):
        return 'тест'

    @romanize('ru')
    def test_ru(**kwargs):
        return 'тест'

    assert test_ru() == 'test'

    @romanize()
    def test_uk(**kwargs):
        return 'іспит'

    @romanize('uk')
    def test_uk(**kwargs):
        return 'іспит'

    assert test_uk() == 'ispyt'


# Generated at 2022-06-23 20:52:03.655620
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize(locale='ru')(lambda: 'Давно выяснено')(
    ) == 'Davno vyyasneno'

    assert romanize(locale='uk')(lambda: 'Давно визначено')(
    ) == 'Davno viznacheno'

    assert romanize(locale='kk')(lambda: 'Давно танылған')(
    ) == 'Davno tanylan'

# Generated at 2022-06-23 20:52:10.265949
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    romanize_function = romanize()
    @romanize_function
    def romanize_text():
        return "Россия"
    assert romanize_text() == "Rossiya"
    assert romanized("ru")(romanize_text)() == "Rossiya"
    assert romanized("uk")(romanize_text)() == "Rosiya"
    assert romanized("kk")(romanize_text)() == "Rossiya"

# Generated at 2022-06-23 20:52:15.633697
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Salem'



# Generated at 2022-06-23 20:52:19.496860
# Unit test for function romanize
def test_romanize():
    # print(romanize()('л'))
    assert romanize()('л') == 'l'


# # Unit test for function romanized
# def test_romanized():
#     assert romanized()('л') == 'l'

# Generated at 2022-06-23 20:52:26.104616
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    @romanize(locale='uk')
    def get_animal(locale):
        return data.Animals(locale).animal()

    assert get_animal('uk') == 'gistra'

    @romanize(locale='uk')
    def get_integer_range(locale, minimum, maximum):
        return data.Numbers(locale).between(minimum, maximum)

    assert isinstance(get_integer_range('uk', 0, 1), int)



# Generated at 2022-06-23 20:52:27.870338
# Unit test for function romanize
def test_romanize():
    assert romanize('de')(lambda: 'Здравствуй') == 'Zdrablstwyj'

# Generated at 2022-06-23 20:52:32.673841
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus_string():
        return 'Пример русской фразы'

    assert rus_string() == 'Primer russkoi frazy'

# Generated at 2022-06-23 20:52:38.108163
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    p = Person(locale=Locale.RU)
    romanized_name = p.full_name(romanize=True)
    assert romanize(locale=Locale.RU)(p.full_name)() == romanized_name

# Generated at 2022-06-23 20:52:46.870712
# Unit test for function romanize
def test_romanize():
    assert romanize.romanized('привет мир')(lambda: 'привет мир')() == ('привет мир')
    assert romanize.romanized('привет мир', locale='ru')(lambda: 'привет мир')() == ('privet mir')
    assert romanize.romanized('привет мир', locale='uk')(lambda: 'привет мир')() == ('pryvit myr')

# Generated at 2022-06-23 20:52:54.950246
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_text():
        return "Любовь Эдмундович дал прямое указание Андрею Ильичу пойти в школу."

    text = romanize_text()
    if text != 'Lyubov Edmudovich dal pryamoie ukazanie Andreyu Ilyichu poiti v shkolu.':
        raise Exception("test_romanize failed")

test_romanize()

# Generated at 2022-06-23 20:53:01.571987
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text as t

    locale = 'ru'

    t1 = t.Text()
    assert ''.join(['a', 'b', 'c']) == t1._romanize('', 'abc')
    assert ''.join(['a', 'b', 'c']) == t1._romanize(locale, 'abc')

    t2 = t.Text(locale='ru')
    assert ''.join(['a', 'b', 'c']) == t2._romanize('', 'abc')
    assert ''.join(['а', 'б', 'ц']) == t2._romanize(locale, 'абц')

    t3 = t.Text(locale='uk')
    assert ''.join(['a', 'b', 'c']) == t3._

# Generated at 2022-06-23 20:53:03.262845
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_text():
        return 'Привет, друг!'

    txt = get_text()
    assert txt == 'Privet, drug!'

# Generated at 2022-06-23 20:53:06.580878
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    rp = RussianSpecProvider()
    result = rp.romanize
    assert isinstance(result, str)
    assert len(result) > 0

# Generated at 2022-06-23 20:53:10.269522
# Unit test for function romanize
def test_romanize():
    @romanize()
    def roman_test(name):
        return name

    assert roman_test('Русификатор') == 'Rusifikator'



# Generated at 2022-06-23 20:53:15.730594
# Unit test for function romanize
def test_romanize():
    for locale in data.ROMANIZATION_DICT.keys():
        @romanize(locale)
        def some_func(locale):
            return data.CYRILLIC_WORDS[locale]

        txt = some_func(locale)
        assert len(txt.split(' ')) == 1

# Generated at 2022-06-23 20:53:21.135936
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'тест')() == 'test'
    assert romanized()(lambda: 'тест') == 'test'
    assert romanized()(lambda: 'Альфа-раші')() == 'Alfa-raší'

# Generated at 2022-06-23 20:53:30.539049
# Unit test for function romanize
def test_romanize():
    def gen_fake_ru_text():
        return "ABC текст на русском языке который нужно" \
               " преобразовать в латинские буквы 123!"

    def gen_fake_kk_text():
        return "ABC әліпби қазақ тілінде келеді 123!"


# Generated at 2022-06-23 20:53:32.723553
# Unit test for function romanize
def test_romanize():
    with open('data/ru_romanized.txt', 'r', encoding='utf-8') as f:
        data = f.readlines()

    @romanize()
    def romanize_text():
        return data

    text = romanize_text()
    assert text

# Generated at 2022-06-23 20:53:38.354108
# Unit test for function romanize
def test_romanize():
    """Test for function `romanize`."""
    @romanize(locale='ru')
    def result(r):
        return r.text(r.random.randint(0, 1000), r.random.randint(1, 1000))

    s = result('Наша страна Россия')
    assert s == 'Nasha strana Rossiya'

# Generated at 2022-06-23 20:53:39.988447
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:53:42.792145
# Unit test for function romanize
def test_romanize():
    @romanize("ru")
    def get_romanized(self):
        return self.random_element(data.CYRILLIC)

    result = get_romanized("ru")
    assert result is not None
    assert type(result) is str

# Generated at 2022-06-23 20:53:53.115580
# Unit test for function romanize
def test_romanize():
    result = romanize()(lambda: 'Привет, Мир!')
    assert result == 'Privet, Mir!'

    result = romanize('uk')(lambda: 'Привіт, Світ!')
    assert result == 'Pryvit, Svit!'

    result = romanize('kk')(lambda: 'Сәлем, Дүние!')
    assert result == 'Sälem, Dünie!'

    result = romanize('ru')(lambda: 'Привет, Мир!')
    assert result == 'Privet, Mir!'

# Generated at 2022-06-23 20:54:00.456730
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo(arg):
        return arg

    assert foo('123') == '123'
    assert foo('Петров Иван') == 'Petrov Ivan'
    assert foo('Великий Андрей Петрович') == 'Velikiy Andrei Petrovich'
    assert foo('Михаил Иванович') == 'Mikhail Ivanovich'
    assert foo('Федор Иванович Достоевский') == 'Fyodor Ivanovich Dostoyevskiy'

# Generated at 2022-06-23 20:54:03.019285
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def _get_token():
        return 'Тест'

    assert _get_token() == 'Test'

# Generated at 2022-06-23 20:54:04.573033
# Unit test for function romanize
def test_romanize():
    """Test romanize()."""
    assert romanize() is not None



# Generated at 2022-06-23 20:54:15.800498
# Unit test for function romanize
def test_romanize():
    assert romanize()('Байт') == 'Byte'
    assert romanize('uk')('Байт') == 'Baĭt'
    assert romanize('kk')('Байт') == 'Bayt'
    assert romanize('kk')('Байт.') == 'Bayt.'
    assert romanize('kk')('Байт.') == 'Bayt.'
    assert romanize('kk')('Байт. Другой текст! Третий текст...')\
        == 'Bayt. Drugyj teks! Tret’ij teks...'


# Generated at 2022-06-23 20:54:18.262131
# Unit test for function romanize
def test_romanize():
    @romanize()
    def russian_text():
        return 'Хоботы'

    assert russian_text() == 'KHoboty'

# Generated at 2022-06-23 20:54:26.065344
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'КИРИЛЛИЦА')() == 'KIRILLICA'
    assert romanized('ru')(lambda: 'Сказочная история')() == 'Skazochnaya istoriya'
    assert romanized('uk')(lambda: 'Александр Пушкін')() == 'Aleksandr Pushkin'
    assert romanized('kk')(lambda: 'Қазақстан Республикасы')() == 'Qazaqstan Respublikası'

# Generated at 2022-06-23 20:54:28.913955
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    person = Person('ru')
    assert (person.name() != person.name(romanize=True))

# Generated at 2022-06-23 20:54:30.905276
# Unit test for function romanize
def test_romanize():
    @romanize('kk')
    def test():
        return 'Привет'

    assert test() == 'Privet'

# Generated at 2022-06-23 20:54:36.596416
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    @romanize(locale='ru')
    def get_ru():
        return 'привет мир'

    assert get_ru() == 'privet mir'

    @romanize(locale='uk')
    def get_uk():
        return 'привіт світ'

    assert get_uk() == 'pryvit svit'

    @romanize(locale='kk')
    def get_kk():
        return 'салам дүние'

    assert get_kk() == 'salam dyuye'



# Generated at 2022-06-23 20:54:42.261859
# Unit test for function romanize
def test_romanize():
    local = 'ru'
    s = u'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'
    result = 'abvgdeëžziiklmnoprstufxčšŝĭǐèûâ'
    assert s.isalpha()
    assert romanize(local)(lambda x: x)(s) == result



# Generated at 2022-06-23 20:54:48.758581
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    person = Person('uk', seed=123456)

    assert isinstance(person.full_name, str)
    assert isinstance(person.username, str)

    assert person.full_name == 'Богдан Зибров'
    assert person.username == 'Богдан-Зибров'  # Usually it's just a name

# Generated at 2022-06-23 20:54:49.338802
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:54:52.116902
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test_txt():
        return 'Привет, мир!'

    assert test_txt() == 'Privet, mir!'

# Generated at 2022-06-23 20:55:02.053397
# Unit test for function romanize
def test_romanize():
    from random import choice
    from string import ascii_letters, digits
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address(Language.RU)
    person = Person(Language.RU)

    result = romanized('')(address.city)
    assert len(result) == len(
        address.city.replace(' ', '').replace('-', ''))

    cp = person.name
    assert [i for i in cp if i in ascii_letters + digits] == [i for i in cp]

    st = ''.join(choice(ascii_letters + digits) for _ in range(32))
    result = romanized('')(st)

# Generated at 2022-06-23 20:55:08.428369
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    romanized_person = Person('uk')
    assert romanized_person._romanize is not None
    assert romanized_person._romanize is not None
    assert romanized_person._romanize is not None
    assert romanized_person._romanize is not None
    assert romanized_person.full_name(use_romanization=True) is not None
    assert romanized_person.full_name(use_romanization=True) is not None
    assert romanized_person.full_name(use_romanization=True) is not None
    assert romanized_person.full_name(use_romanization=True) is not None
    assert romanized_person.full_name(use_romanization=True) is not None

# Generated at 2022-06-23 20:55:08.963639
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:55:12.478607
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Съешь ещё этих мягких французских булок')() == \
           'Seysh eshyó etikh miagkikh frantsuzskikh bulok'

# Generated at 2022-06-23 20:55:18.300336
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'Функция')() == 'Funktziya'
    assert romanized(locale='uk')(lambda: 'Рівне')() == 'Rivne'
    assert romanized(locale='kk')(lambda: 'Сәуір')() == 'SaUir'

# Generated at 2022-06-23 20:55:29.865001
# Unit test for function romanize
def test_romanize():
    from mimesis import Text
    from mimesis.locales import RU
    from mimesis.providers.text import romanized

    ru_text = Text(locale=RU)
    ru_text.set_word_provider(romanized('ru'))
    ru_text.set_title_provider(romanized('ru'))
    ru_text.set_sentence_provider(romanized('ru'))

    ru_text.set_paragraph_provider(romanized('ru'))
    ru_text.set_text_provider(romanized('ru'))

    assert ru_text.romanized_word()[0] == 'a'
    assert ru_text.romanized_sentence()[0] == 'a'

# Generated at 2022-06-23 20:55:31.766233
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Марсель Махди')() == 'Marsel Mahdi'

# Generated at 2022-06-23 20:55:33.940274
# Unit test for function romanize
def test_romanize():
    assert romanized()(lambda: 'Привет, мир!')() == 'Privet, mir!'

# Generated at 2022-06-23 20:55:39.291863
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.text import Text

    text_ru = Text('ru')
    result_ru = text_ru.romanize(text_ru.words(quantity=1))

    text_uk = Text('uk')
    result_uk = text_uk.romanize(text_uk.words(quantity=1))

    text_kk = Text('kk')
    result_kk = text_kk.romanize(text_kk.words(quantity=1))

    assert result_ru != ''
    assert result_uk != ''
    assert result_kk != ''

# Generated at 2022-06-23 20:55:49.398832
# Unit test for function romanize
def test_romanize():
    try:
        @romanized('ru')
        def rus():
            return 'Здравствуйте!'

        rus()
    except UnsupportedLocale:
        assert True
    else:
        assert False

    try:
        @romanized()
        def rus():
            return 'Здравствуйте!'

        rus()
    except UnsupportedLocale:
        assert True
    else:
        assert False

    @romanize('ru')
    def rus():
        return 'Здравствуйте!'

    assert rus() == 'Zdravstvuyte!'


# Generated at 2022-06-23 20:55:51.924347
# Unit test for function romanize
def test_romanize():
    assert ''.join([romanize()(lambda: 'Прывітання')()
                    for _ in range(10)]) == 'Pryvitannyia'

# Generated at 2022-06-23 20:55:55.305767
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def do(text):
        return text

    assert do('Привет Друг! Как дела?') == 'Privet Drug! Kak dela?'

# Generated at 2022-06-23 20:56:01.763412
# Unit test for function romanize
def test_romanize():
    from .text import TextSpec
    from .number import NumberSpec

    class RomanizedText(TextSpec):
        @romanize(locale='ru')
        def romanized_text(self, pattern='#####'):
            return self.random_element(pattern)


    class RomanizedNumber(NumberSpec):
        @romanize(locale='ru')
        def romanized_number(self):
            return str(self.randint(0, 100000))


    t = RomanizedText()
    n = RomanizedNumber()

    assert t.romanized_text().isalpha()
    assert n.romanized_number().isdigit()

# Generated at 2022-06-23 20:56:05.597415
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет!')() == 'Privet!'
    assert romanize('ru')(lambda: 'Привет!')() != 'Privet'

# Generated at 2022-06-23 20:56:13.079237
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Тест')() == 'Test'
    assert romanize('uk')(lambda: 'Тест')() == 'Test'
    assert romanize('kk')(lambda: 'Тест')() == 'Test'
    assert romanized('ru')(lambda: 'Тест')() == 'Test'
    assert romanized('uk')(lambda: 'Тест')() == 'Test'
    assert romanized('kk')(lambda: 'Тест')() == 'Test'

# Generated at 2022-06-23 20:56:22.195630
# Unit test for function romanize
def test_romanize():  # pylint: disable=unused-variable
    """Test for the decorator romanize."""
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    @romanize(Locale.RU)
    def romanized_ru():
        """Romanize a string."""
        person = Person(Locale.RU)
        return person.full_name()

    @romanize(Locale.UK)
    def romanized_uk():
        """Romanize a string."""
        person = Person(Locale.UK)
        return person.full_name()

    @romanize(Locale.KK)
    def romanized_kk():
        """Romanize a string."""
        person = Person(Locale.KK)
        return person.full_name()



# Generated at 2022-06-23 20:56:28.761042
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda x: 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ')() == 'ABVGDEËŽZIJKLMNOPRSTUFHCČŠŜ"Y\'ÈÛÁ'

# Generated at 2022-06-23 20:56:36.324820
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    assert romanize('ru')(lambda: 'тест')() == 'test'
    assert romanize('uk')(lambda: 'тест')() == 'test'
    assert romanize('kk')(lambda: 'тест')() == 'test'
    assert romanize('uk')(lambda: 'Тест')() == 'Test'

# Generated at 2022-06-23 20:56:39.606267
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    assert romanize('ru')(lambda: 'Мэри имела курицу белую')() == 'Mery imela kuritzu belouju'

# Generated at 2022-06-23 20:56:42.996331
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo(seed):
        return seed
    print(foo('Тестовая строка'))

# Generated at 2022-06-23 20:56:49.192644
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')(lambda: 'қәрім')() == 'qɑrim'
    assert romanize('ru')(lambda: 'Россия')() == 'Rossiya'
    assert romanize('uk')(lambda: 'ЗВІДНИК')() == 'ZVІDNYK'

# Generated at 2022-06-23 20:56:59.123232
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Желтая птица') == 'Zhelaya ptitsa'
    assert romanize('uk')(lambda: 'Желтая птица') == 'Zhelaya ptitsya'
    assert romanize('kk')(lambda: 'Желтая птица') == 'Zhelaya ptitsya'
    assert romanize('ru')(lambda: 'Желтая птица')('ru') == 'Zhelaya ptitsa'
    assert romanize('uk')(lambda: 'Желтая птица')('uk') == 'Zhelaya ptitsya'

# Generated at 2022-06-23 20:57:01.036238
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def r():
        return 'Это тест!'

    assert r() == 'Eto test!'

# Generated at 2022-06-23 20:57:07.908636
# Unit test for function romanize
def test_romanize():
    assert romanize()(ru)() == romanize('ru')(ru)()
    assert romanize()(uk)() == romanize('uk')(uk)()
    assert romanize()(kk)() == romanize('kk')(kk)()

    assert romanize()(ru)() == 'Privet, kak dela?'
    assert romanize()(uk)() == 'Pryvit, jak spravy?'
    assert romanize()(kk)() == 'Salem bolsyn?'

    assert romanize('ru')(uk)() == 'Прийщит, жак Справы?'
    assert romanize('ru')(kk)() == 'Салем болсын?'

   

# Generated at 2022-06-23 20:57:14.533862
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.text
    t = mimesis.builtins.text.Text()
    t.__dict__["locale"] = 'uk'
    txt = t.text(5)
    result = t.romanize(txt)
    for i in range(0, len(txt)):
        assert txt[i] == result[i]

# Generated at 2022-06-23 20:57:22.208152
# Unit test for function romanize
def test_romanize():
    from mimesis import Address, Person

    ru_person = Person('ru')
    ru_address = Address('ru')
    ru_second_name = ru_person.second_name()
    ru_street_name = ru_address.street_name()

    assert ru_second_name == romanized('ru')(ru_person.second_name)()
    assert ru_street_name == romanized('ru')(ru_address.street_name)()

# Generated at 2022-06-23 20:57:30.769202
# Unit test for function romanize
def test_romanize():
    from mimesis.numbers import Number
    num = Number()
    assert num.romanized_number()
    assert num.romanized_number(10)
    assert num.romanized_number(10, 20)
    assert num.romanized_number(10, 20, True)
    assert num.romanized_number(10, 20, False)
    assert num.romanized_number(10, 20, True, 'kz')
    assert num.romanized_number(10, 20, False, 'kz')
    assert num.romanized_number(10, 20, False, 'by')
    assert num.romanized_number(10, 20, True, 'by')

# Generated at 2022-06-23 20:57:39.958145
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    assert romanize(Language.RU.value)(lambda: 'Тест')() == 'Тест'
    assert romanize(Language.UK.value)(lambda: 'Тест')() == 'Тест'
    assert romanize(Language.KZ.value)(lambda: 'Тест')() == 'Тест'

    # The default locale is 'en'.
    assert romanize()(lambda: 'Тест')() == 'Test'

# Generated at 2022-06-23 20:57:43.263701
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    from mimesis.builtins import RussiaSpecProvider

    rus = RussiaSpecProvider(locale='ru')
    assert rus._romanize_text('Привет') == 'Privet'