

# Generated at 2022-06-23 20:47:45.156803
# Unit test for function romanize
def test_romanize():
    romanize_ru = romanize('ru')
    romanize_uk = romanize('uk')
    romanize_kk = romanize('kk')

    @romanize_ru
    def random_ru():
        return 'Строка на русском'

    @romanize_uk
    def random_uk():
        return 'Збірник українських висловів і приказів'


# Generated at 2022-06-23 20:47:46.629861
# Unit test for function romanize
def test_romanize():
    """Test of romanize function."""
    assert romanized()('') == ''

# Generated at 2022-06-23 20:47:49.597384
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, Мир!')().lower() == 'privet, mir!'

# Generated at 2022-06-23 20:47:55.518557
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanized('uk')(lambda: 'Привіт, світ!')() == 'Pryvit, svit!'
    assert romanized('kk')(lambda: 'Сәлем, Әлем!')() == 'Sälem, Älem!'

# Generated at 2022-06-23 20:48:00.025428
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    t = Text('en')
    assert t.romanized(locale='ru') is not None
    assert t.romanized(locale='uk') is not None
    assert t.romanized(locale='kk') is not None

# Generated at 2022-06-23 20:48:03.536110
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import  Locale
    from mimesis.providers.address import Address

    address = Address(Locale.RU)

    assert address.get_postal_code()[:3] == '123'

# Generated at 2022-06-23 20:48:11.153627
# Unit test for function romanize
def test_romanize():
    romanization_dict = {
        s: s for s in ascii_letters + digits + punctuation
    }
    romanization_dict.update({**data.ROMANIZATION_DICT['ru'],
                              **data.COMMON_LETTERS})

    result = ''.join(sorted(romanization_dict.keys()))

    @romanize('ru')
    def romanize_test():
        return result

    txt = romanize_test()
    assert isinstance(txt, str)
    assert txt == ''.join([romanization_dict[i] for i in result])

# Generated at 2022-06-23 20:48:21.005687
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет, Мир!') == 'Privet, Mir!'
    assert romanized('uk')('Привіт, Світ!') == 'Pryvit, Svit!'
    assert romanized('kk')('Сәлем, Дүние!') == 'Sälem, Dünie!'


# Generated at 2022-06-23 20:48:31.161568
# Unit test for function romanize
def test_romanize():
    assert romanized(russian)(ascii_characters)(length=10) == \
        russian().ascii_characters(length=10)
    try:
        assert romanized(russian)(ascii_characters)(length=10, locale='en') == \
            russian().ascii_characters(length=10, locale='en')
    except UnsupportedLocale:
        pass
    assert romanized(russian)(ascii_characters)(length=10, locale='ru') == \
        russian().ascii_characters(length=10, locale='ru')
    assert romanized(russian)(ascii_characters)(length=10, locale='uk') == \
        russian().ascii_characters(length=10, locale='uk')
    assert roman

# Generated at 2022-06-23 20:48:38.425374
# Unit test for function romanize
def test_romanize():
    @romanize()
    def fun():
        return 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'

    assert fun() == 'abvgdeejzijklmnoprstufhzcss_y_eua'

    @romanize('ru')
    def fun2():
        return 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'

    assert fun2() == 'abvgdeejzijklmnoprstufhzcss_y_eua'


# Generated at 2022-06-23 20:48:39.579352
# Unit test for function romanize
def test_romanize():
    assert romanize()(dict) == dict

# Generated at 2022-06-23 20:48:40.240842
# Unit test for function romanize
def test_romanize():
    assert True

# Generated at 2022-06-23 20:48:46.029378
# Unit test for function romanize
def test_romanize():
    """Romanize test."""
    from mimesis.enums import Language
    from mimesis.providers.person import Person


    @romanize('ru')
    def get_name(lang: Language) -> str:
        p = Person(lang)
        return p.full_name()


    assert isinstance(get_name(Language.RU), str)
    assert get_name(Language.RU) in data.ROMANIZATION_DICT[Language.RU].values()

# Generated at 2022-06-23 20:48:56.746734
# Unit test for function romanize
def test_romanize():
    string_uk = 'Декоратор для романизації українських текстів.'
    string_ru = 'Декоратор для романизации русских текстов.'
    string_kk = 'Ондай қазақ тілінде қағаздар қарсылымын қабілетті болуы.'



# Generated at 2022-06-23 20:48:58.667717
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет мир!')() == 'Privet mir!'

# Generated at 2022-06-23 20:49:06.014677
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import SpecialChar
    from mimesis.builtins import (
        RussiaSpecProvider,
        UkraineSpecProvider,
    )

    rus_locale = 'ru'
    ukr_locale = 'uk'
    kaz_locale = 'kk'

    @romanize(rus_locale)
    def rus_noun() -> str:
        return RussiaSpecProvider.noun(
            gender=SpecialChar.FEMININE,
            form=SpecialChar.FULL,
        )

    @romanize(ukr_locale)
    def ukr_noun() -> str:
        return UkraineSpecProvider.noun(
            gender=SpecialChar.FEMININE,
            form=SpecialChar.FULL,
        )


# Generated at 2022-06-23 20:49:11.036656
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'вася') == 'vasya'
    assert romanize(locale='kk')(lambda: 'алаңдар') == 'alangdar'
    assert romanize(locale='uk')(lambda: 'Єгор') == 'Yehor'

# Generated at 2022-06-23 20:49:13.413368
# Unit test for function romanize
def test_romanize():
    def foo(bar: str) -> str:
        return bar

    romanized_foo = romanize(locale='ru')(foo)
    assert romanized_foo('В') == 'V'

# Generated at 2022-06-23 20:49:15.665612
# Unit test for function romanize
def test_romanize():
    assert len(ascii_letters + digits + punctuation) == 62
    data.COMMON_LETTERS.update({**data.ROMANIZATION_DICT['ru']})
    assert len(data.COMMON_LETTERS) == 85

# Generated at 2022-06-23 20:49:16.214855
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:49:20.393714
# Unit test for function romanize
def test_romanize():
    # TODO: Probably useful to refactor this test using pytest-mock.

    @romanize('ru')
    def foo():
        return 'привет'

    assert foo() == 'privet'

# Generated at 2022-06-23 20:49:24.501508
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def r_text(num: int = None) -> str:
        return "Привет, это пример текста."

    assert r_text() == "Privyet, eto primer teksta."

# Generated at 2022-06-23 20:49:27.286618
# Unit test for function romanize
def test_romanize():
    expected_value = "hello world!"
    translated_value = romanize()(lambda: "привет мир!")
    assert translated_value == expected_value

# Generated at 2022-06-23 20:49:29.512019
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def roman_test(text):
        return text

    assert roman_test('Привет, мир!') == 'Privet, mir!'

# Generated at 2022-06-23 20:49:33.097265
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Datetime

    dt = Datetime('ru')
    assert dt.datetime() == dt._datetime()

    dt = Datetime('uk')
    assert dt.datetime() == dt._datetime()

    dt = Datetime('kk')
    assert dt.datetime() == dt._datetime()

# Generated at 2022-06-23 20:49:33.638119
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:49:34.756596
# Unit test for function romanize
def test_romanize():
    assert romanize()('Тест') == 'Test'

# Generated at 2022-06-23 20:49:37.974895
# Unit test for function romanize
def test_romanize():
    def show():
        return 'Давайте попробуем всё.'

    romanized_func = romanize(locale='ru')(show)
    result = romanized_func()
    assert result == 'Davayte poprobuyem vsyo.'

# Generated at 2022-06-23 20:49:44.077968
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : {'a': 'а', 'b': 'б'}) == {'a': 'a', 'b': 'b'}
    assert romanize('uk')(lambda : {'a': 'а', 'b': 'б'}) == {'a': 'a', 'b': 'b'}
    assert romanize('kk')(lambda : {'a': 'а', 'b': 'б'}) == {'a': 'a', 'b': 'b'}

# Generated at 2022-06-23 20:49:50.604162
# Unit test for function romanize
def test_romanize():
    text = 'Чи це кращий спосіб, щоб робити транслітерацію для мова Python?'

    def test_func():
        return text

    import mimesis.localization
    mimesis.localization.set_locale('ru')
    romanized_func = romanize('ru')(test_func)
    assert romanized_func() == 'Chi tse khraschi_j sposib, schob robyty' \
                               ' transliteraciyu dlya mova Python?'


test_romanize()

# Generated at 2022-06-23 20:49:51.891910
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-23 20:50:00.514796
# Unit test for function romanize
def test_romanize():
    def text_ru():
        return 'Всем привет!'

    def text_uk():
        return 'Привіт всім!'

    def text_kk():
        return 'Қош келдіңіз'

    for locale, text in zip(['ru', 'uk', 'kk'], [text_ru, text_uk, text_kk]):
        romanized_text = romanize(locale)(text)()
        assert romanized_text == text().lower()

# Generated at 2022-06-23 20:50:09.162783
# Unit test for function romanize
def test_romanize():
    # Test for romanized
    assert romanized(locale='ru')(lambda: 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ')() == 'ABVGDEYOZHZIJKLMNOPRSTUFHCCCHSCHSHIIYEEYUA'

    # Test for romanize

# Generated at 2022-06-23 20:50:16.538972
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Как себя чувствуете?") == "Kak sebya chuvstvuete?"
    assert romanize("uk")("Як себе чуєте?") == "Yak sebe chuyete?"
    assert romanize("kk")("Не сендеріңіз келеді?") == "Ne senderińiz keledi?"

# Generated at 2022-06-23 20:50:22.500605
# Unit test for function romanize

# Generated at 2022-06-23 20:50:26.764833
# Unit test for function romanize
def test_romanize():
    assert romanized(ru)(lambda: 'я')() == 'ya'
    assert romanized(uk)(lambda: 'б')() == 'b'
    assert romanized(kk)(lambda: 'қ')() == 'q'
    assert romanized(fr)(lambda: 'б')() == 'b'

# Generated at 2022-06-23 20:50:29.685724
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Address
    a = Address('ru')
    assert all(isinstance(a.street_name(), str) for _ in range(10))

# Generated at 2022-06-23 20:50:40.903557
# Unit test for function romanize
def test_romanize():
    """Check that function romanize romanizes text."""
    @romanize('ru')
    def russian_text():
        text = 'Один только константинопольский собор «Православие, истина, церковь» явил миру,' \
               ' что христианский мир способен на единство.'
        return text


# Generated at 2022-06-23 20:50:47.461968
# Unit test for function romanize
def test_romanize():
    # Test function
    @romanize()
    def romanized_text() -> str:
        return 'Перевести'

    assert romanized_text() == 'Perevesti'
    assert romanized_text(locale='RU') == 'Perevesti'
    assert romanized_text(locale='UK') == 'Perevesty'
    assert romanized_text(locale='KK') == 'Pereveshi'



# Generated at 2022-06-23 20:50:52.180693
# Unit test for function romanize
def test_romanize():
    assert romanize()(data.ROMANIZATION_DICT['uk']['П']) == 'П'
    assert romanize()(data.ROMANIZATION_DICT['ru']['П']) == 'P'
    assert romanize()(data.ROMANIZATION_DICT['kk']['П']) == 'P'



# Generated at 2022-06-23 20:50:54.089812
# Unit test for function romanize
def test_romanize():
    roman = romanize('ru')
    assert roman(lambda: 'Имя') == 'Imja'

# Generated at 2022-06-23 20:50:59.219322
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    assert RussianSpecProvider.romanize() == '123'
    assert RussianSpecProvider.romanize() == 'aA'
    assert RussianSpecProvider.romanize() == 'Никита Славутич'
    assert RussianSpecProvider.romanize() == 'будет показано на экране'

# Generated at 2022-06-23 20:51:01.305900
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda *args, **kwargs: 'Привет!')() == 'Privet!'

# Generated at 2022-06-23 20:51:02.874523
# Unit test for function romanize
def test_romanize():
    assert romanize('')(lambda: None)() is None

# Generated at 2022-06-23 20:51:05.913542
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test():
        return 'Привет, мир!'

    assert test() == 'Privet, mir!'

# Generated at 2022-06-23 20:51:10.311172
# Unit test for function romanize
def test_romanize():
    assert data.Person('ru').full_name_male() == 'Макаров Геннадий Михайлович'
    assert data.Person('ru').full_name_male(romanize=True) == 'Makarov Gennadiy Mikhailovich'


test_romanize()

# Generated at 2022-06-23 20:51:18.128577
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Громадный')() == 'Gromadnyy'
    assert romanize('uk')(lambda: 'Громадний')() == 'Hromadnyy'
    assert romanize('kk')(lambda: 'Батыр')() == 'Batyr'
    try:
        romanize('en')(lambda: 'Громадный')
    except UnsupportedLocale:
        assert True
    else:
        assert False

# Generated at 2022-06-23 20:51:25.807491
# Unit test for function romanize
def test_romanize():
    assert (romanize('uk')(lambda: 'Київ')() == 'Kyiv')
    assert (romanize('ru')(lambda: 'Київ')() == 'Kiyiv')
    assert (romanize('kk')(lambda: 'Київ')() == 'Qııw')

    assert (romanized('uk')(lambda: 'Київ')() == 'Kyiv')
    assert (romanized('ru')(lambda: 'Київ')() == 'Kiyiv')
    assert (romanized('kk')(lambda: 'Київ')() == 'Qııw')

# Generated at 2022-06-23 20:51:32.797172
# Unit test for function romanize
def test_romanize():
    romanize('ru')(lambda: 'Съешь ещё этих мягких французских булок, '
                       'да выпей чаю. А из-за дождя никакой рыбы, да?')()

# Generated at 2022-06-23 20:51:34.387577
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'privet'

# Generated at 2022-06-23 20:51:40.792333
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    # test the function
    locale = 'ru'
    person = Person(locale)
    assert romanize(locale)(person.full_name) == person.romanized_full_name()
    assert romanize(locale)(person.surname) == person.romanized_surname()

    # test for unsupported locale
    locale = Locale.LATVIAN
    person = Person(locale)
    try:
        romanize(locale)(person.full_name)
    except UnsupportedLocale:
        pass
    else:
        raise ValueError('Expected error not raised')

# Generated at 2022-06-23 20:51:50.631701
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person, Text

    def romanized_function(text='foo'):
        return text + ' bar'

    wrapped = romanize('ru')(romanized_function)
    assert wrapped() == 'foo bar'

    person = Person('ru')
    wrapped_person = romanize('ru')(Person)
    assert isinstance(person, Person)
    assert isinstance(wrapped_person, romanize('ru'))
    assert wrapped_person.full_name() == wrapped_person().get_full_name()
    assert person.full_name() == person().get_full_name()

    text_gen = Text('ru')
    wrapped_text_gen = romanize('ru')(Text)
    assert isinstance(text_gen, Text)

# Generated at 2022-06-23 20:52:01.478762
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Лорем ипсум')() == 'Lorem ipsum'
    assert romanized(locale='ru')(lambda: 'Лорем ипсум')() == 'Lorem ipsum'

# Generated at 2022-06-23 20:52:04.426574
# Unit test for function romanize
def test_romanize():
    # sample function
    def sample(locale: str = '') -> str:
        return 'Война'

    # decorated function
    decorated = romanize(locale='ru')(sample)
    assert decorated() == 'Voina'

# Generated at 2022-06-23 20:52:12.755884
# Unit test for function romanize
def test_romanize():
    dlocales = ['RU', 'UK', 'KK']

    for dlocale in dlocales:
        @romanized(dlocale)
        def f1(c):
            ss = 'ЁЖХЦЩ'
            ss += 'ЁЖХЦЩ'
            ss += 'ёжхцщ'
            ss += 'ёжхцщ'
            ss += '0123456789'
            if c == 0:
                return ss
            return ss[c - 1]

        assert f1(0) == 'YOZHXCSh' * 4 + '0123456789'
        assert f1(1) == 'Y'

# Generated at 2022-06-23 20:52:13.397137
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:52:20.427524
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import SpecialChars

    @romanize('ru')
    def to_romanize(size: int = 6) -> str:
        return SpecialChars.CYRILLIC_CHARACTERS.value[:size]

    assert isinstance(to_romanize(), str)
    assert to_romanize()[0] in SpecialChars.ASCII_LETTERS.value
    assert to_romanize()[1] in SpecialChars.ASCII_LETTERS.value
    assert to_romanize()[2] in SpecialChars.ASCII_LETTERS.value
    assert to_romanize()[3] in SpecialChars.ASCII_LETTERS.value
    assert to_romanize()[4] in SpecialChars.ASCII_LETTERS.value
    assert to_romanize()

# Generated at 2022-06-23 20:52:22.993870
# Unit test for function romanize
def test_romanize():
    @romanized()
    def foo():
        return 'Здравствуй'
    assert foo() == 'Zdrastvoi'

# Generated at 2022-06-23 20:52:30.909386
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import CyrillicText

    cyrillic_str = CyrillicText()

    @romanize(locale='ru')
    def rus(x: int) -> str:
        return cyrillic_str.text(x)

    @romanize(locale='uk')
    def ukr(x: int) -> str:
        return cyrillic_str.text(x)

    @romanize(locale='kk')
    def kaz(x: int) -> str:
        return cyrillic_str.text(x)

    assert rus(10) != ukr(10)
    assert kaz(10) != ukr(10)
    assert rus(10) != kaz(10)

# Generated at 2022-06-23 20:52:32.772765
# Unit test for function romanize
def test_romanize():
    assert romanize('en')('hello') == 'hello'

# Generated at 2022-06-23 20:52:35.394477
# Unit test for function romanize
def test_romanize():
    from mimesis import Address

    adr = Address('es')
    assert adr.street_name()


# Generated at 2022-06-23 20:52:40.965835
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привіт світ!')() == 'Pryvit svit!'
    assert romanize('uk')(lambda: 'Привіт світ!')() == 'Privit svit!'
    assert romanize('kk')(lambda: 'Привіт світ!')() == 'Prywyt svıtw!'

# Generated at 2022-06-23 20:52:47.005725
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def value():
        return 'Привет'

    from mimesis.enums import Locale
    assert value() == 'Privet'

    @romanize(Locale.RUSSIAN)
    def value():
        return 'Привет'

    assert value() == 'Privet'



# Generated at 2022-06-23 20:52:51.211608
# Unit test for function romanize
def test_romanize():
    """Romanize the str 'Привет' to 'Privet'"""
    translated = romanize()(lambda x: 'Привет')
    assert translated() == 'Privet'



# Generated at 2022-06-23 20:52:55.898057
# Unit test for function romanize
def test_romanize():
    # Simple usage
    @romanize(locale='ru')
    def foo(s):
        return s

    # Usage as a decorator without arguments
    @romanize
    def bar(s):
        return s

    assert foo('Привет, Мир!') == 'Privet, mir!'
    assert bar('Привет, Мир!') == 'Privet, mir!'

# Generated at 2022-06-23 20:53:04.482997
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    assert romanized()(Address(Language.RUSSIAN).city) == 'Skolkovo'
    assert romanized(locale='ru')(Address(Language.RUSSIAN).city) == 'Skolkovo'
    assert romanized(locale='uk')(Address(Language.UKRAINIAN).city) == 'Kamyanske'
    assert romanized(locale='kk')(Address(Language.KAZAKH).city) == 'Zhananda'

# Generated at 2022-06-23 20:53:13.782265
# Unit test for function romanize

# Generated at 2022-06-23 20:53:15.876117
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian():
        return 'Строка'

    assert russian() == 'Stroka'



# Generated at 2022-06-23 20:53:22.576602
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    r = RussiaSpecProvider()

    assert r.romanized.full_name() == 'Ann Ivanovna'
    assert r.romanized.full_name() == 'Oleg Vasilievich'

    assert r.romanized.full_name(sex='female') == 'Natalya Sergeevna'
    assert r.romanized.full_name(sex='female') == 'Vladimir'

# Generated at 2022-06-23 20:53:30.660318
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def _ru_ru_romanized():
        return 'Привет, мир!'

    assert _ru_ru_romanized() == 'Privet, mir!'

    @romanize('uk')
    def _uk_uk_romanized():
        return 'Привіт, світ!'

    assert _uk_uk_romanized() == 'Pryvit, svit!'

    @romanize('kk')
    def _kk_kk_romanized():
        return 'Сәлем!'

    assert _kk_kk_romanized() == 'Sälém!'



# Generated at 2022-06-23 20:53:36.216205
# Unit test for function romanize
def test_romanize():
    assert romanized('kk')('Привет, мир!') == 'Pryviet, mir!'
    assert romanized('ru')('Привет, мир!') == 'Privet, mir!'
    assert romanized('uk')('Привет, мир!') == 'Pryvet, mir!'

# Generated at 2022-06-23 20:53:39.639608
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Эй, как дела?')() == 'Ej, kak dela?'
    assert romanize('uk')(lambda x: 'Доброго дня')() == 'Dobrogo dnia'
    assert romanize('kk')(lambda x: 'Сәлем')() == 'Salem'
    assert romanize('kk')(lambda x: 'Ғалам')() == 'Ghalam'

# Generated at 2022-06-23 20:53:43.358649
# Unit test for function romanize
def test_romanize():
    result = romanize(locale="ru")(lambda: "Привет, Мир")
    result()
    assert result()  == "Privet, Mir"

# Generated at 2022-06-23 20:53:46.229011
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func():
        return 'Привет, мир!'
    assert func() == 'Privet, mir!'

# Generated at 2022-06-23 20:53:51.315330
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("привет") == "privet"
    assert romanize("uk")("привіт") == "privit"
    assert romanize("kk")("Сәлем") == "Sälem"



# Generated at 2022-06-23 20:53:57.164303
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    from mimesis.enums import Locale
    from mimesis.providers.internet import Internet

    value = 'Привіт, як справи?'
    romanized_text = 'Privyt, yak spravy?'
    i = Internet(Locale.UKRAINIAN)
    generated_txt = i._romanize(value)
    assert romanized_text == generated_txt

# Generated at 2022-06-23 20:53:58.695619
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert not romanize('es')

# Generated at 2022-06-23 20:54:03.028319
# Unit test for function romanize
def test_romanize():
    """"""
    @romanize(locale='ru')
    def romanize_text():
        return 'Как дела?'

    assert romanize_text() == 'Kak dela?'

# Generated at 2022-06-23 20:54:09.217971
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет')() == 'Privet'
    assert romanized('kk')(lambda: 'Привет')() == 'Privet'
    assert romanized('uk')(lambda: 'Привет')() == 'Privet'


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-23 20:54:14.636212
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_function():
        return ('Сегодня дождливо. '
                'Хорошего дня! :)')

    result = test_function()
    assert result == 'Segodnya dozhdlivo. Khoroshyeo dnya! :)'

# Generated at 2022-06-23 20:54:20.764310
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    # GIVEN locale
    locale = 'ru'
    # AND function with romanize decorator
    @romanize(locale)
    def rusify(text: str) -> str:
        return text

    # WHEN the text is romanized
    romanized_text = rusify('Привет, Мир!')

    # THEN we get romanized text
    assert romanized_text == 'Privet, mir!'

# Generated at 2022-06-23 20:54:29.451828
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda *_, **__: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('uk')(lambda *_, **__: 'Привіт, Світ!')() == 'Pryvit, Svit!'
    assert romanize('kk')(lambda *_, **__: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-23 20:54:32.667263
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_string():
        return 'Привет, как дела?'

    assert russian_string() == 'Priviet, kak dela?'



# Generated at 2022-06-23 20:54:37.629710
# Unit test for function romanize
def test_romanize():
    romanize.alphabet = {
        'a': 'h',
        'b': 'r',
        'c': 'R',
    }

    romanize('ru')

    assert romanize.alphabet == {'a': 'h', 'b': 'r', 'c': 'R', 'б': 'r'}
    delattr(romanize, 'alphabet')

# Generated at 2022-06-23 20:54:44.543626
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize('ru')(lambda: 'Тест'), Callable)
    assert isinstance(romanized('ru')(lambda: 'Тест'), Callable)

    @romanize('ru')
    def test_romanized_string():
        return 'Тест'

    assert isinstance(test_romanized_string(), str)
    assert test_romanized_string() == 'Test'

    @romanize('kk')
    def test_romanized_string_from_kk():
        return 'Тест'

    assert isinstance(test_romanized_string_from_kk(), str)
    assert test_romanized_string_from_kk() == 'Teсt'

# Generated at 2022-06-23 20:54:46.965503
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo():
        return 'тест'
    assert foo() == 'test'

# Generated at 2022-06-23 20:54:51.158649
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Hëllo')() == 'Hello'
    assert romanize('uk')(lambda: 'Hëllo')() == 'Hello'
    assert romanize('kk')(lambda: 'Hëllo')() == 'Hello'

# Generated at 2022-06-23 20:54:53.810913
# Unit test for function romanize
def test_romanize():
    result = romanize(locale='ru')(lambda: "Привет, Мир!")
    assert result() == "Privet, Mir!"

# Generated at 2022-06-23 20:55:00.745583
# Unit test for function romanize
def test_romanize():
    """Test romanize."""

    @romanize(locale='ru_RU')
    def cyrillic_to_latin():
        """Cyrillic text to latin."""
        return 'Привет, мир!'

    assert cyrillic_to_latin() == 'Privet, mir!'

    @romanize()
    def english_to_latin():
        """English text to latin."""
        return 'Hello world.'

    assert english_to_latin() == 'Hello world.'

# Generated at 2022-06-23 20:55:08.092981
# Unit test for function romanize
def test_romanize():
    from .datetime import Datetime
    from .enums import Gender

    d = Datetime(region='RU')
    assert d._romanization_is_supported()
    assert d.full_name(gender=Gender.MALE) == d.full_name(gender=Gender.MALE, romanize=False)
    assert d.full_name(gender=Gender.FEMALE) == d.full_name(gender=Gender.FEMALE, romanize=False)
    assert d.full_name(gender=Gender.UNKNOWN) == d.full_name(gender=Gender.UNKNOWN, romanize=False)

# Generated at 2022-06-23 20:55:14.568834
# Unit test for function romanize
def test_romanize():
    class TestClass:
        def __init__(self):
            self.number = 9

        def test_func(self, locale='ru'):
            return 'фыва йцукен {0:d}'.format(self.number)

    test_obj = TestClass()
    romanize_test_func = romanize(locale='ru')(test_obj.test_func)

    assert romanize_test_func() == 'fivA jtsuken 9'
    assert romanize_test_func(locale='uk') == 'fivA цtsuken 9'
    assert romanize_test_func(locale='kk') == 'fivA tsуken 9'

# Generated at 2022-06-23 20:55:20.310313
# Unit test for function romanize

# Generated at 2022-06-23 20:55:30.799290
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'hello')() == 'hello'
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('ru')(lambda: 'приветствую')() == 'privetstvuju'
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'
    assert romanize('ru')(lambda: 'Приветствую')() == 'Privetstvuju'
    assert romanize('ru')(lambda: 'привет-Привет')() == 'privet-Privet'

# Generated at 2022-06-23 20:55:34.513969
# Unit test for function romanize
def test_romanize():
    """Test for function romanize.
    """
    romanized_text = romanized(locale="ru")
    assert "Привет, мир!" == romanized_text(u"Привет, мир!")

# Generated at 2022-06-23 20:55:41.633459
# Unit test for function romanize
def test_romanize():
    r = romanize('ru')
    assert r('Привет, мир!') == 'Privet, mir!'
    r = romanize('uk')
    assert r('Привіт, світ!') == 'Pryvit, svit!'
    r = romanize('kk')
    assert r('Қайырлы әлем!') == 'Qayırlı älem!'

# Generated at 2022-06-23 20:55:44.090557
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize.

    :return: True
    """
    @romanize(locale='ru')
    def r(_):
        return 'Пока не скажу.'

    assert r(None) == 'Poka ne skazhu.'



# Generated at 2022-06-23 20:55:51.311725
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    # romanize = romanized
    @romanize(locale='ru')
    def romanize_ru(s: str) -> str:
        return s

    @romanize(locale='uk')
    def romanize_uk(s: str) -> str:
        return s

    @romanize(locale='kk')
    def romanize_kk(s: str) -> str:
        return s

    # Test for Russian text
    assert romanize_ru('привет') == 'privet'
    assert romanize_ru('прИВет') == 'privet'
    assert romanize_ru('приВет') == 'privet'

# Generated at 2022-06-23 20:55:54.657800
# Unit test for function romanize
def test_romanize():
    """Test for the romanized_deco function."""
    assert romanize()(romanize)
    assert romanize('ru')(romanize)
    assert romanize('uk')(romanize)
    assert romanize('kk')(romanize)

# Generated at 2022-06-23 20:56:00.036310
# Unit test for function romanize
def test_romanize():
    """Test for the romanize decorator."""
    # pylint: disable=unused-variable, unidiomatic-typecheck
    @romanize()
    def foo(bar: str) -> str:
        return bar

    assert foo('Привет') == 'Privet'

    @romanize('foo')
    def foo1(bar: str) -> str:
        return bar

    try:
        foo1('Привет')
    except Exception as err:
        assert type(err) == UnsupportedLocale
        assert str(err) == 'foo'



# Generated at 2022-06-23 20:56:10.910429
# Unit test for function romanize
def test_romanize():
    # Русский aлфавит: АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ
    # It means Russian alphabet
    alphabet = "abvgde'zhzijklmnoprstufhzschsch'y'ejy"
    # Actually, we don't know what `func` returns, so we will pass
    # it some random value
    assert romanize(locale='ru')(lambda x: alphabet)(42) == alphabet
    assert romanized(locale='ru')(lambda x: alphabet)(42) == alphabet

# Generated at 2022-06-23 20:56:15.395848
# Unit test for function romanize
def test_romanize():
    # GIVEN a transliterated text
    text = 'Русский'
    # WHEN romanize it
    romanized_text = romanize('ru')(lambda: text)()
    # THEN it should be 'Russian'
    assert romanized_text == 'Russian'

# Generated at 2022-06-23 20:56:19.116984
# Unit test for function romanize
def test_romanize():
    print('Unit test for decorator romanize')

    @romanize('ru')
    def romanize_test():
        return 'Здравствуйте, Мир!'

    assert romanize_test() == 'Zdravstvuyte, Mir!'

# Generated at 2022-06-23 20:56:24.494445
# Unit test for function romanize
def test_romanize():
    """Test for romanized()."""

    from .. import Person
    from ..providers.utils.romanization import cyr2lat

    person = Person(locale='ru')

    def foo():
        person.full_name()

    romanize_foo = romanize('ru')(foo)
    assert cyr2lat(person.full_name()) == romanize_foo()

    romanize_foo = romanized('ru')(foo)
    assert cyr2lat(person.full_name()) == romanize_foo()

# Generated at 2022-06-23 20:56:26.016831
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-23 20:56:30.335228
# Unit test for function romanize
def test_romanize():
    decor_func = romanize(locale='ru')
    assert decor_func(lambda a: ''.join((a['personal.name.first_name'], ' ',
                                         a['personal.name.last_name'], ' ',
                                         a['personal.name.patronymic']))) == 'Artur Gavrilov Kholodov'

# Generated at 2022-06-23 20:56:34.028447
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')
    assert romanized(locale='uk')
    assert romanized(locale='kk')

# Generated at 2022-06-23 20:56:39.098631
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Русская азбука')() == 'Russian alphabet'
    assert romanize()(lambda: 'Русская азбука')() == 'Russian alphabet'
    assert romanize()(lambda: 'Русская азбука')() == 'Russian alphabet'

# Generated at 2022-06-23 20:56:40.050056
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)

# Generated at 2022-06-23 20:56:47.674920
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    from mimesis.providers import Internet

    provider = Internet(locale='ru')
    assert provider.jpeg() == 'example.jpeg'
    assert provider.jpeg(romanize=True) == 'example.jpeg'

    provider = Internet(locale='uk')
    assert provider.jpeg() == 'example.jpeg'
    assert provider.jpeg(romanize=True) == 'example.jpeg'

# Generated at 2022-06-23 20:56:52.495005
# Unit test for function romanize
def test_romanize():

    def dummy():
        return "Майский"

    @romanize('ru')
    def dummy_decorated():
        return "Майский"

    assert dummy_decorated() == 'Mayskiy'
    assert dummy() == "Майский"

# Generated at 2022-06-23 20:56:55.655457
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    person = Person('ru')
    assert person.full_name(romanized=True) in person.full_name().split(' ')

# Generated at 2022-06-23 20:56:56.592355
# Unit test for function romanize
def test_romanize():
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 20:57:02.220280
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    pass
    # alphabet = ''.join(data.ROMANIZATION_DICT['ru'])
    # assert len(alphabet) == 32
    # alphabet = ''.join(data.ROMANIZATION_DICT['uk'])
    # assert len(alphabet) == 32
    # alphabet = ''.join(data.ROMANIZATION_DICT['kk'])
    # assert len(alphabet) == 32

# Generated at 2022-06-23 20:57:05.313570
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda self: self.random.choice(('Привет', 'Буржуй')))() == 'Privet'



# Generated at 2022-06-23 20:57:16.413592
# Unit test for function romanize
def test_romanize():
    # Arrange
    expected = 'Krаf моchвиk моy был aмaтерным'
    result = ''

    # Act
    @romanize(locale='ru')
    def rus_test():
        nonlocal result
        result = 'Краф мочвик мой был аматерным'
    rus_test()

    # Assert
    assert result == expected

    # Act
    @romanize(locale='uk')
    def ukr_test():
        nonlocal result
        result = 'Краф мочвик мой был аматерным'
    ukr_test

# Generated at 2022-06-23 20:57:19.664013
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func():
        return 'Я хочу это.'

    assert func() == 'Ya khotchu eto.'

# Generated at 2022-06-23 20:57:29.699751
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 1)() == '1'
    assert romanized('ru')(lambda x, y: 1 + y)(1, 2) == '3'
    assert romanized('ru')(lambda x: 1)() == '1'

    assert romanize('ru')(lambda: 'Привет, сука')() == 'Privet, suka'
    assert romanize('uk')(lambda: 'Привіт, сука')() == 'Pryvit, suka'
    assert romanize('kk')(lambda: 'Привет, сука')() == 'Privet, suka'

# Generated at 2022-06-23 20:57:32.055555
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def ru_name():
        return 'Антон'

    assert ru_name() == 'Anton'

# Generated at 2022-06-23 20:57:40.902622
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_name():
        return 'Татьяна'

    assert russian_name() == 'Tatyana'

    @romanize(locale='uk')
    def ukrainian_name():
        return 'Оксана'

    assert ukrainian_name() == 'Oksana'

    @romanize(locale='kk')
    def kazakh_name():
        return 'Әмирхан'

    assert kazakh_name() == 'Emirhan'