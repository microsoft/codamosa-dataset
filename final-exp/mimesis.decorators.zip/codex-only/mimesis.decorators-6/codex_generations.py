

# Generated at 2022-06-23 20:47:42.077724
# Unit test for function romanize
def test_romanize():
    assert data.Person('ru').name(patronymic=False) == 'Анна Галкина'



# Generated at 2022-06-23 20:47:43.040322
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "")() == ''


# Generated at 2022-06-23 20:47:46.677080
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    from mimesis.enums import Locale
    from mimesis.providers.numbers import Numbers

    n = Numbers(Locale.EN)
    assert len(n.romanize(123)) == 3

# Generated at 2022-06-23 20:47:50.781622
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo():
        return 'Привет, как дела?'

    assert foo() == 'Privet, kak dela?'

# Generated at 2022-06-23 20:47:52.665296
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Федор')() == 'Fedor'

# Generated at 2022-06-23 20:47:56.279586
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_romanized_text():
        return get_title()

    romanized_text = get_romanized_text()
    assert romanized_text.isascii()
    assert romanized_text.isalpha()

# Generated at 2022-06-23 20:48:04.739569
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Съешь ещё этих мягких булок')() == \
        'S’esh’ escho etikh myagkikh bulok'
    assert romanize(locale='uk')(lambda: 'Ми голосуємо за вибір консультанта')() == \
        'Mi holosuyemo za vybir konsultanta'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:48:09.368391
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')(lambda: 'some text') == 'somе tеxt'
    assert romanize('ru')(lambda: 'привет') == 'privyеt'
    assert romanize('uk')(lambda: 'привіт') == 'privit'

# Generated at 2022-06-23 20:48:13.925447
# Unit test for function romanize
def test_romanize():
    def romanize_func():
        return 'Алексей'

    result = romanize_func()
    assert result == 'Алексей'

    romanize_func = romanize('ru')(romanize_func)
    result = romanize_func()
    assert result == 'Aleksey'



# Generated at 2022-06-23 20:48:17.525369
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func():
        return 'привет, я очень крутой'

    assert func() == 'privet, ya ochen\' krutoy'

# Generated at 2022-06-23 20:48:20.965551
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('абвг') == 'abvg'
    assert romanize('uk')('будинок') == 'budynok'
    assert romanize('kk')('красивый') == 'krasivyj'

# Generated at 2022-06-23 20:48:30.026165
# Unit test for function romanize
def test_romanize():
    """Test romanize function.
    """
    # In Russian
    assert romanized('ru')(lambda x: 'привет')() == 'privet'
    assert romanized('uk')(lambda x: 'привіт')() == 'pryvit'
    assert romanized('kk')(lambda x: 'сәлем')() == 'salem'
    assert romanized('kk')(lambda x: 'бұл-тұл')() == 'bul-tul'

    # In Japanese
    assert romanized('ja')(lambda x: 'こんにちは')() == 'konnichiha'

# Generated at 2022-06-23 20:48:41.198109
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    @romanize('ru')
    def emoji(self):
        # Здесь может быть какой-нибудь код
        return '👻🐘🌳🌷📱'

    assert emoji(RussiaSpecProvider()) == '😺😃😄😇😈'

    @romanize('uk')
    def test(self):
        return '🐘🌳🌷📱'

    assert test(RussiaSpecProvider()) == '😺😄😇😈'

    @romanize('kk')
    def test2(self):
        return '🐘🌳🌷📱'


# Generated at 2022-06-23 20:48:44.032132
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Алло, Гарри Поттер!'

    assert foo() == 'Allo, Gary Potter!'

# Generated at 2022-06-23 20:48:46.706156
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет Мир') == 'Privet Mir'
    assert romanize()('Машина') == 'Mashina'
    assert romanize()('Шоссе') == 'Shosse'

# Generated at 2022-06-23 20:48:50.114093
# Unit test for function romanize
def test_romanize():
    # Test for romanize
    assert romanize()
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')

# Generated at 2022-06-23 20:48:52.526140
# Unit test for function romanize
def test_romanize():
    assert all(romanize('ru')(lambda : 'Общество')().endswith('stvo'))
    assert all(romanize('en')(lambda : 'Общество')().endswith('Obschestvo'))

# Generated at 2022-06-23 20:48:58.304313
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT

    assert 'Русский язык' in ROMANIZATION_DICT['ru'].keys()
    assert 'Қазақ тілі' in ROMANIZATION_DICT['kk'].keys()
    assert 'Українська мова' in ROMANIZATION_DICT['uk'].keys()

# Generated at 2022-06-23 20:49:05.761964
# Unit test for function romanize
def test_romanize():
    alphabets = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
                 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
                 'u', 'v', 'w', 'x', 'y', 'z'}
    numbers = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'}

# Generated at 2022-06-23 20:49:15.307209
# Unit test for function romanize
def test_romanize():
    def test_func():
        return 'Привет Мир!'

    @romanize()
    def test_ru_func():
        return 'Привет Мир!'

    assert test_ru_func() == 'Privet Mir!'

    @romanize('kk')
    def test_kk_func():
        return 'Привет Мир!'

    assert test_kk_func() == 'Prıvet Mır!'

    @romanize('uk')
    def test_uk_func():
        return 'Привет Мир!'

    assert test_uk_func() == 'Pryvit Mir!'


# Generated at 2022-06-23 20:49:18.291470
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='')(lambda: 'Привіт')() == 'Pryvit'

# Generated at 2022-06-23 20:49:19.507414
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')

# Generated at 2022-06-23 20:49:25.108421
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'privit'
    assert romanize('kk')(lambda: 'сәлем')() == 'salem'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:49:31.855715
# Unit test for function romanize
def test_romanize():
    def foo():
        return 'Клевый яблоко-персиковые'

    assert romanize(locale='ru')(foo)() == 'Klevyy yabloko-persikovye'
    assert romanize(locale='uk')(foo)() == 'Klewyj jabloko-persikovije'
    assert romanize(locale='kk')(foo)() == 'Kledvıy jabloko-persikovıye'

# Generated at 2022-06-23 20:49:32.413096
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:49:39.429773
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    _localized = Language.EN.localize
    romanize = _localized('romanize')
    # 'Привет' -> 'Privet'
    assert romanize('Привет') == 'Privet'

    _localized = Language.RU.localize
    romanize = _localized('romanize')
    # 'Привет' -> 'Pryvit'
    assert romanize('Привет') == 'Pryvit'

    _localized = Language.UK.localize
    romanize = _localized('romanize')
    # 'Привіт' -> 'Pryvit'

# Generated at 2022-06-23 20:49:43.260998
# Unit test for function romanize
def test_romanize():
    import mimesis
    data = mimesis.Russian()

    t = data.test_romanize()
    assert t == 'niu'

    t = data.test_romanize()
    assert t == 'oge'

# Generated at 2022-06-23 20:49:47.656745
# Unit test for function romanize
def test_romanize():
    assert (romanize()(lambda x: 'Привет!') == 'Privet!')
    assert (romanize('uk')(lambda x: 'Привіт!') == 'Pryvit!')
    assert (romanize('kk')(lambda x: 'Сәлеметсіз бе?') == 'Salemetsiz be?')



# Generated at 2022-06-23 20:49:53.678973
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Спасибо')() == 'Spasibo'
    assert romanize('ru')(lambda: 'Вася')() == 'Vasya'
    assert romanize('ru')(lambda: 'Петр')() == 'Petr'
    assert romanize('ru')(lambda: 'Антон')() == 'Anton'
    assert romanize('ru')(lambda: 'Михаил')() == 'Mikhail'
    assert romanize('ru')(lambda: 'Анна')() == 'Anna'
    assert romanize('ru')(lambda: 'Александр')() == 'Aleksandr'

# Generated at 2022-06-23 20:50:03.534477
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'функция романизации'

    assert foo() == 'funktsiya romanizatsii'

    @romanize('uk')
    def foo_1():
        return 'функція романізації'

    assert foo_1() == 'funktsiya romanizatsiyi'

    @romanize('kk')
    def foo_2():
        return 'романдау функциясы'

    assert foo_2() == 'romanʹdaw funktʹsïyası'

    # Test for wrong locale

# Generated at 2022-06-23 20:50:06.105509
# Unit test for function romanize
def test_romanize():

    @romanized()
    def test_romanize_wrapper():
        return 'Тестовая строка'

    assert test_romanize_wrapper() == 'Testovaya stroka'

# Generated at 2022-06-23 20:50:13.065654
# Unit test for function romanize
def test_romanize():
    assert romanize()('привет') == 'privet'
    assert romanize()('Привет') == 'Privet'
    assert romanize()('красота') == 'krasota'
    assert romanize()('Красота') == 'Krasota'
    assert romanize()('Привет, друг!') == 'Privet, drug!'

# Generated at 2022-06-23 20:50:20.763207
# Unit test for function romanize
def test_romanize():
    class String(object):
        @romanize('ru')
        def __init__(self, value: str) -> None:
            self.value = value

    class String2(object):
        @romanize('de')
        def __init__(self, value: str) -> None:
            self.value = value

    s = String('Тест')
    assert s.value == 'Test'

    s = String('Тест3')
    assert s.value == 'Test3'

    s = String('!@#$%^&*()_+')
    assert s.value == '!@#$%^&*()_+'

    with pytest.raises(UnsupportedLocale):
        s = String2('Test')

test_romanize()

# Generated at 2022-06-23 20:50:29.120533
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru') is not None
    assert romanized(locale='ru') is not None

    assert romanize(locale='ru')(lambda: '') is not None
    assert romanize(locale='ru')(lambda: '123')() == '123'
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Pryviet'

    assert romanized(locale='ru')(lambda: '') is not None
    assert romanized(locale='ru')(lambda: '123')() == '123'
    assert romanized(locale='ru')(lambda: 'Привет')() == 'Pryviet'

# Generated at 2022-06-23 20:50:40.416038
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'привет') == 'privet'
    assert romanize('uk')(lambda x: 'привіт') == 'privit'
    assert romanize('kk')(lambda x: 'сәлем') == 'salem'
    assert romanize('ru')(lambda x: 'Новоэкономическая эпоха') == 'Novoehkonomicheskaiaehpoha'

# Generated at 2022-06-23 20:50:49.257272
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'помидор')() == 'pomidor'
    assert romanized(locale='ru')(lambda: 'вино')() == 'vino'
    assert romanized(locale='uk')(lambda: 'помидор')() == 'pomidor'
    assert romanized(locale='uk')(lambda: 'вино')() == 'vyno'
    assert romanized(locale='kk')(lambda: 'помидор')() == 'pomidor'
    assert romanized(locale='kk')(lambda: 'вино')() == 'vino'

# Generated at 2022-06-23 20:50:52.415919
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_test():
        return 'Большой Тест'

    result = romanize_test()
    assert result == 'Bolshoy Test'



# Generated at 2022-06-23 20:50:59.787675
# Unit test for function romanize
def test_romanize():
    # _test_romanize_deco(func, args, kwargs, result, exception, exp_result):
    assert _test_romanize_deco(
        _get_numbers,
        [[], {'locale': 'en'}],
        {},
        '0123456789',
        UnsupportedLocale,
        {'locale': 'en'},
    )
    assert _test_romanize_deco(
        _get_numbers,
        [[], {'locale': 'ru'}],
        {},
        '0123456789',
        Exception,
        {'locale': 'ru'},
    )



# Generated at 2022-06-23 20:51:08.744597
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address as AddressProvider

    fake = AddressProvider('ru')

    assert fake.postal_code() == '650089'
    assert fake.region() == 'Приморский край'
    assert fake.district() == 'Камчатский район'
    assert fake.city() == 'Петропавловск-Камчатский'
    assert fake.street() == 'Суворова'



# Generated at 2022-06-23 20:51:16.288508
# Unit test for function romanize
def test_romanize():
    # In Russian alphabet there are 32 different letters.
    alphabet_ru = data.ROMANIZATION_DICT['ru']
    assert len(alphabet_ru) == 32

    # In Ukrainian alphabet there are 32 different letters.
    alphabet_uk = data.ROMANIZATION_DICT['uk']
    assert len(alphabet_uk) == 32

    # In Kazakh alphabet there are 33 different letters.
    alphabet_kk = data.ROMANIZATION_DICT['kk']
    assert len(alphabet_kk) == 33

# Generated at 2022-06-23 20:51:22.360653
# Unit test for function romanize
def test_romanize():
    assert 'aaa' == romanized(locale='aaa')(lambda: 'aaa')()
    assert 'aaa' == romanized(locale='ru')(lambda: 'aaa')()
    assert 'aaa' == romanized(locale='uk')(lambda: 'aaa')()
    assert 'aaa' == romanized(locale='kk')(lambda: 'aaa')()
    assert 'aaa' == romanized(locale='us')(lambda: 'ааа')()

# Generated at 2022-06-23 20:51:29.882869
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'Привет, мир')() == 'Privet, mir'
    assert romanized('uk')(lambda : 'Привіт, світе')() == 'Privit, svite'
    assert romanized('kk')(lambda : 'Сәлем, дүние')() == 'Sälem, dünie'



# Generated at 2022-06-23 20:51:33.360415
# Unit test for function romanize
def test_romanize():  # pragma: no cover
    @romanize('ru')
    def cyrillic_string(seed=None) -> str:
        return 'привет мир'

    assert cyrillic_string() == 'privet mir'

# Generated at 2022-06-23 20:51:39.586701
# Unit test for function romanize
def test_romanize():
    txt = 'Съешь ещё этих мягких французских булок, да выпей чаю.'
    expected_result = 'Syesh yeshyo jetix mjagkix francuzskix bulok,' \
                      'da vypey chayu.'
    assert romanize(locale='ru')(lambda x: txt)() == expected_result


# Integration test for class Person

# Generated at 2022-06-23 20:51:42.811923
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')(lambda: 'Дарын! Ба? Кешіріңіз')=='Darın! Ba? Kesiriniiz'

# Generated at 2022-06-23 20:51:45.107253
# Unit test for function romanize
def test_romanize():
    token = data.Token('en')
    assert token.word(use_romanization=True, locale='ru') == 'zhizel'

# Generated at 2022-06-23 20:51:47.888685
# Unit test for function romanize
def test_romanize():
    assert romanized()('Михаил Иванович Фрунзе') == \
        'Mikhail Ivanovich Frunze'

# Generated at 2022-06-23 20:51:56.057030
# Unit test for function romanize

# Generated at 2022-06-23 20:52:01.172143
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers import Address
    from mimesis.providers.address import Address as AddressRuUk

    assert isinstance(Address(), Address)
    assert isinstance(Address(Language.RU), AddressRuUk)
    assert isinstance(Address(Language.UK), AddressRuUk)



# Generated at 2022-06-23 20:52:04.532741
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def hello_world():
        return 'Привет мир'

    assert hello_world() == 'Privet mir'


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:52:09.656545
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.en import English
    en = English()
    assert not romanize('ru')(en.words)(3, as_list=True)
    assert not romanize('uk')(en.words)(3, as_list=True)
    assert not romanize('kk')(en.words)(3, as_list=True)

# Generated at 2022-06-23 20:52:12.375275
# Unit test for function romanize
def test_romanize():
    @romanize('kk')
    def test_func():
        return 'Тест'

    assert test_func() == 'Test'

# Generated at 2022-06-23 20:52:17.356664
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.numbers

    @romanize(locale='ru')
    def test(length=6):
        return mimesis.builtins.numbers.Integer(
            length=length,
            seed=1
            ).create()

    assert test() == '891013'
    assert test(length=2) == '89'
    assert test(length=0) == ''
    assert test(length=1) == '8'



# Generated at 2022-06-23 20:52:21.417722
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address

    address = Address('uk_UA')
    assert 'Платівка' == address.prefecture()
    assert 'Платівка' == address.prefecture(romanize=True)

# Generated at 2022-06-23 20:52:30.013089
# Unit test for function romanize
def test_romanize():
    r = 'Mxncxmxcvct'
    t = 'Maximkract'
    assert r.lower() == romanize('en')(t)

    r = 'Привет, мир!'
    t = 'Privet, mir!'
    assert r.lower() == romanize('ru')(t)

    r = 'Прывітаньне, Свет!'
    t = 'Pryvitanie, Svet!'
    assert r.lower() == romanize('be')(t)

    r = 'Поздоровлення, Світ!'
    t = 'Pozdorovlennya, Svit!'

# Generated at 2022-06-23 20:52:35.860118
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_ru_string(length: int = 8) -> str:
        pass

    result_string = get_ru_string()
    if len(result_string) != 8:
        raise AssertionError(
            "Romanize function doesn't work."
            "It's not equal to 8.")

# Generated at 2022-06-23 20:52:40.340847
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    addr = Address(locale=Locale.KAZAKH)
    assert romanize(locale=Locale.KAZAKH)(addr._get_full_address)(
    ) == 'Elenovskaya st., bld. 7, Almaty, Kazakhstan'

# Generated at 2022-06-23 20:52:47.700455
# Unit test for function romanize
def test_romanize():
    import unittest
    from mimesis.enums import Locale
    from mimesis.builtins import RussianSpecProvider

    class TestRomanize(unittest.TestCase):

        def setUp(self):
            self.russian = RussianSpecProvider

        def test_non_ru_locale(self):
            self.assertRaises(UnsupportedLocale,
                              self.russian(locale=Locale.UK).romanize)


test_romanize()

# Generated at 2022-06-23 20:52:52.729816
# Unit test for function romanize
def test_romanize():
    def foo(locale='ru'):
        local = data.LOCALES[locale]
        return local.romanization('Привет')

    r_func = romanize(locale='ru')(foo)
    assert r_func == 'Privet'



# Generated at 2022-06-23 20:52:55.355940
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:52:57.031578
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    p = Person()
    assert p.romanize().startswith('Anton') == True

# Generated at 2022-06-23 20:53:08.467019
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    def test_romanize(locale: str = '') -> Callable:
        """Romanize the cyrillic text.

        Transliterate the cyrillic script into the latin alphabet.

        .. note:: At this moment it works only for `ru`, `uk`, `kk`.

        :param locale: Locale code.
        :return: Romanized text.
        """


# Generated at 2022-06-23 20:53:15.751370
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    person = Person('ru')
    person.set_provider(RussiaSpecProvider)

    assert 'Марина' == person.full_name(gender=Gender.FEMALE)
    assert 'Марина' == person.full_name(gender=Gender.FEMALE)

    assert 'Гервард' == person.full_name(gender=Gender.MALE)
    assert 'Гервард' == person.full_name(gender=Gender.MALE)

# Generated at 2022-06-23 20:53:18.251353
# Unit test for function romanize
def test_romanize():

    @romanize()
    def get_text():
        return 'текст'

    assert get_text() == 'tekst'

# Generated at 2022-06-23 20:53:20.111278
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanized('ru')

# Generated at 2022-06-23 20:53:22.936585
# Unit test for function romanize
def test_romanize():
    txt = romanized('ru')(lambda : 'Мама мыла раму')()
    assert txt == 'Mama myla ramu'

# Generated at 2022-06-23 20:53:26.986394
# Unit test for function romanize
def test_romanize():
    r = data.Data('en')
    r.romanize

    assert r.romanize('Привет, мир!') == 'Privet, mir!'

test_romanize()

# Generated at 2022-06-23 20:53:36.878980
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'папа')() == 'papa'
    assert romanize('uk')(lambda: 'папа')() == 'papa'
    assert romanize('kk')(lambda: 'папа')() == 'papa'
    assert romanize('en')(lambda: 'папа')() == 'папа'
    assert romanize('ru')(lambda: 'Hello')() == 'Hello'
    assert romanize('uk')(lambda: 'Hello')() == 'Hello'
    assert romanize('kk')(lambda: 'Hello')() == 'Hello'
    assert romanize('en')(lambda: 'Hello')() == 'Hello'

# Generated at 2022-06-23 20:53:43.919153
# Unit test for function romanize
def test_romanize():
    russian_text = romanize('ru')(lambda: 'Весь алфавит')()
    ukrainian_text = romanize('uk')(lambda: 'Весь алфавит')()
    kazakh_text = romanize('kk')(lambda: 'Весь алфавит')()
    assert russian_text == 'Vesʹ alfavit'
    assert ukrainian_text == 'Vesʹ alfavit'
    assert kazakh_text == 'Vesʹ alfavit'



# Generated at 2022-06-23 20:53:46.783236
# Unit test for function romanize
def test_romanize():
    x = romanize()
    assert x('Большой текст') == 'Bolshoy tekst'



# Generated at 2022-06-23 20:53:49.173773
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')().startswith('Privet')

# Generated at 2022-06-23 20:53:54.530055
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Cyrillic, RussianSpecProvider
    assert romanize()(RussianSpecProvider.title)() == 'Ob' + \
        Cyrillic.breve() + 'yasnitel' + Cyrillic.acute() + 'naya zapis' + \
        Cyrillic.acute()

# Generated at 2022-06-23 20:53:58.157082
# Unit test for function romanize
def test_romanize():
    assert 'string' == romanized('ru')(lambda x: 'стринг')('')
    assert 'string' == romanized('uk')(lambda x: 'стринг')('')
    assert 'string' == romanized('kk')(lambda x: 'стринг')('')

# Generated at 2022-06-23 20:54:02.309505
# Unit test for function romanize
def test_romanize():
    """Test for romanization of cyrillic text."""
    assert romanized(str)('Здравствуй мир') == 'Zdravstvuj mir'

# Generated at 2022-06-23 20:54:04.315723
# Unit test for function romanize
def test_romanize():
    assert romanize()('привет') == 'privet'



# Generated at 2022-06-23 20:54:09.946473
# Unit test for function romanize
def test_romanize():
    russian = ('АБВГДЕЁЖЗИIЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'
               'ааааааааааааааааааааааааааааааааа')


# Generated at 2022-06-23 20:54:13.710287
# Unit test for function romanize
def test_romanize():
    def func():
        return 'Привет, Мир!'

    assert romanize()(func)() == 'Privet, Mir!'
    assert romanized()(func)() == 'Privet, Mir!'

# Generated at 2022-06-23 20:54:16.425557
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_name():
        return 'Александр'
    assert get_name() == 'Aleksandr'

# Generated at 2022-06-23 20:54:20.929038
# Unit test for function romanize
def test_romanize():
    r = romanize(locale='ru')(lambda: 'Привет, мир!')
    assert r == 'Privet, mir!'
    assert romanized(locale='ru')(lambda: 'Привет, мир!') == 'Privet, mir!'

# Generated at 2022-06-23 20:54:32.170237
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    # Проверка вызова функции оборачивания другой функции.
    # Check the call of the wrapper function.
    @romanize(locale='ru')
    def romanized_text(x):
        return x

    assert isinstance(romanized_text, Callable)

    # Проверка вызова функции оборачивания другой функ

# Generated at 2022-06-23 20:54:34.895566
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_foo():
        return "Привет мир!"

    assert get_foo() == "Privet mir!"

# Generated at 2022-06-23 20:54:40.623328
# Unit test for function romanize
def test_romanize():
    from mimesis import Generic
    from mimesis.builtins import RussiaSpecProvider

    g = Generic('ru')
    ru = RussiaSpecProvider('ru')
    eng = RussiaSpecProvider('en')
    assert ru.full_name('Фамилия Имя Отчество') == \
           eng.full_name
    assert ru.romanize(g.name()) == eng.name()

# Generated at 2022-06-23 20:54:48.550236
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import BelarusianSpecProvider
    from mimesis.providers.address import Address
    from mimesis.enums import Gender
    a = Address(locale='by')
    be = BelarusianSpecProvider(gender=Gender.MALE)
    assert a.street_suffix() == 'вулiца'
    assert be.full_name() == 'Сямён Зайцев'

# Generated at 2022-06-23 20:54:56.847759
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'русский')() == 'russkiy'
    assert romanized('uk')(lambda: 'Україна')() == 'Ukrayina'
    assert romanized('kk')(lambda: 'Казахстан')() == 'Qazaqstan'

    # Test for unsupported locale
    try:
        romanized('ukr')(lambda: 'Ukraina')()
    except UnsupportedLocale as err:
        assert err.locale == 'ukr'

# Generated at 2022-06-23 20:55:04.555512
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanized_ru():
        return 'Тестовая строка'
    assert romanized_ru() == 'Testovaya stroka'

    @romanize(locale='kk')
    def romanized_kk():
        return 'Тестовая строка'
    assert romanized_kk() == 'Téstovaya stróka'

    @romanize(locale='uk')
    def romanized_uk():
        return 'Тестовая строка'
    assert romanized_uk() == 'Tetovaya stríka'

# Generated at 2022-06-23 20:55:08.263487
# Unit test for function romanize
def test_romanize():
    """Test if decorator `romanize` works as expected

    :return:
    """
    assert romanized('kk')(lambda: "Алтын Төрөл")() == "Алтын Торол"

# Generated at 2022-06-23 20:55:11.956109
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'карамель')() == 'karamel'
    assert romanized(locale='uk')(lambda: 'карамель')() == 'karamel'
    assert romanized(locale='kk')(lambda: 'карамель')() == 'karamel'

# Generated at 2022-06-23 20:55:17.382503
# Unit test for function romanize
def test_romanize():
    def dummy_function():
        """это должен быть романизированный текст и он романизирован"""
        pass

    assert ''.join(dummy_function.__doc__.split()) == \
        'этодолженбытьроманизированныйтекстионроманизирован'
    assert romanized(dummy_function)() == \
        'etodolzhenbytromanizirovannyjtekstiionromanizirovan'

# Generated at 2022-06-23 20:55:18.642483
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'тест')() == 'test'

# Generated at 2022-06-23 20:55:20.973130
# Unit test for function romanize
def test_romanize():
    # TODO: Write tests
    pass



# Generated at 2022-06-23 20:55:29.536717
# Unit test for function romanize
def test_romanize():
    class TestRomanize:

        def __init__(self, locale='en'):
            self.locale = locale

        @romanize(locale='ru')
        def rus(self) -> str:
            return 'привет'

        @romanized(locale='kk')
        def kaz(self) -> str:
            return 'сәлем'

    t = TestRomanize(locale='ru')
    assert t.rus() == 'privet'

    t = TestRomanize(locale='kk')
    assert t.kaz() == 'salem'

# Generated at 2022-06-23 20:55:32.339479
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Кошка')() == 'Koshka'



# Generated at 2022-06-23 20:55:38.090848
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def first_name_ru():
        return 'Никита'

    assert first_name_ru() == 'Nikita'

    @romanized('uk')
    def first_name_uk():
        return 'Вероніка'

    assert first_name_uk() == 'Veronika'

    @romanized('kk')
    def first_name_kk():
        return 'Саян'

    assert first_name_kk() == 'Sayan'

# Generated at 2022-06-23 20:55:40.721217
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize function."""
    romanize_func = romanize('ru')
    assert romanize_func



# Generated at 2022-06-23 20:55:48.815593
# Unit test for function romanize
def test_romanize():
    # Arrange
    locale = 'ru'
    alphabet = {s: s for s in
                    ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT[locale],
        **data.COMMON_LETTERS,
    })
    russian_text = 'Привет мир!'

    # Act
    function = romanized(locale)
    result = function(lambda s: s)(russian_text)

    # Assert
    for i in russian_text:
        assert i in alphabet

# Generated at 2022-06-23 20:55:51.798520
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Сергей Романович Невский") == "Sergej Romanovic Nevskij"

# Generated at 2022-06-23 20:55:55.855772
# Unit test for function romanize
def test_romanize():
    """Test for romanization."""
    @romanize
    def romanize_test(locale: str = ''):
        """Test romanization.

        :param locale: Locale code.
        """
        return ''

    assert romanize_test(locale='ru') == ''

# Generated at 2022-06-23 20:55:59.735311
# Unit test for function romanize
def test_romanize():
    pass
    # def foo(inp, out):
    #     @romanize()
    #     def romanized(text):
    #         return text
    #     assert romanized(inp) == out
    #
    # foo('Привет, мир!', 'Privet, mir!')

# Generated at 2022-06-23 20:56:04.650683
# Unit test for function romanize
def test_romanize():
    romanized_func = romanize('ru')
    func = romanized_func(lambda x: x)

    assert func('абв') == 'abv'
    assert func('Привет, Мир!') == 'Privet, mir!'

# Generated at 2022-06-23 20:56:05.394824
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:56:09.128954
# Unit test for function romanize
def test_romanize():
    text = 'русский текст'
    rus_text = rus(pattern='#word# #word#')

    assert rus_text != text
    assert romanized('ru')(russian_text) == text



# Generated at 2022-06-23 20:56:13.594282
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_text(size=64):
        return 'Красивая строка'
    
    assert get_text() == 'Krasívaya stróka'

# Generated at 2022-06-23 20:56:19.097942
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize('ru')(lambda x: 'Россия')() == 'Rossiya'
    assert romanize('uk')(lambda x: 'Україна')() == 'Ukrayina'
    assert romanize('kk')(lambda x: 'Қазақстан')() == 'Qazaqstan'

    assert romanized('ru')(lambda x: 'Россия')() == 'Rossiya'
    assert romanized('uk')(lambda x: 'Україна')() == 'Ukrayina'
    assert romanized('kk')(lambda x: 'Қазақстан')() == 'Qazaqstan'

# Generated at 2022-06-23 20:56:21.497440
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Санкт-Петербург') == 'Sankt-Peterburg'

# Generated at 2022-06-23 20:56:32.777895
# Unit test for function romanize
def test_romanize():
    assert ''.join([romanized()(a) for a in 'Юлия']) == 'Yuliya'
    assert ''.join([romanized()(b) for b in 'Магомед']) == 'Magomed'
    assert ''.join([romanized()(c) for c in 'Салават']) == 'Salavat'
    assert ''.join([romanized()(d) for d in 'Виктор']) == 'Viktor'
    assert ''.join([romanized()(e) for e in 'Павел']) == 'Pavel'
    assert ''.join([romanized()(f) for f in 'Антон']) == 'Anton'

# Generated at 2022-06-23 20:56:36.722821
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def generate_random_word():
        return 'Переведи на латиницу'

    assert generate_random_word() == 'Perevedi na latinitsu'

# Generated at 2022-06-23 20:56:43.962974
# Unit test for function romanize
def test_romanize():
    text = "Съешь ещё этих мягких французских булок, да выпей чаю."

    @romanize(locale='ru')
    def get_text(text):
        return text

    t = get_text(text)

# Generated at 2022-06-23 20:56:47.586198
# Unit test for function romanize
def test_romanize():
    @romanize('kk')
    def romanized_str(str: str) -> str:
        return str

    assert romanized_str('Амирхан') == 'Amirhan'

# Generated at 2022-06-23 20:56:48.176221
# Unit test for function romanize
def test_romanize():
    assert romanize is romanized



# Generated at 2022-06-23 20:56:58.477415
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    @romanize(locale='ru')
    def test_ru(self):
        return 'йцукенгшщзхъфывапролджэячсмитьбю'

    assert test_ru(None) == 'ycukengshschzhhfvaproldjezachsmitybju'

    @romanize(locale='uk')
    def test_uk(self):
        return 'йцукенгшщзхїфівапролджєячсмитьбю'


# Generated at 2022-06-23 20:56:59.385177
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()

# Generated at 2022-06-23 20:57:03.817190
# Unit test for function romanize
def test_romanize():
    func = romanize('ru')

    @func
    def func1():
        return 'Тестовый текст'

    assert func1() == 'Testovyi tekst'

    @func
    def func2():
        return 'Еще один текст'

    assert func2() == 'Esche odin tekst'

# Generated at 2022-06-23 20:57:15.391455
# Unit test for function romanize
def test_romanize():
    def string(locale: str = ''):
        return 'Предоставление доступа от имени сервисного пользователя'

    romanized_string = romanize(locale='ru')(string)
    assert romanized_string() == 'Predostavlenie dostupa ot imeni ' \
        'servisnogo polzovatelya'

    romanized_string = romanize(locale='uk')(string)
    assert romanized_string() == 'Predostavlennya dostupu vid imeni ' \
        'servisnogo korystuvacha'

    romanized_string

# Generated at 2022-06-23 20:57:21.626594
# Unit test for function romanize
def test_romanize():
    locale = 'ru'

# Generated at 2022-06-23 20:57:24.196974
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Александр')() == 'Aleksandr'

# Generated at 2022-06-23 20:57:25.775126
# Unit test for function romanize
def test_romanize():
    assert data.__name__ == 'mimesis.data'

# Generated at 2022-06-23 20:57:28.956167
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    def get_text():
        """Get text."""
        return 'Мимисус предлагает вам случайный текст.'

    @romanized()
    def get_roman():
        """Get roman."""
        return get_text()

    english = 'Mimisus predlagaet vam sluchainyi tekst.'

    assert get_roman() == english

# Generated at 2022-06-23 20:57:35.588821
# Unit test for function romanize
def test_romanize():
    # Unit test must be written with romanization function,
    #  because romanize decorator mutates the __name__ attribute.
    # original_name = test_romanize.__name__
    # assert original_name == 'test_romanize'
    # test_romanize = romanize(locale='')(test_romanize)
    # assert original_name == test_romanize.__name__
    assert isinstance(romanize, Callable)
    # Below decorator must change the return value.
    @romanize(locale='ru')
    def foo() -> str:
        return 'АБВ'

    assert foo() == 'ABV'

    # Below decorator must change the return value.

# Generated at 2022-06-23 20:57:43.292715
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    # assert romanize('ru')(lambda: 'Я русский') == 'YA russkii'
    # assert romanize('kk')(lambda: 'Сайн байна уу') == 'Sain baina uu'
    # assert romanize('uk')(lambda: 'Я українець') == 'YA ukrayinec'
    # assert romanize('')(lambda: 'Я українець') == 'YA ukrayinec'