

# Generated at 2022-06-23 20:47:47.985602
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.text import Text

    text_provider = Text(Language.EN)

    @romanize(Language.RU)
    def romanize_test():
        return text_provider.text(100)

    assert isinstance(romanize_test(), str)
    assert romanize_test().isalpha()

# Generated at 2022-06-23 20:47:50.667674
# Unit test for function romanize
def test_romanize():
    """This is a test to see if this really works."""
    r = romanize('ru')(lambda: 'быстро летали')
    s = 'bystro letali'
    assert r == s

# Generated at 2022-06-23 20:48:00.880533
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    from mimesis.data import COMMON_LETTERS
    from mimesis.providers.address import Address
    from mimesis.enums import Language

    al = Address('en')
    assert ascii_letters + digits + punctuation == \
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'

    @romanize(locale=Language.EN.value)
    def r_en(text):
        return text


# Generated at 2022-06-23 20:48:08.145392
# Unit test for function romanize
def test_romanize():
    assert romanize()('Как дела?') == 'Kak dela?'
    assert romanized('ru')('Привет, мир!') == 'Privet, mir!'
    assert romanized('uk')('Привіт, світ!') == 'Pryvit, svit!'
    assert romanized('kk')('Сәлем, дүние!') == 'Sälem, dünie!'

# Generated at 2022-06-23 20:48:10.418082
# Unit test for function romanize
def test_romanize():
    pass


if __name__ == '__main__':
    # Unit test for function romanize
    test_romanize()

# Generated at 2022-06-23 20:48:18.417371
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'ПРИВЕТ')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Privit'
    assert romanize(locale='kk')(lambda: 'Сауд')() == 'Saud'
    assert romanize(locale='ru')(lambda: 'Привет!')() == 'Privet!'
    assert romanize(locale='uk')(lambda: 'Привіт!')() == 'Privit!'
    assert romanize(locale='kk')(lambda: 'Сауд!')() == 'Saud!'

# Generated at 2022-06-23 20:48:19.626221
# Unit test for function romanize
def test_romanize():
  assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:48:24.475217
# Unit test for function romanize
def test_romanize():
    class Test:
        @romanize()
        def test_default_ru(self):
            return 'тест'

        @romanize('uk')
        def test_uk(self):
            return 'перевірка'

        @romanize('kk')
        def test_kk(self):
            return 'тестілеме'

    assert Test().test_default_ru() == 'test'
    assert Test().test_uk() == 'perevirka'
    assert Test().test_kk() == 'testileme'

# Generated at 2022-06-23 20:48:26.591305
# Unit test for function romanize
def test_romanize():
    result = romanize(locale='ru')(lambda: 'привет')
    assert result == 'privet'

# Generated at 2022-06-23 20:48:31.640490
# Unit test for function romanize
def test_romanize():
    """Test romanize function as a decorator."""
    from mimesis.builtins import Person

    p = Person('ru')

    assert p.full_name() == 'Наталья Краснова'
    assert p.full_name(romanize=True) == 'Nataliya Krasnova'



# Generated at 2022-06-23 20:48:42.724551
# Unit test for function romanize
def test_romanize():
    """Test for romanize()."""
    from mimesis.providers import Address, Person
    from mimesis.enums import Gender

    _ru = Person('ru')
    _uk = Person('uk')
    _kk = Person('kk')

    person_ru = _ru.full_name(gender=Gender.MALE)
    person_uk = _uk.full_name(gender=Gender.MALE)
    person_kk = _kk.full_name(gender=Gender.MALE)

    assert person_ru == 'Федот Логинов'
    assert person_uk == 'Василь Зайцев'
    assert person_kk == 'Надир Абдуллин'

    assert _ru

# Generated at 2022-06-23 20:48:45.350830
# Unit test for function romanize
def test_romanize():
    assert ''.join([chr(i) for i in range(0x80)]) == romanize(lambda x: ''.join([chr(i) for i in range(0x80)]))('')



# Generated at 2022-06-23 20:48:47.646610
# Unit test for function romanize
def test_romanize():
    from .text import Text

    txt = Text('ru')
    text = txt.cyrillic_text()
    assert text != txt.romanize(text)

# Generated at 2022-06-23 20:48:49.912852
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:48:52.457518
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, как дела?')() == 'Privet, kak dela?'

# Generated at 2022-06-23 20:48:54.899325
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет! Как дела?')() == 'Privet! Kak dela?'

# Generated at 2022-06-23 20:49:02.470419
# Unit test for function romanize
def test_romanize():
    @romanize
    def romanized_function(string: str) -> str:
        return string

    assert romanized_function('Съешь ещё этих мягких французских булок, да выпей чаю') == \
           'Sʺeshʹ eshchë ètikh mïagkikh frantsuzskikh bulok, da vypeï chaiu'

    # Unit test for function romanized and `kk` locale
    assert romanized('kk')('Hello World!') == 'Сәлем Дүние!'

# Generated at 2022-06-23 20:49:09.200394
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    assert romanize is romanized
    assert romanize is romanize(Language.RUSSIAN)

    @romanize
    def convert():
        return 'Кириллица'

    assert convert() == 'Kirillica'

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:49:16.918837
# Unit test for function romanize

# Generated at 2022-06-23 20:49:22.878758
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Мимими')() == 'Mimimi'
    assert romanize(locale='uk')(lambda: 'Мимими')() == 'Mimimi'
    assert romanize(locale='kk')(lambda: 'Мимими')() == 'Mimimi'

# Generated at 2022-06-23 20:49:25.818469
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text

    text = Text('en')
    assert text.romanize() == None
    assert text.romanize('en') == None
    #assert text.romanize('ru') == 'Lyuba ыв'

# Generated at 2022-06-23 20:49:28.433159
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Localization
    from mimesis.providers.languages import Language

    # Romanize string
    provider = Language(Localization.CZECH)
    provider.romanize(provider.get_language())

# Generated at 2022-06-23 20:49:30.040964
# Unit test for function romanize
def test_romanize():
    f = romanize('ru')
    assert(f(lambda : 'Привет') == 'Privet')

# Generated at 2022-06-23 20:49:34.985532
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian_name():
        return 'Иван'

    assert russian_name() == 'Ivan'

    @romanize('uk')
    def ukrainian_name():
        return 'Олексій'

    assert ukrainian_name() == 'Olėksij'

    @romanize('kk')
    def kazakh_name():
        return 'Алиев'

    assert kazakh_name() == 'Aliev'

# Generated at 2022-06-23 20:49:36.402670
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    p = Person('ru')
    assert p.name() == p.romanized().name()



# Generated at 2022-06-23 20:49:45.492531
# Unit test for function romanize
def test_romanize():
    text = 'Привет мир!'
    romanized_text = ''.join([
        'P', 'r', 'i', 'v', 'e', 't', ' ', 'm', 'i', 'r', '!'
    ])
    assert romanize()(lambda: text)() == romanized_text
    assert romanize()(lambda: text)(locale='ru') == romanized_text
    assert romanized(locale='ru')(lambda: text)() == romanized_text
    try:
        assert romanize(locale='en')(lambda: text)()
    except UnsupportedLocale:
        assert True

# Generated at 2022-06-23 20:49:51.042864
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    import pytest
    from mimesis.enums import Locale

    from mimesis.builtins.text import Text, TextSpecification

    cyrillic = Text(Locale.CYRILLIC)

    @romanize('ru')
    def test_func():
        return cyrillic.personal_title()

    assert test_func() in TextSpecification().romanization_dict['ru'].values()



# Generated at 2022-06-23 20:50:02.086213
# Unit test for function romanize
def test_romanize():
    from unittest import TestCase
    import mimesis.data as data
    import mimesis.builtins as builtins
    from mimesis.enums import Localization

    class TestRomanize(TestCase):

        def setUp(self):
            self.abc = builtins.CustomText(Localization.EN)

        def test_does_list_contain_keys(self):
            for key in data.ROMANIZATION_DICT.keys():
                self.assertEqual(key, 'ru')
                self.assertEqual(key, 'uk')
                self.assertEqual(key, 'kk')

        def test_does_list_contain_values(self):
            for value in data.ROMANIZATION_DICT.values():
                self.assertIsInstance(value, dict)

# Generated at 2022-06-23 20:50:03.777965
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-23 20:50:09.062926
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, мир!')() == 'Privet, mir!'
    assert romanize('uk')(lambda: 'Вітаю, світ!')() == 'Vitayu, svit!'
    assert romanize('kk')(lambda: 'Сәлем, Дүние!')() == 'Sälem, Dünie!'

# Generated at 2022-06-23 20:50:13.523840
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda x: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda x: 'Привіт')() == 'Privit'
    assert romanize('kk')(lambda x: 'Сәлем')() == 'Salem'

# Generated at 2022-06-23 20:50:17.711954
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    @romanize()
    def dummy_func(locale: str) -> str:
        """Dummy function.

        :param locale: Locale code.
        :return: Text in cyrillic.
        """
        return 'Привет, Мир!'

    assert dummy_func('ru') == 'Privet, Mir!'



# Generated at 2022-06-23 20:50:19.812871
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test(*args, **kwargs):
        return 'Мимезис'

    assert test == 'Mimezis'

# Generated at 2022-06-23 20:50:21.884735
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Текст'
    assert foo() == 'Tekst'



# Generated at 2022-06-23 20:50:29.308055
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize_in_deco(s):
        return s

    assert romanize_in_deco('Привет!') == 'Privet!'

    @romanize('uk')
    def romanize_in_deco_uk(s):
        return s

    assert romanize_in_deco_uk('Привіт!') == 'Pryvit!'

    @romanize('kk')
    def romanize_in_deco_kk(s):
        return s


# Generated at 2022-06-23 20:50:32.650657
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    @romanize('ru')
    def test():
        return 'Тестовая строка'

    assert test() == 'TESTOVAYA STROKA'

# Generated at 2022-06-23 20:50:35.865376
# Unit test for function romanize
def test_romanize():
    assert romanized()('Железнодорожный') == 'Zheleznodorozhnyy'

# Generated at 2022-06-23 20:50:39.835120
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test_romanize_function(*args):
        return '1234. Привет, мир!'
    
    res = test_romanize_function()
    assert res == '1234. Privet, mir!'

# Generated at 2022-06-23 20:50:41.570917
# Unit test for function romanize
def test_romanize():
    clean = romanize()
    assert clean is not romanized



# Generated at 2022-06-23 20:50:45.138292
# Unit test for function romanize
def test_romanize():
    assert romanized("ru")("Мир") == 'Mir'
    assert romanized("uk")("Мир") == 'Myri'
    assert romanized("ru")("Куку") == 'Kuku'

# Generated at 2022-06-23 20:50:52.554174
# Unit test for function romanize
def test_romanize():
    import inspect
    import random
    from string import ascii_letters
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    locale = random.choice([
        item.value for item in list(Locale) if item.value != Locale.NONE
    ])
    text = Text(locale=locale)
    txt = text._random_text(
        length=random.randint(1, 100),
        with_control_characters=True,
    )
    romanized_text_method = inspect.getmembers(
        Text,
        predicate=lambda m: inspect.ismethod(m) and m.__name__ == 'romanized',
    )[0][1]

# Generated at 2022-06-23 20:51:00.917508
# Unit test for function romanize
def test_romanize():
    def foo(x):
        return x

    assert romanize()(foo)('абв') == 'abv'
    assert romanize()(foo)('абв 123') == 'abv 123'
    assert romanize()(foo)('абв.123') == 'abv.123'
    assert romanize()(foo)('абв,123') == 'abv,123'
    assert romanize()(foo)('абв!123') == 'abv!123'
    assert romanize()(foo)('абв?123') == 'abv?123'
    assert romanize()(foo)('абв-123') == 'abv-123'

# Generated at 2022-06-23 20:51:03.246083
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')('Привет.') == 'Privet.'



# Generated at 2022-06-23 20:51:07.749333
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    from mimesis.builtins import Person

    p = Person('ru')
    r = p._romanize(p.full_name())
    assert r == 'Иванов Иван Иванович'

# Generated at 2022-06-23 20:51:10.819655
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир!')().endswith('Privet, Mir!')

# Generated at 2022-06-23 20:51:21.407188
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russian_text():
        return 'Сталкер'

    res = russian_text()
    assert res == 'Stalker'

    # Unsupported locale
    try:
        @romanize(locale='jp')
        def japanese_text():
            return '漢字'
    except UnsupportedLocale:
        assert True
    else:
        assert False

    @romanize(locale='ru')
    def ascii_symbols():
        return 'Hello, world!'

    res = ascii_symbols()
    assert res == 'Hello, world!'


# Generated at 2022-06-23 20:51:24.894394
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize()(lambda: 'Привет, как дела?') == 'Privet, kak dela?'



# Generated at 2022-06-23 20:51:27.623312
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_method():
        return 'д'
    assert test_method() == 'd'

# Generated at 2022-06-23 20:51:31.029020
# Unit test for function romanize
def test_romanize():
    import re
    p = re.compile('[\W_]+')
    assert p.sub('', romanize()(lambda: 'Компьютер')) == 'Kompiuter'


# Generated at 2022-06-23 20:51:34.806893
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def func():
        return 'Мамы плачут, а мужики пьют'

    assert func() == 'Mamy plachut, a muzhiki pyut'

# Generated at 2022-06-23 20:51:37.566120
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize."""
    romanized_data = romanize('ru')(lambda: 'Берлин')
    expected_data = 'Berlin'
    assert romanized_data == expected_data

# Generated at 2022-06-23 20:51:44.668560
# Unit test for function romanize
def test_romanize():
    """Tests function romanize."""
    assert romanize()(lambda: 'test') == 'test'
    assert romanize('ru')(lambda: 'Тест') == 'Test'
    assert romanize('uk')(lambda: 'Тест') == 'Test'
    assert romanize('kk')(lambda: 'Тест') == 'Test'

# Generated at 2022-06-23 20:51:47.138059
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo():
        return 'Париж'

    assert foo() == 'Parizh'



# Generated at 2022-06-23 20:51:55.591109
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_ru(text):
        return text

    @romanize(locale='uk')
    def romanize_uk(text):
        return text

    @romanize(locale='kk')
    def romanize_kk(text):
        return text

    @romanized(locale='ru')
    def romanized_ru(text):
        return text

    # romanize_ru
    assert romanize_ru('Иванов Иван Иванович') == 'Ivanov Ivan Ivanovich'
    assert romanize_ru('Иванов Іван Іванович') == 'Ivanov Ivan Ivanovich'
    assert romanize

# Generated at 2022-06-23 20:51:58.391557
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    p = Person('ru')
    result = p.full_name(gender=Gender.FEMALE)

    assert result == p.romanize(result)

# Generated at 2022-06-23 20:52:01.890378
# Unit test for function romanize
def test_romanize():
    print(romanize('kk')(lambda: 'мама')('kk'))
    assert romanize('kk')(lambda: 'мама')('kk') == 'мама'

# Generated at 2022-06-23 20:52:06.803039
# Unit test for function romanize
def test_romanize():
    # locale supported
    @romanized(locale='ru')
    def russian_string():
        return 'Привет, Мимимир!'

    assert russian_string() == 'Privet, Mimimir!'

    # locale unsupported
    @romanized(locale='en')
    def russian_string():
        return 'Привет, Мимимир!'

    assert russian_string() == 'Privet, Mimir!'

# Generated at 2022-06-23 20:52:14.286782
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.action import Action
    from mimesis.providers.localization import Localization
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    act = Action(locale=Locale.RUSSIAN)
    loc = Localization(locale=Locale.RUSSIAN)
    per = Person(locale=Locale.RUSSIAN)
    tex = Text(locale=Locale.RUSSIAN)

    action = act.do_something()
    localization = loc.continent()
    person = per.surname()
    text = tex.sentence()

    assert action
    assert localization
    assert person
    assert text

# Generated at 2022-06-23 20:52:19.990765
# Unit test for function romanize
def test_romanize():
    romanize_locale = romanize(locale='ru')

    @romanize_locale
    def test(first_name):
        return first_name

    assert isinstance(test('Иван'), str)
    assert test('Иван') == 'Ivan', test('Иван')

# Generated at 2022-06-23 20:52:24.734503
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    from mimesis.builtins.text import Text
    result = Text('ru').romanize()
    assert result.isalpha()
    result = Text('uk').romanize()
    assert result.isalpha()
    result = Text('kk').romanize()
    assert result.isalpha()

# Generated at 2022-06-23 20:52:30.196879
# Unit test for function romanize
def test_romanize():
    assert data.DATASETS['ru']['mathematician'] == 'Александр Лявонович Алопольский'



# Generated at 2022-06-23 20:52:32.345629
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda :'')() == ''

# Generated at 2022-06-23 20:52:42.078969
# Unit test for function romanize
def test_romanize():
    @romanized('ru')
    def romanize_ru(text: str) -> str:
        return text

    assert romanize_ru('Привет мир!') == 'Privet mir!'

    @romanized('uk')
    def romanize_uk(text: str) -> str:
        return text

    assert romanize_uk('Привіт світ!') == 'Pryvit svit!'

    @romanized('kk')
    def romanize_kk(text: str) -> str:
        return text

    assert romanize_kk('Сәлем Әлем!') == 'Salem Eliim!'


# Generated at 2022-06-23 20:52:46.206888
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.person import Person

    text = "Привет, мир!"

    person = Person(Language.RUSSIAN)
    assert person.full_name() != text
    assert person.full_name(romanize=True) == text

# Generated at 2022-06-23 20:52:48.290472
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Москва')() == 'Moskva'

# Generated at 2022-06-23 20:52:50.846142
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Здравствуйте')() == 'Zdravstvujte'
    assert romanize('uk')(lambda: 'Добрий ранок')() == 'Dobryi ranok'
    assert romanize('kk')(lambda: 'Хайратмын!')() == 'Xairatmyn!'

# Generated at 2022-06-23 20:52:58.878557
# Unit test for function romanize

# Generated at 2022-06-23 20:53:04.843979
# Unit test for function romanize
def test_romanize():
    import mimesis

    text_generator = mimesis.Text()

    @romanize(locale='ru')
    def romanize_text():
        """Romanize the text."""
        return text_generator.sentence()

    romanized_text = romanize_text()
    assert isinstance(romanized_text, str)
    assert romanized_text

# Generated at 2022-06-23 20:53:06.672561
# Unit test for function romanize
def test_romanize():
    assert romanized('ru', 'def') == functools.partial(romanize, 'ru')



# Generated at 2022-06-23 20:53:09.435748
# Unit test for function romanize
def test_romanize():
    """Test for romanize function."""
    @romanize('ru')
    def _():
        return 'Москва'

    assert _() == 'Moskva'



# Generated at 2022-06-23 20:53:15.140739
# Unit test for function romanize
def test_romanize():
    alphabet = {'a': 'a', 'b': 'b', 'c': 'c'}
    a = 'абвг'
    b = ''.join([alphabet[i] for i in a if i in alphabet])
    print(b)


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:53:18.693593
# Unit test for function romanize
def test_romanize():
    @romanize()
    def _romanize(arg):
        return arg

    assert _romanize('Привет') == 'Privet'
    assert _romanize('привет') == 'privet'

# Generated at 2022-06-23 20:53:21.496984
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def russian_name(mask='*'):
        return mask

    assert russian_name() == '*'

# Generated at 2022-06-23 20:53:25.610892
# Unit test for function romanize
def test_romanize():
    """Unit tests for romanize function."""
    ru = romanize('ru')(lambda: 'привет, как твои дела?')
    assert ru == 'privet, kak tvoi dela?'

# Generated at 2022-06-23 20:53:28.167727
# Unit test for function romanize
def test_romanize():
    assert len(romanize()(lambda: 'мимимимимопривет')) == 16

# Generated at 2022-06-23 20:53:30.679694
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanized('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-23 20:53:36.250506
# Unit test for function romanize
def test_romanize():
    """Test for function romanize """
    import random

    for i in range(10):
        text = ''.join(
            random.choice(
                ascii_letters + digits + punctuation
            )
            for _ in range(random.randint(1, 30))
        )
        assert romanize()(text) == text

    assert romanize('ru')('Привет') == 'Privet'
    assert romanize('uk')('Привіт') == 'Pryvit'
    assert romanize('kk')('Сәлем') == 'Sälem'

# Generated at 2022-06-23 20:53:44.534213
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanized_ru(data_provider):
        return data_provider._data['personal']['name']['male'][0]

    @romanize('uk')
    def romanized_uk(data_provider):
        return data_provider._data['personal']['name']['male'][0]

    @romanize('kk')
    def romanized_kk(data_provider):
        return data_provider._data['personal']['name']['male'][0]

    # Russian
    assert romanized_ru(data) == 'Mihail'
    assert romanized_ru(data) == 'Pavel'
    assert romanized_ru(data) == 'Aleksandr'
    assert romanized_ru(data)

# Generated at 2022-06-23 20:53:46.029334
# Unit test for function romanize
def test_romanize():
    assert romanize()("Привет") == "Privet"

# Generated at 2022-06-23 20:53:49.376042
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_me(text):
        return text

    assert romanize_me('Привет мир!') == 'privet mir!'

# Generated at 2022-06-23 20:53:53.318470
# Unit test for function romanize
def test_romanize():
    def romanize(locale: str = '') -> Callable:
        return romanize(locale)
    assert romanize('ru')('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-23 20:53:56.882428
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    text = 'Строка для теста'
    expected_text = 'Stroka dlya testa'
    assert romanized('ru')(lambda: text)() == expected_text

# Generated at 2022-06-23 20:54:04.575455
# Unit test for function romanize
def test_romanize():
    def test_func(text: str) -> str:
        return text

    result = test_func('Мама мыла раму')
    assert result == 'Мама мыла раму'

    with romanize(locale='ru'):
        result = test_func('Мама мыла раму')
        assert result == 'Mama myla ramu'

# Generated at 2022-06-23 20:54:05.199774
# Unit test for function romanize
def test_romanize():
    pass



# Generated at 2022-06-23 20:54:09.950029
# Unit test for function romanize
def test_romanize():
    # This function, though deprecated, has no unit tests
    # (see https://github.com/lk-geimfari/mimesis/issues/135).
    # This is a new unit test for the function.
    assert romanize()(lambda: ascii_letters)() == ascii_letters

# Generated at 2022-06-23 20:54:12.165347
# Unit test for function romanize
def test_romanize():
    def test_func():
        return "Привет мир"

    romanized_func = romanize('ru')(test_func)
    assert romanized_func() == "Privet mir"



# Generated at 2022-06-23 20:54:15.944101
# Unit test for function romanize
def test_romanize():
    def foo():
        return "привет"

    foo_romanized = romanize("ru")(foo)

    assert foo() == "привет"
    assert foo_romanized() == "privet"

# Generated at 2022-06-23 20:54:21.168713
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo(locale):
        return locale

    assert foo(locale='абвгдеёжзийклмнопрстуфхцчшщъыьэюя') == 'abvgdeezhziyklmnoprstufkhtschshshchyy\'eiyua'

# Generated at 2022-06-23 20:54:25.233250
# Unit test for function romanize
def test_romanize():
    assert (romanize('ru')(lambda: 'abc') == 'abc')
    assert (romanize('ru')(lambda: 'привет') == 'privet')
    assert (romanize('ru')(lambda: 'Привет') == 'Privet')
    assert (romanized('ru')(lambda: 'Привет') == 'Privet')

# Generated at 2022-06-23 20:54:29.273653
# Unit test for function romanize
def test_romanize():
    @romanize()
    def do_romanize(text):
        assert text
        return text

    assert do_romanize('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-23 20:54:32.520425
# Unit test for function romanize
def test_romanize():
    import string

    @romanize('ru')
    def f(r: int = 0):
        return string.ascii_lowercase[r]

    assert f() == 'a'
    assert f(25) == 'z'
    assert f(1) == 'b'

# Generated at 2022-06-23 20:54:35.715744
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def ru_romanize(text: str) -> str:
        return text

    assert ru_romanize('Декораторы') == 'Dekoratory'



# Generated at 2022-06-23 20:54:39.888947
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_text(text: str) -> str:
        return text

    text = 'Привет! Как дела?'
    assert romanize_text(text) == 'Privet! Kak dela?'



# Generated at 2022-06-23 20:54:46.306414
# Unit test for function romanize
def test_romanize():
    assert all([romanized('uk')(lambda: 'Привет')() == 'Pryvit',
                romanized('ru')(lambda: 'Привет')() == 'Privet',
                romanized('kk')(lambda: 'Привет')() == 'Привет'])

# Generated at 2022-06-23 20:54:49.952691
# Unit test for function romanize
def test_romanize():
    r = romanize('ru')(lambda: 'Привет Мир')  # noqa
    assert isinstance(r, str)
    assert r == 'Privet Mir'

# Generated at 2022-06-23 20:54:52.391385
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-23 20:54:57.466613
# Unit test for function romanize
def test_romanize():
    for i in range(20):
        assert romanized()() == romanized(locale='ru')()
        assert romanized()() == romanized(locale='uk')()
        assert romanized()() == romanized(locale='kk')()
    assert romanized()() != romanized(locale='en')()

# Generated at 2022-06-23 20:54:59.953245
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')
    assert romanize('tt')

# Generated at 2022-06-23 20:55:01.127308
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')

# Generated at 2022-06-23 20:55:07.965734
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator.

    :return: True.
    """
    from mimesis import Person

    p = Person()

    @romanize()
    def get_fullname():
        """Get a fake fullname."""
        return p.full_name()

    assert get_fullname() in p.provider.full_name.list

    @romanize('ru')
    def get_fullname():
        """Get a fake fullname."""
        return p.full_name()

    assert get_fullname() in p.provider.full_name.list

# Generated at 2022-06-23 20:55:14.769550
# Unit test for function romanize
def test_romanize():
    # Test romanize of Russian words.
    @romanize('ru')
    def russian_words():
        # Test romanize of Russian words.
        return data.CYRILLIC_SYMBOLS[:70]

    assert russian_words() == (
        'A a B В v G G D Д e E Zh Zh '
        'Z I i I K k L M M N N O O P P R R S S T T U U F F Kh '
        'Kh Ts Tc Ch Ch Sh Sh Sch Shch ` Y Y Y I Yu Yu Ya Ya'
    )

    # Test romanize of Ukrainian words.
    @romanize('uk')
    def ukrainian_words():
        # Test romanize of Ukrainian words.
        return data.CYRILLIC_SYMBOLS

# Generated at 2022-06-23 20:55:15.724975
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized

test_romanize()

# Generated at 2022-06-23 20:55:17.727268
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize function."""
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')

# Generated at 2022-06-23 20:55:22.211704
# Unit test for function romanize
def test_romanize():
    # from mimesis.builtins.languages import RussianSpecProvider
    from mimesis.builtins.languages import UkrainianSpecProvider

    # lang = RussianSpecProvider()
    lang = UkrainianSpecProvider()

    assert lang.code('Россия', locale='uk') == 'Rossiya'
    assert lang.code('Часть текста', locale='ru') == 'Chast teksta'

# Generated at 2022-06-23 20:55:24.702548
# Unit test for function romanize
def test_romanize():
    """Test romanization."""
    import mimesis

    assert mimesis.Text().cyrillic() == mimesis.Text().romanized()

# Generated at 2022-06-23 20:55:29.162864
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    person = Person('ru')

    @romanize('ru')
    def do_romanize():
        return person.username()

    romanized_username = do_romanize()
    assert '_' not in romanized_username

# Generated at 2022-06-23 20:55:32.439852
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def func(string):
        return string

    assert func('Привет мир') == 'Privet mir'

# Generated at 2022-06-23 20:55:34.750380
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Журавль')() == 'Zhuravl'
    assert romanize()(lambda: 'Журавль')() == 'Zhuravl'



# Generated at 2022-06-23 20:55:40.932474
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет мир')() == 'Privet mir'
    assert romanized('uk')(lambda: 'вітаю, світе!')() == 'vitayu, svite!'
    assert romanized('kk')(lambda: 'Сәлем, дүние!')() == 'Sälem, dünie!'
    assert romanized('en')(lambda: 'Привет мир')() == 'Привет мир'
    assert romanized()(lambda: 'Привет мир')() == 'Привет мир'

# Generated at 2022-06-23 20:55:46.182084
# Unit test for function romanize
def test_romanize():
    """Unit test for romanize"""

    @romanize(locale='ru')
    def romanize_test(text):
        return text

    assert 'январь и январь' == romanize_test('январь и январь')

# Generated at 2022-06-23 20:55:48.379822
# Unit test for function romanize
def test_romanize():
    assert romanized()('Мама мыла раму.') == 'Mama myla ramu.'

# Generated at 2022-06-23 20:55:49.609484
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')

# Generated at 2022-06-23 20:55:56.953892
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanized_text(locale_code: str = 'ru') -> str:
        return 'СРОЧНАЯ ВАКАНСИЯ! ТРЕБУЮТСЯ ВОДИТЕЛИ В ЕКБ'

    assert romanized_text() == 'SROCHNAYA VAKANSIYA! TREBUYUTSYA VODITELI V EKB'

# Generated at 2022-06-23 20:55:59.535520
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.builtins import Person

    p = Person(locale=Locale.RU)
    print(p.name(patronymic=True))
    print(p.patronymic())

# Generated at 2022-06-23 20:56:04.483197
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def get_ru(self):
        return 'здравствуй мир'
    
    assert get_ru(1) == 'zdravstvuĭ mir'



# Generated at 2022-06-23 20:56:06.868307
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'



# Generated at 2022-06-23 20:56:18.048115
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanize_ru(text):
        return text

    assert romanize_ru(text='Я не говорю по-русски.') == 'Ya ne govoryu ' \
                                                    'po-russki.'

    @romanize(locale='uk')
    def romanize_uk(text):
        return text

    assert romanize_uk(text='Я не говорю по-українськи.') == 'Ya ne govoryu ' \
                                                          'po-ukraïns’ki.'


# Generated at 2022-06-23 20:56:30.061266
# Unit test for function romanize
def test_romanize():
    # Example :
    def russian_func():
        return 'Я хочу в лес'

    # New name for function python_func()
    russian_func_romanized = romanized('ru')(russian_func)

    # Example :
    def ukrainian_func():
        return 'Я хочу в ліс'

    # New name for function python_func()
    ukrainian_func_romanized = romanized('uk')(ukrainian_func)

    # Example :
    def kazakh_func():
        return 'Мен орман келеді'

    # New name for function python_func()
    kazakh_func_romanized = romanized

# Generated at 2022-06-23 20:56:40.815765
# Unit test for function romanize
def test_romanize():

    @romanize(locale='en')
    def text_ru_en(self):
        return self._data['ru']['text']

    assert not text_ru_en

    @romanize(locale='uk')
    def text_ru_uk(self):
        return self._data['ru']['text']

    assert not text_ru_uk

    @romanize(locale='ru')
    def text_ru_ru(self):
        return self._data['ru']['text']

    assert not text_ru_ru

    @romanize(locale='kz')
    def text_ru_kz(self):
        return self._data['ru']['text']

    assert not text_ru_kz


# Generated at 2022-06-23 20:56:44.762339
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.personal import Personal as Per
    p = Per(locale='ru')
    assert p.romanize(p.full_name()) == \
        'Sergey Vladimirovich uzin'

# Generated at 2022-06-23 20:56:47.946754
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Привет, абитуриент!')() == 'Privet, abituirent!'

# Generated at 2022-06-23 20:56:53.234502
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda:
                          'Компьютер — автоматизированная информационная машина')() == \
           'Kompyuter — avtomatizirovannaya informatsionnaya mashina'

# Generated at 2022-06-23 20:57:00.657788
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')('привет') == 'privet'
    assert romanize('uk')(lambda: 'привіт')('привіт') == 'pryvit'
    assert romanize('kk')(lambda: 'қалай қалайсың')('қалай қалайсың') == 'qalay qalaysyn'

# Generated at 2022-06-23 20:57:07.649826
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    text = Text('ru')
    text.data.ROMANIZATION_DICT['ru']['Ё'] = 'Yo'
    text.data.ROMANIZATION_DICT['ru']['ё'] = 'yo'
    text.data.ROMANIZATION_DICT['ru']['Ж'] = 'Zh'
    text.data.ROMANIZATION_DICT['ru']['ж'] = 'zh'
    text.data.ROMANIZATION_DICT['ru']['Х'] = 'Kh'
    text.data.ROMANIZATION_DICT['ru']['х'] = 'kh'
    text.data.ROMANIZATION_DICT['ru']['Ц'] = 'Ts'
    text

# Generated at 2022-06-23 20:57:12.829698
# Unit test for function romanize
def test_romanize():
    @romanize('uk')
    def test_func():
        return 'Привет, я Макс!'

    assert test_func() == 'Pryvit, ya Maks!'

# Generated at 2022-06-23 20:57:16.676292
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize()('Абвгдеёжзийклмнопрстуфхцчшщъыьэюя') == \
        'Abvgdeyozijklmnoprstufhcchshshyiyeuya'

# Generated at 2022-06-23 20:57:25.236338
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.person import Person

    p = Person('ru')
    name_ru = p.full_name(gender='female')
    assert name_ru == 'Альбина Елена Вячеславовна'

    @romanize(locale='ru')
    def name():
        return name_ru

    name_latin = name()
    assert name_latin == 'Albina Yelena Vyacheslavovna'

# Generated at 2022-06-23 20:57:31.394591
# Unit test for function romanize
def test_romanize():
    locale = 'ru'

    @romanize(locale)
    def romanize_test(alphabet):
        return alphabet

    assert romanize_test('Як ти мене розумієш?') == 'Yak ty mene rozumijesh?'
    assert romanize_test("Yo, Я хочу купити квартиру") == \
        "Yo, Ya khochu kupity kvartir"

# Generated at 2022-06-23 20:57:42.407389
# Unit test for function romanize
def test_romanize():
    assert 'nikhil' == romanized('hi_IN')('nikhil')
    assert 'nikhil' == romanized('en')('nikhil')
    assert '' == romanized('de')('')
    assert 'nikhil' == romanized('ru')('nіхіл')
    assert 'Сүттің сағаты' == romanized('ru')('Суттың сағаты')
    assert 'Nikolay Kozlov' == romanized('ru')('Николай Козлов')
    assert 'Aaaa' == romanized('ru')('Аааа')

# Generated at 2022-06-23 20:57:51.262315
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis import Person

    p = Person(Locale.UKRAINE, seed=42)
    assert p.full_name() == 'Дуеллір Нестор Апанасович'
    p.romanize = True
    assert p.full_name() == 'Duellir Nestor Apanasovych'

    p = Person(Locale.RUSSIA, seed=42)
    assert p.full_name() == 'Васильев Мартын Васильевич'
    p.romanize = True
    assert p.full_name() == 'Vasilyev Martyn Vasilyevich'

