

# Generated at 2022-06-23 20:47:46.143900
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    a = Address('ru')
    p = Person('uk')

    def check_string(string):
        for c in string:
            assert c in ascii_letters + digits + punctuation

    assert a.city() == 'Москва'
    assert a.region() == 'Волгоградская область'
    assert p.full_name() == 'Дмитрий Андреев'

    assert a._city() == 'Moskva'
    assert a._region() == 'Volgogradskaya oblast\''

# Generated at 2022-06-23 20:47:56.101361
# Unit test for function romanize
def test_romanize():
    """Check BaseProvider.romanize."""
    from mimesis import Generic

    g = Generic('ru')
    text = g.text.word()
    text2 = g.text.word()
    text3 = g.text.word()

    @romanize('ru')
    def test_romanize_ru(a, b, c, d='3232'):
        return a + b + c + d

    @romanize('uk')
    def test_romanize_uk(a, b, c, d='3232'):
        return a + b + c + d

    assert test_romanize_ru(text, text2, text3) == 'Priamayauzkii'
    assert test_romanize_uk(text, text2, text3) == 'Pryamyh'

# Generated at 2022-06-23 20:47:57.044540
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')

# Generated at 2022-06-23 20:47:59.633337
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    @romanize()
    def r():
        return 'Тест'

    @romanized()
    def rr():
        return 'Тест'

    assert r() == rr()

# Generated at 2022-06-23 20:48:00.917533
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Пример')() == 'Primer'

# Generated at 2022-06-23 20:48:06.937859
# Unit test for function romanize
def test_romanize():
    @romanize()
    def romanize_test():
        return "Абвгдеєжзиіїйклмнопрстуфхцчшщьюя"

    assert romanize_test() == "Abyvhdyezhzhyiyiykylmnoprstufkhtschshshchyuya"

# Generated at 2022-06-23 20:48:10.150972
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address
    from mimesis.providers.text import Text

    address = Address('ru')
    text = Text('ru')

    assert_that(
        address.country() == romanized('ru')(address.country)
    )
    assert_that(
        text.sentence() == romanized('ru')(text.sentence)
    )

# Generated at 2022-06-23 20:48:12.232373
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    p = Person('ru')
    assert p.romanize_text() == p.romanize_text()

# Generated at 2022-06-23 20:48:14.081313
# Unit test for function romanize
def test_romanize():
    romanized_locale = romanize('ru')(lambda : '')
    assert romanized_locale() == ''

# Generated at 2022-06-23 20:48:15.610250
# Unit test for function romanize
def test_romanize():
    assert romanized()('строка') == 'stringa'

# Generated at 2022-06-23 20:48:17.429478
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Тест')() == 'Test'

# Generated at 2022-06-23 20:48:20.136786
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address

    address = Address(Language.UKRAINIAN)
    result = address.city()
    assert isinstance(result, str)

    assert len(result) >= 2

# Generated at 2022-06-23 20:48:22.389485
# Unit test for function romanize
def test_romanize():
    """Test case for function romanize."""

    txt = romanize('ru')(lambda : 'Русский')()
    assert txt == 'Russkiy'

# Generated at 2022-06-23 20:48:25.557013
# Unit test for function romanize
def test_romanize():
    def fn():
        return 'Привет, мир!'

    result = romanized()(fn)()
    assert result == 'Privet, mir!'

# Generated at 2022-06-23 20:48:26.150995
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-23 20:48:26.544275
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:48:28.692898
# Unit test for function romanize
def test_romanize():
    '''
    This function tests the romanize function.
    '''
    @romanize('ru')
    def f():
        '''
        This function returns a Cyrillic string.
        '''
        return 'Привет'

    assert f() == 'Privet'

# Generated at 2022-06-23 20:48:32.720067
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text

    t = Text('ru')

    @romanize('ru')
    def romanizer():
        return t.sentence()

    assert ''.join(list(set(romanizer()))) == ' '.join(list(set(t.sentence())))

# Generated at 2022-06-23 20:48:43.546471
# Unit test for function romanize
def test_romanize():
    # pylint: disable=pointless-string-statement
    """Test case for function romanize."""
    # pylint: enable=pointless-string-statement
    from mimesis import Localization, Datetime, Person

    @romanize()
    def test(localization: Localization) -> str:
        return Person(localization=localization).full_name

    assert test(Datetime('ru')) == 'Иван Иванович Иванов'
    assert test(Datetime('uk')) == 'Іван Іванович Іванов'
    assert test(Datetime('kk')) == 'Іван Івановіч Іванов'


# Generated at 2022-06-23 20:48:46.306573
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def romanized_string(seed: str = None) -> str:
        return 'Просто текст'

    assert romanized_string() == 'Prosto tekst'

# Generated at 2022-06-23 20:48:51.021287
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import UkrainianSpecProvider as usp

    d = usp()

    assert d.romanize('Нахтімка') == d.romanize(locale='uk')('Нахтімка')

# Generated at 2022-06-23 20:48:51.614007
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:48:57.940023
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person

    class RomanizeTest(BaseProvider):
        cls = Person

        @romanize(locale='ru')
        def romanize(self, text: str) -> str:
            return text

    romanize_test = RomanizeTest('ru')
    assert romanize_test.romanize('Максим') == 'Maksim'



# Generated at 2022-06-23 20:49:05.495475
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'Не скажи, что это невозможно и непосильно!')() ==\
        'Ne skazhi, chto eto nevozmozhno i neposilno!'

    assert romanize()(lambda: 'ﺎﻠﻌﻠﻞ ﻲﻫﺎ ﺖﻤﻌﺎﻤﻟﺎﺕ ﻮﻧﺖﻴﻨﺘﻪ')() ==\
        'al-kalimat al-amthulat wa al-mubinat'

    assert romanized()

# Generated at 2022-06-23 20:49:07.648311
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Проверка')() == 'Proverka'

# Generated at 2022-06-23 20:49:14.628615
# Unit test for function romanize
def test_romanize():

    func = lambda _: 'привет мир'

    func = romanize('ru')(func)

    assert func() == 'privet mir'

    func = lambda _: 'привет мир'

    func = romanize('uk')(func)

    assert func() == 'pryvit mir'

    func = lambda _: 'привет мир'

    func = romanize('kk')(func)

    assert func() == 'privet mir'



# Generated at 2022-06-23 20:49:19.460156
# Unit test for function romanize
def test_romanize():
    @romanize()
    def x():
        return 'Пошёл вон отсюда'

    assert x() == 'Пошёл вон отсюда'

# Generated at 2022-06-23 20:49:23.371916
# Unit test for function romanize
def test_romanize():
    somedata = 'Нямаш милиції'
    romanized_somedata = romanize()(somedata)
    assert romanized_somedata == 'Nyamash militsiji'

# Generated at 2022-06-23 20:49:33.324449
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language

    t = romanize(locale=Language.EN)
    assert t(lambda: 'АБВГДЕЁЖЗИК') == 'ABVGDEEJZIK'

    t = romanize(locale=Language.RU)
    assert t(lambda: 'АБВГДЕЁЖЗИК') == 'ABVGDEEJZIK'

    t = romanize(locale=Language.UK)
    assert t(lambda: 'АБВГДЕЁЖЗИК') == 'ABVGDEEJZIK'

    t = romanize(locale=Language.KK)

# Generated at 2022-06-23 20:49:36.258657
# Unit test for function romanize
def test_romanize():
    romanize_deco = romanize()
    assert romanize_deco
    assert callable(romanize_deco)
    assert callable(romanize_deco(lambda: 'abc'))
    assert callable(romanize_deco(lambda: 'г'))

# Generated at 2022-06-23 20:49:47.626408
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    r = RussiaSpecProvider()
    assert romanized()(r.full_name)() == 'Kolotovkin Igor Anatolievich'
    assert romanized('ru')(r.full_name)() == 'Kolotovkin Igor Anatolievich'
    assert romanized('ru')(r.name)() == 'Igor'
    assert romanized('ru')(r.surname)() == 'Kolotovkin'
    assert romanized('ru')(r.patronymic)() == 'Anatolievich'
    assert romanized('uk')(r.full_name)() == 'Kolotovkin Igor Anatolievich'
    assert romanized('uk')(r.name)() == 'Igor'

# Generated at 2022-06-23 20:49:50.372046
# Unit test for function romanize
def test_romanize():
    assert romanized() == romanize()
    assert romanized(locale='ru') == romanize(locale='ru')
    assert romanized(locale='kk') == romanize(locale='kk')
    assert romanized(locale='uk') == romanize(locale='uk')

# Generated at 2022-06-23 20:49:53.815684
# Unit test for function romanize
def test_romanize():
    # Russian
    assert romanized('ru')('Привет, Мир!') == 'Privet, Mir!'

    # Ukrainian
    assert romanized('uk')('Привіт, Світ!') == 'Pryvit, Svit!'

    # Kazakh
    assert romanized('kk')('Қазақ тілі!') == 'Qazaq til'

# Generated at 2022-06-23 20:49:59.531665
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Здравствуйте')() == 'Zdravstvujtie'
    assert romanize('uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda: 'Сәлем')() == 'Sälem'



# Generated at 2022-06-23 20:50:07.903958
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    from mimesis.builtins import Person
    person = Person()

    assert isinstance(person.first_name('ru'), str)
    assert isinstance(person.first_name('uk'), str)
    assert isinstance(person.first_name('kk'), str)

    assert isinstance(person.middle_name('ru'), str)
    assert isinstance(person.middle_name('uk'), str)
    assert isinstance(person.middle_name('kk'), str)

    assert isinstance(person.last_name('ru'), str)
    assert isinstance(person.last_name('uk'), str)
    assert isinstance(person.last_name('kk'), str)

    assert isinstance(person.name('ru'), str)

# Generated at 2022-06-23 20:50:15.244998
# Unit test for function romanize
def test_romanize():
    # Example: ru
    ru = mimesis.Personal(locale='ru')


# Generated at 2022-06-23 20:50:23.775506
# Unit test for function romanize
def test_romanize():
    """Test for romanizator."""
    def decorated(p: str) -> str:
        return p

    dec = romanize('ru')(decorated)

    assert dec('Павел') == 'Pavel'
    assert dec('Васильевич') == 'Vasilievich'
    assert dec('Франк') == 'Frank'
    assert dec('Иванов') == 'Ivanov'
    assert dec('Попков') == 'Popkov'
    assert dec('Петров') == 'Petrov'
    assert dec('Сидоров') == 'Sidorov'
    assert dec('Мещеряков') == 'Meshcheryakov'

# Generated at 2022-06-23 20:50:25.144548
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person

    p = Person('ru')
    assert p.name(romanize=True) == p.name()

# Generated at 2022-06-23 20:50:29.120821
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'привет')() == 'privet'
    assert romanize(locale='uk')(lambda: 'шукаю')() == 'shukaiu'
    assert romanize(locale='kk')(lambda: 'сәтті')() == 'sätti'

# Generated at 2022-06-23 20:50:32.038438
# Unit test for function romanize
def test_romanize():
    romanize_text = romanize(locale='ru')(lambda x: 'Алё, привет!')
    assert romanize_text() == 'Alyo, privet!'

# Generated at 2022-06-23 20:50:43.382404
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address

    @romanize(Language.UKRAINIAN)
    def generate_ukr_address() -> str:
        address = Address(Language.UKRAINIAN)
        return address.address()

    @romanize(Language.RUSSIAN)
    def generate_rus_address() -> str:
        address = Address(Language.RUSSIAN)
        return address.address()

    # Main checks
    assert generate_rus_address().startswith('Россия')
    assert generate_ukr_address().startswith('Україна')


# Generated at 2022-06-23 20:50:46.260440
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def f(txt: str) -> str:
        return txt
    assert f('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-23 20:50:51.709083
# Unit test for function romanize
def test_romanize():
    characters = 'Не получается сделать типографику в Спарке, как в Джентельменском уборе.'
    assert romanize(locale='ru')(lambda: characters)() == \
           'Ne poluchaetsya sdelat tipografiku v Spark\'e, kak v Dzhentel\'menskom ubore.'

# Generated at 2022-06-23 20:50:53.607902
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:50:58.834600
# Unit test for function romanize
def test_romanize():
    """Tests for function romanize."""
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('uk')(lambda: 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda: 'сәлем')() == 'salem'

    # Unsupported locale
    try:
        romanize('en')(lambda: 'привет')()
    except Exception as e:
        assert isinstance(e, UnsupportedLocale)

    # Not a function
    try:
        romanize()('привет')
    except Exception as e:
        assert isinstance(e, TypeError)

# Generated at 2022-06-23 20:51:00.709319
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'привет')(), 'privet'

# Generated at 2022-06-23 20:51:03.449294
# Unit test for function romanize
def test_romanize():
    @romanize(locale='kk')
    def some(a):
        return a

    assert some('Настройка') == 'Nastroyka'

# Generated at 2022-06-23 20:51:07.575786
# Unit test for function romanize
def test_romanize():
    def say(word):
        return word

    @romanize
    def new_say(word):
        return word

    assert say('Слово') == 'Слово'
    assert new_say('Слово') == 'Slovo'

# Generated at 2022-06-23 20:51:14.953618
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет, мир!') == 'Privet, mir!'
    assert romanize('uk')(lambda x: 'Привіт, світ!') == 'Pryvit, svit!'
    assert romanize('kk')(lambda x: 'Сәлем, дүние!') == 'Sälem, dünie!'

# Generated at 2022-06-23 20:51:24.702204
# Unit test for function romanize
def test_romanize():
    assert 'test' == romanized(locale='ru')(lambda: 'test')()
    assert 'otsi' == romanized(locale='ru')(lambda: 'цости')(), \
        'Цости. Expected "otsi", got "{}"'.format(romanized(locale='ru')(lambda: 'цости')())
    assert 'vadi' == romanized(locale='uk')(lambda: 'вадіш')(), \
        'Вадіш. Expected "vadi", got "{}"'.format(romanized(locale='uk')(lambda: 'вадіш')())

# Generated at 2022-06-23 20:51:26.632445
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 20:51:28.835882
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Россия')() == 'Rossiya'



# Generated at 2022-06-23 20:51:33.979600
# Unit test for function romanize
def test_romanize():
    """Test function romanize()."""

    @romanize('ru')
    def text():
        return 'Мама мыла раму.'

    assert text() == 'Mama myla ramu.'

    @romanize('uk')
    def text():
        return 'Мама мила раму.'

    assert text() == 'Mama myla ramu.'

    @romanize('kk')
    def text():
        return 'Мама раму мыла.'

    assert text() == 'Mama ramu myla.'

# Generated at 2022-06-23 20:51:35.565744
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:51:37.798517
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func():
        return 'Здравствуй мир!'

    assert func() == 'Zdravstvuî mir!'

# Generated at 2022-06-23 20:51:49.092313
# Unit test for function romanize
def test_romanize():
    @romanize('kk')
    def demo(pattern):
        return pattern

    assert demo('Дайындау және айту') == 'Dajındaý jäne aýtý'
    assert demo('АЛАТАУ ЖОЛДАРЫ') == 'ALATAW JOLDARÏ'
    assert demo('Сүйеу және оқыту') == 'Sýjëw jäne oqýtý'

# Generated at 2022-06-23 20:51:53.668830
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_name():
        return 'Иван'

    assert get_name() == 'Ivan'

    @romanize('uk')
    def get_name():
        return 'Іван'

    assert get_name() == 'Ivan'

# Generated at 2022-06-23 20:51:55.610966
# Unit test for function romanize
def test_romanize():
    print(romanized('kk')(lambda: "qwerty"))
if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:51:58.424988
# Unit test for function romanize
def test_romanize():
    text = "Мимимишки мухи манят"
    assert romanize("ru")(lambda x: text)(None) == "Mimimishki mukhi maniat"

# Generated at 2022-06-23 20:52:04.774000
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT[locale],
        **data.COMMON_LETTERS,
    })

    result = 'Тест'.lower()
    exp_result = ''.join([alphabet[i] for i in result if i in alphabet])

    assert result == 'тест'
    assert exp_result == 'test'

# Generated at 2022-06-23 20:52:12.807046
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    class UPerson(Person):
        def __init__(self, locale):
            super().__init__(locale)

        @romanize('ru')
        def name(self) -> str:
            return super().name()

    p = UPerson(Language.RU)
    assert p.name().find('Ё') == -1
    a = Address(Language.RU)
    assert a.full_address().find('Ё') == -1



# Generated at 2022-06-23 20:52:16.765017
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def foo():
        return 'Не знаете куда деться? Купите себе кота!'

    assert foo() == 'Ne znayete kuda det’sya? Kupite sebe kota!'



# Generated at 2022-06-23 20:52:22.606182
# Unit test for function romanize
def test_romanize():
    romanized_text = {
        'ru': 'Preved',
        'uk': 'Привіт',
    }

    # See issue #266
    for locale in romanized_text:
        @romanize(locale)
        def _(locale):
            return 'Привет'

        assert _(locale) == romanized_text[locale]

# Generated at 2022-06-23 20:52:30.677843
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def romanize(cyrillic_string: str) -> str:
        return cyrillic_string

    @romanize('uk')
    def romanize_uk(cyrillic_string: str) -> str:
        return cyrillic_string

    @romanize('kk')
    def romanize_kk(cyrillic_string: str) -> str:
        return cyrillic_string

    @romanize('')
    def romanize_error(cyrillic_string: str) -> str:
        return cyrillic_string

    test_text_ru = 'Привет, мир!'
    romanize_ru = romanize(test_text_ru)

# Generated at 2022-06-23 20:52:38.747175
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person

    p = Person('ru')
    assert p.full_name(gender=Gender.FEMALE) == 'Лестер'
    p = Person('uk')
    assert p.full_name(gender=Gender.FEMALE) == 'Клариса'
    p = Person('kk')
    assert p.full_name(gender=Gender.FEMALE) == 'Абдулла'

# Generated at 2022-06-23 20:52:42.756440
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('') == ''
    assert romanized('ru')('Тест') == 'Test'
    assert romanized('uk')('Тест') == 'Test'
    assert romanized('kk')('Тест') == 'Tізірлеу'

# Generated at 2022-06-23 20:52:47.752096
# Unit test for function romanize
def test_romanize():
    def test_func():
        return 'всё в порядке'

    romanize_deco = romanize('ru')
    assert 'все в порядке' == romanize_deco(test_func)()



# Generated at 2022-06-23 20:52:56.358822
# Unit test for function romanize
def test_romanize():
    import unittest

    class RomanizeTestCase(unittest.TestCase):
        def test_romanize(self):
            from mimesis.enums import Locale
            from mimesis.providers.address import Address
            from mimesis.providers.text import Text

            address = RomanizeTestCase.get_address()
            text = RomanizeTestCase.get_text()

            # Test not romanized.
            self.assertEqual(address.address(), address.address())
            self.assertEqual(text.text(), text.text())

            # Test romanized.
            address = Address(Locale.UK)
            self.assertEqual(address.address(), address.romanized.address())
            text = Text(Locale.UK)

# Generated at 2022-06-23 20:53:02.812506
# Unit test for function romanize
def test_romanize():
    """Test romanize decorator."""
    from mimesis.builtins.text import Text

    tx = Text('ru')

    @romanize(locale='ru')
    def romanize_test(x: str, y: str) -> str:
        """Show romanization."""
        return f'{x} {y}'

    assert romanize_test(tx.word(), tx.word()) == 'dva kartochki'

# Generated at 2022-06-23 20:53:08.689367
# Unit test for function romanize
def test_romanize():  # pylint: disable=unused-variable
    assert romanized()(lambda: 'привет')() == 'privet'
    assert romanized()(lambda: 'пРиВет')() == 'pRivEt'
    assert romanized()(lambda: 'привет, мир!')() == 'privet, mir!'

# Generated at 2022-06-23 20:53:17.063156
# Unit test for function romanize
def test_romanize():
    # romanize in russian
    @romanize(locale='ru')
    def get_text():
        return 'Вот такой текст'


    text = get_text()
    assert text == 'Vot takoj tekst'

    # romanize in ukrainian
    @romanize(locale='uk')
    def get_text():
        return 'Тестова ситуація'


    text = get_text()
    assert text == 'Testova sytuatsiia'

    # romanize in kazakh

# Generated at 2022-06-23 20:53:22.490586
# Unit test for function romanize
def test_romanize():
    def cyrillic(*args, **kwargs):
        return "Я запросто смогу перевести на русский это слово"

    romanized = romanize(locale='ru')(cyrillic)

    assert romanized() == 'Ya zaprosto smogu perevesti na russkiy etot slovo'

# Generated at 2022-06-23 20:53:24.114734
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()

# Generated at 2022-06-23 20:53:30.699784
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    rp = RussianSpecProvider()
    assert rp.romanize('Россия') == 'Rossiya'
    assert rp.romanize('Украина') == 'Ukraina'
    assert rp.romanize('Казахстан') == 'Kazakhstan'

# Generated at 2022-06-23 20:53:36.142436
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod(mimesis.__name__)

    from mimesis.builtins.cyrillic import Cyrillic as Cy

    cy = Cy()

    assert cy.romanize() == ''

    text1 = ('Мама мыла раму и покрасила ее в '
             'красный цвет, после этого ее помыли')
    assert cy.romanize(text1) == ('Mama myla ramu i pokrasila ee v '
                                  'krasnyi tsvet, posle etogo ee pomyli')

    # If a string contains the non-Russian characters


# Generated at 2022-06-23 20:53:36.787012
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:53:40.196750
# Unit test for function romanize
def test_romanize():
    """Test for romanize method."""
    from mimesis.builtins import Text
    t = Text(locale='ru')
    assert romanize(locale='ru')(t.word)
    assert romanized(locale='ru')(t.word)

# Generated at 2022-06-23 20:53:52.559051
# Unit test for function romanize
def test_romanize():
    def r(locale='ru'):
        @romanize(locale=locale)
        def _(s):
            return s

        return _

    assert r()('АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ') == 'abvgdeejzijklmnoprstufhccss_y_eua'

# Generated at 2022-06-23 20:53:54.478836
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider as s

    assert s().romanized() == s().romanize()

# Generated at 2022-06-23 20:53:56.720711
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def a():
        return 'Алло Владимир'

    assert a() == 'Allo Vladimir'

# Generated at 2022-06-23 20:54:00.596975
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    romanized_my_func = romanize('ru')(my_func)
    romanized_my_func_2 = romanized('ru')(my_func)
    assert romanized_my_func('Привет') == 'Privet'
    assert romanized_my_func_2('Привет') == 'Privet'


# Generated at 2022-06-23 20:54:09.454002
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def get_foo():
        return 'Привет, мир!'

    assert get_foo() == 'Privet, mir!'

    @romanize('uk')
    def get_foo():
        return 'Привіт, світ!'

    assert get_foo() == 'Pryvit, svit!'

    @romanize('kk')
    def get_foo():
        return 'Сәлем, дүние!'

    assert get_foo() == 'Sälem, dünie!'

# Generated at 2022-06-23 20:54:13.078360
# Unit test for function romanize
def test_romanize():
    l = romanize('ru')(lambda: 'สวัสดี')
    assert l() == 'Свасди'
    l = romanize('uk')(lambda: 'สวัสดี')
    assert l() == 'Свасді'
    l = romanize('kk')(lambda: 'สวัสดี')
    assert l() == 'Свасди'

# Generated at 2022-06-23 20:54:15.799444
# Unit test for function romanize
def test_romanize():
    result = romanized()(lambda x: 'Привет, мир!')
    expected = 'Privet, mir!'
    assert result == expected

# Generated at 2022-06-23 20:54:17.565443
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')(lambda: "qwerty")() == 'qwerty'

# Generated at 2022-06-23 20:54:22.051147
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'тест')() == 'test'
    assert romanize(locale='uk')(lambda: 'тест')() == 'test'
    assert romanize(locale='kk')(lambda: 'тест')() == 'test'



# Generated at 2022-06-23 20:54:24.076284
# Unit test for function romanize
def test_romanize():
    assert romanized('абырвалг')(lambda: 'абырвалг') == 'abyrvalg'

# Generated at 2022-06-23 20:54:29.269943
# Unit test for function romanize
def test_romanize():
    def func(self, s):
        return s

    romanized_func = romanize('ru')(func)
    assert romanized_func(None, 'Я пришла домой') == 'YA prishla domoy'

# Generated at 2022-06-23 20:54:31.914423
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    assert 'Лоренцо Моррино' == Person('ru').full_name
    assert 'Лоренцо Моррино' == Person(Locale.RUSSIAN).full_name



# Generated at 2022-06-23 20:54:41.912095
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.geography import Geography

    a = Address(Language.ENGLISH)
    p = Person(Language.ENGLISH, address=a)
    geo = Geography(Language.ENGLISH, random_data_provider=p, address=a)
    @romanize(locale='unsupported')
    def generate_name():
        return p.full_name()
    assert generate_name() == 'Катерина Королева'

    @romanize(locale='ru')
    def generate_name():
        return p.full_name()

# Generated at 2022-06-23 20:54:53.223137
# Unit test for function romanize
def test_romanize():
    assert romanize()("Привет, мир !!! кирилица прекрасен :)") == "privet, mir !!! kirillica prekrasen :)"
    assert romanize(locale='ru')("Москва, Волга и весь мир") == "moskva, volga i ves' mir"
    assert romanized(locale='ua')("Волга и Петербург") == "volha i peterburh"
    assert romanize(locale='kk')("Астана и Киев") == "astana i kiev"

# Generated at 2022-06-23 20:54:55.140603
# Unit test for function romanize
def test_romanize():
    assert callable(romanize_deco)
    assert callable(romanized_deco)



# Generated at 2022-06-23 20:55:05.346802
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Мама закусывала бабушку')() == 'mama zakusyvala babushku'
    assert romanize('uk')(lambda: 'Ось ці люд',)() == 'os tsii lud'
    assert romanize('kk')(lambda: 'Мына тексттер мәтін',)() == 'myna tekstter mәtin'
    assert romanize('ru')(lambda: 'Мама закусывала бабушку')() == 'mama zakusyvala babushku'



# Generated at 2022-06-23 20:55:06.326541
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-23 20:55:12.297801
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    rp = RussiaSpecProvider()
    assert rp.full_name() == 'Гусев Римма Васильевна'
    assert romanize()(rp.full_name)() == 'Gusev Rima Vasilievna'
    assert romanize('ru')(rp.full_name)() == 'Gusev Rima Vasilievna'
    assert romanize('uk')(rp.full_name)() == 'Gusev Rima Vasylivna'

# Generated at 2022-06-23 20:55:17.323578
# Unit test for function romanize
def test_romanize():

    @romanized(locale='ru')
    def rus():
        return 'привет мир'

    assert rus() == 'privet mir'

    @romanized(locale='uk')
    def ukr():
        return 'привіт світ'

    assert ukr() == 'pryvit svit'

    @romanized(locale='kk')
    def kaz():
        return 'Сәлем, әлем'

    assert kaz() == 'Salem, alim'

# Generated at 2022-06-23 20:55:24.617192
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'
    assert romanize('ru')(lambda: 'привет, привет!')() == 'privet, privet!'
    assert romanize('ru')(lambda: 'ПРИВЕТ, ПРИВЕТ!')() == 'PRIVET, PRIVET!'
    assert romanize('uk')(lambda: 'привіт')() == 'privit'
    assert romanize('uk')(lambda: 'привіт, привіт!')() == 'privit, privit!'

# Generated at 2022-06-23 20:55:29.671704
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider
    provider = RussiaSpecProvider
    assert provider.random_romanized_word(locale='ru') != provider.random_word(locale='ru')
    assert provider.random_romanized_word(locale='ru') == provider.random_romanized_word(locale='ru')

# Generated at 2022-06-23 20:55:34.243415
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins

    @mimesis.builtins.romanized('ru')
    def russian_name():
        return 'Марина Сергеевна'

    result = russian_name()
    assert result == 'Marina Sergeevna'

# Generated at 2022-06-23 20:55:35.818273
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'


# Generated at 2022-06-23 20:55:46.969590
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='ru')(lambda: 'Привет'.upper())() == 'PRIVET'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='uk')(lambda: 'Привіт'.upper())() == 'Pryvit'
    assert romanize(locale='kk')(lambda: 'Сәлем')() == 'Sälem'
    assert romanize(locale='kk')(lambda: 'Сәлем'.upper())() == 'SÄLEM'




# Generated at 2022-06-23 20:55:56.279720
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def romanize_ru(text):
        return text

    assert romanize_ru('Съешь ещё этих мягких французских булок') == 'Sushchyoshyotyikhmyagkikhfrantsuzskikhbulok'

    @romanize(locale='uk')
    def romanize_uk(text):
        return text


# Generated at 2022-06-23 20:55:59.545571
# Unit test for function romanize
def test_romanize():
    r = romanize('ru')(lambda: 'Hello world!')
    assert r == 'Hello world!'
    r = romanize('uk')(lambda: 'Привіт')
    assert r == 'Pryvit'

# Generated at 2022-06-23 20:56:10.551269
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир!')() == 'privet mir!'
    assert romanize('ru')(lambda: '')() == ''
    assert romanize('ru')(lambda: 'Русский')() == 'russkiy'
    assert romanize('ru')(lambda: 'РУССКИЙ')() == 'RUSSkiy'
    assert romanize('kk')(lambda: 'Сөйлеу')() == 'Söyleyu'
    assert romanize('kk')(lambda: 'Қазақша')() == 'Qazaqşa'

# Generated at 2022-06-23 20:56:16.344216
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    p = Person('ru')
    assert p.full_name() == 'Андрей Петров'
    assert p.full_name(romanize=True) == 'Andrey Petroff'
    assert p.full_name(romanize=True, gender=Person.GENDER_FEMALE) == 'Anna Ponomareva'



# Generated at 2022-06-23 20:56:24.070958
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Иван Иванов')() == 'Ivan Ivanov'
    assert romanize(locale='uk')(lambda: 'Іван Іванов')() == 'Ivan Ivanov'
    assert romanize(locale='kk')(lambda: 'Иван Иванов')() == 'Ivan Ivanov'

    def get_text():
        """Get text."""
        return 'Иванов Иван Иванович'

    romanized_text = romanize(locale='ru')(get_text)
    assert romanized_text() == get_text()

# Generated at 2022-06-23 20:56:25.220787
# Unit test for function romanize
def test_romanize():
  assert 'eeeeeeee' == romanize("ru")(lambda: 'eeeeeeee')()
  assert 'eeeeeeee' == romanized("ru")(lambda: 'eeeeeeee')()

# Generated at 2022-06-23 20:56:27.540814
# Unit test for function romanize
def test_romanize():

    @romanize('ru')
    def foo(x: int) -> str:
        return 'Пример' * x

    assert foo(2) == 'PrimerPrimer', 'Wrong romanization'



# Generated at 2022-06-23 20:56:38.472804
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    p = Person(Locale.RU)
    t = Text(Locale.RU)
    a = Address(Locale.RU)
    # Test romanized decorator
    assert p.full_name(romanized='en') == \
        p.full_name(romanized=Locale.EN)
    assert a.address(romanized='en') == \
        a.address(romanized=Locale.EN)
    assert t.sentence(romanized='en') == \
        t.sentence(romanized=Locale.EN)

# Generated at 2022-06-23 20:56:45.533127
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'фыва')() == 'fyva'
    assert romanize(locale='uk')(lambda: 'фыва')() == 'fiva'
    assert romanize(locale='kk')(lambda: 'фыва')() == 'fıwa'
    assert romanized(locale='ru')(lambda: 'фыва')() == 'fyva'

# Generated at 2022-06-23 20:56:55.523288
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.numbers import Numbers

    nums = Numbers(Locale.ENGLISH)
    # Romanize function decorator
    @romanized('ru')
    def get_string():
        return nums.numerify('test_test_test')

    assert get_string() == 'test_test_test'

    @romanize('uk')
    def get_string2():
        return nums.numerify('привіт_друже')

    assert get_string2() == 'privit_druzhe'

    @romanize('kk')
    def get_string3():
        return nums.numerify('тест_тест_тест')

    assert get_

# Generated at 2022-06-23 20:56:58.223135
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    assert romanize(Language.RU.value)(lambda : ['Русский'])() == 'Russkiy'

# Generated at 2022-06-23 20:56:59.863567
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-23 20:57:07.162672
# Unit test for function romanize
def test_romanize():
    from string import ascii_letters, digits, punctuation

    from mimesis.enums import Language

    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text

    txt = Text(Language.ENGLISH)

    internet = Internet()
    dt = Datetime()

    eng = txt.sentence(length=10)
    eng = eng.replace('.', '')
    eng = [i for i in eng if i in ascii_letters + digits + punctuation]

    eng_words = []

    def generate_eng():
        for _ in range(100):
            eng_words.append(eng)

    generate_eng()
    roman_eng = []

# Generated at 2022-06-23 20:57:14.199033
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'abc')() == 'abc'
    assert romanized('uk')(lambda: 'яблоко')() == 'yabloko'
    assert romanized('kk')(lambda: 'томак')() == 'tomаk'
    assert romanized('fr')(lambda: 'яблоко')() == 'yabloko'

# Generated at 2022-06-23 20:57:19.479351
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    import textwrap
    import mimesis.builtins as mimesis_builtins

    @romanize('ru')
    def _test(text: str) -> str:
        return text

    assert _test('Ящер') == 'Yaşer'
    assert _test('ЯЩЕР') == 'YAŞER'
    assert _test('функция') == 'funkciya'

# Generated at 2022-06-23 20:57:22.459223
# Unit test for function romanize
def test_romanize():
    """Test romanize function
    """
    assert romanize()(lambda x: "Русский")() == "Rysskiy"

# Generated at 2022-06-23 20:57:26.290632
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def rus(text):
        return text

    result = rus('Мимисис')
    assert result == 'Mimisis'

# Generated at 2022-06-23 20:57:31.358366
# Unit test for function romanize
def test_romanize():
    _test_data = [
        ('ru', 'Тестовый текст'),
        ('ua', 'Тестовий текст'),
        ('kk', 'Тесттік мәтін')
    ]

    for locale, text in _test_data:
        assert romanize(locale)(lambda x: text)() == text.lower()

# Generated at 2022-06-23 20:57:37.876283
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locales
    from mimesis.providers.person import Person

    p = Person(Locales.UK)
    assert p.full_name(romanize=True)
    assert p.full_name(romanize=True)
    assert p.full_name(romanize=True)
    assert p.full_name(romanize=True)

# Generated at 2022-06-23 20:57:40.463894
# Unit test for function romanize
def test_romanize():
    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT['ru'],
        **data.COMMON_LETTERS,
    })

    @romanize()
    def make_text(length):
        return alphabet.keys()

    make_text(10)
