

# Generated at 2022-06-23 20:47:45.746946
# Unit test for function romanize
def test_romanize():
    r = romanize(locale='ru')(lambda: 'Красивый текст')
    assert r() == 'Krasivyi tekst'

# Generated at 2022-06-23 20:47:49.908868
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.builtins import RussiaSpecProvider

    @Romanize(locale='ru')
    def romanize(self):
        return self.text.word()

    for i in range(20):
        txt = romanize(RussiaSpecProvider)


# Generated at 2022-06-23 20:47:52.893571
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def foo(bar):
        return bar

    assert foo('Привет, как дела?') == 'Privet, kak dela?'

# Generated at 2022-06-23 20:48:02.047306
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='uk')(lambda: 'Привіт')() == 'Pryvit'
    assert romanize(locale='ru')(lambda: 'Владимир')() == 'Vladimir'
    assert romanize(locale='uk')(lambda: 'Володимир')() == 'Volodymyr'
    assert romanize(locale='kk')(lambda: 'Қазақстан')() == 'Qazaqstan'

# Generated at 2022-06-23 20:48:04.818582
# Unit test for function romanize
def test_romanize():
    """Test romanize"""
    assert romanized('ru')(lambda: 'Привет Мир!')() == 'Privyet Mir!'

# Generated at 2022-06-23 20:48:10.321100
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет')(None) == 'Privet'
    assert romanize('uk')(lambda x: 'Привет')(None) == 'Pryvit'
    assert romanize('kk')(lambda x: 'Привет')(None) == 'Privet'



# Generated at 2022-06-23 20:48:11.151803
# Unit test for function romanize
def test_romanize():
    print(romanize('ru'))
    print(romanized('ru'))

# Generated at 2022-06-23 20:48:13.039638
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda x: 'Привет всем')().lower() == 'privet vsem'

# Generated at 2022-06-23 20:48:16.435986
# Unit test for function romanize
def test_romanize():
    def foo():
        return "Тест"

    romanized = romanize("ru")(foo)()
    assert romanized == "Test"

# Generated at 2022-06-23 20:48:22.680486
# Unit test for function romanize
def test_romanize():
    r = romanize()(romanize)
    assert r('ru') == r('ru')
    assert r('ru') != r('en')
    assert r('ru') != r('es')

    r = romanize()(romanize)
    assert r('ru') != r('ru')
    assert r('ru') != r('en')
    assert r('ru') != r('es')

    r = romanize()(romanize)
    assert r('ru') != r('ru')
    assert r('ru') != r('en')
    assert r('ru') != r('es')

# Generated at 2022-06-23 20:48:30.460526
# Unit test for function romanize
def test_romanize():
    """Test romanize function."""
    test_locale = 'ru'
    test_string = 'Привет, Мир!'

    # Check if test_string is Cyrillic
    assert test_string != 'Privet, Mir!'

    @romanize(locale=test_locale)
    def romanize_test(test_string):
        return test_string.lower()

    # Check if test_string is successfully romanized
    assert romanize_test(test_string) == 'Privet, Mir!'

# Generated at 2022-06-23 20:48:38.092081
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Здравствуйте')() == 'Zdravstvujte'
    assert romanize('uk')(lambda: 'Звертаюсь')() == 'Zvertajus'
    assert romanized('kk')(lambda: 'Сәлем, барлықханалар')() == 'Salem, barlıqhana-lar'

# Generated at 2022-06-23 20:48:40.427300
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    import mimesis.builtins
    g = mimesis.builtins.RussianSpecProvider()

    @romanize('ru')
    def romanized(number):
        """Romanize internal function."""
        return '{:04d}'.format(number)

    assert romanized(g.code('####')) == '0123'

# Generated at 2022-06-23 20:48:46.035678
# Unit test for function romanize
def test_romanize():
    import pytest

    @romanize(locale='ru')
    def foo(text):
        return text

    ex_txt = 'Привет, мир!'
    rus_ex_txt = 'Privet, mir!'

    with pytest.raises(UnsupportedLocale):
        @romanize(locale='cn')
        def foo(text):
            return text

    assert foo(ex_txt) == rus_ex_txt

# Generated at 2022-06-23 20:48:56.746450
# Unit test for function romanize
def test_romanize():
    """Test for romanize."""
    assert 'Георгий Победоносец' == romanize.__closure__[0].cell_contents('ru')('Георгий Победоносец')
    assert 'Святослав Петрович' == romanize.__closure__[0].cell_contents('ru')('Святослав Петрович')

# Generated at 2022-06-23 20:48:59.355130
# Unit test for function romanize
def test_romanize():
    """Tests for function romanize."""
    @romanized('ru')
    def hashtag_generator():
        return 'Привет'

    assert hashtag_generator() == 'Privet'

# Generated at 2022-06-23 20:49:02.635035
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize('en')('Привет') == 'Privet'
    assert romanized('en')('Привет') == 'Privet'

# Generated at 2022-06-23 20:49:13.816383
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    import mimesis.builtins.text as t
    r = t.Romanizer('ru')
    assert r.romanize(r.words(), 4) == r.romanize(r.words(), 4)
    assert r.romanize(r.words(), 4) != r.romanize(r.words(), 5)
    r = t.Romanizer('ua')
    assert r.romanize(r.words(), 4) == r.romanize(r.words(), 4)
    assert r.romanize(r.words(), 4) != r.romanize(r.words(), 5)
    r = t.Romanizer('kk')
    assert r.romanize(r.words(), 4) == r.romanize(r.words(), 4)

# Generated at 2022-06-23 20:49:14.521322
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')

# Generated at 2022-06-23 20:49:16.322534
# Unit test for function romanize
def test_romanize():
    print("romanized")
    print(romanized("ru")("Привет"))

    print("Привет".romanize("ru"))

# Generated at 2022-06-23 20:49:28.059248
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def test_romanize_ru():
        return 'Тестовый текст'

    assert test_romanize_ru() == 'Testovyj tekst'
    assert test_romanize_ru.__name__ == 'test_romanize_ru'

    @romanize('uk')
    def test_romanize_uk():
        return 'Тестовий текст'

    assert test_romanize_uk() == 'Testovyj tekst'
    assert test_romanize_uk.__name__ == 'test_romanize_uk'

    @romanize('kk')
    def test_romanize_kk():
        return 'Тесттік мәтін'

# Generated at 2022-06-23 20:49:28.920291
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-23 20:49:30.790868
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locales
    from mimesis.builtins import RussianSpecProvider
    prov = RussianSpecProvider(Locales.RU)
    romanized = prov._romanize('Пантеон')
    assert romanized == 'Panteon'

# Generated at 2022-06-23 20:49:32.079156
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: "Привет")() == "Privet"



# Generated at 2022-06-23 20:49:36.150862
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    result = 'Добро пожаловать на курс по Python!'
    romanized_string = romanize('ru')(lambda: result)()
    assert romanized_string == 'Dobro pozhalovat na kurs po Python!'
 

# Generated at 2022-06-23 20:49:40.559381
# Unit test for function romanize
def test_romanize():
    test_data = 'Привет Мир'
    correct_response = 'Privet Mir'
    assert romanize('ru')(lambda: test_data) == correct_response
test_romanize()

# Generated at 2022-06-23 20:49:50.331367
# Unit test for function romanize
def test_romanize():
    """Unit test to test romanize decorator."""
    # Simple function
    def simple_test(locale: str, text: str) -> str:
        return text

    expect = simple_test(locale="ru", text='Привет Мир')
    actual = simple_test(locale="ru", text='Привет Мир')
    assert expect == actual
    assert expect == 'Привет Мир'
    assert actual == 'Привет Мир'

    # Decorated with romanize
    @romanize(locale="ru")
    def decorated_test(locale: str, text: str) -> str:
        return text


# Generated at 2022-06-23 20:49:56.350185
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda x: 'мама мыла раму')() == 'mama myla ramu'
    assert romanize(locale='kk')(lambda x: 'Қазақстан')() == 'Kazakhstan'

# Generated at 2022-06-23 20:49:58.909045
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def russia():
        return 'Москва'

    assert russia() == 'Moskva'

# Generated at 2022-06-23 20:50:00.987132
# Unit test for function romanize
def test_romanize():
    """Test romanized."""
    assert romanized(locale='ru')('абв') == 'abv'
    assert romanized(locale='uk')('абв') == 'abv'
    assert romanized(locale='kk')('абв') == 'abv'

# Generated at 2022-06-23 20:50:10.825258
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.date_time import DateTime
    from mimesis.types import Code

    dt = DateTime(Locale.RUSSIAN.value)
    date = dt.date()
    assert date == romanize('ru')(dt.date)

    code = Code(Locale.UKRAINIAN.value)
    mac_address = code.mac_address()
    assert mac_address == romanize('uk')(code.mac_address)

    code = Code(Locale.KAZAKH.value)
    mac_address = code.mac_address()
    assert mac_address == romanize('kk')(code.mac_address)

# Generated at 2022-06-23 20:50:19.385754
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    import mimesis.builtins

    bi = mimesis.builtins.builtins

# Generated at 2022-06-23 20:50:27.582238
# Unit test for function romanize
def test_romanize():
    """Test romanize.
    """
    @romanize('ru')
    def get_ru():
        return 'Тестовый контент'

    @romanize('uk')
    def get_uk():
        return 'Тестовий контент'

    @romanize('kk')
    def get_kk():
        return 'Тесттік мақсат'

    assert get_ru() == 'Testovyy kontent'
    assert get_uk() == 'Testovyi kontent'
    assert get_kk() == 'Testtik maksat'

# Generated at 2022-06-23 20:50:31.346691
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locales
    from mimesis.providers import Personal

    personal = Personal(Locales.RU)
    str_ = personal.full_name()
    assert romanized(locale=Locales.RU)(lambda: str_)() == str_

# Generated at 2022-06-23 20:50:38.258148
# Unit test for function romanize
def test_romanize():
    @romanize()
    def foo():
        return 'О том, как Александр Попов учил канонам инженерного дела.'

    assert foo() == 'O tom, kak Aleksandr Popov uchil kanonom inzhenernogo dela.'

# Generated at 2022-06-23 20:50:45.192411
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize(locale='uk')(lambda: 'Вітаю, Світ!')() == 'Vitayu, Svit!'
    assert romanize(locale='kk')(lambda: 'Қош келдіңіз, Дүние!')() == 'Qosh keldiñiz, Dünie!'

# Generated at 2022-06-23 20:50:51.599536
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    from mimesis.enums import Locale
    
    romanized_text = romanize(locale=Locale.RU)(lambda: "привет")()
    assert romanized_text == "privet"

    @romanized(Locale.UK)
    def some_method():
        return "привіт"

    assert some_method() == "privit"

    @romanized(Locale.RU)
    def some_method():
        return "привіт"

    assert some_method() == "privit"

# Generated at 2022-06-23 20:51:00.267988
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def roramize_text():
        return 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'
    assert 'ABVGDEEZHZIJKLMNOPRSTUFHCCSSYEEYJA' == roramize_text()


# Generated at 2022-06-23 20:51:01.208127
# Unit test for function romanize
def test_romanize():
    assert romanize == romanized

# Generated at 2022-06-23 20:51:08.179117
# Unit test for function romanize
def test_romanize():
    # Test translate function
    def test_f(input_str):
        return input_str

    test_f = romanize('kk')(test_f)

    assert test_f('Вероника') == 'Beronіka'

    # Test as decorator
    @romanize('kk')
    def test_f2(input_str):
        return input_str

    assert test_f2('Вероника') == 'Beronіka'

# Generated at 2022-06-23 20:51:15.224289
# Unit test for function romanize
def test_romanize():
    cyrillic_string = 'Данный метод работает, только для ru, uk, kk'
    latin_string = romanize('ru')(lambda: cyrillic_string)()
    assert 'Danniy metod rabotaet, tolko dlya ru, uk, kk' == latin_string

# Generated at 2022-06-23 20:51:19.010664
# Unit test for function romanize
def test_romanize():
    """Test romanization function."""
    def test_fun(text):
        """Simple, returns text."""
        return text

    wrapper = romanize('uk')(test_fun)
    assert wrapper('привіт') == 'pryvit'

# Generated at 2022-06-23 20:51:21.998667
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def a(x):
        return x

    t = a(locale='ru')
    assert t('Привет') == 'Privet'

# Generated at 2022-06-23 20:51:24.273474
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Москва')() == 'Moskva'

# Generated at 2022-06-23 20:51:33.403369
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет! Меня зовут Михаил.') == 'Privet! Menya zovut Mikhail.'
    assert romanized()('Привет! Меня зовут Михаил.') == 'Privet! Menya zovut Mikhail.'
    assert romanized('uk')('Привіт! Мене звати Михайло.') == 'Pryvit! Meny zvaty Mykhailo.'

# Generated at 2022-06-23 20:51:34.969991
# Unit test for function romanize
def test_romanize():
    assert 'Kak dela' == romanize('ru')('как дела')

# Generated at 2022-06-23 20:51:38.584219
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, мир!') == 'Privet, mir!'
    assert romanize()('我爱你.') == '我爱你.'
    assert romanize('uk')('Привіт, світ!') == 'Pryvit, svit!'

# Generated at 2022-06-23 20:51:40.620713
# Unit test for function romanize
def test_romanize():
    assert romanize()('Тест') == 'Test'

# Generated at 2022-06-23 20:51:45.008611
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda a: 'й')('y') == 'y'
    assert romanize('uk')(lambda a: 'й')('y') == 'y'
    assert romanize('kk')(lambda a: 'й')('y') == 'y'

# Generated at 2022-06-23 20:51:48.608892
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda : 'Привет мир!' )() == 'Privet mir!'
    assert romanized('uk')(lambda : 'Привіт світ!' )() == 'Pryvit svit!'
    assert romanized('kk')(lambda : 'Салам дүйнө!' )() == 'Salam dýýnö!'

# Generated at 2022-06-23 20:51:57.549547
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет, мистер МакКлауд')() ==\
        'privet, mister Makhklaud'

    assert romanize('uk')(lambda: 'привіт, пане МакКлоуд')() ==\
        'pryvit, panye MakKloud'

    assert romanize('kk')(lambda: 'сәлем, мистер МакКлауд')() ==\
        'sәlem, mister Makhklaud'



# Generated at 2022-06-23 20:52:02.986588
# Unit test for function romanize
def test_romanize():
    romanize_ru = romanize(locale='ru')
    romanize_uk = romanize(locale='uk')
    romanize_kk = romanize(locale='kk')

    assert romanize_ru('Привет, Мир!') == 'Priviet, Mir!'
    assert romanize_uk('Привіт, Світе!') == 'Pryvit, Svite!'
    assert romanize_kk('Сәлем, Дүние!') == 'Sälem, Dünie!'

# Generated at 2022-06-23 20:52:05.008330
# Unit test for function romanize
def test_romanize():
    assert romanized()('Привет') == 'Privet'


# Generated at 2022-06-23 20:52:07.007305
# Unit test for function romanize
def test_romanize():

    import pytest

    with pytest.raises(UnsupportedLocale):
        romanize('ab')(lambda: 'abc')

    # TODO: Add tests


# Generated at 2022-06-23 20:52:11.549134
# Unit test for function romanize
def test_romanize():
    assert romanize()('Мама мыла раму') == 'Mama myla ramu'
    assert romanize('uk')('Вітаю') == 'Vitayu'
    assert romanize('kk')('Қанықтық') == 'Qanyqtyq'

# Generated at 2022-06-23 20:52:20.609478
# Unit test for function romanize
def test_romanize():
    romanized_func = romanize('ru')(lambda: 'Привет, мир')
    assert isinstance(romanized_func, functools.partial)

    romanized_func = romanized('ru')(lambda: 'Привет, мир')
    assert isinstance(romanized_func, functools.partial)

    romanized_func = romanize()(lambda: 'hello')
    assert isinstance(romanized_func, functools.partial)

    assert romanized_func() == 'hello'

# Generated at 2022-06-23 20:52:30.263419
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'русский')() == 'russkiy'
    assert romanize(locale='ru')(lambda: 'russian')() == 'russian'
    assert romanize(locale='ru')(lambda: 'фүқия')() == 'fukhiia'
    assert romanize(locale='uk')(lambda: 'Україна')() == 'Ukraiina'
    assert romanize(locale='uk')(lambda: 'Ukraiina')() == 'Ukraiina'

# Generated at 2022-06-23 20:52:37.687848
# Unit test for function romanize
def test_romanize():
    romanize_deco = romanize(locale='ru')

    @romanize_deco
    def test_cyrillic_text():
        return 'Привет'
    assert test_cyrillic_text() == 'Privet'

    try:
        romanize_deco = romanize(locale='it')
    except UnsupportedLocale as e:
        assert e.args[0] == 'it'



# Generated at 2022-06-23 20:52:47.798484
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda self: "привет")(None) == 'privet'
    assert romanize()(lambda self: "Привет")(None) == 'Privet'
    assert romanize(locale='uk')(lambda self: "привет")(None) == 'pryvit'
    assert romanize(locale='kk')(lambda self: "привет")(None) == 'privet'
    assert romanize(locale='kk')(lambda self: "привет 123,.-")(None) == 'privet 123,.-'

# Generated at 2022-06-23 20:52:52.110793
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text

    text = Text(locale='ru')
    assert text.romanize('Текст на русском') == 'Tekst na russkom'

# Generated at 2022-06-23 20:52:53.778254
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет')() == 'Privet'



# Generated at 2022-06-23 20:52:55.280722
# Unit test for function romanize
def test_romanize():
  for i in range(1, 10):
    assert len(RomanizedDataProvider().romanize(i)) == i

# Generated at 2022-06-23 20:52:56.943369
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Женя')() == 'Zhenya'



# Generated at 2022-06-23 20:52:59.613757
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda : 'Какой-то текст')() == 'Kakoj-to tekst'

# Generated at 2022-06-23 20:53:03.876750
# Unit test for function romanize
def test_romanize():
    romanize_deco = romanize('ru')
    func = romanize_deco(lambda: 'Привет, Мир!')
    assert func() == 'Privet, Mir!'

# Generated at 2022-06-23 20:53:06.243257
# Unit test for function romanize
def test_romanize():
    @romanize()
    def roman():
        return 'ёфыавпролджэячсмитюцукенгшщзхъфыв'
    assert roman() == 'yo_fy_av_prol_dzh_ye_ya_ch_sm_it_yu_tsu_k_e_ne_g_sh_sh_z_kh_f_y_v'

# Generated at 2022-06-23 20:53:15.201558
# Unit test for function romanize
def test_romanize():
    """Test for romanize decorator."""
    # Cyrillic string can contain ascii
    # symbols, digits and punctuation.
    alphabet = {s: s for s in
                ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT['ru'],
        **data.COMMON_LETTERS,
    })

    def _test(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            txt = ''.join([alphabet[i] for i in result if i in alphabet])
            return txt

        return wrapper

    @_test
    def _test_1(x: str = 'hey') -> str:
        return x


# Generated at 2022-06-23 20:53:16.870584
# Unit test for function romanize
def test_romanize():
    assert 'pyanaya' == romanize('ru')('пыанаыа')

# Generated at 2022-06-23 20:53:27.998978
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize."""
    assert romanize('ru')(lambda: 'Привет мир, сколько сейчас времени?')() == \
        'Privet mir, skolko seychas vremeni?'
    assert romanize('uk')(lambda: 'Привіт світе, скільки саме часу?')() == \
        'Pryvit svite, skilky same chasu?'

# Generated at 2022-06-23 20:53:33.076985
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет!')() == 'Privet!'
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'
    assert romanize('ru')(lambda: 'Привет, Мир!')() == 'Privet, Mir!'

# Generated at 2022-06-23 20:53:38.362596
# Unit test for function romanize
def test_romanize():
    from mimesis import Person, Datetime
    from mimesis.builtins import ArmeniaSpecProvider

    # Russian
    p = Person(locale='ru')
    d = Datetime(locale='ru')
    assert p.full_name() == 'Андрей Скворцов'
    assert p.name() == 'Андрей'
    assert p.surname() == 'Скворцов'
    assert d.month(full_name=True) == 'сентябрь'

    # Ukrainian
    p = Person(locale='uk')
    d = Datetime(locale='uk')

# Generated at 2022-06-23 20:53:39.079721
# Unit test for function romanize
def test_romanize():
    assert True

# Generated at 2022-06-23 20:53:42.040682
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет!')() == 'Privet!'
    assert romanize('uk')(lambda: 'Привіт!')() == 'Pryvit!'

# Generated at 2022-06-23 20:53:45.818476
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.cyrillic import Cyrillic

    cyr = Cyrillic('ru')

    roman = romanize('ru')(cyr.text)
    assert roman('Hello, World!').isalpha()

# Generated at 2022-06-23 20:53:50.436930
# Unit test for function romanize
def test_romanize():
    assert (romanize('ru')(lambda: 'привет')() ==
            romanize('uk')(lambda: 'привіт')() ==
            romanize('kk')(lambda: 'сәлем')() == 'privet')

# Generated at 2022-06-23 20:53:52.007774
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: '')() == ''

# Generated at 2022-06-23 20:53:55.121223
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru')(lambda: 'РУССКИЙ ЯЗЫК')() == 'russkiy yazyk'

# Generated at 2022-06-23 20:53:57.861429
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda x: data.UKRAINIAN_TEXT)
    assert romanized('ru')(lambda x: data.RUSSIAN_TEXT)
    assert romanized('kk')(lambda x: data.KAZAKH_TEXT)

# Generated at 2022-06-23 20:54:07.598964
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT
    from mimesis.enums import Language

    r = data.CyrillicAlphabet('ru')
    assert r.romanize() in ROMANIZATION_DICT[Language.RUSSIAN]

    r = data.CyrillicAlphabet('uk')
    assert r.romanize() in ROMANIZATION_DICT[Language.UKRAINIAN]

    r = data.CyrillicAlphabet('kk')
    assert r.romanize() in ROMANIZATION_DICT[Language.KAZAKH]



# Generated at 2022-06-23 20:54:11.037572
# Unit test for function romanize
def test_romanize():
    """Test romanize."""
    assert romanize()
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-23 20:54:17.668807
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider

    russian = RussianSpecProvider()
    text = russian.text(10)
    assert text != ''

    romanized_text = russian.romanized_text(10)
    assert romanized_text != ''

    # This is for test backward compatibility. Can be removed in v2.0.0
    romanized_text = russian.romanized(10)
    assert romanized_text != ''

# Generated at 2022-06-23 20:54:21.181337
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='')(lambda: 'Привет')() == 'Privet'
    assert romanize(locale='ru')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:54:28.812347
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda x: 'Привет')() == 'Privet'
    assert romanize('ru')(lambda x: 'Привет')() == 'Privet'
    assert romanize('uk')(lambda x: 'Привіт')() == 'Pryvit'
    assert romanize('kk')(lambda x: 'салам')() == 'salam'

# Generated at 2022-06-23 20:54:31.166264
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Сьомая колонна.') == 'S\'omaya kolonna.'

# Generated at 2022-06-23 20:54:34.387499
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Юзер')() == 'Yuser'
    assert romanize('uk')(lambda: 'Юзер')() == 'Juser'
    assert romanize('kk')(lambda: 'Юзер')() == 'Yuser'

# Generated at 2022-06-23 20:54:41.389361
# Unit test for function romanize
def test_romanize():
    """Test for the function romanize."""
    from ..random import random

    r = random.Random(locale='ru')
    assert r.text.romanize(locale='ru') == \
        'Za mnoyu stoyaet koshka'
    assert r.text.romanize(locale='uk') == \
        'Vykrukuvavshy vie vidizdiv'
    assert r.text.romanize(locale='kk') == \
        'Kozhairdi myn bЙsine tabylady'

# Generated at 2022-06-23 20:54:47.736432
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: "Хаштон")() == "Khashton"
    assert romanize(locale='uk')(lambda: "Хаштон")() == "Khashton"
    assert romanize(locale='kk')(lambda: "Хаштон")() == "Khaston"

# Generated at 2022-06-23 20:54:56.269187
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locales
    from mimesis.providers.address import Address

    @romanize(locale=Locales.RU)
    def romanized(arg):
        return arg

    assert romanized('Ф') == 'F'
    assert romanized('В') == 'V'
    assert romanized('К') == 'K'
    assert romanized('Русский') == 'Russky'

    address = Address(locale=Locales.RU)
    assert type(address.building_number()) == str



# Generated at 2022-06-23 20:54:57.362575
# Unit test for function romanize
def test_romanize():
    romanize(locale='ru')

# Generated at 2022-06-23 20:55:01.416382
# Unit test for function romanize
def test_romanize():
    """Test for function romanize

    .. code:: python

        from mimesis.utils import romanize

        @romanize()
        def move(locale: str) -> str:
            return get_data('locales', locale=locale)

        move('ru')
        # => 'поход'

    """
    pass

# Generated at 2022-06-23 20:55:04.254761
# Unit test for function romanize
def test_romanize():
    @romanize('uk')
    def _random_ukrainian_text():
        return 'Буква не є абеткою'

    assert _random_ukrainian_text() == 'Bukva ne ye abetkoiu'

# Generated at 2022-06-23 20:55:07.186333
# Unit test for function romanize
def test_romanize():
    """Romanize text."""
    @romanize()
    def get_word():
        return 'Абракадабра'

    text = get_word()
    assert text == 'Abrakadabra'

# Generated at 2022-06-23 20:55:10.234365
# Unit test for function romanize
def test_romanize():
    data.COMMON_LETTERS.update({'test': 'test'})
    class Example:
        @romanize()
        def get_test(self):
            return 'test'

    ex = Example()
    assert ex.get_test() == 'test'

# Generated at 2022-06-23 20:55:12.477003
# Unit test for function romanize
def test_romanize():
    @romanized(locale='ru')
    def _(self):
        return 'Привет, Мир!'

    assert _(None) == 'Privet, Mir!'

# Generated at 2022-06-23 20:55:15.327171
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanize('ru'))

test_romanize()

# Generated at 2022-06-23 20:55:18.080485
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def _(seed: int = None) -> str:
        return 'Где Котик?'

    assert _() == 'Gde Kotik?'

# Generated at 2022-06-23 20:55:24.043453
# Unit test for function romanize
def test_romanize():

    @romanize('ru')
    def ru_words(a):
        return a

    test_1 = ru_words('Привет')
    assert test_1 == 'Privet'

    @romanize('uk')
    def uk_words(a):
        return a

    test_2 = uk_words('Привіт')
    assert test_2 == 'Pryvit'

    @romanize('kk')
    def kk_words(a):
        return a

    test_3 = kk_words('Сәлем')
    assert test_3 == 'Sälem'

# Generated at 2022-06-23 20:55:32.144906
# Unit test for function romanize
def test_romanize():
    from mimesis.localization import DefaultLocale
    from mimesis.schema import Field, Schema

    class CustomProvider(DefaultLocale):
        @property
        @romanized(locale='ru')
        def word(self) -> str:
            return self.random.choice(data.RU.words)

    provider = CustomProvider()
    assert 'Как' in data.RU.words
    assert 'Kak' not in data.RU.words
    assert provider.word() == 'Kak'

    schema = Schema(field=Field('word', provider=CustomProvider),
                    provider=CustomProvider,)
    assert 'Как' in data.RU.words
    assert 'Kak' not in data.RU.words

# Generated at 2022-06-23 20:55:38.690246
# Unit test for function romanize
def test_romanize():
    for key, value in data.ROMANIZATION_DICT.items():
        @romanized(key)
        def test(a, b, c):
            return f'{a}{b}{c}'
        if key == 'uk':
            assert test(value['п'], value['и'], value['в']) == 'pyv'
        elif key == 'ru':
            assert test(value['п'], value['и'], value['в']) == 'piv'
        else:
            assert test(value['п'], value['и'], value['в']) == 'pyv'

# Generated at 2022-06-23 20:55:44.346590
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda :'правда')() == 'pravda'
    assert romanize('uk')(lambda :'правда')() == 'pravda'
    assert romanize('kk')(lambda :'правда')() == 'pravda'

# Generated at 2022-06-23 20:55:46.325497
# Unit test for function romanize
def test_romanize():
    romanized_func = romanized()
    romanized_func(return_value='Привет')
    # UnsupportedLocale will be raised
    romanized_func(return_value='Привет', locale='en')

# Generated at 2022-06-23 20:55:48.515073
# Unit test for function romanize
def test_romanize():
    s = 'привет мир'
    r = 'privet mir'
    assert romanize()(s) == r

# Generated at 2022-06-23 20:55:50.571268
# Unit test for function romanize
def test_romanize():
    assert romanize('en')(lambda: 'Привет')() == 'Privet'

# Generated at 2022-06-23 20:55:59.885543
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.builtins import Person

    person = Person('ru')

    # test romanization for ukrainian
    @romanize(locale='uk')
    def get_name():
        return person.name()

    assert get_name() == person.name(romanize=True)


    # test romanization for kazakh
    @romanize(locale='kk')
    def get_name():
        return person.name()

    assert get_name() == person.name(romanize=True)


    # test romanization for russian
    @romanize(locale='ru')
    def get_name():
        return person.name()

    assert get_name() == person.name(romanize=True)

    # test normal usage

# Generated at 2022-06-23 20:56:04.474951
# Unit test for function romanize
def test_romanize():
    text = 'Привет, друг'
    romanized_string = romanize(locale='')

    assert romanized_string(text) == 'Privet, drug'

# Generated at 2022-06-23 20:56:06.450804
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: "Лайка") == 'Laika'



# Generated at 2022-06-23 20:56:10.295510
# Unit test for function romanize
def test_romanize():
    # romanize is a decorator,
    # so we use romanize()(lambda: ...)()
    @romanize('ru')
    def get_russian_text():
        return data.RUSSIAN_WORDS

    assert get_russian_text()  # noqa: WPS421

# Generated at 2022-06-23 20:56:17.964635
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет Мир')() == 'Privet Mir'
    assert romanize('uk')(lambda: 'Привіт Світ')() == 'Pryvit Svit'
    assert romanize('kk')(lambda: 'Сәлем Дүние')() == 'Sälem Dünie'
    assert romanize()(lambda: 'Привет Мир')() == 'Privet Mir'

# Generated at 2022-06-23 20:56:29.979094
# Unit test for function romanize
def test_romanize():
    dict_romanize = {
        'Привет, мир!': 'Privet, mir!',
        'Прівет, світе!': 'Privet, svite!',
        'Прывітанне, свет!': 'Прывітанне, svet!',
        'Сағынған жердегіңіздей жатырмын!':
            'Sagynghan jerdegingizdej zatyrmyn!'
    }
    for key, value in dict_romanize.items():
        assert romanized('ru')(lambda: key)()

# Generated at 2022-06-23 20:56:40.752168
# Unit test for function romanize
def test_romanize():
    """Test for `romanize`."""
    validator = data.create_validator('ru')
    for i in range(0, 5):
        person = data.create_person('ru')
        fullname = person.full_name()
        assert isinstance(fullname, str)
        assert ' ' in fullname

        first_name = person.name()
        assert isinstance(first_name, str)
        assert validator.is_first_name(first_name)

        last_name = person.surname()
        assert isinstance(last_name, str)
        assert validator.is_last_name(last_name)

        patronymic = person.patronymic()
        assert isinstance(patronymic, str)
        assert validator.is_patronymic(patronymic)

# Generated at 2022-06-23 20:56:45.429797
# Unit test for function romanize
def test_romanize():
    # assert romanize('ru')(str)('Европа') == 'Evropa'
    assert romanize('uk')(str)('Європа') == 'Ievropa'

# Generated at 2022-06-23 20:56:52.192298
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Languages
    from mimesis import enums, Person
    person = Person()

    @romanize(Languages.RUSSIAN)
    def foo(x):
        return x

    assert foo(person.name()) == \
        person.name(language=enums.Languages.ENGLISH)

    assert foo(person.surname()) == \
        person.surname(language=enums.Languages.ENGLISH)

# Generated at 2022-06-23 20:56:54.741240
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.person import Person

    person = Person('ru')
    person.name()

# Generated at 2022-06-23 20:57:01.702574
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет мир!')() == 'Privet mir!'
    assert romanize('uk')(lambda: 'Привіт світе!')() == 'Pryvit svite!'
    assert romanize('kk')(lambda: 'Сәлем дүние!')() == 'Sälem dünie!'

# Generated at 2022-06-23 20:57:11.099676
# Unit test for function romanize
def test_romanize():
    for locale in ('ru', 'uk', 'kk'):
        @romanize(locale)
        def romanize_test(locale: str=''):
            return data.DATA[locale]['words']

        # Test romanize for data.BASIC
        for field in data.ROMANIZATION[locale]:
            assert romanize_test(locale)[field] == \
                data.ROMANIZATION[locale][field]

        assert romanize_test()[data.NUMERALS[locale]] == \
            data.ROMANIZATION[locale][data.NUMERALS[locale]]

# Generated at 2022-06-23 20:57:14.199326
# Unit test for function romanize
def test_romanize():
    @romanized(locale='ru')
    def rus():
        return 'Русский язык'

    assert rus() == 'Russkii iazyk'

# Generated at 2022-06-23 20:57:15.673394
# Unit test for function romanize
def test_romanize():
    pass


if __name__ == '__main__':
    print(test_romanize())

# Generated at 2022-06-23 20:57:21.369581
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def some_text_gen():
        yield 'I am text'
        yield 'Привет'

    text = some_text_gen()
    assert text == 'I am text'
    text = some_text_gen()
    assert text == 'Privet'

# Generated at 2022-06-23 20:57:24.463536
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'он она оно')().startswith('on ona ono')
    assert romanized('uk')(lambda: 'он она оно')().startswith('on ona ono')
    assert romanized('kk')(lambda: 'он она оно')().startswith('on ona ono')

# Generated at 2022-06-23 20:57:27.644176
# Unit test for function romanize
def test_romanize():
    def test_func(string):
        return string

    assert romanize(locale="ru")(test_func)("тестовая строка") == "testovaya stroka"



# Generated at 2022-06-23 20:57:28.530635
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()

# Generated at 2022-06-23 20:57:29.699491
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()



# Generated at 2022-06-23 20:57:35.662230
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'строка')() == 'str'
    assert romanize('uk')(lambda: 'строка')() == 'str'
    assert romanized('kk')(lambda: 'строка')() == 'str'

    # With additional non-cyrillic characters
    assert romanize('ru')(lambda: '123строка!@#$')() == '123str'
    assert romanize('uk')(lambda: '123строка!@#$')() == '123str'
    assert romanized('kk')(lambda: '123строка!@#$')() == '123str'



# Generated at 2022-06-23 20:57:40.771182
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def test(s: str) -> str:
        return s

    assert test('Russian') == 'Russkiy'
    assert test('Русский') == 'Russkiy'
    assert test('Русский Язык') == 'Russkiy Yazyk'
    assert test('Великая Отечественная') == 'Velikaya Otechestvennaya'

    @romanize(locale='uk')
    def test(s: str) -> str:
        return s

    assert test('Слово') == 'Slovo'
    assert test('Назва') == 'Nazva'

# Generated at 2022-06-23 20:57:43.129168
# Unit test for function romanize
def test_romanize():
    romanized_string = romanized(locale='ru')(lambda: 'Вася Пупкин')()
    assert romanized_string == 'Vasya Pupkin'