

# Generated at 2022-06-25 20:08:02.047576
# Unit test for function romanize
def test_romanize():
    assert callable_0('Привет') == 'Privet'
    assert callable_0('привет') == 'privet'
    assert callable_0('ПРИВЕТ') == 'PRIVET'

if __name__ == '__main__':
    test_case_0()
    test_romanize()


# Generated at 2022-06-25 20:08:03.544294
# Unit test for function romanize
def test_romanize():
    assert True == True



# Generated at 2022-06-25 20:08:06.145076
# Unit test for function romanize
def test_romanize():
    assert callable_0 is not None
    assert callable_0() is None

# Generated at 2022-06-25 20:08:08.109442
# Unit test for function romanize
def test_romanize():
    # Test function: function romanize
    callable_0 = romanize()

    # Test function: function romanize
    callable_1 = romanize('en')



# Generated at 2022-06-25 20:08:10.707306
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru') is not None, "Couldn't find romanize function."

# Generated at 2022-06-25 20:08:12.249145
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()



# Generated at 2022-06-25 20:08:24.562945
# Unit test for function romanize
def test_romanize():
    test_case_0()
    # Testing into the russian locale.

    # Call the decorated function.
    result = romanize(locale='ru')(lambda: 'сольдень')

    assert result == 'salden'

    # Testing into the ukrainian locale.
    result = romanize(locale='uk')(lambda: 'зварював')

    assert result == 'zvaruvav'

    # Testing into the kazakh locale.

    # Call the decorated function.
    result = romanize(locale='kk')(lambda: 'Дініс')

    assert result == 'Dinis'

    # Testing of the romanized alias.

# Generated at 2022-06-25 20:08:25.957433
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())



# Generated at 2022-06-25 20:08:31.656753
# Unit test for function romanize
def test_romanize():
    expected_result = 'aiuoeiou'
    actual_result = romanize(locale='ru')('АЙУОЕИОУ')
    assert actual_result == expected_result


test_case_0()
test_romanize()

# Generated at 2022-06-25 20:08:39.131733
# Unit test for function romanize
def test_romanize():
    # This function tests romanization for russian locale
    def romanize_russian(func):
        def wrapper():
            func()
            assert __result__ == 'hello'
        return wrapper

    @romanize()
    def test_romanize_0():
        global __result__
        __result__ = 'привет'

    @romanize()
    def test_romanize_1():
        global __result__
        __result__ = 'день'

    @romanize()
    def test_romanize_2():
        global __result__
        __result__ = 'завтра'

    @romanize()
    def test_romanize_3():
        global __result__
        __result__ = 'просто'


# Generated at 2022-06-25 20:08:51.799976
# Unit test for function romanize
def test_romanize():
    locale = locale_0 = locale_1 = locale_2 = 'de'
    alphabet_0 = alphabet_1 = alphabet_2 = data.ROMANIZATION_DICT[locale]
    func = func_0 = func_1 = func_2 = romanize(locale)
    func_result_0 = func_0()

# Generated at 2022-06-25 20:08:58.320925
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT

    @romanize('ru')
    def func(locale: str = None):
        return 'Привет мир!'

    romanized_text = func()
    normal_text = []
    for i in 'Привет мир!':
        if i in ROMANIZATION_DICT['ru']:
            normal_text.append(ROMANIZATION_DICT['ru'][i])
        elif i in data.COMMON_LETTERS:
            normal_text.append(data.COMMON_LETTERS[i])
        else:
            normal_text.append(i)

    assert romanized_text == ''.join(normal_text)

# Generated at 2022-06-25 20:09:01.967078
# Unit test for function romanize
def test_romanize():
    try:
        test_case_0()
    except KeyError:
        pass
    except UnsupportedLocale:
        pass

# Generated at 2022-06-25 20:09:03.583340
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()


# Generated at 2022-06-25 20:09:07.018042
# Unit test for function romanize
def test_romanize():
    assert callable_0(5) == '5', 'Failed test_romanize__1'


# Generated at 2022-06-25 20:09:11.208299
# Unit test for function romanize
def test_romanize():
    assert callable_0("Где моя бутса, сволочь?") == 'Gde moja butsa, svoločʹ?'


# Generated at 2022-06-25 20:09:17.504215
# Unit test for function romanize
def test_romanize():
    # Simple test for Romanize decorator with locale in English.
    assert romanize()('Привет') == 'Privet'

    # Simple test for Romanize decorator with locale in Russian.
    assert romanize('ru')('Привет') == 'Privet'

    # Simple test for Romanize decorator with locale in Ukrainian.
    assert romanize('uk')('Привет') == 'Pryvit'

    # Simple test for Romanize decorator with locale in Kazakh.
    assert romanize('kk')('Привет') == 'Privet'


# Generated at 2022-06-25 20:09:28.412262
# Unit test for function romanize
def test_romanize():
    mock_locale_0 = 'tlh'

    callable_0 = romanize(mock_locale_0)
    mock_func_0 = lambda : 'ཟླ་བ་དང་པོ་སྤྱི་ཟླ་དགུ་པ'
    mock_func_0 = callable_0(mock_func_0)
    mock_func_0 = mock_func_0()

# Generated at 2022-06-25 20:09:33.842682
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    result_0 = callable_0('text')
    assert isinstance(result_0, str)
    assert len(result_0) >= 0
    result_1 = callable_0(2)
    assert isinstance(result_1, str)
    assert len(result_1) >= 0
    result_2 = callable_0(3)
    assert isinstance(result_2, str)
    assert len(result_2) >= 0
    result_3 = callable_0(4)
    assert isinstance(result_3, str)
    assert len(result_3) >= 0
    result_4 = callable_0(5)
    assert isinstance(result_4, str)
    assert len(result_4) >= 0

# Generated at 2022-06-25 20:09:34.935698
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()



# Generated at 2022-06-25 20:09:57.396388
# Unit test for function romanize
def test_romanize():
    string = "Я родился 13 апреля / в городе Ижевске / и затем вырос в Нижнем Новгороде"
    romanize_locale = romanize('ru')
    romanize_without_locale = romanize()
    assert romanize_locale(string) == "YA rodivsya 13 aprelya / v gorode Izhivske / i zatem vyros v Nizhnem Novgorode"

# Generated at 2022-06-25 20:09:59.212893
# Unit test for function romanize
def test_romanize():
    assert romanize() != Callable
    return

# Generated at 2022-06-25 20:10:02.822671
# Unit test for function romanize
def test_romanize():
    result = romanize()(lambda *args, **kwargs: 'Ололо')
    assert result == 'Oлолo'

# Generated at 2022-06-25 20:10:05.858012
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanize('ru'))
    assert callable(romanize('uk'))
    assert callable(romanize('kk'))
    assert callable(romanize('en'))
    assert callable(romanize('it'))
    assert callable(romanize('es'))
    assert callable(romanize('fr'))



# Generated at 2022-06-25 20:10:08.861046
# Unit test for function romanize
def test_romanize():
    from mimesis import Generic

    class Foo:
        def __init__(self):
            self.local = 'ru'

        @romanize(locale='ru')
        def get_ru(self):
            return Generic('ru').name()

    foo_obj = Foo()
    assert isinstance(foo_obj.get_ru(), str)

    test_case_0()


# Generated at 2022-06-25 20:10:10.782355
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0 is not None

# Generated at 2022-06-25 20:10:16.307494
# Unit test for function romanize
def test_romanize():
    # Testing whether the function romanize() is called at least once
    assert test_case_0.called
    # Testing whether the function romanize() is called more than once
    assert test_case_0.call_count > 1

# Generated at 2022-06-25 20:10:17.940648
# Unit test for function romanize
def test_romanize():
    assert callable_0('Вася') == 'Vasia'

# Generated at 2022-06-25 20:10:30.228288
# Unit test for function romanize
def test_romanize():
    """Tests for romanize."""
    # noinspection PyUnusedLocal
    def romanize_0(locale: str = '') -> Callable:
        def romanize_deco(func):
            # @functools.wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    # Cyrillic string can contain ascii
                    # symbols, digits and punctuation.
                    alphabet = {s: s for s in
                                ascii_letters + digits + punctuation}
                    alphabet.update({
                        **data.ROMANIZATION_DICT[locale],
                        **data.COMMON_LETTERS,
                    })
                except KeyError:
                    raise UnsupportedLocale(locale)

                result = func(*args, **kwargs)

# Generated at 2022-06-25 20:10:41.901779
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Съешь ещё этих мягких французских булок да выпей чаю')() == 'S'\
                                                                                             'esh'\
                                                                                             ' eshch'\
                                                                                             'o etikh'\
                                                                                             ' miagk'\
                                                                                             'ikh frant'\
                                                                                             'suskikh bulok da vype'\
                                                                                             'i chayu'

# Generated at 2022-06-25 20:11:06.983366
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert callable_0
    assert romanize(locale='ru')
    assert romanize(locale='uk')
    assert romanize(locale='kk')

# Generated at 2022-06-25 20:11:10.874139
# Unit test for function romanize
def test_romanize():
    try:
        romanize()
    except Exception as e:
        if isinstance(e, UnsupportedLocale) or isinstance(e, TypeError):
            assert False

if __name__ == "__main__":
    test_case_0()
    test_romanize()

# Generated at 2022-06-25 20:11:21.756990
# Unit test for function romanize
def test_romanize():
    assert romanize()('АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ') == 'ABVGDEEJZIJKLMNOPRSTUFHC4W4b4E4Ja'
    assert romanize()('абвгдеёжзийклмнопрстуфхцчшщъыьэюя') == 'abvgdeejzijklmnoprstufhc4w4b4e4ja'

# Generated at 2022-06-25 20:11:24.524881
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize()

# Coverage test for function romanize

# Generated at 2022-06-25 20:11:33.783331
# Unit test for function romanize
def test_romanize():
    alphabet = {s: s for s in ascii_letters + digits + punctuation}

# Generated at 2022-06-25 20:11:39.293963
# Unit test for function romanize
def test_romanize():
    # If a string is provided, it must be in a valid format
    assert romanize('ru')('Сны хрустят, а небо плачет.') == 'Sny khrustjat, a nebo plache.'


# Generated at 2022-06-25 20:11:40.969229
# Unit test for function romanize
def test_romanize():
    # Avoid calling of romanize if locale = vi
    assert romanize()
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')

# Generated at 2022-06-25 20:11:51.888104
# Unit test for function romanize
def test_romanize():
    # Tests for function romanize
    assert romanize()('', False, False) == ''
    assert romanize()('', True, False) == ''
    assert romanize()('', False, True) == ''
    assert romanize()('', True, True) == ''
    assert romanize()('', False, False, False) == ''
    assert romanize()('', True, False, False) == ''
    assert romanize()('', False, True, False) == ''
    assert romanize()('', True, True, False) == ''
    assert romanize()('', False, False, True) == ''
    assert romanize()('', True, False, True) == ''
    assert romanize()('', False, True, True) == ''

# Generated at 2022-06-25 20:12:02.574924
# Unit test for function romanize
def test_romanize():
    # Unit test for function romanize with arguments
    assert romanize(locale='') == romanize_deco()

    # Unit test for function romanize with arguments
    assert romanized(locale='') == romanize_deco(func=None)

    # Unit test for function romanize with arguments
    assert romanized(locale='ru') == romanize_deco(func=None)

    # Unit test for function romanized with arguments
    assert romanized(locale='uk') == romanize_deco(func=None)

    # Unit test for function romanized with arguments
    assert romanized(locale='kk') == romanize_deco(func=None)

# Generated at 2022-06-25 20:12:11.038286
# Unit test for function romanize
def test_romanize():
    dictionary = {
        'fruits': {
            'ru': 'яблоко',
            'uk': 'яблуко',
            'kk': 'айрық'
        }
    }
    for k, v in dictionary.items():
        for locale, txt in v.items():
            result = romanize(locale)(lambda: txt)()
            assert len(result) == len(txt)

# Generated at 2022-06-25 20:13:02.546415
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:13:03.533906
# Unit test for function romanize
def test_romanize():
    assert romanize == callable_0

# Generated at 2022-06-25 20:13:04.335735
# Unit test for function romanize
def test_romanize():
    assert romanize() != None


# Generated at 2022-06-25 20:13:06.776906
# Unit test for function romanize
def test_romanize():
    callable_0 = romanized()



# Generated at 2022-06-25 20:13:13.806968
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.enums import Gender

    p = Person('en')
    a = Address('ru')

    assert p.full_name(Gender.FEMALE) == 'Lydia Gibson'
    assert a.region_province() == 'Горно-Алтайский край'

# Generated at 2022-06-25 20:13:14.860871
# Unit test for function romanize
def test_romanize():
    assert romanize() == romanize


# Generated at 2022-06-25 20:13:18.077018
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Language
    from mimesis.builtins import Person

    e = Person(Language.RU)
    # print(e._romanize('Сидоров Андрей Анатольевич'))
    assert e._romanize('Сидоров Андрей Анатольевич') == 'Sidorov Andrey Anatolyevich'

# Generated at 2022-06-25 20:13:19.818747
# Unit test for function romanize
def test_romanize():
    assert test_case_0() == None

romanized()

# Generated at 2022-06-25 20:13:21.029269
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:13:22.871620
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'тест')() == 'test'

# Generated at 2022-06-25 20:15:35.040048
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()



# Generated at 2022-06-25 20:15:50.123724
# Unit test for function romanize
def test_romanize():
    import sys
    import os
    import inspect
    import mimesis

    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(
        inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)

    data_path = os.path.join(parentdir, 'test', 'data', 'test_romanize.txt')
    with open(data_path) as f:
        test_data = f.read().splitlines()

    pt = mimesis.Person("ru")
    for d in test_data:
        tr_d = pt.romanize(d)

# Generated at 2022-06-25 20:15:50.711221
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:15:55.584890
# Unit test for function romanize
def test_romanize():
    from mimesis import locales
    from mimesis.enums import Gender
    from mimesis.exc import UnsupportedLocale
    from mimesis.builtins import RussianSpecProvider

    locale = locales.RU
    r = RussianSpecProvider(locale)
    assert isinstance(r, RussianSpecProvider)
    assert r.locale == locale
    assert r.code == 'ru'
    assert r.data_provider.name == 'RussianSpecProvider'
    assert r.get_full_name(gender=Gender.MALE) == 'Дмитрий Александрович Киселёв'

# Generated at 2022-06-25 20:15:57.262585
# Unit test for function romanize
def test_romanize():
    result = romanized()(func=lambda: 'можно')
    assert result == 'mozhn0'

# Generated at 2022-06-25 20:15:58.214906
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()


# Generated at 2022-06-25 20:15:59.098532
# Unit test for function romanize
def test_romanize():
    with pytest.raises(Exception):
        romanize()

# Generated at 2022-06-25 20:16:06.936307
# Unit test for function romanize
def test_romanize():
    result = romanize()(lambda *args, **kwargs: 'юзер')
    assert result == 'yuzyer', 'Expected \'yuzyer\''
    result = romanize('uk')(lambda *args, **kwargs: 'юзер')
    assert result == 'yuzyer', 'Expected \'yuzyer\''
    result = romanize(locale='uk')(lambda *args, **kwargs: 'юзер')
    assert result == 'yuzyer', 'Expected \'yuzyer\''
    result = romanize(locale='ru')(lambda *args, **kwargs: 'юзер')
    assert result == 'yuzyer', 'Expected \'yuzyer\''

# Generated at 2022-06-25 20:16:07.418863
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:16:10.223182
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
