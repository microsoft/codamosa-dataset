

# Generated at 2022-06-25 20:07:56.011811
# Unit test for function romanize
def test_romanize():
    assert callable_0() == ''

# Generated at 2022-06-25 20:07:57.926945
# Unit test for function romanize
def test_romanize():
    assert romanize is romanized
    assert romanize('ru')



# Generated at 2022-06-25 20:07:58.727273
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:07:59.831423
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize('ru')
    assert callable_0


# Generated at 2022-06-25 20:08:02.766343
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    func_0 = callable_0(lambda : '')
    assert func_0() == ''
    assert callable_0.__name__ == 'wrapper'
    assert callable_0.__name__ == 'wrapper'
    assert callable_0.__name__ == 'wrapper'
    assert callable_0.__name__ == 'wrapper'
    assert callable_0.__name__ == 'wrapper'

# Generated at 2022-06-25 20:08:05.075940
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()


# Generated at 2022-06-25 20:08:06.385376
# Unit test for function romanize
def test_romanize():
    # Test with changeable value of the first argument
    assert callable_0() == ''



# Generated at 2022-06-25 20:08:07.871219
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)


# Generated at 2022-06-25 20:08:09.848471
# Unit test for function romanize
def test_romanize():
    func = romanize()
    assert callable(func)

# Generated at 2022-06-25 20:08:11.295366
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:08:17.748790
# Unit test for function romanize
def test_romanize():
    assert romanize


# Generated at 2022-06-25 20:08:19.133315
# Unit test for function romanize
def test_romanize():
    assert romanize() == 'function'

# Generated at 2022-06-25 20:08:23.504199
# Unit test for function romanize
def test_romanize():
    assert romanize is functools.partial(romanize, 'ru')
    assert romanize is not functools.partial(romanize, 'ru')
    assert not romanize is functools.partial(romanize, 'ru')
    assert romanize is romanize


# Generated at 2022-06-25 20:08:25.527247
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'text') == 'text'



# Generated at 2022-06-25 20:08:35.037705
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'privet'
    assert romanize()('Привет Мир!') == 'privet mir'
    assert romanize()('Привет Мир 123!') == 'privet mir 123'
    assert romanize('uk')('Привіт Світ!') == 'pryvit svit'
    assert romanize('kk')('Сәлем Әлем!') == 'salem allem'

# Generated at 2022-06-25 20:08:40.956812
# Unit test for function romanize
def test_romanize():
    from string import ascii_letters, digits, punctuation
    from mimesis.enums import SpecialChar
    from mimesis import Person

    p = Person()
    assert p.name(patronymic=True, middle_name=True, gender='female')
    assert p.surname(gender='female')
    assert p.patronymic(gender='female')

    assert p.username()
    assert p.password()
    assert p.short_url()
    assert p.url()
    assert p.ipv4()
    assert p.email()
    assert p.mac_address()

    assert p.full_name(gender='male', middle_name=True)
    assert p.full_name(gender='male')
    assert p.full_name(middle_name=True)
    assert p.full

# Generated at 2022-06-25 20:08:48.745144
# Unit test for function romanize
def test_romanize():
    assert 'Привет Мир' == romanize()(lambda: 'Привет Мир')
    assert 'Privet Mir' == romanize('ru')(lambda: 'Privet Mir')
    assert 'Pryvit Mir' == romanize('uk')(lambda: 'Pryvit Mir')
    assert 'Salemäñiz bersin' == romanize('kk')(lambda: 'Salemäñiz bersin')

# Generated at 2022-06-25 20:08:57.562885
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.providers.name import Name
    from mimesis.random import Random

    random_0 = Random(0)
    name_0 = Name(random_0)
    assert isinstance(name_0.romanize("Магдалена Арсланова", locale='ru'), str)
    assert name_0.romanize("Магдалена Арсланова", locale='ru') == 'Magdalaena Arslanova'
    assert name_0.romanize("Магдалена Арсланова", locale='ru') == 'Magdalaena Arslanova'

# Generated at 2022-06-25 20:09:00.283133
# Unit test for function romanize
def test_romanize():
    # Function to test
    result = romanize()
    assert callable(result)

# Generated at 2022-06-25 20:09:02.827905
# Unit test for function romanize
def test_romanize():
    def callable_0():
        return
    x = romanize(callable_0)
    assert x == None

# Generated at 2022-06-25 20:09:14.353852
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_0('function_0')

# Generated at 2022-06-25 20:09:19.000649
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')
    assert not romanize('en')


# Generated at 2022-06-25 20:09:20.385436
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:09:21.473245
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:09:22.095720
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:09:22.789454
# Unit test for function romanize
def test_romanize():
    assert callable_0() is None


# Generated at 2022-06-25 20:09:24.273785
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:09:31.131629
# Unit test for function romanize
def test_romanize():
    # Test for function romanize
    callable_0 = romanize()
    # Assert isinstance(callable_0(), str)
    try:
        callable_0 = romanize('ru')
        # Assert isinstance(callable_0(), str)
        try:
            callable_0 = romanize('uk')
            # Assert isinstance(callable_0(), str)
            try:
                callable_0 = romanize('kk')
                # Assert isinstance(callable_0(), str)
            except Exception as exc:
                print(exc)
        except Exception as exc:
            print(exc)
    except Exception as exc:
        print(exc)
        

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-25 20:09:32.967364
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0() == str

# Generated at 2022-06-25 20:09:35.028359
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func_0():
        return

    assert func_0.__name__ == 'func_0'
    assert func_0.__doc__ == 'Romanize the cyrillic text.'


# Generated at 2022-06-25 20:10:00.727170
# Unit test for function romanize
def test_romanize():
    text = "Какое-то текст."
    assert romanize()(lambda: text) == "Kakoe-to tekst."

# Generated at 2022-06-25 20:10:04.159104
# Unit test for function romanize
def test_romanize():
    locale = "en"
    t = romanize(locale)
    assert t != None
    assert callable(t)


# Generated at 2022-06-25 20:10:09.677239
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Gender
    from mimesis.schema import Field, Schema
    from mimesis.types import Code, DateTime, Text
    from mimesis.providers.person import Person

    person = Person('ru')
    text = Text('ru')

    @Schema
    class PersonInfo:
        first_name = Field(
            lambda: person.full_name(gender=Gender.FEMALE),
            romanize='kk',
        )
        last_name = Field(lambda: person.full_name(gender=Gender.MALE))
        date = Field(lambda: DateTime('ru').date(start=2000, end=2010))
        code = Field(lambda: Code('ru').pin())
        text = Field(lambda: text.text())

    pi = PersonInfo()
    assert pi

# Generated at 2022-06-25 20:10:15.648410
# Unit test for function romanize
def test_romanize():
    try:
        callable_0 = romanize()
        func = functools.partial(callable_0, '')
        result = func.func(*func.args, **func.keywords)
    except KeyError:
        raise UnsupportedLocale(locale)

# Generated at 2022-06-25 20:10:17.607920
# Unit test for function romanize
def test_romanize():
    assert True


test_case_0()

test_romanize()

# Generated at 2022-06-25 20:10:18.328417
# Unit test for function romanize
def test_romanize():
    assert romanize() != None


# Generated at 2022-06-25 20:10:25.563919
# Unit test for function romanize
def test_romanize():
    def test_f(a):
        return a.upper()

    assert test_f('a') == 'A'
    assert test_f('b') == 'B'

    assert romanize()(test_f)('a') == 'A'
    assert romanize()(test_f)('b') == 'B'

# Generated at 2022-06-25 20:10:29.196190
# Unit test for function romanize
def test_romanize():
    assert callable_0('москва') == 'moskva'
    assert callable_0('брест') == 'brest'
    assert callable_0('варшава') == 'varshava'

# Generated at 2022-06-25 20:10:30.037661
# Unit test for function romanize
def test_romanize():
  pass

# Generated at 2022-06-25 20:10:32.321328
# Unit test for function romanize
def test_romanize():
    r = romanize()
    assert r is not None

# Generated at 2022-06-25 20:11:17.735366
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Localization
    localization = Localization()
    ru_version = localization.localize(locale='ru')

    assert ru_version.phone_number() == callable_0(ru_version.phone_number)

# Generated at 2022-06-25 20:11:24.028801
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')(lambda: 'Это Тестовая Строка')() == 'Это Тестовая Строка'
    assert romanized('uk')(lambda: 'Ето Тестова Рядок')() == 'Ето Тестова Рядок'
    assert romanized('kk')(lambda: 'Бұл Тест Жолы')() == 'Бұл Тест Жолы'

# Generated at 2022-06-25 20:11:31.276852
# Unit test for function romanize
def test_romanize():

    callable_0 = romanize()
    func_0 = lambda : 'Данная функция заблокирована администратором'

    assert callable_0(func_0)() == 'Dannaya funktsiya zablokirovana adminom'



# Generated at 2022-06-25 20:11:32.618286
# Unit test for function romanize
def test_romanize():
    assert True


# Generated at 2022-06-25 20:11:34.418967
# Unit test for function romanize
def test_romanize():
    pass
    # assert romanize('test') == 'test'

# Generated at 2022-06-25 20:11:35.714574
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())



# Generated at 2022-06-25 20:11:43.870854
# Unit test for function romanize
def test_romanize():
    assert 'иди нахуй!' == romanize('ru')('иди нахуй!')
    assert 'mama!' == romanize('ru')('мама!')
    assert 'mama' == romanize('ru')('мама')

    assert 'sos' == romanize('ru')('сос')
    assert 'sos' == romanize('uk')('сос')
    assert 'sos' == romanize('kk')('сос')

    assert 'авто' == romanize('ru')('авто')
    assert 'авто' == romanize('uk')('авто')
    assert 'авто' == romanize

# Generated at 2022-06-25 20:11:45.140761
# Unit test for function romanize
def test_romanize():
    assert romanize is not None


# Generated at 2022-06-25 20:11:50.193047
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Привет') == 'Privet'
    assert romanize('uk')('Привіт') == 'Pryvit'
    assert romanize('kk')('Сәлем') == 'Sälem'

# Generated at 2022-06-25 20:11:51.037691
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:13:40.725465
# Unit test for function romanize
def test_romanize():
    assert romanize == romanized

# Generated at 2022-06-25 20:13:41.469758
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

# Generated at 2022-06-25 20:13:48.357066
# Unit test for function romanize
def test_romanize():
    def romanize_0(locale: str = '') -> Callable:
        def romanize_deco(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                try:
                    # Cyrillic string can contain ascii
                    # symbols, digits and punctuation.
                    alphabet = {s: s for s in
                                ascii_letters + digits + punctuation}
                    alphabet.update({
                        **data.ROMANIZATION_DICT[locale],
                        **data.COMMON_LETTERS,
                    })
                except KeyError:
                    raise UnsupportedLocale(locale)

                result = func(*args, **kwargs)
                txt = ''.join([alphabet[i] for i in result if i in alphabet])
                return txt

# Generated at 2022-06-25 20:13:49.521419
# Unit test for function romanize
def test_romanize():
    arg_0 = ''
    ret_0 = romanize(arg_0)
    # assert ret_0 == expected


# Generated at 2022-06-25 20:13:50.580303
# Unit test for function romanize
def test_romanize():
    # This is a sample test case.
    assert callable_0 != None



# Generated at 2022-06-25 20:13:52.061563
# Unit test for function romanize
def test_romanize():

    @romanize()
    def callable_1(arg_0):
        return arg_0

    assert callable_1('foo') == 'foo'


# Generated at 2022-06-25 20:13:55.033061
# Unit test for function romanize
def test_romanize():
    text = 'Привет'
    to_roman = romanize(locale='ru')
    result = to_roman(text)
    assert result == 'Privyet' or result == 'Privet'

# Generated at 2022-06-25 20:13:57.080306
# Unit test for function romanize
def test_romanize():
    # Callable object 'callable_0'
    assert callable(callable_0), 'Should be callable.'
    # Invocation of 'callable_0'
    assert callable_0(), "Romanization function failed."

# Generated at 2022-06-25 20:14:02.947761
# Unit test for function romanize
def test_romanize():
    func = romanize()
    @func
    def test_function0(param):
        return param

    @func
    def test_function1():
        return ""

    assert test_function0("a") == "a"
    assert test_function1() == ""

    func = romanize("ru")
    @func
    def test_function2(param):
        return param

    assert test_function2("Привет!") == "Privet!"

# Generated at 2022-06-25 20:14:04.062579
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod(verbose=True)