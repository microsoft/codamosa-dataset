

# Generated at 2022-06-25 20:08:05.973967
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('hello world') == 'hello world'
    assert romanize('ru')('Я не понимаю почему так произошло') == \
        'YA ne ponimayu pochemu tak proizoshlo'
    assert romanize('ru')('При встрече с представителем компании') == \
        'Pri vstreche s predstavitelem kompanii'

# Generated at 2022-06-25 20:08:07.435581
# Unit test for function romanize
def test_romanize():
    assert romanize() # check for syntax error

# Generated at 2022-06-25 20:08:08.251290
# Unit test for function romanize
def test_romanize():
    func = romanize()
    _ = func()


# Generated at 2022-06-25 20:08:10.440426
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize('ru')
    assert callable_0 is not None


# Generated at 2022-06-25 20:08:12.714547
# Unit test for function romanize
def test_romanize():
    callable_one = romanize('ru')(lambda: 'Строка')
    assert callable_one() == 'Stroka'

# Generated at 2022-06-25 20:08:13.710707
# Unit test for function romanize
def test_romanize():
    @romanize()
    def test_romanize():
        pass

# Generated at 2022-06-25 20:08:24.679609
# Unit test for function romanize

# Generated at 2022-06-25 20:08:26.085615
# Unit test for function romanize
def test_romanize():
    assert True == callable_0()

# Generated at 2022-06-25 20:08:27.432734
# Unit test for function romanize
def test_romanize():
    assert romanize()() == 'romanize'

# Generated at 2022-06-25 20:08:30.271170
# Unit test for function romanize
def test_romanize():
    with pytest.raises(UnsupportedLocale):
        data.Romanization('bogus')



# Generated at 2022-06-25 20:08:45.227307
# Unit test for function romanize
def test_romanize():
    romanize_0 = romanize('ru')
    assert romanize_0
    assert callable(romanize_0)
    romanize_0 = romanize('uk')
    assert romanize_0
    assert callable(romanize_0)
    romanize_0 = romanize('en')
    assert romanize_0
    assert callable(romanize_0)
    romanize_0 = romanize()
    assert romanize_0
    assert callable(romanize_0)
    romanize_0 = romanize('kz')
    assert romanize_0
    assert callable(romanize_0)

# Generated at 2022-06-25 20:08:54.054420
# Unit test for function romanize
def test_romanize():
    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({**data.ROMANIZATION_DICT['ru'], **data.COMMON_LETTERS})

    def func(value):
        return value

    decorated = romanize()(func)
    assert decorated('Сознание прекрасное дарование,') == 'soznaniye prekrasnoye darovaniye,'


# Generated at 2022-06-25 20:08:55.608786
# Unit test for function romanize
def test_romanize():
    assert callable(romanize()) is True

# Generated at 2022-06-25 20:09:03.663389
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize('uk')('Привіт') == 'Privit'
    assert romanize('kk')('Сәлем') == 'Salem'
    assert romanize('kk')('Сәлем!') == 'Salem!'

# Generated at 2022-06-25 20:09:05.858534
# Unit test for function romanize
def test_romanize():
    # Simple test for function romanize
    assert romanize()



# Generated at 2022-06-25 20:09:06.933988
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:09:17.357519
# Unit test for function romanize
def test_romanize():
    alphabet_ru = {s: s for s in ascii_letters + digits + punctuation}
    alphabet_ru.update({**data.ROMANIZATION_DICT['ru'], **data.COMMON_LETTERS})

    alphabet_uk = {s: s for s in ascii_letters + digits + punctuation}
    alphabet_uk.update({**data.ROMANIZATION_DICT['uk'], **data.COMMON_LETTERS})

    alphabet_kk = {s: s for s in ascii_letters + digits + punctuation}
    alphabet_kk.update({**data.ROMANIZATION_DICT['kk'], **data.COMMON_LETTERS})


# Generated at 2022-06-25 20:09:18.778826
# Unit test for function romanize
def test_romanize():
    assert callable_0


# Generated at 2022-06-25 20:09:24.587113
# Unit test for function romanize
def test_romanize():
    # expected = 'Privet Mir!'
    assert romanize()('Привет Мир!') == 'Privet Mir!'
    assert romanize()('Прывітанне Свет!') == 'Pryvitannye Svet!'

    # expected = 'Privet Mir!'
    assert romanize()('Привет Мир!') == 'Privet Mir!'
    assert romanize()('Прывітанне Свет!') == 'Pryvitannye Svet!'

    # expected = 'Pryvitannya, svit!'
    assert romanize()('Привет, мир!') == 'Privet, mir!'

# Generated at 2022-06-25 20:09:29.388615
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    def func(arg_0):
        return arg_0
    assert callable_0(func)('str') == 'str'



# Generated at 2022-06-25 20:09:46.568644
# Unit test for function romanize
def test_romanize():
    # Test 0
    #
    # Test case with default parameters and default values in function.
    #
    # Test function call with default parameters.
    #
    # 1. Call function callable_0 and check result
    callable_0 = romanize()

    # 2. Call function callable_0 and check result
    assert callable_0() == ''

    # Test 1
    #
    # Test case with default parameters and user-defined values in function.
    #
    # Test function call with default parameters.
    #
    # 1. Call function callable_0 and check result
    callable_0 = romanize()

    # 2. Change parameters of function callable_0 and call it with new parameters
    # 3. Check result of function callable_0
    assert callable_0('a') == 'a'

   

# Generated at 2022-06-25 20:09:55.771858
# Unit test for function romanize
def test_romanize():
    import builtins
    # Replace the builtin "open"
    old_open = builtins.open
    def open_no_file(*args, **kwargs):
        raise FileNotFoundError()
    builtins.open = open_no_file
    # Test
    import mimesis
    romanize_0 = romanize('ru')
    @romanize_0
    def func_0():
        pass
    # Restore the builtin "open"
    builtins.open = old_open
    # Call the function
    result = func_0()

# Generated at 2022-06-25 20:09:59.507533
# Unit test for function romanize
def test_romanize():
    def func():
        pass
    t = romanize()(func)
    assert t() == func()




# Generated at 2022-06-25 20:10:02.005068
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0 is not None


# Generated at 2022-06-25 20:10:11.991323
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanize()

    # Locale doesn't contain full path to module.
    with pytest.raises(Exception) as e_info:
        callable_1.name = 'ru'
    assert e_info.type is AttributeError
    # Locale is not supported.
    with pytest.raises(Exception) as e_info:
        callable_0.name = 'pt'
    assert e_info.type is TypeError

    assert callable_0('Привет, мир!') == 'Privet, mir!'
    assert callable_1.name == 'ru'
    assert callable_1.first_name() == 'Vitaliy'

# Generated at 2022-06-25 20:10:15.215399
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanized()


# Generated at 2022-06-25 20:10:17.681812
# Unit test for function romanize
def test_romanize():
    assert callable_0(callable_0('test_string')) == callable_0('test_string')

# Generated at 2022-06-25 20:10:19.544402
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-25 20:10:20.554493
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:10:20.973774
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:10:48.805119
# Unit test for function romanize
def test_romanize():

    # Arrange
    @romanize('ru')
    def rus():
        return 'привет как дела?'

    @romanize('uk')
    def ukr():
        return 'привіт як справи?'

    @romanize('kk')
    def kaz():
        return 'сәлем көкше?'

    # Act
    result_0 = rus()
    result_1 = ukr()
    result_2 = kaz()

    # Assert
    assert result_0 == 'privet kak dela?'
    assert result_1 == 'pryvit iak spravy?'
    assert result_2 == 'salem kokshye?'

# Generated at 2022-06-25 20:11:01.016558
# Unit test for function romanize
def test_romanize():
    romanize_0 = romanize()
    romanize_1 = romanize()
    romanize_2 = romanize()
    romanize_3 = romanize()
    romanize_4 = romanize()
    romanize_5 = romanize()
    romanize_6 = romanize()
    romanize_7 = romanize()
    romanize_8 = romanize()
    romanize_9 = romanize()
    romanize_10 = romanize()
    romanize_11 = romanize()
    romanize_12 = romanize()
    romanize_13 = romanize()
    romanize_14 = romanize()
    romanize_15 = romanize()

# Generated at 2022-06-25 20:11:03.897622
# Unit test for function romanize
def test_romanize():
    assert romanize.__name__ == 'romanize'



# Generated at 2022-06-25 20:11:05.352679
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:11:08.243990
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins
    assert mimesis.builtins.Person().full_name() != ''


# Generated at 2022-06-25 20:11:09.765845
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()



# Generated at 2022-06-25 20:11:13.476915
# Unit test for function romanize
def test_romanize():
    assert callable_0 is not None
    assert callable(callable_0) is True


# Generated at 2022-06-25 20:11:22.098021
# Unit test for function romanize
def test_romanize():
    def romanize_deco(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                # Cyrillic string can contain ascii
                # symbols, digits and punctuation.
                alphabet = {s: s for s in
                            ascii_letters + digits + punctuation}
                alphabet.update({
                    **data.ROMANIZATION_DICT['ru'],
                    **data.COMMON_LETTERS,
                })
            except KeyError:
                raise UnsupportedLocale('ru')

            result = func(*args, **kwargs)
            txt = ''.join([alphabet[i] for i in result if i in alphabet])
            return txt

        return wrapper


# Generated at 2022-06-25 20:11:23.105607
# Unit test for function romanize
def test_romanize():
    assert callable_0

# Generated at 2022-06-25 20:11:27.506596
# Unit test for function romanize
def test_romanize():
    data.COMMON_LETTERS
    data.ROMANIZATION_DICT['uk']
    data.ROMANIZATION_DICT['kk']
    data.ROMANIZATION_DICT['ru']

# Generated at 2022-06-25 20:12:34.227365
# Unit test for function romanize
def test_romanize():
    items = []
    for i in range(10):
        items.append(str(i))

    for i in range(65, 91):
        items.append(chr(i))

    for i in range(97, 123):
        items.append(chr(i))

    for i in range(1040, 1104):
        items.append(chr(i))

    for i in range(123, 127):
        items.append(chr(i))

    answers = []

    for i in range(10):
        answers.append(str(i))

    for i in range(65, 91):
        answers.append(chr(i))

    for i in range(97, 123):
        answers.append(chr(i))


# Generated at 2022-06-25 20:12:46.495741
# Unit test for function romanize
def test_romanize():
    locale = 'ru'

# Generated at 2022-06-25 20:12:46.982856
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:12:50.884350
# Unit test for function romanize
def test_romanize():
    assert (type(romanize()) == functools.partial)
    assert (type(romanize('ru')) == functools.partial)


# Generated at 2022-06-25 20:13:01.673110
# Unit test for function romanize

# Generated at 2022-06-25 20:13:02.993599
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

# Generated at 2022-06-25 20:13:05.954931
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='')
    assert romanize(locale='ru')
    assert romanize(locale='uk')
    assert romanize(locale='kk')



# Generated at 2022-06-25 20:13:08.046010
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:13:13.244472
# Unit test for function romanize
def test_romanize():
    import random
    string = ''
    for i in range(random.randint(6, 100)):
        string += chr(random.randint(0, 128))
    answer = ''.join([data.COMMON_LETTERS[i] if i in data.COMMON_LETTERS else i for i in string])

    assert answer == romanize()(string)


# Generated at 2022-06-25 20:13:17.993337
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None
    assert callable(romanize(locale='')) is True
    assert isinstance(romanize(), Callable) is True
    assert romanize(locale='')() != None
    assert romanize(locale='')() is not None
    # mimesis.data.ROMANIZATION_DICT
    assert romanized(locale='ru') is not None
    assert romanized(locale='kk') is not None
    assert romanized(locale='uk') is not None



# Generated at 2022-06-25 20:15:35.639388
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')
    assert romanize(locale='uk')
    assert romanize(locale='kk')
    assert romanize(locale='ro')

# Generated at 2022-06-25 20:15:36.640477
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)

# Generated at 2022-06-25 20:15:50.120963
# Unit test for function romanize
def test_romanize():
    _result = romanize()
    assert _result(locale="")



# Generated at 2022-06-25 20:15:50.930237
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_0()



# Generated at 2022-06-25 20:15:51.651480
# Unit test for function romanize
def test_romanize():
    assert romanize()



# Generated at 2022-06-25 20:15:53.559570
# Unit test for function romanize
def test_romanize():
    # Unit test for function romanize
    from mimesis import Person
    from mimesis.enums import Gender

    p = Person('ru')
    p.full_name(gender=Gender.FEMALE)

# Generated at 2022-06-25 20:15:58.764871
# Unit test for function romanize
def test_romanize():
    # 1. Assert that function is callable
    # 2. Assert that function is callable
    # 3. Assert that function is callable
    # 4. Assert that function is callable
    # 5. Assert that function is callable
    # 6. Assert that function is callable
    # 7. Assert that function is callable
    # 8. Assert that function is callable
    # 9. Assert that function is callable
    assert callable(romanize())


# Generated at 2022-06-25 20:16:06.635101
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanize()
    callable_2 = romanize()
    callable_3 = romanize()
    callable_4 = romanize()
    callable_5 = romanize()
    callable_6 = romanize()
    callable_7 = romanize()
    callable_8 = romanize()
    callable_9 = romanize()
    callable_10 = romanize()
    callable_11 = romanize()
    callable_12 = romanize()
    callable_13 = romanize()
    callable_14 = romanize()
    callable_15 = romanize()
    callable_16 = romanize()
    callable_17 = romanize()
   

# Generated at 2022-06-25 20:16:07.277063
# Unit test for function romanize
def test_romanize():
    assert romanize


# Generated at 2022-06-25 20:16:09.884682
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize()