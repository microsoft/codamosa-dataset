

# Generated at 2022-06-25 20:08:03.173957
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    from mimesis.enums import Language
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.code import Code
    from mimesis.utils import slugify
    from mimesis.builtins import RussianSpecProvider

    locale = "ru"
    romanized_func = romanize(locale=locale)
    russian = RussianSpecProvider(locale=locale)
    russian.set_language(Language.RU)
    r_f = romanized_func(russian.get_full_name)
    f_n = russian.get_full_name()
    assert r_f == slugify(f_n)

# Generated at 2022-06-25 20:08:05.755734
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()


# Generated at 2022-06-25 20:08:13.510793
# Unit test for function romanize
def test_romanize():

    def romanize_01():
        from mimesis.builtins.languages import romanize

        romanized_str = romanize('ru')
        assert romanized_str('текст') == 'tekst'

    def romanize_02():
        from mimesis.builtins.languages import romanize

        romanized_str = romanize('ru')
        assert romanized_str('текст') == 'tekst'



# Generated at 2022-06-25 20:08:14.394548
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:08:16.007243
# Unit test for function romanize
def test_romanize():
    result = romanize()
    print()

# Generated at 2022-06-25 20:08:18.993278
# Unit test for function romanize
def test_romanize():
    assert romanize()(('Привет, друг!')) == 'Privyet, drug!'

# Generated at 2022-06-25 20:08:21.079193
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    value_0 = callable_0(lambda: 'foo')
    assert value_0 == 'foo'


# Generated at 2022-06-25 20:08:21.677538
# Unit test for function romanize
def test_romanize():
    assert 1 == 1

# Generated at 2022-06-25 20:08:23.149581
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None
    assert (romanized() is not None)


# Generated at 2022-06-25 20:08:25.453691
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda x: x) is not None

# Generated at 2022-06-25 20:08:31.175208
# Unit test for function romanize
def test_romanize():
    test_case_0()

# Generated at 2022-06-25 20:08:32.552419
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-25 20:08:36.172815
# Unit test for function romanize
def test_romanize():
    pass

    # Test case for function Romanize, using custom var callable_0

    callable_0 = romanize()  # TODO: Maybe some params?
    # Test case for function Romanize, using custom var callable_1

    callable_1 = romanize()  # TODO: Maybe some params?



# Generated at 2022-06-25 20:08:37.543445
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())

# Generated at 2022-06-25 20:08:43.953162
# Unit test for function romanize
def test_romanize():
    assert 'hello' == romanize()('hello')
    assert 'hello' == romanize('ru')('hello')
    assert 'привет' == romanize()('привет')
    assert 'привет' == romanize('ru')('привет')



# Generated at 2022-06-25 20:08:52.848606
# Unit test for function romanize
def test_romanize():

    @romanize()
    def func(a, b):
        return "Кекс"

    assertequals("Keks", func("c", "a"))

    try:
        @romanize("ua")
        def func():
            return "Кекс"
        raise AssertionError("Should not reach this point")
    except UnsupportedLocale:
        pass



# Generated at 2022-06-25 20:09:00.925802
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize(locale='ru')
    callable_1 = callable_0(func=lambda: 'мимимимимими')
    assert callable_1 == 'mimimimimimim'


if __name__ == '__main__':
    test_case_0()
    test_romanize()

# Generated at 2022-06-25 20:09:09.058496
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Сидоров Пётр Петрович') == 'Sidorov Pëtr Petrovich'
    assert romanize('uk')('Сідоров Петро Петрович') == 'Sidorov Petro Petrovych'
    assert romanize('kk')('Сидоров Петр Петрович') == 'Sïdorov Petr Petrovïch'


# Generated at 2022-06-25 20:09:13.979050
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: "") == ''
    assert romanize('uk')(lambda: "H") == 'H'
    assert romanize('kk')(lambda: "") == ''



# Generated at 2022-06-25 20:09:15.593191
# Unit test for function romanize
def test_romanize():
    assert True

# Generated at 2022-06-25 20:09:36.450476
# Unit test for function romanize
def test_romanize():

    @romanize
    def gen_romanize():
        return 'Привет'

    assert gen_romanize() == 'Privet'
    assert gen_romanize() == 'Privet'
    assert gen_romanize() == 'Privet'
    assert gen_romanize() == 'Privet'
    assert gen_romanize() == 'Privet'
    assert gen_romanize() == 'Privet'
    assert gen_romanize() == 'Privet'
    assert gen_romanize() == 'Privet'
    assert gen_romanize() == 'Privet'
    assert gen_romanize() == 'Privet'



# Generated at 2022-06-25 20:09:39.003038
# Unit test for function romanize
def test_romanize():

    callable_0 = romanize()
    assert callable_0 is not None



# Generated at 2022-06-25 20:09:40.686407
# Unit test for function romanize
def test_romanize():
    # Assert isinstance(romanize, Callable)
    assert isinstance(romanize, Callable)
    # Assert isinstance(romanize('ru'), Callable)
    assert isinstance(romanize('ru'), Callable)



# Generated at 2022-06-25 20:09:41.417013
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())

# Generated at 2022-06-25 20:09:42.665743
# Unit test for function romanize
def test_romanize():
    assert romanize()

    if romanize() is not None:
        assert True
    else:
        assert False


# Generated at 2022-06-25 20:09:43.478451
# Unit test for function romanize
def test_romanize():
	assert romanize()

# Generated at 2022-06-25 20:09:45.746639
# Unit test for function romanize
def test_romanize():
    # Assert isinstance(romanize(), Callable)
    assert_true(isinstance(romanize(), Callable))

# Generated at 2022-06-25 20:09:48.412848
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()



# Generated at 2022-06-25 20:09:50.293308
# Unit test for function romanize
def test_romanize():
    assert callable_0('Good afternoon, Caitlyn!') == 'Good afternoon, Caitlyn!'

# Generated at 2022-06-25 20:09:51.634339
# Unit test for function romanize
def test_romanize():
    assert True == True



# Generated at 2022-06-25 20:10:20.904530
# Unit test for function romanize
def test_romanize():
    assert callable_0('решение') == 'reshenie'
    assert callable_0('привет') == 'priviet'
    assert callable_0('привет, как дела') == 'priviet, kak dela'
    assert callable_0('привет, как дела, Катя?') == 'priviet, kak dela, Katia?'
    assert callable_0('Роботы наследуют АЗБУКУ') == 'Roboty nasleduiut ABZUKU'

# Generated at 2022-06-25 20:10:25.223784
# Unit test for function romanize
def test_romanize():
    test0 = romanize()

    assert callable(test0) is True

# SYS OUT
if __name__ == '__main__':
    test_case_0()
    test_romanize()

# Generated at 2022-06-25 20:10:30.302019
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('привет') == 'privet'
    assert romanize('uk')('привіт') == 'privit'
    assert romanize('kk')('Сәлем') == 'Salem'
    assert romanize('kk')('Сәлем') != 'Salemор'


# Generated at 2022-06-25 20:10:33.198446
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0

# Generated at 2022-06-25 20:10:35.776445
# Unit test for function romanize
def test_romanize():
    # Test romanize
    assert callable_0
    assert callable_0
    assert callable_0

# Generated at 2022-06-25 20:10:43.590566
# Unit test for function romanize
def test_romanize():
    """Tests of the function romanize()"""
    # Positive tests
    assert romanize()(lambda: 'Привет, как дела?') == 'Privet, kak dela?'
    assert romanize()(lambda: 'Привіт, як справи?') == 'Pryvit, yak spravy?'
    # Negative tests
    # Negative test for an unsupported locale
    try:
        romanize(locale='us')(lambda: 'Hello')
    except UnsupportedLocale:
        assert True

# Generated at 2022-06-25 20:10:46.188812
# Unit test for function romanize
def test_romanize():
    txt = 'тест'
    assert romanize('ru')(txt) == 'test'

# Generated at 2022-06-25 20:10:50.564259
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0.__name__ == 'romanize_deco'
    assert callable_0.__doc__ == 'Romanize the cyrillic text.\n\n    Transliterate the cyrillic script into the latin alphabet.\n\n    .. note:: At this moment it works only for `ru`, `uk`, `kk`.\n\n    :param locale: Locale code.\n    :return: Romanized text.\n    '


# Generated at 2022-06-25 20:10:54.715212
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Привет, Мир')() == 'Privet, Mir'

# Generated at 2022-06-25 20:10:56.847664
# Unit test for function romanize
def test_romanize():
    with pytest.raises(UnsupportedLocale):
        romanize()

# Generated at 2022-06-25 20:11:44.607057
# Unit test for function romanize
def test_romanize():
    assert callable_0('Hello') == 'Hello'

# Generated at 2022-06-25 20:11:48.722867
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def callable_0(text: str) -> str:
        return text
    assert callable_0('Привет') == 'Privet'

# Generated at 2022-06-25 20:11:49.800779
# Unit test for function romanize
def test_romanize():
    # stub
    pass



# Generated at 2022-06-25 20:11:55.031851
# Unit test for function romanize
def test_romanize():
    res = romanize("ru")(lambda: "а")
    res = romanize("uk")(lambda: "а")
    res = romanize("kk")(lambda: "а")

# Generated at 2022-06-25 20:12:02.171499
# Unit test for function romanize
def test_romanize():
    trans_dict = data.ROMANIZATION_DICT['ru']

    @romanize('ru')
    def _(*args):
        return 'какой-то текст'

    translit_text_ru = _()

    for i in 'какой-то текст':
        translit_char_ru = trans_dict[i]
        assert i in translit_text_ru
        assert translit_char_ru in translit_text_ru



# Generated at 2022-06-25 20:12:04.203809
# Unit test for function romanize
def test_romanize():
    assert callable_0(romanize, 'test')() == "test"

# Generated at 2022-06-25 20:12:13.252348
# Unit test for function romanize
def test_romanize():
    assert callable_0(lambda: 'hello')() == 'hello'

    assert callable_0(lambda: 'hello')() == 'hello'

    callable_1 = romanize(locale='ru')
    assert callable_1(lambda: 'привет мир!')() == 'privet mir!'

    callable_2 = romanize(locale='uk')
    assert callable_2(lambda: 'привіт світ!')() == 'privyt svit!'

    callable_3 = romanize(locale='kk')
    assert callable_3(lambda: 'сәлем әлем!')() == 'sälem älem!'

# Generated at 2022-06-25 20:12:19.745154
# Unit test for function romanize
def test_romanize():

    @romanize(locale='uk')
    def example_0(value):
        return value

    example_0('астана')
    example_0('Хабаровск')


# Generated at 2022-06-25 20:12:21.478385
# Unit test for function romanize
def test_romanize():
    pass



# Generated at 2022-06-25 20:12:22.286470
# Unit test for function romanize
def test_romanize():
    assert callable_0() is None


# Generated at 2022-06-25 20:14:15.461691
# Unit test for function romanize
def test_romanize():
    assert callable_0(str)



# Generated at 2022-06-25 20:14:33.990305
# Unit test for function romanize
def test_romanize():
    assert romanize()('ABC') == 'ABC'
    assert romanize()(5) == '5'
    assert romanize('ru')('Банкир') == 'Bankir'
    assert romanize('ru')('Банкир,') == 'Bankir,'
    assert romanize('ru')('Банкир!') == 'Bankir!'
    assert romanize('ru')('Банкир1') == 'Bankir1'
    assert romanize('uk')('РІЧИСЛЕННЯ') == 'VCHISLENNYA'

# Generated at 2022-06-25 20:14:34.613545
# Unit test for function romanize
def test_romanize():
    assert callable_0(lambda: None) is None

# Generated at 2022-06-25 20:14:36.409386
# Unit test for function romanize
def test_romanize():
    assert romanize() != None
    assert romanize() != None
    assert romanize() != None
    assert romanize() != None

# Generated at 2022-06-25 20:14:40.934672
# Unit test for function romanize
def test_romanize():
    # The function uses hard-coded data, which is not
    # covered by test cases
    import pytest

    with pytest.raises(UnsupportedLocale):
        romanize('ab')(lambda: 'a')
    import mimesis.enums
    mimesis.enums.LocaleCode.validate.__globals__['_valid_codes'].add('ab') # type: ignore
    romanize('ab')(lambda: 'a')

# Generated at 2022-06-25 20:14:41.820439
# Unit test for function romanize
def test_romanize():
    test_case_0()

# Generated at 2022-06-25 20:14:43.146271
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk') is not None

# Generated at 2022-06-25 20:14:43.868899
# Unit test for function romanize
def test_romanize():
    assert romanize


# Generated at 2022-06-25 20:14:44.375562
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:14:49.249839
# Unit test for function romanize
def test_romanize():
    data_r = data.ROMANIZATION_DICT['ru']
    data_u = data.ROMANIZATION_DICT['uk']

    assert romanize('ru')('Купить') == 'Kupit'
    assert romanize('uk')('Купить') == 'Kupyty'

    # Unit test for function romanize_deco
    def test(word):
        return word

    assert romanize('ru')(test)('Купить') == 'Kupit'
    assert romanize('uk')(test)('Купить') == 'Kupyty'