

# Generated at 2022-06-25 20:07:59.454291
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0.__name__ == "romanize"

# Generated at 2022-06-25 20:08:01.861629
# Unit test for function romanize
def test_romanize():
    assert callable(test_case_0)

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 20:08:06.222686
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func():
        return 'Всем привет'

    assert func() == 'Vsem privet'



# Generated at 2022-06-25 20:08:07.649592
# Unit test for function romanize
def test_romanize():
    assert romanize() == callable

# Generated at 2022-06-25 20:08:08.290639
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:08:08.814916
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:08:09.627182
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:08:11.957185
# Unit test for function romanize
def test_romanize():
    result = romanized(lambda: 'Россия')()
    assert result == 'Rossiya'



# Generated at 2022-06-25 20:08:24.389448
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize()

    @romanize()
    def f():
        return 'привет мир'

    @romanize('ru')
    def g():
        return 'привет мир'

    assert f() == 'privet mir'
    assert g() == 'privet mir'

    @romanize('en')
    def h():
        return 'привет мир'

    assert h() == 'привет мир'

    @romanize('es')
    def i():
        return 'привет мир'

    assert i() == '???? ????'
    assert callable_1

# Generated at 2022-06-25 20:08:36.173125
# Unit test for function romanize
def test_romanize():
    from mimesis.data import ROMANIZATION_DICT
    from mimesis.data import COMMON_LETTERS

    locale = 'ru'
    s = 'Привет мир!'

    def test_romanize_(locale):
        alphabet = {s: s for s in ascii_letters + digits + punctuation}
        alphabet.update({**ROMANIZATION_DICT[locale],
                         **COMMON_LETTERS})
        return ''.join([alphabet[i] for i in s if i in alphabet])

    romanize1 = romanize(locale)
    romanize2 = romanize1(test_romanize_)
    romanize1.__name__ == 'romanize'

# Generated at 2022-06-25 20:08:46.209073
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda x: x)('Олег') == 'Олег'
    assert romanize('ru')(lambda x: x)('Олег') == 'Oleg'
    assert romanize('uk')(lambda x: x)('Олег') == 'Oleh'
    assert romanize('kk')(lambda x: x)('Олег') == 'Oleg'

# Generated at 2022-06-25 20:08:56.610089
# Unit test for function romanize

# Generated at 2022-06-25 20:09:01.058301
# Unit test for function romanize
def test_romanize():
    func = romanize()
    assert func(lambda *args, **kwargs: 'foo')(*[], **{}) == 'foo'


# Generated at 2022-06-25 20:09:01.831835
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:09:09.165935
# Unit test for function romanize
def test_romanize():
    romanize = romanize(locale='ru')

    test_1 = romanize('Привет')
    assert test_1 == 'Privet'

    test_2 = romanize('Привет мир. Гджу рад тебя видеть.')
    assert test_2 == 'Privet mir. Gdjyu rad tebya videt.'

    test_3 = romanize('Да́рова!')
    assert test_3 == 'Darova!'

    test_4 = romanize('Хаюшка！')
    assert test_4 == 'Hajushka!'

# Generated at 2022-06-25 20:09:18.409053
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    result = callable_0(fn = lambda : 'Привет')
    assert result == 'Privet'

    # Unit test for default arguments
    callable_1 = romanize()
    result = callable_1(fn = lambda : 'Привет, мир!')
    assert result == 'Privet, mir!'

    callable_2 = romanize(locale= 'ru')
    result = callable_2(fn = lambda : 'Привет, мир!')
    assert result == 'Privet, mir!'

    callable_3 = romanize(locale = 'uk')

# Generated at 2022-06-25 20:09:24.421539
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    str_0 = callable_0(str)
    str_1 = str_0()
    bool_0 = str_1 in data.ROMANIZATION_DICT['ru']
    assert bool_0



# Generated at 2022-06-25 20:09:25.635392
# Unit test for function romanize
def test_romanize():
    assert callable_0(lambda: 42) == 42
    assert romanize(lambda: 42) == 42



# Generated at 2022-06-25 20:09:30.057840
# Unit test for function romanize
def test_romanize():
    func = lambda x: 'abc'
    romanized_func = romanize()(func)
    assert romanized_func == 'abc'


# Generated at 2022-06-25 20:09:31.449295
# Unit test for function romanize
def test_romanize():
    assert romanize == romanize


# Generated at 2022-06-25 20:09:45.233485
# Unit test for function romanize
def test_romanize():
    @romanize()
    def function_0(param_0='', param_1='', param_2=''):
        return param_0, param_1, param_2

    assert function_0() == ('', '', '')



# Generated at 2022-06-25 20:09:49.932774
# Unit test for function romanize
def test_romanize():
    assert romanize().__class__.__name__ == 'function'
    assert romanize('uk').__class__.__name__ == 'function'



# Generated at 2022-06-25 20:09:51.243254
# Unit test for function romanize
def test_romanize():
	pass


# Generated at 2022-06-25 20:09:52.555311
# Unit test for function romanize
def test_romanize():
    test_case_0()


# Generated at 2022-06-25 20:09:56.755101
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda: 'ФИО')() == 'FiO'
    assert romanize('ru')(lambda: 'ФИО')() == 'FiO'
    assert romanized('uk')(lambda: 'ФИО')() == 'FiO'
    assert romanized('kk')(lambda: 'ФИО')() == 'FİÖ'
    assert romanize('en')(lambda: 'ФИО')() == 'FIO'

# Generated at 2022-06-25 20:10:00.861428
# Unit test for function romanize
def test_romanize():
    assert 1 == 1


if __name__ == "__main__":
    test_case_0()
    test_romanize()
    print("Everything passed")

# Generated at 2022-06-25 20:10:04.317462
# Unit test for function romanize
def test_romanize():
    # Unit test for function romanize
    callable_1 = romanize(locale='sdfsdfs')


# Generated at 2022-06-25 20:10:08.298087
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Привет') == 'Privet'
    assert romanize('kk')('Сәлем') == 'Salem'
    assert romanize('uk')('Привіт' == 'Pryvit')

# Generated at 2022-06-25 20:10:09.702560
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-25 20:10:10.545210
# Unit test for function romanize
def test_romanize():
    assert romanize() is not False


# Generated at 2022-06-25 20:10:35.503812
# Unit test for function romanize
def test_romanize():
    assert romanize('uk')(lambda x: x)('Привіт, світ!') == 'Pryvit, svit!'

# Generated at 2022-06-25 20:10:37.326744
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize()

# Generated at 2022-06-25 20:10:38.921364
# Unit test for function romanize
def test_romanize():
    # Type error
    assert romanize() is None
    # No tests required

# Generated at 2022-06-25 20:10:50.580623
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='uk')(lambda: 'привіт')() == 'pryvit'
    assert romanize(locale='ru')(lambda: 'привет')() == 'privet'
    assert romanize(locale='kk')(lambda: 'Сәлеметсізбе')() == 'Sälemetsizbe'
    assert romanize(locale='ru')(lambda: 'Hello, world!')() == 'Hello, world!'
    assert romanize(locale='kk')(lambda: 'Привет, мир!')() == 'Privet, mir!'



# Generated at 2022-06-25 20:10:53.532880
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    str_0 = callable_0()

# Generated at 2022-06-25 20:10:55.038298
# Unit test for function romanize
def test_romanize():
    assert callable_0(romanize())

# Generated at 2022-06-25 20:10:59.308239
# Unit test for function romanize
def test_romanize():
    assert callable_0() is None
    assert callable_0() == ''.join([data.COMMON_LETTERS['а'], data.COMMON_LETTERS['б']])


test_case_0()
test_romanize()

# Generated at 2022-06-25 20:11:11.961155
# Unit test for function romanize
def test_romanize():
    # Data and result
    data = {
        'ru': {'Атмосфера': 'Atmofera', 'Волга': 'Volga'},

        'uk': {'Сльоза': 'Slioza', 'Вагнер': 'Vahner'},

        'kk': {'Республика': 'Respublika', 'Судан': 'Sudan'},

        'lat': {'The': 'The', 'Python': 'Python'}
    }

    # Check results
    for lang in data:
        for case in data[lang]:
            decorated_func = romanize(lang)(lambda x: x)

# Generated at 2022-06-25 20:11:13.407449
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None


# Generated at 2022-06-25 20:11:14.806358
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

# Generated at 2022-06-25 20:12:08.923337
# Unit test for function romanize
def test_romanize():
    assert True is True

# Generated at 2022-06-25 20:12:12.723428
# Unit test for function romanize
def test_romanize():

    @romanize()
    def func_0():
        return 'hello, мир!'

    assert func_0() == 'privet, mir!'


if __name__ == '__main__':
    test_case_0()
    test_romanize()

# Generated at 2022-06-25 20:12:24.585635
# Unit test for function romanize
def test_romanize():
    alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890' \
               '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~ '


# Generated at 2022-06-25 20:12:27.636487
# Unit test for function romanize
def test_romanize():
    assert romanize('ru') is not None
    assert romanize('uk') is not None
    assert romanize('kk') is not None
    assert romanize() is not None

# Generated at 2022-06-25 20:12:36.274382
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize()
    callable_2 = romanize()
    callable_3 = romanize()
    callable_4 = romanize()
    callable_5 = romanize()
    callable_6 = romanize()
    callable_7 = romanize()
    callable_8 = romanize()
    callable_9 = romanize()
    callable_10 = romanize()
    callable_11 = romanize()
    callable_12 = romanize()
    callable_13 = romanize()

    assert callable_1("\u0410\u0411\u0412") == "ABV"
    assert callable_2("\u0413\u0414") == "G"

# Generated at 2022-06-25 20:12:39.583882
# Unit test for function romanize
def test_romanize():
    # For function romanize
    callable_0 = romanize()
    assert callable_0(lambda : None)() is None


# Generated at 2022-06-25 20:12:45.061783
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

    assert type(callable_0) == type(romanize), \
        'Creates a function which returns a function'

    callable_1 = callable_0(romanize)
    assert type(callable_1) == type(romanize), \
        'Creates a function which returns a function'

# Generated at 2022-06-25 20:12:48.566631
# Unit test for function romanize
def test_romanize():
    assert romanize('en')(None)('Югославия') == 'Yugoslaviya'
    assert romanize('uk')(None)('Югославия') == 'Yuhoslaviya'
    assert romanize('ru')(None)('Югославия') == 'Yugoslaviya'
    assert romanize('kk')(None)('Югославия') == 'Yuqoslaviya'


# Generated at 2022-06-25 20:12:49.504568
# Unit test for function romanize
def test_romanize():
    assert 1 == 1

# Generated at 2022-06-25 20:12:56.338896
# Unit test for function romanize
def test_romanize():
    import mimesis.builtins.en_US.text as texts

    locale = 'ru'
    for lang, _ in data.ROMANIZATION_DICT.items():
        new_locale = texts.Romanizer(locale=lang)
        assert isinstance(new_locale.romanize('Вася'), str)
        assert new_locale.romanize('Вася') == 'Vasya'

    try:
        new_locale = texts.Romanizer(locale='invalid')
    except KeyError:
        pass

# Generated at 2022-06-25 20:15:01.468779
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:15:02.172465
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize, (Callable))

# Generated at 2022-06-25 20:15:02.844952
# Unit test for function romanize
def test_romanize():
    assert callable_0 is not None


# Generated at 2022-06-25 20:15:11.825905
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    bool_0 = False
    bool_1 = False
    bool_2 = True
    bool_3 = True
    bool_4 = True
    bool_5 = False
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []
    list_5 = []
    list_6 = []
    list_7 = []
    list_8 = []
    list_9 = []
    list_10 = []
    list_11 = []
    list_12 = []
    list_13 = []
    list_14 = []
    list_15 = []
    list_16 = []
    list_17 = []
    list_18 = []
    list_19 = []
    list_20 = []

# Generated at 2022-06-25 20:15:12.783055
# Unit test for function romanize
def test_romanize():
    return None

# Generated at 2022-06-25 20:15:17.737199
# Unit test for function romanize
def test_romanize():
    # assert romanize('Привет, Мир!  ') == 'Privet, Mir!  '
    assert romanize('ru')('Привет, Мир!  ') == 'Privet, Mir!  '
    assert romanize('uk')('Привет, Мир!  ') == 'Pryvet, Mir!  '
    assert romanize('kk')('Привет, Мир!  ') == 'Privet, Mir!  '

# Generated at 2022-06-25 20:15:27.574858
# Unit test for function romanize
def test_romanize():
    assert set(romanized('ru')(lambda: 'ЮЛАРА')()) == 'Iulara'
    assert set(romanized('uk')(lambda: 'ЮЛАРА')()) == 'Iulara'
    assert set(romanized('kk')(lambda: 'ӘЖЕЙ')()) == 'ažej'
    assert set(
        romanized('ru')(lambda: 'КОНЧИК ПАЛЬЦА КЫСИК')()) == 'Končik palʹca kyšik'

# Generated at 2022-06-25 20:15:28.389099
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')

# Generated at 2022-06-25 20:15:28.955249
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:15:29.799940
# Unit test for function romanize
def test_romanize():
    assert romanize('lang') == 'lang'
