

# Generated at 2022-06-25 20:08:00.443974
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')  # Will return nothing if code is OK
    assert romanize('uk')
    assert romanize('kk')
    import pytest
    with pytest.raises(UnsupportedLocale):
        romanize('foobar')

# Generated at 2022-06-25 20:08:02.860399
# Unit test for function romanize
def test_romanize():
    # noinspection PyUnresolvedReferences
    assert callable(romanize)
    assert callable(romanize())

# Generated at 2022-06-25 20:08:14.628948
# Unit test for function romanize
def test_romanize():
    # default romanize
    assert romanized()('Привет') == 'Privet'
    assert romanized()('Hello world') == 'Hello world'
    assert romanized(locale='uk')('Привет') == 'Pryvit'
    assert romanized(locale='uk')('Hello world') == 'Hello world'
    assert romanized(locale='ru')('Привет') == 'Privet'
    assert romanized(locale='ru')('Hello world') == 'Hello world'
    assert romanized(locale='kk')('Привет') == 'Pryvit'
    assert romanized(locale='kk')('Hello world') == 'Hello world'

# Generated at 2022-06-25 20:08:17.325853
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize('ru')
    assert callable_0



# Generated at 2022-06-25 20:08:20.941843
# Unit test for function romanize
def test_romanize():
    #assert callable_0(test_case_0) == 'test_case_0'
    print(test_case_0)


test_romanize()

# Generated at 2022-06-25 20:08:23.480503
# Unit test for function romanize
def test_romanize():
    assert callable_0.__code__.co_names == ('wrapper',)
    
    
if __name__ == '__main__':
    test_romanize()
    test_case_0()

# Generated at 2022-06-25 20:08:24.957472
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None


# Generated at 2022-06-25 20:08:28.557022
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')
    # assert romanize('')



# Generated at 2022-06-25 20:08:33.510324
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    result_0 = callable_0(type=str)
    result_1 = callable_0(type=int)
    assert result_0 is not None
    assert result_1 is not None


# Generated at 2022-06-25 20:08:35.678147
# Unit test for function romanize
def test_romanize():
    assert romanize


# Generated at 2022-06-25 20:08:45.679621
# Unit test for function romanize
def test_romanize():
    assert callable_0('sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssstet') == 'sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssstet'


# Generated at 2022-06-25 20:08:53.688573
# Unit test for function romanize
def test_romanize():
    def func(arg): return arg

    assert func('Привет Мир') == 'Привет Мир'
    func = romanize()(func)
    assert func('Привет Мир') == 'Privet Mir'
    assert func('Привет Мир') == 'Privet Mir'
    # Test code coverage
    f = func('')

# Generated at 2022-06-25 20:08:59.985701
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

    callable_1 = romanize()

    assert callable_0('ru').__name__ == 'wrapper'
    assert callable_1('ru').__name__ == 'wrapper'
    assert callable_0('ru')(lambda: None)

# Generated at 2022-06-25 20:09:04.084681
# Unit test for function romanize
def test_romanize():
    # test_case_0
    locale = ''
    def func():
        return ''
    tester = romanize(locale)(func)
    actual = tester()
    expected = ''
    assert actual == expected

test_case_0()

# Generated at 2022-06-25 20:09:05.532672
# Unit test for function romanize
def test_romanize():
    pass

test_romanize()

# Generated at 2022-06-25 20:09:07.821187
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

# Generated at 2022-06-25 20:09:16.268875
# Unit test for function romanize
def test_romanize():
    test_callable_0 = ("АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯЄІЇ")
    assert callable_0(test_callable_0) == ("ABVGDEYOZHIJKLMNOPRSTUFHCSHSH'Y'EZYEUIEII")



# Generated at 2022-06-25 20:09:16.965105
# Unit test for function romanize
def test_romanize():
    assert romanize()() == None

# Generated at 2022-06-25 20:09:19.009218
# Unit test for function romanize
def test_romanize():
    # Assertion for function romanize
    assert callable(romanize())

# Generated at 2022-06-25 20:09:21.245934
# Unit test for function romanize
def test_romanize():
    # Testing default parameter
    callable_0 = romanize()



# Generated at 2022-06-25 20:09:39.222731
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    test_dict = {}
    str_0 = callable_0(test_dict)
    assert(str_0 != None)
    def romanize_deco():
        def romanize_deco():
            return None
        return romanize_deco
    def romanize_deco():
        def romanize_deco():
            return 'СТАРАЯ АНАДЫРСКАЯ УЛИЦА'
            return 'СТАРАЯ АНАДЫРСКАЯ УЛИЦА'
        return romanize_deco


# Generated at 2022-06-25 20:09:48.578704
# Unit test for function romanize
def test_romanize():
    a = 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя'
    b = 'ABVGDEEZHZIJKLMNOPRSTUFKHCCHSHHSYYYEIYUAabvgdeezhzijklmnoprstufkhcchshhsyyeiyua'

    assert romanize('ru')(a) == b



# Generated at 2022-06-25 20:09:52.555451
# Unit test for function romanize
def test_romanize():
    # Test case where romanize() is called without parameter
    romanize(locale="ru")
    # Test case where romanize() is called with parameter
    romanize()


# Generated at 2022-06-25 20:09:57.495126
# Unit test for function romanize
def test_romanize():
    """Unit test for function `romanize`."""
    cyrillic = 'Янекудадутекуйй͡ымам'
    latin = 'YaneKudaduteKujjyMam'

    @romanize(locale='ru')
    def func_0():
        return cyrillic

    assert func_0() == latin



# Generated at 2022-06-25 20:09:59.802776
# Unit test for function romanize
def test_romanize():
    assert romanize('ru') != None, 'Romanize decorator failed.'

# Generated at 2022-06-25 20:10:01.671073
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет!') == 'Privet!'

# Generated at 2022-06-25 20:10:07.107743
# Unit test for function romanize
def test_romanize():
    @romanize(locale='ru')
    def my_func(foo: str) -> str:
        return foo

    romanized_foo = my_func("Привет, мир!")

    assert romanized_foo == "Privet, mir!"



# Generated at 2022-06-25 20:10:11.585288
# Unit test for function romanize
def test_romanize():
    assert (romanize(locale='ru')(lambda : 'Санкт-Петербург') ==
            'Sankt-Peterburg')

# Generated at 2022-06-25 20:10:20.739379
# Unit test for function romanize
def test_romanize():
    assert callable(romanize(locale=''))
    assert callable(romanize(locale='ru'))
    assert not callable(romanize(locale='test'))
    assert callable(romanize(locale='uk'))
    assert callable(romanize(locale='kk'))
    assert callable(romanized(locale=''))
    assert callable(romanized(locale='ru'))
    assert not callable(romanized(locale='test'))
    assert callable(romanized(locale='uk'))
    assert callable(romanized(locale='kk'))
    assert callable(romanize(locale='ru')(lambda x: x))
    assert callable(romanize(locale='uk')(lambda x: x))

# Generated at 2022-06-25 20:10:27.600012
# Unit test for function romanize
def test_romanize():
    callback = romanize()

    def callback_0():
        return 'A'

    assert callback_0() == 'A'
    assert callback(callback_0)() == 'A'

    def callback_1():
        return 'Петя'

    assert callback_1() == 'Петя'
    assert callback(callback_1)() == 'Pyeta'

# Generated at 2022-06-25 20:10:50.384793
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None



# Generated at 2022-06-25 20:10:52.513641
# Unit test for function romanize
def test_romanize():
    assert callable_0() is None



# Generated at 2022-06-25 20:10:59.290509
# Unit test for function romanize
def test_romanize():
    string_0: str = romanize()
    string_1: str = romanize()
    string_2: str = romanize()
    assert (string_0 == string_1 + string_2) is False
    assert (string_0 == string_1 + string_2) is False
    assert (string_0 == string_1 + string_2) is False

# Generated at 2022-06-25 20:11:01.209439
# Unit test for function romanize
def test_romanize():
    callable = romanize()
    assert callable != None

# Generated at 2022-06-25 20:11:12.616943
# Unit test for function romanize
def test_romanize():
    # Assert that UnsupportedLocale error is raised
    # when localization is not supported.
    ERROR_MESSAGE = "Invalid locale: ab"
    try:
        romanize()("Абвгдеёжзийклмнопрстуфхцчшщъыьэюя")
    except UnsupportedLocale as e:
        assert str(e) == ERROR_MESSAGE


# Generated at 2022-06-25 20:11:21.438542
# Unit test for function romanize
def test_romanize():
    assert True
    #  See if romanize decorator is present
    assert callable(romanize)
    #  See if it can be called
    assert callable_0
    #  Verify the function returns a string
    assert isinstance(romanize('ru'), str)
    #  See if the function raises an error when it is not expected
    try:
        romanize()
        assert True
    except:
        assert False
    #  See if the function raises an UnsupportedLocale exception when an invalid string is passed in
    try:
        romanize('abc')
        assert False
    except UnsupportedLocale as e:
        assert True

# Generated at 2022-06-25 20:11:32.980119
# Unit test for function romanize

# Generated at 2022-06-25 20:11:34.224902
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')



# Generated at 2022-06-25 20:11:36.040784
# Unit test for function romanize
def test_romanize():
    assert (romanize()('a') == 'a')


# Generated at 2022-06-25 20:11:39.842129
# Unit test for function romanize
def test_romanize():
    txt = romanize(locale='ru')(lambda x: 'привет')()
    assert txt == 'privet'
    txt = romanize(locale='kk')(lambda x: 'қазақша')()
    assert txt == 'qazaxsha'



# Generated at 2022-06-25 20:12:36.400395
# Unit test for function romanize
def test_romanize():
    assert romanize is not None


# Generated at 2022-06-25 20:12:40.255418
# Unit test for function romanize
def test_romanize():
    assert str(romanize()) == "<function romanize_deco.<locals>.wrapper at 0x7fab4e4f3d08>"



# Generated at 2022-06-25 20:12:44.178107
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: 'привет')('привет') == 'privet'



# Generated at 2022-06-25 20:12:45.086275
# Unit test for function romanize
def test_romanize():
    assert True == True

# Generated at 2022-06-25 20:12:56.465868
# Unit test for function romanize
def test_romanize():
    import random
    import string

    @romanize()
    def func_0():
        return 'Привет'

    func_0()

    @romanize()
    def func_1():
        return 'Hello'

    func_1()

    @romanize()
    def func_2():
        return 'Привет, Мир!'

    func_2()

    @romanize()
    def func_3(value: str):
        return value

    func_3('Hell')

    @romanize()
    def func_4(value: int):
        return value

    func_4(25)

    @romanize()
    def func_5(value: str):
        return value

    func_5('Hello')


# Generated at 2022-06-25 20:12:57.872963
# Unit test for function romanize
def test_romanize():
    func = romanize()
    func('test', 'ru')


# Generated at 2022-06-25 20:12:58.772879
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanized()

# Generated at 2022-06-25 20:13:01.979175
# Unit test for function romanize
def test_romanize():
    # Test function overloads
    overloads = [
        {'locale': ''},
    ]
    for overload in overloads:
        try:
            assert callable(romanize(**overload))
        except TypeError:
            pass

# Generated at 2022-06-25 20:13:13.842816
# Unit test for function romanize
def test_romanize():
    # simple test of romanize
    assert romanize('ru')(lambda: 'город')() == 'gorod'
    
    # простые тесты на русский
    assert romanize('ru')(lambda: 'петров')() == 'petrov'
    assert romanize('ru')(lambda: 'ПЕТРОВ')() == 'PETROV'
    assert romanize('ru')(lambda: 'Петров')() == 'Petrov'
    
    # простые тесты на казахский

# Generated at 2022-06-25 20:13:15.465771
# Unit test for function romanize
def test_romanize():
    a = 0
    b = 1
    assert a == b, "Test has failed"


# Generated at 2022-06-25 20:15:33.540812
# Unit test for function romanize
def test_romanize():
    st = 'Привет, мир!'
    assert romanize()(st) == 'privet, mir!'



# Generated at 2022-06-25 20:15:50.118755
# Unit test for function romanize
def test_romanize():
    tests = [
        # Test if the function is working correctly
        (2.718281828459045, '2.718281828459045'),
        (2.718281828459045, '2.718281828459045'),
    ]
    for item, expected in tests:
        # Call the function and check if
        # the result is equal to expected.
        assert str(romanize()(item, item)) == str(expected)

# Generated at 2022-06-25 20:15:57.076118
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize()
    callable_1 = romanize()
    callable_2 = romanize()
    callable_2 = romanize()
    callable_3 = romanize()
    callable_3 = romanize()
    callable_4 = romanize()
    callable_4 = romanize()
    callable_5 = romanize()
    callable_5 = romanize()
    callable_6 = romanize()
    callable_6 = romanize()
    callable_7 = romanize()
    callable_7 = romanize()
    callable_8 = romanize()
    callable_8 = romanize()
    callable_9 = romanize()
    callable_9 = romanize()
   

# Generated at 2022-06-25 20:15:58.026241
# Unit test for function romanize
def test_romanize():
    assert callable_0 == romanize


# Generated at 2022-06-25 20:15:59.521111
# Unit test for function romanize
def test_romanize():
    func_0 = romanize()
    func_0(func_0)
    func_0('func_0')


# Generated at 2022-06-25 20:16:02.745852
# Unit test for function romanize
def test_romanize():
    expected = 'Ugly Duckling'
    actual = 'Гадкий утёнок'
    actual_romanized = romanized('ru')(actual)
    assert actual_romanized != actual
    assert actual_romanized == expected



# Generated at 2022-06-25 20:16:03.758617
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")


# Generated at 2022-06-25 20:16:12.217928
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person

    person = Person(Locale.RU)

    assert romanize()(person.full_name()) == 'Евгений Иванович Лукашенко'
    assert romanize()(person.full_name(gender=None)) == 'Степан Лаврентьевич Яков'
    assert romanize()(person.full_name(gender='female', last_name=None)) == 'Марина Николаевна'

# Generated at 2022-06-25 20:16:16.339416
# Unit test for function romanize
def test_romanize():
    assert callable_0(provider_0.provide_string)((('ru'))) == 'Privet'
    assert callable_0(provider_0.provide_string)((('uk'))) == 'Privet'
    assert callable_0(provider_0.provide_string)((('kk'))) == 'Privet'
    assert callable_0(provider_0.provide_string)((('kk'))) == 'Privet'


# Generated at 2022-06-25 20:16:16.950201
# Unit test for function romanize
def test_romanize():
    assert callable_0
