

# Generated at 2022-06-25 20:07:56.682308
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda : "") == ""


# Generated at 2022-06-25 20:07:58.656617
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()



# Generated at 2022-06-25 20:08:02.903395
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize('ru')
    callable_2 = functools.partial(romanize(), 'ru')

    @callable_1(func='test_case_1')
    @callable_2(func='test_case_2')
    def test(func):
        pass



# Generated at 2022-06-25 20:08:06.081634
# Unit test for function romanize
def test_romanize():
    n = 'aaaa'
    assert n == romanize(n)
    assert n == romanize()(n)

# Generated at 2022-06-25 20:08:15.469070
# Unit test for function romanize
def test_romanize():
    def func():
        return "Привет, Мир, как дела?"

    # Test 1
    @romanize()
    def func_1():
        return "Привет, Мир, как дела?"

    assert func() != func_1(), "{} == {}".format(func(), func_1())

    # Test 2
    @romanize(locale='ru')
    def func_2():
        return "Привет, Мир, как дела?"

    assert func() != func_2(), "{} == {}".format(func(), func_2())
    assert func().lower() == func_2(), "{} != {}".format(func(), func_2())

   

# Generated at 2022-06-25 20:08:18.159522
# Unit test for function romanize
def test_romanize():
    try:
        romanize('asdas')
    except UnsupportedLocale as e:
        assert str(e) == 'asdas'
    else:
        assert False

# Generated at 2022-06-25 20:08:21.222471
# Unit test for function romanize
def test_romanize():
    assert romanize is romanized
    assert romanize() is romanized()
    # assert romanize('ru') is romanized('ru')

# Generated at 2022-06-25 20:08:22.106359
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())


# Generated at 2022-06-25 20:08:23.294694
# Unit test for function romanize
def test_romanize():
    # Test with correct input
    assert romanize()
    assert romanized()

# Generated at 2022-06-25 20:08:24.064344
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:08:31.944489
# Unit test for function romanize
def test_romanize():
    test_1 = romanize()
    test_2 = romanize(locale='ru')



# Generated at 2022-06-25 20:08:34.719632
# Unit test for function romanize
def test_romanize():
    # Init
    func_0 = test_case_0
    
    # Run func
    func_0()
    
if __name__ == '__main__':
    #test_romanize()
    pass

# Generated at 2022-06-25 20:08:36.399988
# Unit test for function romanize
def test_romanize():
    assert romanize()



# Generated at 2022-06-25 20:08:38.121697
# Unit test for function romanize
def test_romanize():
    string_0 = romanize()
    boolean_0 = False
    if string_0 == True:
        boolean_0 = True

    assert boolean_0


# Generated at 2022-06-25 20:08:39.510146
# Unit test for function romanize
def test_romanize():
    assert romanize()  # Type hinting

# Generated at 2022-06-25 20:08:40.905026
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()


if __name__ == '__main__':
    import doctest

    doctest.testmod()
    test_case_0()

# Generated at 2022-06-25 20:08:43.775938
# Unit test for function romanize
def test_romanize():
    assert romanize_deco() == romanize_deco()
    assert romanize_deco() == romanize_deco()
    assert romanize_deco() == romanize_deco()


# Generated at 2022-06-25 20:08:46.575374
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func():
        return 'abc'

    assert func() == 'abc'

# Generated at 2022-06-25 20:08:50.323874
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    def function_0():
        return 'Киев'
    assert callable_0(function_0) == 'Kiev'

# Generated at 2022-06-25 20:08:52.200175
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='') == callable

# Generated at 2022-06-25 20:09:03.857287
# Unit test for function romanize
def test_romanize():
    pass



# Generated at 2022-06-25 20:09:04.686473
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:09:06.942450
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:09:17.518328
# Unit test for function romanize
def test_romanize():
    """Unit test for function romanize"""
    assert romanize('ru')(lambda: 'Я думаю в этом нет ничего предсказуемого')() == 'Ya dumayu v etom net nichego predskazuemogo'
    assert romanize('uk')(lambda: 'Я тут англійською написала')() == 'Ya tut angliyskoyu napisala'

# Generated at 2022-06-25 20:09:18.331720
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:09:24.154510
# Unit test for function romanize
def test_romanize():
    from string import ascii_letters, digits, punctuation
    from mimesis import data
    from mimesis.exceptions import UnsupportedLocale
    from mimesis.decorators import romanize
    from mimesis.utils import random_cyrillic_string

    def callable(a, b, c=False):
        return random_cyrillic_string(10)

    callable_0 = romanize('uk')(callable)
    test = callable_0(1, 2)
    assert len(test) == 10
    assert type(test) is str

    test = callable_0(1, 2, True)
    assert len(test) == 10
    assert type(test) is str

    def callable(): return ''

    callable_0 = romanize('uk')(callable)

# Generated at 2022-06-25 20:09:25.373729
# Unit test for function romanize
def test_romanize():
    assert romanize.__name__ == 'romanize'
    patt = '^[a-zA-Z]+$'


# Generated at 2022-06-25 20:09:27.804100
# Unit test for function romanize
def test_romanize():
    assert 1 == 1

from .enums import Language


# Generated at 2022-06-25 20:09:29.301667
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:09:31.849488
# Unit test for function romanize
def test_romanize():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 20:09:55.570490
# Unit test for function romanize
def test_romanize():
    assert romanize() != ''
    assert romanize() is not None
    assert callable(romanize())
    assert callable(romanize)
    assert callable(romanized)

# Generated at 2022-06-25 20:10:07.832706
# Unit test for function romanize
def test_romanize():
    # Assert that UnsupportedLocale raised with locale key,
    # which is not located in ROMANIZATION_DICT
    try:
        romanize()('djur')
    except UnsupportedLocale as error:
        assert error.locale == 'djur'
    else:
        raise AssertionError('UnsupportedLocale not raised')

    @romanize(locale='ru')
    def romanizable(text: str) -> str:
        return text

    # Assert that romanizable function return 'Привет' in latin script
    # 'Privet'
    assert romanizable('Привет') == 'Privet'

# Generated at 2022-06-25 20:10:08.878382
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None
    assert romanize_deco() is not None
    assert wrapper() is not None


# Generated at 2022-06-25 20:10:13.342292
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    # Case 1
    assert callable_0(data.random_item(data.ROMANIZATION_DICT['uk'])) is not None
    # Case 2
    assert callable_0(data.random_item(data.ROMANIZATION_DICT['ru'])) is not None
    # Case 3
    assert callable_0(data.random_item(data.ROMANIZATION_DICT['kk'])) is not None

# Generated at 2022-06-25 20:10:16.088089
# Unit test for function romanize
def test_romanize():
    assert hasattr(romanize, '__call__')


# Generated at 2022-06-25 20:10:18.822604
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')
    assert romanize('en') is None
    assert romanize('zz') is None


# Generated at 2022-06-25 20:10:23.439946
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanize(""))
    assert callable(romanize("ru"))
    assert callable(romanize("uk"))
    assert callable(romanize("kk"))

# Generated at 2022-06-25 20:10:27.562135
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize(locale='')
    result_0 = callable_0()
    # Check that result_0 is not a None value
    assert result_0 is not None


# Generated at 2022-06-25 20:10:30.524662
# Unit test for function romanize
def test_romanize():

    from mimesis.enums import Language

    assert romanize(locale=Language.RU)



# Generated at 2022-06-25 20:10:33.421221
# Unit test for function romanize
def test_romanize():
    language_0 = 'ru'
    assert romanize(language_0)

# Generated at 2022-06-25 20:11:16.534164
# Unit test for function romanize
def test_romanize():
    # Check if the returned value from romanize decorator is callable
    assert callable(test_case_0()) == True

# Generated at 2022-06-25 20:11:22.638554
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Localization
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.address import Address

    person = Person(Localization.ENGLISH)
    text = Text(Localization.ENGLISH)
    address = Address(Localization.ENGLISH)

    assert person.full_name(romanized=True) == text.romanize(person.full_name())
    assert address.city() == text.romanize(address.city(romanized=True))

# Generated at 2022-06-25 20:11:28.753148
# Unit test for function romanize
def test_romanize():
    from mimesis import Person

    person = Person('ru')
    full_name = person.full_name()
    full_name_romanized = person.full_name(romanize=True)

    assert full_name != full_name_romanized
    assert isinstance(full_name_romanized, str)

# Generated at 2022-06-25 20:11:30.117579
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize(), type(test_case_0))

# Generated at 2022-06-25 20:11:41.091771
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda: '')
    assert romanize(locale='ru')(lambda: ' ')
    assert romanize(locale='en')(lambda: '')
    assert romanize(locale='en')(lambda: ' ')
    # Test with Russian locale
    russian_function = romanize(locale='ru')(lambda: 'Привет мир!')
    assert russian_function() == 'Privet mir!'
    # Test with Ukrainian locale
    ukrainian_function = romanize(locale='uk')(lambda: 'Привіт Світ!')
    assert ukrainian_function() == 'Pryvit Svit!'
    # Test with Kazakh locale
    kaz

# Generated at 2022-06-25 20:11:42.365925
# Unit test for function romanize
def test_romanize():
    bool_var = romanize()
    callable_var = romanize()
    str_var = romanize()

# Generated at 2022-06-25 20:11:52.173606
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc

    p = Person('ru')
    misc = Misc('ru')

    assert p.full_name() == 'Белта Шукора'
    assert p.name() == 'Галери'
    assert p.last_name() == 'Чустелла'

    assert misc.currency() == 'рубль Российской Федерации'
    assert misc.sector() == 'IT'

    p = Person('uk')

# Generated at 2022-06-25 20:11:53.787723
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:11:56.910036
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='')(lambda text: text)('Хвилини') == 'Khvyliny'

# Generated at 2022-06-25 20:11:59.578586
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanize("ru")

# Generated at 2022-06-25 20:13:56.451748
# Unit test for function romanize
def test_romanize():
    # test the generated text
    assert romanize()(u'Проверка') == 'Proverka'

    # test the generated text
    assert romanize('uk')(u'Проверка') == 'Proverka'

    # test the generated text
    assert romanize('kk')(u'Проверка') == 'Proverka'

    # test the generated text
    assert romanize('de')(u'Проверка') == 'Proverka'

    # test the generated text
    assert romanize('en')(u'Проверка') == 'Proverka'



# Generated at 2022-06-25 20:13:57.218976
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-25 20:13:59.141376
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')
    assert romanize(locale='uk')
    assert not romanize(locale='zz')

# Generated at 2022-06-25 20:14:03.520360
# Unit test for function romanize
def test_romanize():
    def _func():
        return "Великая октябрьская социалистическая"
    res = romanize("ru")(_func)
    assert res() == "Velikaya oktyabrskaya sotsialisticheskaya"

# Generated at 2022-06-25 20:14:11.417428
# Unit test for function romanize

# Generated at 2022-06-25 20:14:14.936816
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('А роза упала на лапу Азора') == 'A roza upala na lapu Azora'

    assert romanize('uk')('На вулиці дощ, подорож потоплена') == 'Na vulitsi doshch, podorozh potoplena'



# Generated at 2022-06-25 20:14:28.253535
# Unit test for function romanize
def test_romanize():
    c = [1, 2, 5]
    c[0] = romanize('ru')
    c[1] = romanize('uk')
    c[2] = romanize('kk')
    return c

if __name__ == '__main__':
    romanize('ru')
    romanize('uk')
    romanize('kk')
    # function
    print(test_romanize())

# Generated at 2022-06-25 20:14:33.989790
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0(callable)

# Generated at 2022-06-25 20:14:43.613052
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0.__name__ == "romanize"
    assert callable_0.__doc__ == "Romanize the cyrillic text.\n\n    Transliterate the cyrillic script into the latin alphabet.\n\n    .. note:: At this moment it works only for `ru`, `uk`, `kk`.\n\n    :param locale: Locale code.\n    :return: Romanized text.\n    "

    def test_function():
        return 'this is a test string'

    test_function = callable_0(test_function)
    assert test_function() == 'ѕіѕ іѕ а теѕт ѕтяіng'

# Generated at 2022-06-25 20:14:44.341413
# Unit test for function romanize
def test_romanize():
    assert callable_0(func)