

# Generated at 2022-06-25 20:08:00.356589
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())
    assert callable(romanized())
    assert callable(test_case_0()) == callable('test_case_0()')


# Generated at 2022-06-25 20:08:03.168682
# Unit test for function romanize
def test_romanize():
    func = functools.partial(romanize(locale='ru'), func=lambda: 'Тестовая функция')
    assert func() == 'Testovaya funckiya'

# Generated at 2022-06-25 20:08:08.167676
# Unit test for function romanize
def test_romanize():
    test_case_0()
    test_romanize_deco = romanize()
    test_romanize_deco_with_ru = romanize(locale='ru')


# Generated at 2022-06-25 20:08:10.355315
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0 == functools.wraps(callable_0)

# Generated at 2022-06-25 20:08:12.952949
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    str_0 = callable_0(lambda _: 'Строка')
    assert str_0 == 'Stroka'

# Generated at 2022-06-25 20:08:16.168770
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    callable_1 = romanize(locale=locale)


# Generated at 2022-06-25 20:08:22.060445
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text

    text = Text()
    text.romanize()
    str(text)

    text.romanize('ru')
    str(text)
    text.romanize('uk')
    str(text)
    text.romanize('kk')
    str(text)

# Generated at 2022-06-25 20:08:23.808428
# Unit test for function romanize
def test_romanize():
    func_0 = romanize('ru')
    assert func_0(func_1) == 'dobriy vecher'


# Generated at 2022-06-25 20:08:26.428854
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize_deco()

test_case_0()
test_romanize()

# Generated at 2022-06-25 20:08:32.095308
# Unit test for function romanize
def test_romanize():
    class fakeFunc:
        def __init__(self):
            pass

        def __call__(self):
            return 'fake'

    fake_deco = romanize()
    fake_func = fake_deco(fakeFunc())
    assert fake_func() == 'fake'

# Generated at 2022-06-25 20:08:44.527476
# Unit test for function romanize
def test_romanize():
    # Expected output: ''
    assert '' == romanize()()



# Generated at 2022-06-25 20:08:48.956249
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize('ru')
    callable_2 = romanize('en')
    callable_3 = romanize('uk')
    callable_4 = romanize('kk')

# Generated at 2022-06-25 20:08:50.762914
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda *args, **kwargs: 'РїСЂРёРІРµС‚')() == 'privet'

# Generated at 2022-06-25 20:08:58.187620
# Unit test for function romanize
def test_romanize():
    assert romanize()('Строка в кириллице') == 'Stroka v kirillitse'
    assert romanize('uk')('Строка в кириллице') == 'Strіka v kirillіtse'
    assert romanize('kk')('Строка в кириллице') == 'Stroka w qırılıtse'
    assert romanize()('Привет Мир') == 'Privet Mir'
    assert romanize()('Всего Хорошего') == 'Vsego Khoroshogo'


# Generated at 2022-06-25 20:09:01.267170
# Unit test for function romanize
def test_romanize():
    with pytest.raises(UnsupportedLocale):
        callable_1 = romanize()


# Generated at 2022-06-25 20:09:02.610392
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:09:07.138016
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize(locale = 'ru')
    assert callable_0(lambda: 'Это моё сообщение!') == 'Ėto moë soobŝenië!'
    assert callable_0(lambda: 'Хабрахабр') == 'Khabrakhabr'


# Generated at 2022-06-25 20:09:17.422545
# Unit test for function romanize
def test_romanize():
    import random
    import hashlib
    import string
    seed = random.seed
    seed(5)

# Generated at 2022-06-25 20:09:20.030066
# Unit test for function romanize
def test_romanize():
    assert romanize("ru", "") == "Привет"

# Generated at 2022-06-25 20:09:24.734943
# Unit test for function romanize
def test_romanize():
    def callable_0():
        # Simple Romanization.
        pass
    # Return Romanized text.
    callable_0 = romanize('')
    result = callable_0()
    assert result is None

# Generated at 2022-06-25 20:09:43.616666
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale

    try:
        romanize(Locale.ENGLISH)
    except UnsupportedLocale:
        pass
    else:
        raise AssertionError('UnsupportedLocale has not been raised')
    try:
        romanize()
    except UnsupportedLocale:
        pass
    else:
        raise AssertionError('UnsupportedLocale has not been raised')

# Generated at 2022-06-25 20:09:52.204635
# Unit test for function romanize
def test_romanize():
    # Assert that the correct value is returned
    assert romanize() == 'Привет мир'
    # Assert that the correct value is returned
    assert romanize() == 'Привет мир'
    # Assert that the correct value is returned
    assert romanize() == 'Είναι η αρχαία ελληνική έννοια της ευφυΐας'
    # Assert that the correct value is returned
    assert romanize() == 'Я-проста веснянка'
    # Assert that the correct value is returned

# Generated at 2022-06-25 20:09:53.496677
# Unit test for function romanize
def test_romanize():
    assert test_case_0() is None

# Generated at 2022-06-25 20:10:00.239057
# Unit test for function romanize
def test_romanize():
    import random
    text = 'Например, этот длинный текст на русском языке.'
    result = 'Naprimer, etot dlinnyy tekst na russkom yazyke.'
    assert romanize()(text) == result
    text = 'Например, этот длинный текст на русском языке.'
    result = 'Naprymer, etot\tdlinnyi\ntekst na\nrusskom yazyci.'

# Generated at 2022-06-25 20:10:05.982772
# Unit test for function romanize
def test_romanize():
    callable = romanize(locale='ru')
    str = 'Это простой тест'
    assert callable('str') == 'Это простой тест'


# Generated at 2022-06-25 20:10:10.633546
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0.__name__ == 'romanize_deco'
    assert callable_0.__doc__ == 'Romanize the cyrillic text.\n\n    Transliterate the cyrillic script into the latin alphabet.\n\n    \n    :param locale: Locale code.\n    :return: Romanized text.\n    '

# Generated at 2022-06-25 20:10:12.512103
# Unit test for function romanize
def test_romanize():
    assert romanize().__name__ == 'romanize_deco'


# Generated at 2022-06-25 20:10:16.967042
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize()
    result_tuple_0 = callable_1(0)
    assert result_tuple_0 == 0



# Generated at 2022-06-25 20:10:18.693133
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('я') == 'ya'
    assert romanized('uk')('є') == 'ie'

# Generated at 2022-06-25 20:10:20.097050
# Unit test for function romanize
def test_romanize():
  callable_0 = romanize()

# Generated at 2022-06-25 20:10:48.997688
# Unit test for function romanize
def test_romanize():
    # TODO: Rewriting unit test which is no longer valid
    callable_0 = romanize()
    result = callable_0("Скажи мне друг есть ли на свете любовь?")
    assert result == "Skazhi mne drug est' li na svete liubov'?"

# Generated at 2022-06-25 20:10:54.493023
# Unit test for function romanize
def test_romanize():
    import pytest
    from mimesis.builtins import Text

    t = Text()
    r = t.romanize()
    with pytest.raises(UnsupportedLocale):
        assert r.romanize('ua') == ''

# Generated at 2022-06-25 20:10:55.105977
# Unit test for function romanize
def test_romanize():
    assert romanize is not None



# Generated at 2022-06-25 20:10:56.640513
# Unit test for function romanize
def test_romanize():
    assert callable_0(0) == 0

# Generated at 2022-06-25 20:10:58.024615
# Unit test for function romanize
def test_romanize():
    test_case_0()

# Generated at 2022-06-25 20:10:59.197871
# Unit test for function romanize
def test_romanize():
    pass



# Generated at 2022-06-25 20:11:11.909933
# Unit test for function romanize
def test_romanize():
    test_data = [
        ({"locale": "ru"}, "Романизируйте цириллический текст"),
        ({"locale": "uk"}, 'Романізуйте цирилічний текст'),
        ({"locale": "kk"}, 'Романдық желіміне кірістіріңіз'),
    ]
    param = data.ROMANIZATION_DICT
    expected = 'Romaniziruyte tsirillicheskiy tekst'

# Generated at 2022-06-25 20:11:16.599507
# Unit test for function romanize
def test_romanize():
    text = 'Привет, мир!'
    romanized_text = romanized('ru')(lambda : text)()
    assert romanized_text == 'Privet, mir!'



# Generated at 2022-06-25 20:11:19.076751
# Unit test for function romanize
def test_romanize():
    callable_ = romanize(locale='ru')
    assert callable_



# Generated at 2022-06-25 20:11:24.403389
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanize('ru'))

    result = romanize('ru')(lambda: 'Привет')
    assert result == 'Privet'

    result = romanize('uk')(lambda: 'Привіт')
    assert result == 'Pryvit'

    result = romanize('kk')(lambda: 'Сәлем')
    assert result == 'Salem'

    result = romanize('kk')(lambda: 'Қараша')
    assert result == 'Qaraša'

    resu

# Generated at 2022-06-25 20:12:21.268999
# Unit test for function romanize
def test_romanize():
    assert romanize()



# Generated at 2022-06-25 20:12:22.191441
# Unit test for function romanize
def test_romanize():
    print(romanize('ru'))

# Generated at 2022-06-25 20:12:25.022776
# Unit test for function romanize
def test_romanize():
    assert callable_0(0, 0)[0] == 0
    assert callable_0(1, 0)[0] == 1


# Generated at 2022-06-25 20:12:35.351665
# Unit test for function romanize
def test_romanize():

    @romanize()
    def text(self):
        return 'абвгдежзийклмнопрстуфхцчшщъыьэюя'

    class Test:

        @romanize()
        def text(self):
            return 'абвгдежзийклмнопрстуфхцчшщъыьэюя'

    txt = Test().text
    assert txt == 'abvgdeezijklmnoprstufhccss��y��eua'
    txt = text()

# Generated at 2022-06-25 20:12:36.733563
# Unit test for function romanize
def test_romanize():
    test_case_0()

# Generated at 2022-06-25 20:12:43.272356
# Unit test for function romanize
def test_romanize():
    to_romanize = romanize('ru')

    @to_romanize
    def func():
        return 'Привет, друзья.'

    assert func() == 'Privet, druzya.'


# Generated at 2022-06-25 20:12:46.959288
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'привет')() == 'privet'

# Generated at 2022-06-25 20:12:48.430639
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:12:52.867237
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize()(lambda x: x), Callable)
    # callable_0 = romanize()
    # assert isinstance(callable_0(lambda x: x), Callable)

# Generated at 2022-06-25 20:13:02.764649
# Unit test for function romanize
def test_romanize():
    txt = 'Имидж города, вовлечённый в процесс проектирования, также влияет на выбор названия здания.'
    callable_1 = romanize()
    assert callable_1(txt) == 'Imidz goroda, vovlezhennyi v protsess proektirovaniya, takzhe vliyaet na vybor nazvaniya zdaniya.'

# Generated at 2022-06-25 20:15:16.867963
# Unit test for function romanize
def test_romanize():
    assert romanize('ru') is not None

# Generated at 2022-06-25 20:15:27.358402
# Unit test for function romanize
def test_romanize():
    class TestRomanize:
        def __init__(self):
            self.ru = 'Привет, Мир!'
            self.uk = 'Привіт, Мир!'
            self.kk = 'Сәлем, Дүние!'

        @romanize('ru')
        def rus(self):
            return self.ru

        @romanize('uk')
        def ukr(self):
            return self.uk

        @romanize('kk')
        def kaz(self):
            return self.kk

    tr = TestRomanize()
    assert tr.rus() == 'Privet, Mir!'
    assert tr.ukr() == 'Pryvit, Mir!'

# Generated at 2022-06-25 20:15:32.095814
# Unit test for function romanize
def test_romanize():
    locale = ['ru', 'uk', 'kk', 'en']
    assert (romanize(locale[0]))
    assert (romanize(locale[1]))
    assert (romanize(locale[2]))
    assert (romanize(locale[3]) == UnsupportedLocale)

# Generated at 2022-06-25 20:15:32.810156
# Unit test for function romanize
def test_romanize():
    assert True

# Generated at 2022-06-25 20:15:33.654419
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None


# Generated at 2022-06-25 20:15:34.711485
# Unit test for function romanize
def test_romanize():
    assert True


# Generated at 2022-06-25 20:15:50.120100
# Unit test for function romanize
def test_romanize():
    def func0():
        return 'qZXs'
    func0 = romanize()(func0)
    assert func0() == 'qZXs'

    def func1():
        return func0()
    func1 = romanize()(func1)
    assert func1() == 'qZXs'



# Generated at 2022-06-25 20:15:50.730210
# Unit test for function romanize
def test_romanize():
    assert romanize is not None


# Generated at 2022-06-25 20:15:52.102486
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize('ru'), type(romanize_0))
    assert isinstance(romanize(), type(callable_0))



# Generated at 2022-06-25 20:15:53.109178
# Unit test for function romanize
def test_romanize():
    assert(('key', 'value') in data.ROMANIZATION_DICT['uk'])

