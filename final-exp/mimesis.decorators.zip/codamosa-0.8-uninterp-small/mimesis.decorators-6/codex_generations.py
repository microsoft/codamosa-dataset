

# Generated at 2022-06-25 20:07:55.878656
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:07:57.235130
# Unit test for function romanize
def test_romanize():
    assert romanize('') == ''



# Generated at 2022-06-25 20:08:06.128233
# Unit test for function romanize

# Generated at 2022-06-25 20:08:09.771884
# Unit test for function romanize
def test_romanize():
    @romanize()
    def callable_0():
        return 'Приговор Александра Лукашенко подтвердили, он получил пять годов колонии'
    assert callable_0() == 'Prigovor Aleksandra Lukashenko podtverdili, on poluchil piat let koloni'


# Generated at 2022-06-25 20:08:12.628703
# Unit test for function romanize
def test_romanize():
    # Test of function romanize with parameters
    callable_0 = romanize()
    # Test of function romanize_deco with parameters
    pass



# Generated at 2022-06-25 20:08:14.710214
# Unit test for function romanize
def test_romanize():
    # Callable
    assert callable(romanize)
    # Decorator test
    assert callable(romanize(locale="ru")(test_case_0))

# Generated at 2022-06-25 20:08:17.396367
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanize('ru')



# Generated at 2022-06-25 20:08:18.787029
# Unit test for function romanize
def test_romanize():
    # pyre-ignore[11]
    assert callable_0() is None

# Generated at 2022-06-25 20:08:26.258038
# Unit test for function romanize

# Generated at 2022-06-25 20:08:27.057371
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:08:34.097870
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

    def func1():
        pass

    assert callable_0(func1) == func1

# Generated at 2022-06-25 20:08:37.331344
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Привет мир!') == 'Privet mir!'

# Generated at 2022-06-25 20:08:43.708626
# Unit test for function romanize
def test_romanize():
    def func1():
        pass

    def func2():
        pass

    res1 = romanize()(func1)("Hello")
    res2 = romanize()(func2)("Hello")
    res3 = romanize()(func1)("Hello")
    res4 = romanize()(func2)("Hello")

    assert res1 == "Hello"
    assert res2 == "Hello"
    assert res3 == "Hello"
    assert res4 == "Hello"

    def func3():
        pass

    def func4():
        pass

    func3.__wrapped__ = func4

    res5 = romanize()(func3)("Hello")
    res6 = romanize()(func4)("Hello")
    res7 = romanize()(func3)("Hello")
    res8

# Generated at 2022-06-25 20:08:45.897008
# Unit test for function romanize
def test_romanize():
    assert callable_0.romanize() == ''


test_case_0()

# Generated at 2022-06-25 20:08:56.495835
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.text import Text

    t = Text(locale=Locale.RU)
    assert 'Собственник' == t.word()

    t.set_locale(Locale.EN)

# Generated at 2022-06-25 20:09:04.162726
# Unit test for function romanize
def test_romanize():
    @romanize()
    def func_0(arg_0: str) -> str:
        return arg_0
    ret_0 = func_0("\u0435\u0442\u0435")
    assert type(ret_0) == str
    assert ret_0 == "ete"
    assert func_0("\u0435\u0442\u0435") == "ete"


# Generated at 2022-06-25 20:09:16.062572
# Unit test for function romanize
def test_romanize():
    import six
    from mimesis.builtins.text import Text

    txt = Text()
    if six.PY2:
        assert txt.romanized('Привет мир!', 'uk') == u'Pryvit myr!'
        assert txt.romanized('Привет мир!', 'ru') == u'Privet mir!'
    else:
        assert txt.romanized('Привет мир!', 'uk') == 'Pryvit myr!'
        assert txt.romanized('Привет мир!', 'ru') == 'Privet mir!'

# Generated at 2022-06-25 20:09:21.776728
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert callable(romanize(locale='ru')(romanize)(locale='ru'))
    assert callable(romanize('ru')(romanize)('ru'))
    assert UnsupportedLocale(locale='')


# Generated at 2022-06-25 20:09:24.662789
# Unit test for function romanize
def test_romanize():
    assert str(type(test_case_0)) == "<class 'function'>"


# Generated at 2022-06-25 20:09:25.530023
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:09:38.728309
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('kk')

# Generated at 2022-06-25 20:09:42.691928
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    translator = data.ROMANIZATION_DICT[locale]

    def _romanize(text, alphabet=translator):
        return text == ''.join([alphabet[i] for i in text])

    assert _romanize('Привет!')
    assert _romanize('Привет! Ты кто?')
    assert _romanize('Как дела?')
    assert _romanize('Пока.')
    assert _romanize('Я в курсе.')
    assert _romanize('Раскаленный, как ковёр')
    assert _romanize('Не в сети')


# Generated at 2022-06-25 20:09:51.744353
# Unit test for function romanize
def test_romanize():
    def callable_0(arg_0: str = '') -> str:
        return arg_0
    assert callable_0('Привет, мир!') == 'Привет, мир!'
    assert callable_0('хуй') == 'хуй'
    assert callable_0('Привет, хуй!') == 'Привет, хуй!'
    assert callable_0('Стив Джобс') == 'Стив Джобс'

# Generated at 2022-06-25 20:09:59.417370
# Unit test for function romanize
def test_romanize():
    # Create a mocker object that replaces the target function with a
    # mock object.
    from unittest.mock import Mock
    mocker = Mock()
    mocker.side_effect = lambda x: x

    # Create a decorator object.
    romanized_case_0 = romanize()

    # Wrap the mock object with the decorator.
    wrapped = romanized_case_0(mocker)

    # Call the wrapped function
    wrapped('english')
    mocker.assert_called_once_with('english')

    # Call the wrapped function
    wrapped('Русский')
    mocker.assert_called_with('Русский')

    # Call the wrapped function
    wrapped('Русский', 'english')
    mocker

# Generated at 2022-06-25 20:10:00.803630
# Unit test for function romanize
def test_romanize():
    assert callable_0


# Generated at 2022-06-25 20:10:04.233567
# Unit test for function romanize
def test_romanize():
    assert 'привет мир' == 'привет мир'


# Generated at 2022-06-25 20:10:08.923005
# Unit test for function romanize
def test_romanize():
    data_0 = romanize()
    callable_0 = romanize()
    assert isinstance(callable_0, (functools.partial, type(romanize)))
    assert isinstance(data_0, (functools.partial, type(romanize)))
    assert isinstance(callable_0, (functools.partial, type(romanize)))


# Generated at 2022-06-25 20:10:10.315463
# Unit test for function romanize
def test_romanize():
    romanize('aa')

# Generated at 2022-06-25 20:10:20.424779
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import (
        Person,
        Datetime,
    )
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet

    p = Person('ru')
    dt = Datetime('ru')

    romanize_0 = romanize('ru')
    callable_0 = romanize_0(Person.__init__)

    assert type(p._name.__init__) == type(Person.__init__)

    # Test case with Person
    assert p._name.__init__.__name__ == Person.__init__.__name__

    assert isinstance(p._name.__init__.__name__, str)

    assert isinstance(p.full_name(gender=Gender.MALE), str)


# Generated at 2022-06-25 20:10:30.862137
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None
    assert romanize('ru') is not None
    assert romanize('uk') is not None
    assert romanize('kk') is not None
    assert romanize('en') is not None
    assert romanize('it') is not None
    assert romanize('fr') is not None
    assert romanize('sp') is not None
    assert romanize('ar') is not None
    assert romanize('ja') is not None
    assert romanize('zh') is not None
    assert romanize('hi') is not None
    assert romanize('de') is not None
    assert romanize('fa') is not None
    assert romanize('gr') is not None
    assert romanize('la') is not None

# Generated at 2022-06-25 20:11:02.115309
# Unit test for function romanize
def test_romanize():
    # Tests
    result_1 = romanize('ru')('Привет, Вася!')
    assert result_1 == 'Privet, Vasya!'

    result_2 = romanize('uk')('Привіт, Вася!')
    assert result_2 == 'Pryvit, Vasya!'

    result_3 = romanize('kk')('Сәлем, Вася!')
    assert result_3 == 'Sälem, Vasya!'

    result_4 = romanize('kk')('Привет, Вася!')
    assert result_4 == 'Privet, Vasya!'


# Generated at 2022-06-25 20:11:12.804302
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize()
    assert romanize()
    assert romanize(locale='')
    assert romanize(locale='')
    assert romanize(locale='')
    assert romanize(locale='ru')
    assert romanize('ru')
    assert romanize(locale='ru')
    assert romanize('ru')
    assert romanize(locale='ru')
    assert romanize('ru')
    assert romanize(locale='kk')
    assert romanize('kk')
    assert romanize(locale='kk')
    assert romanize('kk')
    assert romanize(locale='uk')
    assert romanize('uk')
    assert romanize(locale='uk')
    assert roman

# Generated at 2022-06-25 20:11:13.684533
# Unit test for function romanize
def test_romanize():
    assert True

# Generated at 2022-06-25 20:11:14.533393
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:11:16.402980
# Unit test for function romanize
def test_romanize():
    result = romanize()
    assert result == NotImplemented


# Generated at 2022-06-25 20:11:17.780241
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:11:21.793279
# Unit test for function romanize
def test_romanize():
    def funct_0(*args):
        # Original signature: romanize(alphabet, text) -> str
        # Modified signature: romanize_0(text) -> str
        return romanize('ru')(args[1])
    assert funct_0('', 'текст') == 'tekst'
    assert funct_0('', 'число') == 'chislo'


# Generated at 2022-06-25 20:11:25.664157
# Unit test for function romanize
def test_romanize():
    assert 1 == 1
    assert romanize  # For coverage testing.
    assert romanized  # For coverage testing.
    assert test_case_0  # For coverage testing.

# Generated at 2022-06-25 20:11:33.799598
# Unit test for function romanize
def test_romanize():
    with pytest.raises(UnsupportedLocale) as exc_info:
        assert 'The locale "ru" is not supported.' == str(UnsupportedLocale('ru'))
    with pytest.raises(UnsupportedLocale) as exc_info:
        assert 'The locale "uk" is not supported.' == str(UnsupportedLocale('uk'))
    with pytest.raises(UnsupportedLocale) as exc_info:
        assert 'The locale "kk" is not supported.' == str(UnsupportedLocale('kk'))
    # assert 0
    # test_case_0()
    # print('[+] Test {}'.format(romanize.__name__))


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-25 20:11:37.569778
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')
    assert romanize()
    assert romanize('uk')

# Generated at 2022-06-25 20:12:36.193066
# Unit test for function romanize
def test_romanize():
    assert romanize('ru', 'text') == 'текст'

# Generated at 2022-06-25 20:12:37.663753
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())


# Generated at 2022-06-25 20:12:44.607356
# Unit test for function romanize
def test_romanize():
    final_result = romanize()('Абвгдеёжзийклмнопрстуфхцчшщъыьэюя')
    assert final_result == 'Abvgdeezhzijklmnoprstufhtschshshyieyuya'

# Generated at 2022-06-25 20:12:47.621839
# Unit test for function romanize
def test_romanize():
    assert romanize == romanized
    assert callable(romanize())
    assert callable(romanized())

# Generated at 2022-06-25 20:12:57.073180
# Unit test for function romanize
def test_romanize():
    locale = 'ru'

# Generated at 2022-06-25 20:12:58.188930
# Unit test for function romanize
def test_romanize():
    assert callable_0 == "trrst"

# Generated at 2022-06-25 20:12:59.914112
# Unit test for function romanize
def test_romanize():
    assert callable_0

if __name__ == '__main__':
    test_case_0()
    test_romanize()

# Generated at 2022-06-25 20:13:03.898757
# Unit test for function romanize
def test_romanize():
    # 1. Arrange
    locale = 'ru'
    result = 'Привет'

    # 2. Act
    callable_0 = romanize(locale)
    result = callable_0(result)

    # 3. Assert
    assert result == 'Privet', f"Expected 'Privet', got '{result}'"



# Generated at 2022-06-25 20:13:04.765045
# Unit test for function romanize
def test_romanize():
    assert True(romanize())

# Generated at 2022-06-25 20:13:16.361781
# Unit test for function romanize
def test_romanize():
    data.ROMANIZATION_DICT['ru'] = {'б': 'b', 'я': 'y'}
    data.COMMON_LETTERS = {'б': 'b'}
    data.ROMANIZATION_DICT['en'] = {'a': 'a', 'b': 'b'}
    assert romanize('ru')(lambda: "бббя")() == "bbby"
    assert romanized('ru')(lambda: "бббя")() == "bbby"
    assert romanize('en')(lambda: "a b")() == "a b"
    data.ROMANIZATION_DICT.pop('ru')
    data.COMMON_LETTERS.pop('б')
    data.ROMANIZATION_DICT.pop

# Generated at 2022-06-25 20:15:32.768024
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())

# Generated at 2022-06-25 20:15:33.540972
# Unit test for function romanize
def test_romanize():
    assert romanize() != None


# Generated at 2022-06-25 20:15:33.993123
# Unit test for function romanize
def test_romanize():
    assert True is True

# Generated at 2022-06-25 20:15:36.828730
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    p = Person('ru')
    s = p.full_name()
    assert p.full_name() == s
    assert p.full_name('ru') == s

# Generated at 2022-06-25 20:15:50.120795
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru') == romanize(locale='ru')
    assert romanize(locale='ru') == romanize(locale='uk')
    assert romanize(locale='ru') == romanize(locale='kk')

# Generated at 2022-06-25 20:15:51.884624
# Unit test for function romanize
def test_romanize():
    with pytest.raises(exceptions.UnsupportedLocale):
        assert romanize('capital') == 'capital'
    assert romanize('uk') == 'ukrainian'


# Generated at 2022-06-25 20:15:59.016687
# Unit test for function romanize
def test_romanize():
    assert callable_0('Привет, мир!') == 'Privet, mir!'
    assert callable_0('') == ''
    assert callable_0('qwerty') == 'qwerty'
    assert callable_0(12345678) == '12345678'
    assert callable_0('Привет, мир!') == 'Privet, mir!'
    assert callable_0(
        'Приглашаю вас на сайт http://mimesis.name') == 'Priglashayu vas na sait http://mimesis.name'

# Generated at 2022-06-25 20:16:01.224059
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    result = romanize(locale)
    assert result.__name__ == 'romanize_deco'
    assert callable(result)


# Generated at 2022-06-25 20:16:02.146525
# Unit test for function romanize
def test_romanize():
    pass
# unit test for function romanized

# Generated at 2022-06-25 20:16:03.317205
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None