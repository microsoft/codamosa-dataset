

# Generated at 2022-06-25 20:07:59.552566
# Unit test for function romanize
def test_romanize():
    # There's no need to test romanize decorator
    # itself because it uses tested string transliteration
    pass

# Generated at 2022-06-25 20:08:01.041368
# Unit test for function romanize
def test_romanize():
    try:
        test_case_0()
    except UnsupportedLocale:
        pass


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-25 20:08:07.731912
# Unit test for function romanize
def test_romanize():
    import unittest


    class TestCase(unittest.TestCase):

        def test_something_0(self):
            callable_0 = romanize()

    runner = unittest.TextTestRunner()
    runner.run(unittest.makeSuite(TestCase))
    # nosetests test_decorators.py



# Generated at 2022-06-25 20:08:13.323800
# Unit test for function romanize
def test_romanize():
    # Unit test for function romanize
    def func_0():
        # AssertionError: False is not true : Expected : True
        assert True
    assert callable(callable_0)
    # AssertionError: None != <function func_0 at 0x000002480F57B730>
    assert callable_0 != func_0



# Generated at 2022-06-25 20:08:14.291930
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())

# Generated at 2022-06-25 20:08:15.855619
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:08:24.596491
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')("Здравствуйте, мир!") == "Zdravstvuyte, mir!"
    assert romanize('uk')("Світ привіт") == "Svit pryvit"
    assert romanize('kk')("Сәлем, дүние!") == "Sälem, dünie!"

    assert romanize('ru')("Здравствуйте, мир!") == "Zdravstvuyte, mir!"
    assert romanize('uк')("Світ привіт") == "Svit pryvit"


# Generated at 2022-06-25 20:08:34.490052
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.enums import Locale
    from mimesis.enums import Gender

    person = Person(locale=Locale.RUSSIAN, gender=Gender.MALE)
    assert romanize()(person.full_name(gender=Gender.MALE)) == 'Pyotr Ivanov'
    assert romanize()(person.full_name(gender=Gender.FEMALE)) == 'Anna Petrovna'
    assert romanize()(person.username()) == 'ivanov.pyotr'

# Generated at 2022-06-25 20:08:36.329045
# Unit test for function romanize
def test_romanize():
    assert callable_0(None) is None

# Generated at 2022-06-25 20:08:38.064361
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_0(func=('Dąbrowski', 'Белый'))


# Generated at 2022-06-25 20:08:47.510294
# Unit test for function romanize
def test_romanize():
    translator = romanize()

    def callable_0(*args, **kwargs):
        return 'привет'

    assert translator(callable_0) == 'privet'

# Generated at 2022-06-25 20:08:48.885724
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:08:50.249734
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:08:51.589172
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())



# Generated at 2022-06-25 20:08:54.053819
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    result_0 = callable_0(str)
    assert isinstance(result_0, str) == True

# Generated at 2022-06-25 20:09:00.436298
# Unit test for function romanize
def test_romanize():

    def test_func():
        return 'Основы Java'

    test_func_ru = romanize('ru')(test_func)
    assert callable(test_func_ru)
    assert test_func_ru() == 'Osnovy Java'

# Generated at 2022-06-25 20:09:05.083884
# Unit test for function romanize
def test_romanize():
  import mimesis
  from mimesis.builtins.enums import Gender
  person = mimesis.Person('en')
  assert person.full_name(gender=Gender.FEMALE) == 'Jill F. Ellis'
  assert person.full_name(gender=Gender.MALE) == 'Bruce L. Springsteen'


# Generated at 2022-06-25 20:09:07.385055
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:09:09.864815
# Unit test for function romanize
def test_romanize():
    # Test for function romanize
    callable_0 = romanize()



# Generated at 2022-06-25 20:09:11.295241
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-25 20:09:25.728898
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanize()
    callable_0('Привет мир')
    callable_1('Привет мир')

# Generated at 2022-06-25 20:09:28.860094
# Unit test for function romanize
def test_romanize():
    test_case_0()


if __name__ == "__main__":
    test_romanize()

# Generated at 2022-06-25 20:09:29.781483
# Unit test for function romanize
def test_romanize():
    assert callable_0

# Generated at 2022-06-25 20:09:31.307681
# Unit test for function romanize
def test_romanize():
    callable = romanize()
    assert callable(lambda: 'Переведи меня'.lower())() == 'perevédi menyá'

# Generated at 2022-06-25 20:09:32.741056
# Unit test for function romanize
def test_romanize():
    # Call function romanize
    assert result == 'Universal Serial Bus'

# Generated at 2022-06-25 20:09:34.737201
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize(locale)
    callable_0(locale)

# Generated at 2022-06-25 20:09:47.306755
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None


    assert callable_0 is not None
    assert callable_0('a') == 'a'
    assert callable_0('а') == 'a'
    assert callable_0('А') == 'A'
    assert callable_0('b') == 'b'
    assert callable_0('б') == 'b'
    assert callable_0('Б') == 'B'
    assert callable_0('v') == 'v'
    assert callable_0('в') == 'v'
    assert callable_0('В') == 'V'
    assert callable_0('g') == 'g'
    assert callable_0('г') == 'g'
    assert callable_0('Г') == 'G'
    assert callable

# Generated at 2022-06-25 20:09:54.926888
# Unit test for function romanize
def test_romanize():
    # Testing romanize(locale)
    from mimesis.builtins import Person
    callable_0 = romanize()
    callable_1 = romanize()
    assert callable_0 != callable_1
    assert callable_0 != Person.name
    assert callable_0 != 'mimesis'
    assert callable_0 != []
    assert callable_0 != {}
    callable_0 = romanize()
    callable_1 = romanize()
    assert callable_0 != callable_1
    assert callable_0 != Person.name
    assert callable_0 != 'mimesis'
    assert callable_0 != []
    assert callable_0 != {}
    callable_0 = romanize()
    callable_1 = romanize()
    assert call

# Generated at 2022-06-25 20:09:55.411060
# Unit test for function romanize
def test_romanize():
    assert True == True

# Generated at 2022-06-25 20:09:59.447512
# Unit test for function romanize
def test_romanize():
    # Assert if the function is callable
    assert callable(romanize)


# Generated at 2022-06-25 20:10:21.846296
# Unit test for function romanize
def test_romanize():
    clazz = data.ROMANIZATION_DICT.__class__
    # Class of the returned object must be dict.
    assert clazz is dict

# Generated at 2022-06-25 20:10:25.564880
# Unit test for function romanize
def test_romanize():
    # Test that romanize fail without argument.
    try:
        romanize()
    except Exception as e:
        assert type(e) == TypeError



# Generated at 2022-06-25 20:10:27.432038
# Unit test for function romanize
def test_romanize():
    assert romanize.__doc__ is not None



# Generated at 2022-06-25 20:10:28.537678
# Unit test for function romanize
def test_romanize():
    with romanize() as romanizer:
        romanizer()

# Generated at 2022-06-25 20:10:36.979878
# Unit test for function romanize
def test_romanize():
    assert callable_0('Привет, Мир') == 'Privet, Mir'
    assert callable_0('Привет, Мир') == 'Privet, Mir', "Expected: 'Privet, Mir'"

test_case_0()
test_romanize()

# Generated at 2022-06-25 20:10:44.180358
# Unit test for function romanize
def test_romanize():
    import random
    import string

    assert romanize("US")("Привет") == "Privet"  # Assertion
    # Assertion if a russian string is given -> russian language is used
    assert romanize("RU")("Привет") == "Privet"
    # Assertion if a language is not supported
    try:
        romanize("DE")("Привет")
    except UnsupportedLocale as e:
        assert e.locale == "DE"  # Assertion

    symbols = list(data.ROMANIZATION_DICT["RU"].keys())
    for _ in range(10):
        word = "".join(random.sample(symbols, random.randint(1, 10)))
        assert r

# Generated at 2022-06-25 20:10:45.575678
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None


# Generated at 2022-06-25 20:10:46.515889
# Unit test for function romanize
def test_romanize():
    assert callable_0() == None

# Generated at 2022-06-25 20:10:52.738984
# Unit test for function romanize
def test_romanize():
    from mimesis import Address, Datetime, Person, Text

    person = Person('ru')
    person.full_name()
    person.full_name(gender='male')
    person.full_name(gender='female')
    person.username()

    address = Address('ru')
    address.address()
    address.city()
    address.country()
    address.country_code()
    address.street_name()
    address.street_suffix()
    address.timezone()

    datetime = Datetime('ru')
    datetime.date(tzinfo=True)
    datetime.datetime(tzinfo=True)
    datetime.datetime(start=0, stop=10, tzinfo=True)
    datetime.date_range(start=0, stop=10, tzinfo=True)


# Generated at 2022-06-25 20:10:55.389679
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0  # Type check
    # Type check for argument locale
    try:
        assert isinstance(str, str)
    except AssertionError:
        raise AssertionError('Argument type "str" does not match. This is argument 1 to function "romanize" declared in "tests/test_decorators.py".')

# Generated at 2022-06-25 20:11:47.985980
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda: 'Санкт-Петербург')() == "Санкт-Петербург"
    assert romanize('uk')(lambda: 'Санкт-Петербург')() == "Санкт-Петербург"
    assert romanize('kk')(lambda: 'Санкт-Петербург')() == "Санкт-Петербург"
    assert romanize('ru')(lambda: 'Лондон')() == "Лондон"

# Generated at 2022-06-25 20:11:49.065978
# Unit test for function romanize
def test_romanize():
    print('Test Passed')


test_case_0()
test_romanize()

# Generated at 2022-06-25 20:11:54.779116
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='')(romanize)() == romanize()
    assert romanize(locale='a')(romanize)() == romanize()
    assert romanize(locale='a')(romanize)() == romanize()
    assert romanize(locale='b')(romanize)() == romanize()
    assert romanize(locale='c')(romanize)() == romanize()
    assert romanize(locale='d')(romanize)() == romanize()
    assert romanize(locale='e')(romanize)() == romanize()
    assert romanize(locale='f')(romanize)() == romanize()
    assert romanize(locale='g')(romanize)() == romanize()

# Generated at 2022-06-25 20:11:56.232856
# Unit test for function romanize
def test_romanize():
    assert callable_0


# Generated at 2022-06-25 20:11:58.335615
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanized)


# Generated at 2022-06-25 20:12:04.282818
# Unit test for function romanize
def test_romanize():
    # If valid locale is given, then should return romanized text.
    romanized_text_0 = romanize('ru')(lambda: 'Привет')
    assert romanized_text_0() == 'Privet'

    # If invalid locale is given, then should raise UnsupportedLocale
    try:
        romanized_text_1 = romanize('x_x')(lambda: 'Привет')
    except UnsupportedLocale:
        pass

    # If no locale is given, then should return original text
    romanized_text_2 = romanize()(lambda: 'Привет')
    assert romanized_text_2() == 'Привет'

# Generated at 2022-06-25 20:12:06.623544
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0 is not None

# Generated at 2022-06-25 20:12:07.436307
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:12:09.453682
# Unit test for function romanize
def test_romanize():
    example_0()
    test_case_0()


# Generated at 2022-06-25 20:12:16.319622
# Unit test for function romanize
def test_romanize():
    # Arguments of callable_0: ()
    # Return value of callable_0: <function romanize_deco.<locals>.wrapper at 0x10d622a60>
    callable_0 = romanize()
    assert callable(callable_0)
    # Arguments of callable_1: ()
    # Return value of callable_1: <function romanize_deco.<locals>.wrapper at 0x10d622a60>
    callable_1 = romanize()
    assert callable(callable_1)
    # Arguments of callable_2: ()
    # Return value of callable_2: <function romanize_deco.<locals>.wrapper at 0x10d622a60>
    callable_2 = romanize()

# Generated at 2022-06-25 20:14:06.326258
# Unit test for function romanize
def test_romanize():
    pass  # TODO

# Generated at 2022-06-25 20:14:12.656201
# Unit test for function romanize
def test_romanize():
    # TODO: DRY
    @romanize(locale='ru')
    def callable_0():
        return 'абвгдежзийклмнопрстуфхцчшщъыьэюя'

    assert callable_0() == 'abvgdjezijklmnoprstufhzcss_y_eua'

    @romanize(locale='ru')
    def callable_1():
        return 'АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'

    assert call

# Generated at 2022-06-25 20:14:13.056716
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:14:13.641321
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:14:14.464160
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:14:16.337974
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    data = RussiaSpecProvider()
    inner_text = data.first_name() + ' ' + data.last_name()
    roman_text = data.romanize(inner_text)
    assert roman_text

# Generated at 2022-06-25 20:14:24.222944
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:14:24.838780
# Unit test for function romanize
def test_romanize():
    assert True

# Generated at 2022-06-25 20:14:26.173205
# Unit test for function romanize
def test_romanize():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-25 20:14:33.991159
# Unit test for function romanize
def test_romanize():
    data_0 = romanize('ru')(lambda : 'Тест')
    assert data_0 == 'Test'
    data_1 = romanize('ru')(lambda : 'Тест')
    assert data_1 == 'Test'
    data_2 = romanize('uk')(lambda : 'Тест')
    assert data_2 == 'Test'
    data_3 = romanize('kk')(lambda : 'Тест')
    assert data_3 == 'Test'
