

# Generated at 2022-06-25 20:08:00.142923
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привіт, світ!') == 'Pryvit, svit!'



# Generated at 2022-06-25 20:08:07.363188
# Unit test for function romanize
def test_romanize():
    fn0 = romanize('ru')(lambda: "АБВ")
    assert fn0() == "ABV"
    fn1 = romanize('kk')(lambda: "АБВ")
    assert fn1() == "ABV"
    fn2 = romanize('uk')(lambda: "АБВ")
    assert fn2() == "ABV"
    fn3 = romanize('uk')(lambda: "АБВГ")
    assert fn3() == "ABVG"
    fn4 = romanize('uk')(lambda: "АБВГД")
    assert fn4() == "ABVGD"
    fn5 = romanize('uk')(lambda: "АБВГДЕ")

# Generated at 2022-06-25 20:08:08.821130
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:08:10.355084
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')


# Generated at 2022-06-25 20:08:11.916853
# Unit test for function romanize
def test_romanize():
    assert data.ROMANIZATION_DICT['cz']['Д'] == 'D'


# Generated at 2022-06-25 20:08:14.659765
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

# Generated at 2022-06-25 20:08:16.840042
# Unit test for function romanize
def test_romanize():
    result = romanize()
    assert(result is not None)

# Generated at 2022-06-25 20:08:19.941520
# Unit test for function romanize
def test_romanize():
    assert romanize_deco() == 'привет как дела'


# Generated at 2022-06-25 20:08:21.850495
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0 == romanize()

# Generated at 2022-06-25 20:08:22.730562
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')


# Generated at 2022-06-25 20:08:33.044919
# Unit test for function romanize
def test_romanize():
    """Decorator for testing romanization."""
    @romanize(locale='ru')
    def russify():
        return 'Привет, мир!'

    assert russify() == 'Privet, mir!'


# Generated at 2022-06-25 20:08:33.879625
# Unit test for function romanize
def test_romanize():
    assert romanize()()



# Generated at 2022-06-25 20:08:36.121498
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)

# Generated at 2022-06-25 20:08:46.428055
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanize()
    callable_2 = romanize()
    callable_3 = romanize()
    callable_4 = romanize()
    callable_5 = romanize()
    callable_6 = romanize()
    callable_7 = romanize()
    callable_8 = romanize()
    callable_9 = romanize()
    callable_10 = romanize()
    callable_11 = romanize()
    callable_12 = romanize()
    callable_13 = romanize()
    callable_14 = romanize()
    callable_15 = romanize()
    callable_16 = romanize()
    callable_17 = romanize()
   

# Generated at 2022-06-25 20:08:47.898557
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-25 20:08:57.266489
# Unit test for function romanize
def test_romanize():

    # Asserting if romanize is callable
    assert callable(romanize)

    # Asserting if romanize is callable
    assert callable(romanize_deco)

    # Asserting if romanize is callable
    assert callable(romanize_0)

    # Asserting if romanize is callable
    assert callable(romanize_1)

    # Asserting if romanize is callable
    assert callable(romanize_2)

    # Asserting if romanize is callable
    assert callable(romanize_3)

    # Asserting if romanize is callable
    assert callable(romanize_4)

    # Asserting if romanize is callable
    assert callable(romanize_5)

    # Asserting if roman

# Generated at 2022-06-25 20:08:58.290767
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:09:00.784379
# Unit test for function romanize
def test_romanize():
    """Test function romanize."""
    assert romanize()


# Generated at 2022-06-25 20:09:09.023421
# Unit test for function romanize
def test_romanize():
    assert 'М' == romanize('')('М')
    assert 'новый' == romanize('')('новый')
    assert 'Ю' == romanize('')('Ю')
    assert 'ви' == romanize('')('ви')
    assert 'флі' == romanize('')('флі')
    assert 'коп' == romanize('')('коп')
    assert 'з' == romanize('')('з')
    assert 'мов' == romanize('')('мов')
    assert 'о' == romanize('')('о')
    assert 'м' == romanize('')('м')
    assert 'е'

# Generated at 2022-06-25 20:09:17.663090
# Unit test for function romanize
def test_romanize():
    # check for single char
    from mimesis.builtins import Cyrillic
    from string import ascii_letters, digits, punctuation

    cyrillic = Cyrillic('ru')

    alphabet = {s: s for s in ascii_letters + digits + punctuation}
    alphabet.update({
        **data.ROMANIZATION_DICT[cyrillic.locale],
        **data.COMMON_LETTERS,
    })
    assert cyrillic.romanize('Ю') == alphabet[cyrillic.letter('Ю')] == 'Ju'
    assert cyrillic.romanize('О') == alphabet[cyrillic.letter('О')] == 'O'



# Generated at 2022-06-25 20:09:28.299353
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    result = romanize(locale)


# Generated at 2022-06-25 20:09:31.579805
# Unit test for function romanize
def test_romanize():
    # Test for romanize
    def test_case_0():
        callable_0 = romanize()


# Generated at 2022-06-25 20:09:35.509782
# Unit test for function romanize
def test_romanize():
    test_input = 'АБВ'.encode('utf-8')
    test_result='ABV'
    assert romanize()(test_input)==test_result

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-25 20:09:37.159831
# Unit test for function romanize
def test_romanize():
    text = "Привет, мир!"
    assert romanize("ru")(lambda x: text)() == "Privet, mir!"



# Generated at 2022-06-25 20:09:40.461592
# Unit test for function romanize
def test_romanize():
    examples = [
        ('foo', 'foo'),
        ('Да', 'Da'),
        ('Привет', 'Privet'),
        ('Альфа', 'Alfa'),
        ('Бета', 'Beta'),
        ('Гамма', 'Gamma')
    ]
    for example in examples:
        assert callable_0(example[0]) == example[1]


# Generated at 2022-06-25 20:09:41.389864
# Unit test for function romanize
def test_romanize():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 20:09:42.000313
# Unit test for function romanize
def test_romanize():
    pass
    # assert your test

# Generated at 2022-06-25 20:09:44.651941
# Unit test for function romanize
def test_romanize():
    assert callable_0()
    assert romanize_0()

    assert romanize_0()
    assert callable_0()


# Generated at 2022-06-25 20:09:45.453791
# Unit test for function romanize
def test_romanize():
    print(type(romanize))


# Generated at 2022-06-25 20:09:57.423540
# Unit test for function romanize
def test_romanize():
    # Define a dictionary containing input
    # parameter's to be passed to function
    test_cases = [{'locale': 'ru'}]

    # Iterate over each test case and make assertions
    count = 0
    for test_case in test_cases:
        count += 1
        result = romanize(**test_case)
        romanize_deco = romanize(**test_case)
        func = romanize_deco(lambda: 'test regex')
        resp = func()

        # Check for expected output
        assert result != None, 'Test Case #' + str(count) + ', Expected Output is not None.'
        assert func != None, 'Test Case #' + str(count) + ', Expected Output is not None.'

        # Check for expected data type

# Generated at 2022-06-25 20:10:20.854135
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет, Мир!') == 'Privet, Mir!'



# Generated at 2022-06-25 20:10:30.986068
# Unit test for function romanize

# Generated at 2022-06-25 20:10:39.137820
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanized)
    assert callable_0('Петрович') == 'Petrovich'
    assert callable_0('Князева') == 'Knyazeva'
    assert callable_0('Борисоглебск') == 'Borissoglebsk'

# Generated at 2022-06-25 20:10:41.374302
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')

# Generated at 2022-06-25 20:10:42.761834
# Unit test for function romanize
def test_romanize():
    test_case_0()



# Generated at 2022-06-25 20:10:44.330614
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None, 'Function did not return value.'

# Test if romanization works, see issue #316

# Generated at 2022-06-25 20:10:49.958002
# Unit test for function romanize
def test_romanize():
    # Confirm the `romanize` decorator properly decorates the callable
    # `callable_with_0`
    assert callable_0.__name__ == 'callable_0'
    # Confirm the wrapped function properly propagates the original
    # docstring of `callable_with_0`
    assert callable_0.__doc__ == 'This is a callable'

# Generated at 2022-06-25 20:10:58.164382
# Unit test for function romanize
def test_romanize():
    result_romanization = "Febrvar' iel' 'stranno"
    callable_1 = romanize()
    assert callable_1(result_romanization) ==  "Фебрар' ийс' 'странно"


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:11:03.932692
# Unit test for function romanize
def test_romanize():
    @romanize(locale='kk')
    def func1():
        return 'hjgj'

    assert func1() == 'hjgj'

    # test locale
    @romanize(locale='kk')
    def func2():
        return 'привет'

    assert func2() == 'privet'

    @romanize(locale='ru')
    def func3():
        return 'привет'

    assert func3() == 'privet'

    @romanize(locale='uk')
    def func4():
        return 'привет'

    assert func4() == 'privet'

    # test locale
    @romanize(locale='uk')
    def func5():
        return 'привіт'



# Generated at 2022-06-25 20:11:05.365042
# Unit test for function romanize
def test_romanize():
    assert True == True


# Generated at 2022-06-25 20:11:57.109728
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:11:58.679270
# Unit test for function romanize
def test_romanize():
    assert callable(romanize) is True

# Generated at 2022-06-25 20:12:04.523201
# Unit test for function romanize
def test_romanize():
    func_0 = romanize()

    def func_1(*args, **kwargs):
        return 'большая новость из края'

    func_1 = func_0(func_1)
    assert func_1() == 'bolʹšaja novostʹ iz kraja'

    def func_2(*args, **kwargs):
        return "ТАКАЯ ТЕСТОВАЯ ФРАЗА"

    func_2 = func_0(func_2)
    assert func_2() == "takaja testovaja fraza"


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 20:12:07.834464
# Unit test for function romanize
def test_romanize():
    assert callable_0() == None
    assert romanize_deco() == None
    assert wrapper() == None

# Generated at 2022-06-25 20:12:09.860057
# Unit test for function romanize
def test_romanize():
    c = romanize()
    c = romanized()

# Generated at 2022-06-25 20:12:10.494143
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())


# Generated at 2022-06-25 20:12:12.753845
# Unit test for function romanize
def test_romanize():
    func = lambda _ : 'Romanize me!'
    decorated = romanize()(func)
    assert (decorated() == 'Romanize me!')

test_case_0()
test_romanize()

# Generated at 2022-06-25 20:12:16.456416
# Unit test for function romanize
def test_romanize():
    assert callable_0("ru")("function_name") == "function_name"

# Generated at 2022-06-25 20:12:25.430368
# Unit test for function romanize

# Generated at 2022-06-25 20:12:27.765899
# Unit test for function romanize
def test_romanize():
    assert callable_0('Привет, друг!') == 'Privet, drug!'

# Generated at 2022-06-25 20:14:24.698245
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')

# Generated at 2022-06-25 20:14:26.065285
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize('ru')


# Generated at 2022-06-25 20:14:33.991632
# Unit test for function romanize
def test_romanize():
    def romanize_0(arg_0, arg_1):
        """Docstring."""
        pass
    assert callable(romanize_0)
    assert romanize_0.__name__ == 'romanize_0'
    assert romanize_0.__doc__ == 'Docstring.'
    assert romanize_0.__annotations__ == {}
    assert hasattr(romanize_0, '__wrapped__')
    assert romanize_0.__wrapped__.__name__ == 'romanize_0'
    assert romanize_0.__wrapped__.__doc__ == 'Docstring.'
    assert romanize_0.__wrapped__.__annotations__ == {}
    assert hasattr(romanize_0, __name__)

# Generated at 2022-06-25 20:14:35.066897
# Unit test for function romanize
def test_romanize():
    assert callable_0(None) == "Romanized text."

# Generated at 2022-06-25 20:14:36.607925
# Unit test for function romanize
def test_romanize():
    try:
        assert romanize()
    except NotImplementedError as e:
        raise e

# Generated at 2022-06-25 20:14:40.449462
# Unit test for function romanize
def test_romanize():
    print(ascii_letters, digits, punctuation)
    txt = 'Это слово в Альфабете'
    romanized_txt = romanize()(lambda x: txt)

# Generated at 2022-06-25 20:14:46.500813
# Unit test for function romanize
def test_romanize():
    sc = romanize('ru')
    def test():
        return 'ПРИВЕТ'

    test = sc(test)
    assert test() == 'PRIVET'

    sc = romanize('uk')
    def test():
        return 'ПРИВІТ'

    test = sc(test)
    assert test() == 'PRIVIT'

    sc = romanize('kk')
    def test():
        return 'СӘЛЕМ'

    test = sc(test)
    assert test() == 'SALEM'


# Generated at 2022-06-25 20:14:52.997895
# Unit test for function romanize
def test_romanize():

    @romanize(locale='ru')
    def romanize_function_0():
        return 'Русский'

    result = romanize_function_0()
    assert result == 'Russkiy'

    @romanize('uk')
    def romanize_function_1():
        return 'Українська'

    result = romanize_function_1()
    assert result == 'Ukrainska'

# Generated at 2022-06-25 20:14:59.185082
# Unit test for function romanize
def test_romanize():
    """Test if the romanize decorator works properly."""
    result = romanized('ru')(lambda: 'может')()
    assert result == 'mozhet'

    result = romanized('ru')(lambda: 'булочка')()
    assert result == 'bulochka'

    result = romanized('ru')(lambda: 'паперти')()
    assert result == 'paeperty'

    result = romanized('uk')(lambda: 'Хрипуча віста')()
    assert result == 'Khypriucha vista'

    result = romanized('kk')(lambda: 'барамыз')()
    assert result == 'baramys'

# Generated at 2022-06-25 20:15:01.930068
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.localization import Localization

    lo = Localization(locale='ru')
    result = lo.romanize('Русский')
    assert result == 'Russkiy'

