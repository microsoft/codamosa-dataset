

# Generated at 2022-06-25 20:07:58.724428
# Unit test for function romanize
def test_romanize():
    locale = "ru"
    assert romanize(locale)

# Unit tests for function romanized

# Generated at 2022-06-25 20:08:01.189416
# Unit test for function romanize
def test_romanize():
    assert romanize('kk')('Hello, world!') == 'Hello, world!'


# Generated at 2022-06-25 20:08:02.556448
# Unit test for function romanize
def test_romanize():
    assert romanize()


if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-25 20:08:14.526246
# Unit test for function romanize
def test_romanize():
    func = lambda s: s

    assert callable(romanize) is True
    assert callable(romanize(None)) is True

    f = romanize()(func)
    assert f('hello') == 'hello'

    f = romanize('ru')(func)
    assert f('hello') == 'hello'

    f = romanize('ru')(func)
    assert f('привет') == 'privet'

    f = romanize('uk')(func)
    assert f('привіт') == 'privit'

    f = romanize('kk')(func)
    assert f('салем') == 'salem'

    f = romanize('kk')(func)
    assert f('сәлем') == 'salem'

# Generated at 2022-06-25 20:08:24.951360
# Unit test for function romanize
def test_romanize():
    import pytest

    values = {
        'ru': 'переведи это просто на латиницу',
        'uk': 'перекласти це просто на латиницю',
        'kk': 'әліпби әрі жүріп латынға аудар',
    }

# Generated at 2022-06-25 20:08:36.377183
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0
    callable_0 = romanize()
    assert callable_0
    callable_0 = romanize()
    assert callable_0
    callable_0 = romanize()
    assert callable_0
    callable_0 = romanize()
    assert callable_0
    callable_0 = romanize()
    assert callable_0
    callable_0 = romanize()
    assert callable_0
    callable_0 = romanize()
    assert callable_0
    callable_0 = romanize()
    assert callable_0
    callable_0 = romanize()
    assert callable_0
    callable_0 = romanize()
    assert callable_0
   

# Generated at 2022-06-25 20:08:46.533467
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize('ru')

    def func_1():
        return 'Привет'

    func_1_result_0 = func_1()

    assert func_1_result_0 == 'Привет'

    func_1_result_1 = callable_1(func_1)()

    assert func_1_result_1 == 'Privet'

    callable_2 = romanize('uk')

    def func_2():
        return 'Привіт'

    func_2_result_0 = func_2()

    assert func_2_result_0 == 'Привіт'

    func_2_result_1 = callable_2(func_2)()

    assert func_2_result_1

# Generated at 2022-06-25 20:08:51.936132
# Unit test for function romanize
def test_romanize():
    assert romanize()  # make sure we can call to the function
    assert romanize()(lambda x: 'я')  # make sure we can create a decorator
    assert romanize()(lambda x: 'я')() == 'ya'  # make sure we can call the decorator

# Generated at 2022-06-25 20:08:53.083044
# Unit test for function romanize
def test_romanize():
    print(romanize)
    print(romanized)

# Generated at 2022-06-25 20:08:53.967207
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:09:01.897295
# Unit test for function romanize
def test_romanize():

    result = romanize('')(str)
    assert isinstance(result(), str) is True



# Generated at 2022-06-25 20:09:04.196882
# Unit test for function romanize
def test_romanize():
    assert callable_0.__name__ == 'wrapper'
    assert callable_0.__doc__ == "Romanize the cyrillic text."

# Generated at 2022-06-25 20:09:07.091034
# Unit test for function romanize
def test_romanize():
    test_case_0()

# Benchmark test for function romanize

# Generated at 2022-06-25 20:09:14.588648
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize('ru')
    callable_1 = romanize('uk')
    callable_2 = romanize('kk')
    with pytest.raises(UnsupportedLocale):
        romanize('unsupported')

    assert callable_0('test') == 'test'
    assert callable_1('test') == 'test'
    assert callable_2('test') == 'test'



# Generated at 2022-06-25 20:09:25.621348
# Unit test for function romanize
def test_romanize():
    #assert romanize()(lambda: 'кириллица')() == 'kyrillitsa'
    #assert romanize(locale='uk')(lambda: 'кириллица')() == 'kyrillitsa'
    assert romanize(locale='ru')(lambda: 'кириллица')() == 'kirillitsa'
    #assert romanize(locale='kk')(lambda: 'кириллица')() == 'kirillitsa'

# Generated at 2022-06-25 20:09:27.528564
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None


# Generated at 2022-06-25 20:09:30.898895
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda :'Привет,мир!')() == 'Privet,mir!'

# Generated at 2022-06-25 20:09:39.102061
# Unit test for function romanize
def test_romanize():
    # Test 1
    assert romanize('ru')(lambda: 'Общественное мнение') == 'Obshestvennoe mnenie'

    # Test 2
    assert romanize('ru')(lambda: 'Республика Саха (Якутия)') == \
           'Respublika Saha (Yakutiya)'

    # Test 3
    assert romanize('uk')(lambda: 'Голос народу') == 'Holos narodu'

    # Test 4

# Generated at 2022-06-25 20:09:39.903137
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:09:45.109915
# Unit test for function romanize
def test_romanize():
    # In this Module, the function romanize is used to
    # romanize a cyrillic text, but it has nothing to do with
    # a "romanian" locale.
    # The result of the test is that the cyrillic text is transliterated
    # using the existing romanization dictionary.
    assert romanize(locale='ro')(lambda: 'Я УКРАИНЕЦ')() == 'YA UKRAINEZ'

# Generated at 2022-06-25 20:09:58.130070
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-25 20:10:03.657132
# Unit test for function romanize
def test_romanize():
    # Unit test for function romanize
    def test_0():
        # test for romanize
        from mimesis.datetime import Datetime
        from mimesis.enums import Gender
        from mimesis.providers.person import Person

        p = Person('en')
        d = Datetime('en')
        d.datetime(
            start=p.birthday(minimum=18, gender=Gender.MALE),
            end=d.now(),
            timezone=None,
        )

    # Unit test for function romanize
    def test_1():
        # test for romanize
        from mimesis.builtins import Person
        from mimesis.locales import en

        Person('en').full_name()

    # Unit test for function romanize

# Generated at 2022-06-25 20:10:05.695539
# Unit test for function romanize
def test_romanize():
    assert callable_0('abcdefg') == 'abcdefg'

# Generated at 2022-06-25 20:10:07.457116
# Unit test for function romanize
def test_romanize():
    assert romanize_deco == 'romanize_deco'
    assert decorated_func == 'decorated_func'
    
    

# Generated at 2022-06-25 20:10:15.144320
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import CyrillicText

    ct = CyrillicText('ru')
    ct_text = ct.word(quantity=10)
    assert isinstance(ct_text, str)
    assert len(ct_text) == 10
    assert isinstance(ct_text, str)


# Generated at 2022-06-25 20:10:16.601344
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    romanize()

# Generated at 2022-06-25 20:10:18.365897
# Unit test for function romanize
def test_romanize():
    assert(romanize()('Привет, мир')) == 'Privet, mir'

# Generated at 2022-06-25 20:10:20.073106
# Unit test for function romanize
def test_romanize():
    assert romanize(locale=None) is not None

# Generated at 2022-06-25 20:10:22.041812
# Unit test for function romanize
def test_romanize():
    result = romanize()
    assert result == romanize

# Generated at 2022-06-25 20:10:26.128902
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    text = Text()
    frase = text.sentence(locale='ru')
    text.romanize(frase,locale='ru')

# Generated at 2022-06-25 20:10:46.970217
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'

# Generated at 2022-06-25 20:10:47.698718
# Unit test for function romanize
def test_romanize():
    test_case_0()

# Generated at 2022-06-25 20:10:49.937883
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:10:53.901820
# Unit test for function romanize
def test_romanize():
    # Test 1
    callable_0 = romanize()

    # Test 2
    callable_0 = romanize(locale='')

# Generated at 2022-06-25 20:11:02.654218
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.providers.person import Person
    from mimesis.providers.language import Language
    from mimesis.providers.text import Text

    # Tests for person
    p = Person(Locale.UKRAINIAN)
    assert not p.first_name().isalpha()
    first_name = p.first_name(romanized=True)
    assert first_name.isalpha()
    last_name = p.last_name(romanized=True)
    assert last_name.isalpha()
    full_name = p.full_name(romanized=True)
    assert full_name.isalpha()

    # Tests for language
    l = Language(Locale.UKRAINIAN)
    l.romanized = True
    l_name = l

# Generated at 2022-06-25 20:11:09.682772
# Unit test for function romanize
def test_romanize():
    assert romanize()("фыввыффыв") == 'fyywyyfyfywy'
    assert romanize("uk")("фыввыффыв") == 'fyyvyyfyfyvy'
    assert romanize("kk")("абвгдежзийклмнопрстуфхцчшщъыьэюя") == 'abwgdeeziyklmnoprstufhtschschschyyeiuiia'

# Generated at 2022-06-25 20:11:13.476963
# Unit test for function romanize
def test_romanize():
    # Test for the existence of the function
    assert callable(test_case_0) == True



# Generated at 2022-06-25 20:11:14.872912
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-25 20:11:20.107618
# Unit test for function romanize
def test_romanize():
    """ Unit test for function romanize. """
    expected_0 = 'test'

    def function_0():
        return 'test'

    decorated_0 = romanize()(function_0)
    actual_0 = decorated_0()
    assert actual_0 == expected_0


# Generated at 2022-06-25 20:11:30.457930
# Unit test for function romanize
def test_romanize():
    from itertools import romanize

    callable_0 = romanize(str)
    assert callable_0('Добрий вечір') == 'Dobryi vechir'
    assert callable_0('Добрый день') == 'Dobryi den'
    assert callable_0('Салам Алейкум') == 'Salam Alejkuum'



# Generated at 2022-06-25 20:12:26.029824
# Unit test for function romanize
def test_romanize():
    romanize()

# Generated at 2022-06-25 20:12:27.092621
# Unit test for function romanize
def test_romanize():
    test_case_0()

# Generated at 2022-06-25 20:12:31.671013
# Unit test for function romanize
def test_romanize():
    # Test empty arg
    assert romanize()
    # Test regular arg
    assert romanize('uk')
    # Test unknown locale
    assert romanize('🐵')

# Generated at 2022-06-25 20:12:38.249082
# Unit test for function romanize
def test_romanize():
    assert (romanized(str)('Привет, Мир!') == 'Privet, Mir!')
    assert (romanized(str)('Привет, Мир!') == 'Privet, Mir!')


# Generated at 2022-06-25 20:12:39.581705
# Unit test for function romanize
def test_romanize():
    pass # TODO


# Generated at 2022-06-25 20:12:44.387675
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    str_0 = callable_0(str())
    str_1 = callable_0(str())
    str_2 = callable_0(str())
    str_3 = callable_0(str())

# Generated at 2022-06-25 20:12:56.179702
# Unit test for function romanize
def test_romanize():
    assert callable_0(lambda : None) is None
    assert callable_0(lambda : True) is True
    assert callable_0(lambda : False) is False
    assert callable_0(lambda : 0) == 0
    assert callable_0(lambda : 1) == 1
    assert callable_0(lambda : 0.0) == 0.0
    assert callable_0(lambda : 0.5) == 0.5
    assert callable_0(lambda : '0') == '0'
    assert callable_0(lambda : '1') == '1'
    assert callable_0(lambda : '0.0') == '0.0'
    assert callable_0(lambda : '0.5') == '0.5'
    assert callable_0(lambda : str) is str
    assert call

# Generated at 2022-06-25 20:12:57.034097
# Unit test for function romanize
def test_romanize():
    assert callable(test_case_0)

# Generated at 2022-06-25 20:12:58.368520
# Unit test for function romanize
def test_romanize():
    # Preserve function test_case_0
    callable_0 = romanize()
    assert issubclass(type(callable_0), type(romanize))


# Generated at 2022-06-25 20:13:01.903532
# Unit test for function romanize
def test_romanize():
    for i in range(0, 100):
        # Callable object 'callable_0' created
        # from decorator 'romanize'
        callable_0 = romanize()
        # TypeError raised
        assert callable(callable_0)


# Generated at 2022-06-25 20:15:15.771219
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    # assert romanize('kk')
    # assert romanize('az')

    assert romanized('ru')
    assert romanized('uk')
    # assert romanized('kk')
    # assert romanized('az')

# Generated at 2022-06-25 20:15:16.833213
# Unit test for function romanize
def test_romanize():
    assert romanize() != None
    assert romanized() != None


# Generated at 2022-06-25 20:15:18.806773
# Unit test for function romanize
def test_romanize():
    assert callable_0

# Generated at 2022-06-25 20:15:20.586736
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:15:22.371907
# Unit test for function romanize
def test_romanize():
    assert romanize("ru")("Славянский") == 'Slavyanskiy'


# Generated at 2022-06-25 20:15:23.433101
# Unit test for function romanize
def test_romanize():
    assert callable_0() == callable_0()

# Generated at 2022-06-25 20:15:24.712623
# Unit test for function romanize
def test_romanize():
    locale = 'en'
    assert romanize(locale)

# Generated at 2022-06-25 20:15:30.632515
# Unit test for function romanize
def test_romanize():
    """Test for function romanize."""
    assert romanize("en")("The") == "The"
    assert romanize("ru")("Новая") == "Novaia"
    assert romanize("ru")("Привет, мир!") == "Privet, mir!"
    assert romanize("ru")("Привет, мир!") == "Privet, mir!"
    assert romanize("ru")("Как дела?") == "Kak dela?"
    assert romanize("ru")("Как дела?") == "Kak dela?"
    assert romanize("ru")("Пока.") == "Poka."
    assert romanize("ru")

# Generated at 2022-06-25 20:15:32.389157
# Unit test for function romanize
def test_romanize():
    assert test_case_0() == None

# Generated at 2022-06-25 20:15:34.499920
# Unit test for function romanize
def test_romanize():
    assert callable_0(lambda: 'text') == 'text'
    assert callable_0(lambda: 'текст') == 'tekst'