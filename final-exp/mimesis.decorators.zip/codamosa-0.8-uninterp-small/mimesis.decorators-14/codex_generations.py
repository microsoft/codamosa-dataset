

# Generated at 2022-06-25 20:07:58.812224
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:08:04.520504
# Unit test for function romanize
def test_romanize():
    result = romanize(locale='ru')(lambda: 'Привет')
    assert result == 'Privet'

    result = romanize(locale='uk')(lambda: 'Привіт')
    assert result == 'Pryvit'

    result = romanize(locale='kk')(lambda: 'Сәлеметсіз бе')
    assert result == 'Sälemetsiz be'

# Generated at 2022-06-25 20:08:05.475201
# Unit test for function romanize
def test_romanize():
    assert callable_0 == romanize_deco



# Generated at 2022-06-25 20:08:07.599102
# Unit test for function romanize
def test_romanize():
    def wrapper():
        import ipdb
        ipdb.set_trace()
        return 'Привет мир!'

    result = wrapper()
    assert result == 'Привет мир!'

# Generated at 2022-06-25 20:08:09.038282
# Unit test for function romanize
def test_romanize():
    test_case_0()

# Generated at 2022-06-25 20:08:10.414206
# Unit test for function romanize
def test_romanize():
    assert callable_0() == 0

# Generated at 2022-06-25 20:08:15.386587
# Unit test for function romanize
def test_romanize():
    # Test function
    test_function = data.Romanization._romanize

    # Function
    function = test_function

    # Check
    # Test error
    with pytest.raises(NotImplementedError):
        function(None, None)

    # Test unsupported locale
    with pytest.raises(UnsupportedLocale):
        function('test', 'test')

    # Test supported locale
    assert function('test', 'uk') == 'test'



# Generated at 2022-06-25 20:08:16.123074
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

# Generated at 2022-06-25 20:08:18.029328
# Unit test for function romanize
def test_romanize():
    assert "ab" == romanize()('ab')

# Generated at 2022-06-25 20:08:19.509157
# Unit test for function romanize
def test_romanize():
    assert callable_0 is functools.update_wrapper(callable_0, functools.wraps)

# Generated at 2022-06-25 20:08:30.857211
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussianSpecProvider
    rus = RussianSpecProvider()
    value = rus.full_name()

    assert isinstance(value, str)
    assert isinstance(test_case_0, Callable)
    test_case_0()
# test_romanize

# Generated at 2022-06-25 20:08:32.359589
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    b = callable_0("mimesis")
    assert b.__eq__('mimesis')


# Generated at 2022-06-25 20:08:33.228469
# Unit test for function romanize
def test_romanize():
    test_case_0()

# Generated at 2022-06-25 20:08:45.643106
# Unit test for function romanize
def test_romanize():
    from mimesis.enums import Locale
    from mimesis.builtins.random import Random

    r = Random(Locale.RUSSIAN)
    str_0 = r.pystring(r.null_byte())
    str_1 = romanize()(str_0)
    assert isinstance(str_0, type(str_1))
    str_2 = r.pystring(r.null_byte())
    str_3 = romanize()(str_2)
    assert isinstance(str_2, type(str_3))
    str_4 = r.pystring(r.null_byte())
    str_5 = romanize()(str_4)
    assert isinstance(str_4, type(str_5))
    str_6 = r.pystring(r.null_byte())

# Generated at 2022-06-25 20:08:51.659016
# Unit test for function romanize
def test_romanize():
    num_0 = functools.partial(romanize, locale='ru')
    num_1 = functools.partial(romanize, locale='en')
    assert num_0(None) is None
    assert callable(num_1(None))
    assert num_1(None) is None

# Generated at 2022-06-25 20:08:57.930010
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins import RussiaSpecProvider

    provider = RussiaSpecProvider

    assert provider.romanian(locale='ro') == 'Ivanov Ivan'
    assert provider.romanian(locale='md') == 'Ivanov Ivan'
    assert provider.romanian(locale='ru') == 'Иванов Иван'
    assert provider.romanian(locale='uk') == 'Іванов Іван'
    assert provider.romanian(locale='kk') == 'Иванов Иван'
    assert provider.romanian(locale='invalid') == 'Ivanov Ivan'



# Generated at 2022-06-25 20:08:59.986112
# Unit test for function romanize
def test_romanize():
    test_case_0()

# Generated at 2022-06-25 20:09:01.336218
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)


# Generated at 2022-06-25 20:09:05.936866
# Unit test for function romanize
def test_romanize():
    assert romanize()('Привет') == 'Privet'
    assert romanize('ru')('Привет') == 'Privet'
    assert romanize('uk')('Привет') == 'Pryvit'
    assert romanize('kk')('Привет') == 'Privyet'

# Generated at 2022-06-25 20:09:07.201658
# Unit test for function romanize
def test_romanize():
    assert len(romanize()) > 0

# Generated at 2022-06-25 20:09:19.149529
# Unit test for function romanize
def test_romanize():
    assert romanized(locale='ru') is not None

# Generated at 2022-06-25 20:09:20.715285
# Unit test for function romanize
def test_romanize():
    def romanize_0():
        assert True

# Generated at 2022-06-25 20:09:24.274857
# Unit test for function romanize
def test_romanize():
    x = 'Привет'
    assert romanize()(x) == 'Privet'



# Generated at 2022-06-25 20:09:26.487358
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    result = callable_0(result)
    assert result == 'nVyfFJyq'


# Generated at 2022-06-25 20:09:29.845545
# Unit test for function romanize
def test_romanize():
    result1 = romanize_deco()
    result2 = romanize_deco()
    assert result1 == result2


# Generated at 2022-06-25 20:09:30.477130
# Unit test for function romanize
def test_romanize():
    assert romanize()



# Generated at 2022-06-25 20:09:36.558782
# Unit test for function romanize
def test_romanize():
    from mimesis.providers.address import Address
    romanize_ = romanize()
    assert romanize_ is not None
    assert isinstance(romanize_, type)

    addr = Address('en')
    assert isinstance(addr, Address)
    assert addr.postal_code() is not None
    assert addr.state() is not None
    assert addr.country() is not None
    assert addr.city() is not None


# Generated at 2022-06-25 20:09:40.385854
# Unit test for function romanize
def test_romanize():
    result = romanize(locale='')(lambda: 'Казахстан')

    assert result == 'Kazakhstan'



# Generated at 2022-06-25 20:09:42.466938
# Unit test for function romanize
def test_romanize():
    print(romanize())

# Unit tests for romanized()

# Generated at 2022-06-25 20:09:44.405119
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('А') == 'A'


# Generated at 2022-06-25 20:10:13.517469
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    assert romanize('ru') is not None
    assert romanize('uk') is not None
    assert romanize('ru') is not False
    assert romanize('uk') is not False
    assert callable(romanize('ru'))
    assert callable(romanize('uk'))
    assert romanize('ru')(type) == romanize('uk')(type)
    assert romanize('ru')(object) == romanize('uk')(object)
    assert romanize('ru')(str) == romanize('uk')(str)
    assert romanize('ru')(bytes) == romanize('uk')(bytes)
    assert romanize('ru')(bytes) == romanize('uk')(bytes)

# Generated at 2022-06-25 20:10:17.396180
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import get_word
    result = get_word()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:10:19.837279
# Unit test for function romanize
def test_romanize():
    # Test case 1
    alphabet = {
        s: s for s in ascii_letters + digits + punctuation}
    alphabet.update(**data.ROMANIZATION_DICT['ru'])
    alphabet.update(data.COMMON_LETTERS)

# Test case 4

# Generated at 2022-06-25 20:10:22.976125
# Unit test for function romanize
def test_romanize():
    dummy_callable = lambda: None
    assert hasattr(romanize(), '__call__')
    assert hasattr(romanize, '__call__')
    assert hasattr(romanize, '__module__')
    assert romanize.__module__ == 'mimesis.builtins.decorators'
    assert romanize('ru')(dummy_callable)() == dummy_callable()


# Generated at 2022-06-25 20:10:25.164724
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()



# Generated at 2022-06-25 20:10:26.299409
# Unit test for function romanize
def test_romanize():
    pass



# Generated at 2022-06-25 20:10:29.380823
# Unit test for function romanize
def test_romanize():
    alphabet, func_0, func_1 = 'aобв', romanize(locale='ru')(str), romanized(str)
    assert func_0(alphabet) == func_1(alphabet)

# Generated at 2022-06-25 20:10:30.735771
# Unit test for function romanize
def test_romanize():
    # TODO: Fix this.
    pass

# Generated at 2022-06-25 20:10:34.146309
# Unit test for function romanize
def test_romanize():
    t = romanize()
    assert t

# This test is compatible with pytest

# Generated at 2022-06-25 20:10:43.416364
# Unit test for function romanize
def test_romanize():
    def test_romanize_deco(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                # Cyrillic string can contain ascii
                # symbols, digits and punctuation.
                alphabet = {s: s for s in
                            ascii_letters + digits + punctuation}
                alphabet.update({
                    **data.ROMANIZATION_DICT['ru'],
                    **data.COMMON_LETTERS,
                })
            except KeyError:
                raise UnsupportedLocale('ru')

            result = func(*args, **kwargs)
            txt = ''.join([alphabet[i] for i in result if i in alphabet])
            return txt

        return wrapper

    return test_romanize_deco

# Generated at 2022-06-25 20:11:30.764179
# Unit test for function romanize
def test_romanize(): 
    # Test with args
    romanize(locale='ru')

    # Test without args
    try:
        romanize()
    except TypeError:
        pass

# Generated at 2022-06-25 20:11:31.868707
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:11:32.686452
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:11:34.496586
# Unit test for function romanize
def test_romanize():
    assert romanize('ru') is not None


# Generated at 2022-06-25 20:11:37.888621
# Unit test for function romanize
def test_romanize():
    from mimesis import toolbelt
    assert romanize('ru')(toolbelt.text_type)("Привет") == "Privet"

# Generated at 2022-06-25 20:11:39.496754
# Unit test for function romanize
def test_romanize():
    assert romanize()
    assert romanize(locale='uk')

# Generated at 2022-06-25 20:11:48.257702
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize()
    callable_2 = romanize('')
    callable_3 = romanize('ab')
    callable_4 = romanize('en')
    callable_5 = romanize('kk')
    callable_6 = romanize('pl')
    callable_7 = romanize('ru')
    callable_8 = romanize('uk')

# Generated at 2022-06-25 20:11:50.337070
# Unit test for function romanize
def test_romanize():
    japanese = romanize('ja')
    @japanese
    def test():
        return 'こんにちは！'

    assert test() == 'konnichiwa!'



# Generated at 2022-06-25 20:11:56.842491
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    test_string = 'Вася Пупкин'
    test_result = 'Vasya Pupkin'
    assert romanize(locale)(lambda x: x)(test_string) == test_result



# Generated at 2022-06-25 20:12:00.017634
# Unit test for function romanize
def test_romanize():
    assert romanized('ru')('Привет, Мир!') == 'Privet, Mir!'

# Generated at 2022-06-25 20:13:57.753799
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None

# Generated at 2022-06-25 20:13:58.544689
# Unit test for function romanize
def test_romanize():
    romanize('ru')

# Generated at 2022-06-25 20:14:00.390478
# Unit test for function romanize
def test_romanize():
    # TODO write unit tests
    assert callable_0

# Generated at 2022-06-25 20:14:09.005894
# Unit test for function romanize

# Generated at 2022-06-25 20:14:14.678724
# Unit test for function romanize

# Generated at 2022-06-25 20:14:16.025170
# Unit test for function romanize
def test_romanize():
    for locale in data.ROMANIZATION_DICT:
        assert romanize(locale)
        assert romanized(locale)


# Generated at 2022-06-25 20:14:33.994288
# Unit test for function romanize
def test_romanize():
    def test_class_0():
        class Class15:
            def __init__(self):
                self.attribute_0 = Attribute14()
                self.undefined_attribute = Attribute15()


        class Class16:
            def __init__(self):
                self.attribute_0 = Attribute12()
        var_1 = Class16()
        var_0 = var_1
        var_0.attribute_0.method_1()
        Class15.undefined_attribute.method_1()
        var_0.attribute_0.method_1()
        var_1.attribute_0.method_1()


    def undefined_attr(var_0, var_1):
        while var_0:
            var_1.attribute_0.method_1()
            if var_0:
                var_1

# Generated at 2022-06-25 20:14:34.818644
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:14:40.959800
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    # Test with locale
    locale: str = 'ru'
    assert callable_0(locale) == 'ru'

    # Test with a string
    text: str = 'Привет'
    assert callable_0(text) == 'privet'

    # Test with no arguments
    assert callable_0() == ''

    # Test for unsupported locale
    locale: str = 'jp'
    try:
        callable_0(locale)
    except UnsupportedLocale as e:
        assert type(e) == UnsupportedLocale and str(e) == locale

# Generated at 2022-06-25 20:14:47.702769
# Unit test for function romanize
def test_romanize():
    # Test 0
    callable_0 = romanize()

    assert callable_0(1) == 1

    assert callable_0(10) == 10

    assert callable_0(100) == 100

    assert callable_0(1000) == 1000

    assert callable_0(0.1) == 0.1

    assert callable_0(0.101) == 0.101

    assert callable_0(0.10101) == 0.10101

    assert callable_0(0.10111) == 0.10111

    assert callable_0(0.1012) == 0.1012

    assert callable_0(0.10121) == 0.10121

    assert callable_0(0.101111) == 0.101111
