

# Generated at 2022-06-25 20:07:56.013858
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanize()


# Generated at 2022-06-25 20:08:02.972172
# Unit test for function romanize
def test_romanize():
    on = romanize('ru')

    @on
    def test_1():
        return 'Вы приехали в Клинцы'

    @on
    def test_2():
        return 'Привет, мир!'

    assert test_1() == 'Vy priekhali v Klintzy'
    assert test_2() == 'Privet, mir!'

# Generated at 2022-06-25 20:08:05.303156
# Unit test for function romanize
def test_romanize():
    test_case_0()
    test_romanized()


# Generated at 2022-06-25 20:08:06.087473
# Unit test for function romanize
def test_romanize():
    assert True == test_case_0()

# Generated at 2022-06-25 20:08:08.676252
# Unit test for function romanize
def test_romanize():
    result_0 = romanize()
    assert callable(result_0)



# Generated at 2022-06-25 20:08:13.948467
# Unit test for function romanize
def test_romanize():
    # assert callable_0(locale_0='ru') == romanize('ru')
    assert romanize('ru')

    # assert callable_0(locale_0='uk') == romanize('uk')
    assert romanize('uk')

    # assert callable_0(locale_0='kk') == romanize('kk')
    assert romanize('kk')

# Generated at 2022-06-25 20:08:19.418928
# Unit test for function romanize
def test_romanize():

    callable_0 = romanize('ru')

    def function_0():
        return 'Спасибо'

    function_0 = callable_0(function_0)

    assert function_0() == 'Spasibo'



# Generated at 2022-06-25 20:08:23.150838
# Unit test for function romanize
def test_romanize():
    expected_0 = 'providet'
    romanize_fn_0 = romanize(locale='')
    result_0 = romanize_fn_0('')
    assert result_0 == expected_0


# Generated at 2022-06-25 20:08:24.063577
# Unit test for function romanize
def test_romanize():
    assert callable_0

# Generated at 2022-06-25 20:08:31.511267
# Unit test for function romanize
def test_romanize():
    for i in range(100):
        assert romanize()(lambda: data.Gender.FEMALE.value) == 'devushka'
        assert romanize()(lambda: data.Gender.MALE.value) == 'muzhchina'
        assert romanize()(lambda: data.Gender.NON_BINARY.value) == 'ne_binarnoe'

# Generated at 2022-06-25 20:08:42.158704
# Unit test for function romanize
def test_romanize():
    function_0 = romanize(locale='ru')
    function_2 = romanize(locale='ru')
    function_2.__name__ = 'test'
    function_1 = romanize(locale='ru')
    function_1.__name__ = 'test'


# Generated at 2022-06-25 20:08:43.422817
# Unit test for function romanize
def test_romanize():
    result = romanize()
    assert result() == ''

# Generated at 2022-06-25 20:08:44.330282
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:08:53.951629
# Unit test for function romanize
def test_romanize():
    # For backward compatibility test
    def to_romanize_function(locale):
        def wrapper():
            print(locale)

        return wrapper

    cyrillic_string = 'Привет!'
    russian_latin = 'Privet!'
    ukrainian_latin = 'Pryvit!'
    kazakh_latin = 'Pryvit!'

    assert romanize('ru')(to_romanize_function)(cyrillic_string) == russian_latin

# Generated at 2022-06-25 20:08:55.463863
# Unit test for function romanize
def test_romanize():
    assert callable(romanize()) is True

# Generated at 2022-06-25 20:09:05.494451
# Unit test for function romanize
def test_romanize():

    def func_0(x):
        return x

    try:
        func_0 = romanize('ru')
    except UnsupportedLocale as e:
        assert True
    else:
        assert False

    try:
        func_0 = romanize('en')
    except UnsupportedLocale as e:
        assert False
    else:
        assert True

    func_0 = romanize('uk')

    assert func_0('Привіт') == 'Pryvit'
    assert func_0('Як справи') == 'Yak spravy'



# Generated at 2022-06-25 20:09:13.260504
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize()
    callable_2 = romanize(locale='')

    assert callable_1(lambda: 'Привет Мир') == 'Privet Mir'
    assert callable_2(lambda: 'Привет Мир') == 'Privet Mir'

# Generated at 2022-06-25 20:09:16.777557
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='') == romanize(locale='')
    assert romanize(locale='') == romanize(locale='')
    assert romanize(locale='') == romanize(locale='')
    assert romanize(locale='') == romanize(locale='')

# Generated at 2022-06-25 20:09:18.183775
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

# Generated at 2022-06-25 20:09:20.172352
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    romanize(locale)


# Generated at 2022-06-25 20:09:30.907909
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize


# Generated at 2022-06-25 20:09:36.499921
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanize('')  # Default is 'ru'
    callable_2 = romanize('ru')
    callable_3 = romanize('uk')
    callable_4 = romanize('kk')
    #
    callable_0()
    callable_1()
    callable_2()
    callable_3()
    callable_4()



# Generated at 2022-06-25 20:09:43.340105
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(lambda : 'привет')() == 'privet'
    assert romanize('uk')(lambda : 'привіт')() == 'pryvit'
    assert romanize('kk')(lambda : 'Салем')() == 'Salem'



# Generated at 2022-06-25 20:09:44.846820
# Unit test for function romanize
def test_romanize():
    assert romanize()

# Generated at 2022-06-25 20:09:56.620234
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize('en'), Callable)
    assert isinstance(romanize('en')(test_case_0), Callable)
    romanize('asd')
    assert romanize('ru')(''.join)(data.ROMANIZATION_DICT['ru']) == \
        ''.join(data.ROMANIZATION_DICT['ru'].values())
    assert romanize('ru')(''.join)(
        data.ROMANIZATION_DICT['ru'] + data.COMMON_LETTERS) == \
        ''.join(data.ROMANIZATION_DICT['ru'].values()) + \
        ''.join(data.COMMON_LETTERS.values())

# Generated at 2022-06-25 20:09:59.149080
# Unit test for function romanize
def test_romanize():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 20:10:02.204548
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanize())
    assert callable(romanized)
    assert callable(romanized())

# Generated at 2022-06-25 20:10:06.229771
# Unit test for function romanize
def test_romanize():
    # Get romanized text from Mimesis
    r_0 = test_case_0()
    assert r_0 == '', 'The got result is empty. No text was generated.'

# Generated at 2022-06-25 20:10:07.563034
# Unit test for function romanize
def test_romanize():
    from mimesis import Person
    m = Person('en').full_name()
    assert callable(romanize())

# Generated at 2022-06-25 20:10:09.969662
# Unit test for function romanize
def test_romanize():
    def callable_0():
        romanize()
    return



# Generated at 2022-06-25 20:10:33.206777
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanized()


# Generated at 2022-06-25 20:10:34.004224
# Unit test for function romanize
def test_romanize():
    assert callable_0

# Generated at 2022-06-25 20:10:41.872192
# Unit test for function romanize
def test_romanize():
    func_0 = romanize(locale='ru')
    func_1 = romanize(locale='uk')
    func_2 = romanize(locale='kk')

    assert func_0('Привет мир!') == 'Privet Mir!'
    assert func_1('Привіт Світ!') == 'Pryvit Svit!'
    assert func_2('Сәлем дүние!') == 'Sälem dunie!'



# Generated at 2022-06-25 20:10:51.614301
# Unit test for function romanize
def test_romanize():
    _romanize = romanize()

    def _test_romanize_deco(func):
        @_romanize
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        assert wrapper.__name__ == func.__name__
        assert wrapper.__doc__ == func.__doc__
        assert wrapper.__doc__ == func.__doc__
        return wrapper

    def test_romanize_deco(func):
        @romanize()
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper

    @_test_romanize_deco
    def dummy_function_0():
        return "Надоело всё это дело"

    assert dummy_function_0()

# Generated at 2022-06-25 20:10:54.356892
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_0()

# Generated at 2022-06-25 20:10:57.122634
# Unit test for function romanize
def test_romanize():
    assert callable(test_case_0)
    assert isinstance(test_case_0, Callable)

# Generated at 2022-06-25 20:10:59.154738
# Unit test for function romanize
def test_romanize():
    locale = ''
    locales = ['ru', 'uk', 'kk']


# Generated at 2022-06-25 20:11:01.134721
# Unit test for function romanize
def test_romanize():
    assert romanized is not None
    assert callable(test_case_0)

# Generated at 2022-06-25 20:11:07.815784
# Unit test for function romanize
def test_romanize():
    # Test with locale
    x1 = romanized('ru')
    assert x1(lambda: 'Дмитрий') == 'Dmitriy'


if __name__ == '__main__':
    test_case_0()
    test_romanize()

# Generated at 2022-06-25 20:11:13.369870
# Unit test for function romanize
def test_romanize():
    func_0 = romanize('ru')
    assert func_0(lambda: 'Какой-то текст') == 'Kakoy-to tekst'

    func_1 = romanize('uk')
    assert func_1(lambda: 'Какий-собі текст') == 'Kakij-sobi tekst'

    func_2 = romanize('kk')
    assert func_2(lambda: 'Кәсіптік мәтін') == 'Käsïptik mätin'

# Generated at 2022-06-25 20:12:07.564619
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0('Привет') == 'Privet'


# Generated at 2022-06-25 20:12:08.377056
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:12:09.315791
# Unit test for function romanize
def test_romanize():
    pass

# Generated at 2022-06-25 20:12:12.502411
# Unit test for function romanize
def test_romanize():
    # get_romanized_list = romanize()
    # assert get_romanized_list(['Привет', 'Hello']) == ['Privet', 'Hello']
    callable_0 = romanize()
    pass

# Generated at 2022-06-25 20:12:21.142554
# Unit test for function romanize
def test_romanize():
    locale_0 = 'ru'
    locale_1 = 'sr-cyrl'
    result_0 = romanize(locale_0)(lambda: 'test')()
    result_1 = romanize(locale_1)(lambda: 'test')()
    assert result_0 == 'test'
    assert result_1 == 'test'

# Generated at 2022-06-25 20:12:22.376359
# Unit test for function romanize
def test_romanize():
    first_word = romanize()
    print(first_word)

# Generated at 2022-06-25 20:12:23.707349
# Unit test for function romanize
def test_romanize():
    assert 0


# Generated at 2022-06-25 20:12:24.452025
# Unit test for function romanize
def test_romanize():
    assert callable_0

# Generated at 2022-06-25 20:12:31.590435
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()

    def callable_func_0():
        return 'Привет, как дела?'

    assert isinstance(callable_0, Callable)
    assert callable_0(callable_func_0) == 'Privet, kak dela?'

# Generated at 2022-06-25 20:12:39.855125
# Unit test for function romanize
def test_romanize():
    assert 'string' == romanize()('стринг')
    assert 'string' == romanize('ru')('стринг')
    assert 'string' == romanize('uk')('стринг')
    assert '' == romanize('ru')('')
    assert '' == romanize('uk')('')

# Generated at 2022-06-25 20:14:33.989798
# Unit test for function romanize
def test_romanize():
    func_a = romanize('ru')



# Generated at 2022-06-25 20:14:34.830012
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)



# Generated at 2022-06-25 20:14:35.799941
# Unit test for function romanize
def test_romanize():
    assert callable_0


# Generated at 2022-06-25 20:14:36.565839
# Unit test for function romanize
def test_romanize():
    assert romanize is not None


# Generated at 2022-06-25 20:14:38.609439
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0 is not None


# Generated at 2022-06-25 20:14:42.282541
# Unit test for function romanize
def test_romanize():
    # Arrange
    # Act
    result_0 = romanize()
    # Assert
    assert callable(result_0)

# Generated at 2022-06-25 20:14:48.467216
# Unit test for function romanize
def test_romanize():
    # First test case
    callable_0 = romanize()
    cyrillic_text_0 = 'Привет'
    latin_text_0 = 'Privet'
    assert callable_0(cyrillic_text_0) == latin_text_0

    # Second test case
    callable_1 = romanize()
    cyrillic_text_1 = 'Калининград'
    latin_text_1 = 'Kalininigrad'
    assert callable_1(cyrillic_text_1) == latin_text_1

    # Third test case
    callable_2 = romanize()
    cyrillic_text_2 = 'Радость'
    latin_text

# Generated at 2022-06-25 20:14:54.281118
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')(str)('Русский язык') == 'Russkiy yazyk'
    assert romanize('uk')(str)('українська мова') == 'ukrayíns`ka mova'
    assert romanize('kk')(str)('Қазақ тілі') == 'Qazaq tili'



# Generated at 2022-06-25 20:14:55.155368
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru') is not None

# Generated at 2022-06-25 20:14:55.940527
# Unit test for function romanize
def test_romanize():
    assert test_case_0() == None