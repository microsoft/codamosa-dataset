

# Generated at 2022-06-25 20:07:58.241415
# Unit test for function romanize
def test_romanize():

    expected_result = 'A'

    actual_result = romanize()(lambda: 'A')
    assert (expected_result == actual_result)

# Generated at 2022-06-25 20:07:59.656923
# Unit test for function romanize
def test_romanize():
    assert romanize.__doc__ is not None

# Generated at 2022-06-25 20:08:01.077477
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    pass

# Generated at 2022-06-25 20:08:02.720833
# Unit test for function romanize
def test_romanize():
    assert romanize()



# Generated at 2022-06-25 20:08:14.577967
# Unit test for function romanize
def test_romanize():
    locale = 'ru'
    expected_result = ['HGJ', 'D', 'd', 'D', 'R', 'HG', 'J', 'HG', 'HG', '{']
    translit_dictionary = {}

# Generated at 2022-06-25 20:08:21.370230
# Unit test for function romanize

# Generated at 2022-06-25 20:08:25.453588
# Unit test for function romanize
def test_romanize():
    assert romanize(locale="ru")(lambda: "Привет")() == "Privet"
    assert romanize(locale="uk")(lambda: "Привіт")() == "Pryvit"
    assert romanize(locale="kk")(lambda: "Сәлем")() == "Salem"

# Generated at 2022-06-25 20:08:27.992331
# Unit test for function romanize
def test_romanize():
    assert callable_0('Дурак') == 'Durak'


# Generated at 2022-06-25 20:08:30.784119
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert romanize(locale='') == callable_0

# Generated at 2022-06-25 20:08:34.969246
# Unit test for function romanize
def test_romanize():
    expected = True
    actual = False
    test_string = "а"
    if callable(romanize):
        if callable(romanize(test_case_0)):
            if test_string == romanize(test_case_0):
                actual = True
    assert expected == actual

# Generated at 2022-06-25 20:08:48.201098
# Unit test for function romanize
def test_romanize():
    # Tests if the romanize decorator works as expected
    import random

    @romanize('ru')
    def _random_text(self):
        text = ""
        for _ in range(0, random.randint(0, 100)):
            text += random.choice("абвгдеёжзийклмнопрстуфхцчшщъыьэюя")
        return text

    # Shouldn't return empty string
    assert not len(_random_text(None)) == 0
    assert not _random_text(None) == ""

    # Shouldn't return empty string
    assert not len(_random_text(None)) == 0
    assert not _random_text(None) == ""

    # Shouldn't return

# Generated at 2022-06-25 20:08:56.254831
# Unit test for function romanize
def test_romanize():
    assert callable_0('Лев') == 'Lev'
    assert callable_0('Волк') == 'Volk'
    assert callable_0('Лев') == 'Lev'
    assert callable_0('Лев') == 'Lev'
    assert callable_0('Лев') == 'Lev'
    assert callable_0('Лев') == 'Lev'
    assert callable_0('Лев') == 'Lev'
    assert callable_0('The quick brown fox jumps over the lazy dog') == 'The quick brown fox jumps over the lazy dog'


# Generated at 2022-06-25 20:09:04.303062
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='ru')(lambda : 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ')() == 'ABVGDEYOZHZIJKLMNOPRSTUFHCCHSHCHYUYA'

# Generated at 2022-06-25 20:09:07.238384
# Unit test for function romanize
def test_romanize():
    assert romanize()('\u044f') == 'ya'

# Generated at 2022-06-25 20:09:10.277535
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    assert callable_0(test_case_0) == 'test_case_0'

# Generated at 2022-06-25 20:09:15.911952
# Unit test for function romanize
def test_romanize():
    from mimesis.data import romanization_dict
    import mimesis

    # Convert romanized string to latin
    for locale in romanization_dict:
        if locale == 'kk':
            continue # Kazakh doesn't have transliteration

        for key, value in romanization_dict[locale].items():
            roman = mimesis.Generic(locale=locale)
            assert roman.romanize(key) == value



# Generated at 2022-06-25 20:09:17.321596
# Unit test for function romanize
def test_romanize():
    assert romanize()


# Generated at 2022-06-25 20:09:19.358123
# Unit test for function romanize
def test_romanize():
    # case 0
    callable_0 = romanize()
    assert callable_0

# Generated at 2022-06-25 20:09:20.943858
# Unit test for function romanize
def test_romanize():
    assert romanize() is not None


# Generated at 2022-06-25 20:09:23.824684
# Unit test for function romanize
def test_romanize():
    test_case_0()

if __name__ == '__main__':
    test_romanize()

# Generated at 2022-06-25 20:09:35.075102
# Unit test for function romanize
def test_romanize():
    result = romanized(lambda: "Привет!")()
    assert result == "Privet!"

# Generated at 2022-06-25 20:09:44.859107
# Unit test for function romanize
def test_romanize():
    assert callable(romanize)
    assert callable(romanized)
    assert romanize()(lambda x: x)('Russian') == ''
    assert romanized('ru')(lambda x: x)('Russian') == 'Rossiyskiy'
    assert romanized('uk')(lambda x: x)('Russian') == 'Rosiyskiy'
    assert romanized('kk')(lambda x: x)('Russian') == 'Rusiq sili'

# Generated at 2022-06-25 20:09:48.148949
# Unit test for function romanize
def test_romanize():
    assert isinstance(romanize, functools.partial)


# Generated at 2022-06-25 20:09:48.951249
# Unit test for function romanize
def test_romanize():
    assert True == True

# Generated at 2022-06-25 20:09:51.898561
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('щщуцппер') == 'shhutchpper'

# Generated at 2022-06-25 20:09:57.205387
# Unit test for function romanize
def test_romanize():
    # Case 0
    callable_0 = romanize()
    assert callable_0 is not None
    assert callable_0(*[], **{}) is not None
    assert callable_0 is not None
    assert callable_0 is not None
    # Case 1
    callable_1 = romanize()
    callable_1 = romanize()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:09:59.579690
# Unit test for function romanize
def test_romanize():
    assert romanize(locale='')(lambda: '')



# Generated at 2022-06-25 20:10:02.540947
# Unit test for function romanize
def test_romanize():
    assert romanize()(lambda : '105рублей') == '105rublej'


# Generated at 2022-06-25 20:10:10.823165
# Unit test for function romanize
def test_romanize():
    callable_1 = romanize()
    callable_1(lambda : "абвгґдеєжзиіїйклмнопрстуфхцчшщьюя")
    print(callable_1)
    print(callable_1(lambda : "абвгґдеєжзиіїйклмнопрстуфхцчшщьюя"))
    # TODO: add result


# Generated at 2022-06-25 20:10:13.258076
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    text_0 = callable_0(str)

# Generated at 2022-06-25 20:10:42.771204
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_0_expect = romanize()

    romanized_0 = romanized()
    romanized_0_expect = romanize()

    # Works exactly like romanize()
    # romanized_0(callable_0) == romanized_0_expect(callable_0)
    # romanized_0(callable_0) == romanize()(callable_0)

    # is romanize() a decorator?
    assert callable(callable_0)
    assert callable(romanized_0)

if __name__ == "__main__":
    test_case_0()
    test_romanize()

# Generated at 2022-06-25 20:10:46.163313
# Unit test for function romanize
def test_romanize():
    # SUT
    romanize_0 = romanize(locale='uk')

    # Function call
    @romanize_0
    def func_0(stream):
        return stream.text(9999)

    # Verify the results
    assert func_0()

# Generated at 2022-06-25 20:10:47.913585
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')
    assert romanize('uk')
    with raises(UnsupportedLocale):
        assert romanize('es')



# Generated at 2022-06-25 20:10:50.383389
# Unit test for function romanize
def test_romanize():
    assert True


# Generated at 2022-06-25 20:10:54.492187
# Unit test for function romanize
def test_romanize():
    d = romanize()(lambda : 'Привет')
    assert d == 'Privet'



# Generated at 2022-06-25 20:10:55.399080
# Unit test for function romanize
def test_romanize():
    romanize()

# Generated at 2022-06-25 20:11:03.155451
# Unit test for function romanize
def test_romanize():
    @romanize('ru')
    def func0(**kwargs):
        results = []
        for i in range(10):
            if i > 0:
                results.append(kwargs['foo']())
        return results

    # romanize does not change the latin script
    assert func0(foo=lambda: 'foo bar') == ['foo bar'] * 9

    # romanize does not change the digits
    assert func0(foo=lambda: '12345') == ['12345'] * 9

    # romanize does not change the punctuation
    assert func0(foo=lambda: '.,;:/') == ['.,;:/'] * 9

    # romanize - no space in the end

# Generated at 2022-06-25 20:11:04.563176
# Unit test for function romanize
def test_romanize():
    pass


# Generated at 2022-06-25 20:11:13.351515
# Unit test for function romanize
def test_romanize():
    assert romanize('ru')('Россия') == 'Rossiya'
    assert romanize('ru')('Николай') == "Nikolay"
    assert romanize('ru')('Екатеринбург') == "Yekaterinburg"
    assert romanize('ru')('Частный дом') == "Chastnyy dom"
    assert romanize('ru')('Андрей') == "Andrey"
    assert romanize('ru')('Евгений') == "Yevgeniy"
    assert romanize('ru')('Москва') == "Moskva"
   

# Generated at 2022-06-25 20:11:19.075435
# Unit test for function romanize
def test_romanize():
    def callable_0():
        pass

    callable_0.__name__ = 'Romanize 0'
    # Check if function is wrapped
    assert callable_0.__name__ == 'wrapper'


if __name__ == '__main__':
    test_case_0()
    test_romanize()

# Generated at 2022-06-25 20:12:15.486372
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()



# Generated at 2022-06-25 20:12:25.148863
# Unit test for function romanize
def test_romanize():
    # See issue #144
    # Call function romanize with correct arguments
    assert romanize(
        'en'
    )(
        lambda: None
    ) is not None
    assert romanize(
        'ru'
    )(
        lambda: None
    ) is not None
    assert romanized(
        'uk'
    )(
        lambda: None
    ) is not None
    assert romanize(
        'kk'
    )(
        lambda: None
    ) is not None
    # Call function romanize with incorrect arguments
    # TypeError raised for 'ru'
    with raises(TypeError):
        assert romanize(
            'ru'
        )(
            lambda: 'Привет, Мир!'
        ) is not TypeError
    # Type

# Generated at 2022-06-25 20:12:30.538236
# Unit test for function romanize
def test_romanize():
    # Type error
    with raises(TypeError):
        callable_0 = romanize(123)

    # UnsupportedLocale
    with raises(UnsupportedLocale):
        callable_1 = romanize('err')



# Generated at 2022-06-25 20:12:34.747801
# Unit test for function romanize
def test_romanize():
    # Set up for test case 0
    t0_function_callable_0 = {
        'key0': 'value0',
    }
    # Call function to test
    t0_result_callable_0 = romanize()(t0_function_callable_0)
    # Test that the output is correct
    assert t0_function_callable_0 == t0_result_callable_0

# Generated at 2022-06-25 20:12:39.718912
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize(locale='ru')
    callable_1 = callable_0(lambda : 'Автомобиль')
    assert callable_1 == 'Avtomobil'

# Generated at 2022-06-25 20:12:43.224370
# Unit test for function romanize
def test_romanize():
    test_case_0()
    assert callable_0('ru') == 'romanize_deco'

# Generated at 2022-06-25 20:12:45.225758
# Unit test for function romanize
def test_romanize():
    assert callable_0(name)

# Generated at 2022-06-25 20:12:47.768537
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize('ru')



# Generated at 2022-06-25 20:12:53.402158
# Unit test for function romanize
def test_romanize():
    from mimesis.builtins.text import Text
    t = Text('ru')
    assert t.personal_title_short() == 'г-н'
    assert t.personal_title_short(romanize=True) == 'g-n'



# Generated at 2022-06-25 20:12:57.411444
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()
    callable_1 = romanize()
    callable_0(data.COMMON_LETTERS, data.ROMANIZATION_DICT)
    callable_1(data.COMMON_LETTERS, data.ROMANIZATION_DICT)


# Generated at 2022-06-25 20:14:59.580505
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize()


# Generated at 2022-06-25 20:15:09.416878
# Unit test for function romanize
def test_romanize():
    tmp = romanize()

    # Type error
    with pytest.raises(TypeError):
        tmp()

    # Unsupported locale
    with pytest.raises(UnsupportedLocale):
        romanize('zz')()

    # Supported locale
    z = romanize('ru')()
    assert z == 'Съешь ещё этих мягких французских булок, да выпей чаю.'



# Generated at 2022-06-25 20:15:17.164586
# Unit test for function romanize
def test_romanize():
    callable_0 = romanize('uk')
    txt_0 = callable_0(lambda: 'Хороша погода.')
    assert txt_0 == 'Horoša pogoda.'

    callable_1 = romanize('ru')
    txt_1 = callable_1(lambda: 'Хорошая погода.')
    assert txt_1 == 'Horoshaya pogoda.'

    callable_2 = romanize('kk')
    txt_2 = callable_2(lambda: 'Хорошая погода.')
    assert txt_2 == 'Xorošaja poxoda.'

# Generated at 2022-06-25 20:15:20.449124
# Unit test for function romanize
def test_romanize():
    pass



# Generated at 2022-06-25 20:15:21.322469
# Unit test for function romanize
def test_romanize():
    assert callable(test_case_0)

# Generated at 2022-06-25 20:15:23.365452
# Unit test for function romanize
def test_romanize():
    test_case_0()


__all__ = ['romanize',
           'romanized',
           'test_case_0']

# Generated at 2022-06-25 20:15:24.675469
# Unit test for function romanize
def test_romanize():
    func = romanize()
    assert func



# Generated at 2022-06-25 20:15:25.664250
# Unit test for function romanize
def test_romanize():
    s = test_case_0()
    assert 'h' == s


# Generated at 2022-06-25 20:15:26.491126
# Unit test for function romanize
def test_romanize():
    assert callable(romanize())

# Generated at 2022-06-25 20:15:31.823184
# Unit test for function romanize
def test_romanize():
    # Test for method romanize
    def _test_romanize(alphabet, s):
        return ''.join([alphabet[i] for i in s if i in alphabet])

    # Test for method romanize
    assert _test_romanize(data.ROMANIZATION_DICT['ru'], 'тест') == 'test'
    assert _test_romanize(data.ROMANIZATION_DICT['uk'], 'тест') == 'test'
    assert _test_romanize(data.ROMANIZATION_DICT['kk'], 'тест') == 'test'
    assert _test_romanize(data.ROMANIZATION_DICT['ru'], 'тест тест') == 'test test'