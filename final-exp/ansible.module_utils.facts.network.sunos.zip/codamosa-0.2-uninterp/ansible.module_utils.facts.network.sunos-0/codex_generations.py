

# Generated at 2022-06-17 01:04:05.337353
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.freebsd import FreebsdIfconfigNetwork
    from ansible.module_utils.facts.network.netbsd import NetBSDIfconfigNetwork
    from ansible.module_utils.facts.network.openbsd import OpenBSDIfconfigNetwork

# Generated at 2022-06-17 01:04:16.389092
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)

    # Test with ifconfig output from Solaris 11.3
    ifconfig_path = 'tests/unit/module_utils/facts/network/test_SunOS_ifconfig_output'
    interfaces, ips = network.get_interfaces_info(ifconfig_path)

    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']

# Generated at 2022-06-17 01:04:18.612726
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork

# Generated at 2022-06-17 01:04:29.168912
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    result = network_collector.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-17 01:04:41.508487
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    if not ifconfig_path:
        module.fail_json(msg='ifconfig command not found')
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']

# Generated at 2022-06-17 01:04:53.965656
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network = network_collector.get_network_instance()
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-17 01:04:55.719275
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:04:57.702807
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:02.194415
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:06.897291
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:05:23.847033
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefixlen'] == '128'

# Generated at 2022-06-17 01:05:25.324131
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:05:36.079717
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)
    interfaces = {}
    current_if = {}

    # Test with a line for an IPv4 interface
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-17 01:05:40.253662
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:42.713174
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of class SunOSNetworkCollector
    """
    SunOSNetworkCollector()

# Generated at 2022-06-17 01:05:43.826279
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:45.327166
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:05:55.029686
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-17 01:06:05.991632
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')

    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv4'][0]['ptp'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-17 01:06:17.855199
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 01:06:38.457613
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-17 01:06:40.980114
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:43.295203
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:06:51.672426
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']['lo0']
    assert '::1' in ips['all_ipv6_addresses']['lo0']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']

# Generated at 2022-06-17 01:07:02.767138
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources']

# Generated at 2022-06-17 01:07:04.763150
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:15.674261
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:07:18.779503
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:28.984879
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-17 01:07:31.280484
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-17 01:07:58.979632
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info = MagicMock(return_value=(None, None))
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector

# Generated at 2022-06-17 01:08:09.449080
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info = MagicMock(return_value=(None, None))
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_default_interfaces = MagicMock(return_value=None)
    network_collector.get_default_interfaces.return_value = None
    network_collector.get_interfaces_ipv4 = MagicMock(return_value=None)
    network_collector.get_interfaces_ipv4.return_value = None
    network_collector.get_interfaces_ipv6 = MagicMock(return_value=None)
    network_collect

# Generated at 2022-06-17 01:08:20.780280
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:08:23.158955
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:25.868967
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:08:28.360252
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert facts._fact_class == SunOSNetwork
    assert facts._platform == 'SunOS'

# Generated at 2022-06-17 01:08:33.164927
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of the class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:08:40.807010
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']
    assert '::1' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']
    assert '::1' in interfaces['lo0']['ipv6'][0]['address']

# Generated at 2022-06-17 01:08:43.097825
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-17 01:08:44.958125
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:09:37.350586
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:09:42.271260
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:09:46.056055
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:09:48.128490
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:09:55.889951
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0'

# Generated at 2022-06-17 01:09:58.539473
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:12.949560
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', required=True)
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-17 01:10:25.572240
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces = {}
    current_if = {}

    # Test 1:
    # Test a line with an IPv4 interface
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-17 01:10:28.679230
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:31.502177
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork

# Generated at 2022-06-17 01:11:49.640293
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:11:58.624621
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a test string

# Generated at 2022-06-17 01:12:01.350007
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:07.860228
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-17 01:12:16.846195
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-17 01:12:26.823994
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_module = SunOSNetwork(module)
    interfaces, ips = network_module.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'

# Generated at 2022-06-17 01:12:31.136636
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of class SunOSNetworkCollector
    """
    SunOSNetworkCollector()

# Generated at 2022-06-17 01:12:33.320622
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:36.141571
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:44.339727
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command.return_value = (0, '', '')
    set_module_args(dict(gather_subset='!all,!min'))
    obj = SunOSNetwork(module)
    interfaces, ips = obj.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'