

# Generated at 2022-06-17 01:03:50.936346
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:03:54.426183
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of SunOSNetworkCollector class should return an object of SunOSNetworkCollector class
    """
    sunos_network_collector_obj = SunOSNetworkCollector()
    assert isinstance(sunos_network_collector_obj, SunOSNetworkCollector)


# Generated at 2022-06-17 01:04:05.741182
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv4'][0]['ptp'] == '127.0.0.1'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-17 01:04:16.859540
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.collect()
    network_facts = network_collector.get_facts()
    assert network_facts['interfaces']['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert network_facts['interfaces']['lo0']['ipv4'][0]['mtu'] == '8232'
    assert network_facts['interfaces']['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']

# Generated at 2022-06-17 01:04:20.411598
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test 1:
    # Test that the method returns a dictionary with the correct keys and values
    # when passed a line from 'ifconfig -a' that contains an IPv4 interface
    # with a single IPv4 address.
    #
    # Expected result:
    # {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}
    line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = line.split()
    current_if = {}
    interfaces = {}
    ips = {}

# Generated at 2022-06-17 01:04:24.458289
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of the class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:04:28.024433
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:04:40.688539
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command.return_value = (0, SUNOS_IFCONFIG_ALL, '')
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:04:53.060291
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    test_obj = SunOSNetwork()
    test_obj.module = None
    test_obj.ifconfig_path = None
    test_obj.ip_path = None
    test_obj.route_path = None
    test_obj.netstat_path = None
    test_obj.interfaces = {}
    test_obj.ips = {}
    test_obj.current_if = {}

    test_words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    test_obj.parse_interface_line(test_words, test_obj.current_if, test_obj.interfaces)

# Generated at 2022-06-17 01:05:01.162654
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']

# Generated at 2022-06-17 01:05:16.798636
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = type('test_module', (object,), {'run_command': run_command})
    test_module.params = {}
    test_module.params['gather_subset'] = ['!all', '!min']
    test_module.params['gather_network_resources'] = ['interfaces']
    test_module.params['gather_network_resources'] = ['interfaces']
    test_module.params['gather_network_resources'] = ['interfaces']
    test_module.params['gather_network_resources'] = ['interfaces']
    test_module.params['gather_network_resources'] = ['interfaces']
    test_module.params['gather_network_resources'] = ['interfaces']
    test_module.params['gather_network_resources'] = ['interfaces']
   

# Generated at 2022-06-17 01:05:21.336673
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:29.120258
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a dictionary of interfaces

# Generated at 2022-06-17 01:05:40.360155
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a dictionary to hold interfaces
    interfaces = {}

    # Create a dictionary to hold current interface
    current_if = {}

    # Create a list of words to be passed to parse_interface_line
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']

    # Call parse_interface_line
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)

    # Check if the current interface is lo0
    assert current_if['device'] == 'lo0'

    # Check if the current interface is of type loopback

# Generated at 2022-06-17 01:05:43.130239
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:54.101305
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']

# Generated at 2022-06-17 01:05:56.757354
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:07.222049
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

# Generated at 2022-06-17 01:06:17.945938
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test get_interfaces_info() of class SunOSNetwork
    """
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()
    # Create a test string

# Generated at 2022-06-17 01:06:21.359730
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:33.532326
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:06:44.736984
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-17 01:06:49.420922
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:07:01.078086
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0'

# Generated at 2022-06-17 01:07:09.535450
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    ifconfig_path = '/sbin/ifconfig'
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = SunOSNetwork(module, ifconfig_path).parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-17 01:07:12.268400
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:07:15.140312
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:26.903054
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    set_module_args({})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefix'] == '128'
    assert interfaces['lo0']['ipv6'][0]['scope'] == 'host'

# Generated at 2022-06-17 01:07:37.809466
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('', (), {})()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    network = SunOSNetwork(module)
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-17 01:07:40.752761
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:58.433942
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-17 01:08:13.431237
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network = network_collector.get_network_instance()
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-17 01:08:24.326623
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:08:36.316826
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefix'] == '128'
    assert interfaces['lo0']['ipv6'][0]['scope'] == 'host'

# Generated at 2022-06-17 01:08:47.927544
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()
    # Create a dict to hold the current interface
    current_if = {}
    # Create a dict to hold all interfaces
    interfaces = {}
    # Create a list of words to parse
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    # Call the method
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    # Assert that the device is 'lo0'
    assert current_if['device'] == 'lo0'
    # Assert that the type is 'loopback'
    assert current_if['type'] == 'loopback'
    #

# Generated at 2022-06-17 01:08:58.736645
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIf

# Generated at 2022-06-17 01:09:01.442925
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:09:04.877262
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:09:15.414701
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:09:17.960957
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:09:51.423262
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']['lo0']
    assert '::1' in ips['all_ipv6_addresses']['lo0']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']

# Generated at 2022-06-17 01:10:03.552037
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, SUNOS_IFCONFIG_ALL, ''))
    network_collector = SunOSNetwork(module)
    interfaces, ips = network_collector.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1/128'

# Generated at 2022-06-17 01:10:15.145962
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0'

# Generated at 2022-06-17 01:10:27.030981
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in ips['all_ipv4_interfaces']
    assert 'lo0' in ips['all_ipv6_interfaces']
    assert 'lo0' in ips['all_ipv4_macs']
    assert 'lo0' in ips['all_ipv6_macs']

# Generated at 2022-06-17 01:10:30.583282
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-17 01:10:34.588778
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:45.958445
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    assert network_collector.interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert network_collector.interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert network_collector.interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert network_collector.interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-17 01:10:58.622594
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']['lo0']
    assert '::1' in ips['all_ipv6_addresses']['lo0']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']

# Generated at 2022-06-17 01:11:12.954084
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefixlen'] == '128'

# Generated at 2022-06-17 01:11:16.406139
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._platform == 'SunOS'
    assert sunos_network_collector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:10.535829
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:13.069114
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:24.133871
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefix'] == '128'

# Generated at 2022-06-17 01:12:33.236238
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a test string

# Generated at 2022-06-17 01:12:42.748431
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')

    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-17 01:12:55.743740
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network = network_collector.get_network_instance()

    # Test 1: Test parsing of a line with IPv4 interface
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {}
    interfaces = {}
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-17 01:12:58.075548
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:13:12.895202
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefix'] == '128'
    assert interfaces['lo0']['ipv6'][0]['scope'] == 'host'
   

# Generated at 2022-06-17 01:13:22.626192
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # Create a SunOSNetwork object
    obj = SunOSNetwork(module)

    # Get interfaces info
    interfaces, ips = obj.get_interfaces_info('/sbin/ifconfig')

    # Test if interfaces is a dictionary
    assert isinstance(interfaces, dict)

    # Test if ips is a dictionary
    assert isinstance(ips, dict)

    # Test if all_ipv4_addresses is a list
    assert isinstance(ips['all_ipv4_addresses'], list)

    # Test if all_ipv6_addresses is a list

# Generated at 2022-06-17 01:13:31.955246
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
    assert current_if