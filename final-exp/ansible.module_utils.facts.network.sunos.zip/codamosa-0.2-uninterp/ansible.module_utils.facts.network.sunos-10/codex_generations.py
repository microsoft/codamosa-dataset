

# Generated at 2022-06-17 01:03:56.486511
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:03:58.453007
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:04:10.693568
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 01:04:22.212888
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']

# Generated at 2022-06-17 01:04:32.287960
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['interfaces']
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:04:34.818241
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:04:35.979089
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-17 01:04:45.642416
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ifconfig')
    module.read_file = MagicMock(return_value='')
    module.get_file_content = MagicMock(return_value='')
    module.get_file_lines = MagicMock(return_value='')
    module.get_mount_size = MagicMock(return_value='')
    module.get_mount_size = MagicMock(return_value='')
    module.get_mount_size = MagicMock(return_value='')

# Generated at 2022-06-17 01:04:47.411710
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:04:51.343060
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:04:58.925801
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:06.049887
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:05:09.381262
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:15.266531
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 01:05:24.400004
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-17 01:05:32.898417
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

# Generated at 2022-06-17 01:05:38.384513
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces

# Generated at 2022-06-17 01:05:49.810194
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    if not ifconfig_path:
        module.fail_json(msg='ifconfig not found')
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']

# Generated at 2022-06-17 01:05:59.771026
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-17 01:06:13.221322
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']

# Generated at 2022-06-17 01:06:34.486121
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefixlen'] == '128'

# Generated at 2022-06-17 01:06:38.995615
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:49.149664
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

# Generated at 2022-06-17 01:07:00.888122
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)

    # test_get_interfaces_info_1
    # test_get_interfaces_info_2
    # test_get_interfaces_info_3
    # test_get_interfaces_info_4
    # test_get_interfaces_info_5
    # test_get_interfaces_info_6
    # test_get_interfaces_info_7
    # test_get_interfaces_info_8
    # test_get_interfaces_info_9
    # test_get_interfaces_info_10
    # test_get_interfaces_info_11
    # test_get_interfaces_info_12
    # test_get_interfaces_info_13
    # test_get_inter

# Generated at 2022-06-17 01:07:08.321961
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()

    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:07:16.257076
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_module = SunOSNetwork(module)
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = network_module.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-17 01:07:18.885658
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:07:29.021554
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:07:30.983875
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:07:36.045229
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:08:04.448357
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv6'][0]['netmask'] == 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff'

# Generated at 2022-06-17 01:08:12.761798
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 01:08:17.452440
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of class SunOSNetworkCollector.
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:08:20.172432
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:30.306056
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']['lo0']
    assert '::1' in ips['all_ipv6_addresses']['lo0']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']

# Generated at 2022-06-17 01:08:34.912227
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of the class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:08:36.811626
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:08:46.495326
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    sunos_network = SunOSNetwork(module)
    interfaces, ips = sunos_network.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']

# Generated at 2022-06-17 01:08:48.624147
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:59.433695
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']

# Generated at 2022-06-17 01:10:01.977428
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = NetworkCollector()
    test_if = {}
    test_interfaces = {}
    test_words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    test_if = test_module.parse_interface_line(test_words, test_if, test_interfaces)
    assert test_if == {'device': 'lo0', 'ipv4': [{'flags': 'UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL', 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-17 01:10:14.364537
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']


# Generated at 2022-06-17 01:10:26.530564
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefixlen'] == '128'

# Generated at 2022-06-17 01:10:31.712548
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector.platform == 'SunOS'
    assert sunos_network_collector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:34.614800
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:46.001220
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a dict to hold the current interface
    current_if = {}

    # Create a dict to hold the interfaces
    interfaces = {}

    # Create a list of words to parse
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']

    # Call the method
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)

    # Check the result
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags']

# Generated at 2022-06-17 01:10:49.410736
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:10:51.475695
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:11:01.929931
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = type('test_module', (object,), {'run_command': lambda self, args: (0, '', '')})()
    test_module.params = {}
    test_module.check_mode = False
    test_module.debug = False
    test_module.fail_json = lambda **kwargs: False
    test_module.exit_json = lambda **kwargs: False
    test_module.warn = lambda msg: False

    test_SunOSNetwork = SunOSNetwork(test_module)

    # Test 1:
    # Test that an empty dictionary is returned when the interface is not already in the interfaces dictionary
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']

# Generated at 2022-06-17 01:11:15.394857
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefix'] == '128'

# Generated at 2022-06-17 01:12:43.220996
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-17 01:12:45.898421
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:58.532833
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path)
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in ips['all_ipv4_interfaces']
    assert 'lo0' in ips['all_ipv6_interfaces']
    assert 'lo0' in ips['all_ipv4_macs']
    assert 'lo0' in ips['all_ipv6_macs']
    assert 'lo0'

# Generated at 2022-06-17 01:13:13.195985
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']

# Generated at 2022-06-17 01:13:15.153253
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:13:22.999261
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command.return_value = (0, '', '')
    set_module_args(dict(gather_subset='!all,!min'))
    obj = SunOSNetwork(module)
    interfaces = obj.get_interfaces_info('/sbin/ifconfig')
    assert interfaces[0]['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces[0]['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-17 01:13:25.163436
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:13:26.638517
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:13:28.321957
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:13:35.055449
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)

    # Test 1:
    # Test that the method correctly parses the first line of an interface
    # and creates a new dictionary for the interface.
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {}
    interfaces = {}
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'