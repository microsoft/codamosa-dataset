

# Generated at 2022-06-17 01:03:52.290999
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces is not None
    assert ips is not None


# Generated at 2022-06-17 01:04:03.980723
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']


# Generated at 2022-06-17 01:04:05.820339
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:04:07.723667
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:04:19.246142
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']
    assert '::1' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']
    assert '::1' in interfaces['lo0']['ipv6'][0]['address']

# Generated at 2022-06-17 01:04:22.914563
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This is a unit test for the constructor of the class SunOSNetworkCollector.
    It tests that the object is properly constructed.
    """
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-17 01:04:31.438971
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces

# Generated at 2022-06-17 01:04:42.774378
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command.return_value = (0, '', '')
    module.get_bin_path = MagicMock(return_value='/sbin/ifconfig')
    module.get_bin_path.return_value = '/sbin/ifconfig'
    module.params = {}
    module.params['gather_subset'] = ['!all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'].append('interfaces')
    module.params['gather_network_resources'].append('interfaces_ipv4')

# Generated at 2022-06-17 01:04:50.016825
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This is a unit test for the constructor of the class SunOSNetworkCollector.
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector.platform == 'SunOS'
    assert sunos_network_collector.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:04:52.062459
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:07.010833
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'

# Generated at 2022-06-17 01:05:11.069026
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of the class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:05:19.886310
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    ifconfig_path = module.get_bin_path('ifconfig', True)
    if not ifconfig_path:
        module.fail_json(msg='ifconfig not found')
    collector = SunOSNetworkCollector(module=module)
    interfaces, ips = collector.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'

# Generated at 2022-06-17 01:05:30.872018
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a dictionary of interfaces

# Generated at 2022-06-17 01:05:42.301969
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'ipv4' in interfaces['lo0']
    assert 'ipv6' in interfaces['lo0']
    assert 'flags' in interfaces['lo0']['ipv4'][0]
    assert 'mtu' in interfaces['lo0']['ipv4'][0]
    assert 'flags' in interfaces['lo0']['ipv6'][0]
    assert 'mtu' in interfaces['lo0']['ipv6'][0]
    assert 'macaddress' in interfaces['lo0']

# Generated at 2022-06-17 01:05:53.847728
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-17 01:05:56.551371
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:58.341661
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:06:01.701628
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:06:05.170288
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:21.205119
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, SUNOS_IFCONFIG_ALL, ''))
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:06:29.701777
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']['lo0']
    assert '::1' in ips['all_ipv6_addresses']['lo0']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']

# Generated at 2022-06-17 01:06:31.760246
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:32.944242
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:39.619535
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of the class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:06:49.650594
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

    # Test data

# Generated at 2022-06-17 01:07:01.260499
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('', (), {})()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.params = {}
    module.params['gather_network_resources'] = ['all']
    module.params['gather_subset'] = ['all']
    module.params['gather_network_interfaces'] = 'yes'
    module.params['gather_network_interfaces_facts'] = 'yes'
    module.params['gather_network_interfaces_addresses'] = 'yes'
    module.params['gather_network_interfaces_config'] = 'yes'
    module.params['gather_network_interfaces_ipv4_addresses'] = 'yes'

# Generated at 2022-06-17 01:07:09.768910
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = dict(gather_subset=['!all', '!min'])
    module.run_command = MagicMock(return_value=(0, SUNOS_IFCONFIG_ALL, ''))
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-17 01:07:13.081281
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:25.338349
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a test dictionary

# Generated at 2022-06-17 01:07:53.474227
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-17 01:07:56.609991
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:00.217886
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:11.339041
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    if not HAS_NETIFACES:
        module.fail_json(msg='netifaces python module required for this module')
    if not HAS_SUBPROCESS:
        module.fail_json(msg='subprocess python module required for this module')

    # Create a SunOSNetwork object
    sn = SunOSNetwork(module)

    # Get interfaces info
    interfaces, ips = sn.get_interfaces_info('/sbin/ifconfig')

    # Test the result
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-17 01:08:22.669923
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']


# Generated at 2022-06-17 01:08:25.039843
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:36.660003
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    obj = SunOSNetwork()

    # Create a test interface
    test_interface = {
        'device': 'lo0',
        'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}],
        'ipv6': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8252'}],
        'type': 'loopback',
        'macaddress': '00:00:00:00:00:00'
    }

    # Create a test interfaces dictionary
    test_interfaces = {
        'lo0': test_interface
    }

    # Create a test ips dictionary

# Generated at 2022-06-17 01:08:41.647402
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:43.301081
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:08:44.900380
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:09:42.735024
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    network_collector = SunOSNetworkCollector(module=module)
    network = network_collector.get_network_instance()
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-17 01:09:44.126454
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:09:46.999076
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork
    assert collector.fact_subclass == GenericBsdIfconfigNetwork


# Generated at 2022-06-17 01:09:48.626090
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:09:53.702071
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a dict to hold the current interface
    current_if = {}

    # Create a dict to hold the interfaces
    interfaces = {}

    # Create a list of words to be parsed
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']

    # Call the method parse_interface_line
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)

    # Assert the device is 'lo0'
    assert current_if['device'] == 'lo0'

    # Assert the type is 'loopback'

# Generated at 2022-06-17 01:10:06.154080
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a dictionary of interfaces

# Generated at 2022-06-17 01:10:08.354347
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:11.025284
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:13.031220
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:25.659464
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)

    # Test with a file containing a single interface
    test_file = open('/tmp/test_SunOSNetwork_get_interfaces_info_single_interface', 'w')
    test_file.write("""lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1
        inet6 ::1/128
        ether 8:0:20:0:0:0
        """)
    test_

# Generated at 2022-06-17 01:11:57.731008
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:12:10.776578
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']['lo0']
    assert '::1' in ips['all_ipv6_addresses']['lo0']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']

# Generated at 2022-06-17 01:12:22.066544
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    if not HAS_SUNOS_IFCONFIG:
        module.fail_json(msg='sunos_ifconfig required for this module')

    ifconfig_path = module.get_bin_path('ifconfig', True)
    if not ifconfig_path:
        module.fail_json(msg='ifconfig required for this module')

    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path)

    # Test for interface 'lo0'

# Generated at 2022-06-17 01:12:33.073579
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']['lo0']
    assert '::1' in ips['all_ipv6_addresses']['lo0']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']

# Generated at 2022-06-17 01:12:36.680627
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-17 01:12:38.542231
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:12:41.266307
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This is a unit test for the constructor of the class SunOSNetworkCollector.
    It tests the creation of an object for the class SunOSNetworkCollector.
    """
    SunOSNetworkCollector()

# Generated at 2022-06-17 01:12:42.993604
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of class SunOSNetworkCollector
    """
    SunOSNetworkCollector()

# Generated at 2022-06-17 01:12:45.684429
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:48.062607
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork