

# Generated at 2022-06-17 01:04:10.827688
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path)

    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv4'][0]['ptp'] == '127.0.0.1'

# Generated at 2022-06-17 01:04:21.022993
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']


# Generated at 2022-06-17 01:04:23.513737
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert facts._fact_class == SunOSNetwork
    assert facts._platform == 'SunOS'

# Generated at 2022-06-17 01:04:25.231710
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:04:28.109175
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:04:31.310426
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:04:42.618624
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefixlen'] == '128'

# Generated at 2022-06-17 01:04:45.502727
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:04:55.059418
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '1']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['ipv6'] == []
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-17 01:04:56.785134
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:05:05.037815
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:08.227305
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:18.533115
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a test dictionary for the 'interfaces' variable
    interfaces = {}

    # Create a test dictionary for the 'current_if' variable
    current_if = {}

    # Create a test dictionary for the 'ips' variable
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Create a test string for the 'out' variable

# Generated at 2022-06-17 01:05:29.823813
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, SUNOS_IFCONFIG_ALL, ''))
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:05:41.326934
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info = MagicMock(return_value=(None, None))
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector

# Generated at 2022-06-17 01:05:53.060740
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-17 01:06:04.141990
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
    assert current_if['ipv4'][0]['mtu']

# Generated at 2022-06-17 01:06:16.776635
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv4'][0]['ptp'] == '127.0.0.1'

# Generated at 2022-06-17 01:06:29.854339
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
    assert current_if

# Generated at 2022-06-17 01:06:40.970420
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-17 01:07:02.270921
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network
    import os
    import sys
    import tempfile
    import textwrap

    # Create a temporary file containing the output of 'ifconfig -a'
    # The file will be automatically deleted when the test ends.
    ifconfig_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-17 01:07:03.958443
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:06.818478
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:07:10.236703
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:23.300853
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.check_mode = False
    module.params = {}
    module.params['gather_subset'] = ['!all']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']

# Generated at 2022-06-17 01:07:32.573396
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = type('test_module', (object,), {})()
    test_module.run_command = lambda x: (0, '', '')
    test_module.get_bin_path = lambda x: '/sbin/ifconfig'
    test_module.fail_json = lambda **kwargs: None
    test_module.warn = lambda **kwargs: None
    test_module.params = {}
    test_module.params['gather_subset'] = ['all']
    test_module.params['gather_network_resources'] = ['all']
    test_module.params['gather_network_resources'] = ['all']
    test_module.params['gather_network_resources'] = ['all']
    test_module.params['gather_network_resources'] = ['all']

# Generated at 2022-06-17 01:07:36.620147
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:39.302516
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:50.202792
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:07:58.859723
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_SunOSNetwork = SunOSNetwork()
    test_interfaces = {}
    test_current_if = {}
    test_words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    test_current_if = test_SunOSNetwork.parse_interface_line(test_words, test_current_if, test_interfaces)
    assert test_current_if['device'] == 'lo0'
    assert test_current_if['type'] == 'loopback'
    assert test_current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-17 01:08:18.547107
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:08:21.032425
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:22.918205
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:35.299180
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    sunos_network = SunOSNetwork(module)
    interfaces, ips = sunos_network.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']

# Generated at 2022-06-17 01:08:36.596549
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:08:46.816951
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:08:48.956190
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:50.674945
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-17 01:09:00.482777
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    if not ifconfig_path:
        module.fail_json(msg='ifconfig not found')

    nm = SunOSNetwork(module)
    interfaces, ips = nm.get_interfaces_info(ifconfig_path)

    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:09:01.745517
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:09:47.622448
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:09:55.598055
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    ifconfig_path = '/sbin/ifconfig'
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = SunOSNetwork(module, ifconfig_path).parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']

# Generated at 2022-06-17 01:10:07.106454
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a test dictionary for the interfaces

# Generated at 2022-06-17 01:10:16.616921
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:10:28.800406
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command.return_value = (0, SUNOS_IFCONFIG_ALL, '')
    network_collector = SunOSNetworkCollector(module=module)
    interfaces, ips = network_collector.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-17 01:10:31.702516
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:43.355551
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    interfaces, ips = collector.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefix'] == '128'

# Generated at 2022-06-17 01:10:55.600324
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    assert network_collector.interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert network_collector.interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert network_collector.interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert network_collector.interfaces['lo0']['ipv4'][0]['network'] == '127.0.0.0'
    assert network_

# Generated at 2022-06-17 01:11:02.281601
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    # Create a SunOSNetwork object
    network_collector = SunOSNetworkCollector(module)
    network = network_collector.get_network_instance()

    # Create a test file
    test_file = open('/tmp/test_SunOSNetwork_get_interfaces_info.txt', 'w')

# Generated at 2022-06-17 01:11:13.975086
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0'

# Generated at 2022-06-17 01:12:09.361488
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:21.686076
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv4'][0]['ptp'] == '127.0.0.1'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-17 01:12:27.711135
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    collector = SunOSNetworkCollector(module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:40.088131
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']['lo0']
    assert '::1' in ips['all_ipv6_addresses']['lo0']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']

# Generated at 2022-06-17 01:12:42.023594
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:12:54.889981
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-17 01:13:03.435926
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']['lo0']
    assert '::1' in ips['all_ipv6_addresses']['lo0']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']

# Generated at 2022-06-17 01:13:15.804249
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info(ifconfig_path)
    network_collector.get_interfaces_ip()
    network_collector.get_default_interfaces()
    network_collector.get_interfaces_ipv6()
    network_collector.get_interfaces_ipv6_addresses()
    network_collector.get_interfaces_ipv6_prefixlen()
    network_collector.get_interfaces_ipv6_scope()
    network_collector.get_interfaces_mac()
    network_collector.get_interfaces_mtu()
   

# Generated at 2022-06-17 01:13:17.180872
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:13:19.134619
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork
