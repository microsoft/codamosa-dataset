

# Generated at 2022-06-17 01:03:57.556220
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:04:10.673734
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', '!min']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources']

# Generated at 2022-06-17 01:04:22.211440
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:04:27.587183
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info()
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces is not None
    assert ips is not None
    assert interfaces != {}
    assert ips != {}


# Generated at 2022-06-17 01:04:40.261858
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv4'][0]['ptp'] == '127.0.0.1'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-17 01:04:52.842619
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-17 01:05:03.717973
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0'

# Generated at 2022-06-17 01:05:13.372410
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-17 01:05:24.700862
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')

    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']

# Generated at 2022-06-17 01:05:30.806235
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:05:49.456383
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    iface = SunOSNetwork(module)
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = iface.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-17 01:05:50.987892
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:05:53.103382
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:04.191018
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv4'][0]['ptp'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-17 01:06:15.020482
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', 'network']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params

# Generated at 2022-06-17 01:06:16.776267
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:29.851688
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']
    assert 'lo0' in ips['all_ipv4_interfaces']
    assert 'lo0' in ips['all_ipv6_interfaces']
    assert 'lo0' in ips['interfaces']
    assert 'lo0' in ips['interfaces']['lo0']['ipv4']
    assert 'lo0' in ips['interfaces']['lo0']['ipv6']


# Generated at 2022-06-17 01:06:31.890612
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:41.541738
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a test string

# Generated at 2022-06-17 01:06:45.710876
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:06:58.098459
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:12.644693
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network = network_collector.get_network_instance()
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-17 01:07:15.037501
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:07:18.064369
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:28.551990
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-17 01:07:31.238467
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:07:44.203985
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()

    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:07:45.784414
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-17 01:07:54.476337
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-17 01:08:03.459474
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    iface = SunOSNetwork(module)
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = iface.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']
    assert current_if['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-17 01:08:27.691638
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector.platform == 'SunOS'
    assert sunos_network_collector.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:37.444796
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info = MagicMock(return_value=(None, None))
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector.get_interfaces_info.return_value = (None, None)
    network_collector

# Generated at 2022-06-17 01:08:48.846139
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:08:51.760124
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:53.821993
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:56.489982
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:08:59.829617
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test the constructor of the class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:09:13.316256
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    network = network_collector.get_network_facts()
    assert network['interfaces']['lo0']['ipv4'][0]['mtu'] == '8232'
    assert network['interfaces']['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert network['interfaces']['lo0']['ipv6'][0]['mtu'] == '8252'

# Generated at 2022-06-17 01:09:23.233369
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This is a unit test for method get_interfaces_info of class SunOSNetwork.
    """
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in ips['interfaces']
    assert 'ipv4' in interfaces['lo0']
    assert 'ipv6' in interfaces['lo0']
    assert 'inet' in interfaces['lo0']['ipv4'][0]
    assert 'inet6' in interfaces['lo0']['ipv6'][0]
    assert 'flags' in interfaces['lo0']['ipv4'][0]

# Generated at 2022-06-17 01:09:26.380904
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._fact_class.platform == 'SunOS'


# Generated at 2022-06-17 01:10:11.482374
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test SunOSNetworkCollector class constructor
    """
    SunOSNetworkCollector()

# Generated at 2022-06-17 01:10:19.502632
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

# Generated at 2022-06-17 01:10:22.915122
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:34.809941
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv4'][0]['ptp'] == '127.0.0.1'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-17 01:10:40.392900
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:10:50.843938
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network = SunOSNetwork(module=module)

    # test parsing of interface line
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {}
    interfaces = {}
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-17 01:11:01.582579
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    network_collector = SunOSNetwork(module)
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'

# Generated at 2022-06-17 01:11:05.516092
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-17 01:11:16.368033
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces, ips = network_collector.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '8252'

# Generated at 2022-06-17 01:11:20.419595
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This is a unit test for the constructor of the class SunOSNetworkCollector
    """
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector.platform == 'SunOS'
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-17 01:13:00.936266
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-17 01:13:14.610703
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info(network.get_bin_path('ifconfig'))

    assert interfaces['lo0']['ipv4'] == [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}]
    assert interfaces['lo0']['ipv6'] == [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'IPv6'], 'mtu': '8252'}]

# Generated at 2022-06-17 01:13:24.455195
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector.get_interfaces_info('/sbin/ifconfig')
    interfaces = network_collector.get_interfaces()
    ips = network_collector.get_all_ip_addresses()
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'
    assert interfaces['lo0']['ipv6'][0]['prefix'] == '128'

# Generated at 2022-06-17 01:13:26.507821
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-17 01:13:34.320150
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork()

    # Create a GenericBsdIfconfigNetwork object
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # Create a dictionary of interfaces
    interfaces = {}

    # Create a dictionary of ips
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Create a dictionary of current_if
    current_if = {}

    # Create a list of words

# Generated at 2022-06-17 01:13:35.221863
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-17 01:13:37.805992
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork
