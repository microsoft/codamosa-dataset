

# Generated at 2022-06-24 23:00:53.935598
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Arrange
    sun_o_s_network_obj_0 = SunOSNetwork()

    # Act
    out = sun_o_s_network_obj_0.get_interfaces_info('/bin/ifconfig')

    # Assert



# Generated at 2022-06-24 23:00:56.274064
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        assert isinstance(SunOSNetworkCollector()._fact_class, SunOSNetwork)
        assert SunOSNetworkCollector()._platform == 'SunOS'
        assert SunOSNetworkCollector()._fact_class.platform == 'SunOS'
    except AssertionError:
        raise
    else:
        pass
    finally:
        pass



# Generated at 2022-06-24 23:01:00.064317
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # No need to test get_interfaces_info, it's called from the base class (GenericBsdIfconfigNetwork)

    assert True

# Generated at 2022-06-24 23:01:08.742855
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

    words = 'bge0:3 flags=1e080863,c0<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST,AUTOCONF,DEPRECATED,NEEDFAIL,IPV6> mtu 1500 index 3'
    words = words.split()
    current_if = {}
    interfaces = {}


# Generated at 2022-06-24 23:01:10.988420
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-24 23:01:13.115753
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:01:15.656469
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(module)
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 23:01:17.688758
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()



# Generated at 2022-06-24 23:01:27.254520
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0.module)
    # Example of how Solaris prints a standard interface.

# Generated at 2022-06-24 23:01:36.067666
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Check that parsing of 'ifconfig -a' output works correctly.
    # Ansible output is not used in these tests.

    module = object
    module.run_command = run_command
    module.params = {'gather_network_resources': 'all'}

    sun_o_s_network_0 = SunOSNetwork(module)

    ifconfig_path = '/usr/sbin/ifconfig'

    interfaces, ips = sun_o_s_network_0.get_interfaces_info(ifconfig_path)

    for interface in interfaces:

        # On Solaris the device name is appended with a ':'
        assert interface.endswith(':')
        assert interfaces[interface]['type'] in ['loopback', 'ether']


# Generated at 2022-06-24 23:01:50.260007
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bytes_0 = b'{\x95meIT\xb9\x86\xc0#Z'
    int_0 = None
    float_0 = 156.66
    str_0 = '\x0b2ulu\n>'
    list_0 = [str_0]
    int_1 = 1146
    sun_o_s_network_0 = SunOSNetwork(list_0, int_1)
    var_0 = sun_o_s_network_0.parse_interface_line(bytes_0, int_0, float_0)
    assert var_0 == {'ipv4': [{'flags': 'UP', 'mtu': '1500'}], 'ipv6': [], 'device': 'lo', 'type': 'unknown'}


# Generated at 2022-06-24 23:01:50.871900
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    pass

# Generated at 2022-06-24 23:01:52.866141
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Collects for system on SunOS
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:57.694830
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    list_0 = []
    int_0 = 806
    sun_o_s_network_0 = SunOSNetwork(list_0, int_0)
    # assert of equality raised a TypeError on line 154
    assert sun_o_s_network_0.get_interfaces_info(list_0) == sun_o_s_network_0.get_interfaces_info(list_0)


# Generated at 2022-06-24 23:02:07.281983
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'{\x95meIT\xb9\x86\xc0#Z'
    int_0 = None
    float_0 = 156.66
    str_0 = '\x0b2ulu\n>'
    list_0 = [str_0]
    int_1 = 1146
    sun_o_s_network_0 = SunOSNetwork(list_0, int_1)
    str_1 = 'joz'
    tuple_0 = (str_0, str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(tuple_0)

# Generated at 2022-06-24 23:02:19.195552
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'{\x95meIT\xb9\x86\xc0#Z'
    int_0 = None
    float_0 = 156.66
    str_0 = '\x0b2ulu\n>'
    list_0 = [str_0]
    int_1 = 1146
    sun_o_s_network_0 = SunOSNetwork(list_0, int_1)
    dict_0 = {}

# Generated at 2022-06-24 23:02:28.435471
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:02:37.541856
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\x8b\x80&&\xda\xbb\x03\xca\x11\xed\x88\x8a\x00\xc0\x4f\xd4\x30\xc8\x13\x00b\xb0\x00\x01\x01\x05\x00\x06\x01\x02&\x07\x81\x04J\x05\xc0\xa80\n\x8d\x01\x81\x80\x00\x01\x00\x08\n\n\x86\xa8\x00\x01\x01\x08\x00\x06\x04\x00\x01\xc0\xa8'
    float_0 = 4.0

# Generated at 2022-06-24 23:02:44.668076
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    fixture_network_collector = SunOSNetworkCollector("TestNetworkCollector")
    SunOSNetwork_instance = fixture_network_collector.get_network_instance()

    fixture_network_collector.get_interfaces_info("ifconfig")
    # Expected result: None



# Generated at 2022-06-24 23:02:50.458076
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    list_0 = []
    int_0 = 1
    sun_o_s_network_collector_0 = SunOSNetworkCollector(list_0, int_0)

# Generated at 2022-06-24 23:03:09.228763
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'R`\x0bD$\x0b'
    bool_0 = bool(str_0)
    bool_1 = bool(str_0)
    bool_2 = bool(str_0)
    list_0 = [str_0, bool_0]
    str_1 = 'lH\x0b\x0b'
    bool_3 = bool(str_1)
    bool_4 = bool(str_1)
    bool_5 = bool(str_0)
    bool_6 = bool(str_1)
    bool_7 = bool(str_0)
    bool_8 = bool(str_1)
    bool_9 = bool(str_1)
    bool_10 = bool(str_0)
    bool_11 = bool(str_1)
    bool

# Generated at 2022-06-24 23:03:14.200390
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    tuple_0 = ()
    float_0 = -1338.04
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    dict_0 = {str_0: sun_o_s_network_collector_0, sun_o_s_network_collector_0: str_0, float_0: float_0}
    sun_o_s_network_0 = SunOSNetwork(dict_0)
    tuple_0 = sun_o_s_network_0.parse_interface_line(str_0, str_0, tuple_0)
    assert (tuple_0 == ())


# Generated at 2022-06-24 23:03:20.214210
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    float_0 = -1338.04
    int_0 = -99991
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(int_0)
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:03:31.394407
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '\x13\x1e\x04\x1c\x14j\x07\x15\x11\x12j\x1d\x1b\t\x04\x06'
    list_0 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9a', 'b', 'c', 'd', 'e', 'f']
    dict_0 = {'\x13\x1e\x04\x1c\x14j\x07\x15\x11\x12j\x1d\x1b\t\x04\x06': 'Totally not a real MAC address.'}

# Generated at 2022-06-24 23:03:40.716658
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'D\x1a;\x1bl\r\r\r@\x0f'
    float_0 = 0.35
    tuple_0 = (str_0,)
    float_1 = float_0
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_1)
    dict_0 = {str_0: sun_o_s_network_collector_0, sun_o_s_network_collector_0: str_0, float_0: float_0}
    sun_o_s_network_0 = SunOSNetwork(dict_0)
    sun_o_s_network_0.get_interfaces_info(tuple_0)


# Generated at 2022-06-24 23:03:45.760923
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'eyb\x1a1\xe3'
    tuple_0 = ()
    float_0 = -1196.28
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    list_0 = list()
    list_0.append(sun_o_s_network_collector_0)
    list_0.append(sun_o_s_network_collector_0)
    # testing if the object sun_o_s_network_collector_0 is equal to itself ie, object itself
    assert sun_o_s_network_collector_0 == sun_o_s_network_collector_0
    # testing if the object sun_o_s_network_collector_0 is equal to the object of another class
    assert sun_o_

# Generated at 2022-06-24 23:03:55.423085
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    tuple_0 = ()
    float_0 = -1338.04
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    dict_0 = {str_0: sun_o_s_network_collector_0, sun_o_s_network_collector_0: str_0, float_0: float_0}
    sun_o_s_network_0 = SunOSNetwork(dict_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:04:01.545851
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    tuple_0 = ()
    float_0 = -1338.04
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    dict_0 = {float_0: float_0}
    sun_o_s_network_0 = SunOSNetwork(dict_0)
    var_0 = sun_o_s_network_0.get_interfaces_info('lo0')


# Generated at 2022-06-24 23:04:09.350902
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    tuple_0 = ()
    float_0 = -1338.04
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    dict_0 = {str_0: sun_o_s_network_collector_0, sun_o_s_network_collector_0: str_0, float_0: float_0}
    sun_o_s_network_0 = SunOSNetwork(dict_0)
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    tuple_0 = ()
    float_0 = -1338.04
    sun_o_s_network_

# Generated at 2022-06-24 23:04:14.219690
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = -1338.04
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)


# Generated at 2022-06-24 23:04:33.881870
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    var_0 = ()
    float_0 = -1336.6888443794473
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    var_1 = sun_o_s_network_0.parse_interface_line(str_0, str_0, var_0)

### END ITERATOR ### END ITERATOR ### END ITERATOR ### END ITERATOR ### END ITERATOR ### END ITERATOR ### END ITERATOR ###

### END ITERATOR ### END ITERATOR ### END ITERATOR ### END ITER

# Generated at 2022-06-24 23:04:34.606374
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-24 23:04:39.869071
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    var_0 = ()
    float_0 = -1336.6888443794473
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:04:47.225400
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    var_0 = ()
    float_0 = -1336.6888443794473
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:04:58.130910
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '$\x1d\x1f\x1eP\x04\x03`\x0e\x1bzA'
    dict_0 = {'\x1e\x06^\x07\x17\x06k\x0e\x0f\x1c\x1a\x16\x07\x11': {'\x12': [{'\x1e': str_0, '\x1f': str_0}], '\x14': '\x1e'}}
    dict_1 = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector('')
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    dict_0, dict_2

# Generated at 2022-06-24 23:04:59.088776
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 23:05:05.168344
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '0DmK\x0bF8\x0b6\x17H'
    var_0 = ''
    float_0 = 8.970461659759467
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:05:17.054419
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'r\rX\r\x0c\x1a\x00\x0f&\x0b\x1b\x1d'
    int_0 = 429082341
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    sun_o_s_network_0 = SunOSNetwork(str_0, str_0)
    var_0 = sun_o_s_network_collector_0.facts
    var_1 = sun_o_s_network_collector_0.facts()

# Generated at 2022-06-24 23:05:25.756980
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    var_0 = ()
    float_0 = -1336.6888443794473
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    str_1 = 'R.\x02\x01e\x01\x00\x00\x00\x00\x00\x000\x00'

# Generated at 2022-06-24 23:05:29.365977
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = -9.404062111585423
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)


# Generated at 2022-06-24 23:05:49.108729
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_os_network_collector_0 = SunOSNetworkCollector()


# test_case_0()

# test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:05:56.430262
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = ')\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!\x0b!'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)

# Generated at 2022-06-24 23:06:01.108268
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '5\x1f\x1d|\x1e\x1c~\x1f\x1e\x1f\x1fK\x1f\x1c|\x1e\x1c~\x1f\x1e\x1f\x1fK'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    str_1 = 'ne\x0f\x0bP\t\rT'
    var_2, var_3 = sun_o_s_network_0.get_interfaces_info(str_1)


# Generated at 2022-06-24 23:06:09.256336
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_1 = ()
    var_2 = ()
    str_2 = '   xge0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2'
    sun_o_s_network_1 = SunOSNetwork(str_1)
    var_3 = sun_o_s_network_1.parse_interface_line(str_2, str_2, var_2)


# Generated at 2022-06-24 23:06:15.919530
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '~\x03\x1cP_\x04\x17\x12\x0e\x1c\x1b'
    str_1 = '5U6\x17\x01\x0b\x11\x12?0&'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = ()
    assert sun_o_s_network_0.get_interfaces_info(str_1) == (var_0, var_0)


# Generated at 2022-06-24 23:06:25.879835
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ',Vlk\x1f4\x1e\x1e\x0b'
    str_1 = 'h:\x0e\x1d\x1c\x19<\x15'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    sun_o_s_network_1 = SunOSNetwork(str_1)
    var_0 = ()
    var_1 = ()
    sun_o_s_network_0.get_interfaces_info(var_0)
    sun_o_s_network_1.get_interfaces_info(var_1)


# Generated at 2022-06-24 23:06:31.727710
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    var_0 = ()
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_1 = False
    var_2 = sun_o_s_network_0.get_interfaces_info(var_1)
    var_3 = (var_1, var_2)


# Generated at 2022-06-24 23:06:43.735821
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    var_0 = {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}], 'ipv6': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'IPv6'], 'mtu': '8252'}], 'type': 'loopback', 'macaddress': 'unknown'}
    var_1 = {'all_ipv6_addresses': [], 'all_ipv4_addresses': []}
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_2 = sun_o_s_network_0.get

# Generated at 2022-06-24 23:06:49.077778
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Try to test constructor with no given argument
    sun_os_network_collector = SunOSNetworkCollector()
    assert sun_os_network_collector is not None


# Unit tests for node_ip()

# Generated at 2022-06-24 23:06:57.703596
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = '0:10:20:d0:e0:f0'
    var_0 = ()
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_1 = sun_o_s_network_0.parse_interface_line(str_0, str_0, var_0)
    assert var_1 == var_0



# Generated at 2022-06-24 23:07:20.071633
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    var_0 = ()
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_1 = sun_o_s_network_0.parse_interface_line(str_0, str_0, var_0)




# Generated at 2022-06-24 23:07:23.203893
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'V\x00\x0b\x1e'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = ()
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:07:27.349443
# Unit test for constructor of class SunOSNetworkCollector

# Generated at 2022-06-24 23:07:32.514901
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'I\x0cx\x17!\n\tA\x7f'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)

test_case_0()
test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:07:36.023475
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class.platform == 'SunOS'
    assert sun_o_s_network_collector_0._platform == 'SunOS'


# Generated at 2022-06-24 23:07:38.155752
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_os_network_collector = SunOSNetworkCollector()
    assert isinstance(sun_os_network_collector, SunOSNetworkCollector)


# Generated at 2022-06-24 23:07:39.713005
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector_0 = SunOSNetworkCollector()
    var_2 = collector_0.get_methods()
    collector_0.collect()

# Generated at 2022-06-24 23:07:42.698129
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()

# Generated at 2022-06-24 23:07:48.128260
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:07:58.597811
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Initialize mock variables
    str_0 = "vx"
    str_1 = ''

# Generated at 2022-06-24 23:08:40.415780
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_1 = 'test_value_2'
    str_2 = 'test_value_3'
    var_2 = ()
    sun_o_s_network_1 = SunOSNetwork(str_1)
    var_3 = sun_o_s_network_1.parse_interface_line(str_1, str_2, var_2)


# Generated at 2022-06-24 23:08:51.260713
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    # str_1 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    # str_2 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    # str_3 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    # str_4 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    str_5 = ']Iv\r^&\x0b"*`(2V_\r1#wi'

# Generated at 2022-06-24 23:08:57.986048
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    var_0 = ()
    sun_o_s_network_0 = SunOSNetwork(str_0)
    sun_o_s_network_0.module = str_0
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:09:07.115279
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    file_name = os.path.basename(__file__)
    file_dir = os.path.dirname(__file__)
    test_dir = os.path.join(file_dir, "testdata")
    temp_dir = os.path.join(test_dir, "temp.dir")
    test_file_name = os.path.join(temp_dir, "test.txt")
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)
        
    # Test 1
    # Test if the class object is created
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0 is not None
    
    # Test 2
    # Test if the get_network_interfaces

# Generated at 2022-06-24 23:09:09.000765
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    osx_sun_os_network_0 = SunOSNetwork(None)

    assert osx_sun_os_network_0.get_interfaces_info(None) == (None, None)



# Generated at 2022-06-24 23:09:10.058926
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:09:16.665619
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    params = dict(
        words = dict(type='str', required=True),
        current_if = dict(type='str', required=True),
        interfaces = dict(type='tuple', required=True),
    )
    module = AnsibleModule(
        argument_spec=params
    )

    test_case_0()



# Generated at 2022-06-24 23:09:22.194360
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = ()
    var_1 = sun_o_s_network_0.get_interfaces_info(var_0)


# Generated at 2022-06-24 23:09:24.015118
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_network_collector_0 = SunOSNetworkCollector()
    return

if __name__ == '__main__':
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:09:24.914860
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  var_SunOSNetworkCollector = SunOSNetworkCollector()

# Generated at 2022-06-24 23:10:14.852280
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = ']Iv\r^&\x0b"*`(2V_\r1#wi'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)


# Generated at 2022-06-24 23:10:17.193038
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()


# Generated at 2022-06-24 23:10:26.160173
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'h\x14\x07\x06\x0b\x1b<\x0c\x17\x1e\x06\x10\x0c\x01\x1e\x0c\x1f\x1e\x0b\x07\x06\x00\x06'
    var_0 = ()
    sun_o_s_network_0 = SunOSNetwork(str_0)
    sun_o_s_network_0.get_interfaces_info(var_0)


# Generated at 2022-06-24 23:10:30.036254
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_1 = SunOSNetworkCollector.get_instance()
    print(sun_o_s_network_1)

if __name__ == "__main__":
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:10:35.539375
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module_5 = AnsibleModuleStub(argument_spec={})
    sun_o_s_network_collector_0 = SunOSNetworkCollector(module_5)
    assert sun_o_s_network_collector_0.platform == 'SunOS'


# Generated at 2022-06-24 23:10:38.507922
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    sun_o_s_network_0 = SunOSNetwork()
    var_1 = sun_o_s_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:10:42.607961
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'lo0: flags=2001000849 mtu 8232 index 1\n  inet 127.0.0.1 netmask ff000000\n  inet6 ::1/128\n  groups: lo\n'
    str_1 = 'lo0: flags=2001000849 mtu 8232 index 1\n  inet 127.0.0.1 netmask ff000000\n  inet6 ::1/128\n  groups: lo\n'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    assert not sun_o_s_network_0.get_interfaces_info(str_1)
