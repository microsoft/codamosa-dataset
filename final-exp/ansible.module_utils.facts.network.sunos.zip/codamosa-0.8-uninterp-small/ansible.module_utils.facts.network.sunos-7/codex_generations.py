

# Generated at 2022-06-24 23:01:03.417846
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_class = SunOSNetworkCollector(None, None, None)
    assert fact_class._fact_class == SunOSNetwork
    assert fact_class._platform == 'SunOS'
    assert fact_class.legacy_facts

# Generated at 2022-06-24 23:01:06.762624
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    dict_0 = None
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(dict_0, bool_0)
    bool_1 = False
    str_0 = 'ifconfig'
    str_1 = sun_o_s_network_0.get_interfaces_info(str_0)
    assert str_1 == '/sbin/ifconfig'

# Generated at 2022-06-24 23:01:12.942605
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    dict_0 = None
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(dict_0, bool_0)
    try:
        assert sun_o_s_network_0.get_interfaces_info("--version") == None
    except:
        raise Exception("Not equal")


# Generated at 2022-06-24 23:01:15.149677
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    import sys
    import os
    import json

    test_case_0()
    test_case_0()


# Generated at 2022-06-24 23:01:20.985833
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    dict_0 = None
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(dict_0, bool_0)
    # following line throws an exception if get_interfaces_info is not implemented correctly
    sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')

test_case_0()
test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:01:23.100334
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    dict_0 = None
    sun_o_s_network_collector_0 = SunOSNetworkCollector(dict_0)


# Generated at 2022-06-24 23:01:24.716128
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector('SunOS')

# Generated at 2022-06-24 23:01:33.850929
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_2['ipv4'] = []
    dict_2['ipv6'] = []
    dict_2['type'] = 'unknown'
    dict_3 = {}
    dict_3['ipv4'] = []
    dict_3['ipv6'] = []
    dict_3['type'] = 'unknown'
    dict_4 = {}
    dict_4['ipv4'] = []
    dict_4['ipv6'] = []
    dict_4['type'] = 'unknown'
    dict_5 = {}
    dict_5['ipv4'] = []
    dict_5['ipv6'] = []
    dict_5['type'] = 'unknown'
    dict_6 = {}

# Generated at 2022-06-24 23:01:42.221984
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    dict_0 = None
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(dict_0, bool_0)
    list_0 = []
    dict_1 = None
    dict_2 = None
    dict_2 = sun_o_s_network_0.parse_interface_line(list_0, dict_1, dict_2)

if __name__ == '__main__':
    # test_case_0()
    # test_SunOSNetwork_parse_interface_line()
    pass

# Generated at 2022-06-24 23:01:46.712921
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    dict_0 = None
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(dict_0, bool_0)
    string_0 = "/sbin/ifconfig"
    str_0 = sun_o_s_network_0.get_interfaces_info(string_0)
    print(str_0)

# Generated at 2022-06-24 23:01:53.256444
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0 is not None, 'The object should be ok'


# Generated at 2022-06-24 23:01:59.878264
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_0.facts
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:02:04.777975
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    sun_o_s_network_0 = SunOSNetwork()
    assert sun_o_s_network_0.get_interfaces_info(ifconfig_path='') == ([], {})


# Generated at 2022-06-24 23:02:12.943247
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork()

    sun_o_s_network_collector_0._fact_class = sun_o_s_network_0
    sun_o_s_network_0.module = AnsibleModuleMock()

# Generated at 2022-06-24 23:02:14.872554
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 23:02:17.423479
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:02:19.193621
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:27.467520
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:02:29.980534
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:02:34.322361
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork({})
    sun_o_s_network_0.interface_name = 'lo0'
    sun_o_s_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:02:50.479527
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    TEST_INTERFACE_0 = {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '8232'}], 'macaddress': 'unknown', 'ipv6': [{'flags': ['UP', 'RUNNING', 'MULTICAST', 'IPv6'], 'mtu': '8252'}], 'type': 'loopback'}

# Generated at 2022-06-24 23:02:59.880322
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # ##
    # Call method get_interfaces_info of class SunOSNetwork, with arg ifconfig_path="echo"
    # Set argument(s) for method get_interfaces_info of class SunOSNetwork
    interface_0_ipv4_0_flag_0 = "UP"
    interface_0_ipv4_0_flag_1 = "IPv4"
    interface_0_ipv4_0_flag_2 = "BROADCAST"
    interface_0_ipv4_0_flag_3 = "RUNNING"
    interface_0_ipv4_0_flag_4 = "MULTICAST"
    interface_0_ipv4_0_flag_5 = "SIMPLEX"
    interface

# Generated at 2022-06-24 23:03:03.534886
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), SunOSNetworkCollector)
    assert isinstance(SunOSNetworkCollector()._fact_class, SunOSNetwork)
    assert SunOSNetworkCollector()._platform == 'SunOS'

# Generated at 2022-06-24 23:03:12.177649
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()

# Generated at 2022-06-24 23:03:21.890869
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork()


# Generated at 2022-06-24 23:03:25.896359
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()

    # Call the method get_interfaces_info of SunOSNetwork
    sun_o_s_network_0.get_interfaces_info(sun_o_s_network_0.module.get_bin_path('ifconfig'))


# Generated at 2022-06-24 23:03:29.282646
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert(sun_o_s_network_collector.platform() == 'SunOS')
    assert(len(sun_o_s_network_collector.defaults())[0]) > 0



# Generated at 2022-06-24 23:03:30.455752
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 23:03:35.359578
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    current_obj = SunOSNetworkCollector()
    if isinstance(current_obj, SunOSNetworkCollector):
        print('Constructor test Successful for SunOSNetworkCollector')
    else:
        print('Constructor test Failed for SunOSNetworkCollector')


# Generated at 2022-06-24 23:03:37.332704
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert sun_o_s_network_collector_0.__class__.__name__ == 'SunOSNetworkCollector'


# Generated at 2022-06-24 23:03:44.522658
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_os_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:03:52.611166
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'ev;MR5ws}6aM\\'
    str_1 = 'M>*o0'
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    var_0 = sun_o_s_network_0.parse_nd6_line(str_0, str_1)


# Generated at 2022-06-24 23:03:58.256593
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'ev;MR5ws}6aM\\'
    str_1 = 'M>*o0'
    str_2 = '8w`T=^a]PlamHNIwT'
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, str_1, str_2)


# Generated at 2022-06-24 23:04:01.073680
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:04:05.975978
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    str_0 = 'w[f@D(bZ!9X'
    str_1 = 'f5%&y|:r|r~lQ,1\x7fw'
    str_2 = ';2@B\x7f#o'
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:04:08.259902
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector) == True


# Generated at 2022-06-24 23:04:10.445011
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork(list_0)
    assert sun_o_s_network_0.parse_interface_line(str_0, str_1, str_2) is None

# Generated at 2022-06-24 23:04:16.604306
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    print("Running get_interfaces_info unit test for class SunOSNetwork")
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    str_0 = '}J<>NuV7R'
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    print(var_0)


# Generated at 2022-06-24 23:04:21.415001
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'C;A+^aqM}]Zb'
    str_1 = 'C*^v'
    str_2 = 'pGicEh#;OK~O;+'
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, str_1, str_2)


# Generated at 2022-06-24 23:04:28.252897
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    list_0 = []
    sun_o_s_network_collector_0 = SunOSNetworkCollector(list_0)
    pass


# Generated at 2022-06-24 23:04:48.818409
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # The SunOSNetwork class is tested as part of the base class, Network
    # so here we're just testing that the SunOS-specific class is being used.

    test_ifconfig_path = '/sbin/i'
    test_module = object()
    test_module.run_command = object()
    test_module.run_command.return_value = ('0', '', '')

# Generated at 2022-06-24 23:04:57.816185
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    str_0 = 'einput'
    str_1 = 'R'
    str_2 = "n'A'i"
    dict_0 = sun_o_s_network_0.parse_interface_line(str_0, str_1, str_2)
    assert dict_0['macaddress'] == 'unknown'
    assert dict_0['ipv6'] == [{'mtu': 'R', 'flags': 'n'}]
    assert dict_0['ipv4'] == []
    assert dict_0['type'] == 'unknown'
    assert dict_0['device'] == 'einput'



# Generated at 2022-06-24 23:05:06.247728
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'ev;MR5ws}6aM\\'
    str_1 = 'M>*o0'
    str_2 = '8w`T=^a]PlamHNIwT'
    str_3 = 'MR5ws}6aM\\'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    str_4 = 'n_6w.7-U`&n'
    str_5 = 'K'
    str_6 = '8w`T=^a]PlamHNIwT'
    var_0 = sun_o_s_network_0.parse_interface_line(str_1, str_2, str_3)
    str_7 = '/>J&gv!8p'
    str_8 = 'K'
   

# Generated at 2022-06-24 23:05:09.697343
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    # test_case_0()
    test_SunOSNetwork()



# Generated at 2022-06-24 23:05:15.234417
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(None)
    str_0 = 'bq3^jak_I+L-{'
    str_1 = 'JWwrn8'
    str_2 = 'Jt'
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0, str_1, str_2)

# Generated at 2022-06-24 23:05:24.490232
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    str_0 = 'lo0'
    str_1 = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    str_2 = ' '
    str_3 = '  inet 127.0.0.1 netmask ff000000  '
    str_4 = '   '
    str_5 = ' options=3<PERFORMNUD,DAD>'
    str_6 = '   '
    str_7 = '    '

# Generated at 2022-06-24 23:05:36.517010
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    list_0 = []
    str_0 = 'ev;MR5ws}6aM\\'
    str_1 = 'M>*o0'
    str_2 = '8w`T=^a]PlamHNIwT'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_

# Generated at 2022-06-24 23:05:38.439235
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    tmp_1 = SunOSNetworkCollector()
    print(tmp_1)


# Generated at 2022-06-24 23:05:41.821949
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

if __name__ == '__main__':
    test_SunOSNetworkCollector()
    test_case_0()

# Generated at 2022-06-24 23:05:48.815816
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_SunOSNetworkCollector_instance = SunOSNetworkCollector()
    assert test_SunOSNetworkCollector_instance._platform == 'SunOS'
    assert isinstance(test_SunOSNetworkCollector_instance, NetworkCollector)
    assert not hasattr(test_SunOSNetworkCollector_instance, '_platform')
    assert isinstance(test_SunOSNetworkCollector_instance, NetworkCollector)


# Generated at 2022-06-24 23:06:10.291857
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  # Nothing to test right now
  pass


# Generated at 2022-06-24 23:06:19.407170
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Initialize
    str_0 = ' *:flags=0x2<UP,BROADCAST> '
    str_1 = ' mtu 1500 index 3 inet 192.168.1.104 netmask ffffff00 broadcast 192.168.1.255 '
    str_2 = 'ether a0:0d:3a:99:c8:c0 '
    str_3 = 'groupname managernic '
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    sun_o_s_network_1 = SunOSNetworkCollector(list_0)
    # Invoke method
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, str_1, str_2, str_3)



# Generated at 2022-06-24 23:06:25.602043
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    list_0 = []
    sun_o_s_network_collector_0 = SunOSNetworkCollector(list_0)
    assert sun_o_s_network_collector_0.platform == 'SunOS'
    assert sun_o_s_network_collector_0.fact_class == SunOSNetwork
    assert sun_o_s_network_collector_0.fact_subclasses == []


# Generated at 2022-06-24 23:06:33.369194
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    str_0 = 'ev;MR5ws}6aM\\'
    str_1 = 'M>*o0'
    str_2 = '8w`T=^a]PlamHNIwT'
    str_3 = 'kP'
    str_4 = '+'
    str_5 = '~b1'
    str_6 = 'kP'
    str_7 = '+'
    str_8 = '~b1'
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    str_9 = 'Z[w'
    str_10 = 'M>*o0'

# Generated at 2022-06-24 23:06:35.017457
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:06:41.001572
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'lo0:3'
    str_1 = 'LOOPBACK'
    dict_0 = {}
    dict_1 = {}
    sun_o_s_network_0 = SunOSNetwork(dict_0)
    sun_o_s_network_0.parse_interface_line(str_0, str_1, dict_1)


# Generated at 2022-06-24 23:06:46.991893
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'MR5ws}6aM\\`T=^a]PlamHNIwT'
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    str_1 = '5P=2lF5(k}]q3~u59e'
    var_0 = sun_o_s_network_0.get_interfaces_info(str_1)


# Generated at 2022-06-24 23:06:48.636265
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:06:54.329669
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Setup
    str_0 = 'ev;MR5ws}6aM\\'
    str_1 = 'M>*o0'
    str_2 = '8w`T=^a]PlamHNIwT'
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    var_0 = sun_o_s_network_0.parse_ether_line(str_0, str_1, str_2)

    sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:06:58.038250
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    _fact_class = SunOSNetwork
    _platform = 'SunOS'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(_fact_class, _platform)
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)
    

# Generated at 2022-06-24 23:07:25.820725
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test basic interface parsing with SunOSNetwork.
    """
    raw_out = """lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        groupname somename
        options=3<PERFORMNUD,ACCEPT_RTADV,PREFER_TEMPADDR>
        ether 0:1:2:d:e:f
        media: Ethernet autoselect (1000baseT full-duplex,master)
        status: inactive
    """

# Generated at 2022-06-24 23:07:32.883955
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_2.update({0: var_3})
    var_1.update({0: var_2})
    str_0 = '/usr/sbin/ifconfig'
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:07:39.427796
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'lo0:3'
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    var_1 = sun_o_s_network_0.parse_interface_line(str_0, str_0, var_0)
    # 'str_0' is the correct value to pass to get_interfaces_info
    var_2 = var_1
    var_3 = var_0
    var_4 = {}
    sun_o_s_network_0.get_interfaces_info(var_2, var_3, var_4)


# Generated at 2022-06-24 23:07:44.206310
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork({})
    assert sun_o_s_network_0.get_interfaces_info() == (None, None)


# Generated at 2022-06-24 23:07:45.503679
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    print('test_SunOSNetwork_parse_interface_line')
    test_case_0()


# Generated at 2022-06-24 23:07:56.428189
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork({})
    sun_o_s_network_1 = SunOSNetwork({})
    str_0 = '/usr/sbin/ifconfig'
    str_1 = '/usr/sbin/ifconfig'
    sun_o_s_network_2, sun_o_s_network_3 = sun_o_s_network_0.get_interfaces_info(ifconfig_path=str_0)
    sun_o_s_network_4, sun_o_s_network_5 = sun_o_s_network_1.get_interfaces_info(ifconfig_path=str_1)


# Generated at 2022-06-24 23:08:06.025902
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_1 = SunOSNetworkCollector()
    var_3 = sun_o_s_network_collector_1._platform
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    var_4 = sun_o_s_network_collector_1._fact_class
    str_1 = '_fact_class'
    str_2 = '_platform'
    assert(isinstance(sun_o_s_network_collector_0, GenericBsdIfconfigNetwork))
    assert(var_4 == var_3)

# Generated at 2022-06-24 23:08:08.567797
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Parameters
    ifconfig_path = '-a'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_2 = sun_o_s_network_0.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-24 23:08:09.808697
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-24 23:08:18.877062
# Unit test for constructor of class SunOSNetworkCollector

# Generated at 2022-06-24 23:09:04.230750
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = 'test_value_0'
    var_1 = 'test_value_1'
    sun_o_s_network_0 = SunOSNetwork(var_0)
    sun_o_s_network_0.get_interfaces_info(var_1)


# Generated at 2022-06-24 23:09:14.385873
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector(facts)
    assert sun_o_s_network_collector_0.platform == 'SunOS'
    assert sun_o_s_network_collector_0.fact_class == SunOSNetwork
    assert sun_o_s_network_collector_0.options == {}
    assert sun_o_s_network_collector_0.interfaces == []
    assert sun_o_s_network_collector_0.validate_interfaces == []
    assert sun_o_s_network_collector_0.exclude_interfaces == []
    assert sun_o_s_network_collector_0.facts == {}

# Generated at 2022-06-24 23:09:18.637291
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_2 = SunOSNetworkCollector()
    var_3 = 'SunOS'
    var_4 = var_2._platform
    var_4 = assertion_utils.assertEqual(var_4, var_3)
    var_5 = SunOSNetwork
    var_6 = var_2._fact_class
    var_6 = assertion_utils.assertEqual(var_6, var_5)


# Generated at 2022-06-24 23:09:22.543333
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'ether 0:1:2:d:e:f'
    sun_o_s_network_0 = SunOSNetwork({})
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    print(var_0)


# Generated at 2022-06-24 23:09:26.234914
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(dict())
    for var_0 in range(0, 5):
        sun_o_s_network_0.get_interfaces_info(var_0)



# Generated at 2022-06-24 23:09:28.869156
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0.platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:09:35.083596
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'lo0:3'
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    var_1 = sun_o_s_network_0.parse_interface_line(str_0, str_0, var_0)




# Generated at 2022-06-24 23:09:36.765421
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_2 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:09:43.239112
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_1 = ['lo0:3']
    var_2 = {}
    sun_o_s_network_1 = SunOSNetwork(var_2)
    var_3 = sun_o_s_network_1.parse_interface_line(str_1, str_1, var_2)
    assert(var_3 == {'ipv6': [], 'macaddress': 'unknown', 'ipv4': [{'flags': ['UP',
                      'LOOPBACK', 'RUNNING'], 'mtu': '8232'}], 'device': 'lo0', 'type':
                      'loopback'})


# Generated at 2022-06-24 23:09:49.415975
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Assigning '{}' to 'ifconfig_path'
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    # Call to Mock()
    sun_o_s_network_0 = SunOSNetwork({})
    str_1 = 'ifconfig_path'
    str_2 = '-a'
    str_3 = 'out'
    var_2 = sun_o_s_network_0.get_interfaces_info(str_1)
    assert var_2[0] == str

# Generated at 2022-06-24 23:10:39.716776
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'
    assert obj._net_filter is None

# Generated at 2022-06-24 23:10:40.917999
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_2 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:10:46.960727
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    iface_fake= {'device': 'lo0',
        'ipv4': [{'mtu': '0', 'addr': [], 'netmask': []}],
        'macaddress': 'unknown',
        'ipv6': [{'mtu': '0', 'addr': [], 'netmask': []}],
        'type': 'loopback'}
    get_interfaces_info_fake = {'lo0': iface_fake }
    get_interfaces_info_fake.update(iface_fake)