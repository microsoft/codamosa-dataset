

# Generated at 2022-06-24 23:01:02.417307
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'a'
    str_1 = 'b'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    assert sun_o_s_network_0 is not None
    sun_o_s_network_1 = SunOSNetwork(str_0)
    assert sun_o_s_network_1 is not None

    sun_o_s_network_0.module = mock_ansible_module(params=dict())
    sun_o_s_network_0.module.run_command = MagicMock(return_value=(0, '0', '0'))

    sun_o_s_network_1.module = mock_ansible_module(params=dict())

# Generated at 2022-06-24 23:01:10.769322
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork('/sbin/ifconfig')
    sun_o_s_network_1 = SunOSNetwork('/sbin/ifconfig')

    with open('../ansible_collections/ansible/os_collect_config/tests/unit/module_utils/facts/network/sunos/test_1.txt', 'r') as fd_0:
        contents_0 = fd_0.read()

    with open('../ansible_collections/ansible/os_collect_config/tests/unit/module_utils/facts/network/sunos/test_2.txt', 'r') as fd_1:
        contents_1 = fd_1.read()

    contents_1 = contents_1.replace("\n", "\r\n")


# Generated at 2022-06-24 23:01:12.681892
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector._fact_class(), SunOSNetwork)



# Generated at 2022-06-24 23:01:15.511404
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    assert callable(SunOSNetwork.get_interfaces_info)


# Generated at 2022-06-24 23:01:17.932879
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:01:27.126155
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path_0 = 'ifconfig_path_0'
    str_0 = '_-'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    str_1 = '_-'
    rc_0, out_0, err_0 = sun_o_s_network_0.module.run_command([ifconfig_path_0, str_1])
    info_dic_0 = {}
    current_if_0 = {}
    ips_0 = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    current_if_1 = sun_o_s_network_0.get_interfaces_info(ifconfig_path_0)
    assert (current_if_1 == current_if_0)


# Generated at 2022-06-24 23:01:36.560018
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    tempdir = '/etc/ansible'
    ifconfig_path = '/sbin/ifconfig'
    sun_o_s_network_0 = SunOSNetwork('/etc/ansible')
    sun_o_s_network_0.module.run_command = MagicMock(return_value=(0, '', ''))
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)
    RC, OUT, ERR = sun_o_s_network_0.module.run_command.call_args[0]
    assert RC == ['/sbin/ifconfig', '-a']


# Generated at 2022-06-24 23:01:41.329221
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '_-'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    str_0 = '_-'
    int_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:01:44.024868
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # assert wordcount is not zero
    assert SunOSNetwork('_-').get_interfaces_info('ifconfig_path')[0] != 0


# Generated at 2022-06-24 23:01:51.535968
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    f = open('sample-outputs/ifconfig-a')
    out = f.read()
    f.close()
    ifconfig_path = '/sbin/ifconfig'
    sun_o_s_network_0 = SunOSNetwork('')
    interfaces, ips = sun_o_s_network_0.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 23:02:03.247869
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  sun_o_s_network_collector_0 = SunOSNetworkCollector()
  assert SunOSNetworkCollector._fact_class == sun_o_s_network_collector_0._fact_class
  assert SunOSNetworkCollector._platform == sun_o_s_network_collector_0._platform

# Generated at 2022-06-24 23:02:10.948919
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'YI.p'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xe5\x80\xf4\x03\xa5\xeb\x9d\x04\x01'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:02:20.411394
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'Y\x9d\x8f\x06\xb4\x0b=\x8e\xe4\t\xb1'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    str_0 = 'H\x1a\x07\xbf\x1c\xa7\x18\xdf\x9d\x8e\xa1j\xbd\xbe\x17\x1e6U'

# Generated at 2022-06-24 23:02:21.581408
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:33.258952
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    pass

    # Test variables
    words = ['igb1', 'flags', '=', '842<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'mtu', '1500']
    current_if = {'device': 'igb0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-24 23:02:34.696146
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # test if constructor returns its object
    assert sun_o_s_network_collector_0 == SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:40.926027
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    str_0 = 'C'
    str_1 = 'h'
    bytes_0 = b"\xdb'\xf8\xabk\x83\x15\xa7\x8a\xcff"
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0 + str_1)


# Generated at 2022-06-24 23:02:43.865723
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)


# Generated at 2022-06-24 23:02:51.169553
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '1'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x12\x05f\x03\xc8'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    if __name__ == '__main__':
        test_SunOSNetwork_get_interfaces_info()
        test_case_0()

# Generated at 2022-06-24 23:02:55.846410
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert(sun_o_s_network_collector._platform == 'SunOS')
    assert(sun_o_s_network_collector._fact_class == SunOSNetwork)


# Generated at 2022-06-24 23:03:12.947934
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '7V.I'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, None)
    str_1 = 'RMrR'
    str_2 = 'iI'
    str_3 = 'FOi'

# Generated at 2022-06-24 23:03:17.401535
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Test case for method get_interfaces_info of class SunOSNetwork."""
    # TODO: Add tests for this method.
    pass


# Generated at 2022-06-24 23:03:26.084327
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x03\xcf\xa5O\x92\xfc\xe2\xce\xd8:'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    str_0 = 'IuF9'
    var_0 = sun_o_s_network_0.get_options(str_0)


# Generated at 2022-06-24 23:03:29.117392
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = '\x86\x9d\x86\x8b\xc4\x07\x02'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)



# Generated at 2022-06-24 23:03:39.149866
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    print('Testing get_interfaces_info of class SunOSNetwork')
    str_0 = '\x0c\x16\x1a\x1e\x18\x19\x0a\x15\x14'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x0f\x14\xdc4\x04\x1f\xa6\x92\xf8\xdf'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    assert var_0 == (None, None)


# Generated at 2022-06-24 23:03:42.118545
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:03:52.569606
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Initialization
    ##################################################################
    # SunOSNetworkCollector object creation
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # static SunOSNetwork object creation
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, b'')
    ##################################################################

    # Testing
    ##################################################################
    # Testing get_interfaces_info method for string input
    # Expected result: None
    sun_o_s_network_0.get_interfaces_info("0")
    ##################################################################


if __name__ == '__main__':
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:04:01.491603
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'J\xd6\x07\xa5\xdd\xc6\x07'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'/\x06\x94\x14\\\xfa\xbc\xd2\xce\xd8:'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:04:09.283635
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'IuF9'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x03\xcf\xa5O\x92\xfc\xe2\xce\xd8:'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    words_0 = ['N\x9e\x05\xb4[\x07/']
    current_if_0 = {'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces_0 = {}
    current_if_1 = sun_o_s_network_0.parse_interface_line(words_0, current_if_0, interfaces_0)


# Generated at 2022-06-24 23:04:20.295035
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_3 = 'y7\x0b'
    sun_o_s_network_collector_3 = SunOSNetworkCollector()
    sun_o_s_network_1 = SunOSNetwork(sun_o_s_network_collector_3, str_3)
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['flags'] = 'flags'
    dict_2['mtu'] = 'mtu'
    dict_1['ipv4'] = dict_2
    dict_1['device'] = 'device'
    dict_0['dict_1 device'] = dict_1
    dict_3 = dict()
    dict_4 = dict()
    dict_4['flags'] = 'flags'

# Generated at 2022-06-24 23:04:40.605030
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'q3\xd6\x95\xf9\xab\xb4\xdf\x0f\xdf\xc1'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:04:50.013727
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'U6@&'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'z\x93\xe7\xd0\x86\xde\xa8\x1a&'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    list_0 = ['F*h', 'N', 'G', '!7']
    dict_0 = {}
    dict_1 = {}
    dict_1['mtu'] = '!7'
    dict_1['flags'] = 'N'
    dict_2 = {}
    dict_2['ipv4'] = [dict_1]
    dict_2['device'] = 'F*h'
    dict

# Generated at 2022-06-24 23:04:52.316219
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)



# Generated at 2022-06-24 23:04:55.925033
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'n_y7'
    sun_o_s_network_0 = SunOSNetwork(SunOSNetworkCollector(), '\x00\x0f\xf4\x9f\x9c\x8e\xc7\x19;')
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    assert var_0



# Generated at 2022-06-24 23:04:59.179821
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Unit tests for class SunOSNetwork

# Generated at 2022-06-24 23:05:06.831084
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'IuF9'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x03\xcf\xa5O\x92\xfc\xe2\xce\xd8:'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    current_if = {}
    interfaces = {}

# Generated at 2022-06-24 23:05:11.578048
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:21.626451
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xad\x0e\xaf\xde\xe0\x97\xb8\xebtr\x92\x96\x12'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    str_0 = 'aPA'
    str_1 = '8Kw'
    list_0 = ['E=', str_1, str_0]
    dict_0 = {'device': 'device', 'ipv6': [], 'ipv4': [], 'type': 'unknown'}
    list_1 = [str_0, str_1]

# Generated at 2022-06-24 23:05:30.777969
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test function arguments
    # This test function was created using the following function definition:
    # def parse_interface_line(self, words, current_if, interfaces):
    str_0 = 'IuF9'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x03\xcf\xa5O\x92\xfc\xe2\xce\xd8:'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    # The following lines were extracted from a test function, test_case_0
    sun_o_s_network_0.get_interfaces_info(str_0)
    # End of extraction
    sun_o_s_network_0.parse

# Generated at 2022-06-24 23:05:42.804187
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '\x98\xed\x82'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'"\x89\x12\xc6\xef\xf1\x1e\xfd\x90\x8d\x04\x94\x1d\xf3\xcd\x0f'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
#    sun_o_s_network_0.get_interfaces_info(str_0)
#    sun_o_s_network_0.get_interfaces_info(

# Generated at 2022-06-24 23:06:21.040914
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:06:21.884671
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    pass


# Generated at 2022-06-24 23:06:29.932521
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x03\xcf\xa5O\x92\xfc\xe2\xce\xd8:'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    ifconfig_path_0 = 'IuF9'

    # Invocation
    result = sun_o_s_network_0.get_interfaces_info(ifconfig_path_0)

    # Verification
    assert result is not None


# Generated at 2022-06-24 23:06:30.654508
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    assert True == True

# Generated at 2022-06-24 23:06:38.988190
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '*T'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x03\xcf\xa5O\x92\xfc\xe2\xce\xd8:'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)

    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:06:48.968351
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '\x0e\x9f\xd5\x9e\x1d\x8e\xad\xba\x13\xf5\xa8\x02\xdc\xda\xaf\xfb\x08'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x0e\x9f\xd5\x9e\x1d\x8e\xad\xba\x13\xf5\xa8\x02\xdc\xda\xaf\xfb\x08'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    var_0 = sun_o_s_network_0.get

# Generated at 2022-06-24 23:06:54.560272
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 23:06:59.491664
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x03\xcf\xa5O\x92\xfc\xe2\xce\xd8:'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info('yY')

# Generated at 2022-06-24 23:07:09.315631
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'IuF9'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\x03\xcf\xa5O\x92\xfc\xe2\xce\xd8:'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    sun_o_s_network_0.platform


# Generated at 2022-06-24 23:07:17.051089
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    current_if = {}
    interfaces = {}
    assert sun_o_s_network_0.parse_interface_line(['qfe0', 'flags=0x1000849<UP,BROADCAST,RUNNING,MULTICAST,IPv6>', 'mtu', '4096'], current_if, interfaces) != {}


# Generated at 2022-06-24 23:08:17.300134
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # No test case available
    assert True



# Generated at 2022-06-24 23:08:20.967536
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:08:29.691451
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = '?\x1dA*h\n'
    list_0 = [str_0, str_0, str_0]
    str_1 = '5\x137\x7fL\x16t\x0c'
    list_1 = [str_1, str_1, str_1, str_1, str_1]
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.parse_interface_line(str_1, list_0, list_1)

# Generated at 2022-06-24 23:08:36.903750
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test for constructor of class SunOSNetworkCollector
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    str_0 = '`t;$nh:?PXd-L(!@\x0b'
    list_0 = [str_0, str_0, str_0, str_0]
    sun_o_s_network_collector_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:08:46.107621
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'P,#xS=\x1dZ\x0b7Plo:AFz{hUVS>'
    list_0 = [str_0, str_0]
    sun_o_s_network_0 = SunOSNetwork(list_0)
    list_1 = [str_0, str_0]
    sun_o_s_network_0.parse_interface_line(str_0, list_1, list_1)
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:08:52.623555
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert (sun_o_s_network_collector is not None), "Invalid object when creating SunOSNetworkCollector"
    assert (sun_o_s_network_collector._fact_class is not None), "Invalid attribute value of _fact_class when creating SunOSNetworkCollector"
    assert (sun_o_s_network_collector._platform is not None), "Invalid attribute value of _platform when creating SunOSNetworkCollector"

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:08:55.464047
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector.platform == 'SunOS'


# Generated at 2022-06-24 23:08:58.890688
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector(list_0)
    list_1 = sun_o_s_network_collector.collect()


# Generated at 2022-06-24 23:09:05.948678
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0.fact_class._platform, str)
    assert sun_o_s_network_collector_0.fact_class._platform == 'SunOS'
    assert sun_o_s_network_collector_0.fact_class is sun_o_s_network_collector_0._fact_class


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:09:09.082473
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = './ifconfig_path'
    interfaces_info = [ifconfig_path]
    sun_o_s_network_0 = SunOSNetwork(interfaces_info)
    var_0 = sun_o_s_network_0.get_interfaces_info(ifconfig_path)
    print(var_0)
