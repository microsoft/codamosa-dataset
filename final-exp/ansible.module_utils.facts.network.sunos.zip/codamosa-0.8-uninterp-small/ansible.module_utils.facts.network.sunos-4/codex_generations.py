

# Generated at 2022-06-24 23:00:58.874902
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    int_0 = 833
    sun_o_s_network_collector_1 = SunOSNetworkCollector(set_0, int_0)


# POC to enable testing.
#
# Run with:
#
# ansible localhost -m test_sunos_network -a '{}'
#

# Generated at 2022-06-24 23:01:03.625487
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces = {}
    set_0 = set()
    int_0 = 833
    sun_o_s_network_collector_0 = SunOSNetworkCollector(set_0, int_0)
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0, set_0, int_0)
    sun_o_s_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:01:05.986824
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    int_0 = 595
    sun_o_s_network_collector_0 = SunOSNetworkCollector(set_0, int_0)


# Generated at 2022-06-24 23:01:10.092882
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    int_0 = 246
    sun_o_s_network_collector_0 = SunOSNetworkCollector(set_0, int_0)



# Generated at 2022-06-24 23:01:20.986209
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    set_0 = set()
    int_0 = 833
    sun_o_s_network_collector_0 = SunOSNetworkCollector(set_0, int_0)
    words_0 = ['en2', 'UP', 'LOOPBACK,RUNNING,MULTICAST', 'mtu', '1500']
    current_if_0 = {'device': 'en2', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces_0 = {'en2': {'device': 'en2', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    current_if_1 = sun_o_s_network_collector_0.find_class_0.find_class_1.find_class_2.find_class_3

# Generated at 2022-06-24 23:01:27.631284
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    set_0 = set()
    int_0 = 833
    sun_o_s_network_collector_0 = SunOSNetworkCollector(set_0, int_0)
    sun_o_s_network_0.module = sun_o_s_network_collector_0
    path_0 = "/sbin/ifconfig"
    sun_o_s_network_0.get_interfaces_info(path_0)


# Generated at 2022-06-24 23:01:38.446075
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:01:45.450975
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-24 23:01:51.706330
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    int_0 = 833
    sun_o_s_network_collector_0 = SunOSNetworkCollector(set_0, int_0)
    assert sun_o_s_network_collector_0._fact_class is SunOSNetwork
    assert sun_o_s_network_collector_0._platform is 'SunOS'


# Generated at 2022-06-24 23:01:55.238706
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    int_0 = 833
    sun_o_s_network_collector_0 = SunOSNetworkCollector(set_0, int_0)


# Generated at 2022-06-24 23:02:09.261596
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    my_test_class = SunOSNetwork('test_str')

# Generated at 2022-06-24 23:02:20.478674
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:02:31.741042
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    iface = 'en0'
    name = 'en0'
    ipv4 = '10.0.0.1'
    ipv6 = '1fff:0:a88:85a3::ac1f:8001'
    nd6 = ['fe80::2ef2:6aff:fe3f:c6cb', '1fff:0:a88:85a3::ac1f:8001']
    macaddress = '00:0e:f2:3f:c6:cb'
    netmask = 'ffff:ffff:ffff:ffff::/64'
    mac_int = '0x00e'
    itype = 'ether'
    flags = 'UP,BROADCAST,RUNNING,MULTICAST'
    mtu = '1500'

# Generated at 2022-06-24 23:02:35.225800
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ''
    sun_o_s_network_0 = SunOSNetwork(str_0)
    ifconfig_path_0 = str()
    assert isinstance(sun_o_s_network_0.get_interfaces_info(ifconfig_path_0), tuple)


# Generated at 2022-06-24 23:02:42.509283
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = ''
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    str_1 = ''
    sun_o_s_network_collector_0.get_device_to_ip_map(str_1)
    str_2 = ''
    sun_o_s_network_collector_0.get_interfaces_info(str_2)
    str_3 = ''
    sun_o_s_network_collector_0.get_default_gateway(str_3)
    str_4 = ''
    sun_o_s_network_collector_0.get_default_interface(str_4)
    str_5 = ''
    sun_o_s_network_collector_0.get_gateways(str_5)

# Generated at 2022-06-24 23:02:50.170665
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str = '''
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
    '''
    sun_o_s_network_0 = SunOSNetwork(str)
    words = sun_o_s_network_0.get_interfaces_info(str)
    result = sun_o_s_network_0.parse_interface_line(words, {}, {})
    assert result['type'] == 'loopback'


# Generated at 2022-06-24 23:02:55.791574
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = ''
    sun_o_s_network_0 = SunOSNetwork(str_0)
    line = sun_o_s_network_0.get_interfaces_info_from_file('sunos_interface_line.txt')


test_SunOSNetwork_parse_interface_line()

# Generated at 2022-06-24 23:03:05.553537
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = '/usr/sbin/ifconfig'
    str_1 = '/usr/sbin/arp'
    str_2 = '/usr/sbin/route'
    str_3 = 'eth0'
    str_4 = 'default'
    str_5 = 'enp0s8'
    str_6 = '1.2.3.4'
    str_7 = '255.255.255.0'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0, str_1, str_2, str_3, str_4)
    sun_o_s_network_collector_0.add_ip_mapping(str_5, str_6, str_7)
    sun_o_s_network_collector_0.add_default_ip

# Generated at 2022-06-24 23:03:12.422930
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Given
    str_0 = ''

    sun_o_s_network_0 = SunOSNetwork(str_0)

    ifconfig_path = '\'/usr/bin/ifconfig\''

    # When
    result = sun_o_s_network_0.get_interfaces_info(ifconfig_path)

    # Then

# Generated at 2022-06-24 23:03:18.212734
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    string_0 = 'SunOSNetworkCollector'
    string_1 = 'SunOS'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(string_0, string_1)
    ansible_facts = dict(ansible_net_all_ipv4_addresses=[])

# Generated at 2022-06-24 23:03:26.597515
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork('/sbin/ifconfig')
    str_0 = '/sbin/ifconfig'
    result = sun_o_s_network_0.get_interfaces_info(str_0)
    assert isinstance(result, tuple)


# Generated at 2022-06-24 23:03:31.486234
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    mod = network_units.MockModule()
    sun_o_s_network_collector_0 = SunOSNetworkCollector(mod)


if __name__ == "__main__":
    import network_units
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:03:41.371315
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:03:50.490735
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {'device': 1, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'device': {'device': 1, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    words = ['device', 'flags', 'hoplimit', 'mtu', 'metric', 'ip', 'groups', 'flags', 'ref', 'cnt']
    sun_o_s_network_0 = SunOSNetwork('str_0')
    result = sun_o_s_network_0.parse_interface_line(words, current_if, interfaces)



# Generated at 2022-06-24 23:03:57.691170
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    command = ['ifconfig', '-a']

# Generated at 2022-06-24 23:04:06.193691
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = ''
    sun_o_s_network_0 = SunOSNetwork(str_0)

    # Test python version used to create this template
    # assert(sys.version_info >= (3,5))

    words_0 = ['lo0:']
    current_if_0 = {'device': 'lo0:', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces_0 = {'lo0:': current_if_0}
    sun_o_s_network_0.parse_interface_line(words_0, current_if_0, interfaces_0)


# Generated at 2022-06-24 23:04:07.463947
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert not hasattr(sun_o_s_network_collector_0, 'facts')


# Generated at 2022-06-24 23:04:13.943302
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork('/sbin/ifconfig')

    # solaris_0 doesn't really exist.  See "parse_interface_line()"

# Generated at 2022-06-24 23:04:17.812002
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = ''
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)


# Generated at 2022-06-24 23:04:20.393657
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ' '
    sun_o_s_network_0 = SunOSNetwork(str_0)

    sun_o_s_network_0.get_interfaces_info()

# Generated at 2022-06-24 23:04:27.759549
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector._fact_class == SunOSNetwork
    assert sun_o_s_network_collector._platform == 'SunOS'




# Generated at 2022-06-24 23:04:29.323476
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    return sun_o_s_network_collector_0


# Generated at 2022-06-24 23:04:33.754940
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:04:35.011810
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    SunOSNetwork().get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-24 23:04:37.167519
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:04:43.939156
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert callable(sun_o_s_network_collector._fact_class)
    assert sun_o_s_network_collector._fact_class().platform == 'SunOS'
    assert sun_o_s_network_collector._platform == 'SunOS'


# Generated at 2022-06-24 23:04:51.569356
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.module = FakeAnsibleModule()
    sun_o_s_network_0.module.get_bin_path = fake_get_bin_path
    sun_o_s_network_0.warnings = []
    sun_o_s_network_0.warnings.append('SunOSNetwork.get_interfaces_info is untested')
    sun_o_s_network_0.get_interfaces_info('/fake/bin/path')
    assert sun_o_s_network_0.warnings == ['SunOSNetwork.get_interfaces_info is untested']


# Generated at 2022-06-24 23:04:55.011250
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork
    assert sun_o_s_network_collector_0._platform == 'SunOS'


# Generated at 2022-06-24 23:05:03.697453
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = '/sbin/ifconfig'

    interfaces_dict = sun_o_s_network_0.get_interfaces_info(ifconfig_path)[0]
    assert(interfaces_dict['en0']['ipv4'][0]['addresses'][0]['address'] == '192.168.0.4')
    assert(interfaces_dict['en0']['ipv6'][0]['scope6'] == 'global')


# Generated at 2022-06-24 23:05:05.699371
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    result = sun_o_s_network_0.get_interfaces_info()

# Generated at 2022-06-24 23:05:14.028188
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert (sun_o_s_network_collector_0.platform == 'SunOS')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:05:20.203602
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_1 = SunOSNetworkCollector(
        module_name='ansible.builtin.ping',
        facts_module='ansible.module_utils.facts.network.bsd.sun_o_s'
    )

    # Check the type of 'sun_o_s_network_collector_1'
    assert isinstance(sun_o_s_network_collector_1, SunOSNetworkCollector)


# Generated at 2022-06-24 23:05:26.194597
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    a_SunOSNetwork = SunOSNetwork()
    interfaces, ips = a_SunOSNetwork.get_interfaces_info()
    for i in interfaces:
        for p in interfaces[i]:
            print (i, p, interfaces[i][p])


# Generated at 2022-06-24 23:05:28.199661
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:36.261630
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    os_platform = sys.platform
    sys.platform = 'SunOS'
    this_module = sys.modules[__name__]
    sunosnetworkcollector = SunOSNetworkCollector()
    sunosnetworkcollector.__thisclass__ = this_module.SunOSNetworkCollector
    fact_class = sunosnetworkcollector._fact_class
    platform = sunosnetworkcollector._platform

    assert fact_class == SunOSNetwork
    assert platform == 'SunOS'
    sys.platform = os_platform

# Generated at 2022-06-24 23:05:38.142881
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:43.689770
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        sun_o_s_network_collector_0 = SunOSNetworkCollector()
    except NameError as err:
        assert False, "Failed to instantiate SunOSNetworkCollector"


# Generated at 2022-06-24 23:05:46.558573
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()



# Generated at 2022-06-24 23:05:49.758951
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()



# Generated at 2022-06-24 23:05:56.970075
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:06:07.788913
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector

if __name__ == '__main__':
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:06:11.347515
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    fc = SunOSNetwork()
    fc.module.run_command = run_command_mock
    interfaces_info = fc.get_interfaces_info('/usr/sbin/ifconfig')


# Generated at 2022-06-24 23:06:13.138513
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Constructor test
    assert len(SunOSNetworkCollector()._platform) > 0


# Generated at 2022-06-24 23:06:15.612762
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector, SunOSNetworkCollector)

# Generated at 2022-06-24 23:06:17.738132
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    s = SunOSNetwork()
    result = s.get_interfaces_info('/usr/sbin/ifconfig')
    print(result)


# Generated at 2022-06-24 23:06:19.909941
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('ifconfig')


# Generated at 2022-06-24 23:06:21.317842
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:06:31.380664
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''The method get_interfaces_info returns a tuple of (interfaces, ips)'''
    # Create an instance of SunOSNetwork by passing dummy arguments
    sun_o_s_network_0 = SunOSNetwork(['ifconfig', '/sbin/ifconfig'])
    # Get the interfaces_info: The method get_interfaces_info returns a tuple of (interfaces, ips) so provide list arguments
    interfaces_info = sun_o_s_network_0.get_interfaces_info('ifconfig')
    assert(isinstance(interfaces_info, tuple))
    # interfaces_info is a tuple of (interfaces, ips)
    # Check interfaces_info[0] is a list of interfaces
    assert(isinstance(interfaces_info[0], dict))
    # Check interfaces_info[1] is a list

# Generated at 2022-06-24 23:06:43.355973
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # Check of type of argument '_fact_class'
    assert isinstance(sun_o_s_network_collector_0._fact_class, SunOSNetwork)
    # Check of type of class variable '_fact_class'
    assert isinstance(SunOSNetworkCollector._fact_class, property)
    # Check of type of class variable '_platform'
    assert isinstance(SunOSNetworkCollector._platform, property)
    # Check of value of class variable '_fact_class'
    assert SunOSNetworkCollector._fact_class.fget(SunOSNetworkCollector) == SunOSNetwork
    # Check of value of class variable '_platform'

# Generated at 2022-06-24 23:06:53.345467
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:07:12.545166
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    str_1 = 'lo0'
    str_2 = 'ether'
    str_3 = 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
    str_4 = 'mtu'
    str_5 = '8232'
    str_6 = 'index'
    str_7 = '1'
    str_8 = 'inet'
    str_9 = '127.0.0.1'
    str_10 = 'netmask'
    str_11 = 'ff000000'
    str_12 = 'options'
    str_13 = '3'
    str_14 = 'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'
    str_

# Generated at 2022-06-24 23:07:16.136609
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    str_0 = '--no-site-packages'
    sun_o_s_network_0 = SunOSNetwork(str_0, bool_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:07:22.525684
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ifconfig_path = '/sbin/ifconfig'
    gather_subset = None
    gather_network_resources = True
    test_SunOSNetworkCollector = SunOSNetworkCollector(ifconfig_path, gather_subset, gather_network_resources)


# Generated at 2022-06-24 23:07:28.822667
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector._fact_class == SunOSNetwork
    assert sun_o_s_network_collector._platform == 'SunOS'


# Generated at 2022-06-24 23:07:36.221857
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    str_0 = '--no-site-packages'
    sun_o_s_network_0 = SunOSNetwork(str_0, bool_0)
    str_1 = '/sbin/ifconfig'
    sun_o_s_network_0.get_interfaces_info(str_1)


# Generated at 2022-06-24 23:07:41.355243
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    a = SunOSNetworkCollector()
    check_class = a._fact_class
    assert(check_class == SunOSNetwork)



# Generated at 2022-06-24 23:07:47.106236
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'xnF8FH'
    bool_0 = False
    set_0 = {bool_0, bool_0}
    str_1 = 'RJ'
    sun_o_s_network_0 = SunOSNetwork(str_0, bool_0)
    sun_o_s_network_0.parse_interface_line(str_0, str_1, set_0)
    assert sun_o_s_network_0._get_interfaces_info(str_0, str_1) == set_0


# Generated at 2022-06-24 23:07:54.842939
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = '--no-site-packages'
    bool_0 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    #assert sun_o_s_network_collector_0._fact_class == bool_0
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork

# Generated at 2022-06-24 23:07:57.505279
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    str_0 = '--no-site-packages'
    sun_o_s_network_0 = SunOSNetwork(str_0, bool_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:07:59.477800
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-24 23:08:22.220162
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    return sun_o_s_network_collector_0

# Generated at 2022-06-24 23:08:25.304777
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector('constructed.')
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector), 'Should be of type SunOSNetworkCollector'

# Generated at 2022-06-24 23:08:29.400981
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    str_0 = '--no-site-packages'
    sun_o_s_network_0 = SunOSNetwork(str_0, bool_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:08:31.907444
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork
    str_0 = '--no-site-packages'
    bool_0 = True
    assert sun_o_s_network_0(str_0, bool_0).get_interfaces_info(str_0)

# Generated at 2022-06-24 23:08:35.161429
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:08:38.958723
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module_path = 'ansible.module_utils.facts.network.sunos.SunOSNetworkCollector'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(module_path)


# Generated at 2022-06-24 23:08:44.534667
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    str_0 = '--no-site-packages'
    sun_o_s_network_0 = SunOSNetwork(str_0, bool_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:08:48.794409
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    dict_0 = dict()
    dict_0['platform'] = 'SunOS'
    dict_0['fact_class'] = SunOSNetwork
    assert sun_o_s_network_collector_0.__dict__ == dict_0


# Generated at 2022-06-24 23:08:55.177779
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork('no-user-site', True)
    var_1 = sun_o_s_network_0.get_interfaces_info('ifconfig')
    print(var_1)
    print(var_1[0])
    print(var_1[1])


# Generated at 2022-06-24 23:09:00.294896
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0, bool_0)
    bool_1 = sun_o_s_network_collector_0.want_default_collector
    assert bool_1 == bool_0, "Failed to get attribute 'want_default_collector'"
    print('Wanted collector: ' + str(bool_1))


# Generated at 2022-06-24 23:09:53.957031
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

if __name__ == '__main__':
    # unit tests for this file
    test_SunOSNetworkCollector()
    test_case_0()

# Generated at 2022-06-24 23:10:02.199550
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # (unit test for method parse_interface_line()):
    test_case_0()
    # (unit test for method get_interfaces_info()):
    sun_o_s_network_collector_0 = SunOSNetworkCollector('/usr/local/bin/python2.7')
    sun_o_s_network_collector_0.get_interfaces_info()


if __name__ == "__main__":
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:10:02.948915
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_SunOSNetworkCollector_0()



# Generated at 2022-06-24 23:10:07.487592
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '--no-site-packages'
    bool_0 = True
    set_0 = {bool_0, bool_0}
    sun_o_s_network_0 = SunOSNetwork(str_0, bool_0)
    assert sun_o_s_network_0.get_interfaces_info(str_0) == (set_0, set_0)


# Generated at 2022-06-24 23:10:15.844949
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '--no-site-packages'
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(str_0, bool_0)
    dict_0 = {}
    dict_1 = {}
    dict_0['type'] = 'unknown'
    dict_1['ipv4'] = []
    dict_1['ipv6'] = []
    dict_1['device'] = 'lo0'
    dict_1['ipv4'].append(dict_0)
    dict_1['ipv6'].append(dict_0)
    dict_1['type'] = 'loopback'
    dict_0['device'] = 'lo0'
    dict_0['ipv6'] = []
    dict_0['ipv4'] = []

# Generated at 2022-06-24 23:10:20.140261
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_0 = None
    # sun_o_s_network_0 = SunOSNetworkCollector(var_0)


# Generated at 2022-06-24 23:10:30.282311
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interface0_0 = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    sun_o_s_network0_0 = SunOSNetwork('--solo', True)
    var0_0 = sun_o_s_network0_0.parse_interface_line('en1,', 'en0,', interface0_0)
    interfaces0_0 = {}
    ips0_0 = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    var0_1 = sun_o_s_network0_0.get_interfaces_info(var0_0, interfaces0_0, ips0_0)


# Generated at 2022-06-24 23:10:37.155023
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    str_0 = '--no-site-packages'
    sun_o_s_network_0 = SunOSNetwork(str_0, bool_0)
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, str_0, set_0)
    assert var_0 == None


# Generated at 2022-06-24 23:10:42.004776
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector.platform == 'SunOS'
    assert sun_o_s_network_collector.defaul_interface_facts == {
        'netmask': '255.255.255.255',
        'network': '0.0.0.0',
        'address': '0.0.0.0',
        'broadcast': '0.0.0.0',
        'macaddress': 'unknown',
        'type': 'unknown',
    }
    assert sun_o_s_network_collector.defaul_ipv6_interface_facts == {
        'address': '::',
        'cidr': '::/0',
        'scope': 'unknown',
    }
    assert sun