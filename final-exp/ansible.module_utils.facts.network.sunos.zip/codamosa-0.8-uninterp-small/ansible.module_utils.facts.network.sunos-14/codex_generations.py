

# Generated at 2022-06-24 23:01:05.338903
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Case 0

    test_success = False
    sun_o_s_network_0 = SunOSNetwork()

# Generated at 2022-06-24 23:01:10.727290
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert type(sun_o_s_network_collector._fact_class) == SunOSNetwork, 'Failed to create SunOSNetworkCollector'

# Generated at 2022-06-24 23:01:21.628917
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = './utils/ifconfig_SunOS'
    sun_o_s_network_0 = SunOSNetwork()
    interfaces, ips = sun_o_s_network_0.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 23:01:32.420581
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    sample_line = 'lo0:1 flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = sample_line.split()
    sun_o_s_network_0 = SunOSNetwork()
    result_0 = sun_o_s_network_0.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-24 23:01:39.118619
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-24 23:01:43.139274
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(module='AnsibleModuleMock')  # Instantiate SunOSNetwork object
    sun_o_s_network_0.interfaces
    sun_o_s_network_0.ips


# Generated at 2022-06-24 23:01:48.742240
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.module = MockModule()
    sun_o_s_network_0.module.run_command = Mock(return_value=(0, 'fake_out', 'fake_err'))
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-24 23:01:57.912375
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()

    # AssertionError: Expected (['lo0', 'UP', 'LOOPBACK', 'RUNNING', 'MTU:', '8232', 'Index:', '1', 'Zone:', 'global'], {'current_if': {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}], 'ipv6': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}], 'type': 'unknown'}, 'interfaces': {'lo0': {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mt

# Generated at 2022-06-24 23:02:07.136538
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    assert sun_o_s_network_0.parse_interface_line(words = ['bge0:'],current_if = {'device': 'unknown', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},interfaces = {}) == {'device': 'bge0', 'ipv4': [{'flags': ['BROADCAST', 'MULTICAST', 'IPv4'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}


# Generated at 2022-06-24 23:02:08.765797
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:17.557576
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork()
    interfaces_info_0 = sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')



# Generated at 2022-06-24 23:02:27.382225
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Path of the file containing the expected result
    expected_result_path = 'utils/ansible_facts/facts_dumps/SunOS_ifconfig_expected_result.txt'
    # Parse the expected result file
    with open(expected_result_path) as expected_result_file:
        expected_result_file_content = expected_result_file.read()

    assert sun_o_s_network_collector_0._platform == 'SunOS'
    # Collect actual result
    actual_result = sun_o_s_network_collector_0.collect()
    # No test for actual_result == None, because it would mean that the ifconfig command failed
    # Parse actual result
    actual_result_str = str(actual_result)

    assert actual_result_str == expected_result_file_content

# Generated at 2022-06-24 23:02:37.185325
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()

# Generated at 2022-06-24 23:02:41.599321
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    fact_path = 'ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.sunos.ifconfig_path'
    sun_o_s_network_0.set_options({fact_path: '/sbin/ifconfig'})
    ifconfig_path = '/sbin/ifconfig'
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-24 23:02:45.945055
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork(dict(module=dict()))
    assert sun_o_s_network.get_interfaces_info('/sbin/ifconfig')[0] == {}


# Generated at 2022-06-24 23:02:48.366761
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info(ifconfig_path="/usr/sbin/ifconfig")


# Generated at 2022-06-24 23:02:58.320903
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = "/bin/ifconfig"
    result = sun_o_s_network_0.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 23:03:00.592305
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


if __name__ == "__main__":
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:03:08.640452
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_os_network_0 = SunOSNetwork()
    res = sun_os_network_0.get_interfaces_info('/sbin/ifconfig')
    assert res[0]['bge0']['type'] == 'ethernet'
    assert res[0]['lo0']['type'] == 'loopback'
    assert res[0]['bge0']['ipv4'][0]['address'] == '10.10.10.10'



# Generated at 2022-06-24 23:03:20.581892
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:03:35.525113
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    sun_o_s_network_0 = SunOSNetwork({}, {})
    sun_o_s_network_0._module.run_command = mock_run_command
    sun_o_s_network_0.module.run_command = mock_run_command
    sun_o_s_network_0.module.params = {'config': 'SunOS'}

# Generated at 2022-06-24 23:03:43.442083
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector = SunOSNetworkCollector()
    sun_o_s_network = SunOSNetwork()
    sun_o_s_network.module = MagicMock()
    sun_o_s_network.module.run_command = MagicMock(return_value=(0, 'lo0:6: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1', ''))
    sun_o_s_network.get_interfaces_info('ifconfig')

# Generated at 2022-06-24 23:03:53.968643
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()

# Generated at 2022-06-24 23:04:02.705092
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    current_if = {}
    interfaces = {}
    ifconfig_path = 'ifconfig_path'
    rc, out, err = sun_o_s_network_0.module.run_command([ifconfig_path, '-a'])
    lines = out.splitlines()
    for line in lines:
        words = line.split()
        if re.match(r'^\S', line) and len(words) > 3:
            current_if = sun_o_s_network_0.parse_interface_line(words, current_if, interfaces)
            interfaces[current_if['device']] = current_if
        else:
            sun_o_s_network_0.parse_options_line(words, current_if, interfaces)
    sun

# Generated at 2022-06-24 23:04:07.417011
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:04:13.895967
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork(dict())

    words_0 = ['e1000g0:', 'flags=20100843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS,EXT>', 'mtu', '1500']
    current_if_0 = dict()
    interfaces_0 = dict()

    expected_0 = {'device': 'e1000g0', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4', 'CoS', 'EXT'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-24 23:04:17.427716
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        test_case_0()
    except:
        raise Exception("Failed Test at test_case_0")

# Generated at 2022-06-24 23:04:25.790226
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network = SunOSNetwork()
    words = ['lo0', ':', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1', 'inet', '127.0.0.1', 'netmask', 'ff000000']
    current_if = {}
    interfaces = {}
    expected = {'mtu': '8232', 'device': 'lo0', 'ipv4': [{'mtu': '8232', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']}], 'ipv6': [], 'type': 'unknown'}
    sun_o_s_network.parse_interface_line

# Generated at 2022-06-24 23:04:27.875402
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    result = sun_o_s_network_0.get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    assert result is not None


# Generated at 2022-06-24 23:04:38.931190
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = '/usr/bin/ifconfig'
    result = sun_o_s_network_0.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 23:04:51.597574
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:04:53.480358
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:04:59.639583
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector, SunOSNetworkCollector) == True


# Generated at 2022-06-24 23:05:04.136485
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path_0 = '/usr/sbin/ifconfig'
    rc, out, err = sun_o_s_network_0.module.run_command([ifconfig_path_0, '-a'])
    interfaces, ips = sun_o_s_network_0.get_interfaces_info(ifconfig_path_0)

    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-24 23:05:09.036890
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('/usr/sbin/ifconfig')

if __name__ == '__main__':
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:05:12.884920
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


if __name__ == '__main__':
    print(repr(test_case_0()))
    print(repr(test_SunOSNetworkCollector()))

# Generated at 2022-06-24 23:05:18.531689
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0 is not None


# Generated at 2022-06-24 23:05:20.814529
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('ifconfig')


# Generated at 2022-06-24 23:05:22.217238
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('/usr/sbin/ifconfig')


# Generated at 2022-06-24 23:05:28.839211
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    # test instance attributes
    assert hasattr(sun_o_s_network_collector, '_fact_class')
    assert hasattr(sun_o_s_network_collector, '_platform')
    assert sun_o_s_network_collector._fact_class == SunOSNetwork
    assert sun_o_s_network_collector._platform == 'SunOS'


# Generated at 2022-06-24 23:05:50.207575
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    assert sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig') is not None



# Generated at 2022-06-24 23:05:59.614448
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    words_0 = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '8']
    current_if_0 = {}
    interfaces_0 = {}
    sun_o_s_network_0.parse_interface_line(words_0, current_if_0, interfaces_0)
    assert current_if_0['device'] == 'lo0'
    assert current_if_0['type'] == 'loopback'
    assert current_if_0['ipv4'] == [{'flags': 'UP,LOOPBACK,RUNNING,MULTICAST,IPv4', 'mtu': '8232'}]


# Generated at 2022-06-24 23:06:12.140255
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()

    words_0 = ['e1000g0:', 'flags=2001000843', 'mtu', '1500']
    current_if_0 = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces_0 = {'e1000g0': {'device': 'e1000g0', 'ipv4': [{'flags': ['BROADCAST', 'MULTICAST', 'RUNNING', 'SIMPLEX', 'MULTI_BCAST'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}}

# Generated at 2022-06-24 23:06:15.012733
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_fixture = SunOSNetwork()
    sun_o_s_network_fixture.get_interfaces_info("/bin/ifconfig")


# Generated at 2022-06-24 23:06:22.820919
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sun_o_s_network_0.module.params['gather_subset'] = ['!all']
    sun_o_s_network_0.module.params['gather_network_resources'] = ['all']
    sun_o_s_network_0.module.params['filter'] = dict()

    # Test with bad filter value
    setattr(sun_o_s_network_0.module.params['filter'], 'device', 'eth0')
    interfaces, ips = sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')

    #

# Generated at 2022-06-24 23:06:26.556956
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    file_path = 'file'
    sun_o_s_network_0 = SunOSNetwork()

    # TODO: improve test coverage by providing a real 'file' argument
    # read file into buffer and pass as 'file' argument

    result = sun_o_s_network_0.get_interfaces_info(file_path)

    assert result is not None

# Unit tests for function test_case_0 of class SunOSNetworkCollector

# Generated at 2022-06-24 23:06:38.297179
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0_out = sun_o_s_network_0.get_interfaces_info("/sbin/ifconfig")
    #assert sun_o_s_network_0_out[0]['en0'] == {'ipv4': [{'netmask': '255.255.255.0', 'broadcast': '10.10.10.255', 'address': '10.10.10.246', 'network': '10.10.10.0'}], 'ipv6': [{'address': 'fe80::a00:27ff:fead:33e0%en0', 'prefix': '64', 'scope': 'link'}], 'device': 'en0', 'mtu': 1500, 'pciid': '

# Generated at 2022-06-24 23:06:45.336383
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.parse_interface_line([u'lo0:', u'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', u'mtu', u'8232'], {}, {})


# Generated at 2022-06-24 23:06:54.610048
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    SunOSNetworkClass = SunOSNetwork()

# Generated at 2022-06-24 23:06:57.702046
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = '/usr/sbin/ifconfig'
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-24 23:07:46.343077
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    # Ensure that interface 'lo1' is defined in the return dictionary
    assert 'lo1' in sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')[0]
    # Check that the first element of 'ipv4' list contains dict with key 'mtu'
    assert 'mtu' in sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')[0]['lo1']['ipv4'][0]
    # Check that the first element of 'ipv4' list contains dict with key 'flags'

# Generated at 2022-06-24 23:07:50.533498
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:07:55.244914
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('ifconfig')


# Generated at 2022-06-24 23:07:58.266281
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_1._platform == 'SunOS'



# Generated at 2022-06-24 23:08:01.531061
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork
    assert sun_o_s_network_collector_0._platform == 'SunOS'


# Generated at 2022-06-24 23:08:05.811947
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    obj = SunOSNetwork()
    rc, out, err = obj.module.run_command(['ifconfig', '-a'])
    if rc != 0:
        obj.module.fail_json(msg='command ifconfig -a failed')
    ifaces, ips = obj.get_interfaces_info('ifconfig')
    assert isinstance(ifaces, dict)

# Generated at 2022-06-24 23:08:16.368402
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_os_network_0 = SunOSNetwork()

    interfaces, ips = sun_os_network_0.get_interfaces_info('/sbin/ifconfig')

    assert len(interfaces) == 2
    assert len(ips) == 2
    assert ips['default_ipv4']['address'] == '192.168.1.10'
    assert ips['default_ipv6']['address'] == 'fe80::219:caff:fe62:e576'
    assert len(interfaces['en2']['ipv6']) == 1
    assert interfaces['en2']['ipv6'][0]['address'] == 'fe80::219:caff:fe62:e576'
    assert len(interfaces['en2']['ipv4']) == 1
    assert interfaces

# Generated at 2022-06-24 23:08:27.560477
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()

    rc, out, err = sun_o_s_network_0.module.run_command([sun_o_s_network_0.module.get_bin_path('ifconfig', True)])
    interfaces, ips = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_0.module.get_bin_path('ifconfig', True))

    assert interfaces['']['ipv4'][0]['broadcast'] == 'ff:ff:ff:ff:ff:ff'
    assert interfaces['']['ipv4'][0]['flags'] == ['BROADCAST', 'MULTICAST', 'UP']

# Generated at 2022-06-24 23:08:29.356856
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)


# Generated at 2022-06-24 23:08:34.347045
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    # 'ifconfig' command output from SunOS

# Generated at 2022-06-24 23:10:14.158980
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_class_0 = sun_o_s_network_collector_0._fact_class
    platform_0 = sun_o_s_network_collector_0._platform

    assert fact_class_0._platform == platform_0


# Generated at 2022-06-24 23:10:18.555790
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0


# Generated at 2022-06-24 23:10:25.097312
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    f0 = SunOSNetwork()
    f1 = f0.get_interfaces_info("ifconfig")
    assert type(f1[0]) is dict, "Interfaces dictionary is not parsed properly"
    assert type(f1[1]) is dict, "IPs dictionary is not parsed properly"
    assert len(f1[0]) == 22, "Interfaces dictionary is not parsed properly"
    assert len(f1[1]) == 2, "IPs dictionary is not parsed properly"

# Generated at 2022-06-24 23:10:28.324306
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0 is not None


# Generated at 2022-06-24 23:10:30.642679
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, object)

# Generated at 2022-06-24 23:10:38.574227
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.module.run_command = lambda *args, **kwargs: (
        0, 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1', '')
    sun_o_s_network_0.module.fail_json = lambda *args, **kwargs: False
    sun_o_s_network_0.module.warn = lambda *args, **kwargs: False
    sun_o_s_network_0.module.exit_json = lambda *args, **kwargs: False


# Generated at 2022-06-24 23:10:40.805055
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)

