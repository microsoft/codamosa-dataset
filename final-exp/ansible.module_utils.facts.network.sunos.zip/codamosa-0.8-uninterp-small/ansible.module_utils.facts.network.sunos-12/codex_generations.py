

# Generated at 2022-06-24 23:01:01.411885
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector._platform == 'SunOS', 'actual: %s' % sun_o_s_network_collector._platform
    assert sun_o_s_network_collector._fact_class == SunOSNetwork, 'actual: %s' % sun_o_s_network_collector._fact_class



# Generated at 2022-06-24 23:01:02.948522
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:05.858959
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0.platform == "SunOS"
    assert sun_o_s_network_collector_0.fact_class == SunOSNetwork


# Generated at 2022-06-24 23:01:18.506150
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_case = SunOSNetwork(dict(module=dict(run_command=lambda *_, **__: (0, SUN_O_S_IFCONFIG_OUTPUT, ''))))
    assert test_case.get_interfaces_info('ifconfig') == (SUN_O_S_INTERFACES_INFO_EXPECTED, SUN_O_S_IPS_INFO_EXPECTED)



# Generated at 2022-06-24 23:01:21.354356
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = 'path'
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 23:01:23.089042
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:25.422348
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print("Testing constructor of SunOSNetworkCollector class")
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)
    print("Constructor of SunOSNetworkCollector class works as expected")


# Generated at 2022-06-24 23:01:29.561300
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:32.551873
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sunos_n_0 = SunOSNetwork()
    assert sunos_n_0.get_interfaces_info(ifconfig_path=None) == '[]'

# Generated at 2022-06-24 23:01:39.378253
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_1 = SunOSNetwork()
    sun_o_s_network_2 = SunOSNetwork()
    sun_o_s_network_3 = SunOSNetwork()
    sun_o_s_network_4 = SunOSNetwork()
    sun_o_s_network_5 = SunOSNetwork()
    sun_o_s_network_6 = SunOSNetwork()
    sun_o_s_network_7 = SunOSNetwork()
    sun_o_s_network_8 = SunOSNetwork()
    sun_o_s_network_9 = SunOSNetwork()
    sun_o_s_network_0.run()
    sun_o_s_network_1.run()

# Generated at 2022-06-24 23:01:52.833629
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetworkCollector()
    interfaces, ips = sun_o_s_network_0.get_interfaces_info()
    print(interfaces)
    print(ips)


# Generated at 2022-06-24 23:02:01.504863
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork()

    # Interfaces should be 'en0', 'en1', 'en2', and 'lo0'

# Generated at 2022-06-24 23:02:04.353605
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert type(sun_o_s_network_collector_0._fact_class) is type

# Generated at 2022-06-24 23:02:09.736721
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sunOSNetwork_0 = SunOSNetwork()
    sunOSNetwork_0._module = get_module_mock()
    sunOSNetwork_0._module.run_command = run_command_mock
    ifconfig_path_0 = 'ifconfig_path'
    rc_0 = 0
    out_0 = """
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1
        inet6 ::1/128
"""
    err_0 = ''
    sunOSNetwork_0.get

# Generated at 2022-06-24 23:02:20.810654
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_1 = SunOSNetworkCollector(
        ansible_module=ansible_module_0)
    assert sun_o_s_network_collector_0.__class__ == SunOSNetworkCollector
    assert sun_o_s_network_collector_0.facts == ['all_ipv4_addresses', 'all_ipv6_addresses', 'default_ipv4_gateway', 'default_ipv6_gateway', 'interfaces', 'ipv4']
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork
    assert sun_o_

# Generated at 2022-06-24 23:02:22.946796
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    print(sun_o_s_network_collector_0)

# Generated at 2022-06-24 23:02:34.779099
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork({})

# Generated at 2022-06-24 23:02:36.338489
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:44.146882
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    words_0 = ['lo0', 'UP,LOOPBACK,RUNNING,MULTICAST', 'mtu', '8232']
    current_if_0 = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces_0 = {}
    sun_o_s_network_0.parse_interface_line(words_0, current_if_0, interfaces_0)
    print('\ninterface after 1st lo0: %s' % interfaces_0)
    words_1 = ['lo0', 'UP,LOOPBACK,RUNNING,IPv6,MULTICAST', 'mtu', '8252']
    sun_o_s_network_0.parse_interface

# Generated at 2022-06-24 23:02:50.975061
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        sun_o_s_network_collector_0 = SunOSNetworkCollector()
        test_case_0()
    except Exception:
        print("Unable to instantiate SunOSNetworkCollector")


# Generated at 2022-06-24 23:03:11.277942
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print('Testing constructor')
    test_case_0()


# Generated at 2022-06-24 23:03:21.333146
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:03:28.994406
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_0.platform = 'SunOS'
    sun_o_s_network_collector_0._fact_class = SunOSNetwork
    sun_o_s_network_collector_0._platform = 'SunOS'
    sun_o_s_network_collector_0.fact_subsets = dict()


# Generated at 2022-06-24 23:03:39.003931
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()

    current_if = {}
    interfaces = {}
    device = 'bge0'
    words = [u'bge0:', u'flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', u'mtu', u'1500']
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)

    assert current_if['device'] == device
    assert current_if['ipv4'] == [{'flags': [u'UP', u'LOOPBACK', u'RUNNING', u'MULTICAST', u'IPv4'], 'mtu': u'1500'}]
    assert current_if['type'] == 'loopback'



# Generated at 2022-06-24 23:03:43.877385
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    #Exercise
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    #Validate
    assert sun_o_s_network_collector_0._fact_class is SunOSNetwork
    assert sun_o_s_network_collector_0._platform is 'SunOS'
    assert sun_o_s_network_collector_0.facts is None
    assert isinstance(sun_o_s_network_collector_0, NetworkCollector)


# Generated at 2022-06-24 23:03:47.528441
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()



# Generated at 2022-06-24 23:03:56.513239
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_os_network = SunOSNetwork(module=None)

    facts = {
        'kernel': 'SunOS',
    }


    interfaces = {
        'en0': {
            'device': 'en0',
            'ipv4': [],
            'ipv6': [],
            'type': 'loopback',
        },
        'lo0': {
            'device': 'lo0',
            'ipv4': [],
            'ipv6': [],
            'type': 'loopback',
        },
    }
    ips = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }

    ifconfig_path = 'PATH NOT SET'
    rc, out, err = 0, '', ''


# Generated at 2022-06-24 23:04:01.377031
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-24 23:04:03.796922
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector.__class__.__name__ == 'SunOSNetworkCollector'


# Generated at 2022-06-24 23:04:11.201559
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    sun_o_s_network_0 = SunOSNetwork(module=None)
    sun_o_s_network_0._module = dict()
    sun_o_s_network_0._module['run_command'] = run_command_mock

# Generated at 2022-06-24 23:04:45.817126
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    result = SunOSNetworkCollector()
    assert result is not None
    assert result._platform == 'SunOS'
    assert result._fact_class == SunOSNetwork

# Generated at 2022-06-24 23:04:48.857090
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = '/usr/sbin/ifconfig'
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 23:04:53.467996
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector is not None


# Generated at 2022-06-24 23:05:00.848495
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:05:03.122228
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


if __name__ == '__main__':
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:05:08.603832
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    sun_o_s_network_0 = SunOSNetwork(dict(module=None, cmd=dict(path=ifconfig_path)), None)
    interfaces, ips = sun_o_s_network_0.get_interfaces_info(ifconfig_path)
    # An interface should have been discovered
    assert len(interfaces) > 0
    # Interface names are separated by ':'
    for iface in interfaces:
        assert iface.find(':') != -1

# Unit tests for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-24 23:05:12.716036
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.module = MagicMock()
    sun_o_s_network_0.parse_interface_line(MagicMock(), MagicMock(), MagicMock())


# Generated at 2022-06-24 23:05:18.067215
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector is not None


# Generated at 2022-06-24 23:05:19.941310
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print('Test constructor of class SunOSNetworkCollector')
    assert SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:30.694941
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    passwd_file_path = '../fixtures/sunos_ifconfig_output_0'
    ifconfig_path = '../fixtures/sunos_ifconfig_output_0'
    sun_o_s_network_0 = SunOSNetwork()
    interfaces, ips = sun_o_s_network_0.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['addresses'] == ['127.0.0.1']
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'IPv6']

# Generated at 2022-06-24 23:06:15.484189
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork({'redirects': '-1'})
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    list_0 = list()
    sun_o_s_network_collector_0.interfaces = list_0
    str_0 = str()
    sun_o_s_network_collector_0.ansible_cmd = str_0
    str_1 = str()
    sun_o_s_network_collector_0.ansible_path = str_1
    list_1 = list()
    sun_o_s_network_collector_0.all_ipv4_addresses = list_1
    list_2 = list()
    sun_o_s_network_collector_0.all_ipv

# Generated at 2022-06-24 23:06:17.864485
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        a = sun_o_s_network_collector_0
    except NameError:
        a = None
    assert a is not None


# Generated at 2022-06-24 23:06:28.801339
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_ifconfig_0 = ['/usr/bin/ifconfig', '-a']

# Generated at 2022-06-24 23:06:40.744207
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork(module=MockModule())
    sun_o_s_network_0.path = 'path'

    # We may need to use a file name if the test is being run on a different
    # machine to the module
    #f = open('/path/to/ifconfig_a_output')
    #sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig', f.read())

# Generated at 2022-06-24 23:06:41.808780
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert True == True


# Generated at 2022-06-24 23:06:50.928112
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0.module = sun_o_s_network_collector_0.module
    sun_o_s_network_0.module.params = sun_o_s_network_collector_0.module.params
    sun_o_s_network_0.parse_interface_line = sun_o_s_network_collector_0.parse_interface_line
    sun_o_s_network_0.parse_ether_line = sun_o_s_network_collector_0.parse_ether_line

# Generated at 2022-06-24 23:06:52.463707
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    sun_o_s_network_collector.get_facts()

# Generated at 2022-06-24 23:06:55.542565
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    sun_o_s_network_0 = SunOSNetwork(dict(), False)
    sun_o_s_network_0.get_interfaces_info()

    return


# Generated at 2022-06-24 23:07:06.327429
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class SunOSNetwork
    """
    sun_o_s_network_0_inst = SunOSNetwork()
    sun_o_s_network_0 = {'device': 'lo0', 'ipv6': [{'mtu': '8232', 'flags': 'UP,LOOPBACK,RUNNING,IPv6'}], 'type': 'loopback', 'macaddress': 'unknown', 'ipv4': [{'mtu': '8232', 'flags': 'UP,LOOPBACK,RUNNING,MULTICAST'}]}
    sun_o_s_network_1_inst = SunOSNetwork()

# Generated at 2022-06-24 23:07:08.549027
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector = SunOSNetworkCollector()


# Generated at 2022-06-24 23:07:48.963144
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    word_0 = "hJZ?CwY<"
    word_1 = ")p`}oT*T"
    word_2 = "|R1g~,2>oHs#6"
    list_0 = [word_2]
    set_0 = set()
    sun_o_s_network_0 = SunOSNetwork(list_0)
    sun_o_s_network_0.module.run_command = MagicMock(return_value=(2, word_0, word_1))
    word_0 = "YwN<$N>hDkK"
    word_1 = "T$)9Xx0=ls"
    word_2 = "[f0gR6Fm0$"
    list_0 = [word_2]
    set_0 = set()

# Generated at 2022-06-24 23:07:55.829763
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '>xzJj<M'
    set_0 = set()
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(list_0)
    str_1 = '~%c@'
    str_2 = '/dS*'
    var_0 = sun_o_s_network_0.get_interfaces_info((str_1 + str_2))


# Generated at 2022-06-24 23:08:00.158593
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        SunOSNetworkCollector()
    except KeyError:
        print("Failed to instantiate SunOSNetworkCollector")
        return False
    else:
        print("Successfully instantiated SunOSNetworkCollector")
        return True



# Generated at 2022-06-24 23:08:04.100993
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '>xzJj<M'
    set_0 = set()
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(list_0)
    sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:08:09.182069
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector_inst = SunOSNetworkCollector()


# Generated at 2022-06-24 23:08:18.541519
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    str_0 = '<'
    str_1 = 'z'
    str_2 = 'J'
    str_3 = 'j'
    str_4 = 'M'
    list_0 = [str_0, str_1, str_2, str_3, str_4]
    sun_o_s_network_0 = SunOSNetwork(list_0)
    str_5 = '<'
    str_6 = 'J'
    str_7 = 'j'
    str_8 = 'M'
    list_1 = [str_5, str_6, str_7, str_8]
    sun_o_s_network_1 = SunOSNetwork(list_1)

# Generated at 2022-06-24 23:08:21.955124
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:08:23.657642
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # get_interfaces_info(ifconfig_path, collects_parallel=True)
    return



# Generated at 2022-06-24 23:08:27.887295
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '>xzJj<M'
    set_0 = set()
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(list_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:08:34.438207
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '>xzJj<M'
    set_0 = set()
    sun_o_s_network_0 = SunOSNetwork(str_0)
    set_1 = set()
    sun_o_s_network_0.get_interfaces_info(str_0, set_1)


# Generated at 2022-06-24 23:09:59.159215
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'x.J.M>'
    set_0 = {str_0, str_0, str_0}
    sun_o_s_network_0 = SunOSNetwork(set_0)
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:10:07.816859
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '('
    str_1 = ','
    str_2 = ')'
    str_3 = '.'
    str_4 = ';'
    str_5 = '?'
    str_6 = 'E'
    str_7 = '['
    str_8 = ']'
    str_9 = 'e'
    str_10 = 'r'
    str_11 = '{'
    str_12 = '}'
    str_13 = '~'
    str_14 = '\x00'
    set_0 = {str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7, str_8, str_9, str_10, str_11, str_12, str_13, str_14}
    list

# Generated at 2022-06-24 23:10:14.075052
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '#c%y4'
    str_1 = '='
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_0['macaddress'] = 'unknown'
    dict_0['ipv6'] = []
    dict_0['ipv4'] = []
    dict_0['type'] = 'unknown'
    dict_0['device'] = 'h9?,Ql'
    dict_1['lladdr'] = 'unknown'
    dict_1['broadcast'] = 'unknown'
    dict_1['netmask'] = 'unknown'
    dict_1['address'] = 'unknown'
    dict_2['macaddress'] = 'unknown'

# Generated at 2022-06-24 23:10:20.517455
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_3 = 'D($'
    set_3 = {str_3, str_3, str_3}
    sun_o_s_network_0 = SunOSNetwork(set_3)
    str_4 = '-0'
    str_5 = 'mg2'
    set_4 = {str_4, str_4, str_4}
    var_0 = sun_o_s_network_0.get_interfaces_info(str_5, set_4)


# Generated at 2022-06-24 23:10:24.363722
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    sun_o_s_network_0 = SunOSNetwork(set_0)
    str_0 = 'yryG$L'
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:10:34.506055
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '>x.J.M'
    set_0 = {str_0, str_0, str_0}
    sun_o_s_network_0 = SunOSNetwork(set_0)
    str_1 = '>x.J.M'
    set_1 = {str_1, str_1, str_1}
    var_0 = sun_o_s_network_0.parse_interface_line(str_1, str_1, set_1)
    str_2 = '>x.J.M'
    set_2 = {str_2, str_2, str_2}
    var_1 = sun_o_s_network_0.get_interfaces_info(str_2)

test_case_0()

# Generated at 2022-06-24 23:10:39.571159
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = '>x.J.M'
    set_0 = {str_0, str_0, str_0}
    sun_o_s_network_0 = SunOSNetwork(set_0)
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, str_0, set_0)


# Generated at 2022-06-24 23:10:40.319048
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-24 23:10:44.457586
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, NetworkCollector)
    assert isinstance(sun_o_s_network_collector_0, object)
