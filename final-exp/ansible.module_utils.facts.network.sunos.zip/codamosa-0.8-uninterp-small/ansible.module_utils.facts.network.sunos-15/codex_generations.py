

# Generated at 2022-06-24 23:01:02.634735
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interface_line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8232 index 1'
    words = interface_line.split()
    devices = {'lo0': {'device': 'lo0', 'type': 'unknown', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv6', 'VIRTUAL'], 'mtu': '8232'}],'ipv6': [], 'macaddress': 'unknown'}}
    sun_o_s_network_0 = SunOSNetwork(None)

# Generated at 2022-06-24 23:01:05.810089
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork('arg_0')
    ifconfig_path_0 = '/etc/passwd'
    sun_o_s_network_0.get_interfaces_info(ifconfig_path_0)


# Generated at 2022-06-24 23:01:15.517548
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    ifconfig_path_0 = '/sbin/ifconfig'
    sun_o_s_network_0._module.run_command.return_value = (2, '', '')
    sun_o_s_network_0._module.fail_json.assert_called_with(msg='command failed: ', rc=2)
    sun_o_s_network_0.get_interfaces_info(ifconfig_path_0)


# Generated at 2022-06-24 23:01:18.734815
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bool_0 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0)

# Generated at 2022-06-24 23:01:26.854935
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    arguments_0 = {'ifconfig_path': 'ifconfig'}
    sun_o_s_network_0.module = MockArgs(arguments_0)
    bool_2 = True
    sun_o_s_network_0.interfaces = bool_2
    arguments_0 = {'ifconfig_path': 'ifconfig'}
    sun_o_s_network_0.module = MockArgs(arguments_0)
    str_0 = sun_o_s_network_0.get_interfaces_info('ifconfig')
    assert(str_0 == None)



# Generated at 2022-06-24 23:01:30.640119
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_1 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_1)

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:01:34.633433
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    str_0 = 'ifconfig'
    # Method invocation
    value = sun_o_s_network_0.get_interfaces_info(str_0)
    # Verify if invocation went well


# Generated at 2022-06-24 23:01:38.167421
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0)


# Generated at 2022-06-24 23:01:48.479580
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    str_0 = '/sbin/ifconfig'
    tuple_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    sun_o_s_network_0.interfaces = tuple_0[0]
    sun_o_s_network_0.all_ipv4_addresses = tuple_0[1]['all_ipv4_addresses']
    sun_o_s_network_0.all_ipv6_addresses = tuple_0[1]['all_ipv6_addresses']
    sun_o_s_network_0.collect()

# Generated at 2022-06-24 23:01:52.672174
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:02:00.010429
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(dict(module=dict()))
    sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-24 23:02:04.852189
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.module = MagicMock()
    sun_o_s_network_0.module.run_command = MagicMock(return_value=(0, "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n        inet 127.0.0.1 netmask ff000000 \n        options=3<PERFORMNUD,ACCEPT_RTADV>\n\n", ""))
    result = sun_o_s_network_0.get_interfaces_info('')

# Generated at 2022-06-24 23:02:09.450980
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    # assert sun_o_s_network_collector_0.fact_subclass == <class 'ansible.module_utils.facts.network.SunOSNetwork'>


# Generated at 2022-06-24 23:02:10.991330
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:21.549432
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()

# Generated at 2022-06-24 23:02:26.124428
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-24 23:02:29.336223
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    return sun_o_s_network_collector_0
# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 23:02:31.092418
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:36.739965
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.module.run_command = MagicMock(return_value=(0, '', ''))
    sun_o_s_network_0.read_file = MagicMock(return_value=(0, '', ''))
    sun_o_s_network_0.get_interfaces_info(
        ifconfig_path='/sbin/ifconfig'
    )

# Generated at 2022-06-24 23:02:38.437404
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:55.679073
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    words_0 = ['xx0:', 'flags=1000843<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    current_if_0 = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces_0 = {}

# Generated at 2022-06-24 23:02:59.396089
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:03:00.731623
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert callable(SunOSNetworkCollector)


# Generated at 2022-06-24 23:03:04.494691
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()

    # Throws exception on failure
    assert sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-24 23:03:06.258557
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-24 23:03:09.536193
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = '/sbin/ifconfig'
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-24 23:03:17.664097
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    info_obj = SunOSNetwork()
    rc, out, err = info_obj.module.run_command([info_obj.ifconfig_path, '-a'])
    print(out)
    interfaces, ips = info_obj.get_interfaces_info(info_obj.ifconfig_path)
    #print(interfaces)
    assert interfaces['lo0']['type'] == 'loopback'
    assert not interfaces['bge0']['ipv4'][0]['multicast']
    assert not interfaces['bge0']['ipv4'][0]['promiscuous']
    assert interfaces['bge0']['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-24 23:03:23.343980
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    assert sun_o_s_network_0
    sun_o_s_network_0.module.run_command.return_value = (0, '', '')
    sun_o_s_network_0.get_interfaces_info()

# Generated at 2022-06-24 23:03:28.950551
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    result = sun_o_s_network_0.get_interfaces_info()
    assert type(result) == tuple
    assert len(result) == 2
    assert len(result[0]) != 0
    assert len(result[1]) != 0
    assert type(result[0]) == dict
    assert type(result[1]) == dict


# Generated at 2022-06-24 23:03:40.012683
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    # These are not normally set by the module so set them manually
    sun_o_s_network_0.module = MockModule()
    sun_o_s_network_0.module.run_command = Mock(return_value=(0, 'lo0', ''))

    # Here is the SunOS 'ifconfig -a' output (formatted for readability)

# Generated at 2022-06-24 23:03:48.507206
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    assert True



# Generated at 2022-06-24 23:03:53.248925
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork({})
    ifconfig_path_0 = 'ifconfig_path'
    var_0 = sun_o_s_network_0.get_interfaces_info(ifconfig_path_0)


# Generated at 2022-06-24 23:04:04.183496
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'as0'
    dict_0 = {}
    dict_0['device'] = 'as0'
    dict_0['ipv4'] = []
    dict_0['ipv6'] = []
    dict_0['type'] = 'unknown'
    dict_1 = {}
    dict_1['device'] = 'as0'
    dict_1['ipv4'] = []
    dict_1['ipv6'] = []
    dict_1['type'] = 'unknown'
    dict_1['ipv4'].append(dict_0)
    dict_1['ipv6'].append(dict_0)
    str_1 = 'UP BROADCAST RUNNING MULTICAST '
    tuple_0 = (str_0, str_1, '1500')
    sun_o_s_

# Generated at 2022-06-24 23:04:06.943008
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-24 23:04:14.687036
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = 'links'
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    sun_o_s_network_0 = SunOSNetwork(ifconfig_path)
    rc, out, err = sun_o_s_network_0.run_command([ifconfig_path, '-a'])

    for line in out.splitlines():

        if line:
            words = line.split()

            if re.match(r'^\S', line) and len(words) > 3:
                current_if = sun_o_s_network_0.parse_interface_line(words, current_if, interfaces)
                interfaces[current_if['device']] = current_if

# Generated at 2022-06-24 23:04:18.323103
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:04:26.378927
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {}
    interfaces = {}
    sun_o_s_network_1 = SunOSNetwork(tuple())
    var_0 = sun_o_s_network_1.parse_interface_line(words, current_if, interfaces)
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:04:28.219900
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector(None)

# Generated at 2022-06-24 23:04:38.145208
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    sun_o_s_network_0.facts['ansible_facts']['ansible_interfaces'] = ['{GIGABITETHERNET}', '{GIGABITETHERNET}']
    sun_o_s_network_0.facts['ansible_facts']['ansible_all_ipv4_addresses'] = ['192.168.3.3', '192.168.12.23']
    sun_o_s_network_0.facts['ansible_facts']['ansible_all_ipv6_addresses'] = ['fe80::a00:27ff:fed3:8780', 'fe80::a00:27ff:fed3:8780']
    sun_

# Generated at 2022-06-24 23:04:48.857068
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:05:02.638268
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Input parameters:
    #   ifconfig_path:
    str_0 = 'links'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:05:07.358940
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'links'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    list_0 = ['name', 'value', 'name', 'value']
    list_1 = {}
    map_0 = {'key': 'value'}
    sun_o_s_network_0.parse_interface_line(list_0, list_1, map_0)

# Generated at 2022-06-24 23:05:11.841177
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    mySunOSNetwork = SunOSNetwork(None)
    mySunOSNetwork.get_interfaces_info(None)


# Generated at 2022-06-24 23:05:16.901220
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'links'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    result = sun_o_s_network_0.get_interfaces_info(str_0)

    assert result == None, \
        'There was not supposed to be any test result here'


# Generated at 2022-06-24 23:05:25.628980
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = '-a'

# Generated at 2022-06-24 23:05:36.834055
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    str_0 = 'NvI0WY9Ny'
    tuple_1 = ()
    sun_o_s_network_1 = SunOSNetwork(tuple_1)
    str_1 = 'Qaxm'
    tuple_2 = ()
    sun_o_s_network_2 = SunOSNetwork(tuple_2)
    str_2 = 't'
    tuple_3 = ()
    sun_o_s_network_3 = SunOSNetwork(tuple_3)
    str_3 = 'links'
    tuple_4 = ()
    sun_o_s_network_4 = SunOSNetwork(tuple_4)
    str_4 = 't'
    tuple_5

# Generated at 2022-06-24 23:05:39.478994
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:05:43.435036
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    with patch('ansible.module_utils.facts.network.sunos.SunOSNetwork._run_ifconfig') as mock_ifconfig:
        sunos_network_collector = SunOSNetwork({})
        sunos_network_collector._get_interfaces_info()
        mock_ifconfig.assert_called_once_with('-a')

# Generated at 2022-06-24 23:05:44.832910
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:50.188137
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_col_sun_os_network_collector = SunOSNetworkCollector()
    assert type(net_col_sun_os_network_collector) is SunOSNetworkCollector

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:06:17.867010
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    str_0 = "intf0"
    str_1 = "flags=IPv4,IPv6"
    str_2 = "mtu=1500"
    list_0 = [str_0, str_1, str_2]
    str_3 = "en0"
    dict_0 = {"device": str_3, "ipv4": [], "ipv6": [], "type": "unknown"}
    dict_1 = {"device": str_3, "ipv4": [{"flags": str_1, "mtu": str_2}], "ipv6": [], "type": "unknown"}

# Generated at 2022-06-24 23:06:28.917059
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  sun_o_s_network_collector_0 = SunOSNetworkCollector(tuple())
  assert sun_o_s_network_collector_0.__class__ is SunOSNetworkCollector
  assert sun_o_s_network_collector_0.platform == 'SunOS'
  assert sun_o_s_network_collector_0.get_device_info(None, None) == ({}, {})
  assert sun_o_s_network_collector_0.get_interfaces_info(None) == ({}, {})
  assert sun_o_s_network_collector_0.get_netmask(None, None) == None
  assert sun_o_s_network_collector_0._platform == 'SunOS'
  assert sun_o_s_network_collector_0.get_device

# Generated at 2022-06-24 23:06:33.288772
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'links'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:06:38.500373
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    str_0 = 'links'
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    assert isinstance(var_0, tuple)


# Generated at 2022-06-24 23:06:42.842942
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'links'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:06:49.112737
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector.platform == 'SunOS'
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'

# Generated at 2022-06-24 23:06:58.540015
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    str_0 = 'links'
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)
    assert var_1 == (('data', 'data', 'data', 'data', 'data', 'data', 'data', 'data', 'data', 'data', 'data'), {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})


# Generated at 2022-06-24 23:07:04.790915
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'links'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)

    assert var_0 == (None, None)



# Generated at 2022-06-24 23:07:09.823235
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # There is a bug on python 3.2 for the following code.
    # Do not run this test in python 3.2 because of that.
    if not (sys.version_info[0] == 3 and sys.version_info[1] == 2):
        sunos_network_collector = SunOSNetworkCollector()

# Generated at 2022-06-24 23:07:15.380321
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    str_0 = ''
    list_0 = []
    dict_0 = {}
    dict_1 = {}
    sun_o_s_network_0.parse_interface_line(list_0, dict_0, dict_1)


# Generated at 2022-06-24 23:07:52.980431
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 23:07:59.437766
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'uri'
    tuple_0 = ()
    sun_o_s_network_collector_0 = SunOSNetworkCollector(tuple_0)
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)
    assert hasattr(sun_o_s_network_collector_0, str_0)
    str_0 = 'platform'
    str_1 = 'SunOS'
    assert sun_o_s_network_collector_0.__getattr__(str_0) == str_1

# Generated at 2022-06-24 23:08:00.308425
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Must implement...
    assert False


# Generated at 2022-06-24 23:08:03.619178
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'links'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:08:10.792745
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # AssertionError: #0: <platform>.get(): expected one of ('Windows', 'Darwin', 'FreeBSD', 'OpenBSD', 'NetBSD', 'DragonFly', 'Linux', 'SunOS', 'AIX', 'HP-UX')


# Generated at 2022-06-24 23:08:16.542868
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    tuple_0 = ()
    sun_o_s_network_collector_0 = SunOSNetworkCollector(tuple_0)

# unit test for constructor of class SunOSNetwork

# Generated at 2022-06-24 23:08:27.692314
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Preparation
    sun_o_s_network = SunOSNetwork(None)
    words = ["lo0:1", "UP", "LOOPBACK", "RUNNING", "MTU:", "8232", "Index:", "1"]
    interface = {'ipv4': [], 'ipv6': [], 'device': 'lo0', 'type': 'loopback'}
    interfaces = {'lo0': interface}

    # Execution
    result = sun_o_s_network.parse_interface_line(words, interface, interfaces)

    # Validation
    assert result == {'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}], 'ipv6': [], 'device': 'lo0', 'type': 'loopback'}

# Generated at 2022-06-24 23:08:36.305762
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'en0: flags=8a63<UP,BROADCAST,SMART,RUNNING,ALLMULTI,SIMPLEX,MULTICAST> mtu 1500'
    words_0 = str_0.split()
    current_if_0 = {}
    interfaces_0 = {}
    sun_o_s_network_0 = SunOSNetwork(())
    # Call parse_interface_line
    sun_o_s_network_0.parse_interface_line(words_0, current_if_0, interfaces_0)


if __name__ == '__main__':
    pass

# Generated at 2022-06-24 23:08:39.166361
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

test_SunOSNetworkCollector()
# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-24 23:08:44.361119
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'links'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:10:19.977124
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:10:24.314090
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    param0 = SunOSNetwork()
    param1 = 'SunOS'
    obj = SunOSNetworkCollector(param0,param1)
    assert not False, "Test01: constructor of class `SunOSNetworkCollector`"


if __name__ == '__main__':
    test00()

# Generated at 2022-06-24 23:10:29.361876
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    str_0 = 'location'
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    assert isinstance(var_0, tuple)


# Generated at 2022-06-24 23:10:34.872779
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Create a SunOSNetworkCollector instance
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:10:38.965102
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'links'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:10:39.751809
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()



# Generated at 2022-06-24 23:10:42.996605
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '/usr/sbin/ifconfig'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(tuple_0)
    assert sun_o_s_network_0.get_interfaces_info(str_0) == (None, None)


# Generated at 2022-06-24 23:10:43.732330
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector(None)