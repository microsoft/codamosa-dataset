

# Generated at 2022-06-24 23:01:01.842842
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()

    # _ifconfig_path is defined in Network.py
    sun_o_s_network_0._ifconfig_path = '/sbin/ifconfig'

    # re.match() returns a match object or None
    assert sun_o_s_network_0._ifconfig_path is not None

    # /sbin/ifconfig does not exist.
    sun_o_s_network_0._ifconfig_path = '/sbin/ifconfig_does_not_exist'


# Generated at 2022-06-24 23:01:03.966519
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('/usr/bin/ifconfig')


# Generated at 2022-06-24 23:01:05.803509
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-24 23:01:10.456363
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)


# Generated at 2022-06-24 23:01:14.264944
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# TODO: Add unit tests for methods of class SunOSNetworkCollector

# Generated at 2022-06-24 23:01:25.610745
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()

    # class variable _interfaces_path must contain a valid (parsable) list
    sun_o_s_network_0._interfaces_path = [
        '/usr/sbin/ifconfig',
        '-a',
        ]

    _interfaces_info = sun_o_s_network_0.get_interfaces_info('/usr/sbin/ifconfig')
    assert _interfaces_info[0]['lo0']['device']=='lo0' and _interfaces_info[0]['lo0']['ipv4'][0]['mtu']=='8232'
    assert _interfaces_info[1]['all_ipv4_addresses'][0]=='127.0.0.1'

# Generated at 2022-06-24 23:01:35.944976
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network = SunOSNetwork()
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '2']
    current_if = sun_o_s_network.parse_interface_line(words, current_if, interfaces)
    assert 'lo0' in interfaces

# Generated at 2022-06-24 23:01:39.913602
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector, SunOSNetworkCollector)


# Generated at 2022-06-24 23:01:41.766425
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:44.784972
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    #assert sun_o_s_network_collector_0._platform == 'SunOS'


# Generated at 2022-06-24 23:01:55.642801
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)

# Generated at 2022-06-24 23:02:03.483863
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)

    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_configured_ipv6_addresses(sun_o_s_network_0)
    assert var_0 == False, "SunOSNetwork.get_interfaces_info did not return false for unsuccessful run_command"
    assert var_0 == False, "SunOSNetwork.get_interfaces_info did not return false for missing ifconfig_path"

# Generated at 2022-06-24 23:02:07.649918
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)


# Generated at 2022-06-24 23:02:16.322725
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
  bytes_0 = b'\xb6\x19\xd3\x94\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
  sun_o_s_network_0 = SunOSNetwork(bytes_0)
  bool_0 = True
  sun_o_s_network_1 = SunOSNetwork(bool_0)
  sun_o_s_network_2 = SunOSNetwork(sun_o_s_network_1)
  var_0 = sun_o_s_network_2.get_interfaces_info(sun_o_s_network_0)

# Generated at 2022-06-24 23:02:19.411582
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)


# Generated at 2022-06-24 23:02:27.908801
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:02:36.796338
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)
    bytes_1 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'

# Generated at 2022-06-24 23:02:45.490919
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)
    # assert var_0 == (True, False)


# Generated at 2022-06-24 23:02:48.613590
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)


# Generated at 2022-06-24 23:02:53.575725
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    print (sun_o_s_network_collector_0._platform)
    sun_o_s_network_collector_0._fact_class.get_interfaces_info(sun_o_s_network_collector_0)
    print (sun_o_s_network_collector_0._fact_class._platform)
    sun_o_s_network_collector_0._get_facts()


# Generated at 2022-06-24 23:03:09.536916
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    with raises(AttributeError):
        sun_o_s_network_0 = SunOSNetwork(bytes_0)
        bool_0 = False
        sun_o_s_network_1 = SunOSNetwork(bool_0)
        # var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)

# Generated at 2022-06-24 23:03:13.345610
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)


# Generated at 2022-06-24 23:03:20.957570
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)


# Generated at 2022-06-24 23:03:25.651510
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    bool_0 = True
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    # self.assertEqual(len(sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)), 2)


# Generated at 2022-06-24 23:03:31.897754
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    var_0 = sun_o_s_network_collector_0.platform
    assert var_0 == "SunOS"
    assert sun_o_s_network_collector_0.subset == '!^(?:docker|lo)$'


# Generated at 2022-06-24 23:03:39.976528
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)
    sun_o_s_network_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:03:47.979376
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Initialize test environment
    bytes_0 = b'\x8ft\x81\x1c\x06'
    bytes_1 = b'IK\xed\x99\xcf\x8e\xdc\x14\xe2\xd9\xb9\xca\x89'
    byte_array_0 = bytearray(bytes_0)
    byte_array_1 = bytearray(bytes_1)
    bytes_2 = b'\xe0\x90\xf9\x04\x01'
    word_list_0 = ['8ft']
    word_list_1 = ['IK']
    word_list_2 = ['\xed\x99\xcf8\xe2\xd9\xb9C\x89']

# Generated at 2022-06-24 23:03:54.978710
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)

# Generated at 2022-06-24 23:03:55.703112
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-24 23:04:02.320092
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    bool_0 = True
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    sun_o_s_network_2 = SunOSNetwork('/usr/sbin/ifconfig')
    sun_o_s_network_3 = SunOSNetwork(b'')
    var_0 = sun_o_s_network_3.get_interfaces_info(sun_o_s_network_2)


# Generated at 2022-06-24 23:04:27.853230
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    words_0 = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '2', 'inet', '127.0.0.1', 'netmask', 'ff000000']
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    current_if_0 = sun_o_s_network_1.parse_interface_

# Generated at 2022-06-24 23:04:29.003743
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-24 23:04:29.660707
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-24 23:04:34.883456
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    _fact_class = SunOSNetwork
    _platform = 'SunOS'
    string_0 = 'd'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(_fact_class, string_0)
    string_1 = '\t'
    sun_o_s_network_collector_1 = SunOSNetworkCollector(sun_o_s_network_collector_0, string_1)
    sun_o_s_network_collector_2 = SunOSNetworkCollector(sun_o_s_network_collector_0, 'ya')
    sun_o_s_network_collector_3 = SunOSNetworkCollector(sun_o_s_network_collector_1, _platform)

# Generated at 2022-06-24 23:04:40.008548
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    return_value_0 = sun_o_s_network_0.get_interfaces_info()  # Don't know how to test this
    return_value_1 = sun_o_s_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:04:49.023842
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    list_0 = [
        'lo0:1',
        'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
        'mtu 8232',
    ]
    current_if = {}
    interfaces = {}
    sun_o_s_network_0.parse_interface_line(list_0, current_if, interfaces)


# Generated at 2022-06-24 23:04:54.428911
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)


# Generated at 2022-06-24 23:04:57.687958
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # test case for constructor of class SunOSNetworkCollector
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork
    # test case for constructor of class SunOSNetworkCollector
    assert sun_o_s_network_collector_0._platform == 'SunOS'


# Generated at 2022-06-24 23:05:02.583524
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    dict_0 = {bytes_0: bytes_0}
    dict_1 = {bytes_0: bytes_0}
    sun_o_s_network_1 = SunOSNetwork(dict_1)
    var_0 = sun_o_s_network_1.parse_interface_line(list_0, dict_0, dict_1)


# Generated at 2022-06-24 23:05:08.565208
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)

# Generated at 2022-06-24 23:05:25.939962
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:28.037105
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:32.670304
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)

# Generated at 2022-06-24 23:05:43.778308
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bytes_1 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_1 = SunOSNetwork(bytes_1)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)


# Generated at 2022-06-24 23:05:52.505642
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)

# Generated at 2022-06-24 23:06:00.251132
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)


# Generated at 2022-06-24 23:06:07.219260
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector(None, None)
    sun_o_s_network_collector_1 = SunOSNetworkCollector((), {}, None)


if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:06:17.042538
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test case for constructor of class SunOSNetworkCollector.
    # Test case for method get_modules.
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_collector_1 = SunOSNetworkCollector(bytes_0)
    var_0 = sun_o_s_network_collector

# Generated at 2022-06-24 23:06:26.445715
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_5 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_9 = SunOSNetwork(bytes_5)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(sun_o_s_network_9)
    assert sun_o_s_network_collector_0.platform() == 'SunOS'


# Generated at 2022-06-24 23:06:28.716198
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert c._platform == 'SunOS'
    assert c._fact_class == SunOSNetwork

# Generated at 2022-06-24 23:07:06.593972
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_1 = SunOSNetworkCollector()
    sun_o_s_network_collector_1._fact_class = sun_o_s_network_collector_0._fact_class
    sun_o_s_network_collector_1._platform = sun_o_s_network_collector_0._platform

# Generated at 2022-06-24 23:07:12.348625
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)


# Generated at 2022-06-24 23:07:18.155578
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)
    print(var_0)


# Generated at 2022-06-24 23:07:24.581608
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    str_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_1)


# Generated at 2022-06-24 23:07:33.239623
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork
    assert sun_o_s_network_collector_0._platform == 'SunOS'


# Generated at 2022-06-24 23:07:36.802440
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b'<\xe0\x96\xc6\x8a\xe2\x96\xba\x06\xa9\x97\x92\xed'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)


# Generated at 2022-06-24 23:07:42.705293
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'

# Generated at 2022-06-24 23:07:47.821852
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)



# Generated at 2022-06-24 23:07:58.334339
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bytes_0 = b'\x88\xb7\x04\xaf\x91\x1f\x88X\xc2\xbf\x0e\x83\xa3\x1eh\x1a\x0cD'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bytes_1 = b't\x00\x01\x00\x00\x93_\x00\x01\x00\x00\x93^\x00\x03\x00\x00\x93H'
    sun_o_s_network_1 = SunOSNetwork(bytes_1)
    bool_0 = False
    sun_o_s_network_2 = SunOSNetwork(bool_0)
    sun_o_s_network_2.get_inter

# Generated at 2022-06-24 23:08:04.898868
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)


# Generated at 2022-06-24 23:09:40.415096
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup mock objects
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    # Call method
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)
    # check return value
    var_1 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_1)
    assert var_1 == var_0
    assert var_0

# Generated at 2022-06-24 23:09:45.706607
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)



# Generated at 2022-06-24 23:09:57.677858
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)

# Generated at 2022-06-24 23:10:02.827398
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(sun_o_s_network_0)


# Generated at 2022-06-24 23:10:08.523015
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)

# Generated at 2022-06-24 23:10:13.991690
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork()
    sun_o_s_network.get_interfaces_info()

# Generated at 2022-06-24 23:10:20.080513
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)


if __name__ == '__main__':
    test_SunOSNetworkCollector()
    test_case_0()

# Generated at 2022-06-24 23:10:22.257678
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:10:31.170550
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xfa\xe2\x84\x90\xf6@9\xb8\x03\x030\x95\x11\x183\xec\x13\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_0)
    sun_o_s_network_0 = SunOSNetwork()
    bool_0 = False
    sun_o_s_network_1 = SunOSNetwork(bool_0)

# Generated at 2022-06-24 23:10:34.112290
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  test_case_0()