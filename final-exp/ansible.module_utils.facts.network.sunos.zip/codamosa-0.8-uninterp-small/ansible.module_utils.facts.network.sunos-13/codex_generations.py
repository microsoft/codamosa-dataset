

# Generated at 2022-06-24 23:00:59.065831
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = "NrIt$P}fJ'>n-(\t"
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)



# Generated at 2022-06-24 23:00:59.905230
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 23:01:02.798215
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print("test_SunOSNetworkCollector:")

    # Test 0
    test_case_0()

    print("test_SunOSNetworkCollector: end")

test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:01:04.438005
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = "?zM=:|"
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)


# Generated at 2022-06-24 23:01:10.254336
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_cases = [
        (0,),
    ]

    for case in test_cases:
        yield test_case_0

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-24 23:01:21.170504
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = "NrIt$P}fJ'>n-(\t"
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    sun_

# Generated at 2022-06-24 23:01:25.945763
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = "NrIt$P}fJ'>n-(\t"
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0, SunOSNetwork(str_0))
    sun_o_s_network_collector_0.get_all_facts()

# Generated at 2022-06-24 23:01:36.984571
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # Create a network object to test with.
    sun_o_s_network_obj = SunOSNetwork('module_name', 'ifconfig_path')

    # Create a dictionary of interface data.
    interfaces_dict = {'lo': {'device': 'lo', 'ipv4': [{'flags': ['UP', 'LOOPBACK'], 'mtu': '1500'}],
                              'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}}

    # Create a list of words for testing.
    words_list = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '1500']

    # Assert that the method returns the expected result.
    assert sun_o_s_

# Generated at 2022-06-24 23:01:48.173099
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = "NrIt$P}fJ'>n-(\t"
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    str_1 = "o\x13\x0c\x11\"\x1c"
    int_0 = len(str_1)
    str_2 = "a"
    str_3 = "C\x1c"
    dict_0 = dict()
    str_4 = "C\x1c"
    dict_0[str_4] = int_0
    str_5 = "C\x1c"
    dict_0[str_5] = str_2
    str_6 = "C\x1c"
    dict_0[str_6] = str_3
    sun_o_s

# Generated at 2022-06-24 23:01:54.655956
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = "  M'c8!bW1i:_q&b/w\r"
    o_s_network_0 = SunOSNetwork(str_0)
    str_1 = "Z\f) #%[h<(2Te$]\f1\ta\r"
    o_s_network_0.get_interfaces_info(str_1)

# Generated at 2022-06-24 23:02:05.415438
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork
    assert sun_o_s_network_collector_0._platform == 'SunOS'



# Generated at 2022-06-24 23:02:16.774242
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork()
    sun_o_s_network, ips = sun_o_s_network.get_interfaces_info(
        ifconfig_path='/sbin/ifconfig')

    assert (sun_o_s_network['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING'])
    assert (sun_o_s_network['lo0']['macaddress'] == '00:00:00:00:00:00')
    assert (sun_o_s_network['lo0']['mtu'] == '8232')
    assert (sun_o_s_network['lo0']['type'] == 'loopback')

# Generated at 2022-06-24 23:02:25.417001
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces = {
        'lo0': {
            'device': 'lo0',
            'ipv4': [{
                        'flags': ['IPv4', 'Loopback', 'UP', 'IPv6', 'Internal'],
                        'mtu': '8232'
                    }, {
                        'flags': [],
                        'mtu': '8232'
                }],
            'ipv6': [{
                        'macaddress': 'unknown',
                        'type': 'loopback'
                    }, {
                        'macaddress': 'unknown',
                        'type': 'loopback'
                    }
                ],
            'macaddress': 'unknown',
            'type': 'unknown'
        }
    }


# Generated at 2022-06-24 23:02:29.111877
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class is not None
    assert sun_o_s_network_collector_0._platform is not None



# Generated at 2022-06-24 23:02:32.519618
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector._fact_class == SunOSNetwork
    assert sun_o_s_network_collector._platform == 'SunOS'


# Generated at 2022-06-24 23:02:37.471473
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    sun_o_s_network_0 = SunOSNetwork()
    interfaces, ips = sun_o_s_network_0.get_interfaces_info(ifconfig_path)

    assert 'lo0' in interfaces
    assert 'e1000g0' in interfaces
    assert interfaces['e1000g0']['ipv4'][0]['address'] == '172.19.0.3'
    assert interfaces['e1000g0']['ipv4'][0]['netmask'] == '255.255.0.0'
    assert interfaces['e1000g0']['ipv4'][0]['broadcast'] == '172.19.255.255'

# Generated at 2022-06-24 23:02:41.128817
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    rc, out, err = sun_o_s_network_0.module.run_command([sun_o_s_network_0.network.get('get_interfaces_command')])
    sun_o_s_network_0.get_interfaces_info(sun_o_s_network_0.network.get('get_interfaces_command'))

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:02:46.812033
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network = SunOSNetwork()

# Generated at 2022-06-24 23:02:55.796788
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork({})
    words = ['net0:', 'flags=201000843', 'mtu', '1500', 'index', '8']
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-24 23:03:01.657636
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork({'module': {'run_command': (lambda *_, **__: ['', '', 0])}}, 'test')
    assert sun_o_s_network_0.get_interfaces_info('test') == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})


# Generated at 2022-06-24 23:03:09.183928
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print('**** Unit test ****')

    test_case_0()
    # Unit test for constructor of class SunOSNetworkCollector
    print('Test case 0:')



# Generated at 2022-06-24 23:03:11.407840
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(), NetworkCollector)


# Generated at 2022-06-24 23:03:16.745924
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = '/sbin/ifconfig'
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)



# Generated at 2022-06-24 23:03:24.040907
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Testing with a external configuration file.
    sun_o_s_network_1_0 = SunOSNetwork(config=[('/etc/test_sun_o_s_network_1', False)])
    result = sun_o_s_network_1_0.get_interfaces_info('/sbin/ifconfig')
    assert result == ({}, {'all_ipv6_addresses': [], 'all_ipv4_addresses': []})

# Generated at 2022-06-24 23:03:35.096377
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork()
    assert isinstance(sun_o_s_network_collector_0, NetworkCollector)
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)
    assert sun_o_s_network_collector_0._fact_class is sun_o_s_network_0
    assert sun_o_s_network_collector_0._platform == 'SunOS'

sun_o_s_network_collector_1 = SunOSNetworkCollector()
sun_o_s_network_1 = SunOSNetworkCollector()._fact_class


# Generated at 2022-06-24 23:03:43.104408
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_os_network = SunOSNetwork()
    ifconfig_path = '/sbin/ifconfig'
    rc, out, err = sun_os_network.module.run_command([ifconfig_path, '-a'])
    interfaces, ips = sun_os_network.get_interfaces_info(ifconfig_path)
    assert interfaces is not None
    assert 'lo0' in interfaces
    for k in 'device', 'ipv4', 'ipv6', 'macaddress', 'type':
        assert k in interfaces['lo0']
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['type'] == 'loopback'
    assert 'flags' in interfaces['lo0']['ipv4'][0]

# Generated at 2022-06-24 23:03:53.928619
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    sun_o_s_network_0 = SunOSNetwork()
    current_if_0 = {
        'device': 'bge0',
        'ipv4': [{
            'flags': ['UP',
                      'BROADCAST',
                      'RUNNING',
                      'SIMPLEX',
                      'MULTICAST'],
            'mtu': '1500'}],
        'ipv6': [{
            'flags': ['UP',
                      'PUNT',
                      'SIMPLEX',
                      'MULTICAST',
                      'IPv6'],
            'mtu': '1500'}],
        'type': 'unknown',
        'macaddress': 'unknown'}

# Generated at 2022-06-24 23:03:57.773405
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:04:07.790968
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This test is for parsing interface output on SunOS 5.11 as this output
    may be different than other versions of Solaris.
    """
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_1 = SunOSNetwork()
    sun_o_s_network_0.module = sun_o_s_network_1.module = MockModule()

    fname = 'tests/unit/module_utils/facts/network/fixture/sample_SunOS5.11_ifconfig-a_clean'
    with open(fname, 'r') as f:
        output = f.read()
    interfaces, ips = sun_o_s_network_0.get_interfaces_info('/usr/sbin/ifconfig')

# Generated at 2022-06-24 23:04:14.205825
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from sys import getsizeof

    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork
    assert sun_o_s_network_collector_0._platform == 'SunOS'

    # Test __init__ and __new__
    sun_o_s_network_collector_1 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_1._fact_class == SunOSNetwork
    assert sun_o_s_network_collector_1._platform == 'SunOS'
    assert sun_o_s_network_collector_1.__sizeof__() >= getsizeof(sun_o_s_network_collector_1)

    # Test __init__ and __new

# Generated at 2022-06-24 23:04:28.252209
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.parse_interface_line()


# Generated at 2022-06-24 23:04:39.235195
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {
        'device': 'lo0',
        'ipv4': [
            {'flags': 'IPv6', 'mtu': '1500'}
        ],
        'ipv6': [
            {'flags': 'IPv4', 'mtu': '1500'}
        ],
        'type': 'loopback'
    }
    interfaces = {}
    SunOSNetwork.parse_interface_line(['lo0:','flags=849','<UP,LOOPBACK,RUNNING>','mtu','1500',
                                       'inet6','::1/128','enet',':localhost'], current_if, interfaces)

# Generated at 2022-06-24 23:04:48.158162
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.module = AnsibleModuleMock()

    assert len(sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')[0].keys()) == 1
    assert len(sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')[1]['all_ipv4_addresses']) == 0
    assert len(sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')[1]['all_ipv6_addresses']) == 0


# Generated at 2022-06-24 23:04:53.980122
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # Test that class can be instantiated.
    assert(sun_o_s_network_collector_0 != None)


# Generated at 2022-06-24 23:05:05.620915
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:05:13.205369
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path_0 = '/sbin/ifconfig'
    assert sun_o_s_network_0.get_interfaces_info(ifconfig_path_0) == (sun_o_s_network_0.interfaces, sun_o_s_network_0.ipv4, sun_o_s_network_0.ipv6)


# Generated at 2022-06-24 23:05:18.818608
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sunos_network_0 = SunOSNetwork({})
    sunos_network_0.get_interfaces_info('/usr/sbin/ifconfig')
    assert True


# Generated at 2022-06-24 23:05:21.758047
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # Constructor should have set '_platform' to platform of machine running the module
    assert sun_o_s_network_collector_0._platform == 'SunOS'



# Generated at 2022-06-24 23:05:23.884395
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0.get_facts()[0]['default_ipv4']['gateway'] == '172.16.1.1'


# Generated at 2022-06-24 23:05:26.469573
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:51.169488
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    if not hasattr(SunOSNetworkCollector, 'platform'):
        SunOSNetworkCollector.platform = 'SunOS'
    if not hasattr(SunOSNetworkCollector, '_fact_class'):
        SunOSNetworkCollector._fact_class = SunOSNetwork
    if not hasattr(SunOSNetworkCollector, '_platform'):
        SunOSNetworkCollector._platform = 'SunOS'



# Generated at 2022-06-24 23:06:01.469779
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()
    sun_o_s_network_1 = SunOSNetwork(sun_o_s_network_collector_1)

# Generated at 2022-06-24 23:06:07.883166
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = '/sbin/ifconfig'
    interfaces_info = sun_o_s_network_0.get_interfaces_info(ifconfig_path)
    # Method 'get_interfaces_info' returns a tuple containing 2 elements.
    assert type(interfaces_info) is tuple


# Generated at 2022-06-24 23:06:12.250325
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork()
    sun_o_s_network_interfaces_info = sun_o_s_network.get_interfaces_info('/sbin/ifconfig')
    assert len(sun_o_s_network_interfaces_info) == 2


# Generated at 2022-06-24 23:06:14.737922
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_1 is not None


# Generated at 2022-06-24 23:06:16.048706
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert(sun_o_s_network_collector_0.platform == 'SunOS')

# Generated at 2022-06-24 23:06:26.678543
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network = SunOSNetwork()
    words = ["lo0:", "flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>", "mtu", "8232", "index", "2"]
    current_if = {'device': "vmnet1", 'ipv4': [{'flags': '2001001843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST,DHCP,IPv4>', 'mtu': '1500'}, {'flags': '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu': '8232'}], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-24 23:06:29.721255
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    print(sun_o_s_network_0)
    sun_o_s_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:06:42.270926
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork()
    interfaces = {}
    current_if = {}
    ips = {}

    rc, out, err = ansible_module.run_command([ifconfig_path, '-a'])
    if rc == 0:
        for line in out.splitlines():
            if line:
                words = line.split()

                if re.match(r'^\S', line) and len(words) > 3:
                    current_if = sun_o_s_network.parse_interface_line(words, current_if, interfaces)
                    interfaces[current_if['device']] = current_if
                elif words[0].startswith('options='):
                    sun_o_s_network.parse_options_line(words, current_if, ips)

# Generated at 2022-06-24 23:06:43.627570
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:07:04.026492
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunosnetworkcollector_0 = SunOSNetworkCollector('mCM|K)n2Jh:')
    assert sunosnetworkcollector_0._fact_class is not None
    assert sunosnetworkcollector_0._platform is not None


# Generated at 2022-06-24 23:07:10.083699
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:07:17.108384
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:07:20.468613
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:07:28.219238
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_1)
    sun_o_s_network_collector_0.platform = str_0
    sun_o_s_network_collector_0.get_facts()

# Generated at 2022-06-24 23:07:38.239429
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    var_1 = SunOSNetworkCollector(str_0)
    var_2 = SunOSNetworkCollector(str_0)
    str_2 = 'Dynamic routing not supported by this host\n'
    str_3 = '0'
    str_4 = 'sfWg"/J<{H9O/P,a_P'
    str_5 = '5~5w5'
    var_3 = var_

# Generated at 2022-06-24 23:07:41.672161
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:07:42.774268
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:07:45.696952
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # str -> unicode
    sun_o_s_network_0 = SunOSNetwork()

    # unicode -> str
    sun_o_s_network_1 = SunOSNetwork()


if __name__ == '__main__':
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:07:54.932237
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    sun_o_s_network_0.parse_interface_line(var_0,)


# Generated at 2022-06-24 23:08:38.478788
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    return var_0


# Generated at 2022-06-24 23:08:47.879003
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)

# Generated at 2022-06-24 23:08:51.300761
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_1)

# Generated at 2022-06-24 23:08:59.622763
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:09:03.360710
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert isinstance(c, SunOSNetworkCollector)
    assert c._platform == 'SunOS'
    assert c._fact_class == SunOSNetwork

test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:09:10.616262
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:09:16.027181
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    assert (sun_o_s_network_0.get_interfaces_info(str_0) == ([], [])) == False



# Generated at 2022-06-24 23:09:22.407699
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:09:26.261286
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    sun_o_s_network_0.get_interfaces_info(str_0)
    var_0 = sun_o_s_network_0.interfaces
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 23:09:29.293669
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'Path %s is owned by group %s, not by group %s as expected\n'
    str_1 = '8hn4$-Vl$:Nid2yi8,'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
