

# Generated at 2022-06-24 23:01:00.584916
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    str_0 = 'M]\x0clG7~fXCz'

# Generated at 2022-06-24 23:01:02.940871
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_1 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:09.936957
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    str_0 = 'bPA\x0c\x0cCfzy\x0c'
    str_1 = 'o\x0c\x0ckN\x0c\x0cZ\x0c'
    str_2 = 'wW2b\x0c\x0cqC\x0c'
    dict_0 = {str_0: {'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'], 'mtu': '1500'}, str_1: {'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'], 'mtu': '1500'}}

# Generated at 2022-06-24 23:01:14.079933
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork('/usr/sbin/ifconfig')
    # test invocation
    sun_o_s_network_0.parse_interface_line(['device'], {}, {})


# Generated at 2022-06-24 23:01:23.976180
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork()
    path = '/sbin/ifconfig'
    sun_o_s_network_0.module._socket_path = path
    interfaces_info = sun_o_s_network_0.get_interfaces_info(path)
    assert interfaces_info[0]['lo0']['ipv4'][0]['mtu'] == '8232' and interfaces_info[0]['lo0']['ipv4'][1]['mtu'] == '8252'
    assert interfaces_info[0]['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'] and interfaces_

# Generated at 2022-06-24 23:01:32.434716
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    str_0 = 'PHayUP\x7fr\x1f'
    sun_o_s_network_0._fact_class = str_0
    str_1 = '~?\t\nV\rv'
    sun_o_s_network_0._platform = str_1

    network_0 = sun_o_s_network_0.get_interfaces_info(str_1)


# Generated at 2022-06-24 23:01:33.694993
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:40.730752
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0.module)

    # Test case for  SunOSNetwork.get_interfaces_info without parameter 'ifconfig_path'
    sun_o_s_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:01:44.972864
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    str_1 = sun_o_s_network_0.parse_interface_line(['lo0', 'flags=2001000849 mtu 8232 index 1', 'inet 127.0.0.1 netmask ff000000'])


# Generated at 2022-06-24 23:01:46.712874
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj, SunOSNetworkCollector)


# Generated at 2022-06-24 23:01:59.895154
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    fact = SunOSNetwork()
    fact.module = "module"
    fact.module.run_command = lambda args: [0, 'out', 'err']

    ifconfig_path = '/sbin/ifconfig'


# Generated at 2022-06-24 23:02:03.260011
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    pass


################################################################################
#

# Generated at 2022-06-24 23:02:08.793187
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork({})

# Generated at 2022-06-24 23:02:09.925146
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'


# Generated at 2022-06-24 23:02:15.143677
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = "/sbin/ifconfig"
    sun_o_s_network_0 = SunOSNetwork()
    interfaces, ips = sun_o_s_network_0.get_interfaces_info(ifconfig_path)
    print(interfaces)
    print(ips)


# Generated at 2022-06-24 23:02:18.088257
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_class = SunOSNetwork
    platform = 'SunOS'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(fact_class, platform)


# Generated at 2022-06-24 23:02:27.409438
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:02:29.013035
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert 'SunOSNetworkCollector' == SunOSNetworkCollector.__name__


# Generated at 2022-06-24 23:02:30.277482
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)



# Generated at 2022-06-24 23:02:39.549986
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()
    sun_o_s_network_collector_1._return_values['run_command'] = (0, '\nlo0:1: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1\n        inet 127.0.0.1 netmask ff000000\n', None)
    sun_o_s_network_collector_1._return_values['get_options'] = {'IPv4', 'UP', 'LOOPBACK', 'MULTICAST', 'RUNNING'}
    result_1 = sun_o_s_network_collector_1.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-24 23:02:54.961060
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)

# Generated at 2022-06-24 23:03:03.583571
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    float_0 = 2602.2129
    #os.chdir('[path to file]')

    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)

# Generated at 2022-06-24 23:03:12.198634
# Unit test for constructor of class SunOSNetworkCollector

# Generated at 2022-06-24 23:03:17.134198
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0.platform == 'SunOS'



# Generated at 2022-06-24 23:03:19.410775
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0.platform == 'SunOS'

# Generated at 2022-06-24 23:03:30.669682
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from unittest.mock import patch
    with patch('ansible.module_utils.facts.network.sunos.SunOSNetwork.parse_interface_line') as mocked_SunOSNetwork_parse_interface_line:
        float_0 = 2602.2129
        bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
        sun_o_s_network_0 = SunOSNetwork(bytes_0)
        par_0 = 2973
        par_1 = par_0
        par_2 = par_1
        par_3 = par_2
        par_4 = par_3
        par_5 = par_4
        par_6 = par_5

# Generated at 2022-06-24 23:03:34.191171
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Constructor SunOSNetworkCollector
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:03:41.004036
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    current_if = dict()
    interfaces = dict()
    words = ["'some'", "'flags'", "'mtu'"]
    assert sun_o_s_network_0.parse_interface_line(words, current_if, interfaces) == {'device': 'some', 'type': 'unknown', 'ipv4': [{'flags': ['flags', 'mtu'], 'mtu': 'mtu'}], 'ipv6': []}


# Generated at 2022-06-24 23:03:46.122251
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    var_0 = sun_o_s_network_collector_0._fact_class(bytes_0)
    assert var_0.parse_interface_line(float_0, float_0, float_0) == -1, 'AssertionError'


# Generated at 2022-06-24 23:03:54.098162
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    words_0 = ['lo0:']
    current_if_0 = {'device': 'lo0:'}
    interfaces_0 = {}
    result = sun_o_s_network_0.parse_interface_line(words_0, current_if_0, interfaces_0)
    result_0 = {'device': 'lo0:', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback'}
    assert result == result_0

# Unit

# Generated at 2022-06-24 23:04:08.656862
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b"\xe0\xa0\xae'"
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)

    assert sun_o_s_network_collector_0._fact_class is SunOSNetwork



# Generated at 2022-06-24 23:04:11.196302
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0, float_0)

# Generated at 2022-06-24 23:04:13.971029
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)


# Generated at 2022-06-24 23:04:24.380645
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)


# Generated at 2022-06-24 23:04:31.873105
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    print('')
    print('Test get_interfaces_info')
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)
    print(var_0)


# Generated at 2022-06-24 23:04:35.198554
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    os_path_0 = os.path
    str_0 = str
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0, float_0, os_path_0, str_0)


# Generated at 2022-06-24 23:04:45.357013
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    sun_o_s_network_0.get_interfaces_info(float_0)
    short_0 = 32767
    short_1 = 32767
    short_2 = 32767
    short_3 = 32767
    short_4 = 32767
    short_5 = 32767
    short_6 = 32767
    short_7 = 32767
    short_8 = 32767
    short_9 = 32767
    short_10 = 32767
    short_11 = 32767
    short_12 = 32767
    short_13 = 32767
    short_14 = 32767
   

# Generated at 2022-06-24 23:04:50.087757
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # test case 0
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)

    assert var_0 == None


# Generated at 2022-06-24 23:04:53.778209
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)
    assert var_0


# Generated at 2022-06-24 23:04:58.516105
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    assert get_interfaces_info() == 'lo0', 'Test get_interfaces_info() method'


# Generated at 2022-06-24 23:05:19.897204
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = 165.5
    bytes_0 = b'\xc0\x8c\x8e\xcf'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(sun_o_s_network_0)
    var_0 = sun_o_s_network_collector_0.get_facts()



# Generated at 2022-06-24 23:05:25.683268
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector_0 = SunOSNetworkCollector()
    return collector_0

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:05:31.435142
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)


# Generated at 2022-06-24 23:05:43.284019
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    words_0 = ['en0:', 'IPv6', 'Media', '10Mb/s', 'RX', 'flow', 'status:', 'no', 'status']
    current_if_0 = dict()
    interfaces_0 = dict()
    var_0 = sun_o_s_network_0.parse_interface_line(words_0, current_if_0, interfaces_0)

# Generated at 2022-06-24 23:05:46.792144
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    sun_o_s_network_collector_0 = SunOSNetworkCollector()
  

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:05:49.326621
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    assert 0 == 0


# Generated at 2022-06-24 23:05:52.800606
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)


# Generated at 2022-06-24 23:05:59.844499
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(sun_o_s_network_0)
    var_0 = sun_o_s_network_collector_0.get_device_to_ip_interface()


# Generated at 2022-06-24 23:06:07.116691
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)

if __name__ == "__main__":
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:06:11.440105
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test for class SunOSNetworkCollector(NetworkCollector)
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    print(sun_o_s_network_collector_0)
    print(repr(sun_o_s_network_collector_0))

# Generated at 2022-06-24 23:06:47.839909
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_0.get_facts()


# Generated at 2022-06-24 23:06:56.554729
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import tempfile
    import os

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # create the output file
    rc, stdout, stderr = module.run_command(['ifconfig', '-a'], check_rc=False)
    filename = os.path.join(tmpdir, 'ifconfig.txt')
    with open(filename, 'wb') as f:
        f.write(stdout)

    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    sun_o_s_network_0.get_interfaces_info(float_0)

# Generated at 2022-06-24 23:06:58.631586
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)
    assert var_0 == ()

# Generated at 2022-06-24 23:07:05.643230
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    # Test create an object from the class SunOSNetworkCollector.
    sunOSNetworkCollectorObject = SunOSNetworkCollector()

    # Test the class name.
    expected = 'SunOSNetworkCollector'
    assert sunOSNetworkCollectorObject.__class__.__name__ == expected, 'Expected class name is: {0}'.format(expected)


# Generated at 2022-06-24 23:07:16.793035
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)
    var_1 = sun_o_s_network_0.get_interfaces_info(float_0)
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_2 = sun_o_s_network_0.get_interfaces_info(float_0)
    var_3 = sun_o_s_network_0.get_interfaces_info(float_0)

# Generated at 2022-06-24 23:07:23.233560
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)

    assert var_0 is None


# Generated at 2022-06-24 23:07:27.729016
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)


# Generated at 2022-06-24 23:07:31.485073
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    # Test implementation of constructor
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:07:36.581967
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetworkCollector(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)

test_case_0()

# Generated at 2022-06-24 23:07:43.376475
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)


# Generated at 2022-06-24 23:08:56.625880
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)


# Generated at 2022-06-24 23:09:06.514889
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_collector_0 = SunOSNetworkCollector(float_0)
    sun_o_s_network_collector_1 = SunOSNetworkCollector(bytes_0)

    # Unit test for get_devices of class SunOSNetworkCollector
    int_0 = 50
    int_1 = 112
    sun_o_s_network_collector_1.get_devices(int_0)
    sun_o_s_network_collector_0.get_devices(int_1)


# Generated at 2022-06-24 23:09:12.722164
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)
    print(var_0)


# Generated at 2022-06-24 23:09:15.750324
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)

# Generated at 2022-06-24 23:09:21.756999
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)

# Generated at 2022-06-24 23:09:27.656927
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 8337.3285
    bytes_0 = b'6\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(float_0)

    float_0 = 1265.2194
    bytes_0 = b'\xdc\xf7\xe5\xe3\x80J\xde\x1c'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    var_1 = sun_o_s_network_0.get_interfaces_info(float_0)

    float_0 = 2438.8763
    bytes_0 = b'\x84\xe0\x94\x83\x10\x12'

# Generated at 2022-06-24 23:09:34.595211
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork(b"M\x00\xff\x7f")
    sun_o_s_network.get_interfaces_info(10.9)

if __name__ == '__main__':
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:09:38.324516
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Check that there are no exceptions
    try:
        test_case_0()
    except Exception as err:
        print('test_SunOSNetwork_get_interfaces_info raised exception: ' + str(err))



# Generated at 2022-06-24 23:09:45.822373
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    float_0 = 2602.2129
    bytes_0 = b"y\xfcK\xfd\x7f\xa7'"
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    assert(len(sun_o_s_network_0.get_interfaces_info(float_0)) == 2)
    #assert(
    #    sun_o_s_network_0.get_interfaces_info(float_0) ==
    #    ({'lo0': {'macaddress': '02:00:00:00:00:00', 'ipv6': [{'mtu': '65536', 'flags': {'IPv6': True, 'MTU': 65536, 'LOOPBACK': True}}], 'type': 'loopback', 'ipv4': [{'mt

# Generated at 2022-06-24 23:09:57.739380
# Unit test for method parse_interface_line of class SunOSNetwork