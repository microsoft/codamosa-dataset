

# Generated at 2022-06-24 23:01:02.894163
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork('/sbin/ifconfig')
    sun_o_s_network_0.get_interfaces_info(None)
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)


# Generated at 2022-06-24 23:01:11.964569
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    arg_0 = '!&t2SPw=e'
    sun_o_s_network_0.module = arg_0
    arg_0 = 'Hq3*'

# Generated at 2022-06-24 23:01:21.372367
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    str_1 = 'P;Lpf'
    sun_o_s_network_1 = SunOSNetwork(str_1)
    str_2 = 'P;Lpf'
    sun_o_s_network_2 = SunOSNetwork(str_2)
    str_3 = ''
    sun_o_s_network_3 = SunOSNetwork(str_3)
    str_4 = ''
    sun_o_s_network_4 = SunOSNetwork(str_4)
    str_5 = 'R%gFA'
    sun_o_s_network_5 = SunOSNetwork(str_5)

# Generated at 2022-06-24 23:01:24.243234
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:25.798146
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector(0) is not None
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-24 23:01:32.009511
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'B:&'
    sun_os_network_collector_0 = SunOSNetworkCollector(str_0)
    assert((sum(sun_os_network_collector_0._supported_facts['_platform'])) == (12))
    assert(sun_os_network_collector_0._platform == 'SunOS')

if __name__ == "__main__":
    test_SunOSNetworkCollector()
    test_case_0()

# Generated at 2022-06-24 23:01:35.275588
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    cmd = 'ifconfig -a'
    rc, out, err = module.run_command(cmd)
    assert True

# Generated at 2022-06-24 23:01:37.319782
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_case_0()


# Generated at 2022-06-24 23:01:38.843040
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 23:01:49.483178
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'nethost1'
    sun_o_s_network_0 = SunOSNetwork(str_0)

    str_1 = 'asdfg'
    sun_o_s_network_1 = SunOSNetwork(str_1)

    str_2 = 'jkl;'
    sun_o_s_network_2 = SunOSNetwork(str_2)

    str_3 = 'options=23000<LINKSTATE,BRIDGE,VLAN_MTU,JUMBO_MTU,VLAN_HWTAGGING>'
    sun_o_s_network_0.parse_options_line(str_3.split(), sun_o_s_network_0.current_if, sun_o_s_network_0.ips)


# Generated at 2022-06-24 23:01:59.212250
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    print(sun_o_s_network_collector)


# Generated at 2022-06-24 23:02:03.870841
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Unit test for constructor of class SunOSNetworkCollector
    """
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:12.032009
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    get_interfaces_info() method of SunOSNetwork class
    """
    ifconfig_path = '/usr/sbin/ifconfig'

    sun_o_s_network_0 = SunOSNetwork()
    #
    # Stub out the '_network_config' method
    #
    sun_o_s_network_0._network_config = lambda _: ([], [])
    result = sun_o_s_network_0.get_interfaces_info(ifconfig_path)
    assert result == ({}, {'all_ipv6_addresses': [], 'all_ipv4_addresses': []})


# Generated at 2022-06-24 23:02:14.564686
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0 is not None


# Generated at 2022-06-24 23:02:18.268350
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network = SunOSNetwork()
    sun_o_s_network.parse_interface_line(['net0', 'UP,BROADCAST,RUNNING,MULTICAST,IPv4', 'mtu 1500'], {}, {})

# Generated at 2022-06-24 23:02:29.154979
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_os_network_0 = SunOSNetwork(None)
    sun_os_network_0.parse_interface_line(['bge0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500', 'index', '3', 'inet', '171.72.234.9', 'netmask', 'ffffff00', 'broadcast', '171.72.234.255'], {}, {})

# Generated at 2022-06-24 23:02:38.113647
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232', 'index', '4', 'inet', '127.0.0.1', 'netmask', 'ffffff00']
    current_if = {}
    interfaces = {}
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')
    assert sun_o_s_network_0.parse_interface_line(words, current_if, interfaces)['ipv4'][0]['flags'] == '1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>'


# Generated at 2022-06-24 23:02:40.163465
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        assert sun_o_s_network_collector_0.__class__.__name__ == 'SunOSNetworkCollector'
    except AssertionError:
        raise


# Generated at 2022-06-24 23:02:45.622407
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()

    current_if = sun_o_s_network_0.parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1', 'inet', '127.0.0.1', 'netmask', 'ffffff00'], {}, {})

    assert 'ipv6' in current_if
    assert 'ipv4' in current_if
    assert 'inet' in current_if
    assert 'netmask' in current_if
    assert 'macaddress' in current_if


# Generated at 2022-06-24 23:02:48.208889
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork()
    assert collector.fact_class == sun_o_s_network_0.__class__

# Generated at 2022-06-24 23:03:01.232459
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '-Zp{}#f'
    list_0 = ['', '', '', '', '', '', '', '', '', '']
    set_0 = set(list_0)
    str_1 = '-Zp{}#f'
    list_1 = ['', '', '', '', '', '', '', '', '', '']
    set_1 = set(list_1)
    str_2 = '-Zp{}#f'
    list_2 = ['', '', '', '', '', '', '', '', '', '']
    set_2 = set(list_2)
    str_3 = '-Zp{}#f'
    list_3 = ['', '', '', '', '', '', '', '', '', '']

# Generated at 2022-06-24 23:03:09.228553
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    str_0 = ':'
    sun_o_s_network_collector_0 = SunOSNetworkCollector('+;27]O\x1e', '#bo-@!qb4{4+l', set_0, '&A*.W\x0e\x0e', 'H\x1e\x06v')
    sun_o_s_network_collector_0._fact_class = str_0
    sun_o_s_network_collector_0.get_network_facts()


# Generated at 2022-06-24 23:03:17.456367
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    # Test Exception handling
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    # Test for valid inputs
    set_0 = set()
    str_0 = 'l2'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    assert sun_o_s_network_0.get_interfaces_info(set_0) is False
    # Test for valid inputs
    set_0 = set()
    str_0 = 'Z'
    sun

# Generated at 2022-06-24 23:03:19.751282
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork('name')
    assert sun_o_s_network_0.get_interfaces_info() == (None, None)

# Generated at 2022-06-24 23:03:27.524044
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)
    print(var_0)
    # assert var_0 == '', 'Failed to get interfaces for SunOS'


# Generated at 2022-06-24 23:03:34.859473
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)

    current_if = {}
    interfaces = {}
    words = []
    assert sun_o_s_network_0.parse_interface_line(words, current_if, interfaces) == current_if


# Generated at 2022-06-24 23:03:37.055863
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()

#####
# Main program
#####
if __name__ == '__main__':
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:03:43.700481
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create an instance of class SunOSNetwork
    sun_o_s_network_1 = SunOSNetwork()

    # Get the facts of the instance of class SunOSNetwork
    var_3 = sun_o_s_network_1.get_interfaces_info()
    assert var_3 == None

    # Create an instance of class SunOSNetwork
    sun_o_s_network_2 = SunOSNetwork()

    # Create an instance of class set with the given arguments
    set_2 = set()

    # Get the facts of the instance of class SunOSNetwork with the given arguments
    var_6 = sun_o_s_network_2.get_interfaces_info(set_2)
    assert var_6 == None


# Generated at 2022-06-24 23:03:49.339138
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(set_0, str_0)
    sun_o_s_network_collector_0.get_interfaces_info(set_0)

# Generated at 2022-06-24 23:03:57.405714
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup test environment
    ifconfig_path = '/sbin/ifconfig'
    sun_o_s_network_0 = SunOSNetwork('/sbin/ifconfig')
    sun_o_s_network_0.module = MagicMock(return_value='')


# Generated at 2022-06-24 23:04:09.650959
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)


# Generated at 2022-06-24 23:04:15.727223
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert_equal = test_case_0
    set_0 = set()
    assert_equal(SunOSNetworkCollector(set_0)._platform, 'SunOS')
    assert_equal(SunOSNetworkCollector(set_0)._fact_class, SunOSNetwork)


# Generated at 2022-06-24 23:04:23.244245
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)
    assert var_0[0]['hme0']['ipv4'][0]['mtu'] == '1500'
    assert var_0[0]['hme0']['ipv6'][0]['mtu'] == '1500'
    assert var_0[0]['hme0']['ipv6'][0]['prefixlen'] == '64'
    assert var_0[0]['hme0']['ipv4'][0]['prefixlen'] == '24'


# Generated at 2022-06-24 23:04:27.817373
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:04:31.700670
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)

# Generated at 2022-06-24 23:04:34.799760
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_1 = set()
    str_1 = 'lKLz0]VJEHT\t$'
    sun_o_s_network_1 = SunOSNetwork(str_1)
    var_1 = sun_o_s_network_1.get_interfaces_info(set_1)


# Generated at 2022-06-24 23:04:37.225710
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    e = SunOSNetwork('')
    e.get_interfaces_info('')

test_case_0()

# Generated at 2022-06-24 23:04:43.296775
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)

# Generated at 2022-06-24 23:04:47.497270
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)


# Generated at 2022-06-24 23:04:55.120270
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    # Test with default module_utils.network.generic_bsd.ifconfig_path
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

    # Test with specified module_utils.network.generic_bsd.ifconfig_path
    sun_o_s_network_collector_1 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:13.097338
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-24 23:05:19.092607
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    sun_o_s_network_collector_0 = SunOSNetworkCollector(set_0)
    assert sun_o_s_network_collector_0._platform == 'SunOS'


# Generated at 2022-06-24 23:05:23.124793
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0, set_0)
    # Unit test for method get_interfaces_info
    set_0 = set()
    sun_o_s_network_collector_0.get_interfaces_info(set_0)


# Generated at 2022-06-24 23:05:32.578165
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # Create instance of class SunOSNetwork
    str_0 = 's8Z'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    assert isinstance(sun_o_s_network_0, SunOSNetwork)

    # Call method get_interfaces_info of SunOSNetwork with argument set('5#'
    set_0 = set()
    str_0 = '5#'
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:05:38.604386
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    options = 't[2rG*!n'
    fact_class = '\xff??\x00\x00'
    platform = options
    sun_o_s_network_collector = SunOSNetworkCollector(fact_class, platform)
    assert sun_o_s_network_collector.platform == platform


# Generated at 2022-06-24 23:05:43.283626
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)


# Generated at 2022-06-24 23:05:50.112606
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # test_case_5
    set_0 = {'@1m)J`', '`b_3q[l4f\t~?', '*YNY]DK9Sww'}
    str_0 = 'CA:3C:4C:4E:76:10'
    sun_o_s_network_0 = SunOSNetworkCollector(str_0, set_0)


if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:05:51.557255
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    f_0 = SunOSNetworkCollector()
    print(f_0)


# Generated at 2022-06-24 23:05:57.701877
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class._platform == 'SunOS'


# Generated at 2022-06-24 23:06:10.291838
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    with patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.sun_os.SunOSNetwork.get_interfaces_info') as mock_get_interfaces_info:
        mock_get_interfaces_info.return_value = (['<name>', '<device>', '<type>', '<ipv4>', '<ipv6>', '<macaddress>'])
        sun_o_s_network_1 = SunOSNetwork('<path>')
        var_0 = sun_o_s_network_1.get_interfaces_info('<arg>')
        assert var_0 == ['<name>', '<device>', '<type>', '<ipv4>', '<ipv6>', '<macaddress>']
        mock_

# Generated at 2022-06-24 23:06:48.699572
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0 is not None


# Generated at 2022-06-24 23:06:52.161921
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = 'j'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    assert sun_o_s_network_0.get_interfaces_info(set_0) is None



# Generated at 2022-06-24 23:06:57.419207
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)
#


# Generated at 2022-06-24 23:06:58.846154
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'K!TNjv_'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)


# Generated at 2022-06-24 23:07:04.648759
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Create an instance of class SunOSNetworkCollector
    sun_o_s_network = SunOSNetworkCollector()
    # Verify class name
    msg = "Object type is not an instance of SunOSNetworkCollector"
    assert isinstance(sun_o_s_network, SunOSNetworkCollector), msg


# Generated at 2022-06-24 23:07:15.663578
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    set_1 = set()
    str_1 = 'AGF!9\x00\x19'
    sun_o_s_network_1 = SunOSNetwork(str_1)
    var_1 = sun_o_s_network_1.parse_interface_line((':3\x07', '', '', '', '', '', '', '', ''), {'ipv4': [], 'ipv6': [], 'type': 'unknown', 'device': ''}, {})
    sun_o_s_network_1.parse_ether_line(('', '', '', '', '', '', '', '', ''), {'ipv4': [], 'ipv6': [], 'type': 'unknown', 'device': ''}, {})


# Generated at 2022-06-24 23:07:25.819060
# Unit test for constructor of class SunOSNetworkCollector

# Generated at 2022-06-24 23:07:32.030381
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    str_0 = '=U|>g(,`6L-~?iH(Zz'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    var_0 = sun_o_s_network_collector_0.get_interfaces_info(set_0)


# Generated at 2022-06-24 23:07:35.280302
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:07:42.323118
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    sun_o_s_network_0.get_interfaces_info(set_0)


# Generated at 2022-06-24 23:09:39.504341
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    set_0 = set()
    str_0 = 'dvtjw'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    sun_o_s_network_0.parse_interface_line(set_0, str_0, str_0)


# Generated at 2022-06-24 23:09:51.051928
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    set_0 = set()
    sun_o_s_network_collector_0 = SunOSNetworkCollector(set_0)
    var_0 = sun_o_s_network_collector_0._fact_class
    set_1 = set()
    var_1 = sun_o_s_network_collector_0._fact_class.get_interfaces_info(set_1)
    set_2 = set()
    sun_o_s_network_collector_1 = SunOSNetworkCollector(set_2)
    var_2 = sun_o_s_network_collector_1._fact_class
    set_3 = set()
    var_3 = sun_o_s_network_collector_1._fact_class.get_interfaces_info(set_3)


# Generated at 2022-06-24 23:09:59.315386
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_2 = set()
    str_0 = '!-4{sJ-;X/b|<H/0'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_2)
    set_0 = set()

# Generated at 2022-06-24 23:10:02.812212
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

    assert sun_o_s_network_collector_0 is not None


# Generated at 2022-06-24 23:10:10.605519
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    str_0 = "I'm a little string, short and stout"
    sun_o_s_network_0 = SunOSNetwork(str_0)
    set_0 = set()
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)

# Generated at 2022-06-24 23:10:15.018555
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    set_0 = set()
    str_0 = '-[<\tu[8SK!TNjv_'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)


# Generated at 2022-06-24 23:10:23.346996
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # String for testing the output of the function parse_interface_line()
    words = 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2'
    current_if = {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    # Perform parse_interface_line() on the given arguments.
    # Return a dictionary.
    interfaces = SunOSNetwork.parse_interface_line(words, current_if, interfaces)
    # Run assertions on the dictionary returned.
    assert interfaces['bge0']['device'] == 'bge0'
    assert interfaces['bge0']['type'] == 'unknown'

# Generated at 2022-06-24 23:10:33.932082
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:10:40.158024
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ''
    with pytest.raises(AnsibleConnectionFailure) as exc:
        SunOSNetwork(str_0)

    set_0 = set()
    str_0 = '&C\x1a6\x0f\x0e\x1c'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(set_0)


# Generated at 2022-06-24 23:10:41.035319
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()
