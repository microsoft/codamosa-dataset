

# Generated at 2022-06-24 23:00:49.489287
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()



# Generated at 2022-06-24 23:00:50.732335
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 23:00:53.798796
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_interfaces_info_0 = sun_o_s_network_0.get_interfaces_info('/usr/sbin/ifconfig')

# Generated at 2022-06-24 23:00:58.179100
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector
    assert sun_o_s_network_collector._platform == 'SunOS'


# Generated at 2022-06-24 23:01:07.903130
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    cmd = ['ifconfig', '-a']

# Generated at 2022-06-24 23:01:09.895107
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:12.512478
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:17.360015
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    if sun_o_s_network_collector_0:
        assert sun_o_s_network_collector_0.platform == 'SunOS'
        assert sun_o_s_network_collector_0._fact_class == SunOSNetwork
        assert sun_o_s_network_collector_0._platform == 'SunOS'
        assert sun_o_s_network_collector_0.fact_subclasses == []


# Generated at 2022-06-24 23:01:27.593471
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    interfaces, ips = sun_o_s_network_0.get_interfaces_info('../fixtures/files/ifconfig_solaris')
    assert type(interfaces) is dict
    assert type(ips) is dict

# Generated at 2022-06-24 23:01:30.610756
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector = SunOSNetworkCollector()
    result = sun_o_s_network_collector.get_interfaces_info()


# Generated at 2022-06-24 23:01:40.334672
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = 'vxibxvvx'
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-24 23:01:45.352525
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # check type of variable 'sun_o_s_network_collector_0'
    if not isinstance(sun_o_s_network_collector_0, NetworkCollector):
        raise Exception("SunOSNetworkCollector is a subclass of NetworkCollector")


# Generated at 2022-06-24 23:01:47.839228
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    print(sun_o_s_network_collector_0)


# Generated at 2022-06-24 23:01:49.205015
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:01:50.900089
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:01:53.268095
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info(0.25)



# Generated at 2022-06-24 23:02:03.388738
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'PK\x8d#q'
    bool_0 = False
    float_0 = -3311.3674
    sun_o_s_network_0 = SunOSNetwork(float_0)
    var_0 = sun_o_s_network_0.parse_interface_line(sun_o_s_network_collector_0, bytes_0, bool_0)
    assert isinstance(var_0, tuple)
    assert isinstance(var_0[0], str)
    assert isinstance(var_0[1], list)
    assert isinstance(var_0[2], list)
    assert isinstance(var_0[3], list)

# Generated at 2022-06-24 23:02:07.787785
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  sun_o_s_network_collector_0 = SunOSNetworkCollector()
  bytes_0 = b'PK\x8d#q'
  bool_0 = False
  float_0 = -3311.3674
  sun_o_s_network_0 = SunOSNetwork(float_0)
  var_0 = sun_o_s_network_0.parse_interface_line(sun_o_s_network_collector_0, bytes_0, bool_0)
  assert sun_o_s_network_collector_0._fact_class.platform == 'SunOS'


# Generated at 2022-06-24 23:02:11.952331
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'PK\x8d#q'
    bool_0 = False
    float_0 = -3311.3674
    sun_o_s_network_0 = SunOSNetwork(float_0)
    sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)

# Generated at 2022-06-24 23:02:14.078654
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:28.310891
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:02:32.491311
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'd'
    list_0 = [str_0, str_0]
    float_0 = None
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:02:35.132270
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)


# Generated at 2022-06-24 23:02:36.658442
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    test_case_0()

# Generated at 2022-06-24 23:02:38.104345
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()  # instantiate SunOSNetworkCollector

# Generated at 2022-06-24 23:02:40.150719
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # TODO: write testing code for constructor of class SunOSNetworkCollector
    pass

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-24 23:02:43.637376
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # testing the instance created above
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:02:45.158976
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0)

# Generated at 2022-06-24 23:02:47.515891
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'ITl'
    list_0 = [str_0, str_0]
    float_0 = None
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    sun_o_s_network_0.get_interfaces_info(list_0)


# Generated at 2022-06-24 23:02:50.152339
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = False
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0)
    pass


# Generated at 2022-06-24 23:03:03.629471
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(None)
    str_0 = '5%cx=f~M'
    list_0 = [str_0, sun_o_s_network_0, str_0]
    sun_o_s_network_0.get_interfaces_info(list_0)


# Generated at 2022-06-24 23:03:08.639928
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    str_0 = '}>@47'
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:03:18.125842
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    str_0 = '}>@47'
    list_0 = [str_0, sun_o_s_network_collector_0, str_0]
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:03:29.468937
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    str_0 = '}>@47'
    list_0 = [str_0, sun_o_s_network_collector_0, str_0]
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, str_0, list_0)
    var_1 = sun_o_s_network_0.parse_interface_line(str_0, str_0, list_0)
    var_2 = sun_o_s_network_0.parse_interface_line(str_0, str_0, list_0)
    var_3 = sun_

# Generated at 2022-06-24 23:03:32.922141
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-24 23:03:36.366358
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
        sun_o_s_network_collector = SunOSNetworkCollector()


# Generated at 2022-06-24 23:03:39.355299
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork

# Generated at 2022-06-24 23:03:44.138299
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_1 = SunOSNetwork(sun_o_s_network_collector_0)
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    assert sun_o_s_network_0.platform == 'SunOS'
    assert sun_o_s_network_1.platform == 'SunOS'


# Generated at 2022-06-24 23:03:47.712652
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    str_1 = 'X3'
    assert sun_o_s_network_0.get_interfaces_info(str_1) == (sun_o_s_network_collector_0._interfaces, sun_o_s_network_collector_0._ips)

# Generated at 2022-06-24 23:03:53.110825
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork(sun_o_s_network_collector_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:04:18.158750
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'h>@b7f'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    list_0 = [str_0]
    sun_o_s_network_0.parse_interface_line(str_0, str_0, list_0)
    assert sun_o_s_network_0.parse_interface_line(str_0, str_0, list_0) == 'h>@b7f'


# Generated at 2022-06-24 23:04:25.819382
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network_0 = SunOSNetwork('test_value_0')
    str_0 = 'a ~R'
    str_1 = 'ePx'
    list_0 = [str_1]
    if_0 = sunos_network_0.parse_interface_line(str_0, str_1, list_0)
    assert if_0['device'] == 'test_value_0'


# Generated at 2022-06-24 23:04:31.727305
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class.platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class.platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class.platform == 'SunOS'

# Generated at 2022-06-24 23:04:33.292095
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    with pytest.raises(AnsibleDefaultVarsFail):
        sun_o_s_network_0.get_interfaces_info(None)


# Generated at 2022-06-24 23:04:38.039075
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '/sbin/ifconfig -a > /tmp/ansible_ifconfig_out.45325'
    str_1 = '/sbin/ifconfig -a'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_1)
    print(var_0)

# Generated at 2022-06-24 23:04:40.949630
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:04:42.204311
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 23:04:46.869262
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork('o>@b7f')
    str_0 = 'b7f'
    list_0 = [str_0]
    assert sun_o_s_network_0.get_interfaces_info(str_0) == list_0

test_SunOSNetwork_get_interfaces_info()


# Generated at 2022-06-24 23:04:52.520762
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # unit test for payload
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector._fact_class == SunOSNetwork
    assert sun_o_s_network_collector._platform == 'SunOS'

# Generated at 2022-06-24 23:04:53.843559
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:32.943637
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        sun_o_s_network_collector = SunOSNetworkCollector()
    except Exception as e:
        print('Error: ', e)
        assert False
    else:
        assert True


# Generated at 2022-06-24 23:05:37.672680
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(None)
    var_0 = sun_o_s_network_0.get_interfaces_info(None)

test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:05:44.536409
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'z$?d6py'
    str_1 = 'uRxVaN;'
    list_0 = [str_1]
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_1)

# Generated at 2022-06-24 23:05:50.188947
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork('o>@b7f')
    assert sun_o_s_network_0.parse_interface_line('o>@b7f', 'o>@b7f', ['o>@b7f']) == []


# Generated at 2022-06-24 23:05:59.946240
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'o>@b7f'
    str_1 = ':0:f:f:f:f,:0:0:0:'
    list_0 = ['o>@b7f']
    list_1 = ['f']
    list_2 = ['o>@b7f', 'f']
    list_3 = ['f', 'b']
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, str_0, list_0)
    var_1 = sun_o_s_network_0.parse_interface_line(str_0, str_0, list_2)
    var_2 = sun_o_s_network_0.parse_interface_line

# Generated at 2022-06-24 23:06:06.818820
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'q'
    str_1 = 'un'
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)



# Generated at 2022-06-24 23:06:11.922411
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/usr/sbin/ifconfig'
    str_0 = '/usr/sbin/ifconfig -a'
    str_1 = None
    str_2 = None
    sun_o_s_network_0 = SunOSNetwork()
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:06:16.688031
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'o>@b7f'
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(str_0)

    # Call the tested method
    # result = sun_o_s_network_0.get_interfaces_info(str_0)
    # assert_true(result)

# Generated at 2022-06-24 23:06:23.549492
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    assert 'SunOSNetwork' in dir(SunOSNetwork)
    ifconfig_path = 'ifconfig_path'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 23:06:24.585291
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_case_0()

# Generated at 2022-06-24 23:07:06.309105
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '0>@b7f'
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(str_0)
    assert sun_o_s_network_0.get_interfaces_info(str_0) == (list_0, [])


# Generated at 2022-06-24 23:07:10.568846
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'p<'
    list_1 = []
    str_1 = 'b'
    list_2 = [str_0, str_1]
    str_2 = 'b'
    sun_o_s_network_0 = SunOSNetwork(str_1)
    var_0 = sun_o_s_network_0.get_interfaces_info(list_2)


# Generated at 2022-06-24 23:07:11.999008
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()


# Generated at 2022-06-24 23:07:14.213203
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_SunOSNetworkCollector_0()



# Generated at 2022-06-24 23:07:16.225989
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector


# Generated at 2022-06-24 23:07:17.737730
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = '.'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)


# Generated at 2022-06-24 23:07:20.070883
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0, str_0)

# Generated at 2022-06-24 23:07:29.608259
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import StringIO

    str_1 = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    str_2 = '\tinet 127.0.0.1 netmask ff000000'
    str_3 = '\tinet6 ::1/128'
    str_4 = 'bge0: flags=10100a0843<UP,BROADCAST,RUNNING,ALLMULTI,IPv4,CoS,VIRTUAL> mtu 1500 index 2'
    str_5 = '\tether 0:1:2:3:4:5'
    str_6 = '\tinet 10.1.2.3 netmask ffffff00 broadcast 10.1.2.255'
    str_7

# Generated at 2022-06-24 23:07:35.126467
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    var_0 = sun_o_s_network_collector_0.run()
    var_1 = sun_o_s_network_collector_0.run()

# Generated at 2022-06-24 23:07:42.196376
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    result_0 = SunOSNetwork.get_interfaces_info(str_0, str_0)
    print(result_0)
    mem_0 = memoryview(bytes(0))
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes(0))
    print(sun_o_s_network_collector_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(None)
    print(sun_o_s_network_collector_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes.fromhex('0d'))
    print(sun_o_s_network_collector_0)

# Generated at 2022-06-24 23:09:00.788107
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    assert True


# Generated at 2022-06-24 23:09:01.667480
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-24 23:09:04.629343
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_0 = SunOSNetwork('')
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:09:08.751824
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'o>@b7f'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    str_1 = 'ether'
    str_2 = '+2@6%'
    list_0 = [str_1, str_2]
    str_3 = 'ether'
    sun_o_s_network_0.parse_interface_line(str_3, str_3, list_0)


# Generated at 2022-06-24 23:09:09.439991
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 23:09:11.923503
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'X'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)
    assert sun_o_s_network_collector_0._fact_class.platform == 'SunOS'


# Generated at 2022-06-24 23:09:16.568515
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(str())
    str_0 = '<'
    str_1 = '@>8'
    str_2 = 'v'
    list_0 = [str_0, str_1, str_2]
    list_1 = []
    sun_o_s_network_0.get_interfaces_info(str_0)
    print('End of test_SunOSNetwork_get_interfaces_info')


# Generated at 2022-06-24 23:09:27.117388
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = 'o>@b7f'
    str_1 = 'o>@b7f'
    str_2 = 'o>@b7f'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    list_0 = [str_0]
    str_3 = 'o>@b7f'
    str_4 = 'o>@b7f'
    sun_o_s_network_0.parse_interface_line(str_2, str_3, list_0)
    # s_0 == 'o>@b7f'
    # s_1 == 'o>@b7f'
    # s_2 == 'o>@b7f'
    # list_0 == [str_0]
    # s_3 == 'o>@b

# Generated at 2022-06-24 23:09:31.768481
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0.platform == 'SunOS'



# Generated at 2022-06-24 23:09:42.187054
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # 1. Create an instance of SunOSNetwork
    str_0 = ';#6U&)6UQ'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    # 2. Create an instance of module_utils.basic.AnsibleModule
    dict_0 = {}
    dict_0['command'] = '/sbin/ifconfig -a'
    dict_1 = {}
    dict_1['stdout'] = '# -->'
    dict_1['rc'] = 0
    dict_0['changed'] = True
    dict_2 = {}
    dict_2['module_utils.basic.AnsibleModule'] = dict_0
    # 3. Call method get_interfaces_info of SunOSNetwork instance with
    # params args and kwargs to simulate call from AnsibleModule.
   