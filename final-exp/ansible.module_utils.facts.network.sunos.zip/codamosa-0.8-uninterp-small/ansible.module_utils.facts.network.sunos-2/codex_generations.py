

# Generated at 2022-06-24 23:01:05.977392
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork()
    sun_o_s_network.module = MagicMock(return_value=True)
    sun_o_s_network.get_interfaces_info('/sbin/ifconfig')

if __name__ == "__main__":
    test_SunOSNetwork_get_interfaces_info()
    test_case_0()

# Generated at 2022-06-24 23:01:18.517915
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()


# Generated at 2022-06-24 23:01:23.801729
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_os_network = SunOSNetwork({})
    actual_result = sun_os_network.get_interfaces_info()

# Generated at 2022-06-24 23:01:33.800903
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Test parse_interface_line
    """
    sun_o_s_network_0 = SunOSNetwork()

    #
    # Test with invalid data
    #
    sun_o_s_network_0.parse_interface_line([], {}, {})
    #
    # Test with valid data
    #
    sun_o_s_network_0.parse_interface_line(['bge0:'], {}, {})

# Generated at 2022-06-24 23:01:35.974688
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info("/usr/sbin/ifconfig")


# Generated at 2022-06-24 23:01:47.384832
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    words_0 = [u'lo0:', u'flags=2001000849', u'<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', u'mtu', u'8232']
    current_if_0 = {}
    interfaces_0 = {}
    return_value_0 = sun_o_s_network_0.parse_interface_line(words_0, current_if_0, interfaces_0)

# Generated at 2022-06-24 23:01:56.894315
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:01:59.654135
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork()
    assert isinstance(sun_o_s_network.get_interfaces_info('/sbin/ifconfig'), tuple)


# Generated at 2022-06-24 23:02:09.071321
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    argument = {}
    argument['module'] = {}
    argument['module']['run_command'] = {}

# Generated at 2022-06-24 23:02:13.568565
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = '/usr/sbin/ifconfig'
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-24 23:02:26.030564
# Unit test for constructor of class SunOSNetworkCollector

# Generated at 2022-06-24 23:02:34.366449
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s = SunOSNetwork()

    # Unit test for get_interfaces_info with argument ifconfig_path=''
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    rc, out, err = sun_o_s_network_collector_0.module.run_command(['ifconfig', '-a'])
    interfaces, ips = sun_o_s.get_interfaces_info('')
    assert out == err
    assert out == ''
    assert interfaces == {}
    assert ips == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}



# Generated at 2022-06-24 23:02:42.404286
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    SunOSNetwork.get_interfaces_info() Test Plan:

        Create a SunOSNetwork object
        Call get_interfaces_info()
        Compare result with a known result

    """
    sun_o_s_network_obj = SunOSNetwork()

    result = sun_o_s_network_obj.get_interfaces_info(ifconfig_path='/sbin/ifconfig')


# Generated at 2022-06-24 23:02:54.194311
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_os_network = SunOSNetwork({})

# Generated at 2022-06-24 23:03:06.682195
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:03:15.532682
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

    test_cases = {
        'test_case_0': [
            '---',
            'lo0:',
            '    flags = 1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>',
            '    mtu 8232'
        ]
    }

    for test_case in test_cases:
        result = sun_o_s_network_0.get_interfaces_info(test_cases[test_case])

        assert result[0]['lo0']['device'] == 'lo0'

# Generated at 2022-06-24 23:03:20.329557
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0.platform == 'SunOS'



# Generated at 2022-06-24 23:03:25.005668
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector.platform == 'SunOS'


# Generated at 2022-06-24 23:03:26.863268
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_os_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:03:33.212157
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # Tests 'ifconfig' output of SunOS 11.3.
    sun_o_s_network_0 = SunOSNetwork(dict(module=None))

    assert sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig') is not None


# Generated at 2022-06-24 23:03:46.247190
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    sun_o_s_network_0 = SunOSNetwork(module=None, ifconfig_path=ifconfig_path)

    interfaces, ips = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_0.module.boolean(ifconfig_path))
    ipv4_interfaces = []
    ipv6_interfaces = []

    sun_o_s_network_0._get_interfaces_info(interfaces=interfaces, ips=ips, ipv4_interfaces=ipv4_interfaces, ipv6_interfaces=ipv6_interfaces)

# Generated at 2022-06-24 23:03:47.739048
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network_obj = SunOSNetworkCollector().get_network_facts()
    assert sunos_network_obj['default_ipv4']['address']


# Generated at 2022-06-24 23:03:51.420399
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class._platform == 'SunOS'


if __name__ == '__main__':
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:03:54.437099
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._platform == 'SunOS'

# Generated at 2022-06-24 23:03:54.861988
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    case_0()

# Generated at 2022-06-24 23:04:03.627318
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    arg_0_0 = '/sbin/ifconfig'
    arg_0_1 = sun_o_s_network_0.get_interfaces_info(arg_0_0)
    assert arg_0_1[0] == {}, """Retval[0] should be {}, but is {}""".format(arg_0_1[0], {})

# Generated at 2022-06-24 23:04:14.268640
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork()

# Generated at 2022-06-24 23:04:16.471020
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info(ifconfig_path='/sbin/ifconfig')

# Generated at 2022-06-24 23:04:17.914916
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print('Testing class SunOSNetworkCollector')
    test_case_0()

if __name__ == '__main__':
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:04:22.001610
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_0._platform = 'SunOS'
    sun_o_s_network_collector_0._fact_class = SunOSNetwork


# Generated at 2022-06-24 23:04:39.533479
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 23:04:42.608736
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()
    if True:
        assert True
    else:
        assert False


# Generated at 2022-06-24 23:04:45.789513
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert test_case_0.__name__ == 'test_case_0'



# Generated at 2022-06-24 23:04:49.446178
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:04:56.482433
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup data
    sun_o_s_network_collector = SunOSNetworkCollector()
    sun_o_s_network_collector.module.run_command = mock_run_command()

    # Run method under test
    result = sun_o_s_network_collector.get_interfaces_info("")

    assert_equals(1, len(result))
    assert_in('lo0', result[0])
    assert_in('enp0s3', result[0])
    assert_equals(['up', 'flags=849<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu: 8232'], result[0]['lo0']['ipv4'][0].values())

# Generated at 2022-06-24 23:04:58.891544
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:05.952051
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0.platform == 'SunOS'
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    assert sun_o_s_network_collector_0.fact_class is not None
    assert sun_o_s_network_collector_0.fact_class == SunOSNetwork
    assert sun_o_s_network_collector_0._fact_class is not None
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:05:14.612610
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.module.run_command = run_command
    sun_o_s_network_0.interfaces_info, sun_o_s_network_0.ips = sun_o_s_network_0.get_interfaces_info('ifconfig_path')

    assert sun_o_s_network_0.interfaces_info['lo0']['ipv4'][0]['mtu'] == '8232'
    assert sun_o_s_network_0.interfaces_info['lo0']['ipv6'][0]['mtu'] == '8252'

# Generated at 2022-06-24 23:05:23.998687
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-24 23:05:27.484638
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_1 = SunOSNetworkCollector(platform='SunOS')

test_case_0()
test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:05:46.577340
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    print("Test case: [None, None, None]")
    sun_o_s_network_0 = SunOSNetwork(True)
    var_0 = sun_o_s_network_0.get_interfaces_info("1Fl\x7f\x03\x0f\x01\x14\x12")


# Generated at 2022-06-24 23:05:50.414113
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector(SunOSNetwork)
    print(sun_o_s_network_collector_0)



# Generated at 2022-06-24 23:05:55.080903
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    list_0 = []
    sun_o_s_network_0 = SunOSNetwork(list_0)
    sun_o_s_network_0.get_interfaces_info(list_0)


# Generated at 2022-06-24 23:05:55.784434
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_case_0()



# Generated at 2022-06-24 23:05:59.119133
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    str_0 = 'curl'
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:06:11.532178
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)

    sun_o_s_network_1 = SunOSNetwork(bool_0)
    str_0 = '\n        Gets a list of available versions for a collection on a Galaxy server.\n\n        :param namespace: The collection namespace.\n        :param name: The collection name.\n        :return: A list of versions that are available.\n        '
    bool_0 = True
    list_0 = [str_0]
    sun_o_s_network_2 = SunOSNetwork(bool_0)

# Generated at 2022-06-24 23:06:17.239712
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector(_platform='_platform_0')
    sun_o_s_network_collector_0._platform
    assert sun_o_s_network_collector_0._platform == '_platform_0'
    sun_o_s_network_collector_0._fact_class
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:06:21.854129
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0)



# Generated at 2022-06-24 23:06:28.889373
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '\n        Gets a list of available versions for a collection on a Galaxy server.\n\n        :param namespace: The collection namespace.\n        :param name: The collection name.\n        :return: A list of versions that are available.\n        '
    bool_0 = True
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:06:31.725535
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunosnetwork_collector_0 = SunOSNetworkCollector(class_0)
    sunosnetwork_collector_0.get_device_info()


# Generated at 2022-06-24 23:07:04.893848
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Testing constructor: sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    if True:
        print('TestCase:')
        print('    Test the constructor')
        sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:07:16.415538
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = '\n        Gets a list of available versions for a collection on a Galaxy server.\n\n        :param namespace: The collection namespace.\n        :param name: The collection name.\n        :return: A list of versions that are available.\n        '
    bool_0 = True
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(sun_o_s_network_0, bool_0)
    sun_o_s_network_collector_0._get_facts()
    sun_o_s_network_collector_0._platform
    sun_o_s_network_collector_0._fact_class
    sun_o_s_

# Generated at 2022-06-24 23:07:19.330532
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    var_0 = sun_o_s_network_0.get_interfaces_info()

# Generated at 2022-06-24 23:07:22.394525
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = True
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(bool_0)
    assert var_0[0] == True
    assert var_0[1] == False


# Generated at 2022-06-24 23:07:32.069025
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = '\n        Gets a list of available versions for a collection on a Galaxy server.\n\n        :param namespace: The collection namespace.\n        :param name: The collection name.\n        :return: A list of versions that are available.\n        '
    bool_0 = True
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(bool_0)
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, bool_0, list_0)
    if var_0 != None:
        print('Failure in test_SunOSNetwork_parse_interface_line')
        print(var_0)


# Generated at 2022-06-24 23:07:39.203243
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup
    str_0 = '\n        Gets a list of available versions for a collection on a Galaxy server.\n\n        :param namespace: The collection namespace.\n        :param name: The collection name.\n        :return: A list of versions that are available.\n        '
    bool_0 = True
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(bool_0)

    # Invocation
    ret = sun_o_s_network_0.get_interfaces_info(str_0)

    # Assertion
    assert isinstance(ret, tuple)
    assert bool_0
    assert list_0


# Generated at 2022-06-24 23:07:44.835426
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Initialize
    bool_0 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0)
    # Verify
    assert sun_o_s_network_collector_0.fact_class.platform == 'SunOS'


# Generated at 2022-06-24 23:07:46.875026
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector.get_collector_platforms() == ['SunOS']


# Generated at 2022-06-24 23:07:51.056861
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    pass

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:07:53.584615
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0.platform == 'SunOS'

# Generated at 2022-06-24 23:09:04.557522
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    var_0 = sun_o_s_network_collector_0.collect()
    var_0 = sun_o_s_network_collector_0.__doc__
    var_0 = sun_o_s_network_collector_0.__init__()

# Generated at 2022-06-24 23:09:07.759750
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = 'w(uu'
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(list_0)
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, list_0, list_0)


# Generated at 2022-06-24 23:09:09.284520
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    result = SunOSNetwork.get_interfaces_info(str)
    assert result is not False


# Generated at 2022-06-24 23:09:14.259433
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    print(' ')
    print('Test for method parse_interface_line of class SunOSNetwork')
    str_0 = 'w(uu'
    list_0 = [str_0]
    sun_o_s_network_0 = SunOSNetwork(list_0)
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, list_0, list_0)



# Generated at 2022-06-24 23:09:19.621948
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '8: w(uu'
    str_1 = 'lo0:8: w(uu'
    sun_o_s_network_0 = SunOSNetwork([str_1])
    # AssertionError: Expected type <str>, got <dict> : 'lo0:8: w(uu'
    # assert sun_o_s_network_0.get_interfaces_info(str_1, [str_0, str_0]) == [], 'Expected type <str>, got <dict> : 'lo0:8: w(uu''


# Generated at 2022-06-24 23:09:21.270761
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    var_0 = sun_o_s_network_collector_0.collect()


# Generated at 2022-06-24 23:09:29.546069
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork(['n'])
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    str_0 = '~R-'
    str_1 = '!M2'
    str_2 = '+jY'
    str_3 = 'FC'
    str_4 = 'Uw'
    str_5 = 'y&'
    str_6 = 'xJ*'
    str

# Generated at 2022-06-24 23:09:31.189522
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_class = "SunOSNetwork"
    platform = "SunOS"
    sun_o_s_network_collector_0 = SunOSNetworkCollector("fact_class", "platform")


# Generated at 2022-06-24 23:09:36.458419
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector._fact_class == SunOSNetwork
    assert sun_o_s_network_collector._platform == 'SunOS'


# Generated at 2022-06-24 23:09:44.413183
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '3v4'
    list_0 = [str_0]
    str_1 = 'Gm'
    list_1 = [str_1, str_1, str_1]
    sun_o_s_network_0 = SunOSNetwork(list_1)
    sun_o_s_network_1 = SunOSNetwork(list_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_1)
    # AssertionError: assert not isinstance(list_0, dict)
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)
    # AssertionError: assert not isinstance(list_0, dict)
    str_2 = 'T'