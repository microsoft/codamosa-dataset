

# Generated at 2022-06-24 23:00:53.738172
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    dict_0 = {}
    sun_o_s_network_0 = SunOSNetwork(dict_0)
    ifconfig_path = 'not-a-real-path'
    sun_o_s_network_0.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-24 23:01:04.128186
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Expected return values, these can be anything, this is a dummy test
    expected_interfaces = {'lo0': {'type': 'loopback', 'macaddress': 'fe:fd:00:00:00:00', 'ipv4': [{'mtu': 8232, 'flags': ['UP', 'RUNNING', 'LOOPBACK', 'MULTICAST']}], 'ipv6': [{'mtu': 8252, 'flags': ['UP', 'RUNNING', 'LOOPBACK', 'IPv6', 'MULTICAST']}], 'device': 'lo0'}}
    expected_ips = {'all_ipv6_addresses': [], 'all_ipv4_addresses': []}
    # Get an instance of SunOSNetwork
    sun_o_s_network_0 = SunOSNetwork

# Generated at 2022-06-24 23:01:09.821477
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    dict_0 = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector(dict_0)
    sun_o_s_network_0 = SunOSNetwork(dict_0)
    assert sun_o_s_network_0.get_interfaces_info("/sbin/ifconfig") == \
        sun_o_s_network_collector_0._fact_class(dict_0).get_interfaces_info("/sbin/ifconfig")

# Generated at 2022-06-24 23:01:10.758176
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 23:01:14.218534
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork({})
    assert sun_o_s_network_0.get_interfaces_info({})


# Generated at 2022-06-24 23:01:16.635432
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    dict_0 = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector(dict_0)

# Generated at 2022-06-24 23:01:20.288360
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    dict_0 = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector(dict_0)
    assert type(sun_o_s_network_collector_0).__name__ == 'SunOSNetworkCollector'


# Generated at 2022-06-24 23:01:21.944582
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(dict({}))
    sun_o_s_network_0.get_interfaces_info('test_value_3')


# Generated at 2022-06-24 23:01:22.557931
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert False


# Generated at 2022-06-24 23:01:28.077086
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork({})
    words_0 = ['en0:', 'flags=8863&lt;UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST&gt', 'mtu', '1500']
    current_if_0 = {}
    interfaces_0 = {}
    sun_o_s_network_0.parse_interface_line(words_0, current_if_0, interfaces_0)


# Generated at 2022-06-24 23:01:36.701737
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
   sun_o_s_network_collector_0 = SunOSNetworkCollector()

test_case_0()
test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:01:40.219132
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_os_network_collector_obj = SunOSNetworkCollector()
    assert isinstance(sun_os_network_collector_obj, NetworkCollector) is True


# Generated at 2022-06-24 23:01:46.382145
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '~mtu'
    str_1 = [str_0, str_0, str_0, str_0]
    var_1 = sun_o_s_network_0.parse_interface_line(str_1, str_1, var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:01:55.959699
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_2 = {}
    sun_o_s_network_1 = SunOSNetwork(var_2)
    str_2 = '/sbin/ifconfig'
    var_3 = sun_o_s_network_1.get_interfaces_info(str_2)
    assert var_3[0]['lo0']['ipv4'] == [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '32768', 'inet': [{'netmask': 'ffffff00', 'address': '127.0.0.1'}]}],\
        ('test_case_1 failed: test_SunOSNetwork_get_interfaces_info')

# Generated at 2022-06-24 23:02:00.935703
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork
    assert sun_o_s_network_collector_0._platform == SunOSNetwork._platform


# Generated at 2022-06-24 23:02:05.452490
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    str_0 = '/sbin/ifconfig -a'
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:02:11.977731
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_2 = {}
    sun_o_s_network_1 = SunOSNetwork(var_2)
    str_2 = '/sbin/ifconfig'
    var_3 = sun_o_s_network_1.get_interfaces_info(str_2)

test_SunOSNetwork_get_interfaces_info()
test_case_0()

# Generated at 2022-06-24 23:02:13.609350
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    str_0 = 'ifconfig'
    sun_o_s_network_0 = SunOSNetwork(var_0)
    var_1, var_2 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:02:16.611226
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_0 = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector(var_0)


# Generated at 2022-06-24 23:02:17.599638
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:30.967718
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_2 = {}
    str_1 = 'ifconfig'
    var_3 = SunOSNetwork(var_2)
    str_2 = 'ifconfig'
    var_4, var_5 = var_3.get_interfaces_info(str_2)
    assert var_4 == var_4
    assert var_5 == var_5


# Generated at 2022-06-24 23:02:32.795168
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector().fact_class == SunOSNetwork

# Generated at 2022-06-24 23:02:36.933928
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_0 = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector(var_0)
    # var_1 = sun_o_s_network_collector_0.get_all_network_interfaces()
    # var_2 = sun_o_s_network_collector_0.get_network_resources()


# Generated at 2022-06-24 23:02:40.539416
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    var_1 = [str_0, str_0, str_0]
    var_2 = {}
    assert isinstance(sun_o_s_network_0.get_interfaces_info(var_1), list)


# Generated at 2022-06-24 23:02:43.713694
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_0 = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector(var_0)
    str_0 = '~mt'
    var_1 = sun_o_s_network_collector_0.choose_facts(str_0, str_0, str_0)

# Generated at 2022-06-24 23:02:47.145710
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_2 = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector(var_2)
    pass


# Generated at 2022-06-24 23:02:56.263048
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '~mt'
    dic_0 = sun_o_s_network_0.parse_interface_line(str_0, str_0, var_0)

    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '~mt'
    str_1 = 'e1000g0'
    dic_0 = sun_o_s_network_0.parse_interface_line(str_0, str_1, var_0)

    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '~mt'

# Generated at 2022-06-24 23:02:59.405564
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    return sun_o_s_network_collector_0


# Generated at 2022-06-24 23:03:04.189086
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '~mt'
    assert sun_o_s_network_0.get_interfaces_info(str_0) == (var_0, var_0)


# Generated at 2022-06-24 23:03:07.242752
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_0 = SunOSNetworkCollector()

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:03:37.117861
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '~mt'
    rc, out, err = sun_o_s_network_0.module.run_command([str_0, '-a'])
    for str_1 in out.splitlines():
        if str_1:
            words = str_1.split()
            if re.match(r'^\S', str_1) and len(words) > 3:
                current_if = sun_o_s_network_0.parse_interface_line(words, str_0, var_0)
                var_0[current_if['device']] = current_if

# Generated at 2022-06-24 23:03:40.535899
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var__0 = {}
    sun_o_s_network_0 = SunOSNetwork(var__0)
    var_0 = '~mt'
    sun_o_s_network_0.parse_interface_line(var_0, var_0, var__0)

if __name__ == "__main__":
    test_SunOSNetwork_get_interfaces_info()
    test_case_0()

# Generated at 2022-06-24 23:03:44.375915
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '~mt'
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)
    assert var_1 == (var_0, var_0)


# Generated at 2022-06-24 23:03:49.811824
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print(SunOSNetworkCollector())


# Generated at 2022-06-24 23:03:52.217306
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:03:56.844302
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_2 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:04:02.940275
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '~mt'
    # from method parse_interface_line of class SunOSNetwork
    var_1 = sun_o_s_network_0.parse_interface_line(str_0, str_0, var_0)
    # from method parse_interface_line of class SunOSNetwork
    var_1 = sun_o_s_network_0.parse_interface_line(str_0, str_0, var_0)


# Generated at 2022-06-24 23:04:08.417921
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = '~mt'
    var_1 = {}
    sun_o_s_network_0 = SunOSNetwork(var_1)
    sun_o_s_network_0.get_interfaces_info(var_0)


# Generated at 2022-06-24 23:04:10.046922
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()

test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:04:13.823435
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    import re


# Generated at 2022-06-24 23:05:00.617290
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    test_0 = getattr(sun_o_s_network_collector_0, '_fact_class')
    assert test_0 == SunOSNetwork, "incorrect value for _fact_class"
    test_1 = getattr(sun_o_s_network_collector_0, '_platform')
    assert test_1 == 'SunOS', "incorrect value for _platform"

# Generated at 2022-06-24 23:05:05.597606
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:05:08.181077
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_0 = SunOSNetworkCollector()
    print(var_0)

# Generated at 2022-06-24 23:05:13.072739
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '/usr/sbin/ifconfig'
    str_1 = sun_o_s_network_0.get_interfaces_info(str_0)
    assert str_1 == var_0


# Generated at 2022-06-24 23:05:18.304223
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_networkcollector_0 = SunOSNetworkCollector()
    sun_o_s_networkcollector_0.collect()

# Generated at 2022-06-24 23:05:26.457326
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Set up mock
    SunOSNetworkCollector.platform = 'SunOS'
    SunOSNetworkCollector.platform_version = '11.4'

    m_run_command = SunOSNetworkCollector.module.run_command = MagicMock(return_value=(0, '', ''))
    m_distutils_version_string_to_tuple = SunOSNetworkCollector.distutils.version.LooseVersion.version = MagicMock(return_value='11.4')

    sun_o_s_network_0 = SunOSNetwork(SunOSNetworkCollector.module)

    # Invoke method
    sun_o_s_network_0.get_interfaces_info(None)

    # Check if mock was called
    m_run_command.assert_called_once()
    m_distutils_version_string_

# Generated at 2022-06-24 23:05:33.385130
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_1 = SunOSNetworkCollector(str_0)
    var_0 = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector(var_0)


# Generated at 2022-06-24 23:05:37.322714
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    return sun_o_s_network_collector_0


# Generated at 2022-06-24 23:05:44.410151
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '~'
    result = sun_o_s_network_0.get_interfaces_info(str_0)
    assert result[0] == result[1]
    assert result[0] == result[0]


# Generated at 2022-06-24 23:05:51.976963
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    str_0 = '~gf'
    var_0 = sun_o_s_network_collector_0.get_device_name(str_0)
    str_1 = '~qh'
    var_1 = sun_o_s_network_collector_0.get_device_name(str_1)


if __name__ == '__main__':
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:07:17.896391
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    var_1 = sun_o_s_network_0._options = {}
    str_0 = '~b\x00\x01'
    str_1 = '~b\x00\x01'
    var_1['gather_timeout'] = str_0
    var_1['command_timeout'] = str_1

    var_2 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:07:22.136193
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork({})
    str_0 = '~mt'
    str_1 = '~mt'
    var_0 = sun_o_s_network_0.parse_interface_line(str_0, str_1, str_0)

test_SunOSNetwork_get_interfaces_info()
test_case_0()

# Generated at 2022-06-24 23:07:28.729183
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    # Create an instance of SunOSNetworkCollector
    # Test the instance created by SunOSNetworkCollector()
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)


# Generated at 2022-06-24 23:07:34.867237
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    var_0 = {}
    sun_o_s_network_collector_0 = SunOSNetworkCollector(var_0)
    print(sun_o_s_network_collector_0.platform)


# Generated at 2022-06-24 23:07:37.969869
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = 'SUN'
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 23:07:44.175029
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-24 23:07:50.950892
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    var_1 = '~/:z'
    var_2 = sun_o_s_network_0.get_interfaces_info(var_1)
    # assert var_2 == (var_0, var_0)


# Generated at 2022-06-24 23:07:54.267064
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_2 = {}
    sun_o_s_network_1 = SunOSNetwork(var_2)
    var_3 = sun_o_s_network_1.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:07:57.905232
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    var_0 = {}
    sun_o_s_network_0 = SunOSNetwork(var_0)
    str_0 = '~mt'
    var_1 = sun_o_s_network_0.get_interfaces_info(str_0)
    assert var_1 is not None


# Generated at 2022-06-24 23:08:02.259123
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    print('SunOSNetworkCollector(): ' + str(sun_o_s_network_collector_0))
    assert str(sun_o_s_network_collector_0) == '<ansible.module_utils.facts.network.sunos.SunOSNetworkCollector>'
