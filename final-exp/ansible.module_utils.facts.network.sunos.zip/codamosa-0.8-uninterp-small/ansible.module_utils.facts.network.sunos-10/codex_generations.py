

# Generated at 2022-06-24 23:00:54.757026
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-24 23:00:55.681652
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    pass


# Generated at 2022-06-24 23:00:59.446796
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0 is not None


# Generated at 2022-06-24 23:01:01.400554
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_os_network_obj_0 = SunOSNetwork()
    sun_os_network_obj_0.get_interfaces_info()

if '__main__' == __name__:
    test_case_0()

    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:01:04.623346
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector._platform == 'SunOS'
    assert sun_o_s_network_collector._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:01:10.943112
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork()
    words = 'e1000g0'.split()
    current_if = {}
    interfaces = {}
    sun_o_s_network_0.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': 'e1000g0', 'ipv4': {}, 'ipv6': {}, 'type': 'unknown'}
    assert interfaces == {'e1000g0': {'type': 'unknown', 'ipv4': {}, 'ipv6': {}}}


# Generated at 2022-06-24 23:01:12.770862
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert True == True


# Generated at 2022-06-24 23:01:16.234048
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    print(sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig'))


# Generated at 2022-06-24 23:01:16.872054
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 23:01:17.502504
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 23:01:22.546041
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert True


# Generated at 2022-06-24 23:01:29.135007
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)

# Generated at 2022-06-24 23:01:37.772412
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_1 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)
    assert type(var_1) == tuple



# Generated at 2022-06-24 23:01:48.917683
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)
    assert var_0[0]['lo0']['ipv4'][0]['inet'] == '127.0.0.1'

# Generated at 2022-06-24 23:01:56.279960
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    assert isinstance(sun_o_s_network_0, SunOSNetwork)
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)
    assert isinstance(var_0, tuple)

# Generated at 2022-06-24 23:02:02.538018
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)
    assert isinstance(var_0, tuple) is True

# Generated at 2022-06-24 23:02:13.411167
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test set up
    tuple_0 = ()
    bytes_0 = b'\x02\x93\x10\x04\x06\x9f\xb5R|\xb4\x8f\xab\x01\xdbz\x83\xfe\x1b\xa6'
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    sun_o_s_network_0_copy_0 = dict(sun_o_s_network_0)
    words_0 = ['bitbucket0:', 'flags=1000843', 'mtu=1500']
    current_if_0 = {}
    interfaces_0 = {}

    # Invoking method

# Generated at 2022-06-24 23:02:20.590223
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)


# Generated at 2022-06-24 23:02:22.069304
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  sun_o_s_network_collector = SunOSNetworkCollector()
  assert isinstance(sun_o_s_network_collector, NetworkCollector)


# Generated at 2022-06-24 23:02:33.042412
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)
    # Output of method get_interfaces_info should be of type <class 'tuple'>
    assert type(var_0) is tuple


# Generated at 2022-06-24 23:02:45.060899
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_1 = b'\xec\'\x01\xef\xfe\xaf\xf4\xdf\x1a(\xe9\x9d]\x1d'
    tuple_1 = ()
    sun_o_s_network_1 = SunOSNetwork(bytes_1, tuple_1)
    sun_o_s_network_collector_1 = SunOSNetworkCollector(sun_o_s_network_1)
    sun_o_s_network_collector_1.get_facts()


# Generated at 2022-06-24 23:02:51.614921
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    sun_o_s_network_0.module = MagicMock()
    ifconfig_path = 'ifconfig'
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'en0': {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
   

# Generated at 2022-06-24 23:03:00.520036
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  sun_o_s_network_collector_0 = SunOSNetworkCollector()
  assert sun_o_s_network_collector_0._fact_class == SunOSNetwork
  assert sun_o_s_network_collector_0._platform == 'SunOS'
  assert sun_o_s_network_collector_0.FACT_SUBSETS == {'all', 'min', 'interfaces', 'interfaces_ipv4', 'interfaces_ipv6', 'ipv4', 'ipv6', 'netmask', 'broadcast', 'network'}


# Generated at 2022-06-24 23:03:10.011273
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xea\x94\xbd\xc3>\xda\xcc\xe3\xfb\x93\xee\x9f\x9e7\xf3\xea\xb2\x01\r\x06'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.list_active_interfaces(sun_o_s_network_collector_0)
    assert type(var_0) == set


# Generated at 2022-06-24 23:03:20.701860
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ifconfig_path_0 = b'/sbin/ifconfig'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(ifconfig_path_0)
    bytes_0 = b'm\x89!\xbb\xd1\xf8\x0fw\xc7F\xfc\x97\x8c\x81'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = list(sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0))

# Generated at 2022-06-24 23:03:30.369743
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 23:03:38.518218
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xee\x08\x0e\x9a\x94\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    sun_o_s_network_collector_0.get_interfaces_info()
    sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)


# Generated at 2022-06-24 23:03:39.684814
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Write your test here!
    assert True


# Generated at 2022-06-24 23:03:46.438133
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)

# Generated at 2022-06-24 23:03:54.181486
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)
    var_1 = sun_o_s_network_0.platform
    if str(var_1) == 'SunOS':
        var_2 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)


# Generated at 2022-06-24 23:04:17.922020
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector = SunOSNetworkCollector()
    bytes = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple = ()
    sun_o_s_network = SunOSNetwork(bytes, tuple)
    var = sun_o_s_network.get_interfaces_info(sun_o_s_network_collector)


# Generated at 2022-06-24 23:04:24.058345
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    tuple_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)



# Generated at 2022-06-24 23:04:29.436016
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)

# Generated at 2022-06-24 23:04:39.597974
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)
    sun_o_s_network_1 = SunOSNetwork(bytes_0, tuple_0)
    current_if_0 = sun_o_s_network_1.get_interfaces_info(sun_o_s_network_collector_0)
    current_if_1 = sun_

# Generated at 2022-06-24 23:04:48.685558
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    str_0 = 'hdhjfh'
    list_0 = []
    dict_0 = {}
    sun_o_s_network_0.parse_interface_line(str_0, list_0, dict_0)


# Generated at 2022-06-24 23:04:52.680554
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    assert True, "Test if the method get_interfaces_info of the SunOSNetwork class works."


# Generated at 2022-06-24 23:04:55.151750
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  sun_o_s_network_collector_0 = SunOSNetworkCollector()
  assert sun_o_s_network_collector_0._platform == 'SunOS'


# Generated at 2022-06-24 23:04:58.296304
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)


# Generated at 2022-06-24 23:05:06.773558
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    bytes_1 = b't\x15\xf4\x9d\x93\x15\x0e\xc3\x86\x1e\xd1'
    tuple_1 = ()
    sun_o_s_network_1 = SunOSNetwork(bytes_1, tuple_1)

# Generated at 2022-06-24 23:05:15.462686
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)


# Generated at 2022-06-24 23:05:53.509423
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    if __name__ == '__main__':
        sun_o_s_network_collector_0 = SunOSNetworkCollector()
        bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
        tuple_0 = ()
        sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
        var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)


# Generated at 2022-06-24 23:06:00.332195
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ip_link_path = '/sbin/ifconfig'
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(ip_link_path)

# Generated at 2022-06-24 23:06:05.704798
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test exception raised when creating SunOSNetworkCollector with no argument
    with pytest.raises(TypeError):
        sun_o_s_network_collector = SunOSNetworkCollector()


# Generated at 2022-06-24 23:06:08.317150
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()
    assert(sun_o_s_network_collector_1 is not None)



# Generated at 2022-06-24 23:06:12.652091
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)
    # assert the instance's type of sun_o_s_network_collector_0 is SunOSNetworkCollector


# Generated at 2022-06-24 23:06:14.347016
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:06:21.887468
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:06:26.688987
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:06:28.152804
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:06:30.059224
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.sys_path == "/usr/bin"


# Generated at 2022-06-24 23:07:33.550564
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0) == None


# Generated at 2022-06-24 23:07:41.389455
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Unit test for method parse_interface_line of class SunOSNetwork
    """
    # get instance of class
    sun_o_s_network_0 = SunOSNetwork()
    # parse line

# Generated at 2022-06-24 23:07:46.983439
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  """
  # To generate key (use in generator):
  p.DH_generate_key()
  # To export key:
  p.exportKey()
  # To import key:
  p.importKey()
  """

# Generated at 2022-06-24 23:07:58.248022
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    words_0 = ['?kfj0h3q55uy0', 'UP', 'RUNNING', 'MULTICAST', 'MTU:1300']
    current_if_0 = {}
    interfaces_0 = {}
    sun_o_s_network_0.parse_interface_line(words_0, current_if_0, interfaces_0)
    assert sun_o_s_network_0.parse_interface

# Generated at 2022-06-24 23:08:04.828361
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)


# Generated at 2022-06-24 23:08:10.167341
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    _fact_class = SunOSNetwork
    _platform = 'SunOS'
    sun_o_s_network_collector = SunOSNetworkCollector(_fact_class, _platform)
    assert type(sun_o_s_network_collector._fact_class) == type(_fact_class)
    assert type(sun_o_s_network_collector._platform) == type(_platform)


# Generated at 2022-06-24 23:08:17.000534
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bytes_0 = b'\x84\x9b\x9d\xba\x8dr\x89\xa4\x82\x95\x15\x83'
    tuple_0 = ()
    words_0 = ('w', '', '', '', '', '', '', '')
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    current_if = {}
    interfaces = {}
    sun_o_s_network_0.parse_interface_line(words_0, current_if, interfaces)


# Generated at 2022-06-24 23:08:21.430120
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    with pytest.raises(TypeError):
        sun_o_s_network_collector_0 = SunOSNetworkCollector(1)


# Generated at 2022-06-24 23:08:29.176757
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    var_0 = sun_o_s_network_0.get_interfaces_info(sun_o_s_network_collector_0)

if(__name__ == '__main__'):
    test_case_0()
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:08:38.842523
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bytes_0 = b'\xbf\x0e\xc9w6\xf5\x9b2G\xe4\x8e\x14\xe4u'
    tuple_0 = ()
    sun_o_s_network_0 = SunOSNetwork(bytes_0, tuple_0)
    words_0 = ['lo0:', 'flags=80049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '8232', 'index', '11']
    sun_o_s_network_0.parse_interface_line(words_0, sun_o_s_network_0)
    # Verify