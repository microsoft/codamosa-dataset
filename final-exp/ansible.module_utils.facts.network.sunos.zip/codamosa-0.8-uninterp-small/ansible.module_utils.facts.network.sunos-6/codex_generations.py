

# Generated at 2022-06-24 23:00:57.920457
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xaaMw\x07\x99\xbd)\x9d\xbe\x00'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)
    print(sun_o_s_network_0.get_interfaces_info())


# Generated at 2022-06-24 23:01:07.883320
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xaaMw\x07\x99\xbd)\x9d\xbe\x00'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)
    bytes_1 = b'\xf2\x80\x9a\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    sun_o_s_network_collector_1 = SunOSNetworkCollector(bytes_1)


# Generated at 2022-06-24 23:01:13.028641
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xaaMw\x07\x99\xbd)\x9d\xbe\x00'
    network_collector_0 = SunOSNetworkCollector(bytes_0)
    result_0 = network_collector_0.get_interfaces_info(b'ifconfig')


# Generated at 2022-06-24 23:01:18.960122
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b'\xaaMw\x07\x99\xbd)\x9d\xbe\x00'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)
    assert (type(sun_o_s_network_collector_0)) is SunOSNetworkCollector

# Test for method 'collect()' of class 'SunOSNetworkCollector'

# Generated at 2022-06-24 23:01:22.230505
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  bytes_0 = b'\xaaMw\x07\x99\xbd)\x9d\xbe\x00'
  sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)

# Generated at 2022-06-24 23:01:30.620823
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bytes_0 = b'\xaaMw\x07\x99\xbd)\x9d\xbe\x00'
    sun_o_s_network_0 = SunOSNetwork(bytes_0)

    # Supported values: 'path'
    # Default value: None
    value_0 = 'path'
    ifconfig_path_0 = sun_o_s_network_0.get_interfaces_info( ifconfig_path=value_0)
    print(ifconfig_path_0)

if __name__ == '__main__':
    test_SunOSNetwork_get_interfaces_info()
    test_case_0()

# Generated at 2022-06-24 23:01:35.089866
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces, ips = SunOSNetwork().get_interfaces_info('/sbin/ifconfig')
    assert len(interfaces) > 0
    assert len(ips['all_ipv4_addresses']) > 0


# Generated at 2022-06-24 23:01:46.387668
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {'device': 'lo0', 'ipv6': [], 'type': 'unknown', 'ipv4': [], 'macaddress': 'unknown'}
    interfaces = {'lo0': {'device': 'lo0', 'ipv6': [], 'type': 'unknown', 'ipv4': [], 'macaddress': 'unknown'}}
    sun_o_s_network_0 = SunOSNetwork()
    words = ['lo0: ', 'flags=2001000849 <UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    sun_o_s_network_0.parse_interface_line(words, current_if, interfaces)



# Generated at 2022-06-24 23:01:52.030040
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bytes_0 = b'\xaaMw\x07\x99\xbd)\x9d\xbe\x00'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork


# Generated at 2022-06-24 23:01:56.554581
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bytes_0 = b'\xaaMw\x07\x99\xbd)\x9d\xbe\x00'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_SunOSNetwork_parse_interface_line()

# Generated at 2022-06-24 23:02:04.691549
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector = SunOSNetworkCollector()
    sun_o_s_network = SunOSNetwork(sun_o_s_network_collector.module)

# Generated at 2022-06-24 23:02:13.716702
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    # SunOSNetwork.parse_interface_line(['lo0:', 'flags=2001000849', '[:0', 'mtu', '0', '-', '-', '-', '-', '-', '-'])
    words = ['lo0:', 'flags=2001000849', '[:0', 'mtu', '0', '-', '-', '-', '-', '-', '-']
    current_if = SunOSNetwork().parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == "lo0"
    assert current_if['ipv4'][0]['flags'] == ['LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4']

# Generated at 2022-06-24 23:02:18.438044
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    assert sun_o_s_network_collector._platform == 'SunOS'
    assert sun_o_s_network_collector._fact_class == SunOSNetwork
    assert sun_o_s_network_collector._cached_facts is None


# Generated at 2022-06-24 23:02:23.236649
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:02:27.505431
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:02:30.296220
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    interfaces_info = sun_o_s_network_0.get_interfaces_info('/bin/ifconfig')
    assert len(interfaces_info[0]) > 0

# Generated at 2022-06-24 23:02:33.709678
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    sun_o_s_network_0.get_interfaces_info("/sbin/ifconfig")


# Generated at 2022-06-24 23:02:35.867869
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()


if __name__ == "__main__":
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:02:37.893667
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector(module=AnsibleModule(argument_spec=dict()))


# Generated at 2022-06-24 23:02:50.351230
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Setup
    sunos_net = SunOSNetwork()

    # Test
    # Test a line of 'ifconfig -a' output: 'lo1: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 2'
    words = 'lo1: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 2'.split()
    current_if = sunos_net.parse_interface_line(words, {}, {})

    # Assert
    assert current_if['device'] == 'lo1'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-24 23:02:58.238382
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0


# Generated at 2022-06-24 23:03:09.094712
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sun_o_s_network_0 = SunOSNetwork({})
    sun_o_s_network_0._module.run_command = lambda *args, **kwargs: (0, "lo0:3: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n\tinet 127.0.0.1 netmask ff000000", '')

# Generated at 2022-06-24 23:03:20.614377
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    modules_json_calls_0 = {
        'run_command': [
            [
                '/sbin/ifconfig',
                '-a'
            ],
        ],
    }
    ansible_module_0 = AnsibleModule(
        argument_spec={
        },
        supports_check_mode=False
    )
    sun_o_s_network_0 = SunOSNetwork(ansible_module=ansible_module_0, path_to_ifconfig='/sbin/ifconfig')
    sun_o_s_network_0.get_interfaces_info('/sbin/ifconfig')

# Generated at 2022-06-24 23:03:25.368784
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0._platform == 'SunOS'

# Generated at 2022-06-24 23:03:26.436112
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert True == True


# Generated at 2022-06-24 23:03:30.399738
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork()

    # Test with positive input
    # sun_o_s_network.get_interfaces_info()


# Generated at 2022-06-24 23:03:40.414386
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_collector_1 = SunOSNetworkCollector()

# Generated at 2022-06-24 23:03:41.310200
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector()

# Generated at 2022-06-24 23:03:50.177912
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork()
    ifconfig_path = 'ifconfig'
    result = sun_o_s_network_0.get_interfaces_info(ifconfig_path)
    assert type(result) is tuple
    assert len(result) == 2
    assert result[0] is not None
    assert type(result[0]) is dict
    assert len(result[0].keys()) == 6
    assert result[1] is not None
    assert type(result[1]) is dict
    assert len(result[1].keys()) == 2



# Generated at 2022-06-24 23:03:52.920990
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:04:03.600816
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = None
    str_1 = None
    bool_0 = True
    bool_1 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0, str_0, bool_1, str_1)
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector)


# Generated at 2022-06-24 23:04:08.478041
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0)
    assert isinstance(sun_o_s_network_collector_0, SunOSNetworkCollector) is True


# Generated at 2022-06-24 23:04:09.807500
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# unit test for get_interfaces_info method of class SunOSNetwork

# Generated at 2022-06-24 23:04:19.503141
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = None
    str_1 = None
    bool_0 = True
    int_0 = 2053
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    # var_0 is a tuple containing two elements. Testing the type of the first element.
    assert type(var_0[0]) is dict
    # var_0 is a tuple containing two elements. Testing the type of the second element.
    assert type(var_0[1]) is dict
    # Testing that test_case_0 runs.
    test_case_0()


# Generated at 2022-06-24 23:04:24.891736
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    print("---- test_SunOSNetwork_get_interfaces_info ----")
    test_case_0()

if __name__ == "__main__":
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:04:30.866922
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    # Test method get_all_network_interfaces of class SunOSNetworkCollector
    arr_0 = [sun_o_s_network_collector_0.get_all_network_interfaces()]
    assert arr_0 == [['lo0', 'lo0', 'lo0', 'lo0', 'bge0', 'bge0', 'bge0', 'bge0', 'lo0', 'bge0']], 'unexpected value for sun_o_s_network_collector_0.get_all_network_interfaces()'
    # Test method get_interfaces_info of class SunOSNetworkCollector

# Generated at 2022-06-24 23:04:37.752475
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = None
    bool_0 = True
    int_0 = 2053
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    word_list = list()
    word_list.append("bge0")
    word_list.append(":")
    word_list.append("IPv4")
    word_list.append("MTU")
    current_if = sun_o_s_network_0.parse_interface_line(word_list, {})


# Generated at 2022-06-24 23:04:42.013043
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = None
    int_0 = None
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0, int_0)

# Generated at 2022-06-24 23:04:52.012293
# Unit test for constructor of class SunOSNetworkCollector

# Generated at 2022-06-24 23:04:53.466306
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_case_0()

# Testing get_interfaces_info()

# Generated at 2022-06-24 23:05:04.627226
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    flag_0 = True
    int_0 = 2053
    sun_o_s_network_0 = SunOSNetwork(flag_0, int_0)

# Generated at 2022-06-24 23:05:05.611742
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_case_0()

# Generated at 2022-06-24 23:05:08.192478
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = False
    module_0 = SunOSNetworkCollector(bool_0)

# Generated at 2022-06-24 23:05:13.837950
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = True
    int_0 = 4590
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0, int_0)
    # Tests for exception RuntimeError in constructor of class SunOSNetworkCollector
    with pytest.raises(RuntimeError):
        SunOSNetworkCollector(bool_0, int_0)

# Generated at 2022-06-24 23:05:17.947129
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = None
    bool_0 = True
    int_0 = 2152
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:05:21.962391
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = None
    bool_0 = True
    int_0 = 2053
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:05:23.478069
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = True
    int_0 = 2053
    # Constructor test case
    object_0 = SunOSNetworkCollector(bool_0, int_0)

# Generated at 2022-06-24 23:05:26.469218
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    assert callable(SunOSNetwork.get_interfaces_info)

test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:05:36.144804
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    str_0 = None
    bool_0 = True
    int_0 = 2053
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    str_1 = "iprb0: flags=12008843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST,IPv4> mtu 1500"
    str_2 = "iprb0"
    sun_o_s_network_0.parse_interface_line(str_1, str_2)


# Generated at 2022-06-24 23:05:42.885224
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = None
    bool_0 = True
    int_0 = 2053
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    sun_o_s_network_collector_0 = SunOSNetworkCollector(sun_o_s_network_0)
    assert sun_o_s_network_collector_0._platform == 'SunOS'
    assert sun_o_s_network_collector_0._fact_class == SunOSNetwork

# Generated at 2022-06-24 23:06:05.544109
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = False
    int_0 = -1970
    str_0 = 'j_'
    str_1 = '/sbin/ifconfig'
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_1)
    return var_0


# Generated at 2022-06-24 23:06:15.657502
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # The test object
    sun_o_s_network_0 = SunOSNetwork(True, 2053)

    # The test variables
    words_0 = ['bge0:', 'flags=20100842<UP,BROADCAST,RUNNING,MULTICAST,DEPRECATED,IPv4>', 'mtu', '1500']
    current_if_0 = {'ipv6': [{'mtu': '1500'}], 'ipv4': [{'mtu': '1500'}], 'macaddress': 'unknown', 'device': 'bge0', 'type': 'unknown'}
    interfaces_0 = {'bge0': current_if_0}

    # Make the call

# Generated at 2022-06-24 23:06:17.505826
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:06:24.139564
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup
    str_0 = None
    bool_0 = True
    int_0 = 2053
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)

    # Procedure
    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:06:26.360453
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    bool_0 = True
    sun_o_s_network_collector_0 = SunOSNetworkCollector(bool_0)

# Generated at 2022-06-24 23:06:30.803532
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_1 = None
    bool_1 = True
    int_1 = 7151
    sun_o_s_network_1 = SunOSNetwork(bool_1, int_1)
    # Test __main__.SunOSNetwork.get_interfaces_info()
    test_case_0()


# Generated at 2022-06-24 23:06:42.842272
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    bool_0 = False
    int_0 = None
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    str_0 = None
    test_case_0(sun_o_s_network_0, str_0)
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    str_0 = None
    test_case_0(sun_o_s_network_0, str_0)
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    str_0 = None
    test_case_0(sun_o_s_network_0, str_0)
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    str

# Generated at 2022-06-24 23:06:48.417159
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    bool_0 = True
    int_0 = 5607
    sun_o_s_network_0 = SunOSNetwork(bool_0, int_0)
    list_0 = ['lo0', 'flags=1004841', 'mtu', '8232']
    dict_0 = {}
    dict_1 = {}
    sun_o_s_network_0.parse_interface_line(list_0, dict_0, dict_1)


# Generated at 2022-06-24 23:06:49.824041
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:06:53.032452
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:07:27.769872
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
    assert sun_o_s_network_collector_0 is not None

# Generated at 2022-06-24 23:07:34.344282
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    var_0 = SunOSNetwork('/usr/sbin/ifconfig')
    str_0 = '4d4x2'
    str_1 = 'lk]$'
    dict_0 = {str_1: str_1}
    str_2 = 'm*Zo'
    var_0.parse_interface_line(str_0, str_1, dict_0)


# Generated at 2022-06-24 23:07:38.411009
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    print(SunOSNetwork.parse_interface_line.__doc__)
    sun_o_s_network_0 = SunOSNetwork('dummy')
    str_0 = '6"eB'
    with pytest.raises(TypeError):
        sun_o_s_network_0.parse_interface_line(str_0, str_0, str_0)

# Generated at 2022-06-24 23:07:40.081825
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network = SunOSNetwork('test_module')
    sun_o_s_network.get_interfaces_info('test_path')

# Generated at 2022-06-24 23:07:43.522239
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    print('\n* Test SunOSNetwork.parse_interface_line *')
    test_case_0()


# Generated at 2022-06-24 23:07:48.461555
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector_0 = SunOSNetworkCollector('net_collector')
# assert_match(net_collector_0._platform, 'SunOS')


# Generated at 2022-06-24 23:07:52.537276
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()
if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:07:54.576899
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'n-Q'
    sun_o_s_network_collector_0 = SunOSNetworkCollector(str_0)

# Generated at 2022-06-24 23:07:56.882700
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    argument_0 = SunOSNetworkCollector._platform
    sun_o_s_network_collector_0 = SunOSNetworkCollector(argument_0)


# Generated at 2022-06-24 23:08:03.644851
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-24 23:09:20.384537
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_args = []
    # Uncomment the line below to see how test_case_0 is generated.
    #print(test_case_0.__doc__)
    test_case_0()


# Generated at 2022-06-24 23:09:24.235251
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    sun_o_s_network_0 = SunOSNetwork(str)
    str_0 = '6"eB'

    sun_o_s_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 23:09:25.475304
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector_0 = SunOSNetworkCollector()


# Generated at 2022-06-24 23:09:28.197635
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_arg_0 = 'gsbQ2'
    sun_o_s_network_0 = SunOSNetwork(str_arg_0)
    var_0 = sun_o_s_network_0.get_interfaces_info(str_arg_0)


# Generated at 2022-06-24 23:09:33.837752
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    str_0 = 'K0'
    sun_o_s_network_collector = SunOSNetworkCollector(str_0)

if __name__ == '__main__':
    test_case_0()
    test_SunOSNetworkCollector()

# Generated at 2022-06-24 23:09:35.262009
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    _fact_class = SunOSNetwork
    _platform = 'SunOS'

# Generated at 2022-06-24 23:09:40.494496
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = '6"eB'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    out_0 = sun_o_s_network_0.get_interfaces_info(str_0)
    assert out_0 == (({}, {}) , ({'all_ipv4_addresses': [], 'all_ipv6_addresses': []}) )


# Generated at 2022-06-24 23:09:42.195123
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_o_s_network_collector = SunOSNetworkCollector()
    print(sun_o_s_network_collector)


# Generated at 2022-06-24 23:09:43.276427
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._platform == 'SunOS'

# Generated at 2022-06-24 23:09:53.650966
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    str_0 = ';6"eB'
    str_1 = ':0_f'
    str_2 = '3#s'
    str_3 = '4"X'
    str_4 = '4"X'
    str_5 = '4A'
    str_6 = '4A'
    str_7 = '4A'
    str_8 = '4A'
    str_9 = '4A'
    str_10 = '4A'
    str_11 = '4A'
    str_12 = '4A'
    str_13 = '4A'
    sun_o_s_network_0 = SunOSNetwork(str_0)
    sun_o_s_network_0.module = str_0
    var_0 = sun_o_s_network_0