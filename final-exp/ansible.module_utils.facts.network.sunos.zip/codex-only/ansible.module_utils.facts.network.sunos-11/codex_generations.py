

# Generated at 2022-06-23 00:06:30.371510
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    a = SunOSNetwork()
    words = ['ether', '0:1:2:3:4:5']
    current_if = {}
    ips = {}
    a.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == words[1]

# Generated at 2022-06-23 00:06:35.222777
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos = SunOSNetwork()
    line = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}

    sunos.parse_ether_line(line, current_if, ips)

    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:06:40.640310
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec={})
    obj = SunOSNetwork(module)

    test_words = ['ether', '0:1:e:cd:ab:9', 'RUNNING']

    obj.parse_ether_line(test_words, {}, {})
    assert test_words[1] == '00:01:0E:CD:AB:09'



# Generated at 2022-06-23 00:06:49.720992
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup test cases
    module = Mock()
    module.run_command.return_value = (0, FACT_TESTING_DATA, None)
    module.params = {
        'gather_subset': [],
        'gather_network_resources': 'all',
        'gather_timeout': 10
    }
    sn = SunOSNetwork(module=module)

    # test get_interfaces_info()
    out_interfaces, out_ips = sn.get_interfaces_info(sn.module.get_bin_path('ifconfig'))
    assert out_interfaces
    assert out_ips

    # test on interface 'lo0'
    lo0 = out_interfaces['lo0']

# Generated at 2022-06-23 00:07:01.486507
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    '''
    ifconfig -a output from a SunOS 5.11 Generic_142900-03 sun4v machine.
    '''


# Generated at 2022-06-23 00:07:14.283632
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    if not HAS_SUNOS_IFCONFIG:
        module.exit_json(changed=False, ansible_facts={})

    ifconfig_path = module.get_bin_path('ifconfig')

    sn = SunOSNetwork()
    interfaces, ips = sn.get_interfaces_info(ifconfig_path)

    module.exit_json(changed=False, ansible_facts={'ansible_interfaces': interfaces, 'ansible_all_ipv4_addresses': ips['all_ipv4_addresses'], 'ansible_all_ipv6_addresses': ips['all_ipv6_addresses']})


# import module snippets

# Generated at 2022-06-23 00:07:16.399510
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class._platform == 'SunOS'


# Generated at 2022-06-23 00:07:18.431597
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sc = SunOSNetworkCollector()
    assert sc.platform == 'SunOS'
    assert sc.fact_class is not None
    assert sc.fact_class._platform == 'SunOS'

# Generated at 2022-06-23 00:07:20.613932
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_net = SunOSNetworkCollector()
    assert sunos_net.platform == 'SunOS'
    assert sunos_net._fact_class == SunOSNetwork
    assert sunos_net._platform == 'SunOS'



# Generated at 2022-06-23 00:07:33.823345
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849', '<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>', 'mtu', '8232']
    current_if = SunOSNetwork.parse_interface_line(SunOSNetwork, words, current_if, interfaces)
    assert current_if['type'] == 'loopback'
    assert current_if['ipv6'][0]['flags'] == '<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>'
    assert current_if['ipv6'][0]['mtu'] == '8232'
    current_if = {}
    interfaces = {}

# Generated at 2022-06-23 00:07:35.743399
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    n = SunOSNetwork(dict(module=dict()))
    assert n.platform == 'SunOS'

# Generated at 2022-06-23 00:07:39.476654
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module)

    assert collector.platform == 'SunOS'
    assert collector.ifconfig_path == 'ifconfig'


# Generated at 2022-06-23 00:07:50.119205
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = None
    ifconfig_path = '/sbin/ifconfig'
    sunos_network = SunOSNetwork(module, ifconfig_path)
    interface_info, ips = sunos_network.get_interfaces_info(ifconfig_path)
    assert interface_info['lo0']['type'] == 'loopback'
    assert interface_info['lo0']['ipv4'][0]['mtu'] == '8232'
    assert 'UP' in interface_info['lo0']['ipv4'][0]['flags']
    assert 'BROADCAST' in interface_info['lo0']['ipv4'][0]['flags']
    assert 'RUNNING' in interface_info['lo0']['ipv4'][0]['flags']

# Generated at 2022-06-23 00:08:00.266384
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:08:06.169212
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    ifconfig_path = '/fake/path/to/ifconfig'
    sunos_network = SunOSNetwork({'ansible_facts': {'ansible_ifconfig': ifconfig_path}}, check_type=False)
    assert sunos_network.platform == 'SunOS'



# Generated at 2022-06-23 00:08:16.900897
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # pylint: disable=C0103,C0111
    from ansible.module_utils.facts.network import InterfaceNetwork

    ifconfig_path = "./utils/ifconfig_sunos"
    mac_address = '0:1:2:d:e:f'
    interface_name = 'bge0'

    # Create test data

# Generated at 2022-06-23 00:08:24.852347
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = line.split()
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ifaces = {}
    facts = SunOSNetwork().parse_interface_line(
        words, current_if, ifaces)
    assert facts['device'] == 'lo0'
    assert facts['type'] == 'loopback'
    assert facts['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-23 00:08:28.324197
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork



# Generated at 2022-06-23 00:08:39.629401
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    sunos = SunOSNetwork()
    interfaces = {'lo0': {}}
    current_if = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = sunos.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']

# Generated at 2022-06-23 00:08:43.285712
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Test creation of SunOSNetwork class object."""
    mod = 'ansible.module_utils.facts.network.sunos.SunOSNetwork'
    obj = SunOSNetwork()
    assert mod == obj.__module__



# Generated at 2022-06-23 00:08:51.366844
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    params = {'module': None, 'paths': {'ifconfig_path': None}}

    test_obj = SunOSNetwork(params)

    # Case 1: device should not be in interfaces
    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    current_if = test_obj.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:09:02.247202
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sut = SunOSNetwork()
    current_if = {'device': 'e1000g0'}
    ips = dict()

    # octets with leading zero
    words = ["ether", "0:4:0:4:4:4"]
    sut.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:04:00:04:04:04'

    # octets without leading zero
    words = ["ether", "0:b:0:d:e:f"]
    sut.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:0b:00:0d:0e:0f'

# Generated at 2022-06-23 00:09:07.565611
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    network_facts = collector.collect()
    assert network_facts['gather_subset'] == ['!all', '!min']
    assert network_facts['gather_network_resources'] == ['network']

# Generated at 2022-06-23 00:09:08.304132
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test if SunOSNetworkCollector is defined"""
    assert SunOSNetworkCollector

# Generated at 2022-06-23 00:09:12.591401
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.__class__.__name__ == 'SunOSNetworkCollector'
    assert collector.platform == 'SunOS'
    assert collector._fact_class.__name__ == 'SunOSNetwork'
    assert collector._fact_class.platform == 'SunOS'


# Generated at 2022-06-23 00:09:21.079467
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    args = dict(
        module=dict(
            run_command=lambda *args, **kwargs: (0, '', '')
        )
    )
    n = SunOSNetwork(**args)
    x, y= n.get_interfaces_info('/sbin/ifconfig')
    assert x['net0']['ipv4'][0]['mtu'] == '1500'
    assert x['net0']['ipv4'][0]['inet'][0]['netmask'] == '255.255.254.0'
    assert x['net0']['ipv6'][0]['inet6'][0]['prefixlen'] == '64'
    assert x['net0']['ipv6'][0]['inet6'][0]['scope'] == 'global'

# Generated at 2022-06-23 00:09:31.652028
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create test object
    s = SunOSNetwork()
    # Create test variables
    line = ['ether', '0:1:2:d:e:f']
    current_if = {'macaddress': '01:23:45:67:89:ab'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # Test
    s.parse_ether_line(line, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:09:38.723538
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test to make sure returned dictionary from get_interfaces_info is accurate
    """
    module = NetworkCollector.get_platform_module('SunOS')
    test = SunOSNetwork(module)
    results = test.get_interfaces_info('fake')

    # Expected results
    expected_results = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }
    assert results[1] == expected_results


# Generated at 2022-06-23 00:09:44.100974
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    SunOSNetwork_Instance = SunOSNetwork(module)
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    interfaces = {}
    current_if = {}
    result = SunOSNetwork_Instance.parse_interface_line(words, current_if, interfaces)
    assert result['ipv4'][0]['mtu'] == '8232'



# Generated at 2022-06-23 00:09:53.113682
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ Test the SunOSNetwork.get_interfaces_info method """


# Generated at 2022-06-23 00:09:55.337927
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork



# Generated at 2022-06-23 00:10:07.901324
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test case to check the get methods of class SunOSNetwork
    """
    sunos_test = SunOSNetwork()

# Generated at 2022-06-23 00:10:10.730930
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'


# Generated at 2022-06-23 00:10:18.745777
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork(None)
    current_if = {}
    # Solaris displays single digit octets in MAC addresses e.g. 0:1:2:d:e:f
    # Add leading zero to each octet where needed.
    words = ['ether', '0:1:2:d:e:f']
    network.parse_ether_line(words, current_if, {})
    assert(current_if['macaddress'] == '00:01:02:0d:0e:0f')

# Generated at 2022-06-23 00:10:22.821591
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    '''
    Test the SunOSNetworkCollector constructor
    '''
    my_sn = SunOSNetworkCollector()
    assert my_sn.platform == 'SunOS'
    assert my_sn._fact_class.platform == 'SunOS'


# Generated at 2022-06-23 00:10:25.888071
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()

    # Test that SunOSNetwork is a subclass of GenericBsdIfconfigNetwork
    assert isinstance(net, GenericBsdIfconfigNetwork)


# Generated at 2022-06-23 00:10:38.928057
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # If you update this method please also update the following
    # doc tests in files in the test directory:
    #   network/solaris_ifconfig1.txt
    #   network/solaris_ifconfig2.txt
    module = DummyAnsibleModule()
    test_SunOSNetwork_obj = SunOSNetwork(module)
    testinterfaces, testips = test_SunOSNetwork_obj.get_interfaces_info('')

# Generated at 2022-06-23 00:10:40.043069
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Test creation of SunOSNetwork class"""
    SunOSNetwork()


# Generated at 2022-06-23 00:10:49.602311
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create an instance of SunOSNetwork class
    obj = SunOSNetwork()
    # Set the current interface dictionary entry
    current_if = {'macaddress': 'dummymacaddress'}
    # Set the current IPs dict entry
    ips = {'all_ipv4_addresses': []}
    # line = 'ether 0:1:2:d:e:f'
    words = 'ether 0:1:2:d:e:f'.split()
    obj.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:11:00.802441
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    modul = AnsibleModule(argument_spec={})
    modul.params = {}
    modul.ifconfig_path = '/sbin/ifconfig'

    sunos_network = SunOSNetwork(modul)


# Generated at 2022-06-23 00:11:13.135183
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    net = SunOSNetwork()
    net.get_interfaces_info = MagicMock(return_value=({"lo0": {"ipv4": [], "ipv6": [], "type": "unknown", "device": "lo0"}}, {}))
    current_if = {}
    interfaces = {}
    words = [
        "lo0:",
        "flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>",
        "mtu 8232",
        "index 1",
    ]
    current_if = net.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:11:25.026757
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    d = dict(device='lo0', ipv4=[], ipv6=[], type='unknown', macaddress='unknown')
    i = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    module = None
    iface = SunOSNetwork(module)

    # Test various invalid inputs
    w = dict(words=['ether', '1:2:3:4:5:6'])
    d = iface.parse_ether_line(**w)
    assert d == dict(device='lo0', ipv4=[], ipv6=[], type='unknown', macaddress='01:02:03:04:05:06')

    w = dict(words=['ether', 'a:b:c:d:e:f'])

# Generated at 2022-06-23 00:11:37.219863
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)
    # test inherited 'facts' attribute
    assert sunos_network.facts == dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
        default_ipv4_route={},
        default_ipv6_route={},
        interfaces={},
    )
    # test inherited '_interfaces' attribute
    assert sunos_network._interfaces == dict(
        SunOS=dict(
            commands={
                'ifconfig_path': 'ifconfig',
                'ip_path': 'ip',
            },
        ),
    )
    # test inherited '_interfaces_class' attribute

# Generated at 2022-06-23 00:11:41.402853
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    module.params['gather_subset'] = ['']
    module.exit_json = MagicMock()
    SunOSNetwork.get_interfaces_info(ifconfig_path='')

# Generated at 2022-06-23 00:11:43.695859
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-23 00:11:54.382934
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork()
    current_if = {}
    interfaces = {}
    # Create the first interface
    words = ['lo0:', 'flags=2001000849', '<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '2']

# Generated at 2022-06-23 00:11:56.916771
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 00:12:10.231078
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    n = SunOSNetwork()
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {'device': 'lo0', 'ipv4': [{'mtu': '8232', 'flags': '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'}], 'ipv6': [{'mtu': '8252', 'flags': '2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>'}], 'type': 'unknown'}
    interfaces = {}

# Generated at 2022-06-23 00:12:14.947175
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    facts = SunOSNetwork()
    assert facts.platform == 'SunOS'
    assert facts.get_interfaces_info.__name__ == 'get_interfaces_info'
    assert facts.collect.__name__ == 'collect'

# Generated at 2022-06-23 00:12:20.272508
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = type('', (object,), {'run_command': (lambda *args, **kwargs: (0, 'foo', 'bar'))})
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class.platform == 'SunOS'

# Generated at 2022-06-23 00:12:33.078028
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    module = MagicMock(name='module', spec=basic.AnsibleModule)
    module.run_command = MagicMock()
    module.run_command.return_value = 0, '', ''

    # Constructor for this class will invoke SunOSNetwork.__init__()
    # which in turn will invoke GenericBsdIfconfigNetwork.__init__()
    os_network = SunOSNetwork(module)

    assert os

# Generated at 2022-06-23 00:12:39.165789
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    ips = {}
    words = ['ether', '0:a:0:0:0:1']
    SunOSNetwork().parse_ether_line(words, current_if, ips)
    if current_if != {'macaddress': '00:0a:00:00:00:01'}:
        raise AssertionError("test_SunOSNetwork_parse_ether_line(): failed")
    return True

# Generated at 2022-06-23 00:12:50.005621
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    words = ['e1000g0:', 'flags=2001000843', 'mtu', '1500', 'index', '8']
    current_if = {}
    interfaces = {}
    SunOSNetwork_parse_interface_line = SunOSNetwork().parse_interface_line(words, current_if, interfaces)
    assert SunOSNetwork_parse_interface_line['device'] == 'e1000g0:'
    assert SunOSNetwork_parse_interface_line['type'] == 'unknown'
    assert SunOSNetwork_parse_interface_line['macaddress'] == 'unknown'
    assert SunOSNetwork_parse_interface_line['ipv4'][0].keys() == ['flags', 'mtu']
    assert SunOSNetwork_parse_interface_line['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-23 00:12:51.672228
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'
    assert isinstance(obj._fact_class(), SunOSNetwork)

# Generated at 2022-06-23 00:13:03.957650
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import ifconfig_path_arg
    ifconfig_path = ifconfig_path_arg
    test_module = "ansible.module_utils.facts.network.generic_bsd"

# Generated at 2022-06-23 00:13:06.101750
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    n = SunOSNetworkCollector()
    assert n.platform == 'SunOS'
    assert n.fact_class == SunOSNetwork


# Generated at 2022-06-23 00:13:17.825328
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = Mock(return_value=0)

    test_obj = SunOSNetwork(module)

    # assign the required values
    test_obj.ifconfig_path = "/sbin/ifconfig"
    test_obj.interfaces = {}
    test_obj.ips = {}
    test_obj.interface_match = re.compile(r'^[A-Za-z][A-Za-z0-9]*(\d+)?(\s|$)')

    rc, out, err = 0, "", "ifconfig: SIOCGLIFCONF: No such device",
    test_obj.module.run_command = Mock(return_value=[rc, out, err])

    # test with empty output

# Generated at 2022-06-23 00:13:30.805670
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    my_sunos_network = SunOSNetwork()

    # Sample line from Solaris 11.4 system
    line = 'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'
    words = line.split()
    current_if = {}
    interfaces = {}
    current_if = my_sunos_network.parse_interface_line(words, current_if, interfaces)

    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert 'UP' in current_if['ipv4'][0]['flags']
    assert 'LOOPBACK' in current_if['ipv4'][0]['flags']

# Generated at 2022-06-23 00:13:43.221416
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    class MockedModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/sbin/ifconfig'

    test_if = {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '8232'}],
               'ipv6': [{'flags': ['UP', 'RUNNING', 'MULTICAST', 'IPv6', 'DUPLICATE'], 'mtu': '8252'}],
               'type': 'loopback',
               'macaddress': 'unknown'}

# Generated at 2022-06-23 00:13:45.190791
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    '''
    Unit test for the constructor of SunOSNetwork
    '''
    module = AnsibleModuleMock({'gather_subset': ['all']})
    obj = SunOSNetwork('/sbin/ifconfig', module)
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 00:13:53.138835
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    m = SunOSNetwork({})
    assert m.get_device_name('lo0:2') == 'lo0'
    assert m.get_device_name('bge11100') == 'bge11100'
    assert m.get_device_name('em0:0') == 'em0'
    assert m.get_device_name('em0:1') == 'em0'
    assert m.get_device_name('em0:2') == 'em0'
    assert m.get_device_name('em0:3') == 'em0'
    assert m.get_device_name('em0:4') == 'em0'
    assert m.get_device_name('em0:5') == 'em0'
    assert m.get_device_name('em0:6') == 'em0'

# Generated at 2022-06-23 00:14:03.435770
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:14:15.069116
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    out = """lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n
        inet 127.0.0.1 netmask ff000000\n
        lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1\n
        inet6 ::1/128\n
        net0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2\n
        inet 192.168.1.1 netmask ffffff00 broadcast 192.168.1.255\n
        ether 0:1:2:3:4:5"""

    current_

# Generated at 2022-06-23 00:14:18.353024
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor test of SunOSNetworkCollector
    """
    module = AnsibleModuleMock()
    assert SunOSNetworkCollector(module)

# Generated at 2022-06-23 00:14:28.498808
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    assert SunOSNetwork.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})[2]['macaddress'] == '00:01:02:0d:0e:0f'
    assert SunOSNetwork.parse_ether_line(['ether', '0:0:0:0:0:0'], {}, {})[2]['macaddress'] == '00:00:00:00:00:00'
    assert SunOSNetwork.parse_ether_line(['ether', '00:11:22:33:44:55'], {}, {})[2]['macaddress'] == '00:11:22:33:44:55'

# Generated at 2022-06-23 00:14:29.658034
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-23 00:14:42.829359
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    # Prepare interface
    iface = dict()
    iface['device'] = 'lo0'
    iface['ipv4'] = [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'broadcast': '127.255.255.255'}]
    iface['ipv6'] = []
    iface['type'] = 'loopback'
    iface['macaddress'] = 'unknown'

    # Prepare ips
    ips = dict(
        all_ipv4_addresses=['127.0.0.1/8'],
        all_ipv6_addresses=[]
    )

    # Create SunOSNetwork object and test it

# Generated at 2022-06-23 00:14:44.286106
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork({}, TestModule())


# Generated at 2022-06-23 00:14:55.703471
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    test_line = "lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1"
    words = test_line.split()
    SunOSNetwork().parse_interface_line(words, current_if, interfaces)
    interfaces_expected = {'lo0': {'ipv4': [{'flags': '1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'device': 'lo0', 'macaddress': 'unknown'}}
    assert interfaces == interfaces_expected


# Generated at 2022-06-23 00:15:07.913238
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockNetwork()
    ifconfig_path = "../ansible/module_utils/facts/network/ip_fil_path"
    network = SunOSNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path)

    assert 'lo0' in interfaces
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'
    assert interfaces['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-23 00:15:19.910031
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork()
    joe = {'device': 'lo0', 'type': 'loopback', 'macaddress': 'unknown'}
    joe['ipv4'] = [{'mtu': '8232', 'flags': ['IPv4', 'Loopback']}]
    res = m.parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
                                  'mtu', '8232'], {}, {})
    assert res == joe
    guido = {'device': 'bge0', 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:15:26.189293
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    line = "ether 0:a:b:c:d:e"
    words = line.split()

    sunos_network = SunOSNetwork()
    current_if = {'device': 'example0'}
    sunos_network.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:a:b:c:d:e'

# Generated at 2022-06-23 00:15:30.291528
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunosnetwork = SunOSNetwork()
    ex0 = {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '8232'}],
           'ipv6': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'IPv6', 'MULTICAST'], 'mtu': '8252', 'netmask': 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff', 'prefixlen': '128'}], 'macaddress': 'unknown', 'type': 'loopback'}

# Generated at 2022-06-23 00:15:41.186352
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    p = SunOSNetwork(module, ifconfig_path='/sbin/ifconfig')

# Generated at 2022-06-23 00:15:42.791143
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'


# Generated at 2022-06-23 00:15:49.084536
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_class = SunOSNetwork({})
    current_if = {'device': 'bge0'}
    test_class.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:15:56.206298
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {}
    module = {}
    module['run_command'] = lambda x, **kwargs: (0, '0:1:2:d:e:f\n', '')
    module['params'] = {}
    SunOSNetwork(module).parse_ether_line(['ether'], iface, {})
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:16:07.882199
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:16:19.441802
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # test cases for method parse_ether_line of class SunOSNetwork
    test_case = [
        {
            'line': '    ether 0:3:ba:3b:d8:75',
            'current_if': {},
            'ips': {},
            'expected_current_if': {'macaddress': '00:3:ba:3b:d8:75'}
        },
        {
            'line': '    ether 3f:12:85:13:a7:c6',
            'current_if': {},
            'ips': {},
            'expected_current_if': {'macaddress': '3f:12:85:13:a7:c6'}
        }
    ]
    # Test each test case
    test_obj = SunOSNetwork()

# Generated at 2022-06-23 00:16:26.639864
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = FakeAnsibleModule(platform='SunOS')
    network = SunOSNetwork()
    network.module = module
    current_if = {}
    ips = {}

    network.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    assert current_if['type'] == 'unknown'

