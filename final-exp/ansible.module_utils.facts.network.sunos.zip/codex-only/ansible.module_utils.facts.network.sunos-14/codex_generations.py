

# Generated at 2022-06-23 00:06:35.139112
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    network_fact_class = SunOSNetwork()
    test_words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '2']
    current_if_facts = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces_facts = {}
    interfaces_facts_expected = {'lo0': {'device': 'lo0', 'ipv4': [{'flags': '2001000849', 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback'}}
    current_if = network_fact_class.parse_interface_line(test_words, current_if_facts, interfaces_facts)
    assert interfaces_facts == interfaces_facts_expected

# Generated at 2022-06-23 00:06:40.549347
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    interfaces, ips = SunOSNetwork().get_interfaces_info('/usr/sbin/ifconfig')
    assert len(interfaces) > 0
    assert 'lo0' in interfaces
    assert 'hme0' in interfaces
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0


# Generated at 2022-06-23 00:06:43.467244
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    testobject = SunOSNetwork()
    testobject.get_interfaces_info('/sbin/ifconfig')



# Generated at 2022-06-23 00:06:50.989579
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeModule()
    interfaces, ips = SunOSNetwork(module).get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert len(interfaces) == 2
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert len(interfaces['lo0']['ipv4']) == 1
    assert interfaces['lo0']['ipv6'][0]['mtu'] == '65536'
    assert len(interfaces['lo0']['ipv6']) == 1
    assert interfaces['lo0']['macaddress'] == '02:00:00:00:00:00'

# Generated at 2022-06-23 00:07:01.994440
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    This function is called if you run tests/units/module_utils/network/sunos/test_network_sunos.py
    """
    sunos_network = SunOSNetwork()
    interfaces = {}
    current_if = {}
    test_line1 = 'lo0:flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    test_line2 = 'lo0:1:1:flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'

# Generated at 2022-06-23 00:07:14.375871
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    instance = SunOSNetwork()
    with open('/etc/ansible/facts/SunOS_get_interfaces_info.out', 'r') as f:
        output = f.read()
    instance.module.run_command = MagicMock(return_value=(0, output, ''))
    result = instance.get_interfaces_info()
    interfaces, ips = result
    assert interfaces['lo0']['macaddress'] == '00:00:00:00:00:00'
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-23 00:07:21.712992
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # create a temporary text file to read results from
    import tempfile
    fd, path = tempfile.mkstemp(text=True)

# Generated at 2022-06-23 00:07:26.369543
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of SunOSNetworkCollector
    """
    obj = SunOSNetworkCollector()
    assert isinstance(obj._fact_class, SunOSNetwork)
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 00:07:38.082554
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """ Unit test for method parse_interface_line of class SunOSNetwork """

    class FakeModule(object):
        def __init__(self):
            self._ansible_no_log = False
            self.run_command = run_command

    # Mocked method run_command()
    def run_command(command, check_rc=True, close_fds=True, data=None):
        return (0, ifconfig_out, '')

    # If -a is specified, ifconfig prints interfaces twice, once for IPv4 and again for IPv6.
    # MTU and FLAGS may differ between IPv4 and IPv6 on the same interface.

# Generated at 2022-06-23 00:07:44.508452
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    interface = {'type': ''}
    ips = {'all_ipv4_addresses': '', 'all_ipv6_addresses': ''}
    SunOSNetwork().parse_ether_line(['ether', '0:1:2:d:e:f'], interface, ips)
    assert interface['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:07:53.665407
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = type('', (), {'run_command': lambda self, args: None})()
    test_sunos_network = SunOSNetwork(test_module)

# Generated at 2022-06-23 00:08:06.458834
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifconfig_path = '/sbin/ifconfig'
    network = SunOSNetwork(None, ifconfig_path)

    current_if = {}
    ips = {}
    words = ['ether', '0:1:2:3:4:5']
    network.parse_ether_line(words, current_if, ips)
    assert current_if == {'macaddress': '00:01:02:03:04:05'}

    current_if = {'macaddress': '00:01:02:03:04:05'}
    ips = {}
    words = ['ether', '0:a:b:c:d:e']
    network.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-23 00:08:13.331165
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Test the constructor of the SunOSNetwork class with good and bad input.
    """
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    # Test good input
    SunOSNetwork(module=None, network_provider=None)

    # Test bad input
    try:
        SunOSNetwork(network_provider="bad_provider")
    except ValueError:
        pass

# Generated at 2022-06-23 00:08:21.927492
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_object = SunOSNetwork()

    interfaces = {}
    current_if = {}

    # Test a line for a Network Interface
    test_line = "e1000g0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2"
    test_words = test_line.split()
    assert test_words[0][0:-1] == "e1000g0"
    assert test_words[1] == "flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>"
    assert test_words[3] == "1500"
    current_if = test_object.parse_interface_line(test_words, current_if, interfaces)
    assert current_if['device'] == "e1000g0"
   

# Generated at 2022-06-23 00:08:35.269523
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mod_args = dict(
        gather_subset=['all'],
    )
    module = AnsibleModule(
        argument_spec=mod_args,
        supports_check_mode=False,
    )
    facts = SunOSNetwork(module).populate()
    assert facts['all_ipv4_addresses'][0] == '192.168.1.1'
    assert facts['interfaces']['en0']['ipv4'][0]['address'] == '192.168.1.1'
    assert facts['interfaces']['en0']['ipv4'][0]['netmask'] == '255.255.255.0'
    assert facts['interfaces']['en0']['ipv4'][0]['broadcast'] == '192.168.1.255'

# Generated at 2022-06-23 00:08:39.453542
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = fake_ansible_module()
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-23 00:08:42.192923
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-23 00:08:50.783738
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from mock import patch

    # This is default output from 'ifconfig -a NET0' on Solaris 11.3.

# Generated at 2022-06-23 00:08:57.132508
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class.platform == 'SunOS'
    assert collector.fact_class._platform == 'SunOS'
    assert collector.fact_class.get_interfaces_info('/bin/ifconfig') == (None, None)


# Generated at 2022-06-23 00:09:04.964997
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_if = {
        'device': 'lo0',
        'ipv4': [{'flags': ['UP'], 'mtu': '8232'}],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown'
    }
    test_ips = {}
    test_words = ['ether', '0:1:2:3:4:5']
    SunOSNetwork().parse_ether_line(test_words, test_if, test_ips)

# Generated at 2022-06-23 00:09:13.221663
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('obj', (object,), {'params': {'gather_subset': "all"}})
    obj = SunOSNetwork(module)
    obj.populate()
    assert list(obj.fact_subsets['interfaces'].keys()) == ['lo0', 'bge0', 'e1000g0', 'e1000g1', 'e1000g2', 'e1000g3']
    assert len(obj.fact_subsets['interfaces']['lo0']['ipv4']) == 1


# Generated at 2022-06-23 00:09:14.468071
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    collect_net_instance = SunOSNetwork()
    assert collect_net_instance.platform == "SunOS"

# Generated at 2022-06-23 00:09:18.435766
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Constructor for class SunOSNetworkCollector should set the correct attributes"""
    _fact_class = SunOSNetwork
    _platform = 'SunOS'
    sunos_network = NetworkCollector(_fact_class, _platform)
    assert sunos_network._fact_class == SunOSNetwork
    assert sunos_network._platform == 'SunOS'

# Generated at 2022-06-23 00:09:30.487098
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interface_if = []
    interfaces = {}
    words = ['lo0', 'flags=1004849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    for word in words:
        interface_if = SunOSNetwork.parse_interface_line(SunOSNetwork(), words, interface_if, interfaces)
    assert interface_if['device'] == 'lo0'
    assert interface_if['macaddress'] == 'unknown'
    assert interface_if['ipv4'][0]['mtu'] == '8232'
    assert interface_if['ipv4'][0]['flags'] == '1004849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>'
    assert len(interface_if['ipv4']) == 1

# Generated at 2022-06-23 00:09:33.196883
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    o = SunOSNetworkCollector()
    assert o._fact_class == SunOSNetwork
    assert o._platform == 'SunOS'

# Generated at 2022-06-23 00:09:35.706471
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    f = SunOSNetworkCollector()
    assert f.platform == 'SunOS'
    assert f._fact_class.__name__ == 'SunOSNetwork'


# Generated at 2022-06-23 00:09:39.616006
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Unit test for constructor of class SunOSNetworkCollector
    """
    new_fact_class = SunOSNetworkCollector('SunOS')
    assert new_fact_class._platform == 'SunOS'
    assert new_fact_class._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:09:40.554495
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork('module')

# Generated at 2022-06-23 00:09:51.041983
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_class = SunOSNetwork()

    # Test IPv4 interface
    words = ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = test_class.parse_interface_line(words, {}, {})
    expected_result = {'device': 'e1000g0', 'ipv4': [{'flags': '1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu': '1500'}], 'macaddress': 'unknown', 'type': 'unknown', 'ipv6': []}
    assert expected_result == current_if

    # Test IPv6 interface

# Generated at 2022-06-23 00:10:03.018493
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork()
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232']
    current_if = facts.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0] == {'flags': '2001000849', 'mtu': '8232'}
    assert current_if['ipv6'] == []
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232']

# Generated at 2022-06-23 00:10:08.716529
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork()
    current_if = {}
    ips = {}
    words = ['ether', '0:14:4f:b5:97:f9']
    network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:14:4f:b5:97:f9'

# Generated at 2022-06-23 00:10:20.697730
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_dict = dict()
    test_dict['ipv4'] = []
    test_dict['ipv6'] = []
    test_dict['macaddress'] = 'unknown'
    test_dict['type'] = 'unknown'
    test_dict['device'] = 'lo0'
    test_SunOSNetwork = SunOSNetwork()
    test_SunOSNetwork.parse_interface_line(['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu' ,'8232'], test_dict, test_dict)
    assert test_dict['ipv4'][0]['flags'] == '1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>'

# Generated at 2022-06-23 00:10:33.087117
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.generic_bsd import Facts
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.facts import get_facts

    my_test_facts = Facts()
    my_test_mock = {'ansible_network_resources': {}}
    my_test_results = {'ansible_network_resources': {'interfaces': {}, 'interfaces_ipv4': {}}}
    my_test_facts.populate()

    # Define a testing list of vlans / interface

# Generated at 2022-06-23 00:10:46.122800
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork


# Generated at 2022-06-23 00:10:55.364330
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test normal constructor
    obj = SunOSNetworkCollector()
    assert obj.facts is None
    assert obj._platform == 'SunOS'
    assert obj._fact_class._platform == 'SunOS'
    assert obj._fact_class.platform == 'SunOS'
    assert obj._fact_class.get_interfaces_info.__code__.co_argcount == 3
    assert obj._fact_class.parse_interface_line.__code__.co_argcount == 4
    assert obj._fact_class.parse_options_line.__code__.co_argcount == 4
    assert obj._fact_class.parse_nd6_line.__code__.co_argcount == 4
    assert obj._fact_class.parse_ether_line.__code__.co_argcount == 4
    assert obj._fact_class

# Generated at 2022-06-23 00:11:07.997310
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:11:15.155499
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    interface = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    assert interface['macaddress'] == 'unknown'
    ips = {}
    SunOSNetwork.parse_ether_line(['ether', '0:1:2:d:e:f'], interface, ips)
    assert interface['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:11:22.109087
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    parser = SunOSNetwork()
    device = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    parser.parse_ether_line(['ether', '0:1:2:d:e:f'], device, {})
    assert device['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:11:30.167178
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Basic test functionality
    out = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n'
    words = out.split()
    iface = SunOSNetwork().parse_interface_line(words, {}, {})
    assert iface['type'] == 'loopback'
    assert iface['ipv4'][0]['mtu'] == '8232'
    assert iface['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']
    # IPv6 interface

# Generated at 2022-06-23 00:11:42.651849
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # set up object
    sunos_network = SunOSNetwork()
    # set up test data
    words = ['ether', '0:1:2:d:e:f']
    current_if = {
        'device': 'net0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown'
    }
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:11:53.580935
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    sunos_network = SunOSNetwork(dict(module=dict()), 'path')
    assert isinstance(sunos_network, GenericBsdNetwork)

# need an echo of Solaris 'ifconfig -a' to unit test
# def test_parse_interface_line():
# def test_parse_options_line():
# def test_parse_nd6_line():
# def test_parse_ether_line():
# def test_parse_media_line():
# def test_parse_status_line():
# def test_parse_lladdr_line():
# def test_parse_inet_line():
# def test_parse_inet6_line():
# def test_parse_unknown_line():
# def test_get_interfaces

# Generated at 2022-06-23 00:12:07.450424
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_class = SunOSNetwork()
    # Test Mac Address with zero as first octet
    test_words = ['ether', '0:1:2:d:e:f']
    test_if = {'device': 'test_device', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    assert test_class.parse_ether_line(test_words, test_if, test_ips) == None
    assert test_if['macaddress'] == '00:01:02:0d:0e:0f'
    # Test Mac Address with zero as second octet

# Generated at 2022-06-23 00:12:20.204737
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test case 1
    # Test data
    cmd_output = 'lo0: flags=2001000849 mtu 8232 index 1'
    ifconfig_path = 'test'
    # Expected result
    expected_result = {'device': 'lo0',
                       'ipv4': [{'flags': '2001000849', 'mtu': '8232'}],
                       'ipv6': [],
                       'type': 'loopback',
                       'macaddress': 'unknown'
                       }
    # Create object of SunOSNetwork and call method parse_interface_line
    sunos_network_object = SunOSNetwork()
    sun_os_network_result = sunos_network_object.parse_interface_line(cmd_output.split(), {}, {})

    # Assert the result
    assert sun_os_network

# Generated at 2022-06-23 00:12:27.963812
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    '''Unit test the SunOSNetwork class.'''

    module = AnsibleModule(argument_spec={})
    sunos_collector = SunOSNetworkCollector(module=module)
    result = sunos_collector.collect()
    assert result['interfaces']['lo0'] == {'device': 'lo0',
                                           'ipv4': None,
                                           'ipv6': [],
                                           'macaddress': 'unknown',
                                           'type': 'loopback'}

# Generated at 2022-06-23 00:12:39.901380
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create instance of SunOSNetwork
    facts_network_collector = SunOSNetworkCollector()
    facts_network_obj = facts_network_collector._fact_class(None)
    # Make sure we have ifconfig installed
    ifconfig_path = facts_network_obj.get_bin_path('ifconfig', required=True)
    # Call get_interfaces_info()
    interfaces, ips = facts_network_obj.get_interfaces_info(ifconfig_path)
    # Test the expected result
    assert interfaces['lagg0']['mtu'] == '1500'
    assert interfaces['lagg0']['ipv4'][0]['mtu'] == '1500'
    assert interfaces['lagg0']['flags'] == ['BROADCAST', 'RUNNING', 'MULTICAST']
   

# Generated at 2022-06-23 00:12:42.531903
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos = SunOSNetworkCollector()
    assert sunos.get_facts() is not None

# Generated at 2022-06-23 00:12:51.797219
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    testobj = SunOSNetwork()
    testobj.module.run_command = lambda *args, **kwargs: (0, '', '')
    testobj.module.params = dict(gather_timeout=1)

    rc, out, err = testobj.module.run_command(["cat", "./unit/ansible_collections/ansible/netcommon/plugins/net_platforms/sunos/facts_data/ifconfig.txt"])

    if rc != 0:
        print ('ERROR: Failed to read sample ifconfig output')
        return

    interfaces, ips = testobj.get_interfaces_info(ifconfig_path='/usr/bin/ifconfig')


# Generated at 2022-06-23 00:12:53.835797
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork(dict(module=None))
    assert net.platform == 'SunOS'


# Generated at 2022-06-23 00:13:05.355505
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('', (), dict(run_command=lambda *_: (0, '', '')))
    ic = SunOSNetwork(module)
    words = 'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'.split()
    current_if = {}
    interfaces = {}
    current_if = ic.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['ipv4'][0] == {'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '8232'}

# Generated at 2022-06-23 00:13:09.619060
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    if collector._platform != 'SunOS':
        raise AssertionError("Incorrect platform: {}".format(collector._platform))



# Generated at 2022-06-23 00:13:11.940549
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class == SunOSNetwork


# Generated at 2022-06-23 00:13:20.284728
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork"""

    module = FakeAnsibleModule()
    module.params['gather_subset'] = ['!all', 'network']

    sut = SunOSNetwork(module)

    sut.get_interfaces_info = mock_get_interfaces_info


# Generated at 2022-06-23 00:13:32.711065
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = Mock()
    module.run_command = mock_run_command
    fact = SunOSNetwork(module)

    current_if = {}
    interfaces = {}
    line = 'bge0: flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8232 index 3'
    words = line.split()

    current_if = fact.parse_interface_line(words, current_if, interfaces)
    interfaces[current_if['device']] = current_if

# Generated at 2022-06-23 00:13:35.575442
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class is not None
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 00:13:41.278953
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_list = ['ether', '0:11:22:33:44:55']
    test_dict = {}
    test_ips = {}
    SunOSNetwork().parse_ether_line(test_list, test_dict, test_ips)
    assert test_dict['macaddress'] == '00:11:22:33:44:55'

# Generated at 2022-06-23 00:13:51.120238
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('FakeModule', (), dict(run_command=lambda *args, **kwargs: (0, '', '')))()
    network_collector = SunOSNetwork(module)
    # words for non-loopback interface
    words = ['net0:', 'flags=1000843', 'mtu', '1500', 'index', '4']
    current_if = {'device': 'net0'}
    interfaces = {}
    current_if = SunOSNetwork.parse_interface_line(network_collector, words, current_if, interfaces)
    expected_current_if = {'device': 'net0', 'ipv4': [{'flags': ['1000843'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}
    assert expected_current_if == current_if

# Generated at 2022-06-23 00:14:02.397311
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector.get_module(dict(cache=False))
    SunOSNetwork = SunOSNetworkCollector.get_network_collector(module)

    interfaces, ips = SunOSNetwork.get_interfaces_info('/sbin/ifconfig')

    assert interfaces['net0']['device'] == 'net0'
    assert interfaces['net0']['ipv4'][0]['macaddress'] == '00:50:b6:c8:71:b7'
    assert interfaces['net0']['ipv4'][0]['mtu'] == '1500'
    assert interfaces['net0']['ipv4'][0]['type'] == 'loopback'

# Generated at 2022-06-23 00:14:07.265254
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    modules = 'ifconfig'
    NetworkCollector._platform = 'SunOS'
    facts = SunOSNetwork(modules)
    assert facts._platform == 'SunOS'
    assert facts._module.params['module_type'] == 'ifconfig'


# Generated at 2022-06-23 00:14:09.674938
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sun_network = SunOSNetwork()
    assert sun_network.get_interfaces_info('/sbin/ifconfig') == ({}, {})

# Generated at 2022-06-23 00:14:18.172801
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Test that the method parse_interface_line() for the class SunOSNetwork returns
    expected values for a provided Solaris interface string
    """
    # setup
    class TestModule:
        def __init__(self):
            self.run_command_environ_update = None
        def run_command(self, args, check_rc=True, close_fds=True, data=None, executable=None,
                        data_complex_args=None, binary_data=False, path_prefix=None, cwd=None,
                        use_unsafe_shell=False, prompt_regex=None):
            pass
    class TestIfaceDict():
        def __init__(self):
            self.device = 'test0'
            self.ipv4 = []
            self.ipv6 = []
            self.type

# Generated at 2022-06-23 00:14:24.699449
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = {}
    SunOSNetworkCollector(None, facts, None).collect()

    assert facts['ansible_facts']['ansible_net_interfaces'] == {}
    assert facts['ansible_facts']['ansible_net_all_ipv4_addresses'] == []
    assert facts['ansible_facts']['ansible_net_all_ipv6_addresses'] == []

# Generated at 2022-06-23 00:14:25.538740
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-23 00:14:31.134607
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    # test_ifconfig_output is just a snippet of data, not a complete interface
    test_ifconfig_output = """
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        inet6 ::1/128
hme0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
        inet 10.201.87.119 netmask ffffff00 broadcast 10.201.87.255
        ether 0:3:ba:ed:35:f0
"""

# Generated at 2022-06-23 00:14:34.011758
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    testobj = SunOSNetworkCollector()
    try:
        assert testobj.platform == 'SunOS'
    except Exception as e:
        raise e

# Generated at 2022-06-23 00:14:35.063924
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-23 00:14:42.557704
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    line = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    net = SunOSNetwork()
    net.parse_ether_line(line, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:14:53.910319
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunosnet = SunOSNetwork()
    words = "ether 0:1:2:d:e:f".split()
    current_if = {}
    ips = []
    sunosnet.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0D:0E:0F'
    words = "ether ab:cd:ef:01:23:45".split()
    current_if = {}
    ips = []
    sunosnet.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == 'AB:CD:EF:01:23:45'


# Generated at 2022-06-23 00:15:06.228701
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    interfaces = SunOSNetwork(module)
    interfaces.collect()

    # Test 'all_ipv4_addresses' and 'all_ipv6_addresses'
    assert "fe80::6334:4ff:fea2:5822" in interfaces.all_ipv6_addresses
    assert "192.168.2.2" in interfaces.all_ipv4_addresses

    # Test for specific interface
    assert "fe80::6334:4ff:fea2:5822" in interfaces.interfaces['e1000g3']['ipv6'][0]['address']
    assert "192.168.2.2" in interfaces.interfaces['e1000g3']['ipv4'][0]['address']

# Generated at 2022-06-23 00:15:13.922205
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = AnsibleModule({'ansible_facts': {'ansible_net_interfaces': {}}})
    m = SunOSNetwork(module)
    m._module = module
    current_if = {}
    words = 'ether 0:1:2:d:e:f'.split()
    m.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    # Check non-octal digits are ignored
    words = 'ether 0:1:2:g:e:f'.split()
    m.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:00:0e:0f'

    # Check extra digits are ignored


# Generated at 2022-06-23 00:15:16.294621
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = SunOSNetwork()
    assert module.platform == 'SunOS'


# Generated at 2022-06-23 00:15:28.511605
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''Unit test for method get_interfaces_info of class SunOSNetwork'''
    ############################################################################
    # Arrange, Act
    #
    # We assume that ifconfig path is /sbin/ifconfig
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    network_collector = SunOSNetworkCollector(module=module, facts={})

# Generated at 2022-06-23 00:15:31.418820
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-23 00:15:39.188498
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    network = collector.get_network_facts()
    interfaces = network['interfaces']
    for key in interfaces:
        value = interfaces[key]
        assert 'mtu' in value['ipv4'][0]
        assert 'mtu' in value['ipv6'][0]
        assert 'flags' in value['ipv4'][0]
        assert 'flags' in value['ipv6'][0]



# Generated at 2022-06-23 00:15:50.274784
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module)
    assert collector.platform == 'SunOS'
    assert collector.facts['all_ipv4_addresses'] == ['fe80::225:90ff:fe71:2842']
    assert collector.facts['all_ipv6_addresses'] == ['fe80::225:90ff:fe71:2842']
    assert collector.facts['default_ipv4']['address'] == '192.168.1.244'
    assert collector.facts['default_ipv4']['gateway'] == '192.168.1.1'
    assert collector.facts['default_ipv6']['address'] == 'fe80::225:90ff:fe71:2842'

# Generated at 2022-06-23 00:16:00.481383
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunosnetwork = SunOSNetwork()
    words = ['hme0:', 'flags=1000843', 'mtu', '1500']
    current_if = {'device': 'hme0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'hme0': current_if}
    current_if = sunosnetwork.parse_interface_line(words, current_if, interfaces)
    assert(current_if['ipv4'][0]['flags'] == '1000843')
    assert(current_if['ipv4'][0]['mtu'] == '1500')


# Generated at 2022-06-23 00:16:11.340073
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # First parameter is the path of the ifconfig executable.
    # Second parameter is the output of the command ifconfig -a
    # in a list form. Every element of the list is a string
    # representing a line.
    # Third parameter is the output of the command netstat -nr
    # in a list form. Every element of the list is a string
    # representing a line.
    fake = FakeSunOSModule('/tmp', FakeSunOSIfconfig_a_data.split('\n'), '')
    ifconfig_path = fake.get_bin_path('ifconfig', required=True)
    # Create a SunOSNetwork object
    sunos_network = SunOSNetwork(fake)
    # Generate the interfaces and ips facts
    interfaces, ips = sunos_network.get_interfaces_info(ifconfig_path)
   

# Generated at 2022-06-23 00:16:17.364587
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test for SunOS/illumos
    test_obj = SunOSNetwork()
    test_obj.module = None
    test_obj.module = MockModule()


# Generated at 2022-06-23 00:16:27.957935
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['all'], type='list')))
    gather_subset = ['all', 'min']
    SunOSNetworkCollector.collect(module=module, gather_subset=gather_subset)
    facts = module.params['ansible_facts']['ansible_network_resources']
    interfaces = facts['interfaces']
    assert 'lo0' in interfaces
    assert 'net0' in interfaces
    assert 'aggr0' in interfaces
    assert 'bge0' in interfaces
    assert 'igb1' in interfaces
    assert 'igb2' in interfaces
    assert 'igb3' in interfaces
    assert 'igb4' in interfaces
    lo0 = interfaces['lo0']
    assert 'ipv4'