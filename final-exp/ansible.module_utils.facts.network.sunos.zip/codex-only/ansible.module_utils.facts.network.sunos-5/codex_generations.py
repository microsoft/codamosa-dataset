

# Generated at 2022-06-23 00:06:37.022811
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """ Test SunOSNetwork.parse_ether_line()
    """

    # Test with valid 'ether' line
    line = 'ether 0:1:2:d:e:f'
    words = line.split()
    network = SunOSNetwork()
    ifconfig_path = '/sbin/ifconfig'
    interfaces = {}
    current_if = {'device': 'igb0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces[current_if['device']] = current_if
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Run parse_ether_line()
    network.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-23 00:06:46.579723
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:06:59.811721
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    sunos_network = SunOSNetwork(module)

    # Setup the fake ifconfig output

# Generated at 2022-06-23 00:07:09.629576
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test = SunOSNetwork()
    test_iface = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    test.parse_ether_line(['ether', '0:16:3e:56:22:70'], test_iface, ips)
    assert test_iface['macaddress'] == '00:16:3e:56:22:70'

# Generated at 2022-06-23 00:07:18.915167
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec=dict())
    iface = {}
    n = SunOSNetwork(module)
    n.parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232'], iface, {})
    assert iface['device'] == 'lo0'
    assert iface['type'] == 'loopback'
    assert iface['ipv4'] == [{'flags': '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu': '8232'}]
    assert iface['ipv6'] == []
    # Add IPV6
    iface = {}
   

# Generated at 2022-06-23 00:07:23.969826
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:07:36.677211
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''Unit test for method get_interfaces_info of class SunOSNetwork
    '''
    # Inventory:
    #   sunos:
    #     hosts:
    #       localhost:
    #         ansible_python_interpreter: /usr/bin/python3
    #
    # ntp_facts.yml playbook:
    # - name: Collect facts from a SunOS host
    #   hosts: sunos
    #   gather_facts: no
    #   tasks:
    #     - name: Display all interfaces
    #       debug:
    #         var: ansible_network_interfaces
    #     - name: Display all IPv4 addresses
    #       debug:
    #         var: ansible_all_ipv4_addresses
    #     - name: Display all IPv6 addresses
    #       debug

# Generated at 2022-06-23 00:07:38.029401
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()


# Generated at 2022-06-23 00:07:45.685857
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mod = GenericBsdIfconfigNetwork(dict(module=None))
    mod.platform = 'SunOS'
    mod._facts_cache = dict()
    mod.get_interfaces_info = lambda x: dict(interfaces={}, ips=dict())
    net_facts = mod.populate()
    assert net_facts['interfaces'] == {}
    assert net_facts['all_ipv4_addresses'] == []
    assert net_facts['all_ipv6_addresses'] == []



# Generated at 2022-06-23 00:07:54.930999
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    ifconfig_path = 'path/to/ifconfig'
    words = ['lo0:4', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>', 'mtu', '8232']
    current_if = {}
    interfaces = {}

    class MockIfconfigModule():
        def __init__(self):
            self.run_command_g = None
        def run_command(self, args):
            self.run_command_g = args

    ifconfig = SunOSNetwork()
    ifconfig.module = MockIfconfigModule()
    current_if = ifconfig.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'] == []
   

# Generated at 2022-06-23 00:08:01.963065
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    class MockedModule:
        run_command = lambda self, arg: (0, '', '')
    def test_parse_interface_line(self, words, current_if, interfaces):
        device = words[0][0:-1]
        if device not in interfaces:
            current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
        else:
            current_if = interfaces[device]
        flags = self.get_options(words[1])
        v = 'ipv4'
        if 'IPv6' in flags:
            v = 'ipv6'
        if 'LOOPBACK' in flags:
            current_if['type'] = 'loopback'

# Generated at 2022-06-23 00:08:06.839489
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.__bases__[0] == NetworkCollector
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-23 00:08:09.296222
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())
    network = SunOSNetwork(module)
    assert network


# Generated at 2022-06-23 00:08:18.760759
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    iface = {'device': 'en0', 'macaddress': 'unknown', 'type': 'unknown', 'ipv4': [{'mtu': 1500, 'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'IPv4']}], 'ipv6': []}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    words = ['ether', '0:1:2:3:4:5']
    sunos_network.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '00:01:02:03:04:05'

    # Test 'ethernet' instead of 'ether'


# Generated at 2022-06-23 00:08:25.679372
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = "ifconfig"
    kwargs = {
        'module': object(),
        'ifconfig_path': ifconfig_path
    }
    iface_name = 'net0'

# Generated at 2022-06-23 00:08:38.332283
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = type('module', (object,), {"run_command": run_command})()

    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    test_output = load_fixture('ifconfig_SunOS', data_dir)

    def run_command(cmd, check_rc=True):
        return test_output

    interface_collector = SunOSNetwork(test_module)
    interfaces_list = interface_collector.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-23 00:08:41.080314
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    '''
    Test constructor of class SunOSNetwork
    '''
    sn = SunOSNetwork()
    assert sn.platform == 'SunOS'

# Generated at 2022-06-23 00:08:45.495190
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    results = {'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    SunOSNetwork().parse_ether_line(['ether', '0:1:2:d:e:f'], results, {})
    assert results['macaddress'] == '00:01:02:0D:0E:0F'

# Generated at 2022-06-23 00:08:46.964496
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    n = SunOSNetworkCollector()
    assert n.platform == 'SunOS'


# Generated at 2022-06-23 00:08:59.030042
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    sunos_network = SunOSNetwork()
    macaddress = 'unknown'
    device = 'lo0'
    interfaces, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')
    current_if = {'device': device}
    flags = sunos_network.get_options('UP')
    v = 'ipv4'
    current_if[v].append({'flags': flags, 'mtu': '0'})
    current_if[v] = ({'flags': flags, 'mtu': '0', 'macaddress': macaddress})
    assert interfaces[device] == current_if

# Generated at 2022-06-23 00:09:10.871136
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    gi = SunOSNetwork()

    test1 = gi.get_interfaces_info('/sbin/ifconfig')

    interfaces = test1[0]
    ips = test1[1]

    assert interfaces['e1000g0']['device'] == 'e1000g0'
    assert interfaces['e1000g0']['ipv4'][0]['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4']
    assert interfaces['e1000g0']['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-23 00:09:19.912156
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Check the output of get_interfaces_info() method of SunOSNetwork class.
    """
    mock_module = Mock()

# Generated at 2022-06-23 00:09:20.409189
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    pass

# Generated at 2022-06-23 00:09:25.218857
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    network_collector = SunOSNetworkCollector(None)
    network = network_collector.get_facts()["ansible_net_interfaces"]

# Generated at 2022-06-23 00:09:37.693693
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    test_iface_config = """
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000 
bge0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
        inet 192.168.0.2 netmask ffffff00 broadcast 192.168.0.255
        ether 0:1:2:d:e:f
        options=23<RXCSUM,TXCSUM,VLAN_MTU>
"""

# Generated at 2022-06-23 00:09:40.732667
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    test_data = SunOSNetworkTestData()

    interfaces_info = SunOSNetwork(test_data.mock_module).get_interfaces_info('/sbin/ifconfig')

    assert interfaces_info == test_data.interfaces_info


# Generated at 2022-06-23 00:09:43.723580
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    my_obj = SunOSNetwork()
    assert my_obj.facts == {}
    assert my_obj._platform == 'SunOS'
    assert my_obj.ifconfig_path == '/sbin/ifconfig'
    assert my_obj.netstat_path == '/usr/bin/netstat'


# Generated at 2022-06-23 00:09:52.807545
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = 'bge0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2'.split()
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    print("current_if:", current_if)
    interfaces[current_if['device']] = current_if

    words = 'bge0: flags=2000843<UP,BROADCAST,RUNNING,MULTICAST,IPv6,Autoconfig> mtu 1500 index 2'.split()
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    print("current_if:", current_if)

# Generated at 2022-06-23 00:10:05.234275
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # create a test module
    import ansible.module_utils.facts.test_network
    test_module = ansible.module_utils.facts.test_network.TestNetwork()

    # create an instance of SunOSNetwork
    net = SunOSNetwork(test_module)

    # set values for testing

# Generated at 2022-06-23 00:10:17.979857
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:10:25.445667
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = None
    class_to_test = SunOSNetwork(module)
    interfaces_test = class_to_test.get_interfaces_info("ifconfig")
    assert class_to_test.platform == 'SunOS'
    assert interfaces_test is not None
    assert class_to_test.parse_interface_line("ifconfig", "ifconfig", "ifconfig") is not None
    assert class_to_test.parse_ether_line("ifconfig", "ifconfig", "ifconfig") is not None
    assert class_to_test.parse_lladdr_line("ifconfig", "ifconfig", "ifconfig") is not None
    assert class_to_test.parse_nd6_line("ifconfig", "ifconfig", "ifconfig") is not None

# Generated at 2022-06-23 00:10:38.448439
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = 'tests/unit/module_utils/facts/network/sunos_ifconfig.txt'
    with open(ifconfig_path, 'r') as ifconfig:
        output = ifconfig.read()


# Generated at 2022-06-23 00:10:50.172821
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # Data to be used when testing the method
    words = [
        "cassini0:",
        "flags=3102<BROADCAST,MULTICAST,SIMPLEX>",
        "mtu=1500",
        "index=7",
        "inet6",
        "fe80::2e0:f0ff:feaa:6ec",
        "prefixlen=64",
        "scopeid=0x3",
        "ether",
        "8:0:20:aa:6e:c",
        "idprom",
        "hwaddr=8:0:20:aa:6e:c"
    ]

    # Define the assumption we would like to test

# Generated at 2022-06-23 00:10:59.103857
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    # Constructor creates object of type SunOSNetwork
    sunos_network_facts = SunOSNetwork({})
    assert isinstance(sunos_network_facts, SunOSNetwork)

    # 'facts' variable is a dict
    assert isinstance(sunos_network_facts.facts, dict)

    # 'facts' dict contains 'devices' and 'all_ipv4_addresses'
    assert 'devices' in sunos_network_facts.facts
    assert 'all_ipv4_addresses' in sunos_network_facts.facts

    # 'facts' dict contains list in 'devices'
    assert isinstance(sunos_network_facts.facts['devices'], list)

# Generated at 2022-06-23 00:11:06.295710
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch

    with patch('ansible.module_utils.facts.network.sunos.SunOSNetwork.get_interfaces_info') as get_interfaces_info:
        SunOSNetwork.get_interfaces_info(None)
        get_interfaces_info.assert_called_with(None)

# Generated at 2022-06-23 00:11:18.592575
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    print('Testing parse_ether_line of class SunOSNetwork')
    sun_net = SunOSNetwork()
    test = {'device': 'test', 'ipv4': [], 'ipv6': [], 'type': 'unknown',
            'macaddress': 'unknown'}
    mac_line = ['ether', '0:1:2:d:e:f', 'test', '55555']
    test = sun_net.parse_ether_line(mac_line, test, {})
    if test['macaddress'] == '00:01:02:0d:0e:0f':
        print("SUCCESS")
    else:
        print("FAIL: Expected '00:01:02:0d:0e:0f' but got '" + test['macaddress'] + "'")


# Generated at 2022-06-23 00:11:20.498893
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:11:29.489413
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # Ensure that get_interfaces_info() can handle multiple IPv4 and IPv6 addresses and
    # FLAGS, MTU, MAC and other interface information can be collected.
    # Note: There is no way to tell if IPv4 and IPv6 addresses are on the same interface
    # without looking at the FLAGS and MTU. Solaris uses the same device name for IPv4 and
    # IPv6 addresses on the same interface but the MTU and FLAGS can differ so
    # get_interfaces_info() will create a separate 'current_if' for each unique combination.
    # This mock ifconfig output is for six interfaces, two of which are for loopback.

    ifconfig_path = '/usr/sbin/ifconfig'

# Generated at 2022-06-23 00:11:42.860469
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = DummyAnsibleModule()
    result = SunOSNetwork(module)
    interfaces = result.pop('interfaces')
    ips = result.pop('all_ipv4_addresses')
    assert result == {
        'default_ipv4_interface': 'vnic0',
        'default_ipv6_interface': None,
        'default_interface': 'vnic0',
        'dhcp4': False,
        'dhcp6': False,
        'interfaces': []
    }

# Generated at 2022-06-23 00:11:48.879411
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    line = 'ether 1:a:b:c:d:e'
    words = line.split()
    current_if = {}
    ips = {}

    test_object = SunOSNetwork()

    test_object.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == '1:a:b:c:d:e'

# Generated at 2022-06-23 00:11:59.859452
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    parser = SunOSNetwork()
    assert parser.parse_interface_line(['en0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500'], {}, {}) == \
        {'device': 'en0', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-23 00:12:09.240947
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # create a test object
    network = SunOSNetwork()
    # create a test dict
    current_if = {'device': 'device', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    # create a test list
    words = ['ether', '0:d:e:f:1:2']
    # call the method
    network.parse_ether_line(words, current_if, {})
    # compare the MAC address obtained with the expected value
    assert current_if['macaddress'] == '00:0d:0e:0f:01:02'


# Generated at 2022-06-23 00:12:15.277296
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork
    assert collector.fact_subdir == 'SunOS'
    assert collector.primary_find_method == '_find_by_default_route'

# Generated at 2022-06-23 00:12:27.686743
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork({})
    assert m.parse_interface_line(['lo0:'], {}, {}) == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    assert m.parse_interface_line(['ether0:'], {}, {}) == {'device': 'ether0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-23 00:12:30.120983
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    network_object = SunOSNetwork()
    assert network_object.platform == 'SunOS'


# Generated at 2022-06-23 00:12:33.855033
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('FakeModule', (object,), {'run_command': lambda *_: ['', '', 0]})()
    SunOSNetwork(module).populate()

# Generated at 2022-06-23 00:12:39.518883
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    line = 'eri0: flags=3008<POINTOPOINT,LINK1,RUNNING,NOARP,MULTICAST> mtu 1500 index 4\n'
    words = line[0:-1].split()
    current_if = {}
    interfaces = {}
    current_if = SunOSNetwork.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'eri0'
    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'][0]['flags'] == ['POINTOPOINT', 'LINK1', 'RUNNING', 'NOARP', 'MULTICAST']
    assert current_if['ipv4'][0]['mtu'] == '1500'
    assert current_if['ipv6'] == []

   

# Generated at 2022-06-23 00:12:47.439046
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_input = ['ether', '0:1:2:d:e:f']
    test_current_if = dict()
    test_ips = dict()
    test_output = dict()
    test_class = SunOSNetwork()
    test_class.parse_ether_line(test_input, test_current_if, test_ips)
    test_output = dict()
    test_output['macaddress'] = '00:01:02:0d:0e:0f'
    assert test_current_if == test_output


# Generated at 2022-06-23 00:12:50.474852
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})
    collector = SunOSNetworkCollector(module)
    assert collector.get_device_name('lo0') == 'lo0'

# Generated at 2022-06-23 00:12:51.434429
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-23 00:13:03.958068
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Construct SunOSNetwork object and test if it
    have all required methods.
    """
    sunos_network = SunOSNetwork({}, None)

# Generated at 2022-06-23 00:13:15.580583
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork(dict(module=dict()))
    current_if = {}
    facts = {}
    words = ['ether', '0:1:2:d:e:f']
    words2 = ['ether', '01:02:03:04:05:06']
    # Check that leading zero is added to each octet
    m.parse_ether_line(words, current_if, facts)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f', 'MAC address incorrectly parsed'
    # Check case where leading zero not needed
    m.parse_ether_line(words2, current_if, facts)
    assert current_if['macaddress'] == '01:02:03:04:05:06', 'MAC address incorrectly parsed'

# Generated at 2022-06-23 00:13:28.408770
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('module', (object,), {})
    module.run_command = fake_run_command

    n = SunOSNetwork(module)

    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849&lt;UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL&gt;', 'mtu', '8232']
    current_if = n.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:13:40.547519
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test object initialization
    test_obj = SunOSNetwork({"module_name": "test_module"})
    # Test variables
    words = ['hme0', '[UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST]', 'mtu', '1500']
    current_if = {}
    interfaces = {}

    # Unit test execution
    result_current_if = test_obj.parse_interface_line(words, current_if, interfaces)
    # Unit test evaluation
    assert 'hme0' in result_current_if, "First element of 'words' is missing in 'current_if' dict"
    assert 'ipv4' in result_current_if, "'ipv4' is missing in 'current_if' dict"

# Generated at 2022-06-23 00:13:43.765015
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-23 00:13:52.479249
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

    network_module = SunOSNetwork()

    rc, out, err = network_module.module.run_command([SunOSNetworkCollector._fact_class.base_command, '-a'])
    interfaces, ips = SunOSNetworkCollector._fact_class.get_interfaces_info(SunOSNetworkCollector._fact_class.base_command)

    assert rc == 0

    # test that 'interfaces' is a dictionary of dictionaries
    assert isinstance(interfaces, dict)

    # test that 'interfaces' has expected content
    assert interfaces[list(interfaces.keys())[0]]['device'] == 'lo0'

# Generated at 2022-06-23 00:14:03.058977
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    data = dict()
    data['ansible_net_hostname'] = 'dell_r620_01'
    data['ansible_net_version'] = '10.3'
    data['ansible_net_serialnum'] = 'VMware-56 4d c8 54 3c d5 f7 a3-da 81 54 4a dd fc e9 ef'
    data['ansible_net_model'] = 'VMware Virtual Platform'
    data['ansible_net_memtotal_mb'] = 6124
    data['ansible_net_memfree_mb'] = 3485
    data['ansible_net_membuffer_mb'] = 0
    data['ansible_net_memcache_mb'] = 0


# Generated at 2022-06-23 00:14:14.050539
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    words = ['ether', '0:1:2:d:e:f']
    current_if = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    facts = SunOSNetwork()
    facts.parse_ether_line(words, current_if, ips)
    assert facts.interfaces['e1000g0']['macaddress'] == '00:01:02:0d:0e:0f'

if __name__ == '__main__':
    test_SunOSNetwork_parse_ether_line()

# Generated at 2022-06-23 00:14:26.891676
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    macaddress = '00:01:02:3D:E5:E6'
    words = ['ether', '0:1:2:3d:e5:e6', '<broadcast,multicast,up>']
    current_if = {'device': 'e1000g0', 'ipv4': [{'flags': [], 'mtu': '1500'}], 'ipv6': [], 'type': 'ether'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    sunos_network = SunOSNetwork()
    sunos_network.parse_ether_line(words, current_if, ips)
    assert macaddress == current_if['macaddress']

# Generated at 2022-06-23 00:14:35.321585
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mock_module = MockModule()
    sunos_network = SunOSNetwork(mock_module)

    # Test some properties of the class
    assert sunos_network.platform == "SunOS"
    assert sunos_network.interfaces_key == "SunOS_interfaces"
    assert sunos_network.addresses_key == "SunOS_all_ipv4_addresses"
    assert sunos_network.gateways_key == "SunOS_default_gateway_ipv4"

# Generated at 2022-06-23 00:14:40.416292
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.__doc__ == NetworkCollector.__doc__

# Generated at 2022-06-23 00:14:42.176438
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    testobj = SunOSNetwork({})

    assert testobj.platform == 'SunOS'

# Generated at 2022-06-23 00:14:54.821495
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_if = SunOSNetwork()
    test_if['ipv4'] = []
    test_if['ipv6'] = []
    test_if['macaddress'] = ''
    test_if['type'] = 'unknown'
    test_if_config = test_if['ipv4'].append({'flags': '', 'mtu': ''})
    test_words = ['lo0:', 'flags=2001000849', 'mtu', '8232']
    test_if = test_if.parse_interface_line(test_words, test_if, test_if_config)
    assert test_if['ipv4'][0]['flags'] == '2001000849'
    assert test_if['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-23 00:15:07.075191
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = SunOSNetworkCollector._create_module()
    sunosnet = SunOSNetwork()

# Generated at 2022-06-23 00:15:08.346244
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork({}, dict(module=dict()), dict(path=dict()))


# Generated at 2022-06-23 00:15:20.617430
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    current_if = SunOSNetwork().parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232'], current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert len(current_if['ipv4']) == 1
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']
    assert current_if

# Generated at 2022-06-23 00:15:33.507134
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    facts = SunOSNetwork()
    interfaces_info = facts.get_interfaces_info()[0]
    interfaces = list(interfaces_info.keys())
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces_info
    assert 'ipv4' in interfaces_info['lo0']
    assert 'ipv6' in interfaces_info['lo0']
    if 'lo0' in interfaces:
        assert 'lo0' in interfaces_info
        assert interfaces_info['lo0']['ipv4'][0]['address'] == '127.0.0.1'
        assert interfaces_info['lo0']['ipv4'][0]['netmask'] == '255.0.0.0'

# Generated at 2022-06-23 00:15:36.902305
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_module = SunOSNetworkCollector()
    assert fact_module._platform == 'SunOS'
    assert fact_module._fact_class == SunOSNetwork
    assert fact_module._network._platform == 'SunOS'

# Generated at 2022-06-23 00:15:39.482192
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collected_facts = dict()
    collector = SunOSNetworkCollector(None, collected_facts)
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 00:15:44.474651
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    interfaces = collector.get_interfaces_info('/sbin/ifconfig')[0]
    for device in interfaces:
        interface = interfaces[device]
        assert(interface['device'] == device)
        if interface['device'] == 'lo0':
            assert(interface['mtu'] == 8232)
            assert(interface['ipv4'][0]['address'] == '127.0.0.1')
            assert(interface['type'] == 'loopback')



# Generated at 2022-06-23 00:15:57.143836
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))
            self.params = dict()

    class MockFactClass(object):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-23 00:16:08.708055
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-23 00:16:21.242719
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork({})
    assert sunos_network.facts['all_ipv4_addresses'] == []
    assert sunos_network.facts['default_ipv4']['address'] == '127.0.0.1'
    assert sunos_network.facts['default_ipv4']['gateway'] == '10.0.0.1'
    assert sunos_network.facts['default_ipv6']['address'] == '::1'
    assert sunos_network.facts['default_ipv6']['gateway'] == 'fe80::a00:27ff:fe34:d6de'
    assert sunos_network.facts['interfaces'] == ['eth0', 'lo0']

# Generated at 2022-06-23 00:16:26.597762
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    machine = type('Foo', (object,), {})
    module = type('Bar', (object,), {})
    module.params = {}
    module.run_command = lambda *args: (0, 'out', 'err')
    module.get_bin_path = lambda *args: 'ifconfig'
    facts = SunOSNetwork(machine, module)
    assert facts.platform == 'SunOS'