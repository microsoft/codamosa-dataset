

# Generated at 2022-06-23 00:06:36.499635
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    testinput = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1", [{}, {}], {'all_ipv4_addresses': []}

    testwords = testinput[0].split()
    current_if = testinput[1]
    interfaces = testinput[2]

    test_obj = SunOSNetwork()
    testoutput = test_obj.parse_interface_line(testwords, current_if, interfaces)

    assert testoutput['device'] == "lo0"
    assert testoutput['type'] == "loopback"
    assert len(testoutput['ipv4']) == 1

# Generated at 2022-06-23 00:06:45.615963
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    'interfaces', 'ipv4' and 'ipv6' facts were moved inside the 'ipv4' and 'ipv6'
    lists in the SunOS Network Class. This unit test was modified to handle
    these changes.

    If rewriting, keep in mind that Solaris can have different FLAGS, MTU and
    ethernet addresses for IPv4 and IPv6 on the same interface.
    """
    """Simple test for get_interfaces_info."""
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all'], type='list')
    })

    ifconfig_path = module.get_bin_path('ifconfig', True)

    fact_class = SunOSNetwork()

# Generated at 2022-06-23 00:06:47.600864
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork(dict(module=True)).collect()

# Generated at 2022-06-23 00:06:49.593550
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)


# Generated at 2022-06-23 00:07:01.451506
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    iface = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # Parse IPv4 interface line
    words = [
        'lo0:',
        'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
        'mtu 8232',
    ]
    current_if = SunOSNetwork().parse_interface_line(words, iface, interfaces)

# Generated at 2022-06-23 00:07:12.676194
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    ips = {}
    testobj = SunOSNetwork()

    # Normal operation
    words = ['ether', '0:1:2:3:4:5']
    testobj.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

    # Add leading zero when needed
    words = ['ether', '0:0:2:3:4:f']
    testobj.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:00:02:03:04:0f'

# Generated at 2022-06-23 00:07:20.614546
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    ips = {}
    module = None
    sunos_network = SunOSNetwork(module=module)

    # Test single digit MAC octets
    words = ['ether', '0:1:2:d:e:f']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    # Test double digit MAC octets - should not change
    current_if = {}
    words = ['ether', '00:aa:bb:11:22:33']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:aa:bb:11:22:33'

# Generated at 2022-06-23 00:07:29.291022
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.network.base import TestNetworkCollector
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.network.generic_bsd import TestGenericBsdIfconfigNetwork

    TestGenericBsdIfconfigNetwork.test_GenericBsdIfconfigNetwork_get_interfaces_info(SunOSNetwork, null_args_string='-a')


# Generated at 2022-06-23 00:07:35.743319
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    # test constants
    ifconfig_path = 'fake_path'
    module = 'fake_module'

    # create test object
    sunos_network_facts = SunOSNetwork(module, ifconfig_path)

    # test '_fact_class'
    assert sunos_network_facts._fact_class == 'SunOS'

    # test '_platform'
    assert sunos_network_facts._platform == 'SunOS'

# Generated at 2022-06-23 00:07:47.451527
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:07:48.426423
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'


# Generated at 2022-06-23 00:07:58.441113
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # Create a SunOSNetwork object for testing
    network = SunOSNetwork()

    # Set up test data
    # The 'current_if' dictionary will be changed by SunOSNetwork.parse_interface_line()
    # so we need a copy for each test.

# Generated at 2022-06-23 00:08:11.387104
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:08:20.512643
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import json
    import os
    basedir = os.path.dirname(__file__)
    fname = os.path.join(basedir, 'data', 'ifconfig_sunos.txt')
    f = open(fname, 'r')
    ifconfig_out = f.read()
    f.close()
    fname = os.path.join(basedir, 'data', 'interfaces_sunos.json')
    f = open(fname, 'r')
    fact_out = json.load(f)
    f.close()

    # Create a fake module object with a appropriate parameters
    class MockModule:
        def __init__(self):
            self.params = {}
        def run_command(self, args):
            return (0, ifconfig_out, None)
    module = MockModule()

# Generated at 2022-06-23 00:08:29.250657
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork({})
    current_if = {'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    # Solaris output
    words = ['ether', '0:1:2:d:e:f']
    result = network.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:08:40.148024
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Instantiate the module with its argument specification
    module = AnsibleModule(argument_spec={})

    # Instantiate the class we want to test
    sunos_network = SunOSNetwork(module)

    # Test non-vlan
    words = ['net0:', 'flags=2001000849', 'mtu=1500', 'index=3', 'inet6', '=::1/128', 'zone']
    interfaces = {}
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': 'net0', 'ipv4': [], 'ipv6': [{'flags': '2001000849', 'mtu': '1500'}], 'type': 'unknown'}
    assert current_if['ipv4'] == []
    assert current_

# Generated at 2022-06-23 00:08:46.622426
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create and initialize SunOSNetwork class
    sunos_network = SunOSNetwork()
    sunos_network._facts['all_ipv4_addresses'] = []
    sunos_network._facts['all_ipv6_addresses'] = []
    # Create and initialize current_if
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    # Create and initialize words
    words = ['ether', '0:1:2:3:e:f']

    # Call parse_ether_line()
    sunos_network.parse_ether_line(words, current_if, sunos_network._facts)

    # Verify that current_if['macaddress'] has the correct value

# Generated at 2022-06-23 00:08:59.793460
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    lines_1 = '''
lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        inet6 ::1/128
        inet6 fe80::1/10
options=30003<RXCSUM,TXCSUM>
'''

# Generated at 2022-06-23 00:09:05.113569
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Check if we can instantiate SunOSNetworkCollector class."""
    try:
        SunOSNetworkCollector()
    except Exception as e:
        assert False, "Testcase for class SunOSNetworkCollector failed. Error: %s" % e.message
    assert True, "Testcase for class SunOSNetworkCollector passed."


# Generated at 2022-06-23 00:09:08.951303
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    facts = SunOSNetwork({'ansible_network_os': 'SunOS'})
    assert facts.get_device_facts() == {'devices': {}}



# Generated at 2022-06-23 00:09:12.002768
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('module', (object,), {})()
    module.params = {'gather_subset': ['all'], 'gather_network_resources': ['all']}
    SunOSNetwork(module=module)

# Generated at 2022-06-23 00:09:20.668028
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MagicMock()
    network = SunOSNetwork(module)

    # test interface with a single line
    words = 'qfe0:  flags=1004841<UP,LOOPBACK,RUNNING,MULTICAST,DHCP,IPv4> mtu 8232 index 2'.split()
    current_if = {'device': 'qfe0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'qfe0': {'device': 'qfe0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'qfe0'

# Generated at 2022-06-23 00:09:33.687394
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # invocation:
    # python -m ansible_fact_collection.facts.network.SunOS.test_SunOSNetwork_get_interfaces_info
    from ansible.module_utils.facts.network.SunOS.SunOSNetwork import SunOSNetwork
    import sys
    SUNOS64_IFCONFIG = "/usr/sbin/ifconfig"
    SUNOS32_IFCONFIG = "/usr/sbin/../sbin/ifconfig"
    if not os.path.exists(SUNOS64_IFCONFIG):
        if not os.path.exists(SUNOS32_IFCONFIG):
            sys.stderr.write("No ifconfig found on this system")
        else:
            SUNOS64_IFCONFIG = SUNOS32_IFCONFIG
    s = SunOSNetwork()

# Generated at 2022-06-23 00:09:39.189719
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list'),
            'gather_network_resources': dict(default='yes', type='str')
        }
    )

    facts_obj = SunOSNetworkCollector(module)
    assert facts_obj.__class__.__name__ == 'SunOSNetworkCollector'

# Generated at 2022-06-23 00:09:49.691821
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    "Test SunOSNetwork.parse_interface_line"
    # SunOSNetwork.parse_interface_line
    # This method is run against every "interfaces:" line that ifconfig prints.
    # The line is split into words, which we provide as an argument.
    # The method parses the line and modifies the 'current_if' dict in place.
    # This test checks that 'current_if' contains the correct values at the end.
    # 'current_if' is a dict containing name and settings of the last interface
    # seen. When the first interface is seen, it is initialised with the following
    # values:
    # current_if['device'] = 'lo0'
    # current_if['type'] = 'unknown'
    # current_if['macaddress'] = 'unknown'
    # current_if['ipv4'] =

# Generated at 2022-06-23 00:09:56.510821
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    generic_bsd_network_fixture = 'tests/fixtures/network/sunos/fixture_ifconfig_a_output.txt'
    sunos_network_fixture = 'tests/fixtures/network/sunos/fixture_ansible_facts.json'

    generic_bsd_network_instance = GenericBsdIfconfigNetwork(module=dict())
    ifconfig_path = 'tests/fixtures/network/sunos/fixture_ifconfig_path'
    interfaces, ips = generic_bsd_network_instance.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-23 00:10:08.931751
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_if = {'ipv4': [], 'device': 'lo0',
               'ipv6': [], 'macaddress': '00:00:00:00:00:00', 'type': 'unknown'}
    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    my_obj = SunOSNetwork()
    my_obj.parse_ether_line(['ether', '0:1:2:d:e:f'], test_if, test_ips)
    assert test_if == {'ipv4': [], 'device': 'lo0',
                       'ipv6': [], 'macaddress': '00:00:00:02:0d:0e:0f', 'type': 'unknown'}

# Generated at 2022-06-23 00:10:20.857015
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    arguments = dict(
        resource_facts_gather_timeout=100,
        ansible_facts={'ansible_net_gather_network_resources': 1}
    )
    mock_module = type('MockModule', (object,), arguments)
    network = SunOSNetwork(mock_module)


# Generated at 2022-06-23 00:10:29.890762
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ansible_module = MagicMock()
    ansible_module.run_command.return_value = (0, "", "")
    ansible_module.get_bin_path.return_value = "/sbin/ifconfig"
    sunos_network_collector = SunOSNetworkCollector(ansible_module)

    assert(sunos_network_collector.platform == 'SunOS')
    assert(sunos_network_collector._fact_class == SunOSNetwork)
    print("Test for SunOSNetworkCollector constructor is passed")


# Generated at 2022-06-23 00:10:40.818978
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    result = SunOSNetwork().parse_interface_line(['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232'],  # noqa
                                                 {}, {})
    assert result['device'] == 'lo0'
    assert result['type'] == 'loopback'
    assert result['ipv4'] == [{'flags': 'UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL', 'mtu': '8232'}]
    assert result['ipv6'] == []
    assert result['macaddress'] == 'unknown'

# Generated at 2022-06-23 00:10:52.109398
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    data = SunOSNetwork()
    # Test for invalid MAC address.
    ifdata = {'device': 'e1000g0', 'ipv4': [{'mtu': '1500', 'flags': ['BROADCAST,MULTICAST,IPv4']}],
              'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    input_data = ['ether', '0:0:0:0:0:0']
    output_data = data.parse_ether_line(input_data, ifdata, {})
    assert output_data['macaddress'] == '00:00:00:00:00:00'

    # Test for valid MAC address.

# Generated at 2022-06-23 00:10:53.381619
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector().get_network_collector(), SunOSNetworkCollector)


# Generated at 2022-06-23 00:10:59.967812
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = None
    current_if = {}
    ips = {}
    sunosnetwork = SunOSNetwork(module, 'ifconfig_path')
    words = [
        'ether', '0:1:2:d:e:f'
    ]
    assert sunosnetwork.parse_ether_line(words, current_if, ips) == {'macaddress': '00:01:02:0d:0e:0f'}

# Generated at 2022-06-23 00:11:06.349380
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    network = SunOSNetwork()
    assert network
    assert network.platform == 'SunOS'
    assert network.get_interfaces_info
    assert network.get_default_interface
    assert network.get_interfaces_ipv4_addresses
    assert network.get_interfaces_ipv6_addresses


# Generated at 2022-06-23 00:11:11.154540
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_data = ['lo0:2: flags=2001000849 metric 0 mtu 8232 index 2',
                 'lo0:3: flags=2001000849 metric 0 mtu 8232 index 2',
                 'lo0:4: flags=2001000849 metric 0 mtu 8232 index 2',
                 'lo0:5: flags=2001000849 metric 0 mtu 8232 index 2',
                 'lo0:6: flags=2001000849 metric 0 mtu 8232 index 2']

# Generated at 2022-06-23 00:11:15.747453
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class == SunOSNetwork


# Generated at 2022-06-23 00:11:20.178064
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'
    assert network_collector._network_class == SunOSNetwork

# Generated at 2022-06-23 00:11:26.390166
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    When given correct input, parse_ether_line()
    returns a properly formatted MAC address.
    """
    sn = SunOSNetwork()
    current_if = {}
    ips = {}
    input = ['ether', '0:1:2:d:e:f']
    sn.parse_ether_line(input, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:11:28.424369
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # TODO: add a unit test for this method.
    pass  # We do not test this, because the output of ifconfig can vary



# Generated at 2022-06-23 00:11:41.664893
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Unit test for method 'SunOSNetwork.get_interfaces_info'
    """
    # instantiate class SunOSNetwork
    sunos_network = SunOSNetwork()

    # set test data
    # The test data for 'get_interfaces_info' is a single line taken from ifconfig -a

# Generated at 2022-06-23 00:11:47.150210
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    testclass = SunOSNetwork()
    testclass.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    result = testclass.interfaces['unknown']
    assert result['macaddress'] == '00:01:02:0d:0e:0f'



# Generated at 2022-06-23 00:11:56.020236
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_instance = SunOSNetwork()

    test_device = 'lo0'
    test_flags = 'UP,LOOPBACK,RUNNING,MULTICAST'
    test_words = ['lo0:', test_flags, 'mtu', '8232', 'index', '3']
    test_current_if = {}
    test_interfaces = {}

    expected_return_value = {'device': test_device, 'ipv4': [{'flags': test_flags, 'mtu': '8232'}],
                             'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

    return_value = test_instance.parse_interface_line(test_words, test_current_if, test_interfaces)
    assert return_value == expected_return_value


# Unit

# Generated at 2022-06-23 00:12:09.750487
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # prepare the test
    test_class = SunOSNetwork
    current_if = {}
    interfaces = {}

    # run the test
    words = ['bge1:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = test_class.parse_interface_line(words, current_if, interfaces)

    # verify results
    assert 'bge1' == current_if['device']
    assert ['1500'] == [x['mtu'] for x in current_if['ipv4']]
    assert ['1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>'] == [x['flags'] for x in current_if['ipv4']]
    assert [] == current_if

# Generated at 2022-06-23 00:12:22.804138
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    line = 'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'
    words = line.split()
    current_if = {}
    interfaces = {}
    network_info = SunOSNetwork()
    current_if = network_info.parse_interface_line(words, current_if, interfaces)
    assert current_if == {
        'ipv4': [{
            'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4'],
            'mtu': '8232'
        }],
        'device': 'lo0',
        'ipv6': [],
        'macaddress': 'unknown',
        'type': 'loopback'
    }

# Generated at 2022-06-23 00:12:27.351041
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector.fact_class.platform == 'SunOS'
    assert SunOSNetworkCollector().platform == 'SunOS'
    assert SunOSNetworkCollector().fact_class.platform == 'SunOS'

# Generated at 2022-06-23 00:12:38.221366
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    words = ["ether", "a:b:c:d:e:f"]
    current_if = {}
    ips = {}

    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == "a:b:c:d:e:f"

    words = ["ether", "0:1:2:d:e:f"]
    current_if = {}
    ips = {}

    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == "00:01:02:d:e:f"

# Generated at 2022-06-23 00:12:49.131117
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:12:50.050576
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork is not None

# Generated at 2022-06-23 00:12:52.510099
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 00:13:04.571306
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeAnsibleModule()
    facts = SunOSNetwork(module)
    interfaces = {}
    current_if = {}
    current_if = facts.parse_interface_line(['fwe1:', 'flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu=8232'], current_if, interfaces)
    assert current_if['device'] == 'fwe1'
    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv6']) == 0
    assert current_if['ipv4'][0]['flags'] == '2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>'

# Generated at 2022-06-23 00:13:16.711879
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockAnsibleModule()
    nc = SunOSNetwork(module=module)

    # Test normal Solaris ifconfig output

# Generated at 2022-06-23 00:13:24.001096
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = AnsibleModuleStub()
    sunosnetwork = SunOSNetwork(module=module, command_config=None)
    current_if = {}
    ips = {}
    sunosnetwork.parse_ether_line(["ether", "0:1:2:d:e:f"], current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-23 00:13:36.230093
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    expected_result = (
        {'lo0': {
            'device': 'lo0',
            'ipv4': [{'flags': ['LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '8232'}],
            'ipv6': [{'flags': ['LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv6'], 'mtu': '8252'}],
            'macaddress': 'fe:0c:4d:4b:4a:4e',
            'type': 'loopback'
        }},
        {'all_ipv4_addresses': [],
         'all_ipv6_addresses': []})

    module = FakeAnsibleModule()
    fact_class = SunOSNetwork

# Generated at 2022-06-23 00:13:38.928514
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork

# Generated at 2022-06-23 00:13:49.673392
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:14:01.814924
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeModule()
    result = {'ipv4': [], 'ipv6': [], 'type': 'unknown', 'device': 'lo0'}
    result['ipv4'].append({'flags': ['LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '8232'})
    assert SunOSNetwork(module).parse_interface_line(['lo0:', 'flags=2001000849', 'mtu', '8232'], {}, {}) == result
    result['ipv6'].append({'flags': ['LOOPBACK', 'RUNNING', 'IPV6', 'MULTICAST'], 'mtu': '8252'})
    result['type'] = 'loopback'

# Generated at 2022-06-23 00:14:06.346278
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    my_obj = SunOSNetworkCollector()
    assert my_obj
    assert isinstance(my_obj, SunOSNetworkCollector)
    assert issubclass(my_obj.__class__, NetworkCollector)


# Generated at 2022-06-23 00:14:16.541139
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test get_interfaces_info of class SunOSNetwork.
    """
    module = AnsibleModule(argument_spec=dict())
    test_obj = SunOSNetwork(module=module)
    # Ifconfig path
    ifconfig_path = module.get_bin_path('ifconfig', True)
    # Get interfaces and IPs information
    (interfaces, ips) = test_obj.get_interfaces_info(ifconfig_path)
    # Check if interfaces is a dictionary
    assert(isinstance(interfaces, dict))
    # Check if ips is a dictionary
    assert(isinstance(ips, dict))
    # Check type of all_ipv4_addresses
    assert(isinstance(ips['all_ipv4_addresses'], list))
    # Check type of all_ipv6_add

# Generated at 2022-06-23 00:14:27.497865
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Creates an instance of the test class
    test_instance = SunOSNetwork('module')

    # Creates an instance of the words list
    words = []

    # Creates an instance of the test facts
    test_facts = {}

    # Creates an instance of the ips dictionary
    ips = {}

    # The unit test
    test_instance.parse_ether_line(words, test_facts, ips)

    # Unit test assertions
    assert test_facts['macaddress'] != 'unknown'
    assert test_facts['macaddress'] == '00:01:02:0d:0e:0f'
    assert '0x0d' and '0x0e' and '0x0f' in test_facts['macaddress']

# Generated at 2022-06-23 00:14:33.443527
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    fixture_path = '../../../../lib/ansible/module_utils/facts/network/test_fixtures/'

# Generated at 2022-06-23 00:14:46.235358
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = dict(
        module=dict(
            params=dict(
                gather_subset=['!all']
            )
        )
    )
    n = SunOSNetwork(m)
    current_if = {}

    # Test correct parsing of MAC address
    words = 'ether 0:1:2:d:e:f'.split()
    n.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    # Test correct parsing of MAC address
    current_if = {}    # reset 'current_if'
    words = 'ether 7:1:2:3:4:5'.split()
    n.parse_ether_line(words, current_if, {})

# Generated at 2022-06-23 00:14:58.577505
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:15:08.463119
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    device = 'lo0'
    flags = 'UP,LOOPBACK,RUNNING,'
    mtu = '8232'
    words = [device + ':', flags, 'mtu', mtu]

    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == flags
    assert current_if['ipv4'][0]['mtu'] == mtu

# Generated at 2022-06-23 00:15:20.783295
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    current_if = {}
    interfaces = {}
    words = ['net0:', 'flags=1e080863,c0', '<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'mtu=1500']
    current_if = SunOSNetwork.parse_interface_line(module, words, current_if, interfaces)
    assert current_if == {'device': 'net0', 'ipv4': [{'flags': ['1e080863', 'c0'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:15:23.519672
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    nm = SunOSNetworkCollector(module)
    assert nm._platform == 'SunOS'


# Generated at 2022-06-23 00:15:24.800482
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()
    assert net is not None

# Generated at 2022-06-23 00:15:37.756249
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:15:44.907284
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:15:57.193309
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    sunos = SunOSNetwork(None)

    # parse_interface_line() returns a dict with keys:
    # 'device', 'ipv4', 'ipv6', 'type', 'macaddress'
    # each test case is a list of words, which is the output from 'ifconfig -a' split into a list
    # and the expected output, a dict described above

# Generated at 2022-06-23 00:16:00.194450
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    testobj = SunOSNetworkCollector()
    assert testobj
    assert testobj._fact_class == SunOSNetwork
    assert testobj._platform == 'SunOS'



# Generated at 2022-06-23 00:16:11.078752
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = dict(
        run_command=dict(return_value=(0, 'test_out', 'test_err')),
        params=dict(gather_subset=['interfaces']),
    )

    network_module = SunOSNetwork(test_module, 'test_ifconfig_path')

    # Mock ifconfig_path
    network_module.module.params['path'] = 'test_ifconfig_path'

    # Mock the output of ifconfig -a
    network_module.module.run_command.return_value = (0, test_ifconfig_out, 'test_err')

    # Assert that get_interfaces_info has the expected output

# Generated at 2022-06-23 00:16:15.731545
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    test_obj = SunOSNetwork()

    # run tests for multiple OS releases to ensure that the parsing logic is robust
    # and does not depend on OS versions.
    for test_str in [
        'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1',
        'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8252 index 1',
        'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,IPv6> mtu 8252 index 1',
    ]:
        words = test_str.split()
       

# Generated at 2022-06-23 00:16:20.556457
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    facts = SunOSNetworkCollector.collect()
    assert facts['network']['interfaces']['net0']['ipv4'][0]['netmask'] == '255.255.255.0'

# Generated at 2022-06-23 00:16:22.861068
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = FakeModule()
    network = SunOSNetwork(module)
    assert network.platform == 'SunOS'


# Generated at 2022-06-23 00:16:32.068209
# Unit test for method parse_interface_line of class SunOSNetwork