

# Generated at 2022-06-23 00:06:25.046660
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)

# Generated at 2022-06-23 00:06:36.160627
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import tempfile
    from StringIO import StringIO
    from ansible.module_utils.facts.network.base import NetworkCollector

    # ifconfig -a output from SmartOS

# Generated at 2022-06-23 00:06:41.094249
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_nw = SunOSNetwork()
    current_if = {'device': 'lo0'}
    ips = {}
    sunos_nw.parse_ether_line(['ether', '0:1:2:3:4:5'], current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-23 00:06:44.396505
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector()
    assert nc._fact_class is SunOSNetwork
    assert nc._platform == 'SunOS'


# Generated at 2022-06-23 00:06:49.690418
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces = []
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    current_if = {}
    t = SunOSNetwork()
    interfaces = t.get_interfaces_info(interfaces, current_if, ips)
    assert len(interfaces) > 0
    assert len(interfaces[0]) > 0


# Testing with a real Solaris 8 virtualbox image
import pytest


# Generated at 2022-06-23 00:07:01.484633
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos.facts import SunOSNetwork


# Generated at 2022-06-23 00:07:14.283091
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:07:21.649034
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:07:27.752149
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_obj = SunOSNetwork()
    test_obj.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    assert test_obj.interfaces['eth0']['macaddress'] == "00:01:02:0d:0e:0f"

# Generated at 2022-06-23 00:07:39.709607
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-23 00:07:50.321139
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.net_tools import NetTools
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    net_tools = NetTools()

    # test if _fact_class variable is set
    assert getattr(SunOSNetworkCollector, '_fact_class', None) is not None
    # test if _fact_class is instance of Network
    assert issubclass(SunOSNetworkCollector._fact_class, GenericBsdIfconfigNetwork)
    # test if _platform variable is set
    assert getattr(SunOSNetworkCollector, '_platform', None) is not None
    # test if _platform variable has correct value
    assert SunOSNetworkCollector._platform == 'SunOS'
    # test if _fact_class attribute is set
    assert hasattr

# Generated at 2022-06-23 00:07:52.099383
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mod = AnsibleModule(argument_spec={})
    net = SunOSNetwork(mod)
    assert net.platform == 'SunOS'

# Generated at 2022-06-23 00:08:00.350077
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create an instance of the SunOSNetwork class.
    sunos_network = SunOSNetwork({})

    # Some variables used in testing the parse_ether_line method.
    # Example line to test with:
    # ether 0:1:2:d:e:f
    # ether 1:2:3:a:b:c
    # ether 1:23:45:ab:cd:ef
    macaddresses = ['0:1:2:d:e:f', '1:2:3:a:b:c', '1:23:45:ab:cd:ef']
    current_if = {'device': 'unknown', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    # Test each macaddress in the macaddresses list.

# Generated at 2022-06-23 00:08:11.715537
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {}
    ips = {}
    network = SunOSNetwork()

    line = "ether 0:e:3:c3:e7:91"
    words = line.split()
    network.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == "00:0e:03:c3:e7:91"

    line = "ether 0:1:2:d:e:f"
    words = line.split()
    network.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == "00:01:02:0d:0e:0f"

# Generated at 2022-06-23 00:08:20.540453
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    facts = SunOSNetwork()
    # On Solaris 11.3 'ifconfig -a' prints non-local IPv6 addresses but there may
    # be no IPv6 routes.
    # Could be a bug in Solaris: https://community.oracle.com/thread/3335154
    # Workaround is to ignore them until/unless there is a route for them.
    # Add a bogus route for 2001:4860:4860::8888 so it will be ignored.
    devices = [
        'lo0', 
        'igb0',
        'igb1',
        'igb2',
        'igb3',
        'igb4',
        'igb5',
        'igb6',
        'igb7'
        ]

# Generated at 2022-06-23 00:08:23.212891
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('', (object,), dict(exit_json=lambda x: None))()
    module.run_command = lambda x: (0, '', '')
    net = SunOSNetwork(module)

    assert(net.platform == 'SunOS')

# Generated at 2022-06-23 00:08:36.460384
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('DummyModule', (object,), {'run_command': fake_run_command})()
    ifc_cmd = SunOSNetwork(module)
    ifc_cmd._ifconfig_path = '/sbin/ifconfig'

    # test for ethernet interface
    line = 'e1000g0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2'
    words = line.split()
    expected = 'e1000g0'

    current_if = {}
    interfaces = {}
    ifc_cmd.parse_interface_line(words, current_if, interfaces)

    assert interfaces[expected]['device'] == expected

    # test for ethernet interface with IPv6 address

# Generated at 2022-06-23 00:08:47.222363
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('DummyModule', (object,), {})()
    module.run_command = lambda x: (0, x, '')
    n = SunOSNetwork(module)
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '10', 'inet', '127.0.0.1', 'netmask', 'ffffff00']
    current_if = {}
    interfaces = {}
    n.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:09:00.290409
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    testobj = SunOSNetwork()
    interfaces = {}

    # First call of 'parse_interface_line' will define a dict in 'interfaces'
    words = ['bge0:', 'flags=43<UP,BROADCAST,RUNNING,MULTICAST>', 'mtu', '1500']
    testobj.parse_interface_line(words, {}, interfaces)
    assert "bge0" in interfaces.keys()

    # Subsequent calls will update the dict
    words = ['bge0:', 'flags=43<UP,BROADCAST,RUNNING,MULTICAST>', 'mtu', '1500']
    testobj.parse_interface_line(words, {}, interfaces)
    assert "bge0" in interfaces.keys()

# Generated at 2022-06-23 00:09:12.738367
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test parsing of interface line with IPv4 address

    # Setup
    modules = dict(
        ifconfig_path='/sbin/ifconfig'
    )
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    set_module_args(modules)
    testModule = SunOSNetworkCollector(module=module, params=modules)

    # Test parameters
    device = 'hme0'
    words = [device + ':', '[UP,BROADCAST,RUNNING,MULTICAST,DEPRECATED]', 'mtu', '1500', 'index', '8', 'inet', '192.168.1.101', 'netmask', 'ffffff00', 'broadcast', '192.168.1.255']
    interfaces = {}
    current_if = {}

    # Test
   

# Generated at 2022-06-23 00:09:21.041216
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # prepare test data
    module = 'fake_ansible_module'
    words = ['lo0:', 'flags=200100849', '<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232',
             'index', '1', 'inet', '127.0.0.1']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': []}
    interfaces = {}

    # run the test
    sunos_network = SunOSNetwork(module)
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)

    # validate the results
    assert current_if['device'] == 'lo0'

# Generated at 2022-06-23 00:09:34.020614
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = NetworkCollector(dict(ANSIBLE_MODULE_ARGS=dict(gather_subset='!all,!min', gather_network_resources='no')))
    fc = SunOSNetwork(test_module)
    fc.get_interfaces_info(fc.sysctl_path)
    assert fc.interfaces[0]['ipv4'][0]['address'] == '172.16.97.88'
    assert fc.interfaces[0]['ipv4'][0]['subnet'] == '255.240.0.0'
    assert fc.interfaces[1]['ipv4'][0]['subnet'] == '255.255.255.240'

# Generated at 2022-06-23 00:09:37.179423
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'
    assert network_collector._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:09:47.414173
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeModule()

# Generated at 2022-06-23 00:09:57.145105
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # setup
    module = AnsibleModule({})
    m = SunOSNetwork(module)
    current_if = {'device': 'e1000g0', 'type': 'unknown', 'ipv4': [], 'ipv6': []}
    interfaces = {'e1000g0': current_if}
    words = ['e1000g0:', 'flags=8802<BROADCAST,SIMPLEX,MULTICAST>', 'mtu', '1500']

    # test
    m.parse_interface_line(words, current_if, interfaces)

    # verify
    assert current_if['ipv4'][0]['flags'] == ['BROADCAST', 'SIMPLEX', 'MULTICAST']
    assert current_if['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-23 00:10:09.361286
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:10:21.130578
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Prepare network
    network = SunOSNetwork()

    # Initialize interface
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': []}

    # Prepare interfaces
    interfaces = {'lo0': current_if}

    # Parse a line
    line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = line.split()
    current_if = network.parse_interface_line(words, current_if, interfaces)

    # Assert results
    assert(current_if['device'] == 'lo0')
    assert(current_if['type'] == 'loopback')

# Generated at 2022-06-23 00:10:24.887775
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule({'gather_subset': ['!all', '!min']})
    network = SunOSNetwork(module)
    assert network.get_file_path() == '/usr/sbin/ifconfig'



# Generated at 2022-06-23 00:10:27.021449
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork

# Generated at 2022-06-23 00:10:40.329658
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:10:46.442850
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    import pprint

    # Test parsing of a single interface.
    test_interface = SunOSNetwork()
    int_name = 'hme0:'
    line = int_name + ' flags=1000849<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2'
    interfaces = {}
    current_if = {}
    current_if = test_interface.parse_interface_line(line.split(), current_if, interfaces)
    # print(pprint.pformat(current_if))
    assert current_if['device'] == 'hme0', 'interface with IPv4 address was not parsed correctly'

# Generated at 2022-06-23 00:10:48.131678
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_instance = SunOSNetworkCollector()
    assert test_instance.platform == 'SunOS'

# Generated at 2022-06-23 00:10:50.446627
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert isinstance(network_collector, NetworkCollector)


# Generated at 2022-06-23 00:10:58.044363
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockModule()
    net = SunOSNetwork({}, platform='SunOS', module=module)
    net.get_interfaces_info('/path/to/ifconfig')

    # check that module.run_command() was called with the expected args
    module.run_command.assert_called_with(['/path/to/ifconfig', '-a'])

    # check that the values returned by module.run_command() were handled
    # as expected by get_interfaces_info()
    assert(module.rc == 0)

# Generated at 2022-06-23 00:11:01.376851
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Make sure we can create an object for SunOS
    obj = SunOSNetworkCollector()

    # Check if the platform is correctly set
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 00:11:10.074385
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list')),
        supports_check_mode=True)
    module.params['gather_subset'] = ['!all', 'network']

    net = GenericBsdIfconfigNetwork(module)
    interfaces, ips = net.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')
    print (interfaces, ips)


from ansible.module_utils.basic import *



# Generated at 2022-06-23 00:11:22.478950
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    current_if = {'device': 'lo0'}
    sunos_network.parse_ether_line(['ether', '0:0:c0:c0:0:0'], current_if, {})
    sunos_network.parse_ether_line(['ether', '0:0:0:abcd:f:a'], current_if, {})
    assert current_if['macaddress'] == '00:00:c0:c0:00:00'
    sunos_network.parse_ether_line(['ether', '0:9:a:b:0:c'], current_if, {})
    assert current_if['macaddress'] == '00:09:0a:0b:00:0c'


# Generated at 2022-06-23 00:11:32.516082
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_net = SunOSNetwork()
    mac_addr = "0:e:c4:3f:b3:9b"
    test_net.parse_ether_line(words=["ether", mac_addr], current_if={}, ips={})
    assert test_net.interfaces["unknown"]["macaddress"] == mac_addr
    mac_addr = "0:1:2:d:e:f"
    test_net.parse_ether_line(words=["ether", mac_addr], current_if={}, ips={})
    assert test_net.interfaces["unknown"]["macaddress"] == "00:01:02:0d:0e:0f"

# Generated at 2022-06-23 00:11:36.580845
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:11:48.931233
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    network = SunOSNetwork()
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    words = 'lo0:4 flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1'.split()
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': 'lo0', 'ipv4': [{'flags': '8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback'}
    # Check that entry in 'interfaces' dictionary has been updated
    assert 'lo0' in interfaces

# Generated at 2022-06-23 00:11:53.335000
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork(dict())
    current_if = {}
    current_if = network.parse_ether_line(['ether', '0:1:2:3:4:5'], current_if, {})
    assert current_if['macaddress'] == '00:01:02:03:04:05'



# Generated at 2022-06-23 00:12:01.566433
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    data = 'ether 0:9:c4:ac:d4:4f '
    words = data.split()
    current_if = {'device': 'e1000g0'}
    ips = {}
    SunOSNetwork().parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:09:c4:ac:d4:4f'

# Generated at 2022-06-23 00:12:03.346744
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos = SunOSNetwork()
    assert isinstance(sunos, SunOSNetwork)

# Generated at 2022-06-23 00:12:15.378964
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModuleMock()
    ifconfig_path = '/sbin/ifconfig -a'

# Generated at 2022-06-23 00:12:27.804248
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork(dict(module_commands={'ifconfig': './dummy.out'}))
    current_if = {}
    words = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'.split()
    result = m.parse_interface_line(words, current_if, {})
    assert result['type'] == 'loopback'
    assert result['ipv4'][0]['mtu'] == '8232'
    assert 'UP' in result['ipv4'][0]['flags']
    assert 'LOOPBACK' in result['ipv4'][0]['flags']
    assert 'RUNNING' in result['ipv4'][0]['flags']

# Generated at 2022-06-23 00:12:29.610763
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()
    assert net.facts == {}


# Generated at 2022-06-23 00:12:33.909725
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'
    assert obj._get_provider_name() == 'SunOSNetwork'

# Generated at 2022-06-23 00:12:45.074217
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts import FactCollector
    import os
    import tempfile

    # This is the output of 'ifconfig -a' on a Solaris system

# Generated at 2022-06-23 00:12:48.710277
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Unit test for constructor of class SunOSNetwork.

    The constructor should always succeed, even if 'ifconfig'
    is not available.
    """
    my_SunOSNetwork = SunOSNetwork(dict(module=None))
    assert my_SunOSNetwork is not None

# Generated at 2022-06-23 00:12:51.192294
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
  assert SunOSNetworkCollector(None)._fact_class is SunOSNetwork
  assert SunOSNetworkCollector(None)._platform == 'SunOS'

# Generated at 2022-06-23 00:12:54.562803
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    from ansible.module_utils.facts.network.sunos.facts import SunOSNetwork
    obj = SunOSNetwork()
    assert isinstance(obj, SunOSNetwork)

# Generated at 2022-06-23 00:12:55.514627
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sn = SunOSNetwork()
    assert sn.platform == 'SunOS'
    assert len(sn.interfaces_list) == 0

# Generated at 2022-06-23 00:13:05.969900
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    class ModuleTest(object):
        def fail_json(self, msg):
            return msg
        def run_command(self, cmd):
            if cmd == ['ip', 'address', 'show', 'up', 'scope', 'global']:
                return (0, '', '')

# Generated at 2022-06-23 00:13:17.724969
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface_details = {
        'ipv4': [{'flags': [], 'mtu': '1500'}],
        'ipv6': [{'flags': [], 'mtu': '1500'}],
        'macaddress': 'unknown',
    }

    # Test a MAC address with missing leading zero in each octet
    test_str = ['ether', '0:1:2:d:e:f']
    SunOSNetwork.parse_ether_line(test_str, iface_details, {})
    assert iface_details['macaddress'] == '00:01:02:0d:0e:0f'

    # Test a MAC address with missing trailing zero in each octet
    test_str = ['ether', '01:02:3:4d:5e:6f']

# Generated at 2022-06-23 00:13:22.785906
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Test the constructor of the SunOSNetwork class
    """

    sunos_network_instance = SunOSNetwork({})

    assert sunos_network_instance.module == {}

    assert sunos_network_instance.platform == 'SunOS'



# Generated at 2022-06-23 00:13:24.001141
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-23 00:13:35.797519
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_object = SunOSNetwork()
    # This is a string of words split by spaces.
    line = "lo0: "
    words = line.split()
    current_if = {}
    interfaces = {}
    current_if = test_object.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'ipv4': [{'flags': {'IPv6', 'LOOPBACK', 'RUNNING', 'MULTICAST'}}],
                         'ipv6': [{'flags': {'IPv6', 'LOOPBACK', 'RUNNING', 'MULTICAST'}}],
                         'device': 'lo0',
                         'type': 'loopback',
                         'macaddress': 'unknown'}


# Generated at 2022-06-23 00:13:38.160137
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    m = SunOSNetworkCollector()
    assert m.get_facts()['ansible_facts']['ansible_net_interfaces'] == {}

# Generated at 2022-06-23 00:13:41.718524
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    test_class = SunOSNetwork('/usr/sbin/ifconfig')
    assert test_class.platform == 'SunOS'
    assert test_class.has_one_child == True

# Generated at 2022-06-23 00:13:51.419959
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m_module = MagicMock()

# Generated at 2022-06-23 00:13:53.745725
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()
    assert net.platform == 'SunOS'


# Generated at 2022-06-23 00:13:57.754974
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector._fact_class == SunOSNetwork
    assert sunos_network_collector._platform == 'SunOS'



# Generated at 2022-06-23 00:13:59.171090
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'

# Generated at 2022-06-23 00:14:05.290276
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import copy
    import re
    import os
    import sys

    # SunOSNetwork.get_interfaces_info() needs an ifconfig binary in $PATH
    if 'PATH' in os.environ:
        os.environ['PATH'] = os.environ['PATH'] + ':/bin:/usr/bin:/usr/sbin:/sbin'
    else:
        os.environ['PATH'] = '/bin:/usr/bin:/usr/sbin:/sbin'
    if 'SYSTEMROOT' in os.environ:
        os.environ['SYSTEMROOT'] = os.environ['SYSTEMROOT'].replace('\\', '/')

    # Note: If no 'ifconfig' binary is found in $PATH, th

# Generated at 2022-06-23 00:14:16.132225
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Test the parse_interface_line function of the SunOSNetwork class.
    """
    # Define fixture for the testcase
    testcase = dict()
    testcase['words'] = [
        'lo0:',
        'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
        'mtu 8232',
        'index 1',
        'inet 127.0.0.1',
        'netmask ff000000',
    ]
    testcase['current_if'] = dict(
        device='lo0',
        ipv4=[],
        ipv6=[],
        type='unknown',
        macaddress='unknown',
    )
    testcase['interfaces'] = dict()

    # Define expected results for the testcase
   

# Generated at 2022-06-23 00:14:17.931152
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)

    assert sunos_network.get_file_path() == '/sbin/ifconfig'



# Generated at 2022-06-23 00:14:25.330418
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mod = SunOSNetwork
    module = type('module', (object,), dict())
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.params = {}
    module.exit_json = lambda *args, **kwargs: None
    module.fail_json = lambda *args, **kwargs: None
    sunos = mod(module)
    assert sunos.module is module
    assert sunos.platform == 'SunOS'

# Generated at 2022-06-23 00:14:32.367860
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    This tests the parse_ether_line() method of SunOSNetwork.
    """
    _test_str = "ether 0:1:2:d:e:f"
    _test_obj = SunOSNetwork()

    _test_obj.parse_ether_line(_test_str.split(), {}, {})

    assert _test_obj.facts['device_mac'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:14:33.752192
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact = SunOSNetworkCollector()

# Generated at 2022-06-23 00:14:46.339313
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test empty line.
    sunos_network_parse_interface_line_in = []
    sunos_network_parse_interface_line_current_if = dict(
        device='current_if_device',
        ipv4=[dict(flags='current_if_ipv4_flags', mtu='current_if_ipv4_mtu')],
        ipv6=[dict(flags='current_if_ipv6_flags', mtu='current_if_ipv6_mtu')],
        type='current_if_type',
        macaddress='current_if_macaddress',
        )

# Generated at 2022-06-23 00:14:58.683509
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # unit test requires pytest-mock.
    # $ pip install pytest-mock
    from mock import patch
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    test_output_netstat = '''<output suppressed>'''


# Generated at 2022-06-23 00:15:10.258994
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = DummyAnsibleModule()
    net = SunOSNetwork(module)
    interfaces, ips = net.get_interfaces_info("/usr/sbin/ifconfig")
    assert len(interfaces) == 2
    # The interfaces are ordered as they are in the file testdata/SunOS/ifconfig_a
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'IPv4', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'
    assert interfaces['lo0']['ipv6'][0]['flags'] == ['UP', 'IPv6', 'LOOPBACK', 'RUNNING']

# Generated at 2022-06-23 00:15:22.762139
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    current_if = SunOSNetwork().parse_interface_line(['lo0:', 'flags=2001000849', 'mtu', '8232'], current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert 'IPv6' not in current_if['ipv4'][0]['flags']
    assert 'LOOPBACK' in current_if['ipv4'][0]['flags']
    assert current_if['type'] == 'loopback'

    current_if = SunOSNetwork().parse_interface_line(['vboxnet0:', 'flags=8943', 'mtu', '1500'], current_if, interfaces)

# Generated at 2022-06-23 00:15:35.877300
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    This test verifies that the parse_interface_line method works as expected
    """
    fact_class = SunOSNetwork()
    interfaces = {}
    current_if = {}
    # test creating a new interface
    current_if = fact_class.parse_interface_line(['bge1:'], current_if, interfaces)
    assert current_if == {'device': 'bge1', 'ipv4': [{'flags': [u'UP', u'BROADCAST', u'RUNNING', u'MULTICAST', u'IPv4'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}

    # test updating an existing interface

# Generated at 2022-06-23 00:15:43.996638
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork()
    ifc = {'ipv4': [], 'ipv6': []}
    l = 'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'
    o = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232', 'index', '1']
    r = m.parse_interface_line(o, ifc, {})

# Generated at 2022-06-23 00:15:52.189196
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_interface = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}
    test_ips = {}
    test_words = ['ether', '0:1:2:d:e:f']

    SunOSNetwork.parse_ether_line(test_words, test_interface, test_ips)
    assert test_interface['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:15:54.026587
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    SunOSNetwork(None).parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, {})
    assert current_if == {'macaddress': '00:01:02:0d:0e:0f'}

# Generated at 2022-06-23 00:15:55.116189
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-23 00:16:06.754619
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = FakeModule()
    sunos_network = SunOSNetwork(module)
    current_if = {}
    ips = {}

    words = ['ether', '0:1:2:d:e:f']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    # 2 is the only single digit octet
    words = ['ether', '0:1:2:e:f:10']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0e:0f:10'

    # Test one zero octet

# Generated at 2022-06-23 00:16:18.504116
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Given
    root_dir = "/"
    sys_class_net = "/faux/sys/class/net/"
    data = {}


# Generated at 2022-06-23 00:16:28.740565
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})

    # If Solaris, populate 'ansible_facts' dict with data from 'ifconfig -a'
    # The 'ifconfig -a' output will be in the 'ansible_ifconfig' fact.
    # If OpenBSD, then gather network facts by calling the proper subclass via super(OpenBSDNetwork, self).get_interfaces_info()

    FakeNetworkCollector = SunOSNetworkCollector(module=module)
    ansible_facts = dict()
    # For now, mock a Solaris 'ifconfig -a' and pretend to be Solaris
    # This can be refactored if/when we use AnsibleModule, but
    # we will not be able to test different platforms via AnsibleModule.
    # AnsibleModule is