

# Generated at 2022-06-23 00:06:35.139382
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # create dict of dicts for interfaces
    interfaces = dict()
    # create dict for ipv4 and ipv6
    ipv4 = dict()
    ipv6 = dict()
    # create list to hold the dicts ipv4 and ipv6
    list_ipv4 = []
    list_ipv6 = []
    # create dict to hold current_if
    current_if = dict()
    network = SunOSNetwork()

    # test ifconfig line for interface not in interfaces
    words = ['e1000g0:', 'flags=1000843', 'mtu', '1500']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'e1000g0', 'did not set inet device correctly'

# Generated at 2022-06-23 00:06:45.740073
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork
    assert SunOSNetwork._platform == 'SunOS'
    assert SunOSNetwork.platform == 'SunOS'
    snc = SunOSNetwork()
    assert snc
    word_list = ['lo0:', 'flags=2001000849', 'mtu', '8232']
    assert snc.parse_interface_line(word_list, '', '') == {'device': 'lo0', 'ipv4': [{'flags': '2001000849', 'mtu': '8232'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:06:59.466829
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    test method SunOSNetwork.get_interfaces_info
    """
    import os
    import sys
    import unittest

    # TODO: test cases where device has no IPv4 address, only IPv6
    # TODO: test cases where device has no IPv6 address, only IPv4


# Generated at 2022-06-23 00:07:12.054254
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    SunOSNetwork.get_interfaces_info unit test
    """

    facts = {}
    module = AnsibleModuleMock(facts)
    sunos_network = SunOSNetwork(module)


# Generated at 2022-06-23 00:07:20.213541
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['all'], type='list')})
    obj = SunOSNetwork(module)
    interfaces, ips = obj.get_interfaces_info('/sbin/ifconfig')
    assert interfaces is not None
    assert ips is not None
    assert len(interfaces) == len(ips['all_ipv4_addresses']) + len(ips['all_ipv6_addresses'])
    assert len(interfaces) == 3    # This Solaris VM has 3 interfaces: lo0, net0 and net1
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-23 00:07:33.604830
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MockAnsibleModule('SunOS')
    network = SunOSNetwork(module)

    # IPv6-capable interface
    words = 'e1000g0: flags=2001000849<UP,BROADCAST,RUNNING,MULTICAST,IPv6,NOFAILOVER> mtu 1500 index 2'.split()
    expected = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv6', 'NOFAILOVER'], 'mtu': '1500'}], 'type': 'unknown'}
    result = network.parse_interface_line(words, None, {})
    assert expected == result

    # IPv4-only interface

# Generated at 2022-06-23 00:07:45.433911
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Create module object
    module = NetworkCollector.get_module(None)
    # Create instance of SunOSNetwork
    network_collector = SunOSNetwork(module)
    # Get the interfaces and ips
    interfaces, ips = network_collector.get_interfaces_info('/usr/bin/ifconfig')
    # Check the length of both interfaces and ips
    assert len(interfaces) == 1
    assert len(ips) == 3
    # Check the keys of 'interfaces'
    assert 'lo0' in interfaces
    assert 'ipv4' in interfaces['lo0']
    assert 'ipv6' in interfaces['lo0']
    # Check the interface type
    assert interfaces['lo0']['type'] == 'loopback'
    # Check macaddress
    assert interfaces['lo0']['macaddress']

# Generated at 2022-06-23 00:07:54.727244
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    iface_list = ['lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1',
                  'lo0: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1']

# Generated at 2022-06-23 00:08:07.847272
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # create args needed in method
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'lo0': {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    words = [
        'lo0:',
        'flags=2001000849',
        'mtu',
        '8232',
        'index',
        '10',
        'inet',
        '127.0.0.1',
        'netmask',
        'ffffff00',
    ]

    test_object = SunOSNetwork(None)
    # run method
    output = test_object.parse_interface_line(words, current_if, interfaces)

    # check

# Generated at 2022-06-23 00:08:12.189810
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    fake_module = type('obj', (object,), {'params': {}})
    fake_module.run_command = lambda *args, **kwargs: (0, '', '')
    obj = SunOSNetwork(fake_module)

# Generated at 2022-06-23 00:08:13.003080
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork({}, test=True)

# Generated at 2022-06-23 00:08:14.480255
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_network_collector = SunOSNetworkCollector()
    assert sunos_network_collector.platform == 'SunOS'

# Generated at 2022-06-23 00:08:15.949434
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = DummyModule()
    SunOSNetworkCollector(module).collect()
    assert module.exit_json.called

# Generated at 2022-06-23 00:08:24.442992
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test for the method get_interfaces_info of the class SunOSNetwork.
    """

    # Create a SunOSNetwork object
    test_SunOSNetwork = SunOSNetwork({'run_command.return_value': ('', '', 0)}, check_invalid_arguments=False)

    # Return value of the method get_interfaces_info

# Generated at 2022-06-23 00:08:34.959483
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork({}, {})
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', '0:1:2:d:e:f']
    m.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:08:46.254869
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_facts = SunOSNetwork({'ansible_module_arg_spec': {
                                  'ifconfig_path': {'default': '/sbin/ifconfig', 'type': 'path'}
                              }
                             })
    # output of 'ifconfig -a'

# Generated at 2022-06-23 00:08:50.380588
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    obj = SunOSNetwork()
    assert obj.platform == 'SunOS'
    assert obj.interfaces == obj.all_interfaces
    assert obj.facts == {}
    assert obj.configs == []
    assert obj.interfaces_info == []

# Generated at 2022-06-23 00:08:59.800841
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {'ipv4': [{'mtu': '1500'}, {'mtu': '1500'}, {'mtu': '1500'}], 'ipv6': [], 'macaddress': 'unknown'}
    words = ['ether', '0:d:e:a:d:b', 'txqueuelen', '100']
    net = SunOSNetwork()
    net.parse_ether_line(words, iface, {})
    assert iface['macaddress'] == '00:0d:0e:0a:0d:0b'

# Generated at 2022-06-23 00:09:12.003326
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_file = 'ansible/test/units/modules/utils/facts/network/sunos_ifconfig.out'
    mock_module = MagicMock()
    mock_module.run_command.return_value = 0, open(test_file).read(), ''
    test_obj = SunOSNetwork(mock_module)
    interfaces_ipv4, interfaces_ipv6 = test_obj.get_interfaces_ip()
    interfaces_info, ips = test_obj.get_interfaces_info('ifconfig')

# Generated at 2022-06-23 00:09:15.620387
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    _fact_class = SunOSNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', '0:3:ba:75:9e:1c']

    _fact_class.parse_ether_line(words, current_if, ips)

    assert current_if == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': '00:03:ba:75:9e:1c'}

# Generated at 2022-06-23 00:09:17.266213
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    iface = SunOSNetwork(module)
    assert iface.platform == 'SunOS'



# Generated at 2022-06-23 00:09:27.028364
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = 'ansible.module_utils.facts.network.sunos.SunOSNetwork'
    mac = '00:01:02:d:e:f'
    words = ['ether', '0:1:2:d:e:f']
    current_if = {'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    n = SunOSNetwork(module)
    n.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == mac

# Generated at 2022-06-23 00:09:38.689441
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = MockModule()
    test_module.params = {}

# Generated at 2022-06-23 00:09:45.606444
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """Test parsing line from Solaris output 'ifconfig -a'"""
    iface = {}
    facts = SunOSNetwork(dict(module=dict(run_command=dict(return_value=(0, '', '')))))
    line = ['test0: flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4> mtu 1500 index 2']
    words = line[0].split()
    # Basic test
    iface = facts.parse_interface_line(words, iface, {})
    assert iface['device'] == 'test0'
    assert iface['type'] == 'unknown'

# Generated at 2022-06-23 00:09:54.103440
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_class = SunOSNetwork()

# Generated at 2022-06-23 00:10:06.728641
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    unit_test_module = NetworkCollector()
    assert unit_test_module.parse_ether_line(
        ['ether', '0:1:2:d:e:f'],
        {},
        {}
    )['macaddress'] == '00:01:02:0d:0e:0f'
    assert unit_test_module.parse_ether_line(
        ['ether', '0:1:2:3:4:5'],
        {},
        {}
    )['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-23 00:10:10.781920
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    x = SunOSNetworkCollector()
    assert x._platform == 'SunOS'
    assert x._fact_class == SunOSNetwork
    assert x._config == {}
    assert x._device_number == -1

# Generated at 2022-06-23 00:10:14.793724
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    new_SunOSNetwork = SunOSNetwork(module)
    assert new_SunOSNetwork is not None


# Generated at 2022-06-23 00:10:23.604485
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeAnsibleModule('SunOS')
    m_current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    m_interfaces = {'lo0': m_current_if}
    m_words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    SunOSNetwork.parse_interface_line(module, m_words, m_current_if, m_interfaces)
    assert m_current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
   

# Generated at 2022-06-23 00:10:25.933576
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class.platform == 'SunOS'

# Generated at 2022-06-23 00:10:32.016232
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    network_collector = SunOSNetworkCollector(module=module,
                                              command_loader=CommandLoaderMock())
    assert network_collector.module == module
    assert network_collector.command_loader == CommandLoaderMock()
    assert network_collector.facts['network'] == {}

# Generated at 2022-06-23 00:10:35.727412
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    obj = SunOSNetworkCollector(module)
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:10:47.628544
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test parse_interface_line() with a line from a 'ifconfig -a' that includes IPv4 and IPv6
    # init values
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {current_if['device']: current_if}
    words = [current_if['device'] + ':', 'flags=e080863<UP,BROADCAST,NOTRAILERS,RUNNING,MULTICAST,IPv6,NOXMIT>', 'mtu', '8232', 'index', '6']

    iface = SunOSNetwork()
    current_if = iface.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:10:56.461340
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Parse the following Solaris 'ifconfig -a' lines:

    net0: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 3
    net0: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 3
    """
    iface = {}
    interfaces = {}
    words = ['net0:', 'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>', 'mtu', '1500', 'index', '3']
    iface = SunOSNetwork.parse_interface_line(None, words, iface, interfaces)

# Generated at 2022-06-23 00:11:03.052998
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():

    facts = SunOSNetwork({})

    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}

    facts.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == '00:01:02:0d:0e:0f', current_if


# Generated at 2022-06-23 00:11:04.231726
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-23 00:11:16.055202
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = type('', (object,), dict(run_command=lambda x, **kw: (0, TEST_INTERFACE_DATA, None)))
    test_net = SunOSNetwork(test_module)
    interfaces, ips = test_net.get_interfaces_info('ifconfig')

    assert interfaces['hme0']['ipv4'][0] == {'flags': ['UP', 'BROADCAST', 'RUNNING', 'IPv4'], 'mtu': '1500'}
    assert interfaces['hme0']['ipv6'][0] == {'flags': ['UP', 'RUNNING', 'IPv6'], 'mtu': '1500'}

# Generated at 2022-06-23 00:11:19.646642
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('', (object,), {})()
    module.run_command = lambda x: [0, '', '']
    SunOSNetwork(module)

# Generated at 2022-06-23 00:11:29.016686
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Unit test for constructor of class SunOSNetwork"""

    def dummy_exists(self, path):
        return True

    def dummy_join(self, *args):
        return '/bin/ifconfig'

    m_path = __import__('os.path', globals(), locals(), ['exists', 'join'])
    m_subprocess = __import__('subprocess', globals(), locals(), ['PIPE', 'STDOUT', 'run'])
    m_base = __import__('ansible.module_utils.facts.network.generic_bsd', globals(), locals(), ['GenericBsdIfconfigNetwork'])
    m_base.GenericBsdIfconfigNetwork.get_interfaces_info = InterfaceInfo()
    m_base.GenericBsdIfconfigNetwork.parse_interface_line = ParseInterfaceLine()
    m_base

# Generated at 2022-06-23 00:11:42.342839
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """SunOSNetwork - get_interfaces_info() for Solaris 11.4."""
    # Note: ifconfig -a does not print the same output on Solaris 10 and 11.
    # Solaris 10 will be tested separately.

# Generated at 2022-06-23 00:11:53.336345
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Test the parse_interface_line method.
    """
    # Create an instance of the SunOSNetwork class
    sunos_net = SunOSNetwork()
    # Create dictionaries for interfaces and current_if
    interfaces = {}
    current_if = {}
    # Create the words list
    words = ['ce0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu=1500', 'index=2', 'inets', '10.1.0.117', 'netmask', 'ffffff00']
    # Run the method parse_interface_line
    current_if = sunos_net.parse_interface_line(words, current_if, interfaces)
    # Verify that the device property is set correctly

# Generated at 2022-06-23 00:12:07.169845
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    ifc = SunOSNetwork()
    data = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    current_if = dict(
        device='net0',
        ipv4=[{'flags': ['UP', 'BROADCAST', 'RUNNING', 'SMART', 'SIMPLEX', 'MULTICAST'], 'mtu': 1500}],
        ipv6=[],
        type='unknown',
    )
    words = ['ether', '0:1:2:d:e:f']
    ifc.parse_ether_line(words, current_if, data)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:12:19.843117
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_dict = {}
    test_current_if = {}
    test_words = ['ixge0:', 'flags=20048<LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232', 'index', '3']
    SunOSNetworkCollector._fact_class.parse_interface_line(SunOSNetworkCollector._fact_class, test_words, test_current_if, test_dict)
    assert 'ixge0' in test_dict
    assert test_dict['ixge0']['device'] == 'ixge0'
    assert test_dict['ixge0']['type'] == 'unknown'
    assert test_dict['ixge0']['macaddress'] == 'unknown'

# Generated at 2022-06-23 00:12:25.468105
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_if = {'device': 'test_device', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    m = SunOSNetwork({})

    # test that second set of words from ifconfig -a are parsed correctly
    test_words = ['test_device1:0', 'flags=1dbef', 'mtu', '1500']
    test_interfaces = {'test_device1': {'device': 'test_device1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    test_current_if = {}
    assert m.parse_interface_line(test_words, test_current_if, test_interfaces) == test_if

    # test that second set of words from ifconfig -a are parsed correctly

# Generated at 2022-06-23 00:12:30.661679
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    network = SunOSNetwork(dict())
    assert network.ipv4_gateway == u'0.0.0.0'
    assert network.ipv6_gateway == u'::'
    assert network.ipv4_interfaces == dict()
    assert network.ipv6_interfaces == dict()



# Generated at 2022-06-23 00:12:34.804464
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test the constructor of SunOSNetworkCollector
    """

    instance = SunOSNetworkCollector()
    assert instance.platform == 'SunOS'
    assert hasattr(instance, '_fact_class')



# Generated at 2022-06-23 00:12:42.687726
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """Unit test for method parse_ether_line of class SunOSNetwork"""
    sunos_network = SunOSNetwork()
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['ether', '0:1:2:3:4:5', 'ethernet']
    sunos_network.parse_ether_line(words, current_if, 'ips')
    assert current_if['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-23 00:12:45.824926
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net_collector = SunOSNetworkCollector(None)
    assert net_collector._platform == 'SunOS'
    assert net_collector._fact_class.platform == 'SunOS'


# Generated at 2022-06-23 00:12:53.206415
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Creates an instance of SunOSNetwork, possibly with
    a Mock of module_utils/facts/network/generic_bsd.py

    Uses class methods to return various properties.
    """
    network = SunOSNetwork()
    print(network.get_interfaces())
    print(network.get_interfaces_ipv4())
    print(network.get_interfaces_ipv6())
    print(network.get_interfaces_list())
    print(network.get_default_interface())
    print(network.get_default_interfaces())
    print(network.get_default_interfaces_ipv4())
    print(network.get_default_interfaces_ipv6())
    print(network.get_default_ipv4())
    print(network.get_default_ipv6())

#

# Generated at 2022-06-23 00:12:57.487130
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    Net = SunOSNetworkCollector()
    assert Net._fact_class == SunOSNetwork
    assert Net._platform == 'SunOS'
    assert Net.platform == 'SunOS'

# Unit tests for SunOSNetwork

# Generated at 2022-06-23 00:12:59.775902
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    '''
    Constructor test for class SunOSNetwork
    '''
    SunOSNetwork(dict())


# Generated at 2022-06-23 00:13:00.693631
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()
    assert net.platform == 'SunOS'

# Generated at 2022-06-23 00:13:10.261977
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Arrange
    words = ["ether", "0:1:2:d:e:f"]
    current_if = {'device': 'nxge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # Act
    SunOSNetwork().parse_ether_line(words, current_if, ips)
    # Assert
    assert 'macaddress' in current_if and current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:13:16.608204
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ip_path = module.get_bin_path('ifconfig', True)

    network_collector = SunOSNetwork(module)
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path=ip_path)

    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'e1000g1' in interfaces
    assert 'e1000g2' in interfaces
    assert 'bge0' in interfaces

    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert 'lo0' in ips['all_ipv4_addresses']

# Generated at 2022-06-23 00:13:29.624216
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_instance = SunOSNetwork()

    # section of 'ifconfig -a' output parsed by parse_ether_line()
    # this is the same output on Solaris 11.3
    line = 'ether 8:0:27:c5:e1:6a'
    words = line.split()

    # no macaddress key
    assert 'macaddress' not in test_instance.interfaces
    assert 'macaddress' not in test_instance.facts

    # run parse_ether_line()
    test_instance.parse_ether_line(words, test_instance.interfaces, test_instance.facts)

    # macaddress key is added to interfaces and facts
    assert 'macaddress' in test_instance.interfaces
    assert 'macaddress' in test_instance.facts

    # macaddress is "aa:bb:cc:dd:

# Generated at 2022-06-23 00:13:33.227803
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mod = SunOSNetwork({})
    assert mod.facts['all_ipv4_addresses'] == []
    assert mod.facts['all_ipv6_addresses'] == []
    assert mod.facts['default_ipv4'] == {}
    assert mod.facts['default_ipv6'] == {}

# Generated at 2022-06-23 00:13:45.651518
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    if1 = {'device': 'bge0', 'ipv4': [{'flags': ['BROADCAST', 'MULTICAST', 'UP', 'IPv4'], 'mtu': '1500'}],
           'ipv6': [
               {'flags': ['BROADCAST', 'MULTICAST', 'UP', 'IPv6', 'IPv4-Compatible'], 'mtu': '1500',
                'scope6': 'global',
                'prefixlen': 64}],
           'type': 'ether', 'macaddress': '0:1:2:3:4:5'}

# Generated at 2022-06-23 00:13:48.509715
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class._platform == 'SunOS'
    assert isinstance(obj.fact_class, SunOSNetwork)
    assert obj.fact_cl

# Generated at 2022-06-23 00:13:52.590180
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_if = {}
    test_line = ['ether', '0:1:2:d:e:f', 'broadcast', 'ff:ff:ff:ff:ff:ff']
    test_if = SunOSNetwork.parse_ether_line(test_line, test_if)
    assert test_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:13:53.856504
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork
    assert SunOSNetworkCollector

# Generated at 2022-06-23 00:13:59.460928
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Unit test for constructor of class SunOSNetworkCollector
    """
    assert SunOSNetworkCollector.__name__ == 'SunOSNetworkCollector'
    assert SunOSNetworkCollector().platform == 'SunOS'
    assert SunOSNetworkCollector()._fact_class == SunOSNetwork

# Unit tests for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:14:01.780134
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    '''Unit test for constructor of class SunOSNetwork'''
    SunOSNetwork()

# Generated at 2022-06-23 00:14:04.674643
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos = SunOSNetworkCollector()
    assert sunos.platform == 'SunOS'
    assert sunos.fact_class == SunOSNetwork

# Generated at 2022-06-23 00:14:15.770847
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    import json
    import os
    import sys

    facts = dict(
        distribution=dict(
            distro='SunOS'
        ),
        system=dict(
            platform='SunOS'
        )
    )

    # Read test data which is the output of '/sbin/ifconfig -a' command.
    module_path = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
    test_data_path = os.path.join(module_path, 'get_interfaces_info.json')
    with open(test_data_path) as data_file:
        test_output = data_file.read()

    # Fake module with set_module_args() method

# Generated at 2022-06-23 00:14:28.212299
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module_mock = type('obj', (object,), {'run_command': SunOSNetwork.run_command})

# Generated at 2022-06-23 00:14:33.372432
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Unit test for constructor of class SunOSNetwork
    """
    # test instance creation
    sunos_network = SunOSNetwork()

    # test name of inherited interface (do not use assertIsInstance here)
    assert type(sunos_network).__name__ == 'GenericBsdIfconfigNetwork'

# Generated at 2022-06-23 00:14:42.931964
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    def test_assert(condition, msg):
        if not condition:
            raise Exception('AssertionError: ' + msg)
    module = None
    check = SunOSNetwork(module)
    test_assert(check.platform == 'SunOS', "platform doesn't match")
    test_assert(check.interface_path == '/usr/sbin/ifconfig', "path doesn't match")
    test_assert(check.facts_type == 'sunos', "facts_type doesn't match")
    test_assert(check.facts_module == 'sunos_facts', "fact_module doesn't match")

# Generated at 2022-06-23 00:14:44.755186
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net = SunOSNetworkCollector()
    assert net.platform == "SunOS"

# Generated at 2022-06-23 00:14:46.286628
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    t = SunOSNetwork()
    assert t.platform == 'SunOS'

# Generated at 2022-06-23 00:14:50.787573
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert isinstance(c, NetworkCollector)
    assert isinstance(c, SunOSNetworkCollector)
    assert c.platform == 'SunOS'
    assert c.fact_class == SunOSNetwork

# Generated at 2022-06-23 00:14:54.498503
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    n = SunOSNetwork(dict(module=dict()))
    assert n.__class__.__name__ == 'SunOSNetwork' or n.__class__.__name__ == 'UnknownNetwork'


# Generated at 2022-06-23 00:15:06.778343
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """SunOSNetwork - get interfaces info"""
    ifconfig_path = '/usr/sbin/ifconfig'


# Generated at 2022-06-23 00:15:07.728374
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    ''' Unit test for constructor of class SunOSNetwork
    '''
    SunOSNetwork()

# Generated at 2022-06-23 00:15:09.361903
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule({})
    collector = SunOSNetwork(module)
    assert collector.get_device_facts() == []


# Generated at 2022-06-23 00:15:22.067832
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    class FakeModule:
        def __init__(self, name, output):
            self.name = name
            self.output = output

        def run_command(self, args):
            if args[-1] == self.name:
                return 0, self.output, ''
            else:
                return 2, '', 'ERROR'

    class FakeFacts:
        def __init__(self, interfaces, ips):
            self.interfaces = interfaces
            self.ips = ips


# Generated at 2022-06-23 00:15:25.831282
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = type('MockModule', (object,), dict(run_command=lambda self, cmd, check_rc=True: (0, '', '')))()
    SunOSNetworkCollector(module)

# Generated at 2022-06-23 00:15:29.442142
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    my_network = SunOSNetwork({'ansible_module': {}})
    assert my_network.__str__() == "SunOS network ="

# Generated at 2022-06-23 00:15:31.308122
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Check constructor of SunOSNetworkCollector class."""
    SunOSNetworkCollector()

# Generated at 2022-06-23 00:15:34.340571
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()

    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-23 00:15:43.307451
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    '''Test for method parse_ether_line of class SunOSNetwork'''
    test_dict = {'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_dict['ipv4'].append({'flags': 'UP,BROADCAST,RUNNING,MULTICAST,IPv4', 'mtu': '1500'})
    test_obj = SunOSNetwork()
    test_obj.parse_ether_line(['ether', '0:1:2:d:e:f'], test_dict, {})
    assert test_dict['macaddress'] == '00:01:02:0d:0e:0f'
    test_obj.parse_ether_line(['ether', 'a:b:c:d:e:f'], test_dict, {})
   

# Generated at 2022-06-23 00:15:56.159454
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_os_ifconfig_path = '/sbin/ifconfig'
    module = type('AnsibleModule', (object,), {})()
    setattr(module, 'get_bin_path', lambda x, y: sun_os_ifconfig_path)
    sun_os_network_collector = SunOSNetworkCollector(module=module)
    assert sun_os_network_collector.module == module
    assert sun_os_network_collector.fact_class._platform == 'SunOS'
    assert sun_os_network_collector.fact_class._conf_file == '/etc/net/ticlts/hosts'

# Generated at 2022-06-23 00:15:58.027495
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module)


# Generated at 2022-06-23 00:16:02.852986
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    obj = SunOSNetwork()
    interfaces = []
    current_if = {}
    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    current_if = obj.parse_interface_line(words, current_if, interfaces)
    # First time parsing same interface name
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv6']

# Generated at 2022-06-23 00:16:12.803634
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModuleMock(params={'gather_subset': ['!all', '!min']})

# Generated at 2022-06-23 00:16:25.207505
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = type(str('FakeModule'), (object,), {})
    module.params = {
        'gather_subset': [],
        'gather_network_resources': [],
    }
    module.config = {
        'network': {}
    }
    module.run_command = lambda *args, **kwargs: ('', '', '')
    collector = SunOSNetworkCollector(module=module)
    facter = collector._fact_class(module)

    words = [ 'ether', '0:1:2:3:4:5' ]
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}