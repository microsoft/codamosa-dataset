

# Generated at 2022-06-23 00:06:26.761530
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector()
    assert nc.facts == 'SunOSNetwork'
    assert nc.platform == 'SunOS'



# Generated at 2022-06-23 00:06:35.987596
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup test data
    test_module = type('module', (object,), {'run_command': lambda *args: (0, 'line1\nline2\n', None)})()
    test_SunOSNetwork = SunOSNetwork(test_module)

    # Test
    test_SunOSNetwork_get_interfaces_info_result = test_SunOSNetwork.get_interfaces_info('ifconfig')
    comparison_dict = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    assert comparison_dict == test_SunOSNetwork_get_interfaces_info_result[1]


# Generated at 2022-06-23 00:06:39.210862
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Constructor of SunOSNetworkCollector should return a SunOSNetworkCollector object """
    sunos_network_collector = SunOSNetworkCollector()
    assert isinstance(sunos_network_collector, SunOSNetworkCollector)

# Generated at 2022-06-23 00:06:46.372128
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    t = SunOSNetwork('', {})
    t.parse_ether_line(('ether', '0:1:2:d:e:f'), {}, {})
    assert(t.device['macaddress'] == '00:01:02:0d:0e:0f')
    t.parse_ether_line(('ether', '0:0:2:d:e:f'), {}, {})
    assert(t.device['macaddress'] == '00:00:02:0d:0e:0f')

# Generated at 2022-06-23 00:06:52.800357
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts import DefaultNetworkCollector
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network import SunOSNetwork

    sunos_network = SunOSNetwork()
    line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = line.split()
    current_if = {}
    interfaces = {}

    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert(current_if['device'] == 'lo0')
    assert(current_if['type'] == 'loopback')
    assert(current_if['macaddress'] == 'unknown')

# Generated at 2022-06-23 00:06:56.097748
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    testobj = SunOSNetwork(None)
    test_data = dict(current_if={'macaddress': 'unknown', 'device': 'lo0', 'ipv4': [{'mtu': '8232', 'flags': ['UP', 'LOOPBACK', 'RUNNING']}], 'ipv6': [], 'type': 'loopback'}, ips={'all_ipv4_addresses': [], 'all_ipv6_addresses': []}, words=['ether', '0:4:4d:17:b8:0'])
    testobj.parse_ether_line(**test_data)
    assert test_data['current_if']['macaddress'] == '00:4:4d:17:b8:00'

# Generated at 2022-06-23 00:07:02.550721
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    SunOSNetwork.get_interfaces_info() Test Case
    """
    SunOSNetwork = SunOSNetwork()

    command = [SunOSNetwork.module.get_bin_path('ifconfig', True), '-a']
    (rc, out, err) = SunOSNetwork.module.run_command(command)

    interfaces, ips = SunOSNetwork.get_interfaces_info(SunOSNetwork.module.get_bin_path('ifconfig', True))

    assert interfaces is not None
    assert ips is not None



# Generated at 2022-06-23 00:07:14.692969
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Given
    kwargs = {
        'dev': 'bge1',
        'words': ['bge1:', 'flags=20000843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST,IPv4>', 'mtu', '1500'],
        'current_if': {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
        'interfaces': {'bge0': {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}},
    }
    sunos = SunOSNetwork()

    # When
    result = sunos.parse_interface_line(**kwargs)

    # Then

# Generated at 2022-06-23 00:07:21.929682
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_SunOSNetwork = SunOSNetwork('/sbin/ifconfig')

    # Create empty dicts for testing.
    interface = {}
    interfaces = {}

    test_data1 = ['bge0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu:1500', 'index:2', 'inet:10.200.51.1', 'netmask:ffffff00', 'broadcast:10.200.51.255']
    test_interface1 = test_SunOSNetwork.parse_interface_line(test_data1, interface, interfaces)

# Generated at 2022-06-23 00:07:34.819602
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    class TestModule(object):
        def __init__(self):
            pass
        def run_command(self, cmd):
            return None, "", ""
    class TestFacts(object):
        def __init__(self):
            pass
    testmodule = TestModule()
    testfact = TestFacts()
    # ifconfig_path = '/sbin/ifconfig'
    testmodule.run_command = run_command_mock

    testfact = SunOSNetwork(testmodule)

    current_if = {}

    interfaces = {}

    line = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1"
    words = line.split()

# Generated at 2022-06-23 00:07:37.446365
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector(None)
    assert obj._fact_class is SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 00:07:48.684482
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ Test the SunOSNetwork.get_interfaces_info method """

    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    module = FakeAnsibleModule()
    module.params = {'gather_subset': ['!all', '!min']}

    # Test that the function returns none for invalid input
    assert SunOSNetwork.get_interfaces_info(module, None) is None
    assert SunOSNetwork.get_interfaces_info(module, '') is None

    # Test that the function returns a string, list and dict when
    # input is a valid string, list and dict respectively
    assert isinstance(SunOSNetwork.get_interfaces_info(module, 'test'), tuple)

# Generated at 2022-06-23 00:07:58.625872
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:08:11.604858
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    testobj = SunOSNetwork(module)
    testobj.interfaces = {}
    testobj.ips = {}

# Generated at 2022-06-23 00:08:15.532456
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Initialize an object of class SunOSNetworkCollector
    sunosnetwork_collector_object = SunOSNetworkCollector()
    # Assert the value of _platform variable
    assert sunosnetwork_collector_object._platform == 'SunOS'
    # Assert the value of _fact_class variable
    assert sunosnetwork_collector_object._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:08:24.260735
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = Mock(params={})

    def run_command_mock(cmd, *args, **kwargs):
        out = 'lo0: flags=2001000849 mtu 8232 index 1\n' \
              '        inet 127.0.0.1 netmask ff000000\n' \
              'net0: flags=1004843 mtu 1500 index 2\n' \
              '        inet 192.168.1.8 netmask ffffff00 broadcast 192.168.1.255\n' \
              '        ether 0:3:ba:26:2:c4\n'
        rc = 0
        err = ''
        return (rc, out, err)

    module.run_command = run_command_mock

    network = SunOSNetwork(module)
    interfaces, ips = network.get_inter

# Generated at 2022-06-23 00:08:37.331681
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork()
    interfaces_a = {}
    current_if_a = {}
    ips_a = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Test case-1: Solaris displays single digit octets in MAC addresses
    # e.g. 0:1:2:d:e:f
    # Add leading zero to each octet where needed.
    words = ['ether', '0:1:2:d:e:f']
    current_if = network.parse_ether_line(words, current_if_a, ips_a)
    interfaces_a[current_if['device']] = current_if

# Generated at 2022-06-23 00:08:41.422789
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    obj = SunOSNetwork()
    assert obj.platform == 'SunOS'
    assert obj.get_interfaces_info('/sbin/ifconfig') == (None, None)


# Generated at 2022-06-23 00:08:44.749937
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Constructing SunOSNetwork
    """
    module = FakeAnsibleModule({})
    network_facts = SunOSNetwork(module)
    assert network_facts.get_network_facts() == {}



# Generated at 2022-06-23 00:08:57.082165
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    os_platform = 'SunOS'
    os_version = '5.11'
    os_release = '11.4'
    os_system = 'sun4v'
    os_machine = 'i86pc'

    # Create an instance of SunOSNetworkCollector with the specified
    # parameters and verify that the instance is created successfully
    network_collector_object = SunOSNetworkCollector(os_platform, os_version, os_release, os_system, os_machine,
                                                     None)

    assert network_collector_object._platform == os_platform
    assert network_collector_object._fact_class.platform == os_platform
    assert network_collector_object._fact_class.module == None

# Generated at 2022-06-23 00:09:04.948793
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232', 'index', '1']
    SunOSNetwork_object = SunOSNetwork()
    result = SunOSNetwork_object.parse_interface_line(words, current_if, interfaces)
    desired_result = {'device': 'lo0', 'ipv4': [{'flags': '1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu': '8232'}], 'ipv6': [], 'type': 'unknown'}
    assert result == desired_result
    # Test 2

# Generated at 2022-06-23 00:09:16.150023
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    fails_on_platforms = ['Darwin', 'FreeBSD', 'Linux']
    if any(platform in NetworkCollector._platform() for platform in fails_on_platforms):
        raise SkipTest("Platform is not {}".format(','.join(fails_on_platforms)))
    platform = SunOSNetwork()

    # empty output
    interfaces = {}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    rc, out, err = platform.module.run_command([platform.get_bin_path('ifconfig'), '-a'])
    current_if = {}
    result = {}
    for line in out.splitlines():

        if line:
            words = line.split()


# Generated at 2022-06-23 00:09:20.415197
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    s = SunOSNetwork({})
    assert s.platform == 'SunOS'
    # Check that facts were initialized by parent class.
    for attribute in s.facts:
        assert s.facts[attribute] == 'unknown'
    # Check that methods were initialized by parent class.
    for attribute in s._network_metadata:
        assert getattr(s, attribute) is not None

# Generated at 2022-06-23 00:09:33.397315
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    nm = SunOSNetwork()
    assert nm.parse_interface_line(['lo0:', 'flags=2001000849', '<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232', 'index', '1'], {}, {}) is not None
    assert nm.parse_interface_line(['lo0:', 'flags=2002000849', '<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>', 'mtu', '8232', 'index', '1'], {}, {}) is not None

# Generated at 2022-06-23 00:09:35.570286
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert(SunOSNetworkCollector._platform == "SunOS")
    assert(SunOSNetworkCollector._fact_class == SunOSNetwork)


# Generated at 2022-06-23 00:09:40.553334
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork()
    assert sunos_network.get_file_path() == '/usr/sbin/ifconfig'
    assert sunos_network.get_interfaces() == []
    assert sunos_network.get_interfaces_ipv4() == []
    assert sunos_network.get_interfaces_ipv6() == []

# Generated at 2022-06-23 00:09:51.039886
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    network_cls = SunOSNetwork()
    iface = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '0']
    test_current_if = network_cls.parse_interface_line(iface, current_if, interfaces)
    control_current_if = {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL'], 'mtu': '0'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}
    assert test_current_if == control_current_

# Generated at 2022-06-23 00:09:57.254009
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    obj = SunOSNetworkCollector()
    assert(isinstance(obj, SunOSNetworkCollector))
    assert(isinstance(obj.fact_class, GenericBsdIfconfigNetwork))
    assert(obj.platform == 'SunOS')

# Generated at 2022-06-23 00:10:09.835456
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test with one IPv4 interface
    ifconfig_path = './unit/data/ifconfig-SunOS-e1000g0'
    ifconfig_out = open(ifconfig_path).read()

    interfaces, ips = SunOSNetwork.get_interfaces_info(None, ifconfig_path)

# Generated at 2022-06-23 00:10:16.791138
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}
    network_collector = SunOSNetwork()
    network_collector.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-23 00:10:22.753080
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list'),
            'gather_network_resources': dict(default=[], type='list'),
        },
        supports_check_mode=True
    )
    collector = SunOSNetworkCollector(module=module)
    assert collector.module.check_mode is True
    assert collector.module.params['gather_subset'] == []
    assert collector.module.params['gather_network_resources'] == []



# Generated at 2022-06-23 00:10:24.617729
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector().collect()
    assert(facts)

# Generated at 2022-06-23 00:10:37.637919
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = 'lo0:1: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232'.split()
    current_if = SunOSNetwork().parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0:1'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == 'UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL'
    assert current_if['ipv4'][0]['mtu'] == '8232'

    current_if = {}
    interfaces = {}

# Generated at 2022-06-23 00:10:40.407526
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork

# Generated at 2022-06-23 00:10:41.395533
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Create a SunOSNetwork object
    SunOSNetworkCollector(None)

# Generated at 2022-06-23 00:10:52.412814
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    # Setup
    sunos_network = SunOSNetwork()
    interfaces = {}
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232', 'index', '1']

    # Exercise parse_interface_line
    interfaces, current_if = sunos_network.parse_interface_line(words, current_if, interfaces)

    # Verify

# Generated at 2022-06-23 00:11:04.062821
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = None
    ifconfig_path = '/usr/sbin/ifconfig'

    fact_class = SunOSNetwork
    # Expected test results for 'ifconfig -a' output

# Generated at 2022-06-23 00:11:05.972145
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork({})


# Generated at 2022-06-23 00:11:18.248180
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'])})

    # hardcode the results of 'ifconfig -a' to save testing on live OS

# Generated at 2022-06-23 00:11:28.143232
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = Mock()
    module.run_command.return_value = (0, sunos_ifconfig_a, '')
    n = SunOSNetwork(module)
    interfaces, ips = n.get_interfaces_info(n.ifconfig_path)
    for iface in interfaces:
        for v in 'ipv4', 'ipv6':
            num = len(interfaces[iface][v])
            assert(num == 1)
            for facts in interfaces[iface][v]:
                for k in facts:
                    if k == 'address':
                        assert(facts[k] == '127.0.0.1')
                    elif k == 'prefixlen':
                        assert(facts[k] == 8)

# Generated at 2022-06-23 00:11:41.350237
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = None
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    sunos_network = SunOSNetwork(module)
    words = ['ether', 'a:b:c:d:e:f']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == 'a:b:c:d:e:f'
    words = ['ether', '0:1:2:d:e:f']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_

# Generated at 2022-06-23 00:11:52.494652
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    ifconfig_path = '/sbin/ifconfig'

    # Set up some test data based on the output of 'ifconfig -a' on a Solaris 10 system

# Generated at 2022-06-23 00:11:54.081085
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector.get_facts()


# Generated at 2022-06-23 00:12:07.973190
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())
    ipv4_networks = module.params.get('ipv4_networks')
    ipv4_interfaces = module.params.get('ipv4_interfaces')
    ipv6_networks = module.params.get('ipv6_networks')
    ipv6_interfaces = module.params.get('ipv6_interfaces')
    ipv4_addresses = module.params.get('ipv4_addresses')
    ipv6_addresses = module.params.get('ipv6_addresses')
    instance = SunOSNetwork(module)
    assert instance.ipv4_networks == ipv4_networks
    assert instance.ipv4_interfaces == ipv4_interfaces
    assert instance.ipv6

# Generated at 2022-06-23 00:12:20.963632
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    w = ['ether', '0:1:2:d:e:f']
    d = {'device': 'lo0', 'type': 'loopback', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '8232'}],
         'ipv6': [{'flags': ['UP', 'LOOPBACK,RUNNING', 'MULTICAST', 'IPv6'], 'mtu': '8252'}]}
    i = {'lo0': d}
    e = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    # first call
    s = SunOSNetwork()
    s.parse_ether_line(w, d, e)
    assert i == s

# Generated at 2022-06-23 00:12:22.858407
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    result = SunOSNetwork({})
    assert result is not None
    assert result.plugin == 'SunOSNetwork'

# Generated at 2022-06-23 00:12:26.050597
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)
    assert sunos_network != None


# Generated at 2022-06-23 00:12:38.318372
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    mod = MockNetworkModule()
    mod.run_command = Mock(return_value=(0, 'interface1: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2\n    inet 192.168.1.50 netmask ffffff00 broadcast 192.168.1.255\n    ether 0:3:ba:d:e:ad', None))
    obj = SunOSNetwork(mod)
    obj.get_interfaces_info('/sbin/ifconfig')

    for inter in obj.interfaces.values():
        assert inter['device'] == 'interface1'
        assert inter['macaddress'] == '00:03:ba:0d:0e:ad'
        assert inter['type'] == 'unknown'

# Generated at 2022-06-23 00:12:41.755258
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector(None)
    assert isinstance(collector, SunOSNetworkCollector)
    assert isinstance(collector.get_facts(), SunOSNetwork)


# Generated at 2022-06-23 00:12:43.349051
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    ip_cls_sunos = SunOSNetwork(module)
    assert ip_cls_sunos.platform == 'SunOS'
    assert ip_cls_sunos.module == module



# Generated at 2022-06-23 00:12:45.214508
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    mc = SunOSNetworkCollector()
    assert mc._fact_class.platform == 'SunOS'

# Generated at 2022-06-23 00:12:50.253256
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    ips = {}

    # test payload for single digit octets in macaddress
    words = ['ether', '0:1:2:d:e:f']
    SunOSNetwork.parse_ether_line(None, words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:12:52.350455
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert(facts.get_facts() == {})


# Generated at 2022-06-23 00:13:04.458255
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    Test the method SunOSNetwork.parse_ether_line
    """

    # Initialize a SunOSNetwork object
    sunos_network_obj = SunOSNetwork()

    # Test with a string composed of 2 octets
    current_if = sunos_network_obj.parse_ether_line(['ether', '0:1:2:d:e:f'], {'ipv4': [{'flags': 'UP', 'mtu': '1500'}, {'flags': 'UP', 'mtu': '1500'}], 'ipv6': [], 'device': 'net0', 'type': 'loopback', 'macaddress': ''}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})

# Generated at 2022-06-23 00:13:16.584370
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    test = SunOSNetwork()
    test.module = get_module_mock()


# Generated at 2022-06-23 00:13:29.624718
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sut = SunOSNetwork({})
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # test case #1: a normal MAC address
    words = ['ether', '0:1:2:3:4:5']
    sut.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

    # test case #2: MAC address with single digit octets
    words = ['ether', '0:1:2:3:d:e:f']
    sut.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-23 00:13:35.847451
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.module == None
    assert collector.facts['all_ipv4_addresses'] == []
    assert collector.facts == {'default_ipv4_gateway': None, 'default_ipv6_gateway': None, 'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

# Generated at 2022-06-23 00:13:38.269240
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert isinstance(facts, NetworkCollector)
    assert isinstance(facts.get_facts(), SunOSNetwork)

# Generated at 2022-06-23 00:13:39.680361
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector

# Generated at 2022-06-23 00:13:45.981891
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    my_SunOSNetworkCollector = SunOSNetworkCollector()
    assert collector.__class__.__name__ == my_SunOSNetworkCollector.__class__.__name__
    assert collector.__class__.__bases__[0].__name__ == my_SunOSNetworkCollector.__class__.__bases__[0].__name__


# Generated at 2022-06-23 00:13:53.462729
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork()
    # Solaris 10 ifconfig -a
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index']
    current_if = {}
    interfaces = {}
    current_if = facts.parse_interface_line(words, current_if, interfaces)
    assert current_if == {'device': 'lo0', 'ipv4': [{'flags': 'UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL', 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:13:55.005949
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    test = SunOSNetwork()
    assert test.platform == 'SunOS'

# Generated at 2022-06-23 00:13:59.315778
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Check that facts are set correctly by the constructor of class SunOSNetworkCollector
    """
    network = SunOSNetworkCollector()
    assert network._fact_class == SunOSNetwork
    assert network._platform == 'SunOS'

# Generated at 2022-06-23 00:14:12.637188
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    ifcfg = SunOSNetwork({})
    current_if = None
    interfaces = {}

    words = ['lo0:',
             'flags=2001000849',
             'mtu 0',
             'inet 127.0.0.1',
             'netmask ff000000']
    current_if = ifcfg.parse_interface_line(words, current_if, interfaces)
    assert dict(current_if) == {'device': 'lo0', 'ipv4': [{'mtu': '0', 'flags': '2001000849'}], 'ipv6': [], 'type': 'unknown'}

    words = ['lo0:', 'flags=2001000849', 'mtu 4096', 'inet 127.0.0.1', 'netmask ff000000']
    current_if = ifcfg.parse_interface_line

# Generated at 2022-06-23 00:14:17.242538
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
        Unit test for constructor of class SunOSNetwork
    """
    simple_network = SunOSNetwork(dict(module=dict()))
    assert simple_network.platform == "SunOS"


# Generated at 2022-06-23 00:14:29.321752
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = type('AnsibleModule', (object,), dict(params={}, check_mode=False))()
    # test case 1:
    words = ['en0:', 'flags=30802<BROADCAST,SIMPLEX,MULTICAST,NEEDSGIANT>', 'mtu=1500', 'options=3<RXCSUM,TXCSUM>', 'ether', '48:5b:39:ff:2a:b6', 'addr:1.2.3.4', 'mask:255.255.255.0']
    iface = dict(device='en0', ipv4=[], ipv6=[], type='unknown')
    ipv6 = dict(device='en0', ipv4=[], ipv6=[], type='unknown')
    sunOSNW = SunOSNetwork(m)
    iface

# Generated at 2022-06-23 00:14:34.513353
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Set up test environment
    current_if = {'device':'net0'}
    class TestSunOSNetwork(SunOSNetwork):
        def parse_unknown_line(self, words, current_if, ips):
            current_if['macaddress'] = words[0]
    test_sunos_network = TestSunOSNetwork(None)

    # Test parsing of a typical ether line
    words = ['ether', '0:1:2:d:e:f']
    test_sunos_network.parse_ether_line(words, current_if, None)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    # Test parsing of a typical ether line
    words = ['ether', '0:1:2:3:4:5']
    test_sunos

# Generated at 2022-06-23 00:14:43.285876
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    actual_if = {}
    actual_current_if = {}
    actual_line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = actual_line.split()
    test_obj = SunOSNetwork()

    actual_current_if = test_obj.parse_interface_line(words, actual_current_if, actual_if)
    assert(actual_current_if)


# Generated at 2022-06-23 00:14:55.799025
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:14:58.148550
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-23 00:14:58.792146
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-23 00:15:10.339298
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork()
    words = 'abc0: flags=3004863<UP,LOOPBACK,RUNNING,MULTICAST,V6,NOLINKLOCAL> mtu 8232 index 1'.split()
    current_if = {}
    interfaces = {}
    current_if = facts.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'abc0'
    assert current_if['ipv6'][0]['flags'] == '3004863<UP,LOOPBACK,RUNNING,MULTICAST,V6,NOLINKLOCAL>'
    assert current_if['ipv6'][0]['mtu'] == '8232'
    assert current_if['type'] == 'loopback'


# Generated at 2022-06-23 00:15:12.772078
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    nm = SunOSNetwork()
    assert nm.platform == 'SunOS'

# Generated at 2022-06-23 00:15:24.496570
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:15:37.520851
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # This test verifies that method parse_ether_line of class SunOSNetwork parses lines with
    # different lengths of MAC addresses correctly and adds leading zero, if needed.
    # Leading zero doesn't make a difference when comparing two MAC addresses, but it
    # makes results more readable.
    #
    # The method is not used any more, but why not to have a unit test for it?
    current_if = {}
    line_1 = '0:1:2:d:e:f'
    words_1 = line_1.split()
    # If a line with MAC address 0:1:2:d:e:f is parsed, method parse_ether_line should
    # add leading zero to each octet of the MAC address, so MAC address will be 00:01:02:0d:0e:0f.

# Generated at 2022-06-23 00:15:48.306824
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    network = SunOSNetwork()
    assert network.platform == 'SunOS'
    assert network.collected_facts['default_gateway'] == 'unknown'
    assert network.collected_facts['default_gateway_interface'] == 'unknown'
    assert network.collected_facts['domain'] == 'unknown'
    assert network.collected_facts['fqdn'] == 'unknown'
    assert network.collected_facts['hostname'] == 'unknown'
    assert network.collected_facts['netmask'] == 'unknown'
    assert network.collected_facts['network_package'] == 'unknown'
    assert network.collected_facts['subnets'] == []
    assert network.collected_facts['interface_ip'] == 'unknown'
    assert network.collected_facts['interfaces'] == []
    assert network.collected

# Generated at 2022-06-23 00:15:55.165504
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    '''
    Test method parse_ether_line of class SunOSNetwork
    '''
    current_if = {}
    ips = {}
    SunOSNetwork().parse_ether_line(['ether', '0:14:4f:a7:39:d6'], current_if, ips)
    assert current_if['macaddress'] == "00:14:4f:a7:39:d6"

# Generated at 2022-06-23 00:15:56.363268
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ns = SunOSNetworkCollector()
    assert ns._fact_class.platform == 'SunOS'



# Generated at 2022-06-23 00:15:59.042890
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._fact_class  == SunOSNetwork
    assert SunOSNetworkCollector._platform  == 'SunOS'

# Generated at 2022-06-23 00:16:01.627200
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Test SunOSNetwork class
    """
    # Test with default values for args
    obj = SunOSNetwork()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 00:16:04.250454
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork(None)
    assert sunos_network.platform == 'SunOS'

# Generated at 2022-06-23 00:16:12.615461
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork()
    current_if = {}
    ips = {}
    # The line passed to this method contains the macaddress.
    line = "ether 0:1:2:d:e:f"
    # Split the line into words.
    words = line.split()
    # Call the method under test.
    m.parse_ether_line(words, current_if, ips)
    # Check the results.
    assert current_if['macaddress'] == "00:01:02:0d:0e:0f"
    # Here we check that the current_if and ips dicts were not altered by the method.
    assert not current_if
    assert not ips

# Generated at 2022-06-23 00:16:16.882248
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test the constructor for the SunOSNetworkCollector"""
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork



# Generated at 2022-06-23 00:16:19.282090
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    a = SunOSNetworkCollector()
    assert a
    assert a._fact_class == SunOSNetwork
    assert a._platform == 'SunOS'

# Generated at 2022-06-23 00:16:29.122218
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # input arguments
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>', 'mtu', '8232', 'index', '1']
    current_if = {}
    interfaces = {}
    # initialize object
    sunos_network = SunOSNetwork()
    # call method
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    # test results
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>'