

# Generated at 2022-06-23 00:06:35.987776
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    test_data = [
        [["ether", "0:1:2:d:e:f"], {'macaddress': '00:01:02:0d:0e:0f'}],
        [["ether", "f:e:d:2:1:0"], {'macaddress': '0f:0e:0d:02:01:00'}],
        [["ether", "01:02:0a:0b:c:d"], {'macaddress': '01:02:0a:0b:0c:0d'}],
    ]

    for in_data, out_data in test_data:
        current_if = {}
        facts.parse_ether_line(in_data, current_if, {})
        assert current_if == out_data

# Generated at 2022-06-23 00:06:43.622381
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork()
    assert m.parse_ether_line(["ether", "0:1:2:d:e:f"], {}, {}) == {"macaddress": "00:01:02:0d:0e:0f"}
    assert m.parse_ether_line(["ether", "1:2:3:a:b:c"], {}, {}) == {"macaddress": "01:02:03:0a:0b:0c"}
    assert m.parse_ether_line(["ether", "0:1:2:3:4:5"], {}, {}) == {"macaddress": "00:01:02:03:04:05"}

# Generated at 2022-06-23 00:06:44.911739
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork
    assert SunOSNetwork.platform == 'SunOS'

# Generated at 2022-06-23 00:06:51.908013
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:07:02.304189
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network import SunOSNetwork
    from ansible.module_utils.facts.network.ifconfig import FreeBSDIfconfigNetwork

    test_object = SunOSNetwork()
    # test data

# Generated at 2022-06-23 00:07:14.521596
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    "Unit test for method get_interfaces_info of class SunOSNetwork"
    ifconfig_path = 'tests/unit/module_utils/facts/network/network_sunos_ifconfig_output.txt'
    with open(ifconfig_path, 'r') as ifconfig_file:
        ifconfig_txt = ifconfig_file.read()
    ifconfig_txt = '{}\n'.format(ifconfig_txt)
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, ifconfig_txt, '')
    interfaces = SunOSNetwork(module).get_interfaces_info(ifconfig_path)

# Generated at 2022-06-23 00:07:19.266166
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('', (), {})()
    setattr(module, '_ansible_is_test', True)
    setattr(module, 'run_command', lambda *_: [255, '', 'An error occurred'])
    iface = SunOSNetwork(module)
    assert iface.platform == 'SunOS'
    assert iface.ifconfig_path == '/usr/sbin/ifconfig'


# Generated at 2022-06-23 00:07:21.234562
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    myTestSunOSNetwork = SunOSNetwork()
    assert myTestSunOSNetwork is not None

# Generated at 2022-06-23 00:07:24.452487
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Create an instance of SunOSNetworkCollector
    obj = SunOSNetworkCollector()

    assert obj.platform == 'SunOS', 'platform should be SunOS'

# Generated at 2022-06-23 00:07:37.395370
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    if_parse = SunOSNetwork(module)

    current_if = {'device': 'lo0', 'ipv6': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'],
                                             'mtu': '8232'}], 'type': 'loopback', 'ipv4': [],
                  'macaddress': 'unknown'}
    current_if = if_parse.parse_interface_line(['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>',
                                                'mtu', '8232'], current_if, {})
    assert current_if['device'] == 'lo0'

# Generated at 2022-06-23 00:07:44.727674
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    '''Unit test for constructor of class SunOSNetwork'''
    from ansible_collections.azure.azcollection.plugins.module_utils.network.common.network_template import NetworkTemplate
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    net = SunOSNetwork(NetworkTemplate())

    assert net.__class__.__name__ == 'SunOSNetwork'
    assert isinstance(net, GenericBsdIfconfigNetwork)

# Generated at 2022-06-23 00:07:49.367869
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifaces_info, ips = SunOSNetwork().get_interfaces_info('/sbin/ifconfig')
    assert type(ifaces_info) == dict
    assert type(ips) == dict
    assert type(ifaces_info['bge0']) == dict
    assert type(ifaces_info['bge0']['ipv4']) == list
    assert type(ifaces_info['bge0']['ipv4'][0]) == dict
    assert type(ifaces_info['bge0']['ipv6']) == list
    assert type(ifaces_info['bge0']['ipv6'][0]) == dict
    assert type(ifaces_info['bge0']['ipv4'][0]['address']) == str

# Generated at 2022-06-23 00:07:59.305303
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_interfaces = {}
    test_current_if = {}
    test_ips = {}
    test_words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '11']
    test_current_if = SunOSNetwork().parse_interface_line(test_words, test_current_if, test_interfaces)
    assert test_current_if.get('device') == 'lo0'
    assert 'ipv4' in test_current_if
    assert 'ipv6' not in test_current_if
    assert len(test_current_if.get('ipv4')) == 1
    assert test_current_if.get('ipv4')[0].get

# Generated at 2022-06-23 00:08:03.143883
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print("Testing SunOSNetworkCollector")
    obj = SunOSNetworkCollector()
    assert obj.platform == "SunOS"
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-23 00:08:15.119749
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:08:23.881065
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create a module, as if it were from a playbook
    from ansible.module_utils.facts import ModuleArgsParser
    args = dict(gather_subset='!all,!min')
    fake_module = ModuleArgsParser.parse_kv(args)

    # Create an instance of SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    sunos_net = SunOSNetwork(fake_module)

    # Prepare fake data and a 'current_if' dict that can hold the data.
    current_if = dict()
    fake_data1 = ['ether', '0:1:2:d:e:f']
    fake_data2 = ['ether', 'a:b:c:d:e:f']

    # run answer01, convert macaddress to a string to avoid 'bytes

# Generated at 2022-06-23 00:08:37.140820
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # pylint: disable=undefined-variable
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    ifconfig_path = module.get_bin_path('ifconfig', True)
    collector = SunOSNetworkCollector(module=module)
    interfaces, ips = collector.get_interfaces_info(ifconfig_path)
    assert interfaces['hme0']['macaddress'] == '08:00:20:3e:dd:1f'
    assert interfaces['hme0']['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-23 00:08:47.856757
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network_module = SunOSNetwork(dict(module=dict()), dict(), dict())
    current_if = dict()
    ips = dict()

    # Test case with 0:1:2:a:b:c
    words = ['ether', '0:1:2:a:b:c']
    network_module.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0a:0b:0c'

    # Test case with 00:11:22:c:d:e
    words = ['ether', '00:11:22:c:d:e']
    network_module.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-23 00:09:00.556800
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Test if SunOSNetwork.get_interfaces_info() works correctly
    # monkeypatch module
    class TestModule:
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-23 00:09:01.609386
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector is not None

# Generated at 2022-06-23 00:09:06.047911
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Constructor of SunOSNetwork class should set platform to 'SunOS'
    """
    sunos_network = SunOSNetwork()
    assert sunos_network.platform == 'SunOS'

# Generated at 2022-06-23 00:09:16.915890
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-23 00:09:23.483482
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    tester = SunOSNetwork()
    tester.parse_interface_line(['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232'], current_if, interfaces)
    tester.parse_interface_line(['lo0:', 'flags=1000829<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>', 'mtu', '8232'], current_if, interfaces)
    tester.parse_interface_line(['vlan10:', 'flags=1004841<UP,RUNNING,MULTICAST,DHCP,IPv4>', 'mtu', '1500'], current_if, interfaces)
    tester.parse

# Generated at 2022-06-23 00:09:35.570287
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_values = (
        {
            'words': [
                'ether', '0:1:2:3:4:5',
            ],
            'current_if': {'device': 'lo0'},
            'ips': {},
            'expected_macaddress': '00:01:02:03:04:05',
        },
        {
            'words': [
                'ether', '0:1:2:d:e:f',
            ],
            'current_if': {'device': 'lo0'},
            'ips': {},
            'expected_macaddress': '00:01:02:0D:0E:0F',
        },
    )

    for test_value in test_values:
        sunos = SunOSNetwork({})

# Generated at 2022-06-23 00:09:37.223390
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
   SunOSNetworkCollector()

# Generated at 2022-06-23 00:09:39.705777
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sunos_network = SunOSNetwork(module)
    assert sunos_network.platform == 'SunOS'

# Generated at 2022-06-23 00:09:50.266467
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_ifconfig_out = """lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        inet6 ::1/128
        inet6 fe80::1/10
        options=80003<RXCSUM,TXCSUM,LINKSTATE>
        groups: lo"""

    # Use a stub of the AnsibleModule object
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, sunos_ifconfig_out, '')
    })

    sunos_net = SunOSNetwork(module)

# Generated at 2022-06-23 00:10:01.848841
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Test SunOSNetwork.parse_interface_line() method
    """
    # Create an instance of SunOSNetwork
    test_obj = SunOSNetwork()
    # Create a test interface dictionary
    test_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    # Test interface dict for 'lo0'
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    test_obj.parse_interface_line(words, test_if, {})
    assert test_if['device'] == 'lo0'

# Generated at 2022-06-23 00:10:05.234420
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    obj = SunOSNetworkCollector()
    assert isinstance(obj, NetworkCollector)
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork



# Generated at 2022-06-23 00:10:11.350100
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunosnetwork = SunOSNetwork()
    words = ["ether", "0:1:1:1:1:f"]
    current_if = {}
    ips = {}
    sunosnetwork.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:01:01:01:0f'

# Generated at 2022-06-23 00:10:13.936568
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    #setup
    args = dict(module=None)
    obj = SunOSNetwork(args)
    assert obj is not None

# Generated at 2022-06-23 00:10:18.680382
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['all'], type='list')),
        supports_check_mode=True)

    runner = ModuleRunner(module)
    facts = runner.get_facts()

    iface = facts['ansible_interfaces'][0]
    assert facts['ansible_facts']['ansible_net_gather_subset'] == ['all']
    assert facts['ansible_facts']['ansible_net_hostname'] == 'localhost'
    assert facts['ansible_facts']['ansible_net_all_ipv4_addresses'] == [ '127.0.0.1' ]

# Generated at 2022-06-23 00:10:29.381433
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = type('AnsibleModule', (), {'run_command': lambda x, **y: (0, 'ether 9:0:2:3:d:e:f', None)})
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    sunos_network = SunOSNetwork(module=module)
    sunos_network.parse_ether_line(['ether', '9:0:2:3:d:e:f'], current_if, ips)
    assert current_if['macaddress'] == '90:02:03:0d:0e:0f'

# Generated at 2022-06-23 00:10:41.906587
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = 'tests/unit/module_utils/facts/network/SunOS/ifconfig_a_ipv4_ipv6'

# Generated at 2022-06-23 00:10:44.854885
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    test_object = SunOSNetworkCollector()
    assert test_object._fact_class == SunOSNetwork
    assert test_object._platform == 'SunOS'

# Generated at 2022-06-23 00:10:51.607244
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collectorname = "SunOSNetworkCollector"
    collectorname2 = "ansible_net_SunOS_NetworkCollector"
    network_fact_class = "SunOSNetwork"
    network_platform = "SunOS"

    x = SunOSNetworkCollector()
    assert x
    assert hasattr(x, '_fact_class')
    assert repr(x._fact_class) == "<class 'ansible.module_utils.facts.network.sunos.SunOSNetwork'>"
    assert x._fact_class.__name__ == network_fact_class
    assert hasattr(x, '_platform')
    assert x._platform == network_platform
    assert hasattr(x, 'collect')

# Generated at 2022-06-23 00:10:53.189028
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert issubclass(SunOSNetworkCollector._fact_class, SunOSNetwork)

# Generated at 2022-06-23 00:10:57.396123
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('module', (object, ), dict(run_command=run_command_mock))()
    module.run_command.side_effect = module_side_effect
    sunosnetwork = SunOSNetwork(module)
    interfaces, ips = sunosnetwork.get_interfaces_info('/sbin/ifconfig')
    assert interfaces == TEST_INTERFACES
    assert ips == TEST_IPS


# Generated at 2022-06-23 00:10:58.998187
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert type(obj) == SunOSNetworkCollector

# Generated at 2022-06-23 00:11:11.324917
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector.get_module({})
    network_collector = SunOSNetworkCollector(module=module)
    # Fact gathering succeeds and returns a list of interfaces
    # with associated IPv4 and IPv6 facts for each
    ifaces, ips = network_collector.get_interfaces_info('/usr/sbin/ifconfig')
    for iface_name, iface_properties in ifaces.items():
        if iface_name == 'lo0':
            assert iface_properties.get('ipv4')[0].get('netmask') == '255.0.0.0'
            assert iface_properties.get('ipv6')[0].get('netmask') == 'ffff:ffff:ffff:ffff::'

# Generated at 2022-06-23 00:11:12.768879
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()


# Generated at 2022-06-23 00:11:24.661253
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeAnsibleModule()
    # Create a new instance of this class so that _is_local_address() gets called
    network = SunOSNetwork(module)

    interfaces = {}
    current_if = {}

    # 'words' is a list of strings from '/sbin/ifconfig -a'
    # The line being processed looks like
    #   'lo0:2        flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'
    words = 'lo0:2        flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'.split()
    current_if = network.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:11:28.216474
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOS_Network_Collector = SunOSNetworkCollector()
    assert SunOS_Network_Collector._fact_class == SunOSNetwork
    assert SunOS_Network_Collector._platform == 'SunOS'
    assert SunOS_Network_Collector._enable_default_collectors is True


# Generated at 2022-06-23 00:11:41.402323
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    words1 = ['ether', '0:14:4f:b0:8f:40', 'auto', 'receive']
    words2 = ['ether', 'b:0:4f:2f:8f:40', 'auto', 'receive']
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    mac_addr = SunOSNetwork()
    mac_addr.parse_ether_line(words1, current_if, ips)
    assert current_if['macaddress'] == '00:14:4f:b0:8f:40', 'Mac address is not valid'
    mac_addr.parse

# Generated at 2022-06-23 00:11:42.402537
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network=SunOSNetwork({})
    assert sunos_network.__class__ == SunOSNetwork


# Generated at 2022-06-23 00:11:44.264427
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    un = SunOSNetwork({})
    assert un
    assert un.platform == 'SunOS'

# Generated at 2022-06-23 00:11:54.773557
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # Test setup
    test_network = SunOSNetwork({})

# Generated at 2022-06-23 00:11:57.972074
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    n = SunOSNetworkCollector()
    assert n.platform == 'SunOS'
    assert n._fact_class == SunOSNetwork


# Generated at 2022-06-23 00:12:00.845671
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    facts = SunOSNetwork()
    assert facts.platform == 'SunOS'

# Generated at 2022-06-23 00:12:13.182396
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test values taken from a Solaris 10 system and checked on Solaris 11.
    interface_line1 = 'lo0: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1'
    interface_line2 = 'lo0:1: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1'
    interface_line3 = 'lo0:2: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1'
    interface_line4 = 'lo0:3: flags=849<UP,LOOPBACK,RUNNING,MULTICAST> mtu 8232 index 1'

# Generated at 2022-06-23 00:12:14.754705
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()
    assert net.platform == 'SunOS'

# Generated at 2022-06-23 00:12:27.246382
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = FakeModule(platform='SunOS')
    network = SunOSNetwork(module=module)

    words1 = ["""ether0:","flags=150841<UP,BROADCAST,RUNNING,MULTICAST,DEPRECATED>","mtu","1500"""]
    words2 = ["ether0:","flags=150841<UP,BROADCAST,RUNNING,MULTICAST,DEPRECATED>","mtu","1500"]
    words3 = ["ether0:","flags=150841<UP,BROADCAST,RUNNING,MULTICAST,DEPRECATED>","ether","0:4:d:cf:a::a"]

# Generated at 2022-06-23 00:12:39.260560
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """Test parsing of the 'ifconfig -a' output"""
    ansible_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    ifconfig_path = ansible_module.get_bin_path('ifconfig', True)
    sunos_network = SunOSNetwork(ansible_module)
    sunos_network.collect_subset = ['all']
    interfaces = {}
    current_if = {}

# Generated at 2022-06-23 00:12:47.575040
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork()
    current_if = {'device': 'net0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', '0:1:2:d:e:f']
    network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:12:56.579339
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = dict(ipv4=[dict(mtu='')], ipv6=[dict(mtu='')], type='unknown')
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    words = ['ether', '0:1:2:d:e:f']
    SunOSNetwork._collector = SunOSNetworkCollector()
    SunOSNetwork().parse_ether_line(words, current_if, ips)

# Generated at 2022-06-23 00:13:00.263215
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-23 00:13:02.395612
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    obj = SunOSNetworkCollector({}, None)
    assert obj
    assert obj._fact_class._platform == 'SunOS'

# Generated at 2022-06-23 00:13:13.860885
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    test_facts = SunOSNetwork({})
    test_interface = 'lo0'
    test_ignore = ['lo']


# Generated at 2022-06-23 00:13:18.690534
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Constructor of SunOSNetworkCollector class automatically
    detects the file paths.
    """
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.ifconfig_path == '/sbin/ifconfig'
    assert obj.get_interfaces_info('/sbin/ifconfig -a')
    assert not obj.get_interfaces_info('nonexistent_path')

# Generated at 2022-06-23 00:13:20.987819
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = SunOSNetwork()
    assert module.platform == 'SunOS'


# Generated at 2022-06-23 00:13:33.339546
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:13:45.746398
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    module = type('module', (object,), {'run_command': None})()
    obj = SunOSNetwork(module)

    # Check the inherited method 'get_interfaces_info'
    assert obj.get_interfaces_info('/sbin/ifconfig') is (None, None)

    # Check the inherited method 'get_network_os'
    assert obj.get_network_os() == 'SunOS'

    # Check the inherited method 'get_default_interfaces'

# Generated at 2022-06-23 00:13:58.333077
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-23 00:14:04.999631
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    ipnet_sunos = SunOSNetworkCollector(module=module)
    assert ipnet_sunos.platform == 'SunOS', "platform must be set to 'SunOS'"
    assert ipnet_sunos.fact_class is SunOSNetwork, "fact_class is not class SunOSNetwork, but %s" % type(ipnet_sunos.fact_class)
    assert ipnet_sunos.ifconfig_path == '/sbin/ifconfig', "ifconfig_path must be set to '/sbin/ifconfig'"
    assert ipnet_sunos.route_path == '/usr/sbin/route', "route_path must be set to '/usr/sbin/route'"


# Generated at 2022-06-23 00:14:05.863108
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    print('Testing SunOSNetworkCollector()')
    obj = SunOSNetworkCollector()
    assert (obj.platform == 'SunOS')

# Generated at 2022-06-23 00:14:12.988319
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Pass in a mock 'module' class and verify that the class, SunOSNetworkCollector inherits
    NetworkCollector and instanciates SunOSNetwork.
    """
    mocked_module = Mock(name='module')
    obj = SunOSNetworkCollector(module=mocked_module, platform='SunOS')
    assert isinstance(obj, NetworkCollector)
    assert isinstance(obj._fact_class, SunOSNetwork)
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 00:14:14.737158
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net_class = SunOSNetwork()
    assert net_class.platform == "SunOS"


# Generated at 2022-06-23 00:14:27.365278
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:14:40.743385
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Helper function for unit test
    def test_one_interface(iface):
        facts = SunOSNetwork()
        words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu:8232', 'index:1']
        words.append('ether' + iface)
        words.extend(['device:lo', 'inet:127.0.0.1', 'netmask:ffffff00', 'broadcast:127.255.255.255'])
        current_if = facts.parse_interface_line(words[0:4], {}, {})
        ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

# Generated at 2022-06-23 00:14:53.696830
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Mocking basic conditions
    current_if = {}
    interfaces = {}
    # Testing first line of output from an Oracle VM server
    words = ["e1000g0:", "flags=2010001802<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>", "mtu=1500"]
    test_if = SunOSNetwork()
    assert test_if.parse_interface_line(words, current_if, interfaces) == {'device': 'e1000g0', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4', 'CoS'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}
    # Testing second line of output from an Oracle VM server

# Generated at 2022-06-23 00:15:06.028523
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = type('test_module', (object,), {'run_command': lambda *args, **kwargs: (0, '', '')})
    net = SunOSNetwork(test_module)
    assert net.parse_interface_line(['lo0:', 'flags=80049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '8232', 'index', '1'], {}, {}) == {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:15:13.827879
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['flags'] == "UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL"
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['macaddress']

# Generated at 2022-06-23 00:15:16.742873
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sys_net_cls = SunOSNetwork()
    assert sys_net_cls
    assert sys_net_cls.platform == 'SunOS'

# Generated at 2022-06-23 00:15:21.799257
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    from ansible.module_utils.facts.collector.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.interfaces import NetworkInterfaces
    sun = SunOSNetwork(NetworkInterfaces())
    assert(sun.platform == 'SunOS')
    assert(sun.ifconfig_path == '/usr/sbin/ifconfig')

# Generated at 2022-06-23 00:15:34.915569
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:15:41.112244
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector(None, None).collect()

    # there should be at least one interface (lo0)
    assert len(facts['interfaces'].keys()) >= 1

    # there should be at least one IPv4 address (127.0.0.1)
    assert len(facts['all_ipv4_addresses']) >= 1

    # there should be at least one IPv6 address (::1)
    assert len(facts['all_ipv6_addresses']) >= 1


# Generated at 2022-06-23 00:15:52.617951
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    import io
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts import Collector

    fake_module = Collector()
    sun_net = SunOSNetwork(fake_module)

    # Test with empty dict, interface is unknown
    current_if = {}
    interfaces = {}
    line = "qfe41: flags=1001000843<UP,BROADCAST,RUNNING,MULTICAST,DEPRECATED,IPv4> mtu 1500 index 3"
    words = line.split()
    current_if = sun_net.parse_interface_line(words, current_if, interfaces)
    assert current_if['type'] == 'unknown'


# Generated at 2022-06-23 00:16:04.202411
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    s = SunOSNetwork({})
    current_if = {}
    ips = {}
    out = []
    out.append('ether 0:1:2:d:e:f')
    out.append('ether 0:1:2:d:e:f')
    out.append('ether 0:1:2:d:e:f')
    out.append('ether 0:1:2:d:e:f')
    out.append('ether a:d:e:f:0:1')
    out.append('ether 0:0:0:0:0:0')
    for line in out:
        words = line.split()
        s.parse_ether_line(words, current_if, ips)
        assert current_if['macaddress'] == words[1]

# Generated at 2022-06-23 00:16:13.478203
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:16:24.128602
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    data = {'ansible_facts': {'ansible_net_interfaces':
                    {'lo0':
                        {'ipv4': [{'broadcast': '127.255.255.255',
                                   'address': '127.0.0.1',
                                   'netmask': '255.0.0.0'}],
                         'ipv6': [{'broadcast': '::1',
                                   'address': '::1',
                                   'netmask': 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff'}]}
                     }}}
    assert SunOSNetworkCollector.collect(data) == data

# Generated at 2022-06-23 00:16:32.820174
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """runs test_SunOSNetwork_parse_interface_line() function"""

    ifconfig_output_line = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n"
    words = ifconfig_output_line.split()
    interface_name = words[0][0:-1]
    interfaces = {}
    current_if = {}
    current_if['device'] = None
    current_if['ipv4'] = []
    current_if['ipv6'] = []
    current_if['type'] = 'unknown'
    interfaces[interface_name] = current_if

    current_if = interfaces[interface_name]