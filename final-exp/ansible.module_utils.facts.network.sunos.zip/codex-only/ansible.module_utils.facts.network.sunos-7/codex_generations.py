

# Generated at 2022-06-23 00:06:26.116228
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork


# Generated at 2022-06-23 00:06:36.781304
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('AnsibleModule', (object,), {'run_command': lambda *_: (0, '', '')})()
    ifc_collector = SunOSNetworkCollector(module=module)

    # `ifconfig -a` output from a real Solaris 10 box

# Generated at 2022-06-23 00:06:47.220799
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Initialize the SunOSNetwork class instance
    sunos_network = SunOSNetwork()

    # Create the test cases

# Generated at 2022-06-23 00:07:00.066134
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork()
    current_if = {
        'device': 'lan0',
        'ipv4': [{'flags': ['IPv4', 'BROADCAST', 'MULTICAST', 'UP'], 'mtu': '1500'}],
        'ipv6': [],
        'type': 'ethernet',
        'macaddress': 'unknown'
    }
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[]
    )
    line = 'ether 0:1:2:d:e:f'
    words = line.split()
    network.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-23 00:07:05.774832
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector('/usr/sbin/ifconfig')
    assert isinstance(network_collector, NetworkCollector)
    assert network_collector._platform == 'SunOS'
    assert isinstance(network_collector._fact_class, SunOSNetwork)

# Generated at 2022-06-23 00:07:16.469679
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """Test parse_interface_line method for SunOSNetwork class."""


# Generated at 2022-06-23 00:07:22.743568
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork(dict())
    assert sunos_network.platform == 'SunOS'
    assert sunos_network.flags_regex == re.compile(r'\<(?P<flags>[^<>]+)\>')
    assert sunos_network.mac_regex == re.compile(r'ether (\S+)')
    assert sunos_network.mtu_regex == re.compile(r'mtu (\d+)')
    assert sunos_network.netmask_regex == re.compile(r'netmask (\S+)')
    assert sunos_network.address_regex == re.compile(r'inet (\S+)')
    assert sunos_network.ipv6_address_regex == re.compile(r'inet6 (\S+)')


# Generated at 2022-06-23 00:07:35.444612
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

# Generated at 2022-06-23 00:07:47.215479
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOS_net = SunOSNetwork()
    # Unit test for get_interfaces_info()
    # Test 1: No interface
    SunOS_net.interfaces = {}
    SunOS_net.gather_platform_facts()
    assert SunOS_net.platform_subclass.facts == {}
    # Test 2: Interface exists

# Generated at 2022-06-23 00:07:48.185700
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunOSNetwork = SunOSNetwork({'module': None})
    assert sunOSNetwork.platform == 'SunOS'

# Generated at 2022-06-23 00:07:58.117606
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = None
    current_if = {}
    ips = {}

# Generated at 2022-06-23 00:08:00.326060
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 00:08:13.340114
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifconfig_path = 'tests/unit/module_utils/facts/network/sunos/ifconfig'
    net = SunOSNetwork()
    net.module = FakeModule()
    net.module.run_command = FakeRunCommand(ifconfig_path=ifconfig_path)
    interfaces, ips = net.get_interfaces_info(ifconfig_path)
    assert interfaces['net0']['ipv4'][0]['address'] == '172.16.3.24'
    assert interfaces['net0']['ipv4'][0]['broadcast'] == '172.16.3.255'
    assert interfaces['net0']['ipv4'][0]['netmask'] == '255.255.255.0'
    assert interfaces['net0']['ipv6'][0]['address']

# Generated at 2022-06-23 00:08:21.927054
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockModule()
    net = SunOSNetwork(module)

    # Set up input
    ifconfig_path = '/sbin/ifconfig'
    rc = 0

# Generated at 2022-06-23 00:08:35.270030
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = get_module_mock()
    obj = SunOSNetwork(module)

    # ifconfig_path = /usr/sbin/ifconfig
    ifconfig_path = '/usr/sbin/ifconfig'
    # ifconfig -a

# Generated at 2022-06-23 00:08:46.516618
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Arrange
    words = ['lo0: ', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '2']
    current_if = {}
    interfaces = {}
    network = SunOSNetwork(dict())
    # Act
    current_if = network.parse_interface_line(words, current_if, interfaces)
    # Assert
    expected_current_if = {'device': 'lo0', 'ipv4': [{'flags': 'lo0: <UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:08:59.606440
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces, ips = SunOSNetwork().get_interfaces_info(ifconfig_path='/sbin/ifconfig')

# Generated at 2022-06-23 00:09:11.660726
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork


# Generated at 2022-06-23 00:09:20.478304
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    import json


# Generated at 2022-06-23 00:09:33.448320
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    module = GenericBsdIfconfigNetwork.MockModule()


# Generated at 2022-06-23 00:09:34.830162
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():

    # Constructor of class SunOSNetworkCollector without any parameters
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'

# Generated at 2022-06-23 00:09:41.976268
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    t = SunOSNetwork()

    # test with no leading zeroes
    current_if = {'macaddress': 'unknown'}
    words = ['ether', '0:1:2:d:e:f']
    t.parse_ether_line(words, current_if, None)
    assert current_if['macaddress'] == '00:01:02:0D:0E:0F'

    # test with leading zeroes
    current_if = {'macaddress': 'unknown'}
    words = ['ether', '00:01:02:dd:ee:ff']
    t.parse_ether_line(words, current_if, None)
    assert current_if['macaddress'] == '00:01:02:DD:EE:FF'

# Generated at 2022-06-23 00:09:51.874735
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:10:04.075469
# Unit test for method parse_ether_line of class SunOSNetwork

# Generated at 2022-06-23 00:10:08.984319
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    ansible_module_mock = AnsibleModuleMock()
    sunos_network_collector = SunOSNetworkCollector(ansible_module_mock, 'dummy_network_arg_spec')
    assert sunos_network_collector.fact_class is SunOSNetwork



# Generated at 2022-06-23 00:10:12.709359
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_class = SunOSNetworkCollector('SunOS')
    assert fact_class.collect() is not None
    assert fact_class._fact_class(dict()) is not None


# Generated at 2022-06-23 00:10:17.075474
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    collector = SunOSNetwork(module=module)
    assert collector.platform == 'SunOS'
    assert collector.module == module

# Generated at 2022-06-23 00:10:24.937298
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    network_collector = SunOSNetworkCollector(module=module)
    network_collector._platform = 'SunOS'
    network_collector._asic_type = 'xge'
    network_collector._pre_existing_interfaces = {}

    # Populate the output of ifconfig for corresponding asic_type
    # xge_out is for "xge" asic_type

# Generated at 2022-06-23 00:10:35.245557
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mysunos_network = SunOSNetwork(dict(module=dict()), 'no_path')
    assert mysunos_network.platform == 'SunOS'
    assert mysunos_network.ignore_list == [
        'lo0',
        'lo',
    ]
    assert mysunos_network.key_order == [
        'default_interface',
        'default_ipv4',
        'default_ipv6',
        'devices',
        'interfaces',
        'all_ipv4_addresses',
        'all_ipv6_addresses'
    ]


# Generated at 2022-06-23 00:10:46.445258
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    nm = SunOSNetwork(module)

    out = dict()
    words = ['lo0:', 'flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    nm.parse_interface_line(words, out, [])
    assert out['type'] == 'loopback'

    out = dict()
    words = ['igb0:', 'flags=201004841<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv6>', 'mtu', '1500']
    nm.parse_interface_line(words, out, [])
    assert out['type'] == 'unknown'

# Generated at 2022-06-23 00:10:55.592418
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('', (), {})()
    module.run_command = lambda x: [1, '', '']
    module.parse_ifconfig_output = lambda x: {}
    module.get_bin_path = lambda x: '/sbin/ifconfig'
    module.ip_version_from_address = lambda x: 0

    facts = SunOSNetwork(module)
    facts.populate()

    interfaces = facts.interfaces
    for key in interfaces:
        assert 'device' in interfaces[key]
        assert 'ipv4' in interfaces[key]
        assert 'ipv6' in interfaces[key]
        assert 'type' in interfaces[key]
        assert 'macaddress' in interfaces[key]
        assert 'mtu' in interfaces[key]
        assert 'flags' in interfaces[key]


# Generated at 2022-06-23 00:10:58.129269
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'



# Generated at 2022-06-23 00:10:59.357725
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector(dict())


# Generated at 2022-06-23 00:11:02.250048
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == "SunOS"
    assert obj._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:11:11.467980
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():

    test = SunOSNetwork()
    test.parse_ether_line(['ether', '8:0:20:d:e:f'], {}, {})
    assert test.facts['interfaces']['lo0']['macaddress'] == '08:00:20:0d:0e:0f'
    test.parse_ether_line(['ether', '8:0:20:d:e:f', 'extra', 'words'], {}, {})
    assert test.facts['interfaces']['lo0']['macaddress'] == '08:00:20:0d:0e:0f'

# Generated at 2022-06-23 00:11:18.179306
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    current_if = {}
    ips = {}
    words = ['ether', '0:1:2:d:e:f']
    current_if = facts.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:11:28.113149
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test data
    words = [
        'e1000g0:',
        'flags=1000000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>',
        'mtu=1500',
    ]
    current_if = {}
    interfaces = {}
    # Code under test
    current_if = SunOSNetwork.parse_interface_line(
        SunOSNetwork(), words, current_if, interfaces)
    # Check for expected result
    assert current_if['device'] == 'e1000g0'
    assert current_if['type'] == 'unknown'

# Generated at 2022-06-23 00:11:32.515417
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'


# Generated at 2022-06-23 00:11:41.505661
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    e = SunOSNetwork()
    f = {'device': 'lo0', 'ipv4': [], 'ipv6': []}
    i = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    e.parse_ether_line(['ether', '0:d:e:f:1:2'], f, i)
    assert f == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'macaddress': '00:de:0f:01:02'}

# Generated at 2022-06-23 00:11:45.003146
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sun = SunOSNetwork(module)

    # 'options' is a dict of dicts
    assert isinstance(sun.options, dict)
    for v in 'ipv4', 'ipv6':
        assert isinstance(sun.options[v], dict)

    assert sun.module == module
    assert sun.platform == 'SunOS'
    assert sun.interfaces == {}
    assert sun.ips == {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }
    assert sun.all_ipv4_addresses == []
    assert sun.all_ipv6_addresses == []


# Generated at 2022-06-23 00:11:48.985177
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class._platform == 'SunOS'
    assert isinstance(obj.fact_class(obj.module), SunOSNetwork)



# Generated at 2022-06-23 00:11:50.866009
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class is SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-23 00:11:59.509888
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Unit test for constructor of class SunOSNetworkCollector
    """

    m_get_file_content = \
        SunOSNetworkCollector.__swig_getmethods__['get_file_content']

    SunOSNetworkCollector.get_file_content = \
        lambda self, filename: ""

    SunOSNetworkCollector("", "")
    SunOSNetworkCollector.__swig_setmethods__['get_file_content'] = \
        SunOSNetworkCollector.get_file_content


# Generated at 2022-06-23 00:12:11.356878
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """Test parse_interface_line() of class SunOSNetwork"""
    interfaces = {}
    current_if = {}
    words = ['bge0:', 'flags=2001000843', 'mtu=1500', 'index=0']
    current_if = SunOSNetwork._parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'bge0'
    assert current_if['ipv4'][0]['flags'] == ['IPv4', 'IPMP', 'BROADCAST', 'NXDOMAIN', 'MULTICAST']
    assert current_if['ipv4'][0]['mtu'] == '1500'
    assert current_if['ipv6'] == []
    assert current_if['macaddress'] == 'unknown'


# Generated at 2022-06-23 00:12:24.047469
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    '''
    This is a unit test for the method parse_interface_line of class SunOSNetwork
    '''
    module = AnsibleModule(argument_spec=dict())
    facts = SunOSNetwork()

    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    current_if = facts.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:12:36.740540
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    import io
    import sys
    import textwrap
    sys.path.insert(0, '.')
    sys.path.insert(0, '..')
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    kwargs = dict(
        module=dict(),
    )
    obj = SunOSNetwork(**kwargs)
    file_name = 'SunOSNetwork.parse_ether_line'

    # test 1:
    input_string = "0:12:34:0a:1b:2c"
    current_if = dict(macaddress='unknown')
    expected_results = {'macaddress': '00:12:34:0a:1b:2c'}
    results = obj.parse_ether_line(input_string.split(), current_if, {})
   

# Generated at 2022-06-23 00:12:47.854907
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:13:00.459779
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test = SunOSNetwork()
    test_interfaces = {}      # test_interfaces is the interfaces list for this test
    test_current_if = {}      # test_current_if is current_if to be passed to parse_interface_line
    test_interfaces_out = {}  # test_interfaces_out is the returned interfaces list for this test
    test_current_if_out = {}  # test_current_if_out is the returned interface
    test_output = ''          # test_output is the output to be parsed by parse_interface_line
    test_words = ''           # test_words is the output split into a list

    # Test 1: output line is blank
    test_output = ' '
    test_words = test_output.split()

# Generated at 2022-06-23 00:13:11.486990
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:13:20.051393
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:13:30.913243
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos = SunOSNetwork()
    words = ['ether', '0:1:2:3:4:5']
    current_if = {}
    ips = {}
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:13:43.381289
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ Unit test for method get_interfaces_info of class SunOSNetwork """

    # initialize the test environment
    test_obj = SunOSNetwork()

    # initialize needed constants
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-23 00:13:52.251854
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule({'gather_subset': ["!all"], "gather_timeout": 5})
    SunOSNetwork = SunOSNetworkCollector(module=module, file_module=FileModule)
    result = SunOSNetwork.get_interfaces_info()


# Generated at 2022-06-23 00:14:02.907258
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {
        'device': 'bge0',
        'ipv4': [{
            'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'IPv4'],
            'mtu': '1500',
        }],
        'ipv6': [{
            'flags': [],
            'mtu': '1500',
        }],
        'type': 'unknown',
        'macaddress': '',
    }
    ips = {}
    sunos_network = SunOSNetwork()
    sunos_network.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, ips)

# Generated at 2022-06-23 00:14:14.695327
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:14:18.186814
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    net = SunOSNetworkCollector()
    assert isinstance(net.get_facts(),dict)
    net.get_facts()

# Generated at 2022-06-23 00:14:22.117235
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    net_SunOS = SunOSNetwork()
    result = str(net_SunOS)

    assert type(net_SunOS).__name__ == "SunOSNetwork"
    assert "SunOSNetwork" in result
    assert "Network" in result

# Generated at 2022-06-23 00:14:26.230696
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import TestGenericBsdIfconfigNetwork as TestGenericBsdIfconfigNetwork
    TestGenericBsdIfconfigNetwork.test_get_interfaces_info(SunOSNetwork)

# Generated at 2022-06-23 00:14:37.538954
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Constructor test for class SunOSNetwork.

    """

    # Constructor for class SunOSNetwork
    sunos_network = SunOSNetwork()

    # Checks the properties of object
    assert sunos_network.platform == 'SunOS'
    assert sunos_network.interfaces == [], 'incorrect interfaces property value'
    assert sunos_network.interface_list == [], 'incorrect interface_list property value'
    assert sunos_network.all_ipv4_addresses == [], 'incorrect all_ipv4_addresses property value'
    assert sunos_network.all_ipv6_addresses == [], 'incorrect all_ipv6_addresses property value'

# Generated at 2022-06-23 00:14:45.345792
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    line = 'net0: flags=10<BROADCAST,INET> mtu 1500 index 2'
    current_if = {}

    obj = SunOSNetwork({})
    result = obj.parse_interface_line(line.split(), current_if, {})

    assert result == {'device': 'net0', 'ipv4': [{'flags': ['BROADCAST', 'INET'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-23 00:14:57.668343
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = FakeAnsibleModule()
    network = SunOSNetwork(module)
    test_interface_config = interface_config.interface_config
    test_interface_config = test_interface_config.replace("\r","")
    test_interface_config = test_interface_config.split("\n")
    interfaces, ips = network.get_interfaces_info(test_interface_config)

    assert interfaces["ce0"]["device"] == "ce0"
    assert interfaces["ce0"]["ipv4"][0]["mtu"] == "1500"
    assert interfaces["ce0"]["ipv4"][0]["flags"] == ['BROADCAST', 'MULTICAST', 'IPv4']

# Generated at 2022-06-23 00:14:59.212403
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Basic constructor test
    """

    SunOSNetworkCollector()

# Generated at 2022-06-23 00:15:10.649498
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test 1
    sunos_network = SunOSNetwork()
    words = ['ip.tun0:', 'flags=2d<UP,POINTOPOINT>', 'mtu=1450', 'index=79']
    current_if = {'device': 'ip.tun0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'ip.tun0': current_if}
    result = sunos_network.parse_interface_line(words, current_if, interfaces)
    assert result['device'] == 'ip.tun0'
    assert result['type'] == 'unknown'
    assert result['macaddress'] == 'unknown'
    assert len(result['ipv4']) == 1
    assert len(result['ipv6']) == 0

# Generated at 2022-06-23 00:15:22.818285
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Constructor test"""

    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(choices=['all', 'min'], default=['min']))
    )

    # validate constructor of SunOSNetwork
    sunos_network_facts = SunOSNetwork(module)
    assert sunos_network_facts.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig') is not None

# Generated at 2022-06-23 00:15:23.899525
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'

# Generated at 2022-06-23 00:15:26.922024
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = _get_module_mock()
    obj = SunOSNetwork(module)
    assert isinstance(obj.facts, dict)


# Generated at 2022-06-23 00:15:39.108490
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """This constructs a SunOSNetwork object, calls populate(), then calls
    all its getters.  This ensures that all the getters
    return sane values without throwing any exceptions.  Expected values are
    arbitrary as long as they are not exceptions.
    """
    facts = {}
    SunOSNetwork(facts)
    # Populates facts dict with the results of an ifconfig -a
    facts['SunOSNetwork'].populate()

    for k, v in SunOSNetwork.__dict__.items():
        # skip private attributes and methods
        if k.startswith('_'):
            continue

        print(k)
        # Call getter
        if 'get_' + k in SunOSNetwork.__dict__:
            func = getattr(facts['SunOSNetwork'], 'get_' + k)

# Generated at 2022-06-23 00:15:42.932890
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    if not HAS_SUNOS_IFCONFIG:
        module.fail_json(msg='sunos_ifconfig not installed')
    net = SunOSNetwork(module=module)
    assert net.module.run_command.call_count == 0

# Generated at 2022-06-23 00:15:55.778844
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule({'gather_subset': ['all']})
    interfaces = {}
    current_if = {}
    words = 'lo0:3 flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'.split()
    current_if = SunOSNetwork().parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-23 00:16:07.462365
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''
    Test the following facts using Solaris 11.3 on x86_64:
    - interfaces
    - all_ipv4_addresses
    - all_ipv6_addresses
    '''
    test_vars = SunOSNetwork(dict(module=None))
    result = test_vars.get_interfaces_info(ifconfig_path='/usr/sbin/ifconfig')[0]

# Generated at 2022-06-23 00:16:10.215096
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj, NetworkCollector)
    assert isinstance(obj._fact_class, SunOSNetwork)
    assert obj._platform == 'SunOS'


# Generated at 2022-06-23 00:16:16.700261
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork()

    # Test MAC address with leading zeros in each octet
    current_if = {'macaddress': 'unknown'}
    m.parse_ether_line(['ether', '0:0:0:0:0:0'], current_if, {})
    assert current_if['macaddress'] == '00:00:00:00:00:00'

    # Test MAC address with no leading zeros in each octet
    current_if = {'macaddress': 'unknown'}
    m.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:16:19.108310
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        obj = SunOSNetworkCollector()
        assert obj.platform == 'SunOS'
    except ImportError:
        pass

# Generated at 2022-06-23 00:16:24.975136
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork({})
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}
    m.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'