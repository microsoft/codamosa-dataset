

# Generated at 2022-06-23 00:06:26.293867
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    collector = SunOSNetworkCollector(module=module)
    interfaces, ips = collector.collect()


# Generated at 2022-06-23 00:06:27.775887
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    myiface = SunOSNetwork()
    assert myiface != None


# Generated at 2022-06-23 00:06:32.693610
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

# Generated at 2022-06-23 00:06:34.071375
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector is not None


# Generated at 2022-06-23 00:06:43.702802
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sun = SunOSNetwork(module)
    facts = sun.get_facts()
    interfaces = facts['interfaces']
    for key in interfaces.keys():
        print(key)
        for k, v in interfaces[key].items():
            print("   %s: %s" % (k, v))
        # assert isinstance(interfaces[key]['ipv4'], list)
        # assert isinstance(interfaces[key]['ipv6'], list)
        # assert 'active' in interfaces[key]

if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-23 00:06:57.415392
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from test.units.module_utils.facts.network.test_network_collector import TestNetworkCollector
    from test.units.module_utils.facts.network.test_generic_bsd import \
        TestGenericBsdIfconfigNetwork

    platform = 'SunOS'

# Generated at 2022-06-23 00:07:04.506350
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    line = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1"
    words = line.split()
    current_if = SunOSNetwork().parse_interface_line(words, current_if, interfaces)
    assert current_if['type'] == 'loopback'
    assert current_if['device'] == "lo0"
    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv6']) == 0
    assert current_if['ipv4'][0]['mtu'] == "8232"
    assert "LOOPBACK" in current_if['ipv4'][0]['flags']

# Generated at 2022-06-23 00:07:07.856874
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module)
    assert collector.get_fact_class() == SunOSNetwork

# Generated at 2022-06-23 00:07:17.730225
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Test method parse_interface_line of class SunOSNetwork.
    :return: None
    """
    o = SunOSNetwork()

    # Test with IPv4 interface
    words = ['bge0:', 'flags=2000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = {'device': words[0], 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    o.parse_interface_line(words, current_if, current_if)

    # Check results
    assert current_if['device'] == words[0][0:-1]

# Generated at 2022-06-23 00:07:23.427567
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test = SunOSNetwork({})

# Generated at 2022-06-23 00:07:36.130368
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork """

    ifconfig_path = 'ifconfig'

    # 'ifconfig -a' output on a Solaris 11.4 (with VirtualBox extensions)
    #
    # The Solaris 'ifconfig' utility displays interfaces twice, once for IPv4
    # and again for IPv6. This sample output shows two physical adapters and
    # a virtual loopback adapter. Note that there are IPv6 facts for 'lo0'
    # even though the output also contains an 'inet6: lo0' stanza.
    #
    # The 'ifconfig -a' output can be obtained with:
    # $ /sbin/ifconfig -a
    #

# Generated at 2022-06-23 00:07:38.995682
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork

# Generated at 2022-06-23 00:07:49.776197
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    m = SunOSNetwork()
    current_if = {}
    expected_if = {}
    interfaces = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    line = 'lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1'
    words = line.split()
    current_if = m.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:07:59.824559
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('', (), dict())()

# Generated at 2022-06-23 00:08:04.099550
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule({})
    result = {
        'SunOSNetwork': 'SunOSNetwork'
    }
    obj = SunOSNetworkCollector(module)
    assert obj.facts == result

# Generated at 2022-06-23 00:08:15.537752
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    result = SunOSNetworkCollector(module).collect()
    facts = result[0]

    assert facts['default_ipv4']['interface'] == 'net0', 'default_ipv4 interface is not correct'
    assert facts['default_ipv4']['gateway'] == '10.0.2.2', 'default_ipv4 gateway is not correct'
    assert facts['default_ipv6']['interface'] == 'net0', 'default_ipv6 interface is not correct'
    assert facts['default_ipv6']['gateway'] == 'fe80::a00:27ff:fef5:5c1a', 'default_ipv6 gateway is not correct'
    assert facts

# Generated at 2022-06-23 00:08:16.827712
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()


# Generated at 2022-06-23 00:08:24.803857
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This is a unit test for the method get_interfaces_info of class SunOSNetwork
    """
    iface = SunOSNetwork()

    # Set expected stdout
    iface.module.run_command.return_value = (0, SOLARIS_IFCONFIG_ALL, None)

    # Call the method under test
    interfaces, ips = iface.get_interfaces_info('')

    # Assert expected dictionary returned
    assert(interfaces == SOLARIS_EXPECTED_INTERFACES)
    assert(ips == SOLARIS_EXPECTED_IPS)



# Generated at 2022-06-23 00:08:37.800781
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    s = SunOSNetwork({}, dict())
    result = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = s.parse_interface_line(words, current_if, result)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['ipv4'][0]['flags'] == 'UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL'
    current_if = {}

# Generated at 2022-06-23 00:08:41.422807
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert isinstance(obj._fact_class, SunOSNetwork)
    assert obj._platform == 'SunOS'


# Generated at 2022-06-23 00:08:50.257701
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Setup test data
    ifconfig_path = 'tests/unit/module_utils/facts/network/sunos_ifconfig.txt'
    test_data = open(ifconfig_path, 'r')
    test_data_str = test_data.read()
    test_data.close()

    # Prepare expected results

# Generated at 2022-06-23 00:08:52.176454
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    Solaris = SunOSNetworkCollector()
    assert Solaris._platform == 'SunOS'

# Generated at 2022-06-23 00:09:02.956805
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork


# Generated at 2022-06-23 00:09:14.800631
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network import SunOSNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    # example line: ether 0:1:2:d:e:f
    words = ['ether', '0:1:2:d:e:f', 'media:', 'Ethernet', 'autoselect', '(100baseTX)', 'status:', 'active']
    current_if = {}
    ips = {}
    SunOSNetwork.parse_ether_line(SunOSNetwork, words, current_if, ips)
    correct_macaddress = '00:01:02:0d:0e:0f'
    assert current_if['macaddress'] == correct_

# Generated at 2022-06-23 00:09:16.875445
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = {}
    SunOSNetworkCollector(facts, None)
    assert facts['ansible_facts']['ansible_net_interfaces'] == {}


# Generated at 2022-06-23 00:09:28.751309
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=[], type='list'),))
    SunOSNetworkFactCollector = SunOSNetworkCollector(module)
    SunOSNetwork = SunOSNetworkFactCollector.collect()[0]

    assert SunOSNetwork.platform == 'SunOS', 'Platform should be SunOS but it is {}'.format(SunOSNetwork.platform)
    assert SunOSNetwork.gather_subset == ['default'], 'Gather subset should be default but it is {}'.format(SunOSNetwork.gather_subset)

    interfaces, ips = SunOSNetwork.get_interfaces_info('/sbin/ifconfig')
    # print(json.dumps({'interfaces': interfaces, 'ips': ips}, indent=2))
    # print(json.dumps({'

# Generated at 2022-06-23 00:09:29.812445
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-23 00:09:33.734361
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork as test_ifaces

    test_ifaces = test_ifaces()
    test_ifaces.get_interfaces_info('/usr/sbin/ifconfig')

# Generated at 2022-06-23 00:09:34.628872
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    facts = SunOSNetwork()
    assert isinstance(facts, SunOSNetwork)

# Generated at 2022-06-23 00:09:44.563792
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    line = 'ether 0:1:2:d:e:f'
    words = line.split()
    current_if = {}
    interface = SunOSNetwork(None, None)
    # call method to test with empty current_if
    interface.parse_ether_line(words, current_if, None)
    # test that macaddress was added to current_if
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'
    assert len(current_if) == 1
    assert current_if['macaddress'] != '0:1:2:d:e:f'
    assert current_if['macaddress'] != '0:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:09:47.162263
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = DummyModule()
    obj = SunOSNetworkCollector(module)
    assert obj._fact_class == SunOSNetwork
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 00:09:49.601723
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    assert isinstance(SunOSNetworkCollector(), SunOSNetworkCollector)


# Generated at 2022-06-23 00:09:56.464147
# Unit test for method parse_ether_line of class SunOSNetwork

# Generated at 2022-06-23 00:10:04.810828
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    fact_class = SunOSNetwork()
    current_if = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}
    words = ['ether', '0:1:2:d:e:f']
    macaddress = ''
    fact_class.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:10:07.109590
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    result = SunOSNetwork()
    assert hasattr(result, 'platform')
    assert result.platform == 'SunOS'


# Generated at 2022-06-23 00:10:19.672222
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    ifconfig_path = module.get_bin_path('ifconfig', required=True)


# Generated at 2022-06-23 00:10:31.857646
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create test data
    ifconfig_path = "/sbin/ifconfig"
    current_if = {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    words = ['bge0:', 'flags=8c03<UP,BROADCAST,RUNNING,IPv4,NOARP,SIMPLEX,MULTICAST>', 'mtu:9000']

    # Create class instance and execute method to test
    test_class = SunOSNetwork()
    result = test_class.parse_interface_line(words, current_if, interfaces)

    # Check result

# Generated at 2022-06-23 00:10:44.630653
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # Create a module for testing purposes.
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Create a class for testing purposes.
    netcollector = collector.get_network_collector(module)
    network_class = netcollector._fact_class(module)

    # Options that are used as arguments to get_interfaces_info()
    options = {
        "ifconfig_path": "/sbin/ifconfig",
        "get_type_from_ip_output": True
    }

    # Create a file that contains the output of 'ifconfig -a'.
    # This file will serve as stdout (and stderr) during the test.

# Generated at 2022-06-23 00:10:46.352920
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    obj = SunOSNetwork({})
    assert isinstance(obj, SunOSNetwork)

# Generated at 2022-06-23 00:10:55.554267
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:10:59.570579
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # create instance of class
    SunOSNetworkCollector = SunOSNetworkCollector()
    # check class variables
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'


# Generated at 2022-06-23 00:11:11.850698
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = FakeAnsibleModule()

    # If Solaris doesn't use the GenericBsdIfconfigNetwork class
    if SunOSNetwork.__bases__[0].__name__ != 'GenericBsdIfconfigNetwork':
        raise Exception('SunOSNetwork does not inherit from GenericBsdIfconfigNetwork')

    # If Solaris doesn't use the correct platform
    if SunOSNetwork.platform != 'SunOS':
        raise Exception('SunOSNetwork has wrong platform')

    # If Solaris can't parse a 'media' line
    if SunOSNetwork.parse_media_line(['media:', 'Ethernet', 'autoselect'], {}, {}) != None:
        raise Exception('SunOSNetwork.parse_media_line() should return None')

    # If Solaris can't parse an 'ether' line

# Generated at 2022-06-23 00:11:14.667991
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork


# Generated at 2022-06-23 00:11:26.093143
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-23 00:11:38.795068
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import json

    # We need to patch the 'GenericBsdIfconfigNetwork' class to add the 'get_options' method
    def get_options(self, flags):
        return flags

    GenericBsdIfconfigNetwork.get_options = get_options

    test = SunOSNetwork()
    test.module = FakeAnsibleModule()
    test.module.get_bin_path = lambda x, opts: '/sbin/ifconfig'
    test.module.run_command = lambda exe: (0, '', '')
    test.get_interfaces_info('/sbin/ifconfig')

    interfaces, ips = test.interfaces, test.ips
    assert isinstance(interfaces, dict)

    # Test

# Generated at 2022-06-23 00:11:40.975378
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = SunOSNetwork()
    assert module.platform == 'SunOS'


# Generated at 2022-06-23 00:11:52.169496
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type("module", (object,), {})()
    module.run_command = lambda x: (0, '', '')
    sunos_network = SunOSNetwork(module)
    rc, out, err = module.run_command = lambda x: (0, sunos_network_get_interfaces_info_output, '')
    interfaces, ips = sunos_network.get_interfaces_info('/sbin/ifconfig')

    assert interfaces['lo0']['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
    assert interfaces['lo0']['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-23 00:11:55.513828
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    pc = SunOSNetworkCollector()
    assert pc._platform == "SunOS"
    assert pc._fact_class.__name__ == "SunOSNetwork"
    assert pc._fact_class.platform == "SunOS"



# Generated at 2022-06-23 00:12:09.333113
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', default=['!all', '!min']),
        'filter': dict(type='list', default=[])
    })

    # Construct a dummy file to be used as ifconfig_path
    file_obj = tempfile.NamedTemporaryFile()

# Generated at 2022-06-23 00:12:22.331349
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # fixture
    module = 'SunOS'

    # test data
    ifconfig_path = 'ifconfig'

# Generated at 2022-06-23 00:12:35.153734
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = None
    ip_path = 'bin/ip'
    ifconfig_path = 'bin/ifconfig'

# Generated at 2022-06-23 00:12:46.320565
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    This function unit tests method 'get_interfaces_info' of class 'SunOSNetwork'.
    """
    # Generate a dictionary containing test data

# Generated at 2022-06-23 00:12:58.033602
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None       # dummy value
    mac_if = {'device': 'e1000g0', 'mtu': '1500', 'type': 'unknown',
              'macaddress': 'unknown', 'ipv4': [], 'ipv6': []}
    lo0_if = {'device': 'lo0', 'mtu': '18186', 'type': 'unknown',
              'macaddress': 'unknown', 'ipv4': [], 'ipv6': []}
    sun_net = SunOSNetwork(module)
    # Run the method
    res = sun_net.parse_interface_line(['e1000g0:', 'flags=1000843', 'mtu', '1500'],
                                       {}, {})
    # Check we got what we expected
    assert res == mac_if
    # Run the method
    res

# Generated at 2022-06-23 00:13:04.340150
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    macaddress = ''
    words = '0:1:2:d:e:f ether'.split(' ')
    for octet in words[0].split(':'):
        octet = ('0' + octet)[-2:None]
        macaddress += (octet + ':')
    macaddress = macaddress[0:-1]
    assert macaddress == '00:01:02:0d:0e:0f'


# Generated at 2022-06-23 00:13:14.960204
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    '''
    SunOSNetwork.parse_interface_line unit test
    '''
    interfaces_before = {}
    current_if = {}
    words = ['erri0:', '<LOOPBACK,UP,LOWER_UP>', 'mtu', '8232', 'index', '1',
             'inet', '127.0.0.1', 'netmask', 'ffffff00']
    SunOSNetwork().parse_interface_line(words, current_if, interfaces_before)
    assert interfaces_before['erri0']['ipv4'][0]['flags'] == ['LOOPBACK', 'UP', 'LOWER_UP']


# Generated at 2022-06-23 00:13:27.270495
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeAnsibleModule()
    facts = SunOSNetwork(module)
    words = ['ip.tun0:', 'flags=8010<POINTOPOINT,MULTICAST>', 'mtu', '1480', 'index', '7']

    interfaces = {}
    current_if = {}

    current_if = facts.parse_interface_line(words=words, current_if=current_if, interfaces=interfaces)
    expected_interfaces = {'ip.tun0': {'device': 'ip.tun0', 'ipv4': [{'flags': ['POINTOPOINT', 'MULTICAST'], 'mtu': '1480'}], 'ipv6': [], 'type': 'unknown'}}

# Generated at 2022-06-23 00:13:39.411489
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = fake_ansible_module()
    collector = SunOSNetworkCollector(module)
    network_module = collector.get_network_module()
    
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '1']
    assert network_module.parse_interface_line(words, current_if, interfaces) == {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:13:43.372461
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Get facts from the SunOSNetworkCollector class
    facter = SunOSNetworkCollector()
    assert facter._fact_class == SunOSNetwork
    assert facter._platform == 'SunOS'

# Generated at 2022-06-23 00:13:51.976067
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    network = SunOSNetwork(None)
    words = ['ether', '0:1:2:d:e:f']
    current_if = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'macaddress': 'unknown'
    }
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

    network.parse_ether_line(words, current_if, ips)

    assert current_if == {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'macaddress': '00:01:02:0d:0e:0f'
    }

# Generated at 2022-06-23 00:14:02.779513
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''Unit testing for method get_interfaces_info of class SunOSNetwork'''
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    test_module.run_command = MagicMock(return_value=(0, '', ''))

    m = SunOSNetwork(module=test_module, run_command_environ_update={})
    interfaces, ips = m.get_interfaces_info(ifconfig_path='/sbin/ifconfig')

    assert 'lo0' in interfaces
    assert interfaces['lo0']['device'] == 'lo0'
    assert len(interfaces['lo0']['ipv4']) == 1

# Generated at 2022-06-23 00:14:14.559021
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test params
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '1']
    current_if = {'device': 'none'}
    interfaces = {'lo0': {'ipv4': [{'flags': '1000849', 'mtu': '8232'}], 'ipv6': [{'flags': '2000849', 'mtu': '8232'}]}}
    network_class = SunOSNetwork()
    # Actual
    output = network_class.parse_interface_line(words, current_if, interfaces)
    # Expected

# Generated at 2022-06-23 00:14:27.366999
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    from ansible_collections.ansible_junos.plugins.module_utils import network as patch
    import sys
    import os

    c = patch.SunOSNetwork

    script_dir = os.path.dirname(__file__)
    rel_path = "test_SunOSNetwork_get_interfaces_info_data.txt"
    abs_file_path = os.path.join(script_dir, rel_path)

    f = open(abs_file_path, "r")
    ifconfig_path = "/sbin/ifconfig"
    interfaces, ips = c.get_interfaces_info(ifconfig_path)
    assert interfaces['xge0']['ipv4'][0]['address'] == '172.16.88.184'

# Generated at 2022-06-23 00:14:31.048366
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule({})
    network = SunOSNetwork(module)

    assert network.platform == 'SunOS'
    assert network.flags == SunOSNetwork.flags

# Generated at 2022-06-23 00:14:44.243197
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    s = SunOSNetwork()
    iface = {}
    s.parse_ether_line(['ether', '0:1:2:3:4:5'], iface, {})
    assert iface['macaddress'] == '00:01:02:03:04:05'
    iface = {}
    s.parse_ether_line(['ether', '0:11:22:33:44:55'], iface, {})
    assert iface['macaddress'] == '00:11:22:33:44:55'
    iface = {}
    s.parse_ether_line(['ether', 'b:11:22:33:44:55'], iface, {})
    assert iface['macaddress'] == '0b:11:22:33:44:55'

# Generated at 2022-06-23 00:14:56.601891
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    class FakeModule():
        def __init__(self):
            self.run_command_called = False

        def run_command(self, _args, **_kwargs):
            self.run_command_called = True
            return None, None, None

    class FakeSunOSNetwork():
        def __init__(self):
            self.module = FakeModule()

    # Test data
    sunos_network = FakeSunOSNetwork()
    current_if = {}
    words = ['em0:', 'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>',
             'mtu 1500']
    interfaces = {}

    # Parse interface line
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)

    # Assert that device

# Generated at 2022-06-23 00:15:01.147736
# Unit test for method parse_ether_line of class SunOSNetwork

# Generated at 2022-06-23 00:15:11.764104
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from io import StringIO
    # this is the input for method get_interfaces_info of class SunOSNetwork
    # it is the output of /sbin/ifconfig -a, each line is separated by \n

# Generated at 2022-06-23 00:15:13.504598
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Unit test for constructor of SunOSNetwork class."""
    assert SunOSNetwork(dict(module=None)) is not None

# Generated at 2022-06-23 00:15:21.202764
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)

    assert collector.platform == "SunOS"
    assert collector.fact_class._platform == "SunOS"

    # assert isinstance(collector.fact_class.module, AnsibleModule)
    # import ansible.module_utils.facts.cpu.linux
    # assert isinstance(collector.fact_class, ansible.module_utils.facts.cpu.linux.LinuxCPU)



# Generated at 2022-06-23 00:15:21.932340
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 00:15:28.920625
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['ether', '0:1:2:d:e:0']
    SunOSNetwork().parse_ether_line(words, current_if, None)
    assert current_if['macaddress'] == '00:01:02:0d:0e:00'

# Generated at 2022-06-23 00:15:40.309495
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModuleMock()
    network_collector = SunOSNetworkCollector(module=module)
    network = network_collector.get_network_gather_subclass()
    interfaces, ips = network.get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert len(interfaces['lo0']['ipv4']) == 1
    assert interfaces['lo0']['ipv4'][0]['flags'] == ['LOOPBACK', 'RUNNING', 'MULTICAST']
    assert '127.0.0.1' in interfaces['lo0']['ipv4'][0]['address']
    assert '::1' in interfaces['lo0']['ipv6'][0]['address']

# Generated at 2022-06-23 00:15:52.043432
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sun = SunOSNetwork()
    assert sun.platform == 'SunOS'
    assert sun.root_device == 'net0'
    assert sun.protocol_as_root_device == ['Loopback']
    assert sun.ignored_interfaces == ['lo0', 'lo', 'vni', 'vpn', 'gre', 'ipip', 'dummynet', 'pflow']
    assert sun.default_ipv4_interface_name == 'net0'
    assert sun.default_ipv6_interface_name == 'net0'
    assert sun.default_interface_name == 'net0'
    assert sun.interface_name_conversions == {}
    assert sun.gateway_name_conversions == {}

# Generated at 2022-06-23 00:16:04.561985
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = MockModule()
    sunos_ifconfig_facts = SunOSNetwork(module)

    ifconfig_path = 'facts/fixtures/ifconfig_SunOS.txt'
    with open(ifconfig_path, 'r') as ifconfig:
        mock_command('facts/fixtures/ifconfig_SunOS.txt', ifconfig.read())
    interfaces, ips = sunos_ifconfig_facts.get_interfaces_info(ifconfig_path)

    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert interfaces['lo0']['ipv4'][0]['subnet_mask'] == '255.0.0.0'

# Generated at 2022-06-23 00:16:10.304453
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_if = {}
    test_ips = {}
    test_line = 'ether 8:0:20:a:b:c'
    test_words = test_line.split()
    test_object = SunOSNetwork()
    test_object.parse_ether_line(test_words, test_if, test_ips)
    assert test_if['macaddress'] == '08:00:20:0a:0b:0c'

# Generated at 2022-06-23 00:16:16.902151
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # check correct handling of MAC address with single digits
    data = dict(current_if = dict(device = 'e1000g0'), ips = dict(all_ipv4_addresses = []))
    words = ['ether', '0:1:2:d:e:f']
    SunOSNetwork().parse_ether_line(words, data['current_if'], data['ips'])
    assert data['current_if']['macaddress'] == '00:01:02:0d:0e:0f'

    # check correct handling of MAC address with double digits
    data = dict(current_if = dict(device = 'e1000g0'), ips = dict(all_ipv4_addresses = []))
    words = ['ether', '3a:4b:5c:6d:7e:8f']


# Generated at 2022-06-23 00:16:18.800290
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_module = NetworkCollector()
    SunOSNetworkCollector(fact_module)
    return fact_module

# Generated at 2022-06-23 00:16:28.894345
# Unit test for method get_interfaces_info of class SunOSNetwork