

# Generated at 2022-06-23 00:06:25.089141
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-23 00:06:36.218524
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # If a class inherits from another class, the unit test for the base class is also executed.
    # We do not need to duplicate it.
    if GenericBsdIfconfigNetwork not in SunOSNetwork.__bases__:
        raise TypeError('The SunOSNetwork class does not inherit from GenericBsdIfconfigNetwork.')
    # The import must be inside the function to avoid circular references.
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    if not issubclass(SunOSNetwork, GenericBsdIfconfigNetwork):
        raise TypeError('The SunOSNetwork class does not inherit from GenericBsdIfconfigNetwork.')
    if SunOSNetwork is GenericBsdIfconfigNetwork:
        raise TypeError('The SunOSNetwork class does not inherit from GenericBsdIfconfigNetwork.')

# Generated at 2022-06-23 00:06:45.468635
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {}
    ips = {}
    net = SunOSNetwork({})
    mac_address_1 = '01:23:45:67:89:ab'
    mac_address_2 = '1:2:3:4:5:6'
    mac_address_3 = '1:2:3:d:e:f'
    mac_address_4 = '0:1:2:d:e:f'

    words = ['ether', mac_address_1]
    net.parse_ether_line(words, iface, ips)
    net.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] is mac_address_1

    words = ['ether', mac_address_2]
    net.parse_ether_line(words, iface, ips)

# Generated at 2022-06-23 00:06:52.671573
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    We don't want to do 'import network' at the top of this file to make the class
    Network. So instead, we use the constructor of the class SunOSNetwork.
    """
    network_collector = SunOSNetwork()
    assert network_collector.platform == 'SunOS'
    assert network_collector.get_interfaces_info

# Generated at 2022-06-23 00:07:02.605294
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    import json
    import sys
    import os

    lines = [
        'vnic20  flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 7\n',
        'vnic20  flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 7\n',
        'vnic20  flags=20100085a<UP,BROADCAST,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 1500 index 7\n',
        'vnic20  flags=20100084b<UP,BROADCAST,RUNNING,MULTICAST,IPv4,IPv6,VIRTUAL> mtu 1500 index 7\n',
    ]


# Generated at 2022-06-23 00:07:05.329629
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-23 00:07:16.261966
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    testobj = SunOSNetwork()

    words = ['lo0:', '0:1:2:3:4:5', 'UP', 'LOOPBACK', 'RUNNING', 'MTU:', '4096', 'Metric:', '1']
    current_if = testobj.parse_interface_line(words, {}, {})
    testobj.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    current_if = testobj.parse_interface_line(words, {}, {})
    testobj.parse_ether_line([words[0], '0::1:2:3::4:5'], current_if, {})

# Generated at 2022-06-23 00:07:22.429812
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Positive test
    iface = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    line = 'ether 0:1:2:3:4:5'
    SunOSNetwork().parse_ether_line(line.split(), iface, ips)
    assert iface['macaddress'] == '00:01:02:03:04:05'
    iface = {}
    line = 'ether 0:1:2:d:e:f'
    SunOSNetwork().parse_ether_line(line.split(), iface, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'
    # Negative test
    iface = {}

# Generated at 2022-06-23 00:07:35.120739
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:07:38.868488
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Test for '_fact_class' and '_platform'
    obj = SunOSNetworkCollector()
    assert obj._fact_class == SunOSNetwork
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 00:07:40.564371
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    d = SunOSNetwork()
    assert d.platform == 'SunOS'

# Generated at 2022-06-23 00:07:44.427524
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_if = {
        'device': 'e1000g0',
        'ipv4': [{'flags': ['BROADCAST', 'MULTICAST', 'IPv4', 'MPSAFE'], 'mtu': '1500'}],
        'ipv6': [{'flags': ['UP', 'BROADCAST', 'MULTICAST', 'IPv6', 'MPSAFE'], 'mtu': '1500'}],
        'type': 'unknown',
        'macaddress': 'unknown',
    }
    test_ips_dict = {}
    words = ['ether', '1:2:3:d:e:f']
    SunOSNetwork().parse_ether_line(words, test_if, test_ips_dict)

# Generated at 2022-06-23 00:07:53.623053
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = SunOSNetwork()
    # Example data is generated from Mac OS Sierra/High Sierra
    ifconfig_path = './tests/unit/module_utils/facts/network/solaris/ifconfig_lo0'
    interfaces, ips = module.get_interfaces_info(ifconfig_path)
    assert 'lo0' in interfaces
    lo0 = interfaces['lo0']
    assert len(lo0['ipv4']) == 1
    assert len(lo0['ipv6']) == 1
    assert lo0['ipv4'][0]['address'] == '127.0.0.1'
    assert lo0['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-23 00:08:01.331145
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import json

    d = dict(SunOSNetwork._ifconfig_patterns)
    d['ether'] = []
    SunOSNetwork._ifconfig_patterns = d

    class _module(object):
        def __init__(self):
            self.argument_spec = {}
            self.params = {}

        def exit_json(self, **kwargs):
            print(json.dumps(kwargs))
            sys.exit(0)


# Generated at 2022-06-23 00:08:07.122582
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = SunOSNetwork(module)
    assert network_facts.platform == 'SunOS'
    assert network_facts.get_interfaces_info("/sbin/ifconfig")
    assert network_facts.get_interfaces_ip()


# Generated at 2022-06-23 00:08:10.055856
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sun_os_network = SunOSNetwork(module)
    assert sun_os_network.platform == "SunOS"


# Generated at 2022-06-23 00:08:12.139108
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'

# Generated at 2022-06-23 00:08:20.618437
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_subject = SunOSNetworkCollector(None)

    # Test case 1:
    # Test successful parsing of 'ifconfig -a' output.
    # This code is written as a list - not a dictionary, because we don't care
    # what order the elements are delivered in.
    # This test case covers the following facts:
    #    interface, ipv4.flags, ipv4.mtu, ipv6.flags, ipv6.mtu
    input_line_1 = ['bge1:1:1:1:1:1:1:1:', 'UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'MTU:1500', 'Metric:1', 'ip6 address fe80::9e9f:79c8:a8f:47e0/64 ignored']
    # This is

# Generated at 2022-06-23 00:08:21.456342
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork(dict())


# Generated at 2022-06-23 00:08:35.215386
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.utils import get_file_content

    ifconfig_path = '/sbin/ifconfig'
    ifconfig_output = get_file_content(
        'tests/unit/module_utils/net_tools_files/SunOS_ifconfig_all')
    ip_path = '/sbin/ip'
    ip_output = ''

    sunos_networkfact = SunOSNetwork(
        module=None, ifconfig_path=ifconfig_path, ip_path=None)

    interfaces, ips = sunos_networkfact.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-23 00:08:42.640595
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_and_solaris = [False, True]
    for sunos in sunos_and_solaris:
        assert SunOSNetworkCollector({'module': {'run_command': run_command, 'is_sunos': sunos}})._platform == 'SunOS'
        assert SunOSNetworkCollector({'module': {'run_command': run_command, 'is_sunos': sunos}})._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:08:44.841795
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert c is not None
    assert c._fact_class is not None
    assert c._platform is not None

# Generated at 2022-06-23 00:08:52.247478
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-23 00:08:54.758106
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    SunOSNetwork()

# Generated at 2022-06-23 00:09:03.977258
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = DummyModule()
    obj = SunOSNetwork(module)
    words = ['ce0:', 'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    current_if = obj.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'ce0'
    assert current_if['ipv4'] == [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '1500'}]
    assert current_if['ipv6'] == []

# Generated at 2022-06-23 00:09:14.709729
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    words = ["lo0:","flags=849<UP,LOOPBACK,RUNNING,MULTICAST>","mtu","8232","index","6","inet","127.0.0.1","netmask","ffffff00"]
    SunOSNetwork().parse_interface_line(words,current_if,{})
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['mtu'] == "8232"
    assert current_if['ipv4'][0]['flags'] == ["UP", "LOOPBACK", "RUNNING", "MULTICAST"]
    assert current_if['type'] == 'loopback'


# Generated at 2022-06-23 00:09:24.824257
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = type('test', (object,), {})()
    test_module.run_command = lambda x: (0, '', '')
    network = SunOSNetwork(test_module)

    words = ['igb0', '[UP,BROADCAST,RUNNING,MULTICAST]', 'mtu', '1500']
    expected_current_if = {'device': 'igb0', 'type': 'unknown', 'macaddress': 'unknown',
                           'ipv4': [{'flags': '[UP,BROADCAST,RUNNING,MULTICAST]', 'mtu': '1500'}], 'ipv6': []}
    current_if = {}
    assert network.parse_interface_line(words, current_if, {}) == expected_current_if
    assert current_if == expected_current

# Generated at 2022-06-23 00:09:37.046254
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_obj = SunOSNetwork()
    test_obj.module = MagicMock()
    test_words = ['e1000g0:', 'flags=', '<UP,BROADCAST,RUNNING,MULTICAST,DHCP>', 'mtu', '1500']
    test_current_if = {}
    test_interfaces = {}
    result = test_obj.parse_interface_line(test_words, test_current_if, test_interfaces)
    assert result == {'device': 'e1000g0', 'ipv4': [{'flags': '<UP,BROADCAST,RUNNING,MULTICAST,DHCP>', 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:09:44.415975
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    This tests the method parse_interface_line of class SunOSNetwork.
    """
    # Create a SunOSNetwork object
    factobj = SunOSNetwork()
    # Get some lines from ifconfig -a
    input_lines = [
        'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1',
        '        inet 127.0.0.1 netmask ff000000',
        '        inet6 ::1/128',
        '        zone local',
    ]
    # Create a known interface dictionary
    interfaces = {'lo0': {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}

    # Test IPv4 facts
    words = input

# Generated at 2022-06-23 00:09:46.585245
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    s = SunOSNetworkCollector()
    assert s._fact_class == SunOSNetwork
    assert s._platform == 'SunOS'



# Generated at 2022-06-23 00:09:54.714211
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.collector import BaseFactCollector
    import sys

    fact_subclass = SunOSNetworkCollector
    fact_superclass = GenericBsdIfconfigNetwork

    # Test inheritance
    assert issubclass(fact_subclass, fact_superclass)
    assert issubclass(fact_subclass, BaseFactCollector)

    # Test object creation
    network_collector = fact_subclass()

    # Tests inherited attributes and methods
    assert(hasattr(network_collector,'module'))
    assert(hasattr(network_collector,'_platform'))

# Generated at 2022-06-23 00:09:58.484554
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert isinstance(obj.facts, SunOSNetwork)
    assert obj.facts.platform == 'SunOS'

# Generated at 2022-06-23 00:10:11.302714
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # testcase 1
    line = "lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1"
    current_if = {'ipv4': [], 'ipv6': [], 'device': 'lo0', 'type': 'unknown'}
    interfaces = {}
    current_if = SunOSNetwork.parse_interface_line(SunOSNetwork, words=line.split(), current_if=current_if, interfaces=interfaces)
    r = {'ipv4': [{'mtu': '8232', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4']}], 'device': 'lo0', 'ipv6': [], 'type': 'loopback'}
    assert r

# Generated at 2022-06-23 00:10:12.764360
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-23 00:10:18.654245
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    int_fact = SunOSNetwork(None, None)
    current_if = {}
    ips = {}
    words = ['ether', '0:1:2:d:e:f']
    int_fact.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:10:22.213693
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test SunOSNetworkCollector constructor
    Ansible facts depends on this module,
    we need to make sure the class is not broken
    """
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork


# Generated at 2022-06-23 00:10:27.572244
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('Module', (object,),
                  dict(run_command=lambda x: (0, "", "")))()
    network_fact = type('NetworkFact', (object,),
                        dict(module=module))()

    # Test for single interface
    network_fact.parse_interface_line(['lo0:', 'flags=2001000849', '<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1'],
                                      dict(), dict())

    # Test for two interfaces (solaris)

# Generated at 2022-06-23 00:10:40.914008
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """ Unit test for method parse_interface_line of class SunOSNetwork """

    m = SunOSNetwork()
    line = 'net0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 2'
    words = line.split()
    current_if = m.parse_interface_line(words,{},{})

    assert current_if['device'] == 'net0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'
   

# Generated at 2022-06-23 00:10:52.233490
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    mock = MockFacts()
    mock.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-23 00:10:53.252397
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunosnet = SunOSNetwork()
    assert sunosnet.platform == 'SunOS'

# Generated at 2022-06-23 00:11:04.171513
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ''' Unit test for method get_interfaces_info of class SunOSNetwork '''

    fake_module = type('', (object, ), {'run_command': run_command})()

    def run_command(self, args):
        return (0, sunos_ifconfig_all, '')

    sunos_net = SunOSNetwork()
    sunos_net.module = fake_module
    interfaces, ips = sunos_net.get_interfaces_info('/sbin/ifconfig')
    assert interfaces == sunos_interfaces
    assert ips['all_ipv4_addresses'] == sunos_ips
    assert ips['all_ipv6_addresses'] == []



# Generated at 2022-06-23 00:11:05.647082
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert(SunOSNetworkCollector)


# Generated at 2022-06-23 00:11:14.887007
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    '''
    SunOSNetwork.parse_ether_line()
    '''
    test_object = SunOSNetwork({}, {}, {})
    test_words = ['ether', '0:1:2:d:e:f']
    test_current_if = {'device': 'lo0'}
    test_ips = {}

    test_dict = test_object.parse_ether_line(test_words, test_current_if, test_ips)
    assert test_dict['device'] == 'lo0'
    assert test_dict['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:11:20.664877
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    obj = SunOSNetwork()
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}
    obj.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:11:29.573205
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    # prep test data
    test_data_linenum = 0

# Generated at 2022-06-23 00:11:42.906235
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    '''
    Test to see if SunOSNetwork.parse_ether_line() method
    adds leading zeros when needed.
    '''
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}

    obj = SunOSNetwork()
    obj.parse_ether_line(words, current_if, ips)
    if current_if['macaddress'] != '00:01:02:0d:0e:0f':
        print('ERROR: SunOSNetwork.parse_ether_line() does not add leading zeros when needed.')
        print('Expected: 00:01:02:0d:0e:0f')
        print('Got:      ' + current_if['macaddress'])
        exit(1)
    else:
        pass


# Generated at 2022-06-23 00:11:53.780010
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    SunOS_net_ins = SunOSNetwork()

# Generated at 2022-06-23 00:11:56.324203
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    n = SunOSNetwork({}, {}, {}, {}, {}, {})
    assert n.platform == 'SunOS'
    assert n.facts == {}

# Generated at 2022-06-23 00:12:08.695008
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']

    current_if = SunOSNetwork.parse_interface_line(words, current_if, interfaces)

    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'] == [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL'], 'mtu': '8232'}]
    assert current_if['ipv6'] == []


# Generated at 2022-06-23 00:12:12.874533
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork({}, [])
    assert sunos_network._platform == 'SunOS'
    assert sunos_network.facts['default_ipv4']['interface'] == 'unknown0'

# Generated at 2022-06-23 00:12:24.793156
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from collections import defaultdict
    from operator import itemgetter
    module = type('FakeModule', (object,), {})
    m = SunOSNetwork(module)
    # Prepare test data
    facts = defaultdict(dict)
    # 'parse_interface_line' is called with keywords:
    # words, current_if, interfaces, when_parsing_interface=True
    #
    # words is a list of tokens from a line of ifconfig output
    # current_if is a dict of interface facts
    # interfaces is a dict of dicts of interface facts

    # Example ifconfig line from Solaris:
    # bge0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
    #
    # This example has IPv4, but the following examples do not

# Generated at 2022-06-23 00:12:37.542918
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Arrange
    module = None
    ifconfig_path = 'ifconfig'
    words = ['lo0:3',
             'flags=0x40<LOOPBACK,RUNNING>',
             'mtu 16436',
             'index 2']

    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    interfaces[current_if['device']] = current_if

    # Act
    sunos_net = SunOSNetwork()
    current_if = sunos_net.parse_interface_line(words, current_if, interfaces)

    # Assert
    assert current_if['device'] == 'lo0:3'

# Generated at 2022-06-23 00:12:38.554063
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()

# Generated at 2022-06-23 00:12:49.440767
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class SunOSNetwork
    """

    fixtures = []

    for output in fixtures:
        module = MockModule()
        module.run_command.return_value = (0, output['parsed'], "")
        m_open = mock_open()
        m_open.return_value.readline.side_effect = output['file'].splitlines()
        conf = SunOSNetwork(module)
        conf.get_interfaces_info('fake_path')
        # check output
        print("Parsed output: " + str(module.facts))
        assert module.facts['interfaces'] == output['interfaces']
        assert module.facts['all_ipv4_addresses'] == output['all_ipv4_addresses']

# Generated at 2022-06-23 00:12:52.021717
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module)
    assert collector.platform == 'SunOS'


# Generated at 2022-06-23 00:12:54.563786
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:12:56.523165
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    '''Unit test for constructor of class SunOSNetwork'''
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    a = SunOSNetwork({}, {})
    assert isinstance(a._ifconfig_path, list)
    assert a._ifconfig_path[0] == '/usr/sbin/ifconfig'

# Generated at 2022-06-23 00:13:00.597566
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This will test the constructor of the SunOSNetworkCollector class
    """
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'
    assert network_collector._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:13:11.743630
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Method 'parse_interface_line' of class SunOSNetwork should return a
    dictionary with keys 'device', 'ipv4', and 'ipv6'.
    Should also set type to 'loopback' for loopback interfaces.
    """
    module = None
    iface = 'lo0'
    words = ['lo0:', 'flags=8001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu 8232', 'index 1']
    current_if = {'device': iface, 'ipv4': [], 'ipv6': []}
    interfaces = {iface: current_if}
    sn = SunOSNetwork(module)
    result = sn.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:13:20.208451
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos = SunOSNetwork()
    assert sunos.get_device_name(['lo0:', 'flags=2001000849', 'mtu', '2000']) == 'lo0'
    assert sunos.get_device_name(['lo0:', 'flags=2001000849', 'mtu', '2000']) == 'lo0'
    assert sunos.get_device_name(['lo0:', 'flags=2001000849', 'mtu', '2000']) == 'lo0'
    assert sunos.get_device_name(['lo0:', 'flags=2001000849', 'mtu', '2000']) == 'lo0'
    assert sunos.get_device_name(['lo0:', 'flags=2001000849', 'mtu', '2000']) == 'lo0'


# Generated at 2022-06-23 00:13:23.216197
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    ip_obj = SunOSNetwork(module)

    assert ip_obj._platform == 'SunOS'

# Generated at 2022-06-23 00:13:29.962101
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    try:
        assert SunOSNetworkCollector.__name__ == 'SunOSNetworkCollector'
        assert SunOSNetworkCollector._fact_class.platform == 'SunOS'
        assert SunOSNetworkCollector._platform == 'SunOS'
        assert SunOSNetworkCollector._fact_class.__name__ == 'SunOSNetwork'
    except AssertionError:
        raise AssertionError('Assertion failed.')

# Generated at 2022-06-23 00:13:40.008495
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This test checks if the SunOSNetworkCollector object is
    created successfully.
    """
    network_collector = SunOSNetworkCollector()
    assert network_collector.platform == 'SunOS'


## Unit test for SunOSNetwork class
#
# TODO: 'parse_interface_line' and 'parse_inet*_line' leave two dicts in the
# ipv4/ipv6 lists which is ugly and hard to read.
# This quick hack merges the dictionaries. Purely cosmetic.
#
#def test_SunOSNetwork():
#    """
#    This test checks if the SunOSNetwork is working properly.
#    """



# Generated at 2022-06-23 00:13:47.327396
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    data = dict(current_if=dict(macaddress='00:00:00:00:00:00'), ips=dict())
    words = ['ether', '0:9:c4:13:c3:4b']
    SunOSNetwork().parse_ether_line(words, data['current_if'], data['ips'])
    mymac = data['current_if']['macaddress']
    assert(mymac == '00:09:c4:13:c3:4b')

# Generated at 2022-06-23 00:13:56.094572
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = Mock()
    module.run_command = Mock()
    module.run_command.return_value = (0, 'ether 8:0:27:49:2c:30', '')
    s = SunOSNetwork(module)
    current_if = {}
    ips = {}
    s.parse_ether_line(module.run_command.return_value[1].split(), current_if, ips)
    assert current_if == {'macaddress': '08:00:27:49:2c:30'}

# Generated at 2022-06-23 00:14:04.600990
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Unit tests for SolarisNetwork.parse_interface_line
    import sys
    from ansible.module_utils.facts.network.sunos.sunos import SunOSNetwork
    interface = SunOSNetwork()

    # This is a fragment of what Solaris 'ifconfig -a' prints for single interface:

# Generated at 2022-06-23 00:14:15.731978
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Test with Solaris 11.2
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    facts = dict()
    iface_info = dict()
    module.params['gather_subset'] = ['all']
    module.run_command = MagicMock(return_value=(0, 'ifconfig -a', ''))
    ipv4_re_search = re.compile(
        r'^(\S+):\sflags=\S+\<(.*)\> mtu (\d+) '
        r'(?:metric \d+ )?\S+ (?:(\S+) )?\S+ (?:(\S+) )?\S+ (?:(<(\S+)>)?\s+)?$'
    )
    ipv6_re_

# Generated at 2022-06-23 00:14:19.732747
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())
    sunos_network = SunOSNetwork(module)
    # Just run the constructor and destructor of the SunOSNetwork class
    del sunos_network

# Generated at 2022-06-23 00:14:23.134715
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector._platform = 'SunOS'
    SunOSNetworkCollector._fact_class = SunOSNetwork
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 00:14:24.805629
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork()


# Generated at 2022-06-23 00:14:25.697860
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    n = SunOSNetworkCollector()
    assert n.facts is not None



# Generated at 2022-06-23 00:14:29.848847
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleFakeModule()
    ifconf = "/sbin/ifconfig"
    net = SunOSNetwork(module=module)
    interfaces = net.get_interfaces_info(ifconf)[0]

    for iface in interfaces:
        for v in 'ipv4', 'ipv6':
            for fact in interfaces[iface][v]:
                for key in fact:
                    assert key in ['address',
                                   'broadcast',
                                   'netmask',
                                   'network',
                                   'macaddress',
                                   'flags',
                                   'mtu']

# Generated at 2022-06-23 00:14:34.851470
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork({})
    iface_facts = facts.parse_ether_line(['ether', 'a:b:c:d:e:f'], {}, {})
    assert iface_facts['macaddress'] == 'a:b:c:d:e:f'

# Generated at 2022-06-23 00:14:42.783426
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = type('ansible.module_utils.facts.network.sunos.NetworkCollector', (object,), {})
    module.run_command = type('ansible.module_utils.facts.network.sunos.NetworkCollector', (object,), {})
    module.run_command.return_value = 1, '', ''
    mm = SunOSNetwork(module)

    assert mm.platform == 'SunOS'
    assert isinstance(mm, SunOSNetwork)



# Generated at 2022-06-23 00:14:55.403605
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = FakeModule({})

# Generated at 2022-06-23 00:14:57.399027
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:15:09.258030
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    module.params['gather_network_resources'] = ['interfaces']

    nm = SunOSNetwork(module)
    # Load ifconfig output
    with open(os.path.join(fixture_path, 'Solaris_ifconfig_a')) as f:
        content = f.read()

    # Mock run_command() method called by get_interfaces_info()
    def run_command(cmd, check_rc=True):
        return [0, content, '']

    setattr(nm, 'run_command', run_command)

    nm.get_interfaces_info('/sbin/ifconfig')
    print(json.dumps(nm.interfaces, indent=4))

# Unit

# Generated at 2022-06-23 00:15:09.792432
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    pass

# Generated at 2022-06-23 00:15:22.609249
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    '''
    The following test checks that the various flags and MTU are correctly assigned
    to the correct list (ipv4/ipv6)
    '''
    words = ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    module = None
    fact = SunOSNetwork(module)
    current_if = {'device': 'test_device'}
    interfaces = {}
    interfaces = fact.parse_interface_line(words, current_if, interfaces)
    assert len(interfaces['e1000g0']['ipv4']) == 1

# Generated at 2022-06-23 00:15:35.715434
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Test the method: SunOSNetwork.get_interfaces_info"""
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

# Generated at 2022-06-23 00:15:43.012175
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test = SunOSNetwork(dict())
    test_words = ['ether', '0:1:2:d:e:f', 'group', '0']
    test_current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}
    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    test.parse_ether_line(test_words, test_current_if, test_ips)
    assert test_current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:15:46.040464
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    SunOSNetworkCollector(module)
    assert module.exit_json.called

# Generated at 2022-06-23 00:15:58.028048
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector.facts['all_ipv4_addresses'] == ['10.10.10.1', '10.0.0.1', '192.168.0.1', '10.0.0.1', '10.0.0.1', '192.168.0.1', '10.0.0.1']
    assert collector.facts['all_ipv6_addresses'] == ['2001:470:1f0d:1c::1', '2001:470:1f0d:1c::1', '2001:470:1f0d:1c::1']

# Generated at 2022-06-23 00:16:02.874890
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    line = 'lo0:4: flags=46000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8232 index 1'
    test_obj = SunOSNetwork({})
    current_if = {}
    current_if = test_obj.parse_interface_line(line.split(), current_if, {})
    assert current_if == {'device': 'lo0', 'ipv4': [], 'ipv6': [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv6', 'VIRTUAL'], 'mtu': '8232'}], 'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:16:12.896444
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    network = SunOSNetwork(None)
    current_if = {}
    interfaces = {}

    # test line with ipv4 interface
    words = ['lo0:', 'flags=20048<LOOPBACK,RUNNING,MULTICAST>', 'mtu', '8232', 'index', '1']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '20048<LOOPBACK,RUNNING,MULTICAST>'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['ipv6'] == []

    # test line with ipv6 interface

# Generated at 2022-06-23 00:16:25.300408
# Unit test for method get_interfaces_info of class SunOSNetwork