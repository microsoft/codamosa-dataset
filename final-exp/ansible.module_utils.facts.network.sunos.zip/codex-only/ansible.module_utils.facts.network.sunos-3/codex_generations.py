

# Generated at 2022-06-23 00:06:36.540195
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork({})
    current_if = {}
    ips = {}
    words = ['ether', '0:1:2:d:e:f', 'ether', '2:1:2:d:e:f', 'ether', 'a:1:2:d:e:f', 'ether', 'b:1:2:d:e:f', 'ether', 'c:1:2:d:e:f', 'ether', 'f:1:2:d:e:f', 'ether', 'e:1:2:d:e:f', 'ether', 'd:1:2:d:e:f', 'ether', '1:1:2:d:e:f', 'ether', '0:0:0:0:0:0']

# Generated at 2022-06-23 00:06:39.191963
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Unit test for constructor of SunOSNetwork class."""
    sunos_network = SunOSNetwork()

    assert sunos_network is not None

# Generated at 2022-06-23 00:06:48.444988
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = SunOSNetwork()
    line = 'lo0:flags=800849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8232 index 1\n'
    words = line.split()
    inf = {}
    inf = facts.parse_interface_line(words, inf, {})
    assert inf['device'] == 'lo0'
    assert inf['ipv4'] == [{'flags': '<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>', 'mtu': '8232'}]
    assert inf['ipv6'] == []
    assert inf['macaddress'] == 'unknown'
    assert inf['type'] == 'loopback'


# Generated at 2022-06-23 00:07:00.979000
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    iface = dict()
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    iface = SunOSNetwork().parse_interface_line(words, iface, {})
    assert iface['type'] == 'loopback'
    assert iface['device'] == 'lo0'
    assert iface['ipv4'] == [{'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '8232'}]
    assert iface['ipv6'] == []

    iface = dict()

# Generated at 2022-06-23 00:07:08.769823
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    current_if = {}
    ips = dict()
    sunos_network = SunOSNetwork()

    sunos_network.parse_ether_line(['ether', '0:b:0:7c:df:6a'], current_if, ips)
    assert current_if['macaddress'] == '00:0b:00:7c:df:6a'

# Generated at 2022-06-23 00:07:11.154002
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sc = SunOSNetworkCollector()

    assert sc._fact_class is SunOSNetwork
    assert sc._platform is 'SunOS'

# Generated at 2022-06-23 00:07:19.344297
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Test that the constructor gives the right values when we have
    a SunOS system with an interface.
    """

    test_facts = dict()

# Generated at 2022-06-23 00:07:32.869173
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    sunos_network_module = SunOSNetwork('/sbin/ifconfig', 'SunOS')

    assert sunos_network_module.platform == 'SunOS'
    assert sunos_network_module.ifconfig_path == '/sbin/ifconfig'
    assert sunos_network_module.get_interfaces.__module__ == 'ansible.module_utils.facts.network.sunos.SunOSNetwork'
    assert sunos_network_module.get_interfaces_info.__module__ == 'ansible.module_utils.facts.network.sunos.SunOSNetwork'
    assert sunos_network_module.get_interfaces_ipv4.__module__ == 'ansible.module_utils.facts.network.sunos.SunOSNetwork'
    assert sunos_network_module.get_interfaces_ipv6

# Generated at 2022-06-23 00:07:44.778931
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    class Module:

        # stub AnsibleModule object
        def __init__(self, params=None):
            self.params = params

        def run_command(self, cmd, check_rc=True):
            rc = 0
            out = ''
            err = ''


# Generated at 2022-06-23 00:07:49.408779
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    interfaces, ips = collector.get_interfaces_info('/sbin/ifconfig')
    assert len(interfaces) == 3
    assert len(interfaces['lo0']) == 4
    assert len(interfaces['lo0']['ipv4']) == 1
    assert len(interfaces['lo0']['ipv6']) == 1
    assert len(interfaces['lo0']['ipv4'][0]) == 3
    assert len(interfaces['lo0']['ipv6'][0]) == 5
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-23 00:07:59.399868
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:08:02.546423
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()

    assert network_collector._fact_class is SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-23 00:08:05.264436
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork

# Generated at 2022-06-23 00:08:16.256798
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector as SunOSNetworkModule
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    module = SunOSNetworkModule()
    test_interface = SunOSNetwork(module)


# Generated at 2022-06-23 00:08:18.972562
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sunos_collector = SunOSNetworkCollector()
    assert sunos_collector._fact_class == SunOSNetwork
    assert sunos_collector._platform == 'SunOS'

# Generated at 2022-06-23 00:08:24.123906
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork({}, dict(module_execute=lambda *args, **kwargs: (0, '', ''),
                                module_fail_json=lambda *args, **kwargs: None,))
    assert net.platform == 'SunOS'
    assert net.module_name == 'facts.collector.network.sunos'
    assert net.ifconfig_path == '/sbin/ifconfig'
    assert net.ip_path == '/usr/sbin/ip'


# Generated at 2022-06-23 00:08:28.965767
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert (collector.platform == 'SunOS')
    assert (collector._fact_class == SunOSNetwork)
    assert (collector.platform == SunOSNetwork.platform)



# Generated at 2022-06-23 00:08:30.735518
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    return SunOSNetworkCollector()

# Generated at 2022-06-23 00:08:40.845613
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_obj = SunOSNetwork()

    # test case 1: string with leading zeroes
    words = ['ether', '0:1:2:a:b:c']
    expected_macaddress = '00:01:02:0a:0b:0c'
    current_if = {'macaddress': ''}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    test_obj.parse_ether_line(words, current_if, ips)
    assert(current_if['macaddress'] == expected_macaddress)

    # test case 2: string with mixed leading zeroes
    words = ['ether', '00:00:1:2:a:b']

# Generated at 2022-06-23 00:08:45.676682
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network_class = SunOSNetwork()
    current_if = {}
    words = ['ether', '0:1:2:d:e:f']

    sunos_network_class.parse_ether_line(words, current_if)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:08:52.611315
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    facts = {}
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = SunOSNetwork.parse_interface_line(facts, words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['macaddress'] == 'unknown'
    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv6']) == 0
    assert current_if['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-23 00:08:56.293107
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())
    network_collector = SunOSNetwork(module)
    assert network_collector._platform == 'SunOS'


# Generated at 2022-06-23 00:09:02.571021
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    data = dict(
        module=None,
        run_command=None,
    )
    fact = SunOSNetwork(data)
    words = ['ether', '0:1:2:d:e:f']
    current_if = {'device': 'lo0'}
    ips = {}
    fact.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:09:07.565347
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert isinstance(SunOSNetworkCollector(None, None, None), NetworkCollector)


# Generated at 2022-06-23 00:09:09.463840
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nc = SunOSNetworkCollector(None, None)
    assert nc.get_fact_class() == SunOSNetwork

# Generated at 2022-06-23 00:09:13.271533
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())
    network = SunOSNetwork(module)
    assert network.platform == 'SunOS'
    assert network.facts['all_ipv4_addresses'] == []
    assert network.facts['all_ipv6_addresses'] == []

# Generated at 2022-06-23 00:09:22.537420
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Test case to prove that the constructor of SunOSNetwork
    is working properly."""


# Generated at 2022-06-23 00:09:34.756337
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    iplink_path = module.get_bin_path('ip', required=False)
    iproute_path = module.get_bin_path('ip', required=False)
    if os.path.exists(iplink_path):
        facts = SunOSNetworkCollector(module).collect()
    else:
        facts = {}
    # Assert nothing if facts are empty
    if facts == {}:
        pass
    # Assert SunOSNetwork.__doc__
    assert SunOSNetwork.__doc__
    # Assert SunOSNetwork.platform
    assert SunOSNetwork.platform == 'SunOS'
    # Assert SunOSNetwork.get_interfaces_info() for the loopback interface

# Generated at 2022-06-23 00:09:38.488619
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Runs a simple test of the SunOSNetworkCollector constructor
    """
    net = SunOSNetworkCollector()
    assert net.platform == 'SunOS'
    assert net.fact_class.platform == 'SunOS'
    assert 'SunOS' in net.get_facts()
    assert 'net0' in net.get_facts()['SunOS']['interfaces']


# Generated at 2022-06-23 00:09:41.863058
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())
    sunos_network_collector = SunOSNetwork(module)
    assert sunos_network_collector.platform == "SunOS"
    assert sunos_network_collector.ifconfig_path == '/sbin/ifconfig'


# Generated at 2022-06-23 00:09:51.795557
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    ifconfig_out = '''lo0: flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4> mtu 8232 index 1
        inet 127.0.0.1 netmask ff000000
        lo0: flags=2000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6> mtu 8252 index 1
        inet6 ::1/128
        ixgbe0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
        ether 0:21:28:ce:2f:5c
        '''.splitlines()

    # result of parsing ifconfig_out

# Generated at 2022-06-23 00:10:04.022559
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import textwrap

    results = SunOSNetwork.get_interfaces_info(SunOSNetwork(), "/sbin/ifconfig")

    # This is the expected result.
    # Only interface 'aggr' is of type 'gretap'.
    # Only interface 'aggr' is 'up'.
    # Only interface 'aggr' has 'BROADCAST' flag set.
    # Only interface 'aggr' has 'MTU=1500' and 'MTU=1476'.
    # Only interface 'aggr' has link-level address '00:00:5e:00:01:01'.
    # Only interface 'aggr' has IPv4 address '10

# Generated at 2022-06-23 00:10:07.960433
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('', (), {})
    module.run_command = lambda x: (0, '', '')
    module.exit_json = lambda **x: x
    module.fail_json = lambda **x: x
    module.params = {}
    ifconfig_path = "/sbin/ifconfig"
    setattr(SunOSNetwork, 'module', module)
    setattr(SunOSNetwork, 'ifconfig_path', ifconfig_path)
    sunos = SunOSNetwork()
    assert 'lo0' == sunos.parse_interface_line(['lo0:', 'flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232'], {}, {})['device']
    assert '2004841' == sunos.parse_interface_line

# Generated at 2022-06-23 00:10:11.193699
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork

# Generated at 2022-06-23 00:10:12.714650
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-23 00:10:16.645647
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSNetwork
    assert obj.fact_subdir == 'SunOS'
    assert obj.secondary_u

# Generated at 2022-06-23 00:10:24.686044
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    fact_class = SunOSNetwork()
    assert fact_class.parse_interface_line(['lo0:', 'flags=2001000849', 'mtu', '8232'], {}, {}) == {'device': 'lo0:', 'ipv4': [{'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:10:35.349416
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    current_if = dict()
    words = ['ether', 'a:b:c:d:e:f']
    sunos_network.parse_ether_line(words, current_if, dict())
    assert current_if['macaddress'] == 'a:b:c:d:e:f'
    words = ['ether', '0:1:2:d:e:f']
    sunos_network.parse_ether_line(words, current_if, dict())
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:10:47.309154
# Unit test for method parse_ether_line of class SunOSNetwork

# Generated at 2022-06-23 00:10:51.087880
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._fact_class.platform == 'SunOS'


# Generated at 2022-06-23 00:10:53.056177
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 00:10:59.171516
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetworkFacts

    # Set up objects so that parse_interface_line can run:
    # modules_utils.basic.AnsibleModule() sets up sys.path
    # NetworkCollector() calls the _fact_class to get the SunOSNetwork() object
    # NetworkCollector()._fetch_facts() calls SunOSNetwork().get_interfaces_info(ifconfig_path)
    # SunOSNetwork().get_interfaces_info(ifconfig_path) calls 'ifconfig -a' to get STDOUT
    #
    # 'ifconfig -a' STDOUT is read line-by-line below so that we can get to the bit
    # where SunOSNetwork().parse_interface_line() is called.
    #
    # If 'parse_interface_

# Generated at 2022-06-23 00:11:02.462327
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    obj = SunOSNetwork()
    assert isinstance(obj, SunOSNetwork)
    assert isinstance(obj, GenericBsdIfconfigNetwork)
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 00:11:05.318813
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = MagicMock()
    obj = SunOSNetwork(module)
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 00:11:17.167324
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    assert SunOSNetwork().parse_interface_line(
        ["lo0:", "flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>", "mtu", "8232", "index", "2"],
        {}, {},
    ) == {
        'device': 'lo0',
        'ipv4': [
            {'flags': set(['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']), 'mtu': '8232'}
        ],
        'ipv6': [],
        'type': 'loopback',
        'macaddress': 'unknown',
    }


# Generated at 2022-06-23 00:11:19.428759
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Create a SunOSNetworkCollector instance
    SunOSNetworkCollector()


# Generated at 2022-06-23 00:11:28.363280
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    C = SunOSNetwork({})
    words = "ether 0:3:ba:26:3:18".split()
    interface = {'device': 'net0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    # Test normal MAC address
    C._parse_ether_line(words, interface, {})
    assert interface['macaddress'] == '00:3:ba:26:3:18'
    # Test single digit MAC address
    words = "ether 0:1:2:d:e:f".split()
    C._parse_ether_line(words, interface, {})
    assert interface['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:11:41.611004
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec=dict())
    args = dict(
        words=['bge0', 'UP', '1234', 'MTU:2000', 'IPv4', 'IPv6'],
        current_if={},
        interfaces={}
    )
    testobj = SunOSNetwork(module)
    current_if = testobj.parse_interface_line(**args)
    assert current_if['device'] == 'bge0'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'][0]['flags'] == ['UP', '1234', 'MTU:2000', 'IPv4', 'IPv6']

# Generated at 2022-06-23 00:11:52.722881
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Test variables
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
             'mtu', '8232', 'index', '1']

    # Create an instance of class SunOSNetwork
    sunos_net = SunOSNetwork()

    # Call method parse_interface_line
    current_if = sunos_net.parse_interface_line(words, current_if, interfaces)

    # Assertions
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert len(current_if['ipv4']) == 1
    assert len(current_if['ipv6']) == 0

# Generated at 2022-06-23 00:12:06.311824
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    Net = SunOSNetwork
    net = Net()

    # Assert 'net.platform' is 'SunOS'
    assert net.platform == 'SunOS'

    # Assert 'net.distribution' is 'None'
    assert net.distribution is None

    # Assert 'net.get_interfaces_info()' returns 'True'
    assert net.get_interfaces_info('tests/unit/module_utils/facts/network/test_sunos_ifconfig.txt')

    # Verify 'net.interfaces' is 'dict'
    assert isinstance(net.interfaces, dict)

    # Verify 'net.interfaces' contains 'dict'
    assert isinstance(net.interfaces['lo0'], dict)

    # Verify 'net.interfaces['lo0']' contains 'dict'

# Generated at 2022-06-23 00:12:19.034377
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork

    test_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}
    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    accept_no_leading_zero = ['0:1:2:3:4:5', '0:0:0:d:e:f', '0:0:a:b:c:d']
    accept_with_leading_zero = ['00:01:02:03:04:05', '00:00:00:0d:0e:0f', '00:00:0a:0b:0c:0d']

# Generated at 2022-06-23 00:12:22.487130
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sc = SunOSNetworkCollector()
    assert sc._platform == 'SunOS'
    assert sc._fact_class == SunOSNetwork
    assert sc._fact_class.platform == 'SunOS'


# Generated at 2022-06-23 00:12:35.299133
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    current_if = {}
    interfaces = {}
    words = ''
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    SunOSNetwork(module).parse_interface_line(words, current_if, interfaces)
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['flags'] == '2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>'

# Generated at 2022-06-23 00:12:46.462493
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import Interface

    ifconfig_path = 'tests/unit/module_utils/facts/network/test_SunOS_ifconfig_path'
    module_mock = Interface({}, {}, [ifconfig_path, '-a'])
    net = SunOSNetwork(module=module_mock)

    interfaces, ips = net.get_interfaces_info(ifconfig_path)

    # test that the network class is able to parse the interfaces correctly
    assert interfaces['lo0']['macaddress'] == '00:00:00:00:00:00'
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
   

# Generated at 2022-06-23 00:12:58.304135
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    collector = SunOSNetworkCollector()

    with open('test/unit/module_utils/facts/network/test_SunOSNetwork_get_interfaces_info.out') as f:
        test_output = f.read()

    collector.module = AnsibleModuleMock({'paths': {'ifconfig': '/sbin/ifconfig'}})
    collector.module.run_command = AnsibleRunCommandMock(rc=0, out=test_output)
    interfaces, ips = collector.get_interfaces_info('/sbin/ifconfig')
    assert interfaces

    assert interfaces['bge0']['has_ipv4']
    assert interfaces['bge0']['has_ipv6']

# Generated at 2022-06-23 00:13:07.159366
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    m = SunOSNetwork(dict(module=dict(), fail_json=dict(msg='Fail')))
    words = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'.split()
    current_if = dict()
    interfaces = dict()
    current_if = m.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['mtu'] == '8232'

# Generated at 2022-06-23 00:13:18.042698
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork()
    current_if = {}
    ips = {}

    words = ['ether', '0:1:2:d:e:f']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert 'macaddress' in current_if
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

    words = ['ether', '0:1:2:3:4:5']
    sunos_network.parse_ether_line(words, current_if, ips)
    assert 'macaddress' in current_if
    assert current_if['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-23 00:13:28.675551
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_iface_dict = {
        'ipv4': [{'flags': [], 'mtu': '1500'}],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown',
    }
    test_ips_dict = {}
    test_net = SunOSNetwork({})
    test_net.parse_ether_line(['ether', '0:1:2:3:4:5'], test_iface_dict, test_ips_dict)
    assert(test_iface_dict['macaddress'] == '00:01:02:03:04:05')

# Generated at 2022-06-23 00:13:37.625863
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork({})
    iface = {'device': 'dmfe0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', '0:1:2:d:e:f']
    iface = facts.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:13:48.896207
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    data = {
        'interface': 'lo0',
        'ipv4': [{
            'flags': ['UP', 'LOOPBACK', 'RUNNING'],
            'mtu': 8232
        }],
        'ipv6': [],
        'macaddress': 'unknown',
        'type': 'unknown'
    }
    solaris_network = SunOSNetwork(dict(module=dict(run_command=lambda *_: (0, 'ether 0:1:2:3:4:5 \n', ''))))
    solaris_network.parse_ether_line(['ether', '0:1:2:3:4:5'], data, {})
    assert solaris_network.interfaces['lo0']['macaddress'] ==  '00:01:02:03:04:05'

# Generated at 2022-06-23 00:14:00.011504
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # initialize module
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['all'], type='list'),
    })
    # initialize SunOSNetwork
    SunOSNetwork = SunOSNetwork(module)
    # get interfaces_info
    interfaces_info = SunOSNetwork.get_interfaces_info()
    # check interfaces_info
    assert interfaces_info
    assert isinstance(interfaces_info, tuple)
    assert len(interfaces_info) == 2
    assert isinstance(interfaces_info[0], dict)
    assert isinstance(interfaces_info[1], dict)

# Generated at 2022-06-23 00:14:12.741261
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Test case with all octets single digits
    words = ['ether', '0:1:2:3:4:5']
    current_if = {}
    ips = {}
    SunOSNetwork.parse_ether_line(None, words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    # Test case with all octets double digits
    words = ['ether', '00:11:22:33:44:55']
    current_if = {}
    ips = {}
    SunOSNetwork.parse_ether_line(None, words, current_if, ips)
    assert current_if['macaddress'] == '00:11:22:33:44:55'
    # Test case with leading zeros in various octets

# Generated at 2022-06-23 00:14:26.124501
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:14:27.731599
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = MagicMock()
    SunOSNetwork(module)

# Generated at 2022-06-23 00:14:33.794714
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos_network = SunOSNetwork(None)

    facts = {}
    words = ['ether', '0:d:e:f:a:b']
    sunos_network.parse_ether_line(words, facts, None)
    assert facts['macaddress'] == '00:0d:0e:0f:0a:0b'

# Generated at 2022-06-23 00:14:36.711502
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sn = SunOSNetwork({'ansible_module_args': {}})

    assert sn is not None and sn.__class__.__name__ == 'SunOSNetwork'

# Generated at 2022-06-23 00:14:41.958013
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector.__name__ == 'SunOSNetworkCollector'

# Generated at 2022-06-23 00:14:44.285674
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network = SunOSNetwork({})
    assert sunos_network.platform == 'SunOS'



# Generated at 2022-06-23 00:14:54.445665
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    collector = SunOSNetworkCollector()
    assert isinstance(collector, SunOSNetworkCollector)
    assert isinstance(collector, NetworkCollector)
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 00:15:00.346469
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Construct an instance of the SunOSNetworkCollector
    sunos_facts = SunOSNetworkCollector(dict(), 'ansible_net_sunos')
    # Assert that _fact_class is of class SunOSNetwork
    assert(sunos_facts._fact_class == SunOSNetwork)
    # Assert that _platform is SunOS
    assert(sunos_facts._platform == 'SunOS')

# Generated at 2022-06-23 00:15:11.392562
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interface = {}
    iface = {}
    # test 1st line of a Solaris ifconfig output
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    iface = SunOSNetwork.parse_interface_line(None, words, interface, iface)
    # test 2nd line of a Solaris ifconfig output
    words = ['flags=a00988411041<UP,BROADCAST,RUNNING,MULTICAST,DEPRECATED,IPv4,PHYSRUNNING,NOFAILOVER>', 'mtu', '1500']
    iface = SunOSNetwork.parse_interface_line(None, words, interface, iface)

# Generated at 2022-06-23 00:15:22.066997
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    Test case to ensure that
    parse_ether_line() function works as expected.
    """
    # create test data
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    module = ''
    test_object = SunOSNetwork(module)
    words = ['ether', '0:1:2:d:e:f']
    expected_output = {'macaddress': '00:01:02:0d:0e:0f'}

    # test the code
    test_object.parse_ether_line(words, current_if, ips)

    # assert the output
    assert current_if == expected_output

# Generated at 2022-06-23 00:15:35.230975
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('AnsibleModule', (object,), {'run_command': lambda *_: (0, '', '')})
    obj = SunOSNetwork(module)


# Generated at 2022-06-23 00:15:35.883274
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-23 00:15:40.622107
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import get_file_content
    test1 = get_file_content('tests/unit/module_utils/facts/network/test_SunOSNetwork_get_interfaces_info.txt')
    test2 = SunOSNetwork().get_interfaces_info('')
    assert test1 == test2

# Generated at 2022-06-23 00:15:42.888632
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    ifcfg = SunOSNetwork({})
    assert ifcfg.facts['default_ipv4']['route'] == "true"

# Generated at 2022-06-23 00:15:55.731684
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:16:06.657429
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # call function with test values for words, current_if, and interfaces
    current_if = GenericBsdIfconfigNetwork.parse_interface_line(['net0:', 'flags=1000843', 'mtu', '1500'], {}, {})
    # test for successful call
    assert current_if['device'] == 'net0'
    assert current_if['ipv4'][0]['flags'] == ['BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert current_if['ipv4'][0]['mtu'] == '1500'
    assert not current_if['ipv6']
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-23 00:16:18.453638
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    Return the results of parse_ether_line function of class SunOSNetwork.
    :return: Parse ether line function output.
    """
    sunos_network = SunOSNetwork()
    current_if = {'ipv6': [], 'ipv4': [{'flags': set(['IPv6']), 'mtu': '1500'}, {'flags': set(['IPv6']), 'mtu': '1500'}], 'device': 'net0', 'type': 'unknown', 'macaddress': 'unknown'}
    ips = dict(all_ipv6_addresses=[], all_ipv4_addresses=[])
    words = ['ether', '1:2:3:4:5:6']
    sunos_network.parse_ether_line(words, current_if, ips)
   

# Generated at 2022-06-23 00:16:28.709327
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from collections import namedtuple
    module = namedtuple("module", ["run_command"])
    
    interfaces = {}
    current_if = {}
    iface = "e1000g0: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 1"
    iface = iface.split()
    current_if = SunOSNetwork.parse_interface_line(None, iface, current_if, interfaces)
    assert current_if["device"] == "e1000g0"
    assert current_if["ipv4"] != []
    assert current_if["ipv6"] == []
    assert current_if["type"] == "unknown"
    
    interfaces = {}
    current_if = {}