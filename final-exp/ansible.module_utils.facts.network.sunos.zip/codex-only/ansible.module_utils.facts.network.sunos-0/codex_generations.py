

# Generated at 2022-06-23 00:06:33.009014
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork(dict(module=dict(run_command=lambda x, check_rc=False: (0, 'ether 0:1:2:d:e:f', ''))))
    current_if = dict()
    ips = dict()
    words = ['ether', '0:1:2:d:e:f']
    m.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:06:35.493818
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    test = SunOSNetwork()
    assert test, "test is null"
    assert test._platform == 'SunOS', test._platform
    assert test._fact_class == 'SunOSNetwork'

# Generated at 2022-06-23 00:06:40.878395
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    from ansible.module_utils.facts.network.sunos.collector import SunOSNetwork as sunos_network_collector
    fact_network_sunos = sunos_network_collector()
    if fact_network_sunos.version != '7':
        fact_network_sunos.version = 7     # Purely cosmetic. Fake a version 7 system
    return fact_network_sunos

# Generated at 2022-06-23 00:06:42.983889
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 00:06:44.697094
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(dict())
    network = SunOSNetwork(module)
    network.get_interfaces_info()

# Generated at 2022-06-23 00:06:51.780003
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    test_SunOSNetwork = SunOSNetwork(module)

    interfaces = {}

    # Test IPv4 line
    words = ['em1:', 'flags=20100843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT>', 'mtu', '1500', 'index', '6']
    current_if = test_SunOSNetwork.parse_interface_line(words, None, interfaces)
    assert current_if['device'] == 'em1'
    assert current_if['type'] == 'unknown'
    assert current_if['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-23 00:07:02.246150
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    class FakeModule:
        def run_command(self):
            pass
    class FakeSunOSNetwork(SunOSNetwork):
        def __init__(self):
            self.module = FakeModule()
            self.parse_known_interfaces = dict()
    iface = FakeSunOSNetwork()

    words = ['e1000g0', 'up', 'mtu', '1500', 'ip', '10.0.0.1', 'netmask', '255.255.255.0', 'broadcast', '10.0.0.255', 'groupname', 'default-link']
    current_if = dict()
    interfaces = dict()
    current_if = iface.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:07:14.429183
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    class AcmeModule:
        def __init__(self):
            self.run_command = lambda x, y, z: (0, "", "")

    class DummyIfconfig:
        def __init__(self, module):
            self.module = module

    x = SunOSNetwork()
    x.module = AcmeModule()
    x.parse_interface_line(None, None, None)

    current_if = {}
    interfaces = {}

# Generated at 2022-06-23 00:07:18.320760
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_words = "ether 0:1:2:d:e:f".split()
    test_network = SunOSNetwork()
    result = test_network.parse_ether_line(test_words, {}, {})
    assert result == {'macaddress': '00:01:02:0d:0e:0f'}

# Generated at 2022-06-23 00:07:23.407023
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    words = 'lo0:3'.split()
    current_if = SunOSNetwork.parse_interface_line(SunOSNetwork(), words, current_if, interfaces)
    assert(current_if['device'] == 'lo0')
    assert(current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'ADDRCONF'])
    assert(current_if['ipv4'][0]['mtu'] == '8232')
    assert(current_if['ipv6'] == [])
    assert(current_if['type'] == 'loopback')


# Generated at 2022-06-23 00:07:27.503068
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector(None, {}).collect()
    assert facts['local']['default_ipv4']['gateway'] == '0.0.0.0'

# Generated at 2022-06-23 00:07:39.421299
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '1']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    test_SunOSNetwork = SunOSNetwork(None)

    current_if = test_SunOSNetwork.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert 'flags' in current_if['ipv4'][0]
    assert 'mtu' in current_if['ipv4'][0]
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-23 00:07:41.120944
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector().get_facts() is not None

# Generated at 2022-06-23 00:07:51.189132
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    collector = SunOSNetwork({})
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # test with single digit octets in MAC address
    words = ['ether', '0:1:2:3:4:5']
    collector.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    # test with double digit octets in MAC address
    words = ['ether', '00:11:22:33:44:55']
    collector.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:11:22:33:44:55'

# Generated at 2022-06-23 00:07:53.417461
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = object()
    collector = SunOSNetworkCollector(module)
    assert(collector._fact_class == SunOSNetwork)
    assert(collector._platform == 'SunOS')

# Generated at 2022-06-23 00:08:01.217777
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:08:13.942480
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    sunos_network = SunOSNetwork()

    # Add two network interfaces
    interfaces = {}
    current_if = {}
    words = ['lo0', '::1', 'lo0:', 'flags=2001000849', '<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>', 'mtu', '16384', 'index', '1']
    current_if = sunos_network.parse_interface_line(words, current_if, interfaces)
    interfaces[current_if['device']] = current_if
    words = ['en5', 'unspec', 'en5:', 'flags=1000890', '<BROADCAST,RUNNING,SIMPLEX,MULTICAST,DEPRECATED>', 'mtu', '1500', 'index', '2']
    current_

# Generated at 2022-06-23 00:08:22.620697
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:08:35.841186
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Create test object
    module = AnsibleModuleMock()
    sunosnet = SunOSNetwork(module)

    # Create test variables
    words = ['ce0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    current_if = {'device': 'ce0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    current_if = sunosnet.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'ce0'
    assert interfaces == {}
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'][0]['mtu'] == '8232'


# Generated at 2022-06-23 00:08:46.689294
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    names = ['get_interfaces_info', 'get_default_interfaces', 'get_interfaces']

# Generated at 2022-06-23 00:08:59.793355
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    s = SunOSNetwork()
    # Argument current_if is a dict which will be returned if no changes are made
    assert s.parse_interface_line(['lo0:'], {'device': 'lo0'}, {}) == {'device': 'lo0'}
    # check IPv4
    assert s.parse_interface_line(['igb0:', 'flags=201000843', 'mtu=9000'], {}, {}) == {
        'device': 'igb0', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'], 'mtu': '9000'}],
        'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    # check IPv6 - use first dict returned by parse_interface_line()

# Generated at 2022-06-23 00:09:01.068094
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock()
    SunOSNetworkCollector(module)



# Generated at 2022-06-23 00:09:13.845088
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    sunosnet = SunOSNetwork()
    current_if = {}
    interfaces = {}

    with patch.object(sunosnet, 'get_options') as mock_get_options:
        mock_get_options.return_value = []
        current_if = sunosnet.parse_interface_line(['vnet0:', 'flags=', 'mtu', '1500'], current_if, interfaces)
        assert current_if['device'] == 'vnet0'
        assert current_if['ipv4'] == [{'flags': [], 'mtu': '1500'}]
        assert current_if['ipv6'] == []

# Generated at 2022-06-23 00:09:15.185230
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModuleMock({})
    SunOSNetworkCollector(module)

# Generated at 2022-06-23 00:09:22.627096
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos = SunOSNetwork()
    assert sunos.platform == 'SunOS'
    assert sunos.get_interfaces_info("/usr/sbin/ifconfig") == ({"lo0": {"device": "lo0",
                                                                        "ipv4": [{"flags": ["UP", "LOOPBACK", "RUNNING"],
                                                                                  "mtu": "8232"}],
                                                                        "ipv6": [{"flags": ["UP", "LOOPBACK", "RUNNING"],
                                                                                  "mtu": "8252"}],
                                                                        "macaddress": "unknown",
                                                                        "type": "loopback"}},
                                                               {"all_ipv4_addresses": [],
                                                                "all_ipv6_addresses": []})



# Generated at 2022-06-23 00:09:34.804033
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    net = SunOSNetwork()

    net.parse_ether_line(['ether', '0:1:2:d:e:f'], {}, {})
    assert net.parse_ether_line.current_if
    assert net.parse_ether_line.current_if['macaddress'] == '00:01:02:0d:0e:0f'

    net.parse_ether_line(['ether', '0:0:2:d:e:f'], {}, {})
    assert net.parse_ether_line.current_if
    assert net.parse_ether_line.current_if['macaddress'] == '00:00:02:0d:0e:0f'


# Generated at 2022-06-23 00:09:36.085387
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Tests the SunOSNetwork class
    """
    SunOSNetwork('module')

# Generated at 2022-06-23 00:09:46.780935
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    sunos_network = SunOSNetwork({}, {}, {})
    # empty line
    words = []
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}
    sunos_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == 'unknown'
    # no mac in line
    words = ['blah', 'blah']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}

# Generated at 2022-06-23 00:09:55.152913
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:10:06.505399
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    test_SunOSNetwork_parse_ether_line() ensures the
    parse_ether_line() method of SunOSNetwork parses Solaris MAC addresses
    with leading zeros correctly.
    """

    # To test the method we create an instance of SunOSNetwork
    # We don't need an actual connection. The instance will use
    # a faked connection.
    instance = SunOSNetwork({})
    interface = {}
    ips = {}

    words = ['ether', '0:1:2:1d:e:f']
    instance.parse_ether_line(words, interface, ips)
    assert interface['macaddress'] == '00:01:02:1d:0e:0f'

# Generated at 2022-06-23 00:10:08.716133
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mysunos_network_obj = SunOSNetwork({})
    assert mysunos_network_obj is not None

# Generated at 2022-06-23 00:10:10.742240
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = MagicMock()
    SunOSNetwork(module=module)

# Generated at 2022-06-23 00:10:14.470309
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.facts.network.sunos import SunOSNetworkCollector

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    # Should work even if we aren't root
    module._ansible_become = False
    module._ansible_no_log = True

    # Insert a test module so we can control the return value of run_command()
    test_module = SunOSNetworkCollector(module)
    # Add the module as

# Generated at 2022-06-23 00:10:16.839894
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'
    assert issubclass(SunOSNetworkCollector._fact_class, GenericBsdIfconfigNetwork)

# Generated at 2022-06-23 00:10:18.213772
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork.platform == 'SunOS'


# Generated at 2022-06-23 00:10:25.024144
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())
    ifconfig_path = module.get_bin_path('ifconfig', True)
    result = {}
    if not ifconfig_path:
        module.fail_json(msg='ifconfig command not found')
    else:
        result = SunOSNetworkCollector.collect(module=module)
    module.exit_json(ansible_facts=result)



# Generated at 2022-06-23 00:10:38.062958
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    assert current_if == {'flags': ['LOOPBACK', 'UP', 'MULTICAST', 'RUNNING', 'VIRTUAL', 'IPv4'], 'mtu': '8232', 'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

# Generated at 2022-06-23 00:10:40.075431
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj.platform == 'SunOS'


# Generated at 2022-06-23 00:10:51.482645
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:10:52.569292
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)


# Generated at 2022-06-23 00:11:04.336714
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    ########################################################################
    #### INPUT TESTS, THESE LINES ARE PASSED TO THE parse_interface_line ####
    ########################################################################

    # match (interface)
    test_input1 = "e1000g0: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS> mtu 1500 index 3"

    # match (interface)
    test_input2 = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1"

    # match (interface)

# Generated at 2022-06-23 00:11:16.055267
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, SUNOS_IFCONFIG_ALL, None)
    obj = SunOSNetwork(mock_module)
    interfaces, ips = obj.get_interfaces_info('/sbin/ifconfig')
    assert interfaces['lo0']['ipv4'][0]['address'] == "127.0.0.1"
    assert interfaces['lo0']['ipv4'][0]['netmask'] == "255.0.0.0"
    assert interfaces['net0']['macaddress'] == "0:14:4f:a2:17:ff"

# Generated at 2022-06-23 00:11:27.116586
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:11:40.019604
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    this_network_obj = SunOSNetwork()
    this_network_obj.parse_interface_line(['eri0:', 'flags=6001000849<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>', 'mtu=1500'], current_if, interfaces)
    assert interfaces['eri0']['device'] == 'eri0'
    assert interfaces['eri0']['type'] == 'unknown'

# Generated at 2022-06-23 00:11:43.182859
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test get_interfaces_info()
    """
    SunOSNetworkTest = SunOSNetwork()
    SunOSNetworkTest.module = 'module'
    SunOSNetworkTest.module.run_command = mock_run_command

    interfaces, ips = SunOSNetworkTest.get_interfaces_info('/sbin/ifconfig')

    assert get_test_result(interfaces) == get_test_interfaces()
    assert get_test_result(ips) == get_test_ips()



# Generated at 2022-06-23 00:11:48.776866
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    fact_class = SunOSNetwork({})
    current_if = {}
    ips = {}
    fact_class.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:11:56.583263
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Constructor test"""

# Generated at 2022-06-23 00:12:10.087999
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = line.split()
    my_if = {'device':'lo0', 'ipv4':[], 'ipv6':[], 'type': 'unknown'}
    my_if = SunOSNetwork().parse_interface_line(words, my_if, {})
    assert my_if['device'] == 'lo0'
    assert my_if['type'] == 'loopback'
    assert len(my_if['ipv4']) == 1
    assert len(my_if['ipv6']) == 0
    assert my_if['ipv4'][0]['mtu'] == '8232'
    assert my_

# Generated at 2022-06-23 00:12:14.438452
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    assert network.platform == 'SunOS'
    assert network.ifconfig_path


# Generated at 2022-06-23 00:12:26.851454
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-23 00:12:38.933490
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_data = {'words': ['lo0:',
                           'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>',
                           'mtu 8232',
                           'index 1',
                           'inet 127.0.0.1',
                           'netmask ff000000',
                           'options=3<RXCSUM,TXCSUM>']}

    collector = SunOSNetworkCollector()
    fact_class = collector._fact_class(None)

    result = fact_class.parse_interface_line(test_data['words'], {}, {})

    assert result['device'] == 'lo0'
    assert result['type'] == 'loopback'
    assert result['macaddress'] == 'unknown'

# Generated at 2022-06-23 00:12:49.792356
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    iface = {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}

    # test BSD style single digit octets e.g. 0:1:2:d:e:f
    words = ['ether', '0:1:2:d:e:f']
    facts.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == "00:01:02:0d:0e:0f"

    # test IEEE style single digit octets e.g. 001:2:3:d:e:f
    # Solaris ifconfig will display the IEEE style if the MAC is
    # configured on the interface e.g. 'ifconfig bge0 ether 01

# Generated at 2022-06-23 00:13:01.982752
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeAnsibleModule()
    interfaces = {}
    current_if = {}
    current_if = SunOSNetwork(module).parse_interface_line(
        ['bge0:', 'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu=1500'],
        current_if, interfaces)
    assert current_if['device'] == 'bge0'
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'
    assert len(current_if['ipv4']) == 1
    assert current_if['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-23 00:13:13.226921
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232', 'index', '1']
    current_if = SunOSNetwork().parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'][0]['flags'] == '1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>'
    assert current_if['ipv4'][0]['mtu'] == '8232'
    assert current_if['ipv6'] == []
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-23 00:13:20.708339
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    ifc = SunOSNetwork(module)

    # Test interface with IPv4 only
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    interfaces = {}
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if = ifc.parse_interface_line(words, current_if, interfaces)
    interfaces[current_if['device']] = current_if
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['type'] == 'loopback'

# Generated at 2022-06-23 00:13:33.100173
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '1', 'inet', '127.0.0.1', 'netmask', 'ff000000']
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['ipv4'] == [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'LOOPBACK', 'MULTICAST', 'IPv4'], 'mtu': '8232'}]
    assert current_if['ipv6'] == []
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-23 00:13:36.010129
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module=module)

    assert collector.name == 'SunOS'

# Generated at 2022-06-23 00:13:43.718567
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    # Get the output of ifconfig -a command
    rc, out, err = module.run_command('ifconfig -a')

    # Create an instance of the class SunOSNetwork
    network = SunOSNetwork(module)

    # Invoke the constructor of the class SunOSNetwork
    sunos_network = SunOSNetwork(network)

    # Check that the object sunos_network is a instance of class SunOSNetwork
    assert isinstance(sunos_network, SunOSNetwork)



# Generated at 2022-06-23 00:13:46.306746
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj
    assert obj._fact_class.platform == 'SunOS'
    assert obj._platform == 'SunOS'


# Generated at 2022-06-23 00:13:51.625144
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec={})
    rc = 0
    out = "ether 0:1:2:d:e:f"
    err = ''
    ifc = SunOSNetwork()

    # dict, dict, dict -> dict
    current_if, _, _ = ifc.parse_ether_line(out.split(), {"device": "test"}, {})
    assert current_if["macaddress"] == "00:01:02:0d:0e:0f"

# Generated at 2022-06-23 00:14:02.545433
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from collections import defaultdict
    new_interface = defaultdict(dict)
    new_interface = SunOSNetwork()
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {'device': '', 'type': '', 'ipv4': [], 'ipv6': [], 'macaddress': 'unknown'}
    interfaces = {}
    current_if['device'] = words[0][0:-1]
    current_if['type'] = 'loopback'
    current_if['ipv4'].append({'flags': words[1], 'mtu': words[3]})

# Generated at 2022-06-23 00:14:14.329628
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}


# Generated at 2022-06-23 00:14:17.675327
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Constructor of SunOSNetwork class
    :return:
    """
    SunOSNetwork()

# Generated at 2022-06-23 00:14:19.242246
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net_obj = SunOSNetwork()
    assert type(net_obj) == SunOSNetwork

# Generated at 2022-06-23 00:14:22.649074
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    network = SunOSNetwork(dict(), dict())
    assert network.platform == 'SunOS'
    assert network.module is None
    assert network.interfaces is None
    assert network.ips is None

# Generated at 2022-06-23 00:14:31.479944
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = ansible_mock

    # Constructor test without arguments
    network = SunOSNetwork(module)

    # Constructor test with ifconfig_path
    ifconfig_path = '/sbin/ifconfig'
    network = SunOSNetwork(module, ifconfig_path)
    assert network.ifconfig_path == ifconfig_path
    assert network.module == module
    # 'facts' is a dict
    assert isinstance(network.facts, dict)
    # 'ifconfig' is a dict
    assert isinstance(network.ifconfig, dict)

# Generated at 2022-06-23 00:14:44.520084
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    ifconfig = SunOSNetwork(dict(module=None, params=None), dict())


# Generated at 2022-06-23 00:14:56.866559
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = Mock()

# Generated at 2022-06-23 00:15:08.824952
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    # Define a SunOS different dict for testing.
    sunos_test_dict = {
        'device': 'en0',
        'type': 'loopback',
        'mtu': '1500',
        'flags': 'IPv6,UP'
    }

    # Create an object of SunOSNetwork class
    obj_sunos_network = SunOSNetwork(sunos_test_dict)

    # Check the device fact
    assert obj_sunos_network.device == sunos_test_dict['device']

    # Check the type fact
    assert obj_sunos_network.type == sunos_test_dict['type']

    # Check the MTU fact
    assert obj_sunos_network.mtu == sunos_test_dict['mtu']

    # Check the FLAGS fact
    assert obj_sunos_

# Generated at 2022-06-23 00:15:13.005213
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-23 00:15:23.674993
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    words = ['lo0:', 'flags=2001000849', '<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232', 'index', '2']
    current_if = SunOSNetwork.parse_interface_line(None, words, current_if, interfaces)
    assert current_if['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL'], "Expect FLAGS populated"
    assert current_if['ipv4'][0]['mtu'] == 8232, "Expect MTU populated"

# Generated at 2022-06-23 00:15:28.976938
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    iface = SunOSNetwork(module)
    assert iface.module == module
    assert iface.platform == 'SunOS'
    assert iface.get_interfaces_info == SunOSNetwork.get_interfaces_info

# Generated at 2022-06-23 00:15:40.348615
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    from collections import defaultdict
    module = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
    current_if = SunOSNetworkCollector(module)._fact_class.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'

# Generated at 2022-06-23 00:15:52.096646
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector()
    module.get_interfaces_info = SunOSNetwork.get_interfaces_info
    interfaces = module.get_interfaces_info('path_to_ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert 'en0' in interfaces
    assert 'flags' in interfaces['en0']
    assert 'mtu' in interfaces['en0']
    assert interfaces['en0']['mtu'] == '1500'
    assert 'en1' in interfaces
    assert 'flags' in interfaces['en1']
    assert 'mtu' in interfaces['en1']
    assert interfaces['en1']['mtu'] == '1500'
    assert 'type' in interfaces['en0']
    assert interfaces['en0']['type'] == 'ether'

# Generated at 2022-06-23 00:15:52.957228
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Sanity check to ensure the class init works
    """
    SunOSNetwork()

# Generated at 2022-06-23 00:16:04.934097
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    interfaces = {}
    current_if = {}

# Generated at 2022-06-23 00:16:13.832009
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    words = ['bge0:', 'flags=10008603<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500']
    current_if = {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'bge0': {'device': 'bge0', 'ipv4': [{'flags': '10008603<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown'}}

# Generated at 2022-06-23 00:16:25.854311
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    class MockModule:
        def __init__(self):
            self.run_command = lambda x, check_rc=True: (0, '', '')
            self.fail_json = lambda msg: None
    class MockFacts:
        def __init__(self):
            self.ansible_net_interfaces = {}
            self.ansible_all_ipv4_addresses = []
            self.ansible_all_ipv6_addresses = []
    module = MockModule()
    facts = MockFacts()
    network = SunOSNetwork(module)
    network.set_facts(facts)
    current_if = {'device': 'net0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}