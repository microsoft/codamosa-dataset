

# Generated at 2022-06-23 00:06:34.274317
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {}
    ips = {}
    words = ['ether', '0:1:2:d:e:f']
    iface = SunOSNetwork.parse_ether_line(SunOSNetwork(), words, iface, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'
    words = ['ether', 'ab:cd:ef:12:34:56:78:90:12:34:56:78:90']
    iface = SunOSNetwork.parse_ether_line(SunOSNetwork(), words, iface, ips)
    assert iface['macaddress'] == 'ab:cd:ef:12:34:56:78:90:12:34:56:78:90'

# Generated at 2022-06-23 00:06:45.141690
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))
    obj = SunOSNetwork(module=module)

    interfaces_info, ips_info = obj.get_interfaces_info('/sbin/ifconfig')
    current_if = {}
    for line in fp:
        if line:
            words = line.split()
            if re.match('^\\S', line) and len(words) > 3:
                current_if = obj.parse_interface_line(words, current_if, interfaces_info)
                interfaces_info[current_if['device']] = current_if
            elif words[0].startswith('options='):
                obj.parse_options_line(words, current_if, ips_info)


# Generated at 2022-06-23 00:06:58.594505
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork()
    iface = {'device': 'igb0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # test_parse_ether_line(self, words, current_if, ips)
    words = ['ether', '0:1:2:d:e:f']
    sunos_network.parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-23 00:07:00.575611
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    sun_collector = SunOSNetworkCollector()
    assert sun_collector.platform == 'SunOS'
    assert sun_collector._fact_class == SunOSNetwork



# Generated at 2022-06-23 00:07:04.656016
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    mm = SunOSNetworkCollector()
    assert mm._platform == 'SunOS'
    assert mm._fact_class == SunOSNetwork


# Generated at 2022-06-23 00:07:14.692573
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Constructor test of SunOSNetwork class.
    """
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.six import PY3

    obj = SunOSNetwork()
    assert isinstance(obj, SunOSNetwork)
    assert isinstance(obj, GenericBsdIfconfigNetwork)
    if PY3:
        assert obj.__dict__ == GenericBsdIfconfigNetwork().__dict__
    else:
        assert obj.__dict__ == GenericBsdIfconfigNetwork().__dict__
    assert obj.platform == 'SunOS'

# Generated at 2022-06-23 00:07:21.906381
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = type('', (object,), {})()
    module.run_command = lambda *args, **kwargs: (0, ['0:1:2:d:e:f\n'], '')

    interfaces = {}
    current_if = {'device': 'e1000g0'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    sunos = SunOSNetwork(module)
    sunos.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, ips)

# Generated at 2022-06-23 00:07:34.770451
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=['!all'], type='list'))
    )
    test_SunOSNetwork = SunOSNetwork(test_module)

# Generated at 2022-06-23 00:07:46.581375
# Unit test for method parse_interface_line of class SunOSNetwork

# Generated at 2022-06-23 00:07:47.719215
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class is SunOSNetwork
    assert obj._platform == 'SunOS'


# Generated at 2022-06-23 00:07:50.280718
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    def test_isinstance(obj, class_or_classes, msg=None):
        if not isinstance(obj, class_or_classes):
            raise AssertionError("%s is not instance of %s" % (obj, class_or_classes))

    sunos = SunOSNetwork()
    test_isinstance(sunos, SunOSNetwork)
    test_isinstance(sunos, NetworkCollector)
    test_isinstance(sunos, object)

# Generated at 2022-06-23 00:07:53.315714
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSNetwork
    assert issubclass(obj._fact_class, NetworkCollector)
    assert obj._constants == {}



# Generated at 2022-06-23 00:07:59.690572
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['!all', '!min'])})
    warn = False
    result = dict(changed=False)
    if module.params['gather_subset'] == ['!all', 'min']:
        warn = True
    net = SunOSNetwork(module)
    result['ansible_network_resources'] = net.get_facts()
    if warn:
        result['warnings'] = 'The gather_subset option has been modified to match the requested subset.'
    module.exit_json(**result)



# Generated at 2022-06-23 00:08:01.723111
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sn = SunOSNetwork()
    assert sn.platform == 'SunOS'



# Generated at 2022-06-23 00:08:06.228597
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert issubclass(SunOSNetworkCollector, NetworkCollector)
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-23 00:08:16.971881
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test SunOSNetwork.get_interfaces_info method
    """

# Generated at 2022-06-23 00:08:24.899769
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MockModule(params={'gather_network_resources': 'no'})
    facts = SunOSNetwork(module)
    words = ['e1000g0', 'UP', 'LOOPBACK', 'RUNNING', 'MTU', '1500', 'IPv4,']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'lo0': {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}}
    result = facts.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:08:35.898146
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    ifconfig_path = os.path.expanduser('~/workspace/unix-tools/bin/ifconfig')
    if not os.path.exists(ifconfig_path):
        module.fail_json(msg="Could not find ifconfig: %s" % ifconfig_path)

    sunos_net = SunOSNetwork(module)
    interfaces, ips = sunos_net.get_interfaces_info(ifconfig_path)
    assert isinstance(interfaces, dict)



# Generated at 2022-06-23 00:08:46.732410
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    _tmpfile_path = '../ansible/module_utils/facts/network/generic_bsd/test_files/SunOS_network_output'
    _tmpfile = open(_tmpfile_path, 'r')
    lines = _tmpfile.readlines()
    _tmpfile.close()

    _tmpifconfig_path = '../ansible/module_utils/facts/network/generic_bsd/test_files/SunOS_ifconfig_output'
    _tmpifconfig = open(_tmpifconfig_path, 'r')
    _ifconfig_lines = _tmpifconfig.readlines()
    _tmpifconfig.close()

    ifconfig_path = '/sbin/ifconfig'
    # We aren't actually running a command here, so we use a dummy class

# Generated at 2022-06-23 00:08:59.839826
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})
    module.exit_json = lambda x: x  # bypass AnsibleModule.run_command()

    # mock module.run_command()

# Generated at 2022-06-23 00:09:04.250100
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict())
    network_facts = SunOSNetwork()
    network_facts.populate(module=module)
    assert network_facts.interface_name_conversions == {}
    assert network_facts.platform_device_mappings == {}

# Generated at 2022-06-23 00:09:08.229885
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector()
    assert network_collector._fact_class is SunOSNetwork
    assert network_collector._platform is 'SunOS'


# Generated at 2022-06-23 00:09:17.974419
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    current_if = {}
    interfaces = {}

    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL>', 'mtu', '8232']
    new_current_if = SunOSNetwork(module).parse_interface_line(words, current_if, interfaces)

    assert new_current_if is not current_if

# Generated at 2022-06-23 00:09:24.531578
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_object = SunOSNetwork()
    test_data = ['0:1:2:d:e:f']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_object.parse_ether_line(test_data, current_if, [])
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:09:28.164917
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class.platform == 'SunOS'


# Generated at 2022-06-23 00:09:39.230404
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork({})
    c = {'device': 'net0'}
    # Input is the output of command 'ifconfig -a' on Solaris 10
    # Output is the c['macaddress'] value from method parse_ether_line()
    test = [
        {'input': 'ether 0:14:4f:aa:71:4a', 'output': '00:14:4f:aa:71:4a'},
        {'input': 'ether 0:1:2:d:e:f', 'output': '00:01:02:0d:0e:0f'},
    ]

    for t in test:
        c = m.parse_ether_line(t['input'].split(), c, '')
        assert c['macaddress'] == t['output']
    assert c['device']

# Generated at 2022-06-23 00:09:49.736753
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork(dict(module=dict()))
    current_if = {}

    # standard mac address (uppercase)
    line = 'ether 0:1:2:3:4:5'
    words = line.split()
    m.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:03:04:05'

    # lowercase mac address
    line = 'ether 0:1:2:3:4:5'
    words = line.split()
    m.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:03:04:05'

    # mixed case mac address

# Generated at 2022-06-23 00:09:57.988341
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_SunOSNetwork = SunOSNetwork({
        'DEVICE': 'lo0',
        'IPV4_ADDRESS': '127.0.0.1',
        'IPV4_NETMASK': '255.0.0.0',
        'IPV4_NETWORK': '127.0.0.0',
        'GATEWAY_ADDRESS': '127.0.0.1',
        'GATEWAY_INTERFACE': 'lo0'
    })
    interfaces = {}
    ips = {}
    assert test_SunOSNetwork.get_interfaces_info(interfaces, ips)



# Generated at 2022-06-23 00:10:10.737502
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ip_path = 'sunos/ifconfig'

# Generated at 2022-06-23 00:10:20.572433
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    nm = SunOSNetwork(module)
    interfaces, ips = nm.get_interfaces_info('ifconfig')

    assert len(interfaces.keys()) == 2
    assert 'lo0' in interfaces
    assert 'en0' in interfaces
    assert len(ips['all_ipv4_addresses']) == 3
    assert '127.0.0.1' in ips['all_ipv4_addresses']
    assert '::1' in ips['all_ipv6_addresses']
    assert '192.168.1.1' in ips['all_ipv4_addresses']



# Generated at 2022-06-23 00:10:32.877270
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_object = SunOSNetwork()

    # Since SunOSNetwork_parse_interface_line() is a helper method
    # used by get_interfaces_info(), this test does not obtain
    # test data from a complete ifconfig -a output.
    # Instead, test data is constructed from the first line
    # of a sample ifconfig -a output as shown below.
    #
    # e1000g0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
    #
    # So the first line in the test data is: ['e1000g0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500', 'index', '2']
    #
    # The second line

# Generated at 2022-06-23 00:10:45.613507
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    Unit test the parse_ether_line
    """
    def test_parse_ether_line(module, current_if_before, words, current_if_after):
        SunOSNetwork.parse_ether_line(module, words, current_if_before, None)
        return current_if_before == current_if_after
    words = ['ether', '0:1:2:d:e:f']
    current_if_before = {'device': ''}
    current_if_after = {'device': '', 'macaddress': '00:01:02:0d:0e:0f'}
    assert test_parse_ether_line(None, current_if_before, words, current_if_after)
    words = ['ether', 'a:b:c:d:e:f']
    current

# Generated at 2022-06-23 00:10:53.184898
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    macaddress = '00:01:02:0d:0e:0f'
    words = ['ether', macaddress.replace(':', '')]
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    obj = SunOSNetwork()
    obj.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == macaddress

# Generated at 2022-06-23 00:10:57.761177
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector(None)
    assert collector.__class__.__name__ == 'SunOSNetworkCollector'
    assert collector._fact_class.__name__ == 'SunOSNetwork'
    assert collector._platform == 'SunOS'

# Unit Test for class SunOSNetwork

# Generated at 2022-06-23 00:10:59.820189
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sn = SunOSNetwork(None)
    assert sn.platform == 'SunOS'


# Generated at 2022-06-23 00:11:09.412947
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    parsed_network = SunOSNetwork()
    parsed_network.parse_ether_line(['ether', '0:1:2:d:e:f'],{},{})
    assert parsed_network.interfaces[0]['macaddress'] == '00:01:02:0d:0e:0f'
    parsed_network.parse_ether_line(['ether', '0:1:2:3:4:5'],{},{})
    assert parsed_network.interfaces[0]['macaddress'] == '00:01:02:03:04:05'

# Generated at 2022-06-23 00:11:21.829537
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    This function is used to unit test the SunOSNetwork constructor.
    """
    module = type('', (object,), dict(run_command=lambda x,: (0, 'out', 'err')))
    facts = SunOSNetwork(module=module)
    assert facts
    assert facts.platform == 'SunOS'
    assert 'options=8<RXCSUM,TXCSUM>' in facts.get_interfaces_info(None)[1]['options']
    assert 'nd6 options=23<PERFORMNUD,ACCEPT_RTADV>' in facts.get_interfaces_info(None)[1]['options']
    assert 'ether 01:02:de:ad:be:ef' in facts.get_interfaces_info(None)[1]['options']

# Generated at 2022-06-23 00:11:30.038763
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():

    modules = {}
    modules['ansible.builtin.solaris_command'] = SolarisCommandMock()

    # Striped down return of 'ifconfig -a' to test 'parse_interface_line' method.
    # Solaris-specific 'options=' and 'ether' lines omitted.

# Generated at 2022-06-23 00:11:33.926215
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    nwc = SunOSNetworkCollector()
    assert nwc._fact_class == SunOSNetwork
    assert nwc._platform == 'SunOS'

# Generated at 2022-06-23 00:11:46.392078
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:11:55.665494
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test method get_interfaces_info of class SunOSNetwork
    """

# Generated at 2022-06-23 00:12:00.967607
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    network_collector = SunOSNetworkCollector("SunOS")
    assert network_collector._fact_class == SunOSNetwork
    assert network_collector._platform == 'SunOS'

# Generated at 2022-06-23 00:12:13.278535
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos = SunOSNetwork()
    assert sunos.interfaces == {}, "interfaces should be {}"
    assert sunos.interfaces_ipv4 == {}, "interfaces should be {}"
    assert sunos.interfaces_ipv6 == {}, "interfaces should be {}"
    assert sunos.all_ipv4_addresses == [], "all_ipv4_addresses should be []"
    assert sunos.all_ipv6_addresses == [], "all_ipv6_addresses should be []"
    assert sunos.default_ipv4 is None, "default_ipv4 should be None"
    assert sunos.default_ipv6 is None, "default_ipv6 should be None"
    assert sunos.default_interface is None, "default_interface should be None"


# Generated at 2022-06-23 00:12:25.597193
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = dict()
    ifconfig_path = 'ifconfig'
    words = ['ether', 'a:b:c:d:e:f']
    current_if = {'device': 'e1000g0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network_facts_obj = SunOSNetwork(module, ifconfig_path)
    network_facts_obj.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == 'a:b:c:d:e:f'


# Generated at 2022-06-23 00:12:36.650246
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    result = SunOSNetwork.parse_interface_line(
        words=['hme0:', 'flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu', '1500'],
        current_if={},
        interfaces={})
    assert result == {
        'device': 'hme0',
        'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv4'],
                  'mtu': '1500'}],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown'
    }



# Generated at 2022-06-23 00:12:40.165839
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module)
    assert collector.platform == 'SunOS'
    assert collector.get_interfaces_info('/sbin/ifconfig')



# Generated at 2022-06-23 00:12:41.566661
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork(dict())


# Generated at 2022-06-23 00:12:44.718824
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module)
    assert collector.get_facts() is not None


# Generated at 2022-06-23 00:12:52.096379
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    m = SunOSNetwork({})
    current_if = {}
    ips = {}
    words = ['ether', '0:c:29:a:b:c']
    m.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:c:29:a:b:c'

    current_if = {}
    ips = {}
    words = ['ether', 'c:29:a:b:c:d']
    m.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == 'c:29:a:b:c:d'

# Generated at 2022-06-23 00:12:59.824289
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector().collect()
    assert facts['all_ipv4_addresses']
    assert facts['all_ipv6_addresses']
    assert facts['default_ipv4']['interface']
    assert facts['default_ipv4']['gateway']
    assert facts['default_ipv6']['interface']
    assert facts['default_ipv6']['gateway']
    assert facts['interfaces']

# Generated at 2022-06-23 00:13:09.465665
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {'device': 'net0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['ether', '0:1:2:3:4:5']
    ips = {}
    SunOSNetwork().parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '00:01:02:03:04:05'
    words = ['ether', 'a:b:c:d:e:f']
    ips = {}
    SunOSNetwork().parse_ether_line(words, iface, ips)
    assert iface['macaddress'] == '0a:0b:0c:0d:0e:0f'



# Generated at 2022-06-23 00:13:19.010956
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    ifname = 'igb0'
    device = 'igb0: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,ROUTER> mtu 1500 index 3'
    ipv4 = 'inet 10.17.39.60 netmask ffffff80 broadcast 10.17.39.127'
    ipv6 = 'inet6 fe80::250:56ff:fe8f:24dd%igb0 prefixlen 64 scopeid 0x3'
    ether = 'ether 00:50:56:8f:24:dd'
    s = SunOSNetwork(ifname, device, ipv4, ipv6, ether)

    if s.current_if is None:
        print('Failed to create an instance of SunOSNetwork class')
    else:
        print('Success!')


# Generated at 2022-06-23 00:13:31.849646
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list')})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    nm = SunOSNetwork(module)

    interfaces_info, ips_info = nm.get_interfaces_info(ifconfig_path)

    # Results are platform-specific.
    if module.params['gather_subset'] in [['!all'], ['network']]:
        platform_subset = 'subset'
    else:
        platform_subset = 'all'

    # Empty network facts for systems without interfaces.
    if interfaces_info:
        interfaces_list = interfaces_info
    else:
        interfaces_list = {}


# Generated at 2022-06-23 00:13:33.339068
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert facts.get_facts() is not None

# Generated at 2022-06-23 00:13:36.281710
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sn = SunOSNetwork()
    # On a Solaris system this should be 'SunOS'
    assert sn.platform == 'SunOS'

# Generated at 2022-06-23 00:13:47.784100
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeAnsibleModule(platform='SunOS')
    sunosnetwork = SunOSNetwork(module)
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {'lo0': current_if}
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '1']
    result = sunosnetwork.parse_interface_line(words, current_if, interfaces)
    assert result['device'] == 'lo0'
    assert result['type'] == 'unknown'
    assert result['ipv4'] == [{'flags': 'IPv6 IPv6multicast LOOPBACK RUNNING', 'mtu': '8232'}]
    assert result['ipv6']

# Generated at 2022-06-23 00:14:00.447452
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    test_interfaces_path = './utils/tests/unit/test_interfaces/SunOS_test_interfaces.facts'
    with open(test_interfaces_path, 'r') as f:
        test_interfaces_data = f.read()
    test_ips_path = './utils/tests/unit/test_ips/SunOS_test_ips.facts'
    with open(test_ips_path, 'r') as f:
        test_ips_data = f.read()

    module = FakeModule({'shell_executable': '/bin/bash',
                         'paths': {'ifconfig': '/sbin/ifconfig'},
                         'run_command': '/bin/bash'})
    obj = SunOSNetwork(module)

# Generated at 2022-06-23 00:14:03.587699
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.platform == 'SunOS'
    assert SunOSNetworkCollector._fact_class == SunOSNetwork
    assert SunOSNetworkCollector._platform == 'SunOS'

# Generated at 2022-06-23 00:14:15.195383
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    inst = SunOSNetwork(module)
    interfaces, ips = inst.get_interfaces_info('/bin/ifconfig')
    assert interfaces['net1']['ipv4'][0]['mtu'] == "1500"
    assert interfaces['net1']['ipv4'][0]['address'] == "192.168.1.10"
    assert interfaces['net1']['ipv6'][0]['mtu'] == "1500"
    assert interfaces['net1']['ipv6'][0]['address'] == "fe80::a00:27ff:fed4:88bb"

# Generated at 2022-06-23 00:14:27.782746
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:14:29.999444
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    obj = SunOSNetwork()
    assert obj.platform == 'SunOS'
    assert obj._platform == 'SunOS'

# Generated at 2022-06-23 00:14:43.135410
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:14:45.060521
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    ifconfig_path = '/sbin/ifconfig'
    network = SunOSNetwork(ifconfig_path)
    assert network.ifconfig_path == '/sbin/ifconfig'


if __name__ == "__main__":
    test_SunOSNetwork()

# Generated at 2022-06-23 00:14:49.565267
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():

    # Initialize the class
    network = SunOSNetwork()
    # Test if type of network object is SunOSNetwork
    assert type(network) is SunOSNetwork
    # Test if the attribute of class is initialized correctly.
    assert network.platform == 'SunOS'

# Generated at 2022-06-23 00:15:01.467188
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )

    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.network.common.utils import p
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.network.common.config import NetworkConfig


    class MockSelinuxBoolean(object):
        def __init__(self, value):
            self.value = value

    class MockSelinux(object):
        def __init__(self, selinux_enabled=None):
            self.selinux_enabled = selinux_enabled


# Generated at 2022-06-23 00:15:10.417039
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sunos = SunOSNetwork()
    current_if = {}
    current_if = sunos.parse_ether_line(['ether', '1:2:3:d:e:f'], current_if, {})
    assert current_if['macaddress'] == '01:02:03:0d:0e:0f'
    current_if = {}
    current_if = sunos.parse_ether_line(['ether', '0:1:2:d:e:f'], current_if, {})
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:15:22.762120
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    module = FakeAnsibleModule()
    sunos_network = SunOSNetwork(module)
    current_if = {}
    # Test with single digit MAC address octets e.g. 0:1:2:d:e:f
    words = ['ether', '0:1:2:d:e:f']
    sunos_network.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == "00:01:02:0d:0e:0f"
    # Test with double digit MAC address octets e.g. 00:11:22:dd:ee:ff
    words = ['ether', '00:11:22:dd:ee:ff']
    sunos_network.parse_ether_line(words, current_if, {})

# Generated at 2022-06-23 00:15:35.931027
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test to verify parsing of output of command - 'ifconfig -a'.
    """

# Generated at 2022-06-23 00:15:44.385544
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:15:52.094890
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig', True)
    network_collector = SunOSNetwork(module, ifconfig_path)
    network_collector.collect()
    interfaces, ips = network_collector.get_interfaces_info(ifconfig_path)
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'


# Generated at 2022-06-23 00:15:53.855815
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    network_collector = SunOSNetworkCollector(module=module)
    interfaces = network_collector.get_interfaces_info('/sbin/ifconfig')
    assert isinstance(interfaces, dict)



# Generated at 2022-06-23 00:15:56.895341
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    c = SunOSNetworkCollector()
    assert c.platform == 'SunOS'
    assert c._fact_class.platform == 'SunOS'


# Generated at 2022-06-23 00:16:08.435512
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class SunOSNetwork"""

    class ModuleMock():
        class RunCommand():
            def __init__(self, rc, out, err):
                self._rc = rc
                self._out = out
                self._err = err

            def run_command(self, cmd):
                return self._rc, self._out, self._err

    IF_MAC_ADDRESS_RE = re.compile("^[0-9a-f]+$")
    IF_IPV4_ADDRESS_RE = re.compile("^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$")

# Generated at 2022-06-23 00:16:11.067670
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():

    facts = SunOSNetwork()
    words = ['ether', '0:1:2:d:e:f']
    current_if = {}
    ips = {}

    facts.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:16:24.557702
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    Unit test for SunOSNetwork.parse_ether_line()
    """
    # Test that with a single digit octet, leading zero is added.
    net = SunOSNetwork()
    current_if = {'macaddress': 'unknown'}
    words = ['ether', '0:a:b:c:d:e']
    net.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == '00:0a:0b:0c:0d:0e'
    # Test that with a two digit octet, no leading zero is added.
    net = SunOSNetwork()
    current_if = {'macaddress': 'unknown'}
    words = ['ether', '00:a:b:c:d:e']