

# Generated at 2022-06-23 00:06:36.665275
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    class TestArgs:
        def __init__(self, module):
            self.module = module
    class TestWords:
        def __init__(self, words):
            self.words = words
    class TestIface:
        def __init__(self, current_if):
            self.current_if = current_if
    class TestIps:
        def __init__(self, ips):
            self.ips = ips
    class TestSunOSNetwork:
        def __init__(self, module):
            self.module = TestModule(module)
    class TestModule:
        def __init__(self, module):
            self.module = module
    module = '0:1:2:d:e:f'
    test_words = TestWords((module,))

# Generated at 2022-06-23 00:06:45.694323
# Unit test for constructor of class SunOSNetwork

# Generated at 2022-06-23 00:06:47.930702
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector._platform == 'SunOS'


# Generated at 2022-06-23 00:07:00.718515
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    SunOSNetwork.parse_ether_line() Test
    """

    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list'),
        }
    )
    if not HAS_NET_SYSTEM:
        module.fail_json(msg='The `net_system` module is required but does not appear to be installed. '
                             'It can be installed using `pip install net_system`')

    network_collector = SunOSNetworkCollector(module)
    network_collector.collect()
    facts = network_collector.get_facts()

    # create an instance of the SunOSNetwork class
    test_instance = SunOSNetwork(module)

    # test valid input

# Generated at 2022-06-23 00:07:11.904628
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    macaddress = '08:00:27:6e:0b:56'
    words = ['ether', '8:0:27:6e:b:56', '(oui)']
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    sunos = SunOSNetwork()
    sunos.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == macaddress

# Generated at 2022-06-23 00:07:13.173062
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    net = SunOSNetwork(dict())
    assert net.platform == 'SunOS'



# Generated at 2022-06-23 00:07:21.010963
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    macaddress = ''
    # Create a mock AnsibleModule object
    context_manager_mock = type('context_manager', (object,), {
        '__enter__': lambda self: self,
        '__exit__': lambda self, exc_type, exc_val, exc_tb: None
    })()
    ansible_module_mock = type('AnsibleModule', (object,), {
        'exit_json': lambda self, **kwargs: None,
        'run_command': lambda self, *args, **kwargs: (0, '', ''),
        'fail_json': lambda self, *args, **kwargs: None,
        'check_mode': False
    })()
    sunos_network = SunOSNetwork(ansible_module_mock)

    # First test, numeric interface

# Generated at 2022-06-23 00:07:33.824054
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Arrange
    current_if = None
    interfaces = {}
    words = ['lo0:', 'flags=2001000849', 'mtu', '8232', 'index', '1']
    expected_current_if = {
        'device': 'lo0',
        'ipv4': [{'flags': '2001000849', 'mtu': '8232'}],
        'ipv6': [],
        'type': 'loopback',
        'macaddress': 'unknown'
    }

    # Act
    sunos_network_module = SunOSNetwork()
    current_if = sunos_network_module.parse_interface_line(words, current_if, interfaces)

    # Assert
    assert current_if == expected_current_if


# Generated at 2022-06-23 00:07:44.021022
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    macaddress = ''
    current_if = {}
    words = ['ether', '0:1:2:3:4:5']
    current_if = SunOSNetwork._fact_class.parse_ether_line(SunOSNetwork, words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    words = ['ether', '0:1:2:3:4:f']
    current_if = SunOSNetwork._fact_class.parse_ether_line(SunOSNetwork, words, current_if, {})
    assert current_if['macaddress'] == '00:01:02:03:04:0f'

# Generated at 2022-06-23 00:07:46.381792
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Constructor of SunOSNetwork can be invoked.
    """

    SunOSNetwork(dict(module=dict()))


# Generated at 2022-06-23 00:07:48.448065
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = SunOSNetworkCollector()
    assert(facts._fact_class == SunOSNetwork)
    assert(facts._platform == 'SunOS')

# Generated at 2022-06-23 00:07:58.440963
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Create instance of class SunOSNetwork
    test_SunOSNetwork = SunOSNetwork()

    # Test lines with each possible single digit octet, in various positions
    words = ["ether", "0:1:2:3:4:5"]
    current_if = {}
    ips = {}
    test_SunOSNetwork.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'

    words = ["ether", "a:b:10:d:e:f"]
    current_if = {}
    ips = {}
    test_SunOSNetwork.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-23 00:08:06.780932
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mod = FakeModule({'path': {'system': '/sbin', 'raw': '/sbin'}})
    c = SunOSNetwork(mod)
    assert c.get_device_name('e1000g1') == 'e1000g1'
    assert c.get_device_name('e1000g0,1') == 'e1000g0_1'
    assert c.get_device_name('e1000g0,1.1') == 'e1000g0_1_1'


# Generated at 2022-06-23 00:08:08.540805
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    facts = {}
    SunOSNetworkCollector(facts, None)
    assert facts['network'].__class__.__name__ == 'SunOSNetwork'

# Generated at 2022-06-23 00:08:18.350521
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # This test tests the method 'parse_interface_line' of class 'SunOSNetwork'

    # Fake module to pass to 'SunOSNetwork' class.
    fake_module = type('', (), {})()

    def fake_run_command(*args, **kwargs):
        return 0, "", ""

    fake_module.run_command = fake_run_command

    sunos_network = SunOSNetwork(fake_module)

    interfaces = {}
    current_if = {}

    # Test ipv4 interface
    current_if = sunos_network.parse_interface_line(['interfacename:', 'flags=0x1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4>', 'mtu=1500'], current_if, interfaces)

# Generated at 2022-06-23 00:08:25.489720
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import set_module_args
    module = AnsibleModule(argument_spec={})
    set_module_args(dict(gather_subset='min'))  # For test_SunOSNetwork the 'min' option is sufficient

    # Read test file and setup temporary 'ifconfig -a' output
    test_file = open('unit/modules/utils/fixtures/SunOS_ifconfig_a_bge0.txt', 'r')
    bge0_output = test_file.read()
    test_file.close()

    test_file = open('unit/modules/utils/fixtures/SunOS_ifconfig_a_lo0.txt', 'r')
    lo0_output = test_file.read()
    test_

# Generated at 2022-06-23 00:08:34.498527
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    iface = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    SunOSNetwork().parse_ether_line(['ether', '0:1:2:d:e:f'], iface, ips)
    assert iface['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:08:45.857536
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})
    fact_class = SunOSNetwork(module)
    fact_class.get_interfaces_info('/usr/sbin/ifconfig')

# Generated at 2022-06-23 00:08:49.716855
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class is not None, 'Ansible network classes are not loaded'
    assert obj._platform == 'SunOS', 'SunOS network platform fact class is missing'


# Generated at 2022-06-23 00:09:01.584593
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    result = SunOSNetwork.parse_interface_line(['lo0:', 'flags=2001000843', 'mtu', '65536'],
                                               {}, {})
    assert result == {'device': 'lo0', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'LOOPBACK', 'IPv4'],
                                                 'mtu': '65536'}],
                      'ipv6': [], 'type': 'loopback'}


# Generated at 2022-06-23 00:09:14.362944
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    network_collector = SunOSNetworkCollector()
    network = network_collector._fact_class()
    interfaces = {}
    current_if = {}
    words = ['lo0:', 'flags=1e080863,849<UP,BROADCAST,LOOPBACK,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>', 'metric', '1', 'mtu', '8232']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if = network.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:09:22.160573
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    # Initialize a SunOSNetwork object
    module = SunOSNetwork(dict(module_defaults='ansible.module_utils.facts.network.generic_bsd'))

# Generated at 2022-06-23 00:09:25.795618
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """ Test SunOSNetworkCollector class constructor """
    c = SunOSNetworkCollector(None)
    assert isinstance(c._fact_class, object)
    assert c._platform == c._fact_class.platform


# Generated at 2022-06-23 00:09:30.914953
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    sunos_network = SunOSNetwork(module)
    assert sunos_network.platform == 'SunOS'
    assert sunos_network.module.get_bin_path('ifconfig') == '/sbin/ifconfig'

# Generated at 2022-06-23 00:09:41.478539
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    Mod = AnsibleModule(argument_spec={})

    m_out = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1\n'
    network = SunOSNetwork(module=Mod, ifconfig_path='/sbin/ifconfig')

    current_if = {}
    interfaces = {}
    words = m_out.split()

    result = network.parse_interface_line(words, current_if, interfaces)

    assert result['device'] == 'lo0'
    assert result['ipv4'][0]['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4', 'VIRTUAL']

# Generated at 2022-06-23 00:09:50.789475
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    from ansible.module_utils.facts import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Always calls superclass's constructor, so reset the class variable
    # 'platform' to the value of the current class.
    GenericBsdIfconfigNetwork.platform = 'SunOS'
    sun = SunOSNetwork()

    current = {}
    ips = {}

    # Test with a '0' at the start of the MAC address
    sun.parse_ether_line(['ether', '0:1:2:3:4:5'], current, ips)
    assert current['macaddress'] == '00:01:02:03:04:05'


# Generated at 2022-06-23 00:10:02.446978
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = type('MyModule', (object, ), {})()
    module.run_command = lambda *args: (0, '', '')
    module.run_command.return_code = 0

    # This output is from Solaris 11.4

# Generated at 2022-06-23 00:10:15.386732
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MyModule(dict(), dict())
    sunos_net = SunOSNetwork(module)
    current_if = {}
    interfaces = dict()

    words = ['e1000g0:', 'flags=1e08086b', 'mtu', '1500']
    current_if = sunos_net.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'e1000g0'
    assert current_if['ipv4'][0]['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'POINTOPOINT', 'NOTRAILERS', 'RXCSUM', 'TXCSUM', 'VLAN_MTU', 'MULTI_BCAST']

# Generated at 2022-06-23 00:10:16.436378
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    SunOSNetworkCollector()


# Generated at 2022-06-23 00:10:21.052407
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    """
    SunOSNetwork.parse_ether_line
    """
    testobj = SunOSNetwork({})
    iface = {}
    testobj.parse_ether_line(['ether', '0:a:b:c:d:e'], iface, {})
    assert iface['macaddress'] == '00:a:b:c:d:e'

# Generated at 2022-06-23 00:10:27.132072
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert isinstance(collector, SunOSNetworkCollector)
    assert isinstance(collector.facts['interfaces'], dict)
    assert isinstance(collector.facts['all_ipv4_addresses'], list)
    assert isinstance(collector.facts['all_ipv6_addresses'], list)

# Generated at 2022-06-23 00:10:40.408209
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    o = SunOSNetwork({})
    o.platform = 'SunOS'

    # TEST 1
    # test with 2-digit MAC
    test_words = []
    test_words.append('ether')
    test_words.append('0:1:2:d:e:f')
    test_current_if = {}
    test_current_if['device'] = 'eth0'
    test_ips = {}
    o.parse_ether_line(test_words, test_current_if, test_ips)
    assert test_current_if['macaddress'] == '00:01:02:0d:0e:0f'

    # TEST 2
    # test with single-digit MAC
    test_words = []
    test_words.append('ether')

# Generated at 2022-06-23 00:10:46.492118
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = None

# Generated at 2022-06-23 00:10:55.663854
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    ifconfig_path = './test_SunOSNetworkIfconfig.txt'
    o = SunOSNetwork()
    interfaces = {}
    with open(ifconfig_path, 'r') as fh:
        for line in fh.readlines():
            words = line.split()
            current_if = {}
            if re.match(r'^\S', line) and len(words) > 3:
                current_if = o.parse_interface_line(words, current_if, interfaces)
                interfaces[current_if['device']] = current_if

# Generated at 2022-06-23 00:11:08.329766
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    current_if = {}
    interfaces = {}
    m = SunOSNetwork(module)
    words = ['e1000g0:',   # device
             'flags=1000843',  # flags
             'mtu',  # mtu
             '1500']  # mtu value
    # Test IPv4 interface
    current_if = m.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'e1000g0'
    assert current_if['type'] == 'unknown'
    assert len(current_if['ipv4']) == 1
    assert current_if['ipv4'][0]['flags'] == '1000843'
    assert current_if['ipv4'][0]['mtu'] == '1500'

# Generated at 2022-06-23 00:11:14.418468
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    def check_SunOSNetwork_parse_interface_line(line, expected):
        """
        Checks method parse_interface_line of class SunOSNetwork
        """
        # initialization
        current_if = {}
        interfaces = {}
        words = line.split()
        print("Running test with input: {0}".format(line))
        # calling the method
        new_if = SunOSNetwork().parse_interface_line(words, current_if, interfaces)
        # checking the result
        assert(new_if == expected)
    # running tests
    # case 1

# Generated at 2022-06-23 00:11:18.513377
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    mod = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    fact_network = SunOSNetwork(mod)
    assert fact_network.platform == 'SunOS'

# Generated at 2022-06-23 00:11:20.013767
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj


# Generated at 2022-06-23 00:11:29.225680
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = None
    ifconfig_path = 'test/unit/ansible_collections/ansible/community/tests/unit/module_utils/facts/network/utils/ifconfig_nobuf'

    test_subject = SunOSNetwork(module)

    interfaces, ips = test_subject.get_interfaces_info(ifconfig_path)

    assert len(interfaces) == 1
    assert 'lo0' in interfaces
    assert len(interfaces['lo0']['ipv4']) == 2
    assert len(interfaces['lo0']['ipv6']) == 2
    assert interfaces['lo0']['ipv4'][0] == {'flags': ['UP', 'LOOPBACK'], 'mtu': '65536'}

# Generated at 2022-06-23 00:11:31.930212
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = object()
    SunOSNetwork(module)


# Generated at 2022-06-23 00:11:33.981071
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    inet_facts = SunOSNetwork()
    assert inet_facts.platform == 'SunOS'

# Generated at 2022-06-23 00:11:38.345825
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Test SunOSNetwork Constructor"""
    # empty module
    module = None
    network = SunOSNetwork(module=module)
    assert network.platform == 'SunOS'

# Unit test of function parse_interface_line()

# Generated at 2022-06-23 00:11:50.092268
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_object_SunOSNetwork = SunOSNetwork()
    interfaces = {'net0': {'device': 'net0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    # For test case
    # test_object_SunOSNetwork.parse_interface_line(['lo0:', 'flags=2004849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>', 'mtu', '8232', 'index', '10'], 'lo0', interfaces)
    words = ['lo0:', 'flags=2004849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6>', 'mtu', '8232', 'index', '10']
    current_if = 'lo0'
    assert test_object_SunOSNetwork.parse

# Generated at 2022-06-23 00:11:56.153778
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.sunos.collections.sunos.netinfo import get_interfaces_info
    from ansible.module_utils import basic

    m = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    interfaces_info = get_interfaces_info(m)
    assert interfaces_info['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-23 00:12:00.845549
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    network = SunOSNetwork(module)
    assert network.platform == 'SunOS'

# Generated at 2022-06-23 00:12:13.181482
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    words = ['e1000g0', 'flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv6>', "mtu=1500"]
    current_if = {}
    interfaces = {}

    sunos = SunOSNetwork()
    current_if = sunos.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == "e1000g0"
    assert current_if['type'] == "unknown"
    assert current_if['macaddress'] == "unknown"
    assert current_if['ipv4'] == [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'IPv6'], 'mtu': '1500'}]
    assert current_if['ipv6'] == []

# Generated at 2022-06-23 00:12:15.642246
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector()
    assert obj._fact_class is SunOSNetwork
    assert obj._platform is 'SunOS'



# Generated at 2022-06-23 00:12:22.433322
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_unit = SunOSNetwork(dict())
    line = 'ether 0:1:2:d:e:f'
    current_if = {}
    ips = {}
    test_unit.parse_ether_line(line.split(), current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'


# Generated at 2022-06-23 00:12:27.252520
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    # Get the SunOSNetwork object
    net_obj = SunOSNetworkCollector.get_network_collector()

    # ---------------------------------------------------------------------- #
    # Test get_interfaces_ip()
    # ---------------------------------------------------------------------- #
    # No test, since it returns a dictionary

    # ---------------------------------------------------------------------- #
    # Test get_interfaces_counters()
    # ---------------------------------------------------------------------- #
    # No test, since it returns a dictionary

    # ---------------------------------------------------------------------- #
    # Test get_interfaces()
    # ---------------------------------------------------------------------- #
    # No test, since it returns a dictionary

    # ---------------------------------------------------------------------- #
    # Test get_interfaces_info()
    # ---------------------------------------------------------------------- #
    # Test using platform specific arguments
    assert net_obj.get_interfaces_info('/sbin/ifconfig') != None

    # ---------------------------------------------------------------------- #
    # Test get_interfaces_ip()

# Generated at 2022-06-23 00:12:39.260723
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    from ansible.module_utils.facts.network.net_tools.bonding import parse_options_line
    from ansible.module_utils.facts.network.net_tools.bonding import parse_nd6_line
    from ansible.module_utils.facts.network.net_tools.bonding import parse_ether_line
    from ansible.module_utils.facts.network.net_tools.bonding import parse_media_line
    from ansible.module_utils.facts.network.net_tools.bonding import parse_status_line
    from ansible.module_utils.facts.network.net_tools.bonding import parse_lladdr_line
    from ansible.module_utils.facts.network.net_tools.bonding import parse_inet_line

# Generated at 2022-06-23 00:12:50.089022
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """This function tests the implementation of the function
    parse_interface_line of the class SunOSNetwork with a given sample
    set of arguments."""

    words_list = [['nge0:', 'flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>', 'mtu=1500'],
                  ['lo0:', 'flags=2001000849<UP,LOOPBACK,ROUTER,PRIVATE,MULTICAST,IPv6>', 'mtu=8232']]

# Generated at 2022-06-23 00:12:53.949288
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    fact_module = NetworkCollector()
    assert fact_module._fact_class.platform == 'SunOS'
    # '_platform' should of been set in constructor of NetworkCollector
    assert fact_module._platform == 'SunOS'


# Generated at 2022-06-23 00:13:05.421172
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    """
    Test "parse_interface_line" of SunOSNetwork.
    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_collector = SunOSNetworkCollector()
    network_collector.get_interfaces_info = Mock(return_value=(dict(), dict()))
    network = network_collector._fact_class(module)

    # test_string = "lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1"
    # IPv4 interface

# Generated at 2022-06-23 00:13:10.903086
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    This is a test for the constructor of class SunOSNetworkCollector
    """
    SunOSNetworkCollectorTest = SunOSNetworkCollector()
    assert SunOSNetworkCollectorTest._fact_class == SunOSNetwork
    assert SunOSNetworkCollectorTest._platform == 'SunOS'

# Generated at 2022-06-23 00:13:17.990446
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test = SunOSNetwork.parse_ether_line
    # Return value of macaddress
    assert test(["ether", "9:9:9:9:9:8"], {}, {}) == {"macaddress": "09:09:09:09:09:08"}
    assert test(["ether", "0:1:2:d:e:f"], {}, {}) == {"macaddress": "00:01:02:0d:0e:0f"}
    assert test(["ether", "0:0:0:0:0:0"], {}, {}) == {"macaddress": "00:00:00:00:00:00"}
    assert test(["ether", "0:0:0:0:"], {}, {}) == {"macaddress": "unknown"}

# Generated at 2022-06-23 00:13:23.678626
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = FakeAnsibleModule()
    ip_collector = SunOSNetwork(module)
    assert ip_collector
    assert ip_collector.module is module
    assert ip_collector.fact_class == SunOSNetwork

# Unit tests for SunOSNetwork.get_interfaces_info()

# Generated at 2022-06-23 00:13:31.207998
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts import collector

    facts_collector = collector.get_network_collector('SunOSNetworkCollector', {})
    assert facts_collector.__class__.__name__ == 'SunOSNetworkCollector'
    assert facts_collector.platform == 'SunOS'
    assert facts_collector._fact_class.__name__ == 'SunOSNetwork'
    assert facts_collector._fact_class.platform == 'SunOS'


# Generated at 2022-06-23 00:13:43.669664
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:13:51.419514
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    sun_network = SunOSNetwork()
    current_if = {}
    ips = {}
    words = []
    words.append('ether')
    words.append('0:1:2:3:4:5')
    sun_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:03:04:05'
    words[1] = '0:1:2:d:e:f'
    sun_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:14:02.545523
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:14:14.329290
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_if = {'example0':
                   {'device': 'example0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}

    test_words = ['example0:', 'flags=1b00843<UP,BROADCAST,RUNNING,ALLMULTI,IPv4,CoS', 'mtu9000']
    test_if = SunOSNetwork().parse_interface_line(test_words, {}, test_if)
    assert test_if == {'example0':
                           {'device': 'example0', 'ipv4': [{'flags': 'UP,BROADCAST,RUNNING,ALLMULTI,IPv4,CoS', 'mtu': '9000'}], 'ipv6': [], 'type': 'unknown'}}

    test_words

# Generated at 2022-06-23 00:14:27.320719
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """Unit test of SunOSNetwork."""

    # root@ns7:~# dladm show-phys
    # LINK        MEDIA             STATE      SPEED  DUPLEX  DEVICE
    # net0        Ethernet          up         1000   full    bnx0
    # net1        Ethernet          unknown    0      unknown bnx0

    # root@ns7:~# ifconfig -a
    # lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
    #          inet 127.0.0.1 netmask ff000000
    #          inet6 ::1/128
    # net0: flags=201000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4,CoS>

# Generated at 2022-06-23 00:14:39.417144
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    SunOSNetwork = SunOSNetwork()
    interfaces = SunOSNetwork.get_interfaces_info()

    for interface in interfaces:
        for v in 'ipv4', 'ipv6':
            if len(interfaces[interface][v]) > 0:
                for facts in interfaces[interface][v]:
                    for k in 'address', 'broadcast', 'netmask':
                        assert facts[k] is not None
        assert interfaces[interface]['macaddress'] is not None

if __name__ == "__main__":
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['all'], type='list')})
    SunOSNetworkCollector.collect(module=module)

# Generated at 2022-06-23 00:14:51.990962
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    This function is used to test the constructor of class SunOSNetwork.
    """
    sunos_network_obj = SunOSNetwork()
    assert sunos_network_obj.platform == 'SunOS'
    assert sunos_network_obj.get_interfaces_info.__doc__ == GenericBsdIfconfigNetwork.get_interfaces_info.__doc__
    assert sunos_network_obj.parse_interface_line.__doc__ == GenericBsdIfconfigNetwork.parse_interface_line.__doc__
    assert sunos_network_obj.parse_options_line.__doc__ == GenericBsdIfconfigNetwork.parse_options_line.__doc__
    assert sunos_network_obj.parse_nd6_line.__doc__ == GenericBsdIfconfigNetwork.parse_nd6_line.__doc__


# Generated at 2022-06-23 00:15:01.077618
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    test_object = SunOSNetwork()
    test_words = ['ether', '0:1:2:d:e:f']
    test_current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    test_object.parse_ether_line(test_words, test_current_if, test_ips)
    assert test_current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:15:05.156453
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """Test the constructor of the SunOSNetworkCollector class."""
    assert not repr(SunOSNetworkCollector()).startswith('<ansible.module_utils.facts.network.sunos.SunOSNetworkCollector object')

# Generated at 2022-06-23 00:15:08.058473
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts import collector
    NetworkCollector = collector.get_network_collector('SunOS', {})
    assert NetworkCollector is not None

# Generated at 2022-06-23 00:15:09.000648
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork({}, {}, {})

# Generated at 2022-06-23 00:15:12.728409
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    obj = SunOSNetworkCollector('/usr/sbin/ifconfig', 'No such file.')
    assert obj._fact_class is SunOSNetwork
    assert obj._platform == 'SunOS'
    assert obj._dev_path == '/usr/sbin/ifconfig'
    assert obj._child_err_msg == 'No such file.'
    assert obj._module is None


# Generated at 2022-06-23 00:15:24.444442
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollector.get_module(None)

# Generated at 2022-06-23 00:15:37.284529
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    line = 'eri100: flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4> mtu 1500 index 2'
    expected_current_if = {'device': 'eri100', 'ipv4': [{'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'DHCP', 'IPv4'], 'mtu': '1500'}], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    current_if = {'device': 'eri100', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    interfaces = {'eri100': current_if}
    ips = [{}]

    sunos = SunOSNetwork()

# Generated at 2022-06-23 00:15:47.736340
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    interfaces = dict()
    ips = dict()
    current_if = dict()

# Generated at 2022-06-23 00:15:53.021100
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_net = SunOSNetwork()
    assert sunos_net.data['all_ipv4_addresses'] == sunos_net.get_ipv4_addr()
    assert sunos_net.data['all_ipv6_addresses'] == sunos_net.get_ipv6_addr()

# Generated at 2022-06-23 00:16:05.038864
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    current_if = {}
    interfaces = {}
    for line in ('lo0:2: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232',
                 'lo0:1: flags=2002000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL> mtu 8252 index 1',):
        words = line.split()
        current_if = SunOSNetwork.parse_interface_line(SunOSNetwork, words, current_if, interfaces)
        interfaces[current_if['device']] = current_if

    assert current_if['type'] == 'loopback'
    assert current_if['macaddress'] == 'unknown'
    assert len(current_if['ipv4']) == 1


# Generated at 2022-06-23 00:16:13.103339
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    mock_device = 'igb0'
    mock_flags = 'UP'
    mock_mtu = '1500'
    mock_words = [mock_device + ':', mock_flags, 'MULTICAST', mock_mtu, '0x10008']

    current_if = {}
    current_if = SunOSNetwork(None).parse_interface_line(mock_words, current_if, {})

    assert current_if['device'] == mock_device
    assert current_if['macaddress'] == 'unknown'
    assert current_if['ipv4'][0]['flags'] == mock_flags
    assert current_if['ipv4'][0]['mtu'] == mock_mtu

# Generated at 2022-06-23 00:16:16.785864
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():

    # TODO: method not tested yet
    return


if __name__ == '__main__':
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-23 00:16:19.539382
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSNetwork


# Generated at 2022-06-23 00:16:29.176248
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_SunOSNet = SunOSNetwork({})
    test_SunOSNet.parse_interface_line(["net0:", "flags=2004841<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>", "mtu", "8232"],
        {}, {}) == {'device': 'net0', 'ipv4': [{'flags': ['LOOPBACK', 'RUNNING', 'MULTICAST', 'IPv4'], 'mtu': '8232'}],
        'ipv6': [], 'type': 'loopback'}