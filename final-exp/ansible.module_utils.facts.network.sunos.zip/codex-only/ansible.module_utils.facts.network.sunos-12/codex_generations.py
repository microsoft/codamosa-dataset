

# Generated at 2022-06-23 00:06:33.302252
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    assert SunOSNetwork.parse_ether_line(('ether:', '0:1:2:d:e:f', '0x1', 'ether'), {}, {}) == \
        {'macaddress': '00:01:02:0d:0e:0f'}
    assert SunOSNetwork.parse_ether_line(('ether:', 'a:b:c:d:e:f', '0x1', 'ether'), {}, {}) == \
        {'macaddress': '0a:0b:0c:0d:0e:0f'}

# Generated at 2022-06-23 00:06:44.046612
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = Mock()
    module.run_command.return_value = 0, '', ''
    sunos_network = SunOSNetwork(module)
    current_if = {}
    # Test for 'lo0' interface
    line = 'lo0: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1'
    words = line.split()
    current_if = sunos_network.parse_interface_line(words, current_if, {})

# Generated at 2022-06-23 00:06:46.918411
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Test case for constructor of class SunOSNetwork
    """
    module = AnsibleModuleMock({})
    collector = SunOSNetworkCollector(module)
    network = SunOSNetwork(module)
    assert collector
    assert network

# Generated at 2022-06-23 00:06:50.029724
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetworkCollector(module=module)
    assert collector._platform == 'SunOS'

# Generated at 2022-06-23 00:06:51.455667
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-23 00:06:55.877200
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_network_facts = SunOSNetwork()
    assert 'platform' in sunos_network_facts.facts
    assert 'default_ipv4' in sunos_network_facts.facts
    assert 'interfaces' in sunos_network_facts.facts


# Generated at 2022-06-23 00:06:58.872926
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    sunos_facts_network = SunOSNetwork()
    assert sunos_facts_network.platform == 'SunOS'


# Generated at 2022-06-23 00:07:11.100278
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:07:19.735320
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:07:33.011345
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    mySunOSNetwork = SunOSNetwork()
    current_if = {}
    interfaces = {}
    words = ['bge0:', 'flags=1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>', 'mtu', '1500']
    current_if = mySunOSNetwork.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'bge0'
    assert current_if['ipv4'][0]['mtu'] == '1500'
    assert current_if['ipv4'][0]['flags'] == '1004843<UP,BROADCAST,RUNNING,MULTICAST,DHCP,IPv4>'
    assert current_if['ipv6'] == []
    assert current_if['type']

# Generated at 2022-06-23 00:07:44.884602
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = ''
    ipaddr = SunOSNetwork(module=module)
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}
    words = ('bge0:', 'flags=1000843', 'mtu', '1500')
    current_if = ipaddr.parse_interface_line(words, current_if, interfaces)
    assert current_if['device'] == 'bge0'
    assert current_if['ipv4'][0]['flags'] == ['BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert current_if['ipv4'][0]['mtu'] == '1500'
    assert current_if['ipv6'] == []

# Generated at 2022-06-23 00:07:54.325795
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = DummyAnsibleModule()
    network = SunOSNetwork(module)
    path = '/sbin/ifconfig'
    interfaces_info, ips = network.get_interfaces_info(path)
    assert len(interfaces_info) == 17
    assert len(ips['all_ipv4_addresses']) == 12
    assert len(ips['all_ipv6_addresses']) == 10
    assert ips['all_ipv6_addresses'][6] == 'fe80::5054:ff:fea1:d2c2'
    assert ips['all_ipv4_addresses'][8] == '10.0.2.15'

# Generated at 2022-06-23 00:08:01.603307
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = type('module', (object,), dict(params=dict()))()
    test_interface = SunOSNetwork(test_module)
    test_interfaces = {}
    test_current_if = {}

    # 'parse_interface_line' should initialize the device, ipv4 and ipv6 facts
    # when a new interface is encountered
    assert test_current_if == {}
    test_current_if = test_interface.parse_interface_line(['bge0:'], test_current_if, test_interfaces)

# Generated at 2022-06-23 00:08:14.311688
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:08:16.353053
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    inventory = SunOSNetwork(module=module)
    assert inventory.platform == 'SunOS'


# Generated at 2022-06-23 00:08:23.698089
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    '''
    Parse a line such as 'ether 8:0:27:2a:8e:7b'
    '''
    line = 'ether 8:0:27:2a:8e:7b'
    words = line.split()
    # Create a fake class to use with testing SunOSNetwork.parse_ether_line()
    c = type("fakeSunOSNetwork", (object,), dict(macaddress='unknown'))
    # Run the parse_ether_line() method with fakeSunOSNetwork object as argument
    c.parse_ether_line(words, c, {})
    assert c.macaddress == '08:00:27:2a:8e:7b'

# Generated at 2022-06-23 00:08:36.950549
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    '''
    Test module for SunOSNetwork.get_interfaces_info()
    '''
    # Constructing data for testing

# Generated at 2022-06-23 00:08:47.647948
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MockModule()
    module.run_command.return_value = (0, '', '')
    sunos_network = SunOSNetwork(module)

    current_if = {}

    # Test case with IPv4 interface and no previous dicts in interfaces
    # The resulting dict should be recognized as a new interface.
    current_if = {}
    interfaces = {}
    words = ['e1000g51:', 'flags=2010002<BROADCAST,SIMPLEX,MULTICAST,IPv4>', 'mtu=1500', 'index=5', 'zone=global']
    result = sunos_network.parse_interface_line(words, current_if, interfaces)

# Generated at 2022-06-23 00:09:00.556858
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:09:13.172390
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    '''
    Example output of Solaris ifconfig -a
    '''

# Generated at 2022-06-23 00:09:22.430085
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch
    module = MagicMock()
    module.run_command.return_value = (0, '', '')

# Generated at 2022-06-23 00:09:34.626536
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    Test method 'get_interfaces_info' of class SunOSNetwork.
    """
    module = MockModule()
    # single interface with IPv4 and IPv6
    module.run_command.return_value = (0, MOCK_IFCONFIG_A, None)
    network = SunOSNetwork(module)
    actual_interfaces, actual_ips = network.get_interfaces_info(ifconfig_path='/sbin/ifconfig')
    assert actual_interfaces == MOCK_SOLARIS_INTERFACES
    assert actual_ips == MOCK_SOLARIS_IPS



# Generated at 2022-06-23 00:09:35.161541
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork()

# Generated at 2022-06-23 00:09:45.962436
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = None
    ifconfig_path = 'ifconfig'
    current_if = {}
    interfaces = {}

    # Solaris can have different FLAGS and MTU for IPv4 and IPv6 on the same interface
    # so these facts have been moved inside the 'ipv4' and 'ipv6' lists.
    # 'parse_interface_line()' checks for previously seen interfaces before defining
    # 'current_if' so that IPv6 facts don't clobber IPv4 facts (or vice versa).
    sunos_facts = SunOSNetwork(module, ifconfig_path)

    # Start with a new interface
    words = ['bge0:', 'UP', 'LOOPBACK', 'RUNNING', 'MULTICAST', 'MTU:1500', 'Metric:1']
    current_if = sunos_facts.parse_

# Generated at 2022-06-23 00:09:54.361753
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:10:07.015329
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """ Unit test for method get_interfaces_info of class SunOSNetwork. """

    from ansible.module_utils.facts.network.tests.unit.fixtures import SunOSNetworkFacts
    from ansible.module_utils.facts.network.tests.unit.fixtures import SunOSIfconfigParse

    network_collector = SunOSNetworkFacts(None, SunOSIfconfigParse)
    interfaces_info = network_collector.get_interfaces_info()

# Generated at 2022-06-23 00:10:19.577648
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    network = SunOSNetwork(module)

    interfaces = {}
    current_if = {}

    device = 'lo0'
    words = ['lo0:', 'flags=2001000849 mtu 8232', 'index 2']
    current_if = network.parse_interface_line(words, current_if, interfaces)
    assert interfaces[device] == {'device': device, 'ipv4': [{'flags': '2001000849', 'mtu': '8232'}], 'ipv6': [], 'type': 'loopback', 'macaddress': 'unknown'}

    # Test that the same physical device with IPv4 and IPv6 interfaces
    # will be merged internally (and not be overwritten in the 'interfaces

# Generated at 2022-06-23 00:10:25.909321
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    facts = SunOSNetwork()
    words = '''ether 0:4:2:c:2:2:'''.split()
    current_if = {}
    ips = {}
    facts.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:04:02:0c:02:02'
    words = '''ether b:a:d:cafe:babe:1'''.split()
    current_if = {}
    ips = {}
    facts.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '0b:0a:0d:0c:0a:0f:0e:01'

# Generated at 2022-06-23 00:10:32.371579
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """Test the method SunOSNetwork.get_interfaces_info"""
    module = MockModule()
    net = SunOSNetwork(module)
    net.get_interfaces_info = Mock(return_value=([], []))
    net.get_interfaces_info('ifconfig_path')
    assert net.get_interfaces_info.call_count == 1


# Generated at 2022-06-23 00:10:35.301127
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert SunOSNetworkCollector.__name__ == 'SunOSNetworkCollector'


# Generated at 2022-06-23 00:10:47.262907
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:10:56.200360
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:11:09.272806
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    """
    Unit test for class 'SunOSNetwork'.
    """

    # Constructor SunOSNetwork()
    module = type('module', (), {})()
    obj = SunOSNetwork(module)

    # Add test for constructor
    assert not hasattr(obj, 'module')

    # has_ipv4()
    obj.module = module
    assert not obj.has_ipv4()

    # has_ipv6()
    assert not obj.has_ipv6()

    # get_interfaces_info()
    assert obj.get_interfaces_info('/bin/ifconfig') == ({}, {})

    # get_interfaces_info() raises an error if command has an exit code.
    def run_command(cmd):
        raise Exception('foobar')

    module.run_command = run_command

# Generated at 2022-06-23 00:11:11.000964
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    assert isinstance(SunOSNetworkCollector(None, None, None), SunOSNetworkCollector)

# Generated at 2022-06-23 00:11:18.584804
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    print("test_SunOSNetwork_get_interfaces_info()")
    fact_class = SunOSNetwork()
    interfaces, ips = fact_class.get_interfaces_info('/sbin/ifconfig')
    print("interfaces: {}".format(interfaces))
    print("ips: {}".format(ips))


if __name__ == '__main__':
    test_SunOSNetwork_get_interfaces_info()

# Generated at 2022-06-23 00:11:19.646509
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    assert SunOSNetwork(dict())



# Generated at 2022-06-23 00:11:21.921368
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    SunOSNetwork(dict(module=dict()), dict(), dict()).populate()


# Generated at 2022-06-23 00:11:30.064468
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_module = SunOSNetworkCollector(dict(module=''), dict())
    words = ['lo0:', 'flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv6,VIRTUAL>',
             'mtu 8232', 'index 1']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}

# Generated at 2022-06-23 00:11:43.467297
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:11:54.223737
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = MockModule()
    sunos_net = SunOSNetwork(module)

# Generated at 2022-06-23 00:12:04.993047
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # Setup mock data
    module = 'ansible.module_utils.facts.network.sunos.SunOSNetworkCollector'
    module_args = {}
    collector = SunOSNetworkCollector(module, module_args)

    # Test SunOSNetworkCollector.__init__()
    assert collector._platform == 'SunOS'
    assert collector._fact_class.platform == 'SunOS'
    assert collector._fact_class.module == module
    assert collector._fact_class.module_args == module_args
    assert collector._module == module
    assert collector._module_args == module_args

# Generated at 2022-06-23 00:12:17.667194
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    from ansible.module_utils.facts.network.sunos.sunos import SunOSNetworkCollector
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Create a instance of SunOSNetworkCollector
    sc = SunOSNetworkCollector()

    # Check that it is an instance of the Singleton NetworkCollector
    assert isinstance(sc, NetworkCollector)
    # Check that it is an instance of the SunOSNetwork
    assert isinstance(sc.facts, SunOSNetwork)
    # Check that it is an instance of the GenericBsdIfconfigNetwork
    assert isinstance(sc.facts, GenericBsdIfconfigNetwork)

    # Try to create another instance of SunOSNetworkCollector
    sc2 = SunOSNetworkCollector()

    # Check that it is the same instance as before


# Generated at 2022-06-23 00:12:29.606924
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:12:41.565365
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = FakeAnsibleModule()
    sunos_network = SunOSNetwork(module)

    current_if = {}
    assert len(current_if.keys()) == 0

    sunos_network.parse_interface_line(['lo1:', 'flags=1000849', '<LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232', 'index', '4'], current_if)

    assert len(current_if.keys()) == 4
    assert current_if['device'] == 'lo1'
    assert current_if['type'] == 'loopback'
    assert len(current_if['ipv4']) == 1
    assert current_if['ipv4'][0]['flags'] == 'LOOPBACK,RUNNING,MULTICAST,IPv4'

# Generated at 2022-06-23 00:12:51.470580
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    # Setup
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    network = SunOSNetwork(module)

    # Test with IPv4 and IPv6 interface

# Generated at 2022-06-23 00:13:03.957850
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = type('module', (object,), {'run_command': lambda x: {'out': '', 'err': '', 'rc': 0}})

    class fake_SunOSNetwork():
        def __init__(self):
            self.module = module

    net = fake_SunOSNetwork()
    words = ['lo0:', 'flags=1000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4>', 'mtu', '8232']
    current_if = {}
    interfaces = {}

    # first time, no interface yet
    new_current_if = net.parse_interface_line(words, current_if, interfaces)

    assert new_current_if['device'] == 'lo0'

# Generated at 2022-06-23 00:13:15.952453
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    """
    test_SunOSNetwork_get_interfaces_info tests various blocks of the parse_interfaces_info method
    of the SunOSNetwork class.
    """

    # Prepare required objects
    module = Mock(run_command=Mock(return_value=('', '', '')))

    # set up test data

# Generated at 2022-06-23 00:13:28.464618
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    AnsibleModuleMock = Mock()
    network_class = SunOSNetwork(AnsibleModuleMock)
    current_if = {}
    interfaces = {}
    out = []

# Generated at 2022-06-23 00:13:30.599797
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    s = SunOSNetwork({}, {}, {})
    assert s.platform == 'SunOS'

# Generated at 2022-06-23 00:13:32.453111
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    collector = SunOSNetworkCollector()
    assert collector.platform == 'SunOS'

# Generated at 2022-06-23 00:13:36.120725
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=['!all'], type='list')))
    SunOSNetworkCollector(module=module).populate()


# Generated at 2022-06-23 00:13:47.644903
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module_mock = Mock(
        params={},
        run_command=Mock(return_value=(0, 'lo0:3 flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1', ''))
    )
    instance = SunOSNetwork(module_mock)
    current_if = {'device': 'test'}
    interfaces = {'lo0':{'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}


# Generated at 2022-06-23 00:14:00.278940
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    ipv4_interfaces = [
        'lo0',
        'net0',
        'net1',
        'ip.tun0',
        'bge0'
    ]
    ipv6_interfaces = [
        'lo0',
        'net0',
        'net1',
        'ip.tun0',
        'bge0'
    ]
    iface_default = dict(
        device='unknown',
        ipv4=[],
        ipv6=[],
        type='unknown',
        macaddress='unknown'
    )
    interfaces = dict()
    for interface in ipv4_interfaces:
        interfaces[interface] = iface_default.copy()
    for interface in ipv6_interfaces:
        interfaces[interface]

# Generated at 2022-06-23 00:14:12.792830
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    with open('../unit/output/SunOS-interface-facts') as output:
        module = type('AnsibleModule', (object,), {'run_command': lambda *args, **kwargs: (0, output.read(), None)})()
        fact_class = SunOSNetwork(module)
        fact_class.populate()
        interfaces = fact_class.interfaces
        assert 'bge0' in interfaces
        assert 'flags' in interfaces['bge0']
        assert 'groups' in interfaces['bge0']
        assert 'ether' in interfaces['bge0']
        assert 'mtu' in interfaces['bge0']
        assert 'ipv4' in interfaces['bge0']
        assert 'broadcast' in interfaces['bge0']['ipv4']

# Generated at 2022-06-23 00:14:26.280594
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    device = 'lo0'
    flag1 = 'UP'
    flag2 = 'LOOPBACK'
    flag3 = 'IPv6'
    mtu = '65536'
    words = [device + ':', flag1 + ',' + flag2 + ',' + flag3, 'MTU', mtu]
    current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces = {}

# Generated at 2022-06-23 00:14:36.051386
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    # Arrange
    test_obj = SunOSNetwork()
    words = ['ether', '0:1:2:d:e:f']
    expected = '00:01:02:0d:0e:0f'
    current_if = {'macaddress': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Act
    test_obj.parse_ether_line(words, current_if, ips)

    # Assert
    assert current_if['macaddress'] == expected

# Generated at 2022-06-23 00:14:42.612820
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    module = NetworkCollectorTestUtils.get_module_mock()
    SunOSFactCollector = SunOSNetworkCollector(module=module)
    SunOSNetwork = SunOSFactCollector.get_network_collector()
    SunOSNetwork.get_interfaces_info(ifconfig_path='/fake/path/to/ifconfig')



# Generated at 2022-06-23 00:14:55.242079
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    ifc = SunOSNetwork({})
    interfaces, ips = ifc.get_interfaces_info('/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces
    assert interfaces['lo0']['type'] == 'loopback'
    assert 'ipv4' in interfaces['lo0']
    assert 'ipv6' in interfaces['lo0']
    assert len(interfaces['lo0']['ipv4']) == 1
    # example solaris 10 interface from zone.  type='unknown' because in zone.
    assert 'bge0' in interfaces
    assert 'bge0' in interfaces
    assert interfaces['bge0']['type'] == 'unknown'
    assert 'ipv4' in interfaces['bge0']

# Generated at 2022-06-23 00:15:07.451812
# Unit test for method get_interfaces_info of class SunOSNetwork
def test_SunOSNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network import SunOSNetwork
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_lines


# Generated at 2022-06-23 00:15:19.207878
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    test_interfaces = {}


# Generated at 2022-06-23 00:15:31.860346
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    current_if = {}
    interfaces = {}
    words = ['em0:', 'flags=1004843', 'metric', '0', 'mtu', '1500', 'inet', '6.7.8.9']
    testclass = SunOSNetwork()
    interface = testclass.parse_interface_line(words, current_if, interfaces)
    assert interface['device'] == 'em0'
    assert interface['ipv4'][0]['flags'] == ['BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert interface['ipv4'][0]['mtu'] == '1500'
    assert len(interface['ipv6']) == 0

# Generated at 2022-06-23 00:15:35.553435
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    """
    Test class constructor
    """
    collector = SunOSNetworkCollector()
    assert collector._fact_class == SunOSNetwork
    assert collector._platform == 'SunOS'


# Generated at 2022-06-23 00:15:43.826456
# Unit test for constructor of class SunOSNetwork
def test_SunOSNetwork():
    module = AnsibleModule(argument_spec={})
    collector = SunOSNetwork(module)
    facts = collector.get_facts()
    assert facts['default_ipv4']['address'] == '192.168.1.10'
    assert facts['default_ipv4']['gateway'] == '192.168.1.1'
    assert facts['interfaces']['eth0']['type'] == 'ether'
    assert facts['interfaces']['eth0']['ipv4'][0]['address'] == '192.168.1.10'
    assert facts['interfaces']['eth0']['ipv4'][0]['netmask'] == '255.255.255.0'

# Generated at 2022-06-23 00:15:48.924098
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    # create an instance of the SunOSNetworkCollector class with a mocked module
    network_collector = SunOSNetworkCollector(load_from_file=False, module=None)
    # verify the name of the Platform
    assert network_collector.platform == 'SunOS'

# Generated at 2022-06-23 00:16:00.847043
# Unit test for method get_interfaces_info of class SunOSNetwork

# Generated at 2022-06-23 00:16:11.606158
# Unit test for method parse_interface_line of class SunOSNetwork
def test_SunOSNetwork_parse_interface_line():
    SunOSNetwork._network_info_paths = dict(ifconfig='/sbin/ifconfig')
    SunOSNetwork_obj = SunOSNetwork()
    interfaces = {}
    current_if = {}

# Generated at 2022-06-23 00:16:22.184391
# Unit test for method parse_ether_line of class SunOSNetwork
def test_SunOSNetwork_parse_ether_line():
    n = SunOSNetwork()
    words = ['ether', '0:1:2:d:e:f']
    interface = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if = interface
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    n.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:01:02:0d:0e:0f'

# Generated at 2022-06-23 00:16:26.340006
# Unit test for constructor of class SunOSNetworkCollector
def test_SunOSNetworkCollector():
    import os

    if not os.path.exists('/sbin/ifconfig'):
        return

    collector = SunOSNetworkCollector()
    assert collector._platform == 'SunOS'
    assert collector._fact_class.platform == 'SunOS'
    assert collector.get_facts() is not None
